# UI notes — 0001511737-13-000013


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001511737-13-000013:notes:1]
SUPPLEMENTARY DATA (UNAUDITED)

[0001511737-13-000013:notes:2]
The following table presents the Company’s unaudited consolidated statements of operations data for each of the eight quarters during fiscal 2013 and 2012. In management’s opinion, this information has been presented on the same basis as the audited consolidated financial statements included in a separate section of this report, and all necessary adjustments, consisting only of normal recurring adjustments, have been included in the amounts below to state fairly the unaudited quarterly results when read in conjunction with the audited consolidated financial statements and related notes. The operating results for any quarter should not be relied upon as necessarily indicative of results for any future period.

[0001511737-13-000013:notes:3]
|  |  | Fiscal 2013 |
| In thousands, except per share data |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 61,535 |  |  | $ | 74,901 |  |  | $ | 83,155 |  |  | $ | 101,232 |  |
| Gross profit |  | 25,020 |  |  | 30,485 |  |  | 35,465 |  |  | 44,364 |  |
| Income from operations |  | 15,775 |  |  | 20,119 |  |  | 23,503 |  |  | 33,207 |  |
| Net income and comprehensive income |  | 13,179 |  |  | 17,803 |  |  | 20,667 |  |  | 28,841 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.14 |  |  | $ | 0.20 |  |  | $ | 0.24 |  |  | $ | 0.33 |  |
| Diluted |  | $ | 0.14 |  |  | $ | 0.20 |  |  | $ | 0.23 |  |  | $ | 0.32 |  |
|  |  | Fiscal 2012 |
|  |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 79,167 |  |  | $ | 87,817 |  |  | $ | 91,665 |  |  | $ | 94,868 |  |
| Gross profit |  | 33,013 |  |  | 37,290 |  |  | 39,659 |  |  | 41,041 |  |
| Income from operations |  | 27,500 |  |  | 31,176 |  |  | 32,556 |  |  | 34,060 |  |
| Net income and comprehensive income |  | 21,493 |  |  | 24,691 |  |  | 27,920 |  |  | 28,485 |  |
| Net income (loss) attributable to common stockholders—basic |  | (81,234 | ) |  | 14,428 |  |  | 27,920 |  |  | 28,485 |  |
| Net income (loss) attributable to common stockholders—diluted |  | (81,234 | ) |  | 14,443 |  |  | 27,920 |  |  | 28,485 |  |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.30 | ) |  | $ | 0.16 |  |  | $ | 0.30 |  |  | $ | 0.31 |  |
| Diluted |  | $ | (1.30 | ) |  | $ | 0.16 |  |  | $ | 0.30 |  |  | $ | 0.30 |  |


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-13-000013:notes:4]
BUSINESS AND BASIS OF PRESENTATION

[0001511737-13-000013:notes:5]
Business— Ubiquiti Networks, Inc. was incorporated in the State of California in 2003 as Pera Networks, Inc.  In 2005 the Company changed its name to Ubiquiti Networks, Inc. and commenced its current operations. In June 2010, the Company was re-incorporated in Delaware.

[0001511737-13-000013:notes:6]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) is a product driven company that leverages innovative proprietary technologies to deliver networking solutions to both startup and established network operators and service providers.

[0001511737-13-000013:notes:7]
On October 13, 2011, the Company entered into an underwriting agreement for its initial public offering of common stock at $15.00 per share.  The Company's initial public offering closed on October 19, 2011. Immediately prior to the closing of the initial public offering, all outstanding shares of the Company’s preferred stock converted to common stock on a one for one basis.

[0001511737-13-000013:notes:8]
On June 18, 2013, the Company completed a secondary offering of 7,031,464 shares of common stock at an offering price of $16.00 per share, which included 531,464 shares sold in connection with the partial exercise of the option to purchase additional shares granted to the underwriters.  All of the shares sold in the offering were sold by existing stockholders of the Company, including entities affiliated with Summit Partners, L.P., and the Company's chief executive officer, Robert J. Pera.  No shares were sold by the Company in the offering, and as such, the Company did not receive any proceeds from the offering.

[0001511737-13-000013:notes:9]
The Company operates on a fiscal year ending June 30. In these notes, Ubiquiti refers to the fiscal years ended June 30, 2013, 2012 and 2011 as fiscal 2013, fiscal 2012 and fiscal 2011, respectively.

[0001511737-13-000013:notes:10]
Basis of Presentation— The Company’s consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of Ubiquiti and its wholly owned subsidiaries. The Company has wholly owned subsidiaries in Lithuania and Hong Kong. The Company’s Hong Kong subsidiary also operates a branch office in Taiwan. All intercompany transactions and balances have been eliminated.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001511737-13-000013:notes:11]
Cash and Cash Equivalents

[0001511737-13-000013:notes:12]
The Company considers investments purchased with a maturity period of three months or less at the date of purchase to be cash equivalents. As of June 30, 2013 and 2012, the Company had cash and cash equivalents of $227.8 million and $122.1 million, respectively. Cash and cash equivalents are stated at cost which approximates fair value. The Company deposits cash and cash equivalents with financial institutions that management believes are of high credit quality. The Company’s cash and cash equivalents consist primarily of cash deposited in U.S. dollar denominated inter-bearing deposit accounts.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-13-000013:notes:13]
COMMITMENTS AND CONTINGENCIES

[0001511737-13-000013:notes:14]
Operating Leases

[0001511737-13-000013:notes:15]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2018.

[0001511737-13-000013:notes:16]
In July 2011, the Company entered into an agreement to lease additional office space for its research and development offices in Taiwan. The lease term is from July 14, 2011 through July 15, 2016. The premises consist of approximately 10,000 rentable square feet of space. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $1.6 million.

[0001511737-13-000013:notes:17]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which the Company uses as its corporate headquarters. The lease term is from April 1, 2012, through  July 31, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.

[0001511737-13-000013:notes:18]
At June 30, 2013, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-13-000013:notes:19]
|  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Operating leases | $ | 1,743 |  |  | $ | 1,679 |  |  | $ | 1,638 |  |  | $ | 1,128 |  |  | $ | 94 |  |  | $ | — |  |  | $ | 6,282 |  |

[0001511737-13-000013:notes:20]
Rent expense under operating leases was $1.7 million, $1.6 million and $751,000 for fiscal 2013, fiscal 2012 and fiscal 2011, respectively.

[0001511737-13-000013:notes:21]
Purchase Commitments

[0001511737-13-000013:notes:22]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded. The Company’s consolidated financial position and results of operations could be negatively impacted if it were required to compensate the contract manufacturers for any liabilities incurred.

[0001511737-13-000013:notes:23]
Indemnification Obligations

[0001511737-13-000013:notes:24]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-13-000013:notes:25]
Legal Matters

[0001511737-13-000013:notes:26]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded. Litigation can be costly, diverting management’s attention and could, upon resolution, have a material adverse effect on the Company’s business, results of operations, financial condition, and cash flows.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-13-000013:notes:27]
Export Compliance Matters

[0001511737-13-000013:notes:28]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.

[0001511737-13-000013:notes:29]
In May 2011, the Company filed a self-disclosure statement with the BIS and OEE.  In June 2011, the Company filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company’s products into Iran during the period from February 2010 through March 2011 and that the Company received various communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty.

[0001511737-13-000013:notes:30]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the “EAR”) and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001511737-13-000013:notes:31]
While the Company has taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner and has adopted policies and procedures to promote its compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its distributor revenue in fiscal 2013.  However the Company cannot be sure such actions will be effective.  Additionally, the Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.

[0001511737-13-000013:notes:32]
Shareholder Class Action Lawsuits

[0001511737-13-000013:notes:33]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs. On March 26, 2013, the Company filed a motion to dismiss the complaint.  On April 30, 2013, the plaintiffs filed an opposition to the Company's motion to dismiss. On August 27, 2013, the court held a hearing on the motion to dismiss.

[0001511737-13-000013:notes:34]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot say that a loss is probable and cannot currently reasonably estimate the loss or the range of possible losses that may be experienced in connection with this litigation.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001511737-13-000013:notes:35]
Commitments and Contingencies

[0001511737-13-000013:notes:36]
The Company periodically evaluates all pending or threatened contingencies and any commitments, if any, that are reasonably likely to have a material adverse effect on its results of operations, financial position or cash flows. The Company assesses the probability of an adverse outcome and determines if it is remote, reasonably possible or probable. If information available prior to the issuance of the Company’s financial statements indicates that it is probable that an asset had been impaired or a liability had been incurred at the date of the Company’s financial statements, and the amount of the loss, or the range of probable loss can be reasonably estimated, then such loss is accrued and charged to operating expenses. If no accrual is made for a loss contingency because one or both of the conditions pursuant to the accounting guidance are not met, but the probability of an adverse outcome is at least reasonably possible, the Company discloses the nature of the contingency and provides an estimate of the possible loss or range of loss, or states that such an estimate cannot be made.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001511737-13-000013:notes:37]
401(k) BENEFIT PLAN

[0001511737-13-000013:notes:38]
The Company sponsors a 401(k) defined contribution plan. It matches 1% of the first 4% of an employee’s compensation contributed to the plan. The Company’s contributions to the plan were $58,000, $47,000 and $28,000 for fiscal 2013, 2012 and 2011, respectively.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001511737-13-000013:notes:39]
Stock-based Compensation

[0001511737-13-000013:notes:40]
The Company records stock-based awards at fair value as of the grant date and recognizes expense ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. The Company estimates the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. Restricted stock units (“RSUs”) are valued based on the fair value of the Company’s common stock on the date of grant.

[0001511737-13-000013:notes:41]
The Black-Scholes option pricing model used to determine the fair value of the Company’s stock option awards requires a number of estimates and assumptions. In valuing share-based awards under the fair value accounting method, significant judgment is required in determining the expected volatility of the Company’s common stock and the expected term individuals will hold their share-based awards prior to exercising. The expected volatility of the Company’s common stock is based on the volatility of a group of comparable companies, as the Company does not have sufficient historical data with regards to the volatility of its stock. The expected term of options granted represents the period of time that the Company expects the options granted to be outstanding. The Company calculates the expected term as the average of the option vesting and contractual terms. In the future, as the Company gains sufficient historical data for volatility in its common stock and the actual term for which its options are held, the expected volatility and expected term may change, which could substantially change the grant date fair value of future awards of stock options and ultimately the expense it records. In addition, the estimation of stock awards that will ultimately vest requires judgment and to the extent actual results differ from the Company’s estimates, these amounts will be recorded as an adjustment in the period estimates are revised.

[0001511737-13-000013:notes:42]
For stock option awards granted to nonemployees and nonemployee directors, the fair value of the stock option awards is estimated using the Black-Scholes option pricing model. This model utilizes the estimated fair value of the Company’s underlying common stock at each measurement date, the contractual term of the option, the expected volatility of the price of the Company’s common stock, risk free interest rates and expected dividend yields of the Company’s common stock.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001511737-13-000013:notes:43]
Other Comprehensive Income

[0001511737-13-000013:notes:44]
In accordance with the guidance in the Financial Accounting Standards Board ("FASB") Accounting Standard Codification ("ASC") 220-10, an entity has the option to present the total of comprehensive income, the components of net income, and the components of other comprehensive income either in a single continuous statement of comprehensive income or in two separate but consecutive statements. In both choices, an entity is required to present each component of net income along with total net income, each component of other comprehensive income along with a total for other comprehensive income, and a total amount for comprehensive income. Given that the Company has no items of other comprehensive income in any period presented, comprehensive income is the same as net income and hence the Company is exempt from the requirement to separately report other comprehensive income or comprehensive income.


## us-gaap:DebtDisclosureTextBlock

[0001511737-13-000013:notes:45]
DEBT

[0001511737-13-000013:notes:46]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes and was financed through the Company's EWB Loan Agreement (as further described below) reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company’s initial public offering and existing cash balances. The interest rate on the notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the event of the Company’s initial public offering or third party financing prior to April 21, 2012. The notes mature on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97 per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.

[0001511737-13-000013:notes:47]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”), which was replaced by the Loan Agreement as discussed below. The credit facilities available under the EWB Loan Agreement consist of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P leaving $1.0 million available for borrowing under the term loan facility.

[0001511737-13-000013:notes:48]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed above. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-13-000013:notes:49]
The loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (at the Company’s election, for a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case with such spread being determined based on the debt service coverage ratio for its most recently ended fiscal quarter. The base rate is the highest of (i) East West Bank’s prime rate, (ii) the federal funds rate plus a margin equal to 0.50%, or (iii) the LIBOR rate plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this size and type.

[0001511737-13-000013:notes:50]
Interest is due and payable monthly in arrears in the case of loans bearing interest at the base rate and at the end of an interest period in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly installments on the first day of each calendar quarter, and each such quarterly installment shall be equal to $1.25 million through July 1, 2014, then equal to $1.875 million from October 1, 2014 through July 1 2015, and then equal to $2.5 million from October 1, 2015 through July 1, 2017, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are due on August 7, 2015.

[0001511737-13-000013:notes:51]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with (i) the proceeds from certain financing transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and (ii) 25.0% of the Company’s excess cash flow in the U.S., as determined after each fiscal year and in accordance with the Loan Agreement, provided that the Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.

[0001511737-13-000013:notes:52]
All of the obligations of the Company under the Loan Agreement are collateralized by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign subsidiaries, but excluding the Company’s intellectual property, which is subject to a negative pledge agreement. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be collateralized by substantially all of the property of such subsidiaries, excluding intellectual property.

[0001511737-13-000013:notes:53]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of June 30, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

[0001511737-13-000013:notes:54]
The Loan Agreement includes customary events of default that, include among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

[0001511737-13-000013:notes:55]
During the fiscal years 2013 and 2012, the Company made aggregate payments of $4.3 million and $5.2 million, respectively, against the loan balance.  As of June 30, 2013, the Company has classified $5.0 million and $71.1 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.

[0001511737-13-000013:notes:56]
The following table summarizes our estimated debt and interest payment obligations as of June 30, 2013 (in thousands):

[0001511737-13-000013:notes:57]
|  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | — |  |  | $ | 76,250 |  |
| Interest payments on debt payment obligations | 1,859 |  |  | 1,723 |  |  | 1,042 |  |  | 532 |  |  | 125 |  |  | — |  |  | 5,281 |  |
| Total | $ | 6,859 |  |  | $ | 8,598 |  |  | $ | 40,417 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | — |  |  | $ | 81,531 |  |


## us-gaap:DeferredChargesPolicyTextBlock

[0001511737-13-000013:notes:58]
Deferred Cost of Revenues

[0001511737-13-000013:notes:59]
Deferred cost of revenues consist of the cost of product shipped to distributors for which the rights and obligations of ownership have passed to the distributor but revenues have not yet been recognized primarily because the collectability criterion for revenue recognition has not been fulfilled.  The Company classifies these amounts as deferred cost of revenues. All deferred costs of revenues are stated at cost. The Company periodically assesses the recoverability of deferred cost of revenues and writes down the deferred cost of revenues balances to establish a new cost basis when recovery of deferred cost of revenues is not reasonably assured. The Company evaluates recoverability based on various factors including the length of time the product has been held at the distributor’s site and the financial viability of the distributor.


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-13-000013:notes:60]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001511737-13-000013:notes:61]
|  | June 30, |
|  | 2013 |  | 2012 |
| Non-trade receivables | $ | 2,203 |  |  | $ | 1,019 |  |
| Other current assets | 948 |  |  | 558 |  |
|  | $ | 3,151 |  |  | $ | 1,577 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-13-000013:notes:62]
STOCK BASED COMPENSATION

[0001511737-13-000013:notes:63]
Stock-Based Compensation Plans

[0001511737-13-000013:notes:64]
2010 Equity Incentive Plan

[0001511737-13-000013:notes:65]
In March 2010, the Company’s board of directors and stockholders approved the 2010 Equity Incentive Plan (the “2010 Plan”). The 2010 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”), and no further awards will be granted pursuant to the 2005 Plan. Under the terms of the 2010 Plan, nonstatutory stock options, stock appreciation rights, restricted stock, and restricted stock units (“RSUs”) may be granted to employees or non-employee service providers. Incentive stock options may be granted only to employees.

[0001511737-13-000013:notes:66]
The maximum aggregate number of shares that may be awarded under the 2010 Plan as of June 30, 2013 was 8,000,000 shares, plus any shares subject to stock options or similar awards granted under the 2005 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2005 Plan that are forfeited to (but not repurchased by) the Company.

[0001511737-13-000013:notes:67]
The 2010 Plan is administered by the board of directors or a committee of the Company’s board of directors. Subject to the terms and conditions of the 2010 Plan, the administrator has the authority to select the persons to whom awards are to be made, to determine the number of shares to be subject to awards and the terms and conditions of awards, and to make all other determinations and to take all other actions necessary or advisable for the administration of the 2010 Plan. The administrator is also authorized to adopt, amend or rescind rules relating to administration of the 2010 Plan. Options and RSUs generally vest over a four year period from the date of grant and generally expire five to ten years from the date of grant. The terms of the 2010 Plan provide that an option price shall not be less than 100% of fair market value on the date of grant.

[0001511737-13-000013:notes:68]
2005 Equity Incentive Plan

[0001511737-13-000013:notes:69]
With the adoption of the 2010 Plan, no additional awards may be granted under the 2005 Plan. In February 2005, the Company’s board of directors and the stockholders approved the 2005 Plan, which was amended and restated in March 2006. The 2005 Plan provided for the issuance of stock options, restricted stock and stock bonuses to employees, consultants, advisors, directors and officers of the Company. The 2005 Plan was administered by the Company’s board of directors, who determined the terms and conditions for each grant. The terms of the options granted under the 2005 Plan were determined at the time of grant. The Company made use of different vesting schedules through fiscal 2009, but subsequent new grants generally vested as to 25% on the first anniversary of the date of grant and monthly thereafter over the next three years and generally have a term of 10 years from the date of grant. The option prices were determined by the Company’s board of directors.

[0001511737-13-000013:notes:70]
As of June 30, 2013, the Company had 5,370,815 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-13-000013:notes:71]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations and Comprehensive Income for fiscal 2013, 2012 and 2011 (in thousands):

[0001511737-13-000013:notes:72]
|  | Years Ended Years Ended June 30, |
|  | 2013 |  | 2012 |  | 2011 |
| Cost of sales | $ | 446 |  |  | $ | 117 |  |  | $ | 30 |  |
| Research and development | 1,433 |  |  | 542 |  |  | 285 |  |
| Sales, general and administrative | 1,497 |  |  | 834 |  |  | 637 |  |
|  | $ | 3,376 |  |  | $ | 1,493 |  |  | $ | 952 |  |

[0001511737-13-000013:notes:73]
Stock Options

[0001511737-13-000013:notes:74]
The following is a summary of option activity for the Company’s stock incentive plans for fiscal 2013, 2012 and 2011:

[0001511737-13-000013:notes:75]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2010 | 5,796,170 |  |  | $ | 0.23 |  |  | 6.92 |  | $ | 12,642 |  |
| Granted | 1,149,062 |  |  | 3.42 |  |  |  |  |  |
| Forfeitures and cancellations | (773,525 | ) |  | 1.03 |  |  |  |  |  |
| Balance, June 30, 2011 | 6,171,707 |  |  | $ | 0.72 |  |  | 6.44 |  | $ | 43,135 |  |
| Granted | 161,000 |  |  | 10.44 |  |  |  |  |  |
| Exercised | (2,885,470 | ) |  | 0.28 |  |  |  |  |  |
| Forfeitures and cancellations | (99,792 | ) |  | 4.71 |  |  |  |  |  |
| Balance, June 30, 2012 | 3,347,445 |  |  | $ | 1.45 |  |  | 6.62 |  | $ | 42,920 |  |
| Granted | 683,500 |  |  | 11.29 |  |  |  |  |  |
| Exercised | (266,558 | ) |  | 2.39 |  |  |  |  |  |
| Forfeitures and cancellations | (150,125 | ) |  | 5.68 |  |  |  |  |  |
| Balance, June 30, 2013 | 3,614,262 |  |  | $ | 3.07 |  |  | 6.17 |  | $ | 52,330 |  |
| Vested and expected to vest as of June 30, 2013 | 3,550,722 |  |  | $ | 2.94 |  |  | 6.12 |  | $ | 51,854 |  |
| Vested and exercisable as of June 30, 2013 | 2,618,311 |  |  | $ | 0.85 |  |  | 5.20 |  | $ | 43,709 |  |

[0001511737-13-000013:notes:76]
Additional information regarding options outstanding as of June 30, 2013 is as follows (in thousands, except weighted average exercise price amounts and contractual life):

[0001511737-13-000013:notes:77]
|  |  | Options Outstanding |  |  |  | Options Exercisable |
| Range of Exercise Prices |  | Number ofOptions |  | WeightedAverageRemainingContractualLife (Years) |  | WeightedAverageExercisePrice |  | Number ofOptions |  | WeightedAverageExercisePrice |
| $0.01 – $0.04 |  | 253,680 |  |  | 3.41 |  | $ | 0.01 |  |  | 253,680 |  |  | $ | 0.01 |  |
| $0.05 – $0.39 |  | 1,764,890 |  |  | 4.78 |  | 0.05 |  |  | 1,764,890 |  |  | 0.05 |  |
| $0.40 – $2.89 |  | 206,375 |  |  | 6.52 |  | 1.41 |  |  | 150,123 |  |  | 1.22 |  |
| $2.90 – $4.07 |  | 383,268 |  |  | 7.25 |  | 2.90 |  |  | 264,711 |  |  | 2.90 |  |
| $4.08 – $10.76 |  | 348,393 |  |  | 7.82 |  | 5.67 |  |  | 171,996 |  |  | 5.65 |  |
| $10.77 – $11.74 |  | 472,500 |  |  | 9.37 |  | 10.77 |  |  | — |  |  | — |  |
| $11.75 – $26.28 |  | 185,156 |  |  | 9.32 |  | 13.65 |  |  | 12,911 |  |  | 16.40 |  |
| $0.01 – $26.28 |  | 3,614,262 |  |  | 6.17 |  | $ | 3.07 |  |  | 2,618,311 |  |  | $ | 0.85 |  |

[0001511737-13-000013:notes:78]
During fiscal 2013 and 2012, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $3.4 million and $48.6 million, respectively, as determined as of the date of option exercise.  The Company had no option exercises during fiscal 2011.

[0001511737-13-000013:notes:79]
As of June 30, 2013, the Company had unrecognized compensation cost of $3.7 million related to stock options which the Company expects to recognize over a weighted-average period of 3.2 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-13-000013:notes:80]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. For fiscal 2013, 2012 and 2011 the fair value of employee stock options was estimated using the following weighted average assumptions:

[0001511737-13-000013:notes:81]
|  | Years Ended Years Ended June 30, |
|  | 2013 |  | 2012 |  | 2011 |
| Expected term | 6.1 years |  |  | 6.1 years |  |  | 6.1 years |  |
| Expected volatility | 52 | % |  | 49 | % |  | 65 | % |
| Risk-free interest rate | 0.9 | % |  | 1.6 | % |  | 4.2 | % |
| Expected dividend yield | — |  |  | — |  |  | — |  |
| Weighted average grant date fair value | $ | 5.57 |  |  | $ | 5.05 |  |  | $ | 2.10 |  |

[0001511737-13-000013:notes:82]
Expected term. Expected term represents the period that the Company’s stock-based awards are expected to be outstanding. As the Company has limited historical option exercise data, the expected term of the stock options granted to employees was calculated based on the simplified method. Under the simplified method, the expected term is equal to the average of an option’s weighted-average vesting period and its contractual term. The Company is permitted to continue using the simplified method until sufficient information regarding exercise behavior, such as historical exercise data or exercise information from external sources, becomes available.

[0001511737-13-000013:notes:83]
Expected volatility. The expected volatility was based on the historical stock volatilities of a group of publicly listed comparable companies over a period equal to the expected terms of the options, as the Company does not have any trading history to use the volatility of its common stock.

[0001511737-13-000013:notes:84]
Expected dividend yield. The Company has never paid dividends on the Company’s common stock and does not expect to pay dividends on its common stock.

[0001511737-13-000013:notes:85]
Risk-free interest rate. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant for zero coupon U.S. Treasury notes with maturities approximately equal to the option’s expected term.

[0001511737-13-000013:notes:86]
Fair value of common stock. The Company’s common stock began trading on the NASDAQ Global Select Market on October 14, 2011, upon its initial public offering. The fair value of the Company’s common stock is determined using the market price of the Company’s common stock as of the date of grant. Prior to October 14, 2011, the fair value of the shares of common stock underlying the stock options has historically been the responsibility of and determined by the Company’s board of directors. Because there had been no public market for the Company’s common stock, its board of directors has determined fair value of the common stock at the time of grant of the option by considering a number of objective and subjective factors including independent third-party valuations of its common stock, operating and financial performance, the lack of liquidity of capital stock and general and industry specific economic outlook, amongst other factors.

[0001511737-13-000013:notes:87]
Forfeiture rate. The Company estimates its forfeiture rate based on an analysis of its actual forfeitures and will continue to evaluate the adequacy of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover behavior and other factors. The impact from a forfeiture rate adjustment will be recognized in full in the period of adjustment, and if the actual number of future forfeitures differs from that estimated, the Company may be required to record adjustments to stock-based compensation expense in future periods.

[0001511737-13-000013:notes:88]
Cash received from stock option exercises during the fiscal 2013, 2012 and 2011 was $635,000, $811,000 and zero, respectively.

[0001511737-13-000013:notes:89]
Restricted Stock Units (“RSUs”)

[0001511737-13-000013:notes:90]
The following table summarizes the activity of the RSUs made by the Company:

[0001511737-13-000013:notes:91]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2010 | 501,180 |  |  | $ | 1.92 |  |
| RSUs granted | 112,500 |  |  | 5.14 |  |
| RSUs vested | (125,295 | ) |  | 1.92 |  |
| Non-vested RSUs, June 30, 2011 | 488,385 |  |  | $ | 2.66 |  |
| RSUs granted | 169,710 |  |  | 22.33 |  |
| RSUs vested | (146,475 | ) |  | 2.37 |  |
| RSUs cancelled | (58,000 | ) |  | 8.04 |  |
| Non-vested RSUs, June 30, 2012 | 453,620 |  |  | $ | 9.42 |  |
| RSUs granted | 656,500 |  |  | 14.11 |  |
| RSUs vested | (70,512 | ) |  | 14.14 |  |
| RSUs cancelled | (294,702 | ) |  | 5.29 |  |
| Non-vested RSUs, June 30, 2013 | 744,906 |  |  | $ | 14.74 |  |

[0001511737-13-000013:notes:92]
The intrinsic value of RSUs vested in fiscal 2013, 2012 and 2011 was $1.0 million, $3.5 million and $640,000, respectively.  The total intrinsic value of all outstanding RSUs was $13.1 million as of June 30, 2013.

[0001511737-13-000013:notes:93]
As of June 30, 2013, there was unrecognized compensation costs related to RSUs of $8.7 million which the Company expects to recognize over a weighted average period of 3.6 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001511737-13-000013:notes:94]
Earnings Per Share

[0001511737-13-000013:notes:95]
The Company applies the two-class method for calculating and presenting earnings per share (“EPS”). Under the two-class method, net income is allocated between shares of common stock and other participating securities based on their participating rights. Participating securities are defined as securities that participate in dividends with common stock according to a pre-determined formula or a contractual obligation to share in the income of the entity. Basic EPS is computed by dividing net income available to common stockholders by the weighted average number of shares of common stock outstanding during the period. Diluted EPS is computed by dividing the amount of net income available to common stockholders outstanding plus income allocable to participating securities, to the extent they are dilutive, by the weighted average number of shares of common stock and potential dilutive shares outstanding during the period if the effect is dilutive. The Company’s potentially dilutive common securities include outstanding stock options, restricted stock units and preferred stock.


## us-gaap:EarningsPerShareTextBlock

[0001511737-13-000013:notes:96]
EARNINGS PER SHARE

[0001511737-13-000013:notes:97]
The following table sets forth the computation of basic and diluted earnings per share for the periods indicated (in thousands, except per share data):

[0001511737-13-000013:notes:98]
|  | Years Ended June 30, |  |
|  | 2013 |  | 2012 |  | 2011 |  |
| Numerator: |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders-basic | $ | 80,490 |  |  | $ | (9,842 | ) |  | $ | 4,875 |  |  |
| Net income (loss) attributable to common stockholders-diluted | $ | 80,490 |  |  | $ | (9,842 | ) |  | $ | 4,978 |  |  |
| Denominator: |  |  |  |  |
| Weighted-average shares used in computing basic net income (loss) per share | 88,314 |  |  | 83,460 |  |  | 63,092 |  |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |
| Stock options | 1,803 |  |  | — |  |  | 3,680 |  |  |
| Restricted stock units | 142 |  |  | — |  |  | 135 |  |  |
| Weighted-average shares used in computing diluted net income (loss) per share | 90,259 |  |  | 83,460 |  |  | 66,907 |  |  |
| Net income (loss) per share of common stock: |  |  |  |  |
| Basic | $ | 0.91 |  |  | $ | (0.12 | ) |  | $ | 0.08 |  |  |
| Diluted | $ | 0.89 |  |  | $ | (0.12 | ) |  | $ | 0.07 |  |  |

[0001511737-13-000013:notes:99]
The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001511737-13-000013:notes:100]
|  | Years Ended June 30, |
|  | 2013 |  | 2012 |  | 2011 |
| Stock options | 658 |  |  | 3,348 |  |  | 360 |  |
| Restricted stock units | 364 |  |  | 454 |  |  | 100 |  |
| Convertible preferred stock | — |  |  | — |  |  | 36,035 |  |
|  | 1,022 |  |  | 3,802 |  |  | 36,495 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-13-000013:notes:101]
As of June 30, 2013 and 2012, the fair value hierarchy for the Company’s financial liabilities was as follows (in thousands):

[0001511737-13-000013:notes:102]
|  | June 30, 2013 |  | June 30, 2012 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt(1) | $ | 76,129 |  |  | $ | — |  |  | $ | 76,129 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |

[0001511737-13-000013:notes:103]
(1) Debt is carried at historical cost on the Company's consolidated balance sheet.


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-13-000013:notes:104]
FAIR VALUE OF FINANCIAL INSTRUMENTS

[0001511737-13-000013:notes:105]
Pursuant to the accounting guidance for fair value measurements and its subsequent updates, fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. The accounting guidance establishes a three-tier fair value hierarchy that requires the Company to use observable market data, when available, and to minimize the use of unobservable inputs when determining fair value. The fair value hierarchy prioritizes the inputs into three levels that may be used in measuring fair value as follows:

[0001511737-13-000013:notes:106]
Level 1—observable inputs which include quoted prices in active markets for identical assets of liabilities.

[0001511737-13-000013:notes:107]
Level 2—inputs which include observable inputs other than Level 1, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability.

[0001511737-13-000013:notes:108]
Level 3—inputs which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001511737-13-000013:notes:109]
The Company did not have any financial assets recorded at fair value at June 30, 2013 or 2012.  At June 30, 2013 and 2012 the Company had debt associated with its Loan and Security Agreement with East West Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001511737-13-000013:notes:110]
Foreign Currency Translation

[0001511737-13-000013:notes:111]
The functional currency of the Company and its subsidiaries is the U.S. dollar. For foreign operations, local currency denominated assets and liabilities are remeasured at the period end exchange rates, and revenues, costs and expenses are remeasured at the average exchange rates during the fiscal year. Foreign exchange gains and losses have been immaterial to the Company’s results of operations to date.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001511737-13-000013:notes:112]
Long Lived Assets

[0001511737-13-000013:notes:113]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-13-000013:notes:114]
INCOME TAXES

[0001511737-13-000013:notes:115]
For financial reporting purposes, the components of income before provision for income taxes were as follows (in thousands):

[0001511737-13-000013:notes:116]
|  |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2011 |
| Domestic |  | $ | 17,860 |  |  | $ | 41,490 |  |  | $ | 24,484 |  |
| Foreign |  | 73,893 |  |  | 82,533 |  |  | 37,675 |  |
|  |  | $ | 91,753 |  |  | $ | 124,023 |  |  | $ | 62,159 |  |

[0001511737-13-000013:notes:117]
The components of the Company’s provision for income taxes consisted of the following (in thousands):

[0001511737-13-000013:notes:118]
|  |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2011 |
| Current |  |  |  |  |  |  |
| Foreign |  | $ | 1,790 |  |  | $ | 2,040 |  |  | $ | 978 |  |
| Federal |  | 8,515 |  |  | 17,437 |  |  | 11,005 |  |
| State |  | 581 |  |  | 2,854 |  |  | 1,612 |  |
| Current tax expense |  | 10,886 |  |  | 22,331 |  |  | 13,595 |  |
| Deferred |  |  |  |  |  |  |
| Foreign |  | — |  |  | — |  |  | — |  |
| Federal |  | (130 | ) |  | (217 | ) |  | (912 | ) |
| State |  | 507 |  |  | (680 | ) |  | (251 | ) |
| Deferred tax expense |  | 377 |  |  | (897 | ) |  | (1,163 | ) |
| Provision for income taxes |  | $ | 11,263 |  |  | $ | 21,434 |  |  | $ | 12,432 |  |

[0001511737-13-000013:notes:119]
Significant components of the Company’s deferred tax assets and liabilities consisted of the following (in thousands):

[0001511737-13-000013:notes:120]
|  |  | June 30, |
|  |  | 2013 |  | 2012 |
| Deferred tax assets |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 337 |  |  | $ | 238 |  |
| Stock-based compensation |  | 833 |  |  | 1,016 |  |
| Accrued expenses |  | 191 |  |  | 256 |  |
| Research and development credits |  | — |  |  | 468 |  |
| Other |  | 323 |  |  | 186 |  |
| Total deferred tax assets |  | 1,684 |  |  | 2,164 |  |
| Deferred tax liabilities |  |  |  |  |
| Basis difference for fixed assets |  | (829 | ) |  | (784 | ) |
| Other |  | (118 | ) |  | (266 | ) |
| Total deferred tax liabilities |  | (947 | ) |  | (1,050 | ) |
| Net deferred tax assets |  | $ | 737 |  |  | $ | 1,114 |  |

[0001511737-13-000013:notes:121]
The effective tax rate differs from the applicable U.S. statutory federal income tax rate as follows:

[0001511737-13-000013:notes:122]
|  |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2011 |
| Statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Stock-based compensation |  | 0.8 |  |  | — |  |  | — |  |
| State tax expense |  | 0.7 |  |  | 1.0 |  |  | 1.0 |  |
| Tax rate differential, foreign income |  | (24.2 | ) |  | (23.0 | ) |  | (20.0 | ) |
| Foreign credits |  | — |  |  | — |  |  | — |  |
| Federal research and development credits |  | (0.4 | ) |  | — |  |  | (1.0 | ) |
| Other permanent items |  | 0.4 |  |  | 4.3 |  |  | 5.0 |  |
| Non-deductible penalties |  | — |  |  | — |  |  | — |  |
| Effective tax rate |  | 12.3 | % |  | 17.3 | % |  | 20.0 | % |

[0001511737-13-000013:notes:123]
The Company had increased foreign operations in fiscal 2013 as compared to fiscal 2012 and in fiscal 2012 as compared to fiscal 2011, generating more income on a comparative year over year basis in foreign jurisdictions that have lower tax rates than the U.S.

[0001511737-13-000013:notes:124]
It is the practice and intention of the Company to reinvest the earnings of its non-U.S. subsidiaries in those operations. As of June 30, 2013, the Company has not made a provision for U.S. or additional foreign withholding taxes on approximately $210.6 million of the excess of the amount for financial reporting over the tax basis of investments in foreign subsidiaries that are essentially permanent in duration. Generally, such amounts become subject to U.S. taxation upon the remittance of dividends and under certain other circumstances. It is not practicable to estimate the amount of deferred tax liability related to investments in these foreign subsidiaries.

[0001511737-13-000013:notes:125]
While management believes that the Company has adequately provided for all tax positions, amounts asserted by tax authorities could be greater or less than the recorded position. Accordingly, the Company's provisions on federal, state and foreign tax-related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved.

[0001511737-13-000013:notes:126]
A reconciliation of the beginning and ending balances of the unrecognized tax benefits during the years ended June 30, 2013 2012 and 2011 consists of the following (in thousands):

[0001511737-13-000013:notes:127]
|  |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2011 |
|  |  | (In thousands) |
| Unrecognized benefit—beginning of period |  | $ | 7,825 |  |  | $ | 2,020 |  |  | $ | 762 |  |
| Gross increases—current year tax positions |  | 3,806 |  |  | 4,697 |  |  | 1,258 |  |
| Gross increases—prior year tax positions |  | (176 | ) |  | 1,108 |  |  | — |  |
| Unrecognized benefit—end of period |  | $ | 11,455 |  |  | $ | 7,825 |  |  | $ | 2,020 |  |

[0001511737-13-000013:notes:128]
Included in the gross unrecognized tax benefits balance as of June 30, 2013 are $11.5 million of tax positions which would affect income tax expense if recognized.  The Company recognizes interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying Consolidated Statement of Operations and Comprehensive Income.  Accrued interest and penalties are included within the related tax liability line in the Consolidated Balance Sheet.  As of June 30, 2013, the Company had $580,000 accrued interest related to uncertain tax matters. The Company does not expect its unrecognized tax benefits as of June 30, 2013 will materially change within the next 12 months.  The Company files income tax returns in the United States, various states and certain foreign jurisdictions.  Tax years 2010 through 2013 are subject to examination by the U.S. federal tax authorities. Tax years 2009 through 2013 are subject to examination by the state tax authorities. There are no income tax examinations currently in process.


## us-gaap:IncomeTaxPolicyTextBlock

[0001511737-13-000013:notes:129]
Income Taxes

[0001511737-13-000013:notes:130]
The Company accounts for income taxes in accordance with accounting guidance which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in its financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company establishes valuation allowances when necessary to reduce deferred tax assets to the amount it expects to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives. In addition, the Company’s calculation of its tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company may be subject to income tax audits in all of the jurisdictions in which it operates and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, the Company must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that the Company establishes a reserve, its provision for income taxes would be increased. If the Company ultimately determines that payment of these amounts is unnecessary, it reverses the liability and recognizes a tax benefit during the period in which it determines that the liability is no longer necessary. The Company records an additional charge in its provision for taxes in the period in which it determines that tax liability is greater than its original estimate.


## us-gaap:InventoryPolicyTextBlock

[0001511737-13-000013:notes:131]
Inventory

[0001511737-13-000013:notes:132]
Inventories consist primarily of finished goods, and, to a lesser extent, raw materials that the Company consigns to its contract manufactures. Inventories are stated at the lower of cost or market value on a first-in, first-out basis. The Company reduces the value of its inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value and establishes a new cost basis.


## us-gaap:LeasePolicyTextBlock

[0001511737-13-000013:notes:133]
Leases

[0001511737-13-000013:notes:134]
The Company leases its facilities under cancelable and noncancelable operating leases. For leases that contain rent escalation or rent concessions provisions, the Company records the total rent expense during the lease term on a straight line basis over the term of the lease. The Company records the difference between the rent paid and the straight line rent as a deferred rent liability in the accompanying consolidated balance sheets.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-13-000013:notes:135]
Recent Accounting Pronouncements

[0001511737-13-000013:notes:136]
In July 2013, the FASB issued a new accounting standard update on the financial statement presentation of unrecognized tax benefits.  The new guidance provides that a liability related to an unrecognized tax benefit would be presented as a reduction of a deferred tax asset for a new operating loss carryforward, a similar tax loss or a tax credit carryforward if such settlement is required or expected in the event the uncertain tax position is disallowed.  The new guidance will become effective for the Company on July 1, 2014 and it should be applied prospectively to unrecognized tax benefits that exist as of the effective date with retrospective application permitted.  The Company is currently assessing the impact of this new guidance.


## us-gaap:PreferredStockTextBlock

[0001511737-13-000013:notes:137]
PREFERRED STOCK

[0001511737-13-000013:notes:138]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. The $68.0 million was paid down primarily using proceeds from the EWB Loan Agreement and the remaining balance was subsequently paid down by funds raised upon the completion of the Company’s initial public offering on October 19, 2011 and the Company’s existing cash balances as discussed in Note 7.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-13-000013:notes:139]
ACCRUED WARRANTY

[0001511737-13-000013:notes:140]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations and comprehensive income within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-13-000013:notes:141]
Warranty obligations, included in other current liabilities, were as follows (in thousands):

[0001511737-13-000013:notes:142]
| Balance at June 30, 2011 | $ | 806 |  |
| Accruals for warranties issued during the period | 1,895 |  |
| Settlements made during the period | (1,320 | ) |
| Balance at June 30, 2012 | 1,381 |  |
| Accruals for warranties issued during the period | 4,079 |  |
| Settlements made during the period | (2,547 | ) |
| Balance at June 30, 2013 | $ | 2,913 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001511737-13-000013:notes:143]
Property and Equipment

[0001511737-13-000013:notes:144]
Furniture, fixtures and equipment are recorded at cost. The Company computes depreciation or amortization using the straight line method over estimated useful lives, as follows:

[0001511737-13-000013:notes:145]
|  |  | Estimated Useful Life |
| Testing equipment |  | 3 to 5 years |
| Computer and other equipment |  | 3 to 5 years |
| Furniture and fixtures |  | 3 years |
| Leasehold improvements |  | shorter of lease term or useful life |

[0001511737-13-000013:notes:146]
Upon retirement or disposition, the asset cost and related accumulated depreciation are removed with any gain or loss recognized in the statement of operations. Expenditures for maintenance and repairs are charged to operations as incurred.


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-13-000013:notes:147]
Property and equipment, net consisted of the following (in thousands):

[0001511737-13-000013:notes:148]
|  | June 30, |
|  | 2013 |  | 2012 |
| Testing equipment | $ | 3,309 |  |  | $ | 2,293 |  |
| Computer and other equipment | 841 |  |  | 578 |  |
| Tooling equipment | 1,737 |  |  | 532 |  |
| Furniture and fixtures | 652 |  |  | 595 |  |
| Leasehold improvements | 1,858 |  |  | 1,424 |  |
| Software | 245 |  |  | 77 |  |
|  | 8,642 |  |  | 5,499 |  |
| Less: Accumulated depreciation and amortization | (2,666 | ) |  | (1,028 | ) |
|  | $ | 5,976 |  |  | $ | 4,471 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001511737-13-000013:notes:149]
Allowance for Doubtful Accounts

[0001511737-13-000013:notes:150]
The Company records an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, (i) the aging of the accounts receivable, (ii) the Company’s historical write offs, (iii) the credit worthiness of each distributor based on payment history and (iv) general economic conditions. In cases where the Company is aware of circumstances that may impair a specific distributor’s ability to meet its obligations to the Company, the Company records a specific allowance against amounts due from the distributor, and thereby reduces the net recognized receivable to the amounts it reasonably believes will be collected.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0001511737-13-000013:notes:151]
Research and Development Costs and Capitalized Software Development Costs

[0001511737-13-000013:notes:152]
Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and contractors engaged in research, design and development activities, as well as costs for prototypes, facilities and travel costs.

[0001511737-13-000013:notes:153]
Software development costs, including costs incurred to purchase third party software, begin to be capitalized when the Company has determined that certain factors are present, including, among others, that technology exists to achieve the performance requirements. The accumulation of software costs to be capitalized ceases when the software is substantially developed and is ready for its intended use. Capitalized costs are amortized on a straight line basis over the estimated useful life of the software once it is available for use.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001511737-13-000013:notes:154]
Recognition of Revenues

[0001511737-13-000013:notes:155]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied post contract customer support (“PCS”). The Company recognizes revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where the Company lacks evidence that collectability of the resulting receivable is reasonably assured, it defers recognition of revenue until the receipt of cash. At June 30, 2013 and 2012, $3.2 million and $805,000, respectively, of revenues were deferred.  The related deferred cost of revenues balance was $1.2 million as of June 30, 2013.

[0001511737-13-000013:notes:156]
For the Company’s sales, evidence of the arrangement consists of an order from a customer. The Company considers delivery to have occurred once its products have been shipped and title and risk of loss have been transferred. For the Company’s sales, these criteria are met at the time the products are transferred to the customer. The Company’s arrangements with customers do not include provisions for cancellation, returns, inventory swaps or refunds that would significantly impact recognized revenues.

[0001511737-13-000013:notes:157]
The Company records amounts billed to distributors for shipping and handling costs as revenues. The Company classifies shipping and handling costs incurred by it as cost of revenues.

[0001511737-13-000013:notes:158]
Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on the Company’s balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001511737-13-000013:notes:159]
The Company’s multi-element arrangements generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is this right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001511737-13-000013:notes:160]
The Company uses a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001511737-13-000013:notes:161]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally the Company does not sell the deliverables separately and, as such, does not have VSOE. |

[0001511737-13-000013:notes:162]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. The Company does not believe that there is accessible TPE evidence for similar deliverables. |

[0001511737-13-000013:notes:163]
| (iii) | BESP reflects the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. The Company believes that BESP is the most appropriate methodology for determining the allocation of revenue among the multiple elements. |

[0001511737-13-000013:notes:164]
The Company has allocated revenues between these two deliverables using the relative selling price method which is based on the estimated selling price for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated life of each of these devices, which currently is two years. At June 30, 2013, $1.0 million of revenue was deferred in this way, of which $691,000 was classified as a current liability on the Company's balance sheet with the remainder classified as a long-term liability. At June 30, 2012, $805,000 of revenue was deferred in this way as a current liability. All cost of revenues, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.

[0001511737-13-000013:notes:165]
The Company’s process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, the Company believes its network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate the Company to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. The Company believes that the relatively low prices of its products and its network operators’ and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, the Company has concluded that if it were to sell PCS on a standalone basis, the selling price would be relatively low.

[0001511737-13-000013:notes:166]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-13-000013:notes:167]
Accrued liabilities consisted of the following (in thousands):

[0001511737-13-000013:notes:168]
|  | June 30, |
|  | 2013 |  | 2012 |
| Accrued compensation and benefits | $ | 2,712 |  |  | $ | 2,657 |  |
| Accrued accounts payable | 323 |  |  | 6,636 |  |
| Accrual for an export compliance matter | 1,625 |  |  | 1,625 |  |
| Warranty accrual | 2,913 |  |  | 1,381 |  |
| Other accruals | 3,577 |  |  | 4,732 |  |
|  | $ | 11,150 |  |  | $ | 17,031 |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001511737-13-000013:notes:169]
The allowance for doubtful accounts activity was as follows (in thousands):

[0001511737-13-000013:notes:170]
|  |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2011 |
| Beginning balance |  | $ | 1,266 |  |  | $ | 596 |  |  | $ | 800 |  |
| Charged to or released from expenses |  | 1,096 |  |  | 815 |  |  | (200 | ) |
| Bad debt write-offs |  | (162 | ) |  | (145 | ) |  | (4 | ) |
| Ending Balance |  | $ | 2,200 |  |  | $ | 1,266 |  |  | $ | 596 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-13-000013:notes:171]
Inventories consisted of the following (in thousands):

[0001511737-13-000013:notes:172]
|  | June 30, |
|  | 2013 |  | 2012 |
| Finished goods | $ | 15,618 |  |  | $ | 3,066 |  |
| Raw materials | 262 |  |  | 4,668 |  |
|  | $ | 15,880 |  |  | $ | 7,734 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-13-000013:notes:173]
Other long-term assets consisted of the following (in thousands):

[0001511737-13-000013:notes:174]
|  | June 30, |
|  | 2013 |  | 2012 |
| Intangible assets, net | $ | 1,029 |  |  | $ | 748 |  |
| Long-term deferred cost of revenues | 1,185 |  |  | — |  |
| Other long-term assets | 672 |  |  | 388 |  |
|  | $ | 2,886 |  |  | $ | 1,136 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-13-000013:notes:175]
SEGMENT INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT CUSTOMERS

[0001511737-13-000013:notes:176]
Revenues by product type were as follows (in thousands, except percentages):

[0001511737-13-000013:notes:177]
|  | Years Ended June 30, |
|  | 2013 |  | 2012 |  | 2011 |
| airMAX | $ | 202,599 |  |  | 63 | % |  | $ | 223,743 |  |  | 63 | % |  | $ | 113,001 |  |  | 57 | % |
| New platforms | 53,868 |  |  | 17 | % |  | 29,465 |  |  | 8 | % |  | 2,513 |  |  | 1 | % |
| Other systems | 18,190 |  |  | 6 | % |  | 52,086 |  |  | 15 | % |  | 44,884 |  |  | 23 | % |
| Systems | 274,657 |  |  | 86 | % |  | 305,294 |  |  | 86 | % |  | 160,398 |  |  | 81 | % |
| Embedded radio | 6,889 |  |  | 2 | % |  | 10,056 |  |  | 3 | % |  | 14,762 |  |  | 7 | % |
| Antennas/other | 39,277 |  |  | 12 | % |  | 38,167 |  |  | 11 | % |  | 22,714 |  |  | 12 | % |
| Total revenues | $ | 320,823 |  |  | 100 | % |  | $ | 353,517 |  |  | 100 | % |  | $ | 197,874 |  |  | 100 | % |

[0001511737-13-000013:notes:178]
The Company generally forwards products directly from its manufacturers to its customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, the Company's products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, the Company's products were predominantly delivered to our customers through distribution hubs in Hong Kong.  The Company's logistics provider, in turn, ships to other locations throughout the world. The Company has determined the geographical distribution of product revenues based upon the customer's ship-to destinations.

[0001511737-13-000013:notes:179]
Revenues by geography were as follows (in thousands, except percentages):

[0001511737-13-000013:notes:180]
|  | Years Ended June 30, |
|  | 2013 |  | 2012 |  | 2011 |
| North America(1) | $ | 84,820 |  |  | 26 | % |  | $ | 88,309 |  |  | 25 | % |  | $ | 61,920 |  |  | 31 | % |
| South America | 65,764 |  |  | 21 | % |  | 88,325 |  |  | 25 | % |  | 50,824 |  |  | 26 | % |
| Europe, the Middle East and Africa | 127,860 |  |  | 40 | % |  | 130,494 |  |  | 37 | % |  | 68,297 |  |  | 35 | % |
| Asia Pacific | 42,379 |  |  | 13 | % |  | 46,389 |  |  | 13 | % |  | 16,833 |  |  | 8 | % |
| Total revenues | $ | 320,823 |  |  | 100 | % |  | $ | 353,517 |  |  | 100 | % |  | $ | 197,874 |  |  | 100 | % |

[0001511737-13-000013:notes:181]
| (1) | Revenue for the United States was $80.6 million, $84.3 million and $60.0 million for fiscal 2013, 2012 and 2011, respectively. |

[0001511737-13-000013:notes:182]
Customers with an accounts receivable balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001511737-13-000013:notes:183]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Years Ended June 30, |  | June 30, |
|  | 2013 |  | 2012 |  | 2011 |  | 2013 |  | 2012 |
| Flytec Computers, Inc. | 13 | % |  | 16 | % |  | 20 | % |  | 12 | % |  | 19 | % |
| P.W. Batna Magdalena Mucha | * |  |  | * |  |  | * |  |  | 11 | % |  | * |  |
| Streakwave Wireless, Inc. | * |  |  | 10 | % |  | 15 | % |  | 15 | % |  | 11 | % |
| Discomp | * |  |  | * |  |  | * |  |  | * |  |  | 12 | % |

[0001511737-13-000013:notes:184]
*  denotes less than 10%


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001511737-13-000013:notes:185]
Segments

[0001511737-13-000013:notes:186]
Management has determined that it operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company’s chief operating decision maker.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-13-000013:notes:187]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001511737-13-000013:notes:188]
Use of Accounting Estimates

[0001511737-13-000013:notes:189]
The preparation of financial statements in conformity with GAAP requires management to make estimates and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. On an ongoing basis, the Company evaluates these estimates, including those related to allowance for doubtful accounts, inventory valuation, warranty costs, stock-based compensation, income taxes, and commitments and contingencies, among others. The Company bases estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates.

[0001511737-13-000013:notes:190]
Management has determined that it operates as one reportable and operating segment as it only reports financial information on an aggregate and consolidated basis to its chief executive officer, who is the Company’s chief operating decision maker. See Note 13.

[0001511737-13-000013:notes:191]
Concentration of Risk

[0001511737-13-000013:notes:192]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents and accounts receivable. The Company primarily places its temporary cash investments in interest-bearing deposit accounts with high credit quality financial institutions. Deposits of cash outside the United States totaled $210.4 million and $102.8 million at June 30, 2013 and 2012, respectively.

[0001511737-13-000013:notes:193]
The Company derives its accounts receivable from revenues earned from customers located worldwide. The Company bases credit decisions primarily upon a customer’s past credit history. The Company’s standard credit terms are net 30 to 60 days.

[0001511737-13-000013:notes:194]
The Company subcontracts with other companies to manufacture most of its products. The Company relies on the ability of these contract manufacturers to produce the products sold to its distributors and original equipment manufacturers (“OEMs”). A significant portion of the Company’s products are manufactured by a few contract manufacturers. If the Company’s contract manufacturers were to lose production capabilities, the Company would experience delays in delivering products to its distributors and OEMs. The Company does not maintain long-term agreements with its contract manufacturers, which could lead to an inability of the Company to obtain its products in a timely fashion at prices consistent with those previously charged.

[0001511737-13-000013:notes:195]
Product Warranties

[0001511737-13-000013:notes:196]
Redeemable Convertible Preferred Stock

[0001511737-13-000013:notes:197]
On October 19, 2011, the Company’s outstanding Series A preferred stock converted to common stock immediately prior to the closing of the Company’s initial public offering and no additional accretion was recorded. Prior to the conversion, upon the sixth anniversary of the issuance of Series A preferred stock, the holders of Series A preferred stock could require the Company to redeem such preferred stock out of legally available funds at the greater of (i) the Liquidation Value of $2.95 per share plus all accrued and unpaid dividends or (ii) the market price of the common stock issuable upon conversion of each share of Series A preferred stock into common stock, plus all accrued and unpaid dividends. Since the maximum redemption amount was contingent on the fair value of the equity security at the redemption date, the Company calculated the accretion based on the fair value as of the balance sheet date prorated over the contractual life. The Company recorded $111.5 million and $37.7 million of accretion in fiscal 2012 and 2011, respectively. Subsequent to the conversion immediately prior to the closing of the Company’s initial public offering, no additional accretion has been recorded.

[0001511737-13-000013:notes:198]
Fair Value of Financial Instruments

[0001511737-13-000013:notes:199]
The carrying value of the Company’s cash equivalents, accounts receivable, accounts payable and other current liabilities approximate fair value due to their short maturities. The fair value of the Company's cash equivalents and debt are disclosed in  Note 3.

[0001511737-13-000013:notes:200]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value. The Company did not recognize any impairment losses for fiscal 2013, 2012 and 2011.

[0001511737-13-000013:notes:201]
Depreciation expense was $1.8 million, $602,000 and $213,000 for fiscal 2013, 2012 and 2011, respectively.

[0001511737-13-000013:notes:202]
Intangible Assets

[0001511737-13-000013:notes:203]
The Company’s intangible assets consist primarily of legal costs associated with application for and registration of the Company’s patents and trademarks. The Company amortizes all acquisition-related intangible assets that are subject to amortization over the estimated useful life based on economic benefit, which ranges from 5 to 10 years.

[0001511737-13-000013:notes:204]
Deferred Offering Costs

[0001511737-13-000013:notes:205]
Deferred offering costs, consisting of legal, accounting and other fees and costs relating to the Company’s initial public offering were capitalized. Deferred offering costs of $3.1 million were offset against initial public offering proceeds upon the closing of the offering in October 2011.

[0001511737-13-000013:notes:206]
Software development costs, including costs incurred to purchase third party software, begin to be capitalized when the Company has determined that certain factors are present, including, among others, that technology exists to achieve the performance requirements. The accumulation of software costs to be capitalized ceases when the software is substantially developed and is ready for its intended use. Capitalized costs are amortized on a straight line basis over the estimated useful life of the software once it is available for use. To date, the Company has not capitalized research and development costs associated with software development as products and enhancements have reached technological feasibility and have been released to customers at substantially the same time.


## us-gaap:SubsequentEventsTextBlock

[0001511737-13-000013:notes:207]
SUBSEQUENT EVENTS

[0001511737-13-000013:notes:208]
The Company has evaluated subsequent events and transactions through September 13, 2013, which is the date the annual consolidated financial statements set forth herein were issued, however the Company did not have any material subsequent events after June 30, 2013.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-13-000013:notes:209]
BALANCE SHEET COMPONENTS

[0001511737-13-000013:notes:210]
Inventories

[0001511737-13-000013:notes:211]
Prepaid Expenses and Other Current Assets

[0001511737-13-000013:notes:212]
Property and Equipment, Net

[0001511737-13-000013:notes:213]
Other Long-term Assets

[0001511737-13-000013:notes:214]
The Company's intangible assets consist primarily of legal costs associated with the application for and registration of the Company’s patents and trademarks.  The Company recorded $200,000 of amortization of intangible assets during fiscal 2013 and the balance of accumulated amortization was $200,000 at June 30, 2013.  The Company did not record any amortization of intangible assets during fiscal 2012.   As of June 30, 2013, the Company cannot reasonably estimate future amortization expense by year due to uncertain timing of patent and trademark registrations; however, the Company expects to amortize the remaining balance of its intangible assets over their estimated useful lives.

[0001511737-13-000013:notes:215]
Other Current Liabilities


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001511737-13-000013:notes:216]
COMMON STOCK AND TREASURY STOCK

[0001511737-13-000013:notes:217]
As of June 30, 2013 and 2012, the authorized capital of the Company included 500,000,000 shares of common stock. As of June 30, 2013, 131,452,763 shares of common stock were issued and 87,213,803 were outstanding. As of June 30, 2012, 131,129,888 shares of common stock were issued and 92,049,978 were outstanding.

[0001511737-13-000013:notes:218]
Common Stock Repurchases

[0001511737-13-000013:notes:219]
On August 9, 2012, the Company announced that its Board of Directors authorized the Company to repurchase up to $100 million of its common stock. The share repurchase program commenced on August 13, 2012. The share repurchase program has been funded from proceeds from the Loan Agreement as discussed in Note 8 and from existing cash on hand.  All repurchased shares are recorded as treasury stock at cost.

[0001511737-13-000013:notes:220]
Common stock repurchase activity during the year ended June 30, 2013 was as follows (in thousands, except share and per share amounts):

[0001511737-13-000013:notes:221]
| Period | Total Numberof SharesPurchased |  | Average PricePaid per Share |  | Dollar Value ofShares that MayYet Be Purchased |
| August 13, 2012 – August 31, 2012 | 2,179,900 |  |  | $ | 8.88 |  |  | $ | 80,599 |  |
| September 1, 2012 – September 30, 2012 | 992,014 |  |  | $ | 11.93 |  |  | $ | 68,742 |  |
| October 1, 2012 - October 31, 2012 | 371,665 |  |  | $ | 11.72 |  |  | $ | 64,377 |  |
| November 1, 2012 - November 30, 2012 | 657,700 |  |  | $ | 11.16 |  |  | $ | 57,024 |  |
| December 1, 2012 - December 31, 2012 | 957,771 |  |  | $ | 11.86 |  |  | $ | 45,646 |  |
| Total | 5,159,050 |  |  | $ | 10.52 |  |  | $ | 45,646 |  |

[0001511737-13-000013:notes:222]
Special Dividend

[0001511737-13-000013:notes:223]
On December 14, 2012, the Company announced that its Board of Directors had authorized a special cash dividend of $0.18 per share for each share of common stock outstanding on December 24, 2012.  The aggregate dividend payment of $15.7 million was paid on December 28, 2012 to stockholders of record on December 24, 2012.  The dividend payment was funded using proceeds from the Loan Agreement as discussed in Note 8.

[0001511737-13-000013:notes:224]
Common Stock Offering
