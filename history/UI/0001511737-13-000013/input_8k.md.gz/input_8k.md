# UI 8-K — 0001511737-13-000009 filed 2013-08-08

## item codes, every 8-K on or before 2013-09-13

- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2013-09-13

- none on or before 2013-09-13

## item 2.02 — earnings release, exhibit 99.1

[0001511737-13-000009:8k_2_02:1]
EX-99.1
2
exhibit991q42013.htm
EXHIBIT 99.1

[0001511737-13-000009:8k_2_02:2]
Exhibit 99.1 Q4 2013

[0001511737-13-000009:8k_2_02:3]
Exhibit 99.1

[0001511737-13-000009:8k_2_02:4]
| Contact: |  |  |  |  |
| Brunswick Group |  |  |  |  |
| Vanessa Chan - ubnt@brunswickgroup.com - 415-671-7676 |  |  |  |  |

[0001511737-13-000009:8k_2_02:5]
UBIQUITI NETWORKS REPORTS RECORD FOURTH QUARTER FINANCIAL RESULTS

[0001511737-13-000009:8k_2_02:6]
~ Record quarter for revenue, earnings and cash flow ~

[0001511737-13-000009:8k_2_02:7]
San Jose, Calif. - August 8, 2013 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”), a product-driven technology company for end-to-end networking solutions, today announced results for the fourth quarter ended June 30, 2013 and fiscal 2013.

[0001511737-13-000009:8k_2_02:8]
Fourth Quarter Financial Highlights

[0001511737-13-000009:8k_2_02:9]
| • | Revenues of $101.2 million, an increase of 22% from the prior quarter, marking the third consecutive quarter of sequential double-digit revenue growth. |

[0001511737-13-000009:8k_2_02:10]
| • | GAAP net income was $28.8 million, an increase of 40% sequentially. |

[0001511737-13-000009:8k_2_02:11]
| • | Non-GAAP operating profitability of $34.3 million, an increase of 42% sequentially. |

[0001511737-13-000009:8k_2_02:12]
| • | GAAP Diluted EPS of $0.32 and non-GAAP diluted EPS of $0.33. |

[0001511737-13-000009:8k_2_02:13]
| • | DSOs declined to 32 days, a record for the company. |

[0001511737-13-000009:8k_2_02:14]
| • | $47.3 million in net cash provided by operating activities. |

[0001511737-13-000009:8k_2_02:15]
Full Year Financial Highlights

[0001511737-13-000009:8k_2_02:16]
| • | Revenue of $320.8 million, down 9% from $353.5 million for the same period of the prior year. |

[0001511737-13-000009:8k_2_02:17]
| • | GAAP Diluted EPS of $0.89 and non-GAAP diluted EPS of $0.91. |

[0001511737-13-000009:8k_2_02:18]
| • | $227.8 million in cash, up from $122.1 million in the year ago period. |

[0001511737-13-000009:8k_2_02:19]
Fourth Quarter Business Highlights

[0001511737-13-000009:8k_2_02:20]
| • | Record quarter for airMAX revenue. |

[0001511737-13-000009:8k_2_02:21]
| • | Accelerating traction in WLAN business, with UniFi rising to fourth place in market share by unit volume in CQ1 and its best-ever quarter in CQ2. |

[0001511737-13-000009:8k_2_02:22]
| • | Introduced airVision 2, a complete, integrated video surveillance system that disrupts another large market opportunity. |

[0001511737-13-000009:8k_2_02:23]
| • | Provided Ecuador's Universidad del Azuay's entire campus with UniFi wireless coverage. The UniFi wireless LAN platform is now being deployed in over 100 countries on six continents. |

[0001511737-13-000009:8k_2_02:24]
“Finishing fiscal 2013 with record quarterly revenue and earnings demonstrates our ability to quickly overcome challenges. Now we are turning our full focus to growth,” said Robert J. Pera, Founder, Chief Executive Officer and Executive Chairman of Ubiquiti Networks. “Our business model, innovative technology and user community are continuing to disrupt incumbents in the networking market.”

[0001511737-13-000009:8k_2_02:25]
Financial Summary ($, in millions, except per share data)

[0001511737-13-000009:8k_2_02:26]
| Financials | F4Q13 | F3Q13 | F4Q12 |
| Revenues | 101.2 | 83.2 | 94.9 |
| Cost of Revenues | 56.9 | 47.7 | 53.8 |
| Gross Profit | 44.4 | 35.5 | 41.0 |
| Total Operating Expenses | 11.2 | 12.0 | 7.0 |
| Income from Operations | 33.2 | 23.5 | 34.1 |
| Non-GAAP EPS (diluted) | 0.33 | 0.24 | 0.30 |

[0001511737-13-000009:8k_2_02:27]
Business Outlook

[0001511737-13-000009:8k_2_02:28]
Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's fiscal first quarter ending September 30, 2013:

[0001511737-13-000009:8k_2_02:29]
| • | Revenues of between $116 million and $122 million |

[0001511737-13-000009:8k_2_02:30]
| • | GAAP Diluted EPS of between $0.37 and $0.40 |

[0001511737-13-000009:8k_2_02:31]
| • | Non-GAAP Diluted EPS of between $0.38 and $0.41 |

[0001511737-13-000009:8k_2_02:32]
Conference Call

[0001511737-13-000009:8k_2_02:33]
Ubiquiti Networks will host a Q&A-only conference call to discuss the Company's financial results at 2:00 p.m. PDT today. In lieu of prepared remarks, the company has provided an audio file and a transcript of management's prepared remarks on the Investor Relations section of Ubiquiti Networks' website, http://www.ubnt.com/.

[0001511737-13-000009:8k_2_02:34]
To listen to the Q&A-only conference call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) and provide the passcode 21115178. Participants should dial in at least 10 minutes prior to the start of the call. Investors may also listen to a live webcast of the Q&A-only conference call by visiting the Investor Relations section of Ubiquiti Networks' website.

[0001511737-13-000009:8k_2_02:35]
The playback of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of Ubiquiti Networks' website.

[0001511737-13-000009:8k_2_02:36]
About Ubiquiti Networks

[0001511737-13-000009:8k_2_02:37]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere.  With over 10 million devices deployed in over 180 countries, Ubiquiti is transforming under-networked businesses and communities.  Our leading edge platforms, airMAX™, UniFi™, airFiber™, airVision™, mFi™ and EdgeMAX™ combine innovative technology, disruptive price performance and the support of a global user community to eliminate barriers to connectivity.   For more information, join our community at http://www.ubnt.com

[0001511737-13-000009:8k_2_02:38]
Use of Non-GAAP Financial Information

[0001511737-13-000009:8k_2_02:39]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense and the tax effects of these non-GAAP adjustments.  In addition, our non-GAAP adjustments present shares of Series A preferred stock as if these shares had been converted to common stock throughout the periods presented.  Reconciliations of the adjustments to GAAP results for the three and twelve months ended June 30, 2013 and 2012 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, the material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-13-000009:8k_2_02:40]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.

[0001511737-13-000009:8k_2_02:41]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, distributors' inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability  to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J.  Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S.  Securities laws and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2012 and in our Quarterly Reports on Form 10-Q for the quarters ended September 30, 2012, December 31, 2012 and March 31, 2013 and other filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting Ubiquiti Networks' Investor Relations Department, or by email at investor.relations@ubnt.com or Ubiquiti Networks' Investor Relations website at www.ubnt.com.

[0001511737-13-000009:8k_2_02:42]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti Networks undertakes no obligation to update information contained in this press release.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-13-000009:8k_2_02:43]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenues |  | $ | 101,232 |  |  | $ | 94,868 |  |  | $ | 320,823 |  |  | $ | 353,517 |  |
| Cost of revenues |  | 56,868 |  |  | 53,827 |  |  | 185,489 |  |  | 202,514 |  |
| Gross profit |  | 44,364 |  |  | 41,041 |  |  | 135,334 |  |  | 151,003 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 5,515 |  |  | 5,028 |  |  | 20,955 |  |  | 16,699 |  |
| Sales, general and administrative |  | 5,642 |  |  | 1,953 |  |  | 21,775 |  |  | 9,012 |  |
| Total operating expenses |  | 11,157 |  |  | 6,981 |  |  | 42,730 |  |  | 25,711 |  |
| Income from operations |  | 33,207 |  |  | 34,060 |  |  | 92,604 |  |  | 125,292 |  |
| Interest expense and other, net |  | (281 | ) |  | (133 | ) |  | (851 | ) |  | (1,269 | ) |
| Income before provision for income taxes |  | 32,926 |  |  | 33,927 |  |  | 91,753 |  |  | 124,023 |  |
| Provision for income taxes |  | 4,085 |  |  | 5,442 |  |  | 11,263 |  |  | 21,434 |  |
| Net income |  | $ | 28,841 |  |  | $ | 28,485 |  |  | $ | 80,490 |  |  | $ | 102,589 |  |
| Preferred stock cumulative dividend and accretion of cost of preferred stock |  | — |  |  | — |  |  | — |  |  | (112,431 | ) |
| Net income (loss) attributable to common stockholders |  | $ | 28,841 |  |  | $ | 28,485 |  |  | $ | 80,490 |  |  | $ | (9,842 | ) |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.33 |  |  | $ | 0.31 |  |  | $ | 0.91 |  |  | $ | (0.12 | ) |
| Diluted |  | $ | 0.32 |  |  | $ | 0.30 |  |  | $ | 0.89 |  |  | $ | (0.12 | ) |
| Weighted average shares used in computing net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 87,148 |  |  | 91,958 |  |  | 88,314 |  |  | 83,460 |  |
| Diluted |  | 89,064 |  |  | 94,168 |  |  | 90,259 |  |  | 83,460 |  |

[0001511737-13-000009:8k_2_02:44]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net income |  | $ | 28,841 |  |  | $ | 28,485 |  |  | $ | 80,490 |  |  | $ | 102,589 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 137 |  |  | 43 |  |  | 446 |  |  | 117 |  |
| Research and development |  | 442 |  |  | 177 |  |  | 1,433 |  |  | 542 |  |
| Sales, general and administrative |  | 548 |  |  | 241 |  |  | 1,497 |  |  | 834 |  |
| Income from a coexistence licensing agreement |  | — |  |  | (1,500 | ) |  | — |  |  | (1,500 | ) |
| Tax effect of non-GAAP adjustments |  | (451 | ) |  | 416 |  |  | (1,351 | ) |  | 3 |  |
| Non-GAAP net income |  | $ | 29,517 |  |  | $ | 27,862 |  |  | $ | 82,515 |  |  | $ | 102,585 |  |
| Non-GAAP diluted EPS (1) |  | $ | 0.33 |  |  | $ | 0.30 |  |  | $ | 0.91 |  |  | $ | 1.09 |  |
| Weighted-average shares used in non-GAAP diluted EPS (1) |  | 89,064 |  |  | 94,168 |  |  | 90,259 |  |  | 93,762 |  |

[0001511737-13-000009:8k_2_02:45]
| (1) | Non-GAAP Diluted EPS is calculated using non-GAAP net income excluding stock-based compensation and income from a coexistence licensing agreement, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001511737-13-000009:8k_2_02:46]
| Ubiquiti Networks, Inc.Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In Computing Non-GAAP Diluted EPS(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Weighted-average shares used in computing netincome (loss) per share of common stock-diluted |  | 89,064 |  |  | 94,168 |  |  | 90,259 |  |  | 83,460 |  |
| Add back: |  |  |  |  |  |  |  |  |
| Weighted-average dilutive effect of stock options and restricted stock units |  | — |  |  | — |  |  | — |  |  | 2,695 |  |
| Weighted-average shares of Series A preferred shares outstanding |  | — |  |  | — |  |  | — |  |  | 7,607 |  |
| Weighted-average shares used in computing non-GAAP diluted EPS |  | 89,064 |  |  | 94,168 |  |  | 90,259 |  |  | 93,762 |  |

[0001511737-13-000009:8k_2_02:47]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands, except share amounts)(Unaudited) |
|  |  | Years Ended June 30, |
|  |  | 2013 |  | 2012(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 227,826 |  |  | $ | 122,060 |  |
| Accounts receivable, net |  | 35,884 |  |  | 75,644 |  |
| Inventories |  | 15,880 |  |  | 7,734 |  |
| Current deferred tax asset |  | 733 |  |  | 882 |  |
| Prepaid expenses and other current assets |  | 3,151 |  |  | 1,577 |  |
| Total current assets |  | 283,474 |  |  | 207,897 |  |
| Property and equipment, net |  | 5,976 |  |  | 4,471 |  |
| Long-term deferred tax asset |  | 527 |  |  | 232 |  |
| Other long–term assets |  | 2,886 |  |  | 1,136 |  |
| Total assets |  | $ | 292,863 |  |  | $ | 213,736 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 36,187 |  |  | $ | 26,450 |  |
| Customer deposits |  | 5,123 |  |  | 235 |  |
| Deferred revenues |  | 691 |  |  | 805 |  |
| Income taxes payable |  | 2,788 |  |  | 946 |  |
| Debt - short-term |  | 5,013 |  |  | 6,968 |  |
| Other current liabilities |  | 11,150 |  |  | 17,031 |  |
| Total current liabilities |  | 60,952 |  |  | 52,435 |  |
| Long-term taxes payable |  | 11,857 |  |  | 7,727 |  |
| Debt - long-term |  | 71,116 |  |  | 22,623 |  |
| Deferred revenues - long-term |  | 2,510 |  |  | — |  |
| Total liabilities |  | 146,435 |  |  | 82,785 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 87 |  |  | 92 |  |
| Additional paid–in capital |  | 133,974 |  |  | 128,981 |  |
| Treasury stock |  | (123,864 | ) |  | (69,515 | ) |
| Retained earnings |  | 136,231 |  |  | 71,393 |  |
| Total stockholders’ equity |  | 146,428 |  |  | 130,951 |  |
| Total liabilities and stockholders’ equity |  | $ | 292,863 |  |  | $ | 213,736 |  |

[0001511737-13-000009:8k_2_02:48]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2012. |

[0001511737-13-000009:8k_2_02:49]
| Ubiquiti Networks Inc.Revenue by Product Category and Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenue by Product Category |  |  |  |  |  |  |  |  |
| airMAX |  | $ | 66,256 |  |  | $ | 58,991 |  |  | $ | 202,599 |  |  | $ | 223,743 |  |
| New platforms |  | 14,511 |  |  | 12,591 |  |  | 53,868 |  |  | 29,465 |  |
| Other systems |  | 5,462 |  |  | 10,759 |  |  | 18,190 |  |  | 52,086 |  |
| Systems |  | 86,229 |  |  | 82,341 |  |  | 274,657 |  |  | 305,294 |  |
| Embedded radio |  | 1,935 |  |  | 2,032 |  |  | 6,889 |  |  | 10,056 |  |
| Antennas/other |  | 13,068 |  |  | 10,495 |  |  | 39,277 |  |  | 38,167 |  |
| Total revenues |  | $ | 101,232 |  |  | $ | 94,868 |  |  | $ | 320,823 |  |  | $ | 353,517 |  |
| Revenue by Geographical Area |  |  |  |  |  |  |  |  |
| North America |  | $ | 31,301 |  |  | $ | 25,281 |  |  | $ | 84,820 |  |  | $ | 88,309 |  |
| South America |  | 19,944 |  |  | 16,574 |  |  | 65,764 |  |  | 88,325 |  |
| Europe, the Middle East and Africa |  | 37,170 |  |  | 38,957 |  |  | 127,860 |  |  | 130,494 |  |
| Asia Pacific |  | 12,817 |  |  | 14,056 |  |  | 42,379 |  |  | 46,389 |  |
| Total revenues |  | $ | 101,232 |  |  | $ | 94,868 |  |  | $ | 320,823 |  |  | $ | 353,517 |  |

[0001511737-13-000009:8k_2_02:50]
About our Non-GAAP Net Income and Adjustments

[0001511737-13-000009:8k_2_02:51]
Use of Non-GAAP Financial Information

[0001511737-13-000009:8k_2_02:52]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain recurring costs, expenses and gains.

[0001511737-13-000009:8k_2_02:53]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts and/or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-13-000009:8k_2_02:54]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-13-000009:8k_2_02:55]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense and the tax effect of these adjustments. In addition, our non-GAAP diluted earnings per share is calculated using weighted-average shares outstanding as if Series A preferred stock outstanding had been converted to common stock throughout the periods presented. Examples of items excluded from net income are:

[0001511737-13-000009:8k_2_02:56]
| • | Recurring charges and gains, including: |

[0001511737-13-000009:8k_2_02:57]
| ◦ | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001511737-13-000009:8k_2_02:58]
| • | Income from a coexistence licensing agreement |

[0001511737-13-000009:8k_2_02:59]
| • | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001511737-13-000009:8k_2_02:60]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-13-000009:8k_2_02:61]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-13-000009:8k_2_02:62]
For more information on the non-GAAP adjustments, please see the tables captioned “Reconciliation of GAAP Net Income to non-GAAP Net Income” and “Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In Computing Non-GAAP Diluted EPS” included in this press release.
