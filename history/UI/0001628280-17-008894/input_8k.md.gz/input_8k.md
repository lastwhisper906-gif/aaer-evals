# UI 8-K — 0001654954-17-006902 filed 2017-08-03

## item codes, every 8-K on or before 2017-08-25

- 2017-08-10 0001654954-17-007226 — 7.01, 9.01
- 2017-08-03 0001654954-17-006902 — 2.02, 9.01
- 2017-05-04 0001415889-17-000692 — 2.02, 9.01
- 2017-04-20 0001415889-17-000662 — 1.01, 2.03, 9.01
- 2017-03-03 0001415889-17-000354 — 8.01
- 2017-02-21 0001571049-17-001493 — 7.01, 9.01
- 2017-02-09 0001415889-17-000235 — 2.02, 9.01
- 2016-12-16 0001415889-16-007589 — 5.07
- 2016-12-08 0001415889-16-007559 — 4.01, 8.01, 9.01
- 2016-11-03 0001415889-16-007334 — 2.02, 9.01
- 2016-08-17 0001415889-16-006877 — 8.01
- 2016-08-10 0001415889-16-006753 — 5.02
- 2016-08-04 0001415889-16-006679 — 2.02, 8.01, 9.01
- 2016-05-05 0001415889-16-005749 — 2.02, 5.02, 8.01, 9.01
- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2017-08-25

- none on or before 2017-08-25

## item 2.02 — earnings release, exhibit 99.1

[0001654954-17-006902:8k_2_02:1]
EX-99.1
2
ex99-1.htm
PRESS RELEASE

[0001654954-17-006902:8k_2_02:2]
Exhibit 99.1

[0001654954-17-006902:8k_2_02:3]
UBIQUITI NETWORKS REPORTS PRELIMINARY FOURTH QUARTER FISCAL 2017
FINANCIAL RESULTS

[0001654954-17-006902:8k_2_02:4]
~ Achieves Record Revenue and Eighth Consecutive Quarter of
Revenue Growth ~

[0001654954-17-006902:8k_2_02:5]
~
Provides Revenue Outlook for Fiscal 2018 of $1.0 billion - $1.15
billion 
~

[0001654954-17-006902:8k_2_02:6]
~The Company to Host Investor Update Meeting on September 26,
2017~

[0001654954-17-006902:8k_2_02:7]
New
York, NY – August 3, 2017 - Ubiquiti Networks, Inc. (NASDAQ:
UBNT) (“Ubiquiti” or the “Company”) today
announced results for its fourth quarter fiscal 2017 ended June 30,
2017.

[0001654954-17-006902:8k_2_02:8]
Fourth Quarter Fiscal 2017 Financial Summary

[0001654954-17-006902:8k_2_02:9]
●

[0001654954-17-006902:8k_2_02:10]
Record quarterly revenues of $228.6 million, increasing 23%
year-over-year

[0001654954-17-006902:8k_2_02:11]
●

[0001654954-17-006902:8k_2_02:12]
GAAP gross profit of $103.2 million, representing 45.1% of
revenues

[0001654954-17-006902:8k_2_02:13]
●

[0001654954-17-006902:8k_2_02:14]
GAAP net income of $60.7 million and non-GAAP net income of $61.0
million

[0001654954-17-006902:8k_2_02:15]
●

[0001654954-17-006902:8k_2_02:16]
GAAP diluted EPS of $0.74 and non-GAAP diluted EPS of
$0.75

[0001654954-17-006902:8k_2_02:17]
Fourth Quarter Financial Highlights

[0001654954-17-006902:8k_2_02:18]
●

[0001654954-17-006902:8k_2_02:19]
Revenues increased 23% year-over-year and 4.7%
sequentially, primarily driven by continued
strong demand for new product offerings across the Company’s
product lines.

[0001654954-17-006902:8k_2_02:20]
●

[0001654954-17-006902:8k_2_02:21]
Enterprise Technology revenues increased 49%
year-over-year, primarily driven by continued adoption of
the Company’s UniFi product family of access points,
switches, gateways and IP cameras.

[0001654954-17-006902:8k_2_02:22]
●

[0001654954-17-006902:8k_2_02:23]
Service Provider Technology revenues increased
5% year-over-year and 10% sequentially, primarily driven by
the Company’s airMAX AC and airMAX AC Gen 2 product
lines.

[0001654954-17-006902:8k_2_02:24]
●

[0001654954-17-006902:8k_2_02:25]
GAAP gross margin of 45.1%, reflecting the
success of our newer product offerings. We generally
introduce new products at an aggressive price to capture market
share and experience margin expansion over time as we reduce costs
while maintaining our selling price. Recent revenue growth has been
primarily driven by new product offerings and, accordingly, gross
margins have decreased slightly on a sequential basis and declined
3.2% on a year-over-year basis.

[0001654954-17-006902:8k_2_02:26]
●

[0001654954-17-006902:8k_2_02:27]
Research and Development expenses increased to
$21.6 million, primarily driven by an increase of
approximately $4 million in non-recurring engineering (NRE)
payments.

[0001654954-17-006902:8k_2_02:28]
Recent Product Highlights

[0001654954-17-006902:8k_2_02:29]
●

[0001654954-17-006902:8k_2_02:30]
Provided GPS synchronization functionality for
the airMAX AC product family, available with only a simple
firmware upgrade.

[0001654954-17-006902:8k_2_02:31]
●

[0001654954-17-006902:8k_2_02:32]
Released significant updates to the UniFi
ecosystem, including new hotspot analytics, high density
WLAN improvements, increased scalability and an integrated RADIUS
server for our security gateways.

[0001654954-17-006902:8k_2_02:33]
●

[0001654954-17-006902:8k_2_02:34]
Introduced the UFiber GPON platform,
enabling internet service providers to quickly build high-speed
fiber networks for many users and over long distances.

[0001654954-17-006902:8k_2_02:35]
●

[0001654954-17-006902:8k_2_02:36]
Introduced PrismStation AC base station radios
and airPrism sector antennas, enabling the next stage of
high-performance, high-density airMAX networks throughout the
world.

[0001654954-17-006902:8k_2_02:37]
●

[0001654954-17-006902:8k_2_02:38]
Continued the roll-out of the AmpliFi product
family into retail stores, including Best Buy, Sam’s
Club, GameStop and international retailers.

[0001654954-17-006902:8k_2_02:39]
●

[0001654954-17-006902:8k_2_02:40]
Added new features to the AmpliFi product
family, including increased parental controls, remote
access, wired ethernet backhaul, support for multiple languages and
other features.

[0001654954-17-006902:8k_2_02:41]
Financial Highlights ($, in millions, except per share
data)

[0001654954-17-006902:8k_2_02:42]
| Income statement highlights |  | F4Q17 |  | F3Q17 |  | F4Q16 |
| Revenues |  | 228.6 |  | 218.4 |  | 185.7 |
| Service Provider Technology |  | 114.7 |  | 104.7 |  | 109.0 |
| Enterprise Technology |  | 114.0 |  | 113.6 |  | 76.7 |
| Gross profit |  | 103.2 |  | 99.1 |  | 89.8 |
| Gross Profit (%) |  | 45.1% |  | 45.4% |  | 48.3% |
| Total operating expenses |  | 31.5 |  | 25.7 |  | 24.1 |
| Income from operations |  | 71.7 |  | 73.4 |  | 65.6 |
| GAAP Net Income |  | 60.7 |  | 64.4 |  | 57.7 |
| GAAP EPS (diluted) |  | 0.74 |  | 0.77 |  | 0.69 |
| Non-GAAP Net Income |  | 61.0 |  | 64.6 |  | 58.2 |
| Non-GAAP EPS (diluted) |  | 0.75 |  | 0.78 |  | 0.69 |

[0001654954-17-006902:8k_2_02:43]
Balance Sheet Highlights

[0001654954-17-006902:8k_2_02:44]
Total
cash and cash equivalents as of June 30, 2017 were $604.2 million,
compared with $533.9 million as of March 31, 2017, representing an
increase of over 13%. The Company held $546.8 million of cash and
cash equivalents in accounts of the Company’s subsidiaries
outside of the United States. The Company repurchased $2.5 million
of common stock during the quarter, representing 50,000 shares at
an average price of $49.55 per share.

[0001654954-17-006902:8k_2_02:45]
This
quarter the Company experienced an increase in days sales
outstanding in accounts receivable ("DSO") to 55 days, compared
with 52 days in the prior quarter. DSO’s have increased over
time and we expect this increase to continue as the mix of the
Company’s distributors evolves toward larger volumes of
products moving through large distributors who qualify for credit
terms. Enabling these distributors to purchase higher volumes of
products on credit terms allows them to shorten the cash conversion
cycle and has helped enable Ubiquiti to significantly expand its
market share while maintaining a conservative customer credit
profile.

[0001654954-17-006902:8k_2_02:46]
Ubiquiti
has invested in inventory to reduce lead times, meet increasing
demand and support the commensurate growth of the Company’s
customers. The Company is committed to optimizing inventory to
correspond with end-market demand. Finished goods inventory at the
end of the quarter increased $11.0 million to $133.8 million,
primarily driven by increased inventory of our newer products. The
Company expects to hold 8 to 12 weeks of previously introduced
product inventory in warehouses going forward, in addition to new
product inventory and selected raw materials.

[0001654954-17-006902:8k_2_02:47]
Outlook

[0001654954-17-006902:8k_2_02:48]
Based
on recent business trends, the Company believes the demand
environment in its end markets supports the following forecast for
the Company's first quarter fiscal 2018 ending September 30,
2017:

[0001654954-17-006902:8k_2_02:49]
●

[0001654954-17-006902:8k_2_02:50]
Revenues of
$230-$250 million;

[0001654954-17-006902:8k_2_02:51]
●

[0001654954-17-006902:8k_2_02:52]
GAAP diluted EPS of
$0.80-$0.90;

[0001654954-17-006902:8k_2_02:53]
●

[0001654954-17-006902:8k_2_02:54]
Gross margins are
expected to remain consistent on a sequential basis;
and

[0001654954-17-006902:8k_2_02:55]
●

[0001654954-17-006902:8k_2_02:56]
An effective tax
rate of 13%.

[0001654954-17-006902:8k_2_02:57]
For the
full year fiscal ending June 30, 2018, the Company expects to
generate revenues of $1.0 - $1.15 billion and diluted earnings per
share of $3.70 - $4.30 driven by growth in the Enterprise
Technology and Service Provider Technology segments.

[0001654954-17-006902:8k_2_02:58]
Investor Update Meeting Scheduled for September 26,
2017

[0001654954-17-006902:8k_2_02:59]
The
Company’s Chairman, Chief Executive Officer, and Founder,
Robert Pera, will host an Investor Update on September 26th at
12:30 p.m. Eastern Time. The meeting will include an Investor
Relations update from Laura Kiernan, and a question and answer
session. The meeting will be video webcast live and will remain on
the Company’s website following the event. Additional details
on the event will be provided at a later date.

[0001654954-17-006902:8k_2_02:60]
Conference Call Information

[0001654954-17-006902:8k_2_02:61]
Ubiquiti
Networks will host a Q&A-only call to discuss the
Company’s financial results at 11:00 a.m. Eastern Time (8:00
a.m. Pacific Time) today. Management’s prepared remarks can
be found on the Investor Relations section of the Ubiquiti Networks
website, http://ir.ubnt.com/results.cfm.

[0001654954-17-006902:8k_2_02:62]
To
listen to the Q&A call via telephone, dial 1-877-291-1296 (U.S.
toll-free) or 1-720-259-9209 (International) Conference ID:
54990409. Participants should dial in at least 10 minutes prior to
the start of the call. Investors may also listen to a live webcast
of the Q&A conference call by visiting the Investor Relations
section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001654954-17-006902:8k_2_02:63]
A
recording of the Q&A call will be available approximately two
hours after the call concludes and will be accessible on the
Investor Relations section of the Ubiquiti Networks website,
http://ir.ubnt.com.

[0001654954-17-006902:8k_2_02:64]
About Ubiquiti Networks

[0001654954-17-006902:8k_2_02:65]
Ubiquiti
Networks, Inc. (Nasdaq: UBNT) eliminates barriers to connectivity
for under-networked enterprises, communities and consumers with its
leading-edge platforms that connect hundreds of millions of people
throughout the world.  With over 60 million devices sold
worldwide, through a network of over 100 distributors, to customers
in more than 180 countries and territories, Ubiquiti has maintained
an industry-leading financial profile by leveraging a unique
business model to develop products that combine innovative
technology with disruptive price-to-performance
characteristics.  Our growth is supported by the Ubiquiti
Community, a global grass-roots community of 4 million
entrepreneurial operators and systems integrators who engage in
thousands of forums.  For more information, join our community
at http://www.ubnt.com.

[0001654954-17-006902:8k_2_02:66]
Ubiquiti,
Ubiquiti Networks, the U logo, UBNT, airMAX, airFiber, mFi,
EdgeMAX, UniFi, AmpliFi and UFiber are registered trademarks or
trademarks of Ubiquiti Networks, Inc. in the United States and
other countries.

[0001654954-17-006902:8k_2_02:67]
Investor Relations Contact

[0001654954-17-006902:8k_2_02:68]
Laura
Kiernan

[0001654954-17-006902:8k_2_02:69]
SVP
Investor Relations

[0001654954-17-006902:8k_2_02:70]
Ubiquiti
Networks, Inc.

[0001654954-17-006902:8k_2_02:71]
laura.kiernan@ubnt.com

[0001654954-17-006902:8k_2_02:72]
Ph. 1-914-598-7733

[0001654954-17-006902:8k_2_02:73]
Forward-looking
statements are subject to certain risks and uncertainties that
could cause our actual future results to differ materially, or
cause a material adverse impact on our results. Potential risks and
uncertainties include, but are not limited to, fluctuations in our
operating results; varying demand for our products due to the
financial and operating condition of our distributors and their
customers, and distributors' inventory management practices;
political and economic conditions and volatility affecting the
stability of business environments, economic growth, currency
values, commodity prices and other factors that may influence the
ultimate demand for our products in particular geographies or
globally; impact of counterfeiting and our ability to contain such
impact; our reliance on a limited number of distributors; inability
of our contract manufacturers and suppliers to meet our demand; our
dependence on Qualcomm Atheros for chipsets without a short-term
alternative; as we move into new markets competition from certain
of our current or potential competitors who may be more established
in such markets; our ability to keep pace with technological and
market developments; success and timing of new product
introductions by us and the performance of our products generally;
our ability to effectively manage the significant increase in our
transactional sales volumes; we may become subject to warranty
claims, product liability and product recalls; that a substantial
majority of our sales are into countries outside the United States
and we are subject to numerous U.S. export control and economic
sanctions laws; costs related to responding to government inquiries
related to regulatory compliance; our reliance on the Ubiquiti
Community; our reliance on certain key members of our management
team, including our founder and chief executive officer, Robert J.
Pera; adverse tax-related matters such as tax audits, changes in
our effective tax rate or new tax legislative proposals; whether
the final determination of our income tax liability may be
materially different from our income tax provisions; the impact of
any intellectual property litigation and claims for
indemnification; litigation related to U.S. Securities laws; and
economic and political conditions in the United States and abroad.
We discuss these risks in greater detail under the heading
“Risk Factors” and elsewhere in our Annual Report on
Form 10-K for the year ended June 30, 2016, and subsequent filings
filed with the U.S. Securities and Exchange Commission (the
“SEC”), which are available at the SEC's website at
www.sec.gov. Copies may also be obtained by contacting the Ubiquiti
Networks Investor Relations Department, by email at IR@ubnt.com or
by visiting the Investor Relations section of the Ubiquiti Networks
website, http://ir.ubnt.com .

[0001654954-17-006902:8k_2_02:74]
Given
these uncertainties, you should not place undue reliance on these
forward-looking statements. Also, forward-looking statements
represent our management's beliefs and assumptions only as of the
date made. Except as required by law, Ubiquiti Networks undertakes
no obligation to update information contained herein. You should
review our SEC filings carefully and with the understanding that
our actual future results may be materially different from what we
expect.

[0001654954-17-006902:8k_2_02:75]
Ubiquiti Networks, Inc.

[0001654954-17-006902:8k_2_02:76]
Condensed Consolidated Statement of Operations

[0001654954-17-006902:8k_2_02:77]
(In thousands, except per share data)

[0001654954-17-006902:8k_2_02:78]
(Unaudited)

[0001654954-17-006902:8k_2_02:79]
|  | Three Months Ended June 30, | Years Ended June 30, |
|  | 2017 | 2016 | 2017 | 2016 (1) |
| Revenues | $228,616 | $185,676 | $865,268 | $666,395 |
| Cost of revenues | 125,437 | 95,919 | 469,560 | 341,600 |
| Gross profit | 103,179 | 89,757 | 395,708 | 324,795 |
| Operating expenses: |  |  |  |  |
| Research and development | 21,614 | 14,955 | 69,094 | 57,765 |
| Sales, general and administrative | 9,915 | 9,156 | 36,853 | 33,269 |
| Business e-mail compromise ("BEC") fraud (recovery) | — | — | — | (8,294) |
| Total operating expenses | 31,529 | 24,111 | 105,947 | 82,740 |
| Income from operations | 71,650 | 65,646 | 289,761 | 242,055 |
| Interest expense and other, net | (1,430) | (838) | (4,737) | (2,115) |
| Income before provision for income taxes | 70,220 | 64,808 | 285,024 | 239,940 |
| Provision for income taxes | 9,542 | 7,102 | 27,518 | 26,324 |
| Net income and comprehensive income | $60,678 | $57,706 | $257,506 | $213,616 |
| Net income per share of common stock: |  |  |  |  |
| Basic | $0.76 | $0.70 | $3.16 | $2.53 |
| Diluted | $0.74 | $0.69 | $3.09 | $2.49 |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |
| Basic | 80,272 | 82,494 | 81,478 | 84,402 |
| Diluted | 81,906 | 83,836 | 83,252 | 85,784 |

[0001654954-17-006902:8k_2_02:80]
(1)

[0001654954-17-006902:8k_2_02:81]
Derived from
audited consolidated statements as of and for the year ended
June 30, 2016.

[0001654954-17-006902:8k_2_02:82]
Ubiquiti Networks, Inc.

[0001654954-17-006902:8k_2_02:83]
Reconciliation of GAAP Net Income to Non-GAAP Net
Income

[0001654954-17-006902:8k_2_02:84]
(In thousands, except per share data)

[0001654954-17-006902:8k_2_02:85]
(Unaudited)

[0001654954-17-006902:8k_2_02:86]
|  | Three Months Ended June 30, | Years Ended June 30, |
|  | 2017 | 2016 | 2017 | 2016 |
| Net income and comprehensive income | $60,678 | $57,706 | $257,506 | $213,616 |
| Stock-based compensation: |  |  |  |  |
| Cost of revenues | 51 | 107 | 264 | 448 |
| Research and development | 499 | 526 | 1,861 | 2,296 |
| Sales, general and administrative | 142 | 220 | 661 | 975 |
| Business e-mail compromise ("BEC") fraud (recovery) | — | — | — | (8,294) |
| Excess tax benefits resulting from the adoption of ASU 2016-09 Stock Compensation | (80) | — | (7,939) | — |
| Implementation of overhead capitalization | — | (8) | — | (1,221) |
| Tax effect of non-GAAP adjustments | (277) | (341) | (1,114) | (1,342) |
| Non-GAAP net income | $61,013 | $58,210 | $251,239 | $206,478 |
| Non-GAAP diluted EPS | $0.75 | $0.69 | $3.04 | $2.41 |
| Shares outstanding (Diluted) | 81,906 | 83,836 | 83,252 | 85,784 |
| Share adjustment (ASU 2016-09 Adoption) | (622) | — | (672) | — |
| Weighted-average shares used in non-GAAP diluted EPS | 81,284 | 83,836 | 82,580 | 85,784 |

[0001654954-17-006902:8k_2_02:87]
Use of Non-GAAP Financial Information

[0001654954-17-006902:8k_2_02:88]
To
supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use
non-GAAP measures of net income and earnings per diluted share that
are adjusted to exclude certain costs, expenses and gains such as
stock based compensation expense, Business e-mail compromise
("BEC") fraud (recovery), the adoption of ASU 2016-09 Improvements
to Employee Share-Based Payments Accounting, implementation of
overhead capitalization and the tax effects of these non-GAAP
adjustments. Reconciliations of the adjustments to GAAP results for
the three and twelve month periods ended June 30, 2017 and 2016 are
provided above. In addition, an explanation of the ways in which
management uses non-GAAP financial information to evaluate its
business, the substance behind management's decision to use this
non-GAAP financial information, material limitations associated
with the use of non-GAAP financial information, the manner in which
management compensates for those limitations, and the substantive
reasons management believes that this non-GAAP financial
information provides useful information to investors is included
under "About our Non-GAAP Net Income and Adjustments" after the
tables below.

[0001654954-17-006902:8k_2_02:89]
Ubiquiti Networks, Inc.

[0001654954-17-006902:8k_2_02:90]
Condensed Consolidated Balance Sheets

[0001654954-17-006902:8k_2_02:91]
(In thousands, except share amounts)

[0001654954-17-006902:8k_2_02:92]
(Unaudited)

[0001654954-17-006902:8k_2_02:93]
|  | June 30, |
|  | 2017 | 2016 (1) |
| Assets |  |  |
| Current assets: |  |  |
| Cash and cash equivalents | $604,198 | $551,031 |
| Accounts receivable, net | 138,875 | 82,790 |
| Inventories | 142,048 | 57,113 |
| Vendor deposits | 54,082 | 30,255 |
| Prepaid income taxes | 2,419 | 299 |
| Prepaid expenses and other current assets | 9,026 | 6,896 |
| Total current assets | 950,648 | 728,384 |
| Property and equipment, net | 12,916 | 12,953 |
| Long-term deferred tax assets | 5,133 | 4,195 |
| Other long–term assets | 2,328 | 1,576 |
| Total assets | $971,025 | $747,108 |
| Liabilities and Stockholders’ Equity |  |  |
| Current liabilities: |  |  |
| Accounts payable | $49,009 | $51,510 |
| Income taxes payable | 1,707 | 1,488 |
| Debt - short-term | 14,743 | 10,993 |
| Other current liabilities | 31,344 | 26,672 |
| Total current liabilities | 96,803 | 90,663 |
| Long-term taxes payable | 28,023 | 23,202 |
| Debt - long-term | 241,821 | 191,564 |
| Deferred revenues - long-term | 2,615 | 1,303 |
| Total liabilities | 369,262 | 306,732 |
| Stockholders’ equity: |  |  |
| Common stock | 80 | 82 |
| Additional paid- in capital | 525 | — |
| Retained earnings | 601,158 | 440,294 |
| Total stockholders’ equity | 601,763 | 440,376 |
| Total liabilities and stockholders’ equity | $971,025 | $747,108 |

[0001654954-17-006902:8k_2_02:94]
(1)

[0001654954-17-006902:8k_2_02:95]
Derived from
audited consolidated statements as of and for the year ended
June 30, 2016.

[0001654954-17-006902:8k_2_02:96]
Ubiquiti Networks, Inc.

[0001654954-17-006902:8k_2_02:97]
Revenues by Product Type

[0001654954-17-006902:8k_2_02:98]
(In thousands)

[0001654954-17-006902:8k_2_02:99]
(Unaudited)

[0001654954-17-006902:8k_2_02:100]
|  | Three Months Ended June 30, | Years Ended June 30, |
|  | 2017 | 2016 | 2017 | 2016 |
| Service Provider Technology | $114,662 | $109,004 | $455,598 | $418,346 |
| Enterprise Technology | 113,954 | 76,672 | 409,670 | 248,049 |
| Total revenues | $228,616 | $185,676 | $865,268 | $666,395 |

[0001654954-17-006902:8k_2_02:101]
Ubiquiti Networks, Inc.

[0001654954-17-006902:8k_2_02:102]
Revenues by Geographical Area

[0001654954-17-006902:8k_2_02:103]
(In thousands)

[0001654954-17-006902:8k_2_02:104]
(Unaudited)

[0001654954-17-006902:8k_2_02:105]
|  | Three Months Ended June 30, | Years Ended June 30, |
|  | 2017 | 2016 | 2017 | 2016 |
| North America | $84,088 | $71,087 | $331,435 | $239,526 |
| South America | 34,271 | 23,925 | 105,511 | 85,036 |
| Europe, the Middle East and Africa | 87,937 | 69,658 | 334,473 | 264,404 |
| Asia Pacific | 22,320 | 21,006 | 93,849 | 77,429 |
| Total revenues | $228,616 | $185,676 | $865,268 | $666,395 |

[0001654954-17-006902:8k_2_02:106]
About our Non-GAAP Net Income and Adjustments

[0001654954-17-006902:8k_2_02:107]
Use of Non-GAAP Financial Information

[0001654954-17-006902:8k_2_02:108]
To
supplement our condensed consolidated financial results prepared
under generally accepted accounting principles, or GAAP, we use
non-GAAP measures of net income and earnings per diluted share that
are GAAP net income and GAAP earnings per diluted share adjusted to
exclude certain costs, expenses and gains/losses.

[0001654954-17-006902:8k_2_02:109]
We
believe that the presentation of non-GAAP net income and non-GAAP
earnings per diluted share provides important supplemental
information regarding non-cash expenses, significant items that we
believe are important to understanding our financial, and business
trends relating to our financial condition and results of
operations. Non-GAAP net income and non-GAAP earnings per diluted
share are among the primary indicators used by management as a
basis for planning and forecasting future periods and by management
and our board of directors to determine whether our operating
performance has met specified targets and thresholds. Management
uses non-GAAP net income and non-GAAP earnings per diluted share
when evaluating operating performance because it believes that the
exclusion of the items described below, for which the amounts or
timing may vary significantly depending upon the Company's
activities and other factors, facilitates comparability of the
Company's operating performance from period to period. We have
chosen to provide this information to investors so they can analyze
our operating results in the same way that management does and use
this information in their assessment of our business and the
valuation of our Company.

[0001654954-17-006902:8k_2_02:110]
Use and Economic Substance of Non-GAAP Financial Measures used by
Ubiquiti Networks

[0001654954-17-006902:8k_2_02:111]
We
compute non-GAAP net income and non-GAAP earnings per diluted share
by adjusting GAAP net income and GAAP earnings per diluted share to
remove the impact of certain adjustments and the tax effect of
those adjustments. Items excluded from net income are:

[0001654954-17-006902:8k_2_02:112]
●

[0001654954-17-006902:8k_2_02:113]
Stock-based
compensation expense

[0001654954-17-006902:8k_2_02:114]
●

[0001654954-17-006902:8k_2_02:115]
Business e-mail
compromise ("BEC") fraud (recovery)

[0001654954-17-006902:8k_2_02:116]
●

[0001654954-17-006902:8k_2_02:117]
Adoption of ASU
2016-09 Improvements to Employee Share-Base Payment
Accounting

[0001654954-17-006902:8k_2_02:118]
●

[0001654954-17-006902:8k_2_02:119]
Implementation of
overhead capitalization

[0001654954-17-006902:8k_2_02:120]
●

[0001654954-17-006902:8k_2_02:121]
Tax effect of
non-GAAP adjustments, applying the principles of ASC
740

[0001654954-17-006902:8k_2_02:122]
Usefulness of Non-GAAP Financial Information to
Investors

[0001654954-17-006902:8k_2_02:123]
These
non-GAAP measures are not in accordance with, or an alternative to,
GAAP and may be materially different from other non-GAAP measures,
including similarly titled non-GAAP measures used by other
companies. The presentation of this additional information should
not be considered in isolation from, as a substitute for, or
superior to, net income or earnings per diluted share prepared in
accordance with GAAP. Non-GAAP financial measures have limitations
in that they do not reflect certain items that may have a material
impact upon our reported financial results. We expect to continue
to incur expenses of a nature similar to the non-GAAP adjustments
described above, and exclusion of these items from our non-GAAP net
income and non-GAAP earnings per diluted share should not be
construed as an inference that these costs are unusual, infrequent
or non-recurring.

[0001654954-17-006902:8k_2_02:124]
For
more information on the non-GAAP adjustments, please see the table
captioned “Reconciliation of GAAP Net Income to Non-GAAP Net
Income” included in this press release.
