# UI notes — 0001628280-17-008894


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001628280-17-008894:notes:1]
Customers with an accounts receivable balance of 10% or greater of total accounts receivable and customers with net revenues of 10% or greater of total revenues are presented below for the periods indicated:

[0001628280-17-008894:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Years Ended June 30, |  | June 30, |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |
| Customer A | * |  |  | * |  | * |  | * |  |  | 11 | % |
| Customer B | * |  |  | * |  | * |  | 12 | % |  | 13 | % |
| Customer C | 11 | % |  | * |  | * |  | 18 | % |  | 18 | % |

[0001628280-17-008894:notes:3]
*  denotes less than 10%


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-17-008894:notes:4]
SUPPLEMENTARY DATA (UNAUDITED)

[0001628280-17-008894:notes:5]
The following table presents the Company’s unaudited consolidated statements of operations data for each of the eight quarters during fiscal 2017 and 2016. In management’s opinion, this information has been presented on the same basis as the audited consolidated financial statements included in a separate section of this report, and all necessary adjustments, consisting only of normal recurring adjustments, have been included in the amounts below to state fairly the unaudited quarterly results when read in conjunction with the audited consolidated financial statements and related notes. The operating results for any quarter should not be relied upon as necessarily indicative of results for any future period.

[0001628280-17-008894:notes:6]
|  |  | Fiscal 2017 |
| In thousands, except per share data |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 204,757 |  |  | $ | 213,536 |  |  | $ | 218,359 |  |  | $ | 228,616 |  |
| Gross profit |  | 98,304 |  |  | 95,139 |  |  | 99,086 |  |  | 103,179 |  |
| Income from operations |  | 74,902 |  |  | 69,800 |  |  | 73,409 |  |  | 71,650 |  |
| Net income and comprehensive income |  | 71,788 |  |  | 60,608 |  |  | 64,432 |  |  | 60,678 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.88 |  |  | $ | 0.74 |  |  | $ | 0.79 |  |  | $ | 0.76 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 0.72 |  |  | $ | 0.77 |  |  | $ | 0.74 |  |
|  |  | Fiscal 2016 |
|  |  | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |
| Net revenue |  | $ | 151,415 |  |  | $ | 161,871 |  |  | $ | 167,433 |  |  | $ | 185,676 |  |
| Gross profit |  | 73,504 |  |  | 79,041 |  |  | 82,493 |  |  | 89,757 |  |
| Income from operations |  | 59,835 |  |  | 56,436 |  |  | 60,138 |  |  | 65,646 |  |
| Net income and comprehensive income |  | 53,759 |  |  | 49,452 |  |  | 52,699 |  |  | 57,706 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 0.58 |  |  | $ | 0.63 |  |  | $ | 0.70 |  |
| Diluted |  | $ | 0.61 |  |  | $ | 0.57 |  |  | $ | 0.62 |  |  | $ | 0.69 |  |


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001628280-17-008894:notes:7]
BUSINESS AND BASIS OF PRESENTATION

[0001628280-17-008894:notes:8]
Business— Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develop high performance networking technology for service providers, enterprises and consumers globally.

[0001628280-17-008894:notes:9]
The Company operates on a fiscal year ending June 30. In these notes, Ubiquiti refers to the fiscal years ended June 30, 2017, 2016 and 2015 as fiscal 2017, fiscal 2016 and fiscal 2015, respectively.

[0001628280-17-008894:notes:10]
Basis of Presentation— The Company’s consolidated financial statements and accompanying notes are prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of Ubiquiti and its wholly owned subsidiaries. The Company has wholly owned subsidiaries in Lithuania, Hong Kong, China, Latvia, Czech Republic, Canada, Ukraine, Poland, India and the Cayman Islands. The Company’s Hong Kong subsidiary also operates a branch office in Taiwan. All intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001628280-17-008894:notes:11]
Cash and Cash Equivalents

[0001628280-17-008894:notes:12]
The Company considers investments purchased with a maturity period of three months or less at the date of purchase to be cash equivalents.  Cash and cash equivalents are stated at cost which approximates fair value. The Company deposits cash and cash equivalents with financial institutions that management believes are of high credit quality. The Company’s cash and cash equivalents consist primarily of cash deposited in U.S. dollar denominated interest-bearing deposit accounts.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-17-008894:notes:13]
COMMITMENTS AND CONTINGENCIES

[0001628280-17-008894:notes:14]
Operating Leases

[0001628280-17-008894:notes:15]
The Company leases its headquarters in New York, New York and other locations worldwide under non-cancelable operating leases that expire at various dates through 2023.

[0001628280-17-008894:notes:16]
At June 30, 2017, future minimum annual payments under operating leases are as follows (in thousands):

[0001628280-17-008894:notes:17]
| Fiscal Year | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Operating leases | $ | 6,075 |  |  | $ | 3,223 |  |  | $ | 2,331 |  |  | $ | 1,484 |  |  | $ | 942 |  |  | $ | 578 |  |  | $ | 14,633 |  |

[0001628280-17-008894:notes:18]
Rent expense under operating leases was $6.7 million, $5.0 million and $3.6 million for fiscal 2017, fiscal 2016 and fiscal 2015, respectively.

[0001628280-17-008894:notes:19]
Purchase Obligations

[0001628280-17-008894:notes:20]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had inventory purchase obligations for finished goods of $32.9 million as of June 30, 2017.

[0001628280-17-008894:notes:21]
Indemnification Obligations

[0001628280-17-008894:notes:22]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001628280-17-008894:notes:23]
Legal Matters

[0001628280-17-008894:notes:24]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.  The Company is not currently aware of any pending or threatened litigation that would have a material adverse effect on the Company's financial statements.

[0001628280-17-008894:notes:25]
Shareholder Class Action Lawsuits

[0001628280-17-008894:notes:26]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California (the “Court”) against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws (collectively, the “Shareholder Lawsuit”). On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The Ninth Circuit head oral arguments on August 10, 2015. On October 24, 2016, the Ninth Circuit issued an unpublished memorandum opinion, reaffirming the district court’s dismissal of the alleged violations of Section10(b) and 20(a) of the Securities Exchange Act of 1934 and reversing the district court’s dismissal of the alleged violations of Section 11 and 15 of the Securities Act of 1933.

[0001628280-17-008894:notes:27]
On August 4, 2017, the parties to the Shareholder Lawsuit filed with the Court a settlement that they reached to resolve the Shareholder Lawsuit against the defendants.  Pursuant to the settlement stipulation and subject to certain conditions therein, the settlement class will receive $6.8 million, to be funded largely by the Company’s insurance carriers and placed into escrow within 20 calendar days of the entry of the preliminary approval order approving settlement in the Shareholder Lawsuit.

[0001628280-17-008894:notes:28]
The settlement is subject to the Court’s approval and its terms may change as a result of the settlement approval process.  The preliminary settlement approval hearing is scheduled for September 5, 2017.  The final approval hearing date is not yet set.  If the Court approves the settlement and enters a judgment substantially in the form requested by the parties, the settlement will become effective when certain conditions specified in the settlement stipulation are satisfied, including the expiration of any right to appeal the judgment.

[0001628280-17-008894:notes:29]
Synopsys

[0001628280-17-008894:notes:30]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and an employee in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act (“DMCA”). On March 28, 2017, Synopsys filed an amended complaint alleging (i) additional claims under the DMCA, (ii) claims under the Anti-Counterfeiting Act, and (iii) claims for label trafficking, fraud, civil RICO and negligent misrepresentation. On April 11, 2017, the Company moved to dismiss all but the initial DMCA claim in the amended complaint and its subsidiary moved to dismiss for lack of personal jurisdiction and joined the Company’s motion to dismiss certain claims. On August 15, 2017, the court issued an order granting the Company’s motion to dismiss the Anti-Counterfeiting Act claim and certain of the predicate acts alleged under the civil RICO claim. The court denied the motion to dismiss the remaining claims, and denied the subsidiary’s motion to dismiss for lack of jurisdiction. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation

[0001628280-17-008894:notes:31]
Vivato/XR

[0001628280-17-008894:notes:32]
On April 19, 2017, XR Communications, LLC, d/b/a Vivato Technologies (“Vivato”), filed a complaint against the Company in the United States District Court for the Central District of California, alleging that at least one of the Company’s products infringes United States Patent Numbers 7,062,296 (the “’296 Patent”), 7,729,728 (the “’728 Patent”), and 6,611,231 (the “’231 Patent and, collectively, the “Patents-in-Suit”).  The ‘296 and ‘728 Patents are entitled “Forced Beam Switching in Wireless Communication Systems Having Smart Antennas.”  The ‘231 Patent is entitled “Wireless Packet Switched Communications Systems and Networks Using Adaptively Steered Antenna Arrays.”  Vivato amended its complaint on June 23, 2017 and again on July 6, 2017.  According to the complaint, the products accused of infringing the Patents-in-Suit include Wi-Fi access points and routers supporting MU-MIMO, including without limitation access points and routers utilizing the IEEE 802.11ac-2013 standard. Vivato has also recently filed nine other lawsuits asserting the same patents against other defendants in the Central District of California.

[0001628280-17-008894:notes:33]
The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001628280-17-008894:notes:34]
Commitments and Contingencies

[0001628280-17-008894:notes:35]
The Company periodically evaluates all pending or threatened contingencies and any commitments, if any, that are reasonably likely to have a material adverse effect on its results of operations, financial position or cash flows. The Company assesses the probability of an adverse outcome and determines if it is remote, reasonably possible or probable. If information available prior to the issuance of the Company’s financial statements indicates that it is probable that an asset had been impaired or a liability had been incurred at the date of the Company’s financial statements, and the amount of the loss, or the range of probable loss can be reasonably estimated, then such loss is accrued and charged to operating expenses. If no accrual is made for a loss contingency because one or both of the conditions pursuant to the accounting guidance are not met, but the probability of an adverse outcome is at least reasonably possible, the Company discloses the nature of the contingency and provides an estimate of the possible loss or range of loss, or states that such an estimate cannot be made.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001628280-17-008894:notes:36]
Stock-based Compensation

[0001628280-17-008894:notes:37]
The Company records stock-based awards at fair value as of the grant date and recognize expense, net of forfeitures, ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. The Company did not grant any stock options during fiscal 2017, fiscal 2016, or fiscal 2015. Restricted stock units are valued based on the fair value of the Company's common stock on the date of grant.  Since the Company's initial public offering on October 14, 2011, the fair value of our common stock is determined using the closing market price of the Company's common stock as of the date of grant.


## us-gaap:DebtDisclosureTextBlock

[0001628280-17-008894:notes:38]
DEBT

[0001628280-17-008894:notes:39]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its 2014 Credit Agreement (as defined below) with Wells Fargo Bank, National Association ("Wells Fargo"), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders (the "Credit Agreement").  The Credit Agreement replaced the Company's $150.0 million senior secured revolving credit facility under its prior credit agreement dated May 5, 2014 (the "2014 Credit Agreement").

[0001628280-17-008894:notes:40]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The First Amendment increased the maximum aggregate amount of the senior secured credit revolving facility from $200.0 million to $300.0 million ("Revolving Facility"), but maintained the $100.0 million senior secured term facility ("Term Facility", together with the Revolving Facility, the "Facilities") under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).

[0001628280-17-008894:notes:41]
The Amended Credit Agreement matures on March 3, 2020. The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing of the original Credit Agreement, and $72.3 million was used to repay the outstanding balance under its prior credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement.

[0001628280-17-008894:notes:42]
During fiscal 2017, the Company drew $99.0 million against the Revolving Facility. As of June 30, 2017, $76.3 million was outstanding on the Term Facility and $181.0 million on the Revolving Facility, leaving $119.0 million available on the Revolving Facility. As of June 30, 2017, the interest rate on the term loan was 2.65%. The table below shows the respective interest rates as of June 30, 2017 in addition to interest rate reset dates and rates (as available) for each revolver draw.

[0001628280-17-008894:notes:43]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | June 30, 2017 |  | Rate Reset Date |  | Reset Rate |
| $69 Million Revolver |  | 2.65% |  | 7/3/2017 |  | 2.80% |
| $18 Million Revolver |  | 2.66% |  | 7/18/2017 |  | 2.80% |
| $16 Million Revolver |  | 2.68% |  | 8/15/2017 |  | 2.82% |
| $48 Million Revolver |  | 2.70% |  | 8/30/2017 |  | * |
| $30 Million Revolver |  | 2.93% |  | 09/15/2017 |  | * |

[0001628280-17-008894:notes:44]
* - Reset rate not available as of filing date.

[0001628280-17-008894:notes:45]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan was payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017,  and thereafter increased to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company's option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001628280-17-008894:notes:46]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001628280-17-008894:notes:47]
The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

[0001628280-17-008894:notes:48]
During fiscal 2017, the Company made aggregate payments of $13.3 million against the term loan facility balance under the Amended Credit Agreement, of which $11.3 million was for repayments of principal and $2.0 million was for payments of interest. During fiscal 2017, the Company made aggregate payments of $37.2 million against the Revolving Facility under the Amended Credit Agreement, of which $34.0 million was for repayments of principal and $3.2 million was for payments of interest. As of June 30, 2017, the Company has classified $14.7 million and $241.8 million of short term and long-term debt, respectively, on its consolidated balance sheet related to the Amended Credit Agreement.

[0001628280-17-008894:notes:49]
On September 2, 2015, the Company accessed a letter of credit under its Revolving Facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2017, subject to automatic renewal

[0001628280-17-008894:notes:50]
for additional one-year periods.

[0001628280-17-008894:notes:51]
The following table summarizes our debt payment obligations as of June 30, 2017 (in thousands):

[0001628280-17-008894:notes:52]
| Fiscal Year | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Debt payment obligations(2) | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 227,250 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 257,250 |  |
| Interest and other payments on debt payment obligations (1) | 7,044 |  |  | 6,642 |  |  | 4,314 |  |  | — |  |  | — |  |  | — |  |  | 18,000 |  |
| Total | $ | 22,044 |  |  | $ | 21,642 |  |  | $ | 231,564 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 275,250 |  |

[0001628280-17-008894:notes:53]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of June 30, 2017. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

[0001628280-17-008894:notes:54]
(2)- Debt Payment obligation reported above excludes unamortized Debit Issuance Cost.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-17-008894:notes:55]
STOCK BASED COMPENSATION

[0001628280-17-008894:notes:56]
Stock-Based Compensation Plans

[0001628280-17-008894:notes:57]
2010 Equity Incentive Plan

[0001628280-17-008894:notes:58]
In March 2010, the Company’s Board of Directors and stockholders approved the 2010 Equity Incentive Plan (the “2010 Plan”). The 2010 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”), and no further awards will be granted pursuant to the 2005 Plan. Under the terms of the 2010 Plan, non-statutory stock options, stock appreciation rights, restricted stock, and restricted stock units (“RSUs”) may be granted to employees or non-employee service providers. Incentive stock options may be granted only to employees.

[0001628280-17-008894:notes:59]
The maximum aggregate number of shares that may be awarded under the 2010 Plan as of June 30, 2017 was 8,000,000 shares, plus any shares subject to stock options or similar awards granted under the 2005 Plan that expire or otherwise terminate without having been exercised in full and shares issued pursuant to awards granted under the 2005 Plan that are forfeited to (but not repurchased by) the Company.

[0001628280-17-008894:notes:60]
The 2010 Plan is administered by the Company's Board of Directors or a committee of the Company’s Board of Directors. Subject to the terms and conditions of the 2010 Plan, the administrator has the authority to select the persons to whom awards are to be made, to determine the number of shares to be subject to awards and the terms and conditions of awards, and to make all other determinations and to take all other actions necessary or advisable for the administration of the 2010 Plan. The administrator is also authorized to adopt, amend or rescind rules relating to administration of the 2010 Plan. Options and RSUs generally vest over a four year period from the date of grant and generally expire five to ten years from the date of grant. The terms of the 2010 Plan provide that an option price shall not be less than 100% of fair market value on the date of grant.

[0001628280-17-008894:notes:61]
2005 Equity Incentive Plan

[0001628280-17-008894:notes:62]
With the adoption of the 2010 Plan, no additional awards may be granted under the 2005 Plan. In February 2005, the Company’s Board of Directors and the stockholders approved the 2005 Plan, which was amended and restated in March 2006. The 2005 Plan provided for the issuance of stock options, restricted stock and stock bonuses to employees, consultants, advisors, directors and officers of the Company. The terms of the options granted under the 2005 Plan were determined at the time of grant. The Company made use of different vesting schedules through fiscal 2009, but subsequent new grants generally vested as to 25% on the first anniversary of the date of grant and monthly thereafter over the next three years and generally have a term of 10 years from the date of grant.

[0001628280-17-008894:notes:63]
As of June 30, 2017, the Company had 10,026,282 authorized shares available for future issuance under all of its stock incentive plans.

[0001628280-17-008894:notes:64]
The following table shows total stock-based compensation expense included in the Consolidated Statements of Operations and Comprehensive Income for fiscal 2017, 2016 and 2015 (in thousands):

[0001628280-17-008894:notes:65]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Cost of revenues | $ | 264 |  |  | $ | 448 |  |  | $ | 601 |  |
| Research and development | 1,861 |  |  | 2,296 |  |  | 2,854 |  |
| Sales, general and administrative | 660 |  |  | 975 |  |  | 1,537 |  |
|  | $ | 2,785 |  |  | $ | 3,719 |  |  | $ | 4,992 |  |

[0001628280-17-008894:notes:66]
Stock Options

[0001628280-17-008894:notes:67]
The following is a summary of option activity for the Company’s stock incentive plans for fiscal 2017, 2016 and 2015:

[0001628280-17-008894:notes:68]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2014 | 2,657,142 |  |  | $ | 2.96 |  |  | 5.11 |  | $ | 112,215 |  |
| Exercised | (299,034 | ) |  | $ | 5.64 |  |  |  |  |  |
| Forfeitures and cancellations | (56,964 | ) |  | $ | 12.14 |  |  |  |  |  |
| Balance, June 30, 2015 | 2,301,144 |  |  | $ | 2.38 |  |  | 3.82 |  | $ | 67,969 |  |
| Exercised | (171,263 | ) |  | $ | 6.46 |  |  |  |  |  |
| Forfeitures and cancellations | (4,574 | ) |  | $ | 13.82 |  |  |  |  |  |
| Balance, June 30, 2016 | 2,125,307 |  |  | $ | 2.03 |  |  | 2.65 |  | $ | 77,850 |  |
| Exercised | (502,350 | ) |  | $ | 2.86 |  |  |  |  |  |
| Forfeitures and cancellations | (1,356 | ) |  | $ | 11.72 |  |  |  |  |  |
| Balance, June 30, 2017 | 1,621,601 |  |  | $ | 1.76 |  |  | 1.55 |  | $ | 81,413 |  |
| Vested and expected to vest as of June 30, 2017 | 1,621,601 |  |  | $ | 1.76 |  |  | 1.55 |  | $ | 81,413 |  |
| Vested and exercisable as of June 30, 2017 | 1,621,601 |  |  | $ | 1.76 |  |  | 1.55 |  | $ | 81,413 |  |

[0001628280-17-008894:notes:69]
Additional information regarding options outstanding as of June 30, 2017 is as follows:

[0001628280-17-008894:notes:70]
|  |  | Options Outstanding & Exercisable |  |  |
| Range of Exercise Prices |  | Number ofOptions |  | WeightedAverageRemainingContractualLife (Years) |  | WeightedAverageExercisePrice |
| $0.01 - $10.76 |  | 1,397,128 |  |  | 0.93 |  | $ | 0.26 |  |
| $10.77 - $14.99 |  | 214,228 |  |  | 5.38 |  | $ | 10.90 |  |
| $15.00 - $16.75 |  | 4,645 |  |  | 4.84 |  | $ | 15.02 |  |
| $16.76 - $18.70 |  | 4,350 |  |  | 5.38 |  | $ | 17.46 |  |
| $18.71 - $19.99 |  | 1,250 |  |  | 4.38 |  | $ | 19.22 |  |
|  |  | 1,621,601 |  |  |  |  |  |  |

[0001628280-17-008894:notes:71]
During fiscal 2017, 2016 and 2015, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $24.8 million, $4.9 million, and $9.2 million, respectively, as determined as of the date of option exercise.

[0001628280-17-008894:notes:72]
As of June 30, 2017, the Company had no unrecognized compensation cost related to stock options.

[0001628280-17-008894:notes:73]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. The Company did not grant any stock options during fiscal 2017, fiscal 2016, or fiscal 2015.

[0001628280-17-008894:notes:74]
Forfeiture rate. The Company estimates its forfeiture rate based on an analysis of its actual forfeitures and will continue to evaluate the adequacy of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover behavior and other factors. The impact from a forfeiture rate adjustment will be recognized in full in the period of adjustment, and if the actual number of future forfeitures differs from that estimated, the Company may be required to record adjustments to stock-based compensation expense in future periods.

[0001628280-17-008894:notes:75]
Cash received from stock option exercises during fiscal 2017, 2016 and 2015 was $1.4 million, $1.1 million and $1.7 million, respectively.

[0001628280-17-008894:notes:76]
Restricted Stock Units (“RSUs”)

[0001628280-17-008894:notes:77]
The following table summarizes the activity of the RSUs made by the Company:

[0001628280-17-008894:notes:78]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2014 | 549,702 |  |  | $ | 22.65 |  |
| RSUs granted | 182,865 |  |  | $ | 32.47 |  |
| RSUs vested | (182,507 | ) |  | $ | 21.27 |  |
| RSUs canceled | (149,425 | ) |  | $ | 24.84 |  |
| Non-vested RSUs, June 30, 2015 | 400,635 |  |  | $ | 26.95 |  |
| RSUs granted | 132,746 |  |  | $ | 31.38 |  |
| RSUs vested | (141,159 | ) |  | $ | 23.54 |  |
| RSUs canceled | (120,251 | ) |  | $ | 31.84 |  |
| Non-vested RSUs, June 30, 2016 | 271,971 |  |  | $ | 28.72 |  |
| RSUs granted | 72,023 |  |  | $ | 55.33 |  |
| RSUs vested | (120,649 | ) |  | $ | 25.29 |  |
| RSUs canceled | (42,972 | ) |  | $ | 33.45 |  |
| Non-vested RSUs, June 30, 2017 | 180,373 |  |  | $ | 40.51 |  |

[0001628280-17-008894:notes:79]
The intrinsic value of RSUs vested in fiscal 2017, 2016 and 2015 was $6.2 million, $4.6 million and $6.4 million, respectively.  The total intrinsic value of all outstanding RSUs was $9.4 million as of June 30, 2017.

[0001628280-17-008894:notes:80]
As of June 30, 2017, there was unrecognized compensation costs related to RSUs of $5.3 million which the Company expects to recognize over a weighted average period of 3.1 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-17-008894:notes:81]
Earnings Per Share

[0001628280-17-008894:notes:82]
The Company applies the treasury stock method for calculating and presenting earnings per share (“EPS”).  Basic EPS is computed by dividing the net income available to common stockholders by the weighted-average number of common shares outstanding during the period. Diluted EPS available to common stockholders is computed by dividing the amount of net income available to common stockholders by the weighted-average number of common shares outstanding, including potential dilutive common shares assuming the dilutive effect of outstanding stock options and restricted stock units using the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001628280-17-008894:notes:83]
EARNINGS PER SHARE

[0001628280-17-008894:notes:84]
The following table sets forth the computation of basic and diluted earnings per share for the periods indicated (in thousands, except per share data):

[0001628280-17-008894:notes:85]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |
| Net income and comprehensive income | $ | 257,506 |  |  | $ | 213,616 |  |  | $ | 129,663 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 81,478 |  |  | 84,402 |  |  | 88,008 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |
| Stock options | 1,670 |  |  | 1,275 |  |  | 1,392 |  |
| Restricted stock units | 104 |  |  | 107 |  |  | 169 |  |
| Weighted-average shares used in computing diluted net income per share | 83,252 |  |  | 85,784 |  |  | 89,569 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 3.16 |  |  | $ | 2.53 |  |  | $ | 1.47 |  |
| Diluted | $ | 3.09 |  |  | $ | 2.49 |  |  | $ | 1.45 |  |

[0001628280-17-008894:notes:86]
The Company excludes potentially dilutive securities from its diluted net income per share calculation when their effect would be antidilutive to net income per share amounts.  The following table summarizes the total potential shares of common stock that were excluded from the diluted per share calculation, because to include them would have been anti-dilutive for the period (in thousands):

[0001628280-17-008894:notes:87]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Restricted stock units | 18 |  |  | 8 |  |  | 2 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001628280-17-008894:notes:88]
As of June 30, 2017 and 2016, the fair value hierarchy for the Company’s financial liabilities was as follows (in thousands):

[0001628280-17-008894:notes:89]
|  | June 30, 2017 |  | June 30, 2016 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt(1) | $ | 257,250 |  |  | $ | — |  |  | $ | 257,250 |  |  | $ | — |  |  | $ | 203,500 |  |  | $ | — |  |  | $ | 203,500 |  |  | $ | — |  |

[0001628280-17-008894:notes:90]
(1) Debt is carried at historical cost on the Company's consolidated balance sheet.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-17-008894:notes:91]
FAIR VALUE OF FINANCIAL INSTRUMENTS

[0001628280-17-008894:notes:92]
For certain of the Company’s financial instruments, including cash, accounts receivable, accounts payable, and other current liabilities, the carrying amounts approximate fair value due to their short maturities, and are therefore excluded from the fair value tables below. Additionally, as of June 30, 2017, we held $546.8 million of our $604.2 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States, and we would incur significant tax liabilities if we were to repatriate those amounts.

[0001628280-17-008894:notes:93]
As of June 30, 2017 and 2016, the Company had outstanding debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was classified as Level 2 measurement.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001628280-17-008894:notes:94]
Foreign Currency Remeasurement

[0001628280-17-008894:notes:95]
The functional currency of the Company and its subsidiaries is the U.S. dollar. For foreign operations, local currency denominated monetary assets and liabilities are remeasured at the period end exchange rates, and revenues, costs and expenses are remeasured at the average exchange rates during the fiscal year. Foreign exchange gains and losses have been immaterial to the Company’s results of operations to date.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001628280-17-008894:notes:96]
Long Lived Assets

[0001628280-17-008894:notes:97]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-17-008894:notes:98]
INCOME TAXES

[0001628280-17-008894:notes:99]
For financial reporting purposes, the components of income before provision for income taxes were as follows (in thousands):

[0001628280-17-008894:notes:100]
|  |  | Years Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Domestic |  | $ | 81,957 |  |  | $ | 60,073 |  |  | $ | 44,743 |  |
| Foreign |  | 203,067 |  |  | 179,867 |  |  | 101,005 |  |
|  |  | $ | 285,024 |  |  | $ | 239,940 |  |  | $ | 145,748 |  |

[0001628280-17-008894:notes:101]
The components of the Company’s provision for income taxes consisted of the following (in thousands):

[0001628280-17-008894:notes:102]
|  |  | Years Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Current |  |  |  |  |  |  |
| Federal |  | $ | 25,533 |  |  | $ | 25,635 |  |  | $ | 15,786 |  |
| State |  | 360 |  |  | (149 | ) |  | 299 |  |
| Foreign |  | 2,563 |  |  | 1,983 |  |  | 909 |  |
| Current tax expense |  | 28,456 |  |  | 27,469 |  |  | 16,994 |  |
| Deferred |  |  |  |  |  |  |
| Federal |  | (858 | ) |  | (1,116 | ) |  | (856 | ) |
| State |  | (80 | ) |  | (29 | ) |  | (53 | ) |
| Foreign |  | — |  |  | — |  |  | — |  |
| Deferred tax expense |  | (938 | ) |  | (1,145 | ) |  | (909 | ) |
| Provision for income taxes |  | $ | 27,518 |  |  | $ | 26,324 |  |  | $ | 16,085 |  |

[0001628280-17-008894:notes:103]
The effective tax rate differs from the applicable U.S. statutory federal income tax rate as follows:

[0001628280-17-008894:notes:104]
|  |  | Years Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Tax rate differential, foreign income |  | (23.3 | ) |  | (24.4 | ) |  | (23.2 | ) |
| State tax expense |  | 0.3 |  |  | (0.1 | ) |  | 0.1 |  |
| Stock-based compensation |  | (2.5 | ) |  | 0.3 |  |  | 0.6 |  |
| Federal research and development credits |  | (0.4 | ) |  | (0.6 | ) |  | (1.1 | ) |
| Other permanent items |  | 0.6 |  |  | 0.8 |  |  | (0.4 | ) |
| Effective tax rate |  | 9.7 | % |  | 11.0 | % |  | 11.0 | % |

[0001628280-17-008894:notes:105]
The Company’s effective tax rate decreased 1.3% to 9.7% in fiscal 2017 from 11.0% in fiscal 2016. This decrease is primarily due to the adoption of Accounting Standards Update (“ASU”) 2016-09 that requires companies to record all excess tax benefits and tax deficiencies from stock based compensation as an income tax benefit or expense in the income statement. The Company’s adoption of the new standard resulted in a benefit for excess tax deductions from stock based compensation. Overall, the rate benefit is due to income in foreign jurisdictions that have lower tax rates than the U.S.

[0001628280-17-008894:notes:106]
It is the Company's intention to permanently reinvest the earnings of its foreign subsidiaries.  As of June 30, 2017, the Company has not made a provision for U.S. or additional foreign withholding taxes on approximately $811.5 million of the excess of the amount for the financial reporting over the tax basis of its investments in foreign subsidiaries that is indefinitely reinvested outside of U.S. This amount would become subject to U.S. tax upon repatriation. It is not practicable to estimate the amount of deferred tax liability related to investments in these foreign subsidiaries.

[0001628280-17-008894:notes:107]
Significant components of the Company’s deferred tax assets and liabilities consisted of the following (in thousands):

[0001628280-17-008894:notes:108]
|  |  | June 30, |
|  |  | 2017 |  | 2016 |
| Deferred tax assets |  |  |  |  |
| Reserves and Allowances |  | $ | 2,215 |  |  | $ | 1,539 |  |
| Stock-based compensation |  | 712 |  |  | 998 |  |
| Accrued expenses |  | 371 |  |  | 363 |  |
| Research and development credits |  | — |  |  | 146 |  |
| State tax |  | 1,110 |  |  | 925 |  |
| Other |  | 782 |  |  | 482 |  |
| Total deferred tax assets |  | 5,190 |  |  | 4,453 |  |
| Deferred tax liabilities |  |  |  |  |
| Basis difference for fixed assets |  | (57 | ) |  | (112 | ) |
| Total deferred tax liabilities |  | (57 | ) |  | (112 | ) |
| Valuation allowance |  | — |  |  | (146 | ) |
| Net deferred tax assets |  | $ | 5,133 |  |  | $ | 4,195 |  |

[0001628280-17-008894:notes:109]
Prior to fiscal year 2017, the Company had maintained a valuation allowance against California research credit carryover deferred tax asset as the Company had concluded that it was not more likely than not to be realizable in the future. However, in the fiscal year 2017, due to increased profitability, the Company will utilize the remaining research credit carryover. This resulted in the release of the prior valuation allowance and a tax benefit of approximately $0.3 million.

[0001628280-17-008894:notes:110]
A reconciliation of the beginning and ending balances of the unrecognized tax benefits during the years ended June 30, 2017,  2016 and 2015 consists of the following (in thousands):

[0001628280-17-008894:notes:111]
|  |  | Years Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
|  |  | (In thousands) |
| Unrecognized benefit—beginning of year |  | $ | 22,851 |  |  | $ | 19,590 |  |  | $ | 14,914 |  |
| Gross increases—current year tax positions |  | 5,184 |  |  | 3,879 |  |  | 4,960 |  |
| Gross decreases - prior year tax positions due to statute lapse |  | (597 | ) |  | (618 | ) |  | (284 | ) |
| Unrecognized benefit—end of year |  | $ | 27,438 |  |  | $ | 22,851 |  |  | $ | 19,590 |  |

[0001628280-17-008894:notes:112]
The gross unrecognized tax benefits balance as of June 30, 2017 is $27.4 million which would affect income tax expense if recognized.  The Company recognizes interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying Consolidated Statement of Operations and Comprehensive Income.  Accrued interest and penalties are included within the related tax liability line in the Consolidated Balance Sheet. As of June 30, 2017, the Company had $2.4 million accrued interest related to uncertain tax matters. The Company believes that it is reasonably possible that a decrease of up to $3.4 million in unrecognized tax benefits may occur due to settlements with tax authorities or statute lapse. The Company files income tax returns in the United States, various states and certain foreign jurisdictions.  Tax years 2011 through 2017 are subject to examination by the U.S. federal tax authorities and by certain foreign tax authorities. Tax years 2012 through 2017 are subject to examination by the state tax authorities.

[0001628280-17-008894:notes:113]
On July 27, 2015, in Altera Corp. vs. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. On June 27, 2016, the Internal Revenue Service appealed the court's decision to the Ninth Circuit Court of Appeals. On November 10, 2016, the Internal Revenue Service filed its reply brief.

[0001628280-17-008894:notes:114]
We have reviewed this case and its potential impact on Ubiquiti and concluded that no adjustment to the consolidated financial statements is appropriate at this time. We will continue to monitor ongoing developments and potential impacts to our consolidated financial statements.

[0001628280-17-008894:notes:115]
As discussed in Note 2, in fiscal year 2017 the Company early-adopted ASU 2016-09, “Improvements to Employee Share-Based Payment Accounting” which the FASB issued in March 2016. The ASU simplifies several aspects of the accounting for employee share-based payment transactions for both public and non-public entities. The amendments related to income taxes include a requirement to recognize all excess tax benefits and tax deficiencies as income tax benefit or expense in the income statement and classification of excess tax benefits in the statement of cash flows as an operating activity. The ASU further eliminates the requirement to defer the recognition of an excess tax benefit until such tax benefit is realized through a reduction to taxes payable.


## us-gaap:IncomeTaxPolicyTextBlock

[0001628280-17-008894:notes:116]
Income Taxes

[0001628280-17-008894:notes:117]
The Company accounts for income taxes in accordance with accounting guidance which requires recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in its financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company establishes valuation allowances when necessary to reduce deferred tax assets to the amount it expects to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives. In addition, the Company’s calculation of its tax liabilities involves dealing with uncertainties in the application of complex tax regulations. The Company may be subject to income tax audits in all of the jurisdictions in which it operates and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, the Company must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that the Company establishes a reserve, its provision for income taxes would be increased. If the Company ultimately determines that payment of these amounts is unnecessary, it reverses the liability and recognizes a tax benefit during the period in which it determines that the liability is no longer necessary. The Company records an additional charge in its provision for taxes in the period in which it determines that tax liability is greater than its original estimate.  The Company recognizes interest and penalties related to unrecognized tax benefits on the income tax expense line in the accompanying consolidated statement of operations. Accrued interest and penalties are included on the related tax liability line in the consolidated balance sheet.


## us-gaap:InventoryPolicyTextBlock

[0001628280-17-008894:notes:118]
Inventory and Inventory Valuation

[0001628280-17-008894:notes:119]
The Company's inventories are primarily finished goods and, to a lesser extent, raw materials, which have been either consigned to the Company's contract manufacturers or are held by the Company.  Inventories are stated at the lower of actual cost (computed on a first-in, first-out basis), or Net Realizable Value (NRV). NRV is based upon an estimated average selling price reduced by the estimated costs of disposal. The determination of net realizable value involves numerous judgments including estimating average selling prices based up recent sales, industry trends, existing customer orders, and seasonal factors. Should actual market conditions differ from the Company's estimates, future results of operations could be materially affected. The Company reduces the value of its inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value. Write-downs are not reversed until the related inventory has been subsequently sold or scrapped.

[0001628280-17-008894:notes:120]
The valuation of inventory also requires the Company to estimate excess and obsolete inventory. The determination of excess or obsolete inventory is estimated based on a comparison of the quantity and cost of inventory on hand to the Company's forecast of customer demand. Customer demand is dependent on many factors and requires the Company to use significant judgment in our forecasting process. The Company also makes assumptions regarding the rate at which new products will be accepted in the marketplace and at which customers will transition from older products to newer products. If actual market conditions are less favorable than those projected by management, additional inventory write-downs may be required, which would have a negative impact on the Company's gross margin. If the Company ultimately sells inventory that has been previously written down, the Company's gross margins in future periods would be positively impacted.

[0001628280-17-008894:notes:121]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs. Capitalized

[0001628280-17-008894:notes:122]
costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not

[0001628280-17-008894:notes:123]
sold during the period.


## us-gaap:LeasePolicyTextBlock

[0001628280-17-008894:notes:124]
Leases

[0001628280-17-008894:notes:125]
The Company leases its facilities under cancelable and noncancelable operating leases. For leases that contain rent escalation or rent concessions provisions, the Company records the total rent expense during the lease term on a straight line basis over the term of the lease. The Company records the difference between the rent paid and the straight line rent as a deferred rent liability on the consolidated balance sheets.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-17-008894:notes:126]
Recent Accounting Pronouncements

[0001628280-17-008894:notes:127]
Effective July 1, 2016, the Company adopted Accounting Standards Update (“ASU”) 2015-03, regarding simplifying the presentation of debt issuance costs. The guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. Previously the Company reported these costs as assets on its balance sheet. The guidance is applied on a retrospective basis whereby prior-period financial statements must be adjusted to reflect the adoption of the new guidance. The guidance only resulted in a reclassification on the Company's consolidated balance sheet. The Company has reclassified $0.3 million from "prepaid expenses and other current assets" to "Debt - short-term", and $0.7 million from "Other long-term assets"

[0001628280-17-008894:notes:128]
to "Debt - long-term" on the June 30, 2016 consolidated balance sheet.

[0001628280-17-008894:notes:129]
Effective July 1, 2016, the Company adopted ASU 2015-11, "Inventory (Topic 330)-Simplifying the Measurement of Inventory, ("ASU 2015-11"). The guidance requires an entity to measure inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. The Company adopted this update prospectively, and it did not have a material impact on the Company's consolidated financial statements.

[0001628280-17-008894:notes:130]
Effective July 1, 2016, the Company early adopted ASU 2016-09,"Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting," ("ASU 2016-09"), regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits in the consolidated statement of cash flows on a prospective basis; accordingly, prior period amounts have not been adjusted. During fiscal 2017, the Company recognized the excess tax benefits of $7.9 million, within the provision for income taxes rather than additional paid-in capital. The Company classified the excess tax benefits within cash flows from operating activities for year ended June 30, 2017, rather than within cash flows from financing activities. In regard to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's consolidated financial statements.

[0001628280-17-008894:notes:131]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory," (“ASU 2016-16”). ASU 2016-16 eliminates the exception for all intra-entity sales of assets other than inventory. As a result, a reporting entity would recognize the tax expense from the sale of the asset in the seller’s tax jurisdiction when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. Any deferred tax asset that arises in the buyer’s jurisdiction would also be recognized at the time of the transfer. ASU 2016-16 is effective for fiscal years beginning after December 15, 2017, and early adoption is permitted but can only be adopted in the first interim period of a fiscal year. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001628280-17-008894:notes:132]
In June 2016, the FASB issued ASU 2016-13, “Financial Instruments – Credit Losses (TOPIC 326): Measurement of Credit  Losses On Financial Instruments” ("ASU 2016-13"). ASU 2016-13 implements a comprehensive change in estimating the allowances for loan losses from the current model of losses inherent in the loan portfolio to a current expected credit loss model that generally is expected to result in earlier recognition of allowances for losses. Additionally, purchase accounting rules have been modified as well as credit losses on held-to-maturity debt securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019, and early adoption is permitted for annual and interim periods beginning after December 15, 2018. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001628280-17-008894:notes:133]
In February 2016, the FASB issued ASU 2016-02, “Leases (Topic 842),” (“ASU 2016-02”). ASU 2016-02 requires lessees to recognize assets and liabilities on the balance sheet for leases with lease terms greater than twelve months and disclose key information about leasing arrangements. ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those fiscal years, with early application permitted. The Company is evaluating the impact that adoption of this new standard will have on its consolidated financial statements.

[0001628280-17-008894:notes:134]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers , with amendments in 2015 and 2016, which creates new ASC Topic 606 (Topic 606) that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019 and early application for the Company's first quarter of fiscal year 2018 is permitted. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures and has determined that it will not early adopt this standard in fiscal 2018, however it has not yet selected a transition method for its adoption of this standard in fiscal 2019.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001628280-17-008894:notes:135]
Other long-term assets consisted of the following (in thousands):

[0001628280-17-008894:notes:136]
|  | June 30, |
|  | 2017 |  | 2016 |
| Intangible assets, net (1) | $ | 437 |  |  | $ | 616 |  |
| Other long-term assets | 1,891 |  |  | 960 |  |
|  | $ | 2,328 |  |  | $ | 1,576 |  |

[0001628280-17-008894:notes:137]
(1) - Accumulated amortization was $1.2 million and $1.0 million as of June 30, 2017 and June 30, 2016, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001628280-17-008894:notes:138]
ACCRUED WARRANTY

[0001628280-17-008894:notes:139]
Warranty obligations, included in other current liabilities, were as follows (in thousands):

[0001628280-17-008894:notes:140]
| Balance at June 30, 2015 | $ | 2,750 |  |
| Accruals for warranties issued during the period | 2,597 |  |
| Settlements made during the period | (3,111 | ) |
| Balance at June 30, 2016 | 2,236 |  |
| Accruals for warranties issued during the period | 6,911 |  |
| Changes in liability for pre-existing warranties during the period | (92 | ) |
| Settlements made during the period | (5,454 | ) |
| Balance at June 30, 2017 | $ | 3,601 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001628280-17-008894:notes:141]
Property and Equipment

[0001628280-17-008894:notes:142]
Furniture, fixtures and equipment are recorded at cost. The Company also capitalizes certain costs of software developed for internal use, which is included as property and equipment on the Company's consolidated balance sheets.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs.

[0001628280-17-008894:notes:143]
The Company computes depreciation or amortization using the straight line method over estimated useful lives, as follows:

[0001628280-17-008894:notes:144]
|  |  | Estimated Useful Life |
| Testing equipment |  | 3 to 5 years |
| Computer and other equipment |  | 3 to 5 years |
| Furniture and fixtures |  | 3 to 5 years |
| Software |  | up to 3 years |
| Leasehold improvements |  | shorter of lease term or useful life |

[0001628280-17-008894:notes:145]
Upon retirement or disposition, the asset cost and related accumulated depreciation are removed with any gain or loss recognized in the statement of operations. Expenditures for maintenance and repairs are charged to operations as incurred.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-17-008894:notes:146]
Property and equipment, net consisted of the following (in thousands):

[0001628280-17-008894:notes:147]
|  | June 30, |
|  | 2017 |  | 2016 |
| Testing equipment | $ | 7,587 |  |  | $ | 6,051 |  |
| Computer and other equipment | 5,740 |  |  | 4,857 |  |
| Tooling equipment | 7,828 |  |  | 5,801 |  |
| Furniture and fixtures | 1,528 |  |  | 1,325 |  |
| Leasehold improvements | 6,424 |  |  | 5,136 |  |
| Software (1) (2) | 5,601 |  |  | 2,488 |  |
| Software in development (1) (2) | — |  |  | 2,739 |  |
| Property and Equipment, Gross | 34,708 |  |  | 28,397 |  |
| Less: Accumulated depreciation (3) | (21,792 | ) |  | (15,444 | ) |
|  | $ | 12,916 |  |  | $ | 12,953 |  |

[0001628280-17-008894:notes:148]
(1) - In the year ended June 30, 2016, the Company recorded a $2.5 million impairment charge in research and development

[0001628280-17-008894:notes:149]
expense for capitalized software development costs due to the cancellation of the commercial launch of certain software in development.  No impairment charges were recorded for the year ended June 30, 2017.

[0001628280-17-008894:notes:150]
(2) -  We capitalized $0.1 million for software development in fiscal 2017. We capitalized $1.3 million for software development in fiscal 2016.

[0001628280-17-008894:notes:151]
(3)- The Company recorded depreciation expense of $6.8 million, $5.7 million and $4.7 million in fiscal 2017, 2016 and 2015, respectively.


## us-gaap:ReceivablesPolicyTextBlock

[0001628280-17-008894:notes:152]
Allowance for Doubtful Accounts

[0001628280-17-008894:notes:153]
The Company records an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, (i) the aging of the accounts receivable, (ii) the Company’s historical write offs, (iii) the credit worthiness of each distributor based on payment history and (iv) general economic conditions. In cases where the Company is aware of circumstances that may impair a specific distributor’s ability to meet its obligations to the Company, the Company records a specific allowance against amounts due from the distributor, and thereby reduces the net recognized receivable to the amounts it reasonably believes will be collected.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001628280-17-008894:notes:154]
Revenues by product type were as follows (in thousands, except percentages):

[0001628280-17-008894:notes:155]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Service Provider Technology | $ | 455,598 |  |  | 53 | % |  | $ | 418,346 |  |  | 63 | % |  | $ | 418,021 |  |  | 70 | % |
| Enterprise Technology | 409,670 |  |  | 47 | % |  | 248,049 |  |  | 37 | % |  | 177,926 |  |  | 30 | % |
| Total revenues | $ | 865,268 |  |  | 100 | % |  | $ | 666,395 |  |  | 100 | % |  | $ | 595,947 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-17-008894:notes:156]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001628280-17-008894:notes:157]
Aircraft Lease Agreement

[0001628280-17-008894:notes:158]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s Chief Executive Officer, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $2.12 million, $1.3 million and $0.4 million in expenses pursuant to the Aircraft Lease Agreement during fiscal 2017, fiscal 2016 and fiscal 2015, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0001628280-17-008894:notes:159]
Research and Development Costs

[0001628280-17-008894:notes:160]
Research and development expenses are expensed as incurred and consist primarily of payroll and payroll-related costs and facilities costs.  Research and development expenses associated with software development are typically expensed as incurred as our software is usually released to end customers immediately after technological feasibility has been established.  However, the Company capitalizes development costs when material costs are incurred subsequent to technological feasibility but prior to commercial release.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001628280-17-008894:notes:161]
Revenues by geography based on customer's ship-to destinations were as follows (in thousands, except percentages):

[0001628280-17-008894:notes:162]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
| North America(1) | $ | 331,435 |  |  | 38 | % |  | $ | 239,526 |  |  | 36 | % |  | $ | 197,693 |  |  | 33 | % |
| South America | 105,511 |  |  | 12 | % |  | 85,036 |  |  | 13 | % |  | 97,118 |  |  | 16 | % |
| Europe, the Middle East and Africa | 334,473 |  |  | 39 | % |  | 264,404 |  |  | 39 | % |  | 234,383 |  |  | 40 | % |
| Asia Pacific | 93,849 |  |  | 11 | % |  | 77,429 |  |  | 12 | % |  | 66,753 |  |  | 11 | % |
| Total revenues | $ | 865,268 |  |  | 100 | % |  | $ | 666,395 |  |  | 100 | % |  | $ | 595,947 |  |  | 100 | % |

[0001628280-17-008894:notes:163]
| (1) | Revenue for the United States was $315.0 million, $225.6 million and $187.3 million for fiscal 2017, 2016 and 2015, respectively. |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001628280-17-008894:notes:164]
Recognition of Revenues

[0001628280-17-008894:notes:165]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied post contract customer support (“PCS”). The Company recognizes revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where the Company lacks evidence that collectability of the resulting receivable is reasonably assured, it defers recognition of revenue until the receipt of cash.

[0001628280-17-008894:notes:166]
For the Company’s sales, evidence of the arrangement consists of an order from a customer. The Company considers delivery to have occurred once its products have been shipped and title and risk of loss have been transferred. For the Company’s sales, these criteria are met at the time the products are transferred to the customer. The Company’s arrangements with customers do not, in most cases, include provisions for cancellation, returns, inventory swaps or refunds that would materially impact recognized revenues.

[0001628280-17-008894:notes:167]
The Company records amounts billed to distributors for shipping and handling costs as revenues. The Company classifies shipping and handling costs incurred by it as cost of revenues.

[0001628280-17-008894:notes:168]
Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on the Company’s balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001628280-17-008894:notes:169]
A portion of the Company's revenues related to PCS are deferred.  This relates to the Company’s multi-element arrangements, which generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is this right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001628280-17-008894:notes:170]
The Company uses a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001628280-17-008894:notes:171]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally, the Company does not sell the deliverables separately and, as such, does not have VSOE. |

[0001628280-17-008894:notes:172]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. The Company does not believe that there is accessible TPE evidence for similar deliverables. |

[0001628280-17-008894:notes:173]
| (iii) | BESP reflects the Company’s best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. The Company believes that BESP is the most appropriate methodology for determining the allocation of revenue among the multiple elements. |

[0001628280-17-008894:notes:174]
The Company allocates revenues between these two deliverables using the relative selling price method which is based on the estimated selling price for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated period for which services will be delivered to support each of these devices which, currently, is two years.  If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.  All cost of revenues for the delivered hardware and the related essential software, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. Costs for PCS are recognized as they are incurred.

[0001628280-17-008894:notes:175]
The Company’s process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, the Company believes its network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate the Company to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. The Company believes that the relatively low prices of its products and its network operators’ and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, the Company has concluded that if it were to sell PCS on a standalone basis, the selling price would be relatively low.

[0001628280-17-008894:notes:176]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001628280-17-008894:notes:177]
Accrued liabilities consisted of the following (in thousands):

[0001628280-17-008894:notes:178]
|  | June 30, |
|  | 2017 |  | 2016 |
| Accrued compensation and benefits | $ | 2,467 |  |  | $ | 1,589 |  |
| Accrued expense | 9,826 |  |  | 5,749 |  |
| Warranty accrual | 3,601 |  |  | 2,236 |  |
| Deferred revenue - short term | 5,254 |  |  | 2,917 |  |
| Customer deposits | 1,905 |  |  | 856 |  |
| Reserve for sales returns | 3,600 |  |  | 2,820 |  |
| Other payables | 6,377 |  |  | 10,505 |  |
|  | $ | 33,030 |  |  | $ | 26,672 |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001628280-17-008894:notes:179]
The allowance for doubtful accounts activity was as follows (in thousands):

[0001628280-17-008894:notes:180]
|  |  | Years Ended June 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Beginning balance |  | $ | 48 |  |  | $ | 1,071 |  |  | $ | 1,395 |  |
| Charged to (released from) expenses |  | 392 |  |  | (1 | ) |  | 106 |  |
| Bad debt write-offs |  | — |  |  | (1,022 | ) |  | (430 | ) |
| Ending balance |  | $ | 440 |  |  | $ | 48 |  |  | $ | 1,071 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-17-008894:notes:181]
Inventories consisted of the following (in thousands):

[0001628280-17-008894:notes:182]
|  | June 30, |
|  | 2017 |  | 2016 |
| Finished goods | $ | 141,247 |  |  | $ | 55,694 |  |
| Raw materials | 10,361 |  |  | 8,500 |  |
| Provision for inventory obsolescence | (9,560 | ) |  | (7,081 | ) |
|  | $ | 142,048 |  |  | $ | 57,113 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-17-008894:notes:183]
SEGMENT INFORMATION, REVENUES BY GEOGRAPHY AND SIGNIFICANT CUSTOMERS

[0001628280-17-008894:notes:184]
Management has determined that the Company operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis.  Furthermore, the Company does not organize or report its costs on a segment basis.

[0001628280-17-008894:notes:185]
Revenue


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001628280-17-008894:notes:186]
Segments

[0001628280-17-008894:notes:187]
Management has determined that it operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-17-008894:notes:188]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001628280-17-008894:notes:189]
Use of Accounting Estimates

[0001628280-17-008894:notes:190]
The preparation of financial statements in conformity with GAAP requires management to make estimates and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. On an ongoing basis, the Company evaluates these estimates, including those related to allowance for doubtful accounts, inventory valuation, vendor deposits, warranty costs, stock-based compensation and income taxes, among others. The Company bases estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ materially from these estimates.

[0001628280-17-008894:notes:191]
Management has determined that it operates as one reportable and operating segment as the Company's Chief Executive Officer, who is the Company's chief operating decision maker, does not make decisions about resources to be allocated or assess performance on a segment basis. See Note 12.

[0001628280-17-008894:notes:192]
Key factors considered by the Company in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.  As of June 30, 2017 and 2016, the Company had deferred revenues of $7.9 million and $4.2 million, respectively, related to these obligations.

[0001628280-17-008894:notes:193]
Concentration of Risk

[0001628280-17-008894:notes:194]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents and accounts receivable. The Company limits its exposure by primarily placing its cash in interest-bearing deposit accounts with high credit quality financial institutions.

[0001628280-17-008894:notes:195]
The Company derives its accounts receivable from revenues earned from customers located worldwide. The Company bases credit decisions primarily upon a customer’s past credit history. The Company’s standard credit terms are net 30 to 120 days.

[0001628280-17-008894:notes:196]
The Company subcontracts with other companies to manufacture most of its products. The Company relies on the ability of these contract manufacturers to produce the products sold to its distributors.  A significant portion of the Company’s products are manufactured by a few contract manufacturers.

[0001628280-17-008894:notes:197]
sold during the period. Manufacturing overhead costs are capitalized to inventory and are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.

[0001628280-17-008894:notes:198]
Product Warranties

[0001628280-17-008894:notes:199]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations and comprehensive income within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical experience factors including product failure rates, material usage, and service delivery cost incurred in correcting product failures. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001628280-17-008894:notes:200]
Fair Value of Financial Instruments

[0001628280-17-008894:notes:201]
Pursuant to the accounting guidance for fair value measurements and its subsequent updates, fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. The accounting guidance establishes a three-tier fair value hierarchy that requires the Company to use observable market data, when available, and to minimize the use of unobservable inputs when determining fair value. The fair value hierarchy prioritizes the inputs into three levels that may be used in measuring fair value as follows:

[0001628280-17-008894:notes:202]
Level 1—observable inputs which include quoted prices in active markets for identical assets of liabilities.

[0001628280-17-008894:notes:203]
Level 2—inputs which include observable inputs other than Level 1, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability.

[0001628280-17-008894:notes:204]
Level 3—inputs which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001628280-17-008894:notes:205]
The Company evaluates its long lived assets including property and equipment for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. An impairment loss is recognized when the net book value of such assets exceeds the estimated future undiscounted cash flows attributable to the assets or asset group. If impairment is indicated, the asset is written down to its estimated fair value. In fiscal 2016, the Company recorded a $2.5 million impairment charge for capitalized software development costs due to the cancellation of the commercial launch of certain software in development. The Company did not recognize any significant impairment loss for fiscal 2017 or 2015.

[0001628280-17-008894:notes:206]
Intangible Assets

[0001628280-17-008894:notes:207]
The Company’s intangible assets consist primarily of legal costs associated with application for and registration of the Company’s trademarks. The Company amortizes all definite-lived intangible assets that are subject to amortization over the estimated useful life based on economic benefit, which is generally 5 years.  All patent filing and defense costs are expensed as incurred, however to date these costs have not been significant.

[0001628280-17-008894:notes:208]
Advertising Costs

[0001628280-17-008894:notes:209]
The Company expenses all advertising costs as incurred.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-17-008894:notes:210]
COMMON STOCK AND TREASURY STOCK

[0001628280-17-008894:notes:211]
As of June 30, 2017 and 2016, the authorized capital of the Company included 500,000,000 shares of common stock. As of June 30, 2017 and 2016, 80,275,965 and 81,667,129 shares of common stock were outstanding, respectively.

[0001628280-17-008894:notes:212]
Treasury Stock Retirement

[0001628280-17-008894:notes:213]
In February 2015, we retired 44,768,739 shares of the Company's treasury stock. These retired shares are now included in the Company’s pool of authorized but unissued shares. The retired stock had a carrying value of $138.9 million. The Company’s policy upon the formal retirement of treasury stock is to reflect the excess over par value as a deduction from Additional Paid-in Capital until the balance is reduced to zero, then the Company records any additional excess directly to retained earnings.

[0001628280-17-008894:notes:214]
Common Stock Repurchases

[0001628280-17-008894:notes:215]
On May 4, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program.  Under the stock repurchase program, the Company was authorized to repurchase up to $50 million of its common stock. During the fourth quarter of fiscal 2016, the Company repurchased and retired 1,309,606 shares of its common stock at an average price per share of $38.18 for an aggregate amount of $50 million.  This included unpaid stock repurchases of $6.5 million relating to repurchases executed on or prior to June 30, 2016 for trades that settled after June 30, 2016.

[0001628280-17-008894:notes:216]
On August 3, 2016, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $50 million of its common stock. During the third quarter of fiscal 2017, the Company repurchased and retired 1,014,956 shares of its common stock at an average price per share of $49.26 for an aggregate amount of $50 million.

[0001628280-17-008894:notes:217]
On March 3, 2017, the Board of Directors of the Company approved a $50 million stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $50 million of its common stock. The program expires on March 31, 2018. During the third quarter of fiscal 2017, the Company repurchased and retired 917,455 shares of its common stock at an average price per share of $50.43 for an aggregate amount of $46.3 million. This included unpaid stock repurchases of $3.0 million relating to repurchases executed on or prior to March 31, 2017 for trades that settled in the fourth quarter of fiscal 2017.  During the fourth quarter of fiscal 2017, the Company repurchased and retired 50,000 shares of its common stock at an average price per share of $49.55 for an aggregate amount of $2.5 million. As of June 30, 2017, the Company had $1.3 million available under the stock repurchase program.

[0001628280-17-008894:notes:218]
Dividend Distribution

[0001628280-17-008894:notes:219]
On September 30, 2014, the Company announced that its Board of Directors had approved an annual dividend. The Company declared the dividend of $0.17 per share on September 30, 2014. The aggregate amount of $15.0 million was paid on October 28, 2014 to stockholders of record on October 17, 2014. The Company currently has no plans to pay a cash dividend at this time or at any time in the foreseeable future.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-17-008894:notes:220]
BALANCE SHEET COMPONENTS

[0001628280-17-008894:notes:221]
Inventories

[0001628280-17-008894:notes:222]
Property and Equipment, Net

[0001628280-17-008894:notes:223]
Other Long-term Assets

[0001628280-17-008894:notes:224]
Other Current Liabilities


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001628280-17-008894:notes:225]
BUSINESS EMAIL COMPROMISE FRAUD LOSS

[0001628280-17-008894:notes:226]
In June 2015, the Company determined that it was the victim of criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties. As of June 30, 2015, the Company recovered $8.1 million.  As a result, the Company recorded a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  In fiscal 2016, the Company recorded a net recovery of $8.3 million, comprised of the $8.6 million recovery less $0.3 million of professional service fees associated with the recovery.

[0001628280-17-008894:notes:227]
The Company is continuing to pursue the recovery of the remaining $30.0 million and is cooperating with U.S. federal and numerous overseas law enforcement authorities who are actively pursuing a multi-agency criminal investigation.  Any additional recoveries are likely remote and therefore cannot be assured.
