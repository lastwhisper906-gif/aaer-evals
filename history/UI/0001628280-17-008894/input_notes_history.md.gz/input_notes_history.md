# UI note change history — 0001511737-17-000003 → 0001628280-17-004928


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001628280-17-004928:note_history:1]
At March 31, 2017, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):
  (was, 2017-02-09, similarity 0.9705):
[0001511737-17-000003:note_history:1]
At December 31, 2016, future minimum annual payments under operating leases for the remainder of fiscal 2017 and future fiscal years are as follows (in thousands):

- changed (2017-05-04):
[0001628280-17-004928:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of March 31, 2017.  The Company had inventory purchase obligations of $40.7 million as of March 31, 2017.
  (was, 2017-02-09, similarity 0.9793):
[0001511737-17-000003:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability under its orders, and no significant accruals have been recorded as of December 31, 2016.  The Company had inventory purchase obligations of $34.7 million as of December 31, 2016.

- changed (2017-05-04):
[0001628280-17-004928:note_history:3]
The Company had other obligations of $9.8 million as of March 31, 2017, which consisted primarily of commitments related to research and development projects.
  (was, 2017-02-09, similarity 0.9703):
[0001511737-17-000003:note_history:3]
The Company had other obligations of $9.9 million as of December 31, 2016, which consisted primarily of commitments related to research and development projects.

- added (2017-05-04):
[0001628280-17-004928:note_history:4]
Synopsys

- added (2017-05-04):
[0001628280-17-004928:note_history:5]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and certain employees in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act (“DMCA”). On March 28, 2017, Synopsys filed an amended complaint alleging claims under the trafficking provisions of the DMCA and claims for fraud, civil RICO and negligent misrepresentation. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001628280-17-004928:note_history:6]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2017-02-09, similarity 0.9435):
[0001511737-17-000003:note_history:6]
These consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2016, included in its Annual Report on Form 10-K, as filed with the SEC on August 22, 2016 (the “Annual Report”). The results of operations for the three and six months ended December 31, 2016 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001628280-17-004928:note_history:7]
Effective July 1, 2016, the Company early adopted ASU 2016-09,"Compensation-Stock Compensation (Topic 718), Improvements to Employee Share-Based Payment Accounting," regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits in the consolidated statement of cash flows on a prospective basis; accordingly, prior period amounts have not been adjusted. During the three and nine months ended March 31, 2017, the Company recognized the excess tax benefits of $0.2 million and $7.9 million, respectively, within the provision for income taxes rather than additional paid-in capital. The Company classified the excess tax benefits within cash flows from operating activities for the nine months ended March 31, 2017 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's consolidated financial statements.
  (was, 2017-02-09, similarity 0.6646):
[0001511737-17-000003:note_history:7]
Effective July 1, 2016, the Company early adopted ASU 2016-09 regarding the Improvements to Employee Share-Based Payment Accounting. The Company applied the guidance relating to accounting for excess tax benefits and the presentation of excess tax benefits in the consolidated statement of cash flows on a prospective basis; accordingly, prior period amounts have not been adjusted. During the three and six months ended December 31, 2016, the Company recognized the excess tax benefits of $0.9 million and $7.7 million, respectively, within the provision for income taxes rather than additional paid-in capital. The Company classified the excess tax benefits within cash flows from operating activities for the six months ended December 31, 2016 rather than within cash flows from financing activities. In regards to the forfeiture policy election, we will continue to estimate the number of awards expected to be forfeited, rather than electing to account for forfeitures as they occur. No other terms of the adopted guidance resulted in an impact on the Company's Consolidated Financial Statements.

- added (2017-05-04):
[0001628280-17-004928:note_history:8]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 (Topic 606) that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019 and early application for the Company's first quarter of fiscal year 2018 is permitted. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures and has not yet selected a transition method or determined if it will adopt this standard in fiscal 2018 or 2019.

- removed (2017-05-04):
[0001511737-17-000003:note_history:9]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, with amendments in 2015 and 2016, which creates new ASC Topic 606 (Topic 606) that will replace most existing revenue recognition guidance in GAAP when it becomes effective. Topic 606 requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for the Company’s first quarter of fiscal year 2019 and early application for in the first quarter of fiscal year 2018 is permitted. Topic 606 may be applied retrospectively to each prior period presented or with the cumulative effect recognized as of the date of initial application. The Company is still evaluating the impact of adopting Topic 606 on its consolidated financial statements and related financial statement disclosures and has not yet selected a transition method or determined if it will adopt this standard in fiscal 2018 or 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001628280-17-004928:note_history:10]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its prior credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Credit Agreement provides for a $200.0 million senior secured revolving credit facility ("Revolving Facility") and a $100.0 million senior secured term loan facility ("Term Facility", together with the Revolving Facility, the “Facilities”), with an option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Credit Agreement, matures on March 3, 2020. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its prior credit agreement. The $100.0 million term loan facility of the Credit Agreement was fully drawn at closing of the Credit Agreement, and $72.3 million was used to repay the outstanding balance under its prior credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Credit Agreement.
  (was, 2017-02-09, similarity 0.8479):
[0001511737-17-000003:note_history:10]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated its original credit agreement (the “Amended Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility ("Revolving Facility") and a $100.0 million senior secured term loan facility ("Term Facility", together with the Revolving Facility, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under its original credit agreement. The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under its original credit agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement.

- changed (2017-05-04):
[0001628280-17-004928:note_history:11]
|  | March 31, 2017 |  | June 30, 2016 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 10,993 |  |
| Term Loan - long term | 65,000 |  |  | 76,250 |  |
| Revolver - long term | 146,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (493 | ) |  | (686 | ) |
| Total Debt - long term | $ | 210,507 |  |  | $ | 191,564 |  |
  (was, 2017-02-09, similarity 0.9817):
[0001511737-17-000003:note_history:11]
|  | December 31, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 13,750 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 13,493 |  |  | 10,993 |  |
| Term Loan - long term | 68,750 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (556 | ) |  | (686 | ) |
| Total Debt - long term | $ | 184,194 |  |  | $ | 191,564 |  |

- changed (2017-05-04):
[0001628280-17-004928:note_history:12]
As of March 31, 2017, the interest rate on the term loan was 2.65%. The table below shows the respective interest rates as of March 31, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.
  (was, 2017-02-09, similarity 0.9493):
[0001511737-17-000003:note_history:12]
As of December 31, 2016, the interest rate on the term loan was 2.50%. The table below shows the respective interest rates as of December 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- changed (2017-05-04):
[0001628280-17-004928:note_history:13]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2017 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.51% |  | 4/10/2017 |  | # |
| $18 Million Revolver |  | 2.52% |  | 7/18/2017 |  | 2.66% |
| $16 Million Revolver |  | 2.53% |  | 5/15/2017 |  | * |
| $19 Million Revolver |  | 2.50% |  | 4/3/2017 |  | # |
| $48 Million Revolver |  | 2.55% |  | 5/30/2017 |  | * |
| $30 Million Revolver |  | 2.93% |  | 9/15/2017 |  | * |
  (was, 2017-02-09, similarity 0.92):
[0001511737-17-000003:note_history:13]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | December 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 1/9/2017 |  | 2.51% |
| $18 Million Revolver |  | 2.48% |  | 1/18/2017 |  | 2.52% |
| $16 Million Revolver |  | 2.70% |  | 2/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 1/3/2017 |  | 2.50% |
| $48 Million Revolver |  | 2.44% |  | 2/28/2017 |  | * |

- added (2017-05-04):
[0001628280-17-004928:note_history:14]
# - Revolver repaid subsequent to March 31, 2017

- changed (2017-05-04):
[0001628280-17-004928:note_history:15]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.
  (was, 2017-02-09, similarity 0.9937):
[0001511737-17-000003:note_history:15]
The Revolving Facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

- changed (2017-05-04):
[0001628280-17-004928:note_history:16]
The Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. In addition, the Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.
  (was, 2017-02-09, similarity 0.9766):
[0001511737-17-000003:note_history:16]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants and includes customary events of default. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

- changed (2017-05-04):
[0001628280-17-004928:note_history:17]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.
  (was, 2017-02-09, similarity 0.9882):
[0001511737-17-000003:note_history:17]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

- changed (2017-05-04):
[0001628280-17-004928:note_history:18]
During the three months ended March 31, 2017, the Company made a payment of $3.0 million against the balance under the Term Facility, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the nine months ended March 31, 2017, the Company made aggregate payments of $9.0 million against the balance under the Term Facility, of which $7.5 million was a repayment of principal and $1.5 million was payment of interest.
  (was, 2017-02-09, similarity 0.6462):
[0001511737-17-000003:note_history:18]
During the three months ended December 31, 2016, the Company made a payment of $3.0 million against the balance under the Term Facility, of which $2.5 million was a repayment of principal and $0.5 million was payment of interest. During the six months ended December 31, 2016, the Company made aggregate payments of $6.0 million against the balance under the Term Facility, of which $5.0 million was a repayment of principal and $1.0 million was payment of interest.

- changed (2017-05-04):
[0001628280-17-004928:note_history:19]
During the three months ended March 31, 2017, the Company made a payment of $0.7 million of interest under the Revolving Facility. During the nine months ended March 31, 2017, the Company made aggregate payments of $2.2 million of interest under the Revolving Facility.
  (was, 2017-02-09, similarity 0.8806):
[0001511737-17-000003:note_history:19]
During the three months ended December 31, 2016, the Company made a payment of $1.1 million of interest under the Revolving Facility. During the six months ended December 31, 2016, the Company made aggregate payments of $1.5 million of interest under the Revolving Facility.

- changed (2017-05-04):
[0001628280-17-004928:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2017, for the remainder of fiscal 2017 and future fiscal years (in thousands):
  (was, 2017-02-09, similarity 0.9735):
[0001511737-17-000003:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):

- changed (2017-05-04):
[0001628280-17-004928:note_history:21]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2017. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2017-02-09, similarity 0.9733):
[0001511737-17-000003:note_history:21]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of December 31, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001628280-17-004928:note_history:22]
The table below shows the respective interest rates as of March 31, 2017 in addition to interest rate reset dates and rates as available for each revolver draw.
  (was, 2017-02-09, similarity 0.9712):
[0001511737-17-000003:note_history:22]
The table below shows the respective interest rates as of December 31, 2016 in addition to interest rate reset dates and rates as available for each revolver draw.

- changed (2017-05-04):
[0001628280-17-004928:note_history:23]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | March 31, 2017 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.51% |  | 4/10/2017 |  | # |
| $18 Million Revolver |  | 2.52% |  | 7/18/2017 |  | 2.66% |
| $16 Million Revolver |  | 2.53% |  | 5/15/2017 |  | * |
| $19 Million Revolver |  | 2.50% |  | 4/3/2017 |  | # |
| $48 Million Revolver |  | 2.55% |  | 5/30/2017 |  | * |
| $30 Million Revolver |  | 2.93% |  | 9/15/2017 |  | * |
  (was, 2017-02-09, similarity 0.92):
[0001511737-17-000003:note_history:23]
|  |  | Interest Rate as of |  |  |  |  |
| Debt Payment Obligations |  | December 31, 2016 |  | Rate Reset Date |  | Reset Rate |
| $15 Million Revolver |  | 2.42% |  | 1/9/2017 |  | 2.51% |
| $18 Million Revolver |  | 2.48% |  | 1/18/2017 |  | 2.52% |
| $16 Million Revolver |  | 2.70% |  | 2/13/2017 |  | * |
| $19 Million Revolver |  | 2.41% |  | 1/3/2017 |  | 2.50% |
| $48 Million Revolver |  | 2.44% |  | 2/28/2017 |  | * |

- added (2017-05-04):
[0001628280-17-004928:note_history:24]
# - Revolver repaid subsequent to March 31, 2017


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001628280-17-004928:note_history:25]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2017, for the remainder of fiscal 2017 and future fiscal years (in thousands):
  (was, 2017-02-09, similarity 0.9735):
[0001511737-17-000003:note_history:25]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2016, for the remainder of fiscal 2017 and future fiscal years (in thousands):

- changed (2017-05-04):
[0001628280-17-004928:note_history:26]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of March 31, 2017. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.
  (was, 2017-02-09, similarity 0.9733):
[0001511737-17-000003:note_history:26]
(1) - Interest payments are calculated based on the applicable rates and payment dates as of December 31, 2016. Furthermore, two to three-month payment intervals on the revolving debt have been assumed, consistent with the Company's elections to date.

- changed (2017-05-04):
[0001628280-17-004928:note_history:27]
|  | March 31, 2017 |  | June 30, 2016 |
| Term Loan - short term | $ | 15,000 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 14,743 |  |  | 10,993 |  |
| Term Loan - long term | 65,000 |  |  | 76,250 |  |
| Revolver - long term | 146,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (493 | ) |  | (686 | ) |
| Total Debt - long term | $ | 210,507 |  |  | $ | 191,564 |  |
  (was, 2017-02-09, similarity 0.9817):
[0001511737-17-000003:note_history:27]
|  | December 31, 2016 |  | June 30, 2016 |
| Term Loan - short term | $ | 13,750 |  |  | $ | 11,250 |  |
| Debt issuance costs, net (1) | (257 | ) |  | (257 | ) |
| Total Debt - short term | 13,493 |  |  | 10,993 |  |
| Term Loan - long term | 68,750 |  |  | 76,250 |  |
| Revolver - long term | 116,000 |  |  | 116,000 |  |
| Debt issuance costs, net (1) | (556 | ) |  | (686 | ) |
| Total Debt - long term | $ | 184,194 |  |  | $ | 191,564 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001628280-17-004928:note_history:28]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.5 million and $1.7 million in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2017, respectively.  The Company recognized a total of approximately $0.4 million and $1.0 million in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2016, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.
  (was, 2017-02-09, similarity 0.9576):
[0001511737-17-000003:note_history:28]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $0.5 million and $1.2 million in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2016, respectively.  The Company recognized a total of approximately $0.4 million and $0.6 million in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2015, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-05-04):
[0001628280-17-004928:note_history:29]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The First Amendment increased the maximum aggregate amount of the Revolving Facility from $200.0 million to $300.0 million, but maintained the $100.0 million Term Facility under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions.

- added (2017-05-04):
[0001628280-17-004928:note_history:30]
Pursuant to the $50 million stock repurchase program approved by the Board of Directors of the Company on March 3, 2017, the Company repurchased $3.0 million of its common stock in the fourth quarter of fiscal 2017 that were trades executed on or prior to March 31, 2017. Please see Note 9 of the notes to the consolidated financial statements and Part II “Other Information” - Item 2 “Unregistered Sales of Equity Securities and Use of Proceeds” for more information.

- removed (2017-05-04):
[0001511737-17-000003:note_history:31]
On February 3, 2017, Synopsys, Inc. (“Synopsys”) filed a complaint against the Company, one of our subsidiaries and certain employees in the United States District Court for the Northern District of California, alleging claims under the Digital Millennium Copyright Act. The Company plans to vigorously defend itself against these claims; however, there can be no assurance that the Company will prevail in the lawsuit. The Company cannot currently estimate the possible loss or range of losses, if any, that it may experience in connection with this litigation.
