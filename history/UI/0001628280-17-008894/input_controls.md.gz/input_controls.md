# UI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 4 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001628280-17-008894:item_9a:1]
Item 9A. Controls and Procedures

[0001628280-17-008894:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001628280-17-008894:item_9a:3]
Management, with the participation of the Company’s Chief Executive Officer and Chief Accounting Officer, evaluated the effectiveness of our disclosure controls and procedures as of June 30, 2017. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), means

[0001628280-17-008894:item_9a:4]
52

[0001628280-17-008894:item_9a:5]
controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives. Based on the evaluation of our disclosure controls and procedures as of June 30, 2017, our Chief Executive Officer and Chief Accounting Officer concluded that, as of such date, our disclosure controls and procedures were effective.

[0001628280-17-008894:item_9a:6]
Management’s Report on Internal Control over Financial Reporting

[0001628280-17-008894:item_9a:7]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f). A company’s internal control over financial reporting is a process designed by, or under the supervision of, its Chief Executive Officer and Chief Accounting Officer, and effected by such company's board of directors, management and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles and includes those policies and procedures that:

[0001628280-17-008894:item_9a:8]
| (i) | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; |
| (ii) | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and |
| (iii) | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements. |

[0001628280-17-008894:item_9a:9]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of a company's annual or interim financial statements will not be prevented or detected on a timely basis.

[0001628280-17-008894:item_9a:10]
Management, with the participation of our Chief Executive Officer and Chief Accounting Officer, has conducted an evaluation of the effectiveness of our internal control over financial reporting as of June 30, 2017, based on the framework set forth in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on this assessment, management has concluded that the Company maintained effective internal control over financial reporting as of June 30, 2017.

[0001628280-17-008894:item_9a:11]
The effectiveness of our internal control over financial reporting as of June 30, 2017 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in their report which appears herein.

[0001628280-17-008894:item_9a:12]
Material Weaknesses in Internal Control over Financial Reporting

[0001628280-17-008894:item_9a:13]
As reported in its Annual Reports on Form 10-K for the years ended June 30, 2016 and 2015, Management determined that the Company did not maintain an effective control environment, attributable to a lack of sufficient, competent personnel necessary for effective financial reporting. This resulted in the lack of comprehensive and up-to-date accounting policies and procedures, skepticism on the part of key accounting personnel, internal control training, leadership and adequate communication of roles and responsibilities. Growth in the complexity of the business without commensurate growth in the capabilities of the finance and accounting organization contributed to this deficiency.

[0001628280-17-008894:item_9a:14]
The Company’s failure to maintain an effective control environment contributed to a second deficiency in the form of ineffectively designed and maintained controls required for safeguarding of the Company’s funds and timely detection of improper transactions in the general ledger. Specifically, the Company’s disbursement authorization policies were not updated timely for changes in personnel and positions, nor were authorization requirements clearly stated, including those for non-routine transactions.

[0001628280-17-008894:item_9a:15]
53

[0001628280-17-008894:item_9a:16]
The Company’s failure to maintain an effective control environment also contributed to a third deficiency in the form of ineffectively designed and maintained controls over user access and transaction privileges to modify and post entries to the general ledger and subsidiary ledgers. In particular, the scope of user access and transaction privileges to the general ledger and subsidiary ledgers is not sufficiently restricted to provide reasonable assurance of effective process and review controls over postings to the general ledger. Additionally, general ledger changes were completed without due consideration of collateral impacts on segregation of duties controls.

[0001628280-17-008894:item_9a:17]
These control deficiencies could result in misstatements of accounts or disclosures that would each result in a material misstatement of the interim or consolidated financial statements that would not be prevented or detected and, therefore, management has determined that these control deficiencies constitute material weaknesses. However, management has determined that the foregoing material weaknesses did not result in a material misstatement in the consolidated financial statements as of June 30, 2016.

[0001628280-17-008894:item_9a:18]
Remediation of Previously Reported Material Weaknesses

[0001628280-17-008894:item_9a:19]
During the period covered by this Annual Report on Form 10-K, we completed the remediation efforts of the material weaknesses described above.

[0001628280-17-008894:item_9a:20]
Regarding the lack of sufficient, competent personnel necessary for effective financial reporting, we recruited and transitioned the leadership team within the finance organization by adding additional qualified and experienced personnel. We have updated our accounting policies and procedures documentation together with key process level documents. In conjunction with the recruitment efforts, we have clarified roles and responsibilities within the finance organization.

[0001628280-17-008894:item_9a:21]
Regarding the ineffectively designed and maintained controls required for safeguarding of the Company’s funds and timely detection of improper transactions in the general ledger, we have implemented new policies and controls surrounding disbursement authorities and journal entry creation, including training on required supporting documentation.

[0001628280-17-008894:item_9a:22]
Regarding the ineffectively designed and maintained controls over user access and transaction privileges to modify and post entries to the general ledger and subsidiary ledgers, the Company has reviewed and updated user access and transaction privileges to the general ledger and interfacing subsidiary systems through the implementation of automated and manual controls. Additionally, we have performed a segregation of duties analysis over general ledger access. Management has also developed policies to ensure that future system changes consider impacts to the general ledger, including transaction privileges and segregation of duties.

[0001628280-17-008894:item_9a:23]
We have completed our testing of the controls discussed above and conclude that our previously reported material weaknesses in our internal controls over financial reporting have been satisfactorily remediated as of June 30, 2017.

[0001628280-17-008894:item_9a:24]
Changes in Internal Control Over Financial Reporting

[0001628280-17-008894:item_9a:25]
Other than the changes described above, there were no other changes in our internal control over financial reporting that occurred during the quarter ended June 30, 2017 that materially affected, or that are reasonably likely to materially affect, our internal control over financial reporting.
