# UI MD&A — 0001628280-17-008894


## mdna

[0001628280-17-008894:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-17-008894:mdna:2]
Overview

[0001628280-17-008894:mdna:3]
Ubiquiti Networks develops high performance networking technology for service providers, enterprises and consumers globally. Our technology platforms focus on delivering highly-advanced and easily deployable solutions that appeal to a global customer base in underserved and underpenetrated markets. Our differentiated business model has enabled us to break down traditional barriers such as high product and network deployment costs and offer solutions with disruptive price-performance characteristics. Our growth is supported by the Ubiquiti Community, a global, grass-roots community of 4 million entrepreneurial operators and systems integrators who engage in thousands of on-line forums at http://www.ubnt.com.

[0001628280-17-008894:mdna:4]
The Company maintains an industry leading financial profile by leveraging a unique business model. This differentiated business model, combined with our innovative proprietary technologies, has resulted in an attractive alternative to traditional high touch, high cost providers, allowing us to advance the market adoption of our platforms for ubiquitous connectivity. Since

[0001628280-17-008894:mdna:5]
38

[0001628280-17-008894:mdna:6]
our founding, more than 70 million devices have been sold worldwide through a network of over 100 distributors and on-line retailers, to customers in more than 200 countries and territories.  As a result, our technology has enabled hundreds of millions of people throughout the world to stay connected.

[0001628280-17-008894:mdna:7]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing and the related software for entrepreneurs to easily control, track and bill their customers. Our enterprise product platforms provide wireless LAN (WLAN) infrastructure, video surveillance products, switching and routing solutions, security gateways, and other complimentary WLAN products along with a unique software platform, which enables users to control their network from one simple, easy to use interface. Our consumer products, sold under the Ubiquiti Labs brand name, are targeted to the smart home and highly connected consumers.  We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001628280-17-008894:mdna:8]
In fiscal 2017, we announced Ubiquiti Labs, a division focusing on research and development of consumer electronics and introduced a new consumer product platform, called AmpliFi, which is a Wi-Fi system solution designed to serve the demands of the modern connected home.  AmpliFi is distributed through a network of retailers including Sam’s Club, Best Buy and Game Stop, as well as on-line retailers Amazon.com and Bestbuy.com among others. This division is focused on delivery direct to consumer based solutions in an array of high technology products.

[0001628280-17-008894:mdna:9]
As a core part of our strategy, we have developed a differentiated business model for marketing and selling high volumes of carrier and enterprise-class communications platforms. Our business model is driven by a large, growing and highly engaged community of service providers, distributors, value added resellers, systems integrators and corporate IT professionals, which we refer to as the Ubiquiti Community. The Ubiquiti Community is a critical element of our business strategy as it enables us to drive:

[0001628280-17-008894:mdna:10]
| • | Rapid customer and community driven product development. We have an active, loyal community built from our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market. |

[0001628280-17-008894:mdna:11]
| • | Scalable sales and marketing model. We do not currently have, nor do we plan to hire, a direct sales force, but instead utilize the Ubiquiti Community to drive market awareness and demand for our products and solutions. This community-propagated viral marketing enables us to reach underserved and underpenetrated markets far more efficiently and cost-effectively than is possible through traditional sales models. Leveraging the information transparency of the Internet allows customers to research, evaluate and validate our solutions with the Ubiquiti Community and via third party web sites. This allows us to operate a scalable sales and marketing model and effectively create awareness of our brand and products. Word of mouth referrals from the Ubiquiti Community generate high quality leads for our distributors at relatively little cost. |

[0001628280-17-008894:mdna:12]
| • | Self-sustaining product support. The engaged members of the Ubiquiti Community have enabled us to foster a large, cost efficient, highly-scalable and, we believe, self-sustaining mechanism for rapid product support and dissemination of information. |

[0001628280-17-008894:mdna:13]
By reducing the cost of development, sales, marketing and support we are able to eliminate traditional business model inefficiencies and offer innovative solutions with disruptive price performance characteristics to our customers.

[0001628280-17-008894:mdna:14]
Key Components of Our Results of Operations and Financial Condition

[0001628280-17-008894:mdna:15]
Revenues

[0001628280-17-008894:mdna:16]
Our revenues are derived principally from the sale of networking hardware and management tools. In addition, while we do not sell maintenance and support separately, because we have historically included it free of charge in many of our arrangements, we attribute a portion of our systems revenues to this implied post-contract customer support (“PCS”).

[0001628280-17-008894:mdna:17]
We classify our revenues into two primary product categories, Service Provider Technology and Enterprise Technology.

[0001628280-17-008894:mdna:18]
39

[0001628280-17-008894:mdna:19]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. |

[0001628280-17-008894:mdna:20]
| • | Enterprise Technology includes our UniFi and mFi platforms, including UniFi enterprise Wi-Fi products, Unifi Video products, Unifi switching and routing solutions, and AmpliFi Enterprise Technology also includes revenues that are attributable to PCS. |

[0001628280-17-008894:mdna:21]
We sell our products and solutions globally to service providers and enterprises primarily through our extensive network of distributors, and, to a lesser extent, direct customers.  Sales to distributors accounted for 99% of our revenues in the year ended June 30, 2017.  Other channel partners, such as resellers, largely accounted for the balance of our revenues.

[0001628280-17-008894:mdna:22]
Cost of Revenues

[0001628280-17-008894:mdna:23]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes tooling, labor and other costs associated with engineering, testing and quality assurance, warranty costs, stock-based compensation, logistics related fees and excess and obsolete inventory.

[0001628280-17-008894:mdna:24]
In addition to utilizing contract manufacturers, we outsource most of our logistics warehousing and order fulfillment functions, which are located primarily in China, and to a lesser extent, Taiwan and United States. We also evaluate and utilize other vendors for various portions of our supply chain from time to time. Our operations organization consists of employees and consultants engaged in the management of our contract manufacturers, new product introduction activities, logistical support and engineering.

[0001628280-17-008894:mdna:25]
Gross Profit

[0001628280-17-008894:mdna:26]
Our gross profit has been, and may in the future be, influenced by several factors including changes in product mix, target end markets for our products, pricing due to competitive pressure, production costs and global demand for electronic components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs, in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers, they may try to pass these additional costs on to us, which could have a material impact on our future average selling prices and unit costs.

[0001628280-17-008894:mdna:27]
Operating Expenses

[0001628280-17-008894:mdna:28]
We classify our operating expenses as research and development, sales, general and administrative expenses and expense related to the business email compromise fraud loss.

[0001628280-17-008894:mdna:29]
| • | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, licensed or purchased intellectual property, facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products in addition to new versions of our existing products. |

[0001628280-17-008894:mdna:30]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations. |

[0001628280-17-008894:mdna:31]
| • | Business e-mail compromise fraud (recovery)loss - In June 2015, we determined that we were the victim of criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department. The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by |

[0001628280-17-008894:mdna:32]
40

[0001628280-17-008894:mdna:33]
third parties, of which we recovered $8.1 million in fiscal 2015.  As a result, we recorded a charge of $39.1 million in the fourth quarter of 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  In fiscal 2016, the Company recorded a net recovery of an additional $8.3 million, comprised of an $8.6 million recovery less $0.3 million of professional service fees associated with the recovery. The Company is continuing to pursue the recovery of the remaining $30.0 million and is cooperating with U.S. federal and numerous overseas law enforcement authorities who are actively pursuing a multi-agency criminal investigation. However, any additional recoveries are likely remote and, therefore, cannot be assured.

[0001628280-17-008894:mdna:34]
Deferred Revenues

[0001628280-17-008894:mdna:35]
We recognize revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where we lack evidence that all of these criteria have been met, we defer recognition of revenue. Included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of June 30, 2017, and 2016, we had deferred revenues of $7.9 million and $4.2 million, respectively, related mainly to future PCS obligations.

[0001628280-17-008894:mdna:36]
Critical Accounting Policies

[0001628280-17-008894:mdna:37]
We prepare our consolidated financial statements in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. In other cases, management’s judgment is required in selecting among available alternative accounting standards that provide for different accounting treatment for similar transactions. The preparation of consolidated financial statements also requires us to make estimates and assumptions that affect the amounts we report as assets, liabilities, revenues, costs and expenses and affect the related disclosures. We base our estimates on historical experience and other assumptions that we believe are reasonable under the circumstances. In many instances, we could reasonably use different accounting estimates, and in some instances, changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, our actual results could differ significantly from the estimates made by our management. To the extent that there are differences between our estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected. We believe that the accounting policies discussed below are critical to understanding our historical and future performance, as these policies relate to the more significant areas involving management’s judgments and estimates.

[0001628280-17-008894:mdna:38]
Recognition of Revenues

[0001628280-17-008894:mdna:39]
Revenues consist primarily of revenues from the sale of hardware and management tools, as well as the related implied PCS. We recognize revenues when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable and the collectability of the resulting receivable is reasonably assured. In cases where we lack evidence that collectability of the resulting receivable is reasonably assured, we defer recognition of revenue until the receipt of cash.

[0001628280-17-008894:mdna:40]
For our sales, evidence of the arrangement consists of an order from a customer. We consider delivery to have occurred once our products have been shipped and title and risk of loss have been transferred. For our sales, these criteria are met at the time the products are transferred to the customer's shipping agent. Our arrangements with customers do not include provisions for cancellation, returns, inventory swaps or refunds that materially impact recognized revenues.

[0001628280-17-008894:mdna:41]
We record amounts billed to distributors for shipping and handling costs as revenues. We classify shipping and handling costs incurred by us as cost of revenues.  Deposit payments received from distributors in advance of recognition of revenues are included in current liabilities on our balance sheet and are recognized as revenues when all the criteria for recognition of revenues are met.

[0001628280-17-008894:mdna:42]
Our multi-element arrangements generally include two deliverables. The first deliverable is the hardware and software essential to the functionality of the hardware device delivered at the time of sale. The second deliverable is the implied right to PCS included with the purchase of certain products. PCS is the right to receive, on a when and if available basis, future unspecified software upgrades and features relating to the product’s essential software as well as bug fixes, email and telephone support.

[0001628280-17-008894:mdna:43]
We use a hierarchy to determine the allocation of revenues to the deliverables. The hierarchy is as follows: (i) vendor-specific objective evidence of fair value (“VSOE”), (ii) third-party evidence of selling price (“TPE”), and (iii) best estimate of the selling price (“BESP”).

[0001628280-17-008894:mdna:44]
| (i) | VSOE generally exists only when a company sells the deliverable separately and is the price actually charged by the company for that deliverable. Generally, we do not sell the deliverables separately and, as such, do not have VSOE. |

[0001628280-17-008894:mdna:45]
| (ii) | TPE can be substantiated by determining the price that other parties sell similar or substantially similar offerings. We do not believe that there is accessible TPE evidence for similar deliverables. |

[0001628280-17-008894:mdna:46]
| (iii) | BESP reflects our best estimates of what the selling prices of elements would be if they were sold regularly on a stand-alone basis. We believe that BESP is the most appropriate methodology for determining the allocation of revenues among the multiple elements. |

[0001628280-17-008894:mdna:47]
We have allocated revenues between these two deliverables using the relative selling price method which is based on the BESP for all deliverables. Revenues allocated to the delivered hardware and the related essential software are recognized at the time of sale provided the other conditions for recognition of revenues have been met. Revenues allocated to the PCS are deferred and recognized on a straight-line basis over the estimated period for which services will be delivered to support each of these devices which, currently, is two years. All costs of revenues, including estimated warranty costs, are recognized at the time of sale. Costs for research and development and sales and marketing are expensed as incurred. If the estimated life of the hardware product should change, the future rate of amortization of the revenues allocated to PCS would also change.

[0001628280-17-008894:mdna:48]
Our process for determining BESP for deliverables involves multiple factors that may vary depending upon the unique facts and circumstances related to each deliverable. For PCS, we believe our network operators and service providers would be reluctant to pay for such services separately. This view is primarily based on the fact that unspecified upgrade rights do not obligate us to provide upgrades at a particular time or at all, and do not specify to network operators and service providers which upgrades or features will be delivered. We believe that the relatively low prices of our products and our network operators, and service providers’ price sensitivity would add to their reluctance to pay for PCS. Therefore, we have concluded that if we were to sell PCS on a stand-alone basis, the selling price would be relatively low.

[0001628280-17-008894:mdna:49]
Key factors considered by us in developing the BESP for PCS include reviewing the activities of specific employees engaged in support and software development to determine the amount of time that is allocated to the development of the undelivered elements, determining the cost of this development effort, and then adding an appropriate level of gross profit to these costs.

[0001628280-17-008894:mdna:50]
Inventory and Inventory Valuation

[0001628280-17-008894:mdna:51]
Our inventories are primarily finished goods and, to a lesser extent, raw materials.  Our inventories are stated at the lower of actual cost (computed on a first-in, first-out basis), or Net Realizable Value (NRV). NRV is based upon an estimated average selling price reduced by the estimated costs of disposal. The determination of NRV involves numerous judgments including estimating average selling prices based upon recent sales, industry trends, existing customer orders, and seasonal factors. Should actual market conditions differ from our estimates, our future results of operations could be materially affected. We reduce the value of our inventory for estimated obsolescence or lack of marketability by the difference between the cost of the affected inventory and the estimated market value. Write-downs are not reversed until the related inventory has been subsequently sold or scrapped.

[0001628280-17-008894:mdna:52]
The valuation of inventory also requires us to estimate excess and obsolete inventory. The determination of excess or obsolete inventory is estimated based on a comparison of the quantity and cost of inventory on hand to our forecast of customer demand. Customer demand is dependent on many factors and requires us to use significant judgment in our forecasting process. We also make assumptions regarding the rate at which new products will be accepted in the marketplace and at which customers will transition from older products to newer products. If actual market conditions are less favorable than those projected by management, additional inventory write-downs may be required, which would have a negative impact on our gross margin. If we ultimately sell inventory that we have previously written down, our gross margins in future periods will be positively impacted.

[0001628280-17-008894:mdna:53]
Product Warranties

[0001628280-17-008894:mdna:54]
We offer warranties on certain products and record a liability for the estimated future costs associated with potential warranty claims. These warranty costs are reflected in our consolidated statement of operations and comprehensive income within cost of revenues. Our warranties are in effect for 12 months from the date of purchase.  Our estimates of future warranty costs are largely based on historical experience of product failure rates, material usage and service delivery costs incurred in correcting product failures. Our operating results could be materially and adversely affected if future warranty claims exceed historical experiences and we are not able to recover costs from our contract manufacturers.  In the future, we may introduce certain products with longer warranty periods.

[0001628280-17-008894:mdna:55]
Allowance for Doubtful Accounts

[0001628280-17-008894:mdna:56]
We record an allowance for doubtful accounts for estimated probable losses on uncollectible accounts receivable. In estimating the allowance, management considers, among other factors, the aging of the accounts receivable, our historical write offs, the credit worthiness of each distributor based on payment history and general economic conditions.

[0001628280-17-008894:mdna:57]
Income Taxes

[0001628280-17-008894:mdna:58]
We account for income taxes by recognizing deferred tax assets and liabilities for the expected future tax consequences of events that have been included in our financial statements or tax returns. Deferred tax assets and liabilities are determined based on the temporary difference between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We establish valuation allowances when necessary to reduce deferred tax assets to the amount we expect to realize. The assessment of whether or not a valuation allowance is required often requires significant judgment including current operating results, the forecast of future taxable income and ongoing prudent and feasible tax planning initiatives.

[0001628280-17-008894:mdna:59]
In addition, our calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations. We may be subject to income tax audits in each of the jurisdictions in which we operate and, as a result, must also assess exposures to any potential issues arising from current or future audits of current and prior years’ tax returns. Accordingly, we must assess such potential exposures and, where necessary, provide a reserve to cover any expected loss. To the extent that we establish a reserve, our provision for income taxes would be increased. We review our potential liabilities periodically and, if necessary, record an additional charge in our provision for taxes in the period in which we determine that tax liability is greater than our original estimate. If we ultimately determine that payment of these amounts is unnecessary, we reverse the liability and recognize a tax benefit during the period in which we determine that the liability is no longer necessary.

[0001628280-17-008894:mdna:60]
Stock-based Compensation

[0001628280-17-008894:mdna:61]
We record stock-based awards at fair value as of the grant date and recognize expense, net of forfeitures, ratably on a straight-line basis over the requisite service period, which is generally the vesting term of the awards. We estimate the fair value of stock option awards on the grant date using the Black-Scholes option pricing model. The determination of the fair value of a stock-based award on the date of grant using the Black-Scholes option-pricing model is affected by our stock price on the date of grant as well as assumptions regarding a number of complex and subjective variables. These variables include our expected stock price volatility over the expected term of the award, actual and projected employee stock option exercise behaviors, the risk-free interest rate for the expected term of the award and expected dividends. The Company did not grant any stock options during fiscal 2017, fiscal 2016, or fiscal 2015. Restricted stock units are valued based on the fair value of our common stock on the date of grant.  Since our initial public offering on October 14, 2011, the fair value of our common stock is determined using the closing market price of our common stock as of the date of grant.

[0001628280-17-008894:mdna:62]
Results of Operations

[0001628280-17-008894:mdna:63]
Comparison of Years Ended June 30, 2017 and 2016

[0001628280-17-008894:mdna:64]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |
|  | (In thousands, except percentages) |
| Revenues | $ | 865,268 |  |  | 100 | % |  | $ | 666,395 |  |  | 100 | % |
| Cost of revenues(1) | 469,560 |  |  | 54 | % |  | 341,600 |  |  | 51 | % |
| Gross profit | 395,708 |  |  | 46 | % |  | 324,795 |  |  | 49 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development(1) | 69,094 |  |  | 8 | % |  | 57,765 |  |  | 9 | % |
| Sales, general and administrative(1) | 36,853 |  |  | 4 | % |  | 33,269 |  |  | 5 | % |
| Business e-mail compromise ("BEC") fraud (recovery) | — |  |  | — | % |  | (8,294 | ) |  | (1 | )% |
| Total operating expenses | 105,947 |  |  | 12 | % |  | 82,740 |  |  | 13 | % |
| Income from operations | 289,761 |  |  | 33 | % |  | 242,055 |  |  | 36 | % |
| Interest expense and other, net | (4,737 | ) |  | * |  |  | (2,115 | ) |  | * |  |
| Income before provision for income taxes | 285,024 |  |  | 33 | % |  | 239,940 |  |  | 36 | % |
| Provision for income taxes | 27,518 |  |  | 3 | % |  | 26,324 |  |  | 4 | % |
| Net income and comprehensive income | $ | 257,506 |  |  | 30 | % |  | $ | 213,616 |  |  | 32 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows |  |  |  |  |  |  |  |
| Cost of revenues | $ | 264 |  |  |  |  | $ | 448 |  |  |  |
| Research and development | 1,861 |  |  |  |  | 2,296 |  |  |  |
| Sales, general and administrative | 660 |  |  |  |  | 975 |  |  |  |
| Total stock-based compensation | $ | 2,785 |  |  |  |  | $ | 3,719 |  |  |  |

[0001628280-17-008894:mdna:65]
Revenues

[0001628280-17-008894:mdna:66]
Revenues increased $198.9 million, or 30%, from $666.4 million in fiscal 2016 to $865.3 million in fiscal 2017.  The overall increase in revenues during fiscal 2017 was driven by increased adoption of our Enterprise Technologies products, which represented 47% of our total revenue in fiscal 2017 and increased sales of new products offered to our Service Provider community, which represented 53% of our total revenue in fiscal 2017.

[0001628280-17-008894:mdna:67]
There were no material price changes in the Company's products sold during fiscal 2017.

[0001628280-17-008894:mdna:68]
Revenues by Product Type

[0001628280-17-008894:mdna:69]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 455,598 |  |  | 53 | % |  | $ | 418,346 |  |  | 63 | % |
| Enterprise Technology | 409,670 |  |  | 47 | % |  | 248,049 |  |  | 37 | % |
| Total revenues | $ | 865,268 |  |  | 100 | % |  | $ | 666,395 |  |  | 100 | % |

[0001628280-17-008894:mdna:70]
Service Provider Technology revenues increased $37.3 million, or 9%, during fiscal 2017, primarily due to increased revenue for Service Provider Technology products in all regions except Europe, the Middle East, and Africa (EMEA).

[0001628280-17-008894:mdna:71]
Enterprise Technology revenues increased $161.6 million, or 65%, during fiscal 2017, primarily due to product expansion and further adoption of our UniFi technology platform across all regions.

[0001628280-17-008894:mdna:72]
Revenues by Geography

[0001628280-17-008894:mdna:73]
We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be in different countries than the initial ship-to destination.  The following are our revenues by geography for fiscal 2017 and fiscal 2016 (in thousands, except percentages):

[0001628280-17-008894:mdna:74]
44

[0001628280-17-008894:mdna:75]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |
| North America(1) | $ | 331,435 |  |  | 38 | % |  | $ | 239,526 |  |  | 36 | % |
| South America | 105,511 |  |  | 12 | % |  | 85,036 |  |  | 13 | % |
| Europe, the Middle East and Africa | 334,473 |  |  | 39 | % |  | 264,404 |  |  | 39 | % |
| Asia Pacific | 93,849 |  |  | 11 | % |  | 77,429 |  |  | 12 | % |
| Total revenues | $ | 865,268 |  |  | 100 | % |  | $ | 666,395 |  |  | 100 | % |

[0001628280-17-008894:mdna:76]
| (1) | Revenue for the United States was $315.0 million and $225.6 million in fiscal 2017 and fiscal 2016, respectively. |

[0001628280-17-008894:mdna:77]
North America

[0001628280-17-008894:mdna:78]
Revenues in North America increased $91.9 million, or 38%, from $239.5 million in fiscal 2016 to $331.4 million in fiscal 2017. The year-over-year increase was due to increased adoption of both our Service Provider and Enterprise Technology products.

[0001628280-17-008894:mdna:79]
South America

[0001628280-17-008894:mdna:80]
Revenues in South America increased $20.5 million, or 24%, from $85.0 million in fiscal 2016 to $105.5 million in fiscal 2017.  The year-over-year increase was due to increased adoption of both Service our Provider Technology and Enterprise Technology products.

[0001628280-17-008894:mdna:81]
Europe, the Middle East, and Africa ("EMEA")

[0001628280-17-008894:mdna:82]
Revenues in EMEA increased $70.1 million, or 27%, from $264.4 million in fiscal 2016 to $334.5 million in fiscal 2017. The year-over-year increase was primarily due to increased adoption of our Enterprise Technology products, offset, in part, by a decline in service provider products.

[0001628280-17-008894:mdna:83]
Asia Pacific

[0001628280-17-008894:mdna:84]
Revenues in the Asia Pacific region increased $16.4 million, or 21%, from $77.4 million in fiscal 2016 to $93.8 million in fiscal 2017. The year-over-year increase was primarily due to increased adoption of our Enterprise Technology products.

[0001628280-17-008894:mdna:85]
Cost of Revenues and Gross Profit

[0001628280-17-008894:mdna:86]
Cost of revenues increased $128.0 million, or 37%, from $341.6 million in fiscal 2016 to $469.6 million in fiscal 2017. The increase in fiscal 2017 was primarily due to our overall increase in revenue and to a lesser extent, an increase in cost associated with fulfillment operations, warranty accruals and inventory reserves. Gross profit margin decreased to 46% in fiscal 2017 compared to 49% in fiscal 2016, which was primarily due to change in mix of products sold, increased costs associated with fulfillment operations, increased inventory obsolescence charges and warranty accruals.

[0001628280-17-008894:mdna:87]
Operating Expenses

[0001628280-17-008894:mdna:88]
Research and Development

[0001628280-17-008894:mdna:89]
Research and development expenses increased $11.3 million, or 20%, from $57.8 million in fiscal 2016 to $69.1 million in fiscal 2017. As a percentage of revenues, research and development expenses decreased from 9% in fiscal 2016 to 8% in fiscal 2017.  The increase in R&D expense in absolute dollars, was primarily due to increase in headcount, development activities and higher non-recurring engineering (NRE) payments, which was partially offset by the $2.5 million impairment charge for capitalized software development cost recognized in fiscal 2016. The increase in headcount and development cost reflects the increased efforts to broaden our research and development activities to introduce new products and new versions of existing products. As a percentage of revenue, R&D expense decreased primarily due to our overall increase in revenue.

[0001628280-17-008894:mdna:90]
Sales, General and Administrative

[0001628280-17-008894:mdna:91]
Sales, general and administrative expenses increased $3.6 million, or 11%, from $33.3 million in fiscal 2016 to $36.9 million in fiscal 2017. As a percentage of revenues, sales, general and administrative expenses decreased to 4% in fiscal 2017, compared to 5%  in fiscal 2016.  The increase in sales, general and administrative expenses in absolute dollars was primarily due to an increase in headcount in the administrative function and business development organization, and the overall increases in business development initiatives, partially offset by lower cost for interim management and advisory services to remediate

[0001628280-17-008894:mdna:92]
internal control weaknesses. As a percentage of revenue, sales, general and administrative expenses decreased primarily due to our overall increase in revenue.

[0001628280-17-008894:mdna:93]
Provision for Income Taxes

[0001628280-17-008894:mdna:94]
Our provision for income taxes increased $1.2 million from $26.3 million for fiscal 2016 to $27.5 million for fiscal 2017.  Our effective tax rate decreased to 9.7% in fiscal 2017 as compared to 11.0% for fiscal 2016.  The effective tax rate decrease in the fiscal 2017 was primarily due to tax benefit recognition as a result of the adoption of ASU 2016-09 of $7.9 million.

[0001628280-17-008894:mdna:95]
Comparison of Year Ended June 30, 2016 and 2015

[0001628280-17-008894:mdna:96]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |
|  | (In thousands, except percentages) |
| Revenues | $ | 666,395 |  |  | 100 | % |  | $ | 595,947 |  |  | 100 | % |
| Cost of revenues (1) (2) | 341,600 |  |  | 51 | % |  | 333,760 |  |  | 56 | % |
| Gross profit | 324,795 |  |  | 49 | % |  | 262,187 |  |  | 44 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development(1) | 57,765 |  |  | 9 | % |  | 54,565 |  |  | 9 | % |
| Sales, general and administrative(1) | 33,269 |  |  | 5 | % |  | 21,607 |  |  | 4 | % |
| Business e-mail compromise ("BEC") fraud (recovery)/ loss | (8,294 | ) |  | (1 | )% |  | 39,137 |  |  | 6 | % |
| Total operating expenses | 82,740 |  |  | 13 | % |  | 115,309 |  |  | 19 | % |
| Income from operations | 242,055 |  |  | 36 | % |  | 146,878 |  |  | 25 | % |
| Interest expense and other, net | (2,115 | ) |  | * |  |  | (1,130 | ) |  | * |  |
| Income before provision for income taxes | 239,940 |  |  | 36 | % |  | 145,748 |  |  | 24 | % |
| Provision for income taxes | 26,324 |  |  | 4 | % |  | 16,085 |  |  | 3 | % |
| Net income and comprehensive income | $ | 213,616 |  |  | 32 | % |  | $ | 129,663 |  |  | 21 | % |
| * Less than 1% |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows |  |  |  |  |  |  |  |
| Cost of revenues | $ | 448 |  |  |  |  | $ | 601 |  |  |  |
| Research and development | 2,296 |  |  |  |  | 2,854 |  |  |  |
| Sales, general and administrative | 975 |  |  |  |  | 1,537 |  |  |  |
| Total stock-based compensation | $ | 3,719 |  |  |  |  | $ | 4,992 |  |  |  |
| (2) Includes purchase commitment termination fee | $ | — |  |  |  |  | $ | 5,500 |  |  |  |

[0001628280-17-008894:mdna:97]
Revenues

[0001628280-17-008894:mdna:98]
Revenues increased $70.4 million, or 12%, from $595.9 million in fiscal 2015 to $666.4 million in fiscal 2016. The increase in revenues during fiscal 2016 was driven by increased adoption of our Enterprise Technologies products which represented 37% of our total revenue in fiscal 2016. Service Provider products revenue were flat year over year and represented 63% of our total revenue in fiscal 2016.

[0001628280-17-008894:mdna:99]
No distributor or customer represented more than 10% of our revenues in fiscal 2016 or fiscal 2015.

[0001628280-17-008894:mdna:100]
Revenues by Product Type

[0001628280-17-008894:mdna:101]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 418,346 |  |  | 63 | % |  | $ | 418,021 |  |  | 70 | % |
| Enterprise Technology | 248,049 |  |  | 37 | % |  | 177,926 |  |  | 30 | % |
| Total revenues | $ | 666,395 |  |  | 100 | % |  | $ | 595,947 |  |  | 100 | % |

[0001628280-17-008894:mdna:102]
46

[0001628280-17-008894:mdna:103]
Service Provider Technology revenues remained flat in fiscal 2016,  as the increase in sales in North America, Europe, the Middle East, and Africa ("EMEA") and Asia Pacific were largely offset by the decrease in sales in South America.

[0001628280-17-008894:mdna:104]
Enterprise Technology revenues increased $70.1 million, or 39%, during fiscal 2016, primarily due to product expansion and further adoption of our Enterprise Technology platform.

[0001628280-17-008894:mdna:105]
Revenues by Geography

[0001628280-17-008894:mdna:106]
We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be different countries than the initial ship-to destination.  The following are our revenues by geography for fiscal 2016 and fiscal 2015 (in thousands, except percentages):

[0001628280-17-008894:mdna:107]
|  | Years Ended June 30, |
|  | 2016 |  | 2015 |
| North America(1) | $ | 239,526 |  |  | 36 | % |  | $ | 197,693 |  |  | 33 | % |
| South America | 85,036 |  |  | 13 | % |  | 97,118 |  |  | 16 | % |
| Europe, the Middle East and Africa | 264,404 |  |  | 39 | % |  | 234,383 |  |  | 40 | % |
| Asia Pacific | 77,429 |  |  | 12 | % |  | 66,753 |  |  | 11 | % |
| Total revenues | $ | 666,395 |  |  | 100 | % |  | $ | 595,947 |  |  | 100 | % |

[0001628280-17-008894:mdna:108]
| (1) | Revenue for the United States was $225.6 million and $187.3 million in fiscal 2016 and fiscal 2015, respectively. |

[0001628280-17-008894:mdna:109]
North America

[0001628280-17-008894:mdna:110]
Revenues in North America increased $41.8 million, or 21%, from $197.7 million in fiscal 2015 to $239.5 million in fiscal 2016.  The increase in revenues in North America in fiscal 2016 compared to fiscal 2015 was due to increased adoption of our Service Provider and Enterprise Technologies.

[0001628280-17-008894:mdna:111]
South America

[0001628280-17-008894:mdna:112]
Revenues in South America decreased $12.1 million, or 12%, from $97.1 million in fiscal 2015 to $85.0 million in fiscal 2016.  We believe the decrease in revenues in South America in fiscal 2016 compared to fiscal 2015 was primarily due to decreased demand for our Service Provider Technologies due in part to economic instability and partially as a result of a strong U.S. Dollar.

[0001628280-17-008894:mdna:113]
EMEA

[0001628280-17-008894:mdna:114]
Revenues in EMEA increased $30.0 million, or 13%, from $234.4 million in fiscal 2015 to $264.4 million in fiscal 2016. The increase in revenues in EMEA in fiscal 2016 compared to fiscal 2015 was due to increased adoption of our Service Provider and Enterprise Technologies.

[0001628280-17-008894:mdna:115]
Asia Pacific

[0001628280-17-008894:mdna:116]
Revenues in the Asia Pacific region increased $10.7 million, or 16%, from $66.8 million in fiscal 2015 to $77.4 million in fiscal 2016. The increase in revenues in the Asia Pacific region in fiscal 2016 compared to fiscal 2015 was primarily due to increased adoption of our Service Provider and Enterprise Technologies.

[0001628280-17-008894:mdna:117]
Cost of Revenues and Gross Profit

[0001628280-17-008894:mdna:118]
Cost of revenues increased $7.8 million, or 2%, from $333.8 million in fiscal 2015 to $341.6 million in fiscal 2016.  The increase in cost of revenues in fiscal 2016 was primarily due to increased volume and to a lesser extent, changes in product mix. Gross profit as a percentage of revenue increased to 49% in fiscal 2016 compared to 44% in fiscal 2015.

[0001628280-17-008894:mdna:119]
Operating Expenses

[0001628280-17-008894:mdna:120]
Research and Development

[0001628280-17-008894:mdna:121]
Research and development expenses increased $3.2 million, or 6%, from $54.6 million in fiscal 2015 to $57.8 million in fiscal 2016. As a percentage of revenues, research and development expenses remained flat at 9% in both fiscal 2016 and fiscal 2015. This increase in absolute dollar expenditures is primarily driven by a $2.5 million impairment charge for capitalized software and software in development costs recognized in the second quarter of fiscal 2016 due to the cancellation of the commercial

[0001628280-17-008894:mdna:122]
47

[0001628280-17-008894:mdna:123]
launch of certain software in development. Over time, we expect our research and development costs to continue to increase in absolute dollars as we continue making investments in developing new products in addition to new versions of our existing products.

[0001628280-17-008894:mdna:124]
Sales, General and Administrative

[0001628280-17-008894:mdna:125]
Sales, general and administrative expenses increased $11.7 million, or 54% from $21.6 million in fiscal 2015 to $33.3 million in fiscal 2016. As a percentage of revenues, sales, general and administrative expenses increased to 5% in fiscal 2016, compared to 4% in fiscal 2015. The increase in sales, general and administrative expenses in absolute dollars and as a percentage of revenues was due to higher consulting fees incurred to support the finance team and to assist with material weakness remediation, higher legal costs, and an increase in headcount in the business development organization.

[0001628280-17-008894:mdna:126]
Business e-mail compromise fraud (recovery) loss

[0001628280-17-008894:mdna:127]
In June 2015, we determined that we were the victim of criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department. The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties. The Company recovered $8.1 million in fiscal 2015 and recorded a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss. In fiscal 2016, the Company recorded a net recovery of an additional $8.3 million, comprised of an $8.6 million recovery less $0.3 million of professional service fees associated with the recovery.

[0001628280-17-008894:mdna:128]
The Company is continuing to pursue the recovery of the remaining $30.0 million and is cooperating with U.S. federal and numerous overseas law enforcement authorities who are actively pursuing a multi-agency criminal investigation. However, any additional recoveries are likely remote and therefore cannot be assured.

[0001628280-17-008894:mdna:129]
Provision for Income Taxes

[0001628280-17-008894:mdna:130]
Our provision for income taxes increased $10.2 million from $16.1 million for fiscal 2015 to $26.3 million for fiscal 2016.  Our effective tax rate remained flat at 11% in both fiscal 2016 and fiscal 2015 because the Company's ratio of domestic and foreign income remained relatively constant for fiscal 2015 and fiscal 2016. Overall, the rate benefit is due to income in foreign jurisdictions that have lower tax rates than the U.S.

[0001628280-17-008894:mdna:131]
Liquidity and Capital Resources

[0001628280-17-008894:mdna:132]
Sources and Uses of Cash

[0001628280-17-008894:mdna:133]
Since inception, our operations primarily have been funded through cash generated by operations.  We had cash and cash equivalents of $604.2 million, $551.0 million and $446.4 million at June 30, 2017, 2016 and 2015, respectively.

[0001628280-17-008894:mdna:134]
Consolidated Cash Flow Data

[0001628280-17-008894:mdna:135]
The following table sets forth the major components of our consolidated statements of cash flows data for the periods presented:

[0001628280-17-008894:mdna:136]
|  | Years Ended June 30, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 112,036 |  |  | $ | 197,508 |  |  | $ | 134,547 |  |
| Net cash (used in) investing activities | (7,232 | ) |  | (6,248 | ) |  | (12,724 | ) |
| Net cash (used in) financing activities | (51,637 | ) |  | (86,630 | ) |  | (22,519 | ) |
| Net increase in cash and cash equivalents | $ | 53,167 |  |  | $ | 104,630 |  |  | $ | 99,304 |  |

[0001628280-17-008894:mdna:137]
Cash Flows from Operating Activities

[0001628280-17-008894:mdna:138]
Net cash provided by operating activities in fiscal 2017 consisted primarily of net income of $257.5 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $157.1 million. These changes consisted primarily of a $58.2 million increase in accounts receivable due to overall higher revenues for the period, a $22.7 million  increase in vendor deposit and $87.0 million increase in inventory due to an increase in warehouse stock levels in order to better support customers, support new product releases and reduce lead times, a $3.1 million increase in prepaid expense and

[0001628280-17-008894:mdna:139]
other assets primarily due to the increase of non-trade accounts receivable, a $7.2 million increase in accounts payable and accrued liabilities due to timing of payments, $3.6 million increase in deferred revenue due to additional PCS revenue deferrals during the year and a $2.9 million net increase in taxes payable and prepaid income taxes due to the timing of federal tax payments.  Overall, cash inflows from operating activities were driven by our net income, which included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, and increases to our provision for losses on deposits with our vendors. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $11.7 million.

[0001628280-17-008894:mdna:140]
Net cash provided by operating activities in fiscal 2016 consisted primarily of net income of $213.6 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $27.1 million. This net change was primarily driven by outflows arising from a $20.0 million increase in inventory, and a $9.3 million increase in vendor deposits due to our strategic efforts to reduce lead times and maximize order fulfillments, a $16.7 million increase in accounts receivable due to our overall increase in revenue. These outflows were offset by changes in operating assets and liabilities resulting in cash inflows, including a $11.0 million increase in accounts payable and accrued liabilities due to the timing of payments with our vendors, a $7.0 million net increase in taxes payable and decrease in prepaid income taxes due the timing of federal tax payments, a $0.7 million increase in deferred revenue due to additional PCS revenue deferrals during the year and a $0.2 million decrease in prepaid expenses and other current assets due to timing of deposit payments with our suppliers. Overall, cash inflows from operating activities were driven by our net income, which included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases to our provision for losses on deposits with our vendors, decreases in our allowance for doubtful accounts and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $11.0 million.

[0001628280-17-008894:mdna:141]
Net cash provided by operating activities in the fiscal 2015 consisted primarily of net income of $129.7 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $11.7 million . These changes consisted primarily of a $22.0 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, an $11.3 million increase in accounts receivable due to our overall increase in revenue, a $9.1 million increase in accounts payable and accrued liabilities due to the timing of payments with our vendors, a $7.0 million decrease in inventory due to our efforts to optimize our inventory levels and a $5.8 million net increase in taxes payable and prepaid income taxes due the timing of federal tax payments. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, increases to

[0001628280-17-008894:mdna:142]
our provision for losses on deposits with our vendors, decreases in our allowance for doubtful accounts and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $16.6 million.

[0001628280-17-008894:mdna:143]
Cash Flows from Investing Activities

[0001628280-17-008894:mdna:144]
We used $7.2 million of cash in investing activities during fiscal 2017. Our investing activities consist of capital expenditures and purchases of intangible assets. Capital expenditures for fiscal 2017, fiscal 2016 and fiscal 2015 were $7.1 million, $5.9 million and $12.7 million, respectively. Additionally, we had cash outflows related to intangible assets of $0.1 million, $0.3 million and $0.05 million during fiscal 2017, fiscal 2016 and fiscal 2015, respectively, consisting primarily of legal costs associated with trademark applications and acquisition of domain names.

[0001628280-17-008894:mdna:145]
Cash Flows from Financing Activities

[0001628280-17-008894:mdna:146]
We used $51.6 million of cash in financing activities during fiscal 2017.  During fiscal 2017 we paid $105.2 million for repurchase of common stock. We also made principal repayments of $11.3 million on our outstanding Term Facility and $34 million on our Revolving Facility. These cash outflows were offset by financing cash inflows of $99.0 million related to draws under our Revolving Facility. Additionally, cash inflows from financing activities included $1.4 million of cash proceeds received from the exercise of stock options partially offset by tax withholdings related to net share settlements of restricted stock units totaling $1.6 million.

[0001628280-17-008894:mdna:147]
We used $86.6 million of cash in financing activities during fiscal 2016, primarily driven by repurchasing $193.5 million of our common stock. We also made repayments of $10.0 million on our outstanding term loan debt and $14.0 million on our outstanding revolving loans under the Amended Credit Agreement during fiscal 2016. These cash outflows were offset by financing cash inflows, including the draws made under the Revolving Facility totaling $130.0 million. Additionally, cash inflows from financing activities included $1.1 million of cash proceeds received from the exercise of stock options in addition to $1.0 million of excess tax benefit from employee stock-based awards, partially offset by tax withholdings related to net share settlements of restricted stock units totaling $1.2 million.

[0001628280-17-008894:mdna:148]
49

[0001628280-17-008894:mdna:149]
We had $22.5 million of cash used in financing activities during fiscal 2015, primarily from cash received from our term loan with Wells Fargo Bank of $100.0 million, offset by repayments of our prior 2014 Credit Agreement with Wells Fargo Bank of $74.8 million. Additionally, during fiscal 2015 we paid $15.0 million for dividends on our common stock, paid $34.7 million for repurchases of our common stock and had tax withholdings related to net share settlements of restricted stock units of $1.8 million. Other cash inflows from financing activities included cash received for stock option exercises of $1.7 million and an excess tax benefit from employee stock-based awards of $2.1 million.

[0001628280-17-008894:mdna:150]
Liquidity

[0001628280-17-008894:mdna:151]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds, under the Facilities, will be sufficient to meet our working capital and capital expenditure needs for the next twelve months. However, this estimate is based on a number of assumptions that may prove to be wrong and we could exhaust our available cash and cash equivalents earlier than presently anticipated.  Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of June 30, 2017, we held $546.8 million of our $604.2 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001628280-17-008894:mdna:152]
We believe that the combination of our existing United States cash and cash equivalent balances and future United States operating cash flows are sufficient to meet our ongoing United States operating expenses and debt repayment obligations for the foreseeable future.

[0001628280-17-008894:mdna:153]
We earn a significant amount of our operating income outside the United States, which is deemed to be indefinitely reinvested in foreign jurisdictions. As a result, a significant portion of our cash and short-term investments are held by foreign subsidiaries. We currently do not intend nor foresee a need to repatriate these funds. We expect existing domestic cash and short-term investments and cash flows from operations to continue to be sufficient to fund our domestic operating activities and cash commitments for investing and financing activities, such as regular quarterly dividends, debt repayment, and capital expenditures, for at least the next 12 months and thereafter for the foreseeable future.

[0001628280-17-008894:mdna:154]
If we should require more capital in the United States than is generated by our domestic operations, for example to fund significant discretionary activities such as business acquisitions and share repurchases, we could elect to repatriate future earnings from foreign jurisdictions or raise capital in the United States through debt or equity issuances. These alternatives could result in higher effective tax rates, increased interest expense, or dilution of our earnings. We could also elect to borrow funds domestically, which we have done in the past and continue to believe we have the ability to do so at reasonable interest rates.

[0001628280-17-008894:mdna:155]
Contractual Obligations and Off-Balance Sheet Arrangements

[0001628280-17-008894:mdna:156]
The following table summarizes our contractual obligations as of June 30, 2017:

[0001628280-17-008894:mdna:157]
|  |  | Payments Due by Period |  |  |
|  |  | Year 1 |  | 1-3 Years |  | 3-5 years |  | Over 5 years |  | Total |
|  |  | (In thousands) |  |  |
| Operating leases |  | $ | 6,075 |  |  | $ | 5,554 |  |  | $ | 2,426 |  |  | $ | 578 |  |  | $ | 14,633 |  |
| Debt payment obligations |  | 15,000 |  |  | 242,250 |  |  | — |  |  | — |  |  | 257,250 |  |
| Interest and other payments on debt payment obligations |  | 7,044 |  |  | 10,956 |  |  | — |  |  | — |  |  | 18,000 |  |
| Purchase obligations |  | 32,884 |  |  | — |  |  | — |  |  | — |  |  | 32,884 |  |
| Other obligations |  | 4,337 |  |  | — |  |  | — |  |  | — |  |  | 4,337 |  |
| Total |  | $ | 65,340 |  |  | $ | 258,760 |  |  | $ | 2,426 |  |  | $ | 578 |  |  | $ | 327,104 |  |

[0001628280-17-008894:mdna:158]
Operating Leases

[0001628280-17-008894:mdna:159]
The Company leases its headquarters in New York, NY and other locations worldwide under non-cancelable operating leases that expire at various dates through 2023.

[0001628280-17-008894:mdna:160]
Debt and Interest Payment Obligations

[0001628280-17-008894:mdna:161]
On April 14, 2017, the Company, the Cayman Borrower and certain of its subsidiaries entered in the First Amendment (the “First Amendment”) to the Credit Agreement (as amended by the First Amendment, the “Amended Credit Agreement”). The

[0001628280-17-008894:mdna:162]
First Amendment increased the maximum aggregate amount of the Revolving Facility from $200.0 million to $300.0 million, but maintained the $100.0 million Term Facility under the Credit Agreement and the option to request increases in the amounts of such Facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion). The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $250.0 million, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the Revolving Facility. All other material terms and provisions of the Amended Credit Agreement remain substantially identical to the terms and provisions in place immediately prior to the effectiveness of the First Amendment, other than the revision or inclusion of certain customary market provisions. Please see Note 7 of the Notes to the Consolidated Financial Statements for more information. We have calculated estimated interest payments for our debt based on the applicable rates and payment dates. Although our interest rates on our debt obligations may vary, we have assumed the most recent available interest rates for all years presented.   Also included are estimated bank fees to be paid for unused portions of our revolving credit facility.

[0001628280-17-008894:mdna:163]
Purchase Obligations

[0001628280-17-008894:mdna:164]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability, and to date, no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred. We had inventory purchase obligations for finished goods of $32.9 million as of June 30, 2017.

[0001628280-17-008894:mdna:165]
Other Obligations

[0001628280-17-008894:mdna:166]
We had other obligations of $4.3 million as of June 30, 2017, which consisted primarily of commitments related to research and development projects.

[0001628280-17-008894:mdna:167]
Unrecognized Tax Benefits

[0001628280-17-008894:mdna:168]
As of June 30, 2017, we had $27.4 million and an additional $2.4 million for gross interest classified as non-current liabilities. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the above contractual obligation table.

[0001628280-17-008894:mdna:169]
Warranties and Indemnifications

[0001628280-17-008894:mdna:170]
Our products are generally accompanied by a 12-month warranty, which covers both parts and labor. Generally, the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001628280-17-008894:mdna:171]
We have entered and may in the future enter into standard indemnification agreements with certain distributors as well as other business partners in the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001628280-17-008894:mdna:172]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We had not recorded any liabilities for these agreements as of June 30, 2017 or 2016.

[0001628280-17-008894:mdna:173]
51

[0001628280-17-008894:mdna:174]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities as of June 30, 2017.

[0001628280-17-008894:mdna:175]
Off-Balance Sheet Arrangements

[0001628280-17-008894:mdna:176]
As of June 30, 2017 and 2016, we had no off-balance sheet arrangements other than those indemnification agreements described above.

[0001628280-17-008894:mdna:177]
Recent Accounting Pronouncements

[0001628280-17-008894:mdna:178]
For a discussion of recent accounting pronouncements, refer to Note 2 to the Consolidated Financial Statements.
