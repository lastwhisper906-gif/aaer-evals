# UI MD&A — 0001511737-13-000006


## mdna

[0001511737-13-000006:mdna:1]
[same as prior period, unchanged from 0001445305-13-000191:mdna:1]

[0001511737-13-000006:mdna:2]
[same as prior period, unchanged from 0001445305-13-000191:mdna:2]

[0001511737-13-000006:mdna:3]
Ubiquiti Networks is a product driven technology company that designs end-to-end networking solutions for service providers and enterprises. Our technology platforms focus on delivering highly-advanced and efficiently deployable solutions that appeal to a global customer base in underserved and underpenetrated markets. Our differentiated business model, focused around the Ubiquiti Community, has enabled us to break down traditional barriers, such as high product and network deployment costs, and offer solutions with disruptive price-performance characteristics. This disruptive business model, combined with our innovative proprietary technologies, has resulted in an attractive alternative to traditional relationship based, high-cost providers, allowing us to advance the market adoption of platforms for ubiquitous connectivity.

[0001511737-13-000006:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises.  Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing.  Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, and machine-to-machine communication components. We believe that our products are highly differentiated due to the combination of our significant software intellectual property, protocol innovation, firmware expertise and hardware design capabilities.  These products are integrated and flexible, which substantially reduces the cost and complexity of installation, maintenance and management. Our products and solutions meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those of our competitors' solutions.

[0001511737-13-000006:mdna:5]
As a core part of our strategy, we have developed a disruptive business model for marketing and selling high volumes of carrier and enterprise class communications platforms.  Our business model is driven by a large, growing and engaged community of network operators, distributors, value added resellers (“VARs”), systems integrators and corporate IT professionals, which we refer to as the Ubiquiti Community.  The Ubiquiti Community is a critical element of our business strategy as it enables us to drive:

[0001511737-13-000006:mdna:6]
| • | Rapid customer and community driven product development. We have an active, loyal end-user community built from our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of optimally designed products. This approach significantly reduces our development costs and the time to market for our products. |

[0001511737-13-000006:mdna:7]
| • | Scalable sales and marketing model. We do not currently have, nor do we plan to hire, a direct sales force, but instead utilize the Ubiquiti Community to drive market awareness and demand for our products and solutions. This community-propagated viral marketing enables us to reach underserved and underpenetrated markets far more efficiently and cost effectively than is possible through traditional sales models. Leveraging the information transparency of the Internet allows customers to research and evaluate our solutions with the Ubiquiti Community and via third-party web sites. This allows us to operate a scalable sales and marketing model that is designed to create awareness of our brand and products, engage significant numbers of potential customers and create a substantial volume of high quality sales leads at relatively little cost. |

[0001511737-13-000006:mdna:8]
| • | Self-sustaining product support. The engaged members of the Ubiquiti Community have enabled us to foster a large, cost efficient, highly scalable and, we believe, self-sustaining mechanism for rapid product support and dissemination of information. |

[0001511737-13-000006:mdna:9]
Our revenues decreased 9% to $83.2 million in the three months ended March 31, 2013 from $91.7 million in the three months ended March 31, 2012.  Our revenues decreased 15% to $219.6 million in the nine months ended March 31, 2013 from $258.6 million in the nine months ended March 31, 2012. We believe the overall decrease in revenues during both the three and nine months ended March 31, 2013 was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.  We had net income of $20.7 million and $27.9 million in the three months ended March 31, 2013 and 2012, respectively.  We had net income of

[0001511737-13-000006:mdna:10]
$51.6 million and $74.1 million in the nine months ended March 31, 2013 and 2012, respectively.  The declines in net income in both the three and nine months ended March 31, 2013 as compared to the same periods in the prior year were primarily due to the decline in revenues and increased operating expenses.

[0001511737-13-000006:mdna:11]
[same as prior period, unchanged from 0001445305-13-000191:mdna:8]

[0001511737-13-000006:mdna:12]
[same as prior period, unchanged from 0001445305-13-000191:mdna:9]

[0001511737-13-000006:mdna:13]
[same as prior period, unchanged from 0001445305-13-000191:mdna:10]

[0001511737-13-000006:mdna:14]
[same as prior period, unchanged from 0001445305-13-000191:mdna:11]

[0001511737-13-000006:mdna:15]
[same as prior period, unchanged from 0001445305-13-000191:mdna:12]

[0001511737-13-000006:mdna:16]
[same as prior period, unchanged from 0001445305-13-000191:mdna:13]

[0001511737-13-000006:mdna:17]
[same as prior period, unchanged from 0001445305-13-000191:mdna:14]

[0001511737-13-000006:mdna:18]
[same as prior period, unchanged from 0001445305-13-000191:mdna:15]

[0001511737-13-000006:mdna:19]
[same as prior period, unchanged from 0001445305-13-000191:mdna:16]

[0001511737-13-000006:mdna:20]
[same as prior period, unchanged from 0001445305-13-000191:mdna:17]

[0001511737-13-000006:mdna:21]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 98% and 99% of our revenues in the three months ended March 31, 2013 and 2012, respectively. Sales to distributors accounted for 97% and 98% of our revenues in the nine months ended March 31, 2013 and 2012, respectively. Other channel partners, such as resellers and OEMs, largely accounted for the balance of our revenues. We sell our products without any right of return.

[0001511737-13-000006:mdna:22]
[same as prior period, unchanged from 0001445305-13-000191:mdna:19]

[0001511737-13-000006:mdna:23]
Our cost of revenues is comprised primarily of the costs of procuring finished goods from our contract manufacturers and chipsets that we consign to certain of our contract manufacturers. In addition, cost of revenues includes tooling, labor and other costs associated with engineering, testing and quality assurance, warranty costs, stock-based compensation, logistics related fees and excess and obsolete inventory.

[0001511737-13-000006:mdna:24]
[same as prior period, unchanged from 0001445305-13-000191:mdna:21]

[0001511737-13-000006:mdna:25]
[same as prior period, unchanged from 0001445305-13-000191:mdna:22]

[0001511737-13-000006:mdna:26]
[same as prior period, unchanged from 0001445305-13-000191:mdna:23]

[0001511737-13-000006:mdna:27]
[same as prior period, unchanged from 0001445305-13-000191:mdna:24]

[0001511737-13-000006:mdna:28]
[same as prior period, unchanged from 0001445305-13-000191:mdna:25]

[0001511737-13-000006:mdna:29]
[same as prior period, unchanged from 0001445305-13-000191:mdna:26]

[0001511737-13-000006:mdna:30]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well |

[0001511737-13-000006:mdna:31]
18

[0001511737-13-000006:mdna:32]
as the costs of outside legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our registration and defense of trademarks and patents efforts and to support our business and operations as a public company.

[0001511737-13-000006:mdna:33]
[same as prior period, unchanged from 0001445305-13-000191:mdna:29]

[0001511737-13-000006:mdna:34]
In the event that collectability of a receivable from products we have shipped is not probable, we classify those amounts as deferred revenues on our balance sheet until such time as we receive payment of the accounts receivable. We classify the cost of products associated with these deferred revenues as deferred costs of revenues. At March 31, 2013, $984,000 of revenue was deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably probable. The related deferred cost of revenues balance was $541,000 as of March 31, 2013.  At June 30, 2012, we did not have any revenue deferred for transactions where we lacked evidence that collectability of the receivables recorded was reasonably probable.

[0001511737-13-000006:mdna:35]
Also included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of March 31, 2013 and June 30, 2012, we had deferred revenues of  $857,000 and $805,000 respectively, related to these obligations.

[0001511737-13-000006:mdna:36]
[same as prior period, unchanged from 0001445305-13-000191:mdna:34]

[0001511737-13-000006:mdna:37]
[same as prior period, unchanged from 0001445305-13-000191:mdna:35]

[0001511737-13-000006:mdna:38]
[same as prior period, unchanged from 0001445305-13-000191:mdna:37]

[0001511737-13-000006:mdna:39]
Comparison of Three and Nine Months Ended March 31, 2013 and 2012

[0001511737-13-000006:mdna:40]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (In thousands, except percentages) |
| Revenues | $ | 83,155 |  |  | 100 | % |  | $ | 91,665 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |  | $ | 258,649 |  |  | 100 | % |
| Cost of revenues | 47,690 |  |  | 57 | % |  | 52,006 |  |  | 57 | % |  | 128,621 |  |  | 59 | % |  | 148,687 |  |  | 57 | % |
| Gross profit | 35,465 |  |  | 43 | % |  | 39,659 |  |  | 43 | % |  | 90,970 |  |  | 41 | % |  | 109,962 |  |  | 43 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 5,677 |  |  | 7 | % |  | 4,619 |  |  | 5 | % |  | 15,440 |  |  | 7 | % |  | 11,671 |  |  | 5 | % |
| Sales, general and administrative | 6,285 |  |  | 8 | % |  | 2,484 |  |  | 3 | % |  | 16,133 |  |  | 7 | % |  | 7,059 |  |  | 3 | % |
| Total operating expenses | 11,962 |  |  | 15 | % |  | 7,103 |  |  | 8 | % |  | 31,573 |  |  | 14 | % |  | 18,730 |  |  | 8 | % |
| Income from operations | 23,503 |  |  | 28 | % |  | 32,556 |  |  | 35 | % |  | 59,397 |  |  | 27 | % |  | 91,232 |  |  | 35 | % |
| Interest expense and other, net | (287 | ) |  | * |  |  | (190 | ) |  | * |  |  | (570 | ) |  | * |  |  | (1,136 | ) |  | * |  |
| Income before provision for income taxes | 23,216 |  |  | 28 | % |  | 32,366 |  |  | 35 | % |  | 58,827 |  |  | 27 | % |  | 90,096 |  |  | 35 | % |
| Provision for income taxes | 2,549 |  |  | 3 | % |  | 4,446 |  |  | 5 | % |  | 7,178 |  |  | 3 | % |  | 15,992 |  |  | 6 | % |
| Net income | $ | 20,667 |  |  | 25 | % |  | $ | 27,920 |  |  | 30 | % |  | $ | 51,649 |  |  | 24 | % |  | $ | 74,104 |  |  | 29 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 124 |  |  |  |  | $ | 41 |  |  |  |  | $ | 309 |  |  |  |  | $ | 74 |  |  |  |
| Research and development | 324 |  |  |  |  | 133 |  |  |  |  | 991 |  |  |  |  | 365 |  |  |  |
| Sales, general and administrative | 252 |  |  |  |  | 156 |  |  |  |  | 949 |  |  |  |  | 593 |  |  |  |
| Total stock-based compensation | $ | 700 |  |  |  |  | $ | 330 |  |  |  |  | $ | 2,249 |  |  |  |  | $ | 1,032 |  |  |  |

[0001511737-13-000006:mdna:41]
[same as prior period, unchanged from 0001445305-13-000191:mdna:40]

[0001511737-13-000006:mdna:42]
Revenues decreased $8.5 million, or 9%, from $91.7 million in the three months ended March 31, 2012 to $83.2 million in the three months ended March 31, 2013.  Revenues decreased $39.1 million, or 15%, from $258.6 million in the nine months ended March 31, 2012 to $219.6 million in the nine months ended March 31, 2013.  We believe the overall decrease in revenues during the three and nine months ended March 31, 2013 was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, which also created customer uncertainty regarding the authenticity of their potential purchases.  We believe these factors contributed to a buildup in channel inventory with our distributors, further impacting our revenues.  This has had the most significant impact on our airMAX platform which decreased $6.4 million and $28.4 million, respectively, in the three and nine months ended March 31, 2013 compared to the same periods in the prior year.

[0001511737-13-000006:mdna:43]
In the three months ended March 31, 2013, revenues from Customer A represented 15% of our revenues.  In the three months ended March 31, 2012, revenues from Customer A and Customer B represented 20% and 10% of our revenues, respectively.  In the nine months ended March 31, 2013, revenues from Customer A represented 13% of our revenues. In the nine months ended March 31, 2012, revenues from Customer A and Customer C represented 19% and 10% of our revenues, respectively.

[0001511737-13-000006:mdna:44]
[same as prior period, unchanged from 0001445305-13-000191:mdna:43]

[0001511737-13-000006:mdna:45]
[same as prior period, unchanged from 0001445305-13-000191:mdna:44]

[0001511737-13-000006:mdna:46]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (in thousands, except percentages) |
| airMAX | $ | 55,534 |  |  | 67 | % |  | $ | 61,978 |  |  | 68 | % |  | $ | 136,343 |  |  | 62 | % |  | $ | 164,752 |  |  | 64 | % |
| New platforms | 11,825 |  |  | 14 | % |  | 9,914 |  |  | 11 | % |  | 39,358 |  |  | 18 | % |  | 16,874 |  |  | 6 | % |
| Other systems | 4,108 |  |  | 5 | % |  | 10,308 |  |  | 11 | % |  | 12,727 |  |  | 6 | % |  | 41,327 |  |  | 16 | % |
| Systems | 71,467 |  |  | 86 | % |  | 82,200 |  |  | 90 | % |  | 188,428 |  |  | 86 | % |  | 222,953 |  |  | 86 | % |
| Embedded radio | 1,721 |  |  | 2 | % |  | 2,232 |  |  | 2 | % |  | 4,954 |  |  | 2 | % |  | 8,024 |  |  | 3 | % |
| Antennas/other | 9,967 |  |  | 12 | % |  | 7,233 |  |  | 8 | % |  | 26,209 |  |  | 12 | % |  | 27,672 |  |  | 11 | % |
| Total revenues | $ | 83,155 |  |  | 100 | % |  | $ | 91,665 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |  | $ | 258,649 |  |  | 100 | % |

[0001511737-13-000006:mdna:47]
Systems revenues decreased $10.7 million, or 13%, from $82.2 million in the three months ended March 31, 2012 to $71.5 million in the three months ended March 31, 2013.  Systems revenues decreased $34.5 million, or 15%, from $223.0 million in the nine months ended March 31, 2012 to $188.4 million in the nine months ended March 31, 2013.  As noted above, we believe the decrease in systems revenues was primarily driven by lost sales due to the proliferation of counterfeit versions of our products, in particular our airMAX product line. The decrease in our airMAX product line was partially offset by increased sales in our new platforms category, which includes platforms introduced since late fiscal 2011. Our new platforms contributed $11.8 million and $9.9 million of revenue during the three months ended March 31, 2013 and 2012, respectively, and $39.4 million and $16.9 million of revenue during the nine months ended March 31, 2013 and 2012, respectively. Our other systems revenue decreased $6.2 million during the three months ended March 31, 2013 as compared to the three months ended March 31, 2012 due to further adoption of our airMax solutions. Our other systems revenue decreased $28.6 million during the nine months ended March 31, 2013 as compared to the nine months ended March 31, 2012 due primarily to our December 2011 quarter including a large order to a single direct customer and further adoption of our airMax solutions in 2013.  We anticipate that our other systems products will decline in future periods as sales of these products are outpaced by airMax and new platform products.

[0001511737-13-000006:mdna:48]
Embedded radio revenues decreased $511,000, or 23%, from $2.2 million in the three months ended March 31, 2012 to $1.7 million in the three months ended March 31, 2013, and decreased $3.1 million, or 38%, from $8.0 million in the nine months ended March 31, 2012 to $5.0 million in the nine months ended March 31, 2013. We anticipate that embedded radio products will decline as a percentage of revenues in future periods as sales of these legacy products are outpaced by sales of systems products.

[0001511737-13-000006:mdna:49]
Antennas/other revenues increased $2.7 million, or 38% from $7.2 million in the three months ended March 31, 2012 to $10.0 million in the three months ended March 31, 2013.  Antennas/other revenues decreased $1.5 million, or 5% from $27.7 million in the nine months ended March 31, 2012 to $26.2 million in the nine months ended March 31, 2013. The increase in antennas/other revenues during the three months ended March 31, 2013 was due primarily to continued expansion of core infrastructure build-outs in our wireless markets. The decline in antennas/other revenues during nine months ended March 31, 2013 was primarily due to the decreased sales of our systems platforms, which negatively impacted the demand for associated antennas. Other revenues also include revenues that are attributable to PCS.  We anticipate that antenna/other revenues will decline as a percentage of total revenues due to more rapid growth of systems revenues.

[0001511737-13-000006:mdna:50]
[same as prior period, unchanged from 0001445305-13-000191:mdna:49]

[0001511737-13-000006:mdna:51]
[same as prior period, unchanged from 0001445305-13-000191:mdna:50]

[0001511737-13-000006:mdna:52]
We generally forward products directly from our manufacturers to our customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, our products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, our products were predominantly delivered to our customers through distribution hubs in Hong Kong.  Our logistics provider, in turn, ships to other locations throughout the world. We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers.  For the three months ended March 31, 2013, revenues in North America increased primarily due to the three months ended March 31, 2012 being impacted by our customers' ordering patterns as we had introduced our U.S.-specific products. We believe the decline in revenues in the South America and Europe, Middle East and Africa regions in the three months ended March 31, 2013 and the decline in revenue in all regions during the nine months ended March 31, 2013 as compared to the same periods in the prior year was primarily driven by the proliferation of counterfeit versions of our products, which has also created customer uncertainty regarding the authenticity of their potential purchases. Revenues in the Asia Pacific region tend to be volatile given their low levels. The following are our revenues by geography for the three and nine months ended March 31, 2013 and 2012 (in thousands, except percentages):

[0001511737-13-000006:mdna:53]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| North America(1) | $ | 21,052 |  |  | 25 | % |  | $ | 16,647 |  |  | 18 | % |  | $ | 53,519 |  |  | 24 | % |  | $ | 63,028 |  |  | 24 | % |
| South America | 18,496 |  |  | 22 | % |  | 27,666 |  |  | 30 | % |  | 45,820 |  |  | 21 | % |  | 71,751 |  |  | 28 | % |
| Europe, the Middle East and Africa | 31,617 |  |  | 38 | % |  | 36,398 |  |  | 40 | % |  | 90,690 |  |  | 41 | % |  | 91,537 |  |  | 35 | % |
| Asia Pacific | 11,990 |  |  | 15 | % |  | 10,954 |  |  | 12 | % |  | 29,562 |  |  | 14 | % |  | 32,333 |  |  | 13 | % |
| Total revenues | $ | 83,155 |  |  | 100 | % |  | $ | 91,665 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |  | $ | 258,649 |  |  | 100 | % |

[0001511737-13-000006:mdna:54]
| (1) | Revenue for the United States was $19.7 million and $14.9 million for the three months ended March 31, 2013 and 2012, respectively. Revenue for the United States was $50.5 million and $60.0 million for the nine months ended March 31, 2013 and 2012, respectively. |

[0001511737-13-000006:mdna:55]
[same as prior period, unchanged from 0001445305-13-000191:mdna:54]

[0001511737-13-000006:mdna:56]
Cost of revenues decreased $4.3 million, or 8%, from $52.0 million in the three months ended March 31, 2012 to $47.7 million in the three months ended March 31, 2013.  Cost of revenues decreased $20.1 million, or 13%, from $148.7 million in the nine months ended March 31, 2012 to $128.6 million in the nine months ended March 31, 2013.  The decreases in cost of revenues in both the three and nine months ended March 31, 2013 was primarily due to decreased revenues and to a lesser extent, changes in product mix, partially offset by increased warranty costs of approximately $1.0 million incurred during the three months ended March 31, 2013 related to the recall of our Rocket Titanium products due to an identified manufacturing issue which was subsequently rectified.

[0001511737-13-000006:mdna:57]
Gross profit remained flat at 43% in the three months ended March 31, 2013 as compared to the three months ended March 31, 2012. Gross profit decreased from 43% in the nine months ended March 31, 2012 to 41% in the nine months ended March 31, 2013. The decrease in gross profit in the nine months ended March 31, 2013 reflects increases in variable operating costs and changes in product mix.

[0001511737-13-000006:mdna:58]
[same as prior period, unchanged from 0001445305-13-000191:mdna:57]

[0001511737-13-000006:mdna:59]
[same as prior period, unchanged from 0001445305-13-000191:mdna:58]

[0001511737-13-000006:mdna:60]
Research and development expenses increased $1.1 million, or 23%, from $4.6 million in the three months ended March 31, 2012 to $5.7 million in the three months ended March 31, 2013. As a percentage of revenues, research and development expenses increased from 5% in the three months ended March 31, 2012 to 7% in the three months ended March 31, 2013. Research and development expenses increased $3.8 million, or 32%, from $11.7 million in the nine months ended March 31, 2012 to $15.4 million in the nine months ended March 31, 2013. As a percentage of revenues, research and development expenses increased from 5% in the nine months ended March 31, 2012 to 7% in the nine months ended March 31, 2013. The increase in research and development expenses in absolute dollars in both periods was due to increases in headcount as we broadened our research and development activities to new product areas. As a percentage of revenues, research and development expenses increased in both periods primarily due to our overall decrease in revenues. Over time, we expect our research and development costs to increase in absolute dollars as we continue making significant investments in developing new products and developing new versions of our existing products.

[0001511737-13-000006:mdna:61]
22

[0001511737-13-000006:mdna:62]
[same as prior period, unchanged from 0001445305-13-000191:mdna:60]

[0001511737-13-000006:mdna:63]
Sales, general and administrative expenses increased $3.8 million, or 153%, from $2.5 million in the three months ended March 31, 2012 to $6.3 million in the three months ended March 31, 2013. As a percentage of revenues, sales, general and administrative expenses increased from 3% in the three months ended March 31, 2012 to 8% in the three months ended March 31, 2013. Sales, general and administrative expenses increased $9.1 million, or 129%, from $7.1 million in the nine months ended March 31, 2012 to $16.1 million in the nine months ended March 31, 2013. As a percentage of revenues, sales, general and administrative expenses increased from 3% in the nine months ended March 31, 2012 to 7% in the nine months ended March 31, 2013. Sales, general and administrative expenses increased in both periods due largely to increased legal expenses associated with our anti-counterfeiting litigation, increased marketing and tradeshow activity and increases in our bad debt allowance. As a percentage of revenues sales, general and administrative expenses increased in both periods primarily due to our overall revenue decrease in revenues and increased legal expenses associated with our anti-counterfeiting litigation. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued efforts to protect our intellectual property and growth in headcount to support our business and operations.

[0001511737-13-000006:mdna:64]
[same as prior period, unchanged from 0001445305-13-000191:mdna:63]

[0001511737-13-000006:mdna:65]
Interest expense and other, net was $287,000 for the three months ended March 31, 2013, representing an increase of $97,000 from $190,000 for the three months ended March 31, 2012. Interest expense and other, net was $570,000 for the nine months ended March 31, 2013, representing a decrease of $566,000 from $1.1 million for the nine months ended March 31, 2012. The increase in interest expense and other, net during the three months ended March 31, 2013 compared to the same period in the prior year was primarily due to additional interest expense resulting from our borrowings from East West Bank during the three months ended December 31, 2012.  The decrease in nine months ended March 31, 2013 as compared to the same period in the prior year was primarily due to additional interest expense on our convertible subordinated promissory notes issued as part of the repurchase of Series A convertible preferred stock from entities affiliated with Summit Partners, L.P. in July 2011.  The convertible subordinated promissory notes were repaid in full in October 2011.

[0001511737-13-000006:mdna:66]
[same as prior period, unchanged from 0001445305-13-000191:mdna:65]

[0001511737-13-000006:mdna:67]
Our provision for income taxes decreased $1.9 million, or 43%, from $4.4 million for the three months ended March 31, 2012 to $2.5 million for the three months ended March 31, 2013. Our provision for income taxes decreased $8.8 million, or 55%, from $16.0 million for the nine months ended March 31, 2012 to $7.2 million for the nine months ended March 31, 2013. Our effective tax rate decreased to 11% for the three months ended March 31, 2013 as compared to 14% the three months ended March 31, 2012.   Our effective tax rate decreased to 12% for the nine months ended March 31, 2013 as compared to 18% the nine months ended March 31, 2012.   The decrease in the effective tax rates during both periods was primarily due to a larger percentage of our overall profitability occurring in foreign jurisdictions with lower income tax rates.  On January 2, 2013, the American Taxpayer Relief Act of 2012 ("the Act") was signed into law. One of the provisions of the Act provides a retroactive extension of the research and experimentation tax credit ("R&D credit") through December 31, 2013, which had expired on December 31, 2011.  We recognized a tax benefit of $539,000 during the third quarter of fiscal 2013 as a result of the retroactive extension of the R&D credit.

[0001511737-13-000006:mdna:68]
[same as prior period, unchanged from 0001445305-13-000191:mdna:67]

[0001511737-13-000006:mdna:69]
[same as prior period, unchanged from 0001445305-13-000191:mdna:68]

[0001511737-13-000006:mdna:70]
Since inception, our operations primarily have been funded through cash generated by operations. Cash and cash equivalents increased from $122.1 million at June 30, 2012 to $181.7 million at March 31, 2013.

[0001511737-13-000006:mdna:71]
[same as prior period, unchanged from 0001445305-13-000191:mdna:70]

[0001511737-13-000006:mdna:72]
[same as prior period, unchanged from 0001445305-13-000191:mdna:71]

[0001511737-13-000006:mdna:73]
|  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 85,684 |  |  | $ | 51,703 |  |
| Net cash used in investing activities | (4,408 | ) |  | (1,617 | ) |
| Net cash used in financing activities | (21,647 | ) |  | (32,247 | ) |
| Net increase in cash and cash equivalents | $ | 59,629 |  |  | $ | 17,839 |  |

[0001511737-13-000006:mdna:74]
[same as prior period, unchanged from 0001445305-13-000191:mdna:73]

[0001511737-13-000006:mdna:75]
Net cash provided by operating activities in the nine months ended March 31, 2013 of $85.7 million consisted primarily of net income of $51.6 million and net changes in operating assets and liabilities that resulted in net cash inflows of $28.1 million. These changes consisted primarily of a $35.6 million decrease in accounts receivable due to decreased revenues and improved cash collections, a $12.7 million increase in inventory due to increased inventory on hand as a result of a transition to a third-party logistics provider during December 2012, a $3.7 million increase in taxes payable due the timing of federal tax payments, a $2.5 million increase in accounts payable and accrued liabilities due to the timing of payments with our vendors and a $1.5 million increase in prepaid expenses and other current assets due to an increase in overall business activity. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for doubtful accounts and write-downs for inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $5.9 million.

[0001511737-13-000006:mdna:76]
Net cash provided by operating activities in the nine months ended March 31, 2012 of $51.7 million consisted primarily of net income of $74.1 million partially offset by changes in operating assets and liabilities.  These changes consisted primarily of a $29.4 million increase in accounts receivable due to our overall revenue growth, a $12.4 million increase in taxes payable, a $4.8 million decrease in prepaid expenses and other current assets, a $4.0 million increase in inventories, a $1.9 million increase in accounts payable and accrued liabilities, and an increase of $700,000 in deferred revenues and deferred cost of revenues.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, adjustments to our provisions for doubtful accounts and inventory obsolescence and an excess tax benefit from stock-based awards. The net of these non-cash adjustments resulted in a reduction of our net cash provided by operating activities of $8.8 million.

[0001511737-13-000006:mdna:77]
[same as prior period, unchanged from 0001445305-13-000191:mdna:78]

[0001511737-13-000006:mdna:78]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the nine months ended March 31, 2013 and 2012 were $3.3 million and $1.6 million, respectively. Additionally, we had cash outflows related to the purchase of intangible assets of $1.1 million during the nine months ended March 31, 2013.

[0001511737-13-000006:mdna:79]
[same as prior period, unchanged from 0001445305-13-000191:mdna:80]

[0001511737-13-000006:mdna:80]
On August 7, 2012, we entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed below. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). We may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility, and no borrowings remain available thereunder.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012, we borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-13-000006:mdna:81]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict our and

[0001511737-13-000006:mdna:82]
[same as prior period, unchanged from 0001445305-13-000191:mdna:83]

[0001511737-13-000006:mdna:83]
[same as prior period, unchanged from 0001445305-13-000191:mdna:84]

[0001511737-13-000006:mdna:84]
[same as prior period, unchanged from 0001445305-13-000191:mdna:85]

[0001511737-13-000006:mdna:85]
each case subject to customary exceptions for a credit facility of this size and type. We are also required to maintain a

[0001511737-13-000006:mdna:86]
minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio. As of March 31, 2013, we

[0001511737-13-000006:mdna:87]
were in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and minimum level

[0001511737-13-000006:mdna:88]
[same as prior period, unchanged from 0001445305-13-000191:mdna:89]

[0001511737-13-000006:mdna:89]
On August 9, 2012, we announced that our Board of Directors authorized us to repurchase up to $100.0 million of our common stock. The share repurchase program commenced August 13, 2012. During the nine months ended March 31, 2013 we repurchased 5,159,050 shares for a total cost of $54.4 million.

[0001511737-13-000006:mdna:90]
[same as prior period, unchanged from 0001445305-13-000191:mdna:91]

[0001511737-13-000006:mdna:91]
[same as prior period, unchanged from 0001445305-13-000191:mdna:94]

[0001511737-13-000006:mdna:92]
[same as prior period, unchanged from 0001445305-13-000191:mdna:92]

[0001511737-13-000006:mdna:93]
On September 15, 2011, we entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”). The EWB Loan Agreement consisted of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan was scheduled to mature on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. During the three months ended September 30, 2011, we used $34.0 million of the term loan to repay a portion of our outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P. The EWB Agreement was replaced by the Loan Agreement on August 7, 2012 as discussed above.

[0001511737-13-000006:mdna:94]
[same as prior period, unchanged from 0001445305-13-000191:mdna:96]

[0001511737-13-000006:mdna:95]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of March 31, 2013, we held $170.2 million of our $181.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-13-000006:mdna:96]
Commitments and Contingencies

[0001511737-13-000006:mdna:97]
[same as prior period, unchanged from 0001445305-13-000191:mdna:99]

[0001511737-13-000006:mdna:98]
[same as prior period, unchanged from 0001445305-13-000191:mdna:100]

[0001511737-13-000006:mdna:99]
OFAC is still reviewing our voluntary disclosure. In our submission, we have provided OFAC with an explanation of the activities that led to the sales of our products in Iran and the failure to comply with the EAR and OFAC sanctions. Although our

[0001511737-13-000006:mdna:100]
25

[0001511737-13-000006:mdna:101]
OFAC and OEE voluntary disclosures covered similar sets of facts, which led OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that our actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of our ability to export our products and/or referral for criminal prosecution. The penalties may be imposed against us and/or our management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to our financial results in the period in which they are imposed.  Also, disclosure of our conduct and any fines or other action relating to this conduct could harm our reputation and have a material adverse effect on our business. We cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001511737-13-000006:mdna:102]
While we have taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner and have adopted policies and procedures to promote our compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of our distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of our distributors of their obligations and obtaining updated distribution agreements from distributors that account for over 99% of our revenue in fiscal 2012.  However we cannot be sure such actions will be effective.  Additionally, our failure to amend all our distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on us or our management.  Based on the facts known to us to date, we recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature.  This amount was calculated from information discovered through our internal review and we deem this loss to be probable and reasonably estimable. However, we believe that it is reasonably possible that the loss may be higher, but we cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from our estimates, our business, financial condition, cash flows and results of operations would be materially negatively impacted.

[0001511737-13-000006:mdna:103]
[same as prior period, unchanged from 0001445305-13-000191:mdna:104]

[0001511737-13-000006:mdna:104]
Our products are generally accompanied by a 12 month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-13-000006:mdna:105]
[same as prior period, unchanged from 0001445305-13-000191:mdna:106]

[0001511737-13-000006:mdna:106]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a director and officer insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal. We had not recorded any liabilities for these agreements as of March 31, 2013 or 2012.

[0001511737-13-000006:mdna:107]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at March 31, 2013.

[0001511737-13-000006:mdna:108]
[same as prior period, unchanged from 0001445305-13-000191:mdna:109]

[0001511737-13-000006:mdna:109]
We lease our headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through fiscal 2018.

[0001511737-13-000006:mdna:110]
In December 2011, we entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which we use as our corporate headquarters. The lease term is from April 1,

[0001511737-13-000006:mdna:111]
2012, though July 31, 2017. The lease has been categorized as an operating lease, and the total estimated lease obligation is approximately $4.9 million.

[0001511737-13-000006:mdna:112]
On August 7, 2012, we entered into the Loan Agreement with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million Term Loan Facility. We may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, we borrowed $20.8 million of term loans under the Term Loan Facility bringing the total borrowed to  $50.0 million, and no borrowings remain available thereunder.  On November 21, 2012, we borrowed $10.0 million under the Revolving Credit Facility.  On December 20, 2012 we borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-13-000006:mdna:113]
The following table summarizes our contractual obligations as of March 31, 2013:

[0001511737-13-000006:mdna:114]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Operating leases | $ | 407 |  |  | $ | 1,712 |  |  | $ | 1,678 |  |  | $ | 1,638 |  |  | $ | 1,129 |  |  | $ | 94 |  |  | $ | 6,658 |  |
| Debt payment obligations | 1,250 |  |  | 5,000 |  |  | 6,875 |  |  | 39,375 |  |  | 10,000 |  |  | 15,000 |  |  | 77,500 |  |
| Interest payments on debt payment obligations | 472 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,754 |  |
| Total | $ | 2,129 |  |  | $ | 8,571 |  |  | $ | 10,276 |  |  | $ | 42,056 |  |  | $ | 11,661 |  |  | $ | 15,219 |  |  | $ | 89,912 |  |

[0001511737-13-000006:mdna:115]
[same as prior period, unchanged from 0001445305-13-000191:mdna:116]

[0001511737-13-000006:mdna:116]
As of March 31, 2013, we had $10.4 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-13-000006:mdna:117]
[same as prior period, unchanged from 0001445305-13-000191:mdna:118]

[0001511737-13-000006:mdna:118]
[same as prior period, unchanged from 0001445305-13-000191:mdna:119]

[0001511737-13-000006:mdna:119]
[same as prior period, unchanged from 0001445305-13-000191:mdna:120]

[0001511737-13-000006:mdna:120]
[same as prior period, unchanged from 0001445305-13-000191:mdna:121]

[0001511737-13-000006:mdna:121]
[same as prior period, unchanged from 0001445305-13-000191:mdna:122]

[0001511737-13-000006:mdna:122]
[same as prior period, unchanged from 0001445305-13-000191:mdna:123]

[0001511737-13-000006:mdna:123]
[same as prior period, unchanged from 0001445305-13-000191:mdna:126]

[0001511737-13-000006:mdna:124]
[same as prior period, unchanged from 0001445305-13-000191:mdna:124]

[0001511737-13-000006:mdna:125]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income | $ | 21,087 |  |  | $ | 28,118 |  |  | $ | 52,998 |  |  | $ | 74,723 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.58 |  |  | $ | 0.80 |  |

[0001511737-13-000006:mdna:126]
[same as prior period, unchanged from 0001445305-13-000191:mdna:127]

[0001511737-13-000006:mdna:127]
[same as prior period, unchanged from 0001445305-13-000191:mdna:128]

[0001511737-13-000006:mdna:128]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (In thousands, except pershare amounts) |
| Net Income | $ | 20,667 |  |  | $ | 27,920 |  |  | $ | 51,649 |  |  | $ | 74,104 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 124 |  |  | 41 |  |  | 309 |  |  | 74 |  |
| Research and development | 324 |  |  | 133 |  |  | 991 |  |  | 365 |  |
| Sales, general and administrative | 252 |  |  | 156 |  |  | 949 |  |  | 593 |  |
| Tax effect of non-GAAP adjustments | (280 | ) |  | (132 | ) |  | (900 | ) |  | (413 | ) |
| Non-GAAP net income | $ | 21,087 |  |  | $ | 28,118 |  |  | $ | 52,998 |  |  | $ | 74,723 |  |
| Non-GAAP diluted net income per share of common stock (1) | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.58 |  |  | $ | 0.80 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock (1) | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 93,667 |  |

[0001511737-13-000006:mdna:129]
[same as prior period, unchanged from 0001445305-13-000191:mdna:130]

[0001511737-13-000006:mdna:130]
[same as prior period, unchanged from 0001445305-13-000191:mdna:131]

[0001511737-13-000006:mdna:131]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  | (In thousands) |  | (In thousands) |
| Weighted average shares used in computing net loss per share of common stock- diluted | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 80,648 |  |
| Weighted average dilutive effect of stock options and restricted stock units | — |  |  | — |  |  | — |  |  | 2,895 |  |
| Weighted average shares of Series A preferred stock outstanding | — |  |  | — |  |  | — |  |  | 10,124 |  |
| Weighted-average shares used in computing non-GAAP diluted income per share of common stock | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 93,667 |  |

[0001511737-13-000006:mdna:132]
28
