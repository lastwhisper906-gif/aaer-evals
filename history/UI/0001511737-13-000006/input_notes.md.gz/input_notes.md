# UI notes — 0001511737-13-000006


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-13-000006:notes:1]
[same as prior period, unchanged from 0001445305-13-000191:notes:1]

[0001511737-13-000006:notes:2]
[same as prior period, unchanged from 0001445305-13-000191:notes:2]

[0001511737-13-000006:notes:3]
[same as prior period, unchanged from 0001445305-13-000191:notes:3]

[0001511737-13-000006:notes:4]
[same as prior period, unchanged from 0001445305-13-000191:notes:4]

[0001511737-13-000006:notes:5]
[same as prior period, unchanged from 0001445305-13-000191:notes:5]

[0001511737-13-000006:notes:6]
[same as prior period, unchanged from 0001445305-13-000191:notes:6]

[0001511737-13-000006:notes:7]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2012 included in its Annual Report on Form 10-K, as filed on September 28, 2012 with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2013 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001511737-13-000006:notes:8]
[same as prior period, unchanged from 0001445305-13-000191:notes:8]

[0001511737-13-000006:notes:9]
[same as prior period, unchanged from 0001445305-13-000191:notes:9]

[0001511737-13-000006:notes:10]
|  | March 31, 2013 |  | June 30, 2012 |
| Cash | $ | 16,447 |  |  | $ | 13,832 |  |
| Money market funds | 165,242 |  |  | 108,228 |  |
|  | $ | 181,689 |  |  | $ | 122,060 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-13-000006:notes:11]
COMMITMENTS AND CONTINGENCIES

[0001511737-13-000006:notes:12]
Operating Leases

[0001511737-13-000006:notes:13]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2018.

[0001511737-13-000006:notes:14]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which the Company uses as its corporate headquarters. The lease term is from April 1, 2012, through  July 31, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.

[0001511737-13-000006:notes:15]
At March 31, 2013, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-13-000006:notes:16]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Operating leases | $ | 407 |  |  | $ | 1,712 |  |  | $ | 1,678 |  |  | $ | 1,638 |  |  | $ | 1,129 |  |  | $ | 94 |  |  | $ | 6,658 |  |

[0001511737-13-000006:notes:17]
Purchase Commitments

[0001511737-13-000006:notes:18]
The Company subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded. The Company’s consolidated financial position and results of operations could be negatively impacted if it were required to compensate the contract manufacturers for any liabilities incurred.

[0001511737-13-000006:notes:19]
Indemnification Obligations

[0001511737-13-000006:notes:20]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-13-000006:notes:21]
Legal Matters

[0001511737-13-000006:notes:22]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded. Litigation can be costly, diverting management’s attention and could, upon resolution, have a material adverse effect on the Company’s business, results of operations, financial condition, and cash flows.

[0001511737-13-000006:notes:23]
Export Compliance Matters

[0001511737-13-000006:notes:24]
In January 2011, the U.S. Commerce Department, Bureau of Industry and Security’s (“BIS”) Office of Export Enforcement (“OEE”) contacted the Company to request that the Company provide information related to its relationship with a logistics company in the United Arab Emirates (“UAE”) and with a company in Iran, as well as information on the export classification of its products. As a result of this inquiry the Company, assisted by outside counsel, conducted a review of the Company's export transactions from 2008 through March 2011 to not only gather information responsive to the OEE's request but also to review the Company's overall compliance with export control and sanctions laws.  The Company believes its products have been sold into Iran by third parties. The Company does not believe that it directly sold, exported or shipped its products into Iran or any other country subject to a U.S. embargo. However, until early 2010, the Company did not prohibit its distributors from selling its products into Iran or any other country subject to a U.S. embargo. In the course of this review the Company identified that two distributors may have sold the Company's products into Iran. The Company's review also found that while it had obtained required Commodity Classification Rulings for its products in June 2010 and November 2010, the Company did not advise its shipping personnel to change the export authorizations used on its shipping documents until February 2011. During the course of the Company's export control review, the Company also determined that it had failed to maintain adequate records for the five year period required by the EAR and the sanctions regulations due to its lack of infrastructure and because it was prior to its transition to its current system of record, NetSuite.

[0001511737-13-000006:notes:25]
In May 2011, the Company filed a self-disclosure statement with the BIS and OEE.  In June 2011, the Company filed a self-disclosure statement with the U.S. Department of the Treasury’s Office of Foreign Asset Control (“OFAC”) regarding the compliance issues noted above. The disclosures address the above described findings and the remedial actions the Company had taken to date. However, the findings also indicate that both distributors continued to sell, directly or indirectly, the Company’s products into Iran during the period from February 2010 through March 2011 and that the Company received various communications from them indicating that they were continuing to do so. Since January 2011, the Company has cooperated with OEE and, prior to its disclosure filing, the Company informally shared with the OEE the substance of its findings with respect to both distributors. From May 2011 to August 2011, the Company provided additional information regarding its review and its findings to OEE to facilitate its investigation and OEE advised the Company in August 2011 that it had completed its investigation of the Company. In August 2011, the Company received a warning letter from OEE stating that OEE had not referred the findings of the Company’s review for criminal or administrative prosecution and closed the investigation of the Company without penalty.

[0001511737-13-000006:notes:26]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the “EAR”) and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

[0001511737-13-000006:notes:27]
While the Company has taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner and has adopted policies and procedures to promote its compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2012.  However the Company cannot be sure such actions will be effective.  Additionally, the Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.

[0001511737-13-000006:notes:28]
Shareholder Class Action Lawsuits

[0001511737-13-000006:notes:29]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs. On March 26, 2013, the Company filed a motion to dismiss the complaint.  On April 30, 2013, the plaintiffs filed an opposition to the Company's motion to dismiss.

[0001511737-13-000006:notes:30]
The Company believes that the allegations in the consolidated complaint are without merit and intend to vigorously contest the litigation. However, there can be no assurance that the Company will be successful in its defense. Because the case is at a very early stage, the Company cannot currently estimate the loss or the range of possible losses we may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-13-000006:notes:31]
DEBT

[0001511737-13-000006:notes:32]
In July 2011, the Company repurchased an aggregate of 12,041,700 shares of the Company’s Series A convertible preferred stock from entities affiliated with Summit Partners, L.P., one of the Company’s major stockholders, at a price of $8.97 per share for an aggregate consideration of $108.0 million. Of the aggregate purchase price, $40.0 million was paid in cash at the time of closing and the balance of the shares were paid for through the issuance of convertible subordinated promissory notes in the aggregate principal amount of $68.0 million. On September 15, 2011, $34.0 million was paid against the notes and was financed through the Company's EWB Loan Agreement (as further described below) reducing the aggregate principal amount outstanding to $34.0 million. The remainder of the notes were retired in October 2011 with the proceeds of the Company’s initial public offering and existing cash balances. The interest rate on the notes started at 5% per annum and increased by two percentage points every three months until it would have reached 9% in January 2012. The notes were prepayable without penalty prior to April 21, 2012, and were required to be paid in the event of the Company’s initial public offering or third party financing prior to April 21, 2012. The notes matured on July 21, 2021. The unpaid principal on the notes was convertible into shares of Series A preferred stock at $8.97 per share at any point after July 21, 2012. The difference between the repurchase price and the carrying value of the repurchased preferred stock on June 30, 2011 was $59.0 million. The difference was debited to available retained earnings with the remaining amount debited to additional paid-in capital and reduced the net income attributable to common stock shareholders resulting in a reduction of basic and diluted net income per share.

[0001511737-13-000006:notes:33]
On September 15, 2011, the Company entered into a Loan and Security Agreement with East West Bank, (the “EWB Loan Agreement”), which was replaced by the Loan Agreement as discussed below. The credit facilities available under the EWB Loan Agreement consist of a $35.0 million term loan facility and a $5.0 million revolving line of credit facility. The term loan matures on September 15, 2016 with principal and interest to be repaid in 60 monthly installments. The Company used $34.0 million of the term loan to repay a portion of the outstanding convertible subordinated promissory notes held by entities affiliated with Summit Partners, L.P leaving $1.0 million available for borrowing under the term loan facility.

[0001511737-13-000006:notes:34]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement. The Loan Agreement replaced the EWB Loan Agreement discussed above. The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”). The Company may request borrowings under the Revolving Credit Facility until August 7, 2015. On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remains available for borrowing thereunder.

[0001511737-13-000006:notes:35]
The loans bear interest, at the Company’s option, at the base rate plus a spread of 1.25% to 1.75% or an adjusted LIBOR rate (at the Company’s election, for a period of 30, 60, or 90 days) plus a spread of 2.25% to 2.75%, in each case with such spread being determined based on the debt service coverage ratio for its most recently ended fiscal quarter. The base rate is the highest of (i) East West Bank’s prime rate, (ii) the federal funds rate plus a margin equal to 0.50%, or (iii) the LIBOR rate plus a margin equal to 1.00%. The Company is also obligated to pay other customary closing fees, arrangement fees, administration fees, commitment fees and letter of credit fees for a credit facility of this size and type.

[0001511737-13-000006:notes:36]
Interest is due and payable monthly in arrears in the case of loans bearing interest at the base rate and at the end of an interest period in the case of loans bearing interest at the adjusted LIBOR rate. Principal payments under the Term Loan Facility will be made in quarterly installments on the first day of each calendar quarter, and each such quarterly installment shall be equal to $1.25 million through July 1, 2014, then equal to $1.875 million from October 1, 2014 through July 1 2015, and then equal to $2.5 million from October 1, 2015 through July 1, 2017, with the remaining outstanding principal balance and all accrued and unpaid interest due on August 7, 2017. All outstanding loans under the Revolving Credit Facility, together with all accrued and unpaid interest, are due on August 7, 2015.

[0001511737-13-000006:notes:37]
The Company may prepay the loans, in whole or in part, at any time without premium or penalty, subject to certain conditions including minimum amounts and reimbursement of certain costs in the case of prepayments of LIBOR loans. In addition, the Company is required to prepay the loan under the Term Loan Facility with (i) the proceeds from certain financing transactions or asset sales (subject, in the case of asset sales, to reinvestment rights) and (ii) 25.0% of the Company’s excess cash flow in the U.S., as determined after each fiscal year and in accordance with the Loan Agreement, provided that the Company shall not be required to prepay the loan out of its excess cash flow if its leverage ratio is greater than 1.50:1.00 on the last day of such fiscal year.

[0001511737-13-000006:notes:38]
All of the obligations of the Company under the Loan Agreement are collateralized by substantially all of the Company’s assets, including all of the capital stock of the Company’s future domestic subsidiaries and 65% of the capital stock of the Company’s existing and future foreign subsidiaries, but excluding the Company’s intellectual property, which is subject to a negative pledge agreement. All of the Company’s future domestic subsidiaries are required to guaranty the obligations under the Loan Agreement. Such guarantees by future subsidiaries will be collateralized by substantially all of the property of such subsidiaries, excluding intellectual property.

[0001511737-13-000006:notes:39]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of March 31, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

[0001511737-13-000006:notes:40]
The Loan Agreement includes customary events of default that, include among other things, defaults for the failure to timely pay principal, interest, or other amounts due, defaults due to the inaccuracy of representations and warranties, covenant defaults, a cross default to material indebtedness, bankruptcy and insolvency defaults, material judgment defaults, defaults due to the unenforceability of a guaranty, and defaults due to circumstances that have or could reasonably be expected to have a material adverse effect on the Company's business, operations or financial condition, its ability to pay or perform under the Loan Agreement, or on the lenders' security interests. The occurrence of an event of default could result in the acceleration of the obligations under the Loan Agreement. During the existence of an event of default, interest on the obligations under the Loan Agreement could be increased by 2.00% above the otherwise applicable interest rate.

[0001511737-13-000006:notes:41]
During the three and nine months ended March 31, 2013, the Company made aggregate payments of $1.3 million and $3.1 million, respectively, against the loan balance.  As of March 31, 2013, the Company has classified $5.0 million and $72.4 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.

[0001511737-13-000006:notes:42]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2013 (in thousands):

[0001511737-13-000006:notes:43]
|  | 2013(remainder) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 1,250 |  |  | $ | 5,000 |  |  | $ | 6,875 |  |  | $ | 39,375 |  |  | $ | 10,000 |  |  | $ | 15,000 |  |  | $ | 77,500 |  |
| Interest payments on debt payment obligations | 472 |  |  | 1,859 |  |  | 1,723 |  |  | 1,043 |  |  | 532 |  |  | 125 |  |  | 5,754 |  |
| Total | $ | 1,722 |  |  | $ | 6,859 |  |  | $ | 8,598 |  |  | $ | 40,418 |  |  | $ | 10,532 |  |  | $ | 15,125 |  |  | $ | 83,254 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-13-000006:notes:44]
[same as prior period, unchanged from 0001445305-13-000191:notes:44]

[0001511737-13-000006:notes:45]
|  | March 31, 2013 |  | June 30, 2012 |
| Non-trade receivables | 1,548 |  |  | 1,019 |  |
| Other current assets | 1,721 |  |  | 558 |  |
|  | $ | 3,269 |  |  | $ | 1,577 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-13-000006:notes:46]
[same as prior period, unchanged from 0001445305-13-000191:notes:46]

[0001511737-13-000006:notes:47]
[same as prior period, unchanged from 0001445305-13-000191:notes:47]

[0001511737-13-000006:notes:48]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of March 31, 2013, the Company had 5,346,715 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-13-000006:notes:49]
[same as prior period, unchanged from 0001445305-13-000191:notes:49]

[0001511737-13-000006:notes:50]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and nine months ended March 31, 2013 and 2012 (in thousands):

[0001511737-13-000006:notes:51]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Cost of sales | $ | 124 |  |  | $ | 41 |  |  | $ | 309 |  |  | $ | 74 |  |
| Research and development | 324 |  |  | 133 |  |  | 991 |  |  | 365 |  |
| Sales, general and administrative | 252 |  |  | 156 |  |  | 949 |  |  | 593 |  |
|  | $ | 700 |  |  | $ | 330 |  |  | $ | 2,249 |  |  | $ | 1,032 |  |

[0001511737-13-000006:notes:52]
[same as prior period, unchanged from 0001445305-13-000191:notes:52]

[0001511737-13-000006:notes:53]
The following is a summary of option activity for the Company’s stock incentive plans for the nine months ended March 31, 2013:

[0001511737-13-000006:notes:54]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2012 | 3,347,445 |  |  | $ | 1.45 |  |  |  |  |  |
| Granted | 672,000 |  |  | 11.21 |  |  |  |  |  |
| Exercised | (136,182 | ) |  | 2.29 |  |  |  |  |  |
| Forfeitures and cancellations | (147,751 | ) |  | 5.55 |  |  |  |  |  |
| Balance, March 31, 2013 | 3,735,512 |  |  | $ | 3.01 |  |  | 6.28 |  | $ | 40,087 |  |
| Vested and expected to vest as of March 31, 2013 | 3,660,648 |  |  | $ | 2.88 |  |  | 6.22 |  | $ | 39,783 |  |
| Vested and exercisable as of March 31, 2013 | 2,668,567 |  |  | $ | 0.84 |  |  | 5.25 |  | $ | 34,407 |  |

[0001511737-13-000006:notes:55]
During the three months ended March 31, 2013 and 2012, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $1.1 million and $406,000, respectively, as determined as of the date of option exercise. During the nine months ended March 31, 2013 and 2012, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $1.5 million and $47.0 million respectively.

[0001511737-13-000006:notes:56]
As of March 31, 2013, the Company had unrecognized compensation costs of $4.0 million related to stock options which the Company expects to recognize over a weighted-average period of 3.5 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-13-000006:notes:57]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards. For the three and nine months ended March 31, 2013 and 2012, the fair value of employee stock options was estimated using the following weighted average assumptions:

[0001511737-13-000006:notes:58]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Expected term | 6.1 years |  |  | 6.1 years |  |  | 6.1 years |  |  | 6.1 years |  |
| Expected volatility | 52 | % |  | 51 | % |  | 52 | % |  | 49 | % |
| Risk-free interest rate | 1.0 | % |  | 1.2 | % |  | 0.8 | % |  | 1.6 | % |
| Expected dividend yield | — |  |  | — |  |  | — |  |  | — |  |
| Weighted average grant date fair value | $ | 6.69 |  |  | $ | 9.86 |  |  | $ | 5.51 |  |  | $ | 5.05 |  |

[0001511737-13-000006:notes:59]
[same as prior period, unchanged from 0001445305-13-000191:notes:59]

[0001511737-13-000006:notes:60]
[same as prior period, unchanged from 0001445305-13-000191:notes:60]

[0001511737-13-000006:notes:61]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2012 | 453,620 |  |  | $ | 9.42 |  |
| RSUs granted | 586,500 |  |  | 13.92 |  |
| RSUs vested | (48,595 | ) |  | 12.79 |  |
| RSUs cancelled | (287,090 | ) |  | 5.03 |  |
| Non-vested RSUs, March 31, 2013 | 704,435 |  |  | $ | 14.73 |  |

[0001511737-13-000006:notes:62]
The intrinsic value of RSUs vested in the three months ended March 31, 2013 and 2012 was $389,000 and $25,000, respectively. The intrinsic value of RSUs vested in the nine months ended March 31, 2013 and 2012 was $622,000 and $25,000, respectively. The total intrinsic value of all outstanding RSUs was $9.7 million as of March 31, 2013.

[0001511737-13-000006:notes:63]
As of March 31, 2013, there was unrecognized compensation costs related to RSUs of $8.5 million which the Company expects to recognize over a weighted average period of 3.9 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-13-000006:notes:64]
[same as prior period, unchanged from 0001445305-13-000191:notes:64]

[0001511737-13-000006:notes:65]
[same as prior period, unchanged from 0001445305-13-000191:notes:65]

[0001511737-13-000006:notes:66]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Numerator: |  |  |  |
| Net income (loss) attributable to common stockholders | $ | 20,667 |  |  | $ | 27,920 |  |  | $ | 51,649 |  |  | $ | (38,327 | ) |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income (loss) per share | 87,004 |  |  | 91,861 |  |  | 88,702 |  |  | 80,648 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,803 |  |  | 2,044 |  |  | 1,808 |  |  | — |  |
| Restricted stock units | 146 |  |  | 272 |  |  | 146 |  |  | — |  |
| Weighted-average shares used in computing diluted net income (loss) per share | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 80,648 |  |
| Net income (loss) per share of common stock: |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.58 |  |  | $ | (0.48 | ) |
| Diluted | $ | 0.23 |  |  | $ | 0.30 |  |  | $ | 0.57 |  |  | $ | (0.48 | ) |

[0001511737-13-000006:notes:67]
[same as prior period, unchanged from 0001445305-13-000191:notes:67]

[0001511737-13-000006:notes:68]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Stock options | 655 |  |  | 11,214 |  |  | 356 |  |  | 3,441 |  |
| Restricted stock units | 205 |  |  | 5,000 |  |  | 129 |  |  | 470 |  |
|  | 860 |  |  | 16,214 |  |  | 485 |  |  | 3,911 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-13-000006:notes:69]
As of March 31, 2013 and June 30, 2012, the fair value hierarchy for the Company’s financial assets and financial liabilities was as follows (in thousands):

[0001511737-13-000006:notes:70]
|  | March 31, 2013 |  | June 30, 2012 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 165,242 |  |  | $ | 165,242 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,228 |  |  | $ | 108,228 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt | $ | 77,369 |  |  | $ | — |  |  | $ | 77,369 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |  | $ | 29,591 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-13-000006:notes:71]
[same as prior period, unchanged from 0001445305-13-000191:notes:71]

[0001511737-13-000006:notes:72]
[same as prior period, unchanged from 0001445305-13-000191:notes:72]

[0001511737-13-000006:notes:73]
[same as prior period, unchanged from 0001445305-13-000191:notes:73]

[0001511737-13-000006:notes:74]
[same as prior period, unchanged from 0001445305-13-000191:notes:74]

[0001511737-13-000006:notes:75]
[same as prior period, unchanged from 0001445305-13-000191:notes:75]

[0001511737-13-000006:notes:76]
The Company’s financial assets at March 31, 2013 and June 30, 2012 included money market funds which were valued based on quoted prices in active markets for substantially similar assets and, therefore, were Level 1 instruments. Additionally, at March 31, 2013 and June 30, 2012 the Company had debt associated with its Loan and Security Agreement with East West Bank (See Note 8). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and were therefore Level 2 instruments.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-13-000006:notes:77]
[same as prior period, unchanged from 0001445305-13-000191:notes:77]

[0001511737-13-000006:notes:78]
As of March 31, 2013, the Company had approximately $10.4 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At March 31, 2013, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded an increase of its unrecognized tax benefits of $1.1 million for the three months ended March 31, 2013. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-13-000006:notes:79]
The Company recorded a tax provision of $2.5 million for the three months ended March 31, 2013. The Company’s estimated 2012 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-13-000006:notes:80]
[same as prior period, unchanged from 0001445305-13-000191:notes:80]

[0001511737-13-000006:notes:81]
On January 2, 2013, the American Taxpayer Relief Act of 2012 ("the Act") was signed into law. One of the provisions of the Act provides a retroactive extension of the research and experimentation tax credit ("R&D credit") through December 31, 2013, which had expired on December 31, 2011.  The Company has recognized a tax benefit of $539,000 during the third quarter of fiscal 2013 as a result of the retroactive extension of the R&D credit.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-13-000006:notes:82]
The Company does not believe there have been any recent accounting pronouncements that would have a significant impact on the Company’s financial statements.


## us-gaap:PreferredStockTextBlock

[0001511737-13-000006:notes:83]
[same as prior period, unchanged from 0001445305-13-000191:notes:82]

[0001511737-13-000006:notes:84]
[same as prior period, unchanged from 0001445305-13-000191:notes:83]

[0001511737-13-000006:notes:85]
[same as prior period, unchanged from 0001445305-13-000191:notes:84]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-13-000006:notes:86]
[same as prior period, unchanged from 0001445305-13-000191:notes:85]

[0001511737-13-000006:notes:87]
[same as prior period, unchanged from 0001445305-13-000191:notes:86]

[0001511737-13-000006:notes:88]
[same as prior period, unchanged from 0001445305-13-000191:notes:87]

[0001511737-13-000006:notes:89]
|  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |
| Beginning balance | $ | 1,381 |  |  | $ | 806 |  |
| Accruals for warranties issued during the period | 3,076 |  |  | 1,572 |  |
| Warranty costs incurred during the period | (1,804 | ) |  | (991 | ) |
|  | $ | 2,653 |  |  | $ | 1,387 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-13-000006:notes:90]
[same as prior period, unchanged from 0001445305-13-000191:notes:89]

[0001511737-13-000006:notes:91]
|  | March 31, 2013 |  | June 30, 2012 |
| Testing equipment | $ | 3,126 |  |  | $ | 2,293 |  |
| Computer and other equipment | 828 |  |  | 578 |  |
| Tooling equipment | 1,605 |  |  | 532 |  |
| Furniture and fixtures | 641 |  |  | 595 |  |
| Leasehold improvements | 1,808 |  |  | 1,424 |  |
| Software | 229 |  |  | 77 |  |
| Construction in progress | 60 |  |  | — |  |
|  | 8,297 |  |  | 5,499 |  |
| Less: Accumulated depreciation and amortization | (2,119 | ) |  | (1,028 | ) |
|  | $ | 6,178 |  |  | $ | 4,471 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-13-000006:notes:92]
[same as prior period, unchanged from 0001445305-13-000191:notes:91]

[0001511737-13-000006:notes:93]
|  | March 31, 2013 |  | June 30, 2012 |
| Accrued compensation and benefits | $ | 3,068 |  |  | $ | 2,657 |  |
| Accrued accounts payable | 405 |  |  | 6,636 |  |
| Accrual for an export compliance matter | 1,625 |  |  | 1,625 |  |
| Warranty accrual | 2,653 |  |  | 1,381 |  |
| Other accruals | 3,225 |  |  | 4,732 |  |
|  | $ | 10,976 |  |  | $ | 17,031 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-13-000006:notes:94]
[same as prior period, unchanged from 0001445305-13-000191:notes:93]

[0001511737-13-000006:notes:95]
|  | March 31, 2013 |  | June 30, 2012 |
| Raw materials | $ | 2,629 |  |  | $ | 4,668 |  |
| Finished goods | 16,752 |  |  | 3,066 |  |
|  | $ | 19,381 |  |  | $ | 7,734 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-13-000006:notes:96]
[same as prior period, unchanged from 0001445305-13-000191:notes:95]

[0001511737-13-000006:notes:97]
|  | March 31, 2013 |  | June 30, 2012 |
| Intangible assets, net | $ | 1,073 |  |  | $ | 748 |  |
| Other long-term assets | 702 |  |  | 388 |  |
|  | $ | 1,775 |  |  | $ | 1,136 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-13-000006:notes:98]
[same as prior period, unchanged from 0001445305-13-000191:notes:97]

[0001511737-13-000006:notes:99]
[same as prior period, unchanged from 0001445305-13-000191:notes:98]

[0001511737-13-000006:notes:100]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| airMAX | $ | 55,534 |  |  | 67 | % |  | $ | 61,978 |  |  | 68 | % |  | $ | 136,343 |  |  | 62 | % |  | $ | 164,752 |  |  | 64 | % |
| New platforms | 11,825 |  |  | 14 | % |  | 9,914 |  |  | 11 | % |  | 39,358 |  |  | 18 | % |  | 16,874 |  |  | 6 | % |
| Other systems | 4,108 |  |  | 5 | % |  | 10,308 |  |  | 11 | % |  | 12,727 |  |  | 6 | % |  | 41,327 |  |  | 16 | % |
| Systems | 71,467 |  |  | 86 | % |  | 82,200 |  |  | 90 | % |  | 188,428 |  |  | 86 | % |  | 222,953 |  |  | 86 | % |
| Embedded radio | 1,721 |  |  | 2 | % |  | 2,232 |  |  | 2 | % |  | 4,954 |  |  | 2 | % |  | 8,024 |  |  | 3 | % |
| Antennas/other | 9,967 |  |  | 12 | % |  | 7,233 |  |  | 8 | % |  | 26,209 |  |  | 12 | % |  | 27,672 |  |  | 11 | % |
| Total revenues | $ | 83,155 |  |  | 100 | % |  | $ | 91,665 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |  | $ | 258,649 |  |  | 100 | % |

[0001511737-13-000006:notes:101]
The Company generally forwards products directly from its manufacturers to its customers via logistics distribution hubs in Asia.  Beginning in the quarter ended December 31, 2012, the Company's products were predominantly routed through a third party logistics provider in China and prior to the quarter ended December 31, 2012, the Company's products were predominantly delivered to our customers through distribution hubs in Hong Kong.  The Company's logistics provider, in turn, ships to other locations throughout the world. The Company has determined the geographical distribution of product revenues based upon the customer's ship-to destinations.

[0001511737-13-000006:notes:102]
[same as prior period, unchanged from 0001445305-13-000191:notes:101]

[0001511737-13-000006:notes:103]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| North America(1) | $ | 21,052 |  |  | 25 | % |  | $ | 16,647 |  |  | 18 | % |  | $ | 53,519 |  |  | 24 | % |  | $ | 63,028 |  |  | 24 | % |
| South America | 18,496 |  |  | 22 | % |  | 27,666 |  |  | 30 | % |  | 45,820 |  |  | 21 | % |  | 71,751 |  |  | 28 | % |
| Europe, the Middle East and Africa | 31,617 |  |  | 38 | % |  | 36,398 |  |  | 40 | % |  | 90,690 |  |  | 41 | % |  | 91,537 |  |  | 35 | % |
| Asia Pacific | 11,990 |  |  | 15 | % |  | 10,954 |  |  | 12 | % |  | 29,562 |  |  | 14 | % |  | 32,333 |  |  | 13 | % |
| Total revenues | $ | 83,155 |  |  | 100 | % |  | $ | 91,665 |  |  | 100 | % |  | $ | 219,591 |  |  | 100 | % |  | $ | 258,649 |  |  | 100 | % |

[0001511737-13-000006:notes:104]
| (1) | Revenue for the United States was $19.7 million and $14.9 million for the three months ended March 31, 2013 and 2012, respectively. Revenue for the United States was $50.5 million and $60.0 million for the nine months ended March 31, 2013 and 2012, respectively. |

[0001511737-13-000006:notes:105]
[same as prior period, unchanged from 0001445305-13-000191:notes:104]

[0001511737-13-000006:notes:106]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |  | March 31, |  | June 30, |
|  | 2013 |  | 2012 |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Customer A | 15 | % |  | 20 | % |  | 13 | % |  | 19 | % |  | 13 | % |  | 19 | % |
| Customer B | * |  |  | 10 | % |  | * |  |  | * |  |  | 10 | % |  | * |  |
| Customer C | * |  |  | * |  |  | * |  |  | 10 | % |  | 13 | % |  | 11 | % |
| Customer D | * |  |  | * |  |  | * |  |  | * |  |  | * |  |  | 12 | % |

[0001511737-13-000006:notes:107]
[same as prior period, unchanged from 0001445305-13-000191:notes:106]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-13-000006:notes:108]
[same as prior period, unchanged from 0001445305-13-000191:notes:107]

[0001511737-13-000006:notes:109]
[same as prior period, unchanged from 0001445305-13-000191:notes:108]

[0001511737-13-000006:notes:110]
[same as prior period, unchanged from 0001445305-13-000191:notes:109]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-13-000006:notes:111]
[same as prior period, unchanged from 0001445305-13-000191:notes:110]

[0001511737-13-000006:notes:112]
[same as prior period, unchanged from 0001445305-13-000191:notes:111]

[0001511737-13-000006:notes:113]
[same as prior period, unchanged from 0001445305-13-000191:notes:112]

[0001511737-13-000006:notes:114]
[same as prior period, unchanged from 0001445305-13-000191:notes:113]

[0001511737-13-000006:notes:115]
[same as prior period, unchanged from 0001445305-13-000191:notes:114]

[0001511737-13-000006:notes:116]
[same as prior period, unchanged from 0001445305-13-000191:notes:115]


## ubnt:CommonStockAndTreasuryStockDiscloseTextBlock

[0001511737-13-000006:notes:117]
[same as prior period, unchanged from 0001445305-13-000191:notes:116]

[0001511737-13-000006:notes:118]
As of March 31, 2013 and June 30, 2012, the authorized capital of the Company included 500,000,000 shares of common stock. As of March 31, 2013, 131,306,084 shares of common stock were issued and 87,067,124 were outstanding. As of June 30, 2012, 131,129,888 shares of common stock were issued and 92,049,978 were outstanding.

[0001511737-13-000006:notes:119]
[same as prior period, unchanged from 0001445305-13-000191:notes:118]

[0001511737-13-000006:notes:120]
[same as prior period, unchanged from 0001445305-13-000191:notes:119]

[0001511737-13-000006:notes:121]
Common stock repurchase activity during the nine months ended March 31, 2013 was as follows (in thousands, except share and per share amounts):

[0001511737-13-000006:notes:122]
[same as prior period, unchanged from 0001445305-13-000191:notes:121]

[0001511737-13-000006:notes:123]
The Company did not repurchase any of its common stock during the three months ended March 31, 2013.

[0001511737-13-000006:notes:124]
[same as prior period, unchanged from 0001445305-13-000191:notes:122]

[0001511737-13-000006:notes:125]
[same as prior period, unchanged from 0001445305-13-000191:notes:123]
