# UI 8-K — 0001511737-13-000004 filed 2013-05-09

## item codes, every 8-K on or before 2013-05-10

- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2013-05-10

- none on or before 2013-05-10

## item 2.02 — earnings release, exhibit 99.1

[0001511737-13-000004:8k_2_02:1]
EX-99.1
2
exhibit991q32013.htm
PRESS RELEASE

[0001511737-13-000004:8k_2_02:2]
Exhibit 99.1 Q3 2013

[0001511737-13-000004:8k_2_02:3]
Exhibit 99.1

[0001511737-13-000004:8k_2_02:4]
| Contact: |  |  |  |  |
| The Abernathy MacGregor Group |  |  |  |  |
| Amy Feng / asf@abmac.com / 213-630-6550 |  |  |  |  |

[0001511737-13-000004:8k_2_02:5]
UBIQUITI NETWORKS REPORTS Q3 FISCAL 2013 RESULTS

[0001511737-13-000004:8k_2_02:6]
| • | Revenues of $83.2 million, an increase of 11% from the prior quarter |

[0001511737-13-000004:8k_2_02:7]
| • | Second consecutive quarter of double-digit sequential growth in total and airMAX revenues |

[0001511737-13-000004:8k_2_02:8]
| • | Non-GAAP operating profitability of $24.2 million, an increase of 15% from the prior quarter |

[0001511737-13-000004:8k_2_02:9]
| • | $35.2 million in net cash provided by operating activities |

[0001511737-13-000004:8k_2_02:10]
| • | Quarterly GAAP Diluted EPS of $0.23 and Non-GAAP Diluted EPS of $0.24 |

[0001511737-13-000004:8k_2_02:11]
San Jose, Calif. — May 9, 2013 — Ubiquiti Networks, Inc. (NASDAQ:UBNT) ("Ubiquiti"), a product driven technology company for end-to-end networking solutions, today announced results for the third quarter of fiscal 2013, ended March 31, 2013.

[0001511737-13-000004:8k_2_02:12]
For the third quarter of fiscal 2013, Ubiquiti reported revenues of $83.2 million, a decrease of 9% compared to revenues of $91.7 million for the same period the prior year and an increase of 11% compared to the prior quarter. For the nine months ended March 31, 2013 Ubiquiti reported revenues of $219.6 million, a decrease of 15% compared to revenues of $258.6 million for the same period in the prior year.

[0001511737-13-000004:8k_2_02:13]
For the third quarter of fiscal 2013, GAAP net income was $20.7 million, a decrease of 26% compared to GAAP net income of $27.9 million for the same period the prior year and an increase of 16% from the prior quarter. Non-GAAP net income was $21.1 million, a decrease of 25% compared to $28.1 million for the same period last year and an increase of 15% compared to the prior quarter.

[0001511737-13-000004:8k_2_02:14]
For the nine months ended March 31, 2013, GAAP net income was $51.6 million, a decrease of 30% compared to GAAP net income of $74.1 million for the same period in the prior year. Non-GAAP net income was $53.0 million, a decrease of 29% compared to $74.7 million for the same period in the prior year.

[0001511737-13-000004:8k_2_02:15]
“I believe we are back on the right track, but we still have high internal performance expectations. We believe our unique research and development approach, disruptive product economics, and user community evangelism together represent a paradigm shift for the service provider and enterprise markets.  We look forward to the opportunity to show stronger results and to execute on our long-term vision," said Robert J. Pera, Founder, Chief Executive Officer and Executive Chairman of Ubiquiti Networks.

[0001511737-13-000004:8k_2_02:16]
The following table reconciles GAAP net income to non-GAAP net income and weighted-average shares used in computing net income per share of common stock-diluted to weighted-average shares used in computing non-GAAP Diluted EPS:

[0001511737-13-000004:8k_2_02:17]
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
|  |  | (in thousands, except per share data)(unaudited) |
| Net income |  | $ | 20,667 |  |  | $ | 27,920 |  |  | $ | 51,649 |  |  | $ | 74,104 |  |
| Stock-based compensation, net of taxes |  | 420 |  |  | 198 |  |  | 1,349 |  |  | 619 |  |
| Non-GAAP net income |  | $ | 21,087 |  |  | $ | 28,118 |  |  | $ | 52,998 |  |  | $ | 74,723 |  |
| Weighted-average shares used in computing net income (loss) per share of common stock-diluted |  | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 80,648 |  |
| Weighted-average dilutive effect of stock options and restricted stock units |  | — |  |  | — |  |  | — |  |  | 2,895 |  |
| Weighted-average shares of Series A preferred shares outstanding |  | — |  |  | — |  |  | — |  |  | 10,124 |  |
| Weighted-average shares used in computing non-GAAP diluted EPS (1) |  | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 93,667 |  |
| Non-GAAP diluted EPS (1) |  | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.58 |  |  | $ | 0.80 |  |

[0001511737-13-000004:8k_2_02:18]
| (1) | Non-GAAP Diluted EPS is calculated using non-GAAP net income excluding stock-based compensation, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001511737-13-000004:8k_2_02:19]
Recent Highlights

[0001511737-13-000004:8k_2_02:20]
| • | Announced UniFi 3.0, a major upgrade to Ubiquiti's flagship enterprise WLAN platform and the industry's first enterprise 802.11ac wi-fi access point. According to research firm Gartner, UniFi was the fastest growing enterprise WLAN platform in 2012 as measured by unit share. |

[0001511737-13-000004:8k_2_02:21]
| • | Announced that Enforta, the largest fixed wireless broadband service provider in Russia will deploy airMAX to provide high speed wireless broadband to 150 cities across the country. |

[0001511737-13-000004:8k_2_02:22]
| • | Strengthened and enhanced the management team with the hiring of a new chief financial officer and the Company's first chief marketing officer |

[0001511737-13-000004:8k_2_02:23]
Business Outlook

[0001511737-13-000004:8k_2_02:24]
Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's fiscal fourth quarter ending June 30, 2013:

[0001511737-13-000004:8k_2_02:25]
| • |  |

[0001511737-13-000004:8k_2_02:26]
| • | Revenues of between $90 million and $96 million |

[0001511737-13-000004:8k_2_02:27]
| • | GAAP Diluted EPS of between $0.25 and $0.28 |

[0001511737-13-000004:8k_2_02:28]
| • | Non-GAAP Diluted EPS of between $0.26 and $0.29 |

[0001511737-13-000004:8k_2_02:29]
Conference Call

[0001511737-13-000004:8k_2_02:30]
Ubiquiti Networks will discuss the Company's financial results by conference call at 2:00 p.m. PDT today.

[0001511737-13-000004:8k_2_02:31]
To listen to the conference call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) and provide the passcode 33684847. Participants should dial in at least 10 minutes prior to the start of the call. Investors may also listen to a live webcast of the conference call by visiting the Investor Relations portion of Ubiquiti Networks' website, http://www.ubnt.com/.

[0001511737-13-000004:8k_2_02:32]
The playback of the conference call will be available approximately two hours after the call concludes and will be accessible on the Ubiquiti Networks' corporate web site or by calling (855) 859-2056 (U.S. toll-free) or (404) 537-3406 (International) and entering the passcode 33684847. The audio replay will be available for three days. A replay of the webcast will also be available at http://www.ubnt.com/ following the completion of the call.

[0001511737-13-000004:8k_2_02:33]
About Ubiquiti Networks

[0001511737-13-000004:8k_2_02:34]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere.  With over 10 million devices deployed in over 180 countries, Ubiquiti is transforming under-networked businesses and communities.  Our leading edge platforms, airMAX™, UniFi™, airFiber™, airVision™, mFi™ and EdgeMAX™ combine innovative technology, disruptive price performance and the support of a global user community to eliminate barriers to connectivity.   For more information, join our community at http://www.ubnt.com/.

[0001511737-13-000004:8k_2_02:35]
Use of Non-GAAP Financial Information

[0001511737-13-000004:8k_2_02:36]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain recurring costs, expenses and gains such as stock based compensation expense and the tax effects of these non-GAAP adjustments.  In addition, our non-GAAP adjustments present shares of Series A preferred stock as if these shares had been converted to common stock throughout the periods presented.  Reconciliations of the adjustments to GAAP results for the three and nine months ended March 31, 2013 and 2012 are provided below. In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, the material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-13-000004:8k_2_02:37]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.

[0001511737-13-000004:8k_2_02:38]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, distributors' inventory management practices and general economic conditions; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S.  export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J.  Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification and litigation related to U.S.  Securities laws and economic and

[0001511737-13-000004:8k_2_02:39]
political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2012 and in our Quarterly Reports on Form 10-Q for the quarters ended September 30, 2012 and December 31, 2012 and other filings filed with the U.S.  Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting Ubiquiti Networks' Investor Relations Department, or by email at investor.relations@ubnt.com or Ubiquiti Networks' Investor Relations website at www.ubnt.com.

[0001511737-13-000004:8k_2_02:40]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Ubiquiti Networks undertakes no obligation to update information contained in this press release.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-13-000004:8k_2_02:41]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenues |  | $ | 83,155 |  |  | $ | 91,665 |  |  | $ | 219,591 |  |  | $ | 258,649 |  |
| Cost of revenues |  | 47,690 |  |  | 52,006 |  |  | 128,621 |  |  | 148,687 |  |
| Gross profit |  | 35,465 |  |  | 39,659 |  |  | 90,970 |  |  | 109,962 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 5,677 |  |  | 4,619 |  |  | 15,440 |  |  | 11,671 |  |
| Sales, general and administrative |  | 6,285 |  |  | 2,484 |  |  | 16,133 |  |  | 7,059 |  |
| Total operating expenses |  | 11,962 |  |  | 7,103 |  |  | 31,573 |  |  | 18,730 |  |
| Income from operations |  | 23,503 |  |  | 32,556 |  |  | 59,397 |  |  | 91,232 |  |
| Interest expense and other, net |  | (287 | ) |  | (190 | ) |  | (570 | ) |  | (1,136 | ) |
| Income before provision for income taxes |  | 23,216 |  |  | 32,366 |  |  | 58,827 |  |  | 90,096 |  |
| Provision for income taxes |  | 2,549 |  |  | 4,446 |  |  | 7,178 |  |  | 15,992 |  |
| Net income |  | $ | 20,667 |  |  | $ | 27,920 |  |  | $ | 51,649 |  |  | $ | 74,104 |  |
| Preferred stock cumulative dividend and accretion of cost of preferred stock |  | — |  |  | — |  |  | — |  |  | (112,431 | ) |
| Net income (loss) attributable to common stockholders |  | $ | 20,667 |  |  | $ | 27,920 |  |  | $ | 51,649 |  |  | $ | (38,327 | ) |
| Net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.58 |  |  | $ | (0.48 | ) |
| Diluted |  | $ | 0.23 |  |  | $ | 0.30 |  |  | $ | 0.57 |  |  | $ | (0.48 | ) |
| Weighted average shares used in computing net income (loss) per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 87,004 |  |  | 91,861 |  |  | 88,702 |  |  | 80,648 |  |
| Diluted |  | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 80,648 |  |

[0001511737-13-000004:8k_2_02:42]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net income |  | $ | 20,667 |  |  | $ | 27,920 |  |  | $ | 51,649 |  |  | $ | 74,104 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 124 |  |  | 41 |  |  | 309 |  |  | 74 |  |
| Research and development |  | 324 |  |  | 133 |  |  | 991 |  |  | 365 |  |
| Sales, general and administrative |  | 252 |  |  | 156 |  |  | 949 |  |  | 593 |  |
| Tax effect of non-GAAP adjustments |  | (280 | ) |  | (132 | ) |  | (900 | ) |  | (413 | ) |
| Non-GAAP net income |  | $ | 21,087 |  |  | $ | 28,118 |  |  | $ | 52,998 |  |  | $ | 74,723 |  |
| Non-GAAP diluted EPS (1) |  | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.58 |  |  | $ | 0.80 |  |
| Weighted-average shares used in non-GAAP diluted EPS (1) |  | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 93,667 |  |

[0001511737-13-000004:8k_2_02:43]
| (1) | Non-GAAP Diluted EPS is calculated using non-GAAP net income excluding stock-based compensation, net of taxes and weighted-average shares outstanding as if Series A preferred stock is treated as common stock for the periods presented. |

[0001511737-13-000004:8k_2_02:44]
| Ubiquiti Networks, Inc.Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In Computing Non-GAAP Diluted EPS(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Weighted-average shares used in computing netincome (loss) per share of common stock-diluted |  | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 80,648 |  |
| Add back: |  |  |  |  |  |  |  |  |
| Weighted-average dilutive effect of stock options and restricted stock units |  | — |  |  | — |  |  | — |  |  | 2,895 |  |
| Weighted-average shares of Series A preferred shares outstanding |  | — |  |  | — |  |  | — |  |  | 10,124 |  |
| Weighted-average shares used in computing non-GAAP diluted EPS |  | 88,953 |  |  | 94,177 |  |  | 90,656 |  |  | 93,667 |  |

[0001511737-13-000004:8k_2_02:45]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands, except share amounts)(Unaudited) |
|  |  | March 31, 2013 |  | June 30, 2012(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 181,689 |  |  | $ | 122,060 |  |
| Accounts receivable, net |  | 38,417 |  |  | 75,644 |  |
| Inventories |  | 19,381 |  |  | 7,734 |  |
| Current deferred tax asset |  | 882 |  |  | 882 |  |
| Prepaid expenses and other current assets |  | 3,269 |  |  | 1,577 |  |
| Total current assets |  | 243,638 |  |  | 207,897 |  |
| Property and equipment, net |  | 6,178 |  |  | 4,471 |  |
| Long-term deferred tax asset |  | 232 |  |  | 232 |  |
| Other long–term assets |  | 1,775 |  |  | 1,136 |  |
| Total assets |  | $ | 251,823 |  |  | $ | 213,736 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 31,257 |  |  | $ | 26,450 |  |
| Customer deposits |  | 3,010 |  |  | 235 |  |
| Deferred revenues |  | 1,841 |  |  | 805 |  |
| Income taxes payable |  | 4,601 |  |  | 946 |  |
| Debt - short-term |  | 5,011 |  |  | 6,968 |  |
| Other current liabilities |  | 10,976 |  |  | 17,031 |  |
| Total current liabilities |  | 56,696 |  |  | 52,435 |  |
| Long-term taxes payable |  | 7,727 |  |  | 7,727 |  |
| Debt - long-term |  | 72,358 |  |  | 22,623 |  |
| Total liabilities |  | 136,781 |  |  | 82,785 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 87 |  |  | 92 |  |
| Additional paid–in capital |  | 131,429 |  |  | 128,981 |  |
| Treasury stock |  | (123,864 | ) |  | (69,515 | ) |
| Retained earnings |  | 107,390 |  |  | 71,393 |  |
| Total stockholders’ equity |  | 115,042 |  |  | 130,951 |  |
| Total liabilities and stockholders’ equity |  | $ | 251,823 |  |  | $ | 213,736 |  |

[0001511737-13-000004:8k_2_02:46]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2012. |

[0001511737-13-000004:8k_2_02:47]
| Ubiquiti Networks Inc.Revenue by Product Category and Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenue by Product Category |  |  |  |  |  |  |  |  |
| airMAX |  | $ | 55,534 |  |  | $ | 61,978 |  |  | $ | 136,343 |  |  | $ | 164,752 |  |
| New platforms |  | 11,825 |  |  | 9,914 |  |  | 39,358 |  |  | 16,874 |  |
| Other systems |  | 4,108 |  |  | 10,308 |  |  | 12,727 |  |  | 41,327 |  |
| Systems |  | 71,467 |  |  | 82,200 |  |  | 188,428 |  |  | 222,953 |  |
| Embedded radio |  | 1,721 |  |  | 2,232 |  |  | 4,954 |  |  | 8,024 |  |
| Antennas/other |  | 9,967 |  |  | 7,233 |  |  | 26,209 |  |  | 27,672 |  |
| Total revenues |  | $ | 83,155 |  |  | $ | 91,665 |  |  | $ | 219,591 |  |  | $ | 258,649 |  |
| Revenue by Geographical Area |  |  |  |  |  |  |  |  |
| North America |  | $ | 21,052 |  |  | $ | 16,647 |  |  | $ | 53,519 |  |  | $ | 63,028 |  |
| South America |  | 18,496 |  |  | 27,666 |  |  | 45,820 |  |  | 71,751 |  |
| Europe, the Middle East and Africa |  | 31,617 |  |  | 36,398 |  |  | 90,690 |  |  | 91,537 |  |
| Asia Pacific |  | 11,990 |  |  | 10,954 |  |  | 29,562 |  |  | 32,333 |  |
| Total revenues |  | $ | 83,155 |  |  | $ | 91,665 |  |  | $ | 219,591 |  |  | $ | 258,649 |  |

[0001511737-13-000004:8k_2_02:48]
About our Non-GAAP Net Income and Adjustments

[0001511737-13-000004:8k_2_02:49]
Use of Non-GAAP Financial Information

[0001511737-13-000004:8k_2_02:50]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain recurring costs, expenses and gains.

[0001511737-13-000004:8k_2_02:51]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant recurring items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations. Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds. Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts and/or timing may vary significantly depending upon the Company’s activities and other factors, facilitates comparability of the Company’s operating performance from period to period. We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-13-000004:8k_2_02:52]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-13-000004:8k_2_02:53]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of recurring stock-based compensation expense and the tax effect of these adjustments. In addition, our non-GAAP diluted earnings per share is calculated using weighted-average shares outstanding as if Series A preferred stock outstanding had been converted to common stock throughout the periods presented. Examples of items excluded from net income are:

[0001511737-13-000004:8k_2_02:54]
| • | Recurring charges and gains, including: |

[0001511737-13-000004:8k_2_02:55]
| ◦ | Stock-based compensation expense is recognized in accordance with FASB Accounting Standards Codification, Topic 718, Stock Compensation. |

[0001511737-13-000004:8k_2_02:56]
| • | Tax effect of non-GAAP adjustments. After adjusting to exclude the items described above, we apply the principles of ASC 740, Income Taxes, to estimate the non-GAAP income tax provision. |

[0001511737-13-000004:8k_2_02:57]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-13-000004:8k_2_02:58]
These non-GAAP measures are not in accordance with or an alternative to GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures, used by other companies. The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP. Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results. We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-13-000004:8k_2_02:59]
For more information on the non-GAAP adjustments, please see the tables captioned “Reconciliation of GAAP Net Income to non-GAAP Net Income” and “Reconciliation of Weighted-Average Shares Used in Computing Net Income (Loss) Per Share of Common Stock-Diluted to Weighted-Average Shares Used In Computing Non-GAAP Diluted EPS” included in this press release.
