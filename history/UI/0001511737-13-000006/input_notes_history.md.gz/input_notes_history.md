# UI note change history — 0001445305-13-000191 → 0001511737-13-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-05-10):
[0001511737-13-000006:note_history:1]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which the Company uses as its corporate headquarters. The lease term is from April 1, 2012, through  July 31, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.
  (was, 2013-02-08, similarity 0.9949):
[0001445305-13-000191:note_history:1]
In December 2011, the Company entered into an agreement to lease approximately 64,512 square feet of office and research and development space located in San Jose, California, which the Company uses as its corporate headquarters. The lease term is from April 1, 2012, through  June 30, 2017. The lease has been categorized as an operating lease, and the total estimated rent expense to be recognized is $4.9 million.

- changed (2013-05-10):
[0001511737-13-000006:note_history:2]
At March 31, 2013, future minimum annual payments under operating leases are as follows (in thousands):
  (was, 2013-02-08, similarity 0.9543):
[0001445305-13-000191:note_history:2]
At December 31, 2012, future minimum annual payments under operating leases are as follows (in thousands):

- changed (2013-05-10):
[0001511737-13-000006:note_history:3]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the “EAR”) and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. Any such fines or restrictions may be material to the Company’s financial results in the period in which they are imposed.  The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.
  (was, 2013-02-08, similarity 0.8104):
[0001445305-13-000191:note_history:3]
OFAC is still reviewing the Company’s voluntary disclosure. In the Company’s submission, the Company provided OFAC with an explanation of the activities that led to the sales of its products in Iran and the failure to comply with the Export Administration Regulations (the “EAR”) and OFAC sanctions. Although the Company’s OFAC and OEE voluntary disclosures covered similar sets of facts, which led the OEE to resolve the case with the issuance of a warning letter, OFAC may conclude that the Company’s actions resulted in violations of U.S. export control and economic sanctions laws and warrant the imposition of penalties that could include fines, termination of the Company’s ability to export its products, and/or referral for criminal prosecution. Any such fines may be material to the Company’s financial results in the period in which they are imposed. The penalties may be imposed against the Company and/or its management. The maximum civil monetary penalty for the violations is up to $250,000 or twice the value of the transaction, whichever is greater, per violation. The Company cannot predict when OFAC will complete its review or decide upon the imposition of possible penalties.

- changed (2013-05-10):
[0001511737-13-000006:note_history:4]
While the Company has taken actions designed to ensure that export classification information is distributed to the appropriate personnel in a timely manner and has adopted policies and procedures to promote its compliance with applicable export laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2012.  However the Company cannot be sure such actions will be effective.  Additionally, the Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.
  (was, 2013-02-08, similarity 0.9343):
[0001445305-13-000191:note_history:4]
While the Company has now taken actions to ensure that export classification information is distributed to the appropriate personnel in a timely manner and has adopted policies and procedures to promote its compliance with these laws and regulations, including obtaining written distribution agreements with substantially all of its distributors that contain covenants requiring compliance with U.S. export control and economic sanctions law; notifying all of its distributors of their obligations and obtaining updated distribution agreements from distributors that accounted for approximately 99% of its revenue in fiscal 2012.  The Company's failure to amend all its distribution agreements and to implement more robust compliance controls immediately after the discovery of Iran-related sales activity in early 2010 may be aggravating factors that could impact the imposition of penalties imposed on the Company or its management.  Based on the facts known to the Company to date, the Company recorded an expense of $1.6 million for this export compliance matter in fiscal 2010, which represents management’s estimated exposure for fines in accordance with applicable accounting literature. This amount was calculated from information discovered through the Company’s internal review and this loss is deemed to be probable and reasonably estimable. However, the Company also believes that it is reasonably possible that the loss may be higher, but the Company cannot reasonably estimate the range of any further potential losses. Specific information has come to management’s attention and as such management cannot estimate any further range of possible losses. Should additional facts be discovered in the future and/or should actual fines or other penalties substantially differ from the Company’s estimates, its business, financial condition, cash flows and results of operations would be materially negatively impacted.

- changed (2013-05-10):
[0001511737-13-000006:note_history:5]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs. On March 26, 2013, the Company filed a motion to dismiss the complaint.  On April 30, 2013, the plaintiffs filed an opposition to the Company's motion to dismiss.
  (was, 2013-02-08, similarity 0.9303):
[0001445305-13-000191:note_history:5]
Beginning on September 7, 2012, two shareholder class action complaints were filed against the Company, certain of its officers and directors and the underwriters of the Company's initial public offering in the United States District Court for the Northern District of California. On January 30, 2013, the plaintiffs filed an Amended Consolidated Complaint, which alleges claims under the Securities Act of 1933, the Securities Exchange Act of 1934 and SEC Rule 10b-5 on behalf of a purported class of those who purchased the Company's common stock between October 14, 2011 and August 9, 2012 and/or acquired the Company's stock pursuant to or traceable to the registration statement for the initial public offering. The Amended Consolidated Complaint alleges that the defendants violated the federal securities laws by issuing false or misleading statements regarding the sale of counterfeit Company products.  The consolidated complaint seeks, among other things, damages and interest, rescission, and attorneys' fees and costs.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-05-10):
[0001511737-13-000006:note_history:6]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2012 included in its Annual Report on Form 10-K, as filed on September 28, 2012 with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2013 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2013-02-08, similarity 0.9452):
[0001445305-13-000191:note_history:6]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2012 included in its Annual Report on Form 10-K, as filed on September 28, 2012 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2012 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-05-10):
[0001511737-13-000006:note_history:7]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of March 31, 2013, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.
  (was, 2013-02-08, similarity 0.9928):
[0001445305-13-000191:note_history:7]
The Loan Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur indebtedness, grant liens, merge or consolidate, dispose of assets, pay dividends or make distributions, make investments, make acquisitions, prepay certain indebtedness, change the nature of its business, enter into certain transactions with affiliates, enter into restrictive agreements, and make capital expenditures, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain a minimum debt service coverage ratio, a maximum leverage ratio, and a minimum liquidity ratio.  As of December 31, 2012, the Company was in compliance with all affirmative and negative covenants, debt service coverage ratio, leverage ratio and liquidity ratio requirements.

- changed (2013-05-10):
[0001511737-13-000006:note_history:8]
During the three and nine months ended March 31, 2013, the Company made aggregate payments of $1.3 million and $3.1 million, respectively, against the loan balance.  As of March 31, 2013, the Company has classified $5.0 million and $72.4 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.
  (was, 2013-02-08, similarity 0.9099):
[0001445305-13-000191:note_history:8]
During the three and six months ended December 31, 2012, the Company made aggregate payments of $1.3 million and $1.8 million, respectively, against the loan balance.  As of December 31, 2012, the Company has classified $5.0 million and $73.6 million in short-term and long-term debt, respectively, on its consolidated balance sheet related to the Loan Agreement.

- changed (2013-05-10):
[0001511737-13-000006:note_history:9]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2013 (in thousands):
  (was, 2013-02-08, similarity 0.961):
[0001445305-13-000191:note_history:9]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2012 (in thousands):


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-05-10):
[0001511737-13-000006:note_history:10]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2013 (in thousands):
  (was, 2013-02-08, similarity 0.961):
[0001445305-13-000191:note_history:10]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2012 (in thousands):
