# UI 8-K — 0001511737-15-000016 filed 2015-05-07

## item codes, every 8-K on or before 2015-05-07

- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2015-05-07

- none on or before 2015-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001511737-15-000016:8k_2_02:1]
EX-99.1
2
exhibit991q32015.htm
PRESS RELEASE OF UBIQUITI NETWORKS, INC.

[0001511737-15-000016:8k_2_02:2]
Exhibit 99.1 Q3 2015

[0001511737-15-000016:8k_2_02:3]
Exhibit 99.1

[0001511737-15-000016:8k_2_02:4]
UBIQUITI NETWORKS REPORTS THIRD QUARTER FISCAL 2015 FINANCIAL RESULTS

[0001511737-15-000016:8k_2_02:5]
~ Service Provider Technology Growth ~

[0001511737-15-000016:8k_2_02:6]
~ Non-GAAP Diluted EPS of $0.47 Per Share ~

[0001511737-15-000016:8k_2_02:7]
San Jose, Calif. - May 7, 2015 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the third fiscal quarter of 2015, ended March 31, 2015.

[0001511737-15-000016:8k_2_02:8]
Third Quarter Financial Summary

[0001511737-15-000016:8k_2_02:9]
| • | Revenues of $147.5 million |

[0001511737-15-000016:8k_2_02:10]
| • | GAAP gross profit of $66.0 million and non-GAAP gross profit of $66.1 million |

[0001511737-15-000016:8k_2_02:11]
| • | GAAP net income of $41.1 million and non-GAAP net income of $42.0 million |

[0001511737-15-000016:8k_2_02:12]
| • | GAAP diluted EPS of $0.46 and non-GAAP diluted EPS of $0.47 |

[0001511737-15-000016:8k_2_02:13]
| • | $36.7 million in net cash provided by operating activities |

[0001511737-15-000016:8k_2_02:14]
Recent Financial Highlights

[0001511737-15-000016:8k_2_02:15]
| • | Service Provider Technology revenues increased over 6% in just one quarter, driven by strong demand for AirMAX® AC products. |

[0001511737-15-000016:8k_2_02:16]
| • | Enterprise Technology revenues increased over 50% year-over-year, fueled by UniFi® access points and other industry-leading products targeting the Enterprise market. |

[0001511737-15-000016:8k_2_02:17]
| • | North American revenues increased over 56% year-over-year, reflecting consistent demand for both our Service Provider Technology and Enterprise Technology products in this historically underpenetrated market. |

[0001511737-15-000016:8k_2_02:18]
| • | Refinanced our credit facility, providing for a $100 million term loan and a $200 million revolving credit loan. |

[0001511737-15-000016:8k_2_02:19]
Recent Product Highlights

[0001511737-15-000016:8k_2_02:20]
| • | Shipped the first airFiber® X and sold related antennas, a revolutionary new platform for the global last-mile wireless industry. |

[0001511737-15-000016:8k_2_02:21]
| • | Extended the UniFi® Video surveillance management system with the introduction of the UniFi Video Camera Micro and new UniFi Video software, including iOS application. |

[0001511737-15-000016:8k_2_02:22]
| • | Shipped our recently launched Enterprise Technology products to distributors, including the first UniFi Switches, as well as the PRO and Executive models of the UniFi VoIP Phones. |

[0001511737-15-000016:8k_2_02:23]
| • | Announced the EdgeRouterTM X, an advanced gigabit Ethernet router that delivers world-leading price-to-performance value in an ultra‑compact form factor. |

[0001511737-15-000016:8k_2_02:24]
“We are focused on advancing our R&D and expanding our market opportunities in the coming quarters,” said Robert J. Pera, Founder and Chief Executive Officer of Ubiquiti Networks, Inc.

[0001511737-15-000016:8k_2_02:25]
Financial Highlights ($, in millions, except per share data)

[0001511737-15-000016:8k_2_02:26]
| Income statement highlights |  | F3Q15 |  | F2Q15 |  | F3Q14 |
| Revenues |  | 147.5 |  | 153.1 |  | 148.3 |
| Service Provider Technology |  | 106.3 |  | 99.7 |  | 121.0 |
| Enterprise Technology |  | 41.2 |  | 53.4 |  | 27.3 |
| Cost of Revenues |  | 81.5 |  | 84.1 |  | 82.7 |
| Gross Profit |  | 66.0 |  | 69.0 |  | 65.6 |
| Gross Profit (%) |  | 44.7% |  | 45.1% |  | 44.2% |
| Total Operating Expenses |  | 20.7 |  | 18.3 |  | 15.5 |
| Income from Operations |  | 45.2 |  | 50.7 |  | 50.1 |
| GAAP Net Income |  | 41.1 |  | 46.3 |  | 45.2 |
| GAAP EPS (diluted) |  | 0.46 |  | 0.52 |  | 0.50 |
| Non-GAAP Net Income |  | 42.0 |  | 47.1 |  | 45.2 |
| Non-GAAP EPS (diluted) |  | 0.47 |  | 0.53 |  | 0.50 |

[0001511737-15-000016:8k_2_02:27]
Balance Sheet Highlights

[0001511737-15-000016:8k_2_02:28]
Total cash and cash equivalents as of March 31, 2015 were $451.2 million, compared with $388.6 million as of December 31, 2014.  The increase in cash and cash equivalents was primarily as a result of cash provided by operating activities of $36.7 million for the quarter and net proceeds from a new debt facility.  We believe that our cash position will allow us to make investments that will continue to enhance our competitive position and product portfolio.

[0001511737-15-000016:8k_2_02:29]
This quarter we saw days sales outstanding in accounts receivable ("DSO") of 43 days, compared with 44 days in the prior quarter, and 30 days in the third quarter of fiscal 2014.

[0001511737-15-000016:8k_2_02:30]
Business Outlook

[0001511737-15-000016:8k_2_02:31]
The following are Ubiquiti’s financial performance estimates for the fourth quarter of fiscal 2015:

[0001511737-15-000016:8k_2_02:32]
| • | Revenues of between $140 million and $150 million |

[0001511737-15-000016:8k_2_02:33]
| • | GAAP diluted EPS of $0.42 - $0.47 |

[0001511737-15-000016:8k_2_02:34]
| • | Non-GAAP diluted EPS of $0.43 - $0.48 |

[0001511737-15-000016:8k_2_02:35]
Conference Call Information

[0001511737-15-000016:8k_2_02:36]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001511737-15-000016:8k_2_02:37]
To listen to the Q&A call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001511737-15-000016:8k_2_02:38]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-15-000016:8k_2_02:39]
About Ubiquiti Networks

[0001511737-15-000016:8k_2_02:40]
Ubiquiti Networks (NASDAQ: UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere. With over 28 million devices sold worldwide, Ubiquiti is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, UniFi® VoIP,

[0001511737-15-000016:8k_2_02:41]
UniFi® Switch, mFi® and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001511737-15-000016:8k_2_02:42]
Ubiquiti, the Ubiquiti U logo, Ubiquiti Networks, airMAX, airFiber, airCRM, UniFi, mFi, EdgeMAX, and EdgeRouter are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001511737-15-000016:8k_2_02:43]
The Ubiquiti Networks, Inc. logo is available at http://www.globenewswire.com/newsroom/prs/?pkgid=24865.

[0001511737-15-000016:8k_2_02:44]
Investor Relations Contact

[0001511737-15-000016:8k_2_02:45]
Anne Fazioli

[0001511737-15-000016:8k_2_02:46]
Ubiquiti Networks, Vice President of Investor Relations

[0001511737-15-000016:8k_2_02:47]
IR@ubnt.com

[0001511737-15-000016:8k_2_02:48]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities laws; and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2014, and subsequent filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001511737-15-000016:8k_2_02:49]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein.  You should

[0001511737-15-000016:8k_2_02:50]
review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001511737-15-000016:8k_2_02:51]
Use of Non-GAAP Financial Information

[0001511737-15-000016:8k_2_02:52]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, purchase commitment termination fee and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and nine months ended March 31, 2015 and 2014 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001511737-15-000016:8k_2_02:53]
| Ubiquiti Networks Inc.Condensed Consolidated Statement of Operations(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenues |  | $ | 147,456 |  |  | $ | 148,331 |  |  | $ | 450,680 |  |  | $ | 416,457 |  |
| Cost of revenues |  | 81,479 |  |  | 82,719 |  |  | 254,631 |  |  | 231,851 |  |
| Gross profit |  | 65,977 |  |  | 65,612 |  |  | 196,049 |  |  | 184,606 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 15,236 |  |  | 9,413 |  |  | 39,893 |  |  | 23,807 |  |
| Sales, general and administrative |  | 5,510 |  |  | 6,064 |  |  | 16,568 |  |  | 17,648 |  |
| Total operating expenses |  | 20,746 |  |  | 15,477 |  |  | 56,461 |  |  | 41,455 |  |
| Income from operations |  | 45,231 |  |  | 50,135 |  |  | 139,588 |  |  | 143,151 |  |
| Interest expense and other, net |  | (763 | ) |  | (283 | ) |  | (804 | ) |  | (778 | ) |
| Income before provision for income taxes |  | 44,468 |  |  | 49,852 |  |  | 138,784 |  |  | 142,373 |  |
| Provision for income taxes |  | 3,331 |  |  | 4,653 |  |  | 13,639 |  |  | 14,854 |  |
| Net income |  | $ | 41,137 |  |  | $ | 45,199 |  |  | $ | 125,145 |  |  | $ | 127,519 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.47 |  |  | $ | 0.51 |  |  | $ | 1.42 |  |  | $ | 1.45 |  |
| Diluted |  | $ | 0.46 |  |  | $ | 0.50 |  |  | $ | 1.40 |  |  | $ | 1.42 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |
| Basic |  | 87,904 |  |  | 87,901 |  |  | 88,115 |  |  | 87,656 |  |
| Diluted |  | 89,400 |  |  | 89,775 |  |  | 89,707 |  |  | 89,667 |  |
| Cash dividends declared per common share |  | $ | — |  |  | $ | — |  |  | $ | 0.17 |  |  | $ | — |  |

[0001511737-15-000016:8k_2_02:54]
| Ubiquiti Networks Inc.Reconciliation of GAAP Net Income to Non-GAAP Net Income(In thousands, except per share data)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net income |  | $ | 41,137 |  |  | $ | 45,199 |  |  | $ | 125,145 |  |  | $ | 127,519 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |
| Cost of revenues |  | 141 |  |  | 153 |  |  | 440 |  |  | 445 |  |
| Research and development |  | 810 |  |  | 630 |  |  | 2,499 |  |  | 1,679 |  |
| Sales, general and administrative |  | 425 |  |  | 258 |  |  | 1,240 |  |  | 1,506 |  |
| Purchase commitment termination fee |  | — |  |  | — |  |  | 5,500 |  |  | — |  |
| Gain on reversal of charge for an export compliance matter |  | — |  |  | (1,121 | ) |  | — |  |  | (1,121 | ) |
| Tax effect of non-GAAP adjustments |  | (550 | ) |  | 32 |  |  | (2,331 | ) |  | (1,004 | ) |
| Non-GAAP net income |  | $ | 41,963 |  |  | $ | 45,151 |  |  | $ | 132,493 |  |  | $ | 129,024 |  |
| Non-GAAP diluted EPS |  | $ | 0.47 |  |  | $ | 0.50 |  |  | $ | 1.48 |  |  | $ | 1.44 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  | 89,400 |  |  | 89,775 |  |  | 89,707 |  |  | 89,667 |  |

[0001511737-15-000016:8k_2_02:55]
| Ubiquiti Networks Inc.Condensed Consolidated Balance Sheets(In thousands)(Unaudited) |
|  |  | March 31, 2015 |  | June 30, 2014(1) |
| Assets |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 451,159 |  |  | $ | 347,097 |  |
| Accounts receivable, net |  | 69,908 |  |  | 54,871 |  |
| Inventories |  | 41,717 |  |  | 46,349 |  |
| Current deferred tax asset |  | 797 |  |  | 884 |  |
| Prepaid income taxes |  | 7,394 |  |  | 3,256 |  |
| Prepaid expenses and other current assets |  | 30,216 |  |  | 13,267 |  |
| Total current assets |  | 601,191 |  |  | 465,724 |  |
| Property and equipment, net |  | 14,759 |  |  | 7,260 |  |
| Long-term deferred tax asset |  | 1,100 |  |  | 1,255 |  |
| Other long–term assets |  | 2,235 |  |  | 1,912 |  |
| Total assets |  | $ | 619,285 |  |  | $ | 476,151 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 48,662 |  |  | $ | 33,933 |  |
| Income taxes payable |  | 787 |  |  | 2,499 |  |
| Debt - short-term |  | 10,000 |  |  | — |  |
| Other current liabilities |  | 14,930 |  |  | 15,883 |  |
| Total current liabilities |  | 74,379 |  |  | 52,315 |  |
| Long-term taxes payable |  | 18,532 |  |  | 15,346 |  |
| Debt - long-term |  | 90,000 |  |  | 72,254 |  |
| Deferred revenues - long-term |  | 997 |  |  | 972 |  |
| Total liabilities |  | 183,908 |  |  | 140,887 |  |
| Stockholders’ equity: |  |  |  |  |
| Common stock |  | 88 |  |  | 88 |  |
| Additional paid–in capital |  | 11,996 |  |  | 145,872 |  |
| Treasury stock |  | — |  |  | (123,864 | ) |
| Retained earnings |  | 423,293 |  |  | 313,168 |  |
| Total stockholders’ equity |  | 435,377 |  |  | 335,264 |  |
| Total liabilities and stockholders’ equity |  | $ | 619,285 |  |  | $ | 476,151 |  |

[0001511737-15-000016:8k_2_02:56]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2014. |

[0001511737-15-000016:8k_2_02:57]
| Ubiquiti Networks Inc.Revenues by Product Type (In thousands)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Service provider technology |  | $ | 106,242 |  |  | $ | 120,987 |  |  | $ | 313,233 |  |  | $ | 326,658 |  |
| Enterprise technology |  | 41,214 |  |  | 27,344 |  |  | 137,447 |  |  | 89,799 |  |
| Total revenues |  | $ | 147,456 |  |  | $ | 148,331 |  |  | $ | 450,680 |  |  | $ | 416,457 |  |

[0001511737-15-000016:8k_2_02:58]
| Ubiquiti Networks Inc.Revenues by Geographical Area(In thousands)(Unaudited) |
|  |  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| North America |  | $ | 45,692 |  |  | $ | 29,178 |  |  | $ | 153,400 |  |  | $ | 99,178 |  |
| South America |  | 17,866 |  |  | 25,059 |  |  | 71,242 |  |  | 73,827 |  |
| Europe, the Middle East and Africa |  | 66,770 |  |  | 77,883 |  |  | 177,474 |  |  | 189,591 |  |
| Asia Pacific |  | 17,128 |  |  | 16,211 |  |  | 48,564 |  |  | 53,861 |  |
| Total revenues |  | $ | 147,456 |  |  | $ | 148,331 |  |  | $ | 450,680 |  |  | $ | 416,457 |  |

[0001511737-15-000016:8k_2_02:59]
About our Non-GAAP Net Income and Adjustments

[0001511737-15-000016:8k_2_02:60]
Use of Non-GAAP Financial Information

[0001511737-15-000016:8k_2_02:61]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains.

[0001511737-15-000016:8k_2_02:62]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001511737-15-000016:8k_2_02:63]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001511737-15-000016:8k_2_02:64]
We compute non-GAAP net income and non-GAAP diluted earnings per share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001511737-15-000016:8k_2_02:65]
| • | Stock-based compensation expense |

[0001511737-15-000016:8k_2_02:66]
| • | Reserve against vendor deposits relating to a purchase commitment termination fee |

[0001511737-15-000016:8k_2_02:67]
| • | Gain on reversal of charge for an export compliance matter |

[0001511737-15-000016:8k_2_02:68]
| • | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001511737-15-000016:8k_2_02:69]
Usefulness of Non-GAAP Financial Information to Investors

[0001511737-15-000016:8k_2_02:70]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.  We expect to continue to incur expenses of a nature similar to the non-GAAP adjustments described above, and exclusion of these items from our non-GAAP net income and non-GAAP earnings per diluted share should not be construed as an inference that these costs are unusual, infrequent or non-recurring.

[0001511737-15-000016:8k_2_02:71]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
