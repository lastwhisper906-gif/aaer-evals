# UI notes — 0001511737-15-000018


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-15-000018:notes:1]
[same as prior period, unchanged from 0001511737-15-000009:notes:1]

[0001511737-15-000018:notes:2]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |  | March 31, |  | June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Customer A | * |  | 11 | % |  | 10 | % |  | 13 | % |  | * |  |  | 13 | % |
| Customer B | * |  | * |  |  | 10 | % |  | * |  |  | 14 | % |  | 12 | % |
| Customer C | * |  | * |  |  | * |  |  | * |  |  | 12 | % |  | 12 | % |
| Customer D | * |  | 10 | % |  | * |  |  | * |  |  | * |  |  | * |  |

[0001511737-15-000018:notes:3]
[same as prior period, unchanged from 0001511737-15-000009:notes:3]


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-15-000018:notes:4]
[same as prior period, unchanged from 0001511737-15-000009:notes:4]

[0001511737-15-000018:notes:5]
[same as prior period, unchanged from 0001511737-15-000009:notes:5]

[0001511737-15-000018:notes:6]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develop high performance networking technology for service providers and enterprises.

[0001511737-15-000018:notes:7]
[same as prior period, unchanged from 0001511737-15-000009:notes:7]

[0001511737-15-000018:notes:8]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2014 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.

[0001511737-15-000018:notes:9]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014, included in its Annual Report on Form 10-K, as filed on August 22, 2014, with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2015, are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-15-000018:notes:10]
COMMITMENTS AND CONTINGENCIES

[0001511737-15-000018:notes:11]
Operating Leases

[0001511737-15-000018:notes:12]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2020.

[0001511737-15-000018:notes:13]
At March 31, 2015, future minimum annual payments under operating leases are as follows (in thousands):

[0001511737-15-000018:notes:14]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 895 |  |  | $ | 3,860 |  |  | $ | 2,675 |  |  | $ | 1,128 |  |  | $ | 219 |  |  | $ | 169 |  |  | $ | 8,946 |  |

[0001511737-15-000018:notes:15]
Purchase Obligations

[0001511737-15-000018:notes:16]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had inventory purchase obligations of $12.8 million as of March 31, 2015.

[0001511737-15-000018:notes:17]
Other Obligations

[0001511737-15-000018:notes:18]
The Company had other obligations of $4.6 million as of March 31, 2015, which consisted primarily of commitments related to research and development projects.

[0001511737-15-000018:notes:19]
Indemnification Obligations

[0001511737-15-000018:notes:20]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-15-000018:notes:21]
Legal Matters

[0001511737-15-000018:notes:22]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-15-000018:notes:23]
Shareholder Class Action Lawsuits

[0001511737-15-000018:notes:24]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-15-000018:notes:25]
DEBT

[0001511737-15-000018:notes:26]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million term loan facility.

[0001511737-15-000018:notes:27]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).

[0001511737-15-000018:notes:28]
On March 3, 2015, the Company and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender's sole discretion), and matures on March 3, 2020.  The term loan facility was fully drawn at closing,  $72.3 million of which was used to repay the outstanding balance under the Original Credit Agreement.

[0001511737-15-000018:notes:29]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company's $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company's option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-15-000018:notes:30]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-15-000018:notes:31]
The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

[0001511737-15-000018:notes:32]
No payments were made during the three or nine months ended March 31, 2015 against the term loan balance under the Amended Credit Agreement.  During the three and nine months ended March 31, 2014, the Company made aggregate payments of $1.3 million and $3.8 million, respectively, against the loan balance under the Original Credit Agreement.  As of March 31, 2015, the Company has classified $10.0 million and $90.0 million of short term and long-term debt, respectively, on its consolidated balance sheet related to the Amended Credit Agreement.

[0001511737-15-000018:notes:33]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2015 (in thousands):

[0001511737-15-000018:notes:34]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 10,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | 100,000 |  |
| Interest and other payments on debt payment obligations | 674 |  |  | 2,057 |  |  | 1,876 |  |  | 1,645 |  |  | 1,380 |  |  | 812 |  |  | 8,444 |  |
| Total | $ | 3,174 |  |  | $ | 12,057 |  |  | $ | 13,126 |  |  | $ | 16,645 |  |  | $ | 16,380 |  |  | $ | 47,062 |  |  | $ | 108,444 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-15-000018:notes:35]
[same as prior period, unchanged from 0001511737-15-000009:notes:34]

[0001511737-15-000018:notes:36]
|  | March 31, 2015 |  | June 30, 2014 |
| Vendor deposits | $ | 25,850 |  |  | $ | 8,043 |  |
| Other current assets | 4,366 |  |  | 5,224 |  |
|  | $ | 30,216 |  |  | $ | 13,267 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-15-000018:notes:37]
[same as prior period, unchanged from 0001511737-15-000009:notes:36]

[0001511737-15-000018:notes:38]
[same as prior period, unchanged from 0001511737-15-000009:notes:37]

[0001511737-15-000018:notes:39]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of March 31, 2015, the Company had 9,881,758 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-15-000018:notes:40]
[same as prior period, unchanged from 0001511737-15-000009:notes:39]

[0001511737-15-000018:notes:41]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and nine months ended March 31, 2015 and 2014 (in thousands):

[0001511737-15-000018:notes:42]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of sales | $ | 141 |  |  | $ | 153 |  |  | $ | 440 |  |  | $ | 445 |  |
| Research and development | 810 |  |  | 630 |  |  | 2,499 |  |  | 1,679 |  |
| Sales, general and administrative | 425 |  |  | 258 |  |  | 1,240 |  |  | 1,506 |  |
|  | $ | 1,376 |  |  | $ | 1,041 |  |  | $ | 4,179 |  |  | $ | 3,630 |  |

[0001511737-15-000018:notes:43]
[same as prior period, unchanged from 0001511737-15-000009:notes:42]

[0001511737-15-000018:notes:44]
The following is a summary of option activity for the Company’s stock incentive plans for the nine months ended March 31, 2015:

[0001511737-15-000018:notes:45]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue |
|  |  |  |  |  |  |  | (In thousands) |
| Balance, June 30, 2014 | 2,657,142 |  |  | $ | 2.96 |  |  |  |  |  |
| Exercised | (203,698 | ) |  | 4.17 |  |  |  |  |  |
| Forfeitures and cancellations | (25,348 | ) |  | 10.36 |  |  |  |  |  |
| Balance, March 31, 2015 | 2,428,096 |  |  | $ | 2.78 |  |  | 4.11 |  | $ | 65,002 |  |
| Vested and expected to vest as of March 31, 2015 | 2,418,844 |  |  | $ | 2.74 |  |  | 4.10 |  | $ | 64,837 |  |
| Vested and exercisable as of March 31, 2015 | 2,224,808 |  |  | $ | 1.98 |  |  | 3.79 |  | $ | 61,347 |  |

[0001511737-15-000018:notes:46]
During the three months ended March 31, 2015 and 2014, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $2.1 million and $13.2 million, respectively, as determined as of the date of option exercise. During the nine months ended March 31, 2015 and 2014, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $7.1 million and $26.9 million, respectively, as determined as of the date of option exercise.

[0001511737-15-000018:notes:47]
As of March 31, 2015, the Company had unrecognized compensation costs of $1.1 million related to stock options which the Company expects to recognize over a weighted-average period of 1.7 years. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-15-000018:notes:48]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is being amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and nine months ended March 31, 2015 and 2014.

[0001511737-15-000018:notes:49]
[same as prior period, unchanged from 0001511737-15-000009:notes:48]

[0001511737-15-000018:notes:50]
[same as prior period, unchanged from 0001511737-15-000009:notes:49]

[0001511737-15-000018:notes:51]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |
| Non-vested RSUs, June 30, 2014 | 549,702 |  |  | $ | 22.65 |  |
| RSUs granted | 129,801 |  |  | 34.13 |  |
| RSUs vested | (161,711 | ) |  | 21.82 |  |
| RSUs canceled | (21,912 | ) |  | 22.87 |  |
| Non-vested RSUs, March 31, 2015 | 495,880 |  |  | $ | 25.92 |  |

[0001511737-15-000018:notes:52]
The intrinsic value of RSUs vested in the three months ended March 31, 2015 and 2014 was $1.9 million and $2.4 million, respectively.  The intrinsic value of RSUs vested in the nine months ended March 31, 2015 and 2014 was $5.7 million and $5.3 million, respectively.

[0001511737-15-000018:notes:53]
As of March 31, 2015, there was unrecognized compensation costs related to RSUs of $10.1 million which the Company expects to recognize over a weighted average period of 2.9 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-15-000018:notes:54]
[same as prior period, unchanged from 0001511737-15-000009:notes:53]

[0001511737-15-000018:notes:55]
[same as prior period, unchanged from 0001511737-15-000009:notes:54]

[0001511737-15-000018:notes:56]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |
| Net income and comprehensive income | $ | 41,137 |  |  | $ | 45,199 |  |  | $ | 125,145 |  |  | $ | 127,519 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 87,904 |  |  | 87,901 |  |  | 88,115 |  |  | 87,656 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,367 |  |  | 1,646 |  |  | 1,417 |  |  | 1,754 |  |
| Restricted stock units | 129 |  |  | 228 |  |  | 175 |  |  | 257 |  |
| Weighted-average shares used in computing diluted net income per share | 89,400 |  |  | 89,775 |  |  | 89,707 |  |  | 89,667 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.47 |  |  | $ | 0.51 |  |  | $ | 1.42 |  |  | $ | 1.45 |  |
| Diluted | $ | 0.46 |  |  | $ | 0.50 |  |  | $ | 1.40 |  |  | $ | 1.42 |  |

[0001511737-15-000018:notes:57]
[same as prior period, unchanged from 0001511737-15-000009:notes:56]

[0001511737-15-000018:notes:58]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Stock options | 1 |  |  | — |  |  | — |  |  | — |  |
| Restricted stock units | 101 |  |  | 6 |  |  | 5 |  |  | 85 |  |
|  | 102 |  |  | 6 |  |  | 5 |  |  | 85 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-15-000018:notes:59]
As of March 31, 2015 and June 30, 2014, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-15-000018:notes:60]
|  | March 31, 2015 |  | June 30, 2014 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 100,000 |  |  | $ | — |  |  | $ | 100,000 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-15-000018:notes:61]
[same as prior period, unchanged from 0001511737-15-000009:notes:60]

[0001511737-15-000018:notes:62]
[same as prior period, unchanged from 0001511737-15-000009:notes:61]

[0001511737-15-000018:notes:63]
[same as prior period, unchanged from 0001511737-15-000009:notes:62]

[0001511737-15-000018:notes:64]
[same as prior period, unchanged from 0001511737-15-000009:notes:63]

[0001511737-15-000018:notes:65]
[same as prior period, unchanged from 0001511737-15-000009:notes:64]

[0001511737-15-000018:notes:66]
For certain of the Company’s financial instruments, including accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of March 31, 2015, we held $392.3 million of our $451.2 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we would incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-15-000018:notes:67]
At March 31, 2015 and June 30, 2014 the Company had debt associated with its Amended Credit Agreement and Original Credit Agreement, respectively, with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-15-000018:notes:68]
[same as prior period, unchanged from 0001511737-15-000009:notes:67]

[0001511737-15-000018:notes:69]
As of March 31, 2015, the Company had approximately $18.2 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At March 31, 2015, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded an increase of its unrecognized tax benefits of $1.2 million for the three months ended March 31, 2015. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-15-000018:notes:70]
The Company recorded income tax provisions of $3.3 million and $13.6 million for the three and nine months ended March 31, 2015, respectively. The Company’s estimated 2015 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-15-000018:notes:71]
[same as prior period, unchanged from 0001511737-15-000009:notes:70]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-15-000018:notes:72]
Recent Accounting Pronouncements

[0001511737-15-000018:notes:73]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-15-000018:notes:74]
Step 1: Identify the contract(s) with a customer.

[0001511737-15-000018:notes:75]
Step 2: Identify the performance obligations in the contract.

[0001511737-15-000018:notes:76]
Step 3: Determine the transaction price.

[0001511737-15-000018:notes:77]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-15-000018:notes:78]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-15-000018:notes:79]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in April 2015, the FASB issued a proposal to defer the effective date by one year, to December 15, 2017,  to provide adequate time to effectively implement the new standard.  The Company is currently assessing the impact of this new guidance.

[0001511737-15-000018:notes:80]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company's balance sheet and is not expected to have any effect on the Company's operating results.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-15-000018:notes:81]
[same as prior period, unchanged from 0001511737-15-000009:notes:79]

[0001511737-15-000018:notes:82]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations within cost of revenues. The warranties are typically in effect for 12 months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical factors including product failure rates, material usage, and service delivery cost incurred in replacing products. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-15-000018:notes:83]
[same as prior period, unchanged from 0001511737-15-000009:notes:81]

[0001511737-15-000018:notes:84]
|  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |
| Beginning balance | $ | 2,850 |  |  | $ | 2,913 |  |
| Accruals for warranties issued during the period | 3,253 |  |  | 3,287 |  |
| Warranty costs incurred during the period | (2,953 | ) |  | (3,250 | ) |
|  | $ | 3,150 |  |  | $ | 2,950 |  |


## us-gaap:PropertyPlantAndEquipmentScheduleOfSignificantAcquisitionsAndDisposalsTextBlock

[0001511737-15-000018:notes:85]
[same as prior period, unchanged from 0001511737-15-000009:notes:83]

[0001511737-15-000018:notes:86]
|  | March 31, 2015 |  | June 30, 2014 |
| Testing equipment | $ | 4,704 |  |  | $ | 3,785 |  |
| Computer and other equipment | 4,230 |  |  | 1,019 |  |
| Tooling equipment | 3,633 |  |  | 2,898 |  |
| Furniture and fixtures | 1,211 |  |  | 973 |  |
| Leasehold improvements | 4,779 |  |  | 3,173 |  |
| Software | 2,715 |  |  | 521 |  |
| Construction in progress | 1,500 |  |  | — |  |
|  | 22,772 |  |  | 12,369 |  |
| Less: Accumulated depreciation and amortization | (8,013 | ) |  | (5,109 | ) |
|  | $ | 14,759 |  |  | $ | 7,260 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-15-000018:notes:87]
[same as prior period, unchanged from 0001511737-15-000009:notes:85]

[0001511737-15-000018:notes:88]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Service Provider Technology | $ | 106,242 |  |  | 72 | % |  | $ | 120,987 |  |  | 82 | % |  | $ | 313,233 |  |  | 70 | % |  | $ | 326,658 |  |  | 78 | % |
| Enterprise Technology | 41,214 |  |  | 28 | % |  | 27,344 |  |  | 18 | % |  | 137,447 |  |  | 30 | % |  | 89,799 |  |  | 22 | % |
| Total revenues | $ | 147,456 |  |  | 100 | % |  | $ | 148,331 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-15-000018:notes:89]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-15-000018:notes:90]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $150,000 and $330,000 in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2015, respectively.  In comparison, the Company recognized a total of approximately $120,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended March 31, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-15-000018:notes:91]
[same as prior period, unchanged from 0001511737-15-000009:notes:89]

[0001511737-15-000018:notes:92]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| North America (1) | $ | 45,692 |  |  | 31 | % |  | $ | 29,178 |  |  | 20 | % |  | $ | 153,400 |  |  | 34 | % |  | $ | 99,178 |  |  | 24 | % |
| South America | 17,866 |  |  | 12 | % |  | 25,059 |  |  | 17 | % |  | 71,242 |  |  | 16 | % |  | 73,827 |  |  | 18 | % |
| Europe, the Middle East and Africa | 66,770 |  |  | 45 | % |  | 77,883 |  |  | 52 | % |  | 177,474 |  |  | 39 | % |  | 189,591 |  |  | 45 | % |
| Asia Pacific | 17,128 |  |  | 12 | % |  | 16,211 |  |  | 11 | % |  | 48,564 |  |  | 11 | % |  | 53,861 |  |  | 13 | % |
| Total revenues | $ | 147,456 |  |  | 100 | % |  | $ | 148,331 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |

[0001511737-15-000018:notes:93]
| (1) | Revenue for the United States was $43.9 million and $27.7 million for the three months ended March 31, 2015 and 2014, respectively. Revenue for the United States was $146.1 million and $95.0 million for the nine months ended March 31, 2015 and 2014, respectively. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001511737-15-000018:notes:94]
consisted of the following (in thousands):

[0001511737-15-000018:notes:95]
|  | March 31, 2015 |  | June 30, 2014 |
| Accrued compensation and benefits | $ | 2,448 |  |  | $ | 3,432 |  |
| Warranty accrual | 3,150 |  |  | 2,850 |  |
| Deferred revenue - short term | 2,474 |  |  | 4,218 |  |
| Customer deposits | 489 |  |  | 1,834 |  |
| Other accruals | 6,369 |  |  | 3,549 |  |
|  | $ | 14,930 |  |  | $ | 15,883 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-15-000018:notes:96]
[same as prior period, unchanged from 0001511737-15-000009:notes:94]

[0001511737-15-000018:notes:97]
|  | March 31, 2015 |  | June 30, 2014 |
| Finished goods | $ | 39,865 |  |  | $ | 45,881 |  |
| Raw materials | 1,852 |  |  | 468 |  |
|  | $ | 41,717 |  |  | $ | 46,349 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-15-000018:notes:98]
[same as prior period, unchanged from 0001511737-15-000009:notes:98]

[0001511737-15-000018:notes:99]
[same as prior period, unchanged from 0001511737-15-000009:notes:99]

[0001511737-15-000018:notes:100]
[same as prior period, unchanged from 0001511737-15-000009:notes:100]

[0001511737-15-000018:notes:101]
| • | Enterprise Technology includes the Company's UniFi and mFi platforms, including Unifi Access Point ("UAP") products, Unifi Video Products, Unifi Voice Over IP ("VOIP") phones and Unifi switches. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-15-000018:notes:102]
[same as prior period, unchanged from 0001511737-15-000009:notes:102]

[0001511737-15-000018:notes:103]
[same as prior period, unchanged from 0001511737-15-000009:notes:103]

[0001511737-15-000018:notes:104]
[same as prior period, unchanged from 0001511737-15-000009:notes:104]

[0001511737-15-000018:notes:105]
The Company capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. The cost of internally developed software is amortized on a straight-line basis over its estimated useful life, typically three (3) to five (5) years.  During the three and nine months ended March 31, 2015, the Company capitalized $1.5 million and $3.0 million of software development costs, respectively, which is included as property and equipment in the Company's balance sheet as of  March 31, 2015.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-15-000018:notes:106]
[same as prior period, unchanged from 0001511737-15-000009:notes:106]

[0001511737-15-000018:notes:107]
As of March 31, 2015 and June 30, 2014, the authorized capital of the Company included 500,000,000 shares of common stock.  As of March 31, 2015 and June 30, 2014, 87,968,963 and 88,179,448 shares of common stock were outstanding.

[0001511737-15-000018:notes:108]
Treasury Stock Retirement

[0001511737-15-000018:notes:109]
In February 2015, we retired 44,768,739 shares of the Company's treasury stock.  These retired shares are now included in the Company’s pool of authorized but unissued shares. The retired stock had a carrying value of $138.9 million. The Company’s policy upon the formal retirement of treasury stock is to reflect the excess over par value as a deduction from Additional Paid-in Capital.

[0001511737-15-000018:notes:110]
[same as prior period, unchanged from 0001511737-15-000009:notes:108]

[0001511737-15-000018:notes:111]
On May 29, 2014, the Company announced that its Board of Directors authorized the Company to repurchase up to $75.0 million of its common stock. The share repurchase program commenced June 2, 2014 and will expire after one year.  The Company did not repurchase any shares of its common stock during the three months ended March 31, 2015.  During the nine months ended March 31, 2015, the company repurchased 529,779 shares of its common stock at an average price per share of  $28.29 for an aggregate amount of $15.0 million.  As of March 31, 2015, the share repurchases under the repurchase program were funded from cash on hand.  The Company has approximately $60.0 million remaining for common stock repurchases under the repurchase plan.

[0001511737-15-000018:notes:112]
[same as prior period, unchanged from 0001511737-15-000009:notes:110]

[0001511737-15-000018:notes:113]
[same as prior period, unchanged from 0001511737-15-000009:notes:111]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-15-000018:notes:114]
[same as prior period, unchanged from 0001511737-15-000009:notes:112]

[0001511737-15-000018:notes:115]
[same as prior period, unchanged from 0001511737-15-000009:notes:113]

[0001511737-15-000018:notes:116]
[same as prior period, unchanged from 0001511737-15-000009:notes:114]

[0001511737-15-000018:notes:117]
[same as prior period, unchanged from 0001511737-15-000009:notes:115]

[0001511737-15-000018:notes:118]
[same as prior period, unchanged from 0001511737-15-000009:notes:118]

[0001511737-15-000018:notes:119]
Other current liabilities consisted of the following (in thousands):
