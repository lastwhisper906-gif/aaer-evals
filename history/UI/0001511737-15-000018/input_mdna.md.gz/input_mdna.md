# UI MD&A — 0001511737-15-000018


## mdna

[0001511737-15-000018:mdna:1]
[same as prior period, unchanged from 0001511737-15-000009:mdna:1]

[0001511737-15-000018:mdna:2]
[same as prior period, unchanged from 0001511737-15-000009:mdna:3]

[0001511737-15-000018:mdna:3]
[same as prior period, unchanged from 0001511737-15-000009:mdna:4]

[0001511737-15-000018:mdna:4]
We offer a broad and expanding portfolio of networking products and solutions for service providers and enterprises. Our service provider product platforms provide carrier-class network infrastructure for fixed wireless broadband, wireless backhaul systems and routing. Our enterprise product platforms provide wireless LAN infrastructure, video surveillance products, UniFi VOIP phones, UniFi switches and machine-to-machine communication components. We believe that our products are highly differentiated due to our proprietary software protocol innovation, firmware expertise, and hardware design capabilities. This differentiation allows our portfolio to meet the demanding performance requirements of video, voice and data applications at prices that are a fraction of those offered by our competitors.

[0001511737-15-000018:mdna:5]
[same as prior period, unchanged from 0001511737-15-000009:mdna:6]

[0001511737-15-000018:mdna:6]
[same as prior period, unchanged from 0001511737-15-000009:mdna:7]

[0001511737-15-000018:mdna:7]
[same as prior period, unchanged from 0001511737-15-000009:mdna:8]

[0001511737-15-000018:mdna:8]
[same as prior period, unchanged from 0001511737-15-000009:mdna:9]

[0001511737-15-000018:mdna:9]
[same as prior period, unchanged from 0001511737-15-000009:mdna:10]

[0001511737-15-000018:mdna:10]
[same as prior period, unchanged from 0001511737-15-000009:mdna:13]

[0001511737-15-000018:mdna:11]
[same as prior period, unchanged from 0001511737-15-000009:mdna:14]

[0001511737-15-000018:mdna:12]
[same as prior period, unchanged from 0001511737-15-000009:mdna:15]

[0001511737-15-000018:mdna:13]
[same as prior period, unchanged from 0001511737-15-000009:mdna:16]

[0001511737-15-000018:mdna:14]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes revenues that are attributable to PCS. |

[0001511737-15-000018:mdna:15]
| • | Enterprise Technology includes our UniFi and mFi platforms, including UAP products, Unifi Video Products, Unifi VOIP phones and Unifi switches. |

[0001511737-15-000018:mdna:16]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and OEMs. Sales to distributors accounted for 99% of our revenues in both the three and nine months ended March 31, 2015.

[0001511737-15-000018:mdna:17]
[same as prior period, unchanged from 0001511737-15-000009:mdna:20]

[0001511737-15-000018:mdna:18]
[same as prior period, unchanged from 0001511737-15-000009:mdna:21]

[0001511737-15-000018:mdna:19]
[same as prior period, unchanged from 0001511737-15-000009:mdna:22]

[0001511737-15-000018:mdna:20]
16

[0001511737-15-000018:mdna:21]
[same as prior period, unchanged from 0001511737-15-000009:mdna:23]

[0001511737-15-000018:mdna:22]
Our gross profit has been, and may in the future be, influenced by several factors including changes in product mix, target end markets for our products, pricing due to competitive pressure, production costs and global demand for electronic components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs, in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers, they may try to pass these additional costs on to us, which could have a material impact on our future average selling prices and unit costs.

[0001511737-15-000018:mdna:23]
[same as prior period, unchanged from 0001511737-15-000009:mdna:25]

[0001511737-15-000018:mdna:24]
[same as prior period, unchanged from 0001511737-15-000009:mdna:26]

[0001511737-15-000018:mdna:25]
[same as prior period, unchanged from 0001511737-15-000009:mdna:27]

[0001511737-15-000018:mdna:26]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations. |

[0001511737-15-000018:mdna:27]
[same as prior period, unchanged from 0001511737-15-000009:mdna:30]

[0001511737-15-000018:mdna:28]
[same as prior period, unchanged from 0001511737-15-000009:mdna:31]

[0001511737-15-000018:mdna:29]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will perform in the future. As of March 31, 2015 and June 30, 2014, we had deferred revenues of $3.5 million and $2.8 million respectively, related to these obligations.

[0001511737-15-000018:mdna:30]
[same as prior period, unchanged from 0001511737-15-000009:mdna:33]

[0001511737-15-000018:mdna:31]
[same as prior period, unchanged from 0001511737-15-000009:mdna:34]

[0001511737-15-000018:mdna:32]
[same as prior period, unchanged from 0001511737-15-000009:mdna:35]

[0001511737-15-000018:mdna:33]
[same as prior period, unchanged from 0001511737-15-000009:mdna:36]

[0001511737-15-000018:mdna:34]
Comparison of Three and Nine Months Ended March 31, 2015 and 2014

[0001511737-15-000018:mdna:35]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In thousands, except percentages) |
| Revenues | $ | 147,456 |  |  | 100 | % |  | $ | 148,331 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |
| Cost of revenues | 81,479 |  |  | 55 | % |  | 82,719 |  |  | 56 | % |  | 254,631 |  |  | 56 | % |  | 231,851 |  |  | 56 | % |
| Gross profit | 65,977 |  |  | 45 | % |  | 65,612 |  |  | 44 | % |  | 196,049 |  |  | 44 | % |  | 184,606 |  |  | 44 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 15,236 |  |  | 10 | % |  | 9,413 |  |  | 6 | % |  | 39,893 |  |  | 9 | % |  | 23,807 |  |  | 6 | % |
| Sales, general and administrative | 5,510 |  |  | 4 | % |  | 6,064 |  |  | 4 | % |  | 16,568 |  |  | 4 | % |  | 17,648 |  |  | 4 | % |
| Total operating expenses | 20,746 |  |  | 14 | % |  | 15,477 |  |  | 10 | % |  | 56,461 |  |  | 13 | % |  | 41,455 |  |  | 10 | % |
| Income from operations | 45,231 |  |  | 31 | % |  | 50,135 |  |  | 34 | % |  | 139,588 |  |  | 31 | % |  | 143,151 |  |  | 34 | % |
| Interest expense and other, net | (763 | ) |  | * |  |  | (283 | ) |  | * |  |  | (804 | ) |  | * |  |  | (778 | ) |  | * |  |
| Income before provision for income taxes | 44,468 |  |  | 30 | % |  | 49,852 |  |  | 34 | % |  | 138,784 |  |  | 31 | % |  | 142,373 |  |  | 34 | % |
| Provision for income taxes | 3,331 |  |  | 2 | % |  | 4,653 |  |  | 3 | % |  | 13,639 |  |  | 3 | % |  | 14,854 |  |  | 4 | % |
| Net income and comprehensive income | $ | 41,137 |  |  | 28 | % |  | $ | 45,199 |  |  | 31 | % |  | $ | 125,145 |  |  | 28 | % |  | $ | 127,519 |  |  | 30 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 141 |  |  |  |  | $ | 153 |  |  |  |  | $ | 440 |  |  |  |  | $ | 445 |  |  |  |
| Research and development | 810 |  |  |  |  | 630 |  |  |  |  | 2,499 |  |  |  |  | 1,679 |  |  |  |
| Sales, general and administrative | 425 |  |  |  |  | 258 |  |  |  |  | 1,240 |  |  |  |  | 1,506 |  |  |  |
| Total stock-based compensation | $ | 1,376 |  |  |  |  | $ | 1,041 |  |  |  |  | $ | 4,179 |  |  |  |  | $ | 3,630 |  |  |  |

[0001511737-15-000018:mdna:36]
[same as prior period, unchanged from 0001511737-15-000009:mdna:39]

[0001511737-15-000018:mdna:37]
Revenues decreased $875,000, or 1%, from $148.3 million in the three months ended March 31, 2014 to $147.5 million in the three months ended March 31, 2015.  Revenues increased $34.2 million, or 8%, from $416.5 million in the nine months ended March 31, 2014 to $450.7 million in the nine months ended March 31, 2015.  We believe the overall increase in revenues during the nine months ended March 31, 2015 was driven by increased adoption of our enterprise technologies, partially offset by a decrease in sales of our service provider technologies due to lower demand from our service provider customers outside of North America as a result of political and economic instability in some of those regions.

[0001511737-15-000018:mdna:38]
[same as prior period, unchanged from 0001511737-15-000009:mdna:41]

[0001511737-15-000018:mdna:39]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 106,242 |  |  | 72 | % |  | $ | 120,987 |  |  | 82 | % |  | $ | 313,233 |  |  | 70 | % |  | $ | 326,658 |  |  | 78 | % |
| Enterprise Technology | 41,214 |  |  | 28 | % |  | 27,344 |  |  | 18 | % |  | 137,447 |  |  | 30 | % |  | 89,799 |  |  | 22 | % |
| Total revenues | $ | 147,456 |  |  | 100 | % |  | $ | 148,331 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |

[0001511737-15-000018:mdna:40]
Revenues from Service Provider Technologies decreased $14.7 million, or 12%, from $121.0 million in the three months ended March 31, 2014 to $106.2 million in the three months ended March 31, 2015.  Revenues from Service Provider Technologies decreased $13.4 million, or 4%, from $326.7 million in the nine months ended March 31, 2014 to $313.2 million in the nine months ended March 31, 2015.   The decline in revenues from Service Provider Technologies in both periods was primarily due to lower demand from our service provider customers outside of North America as a result of political and economic instability in some of those regions.

[0001511737-15-000018:mdna:41]
[same as prior period, unchanged from 0001511737-15-000009:mdna:45]

[0001511737-15-000018:mdna:42]
Enterprise Technology revenues increased $13.9 million, or 51% from $27.3 million in the three months ended March 31, 2014 to $41.2 million in the three months ended March 31, 2015.  Enterprise Technology revenues increased $47.6 million, or 53% from $89.8 million in the nine months ended March 31, 2014 to $137.4 million in the nine months ended March 31, 2015.  The increase in Enterprise Technology revenues during both the three and nine months ended March 31, 2015 was due primarily to product expansion and further adoption of our UniFi technology platform.

[0001511737-15-000018:mdna:43]
[same as prior period, unchanged from 0001511737-15-000009:mdna:47]

[0001511737-15-000018:mdna:44]
We have determined the geographical distribution of our product revenues based on our customers' ship-to destinations. A majority of our sales are to distributors who in turn sell to resellers or directly to end customers, which may be different countries than the initial ship-to destination.  The following are our revenues by geography for the three and nine months ended March 31, 2015 and 2014 (in thousands, except percentages):

[0001511737-15-000018:mdna:45]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| North America (1) | $ | 45,692 |  |  | 31 | % |  | $ | 29,178 |  |  | 20 | % |  | $ | 153,400 |  |  | 34 | % |  | $ | 99,178 |  |  | 24 | % |
| South America | 17,866 |  |  | 12 | % |  | 25,059 |  |  | 17 | % |  | 71,242 |  |  | 16 | % |  | 73,827 |  |  | 18 | % |
| Europe, the Middle East and Africa | 66,770 |  |  | 45 | % |  | 77,883 |  |  | 52 | % |  | 177,474 |  |  | 39 | % |  | 189,591 |  |  | 45 | % |
| Asia Pacific | 17,128 |  |  | 12 | % |  | 16,211 |  |  | 11 | % |  | 48,564 |  |  | 11 | % |  | 53,861 |  |  | 13 | % |
| Total revenues | $ | 147,456 |  |  | 100 | % |  | $ | 148,331 |  |  | 100 | % |  | $ | 450,680 |  |  | 100 | % |  | $ | 416,457 |  |  | 100 | % |

[0001511737-15-000018:mdna:46]
| (1) | Revenue for the United States was $43.9 million and $27.7 million for the three months ended March 31, 2015 and 2014, respectively. Revenue for the United States was $146.1 million and $95.0 million for the nine months ended March 31, 2015 and 2014, respectively. |

[0001511737-15-000018:mdna:47]
North America

[0001511737-15-000018:mdna:48]
Revenues in North America increased $16.5 million, or 57%, from $29.2 million in the three months ended March 31, 2014 to $45.7 million in the three months ended March 31, 2015.  Revenues in North America increased $54.2 million, or 55%, from $99.2 million in the nine months ended March 31, 2014 to $153.4 million in the nine months ended March 31, 2015.  The increase in revenues in North America in both the three and nine months ended March 31, 2015 as compared to the same periods in the prior year was due to increased adoption of our Service Provider and Enterprise Technologies.

[0001511737-15-000018:mdna:49]
South America

[0001511737-15-000018:mdna:50]
Revenues in South America decreased $7.2 million, or 29%, from $25.1 million in the three months ended March 31, 2014 to $17.9 million in the three months ended March 31, 2015.  Revenues in South America decreased $2.6 million, or 4%, from $73.8 million in the nine months ended March 31, 2014 to $71.2 million in the nine months ended March 31, 2015.  We believe the decrease in revenues in South America in both the three and nine months ended March 31, 2015 as compared to the same periods in the prior year was primarily due to decreased demand for our Service Provider Technologies due in part to economic instability and partially as a result of of a strong U.S. Dollar.

[0001511737-15-000018:mdna:51]
Europe, the Middle East, and Africa ("EMEA")

[0001511737-15-000018:mdna:52]
Revenues in EMEA decreased $11.1 million, or 14%, from $77.9 million in the three months ended March 31, 2014 to $66.8 million in the three months ended March 31, 2015.  Revenues in EMEA decreased $12.1 million, or 6%, from $189.6 million in the nine months ended March 31, 2014 to $177.5 million in the nine months ended March 31, 2015.  The decrease in revenues in EMEA in both the three and nine months ended March 31, 2015 as compared to the same periods in the prior year was primarily due to decreased demand for our Service Provider Technologies, due in part to economic instability in this region and partially as a result of of a strong U.S. Dollar.  The decrease in both periods was partially offset by increased adoption of our Enterprise Technology platforms.

[0001511737-15-000018:mdna:53]
Asia Pacific

[0001511737-15-000018:mdna:54]
Revenues in the Asia Pacific region remained relatively flat at $17.1 million in the three months ended March 31, 2015 compared to $16.2 million in the three months ended March 31, 2014.  Revenues in the Asia Pacific region decreased $5.3 million, or 10%, from $53.9 million in the nine months ended March 31, 2014 to $48.6 million in the nine months ended March 31, 2015.  The decrease in revenues in the Asia Pacific region in the nine months ended March 31, 2015 as compared to the same period in the prior year was primarily due to decreased demand for our Service Provider Technologies, partially offset by increased adoption of our Enterprise Technology platforms.

[0001511737-15-000018:mdna:55]
[same as prior period, unchanged from 0001511737-15-000009:mdna:51]

[0001511737-15-000018:mdna:56]
Cost of revenues decreased $1.2 million, or 1%, from $82.7 million in the three months ended March 31, 2014 to $81.5 million in the three months ended March 31, 2015.  Cost of revenues increased $22.8 million, or 10%, from $231.9 million in the nine months ended March 31, 2014 to $254.6 million in the three months ended March 31, 2015.  The decrease in cost of revenues in the three months ended March 31, 2015 was primarily due to our overall decrease in revenues.  The increase in cost of revenues in the nine months ended March 31, 2015 was primarily due to our overall increase in revenues and a non-recurring charge associated with a termination fee of $5.5 million for the cancellation of a purchase commitment during the three months ended September 30, 2014.

[0001511737-15-000018:mdna:57]
Gross profit increased to 45% in the three months ended March 31, 2015 compared to 44% in the three months ended March 31, 2014, and remained flat at 44% in both the nine months ended March 31, 2015 and March 31, 2014.  The increase in gross profit during the three months ended March 31, 2015 was primarily due to changes in product mix.

[0001511737-15-000018:mdna:58]
[same as prior period, unchanged from 0001511737-15-000009:mdna:54]

[0001511737-15-000018:mdna:59]
[same as prior period, unchanged from 0001511737-15-000009:mdna:55]

[0001511737-15-000018:mdna:60]
Research and development ("R&D") expenses increased $5.8 million, or 62%, from $9.4 million in the three months ended March 31, 2014 to $15.2 million in the three months ended March 31, 2015. As a percentage of revenues, research and development expenses increased from 6% in the three months ended March 31, 2014 to 10% in the three months ended March 31, 2015.  Research and development expenses increased $16.1 million, or 68%, from $23.8 million in the nine months ended March 31, 2014 to $39.9 million in the nine months ended March 31, 2015. As a percentage of revenues, research and development expenses increased from 6% in the nine months ended March 31, 2014 to 9% in the nine months ended March 31, 2015.  The increase in research and development expenses in absolute dollars and as a percentage of revenues was due to increases in headcount to support our strategy as we broadened our research and development activities to new product areas and certain one-time costs incurred for IP purchased for use in our products. Over time, we expect our research and development costs to increase in absolute dollars as we continue making investments in developing new products and developing new versions of our existing products.

[0001511737-15-000018:mdna:61]
[same as prior period, unchanged from 0001511737-15-000009:mdna:57]

[0001511737-15-000018:mdna:62]
Sales, general and administrative expenses decreased slightly, from $6.1 million in the three months ended March 31, 2014 to $5.5 million in the three months ended March 31, 2015.  As a percentage of revenues, sales, general and administrative expenses remained flat at 4% in both the three months ended March 31, 2014 and March 31, 2015.  Sales, general and administrative expenses decreased slightly, from $17.6 million in the nine months ended March 31, 2014 to $16.6 million in the six months ended March 31, 2015.  As a percentage of revenues, sales, general and administrative expenses remained flat at 4% in the nine months ended March 31, 2015 and 2014.

[0001511737-15-000018:mdna:63]
[same as prior period, unchanged from 0001511737-15-000009:mdna:61]

[0001511737-15-000018:mdna:64]
Our provision for income taxes decreased $1.3 million, or 28%, from $4.7 million for the three months ended March 31, 2014 to $3.3 million for the three months ended March 31, 2015. Our effective tax rate decreased to 7% for the three months ended March 31, 2015 as compared to 9% for the three months ended March 31, 2014.  The lower effective tax rate in the three months ended March 31, 2015 was due to discrete tax benefits related to U.S. federal income tax return filings.  Our provision for income taxes decreased $1.2 million, or 8%, from $14.9 million for the nine months ended March 31, 2014 to $13.6 million for the nine months ended March 31, 2015. Our effective tax rate remained flat at 10% for the nine months ended March 31, 2015 as compared to the nine months ended March 31, 2014.

[0001511737-15-000018:mdna:65]
[same as prior period, unchanged from 0001511737-15-000009:mdna:63]

[0001511737-15-000018:mdna:66]
[same as prior period, unchanged from 0001511737-15-000009:mdna:64]

[0001511737-15-000018:mdna:67]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents increased from $347.1 million at June 30, 2014 to $451.2 million at March 31, 2015.

[0001511737-15-000018:mdna:68]
[same as prior period, unchanged from 0001511737-15-000009:mdna:72]

[0001511737-15-000018:mdna:69]
[same as prior period, unchanged from 0001511737-15-000009:mdna:66]

[0001511737-15-000018:mdna:70]
[same as prior period, unchanged from 0001511737-15-000009:mdna:67]

[0001511737-15-000018:mdna:71]
|  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 116,344 |  |  | $ | 65,534 |  |
| Net cash used in investing activities | (10,817 | ) |  | (3,244 | ) |
| Net cash provided by (used in) financing activities | (1,465 | ) |  | 1,554 |  |
| Net increase in cash and cash equivalents | $ | 104,062 |  |  | $ | 63,844 |  |

[0001511737-15-000018:mdna:72]
[same as prior period, unchanged from 0001511737-15-000009:mdna:69]

[0001511737-15-000018:mdna:73]
Net cash provided by operating activities in the nine months ended March 31, 2015 of $116.3 million consisted primarily of net income of $125.1 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $19.1 million. These changes consisted primarily of a $20.7 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, a $14.8 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $4.1 million increase in prepaid taxes due to the timing of federal tax payments, a $3.5 million decrease in inventory due to efforts to optimize our inventory levels and a $3.1 million increase in taxes payable.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance for doubtful accounts and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $10.3 million.

[0001511737-15-000018:mdna:74]
Net cash provided by operating activities in the nine months ended March 31, 2014 of $65.5 million consisted primarily of net income of $127.5 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $66.0 million. These changes consisted primarily of a $52.2 million increase in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, an $8.3 million increase in prepaid expenses and other current assets due to timing of deposit payments with our suppliers, an $8.0 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $5.1 million increase in prepaid taxes due to the timing of federal tax payments and a $4.0 million increase in taxes payable. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance for doubtful accounts, a write-off of our intangible assets and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $4.0 million.

[0001511737-15-000018:mdna:75]
[same as prior period, unchanged from 0001511737-15-000009:mdna:73]

[0001511737-15-000018:mdna:76]
Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the nine months ended March 31, 2015 and 2014 were $10.8 million and $3.0 million, respectively.  Capital expenditures during the nine months ended March 31, 2015 included machinery and equipment purchases for our product development and prototyping facility in China.  Additionally, we had cash outflows related to the purchase of intangible assets of $38,000 and $207,000 during the nine months ended March 31, 2015 and 2014, respectively.

[0001511737-15-000018:mdna:77]
[same as prior period, unchanged from 0001511737-15-000009:mdna:75]

[0001511737-15-000018:mdna:78]
We had $1.5 million of cash used in financing activities during the nine months ended March 31, 2015, primarily from cash received from our term loan with Wells Fargo Bank of $100.0 million, offset by repayments of our prior Original Credit Agreement with Wells Fargo Bank of $72.3 million.  Additionally, during the nine months ended March 31, 2015 we paid $15.0 million for dividends on our common stock of, paid $15.0 million for repurchases of our common stock and had tax withholdings related to net share settlements of restricted stock units of $1.6 million.  Other cash inflows from financing activities included cash received for stock option exercises of $850,000 and an excess tax benefit from employee stock-based awards of $1.6 million.

[0001511737-15-000018:mdna:79]
We had $1.6 million of cash provided by financing activities during the nine months ended March 31, 2014, which primarily consisted of an excess tax benefit from employee stock-based awards of $5.3 million and cash received for stock option exercises of $1.8 million, partially offset by repayments on our term loan balance with East West Bank of $3.8 million and tax withholdings related to net share settlements of restricted stock units of $1.8 million.

[0001511737-15-000018:mdna:80]
[same as prior period, unchanged from 0001511737-15-000009:mdna:78]

[0001511737-15-000018:mdna:81]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our loan agreements will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of March 31, 2015, we held $392.3 million of our $451.2 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-15-000018:mdna:82]
[same as prior period, unchanged from 0001511737-15-000009:mdna:80]

[0001511737-15-000018:mdna:83]
Our products are generally accompanied by a twelve (12) month warranty, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-30, Loss Contingencies, we record an accrual when we believe it is estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-15-000018:mdna:84]
[same as prior period, unchanged from 0001511737-15-000009:mdna:82]

[0001511737-15-000018:mdna:85]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe the fair value of these indemnification agreements is minimal.  We have not recorded any liabilities for these agreements as of March 31, 2015.

[0001511737-15-000018:mdna:86]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we will have significant liability for the above indemnities at March 31, 2015.

[0001511737-15-000018:mdna:87]
[same as prior period, unchanged from 0001511737-15-000009:mdna:85]

[0001511737-15-000018:mdna:88]
The following table summarizes our contractual obligations as of March 31, 2015 for the remainder of fiscal 2015 and future fiscal years:

[0001511737-15-000018:mdna:89]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 895 |  |  | $ | 3,860 |  |  | $ | 2,675 |  |  | $ | 1,128 |  |  | $ | 219 |  |  | $ | 169 |  |  | $ | 8,946 |  |
| Debt payment obligations | 2,500 |  |  | 10,000 |  |  | 11,250 |  |  | 15,000 |  |  | 15,000 |  |  | 46,250 |  |  | 100,000 |  |
| Interest and other payments on debt payment obligations | 674 |  |  | 2,057 |  |  | 1,876 |  |  | 1,645 |  |  | 1,380 |  |  | 812 |  |  | 8,444 |  |
| Purchase obligations | 12,770 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 12,770 |  |
| Other obligations | 4,447 |  |  | 89 |  |  | 29 |  |  | 3 |  |  | — |  |  | — |  |  | 4,568 |  |
| Total | $ | 21,286 |  |  | $ | 16,006 |  |  | $ | 15,830 |  |  | $ | 17,776 |  |  | $ | 16,599 |  |  | $ | 47,231 |  |  | $ | 134,728 |  |

[0001511737-15-000018:mdna:90]
[same as prior period, unchanged from 0001511737-15-000009:mdna:88]

[0001511737-15-000018:mdna:91]
We lease our headquarters in San Jose, California and other locations worldwide under non-cancelable operating leases that expire at various dates through 2020.

[0001511737-15-000018:mdna:92]
[same as prior period, unchanged from 0001511737-15-000009:mdna:90]

[0001511737-15-000018:mdna:93]
22

[0001511737-15-000018:mdna:94]
On March 3, 2015, we entered into the Amended Credit Agreement, that provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility, with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender's sole discretion).  Please see Note 7 of the Notes to the Consolidated Financial Statements for more information. We have calculated estimated interest payments for our debt based on the applicable rates and payment dates. Although our interest rates on our debt obligations may vary, we have assumed our interest rate of March 31, 2015 rate for all years presented.   Also included are estimated bank fees to be paid for unused portions of our revolving credit facility.

[0001511737-15-000018:mdna:95]
[same as prior period, unchanged from 0001511737-15-000009:mdna:92]

[0001511737-15-000018:mdna:96]
We subcontract with other companies to manufacture our products. During the normal course of business, our contract manufacturers procure components based upon orders placed by us. If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components purchased by the subcontractors to manufacture our products. We periodically review the potential liability and to date no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.  The Company had inventory purchase obligations of $12.8 million as of March 31, 2015.

[0001511737-15-000018:mdna:97]
[same as prior period, unchanged from 0001511737-15-000009:mdna:94]

[0001511737-15-000018:mdna:98]
We had other obligations of $4.6 million as of March 31, 2015, which consisted primarily of commitments related to research and development projects.

[0001511737-15-000018:mdna:99]
[same as prior period, unchanged from 0001511737-15-000009:mdna:96]

[0001511737-15-000018:mdna:100]
As of March 31, 2015, we had $18.2 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-15-000018:mdna:101]
[same as prior period, unchanged from 0001511737-15-000009:mdna:98]

[0001511737-15-000018:mdna:102]
[same as prior period, unchanged from 0001511737-15-000009:mdna:99]

[0001511737-15-000018:mdna:103]
[same as prior period, unchanged from 0001511737-15-000009:mdna:100]

[0001511737-15-000018:mdna:104]
Regulation G, conditions for use of Non-Generally Accepted Accounting Principles (“Non-GAAP”) financial measures, and other SEC regulations define and prescribe the conditions for use of certain Non-GAAP financial information. To supplement our condensed consolidated financial results presented in accordance with GAAP, we use Non-GAAP financial measures which are adjusted from the most directly comparable GAAP financial measures to exclude certain items, as described below. Management believes that these Non-GAAP financial measures reflect an additional and useful way of viewing aspects of our operations that, when viewed in conjunction with our GAAP results, provide a more comprehensive understanding of the various factors and trends affecting our business and operations. Non-GAAP financial measures used by us include net income or loss and diluted net income or loss per share.  Other companies may calculate these measures differently than we do, limiting the usefulness of these items as comparative measures.

[0001511737-15-000018:mdna:105]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes and other special charges and credits.  Additionally, during the nine months ended March 31, 2015 we recorded a one-time charge of $5.5 million due to a termination fee related to a purchase commitment entered into during fiscal 2014.  Management believes these Non-GAAP financial measures provide meaningful supplemental information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes. In addition, these Non-GAAP financial measures facilitate management’s internal comparisons to our historical operating results and comparisons to competitors’ operating results.

[0001511737-15-000018:mdna:106]
[same as prior period, unchanged from 0001511737-15-000009:mdna:104]

[0001511737-15-000018:mdna:107]
[same as prior period, unchanged from 0001511737-15-000009:mdna:105]

[0001511737-15-000018:mdna:108]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 41,963 |  |  | $ | 45,151 |  |  | $ | 132,493 |  |  | $ | 129,024 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.47 |  |  | $ | 0.50 |  |  | $ | 1.48 |  |  | $ | 1.44 |  |

[0001511737-15-000018:mdna:109]
[same as prior period, unchanged from 0001511737-15-000009:mdna:107]

[0001511737-15-000018:mdna:110]
[same as prior period, unchanged from 0001511737-15-000009:mdna:108]

[0001511737-15-000018:mdna:111]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In thousands, except pershare amounts) |
| Net income and comprehensive income | $ | 41,137 |  |  | $ | 45,199 |  |  | $ | 125,145 |  |  | $ | 127,519 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 141 |  |  | 153 |  |  | 440 |  |  | 445 |  |
| Research and development | 810 |  |  | 630 |  |  | 2,499 |  |  | 1,679 |  |
| Sales, general and administrative | 425 |  |  | 258 |  |  | 1,240 |  |  | 1,506 |  |
| Purchase commitment termination fee | — |  |  | — |  |  | 5,500 |  |  | — |  |
| Gain on reversal of charge for an export compliance matter | — |  |  | (1,121 | ) |  | — |  |  | (1,121 | ) |
| Tax effect of non-GAAP adjustments | (550 | ) |  | 32 |  |  | (2,331 | ) |  | (1,004 | ) |
| Non-GAAP net income and comprehensive income | $ | 41,963 |  |  | $ | 45,151 |  |  | $ | 132,493 |  |  | $ | 129,024 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.47 |  |  | $ | 0.50 |  |  | $ | 1.48 |  |  | $ | 1.44 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 89,400 |  |  | 89,775 |  |  | 89,707 |  |  | 89,667 |  |
