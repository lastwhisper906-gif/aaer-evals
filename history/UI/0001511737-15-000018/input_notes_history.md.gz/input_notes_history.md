# UI note change history — 0001511737-15-000009 → 0001511737-15-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2015-05-07):
[0001511737-15-000018:note_history:1]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2020.

- changed (2015-05-07):
[0001511737-15-000018:note_history:2]
At March 31, 2015, future minimum annual payments under operating leases are as follows (in thousands):
  (was, 2015-02-05, similarity 0.9543):
[0001511737-15-000009:note_history:2]
At December 31, 2014, future minimum annual payments under operating leases are as follows (in thousands):

- changed (2015-05-07):
[0001511737-15-000018:note_history:3]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 895 |  |  | $ | 3,860 |  |  | $ | 2,675 |  |  | $ | 1,128 |  |  | $ | 219 |  |  | $ | 169 |  |  | $ | 8,946 |  |
  (was, 2015-02-05, similarity 0.9942):
[0001511737-15-000009:note_history:3]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Operating leases | $ | 1,690 |  |  | $ | 3,270 |  |  | $ | 1,903 |  |  | $ | 506 |  |  | $ | 53 |  |  | $ | — |  |  | $ | 7,422 |  |

- changed (2015-05-07):
[0001511737-15-000018:note_history:4]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.  The Company had inventory purchase obligations of $12.8 million as of March 31, 2015.
  (was, 2015-02-05, similarity 0.9314):
[0001511737-15-000009:note_history:4]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability and to date no significant accruals have been recorded.

- changed (2015-05-07):
[0001511737-15-000018:note_history:5]
The Company had other obligations of $4.6 million as of March 31, 2015, which consisted primarily of commitments related to research and development projects.
  (was, 2015-02-05, similarity 0.7267):
[0001511737-15-000009:note_history:5]
The Company had other obligations of $487,000 as of December 31, 2014, which consisted primarily of commitments to acquire capital assets, including manufacturing equipment.

- removed (2015-05-07):
[0001511737-15-000009:note_history:6]
Certain facilities and equipment are leased under noncancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2019.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001511737-15-000018:note_history:7]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develop high performance networking technology for service providers and enterprises.
  (was, 2015-02-05, similarity 0.9973):
[0001511737-15-000009:note_history:7]
Ubiquiti Networks, Inc. and its wholly owned subsidiaries (collectively, “Ubiquiti” or the “Company”) develops high performance networking technology for service providers and enterprises.

- changed (2015-05-07):
[0001511737-15-000018:note_history:8]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2014 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.  The Company has reclassified certain amounts reported in the previous period to conform to the current period presentation.
  (was, 2015-02-05, similarity 0.9348):
[0001511737-15-000009:note_history:8]
Basis of Presentation— The accompanying condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) related to interim financial statements based on applicable Securities and Exchange Commission (“SEC”) rules and regulations. Accordingly, they do not include all the information and footnotes required by U.S. GAAP for complete financial statements. This information reflects all adjustments, which are, in the opinion of the Company, of a normal and recurring nature and necessary to state fairly the statements of financial position, results of operations and cash flows for the dates and periods presented. The June 30, 2014 balance sheet was derived from the audited financial statements as of that date. All significant intercompany transactions and balances have been eliminated.

- changed (2015-05-07):
[0001511737-15-000018:note_history:9]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014, included in its Annual Report on Form 10-K, as filed on August 22, 2014, with the SEC (the “Annual Report”). The results of operations for the three and nine months ended March 31, 2015, are not necessarily indicative of the results to be expected for any future periods.
  (was, 2015-02-05, similarity 0.9448):
[0001511737-15-000009:note_history:9]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2014 included in its Annual Report on Form 10-K, as filed on August 22, 2014 with the SEC (the “Annual Report”). The results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001511737-15-000018:note_history:10]
The Company capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. The cost of internally developed software is amortized on a straight-line basis over its estimated useful life, typically three (3) to five (5) years.  During the three and nine months ended March 31, 2015, the Company capitalized $1.5 million and $3.0 million of software development costs, respectively, which is included as property and equipment in the Company's balance sheet as of  March 31, 2015.
  (was, 2015-02-05, similarity 0.7003):
[0001511737-15-000009:note_history:10]
The Company capitalizes certain costs of software developed for internal use.  Capitalized costs primarily include payroll and payroll-related costs and facilities costs. The cost of internally developed software is amortized on a straight-line basis over its estimated useful life, typically 3 to 5 years.  During the three and six months ended December 31, 2014, the Company capitalized $1.5 million of software development costs, which is included as property and equipment in the Company's balance sheet as of  December 31, 2014.

- changed (2015-05-07):
[0001511737-15-000018:note_history:11]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for annual and interim reporting periods beginning after December 15, 2016.  However, in April 2015, the FASB issued a proposal to defer the effective date by one year, to December 15, 2017,  to provide adequate time to effectively implement the new standard.  The Company is currently assessing the impact of this new guidance.
  (was, 2015-02-05, similarity 0.6863):
[0001511737-15-000009:note_history:11]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance will be effective for the Company beginning July 1, 2017.  The Company is currently assessing the impact of this new guidance.

- added (2015-05-07):
[0001511737-15-000018:note_history:12]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company's balance sheet and is not expected to have any effect on the Company's operating results.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-05-07):
[0001511737-15-000018:note_history:13]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million term loan facility.

- added (2015-05-07):
[0001511737-15-000018:note_history:14]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).

- added (2015-05-07):
[0001511737-15-000018:note_history:15]
On March 3, 2015, the Company and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender's sole discretion), and matures on March 3, 2020.  The term loan facility was fully drawn at closing,  $72.3 million of which was used to repay the outstanding balance under the Original Credit Agreement.

- added (2015-05-07):
[0001511737-15-000018:note_history:16]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company's $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company's option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo's prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender's commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of between 1.50% and 2.25%, depending on the Company's leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- added (2015-05-07):
[0001511737-15-000018:note_history:17]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

- added (2015-05-07):
[0001511737-15-000018:note_history:18]
The obligations of the Company and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Company and the Guarantors.

- added (2015-05-07):
[0001511737-15-000018:note_history:19]
No payments were made during the three or nine months ended March 31, 2015 against the term loan balance under the Amended Credit Agreement.  During the three and nine months ended March 31, 2014, the Company made aggregate payments of $1.3 million and $3.8 million, respectively, against the loan balance under the Original Credit Agreement.  As of March 31, 2015, the Company has classified $10.0 million and $90.0 million of short term and long-term debt, respectively, on its consolidated balance sheet related to the Amended Credit Agreement.

- changed (2015-05-07):
[0001511737-15-000018:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2015 (in thousands):
  (was, 2015-02-05, similarity 0.961):
[0001511737-15-000009:note_history:20]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2014 (in thousands):

- changed (2015-05-07):
[0001511737-15-000018:note_history:21]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 10,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | 100,000 |  |
| Interest and other payments on debt payment obligations | 674 |  |  | 2,057 |  |  | 1,876 |  |  | 1,645 |  |  | 1,380 |  |  | 812 |  |  | 8,444 |  |
| Total | $ | 3,174 |  |  | $ | 12,057 |  |  | $ | 13,126 |  |  | $ | 16,645 |  |  | $ | 16,380 |  |  | $ | 47,062 |  |  | $ | 108,444 |  |
  (was, 2015-02-05, similarity 0.8163):
[0001511737-15-000009:note_history:21]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 510 |  |  | 1,019 |  |  | 1,019 |  |  | 1,019 |  |  | 863 |  |  | 4,430 |  |
| Total | $ | 510 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 73,117 |  |  | $ | 76,684 |  |

- removed (2015-05-07):
[0001511737-15-000009:note_history:22]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provides for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances (the “Revolving Credit Facility”), and (ii) a $50.0 million term loan facility (the “Term Loan Facility”).  The Loan Agreement replaced a previous agreement whereby the Company had an existing term loan balance of $29.2 million as of the date the new Loan Agreement.  On August 7, 2012, the Company borrowed $20.8 million under the Term Loan Facility, and no borrowings remain available for borrowing thereunder.  On November 21, 2012, the Company borrowed $10.0 million under the Revolving Credit Facility. On December 20, 2012, the Company borrowed an additional $20.0 million under the Revolving Credit Facility, and $20.0 million remained available for borrowing thereunder.  During the three and six months ended December 31, 2013 the Company made aggregate payments of $1.3 million and $2.5 million against the loan balance, respectively.

- removed (2015-05-07):
[0001511737-15-000009:note_history:23]
On May 5, 2014, the Company and certain of its subsidiaries entered into a credit agreement (the “Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provides for a $150 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50 million (any such increase to be in each lender’s sole discretion).  The Company may borrow up to $110 million of the facility as a U.S. sublimit.  The entire amount of the facility is available to Ubiquiti International Holding Company Limited, a wholly-owned subsidiary of the Company organized under the laws of the Cayman Islands.  The credit facility includes a sub-limit of $5 million for letters of credit and a sub-limit of $15 million for swingline loans.   In connection with the execution of the Credit Agreement, the Company terminated the $50 million line of credit facility under the Loan Agreement with East West Bank described above.  Under the Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until May 5, 2019, at which time all amounts borrowed must be repaid.   Additionally, as of December 31, 2014, $72.3 million is outstanding under the Credit Agreement, which was borrowed by the Company to repay obligations under the Loan Agreement and to pay transaction fees and costs.  Revolving loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.250% and 2.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Swingline loans will bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.250% and 1.000%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.   Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.500% or (C) a per annum rate equal to the rate at which dollar deposits are offered in the London interbank market for a period of one month plus 1.000%.  A default interest rate shall apply on all obligations during a payment event of default under the Credit Agreement at a rate per annum equal to 2.000% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make loans, of between 0.200% and 0.350%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter.  Revolving loans and swingline loans may be prepaid at any time without penalty.  The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- removed (2015-05-07):
[0001511737-15-000009:note_history:24]
The Credit Agreement requires the Company to maintain a maximum leverage ratio and a minimum interest coverage ratio during the term of the credit facility.  In addition, the Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur subsidiary indebtedness, in each case subject to customary exceptions for a credit facility of this size and type.  The Credit Agreement includes customary events of default that, include among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.  The credit facility under the Credit Agreement expires May 5, 2019.

- removed (2015-05-07):
[0001511737-15-000009:note_history:25]
The obligations of the Company and its subsidiaries under the Credit Agreement are collateralized by substantially all assets (excluding intellectual property) of the Company and its subsidiaries.

- removed (2015-05-07):
[0001511737-15-000009:note_history:26]
Wells Fargo and the lenders party to the Credit Agreement, and certain of their respective affiliates, have provided, and in the future may provide, financial, banking and related services to the Company. These parties have received, and in the future may receive, compensation from the Company for these services.

- removed (2015-05-07):
[0001511737-15-000009:note_history:27]
No payments were made for borrowings under the Credit Agreement with Wells Fargo during the three and six months ended December 31, 2014.  As of December 31, 2014, the Company has classified $72.3 million of long-term debt on its consolidated balance sheet related to the Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001511737-15-000018:note_history:28]
The following table summarizes our estimated debt and interest payment obligations as of March 31, 2015 (in thousands):
  (was, 2015-02-05, similarity 0.961):
[0001511737-15-000009:note_history:28]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2014 (in thousands):

- changed (2015-05-07):
[0001511737-15-000018:note_history:29]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 2,500 |  |  | $ | 10,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | 100,000 |  |
| Interest and other payments on debt payment obligations | 674 |  |  | 2,057 |  |  | 1,876 |  |  | 1,645 |  |  | 1,380 |  |  | 812 |  |  | 8,444 |  |
| Total | $ | 3,174 |  |  | $ | 12,057 |  |  | $ | 13,126 |  |  | $ | 16,645 |  |  | $ | 16,380 |  |  | $ | 47,062 |  |  | $ | 108,444 |  |
  (was, 2015-02-05, similarity 0.8163):
[0001511737-15-000009:note_history:29]
|  | 2015 (remainder) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Total |
| Debt payment obligations | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 72,254 |  |  | $ | 72,254 |  |
| Interest payments on debt payment obligations | 510 |  |  | 1,019 |  |  | 1,019 |  |  | 1,019 |  |  | 863 |  |  | 4,430 |  |
| Total | $ | 510 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | 73,117 |  |  | $ | 76,684 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001511737-15-000018:note_history:30]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $150,000 and $330,000 in expenses pursuant to the Aircraft Lease Agreement during the three and nine months ended March 31, 2015, respectively.  In comparison, the Company recognized a total of approximately $120,000 in expenses pursuant to the Aircraft Lease Agreement during the three months ended March 31, 2014.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
  (was, 2015-02-05, similarity 0.7776):
[0001511737-15-000009:note_history:30]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company will purchase from a third-party provider. The Company recognized a total of approximately $29,000 and $180,000 in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2014, respectively.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company's sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
