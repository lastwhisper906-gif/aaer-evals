# UI note change history — 0001511737-15-000029 → 0001511737-16-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-04):
[0001511737-16-000032:note_history:1]
At December 31, 2015, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):
  (was, 2015-11-05, similarity 0.9838):
[0001511737-15-000029:note_history:1]
At September 30, 2015, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):

- changed (2016-02-04):
[0001511737-16-000032:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and to date, no significant accruals have been recorded.  The Company had inventory purchase obligations of $21.6 million as of December 31, 2015.
  (was, 2015-11-05, similarity 0.9942):
[0001511737-15-000029:note_history:2]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and to date, no significant accruals have been recorded.  The Company had inventory purchase obligations of $11.6 million as of September 30, 2015.

- changed (2016-02-04):
[0001511737-16-000032:note_history:3]
The Company had other obligations of $6.2 million as of December 31, 2015, which consisted primarily of commitments related to research and development projects.
  (was, 2015-11-05, similarity 0.9837):
[0001511737-15-000029:note_history:3]
The Company had other obligations of $6.1 million as of September 30, 2015, which consisted primarily of commitments related to research and development projects.

- changed (2016-02-04):
[0001511737-16-000032:note_history:4]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third-party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third-party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.
  (was, 2015-11-05, similarity 0.9971):
[0001511737-15-000029:note_history:4]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-04):
[0001511737-16-000032:note_history:5]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results to be expected for any future periods.
  (was, 2015-11-05, similarity 0.7769):
[0001511737-15-000029:note_history:5]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three months ended September 30, 2015 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-04):
[0001511737-16-000032:note_history:6]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  As of December 31, 2015, the Company capitalized $994 thousand of manufacturing overhead costs, which are included in inventory on the Company’s condensed consolidated balance sheet as of December 31, 2015.  These capitalized amounts are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.
  (was, 2015-11-05, similarity 0.804):
[0001511737-15-000029:note_history:6]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  During the three months ended September 30, 2015, the Company capitalized $944 thousand of manufacturing overhead costs, which are included in inventory on the Company’s condensed consolidated balance sheet as of September 30, 2015.

- changed (2016-02-04):
[0001511737-16-000032:note_history:7]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was initially effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB voted to defer the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard.  The Company does not anticipate that the new guidance will have a material impact on its consolidated financial statements.
  (was, 2015-11-05, similarity 0.9803):
[0001511737-15-000029:note_history:7]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was initially effective for annual and interim reporting periods beginning after December 15, 2016.  However, in April 2015, the FASB issued a proposal to defer the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard.  The Company does not anticipate that the new guidance will have a material impact on its consolidated financial statements.

- changed (2016-02-04):
[0001511737-16-000032:note_history:8]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and will not have any effect on the Company’s results of operations or cash flows.
  (was, 2015-11-05, similarity 0.944):
[0001511737-15-000029:note_history:8]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and is not expected to have any effect on the Company’s operating results.

- changed (2016-02-04):
[0001511737-16-000032:note_history:9]
In July 2015, the FASB issued Accounting Standards Update (ASU) 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2017.  We do not anticipate that this guidance will have a material impact on the presentation of the Company’s consolidated financial statements.
  (was, 2015-11-05, similarity 0.9904):
[0001511737-15-000029:note_history:9]
Additionally, in July 2015, the FASB issued Accounting Standards Update (ASU) 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2016.  We do not anticipate that this guidance will have a material impact on the presentation of the Company’s consolidated financial statements.

- added (2016-02-04):
[0001511737-16-000032:note_history:10]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-17, Balance Sheet Classification of Deferred Taxes. ASU 2015-17 simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. The guidance may be adopted prospectively or retrospectively and early adoption is permitted. We are currently evaluating ASU 2015-17 to determine if this guidance will have a material impact on our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-04):
[0001511737-16-000032:note_history:11]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the “Amended Credit Agreement”) with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under the Original Credit Agreement.  During the three months ended December 31, 2015, the Company drew $15 million and $18 million against the revolving credit facility.  These balances are not due until March 2020, and accordingly are classified as long-term debt.  As of December 31, 2015, $92.5 million was outstanding on the term loan and $33 million on the revolver.  As of December 31, 2015, the interest rate on the term loan was 2.10%.  As of December 31, 2015, the interest rate for the $15 million revolver draw was 1.85% and will reset on February 8, 2016.  Additionally, the interest rate for the $18 million revolver draw was 1.91% and will reset on February 16, 2016.  The interest rates on the revolving and term loans fluctuate as described below.  Subsequent to December 31, 2015, the Company drew an additional $33 million on the revolver.
  (was, 2015-11-05, similarity 0.6708):
[0001511737-15-000029:note_history:11]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the "Amended Credit Agreement") with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the "Facilities"), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under the Original Credit Agreement.  As of September 30, 2015, $95 million was outstanding on the term loan and $0 on the revolver.  Subsequent to September 30, 2015, the Company drew $33 million on the revolver.

- added (2016-02-04):
[0001511737-16-000032:note_history:12]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

- changed (2016-02-04):
[0001511737-16-000032:note_history:13]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of the LIBOR rate plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.
  (was, 2015-11-05, similarity 0.7996):
[0001511737-15-000029:note_history:13]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty. Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of the LIBOR rate plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

- changed (2016-02-04):
[0001511737-16-000032:note_history:14]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.
  (was, 2015-11-05, similarity 0.952):
[0001511737-15-000029:note_history:14]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the "Domestic Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the "Guarantors") and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

- changed (2016-02-04):
[0001511737-16-000032:note_history:15]
During the three months ended December 31, 2015, the Company made a payment of $2.9 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $439 thousand was payment of interest. During the six months ended December 31, 2015, the Company made aggregate payments of $5.9 million against the term loan facility balance under the Amended Credit Agreement, of which $5.0 million was a repayment of principal and $883 thousand was payment of interest.  During the three and six months ended December 31, 2015, the Company made aggregate payments of $99 thousand against the revolving loan facility under the Amended Credit Agreement.  As of December 31, 2015, the Company classified $10.0 million as short-term and $115.5 million as long-term debt on its consolidated balance sheet related to the Facilities under the Amended Credit Agreement.
  (was, 2015-11-05, similarity 0.6098):
[0001511737-15-000029:note_history:15]
During the three months ended September 30, 2015, the Company made a payment of $2.9 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $444 thousand was payment of interest.  As of September 30, 2015, the Company has classified $10.0 million and $85.0 million as short-term and long-term debt, respectively, on its consolidated balance sheet related to the term loan facility under the Amended Credit Agreement.

- changed (2016-02-04):
[0001511737-16-000032:note_history:16]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2015, for the remainder of fiscal 2016 and future fiscal years (in thousands):
  (was, 2015-11-05, similarity 0.9854):
[0001511737-15-000029:note_history:16]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2015 for the remainder of fiscal 2016 and future fiscal years (in thousands):

- changed (2016-02-04):
[0001511737-16-000032:note_history:17]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 5,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 79,250 |  |  | $ | — |  |  | $ | 125,500 |  |
| Interest and other payments on debt | 1,439 |  |  | 2,718 |  |  | 2,442 |  |  | 2,127 |  |  | 1,313 |  |  | — |  |  | 10,039 |  |
| Total | $ | 6,439 |  |  | $ | 13,968 |  |  | $ | 17,442 |  |  | $ | 17,127 |  |  | $ | 80,563 |  |  | $ | — |  |  | $ | 135,539 |  |
  (was, 2015-11-05, similarity 0.9733):
[0001511737-15-000029:note_history:17]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 7,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | — |  |  | $ | 95,000 |  |
| Interest and other payments on debt payment obligations | 1,521 |  |  | 1,893 |  |  | 1,659 |  |  | 1,392 |  |  | 818 |  |  | — |  |  | 7,283 |  |
| Total | $ | 9,021 |  |  | $ | 13,143 |  |  | $ | 16,659 |  |  | $ | 16,392 |  |  | $ | 47,068 |  |  | $ | — |  |  | $ | 102,283 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-04):
[0001511737-16-000032:note_history:18]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2015, for the remainder of fiscal 2016 and future fiscal years (in thousands):
  (was, 2015-11-05, similarity 0.9854):
[0001511737-15-000029:note_history:18]
The following table summarizes our estimated debt and interest payment obligations as of September 30, 2015 for the remainder of fiscal 2016 and future fiscal years (in thousands):

- changed (2016-02-04):
[0001511737-16-000032:note_history:19]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 5,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 79,250 |  |  | $ | — |  |  | $ | 125,500 |  |
| Interest and other payments on debt | 1,439 |  |  | 2,718 |  |  | 2,442 |  |  | 2,127 |  |  | 1,313 |  |  | — |  |  | 10,039 |  |
| Total | $ | 6,439 |  |  | $ | 13,968 |  |  | $ | 17,442 |  |  | $ | 17,127 |  |  | $ | 80,563 |  |  | $ | — |  |  | $ | 135,539 |  |
  (was, 2015-11-05, similarity 0.9733):
[0001511737-15-000029:note_history:19]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 7,500 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 46,250 |  |  | $ | — |  |  | $ | 95,000 |  |
| Interest and other payments on debt payment obligations | 1,521 |  |  | 1,893 |  |  | 1,659 |  |  | 1,392 |  |  | 818 |  |  | — |  |  | 7,283 |  |
| Total | $ | 9,021 |  |  | $ | 13,143 |  |  | $ | 16,659 |  |  | $ | 16,392 |  |  | $ | 47,068 |  |  | $ | — |  |  | $ | 102,283 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-02-04):
[0001511737-16-000032:note_history:20]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $394 thousand and $607 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2015, respectively.  In comparison, the Company recognized a total of approximately $29 thousand and $180 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2014, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
  (was, 2015-11-05, similarity 0.6279):
[0001511737-15-000029:note_history:20]
On November 13, 2013, the Company entered into an aircraft lease agreement (the "Aircraft Lease Agreement") with RJP Manageco LLC (the "Lessor"), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $213 thousand in expenses pursuant to the Aircraft Lease Agreement during the three months ended September 30, 2015.  All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.
