# UI 10-Q controls and the auditor's report


## item_4_controls

[0001511737-16-000032:item_4_controls:1]
Item 4. Controls and Procedures

[0001511737-16-000032:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001511737-16-000032:item_4_controls:3]
Management, with the participation of the Company’s Chief Executive Officer and Interim Chief Accounting Officer, evaluated the effectiveness of our disclosure controls and procedures as of December 31, 2015. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives. Based on the evaluation of our disclosure controls and procedures as of December 31, 2015, our Chief Executive Officer and Interim Chief Accounting Officer concluded that, as of such date, due to the identification of material weaknesses in our internal control over financial reporting, as further described in Item 9A of our Annual Report, our disclosure controls and procedures were not effective.

[0001511737-16-000032:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001511737-16-000032:item_4_controls:5]
Our remediation efforts were ongoing during the three months ended December 31, 2015, and, other than those remediation efforts described in “Remediation Plan and Other Information” in Item 9A of our Annual Report, there were no other changes in our internal control over financial reporting that occurred during the three months ended December 31, 2015 that materially affected, or that are reasonably likely to materially affect, our internal control over financial reporting.

[0001511737-16-000032:item_4_controls:6]
The material weaknesses in our internal control over financial reporting, which are described more fully in our Annual Report, continued to exist as of the end of the period covered by this Quarterly Report on Form 10-Q.  The Company is actively engaged in remediation efforts designed to address the material weaknesses, and subsequent to the filing of its Annual Report the Company has added additional full-time and consulting resources to its finance organization.  Additionally, management has reviewed and updated certain accounting policies and procedures, including its disbursement authorities, implemented new financial reporting control procedures and improved overall communication in the finance organization, including clarifying individual roles and responsibilities and documentation standards.  The Company is committed to designing, implementing and operating effective internal controls, and management continues to regularly assess its progress.  We continue to be materially dependent upon outside consultants to provide us with interim accounting resources while we continue to recruit full-time employees.  Successful recruiting and integration of such personnel is a critical component of our remediation efforts designed to address the material weaknesses.

[0001511737-16-000032:item_4_controls:7]
28

[0001511737-16-000032:item_4_controls:8]
Notwithstanding the ineffectiveness of the Company’s disclosure controls and procedures as of the end of the period covered by this Quarterly Report on Form 10-Q and the material weakness in our internal control over financial reporting that existed as of that date, management believes that (i) this Quarterly Report on Form 10-Q does not contain any untrue statement of a material fact or omit to state a material fact necessary to make the statements made, in light of the circumstances under which they were made, not misleading with respect to the period covered by this Quarterly Report on Form 10-Q and (ii) the unaudited consolidated financial statements, and other financial information, included in this Quarterly Report on Form 10-Q fairly present in all material respects in accordance with GAAP our financial condition, results of operations and cash flows as of, and for, the dates and periods presented.

[0001511737-16-000032:item_4_controls:9]
Limitations on the Effectiveness of Controls

[0001511737-16-000032:item_4_controls:10]
Control systems, no matter how well conceived and operated, are designed to provide a reasonable, but not an absolute, level of assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, have been detected. Because of the inherent limitations in any control system, misstatements due to error or fraud may occur and not be detected.
