# UI notes — 0001511737-16-000032


## ubnt:CapitalizedManufacturingOverheadCostsPolicyPolicyTextBlock

[0001511737-16-000032:notes:1]
These capitalized amounts are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.

[0001511737-16-000032:notes:2]
[same as prior period, unchanged from 0001511737-15-000029:notes:1]

[0001511737-16-000032:notes:3]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.


## ubnt:ScheduleOfRevenueAndAccountsReceivableByMajorCustomersByReportingSegmentsTableTableTextBlock

[0001511737-16-000032:notes:4]
[same as prior period, unchanged from 0001511737-15-000029:notes:3]

[0001511737-16-000032:notes:5]
|  | Percentage of Revenues |  | Percentage of Accounts Receivable |
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |  | December 31, |  | June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2015 |
| Customer A | 13% |  | 12% |  | 11% |  | 11% |  | * |  | * |
| Customer B | * |  | 13% |  | * |  | 11% |  | * |  | 13% |
| Customer C | * |  | * |  | * |  | * |  | 14% |  | 12% |
| Customer D | * |  | * |  | * |  | * |  | 15% |  | * |

[0001511737-16-000032:notes:6]
* denotes less than


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001511737-16-000032:notes:7]
[same as prior period, unchanged from 0001511737-15-000029:notes:6]

[0001511737-16-000032:notes:8]
These condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended June 30, 2015, included in its Annual Report on Form 10-K, as filed with the SEC on August 21, 2015 (the “Annual Report”). The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results to be expected for any future periods.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001511737-16-000032:notes:9]
[same as prior period, unchanged from 0001511737-15-000029:notes:8]

[0001511737-16-000032:notes:10]
[same as prior period, unchanged from 0001511737-15-000029:notes:9]

[0001511737-16-000032:notes:11]
[same as prior period, unchanged from 0001511737-15-000029:notes:10]

[0001511737-16-000032:notes:12]
[same as prior period, unchanged from 0001511737-15-000029:notes:11]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001511737-16-000032:notes:13]
COMMITMENTS AND CONTINGENCIES

[0001511737-16-000032:notes:14]
Operating Leases

[0001511737-16-000032:notes:15]
Certain facilities and equipment are leased under non-cancelable operating leases. The Company generally pays taxes, insurance and maintenance costs on leased facilities and equipment. The Company leases office space in San Jose, California and other locations under various non-cancelable operating leases that expire at various dates through 2021.

[0001511737-16-000032:notes:16]
At December 31, 2015, future minimum annual payments under operating leases for the remainder of fiscal 2016 and future fiscal years are as follows (in thousands):

[0001511737-16-000032:notes:17]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases | $ | 2,297 |  |  | $ | 3,629 |  |  | $ | 2,082 |  |  | $ | 978 |  |  | $ | 668 |  |  | $ | 276 |  |  | $ | 9,930 |  |

[0001511737-16-000032:notes:18]
Purchase Obligations

[0001511737-16-000032:notes:19]
The Company primarily subcontracts with other companies to manufacture its products. During the normal course of business, the Company’s contract manufacturers procure components based upon orders placed by the Company. If the Company cancels all or part of the orders, it may still be liable to the contract manufacturers for the cost of the components purchased by them to manufacture the Company’s products. The Company periodically reviews the potential liability, and to date, no significant accruals have been recorded.  The Company had inventory purchase obligations of $21.6 million as of December 31, 2015.

[0001511737-16-000032:notes:20]
Other Obligations

[0001511737-16-000032:notes:21]
The Company had other obligations of $6.2 million as of December 31, 2015, which consisted primarily of commitments related to research and development projects.

[0001511737-16-000032:notes:22]
Indemnification Obligations

[0001511737-16-000032:notes:23]
The Company enters into standard indemnification agreements with many of its business partners in the ordinary course of business. These agreements include provisions for indemnifying the business partner against any claim brought by a third-party to the extent any such claim alleges that a Company product infringes a patent, copyright or trademark, or violates any other proprietary rights of that third-party. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable and the Company has not incurred any material costs to defend lawsuits or settle claims related to these indemnification agreements to date.

[0001511737-16-000032:notes:24]
Legal Matters

[0001511737-16-000032:notes:25]
The Company may be involved, from time to time, in a variety of claims, lawsuits, investigations, and proceedings relating to contractual disputes, intellectual property rights, employment matters, regulatory compliance matters and other litigation matters relating to various claims that arise in the normal course of business. The Company determines whether an estimated loss from a contingency should be accrued by assessing whether a loss is deemed probable and can be reasonably estimated. The Company assesses its potential liability by analyzing specific litigation and regulatory matters using available information. The Company develops its views on estimated losses in consultation with inside and outside counsel, which involves a subjective analysis of potential results and outcomes, assuming various combinations of appropriate litigation and settlement strategies. Taking all of the above factors into account, the Company records an amount where it is probable that the Company will incur a loss and where that loss can be reasonably estimated. However, the Company’s estimates may be incorrect and the Company could ultimately incur more or less than the amounts initially recorded.  The Company may also incur significant legal fees, which are expensed as incurred, in defending against these claims.

[0001511737-16-000032:notes:26]
Shareholder Class Action Lawsuits

[0001511737-16-000032:notes:27]
Beginning on September 7, 2012, two class action lawsuits were filed in the United States District Court for the Northern District of California against Ubiquiti Networks, Inc., certain of its officers and directors, and the underwriters of its initial public offering, alleging claims under U.S. securities laws. On January 30, 2013, the plaintiffs filed an amended consolidated complaint. On March 26, 2014, the court issued an order granting a motion to dismiss the complaint with leave to amend. Following the plaintiffs’ decision not to file an amended complaint, on April 16, 2014, the court ordered the dismissal of the lawsuit with prejudice, and entered judgment in favor of the Company and the other defendants, and against the plaintiffs. On May 15, 2014, the plaintiffs filed a notice of appeal from the judgment of the court. The appeal is ongoing before the U.S. Court of Appeals for the Ninth Circuit. There can be no assurance that the Company will prevail in the appeal proceeding.  The Company cannot currently estimate the possible loss, if any, that it may experience in connection with this litigation.


## us-gaap:DebtDisclosureTextBlock

[0001511737-16-000032:notes:28]
DEBT

[0001511737-16-000032:notes:29]
On August 7, 2012, the Company entered into a Loan and Security Agreement (the “Loan Agreement”) with U.S. Bank, as syndication agent, and East West Bank, as administrative agent for the lenders party to the Loan Agreement.  The Loan Agreement provided for (i) a $50.0 million revolving credit facility, with a $5.0 million sublimit for the issuance of letters of credit and a $5.0 million sublimit for the making of swingline loan advances, and (ii) a $50.0 million term loan facility.

[0001511737-16-000032:notes:30]
On May 5, 2014, Ubiquiti Networks, Inc. and certain of its subsidiaries entered into a credit agreement (the “Original Credit Agreement”) with Wells Fargo Bank, National Association (“Wells Fargo”), the financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders, that provided for a $150.0 million senior secured revolving credit facility, with an option to request an increase in the amount of the credit facility by up to an additional $50.0 million (any such increase to be in each lender’s sole discretion).  Proceeds from borrowings under the Original Credit Agreement were used to repay the Loan Agreement in full.

[0001511737-16-000032:notes:31]
On March 3, 2015, Ubiquiti Networks, Inc. and Ubiquiti International Holding Company Limited (the “Cayman Borrower”) amended and restated the Original Credit Agreement (the “Amended Credit Agreement”) with Wells Fargo, the other financial institutions named as lenders therein, and Wells Fargo as administrative agent for the lenders.  The Amended Credit Agreement provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility (collectively, the “Facilities”), with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion), and matures on March 3, 2020.  The $100.0 million term loan facility of the Amended Credit Agreement was fully drawn at closing, and $72.3 million was used to repay the outstanding balance under the Original Credit Agreement.  During the three months ended December 31, 2015, the Company drew $15 million and $18 million against the revolving credit facility.  These balances are not due until March 2020, and accordingly are classified as long-term debt.  As of December 31, 2015, $92.5 million was outstanding on the term loan and $33 million on the revolver.  As of December 31, 2015, the interest rate on the term loan was 2.10%.  As of December 31, 2015, the interest rate for the $15 million revolver draw was 1.85% and will reset on February 8, 2016.  Additionally, the interest rate for the $18 million revolver draw was 1.91% and will reset on February 16, 2016.  The interest rates on the revolving and term loans fluctuate as described below.  Subsequent to December 31, 2015, the Company drew an additional $33 million on the revolver.

[0001511737-16-000032:notes:32]
The revolving credit facility includes a sub-limit of $10.0 million for letters of credit and a sub-limit of $25.0 million for swingline loans. The Facilities replaced the Company’s $150.0 million senior secured revolving credit facility under the Original Credit Agreement. The Facilities are available for working capital and general corporate purposes that comply with the terms of the Amended Credit Agreement. Under the Amended Credit Agreement, revolving loans and swingline loans may be borrowed, repaid and reborrowed until March 3, 2020, at which time all amounts borrowed must be repaid. The term loan is payable in quarterly installments of 2.50% of the original principal amount of the term loan until March 31, 2017, thereafter increasing to 3.75% of the original principal amount of the term loan, in each case plus accrued and unpaid interest. Revolving, swingline and term loans may be prepaid at any time without penalty.

[0001511737-16-000032:notes:33]
Revolving and term loans bear interest, at the Company’s option, at either (i) a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter or (ii) a floating per annum rate equal to the applicable LIBOR rate for a specified period, plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Swingline loans bear interest at a floating rate per annum equal to the base rate plus a margin of between 0.50% and 1.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. Base rate is defined as the greatest of (A) Wells Fargo’s prime rate, (B) the federal funds rate plus 0.50% or (C) the applicable LIBOR rate for a period of one month plus 1.00%. A default interest rate shall apply on all obligations during certain events of default under the Amended Credit Agreement at a rate per annum equal to 2.00% above the applicable interest rate. The Company will pay to each lender a facility fee on a quarterly basis based on the unused amount of each lender’s commitment to make revolving loans, of between 0.20% and 0.35%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter. The Company will also pay to the applicable lenders on a quarterly basis certain fees based on the daily amount available to be drawn under each outstanding letter of credit, including aggregate letter of credit commissions of the LIBOR rate plus a margin of between 1.50% and 2.25%, depending on the Company’s leverage ratio as of the most recently ended fiscal quarter, and issuance fees of 0.125% per annum. The Company is also obligated to pay Wells Fargo, as agent, fees customary for a credit facility of this size and type.

[0001511737-16-000032:notes:34]
The Amended Credit Agreement requires the Company to maintain during the term of the Facilities (i) a maximum leverage ratio of 2.50 to 1.00 and (ii) minimum liquidity of $225.0 million, increasing to $250.0 million in the event of an incremental increase in the size of the Facilities, which can be satisfied with unrestricted cash and cash equivalents and up to $50.0 million of availability under the revolving credit facility. In addition, the Amended Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the ability of the Company and its subsidiaries to, among other things, grant liens or enter into agreements restricting their ability to grant liens on property, enter into mergers, dispose of assets, change their accounting or reporting policies, change their business and incur indebtedness, in each case subject to customary exceptions for a credit facility of this size and type. The Amended Credit Agreement includes customary events of default that include, among other things, non-payment of principal, interest or fees, inaccuracy of representations and warranties, violation of covenants, cross default to certain other indebtedness, bankruptcy and insolvency events, material judgments, change of control and certain ERISA events. The occurrence of an event of default could result in the acceleration of the obligations under the Amended Credit Agreement.

[0001511737-16-000032:notes:35]
The obligations of Ubiquiti Networks, Inc. and certain domestic subsidiaries, if any, under the Amended Credit Agreement are required to be guaranteed by such domestic subsidiaries (the “Domestic Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of Ubiquiti Networks, Inc. and the Domestic Guarantors. The obligations of the Cayman Borrower and certain foreign subsidiaries under the Amended Credit Agreement are required to be guaranteed by certain domestic and material foreign subsidiaries (the “Guarantors”) and are collateralized by substantially all assets (excluding intellectual property) of the Cayman Borrower and the Guarantors.

[0001511737-16-000032:notes:36]
During the three months ended December 31, 2015, the Company made a payment of $2.9 million against the term loan facility balance under the Amended Credit Agreement, of which $2.5 million was a repayment of principal and $439 thousand was payment of interest. During the six months ended December 31, 2015, the Company made aggregate payments of $5.9 million against the term loan facility balance under the Amended Credit Agreement, of which $5.0 million was a repayment of principal and $883 thousand was payment of interest.  During the three and six months ended December 31, 2015, the Company made aggregate payments of $99 thousand against the revolving loan facility under the Amended Credit Agreement.  As of December 31, 2015, the Company classified $10.0 million as short-term and $115.5 million as long-term debt on its consolidated balance sheet related to the Facilities under the Amended Credit Agreement.

[0001511737-16-000032:notes:37]
On September 2, 2015, the Company accessed a letter of credit under its revolving credit facility in the amount of $237 thousand for the benefit of the landlord pursuant to a new lease of office space. The landlord can draw against the letter of credit in the event of default by the Company. The letter of credit expires on September 2, 2016, subject to automatic renewal for additional one-year periods.

[0001511737-16-000032:notes:38]
The following table summarizes our estimated debt and interest payment obligations as of December 31, 2015, for the remainder of fiscal 2016 and future fiscal years (in thousands):

[0001511737-16-000032:notes:39]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt payment obligations | $ | 5,000 |  |  | $ | 11,250 |  |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | 79,250 |  |  | $ | — |  |  | $ | 125,500 |  |
| Interest and other payments on debt | 1,439 |  |  | 2,718 |  |  | 2,442 |  |  | 2,127 |  |  | 1,313 |  |  | — |  |  | 10,039 |  |
| Total | $ | 6,439 |  |  | $ | 13,968 |  |  | $ | 17,442 |  |  | $ | 17,127 |  |  | $ | 80,563 |  |  | $ | — |  |  | $ | 135,539 |  |


## us-gaap:DeferredCostsCapitalizedPrepaidAndOtherAssetsDisclosureTextBlock

[0001511737-16-000032:notes:40]
[same as prior period, unchanged from 0001511737-15-000029:notes:38]

[0001511737-16-000032:notes:41]
|  | December 31, 2015 |  | June 30, 2015 |
| BEC recovery receivable | $ | — |  |  | $ | 1,376 |  |
| Other current assets | 8,440 |  |  | 6,335 |  |
|  | $ | 8,440 |  |  | $ | 7,711 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001511737-16-000032:notes:42]
[same as prior period, unchanged from 0001511737-15-000029:notes:40]

[0001511737-16-000032:notes:43]
[same as prior period, unchanged from 0001511737-15-000029:notes:41]

[0001511737-16-000032:notes:44]
The Company’s 2010 Equity Incentive Plan and 2005 Equity Incentive Plan are described in its Annual Report. As of December 31, 2015, the Company had 10,030,685 authorized shares available for future issuance under all of its stock incentive plans.

[0001511737-16-000032:notes:45]
[same as prior period, unchanged from 0001511737-15-000029:notes:43]

[0001511737-16-000032:notes:46]
The following table shows total stock-based compensation expense included in the Condensed Consolidated Statements of Operations for the three and six months ended December 31, 2015 and 2014 (in thousands):

[0001511737-16-000032:notes:47]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of sales | $ | 114 |  |  | $ | 150 |  |  | $ | 227 |  |  | $ | 299 |  |
| Research and development | 580 |  |  | 864 |  |  | 1,204 |  |  | 1,689 |  |
| Sales, general and administrative | 263 |  |  | 417 |  |  | 553 |  |  | 815 |  |
|  | $ | 957 |  |  | $ | 1,431 |  |  | $ | 1,984 |  |  | $ | 2,803 |  |

[0001511737-16-000032:notes:48]
[same as prior period, unchanged from 0001511737-15-000029:notes:46]

[0001511737-16-000032:notes:49]
The following is a summary of option activity for the Company’s stock incentive plans for the six months ended December 31, 2015:

[0001511737-16-000032:notes:50]
|  | Common Stock Options Outstanding |
|  | Numberof Shares |  | WeightedAverageExercisePrice |  | WeightedAverageRemainingContractualLife (Years) |  | AggregateIntrinsicValue(In thousands) |
| Balance, June 30, 2015 | 2,301,144 |  |  | $ | 2.38 |  |  |  |  |  |
| Exercised | (78,863 | ) |  | 6.17 |  |  |  |  |  |
| Forfeitures and cancellations | (927 | ) |  | 20.10 |  |  |  |  |  |
| Balance, December 31, 2015 | 2,221,354 |  |  | 2.24 |  |  | 3.23 |  | $ | 65,417 |  |
| Vested and expected to vest as of December 31, 2015 | 2,218,887 |  |  | $ | 2.23 |  |  | 3.22 |  | $ | 65,367 |  |
| Vested and exercisable as of December 31, 2015 | 2,140,364 |  |  | $ | 1.90 |  |  | 3.10 |  | $ | 63,769 |  |

[0001511737-16-000032:notes:51]
During the three months ended December 31, 2015 and December 31, 2014, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $738 thousand and $140 thousand, respectively, as determined as of the date of option exercise.  During the six months ended December 31, 2015 and 2014, the aggregate intrinsic value of options exercised under the Company’s stock incentive plans was $2.2 million and $5 million, respectively, as determined as of the date of option exercise.

[0001511737-16-000032:notes:52]
As of December 31, 2015, the Company had unrecognized compensation costs of $421 thousand related to stock options which the Company expects to recognize over a weighted-average period of 1.0 year. Future option grants will increase the amount of compensation expense to be recorded in these periods.

[0001511737-16-000032:notes:53]
The Company estimates the fair value of employee stock options using the Black-Scholes option pricing model. The fair value of employee stock options is amortized on a straight-line basis over the requisite service period of the awards.  The Company did not grant any employee stock options during the three and six months ended December 31, 2015 and 2014.

[0001511737-16-000032:notes:54]
[same as prior period, unchanged from 0001511737-15-000029:notes:52]

[0001511737-16-000032:notes:55]
[same as prior period, unchanged from 0001511737-15-000029:notes:53]

[0001511737-16-000032:notes:56]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value Per Share |
| Non-vested RSUs, June 30, 2015 | 400,635 |  |  | $ | 26.95 |  |
| RSUs granted | 48,051 |  |  | 32.93 |  |
| RSUs vested | (86,592 | ) |  | 24.11 |  |
| RSUs cancelled | (63,184 | ) |  | 34.28 |  |
| Non-vested RSUs, December 31, 2015 | 298,910 |  |  | $ | 27.18 |  |

[0001511737-16-000032:notes:57]
The intrinsic value of RSUs vested in the three months ended December 31, 2015 and 2014 was $941 thousand and $1.1 million, respectively.  The intrinsic value of RSUs vested in the six months ended December 31, 2015 and 2014 was $2.8 million and $3.8 million, respectively.

[0001511737-16-000032:notes:58]
As of December 31, 2015, there were unrecognized compensation costs related to RSUs of $5.9 million which the Company expects to recognize over a weighted average period of 2.9 years.


## us-gaap:EarningsPerShareTextBlock

[0001511737-16-000032:notes:59]
[same as prior period, unchanged from 0001511737-15-000029:notes:57]

[0001511737-16-000032:notes:60]
[same as prior period, unchanged from 0001511737-15-000029:notes:58]

[0001511737-16-000032:notes:61]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |
| Net income and comprehensive income | $ | 49,452 |  |  | $ | 46,265 |  |  | $ | 103,211 |  |  | $ | 84,008 |  |
| Denominator: |  |  |  |
| Weighted-average shares used in computing basic net income per share | 84,724 |  |  | 88,196 |  |  | 85,893 |  |  | 88,218 |  |
| Add—dilutive potential common shares: |  |  |  |  |  |  |  |
| Stock options | 1,281 |  |  | 1,398 |  |  | 1,291 |  |  | 1,442 |  |
| Restricted stock units | 86 |  |  | 143 |  |  | 101 |  |  | 178 |  |
| Weighted-average shares used in computing diluted net income per share | 86,091 |  |  | 89,737 |  |  | 87,285 |  |  | 89,838 |  |
| Net income per share of common stock: |  |  |  |
| Basic | $ | 0.58 |  |  | $ | 0.52 |  |  | $ | 1.20 |  |  | $ | 0.95 |  |
| Diluted | $ | 0.57 |  |  | $ | 0.52 |  |  | $ | 1.18 |  |  | $ | 0.94 |  |

[0001511737-16-000032:notes:62]
[same as prior period, unchanged from 0001511737-15-000029:notes:60]

[0001511737-16-000032:notes:63]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Restricted stock units | 22 |  |  | 117 |  |  | 1 |  |  | 6 |  |
|  | 22 |  |  | 117 |  |  | 1 |  |  | 6 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001511737-16-000032:notes:64]
As of December 31, 2015 and June 30, 2015, the fair value hierarchy of the Company’s debt carried at historical cost was as follows (in thousands):

[0001511737-16-000032:notes:65]
|  | December 31, 2015 |  | June 30, 2015 |
|  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |  | FairValue |  | Level 1 |  | Level 2 |  | Level 3 |
| Debt | $ | 125,500 |  |  | $ | — |  |  | $ | 125,500 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |  | $ | 97,500 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001511737-16-000032:notes:66]
[same as prior period, unchanged from 0001511737-15-000029:notes:64]

[0001511737-16-000032:notes:67]
[same as prior period, unchanged from 0001511737-15-000029:notes:65]

[0001511737-16-000032:notes:68]
[same as prior period, unchanged from 0001511737-15-000029:notes:66]

[0001511737-16-000032:notes:69]
[same as prior period, unchanged from 0001511737-15-000029:notes:67]

[0001511737-16-000032:notes:70]
[same as prior period, unchanged from 0001511737-15-000029:notes:68]

[0001511737-16-000032:notes:71]
For certain of the Company’s financial instruments, including accounts receivable and accounts payable, the carrying amounts approximate fair value due to their short maturities.  Additionally, as of December 31, 2015, we held $476.9 million of our $496.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we would incur significant tax liabilities if we were to repatriate those amounts.

[0001511737-16-000032:notes:72]
At December 31, 2015 and June 30, 2015 the Company had debt associated with its Amended Credit Agreement with Wells Fargo Bank (See Note 7). The fair value of the Company’s debt was estimated based on the current rates offered to the Company for debt with similar terms and remaining maturities and was Level 2 measurement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001511737-16-000032:notes:73]
[same as prior period, unchanged from 0001511737-15-000029:notes:71]

[0001511737-16-000032:notes:74]
As of December 31, 2015, the Company had approximately $21.9 million of unrecognized tax benefits, substantially all of which would, if recognized, affect its tax expense. The Company has elected to include interest and penalties related to uncertain tax positions as a component of tax expense. At December 31, 2015, an insignificant amount of interest and penalties are included in long-term income tax payable. The Company recorded a net increase of its unrecognized tax benefits of $1.2 million for the three months ended December 31, 2015. The Company does not expect any significant increases or decreases to its unrecognized tax benefits in the next twelve months.

[0001511737-16-000032:notes:75]
The Company recorded a tax provision of $6.3 million and $12.3 million for the three and six months ended December 31, 2015.  The Company’s estimated fiscal 2016 effective tax rate differs from the U.S. statutory rate primarily due to profits earned in jurisdictions where the tax rate is lower than the U.S. tax rate.

[0001511737-16-000032:notes:76]
[same as prior period, unchanged from 0001511737-15-000029:notes:74]

[0001511737-16-000032:notes:77]
[same as prior period, unchanged from 0001511737-15-000029:notes:75]

[0001511737-16-000032:notes:78]
As discussed in Note 2, in November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes. We are currently evaluating ASU 2015-17 to determine if this guidance will have a material impact on our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001511737-16-000032:notes:79]
Recent Accounting Pronouncements

[0001511737-16-000032:notes:80]
In June 2014, the Financial Accounting Standards Board, or FASB, issued a new accounting standard update on revenue from contracts with customers.  The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  To achieve that core principle, an entity should apply the following steps:

[0001511737-16-000032:notes:81]
Step 1: Identify the contract(s) with a customer.

[0001511737-16-000032:notes:82]
Step 2: Identify the performance obligations in the contract.

[0001511737-16-000032:notes:83]
Step 3: Determine the transaction price.

[0001511737-16-000032:notes:84]
Step 4: Allocate the transaction price to the performance obligations in the contract.

[0001511737-16-000032:notes:85]
Step 5: Recognize revenue when (or as) the entity satisfies a performance obligation.

[0001511737-16-000032:notes:86]
An entity should disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. Qualitative and quantitative information is required about contracts with customers, significant judgments and any assets recognized from the costs to obtain or fulfill a contract.   The guidance was initially effective for annual and interim reporting periods beginning after December 15, 2016.  However, in July 2015, the FASB voted to defer the effective date by one year, to December 15, 2017, to provide adequate time to effectively implement the new standard.  The Company does not anticipate that the new guidance will have a material impact on its consolidated financial statements.

[0001511737-16-000032:notes:87]
In April 2015, the FASB issued an accounting standard update on simplifying the presentation of debt issuance costs.  The updated guidance requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The recognition and measurement guidance for debt issuance costs are not affected by the updated guidance.  The guidance will be effective for the Company beginning July 1, 2016.  The guidance will result only in a reclassification on the Company’s balance sheet and will not have any effect on the Company’s results of operations or cash flows.

[0001511737-16-000032:notes:88]
In July 2015, the FASB issued Accounting Standards Update (ASU) 2015-11 which explains how the Accounting Standards Codification will be updated to simplify the measurement of inventory costs.  The updated guidance requires that inventory be valued at the lower of cost or net realizable value.  This differs from current guidance which requires that inventory be valued at the lower of cost or market, where market can be replacement cost, net realizable value or net realizable value less an approximately normal profit margin.  The guidance will be effective for the Company beginning July 1, 2017.  We do not anticipate that this guidance will have a material impact on the presentation of the Company’s consolidated financial statements.

[0001511737-16-000032:notes:89]
In November 2015, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2015-17, Balance Sheet Classification of Deferred Taxes. ASU 2015-17 simplifies the presentation of deferred taxes by requiring deferred tax assets and liabilities be classified as noncurrent on the balance sheet. ASU 2015-17 is effective for public companies for annual reporting periods beginning after December 15, 2016, and interim periods within those fiscal years. The guidance may be adopted prospectively or retrospectively and early adoption is permitted. We are currently evaluating ASU 2015-17 to determine if this guidance will have a material impact on our consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001511737-16-000032:notes:90]
[same as prior period, unchanged from 0001511737-15-000029:notes:86]

[0001511737-16-000032:notes:91]
|  | December 31, 2015 |  | June 30, 2015 |
| Accrued expenses | $ | 6,011 |  |  | $ | 5,540 |  |
| Accrued compensation and benefits | 1,637 |  |  | 2,142 |  |
| Warranty accrual | 2,205 |  |  | 2,750 |  |
| Deferred revenue - short term | 2,720 |  |  | 2,538 |  |
| Customer deposits | 572 |  |  | 63 |  |
| Reserve for sales returns | 1,389 |  |  | 1,227 |  |
| Other payables | 1,683 |  |  | 910 |  |
|  | $ | 16,217 |  |  | $ | 15,170 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001511737-16-000032:notes:92]
[same as prior period, unchanged from 0001511737-15-000029:notes:88]

[0001511737-16-000032:notes:93]
The Company offers warranties on certain products, generally for a period of one year, and records a liability for the estimated future costs associated with potential warranty claims. The warranty costs are reflected in the Company’s consolidated statement of operations and comprehensive income within cost of revenues. The warranties are typically in effect for twelve months from the distributor’s purchase date of the product. The Company’s estimate of future warranty costs is largely based on historical factors including product failure rates, material usage, and service delivery cost incurred in replacing products. In certain circumstances, the Company may have recourse from its contract manufacturers for replacement cost of defective products, which it also factors into its warranty liability assessment.

[0001511737-16-000032:notes:94]
[same as prior period, unchanged from 0001511737-15-000029:notes:90]

[0001511737-16-000032:notes:95]
|  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |
| Beginning balance | $ | 2,750 |  |  | $ | 2,850 |  |
| Accruals for warranties issued during the period | 1,027 |  |  | 1,718 |  |
| Settlements made during the period | (1,572 | ) |  | (1,818 | ) |
|  | $ | 2,205 |  |  | $ | 2,750 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001511737-16-000032:notes:96]
[same as prior period, unchanged from 0001511737-15-000029:notes:92]

[0001511737-16-000032:notes:97]
|  | December 31, 2015 |  | June 30, 2015 |
| Testing equipment | $ | 5,378 |  |  | $ | 4,816 |  |
| Computer and other equipment | 4,577 |  |  | 4,458 |  |
| Tooling equipment | 4,849 |  |  | 4,073 |  |
| Furniture and fixtures | 1,325 |  |  | 1,239 |  |
| Leasehold improvements | 4,931 |  |  | 4,789 |  |
| Software (1) | 2,333 |  |  | 3,268 |  |
| Software in development (1),(2) | 2,567 |  |  | 2,700 |  |
|  | 25,960 |  |  | 25,343 |  |
| Less: Accumulated depreciation and amortization (3) | (12,601 | ) |  | (9,741 | ) |
|  | $ | 13,359 |  |  | $ | 15,602 |  |

[0001511737-16-000032:notes:98]
(1) - In the three months ended December 31, 2015, the Company recorded a $2.5 million impairment charge for capitalized software development costs due to the cancellation of the commercial launch of certain software in development.

[0001511737-16-000032:notes:99]
(2) - We capitalized $323 thousand and $1.2 million for software development for the three and six months ended December 31, 2015, respectively.

[0001511737-16-000032:notes:100]
(3) - Depreciation expense was $1.4 million and $2.9 million for the three and six months ended December 31, 2015, respectively.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001511737-16-000032:notes:101]
[same as prior period, unchanged from 0001511737-15-000029:notes:96]

[0001511737-16-000032:notes:102]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Service Provider Technology | $ | 109,616 |  |  | 68 | % |  | $ | 99,720 |  |  | 65 | % |  | $ | 213,015 |  |  | 68 | % |  | $ | 206,991 |  |  | 68 | % |
| Enterprise Technology | 52,255 |  |  | 32 | % |  | 53,417 |  |  | 35 | % |  | 100,271 |  |  | 32 | % |  | 96,233 |  |  | 32 | % |
| Total revenues | $ | 161,871 |  |  | 100 | % |  | $ | 153,137 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001511737-16-000032:notes:103]
RELATED PARTY TRANSACTIONS AND CERTAIN OTHER TRANSACTIONS

[0001511737-16-000032:notes:104]
Aircraft Lease Agreement

[0001511737-16-000032:notes:105]
On November 13, 2013, the Company entered into an aircraft lease agreement (the “Aircraft Lease Agreement”) with RJP Manageco LLC (the “Lessor”), a limited liability company owned by the Company’s CEO, Robert J. Pera. Pursuant to the Aircraft Lease Agreement, the Company may lease an aircraft owned by the Lessor for Company business purposes. Under the Aircraft Lease Agreement, the aircraft may be leased at a rate of $5,000 per flight hour. This hourly rate does not include the cost of flight crew or on-board services, which the Company purchases from a third-party provider. The Company recognized a total of approximately $394 thousand and $607 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2015, respectively.  In comparison, the Company recognized a total of approximately $29 thousand and $180 thousand in expenses pursuant to the Aircraft Lease Agreement during the three and six months ended December 31, 2014, respectively. All expenses pursuant to the Aircraft Lease Agreement have been included in the Company’s sales, general and administrative expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001511737-16-000032:notes:106]
[same as prior period, unchanged from 0001511737-15-000029:notes:101]

[0001511737-16-000032:notes:107]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| North America (1) | $ | 57,133 |  |  | 35 | % |  | $ | 54,127 |  |  | 35 | % |  | $ | 110,367 |  |  | 35 | % |  | $ | 107,708 |  |  | 36 | % |
| South America | 23,795 |  |  | 15 | % |  | 22,241 |  |  | 15 | % |  | 45,943 |  |  | 15 | % |  | 53,376 |  |  | 18 | % |
| Europe, the Middle East and Africa | 60,973 |  |  | 38 | % |  | 60,097 |  |  | 39 | % |  | 121,476 |  |  | 39 | % |  | 110,704 |  |  | 36 | % |
| Asia Pacific | 19,970 |  |  | 12 | % |  | 16,672 |  |  | 11 | % |  | 35,500 |  |  | 11 | % |  | 31,436 |  |  | 10 | % |
| Total revenues | $ | 161,871 |  |  | 100 | % |  | $ | 153,137 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |

[0001511737-16-000032:notes:108]
| (1) | Revenue for the United States was $53.6 million and $50.5 million for the three months ended December 31, 2015 and 2014, respectively. Revenue for the United States was $104.2 million and $102.2 million for the six months ended December 31, 2015 and 2014, respectively. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001511737-16-000032:notes:109]
[same as prior period, unchanged from 0001511737-15-000029:notes:104]

[0001511737-16-000032:notes:110]
|  | December 31, 2015 |  | June 30, 2015 |
| Finished goods | $ | 31,724 |  |  | $ | 35,848 |  |
| Raw materials | 1,381 |  |  | 1,183 |  |
|  | $ | 33,105 |  |  | $ | 37,031 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001511737-16-000032:notes:111]
[same as prior period, unchanged from 0001511737-15-000029:notes:106]

[0001511737-16-000032:notes:112]
|  | December 31, 2015 |  | June 30, 2015 |
| Intangible assets, net (1) | $ | 466 |  |  | $ | 575 |  |
| Debt issuance costs, net (2) | 814 |  |  | 943 |  |
| Other long-term assets | 638 |  |  | 591 |  |
|  | $ | 1,918 |  |  | $ | 2,109 |  |

[0001511737-16-000032:notes:113]
(1) - Accumulated amortization was $820 thousand and $690 thousand as of December 31, 2015 and June 30, 2015, respectively.

[0001511737-16-000032:notes:114]
(2) - Accumulated amortization was $213 thousand and $84 thousand as of December 31, 2015 and June 30, 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001511737-16-000032:notes:115]
[same as prior period, unchanged from 0001511737-15-000029:notes:110]

[0001511737-16-000032:notes:116]
[same as prior period, unchanged from 0001511737-15-000029:notes:111]

[0001511737-16-000032:notes:117]
| • | Service Provider Technology includes the Company’s airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and Customer Premise Equipment (“CPE”). Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0 GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes solar products (sales of which have not been material to date) and revenues that are attributable to post-contract customer support (“PCS”). |

[0001511737-16-000032:notes:118]
| • | Enterprise Technology includes the Company’s UniFi and mFi platforms, including UniFi Access Point (“UAP”) products, UniFi Video products, UniFi Voice Over IP (“VOIP”) phones and UniFi switch products. Enterprise Technology also includes revenues that are attributable to PCS. |

[0001511737-16-000032:notes:119]
* denotes less than 10%


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001511737-16-000032:notes:120]
[same as prior period, unchanged from 0001511737-15-000029:notes:115]

[0001511737-16-000032:notes:121]
[same as prior period, unchanged from 0001511737-15-000029:notes:116]

[0001511737-16-000032:notes:122]
In fiscal 2016, the Company began capitalizing manufacturing overhead expenditures as part of inventory costs.  Capitalized costs primarily include management’s best estimate of the direct labor and materials costs related to inventory produced but not sold during the period.  As of December 31, 2015, the Company capitalized $994 thousand of manufacturing overhead costs, which are included in inventory on the Company’s condensed consolidated balance sheet as of December 31, 2015.  These capitalized amounts are recognized as cost of revenues in the following quarter, consistent with the Company's historical inventory turnover.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001511737-16-000032:notes:123]
[same as prior period, unchanged from 0001511737-15-000029:notes:117]

[0001511737-16-000032:notes:124]
As of December 31, 2015 and June 30, 2015, the authorized capital of the Company included 500,000,000 shares of common stock.  As of December 31, 2015 and June 30, 2015, there were 84,610,812 and 87,413,777 shares of common stock outstanding, respectively.

[0001511737-16-000032:notes:125]
[same as prior period, unchanged from 0001511737-15-000029:notes:119]

[0001511737-16-000032:notes:126]
Effective August 7, 2015, the Board of Directors approved a $100 million stock repurchase program. Under the stock repurchase program, the Company was authorized to repurchase up to $100 million of its common stock.  All common stock repurchased by the Company is immediately retired.  Upon retirement, the excess over par value is recorded as a reduction in Additional Paid-in Capital until the balance is reduced to zero, with any additional excess recorded to Retained Earnings.  The share repurchase program is funded from existing domestic cash on hand in addition to draws on the revolving credit facility of the Amended Credit Agreement.  In the first quarter of fiscal 2016, the Company repurchased 1,872,469 shares of its common stock at an average price per share of $33.79 for an aggregate amount of $63.3 million.  Of the $63.3 million of repurchases and retirements, $1.1 million was recorded against Additional Paid-in Capital and $62.2 million to Retained Earnings.  In the second fiscal quarter of 2016, the Company repurchased 1,074,749 shares of its common stock at an average price per share of $34.12 for an aggregate amount of $36.7 million, extinguishing the full $100 million of availability under this stock repurchase program.  Of the $36.7 million of repurchases and retirements, $1.1 million was recorded against Additional Paid-in Capital and $35.6 million to Retained Earnings.

[0001511737-16-000032:notes:127]
Effective November 6, 2015, the Board of Directors of the Company approved a new stock repurchase program where the Company may repurchase up to $50 million of its common stock.  The plan expires on September 30, 2016.  As of December 31, 2015, the Company had the full $50 million remaining for common stock repurchases under the repurchase plan.  Subsequent to December 31, 2015, the Company repurchased an additional 1,765,523 shares of its common stock at an average price per share of $28.30 for an aggregate amount of $50.0 million, extinguishing the full $50.0 million available under this stock repurchase program.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001511737-16-000032:notes:128]
[same as prior period, unchanged from 0001511737-15-000029:notes:124]

[0001511737-16-000032:notes:129]
[same as prior period, unchanged from 0001511737-15-000029:notes:125]

[0001511737-16-000032:notes:130]
[same as prior period, unchanged from 0001511737-15-000029:notes:126]

[0001511737-16-000032:notes:131]
[same as prior period, unchanged from 0001511737-15-000029:notes:127]

[0001511737-16-000032:notes:132]
[same as prior period, unchanged from 0001511737-15-000029:notes:128]

[0001511737-16-000032:notes:133]
[same as prior period, unchanged from 0001511737-15-000029:notes:129]


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001511737-16-000032:notes:134]
[same as prior period, unchanged from 0001511737-15-000029:notes:130]

[0001511737-16-000032:notes:135]
As disclosed in Note 14 of the Annual Report, in June 2015 the Company determined that it was the victim of a criminal fraud known to law enforcement authorities as business e-mail compromise fraud which involved employee impersonation and fraudulent requests targeting our finance department.  The fraud resulted in transfers of funds aggregating $46.7 million held by a Company subsidiary incorporated in Hong Kong to other overseas accounts held by third parties.  As of June 30, 2015, the Company recovered $8.1 million.  As a result, the Company recorded a charge of $39.1 million in the fourth quarter of fiscal 2015, including additional expenses consisting of professional service fees associated with the fraud loss.  During the three months ended September 30, 2015, the Company secured a court order for an additional recovery of $8.6 million.  As a result, the Company recorded a net recovery of $8.0 million in the first quarter of fiscal 2016, comprised of the $8.6 million recovery less $564 thousand of professional service fees associated with the recovery.  As of September 30, 2015, $6.0 million of the $8.6 million was recorded as receivable.  During the three months ended December 31, 2015, the Company collected the $6.0 million, receiving $5.6 million in cash net of $400 thousand in foreign exchange loss and transaction fees. Additionally, the Company recorded a net recovery of $257 thousand as a result of incurring $344 thousand less in BEC legal expenses than previously accrued at September 30, 2015 offset by $87 thousand in transaction fees.

[0001511737-16-000032:notes:136]
The Company is continuing to pursue the recovery of the remaining $30.0 million and is cooperating with U.S. federal and numerous overseas law enforcement authorities who are actively pursuing a multi-agency criminal investigation.  Any additional recoveries are likely remote and therefore cannot be assured.
