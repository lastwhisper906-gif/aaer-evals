# UI 8-K — 0001415889-16-004613 filed 2016-02-04

## item codes, every 8-K on or before 2016-02-04

- 2016-02-04 0001415889-16-004613 — 2.02, 9.01
- 2015-12-18 0001415889-15-004120 — 3.01, 5.07
- 2015-11-05 0001415889-15-003599 — 2.02, 8.01, 9.01
- 2015-10-16 0001415889-15-003433 — 5.02
- 2015-08-06 0001571049-15-006288 — 2.02, 5.02, 8.01, 9.01
- 2015-05-07 0001511737-15-000016 — 2.02, 9.01
- 2015-04-23 0001415889-15-001433 — 2.02, 5.02, 9.01
- 2015-03-06 0001415889-15-000787 — 1.01, 1.02, 2.03, 9.01
- 2015-02-05 0001511737-15-000008 — 2.02, 9.01
- 2014-12-18 0001193125-14-446627 — 5.07
- 2014-11-06 0001511737-14-000029 — 2.02, 9.01
- 2014-09-30 0001193125-14-359060 — 7.01, 9.01
- 2014-08-07 0001511737-14-000021 — 2.02, 9.01
- 2014-05-08 0001511737-14-000016 — 2.02, 9.01
- 2014-04-17 0001193125-14-146710 — 7.01
- 2014-03-06 0001193125-14-084883 — 8.01
- 2014-02-06 0001511737-14-000005 — 2.02, 9.01
- 2013-12-16 0001193125-13-474388 — 5.07
- 2013-11-22 0001193125-13-451511 — 5.02
- 2013-11-07 0001511737-13-000018 — 2.02, 9.01
- 2013-10-28 0001193125-13-413414 — 5.02, 9.01
- 2013-10-18 0001193125-13-404111 — 5.02, 9.01
- 2013-08-08 0001511737-13-000009 — 2.02, 9.01
- 2013-05-09 0001511737-13-000004 — 2.02
- 2013-03-25 0001193125-13-124353 — 5.07
- 2013-03-08 0001193125-13-098334 — 5.02, 9.01
- 2013-02-07 0001193125-13-043701 — 2.02, 9.01
- 2012-12-28 0001193125-12-518487 — 1.01
- 2012-12-17 0001193125-12-503742 — 7.01, 9.01
- 2012-12-13 0001193125-12-501894 — 5.02
- 2012-11-16 0001193125-12-474083 — 5.02
- 2012-11-13 0001193125-12-467376 — 5.02
- 2012-11-08 0001193125-12-460665 — 2.02, 9.01
- 2012-10-10 0001193125-12-420015 — 5.02, 9.01
- 2012-08-13 0001193125-12-352624 — 1.01, 2.03, 9.01
- 2012-08-09 0001193125-12-347776 — 1.01, 9.01
- 2012-08-09 0001193125-12-347732 — 2.02, 9.01
- 2012-05-01 0001193125-12-201012 — 2.02, 9.01
- 2012-03-30 0001193125-12-144074 — 5.02
- 2012-03-27 0001193125-12-134395 — 5.02, 9.01
- 2012-03-22 0001193125-12-127536 — 5.02
- 2012-01-31 0001193125-12-032079 — 2.02, 9.01
- 2011-12-27 0001193125-11-353002 — 1.01, 9.01
- 2011-12-06 0001193125-11-332192 — 5.02
- 2011-11-10 0001193125-11-306969 — 2.02, 9.01

## late-filing notifications on or before 2016-02-04

- none on or before 2016-02-04

## item 2.02 — earnings release, exhibit 99.1

[0001415889-16-004613:8k_2_02:1]
EX-99
2
ex99-02042016_040207.htm

[0001415889-16-004613:8k_2_02:2]
ubiquityex991.htm

[0001415889-16-004613:8k_2_02:3]
UBIQUITI NETWORKS REPORTS SECOND QUARTER FISCAL 2016 FINANCIAL RESULTS

[0001415889-16-004613:8k_2_02:4]
~ Achieves Record Revenue and Earnings ~

[0001415889-16-004613:8k_2_02:5]
~ Non-GAAP Diluted EPS of $0.58 Per Share ~

[0001415889-16-004613:8k_2_02:6]
SAN JOSE, Calif. – Feb. 04, 2016 - Ubiquiti Networks, Inc. (NASDAQ:UBNT) (“Ubiquiti”) today announced results for the second fiscal quarter of 2016, ended December 31, 2015.

[0001415889-16-004613:8k_2_02:7]
Second Quarter Fiscal 2016 Financial Summary

[0001415889-16-004613:8k_2_02:8]
| ● | Revenues of $161.9 million |

[0001415889-16-004613:8k_2_02:9]
| ● | GAAP gross profit of $79.0 million and non-GAAP gross profit of $79.1 million |

[0001415889-16-004613:8k_2_02:10]
| ● | GAAP net income of $49.5 million and non-GAAP net income of $49.7 million |

[0001415889-16-004613:8k_2_02:11]
| ● | GAAP diluted EPS of $0.57 and non-GAAP diluted EPS of $0.58 |

[0001415889-16-004613:8k_2_02:12]
| ● | Cash of $496.7 million, up 28% year-over-year and 14% sequentially |

[0001415889-16-004613:8k_2_02:13]
| ● | $77.3 million in net cash provided by operating activities |

[0001415889-16-004613:8k_2_02:14]
Recent Financial Highlights

[0001415889-16-004613:8k_2_02:15]
| ● | Enterprise Technology revenues increased 9% quarter-over-quarter, fueled by UniFi® AC access points, UniFi Switch and other industry-leading products targeting the Enterprise market. |

[0001415889-16-004613:8k_2_02:16]
| ● | Service Provider Technology revenues increased 6% quarter-over-quarter, primarily fueled by our airMAX® technology platform. |

[0001415889-16-004613:8k_2_02:17]
| ● | Completed $50 million stock repurchase plan as of February 3, 2016. |

[0001415889-16-004613:8k_2_02:18]
Recent Product Highlights

[0001415889-16-004613:8k_2_02:19]
| ● | Shipped in volume UniFi AC access points which feature the latest Wi-Fi 802.11ac technology in a refined industrial design and are ideal for cost-effective deployment of high‑performance wireless networks. |

[0001415889-16-004613:8k_2_02:20]
| ● | Released EdgePoint, an innovative combination of robust routing performance, fiber backhaul capability, and the convenience of passive PoE support. |

[0001415889-16-004613:8k_2_02:21]
| ● | Shipped LiteBeam, an ultra-lightweight airMAX ac CPE device with incredible range and disruptive pricing. |

[0001415889-16-004613:8k_2_02:22]
| ● | Shipped UniFi Cloud Key, a hybrid cloud device manager that securely runs a local instance of the UniFi Controller software and features cloud Single Sign-On for remote access. |

[0001415889-16-004613:8k_2_02:23]
Financial Results Summary ($, in millions, except per share data)

[0001415889-16-004613:8k_2_02:24]
| Income statement highlights |  | F2Q16 |  | F1Q16 |  | F2Q15 |
| Revenues |  | 161.9 |  | 151.4 |  | 153.1 |
| Service Provider Technology |  | 109.6 |  | 103.4 |  | 99.7 |
| Enterprise Technology |  | 52.3 |  | 48.0 |  | 53.4 |
| Cost of Revenues |  | 82.8 |  | 77.9 |  | 84.1 |
| Gross Profit |  | 79.0 |  | 73.5 |  | 69.0 |
| Gross Profit (%) |  | 48.8% |  | 48.5% |  | 45.1% |
| Total Operating Expenses(1) |  | 22.6 |  | 13.7 |  | 18.3 |
| Income from Operations |  | 56.4 |  | 59.8 |  | 50.7 |
| GAAP Net Income |  | 49.5 |  | 53.8 |  | 46.3 |
| GAAP EPS (diluted) |  | 0.57 |  | 0.61 |  | 0.52 |
| Non-GAAP Net Income |  | 49.7 |  | 45.5 |  | 47.1 |
| Non-GAAP EPS (diluted) |  | 0.58 |  | 0.51 |  | 0.53 |

[0001415889-16-004613:8k_2_02:25]
| (1) | Includes business e-mail compromise (“BEC”) fraud loss recoveries of $8.0 million and $257 thousand in F1Q16 and F2Q16, respectively. |

[0001415889-16-004613:8k_2_02:26]
Balance Sheet Highlights

[0001415889-16-004613:8k_2_02:27]
Total cash and cash equivalents as of December 31, 2015 were $496.7 million, compared with $436.1 million as of September 30, 2015.  We held $476.9 million of our $496.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States.

[0001415889-16-004613:8k_2_02:28]
The sequential increase in cash and cash equivalents during the second quarter of fiscal 2016 is net of $36.7 million in share repurchases as part of our $100 million share repurchase program which has been extinguished, partially offset by draws of $33 million on our revolver.  Effective November 6, 2015, the Board of Directors of the Company approved a $50 million stock repurchase program.  The full $50 million common stock repurchase program was completed subsequent to the close of second quarter of fiscal 2016.

[0001415889-16-004613:8k_2_02:29]
This quarter we saw days sales outstanding in accounts receivable ("DSO") of 37 days, compared with 39 days in the prior quarter, and 44 days in the second quarter of fiscal 2015.

[0001415889-16-004613:8k_2_02:30]
Business Outlook

[0001415889-16-004613:8k_2_02:31]
Based on recent business trends, Ubiquiti currently believes the demand environment in its end markets supports the following forecast for the Company's third fiscal quarter ending March 31, 2016.  The following are Ubiquiti’s financial performance estimates for the third quarter of fiscal 2016:

[0001415889-16-004613:8k_2_02:32]
| ● | Revenues between $160 million and $170 million |

[0001415889-16-004613:8k_2_02:33]
| ● | GAAP diluted EPS of $0.52 - $0.59 |

[0001415889-16-004613:8k_2_02:34]
| ● | Non-GAAP diluted EPS of $0.53 - $0.60 |

[0001415889-16-004613:8k_2_02:35]
Conference Call Information

[0001415889-16-004613:8k_2_02:36]
Ubiquiti Networks will host a Q&A-only call to discuss the Company’s financial results at 2:00 p.m. Pacific Time today.  Management’s prepared remarks can be found on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com/results.cfm.

[0001415889-16-004613:8k_2_02:37]
To listen to the Q&A call via telephone, dial (877) 291-1296 (U.S. toll-free) or (720) 259-9209 (International) to be connected to the call by an operator.  Participants should dial in at least 10 minutes prior to the start of the call.  Investors may also listen to a live webcast of the Q&A conference call by visiting the Investor Relations section of the Ubiquiti Networks website at http://ir.ubnt.com.

[0001415889-16-004613:8k_2_02:38]
A recording of the Q&A call will be available approximately two hours after the call concludes and will be accessible on the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-004613:8k_2_02:39]
About Ubiquiti Networks

[0001415889-16-004613:8k_2_02:40]
Ubiquiti Networks (Nasdaq:UBNT) is closing the digital divide by building network communication platforms for everyone and everywhere. With over 34 million devices sold worldwide, Ubiquiti is transforming under-networked enterprises and communities. Our leading edge platforms, airMAX®, UniFi®, airFiber®, UniFi® Video, mFi® and EdgeMAX®, combine innovative technology, disruptive price-to-performance and the support of a global user community to eliminate barriers to connectivity. For more information, join our community at http://www.ubnt.com.

[0001415889-16-004613:8k_2_02:41]
Ubiquiti, Ubiquiti Networks, the U logo, UBNT, airMAX, UniFi, airFiber, mFi, EdgeMAX and sunMAX are registered trademarks or trademarks of Ubiquiti Networks, Inc. in the United States and other countries.

[0001415889-16-004613:8k_2_02:42]
The Ubiquiti Networks, Inc. logo is available at http://www.globenewswire.com/newsroom/prs/?pkgid=24865

[0001415889-16-004613:8k_2_02:43]
Investor Relations Contact

[0001415889-16-004613:8k_2_02:44]
Anne Fazioli

[0001415889-16-004613:8k_2_02:45]
Ubiquiti Networks, Vice President of Investor Relations

[0001415889-16-004613:8k_2_02:46]
IR@ubnt.com

[0001415889-16-004613:8k_2_02:47]
Forward-looking statements are subject to certain risks and uncertainties that could cause our actual future results to differ materially, or cause a material adverse impact on our results.  Potential risks and uncertainties include, but are not limited to, fluctuations in our operating results; varying demand for our products due to the financial and operating condition of our distributors and their customers, and distributors' inventory management practices; political and economic conditions and volatility affecting the stability of business environments, economic growth, currency values, commodity prices and other factors that may influence the ultimate demand for our products in particular geographies or globally; impact of counterfeiting and our ability to contain such impact; our reliance on a limited number of distributors; inability of our contract manufacturers and suppliers to meet our demand; our dependence on Qualcomm Atheros for chipsets without a short-term alternative; as we move into new markets competition from certain of our current or potential competitors who may be more established in such markets; our ability to keep pace with technological and market developments; success and timing of new product introductions by us and the performance of our products generally; our ability to effectively manage the significant increase in our transactional sales volumes; we may become subject to warranty claims, product liability and product recalls; that a substantial majority of our sales are into countries outside the United States and we are subject to numerous U.S. export control and economic sanctions laws; costs related to responding to government inquiries related to regulatory compliance; our reliance on the Ubiquiti Community; our reliance on certain key members of our management team, including our founder and chief executive officer, Robert J. Pera; adverse tax-related matters such as tax audits, changes in our effective tax rate or new tax legislative proposals; whether the final determination of our income tax liability may be materially different from our income tax provisions; the impact of any intellectual property litigation and claims for indemnification; litigation related to U.S. Securities laws; and economic and political conditions in the United States and abroad.  We discuss these risks in greater detail under the heading “Risk Factors” and elsewhere in our Annual Report on Form 10-K for the year ended June 30, 2015, and subsequent filings filed with the U.S. Securities and Exchange Commission (the SEC), which are available at the SEC's website at www.sec.gov.  Copies may also be obtained by contacting the Ubiquiti Networks Investor Relations Department, by email at IR@ubnt.com or by visiting the Investor Relations section of the Ubiquiti Networks website, http://ir.ubnt.com.

[0001415889-16-004613:8k_2_02:48]
Given these uncertainties, you should not place undue reliance on these forward-looking statements.  Also, forward-looking statements represent our management's beliefs and assumptions only as of the date made.  Except as required by law, Ubiquiti Networks undertakes no obligation to update information contained herein.  You should review our SEC filings carefully and with the understanding that our actual future results may be materially different from what we expect.

[0001415889-16-004613:8k_2_02:49]
Use of Non-GAAP Financial Information

[0001415889-16-004613:8k_2_02:50]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are adjusted to exclude certain costs, expenses and gains such as stock based compensation expense, Business e-mail compromise ("BEC") fraud loss/(recovery), implementation of overhead capitalization, reserve against vendor deposits relating to a purchase commitment termination fee and the tax effects of these non-GAAP adjustments.  Reconciliations of the adjustments to GAAP results for the three and six months ended December 31, 2015 and 2014 are provided below.  In addition, an explanation of the ways in which management uses non-GAAP financial information to evaluate its business, the substance behind management's decision to use this non-GAAP financial information, material limitations associated with the use of non-GAAP financial information, the manner in which management compensates for those limitations, and the substantive reasons management believes that this non-GAAP financial information provides useful information to investors is included under "About our Non-GAAP Net Income and Adjustments" after the tables below.

[0001415889-16-004613:8k_2_02:51]
Ubiquiti Networks Inc.

[0001415889-16-004613:8k_2_02:52]
Condensed Consolidated Statement of Operations

[0001415889-16-004613:8k_2_02:53]
(In thousands, except per share data)

[0001415889-16-004613:8k_2_02:54]
(Unaudited)

[0001415889-16-004613:8k_2_02:55]
|  |  | Three Months Ended December 31, |  |  | Six Months Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenues |  | $ | 161,871 |  |  | $ | 153,137 |  |  | $ | 313,286 |  |  | $ | 303,224 |  |
| Cost of revenues |  |  | 82,830 |  |  |  | 84,116 |  |  |  | 160,741 |  |  |  | 173,152 |  |
| Gross profit |  |  | 79,041 |  |  |  | 69,021 |  |  |  | 152,545 |  |  |  | 130,072 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 15,429 |  |  |  | 12,936 |  |  |  | 28,990 |  |  |  | 24,657 |  |
| Sales, general and administrative |  |  | 7,433 |  |  |  | 5,362 |  |  |  | 15,575 |  |  |  | 11,058 |  |
| Business e-mail compromise ("BEC") fraud loss/(recovery) |  |  | (257 | ) |  |  | — |  |  |  | (8,291 | ) |  |  | — |  |
| Total operating expenses |  |  | 22,605 |  |  |  | 18,298 |  |  |  | 36,274 |  |  |  | 35,715 |  |
| Income from operations |  |  | 56,436 |  |  |  | 50,723 |  |  |  | 116,271 |  |  |  | 94,357 |  |
| Interest expense and other, net |  |  | (651 | ) |  |  | 17 |  |  |  | (767 | ) |  |  | (41 | ) |
| Income before provision for income taxes |  |  | 55,785 |  |  |  | 50,740 |  |  |  | 115,504 |  |  |  | 94,316 |  |
| Provision for income taxes |  |  | 6,333 |  |  |  | 4,475 |  |  |  | 12,293 |  |  |  | 10,308 |  |
| Net income |  | $ | 49,452 |  |  | $ | 46,265 |  |  | $ | 103,211 |  |  | $ | 84,008 |  |
| Net income per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.58 |  |  | $ | 0.52 |  |  | $ | 1.20 |  |  | $ | 0.95 |  |
| Diluted |  | $ | 0.57 |  |  | $ | 0.52 |  |  | $ | 1.18 |  |  | $ | 0.94 |  |
| Weighted average shares used in computing net income per share of common stock: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 84,724 |  |  |  | 88,196 |  |  |  | 85,893 |  |  |  | 88,218 |  |
| Diluted |  |  | 86,091 |  |  |  | 89,737 |  |  |  | 87,285 |  |  |  | 89,838 |  |

[0001415889-16-004613:8k_2_02:56]
| Ubiquiti Networks Inc. |  |
| Reconciliation of GAAP Net Income to Non-GAAP Net Income |  |
| (In thousands, except per share data) |  |
| (Unaudited) |  |
|  |  | Three Months Ended December 31, |  |  | Six Months Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 49,452 |  |  | $ | 46,265 |  |  | $ | 103,211 |  |  | $ | 84,008 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  | 114 |  |  |  | 150 |  |  |  | 227 |  |  |  | 299 |  |
| Research and development |  |  | 580 |  |  |  | 864 |  |  |  | 1,204 |  |  |  | 1,689 |  |
| Sales, general and administrative |  |  | 263 |  |  |  | 417 |  |  |  | 553 |  |  |  | 815 |  |
| Purchase commitment termination fee |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5,500 |  |
| Business e-mail compromise ("BEC") fraud loss/(recovery) |  |  | (257 | ) |  |  | — |  |  |  | (8,291 | ) |  |  | — |  |
| Implementation of overhead capitalization |  |  | (50 | ) |  |  | — |  |  |  | (994 | ) |  |  | — |  |
| Tax effect of non-GAAP adjustments |  |  | (377 | ) |  |  | (572 | ) |  |  | (674 | ) |  |  | (1,781 | ) |
| Total Non-GAAP adjustments |  | $ | 273 |  |  | $ | 859 |  |  | $ | (7,975 | ) |  | $ | 6,522 |  |
| Non-GAAP net income |  | $ | 49,725 |  |  | $ | 47,124 |  |  | $ | 95,236 |  |  | $ | 90,530 |  |
| Non-GAAP diluted EPS |  | $ | 0.58 |  |  | $ | 0.53 |  |  | $ | 1.09 |  |  | $ | 1.01 |  |
| Weighted-average shares used in non-GAAP diluted EPS |  |  | 86,091 |  |  |  | 89,737 |  |  |  | 87,285 |  |  |  | 89,838 |  |

[0001415889-16-004613:8k_2_02:57]
| Ubiquiti Networks Inc. Condensed Consolidated Balance Sheets (In thousands, except share amounts) (Unaudited) |
|  |  | December 31, 2015 |  |  | June 30, 2015(1) |  |
| Assets |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 496,672 |  |  | $ | 446,401 |  |
| Accounts receivable, net |  | 64,568 |  |  | 66,104 |  |
| Inventories |  | 33,105 |  |  | 37,031 |  |
| Vendor deposits |  | 15,620 |  |  | 19,998 |  |
| Current deferred tax asset |  | 1,535 |  |  | 1,535 |  |
| Prepaid income taxes |  | — |  |  | 2,566 |  |
| Prepaid expenses and other current assets |  | 8,440 |  |  | 7,711 |  |
| Total current assets |  | 619,940 |  |  | 581,346 |  |
| Property and equipment, net |  | 13,359 |  |  | 15,602 |  |
| Long-term deferred tax asset |  | 1,538 |  |  | 1,515 |  |
| Other long–term assets |  | 1,918 |  |  | 2,109 |  |
| Total assets |  | $ | 636,755 |  |  | $ | 600,572 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 42,600 |  |  | $ | 43,856 |  |
| Income taxes payable |  |  | 1,739 |  |  |  | 1,108 |  |
| Debt - short-term |  |  | 10,000 |  |  |  | 10,000 |  |
| Other current liabilities |  | 16,217 |  |  | 15,170 |  |
| Total current liabilities |  | 70,556 |  |  | 70,134 |  |
| Long-term taxes payable |  | 22,129 |  |  | 19,810 |  |
| Debt - long-term |  | 115,500 |  |  | 87,500 |  |
| Deferred revenues - long-term |  | 1,003 |  |  | 974 |  |
| Total liabilities |  | 209,188 |  |  | 178,418 |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Common stock |  | 85 |  |  | 87 |  |
| Additional paid–in capital |  | — |  |  | — |  |
| Treasury stock |  | — |  |  | — |  |
| Retained earnings |  | 427,482 |  |  | 422,067 |  |
| Total stockholders’ equity |  | 427,567 |  |  | 422,154 |  |
| Total liabilities and stockholders’ equity |  | $ | 636,755 |  |  | $ | 600,572 |  |

[0001415889-16-004613:8k_2_02:58]
| (1) | Derived from audited consolidated statements as of and for the year ended June 30, 2015. |

[0001415889-16-004613:8k_2_02:59]
| Ubiquiti Networks Inc. |  |  |  |
| Revenue by Product Category |  |  |  |
| (In thousands) |  |  |  |

[0001415889-16-004613:8k_2_02:60]
(Unaudited)

[0001415889-16-004613:8k_2_02:61]
|  |  | Three Months Ended December 31, |  |  | Six Months Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Service Provider Technology |  | $ | 109,616 |  |  | $ | 99,720 |  |  | $ | 213,015 |  |  | $ | 206,991 |  |
| Enterprise Technology |  |  | 52,255 |  |  |  | 53,417 |  |  |  | 100,271 |  |  |  | 96,233 |  |
| Total revenues |  | $ | 161,871 |  |  | $ | 153,137 |  |  | $ | 313,286 |  |  | $ | 303,224 |  |

[0001415889-16-004613:8k_2_02:62]
| Ubiquiti Networks Inc. |  |  |  |  |  |  |  |
| Revenue by Geographical Area |  |  |  |  |  |  |  |
| (In thousands) |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |

[0001415889-16-004613:8k_2_02:63]
|  |  | Three Months Ended December 31, |  |  | Six Months Ended December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| North America |  | $ | 57,133 |  |  | $ | 54,127 |  |  | $ | 110,367 |  |  | $ | 107,708 |  |
| South America |  |  | 23,795 |  |  |  | 22,241 |  |  |  | 45,943 |  |  |  | 53,376 |  |
| Europe, the Middle East and Africa |  |  | 60,973 |  |  |  | 60,097 |  |  |  | 121,476 |  |  |  | 110,704 |  |
| Asia Pacific |  |  | 19,970 |  |  |  | 16,672 |  |  |  | 35,500 |  |  |  | 31,436 |  |
| Total revenues |  | $ | 161,871 |  |  | $ | 153,137 |  |  | $ | 313,286 |  |  | $ | 303,224 |  |

[0001415889-16-004613:8k_2_02:64]
About our Non-GAAP Net Income and Adjustments

[0001415889-16-004613:8k_2_02:65]
Use of Non-GAAP Financial Information

[0001415889-16-004613:8k_2_02:66]
To supplement our condensed consolidated financial results prepared under generally accepted accounting principles, or GAAP, we use non-GAAP measures of net income and earnings per diluted share that are GAAP net income and GAAP earnings per diluted share adjusted to exclude certain costs, expenses and gains/losses.

[0001415889-16-004613:8k_2_02:67]
We believe that the presentation of non-GAAP net income and non-GAAP earnings per diluted share provides important supplemental information regarding non-cash expenses, significant items that we believe are important to understanding our financial, and business trends relating to our financial condition and results of operations.  Non-GAAP net income and non-GAAP earnings per diluted share are among the primary indicators used by management as a basis for planning and forecasting future periods and by management and our board of directors to determine whether our operating performance has met specified targets and thresholds.  Management uses non-GAAP net income and non-GAAP earnings per diluted share when evaluating operating performance because it believes that the exclusion of the items described below, for which the amounts or timing may vary significantly depending upon the Company's activities and other factors, facilitates comparability of the Company's operating performance from period to period.  We have chosen to provide this information to investors so they can analyze our operating results in the same way that management does and use this information in their assessment of our business and the valuation of our Company.

[0001415889-16-004613:8k_2_02:68]
Use and Economic Substance of Non-GAAP Financial Measures used by Ubiquiti Networks

[0001415889-16-004613:8k_2_02:69]
We compute non-GAAP net income and non-GAAP earnings per diluted share by adjusting GAAP net income and GAAP earnings per diluted share to remove the impact of certain adjustments and the tax effect of those adjustments.  Items excluded from net income are:

[0001415889-16-004613:8k_2_02:70]
| ● | Stock-based compensation expense |

[0001415889-16-004613:8k_2_02:71]
| ● | Business e-mail compromise ("BEC") fraud loss/(recovery) |

[0001415889-16-004613:8k_2_02:72]
| ● | Implementation of overhead capitalization |

[0001415889-16-004613:8k_2_02:73]
| ● | Reserve against vendor deposits relating to a purchase commitment termination fee |

[0001415889-16-004613:8k_2_02:74]
| ● | Tax effect of non-GAAP adjustments, applying the principles of ASC 740 |

[0001415889-16-004613:8k_2_02:75]
Usefulness of Non-GAAP Financial Information to Investors

[0001415889-16-004613:8k_2_02:76]
These non-GAAP measures are not in accordance with, or an alternative to, GAAP and may be materially different from other non-GAAP measures, including similarly titled non-GAAP measures used by other companies.  The presentation of this additional information should not be considered in isolation from, as a substitute for, or superior to, net income or earnings per diluted share prepared in accordance with GAAP.  Non-GAAP financial measures have limitations in that they do not reflect certain items that may have a material impact upon our reported financial results.

[0001415889-16-004613:8k_2_02:77]
For more information on the non-GAAP adjustments, please see the table captioned “Reconciliation of GAAP Net Income to Non-GAAP Net Income” included in this press release.
