# UI MD&A — 0001511737-16-000032


## mdna

[0001511737-16-000032:mdna:1]
[same as prior period, unchanged from 0001511737-15-000029:mdna:1]

[0001511737-16-000032:mdna:2]
[same as prior period, unchanged from 0001511737-15-000029:mdna:2]

[0001511737-16-000032:mdna:3]
[same as prior period, unchanged from 0001511737-15-000029:mdna:3]

[0001511737-16-000032:mdna:4]
[same as prior period, unchanged from 0001511737-15-000029:mdna:4]

[0001511737-16-000032:mdna:5]
[same as prior period, unchanged from 0001511737-15-000029:mdna:5]

[0001511737-16-000032:mdna:6]
| • | Rapid customer and community driven product development. We have an active, loyal community built by our customers that we believe is a sustainable competitive advantage. Our solutions benefit from the active engagement between the Ubiquiti Community and our development engineers throughout the product development cycle, which eliminates long and expensive multistep internal processes and results in rapid introduction and adoption of our products. This approach significantly reduces our development costs and time to market. |

[0001511737-16-000032:mdna:7]
| • | Scalable sales and marketing model. We do not currently have, nor do we plan to hire, a direct sales force, but instead utilize the Ubiquiti Community to drive market awareness and demand for our products and solutions. This community-propagated, viral marketing enables us to reach underserved and underpenetrated markets far more efficiently and cost-effectively than is possible through traditional sales models. Leveraging the information transparency of the Internet allows customers to research, evaluate and validate our solutions with the Ubiquiti Community and via third-party web sites. This allows us to operate a scalable sales and marketing model and effectively create awareness for our brand and products. Word-of-mouth referrals from the Ubiquiti Community generate high quality leads for our distributors at relatively little cost. |

[0001511737-16-000032:mdna:8]
[same as prior period, unchanged from 0001511737-15-000029:mdna:8]

[0001511737-16-000032:mdna:9]
[same as prior period, unchanged from 0001511737-15-000029:mdna:9]

[0001511737-16-000032:mdna:10]
17

[0001511737-16-000032:mdna:11]
[same as prior period, unchanged from 0001511737-15-000029:mdna:10]

[0001511737-16-000032:mdna:12]
[same as prior period, unchanged from 0001511737-15-000029:mdna:11]

[0001511737-16-000032:mdna:13]
[same as prior period, unchanged from 0001511737-15-000029:mdna:12]

[0001511737-16-000032:mdna:14]
We classify our revenues into two primary product categories: Service Provider Technology and Enterprise Technology.

[0001511737-16-000032:mdna:15]
| • | Service Provider Technology includes our airMAX, EdgeMAX and airFiber platforms, as well as embedded radio products and other 802.11 standard products including base stations, radios, backhaul equipment and CPE. Additionally, Service Provider Technology includes antennas and other products in the 0.9 to 6.0 GHz spectrum and miscellaneous products such as mounting brackets, cables and power over Ethernet adapters. Service Provider Technology also includes solar products (sales of which have not been material to date) and revenues that are attributable to PCS. |

[0001511737-16-000032:mdna:16]
| • | Enterprise Technology includes our UniFi and mFi platforms, including UAP products, UniFi Video Products, UniFi VOIP phones and UniFi switch products. Enterprise Technology also includes revenues that are attributable to PCS. |

[0001511737-16-000032:mdna:17]
We sell substantially all of our products through a limited number of distributors and other channel partners, such as resellers and Original Equipment Manufacturers (“OEMs”). Sales to distributors accounted for 98% of our revenues in the three and six months ended December 31, 2015.

[0001511737-16-000032:mdna:18]
[same as prior period, unchanged from 0001511737-15-000029:mdna:17]

[0001511737-16-000032:mdna:19]
[same as prior period, unchanged from 0001511737-15-000029:mdna:18]

[0001511737-16-000032:mdna:20]
[same as prior period, unchanged from 0001511737-15-000029:mdna:19]

[0001511737-16-000032:mdna:21]
[same as prior period, unchanged from 0001511737-15-000029:mdna:20]

[0001511737-16-000032:mdna:22]
Our gross profit has been, and may, in the future, be influenced by several factors, including changes in product mix, target end markets for our products, pricing due to competitive pressure, production costs and global demand for electronic components. Although we procure and sell our products in U.S. dollars, our contract manufacturers incur many costs, including labor costs, in other currencies. To the extent that the exchange rates move unfavorably for our contract manufacturers, they may try to pass these additional costs to us, which could have a material impact on our future average selling prices and unit costs.

[0001511737-16-000032:mdna:23]
[same as prior period, unchanged from 0001511737-15-000029:mdna:22]

[0001511737-16-000032:mdna:24]
[same as prior period, unchanged from 0001511737-15-000029:mdna:23]

[0001511737-16-000032:mdna:25]
| • | Research and development expenses consist primarily of salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in research, design and development activities, as well as costs for prototypes, purchased Intellectual Property (“IP”), facilities and travel. Over time, we expect our research and development costs to increase as we continue making significant investments in developing new products and developing new versions of our existing products. |

[0001511737-16-000032:mdna:26]
| • | Sales, general and administrative expenses include salary and benefit expenses, including stock-based compensation, for employees and costs for contractors engaged in sales, marketing and general and administrative activities, as well as the costs of legal expenses, trade shows, marketing programs, promotional materials, bad debt expense, professional services, facilities, general liability insurance and travel. As our product portfolio and targeted markets expand, we may need to employ different sales models, such as building a direct sales force. These sales models would likely increase our costs. Over time, we expect our sales, general and administrative expenses to increase in absolute dollars due to |

[0001511737-16-000032:mdna:27]
18

[0001511737-16-000032:mdna:28]
continued growth in headcount, expansion of our efforts to register and defend trademarks and patents and to support our business and operations.

[0001511737-16-000032:mdna:29]
[same as prior period, unchanged from 0001511737-15-000029:mdna:27]

[0001511737-16-000032:mdna:30]
[same as prior period, unchanged from 0001511737-15-000029:mdna:28]

[0001511737-16-000032:mdna:31]
Included in our deferred revenues is a portion related to PCS obligations that we estimate we will fulfill in the future. As of December 31, 2015 and June 30, 2015, we had deferred revenues of $3.6 million and $3.5 million, respectively, related to these obligations.

[0001511737-16-000032:mdna:32]
[same as prior period, unchanged from 0001511737-15-000029:mdna:30]

[0001511737-16-000032:mdna:33]
[same as prior period, unchanged from 0001511737-15-000029:mdna:31]

[0001511737-16-000032:mdna:34]
[same as prior period, unchanged from 0001511737-15-000029:mdna:32]

[0001511737-16-000032:mdna:35]
Comparison of Three and Six Months Ended December 31, 2015 and 2014

[0001511737-16-000032:mdna:36]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In thousands, except percentages) |
| Revenues | $ | 161,871 |  |  | 100 | % |  | $ | 153,137 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |
| Cost of revenues (1)(2)(3) | 82,830 |  |  | 51 | % |  | 84,116 |  |  | 55 | % |  | 160,741 |  |  | 51 | % |  | 173,152 |  |  | 57 | % |
| Gross profit | 79,041 |  |  | 49 | % |  | 69,021 |  |  | 45 | % |  | 152,545 |  |  | 49 | % |  | 130,072 |  |  | 43 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development (1) | 15,429 |  |  | 10 | % |  | 12,936 |  |  | 8 | % |  | 28,990 |  |  | 9 | % |  | 24,657 |  |  | 8 | % |
| Sales, general and administrative (1) | 7,433 |  |  | 5 | % |  | 5,362 |  |  | 4 | % |  | 15,575 |  |  | 5 | % |  | 11,058 |  |  | 4 | % |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | (257 | ) |  | * |  |  | — |  |  | * |  |  | (8,291 | ) |  | (3 | )% |  | — |  |  | * |  |
| Total operating expenses | 22,605 |  |  | 14 | % |  | 18,298 |  |  | 12 | % |  | 36,274 |  |  | 12 | % |  | 35,715 |  |  | 12 | % |
| Income from operations | 56,436 |  |  | 35 | % |  | 50,723 |  |  | 33 | % |  | 116,271 |  |  | 37 | % |  | 94,357 |  |  | 31 | % |
| Interest expense and other, net | (651 | ) |  | * |  |  | 17 |  |  | * |  |  | (767 | ) |  | * |  |  | (41 | ) |  | * |  |
| Income before provision for income taxes | 55,785 |  |  | 34 | % |  | 50,740 |  |  | 33 | % |  | 115,504 |  |  | 37 | % |  | 94,316 |  |  | 31 | % |
| Provision for income taxes | 6,333 |  |  | 4 | % |  | 4,475 |  |  | 3 | % |  | 12,293 |  |  | 4 | % |  | 10,308 |  |  | 3 | % |
| Net income and comprehensive income | $ | 49,452 |  |  | 31 | % |  | $ | 46,265 |  |  | 30 | % |  | $ | 103,211 |  |  | 33 | % |  | $ | 84,008 |  |  | 28 | % |
| * Less than 1% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues | $ | 114 |  |  |  |  | $ | 150 |  |  |  |  | $ | 227 |  |  |  |  | $ | 299 |  |  |  |
| Research and development | 580 |  |  |  |  | 864 |  |  |  |  | 1,204 |  |  |  |  | 1,689 |  |  |  |
| Sales, general and administrative | 263 |  |  |  |  | 417 |  |  |  |  | 553 |  |  |  |  | 815 |  |  |  |
| Total stock-based compensation | $ | 957 |  |  |  |  | $ | 1,431 |  |  |  |  | $ | 1,984 |  |  |  |  | $ | 2,803 |  |  |  |
| (2) Includes purchase commitment termination fee | $ | — |  |  |  |  | $ | — |  |  |  |  | $ | — |  |  |  |  | $ | 5,500 |  |  |  |
| (3) Includes benefit of implementing overhead capitalization | $ | (50 | ) |  |  |  | $ | — |  |  |  |  | $ | (994 | ) |  |  |  | $ | — |  |  |  |

[0001511737-16-000032:mdna:37]
[same as prior period, unchanged from 0001511737-15-000029:mdna:35]

[0001511737-16-000032:mdna:38]
Total revenues increased 8.8 million, or 6%, from $153.1 million in the three months ended December 31, 2014 to $161.9 million in the three months ended December 31, 2015.   Revenues increased $10.1 million, or 3% from $303.2 million in the six months ended December 31, 2014 to $313.3 million in the six months ended December 31, 2015.  The drivers of both increases are discussed in further detail below. During the three and six months ended December 31, 2015, there were no material price changes in the Company's products sold.  During these periods there were changes in product mix, including a higher mix of Service Provider Technology products sold during the three months ended December 31, 2015 as compared to the three months ended December 31, 2014 and a slightly higher mix of Enterprise Technology products sold during the six months ended December 31, 2015 as compared to the six months ended December 31, 2014.

[0001511737-16-000032:mdna:39]
[same as prior period, unchanged from 0001511737-15-000029:mdna:37]

[0001511737-16-000032:mdna:40]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (in thousands, except percentages) |
| Service Provider Technology | $ | 109,616 |  |  | 68 | % |  | $ | 99,720 |  |  | 65 | % |  | $ | 213,015 |  |  | 68 | % |  | $ | 206,991 |  |  | 68 | % |
| Enterprise Technology | 52,255 |  |  | 32 | % |  | 53,417 |  |  | 35 | % |  | 100,271 |  |  | 32 | % |  | 96,233 |  |  | 32 | % |
| Total revenues | $ | 161,871 |  |  | 100 | % |  | $ | 153,137 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |

[0001511737-16-000032:mdna:41]
20

[0001511737-16-000032:mdna:42]
Service Provider Technology revenue increased $9.9 million, or 10%, from $99.7 million in the three months ended December 31, 2014 to $109.6 million in the three months ended December 31, 2015.  Revenues increased $6.0 million, or 3%, from $207.0 million in the six months ended December 31, 2014 to $213.0 million in the six months ended December 31, 2015.  The increase in Service Provider Technology revenue during the three months ended December 31, 2015 as compared to the same period in the prior year was primarily due to increased revenues for Service Provider Technology products outside of North America.  The increase in Service Provider Technology revenue during the six months ended December 31, 2015 as compared to the same period in the prior year was primarily due to increased revenues for Service Provider Technology products outside of South America.

[0001511737-16-000032:mdna:43]
Enterprise Technology revenue decreased $1.1 million, or 2%, from $53.4 million in the three months ended December 31, 2014 to $52.3 million in the three months ended December 31, 2015.  Revenues increased $4.1 million, or 4%, from $96.2 million in the six months ended December 31, 2014 to $100.3 million in the six months ended December 31, 2015. The decrease in Enterprise Technology revenue during the three months ended December 31, 2015 as compared to the same period in the prior year was primarily due to decreased revenues in EMEA and South America, partially offset by increased revenues in North America.  The increase in Enterprise Technology revenue during the six months ended December 31, 2015 as compared to the same period in the prior year was primarily due to increased revenues in EMEA, partially offset by decreased revenues South America.

[0001511737-16-000032:mdna:44]
[same as prior period, unchanged from 0001511737-15-000029:mdna:42]

[0001511737-16-000032:mdna:45]
We have determined the geographical distribution of our product revenues based on our customers’ ship-to destinations. A majority of our sales are to distributors who either sell to resellers or directly to end customers, who may be located in different countries than the initial ship-to destination.  The following are our revenues by geography for the three and six months ended December 31, 2015 and 2014 (in thousands, except percentages):

[0001511737-16-000032:mdna:46]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| North America (1) | $ | 57,133 |  |  | 35 | % |  | $ | 54,127 |  |  | 35 | % |  | $ | 110,367 |  |  | 35 | % |  | $ | 107,708 |  |  | 36 | % |
| South America | 23,795 |  |  | 15 | % |  | 22,241 |  |  | 15 | % |  | 45,943 |  |  | 15 | % |  | 53,376 |  |  | 18 | % |
| Europe, the Middle East and Africa | 60,973 |  |  | 38 | % |  | 60,097 |  |  | 39 | % |  | 121,476 |  |  | 39 | % |  | 110,704 |  |  | 36 | % |
| Asia Pacific | 19,970 |  |  | 12 | % |  | 16,672 |  |  | 11 | % |  | 35,500 |  |  | 11 | % |  | 31,436 |  |  | 10 | % |
| Total revenues | $ | 161,871 |  |  | 100 | % |  | $ | 153,137 |  |  | 100 | % |  | $ | 313,286 |  |  | 100 | % |  | $ | 303,224 |  |  | 100 | % |

[0001511737-16-000032:mdna:47]
| (1) | Revenue for the United States was $53.6 million and $50.5 million for the three months ended December 31, 2015 and 2014, respectively. Revenue for the United States was $104.2 million and $102.2 million for the six months ended December 31, 2015 and 2014, respectively. |

[0001511737-16-000032:mdna:48]
[same as prior period, unchanged from 0001511737-15-000029:mdna:46]

[0001511737-16-000032:mdna:49]
Revenues in North America increased $3.0 million, or 6%, from $54.1 million in the three months ended December 31, 2014 to $57.1 million in the three months ended December 31, 2015.  Revenues increased $2.7 million, or 3%, from $107.7 million in the six months ended December 31, 2014 to $110.4 million in the six months ended December 31, 2015.  The increase in North American revenues during the three months ended December 31, 2015 as compared to the same period in the prior year was primarily due to increased Enterprise Technology revenue.  The increase during the six months ended December 31, 2015 as compared to the same period in the prior year was primarily due to increased Service Provider Technology revenue.

[0001511737-16-000032:mdna:50]
[same as prior period, unchanged from 0001511737-15-000029:mdna:48]

[0001511737-16-000032:mdna:51]
Revenues in South America increased $1.6 million, or 7%, from $22.2 million in the three months ended December 31, 2014 to $23.8 million in the three months ended December 31, 2015.  Revenues decreased $7.5 million, or 14%, from $53.4 million in the six months ended December 31, 2014 to $45.9 million in the six months ended December 31, 2015.  The increase in South American revenues during the three months ended December 31, 2015 as compared to the same period in the prior year was primarily due to increased revenues from Service Provider Technology products.  The decrease in South American revenues during the six months ended December 31, 2015 as compared to the same period in the prior year was primarily due to decreased revenues from Service Provider Technology products.  We believe that the large fluctuations in South American revenues are largely driven by a strong U.S. dollar and by general economic instability in the region.

[0001511737-16-000032:mdna:52]
[same as prior period, unchanged from 0001511737-15-000029:mdna:50]

[0001511737-16-000032:mdna:53]
Revenues in EMEA increased $0.9 million, or 1%, from $60.1 million in the three months ended December 31, 2014 to $61.0 million in the three months ended December 31, 2015.  Revenues increased $10.8 million, or 10%, from $110.7 million in the six months ended December 31, 2014 to $121.5 million in the six months ended December 31, 2015. The increase in EMEA revenues during the three and six months ended December 31, 2015 as compared to the same periods in the prior year was primarily due to increased revenues from Service Provider Technology products.

[0001511737-16-000032:mdna:54]
[same as prior period, unchanged from 0001511737-15-000029:mdna:52]

[0001511737-16-000032:mdna:55]
Revenues in the Asia Pacific region increased $3.3 million, or 20%, from $16.7 million in the three months ended December 31, 2014 to $20.0 million in the three months ended December 31, 2015.  Revenues increased $4.1 million, or 13%, from $31.4 million in the six months ended December 31, 2014 to $35.5 million in the six months ended December 31, 2015.  The increase in Asia Pacific revenues during both the three and six months ended December 31, 2015 as compared to the same periods in the prior year was primarily due to increased Service Provider Technology revenue.

[0001511737-16-000032:mdna:56]
[same as prior period, unchanged from 0001511737-15-000029:mdna:54]

[0001511737-16-000032:mdna:57]
Cost of revenues decreased $1.3 million, or 2%, from $84.1 million in the three months ended December 31, 2014 to $82.8 million in the three months ended December 31, 2015.  This reduction primarily relates to changes in product mix and improved gross margins in the Service Provider Technology product category.

[0001511737-16-000032:mdna:58]
Cost of revenues decreased $12.5 million, or 7%, from $173.2 million in the six month period ended December 31, 2014 to $160.7 million in the six months ended December 31, 2015.  This reduction reflects a non-recurring termination fee of $5.5 million recognized in the prior six months ended December 31, 2014 related to the cancellation of a purchase commitment.  Additionally, as discussed further in Note 2, in the six months ended December 31, 2015, the Company began capitalizing manufacturing overhead related to inventory produced but not sold during the period.   Specifically, in the six months ended December 31, 2015, the impact of capitalization of manufacturing overhead was a net reduction of $994 thousand to cost of revenues.  The remaining decrease in costs of revenues is attributable to improved margins for both Service Provider and Enterprise Technologies.

[0001511737-16-000032:mdna:59]
Gross profit margin increased to 49% in the three months ended December 31, 2015 compared to 45% in the three months ended December 31, 2014, and increased to 49% in the six months ended December 31, 2015 compared to 43% in the six months ended December 31, 2014.  The increases for both periods are consistent with the cost of revenue fluctuations discussed above.

[0001511737-16-000032:mdna:60]
[same as prior period, unchanged from 0001511737-15-000029:mdna:57]

[0001511737-16-000032:mdna:61]
[same as prior period, unchanged from 0001511737-15-000029:mdna:58]

[0001511737-16-000032:mdna:62]
Research and development (“R&D”) expenses increased $2.5 million, or 19%, from $12.9 million in the three months ended December 31, 2014 to $15.4 million in the three months ended December 31, 2015. As a percentage of revenues, research and development expenses increased from 8% in the three months ended December 31, 2014 to 10% in the three months ended December 31, 2015.  This increase is due to a $2.5 million impairment charge for capitalized software development costs recorded in the three months ended December 31, 2015 related to the cancellation of the commercial launch of certain software in development.  Research and development costs increased $4.3 million, or 17%, from $24.7 million in the six months ended December 31, 2014 to $29.0 million in the six months ended December 31, 2015.  As a percentage of revenues, research and development expenses increased from 8% in the six months ended December 31, 2014 to 9% in the six months ended December 31, 2015.  This increase is driven by the $2.5 million impairment charge for capitalized software development costs recognized in the six months ended December 31, 2015, as discussed above. Additionally, this increase is driven by decreased levels of software capitalization in the six months ended December 31, 2015 as compared to the same period ended December 31, 2014. Over time, we expect our research and development costs to increase in absolute dollars as we continue making investments in developing new products and developing new versions of our existing products.

[0001511737-16-000032:mdna:63]
[same as prior period, unchanged from 0001511737-15-000029:mdna:60]

[0001511737-16-000032:mdna:64]
Sales, general and administrative expenses increased $2.0 million, or 37%, from $5.4 million in the three months ended December 31, 2014 to $7.4 million in the three months ended December 31, 2015.  As a percentage of revenues, sales, general and administrative expenses increased from 4% in the three months ended December 31, 2014 to 5% in the three months ended December 31, 2015.  Of the $2.0 million increase, $700 thousand is attributable to increased sales and marketing expenses incurred related to increased hiring of sales personnel.  The remaining $1.3 million increase is primarily attributable to general and administrative costs incurred for interim management and advisory services to remediate internal control weaknesses as disclosed in the Annual Report.

[0001511737-16-000032:mdna:65]
Sales, general and administrative expenses increased $4.5 million, or 41%, from $11.1 million in the six months ended December 31, 2014 to $15.6 million in the six months ended December 31, 2015. As a percentage of revenues, sales, general and administrative expenses increased from 4% in the six months ended December 31, 2014 to 5% in the six months ended December 31, 2015.  Of the $4.5 million increase, $700 thousand is attributable to sales and marking expenses and $3.8 million is attributable to general and administrative expenses. Both increases are consistent with the explanations discussed above.

[0001511737-16-000032:mdna:66]
[same as prior period, unchanged from 0001511737-15-000029:mdna:62]

[0001511737-16-000032:mdna:67]
Our provision for income taxes increased $1.9 million or 42%, from $4.5 million for the three months ended December 31, 2014 to $6.3 million for the three months ended December 31, 2015. Our effective tax rate increased to 11% for the three months ended December 31, 2015 as compared to 9% for the three months ended December 31, 2014.  The higher effective tax rate in the three months ended December 31, 2015 was primarily due to a reduced tax benefit from federal research credits as compared to the three months ended December 31, 2014, as well as a discrete one-time tax benefit recorded in a foreign jurisdiction in the three months ended December 31, 2014.  Our provision for income taxes increased $2.0 million, or 19%, from $10.3 million for the six months ended December 31, 2014 to $12.3 million for the six months ended December 31, 2015. Our effective tax rate remained flat at 11% for the six months ended December 31, 2014 and December 31, 2015.

[0001511737-16-000032:mdna:68]
[same as prior period, unchanged from 0001511737-15-000029:mdna:64]

[0001511737-16-000032:mdna:69]
[same as prior period, unchanged from 0001511737-15-000029:mdna:65]

[0001511737-16-000032:mdna:70]
Since inception, our operations primarily have been funded through cash generated by operations and proceeds from our various debt agreements. Cash and cash equivalents increased from $446.4 million at June 30, 2015 to $496.7 million at December 31, 2015.

[0001511737-16-000032:mdna:71]
[same as prior period, unchanged from 0001511737-15-000029:mdna:67]

[0001511737-16-000032:mdna:72]
[same as prior period, unchanged from 0001511737-15-000029:mdna:68]

[0001511737-16-000032:mdna:73]
|  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |
|  | (In thousands) |
| Net cash provided by operating activities | $ | 125,074 |  |  | $ | 79,618 |  |
| Net cash used in investing activities | (3,022 | ) |  | (8,391 | ) |
| Net cash used in financing activities | (71,781 | ) |  | (29,721 | ) |
| Net increase in cash and cash equivalents | $ | 50,271 |  |  | $ | 41,506 |  |

[0001511737-16-000032:mdna:74]
[same as prior period, unchanged from 0001511737-15-000029:mdna:70]

[0001511737-16-000032:mdna:75]
Net cash provided by operating activities in the six months ended December 31, 2015 of $125.1 million consisted primarily of net income of $103.2 million and net changes in operating assets and liabilities that resulted in net cash inflows of $13.8 million. These changes consisted primarily of a $4.4 million decrease in vendor deposits due to timing of deposit payments with our suppliers, a $0.8 million increase in prepaid expenses and other current assets, a $1.3 million decrease in accounts receivable due to increased collections during the period, a $0.7 million decrease in accounts payable and accrued liabilities, a $0.2 million increase in deferred revenue due to additional PCS revenue deferrals during the period, a $2.6 million decrease in prepaid taxes due to the timing of federal tax payments, a $3.4 million decrease in inventory due to increased sales during the period and a $3.4 million increase in taxes payable.  Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, increases to our provision for sales returns, increases in deferred taxes, and a write off of software development costs. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $8.1 million.

[0001511737-16-000032:mdna:76]
Net cash provided by operating activities in the six months ended December 31, 2014 of $79.6 million consisted primarily of net income of $84.0 million partially offset by net changes in operating assets and liabilities that resulted in net cash outflows of $9.1 million. These changes consisted primarily of a $20.9 million increase in accounts payable and accrued liabilities due primarily to our increase in cost of revenues, a $20.2 million increase in prepaid expenses and other current assets due to the timing of deposit payments with our suppliers, an $8.1 million increase in inventory due to our efforts to build warehouse stock levels and ultimately decrease lead times, a $1.4 million increase in taxes payable and a $1.3 million increase in prepaid taxes due to the timing of federal tax payments. Additionally, our net income included non-cash adjustments due to stock-based compensation, depreciation and amortization, increases to our provision for inventory obsolescence, decreases in our allowance

[0001511737-16-000032:mdna:77]
for doubtful accounts, a write-off of our intangible assets and taxes. The net of these non-cash adjustments resulted in an increase of our net cash provided by operating activities of $4.7 million.

[0001511737-16-000032:mdna:78]
[same as prior period, unchanged from 0001511737-15-000029:mdna:75]

[0001511737-16-000032:mdna:79]
We used $3.0 million of cash in investing activities during the six months ended December 31, 2015.  Our investing activities consist solely of capital expenditures and purchases of intangible assets. Capital expenditures for the six months ended December 31, 2015 and 2014 were $3.0 million and $8.4 million, respectively.  Capital expenditures during the six months ended December 31, 2015 included machinery and equipment purchases for our product development and prototyping activities. Additionally, we had cash outflows related to the purchase of intangible assets of $20 thousand and $30 thousand during the six months ended December 31, 2015 and 2014, respectively, consisting primarily of legal costs associated with trademark applications.

[0001511737-16-000032:mdna:80]
[same as prior period, unchanged from 0001511737-15-000029:mdna:77]

[0001511737-16-000032:mdna:81]
We used $71.8 million of cash in financing activities during the six months ended December 31, 2015.  During the six months ended December 31, 2015 we paid $100.0 million for repurchases of our common stock.  We also made a $5.0 million repayment on our outstanding debt under the term loan portion of our Amended Credit Agreement.  Additionally, we drew $33.0 million under the revolver of our Amended Credit Agreement that was used for the repurchases of our common stock.  Cash inflows from financing activities included $0.5 million of cash proceeds received from the exercise of stock options in addition to $0.4 million of excess tax benefit from employee stock-based awards, partially offset by tax withholdings related to net share settlements of restricted stock units of $0.7 million.

[0001511737-16-000032:mdna:82]
We had $29.7 million of cash used by financing activities during the six months ended December 31, 2014, which consisted of cash paid for dividends on our common stock of $15.0 million, cash paid for repurchases of our common stock of $15.0 million and tax withholdings related to net share settlements of restricted stock units of $1.0 million, partially offset by cash received for stock option exercises of $497 thousand and an excess tax benefit from employee stock-based awards of $787 thousand.

[0001511737-16-000032:mdna:83]
[same as prior period, unchanged from 0001511737-15-000029:mdna:80]

[0001511737-16-000032:mdna:84]
We believe our existing cash and cash equivalents, cash provided by operations and the availability of additional funds under our Amended Credit Agreement will be sufficient to meet our working capital and capital expenditure needs for at least the next twelve months. Our future capital requirements may vary materially from those currently planned and will depend on many factors, including our rate of revenue growth, the timing and extent of spending to support development efforts, the timing of new product introductions, market acceptance of our products and overall economic conditions. As of December 31, 2015, we held $476.9 million of our $496.7 million of cash and cash equivalents in accounts of our subsidiaries outside of the United States and we will incur significant tax liabilities if we decide to repatriate those amounts.

[0001511737-16-000032:mdna:85]
[same as prior period, unchanged from 0001511737-15-000029:mdna:82]

[0001511737-16-000032:mdna:86]
Our products are generally accompanied by a twelve month warranty from date of purchase, which covers both parts and labor. Generally the distributor is responsible for the freight costs associated with warranty returns, and we absorb the freight costs of replacing items under warranty. In accordance with the Financial Accounting Standards Board’s (“FASB’s”), Accounting Standards Codification (“ASC”), 450-20, Loss Contingencies, we record an accrual when we believe it is reasonably estimable and probable based upon historical experience. We record a provision for estimated future warranty work in cost of goods sold upon recognition of revenues, and we review the resulting accrual regularly and periodically adjust it to reflect changes in warranty estimates.

[0001511737-16-000032:mdna:87]
We may in the future enter into standard indemnification agreements with many of our distributors and OEMs, as well as certain other business partners in the ordinary course of business. These agreements may include provisions for indemnifying the distributor, OEM or other business partner against any claim brought by a third-party to the extent any such claim alleges that a Ubiquiti product infringes a patent, copyright or trademark or violates any other proprietary rights of that third-party. The maximum amount of potential future indemnification is unlimited. The maximum potential amount of future payments we could be required to make under these indemnification agreements is not estimable.

[0001511737-16-000032:mdna:88]
We have agreed to indemnify our directors, officers and certain other employees for certain events or occurrences, subject to certain limits, while such persons are or were serving at our request in such capacity. We may terminate the indemnification agreements with these persons upon the termination of their services with us, but termination will not affect claims for indemnification related to events occurring prior to the effective date of termination. The maximum amount of potential future indemnification is unlimited. We have a Directors and Officers insurance policy that limits our potential exposure. We believe

[0001511737-16-000032:mdna:89]
the fair value of these indemnification agreements is minimal.  We have not recorded any liabilities for these agreements as of December 31, 2015.

[0001511737-16-000032:mdna:90]
Based upon our historical experience and information known as of the date of this report, we do not believe it is likely that we have a significant liability for the above indemnities at December 31, 2015.

[0001511737-16-000032:mdna:91]
[same as prior period, unchanged from 0001511737-15-000029:mdna:88]

[0001511737-16-000032:mdna:92]
The following table summarizes our contractual obligations as of December 31, 2015 for the remainder of fiscal 2016 and future fiscal years (in thousands):

[0001511737-16-000032:mdna:93]
|  | 2016 (remainder) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases | $ | 2,297 |  |  | $ | 3,629 |  |  | $ | 2,082 |  |  | $ | 978 |  |  | $ | 668 |  |  | $ | 276 |  |  | $ | 9,930 |  |
| Debt payment obligations | 5,000 |  |  | 11,250 |  |  | 15,000 |  |  | 15,000 |  |  | 79,250 |  |  | — |  |  | 125,500 |  |
| Interest and other payments on debt | 1,439 |  |  | 2,718 |  |  | 2,442 |  |  | 2,127 |  |  | 1,313 |  |  | — |  |  | 10,039 |  |
| Purchase obligations | 21,646 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 21,646 |  |
| Other obligations | 6,157 |  |  | 32 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 6,192 |  |
| Total | $ | 36,539 |  |  | $ | 17,629 |  |  | $ | 19,527 |  |  | $ | 18,105 |  |  | $ | 81,231 |  |  | $ | 276 |  |  | $ | 173,307 |  |

[0001511737-16-000032:mdna:94]
[same as prior period, unchanged from 0001511737-15-000029:mdna:91]

[0001511737-16-000032:mdna:95]
[same as prior period, unchanged from 0001511737-15-000029:mdna:92]

[0001511737-16-000032:mdna:96]
Principal, Interest and Other Debt Payment Obligations

[0001511737-16-000032:mdna:97]
On March 3, 2015, we entered into the Amended Credit Agreement, that provides for a $200.0 million senior secured revolving credit facility and a $100.0 million senior secured term loan facility, with an option to request increases in the amounts of such credit facilities by up to an additional $50.0 million in the aggregate (any such increase to be in each lender’s sole discretion).  Please see Note 7 of the Notes to the Consolidated Financial Statements for more information. We have calculated estimated interest payments for our debt based on the applicable rates and payment dates. Although our interest rates on our debt obligations will likely vary over time, we have assumed our interest rates as of December 31, 2015 as the interest rates for all fiscal years presented.  Furthermore, the interest payment intervals on our revolving debt are determined at the Company's election pursuant to the Amended Credit Agreement.  For purposes of the table above, we have assumed two month payment intervals on our revolving debt consistent with our elections to date.  Also included are estimated bank fees to be paid for unused portions of our revolving credit facility.

[0001511737-16-000032:mdna:98]
[same as prior period, unchanged from 0001511737-15-000029:mdna:95]

[0001511737-16-000032:mdna:99]
We subcontract with third parties to manufacture our products. During the normal course of business, our contract manufacturers procure components and manufacture product based upon orders placed by us.  Component and product inventory held by our manufacturers or our third-party logistics providers is not recorded on our balance sheet until legal title passes to the Company.  If we cancel all or part of the orders, we may still be liable to the contract manufacturers for the cost of the components they purchased and for manufacturing and other costs related to these components.  We periodically review the potential liability and to date no significant liabilities for cancellations have been recorded. Our consolidated financial position and results of operations could be negatively impacted if we were required to compensate the contract manufacturers for any unrecorded liabilities incurred.  The Company had inventory purchase obligations of $21.6 million as of December 31, 2015.

[0001511737-16-000032:mdna:100]
[same as prior period, unchanged from 0001511737-15-000029:mdna:97]

[0001511737-16-000032:mdna:101]
We had other obligations of $6.2 million as of December 31, 2015, which consisted primarily of commitments related to research and development projects.

[0001511737-16-000032:mdna:102]
[same as prior period, unchanged from 0001511737-15-000029:mdna:99]

[0001511737-16-000032:mdna:103]
As of December 31, 2015, we had $21.9 million of unrecognized tax benefits, substantially all of which would, if recognized, affect our tax expense. We have elected to include interest and penalties related to uncertain tax positions as a component of tax expense. We do not expect any significant increases or decreases to our unrecognized tax benefits in the next twelve months.

[0001511737-16-000032:mdna:104]
[same as prior period, unchanged from 0001511737-15-000029:mdna:101]

[0001511737-16-000032:mdna:105]
[same as prior period, unchanged from 0001511737-15-000029:mdna:102]

[0001511737-16-000032:mdna:106]
[same as prior period, unchanged from 0001511737-15-000029:mdna:103]

[0001511737-16-000032:mdna:107]
[same as prior period, unchanged from 0001511737-15-000029:mdna:104]

[0001511737-16-000032:mdna:108]
Our Non-GAAP measures primarily exclude stock-based compensation, net of taxes, and other special charges and credits.  In fiscal 2016, our non-GAAP net income excluded a benefit of $8.3 million related to the BEC fraud loss, as described at Note 14 to the Condensed Consolidated Financial Statements.  We use each of these Non-GAAP financial measures for internal managerial purposes when providing our financial results and business outlook to the public. Management believes that these Non-GAAP measures provide meaningful supplemental information regarding our operational and financial performance of current and historical results, facilitating period-to-period comparisons.  Additionally, we believe these Non-GAAP financial measures provide meaningful information regarding our strategic and business decision making, internal budgeting, forecasting and resource allocation processes as well as supplement management’s internal comparisons to our historical operating results and to our competitors’ operating results.

[0001511737-16-000032:mdna:109]
[same as prior period, unchanged from 0001511737-15-000029:mdna:106]

[0001511737-16-000032:mdna:110]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In thousands, except per share amounts) |
| Non-GAAP net income and comprehensive income | $ | 49,725 |  |  | $ | 47,124 |  |  | $ | 95,236 |  |  | $ | 90,530 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.58 |  |  | $ | 0.53 |  |  | $ | 1.09 |  |  | $ | 1.01 |  |

[0001511737-16-000032:mdna:111]
[same as prior period, unchanged from 0001511737-15-000029:mdna:108]

[0001511737-16-000032:mdna:112]
[same as prior period, unchanged from 0001511737-15-000029:mdna:109]

[0001511737-16-000032:mdna:113]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (In thousands, except per share amounts) |
| Net income and comprehensive income | $ | 49,452 |  |  | $ | 46,265 |  |  | $ | 103,211 |  |  | $ | 84,008 |  |
| Stock-based compensation: |  |  |  |  |  |  |  |
| Cost of revenues | 114 |  |  | 150 |  |  | 227 |  |  | 299 |  |
| Research and development | 580 |  |  | 864 |  |  | 1,204 |  |  | 1,689 |  |
| Sales, general and administrative | 263 |  |  | 417 |  |  | 553 |  |  | 815 |  |
| Purchase commitment termination fee | — |  |  | — |  |  | — |  |  | 5,500 |  |
| Business e-mail compromise (“BEC”) fraud loss/(recovery) | (257 | ) |  | — |  |  | (8,291 | ) |  | — |  |
| Implementation of overhead capitalization (1) | (50 | ) |  | — |  |  | (994 | ) |  | — |  |
| Tax effect of non-GAAP adjustments | (377 | ) |  | (572 | ) |  | (674 | ) |  | (1,781 | ) |
| Non-GAAP net income and comprehensive income | $ | 49,725 |  |  | $ | 47,124 |  |  | $ | 95,236 |  |  | $ | 90,530 |  |
| Non-GAAP diluted net income per share of common stock | $ | 0.58 |  |  | $ | 0.53 |  |  | $ | 1.09 |  |  | $ | 1.01 |  |
| Weighted-average shares used in computing non-GAAP diluted net income per share of common stock | 86,091 |  |  | 89,737 |  |  | 87,285 |  |  | 89,838 |  |

[0001511737-16-000032:mdna:114]
(1) - Overhead capitalization was implemented in the first quarter of fiscal 2016.  As a result of implementing the policy, we recognized a one-time benefit in the first quarter of fiscal 2016.

[0001511737-16-000032:mdna:115]
[same as prior period, unchanged from 0001511737-15-000029:mdna:111]

[0001511737-16-000032:mdna:116]
When used in this Report, the words “anticipates,” “believes,” “could,” “seeks,” “estimates,” “expects,” “intends,” “may,” “plans” “potential,” “predicts,” “projects,” “should,” “will,” “would” or similar expressions and negatives of those terms are intended to identify forward-looking statements. These are statements that relate to future periods and include statements about our future results, sources of revenue, our continued growth, our gross margins, market trends, our product development, technological developments, the features, benefits and performance of our current and future products, the ability of our products to address a variety of markets, the anticipated growth of demand for connectivity worldwide, our growth strategies, future price reductions, our competitive status, our dependence on our senior management and our ability to attract and retain key personnel, dependency on and concentration of our distributors, our employee relations, current and potential litigation, the effects of government regulations, our compliance with laws and regulations, our expected future operating costs and expenses and expenditure levels for research and development, selling, general and administrative expenses, fluctuations in operating results, fluctuations in our stock price, our payment of dividends, our future liquidity and cash needs, our credit facility, future acquisitions of and investments in complimentary businesses and the expected impact of various accounting policies and rules adopted by the Financial Accounting Standards Board. Forward-looking statements are subject to risks and uncertainties that could cause actual results to differ materially from those projected. These risks and uncertainties include, but are not limited to, factors affecting our quarterly results, our ability to manage our growth, our ability to sustain or increase profitability, demand for our products, our ability to compete, our ability to rapidly develop new technology and introduce new products, our ability to safeguard our intellectual property, trends in the networking industry and fluctuations in general economic conditions, and the risks set forth throughout this Report, including under Item 1, “Business” and under Item 1A, “Risk Factors.” These forward-looking statements speak only as of the date hereof. Except as required by law, we expressly disclaim any obligation or undertaking to release publicly any updates or revisions to any forward-looking statements contained herein to reflect any change in our expectations with regard thereto or any change in events, conditions or circumstances on which any such statement is based.
