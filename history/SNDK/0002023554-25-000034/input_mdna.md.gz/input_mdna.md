# SNDK MD&A — 0002023554-25-000034


## mdna

[0002023554-25-000034:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0002023554-25-000034:mdna:2]
For management’s discussion of our combined results for the year ended June 28, 2024 in comparison with the year ended June 30, 2023, and other financial information related to fiscal year 2024, refer to Item 2., “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” included in our Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025 (as amended, the “Form 10”).

[0002023554-25-000034:mdna:3]
Unless otherwise indicated, references herein to specific years and quarters are to our fiscal years and fiscal quarters. As used herein, the terms “we,” “us,” “our,” and the “Company” refer to Sandisk Corporation and its subsidiaries.

[0002023554-25-000034:mdna:4]
Overview

[0002023554-25-000034:mdna:5]
The Separation

[0002023554-25-000034:mdna:6]
On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized management to pursue a plan to separate the Company into an independent public company. The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, we were wholly owned by WDC.

[0002023554-25-000034:mdna:7]
On February 21, 2025, WDC executed the spin-off of the Company through WDC’s pro rata distribution of 116,035,464 or 80.1% of the outstanding shares of common stock of the Company to holders of WDC’s common stock. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 28,827,787 or 19.9% of the outstanding shares of the Company’s common stock, which WDC was expected to retain for a period of up to twelve months following the distribution. Following the distribution, the Company became an independent publicly listed company, and on February 24, 2025, the Company began trading as an independent publicly traded company under the stock symbol “SNDK” on Nasdaq.

[0002023554-25-000034:mdna:8]
On June 6, 2025, WDC disposed of 21,314,768 or 14.6% of our common stock through an exchange of our common stock for WDC debt held by WDC creditors.

[0002023554-25-000034:mdna:9]
Our Business

[0002023554-25-000034:mdna:10]
Sandisk is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for artificial intelligence (“AI”) workloads in datacenters, edge devices, and consumers. Our technologies enable everyone from students, gamers and home offices to the largest enterprises and public clouds to produce, analyze, and store data. Our solutions include a broad range of solid-state drives (“SSDs”), embedded products, removable cards, universal serial bus drives and wafers and components. Our broad portfolio of technology and products addresses multiple end markets of “Cloud,” “Client,” and “Consumer.”

[0002023554-25-000034:mdna:11]
Through the Client end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalizes on the strength of our product brand recognition and vast presence around the world. Cloud is comprised primarily of products for datacenters, cloud service providers, and private cloud customers.

[0002023554-25-000034:mdna:12]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2025, 2024, and 2023, which ended on June 27, 2025, June 28, 2024, and June 30, 2023 are each comprised of 52 weeks, with each fiscal quarter consisting of 13 weeks. Fiscal year 2026 will be comprised of 52 weeks and end on July 3, 2026.

[0002023554-25-000034:mdna:13]
Sale-Leaseback

[0002023554-25-000034:mdna:14]
In September 2023, WDC completed a sale and leaseback of its facility in Milpitas, California, and received net proceeds of $191 million in cash. A substantial majority of these assets are associated with the Company, and as a result, $134 million of the net proceeds from the sale-leaseback transaction were allocated to us on a relative square footage basis. The property is being leased back to us at a total annual rate of $16 million for the first year and increasing by 3% per year thereafter through January 1, 2039. The lease includes three five-year renewal options and one four-year renewal option that provide the ability to extend through December 2057. The associated operating lease liability and right-of-use asset for this facility have been included in the Consolidated Balance Sheets as of June 27, 2025 and June 28, 2024.

[0002023554-25-000034:mdna:15]
SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”)

[0002023554-25-000034:mdna:16]
As discussed in Part II, Item 8., Note 10, Related Parties and Related Commitments and Contingencies of the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K, on September 28, 2024, prior to the separation, WDC’s wholly-owned subsidiary, SanDisk China Limited (“SanDisk China”) completed the sale of 80% of its equity interest in SDSS (the “Transaction”) to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “SDSS Venture”). The Transaction resulted in a pre-tax gain of $34 million.

[0002023554-25-000034:mdna:17]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT”) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million. On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if SDSS fails to meet its minimum annual commitment. The Supply Agreement also provides that if SDSS purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. As a result of the Transaction, we expect to incur a modest reduction in annual operating expenses and a reduction in annual capital expenditure related to the assembly and testing of flash-based products. We also anticipate that the transition to a contract manufacturing model through the SDSS Venture will result in a small increase in our annual cost of revenue for flash-based products.

[0002023554-25-000034:mdna:18]
Goodwill Impairment

[0002023554-25-000034:mdna:19]
As discussed in Part II, Item 8., Note 5, Supplemental Financial Statement Data of the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K, subsequent to the separation, we conducted a quantitative analysis of potential goodwill and long-lived assets impairments, in accordance with Accounting Standards Codification (“ASC”) No. 350, Intangibles - Goodwill and Other. This analysis indicated that the estimated carrying value of our reporting unit exceeded its fair value. Consequently, we recorded a goodwill impairment charge of $1.8 billion during the third quarter of the fiscal year ended June 27, 2025.

[0002023554-25-000034:mdna:20]
Our policy is to perform an annual impairment test on the first day of the fourth fiscal quarter. For the year ended June 27, 2025, we performed a qualitative analysis which did not indicate that goodwill was more-likely-than-not impaired. As a result, no additional quantitative analysis was required and no additional impairment charge was recorded during the fiscal year ended June 27, 2025.

[0002023554-25-000034:mdna:21]
Financing Activities

[0002023554-25-000034:mdna:22]
Prior to the separation, we received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additional information regarding our outstanding notes due to (from) Western Digital Corporation is included in Part II, Item 8., Note 10, Related Parties and Related Commitments and Contingencies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:23]
As discussed in Part II, Item 8., Note 8, Debt of the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K, on February 21, 2025, we entered into a loan agreement comprised of a seven-year Term Loan B facility in an aggregate principal amount of $2.0 billion (the “Term Loan Facility”) and a five-year revolving credit facility (the “Revolving Credit Facility”) in an aggregate principal amount of $1.5 billion with $150 million available for letters of credit.

[0002023554-25-000034:mdna:24]
On February 21, 2025, we borrowed $2.0 billion under the Term Loan Facility. We used a portion of the proceeds of the borrowing to make a net distribution payment of approximately $1.5 billion to WDC, with the remainder to be used for general corporate purposes. The proceeds of the Revolving Credit Facility may be used for working capital and general corporate purposes.

[0002023554-25-000034:mdna:25]
As of June 27, 2025, we have drawn no amounts under the Revolving Credit Facility.

[0002023554-25-000034:mdna:26]
Operational Update

[0002023554-25-000034:mdna:27]
In 2025, we generally saw an improvement in the supply and demand dynamics, leading to improved revenues and gross margin in fiscal 2025 compared to 2024. As part of our actions to align supply with market demand in the later half of fiscal 2025, we incurred charges for unabsorbed manufacturing overhead costs due to reduced utilization of our manufacturing capacity totaling $75 million, and we anticipate incurring some underutilization charges as we moderate production levels to align with demand for our products in the first quarter of 2026.

[0002023554-25-000034:mdna:28]
Additionally, in 2025, the U.S. announced changes to U.S. trade policy, including increased tariffs on imported goods. Currently, the majority of our products sold in the U.S. are exempt from tariffs, but additional tariff increases, or the loss of applicable exemptions would increase the cost of goods sold for our products sold in the U.S., which could negatively impact our margins and financial performance. Increases in the price of our products in response to increased costs may adversely impact demand for those products in the U.S., which could also negatively impact our performance and financial results. Future trade policies and regulations in the U.S. and other countries, the terms of any trade arrangements that may be negotiated between the U.S. and other countries, the scope, amount, or duration of tariffs that may be imposed by any country, and the impact of these factors on our business are uncertain and may contribute to increased costs and reduced demand for our products, each of which could harm our financial performance.

[0002023554-25-000034:mdna:29]
With regard to technological advances, we anticipate that digital transformation, including the AI data-cycle, will drive improved market conditions in the long term for our data storage products.

[0002023554-25-000034:mdna:30]
We will continue to actively monitor developments impacting our business and may take additional responsive actions that we determine to be in the best interest of our business and stakeholders.

[0002023554-25-000034:mdna:31]
Basis of Presentation

[0002023554-25-000034:mdna:32]
On February 21, 2025, we became a standalone publicly traded company, and our financial statements are now presented on a consolidated basis. Prior to the separation, our historical financial statements were derived from WDC’s consolidated financial statements and accounting records and prepared as if we existed on a standalone basis. The financial statements for all periods presented, including our historical results prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”).

[0002023554-25-000034:mdna:33]
The following discussion reflects our financial condition and results of operations as set forth in the Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:34]
The Consolidated Statements of Operations include all revenues and costs directly attributable to us, including costs for facilities, functions, and services used by us. Prior to the separation, our business had historically functioned together with the other businesses controlled by WDC. Accordingly, we relied on WDC’s corporate overhead and other support functions. Therefore, certain corporate overhead and shared costs were allocated to us including (i) certain general and administrative expenses related to WDC’s support functions that are provided on a centralized basis within WDC (e.g., expenses for corporate facilities, executive oversight, treasury, finance, legal, human resources, compliance, information technology, employee benefit plans, stock compensation plans and other corporate functions), and (ii) certain operations support costs incurred by WDC, including product sourcing, maintenance and support services, and other supply chain functions. These expenses were specifically identified, when possible, or allocated based on revenues, headcount, usage or other allocation methods that are considered to be a reasonable reflection of the utilization of services provided or benefit received. While management considers that such allocations were made on a reasonable basis consistent with benefits received, the Consolidated Financial Statements included in this Annual Report on Form 10-K may not be indicative of our future performance, do not necessarily include the actual expenses that would have been incurred by us and may not reflect our results of operations, financial position, and cash flows had we been a separate, standalone company during the periods presented. For additional information, see Part II, Item 8., Note 1, Organization, Basis of Presentation and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:35]
Results of Operations

[0002023554-25-000034:mdna:36]
Overview

[0002023554-25-000034:mdna:37]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by dollars and percentage of net revenue(1):

[0002023554-25-000034:mdna:38]
|  | 2025 |  | 2024 |  | 2023 |  |  |  |
|  | (in millions, except percentages) |
| Revenue, net | $ | 7,355 |  |  | 100.0 | % |  | $ | 6,663 |  |  | 100.0 | % |  | $ | 6,086 |  |  | 100.0 | % |  |  |  |
| Cost of revenue | 5,143 |  |  | 69.9 |  |  | 5,591 |  |  | 83.9 |  |  | 5,656 |  |  | 92.9 |  |  |  |  |
| Gross profit | 2,212 |  |  | 30.1 |  |  | 1,072 |  |  | 16.1 |  |  | 430 |  |  | 7.1 |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,132 |  |  | 15.4 |  |  | 1,061 |  |  | 15.9 |  |  | 1,167 |  |  | 19.2 |  |  |  |  |
| Selling, general and administrative | 573 |  |  | 7.8 |  |  | 455 |  |  | 6.8 |  |  | 558 |  |  | 9.2 |  |  |  |  |
| Goodwill impairment | 1,830 |  |  | 24.9 |  |  | — |  |  | — |  |  | 671 |  |  | 11.0 |  |  |  |  |
| Business separation costs | 67 |  |  | 0.9 |  |  | 64 |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |
| Employee termination and other | 21 |  |  | 0.3 |  |  | (40) |  |  | (0.6) |  |  | 69 |  |  | 1.1 |  |  |  |  |
| Gain on business divestiture | (34) |  |  | (0.5) |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |
| Total operating expenses | 3,589 |  |  | 48.8 |  |  | 1,540 |  |  | 23.1 |  |  | 2,465 |  |  | 40.5 |  |  |  |  |
| Operating income (loss) | (1,377) |  |  | (18.7) |  |  | (468) |  |  | (7.0) |  |  | (2,035) |  |  | (33.4) |  |  |  |  |
| Interest and other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 22 |  |  | 0.3 |  |  | 12 |  |  | 0.2 |  |  | 21 |  |  | 0.3 |  |  |  |  |
| Interest expense | (63) |  |  | (0.9) |  |  | (40) |  |  | (0.6) |  |  | (31) |  |  | (0.5) |  |  |  |  |
| Other income (expense), net | (61) |  |  | (0.8) |  |  | (7) |  |  | (0.1) |  |  | 43 |  |  | 0.7 |  |  |  |  |
| Total interest and other income (expense), net | (102) |  |  | (1.4) |  |  | (35) |  |  | (0.5) |  |  | 33 |  |  | 0.5 |  |  |  |  |
| Income (loss) before taxes | (1,479) |  |  | (20.1) |  |  | (503) |  |  | (7.5) |  |  | (2,002) |  |  | (32.9) |  |  |  |  |
| Income tax expense | 162 |  |  | 2.2 |  |  | 169 |  |  | 2.5 |  |  | 141 |  |  | 2.3 |  |  |  |  |
| Net income (loss) | $ | (1,641) |  |  | (22.3) | % |  | $ | (672) |  |  | (10.0) | % |  | $ | (2,143) |  |  | (35.2) | % |  |  |  |

[0002023554-25-000034:mdna:39]
(1) Percentage may not total due to rounding.

[0002023554-25-000034:mdna:40]
The following table sets forth, for the periods presented, summary information regarding our disaggregated revenue:

[0002023554-25-000034:mdna:41]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |
| Cloud | $ | 960 |  |  | $ | 325 |  | $ | 500 |  |
| Client | 4,127 |  |  | 4,069 |  | 3,637 |  |
| Consumer | 2,268 |  |  | 2,269 |  | 1,949 |  |
| Total revenue | $ | 7,355 |  |  | $ | 6,663 |  |  | $ | 6,086 |  |
| Revenue by geography: |  |  |  |  |  |
| Asia | $ | 4,457 |  |  | $ | 4,510 |  | $ | 3,890 |  |
| Americas | 1,618 |  |  | 1,095 |  | 1,266 |  |
| Europe, Middle East and Africa | 1,280 |  |  | 1,058 |  | 930 |  |
| Total revenue | $ | 7,355 |  | 7355000000 | $ | 6,663 |  |  | $ | 6,086 |  |

[0002023554-25-000034:mdna:42]
48

[0002023554-25-000034:mdna:43]
Our broad portfolio of technology and products addresses multiple end markets. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, we provide our OEM and channel customers a broad array of high-performance flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast points of presence around the world.

[0002023554-25-000034:mdna:44]
Net Revenue

[0002023554-25-000034:mdna:45]
Net revenue increased 10%, or $692 million, in 2025 compared to 2024, primarily due to a 6% increase in exabytes sold due to stronger demand in our Cloud end market and a 4% increase in average selling prices (“ASP”) per gigabyte due to enhanced pricing as the supply-demand balance improved.

[0002023554-25-000034:mdna:46]
Cloud revenue increased 195%, or $635 million, in 2025 compared to 2024, primarily due to a 153% increase in exabytes sold due to increased enterprise SSD shipments to data center customers and a 17% increase in ASP per gigabyte due to improved pricing.

[0002023554-25-000034:mdna:47]
Client revenue increased 1%, or $58 million, in 2025 compared to 2024, primarily due to an 8% increase in ASP per gigabyte, partially offset by a 7% decrease in exabytes sold.

[0002023554-25-000034:mdna:48]
Consumer revenue decreased $1 million in 2025 compared to 2024, primarily due to a 6% increase in exabytes sold, offset by a 7% decrease in ASP per gigabyte due to pricing pressure.

[0002023554-25-000034:mdna:49]
The changes in net revenue by geography in 2025 compared to 2024 primarily reflected higher revenue in the Americas region from Cloud customers.

[0002023554-25-000034:mdna:50]
Consistent with standard industry practice, we offer sales incentives and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as reductions of gross revenue. For 2025, 2024 and 2023, these programs represented 19%, 19%, and 21%, respectively, of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0002023554-25-000034:mdna:51]
Gross Profit and Gross Margin

[0002023554-25-000034:mdna:52]
Gross profit increased $1,140 million in 2025 compared to 2024, primarily due to improved pricing, a favorable product mix, a decrease in manufacturing underutilization charges incurred in 2025 compared to the comparable prior year period, and a $54 million write-down of Flash inventory in 2024 as a result of decreases in market pricing, for which a similar charge was not incurred in 2025, partially offset by $36 million of insurance recoveries received during 2024 for losses incurred due to a contamination incident in 2022. In 2024, we recognized a $252 million charge due to reduced manufacturing capacity utilization, compared to an underutilization charge of $75 million incurred in 2025.

[0002023554-25-000034:mdna:53]
Gross profit margin increased 14% in 2025 compared to 2024, with approximately 10% driven by higher revenue due to improved pricing, higher demand for our offerings, and favorable product mix and the remaining 4% due to the decrease in manufacturing underutilization charges incurred in 2025 and a write-down of Flash inventory in 2024 for which a similar charge was not incurred in the current period.

[0002023554-25-000034:mdna:54]
Operating Expenses

[0002023554-25-000034:mdna:55]
Research and development (“R&D”) expenses increased $71 million in 2025 compared to 2024, primarily due to a $32 million increase in compensation and benefits mainly due to higher variable compensation which includes short-term incentives, an $18 million increase in spending for R&D projects, a $15 million increase in material purchases, and a $5 million increase in legal and outside service fees.

[0002023554-25-000034:mdna:56]
Selling, general and administrative expenses increased $118 million in 2025 compared to 2024, primarily due to an $84 million increase in compensation and benefits due to higher variable compensation which includes short-term incentives, a $24 million increase in materials, a $16 million increase in legal service fees, and a $14 million increase in sales and marketing expenses, partially offset by a $20 million decrease in strategic review costs incurred in 2024 for which there are no comparable costs in the current year.

[0002023554-25-000034:mdna:57]
Employee termination and other charges decreased $61 million in 2025 compared to 2024, primarily due to a $60 million gain on the sale-leaseback of a facility in the prior period, for which there is no comparable transaction in 2025. For additional information regarding employee termination and other charges, see Part II, Item 8., Note 15, Employee Termination and Other Charges of the Notes to Consolidated Financial Statements included in this Annual Report.

[0002023554-25-000034:mdna:58]
Goodwill impairment

[0002023554-25-000034:mdna:59]
Goodwill impairment increased $1.8 billion in 2025 compared to 2024 due to an impairment charge resulting from the difference between the carrying value of our reporting unit and its fair value.

[0002023554-25-000034:mdna:60]
Business separation costs

[0002023554-25-000034:mdna:61]
Business separation costs increased $3 million in 2025 compared to 2024, primarily due to the completion of the separation from WDC.

[0002023554-25-000034:mdna:62]
Gain on business divestiture

[0002023554-25-000034:mdna:63]
Gain on business divestiture increased $34 million in 2025 compared to 2024 due to the pre-tax gain on the sale of SDSS.

[0002023554-25-000034:mdna:64]
Interest and Other Expense, net

[0002023554-25-000034:mdna:65]
Interest and other expense, net increased $67 million in 2025 compared to 2024, primarily due to a $56 million increase in interest expense from our Loan Agreement, a $37 million increase in losses on our equity method investments, and a $24 million increase in foreign exchange losses, partially offset by a $28 million decrease in interest expense on borrowings due to WDC, a $15 million increase in interest income due to an increase in available cash, and a $7 million increase in interest income arising from the accretion of the present value discount on the outstanding SDSS sale consideration receivable.

[0002023554-25-000034:mdna:66]
Income Tax Expense

[0002023554-25-000034:mdna:67]
H.R.1, more widely known as the Big Beautiful Bill Act, was recently signed into law on July 4, 2025. It reversed the requirement for capitalization of U.S. research and development expenditures that came into law under the Tax Cuts and Jobs Act of 2017, but the mandatory requirement of capitalization of foreign research and development expenditures remains. The tax rates for income earned by our foreign subsidiaries will also be changed under H.R. 1. Depending on our operating results, these changes can materially impact our effective tax rate and reduce our operating cash flows. As H.R.1 was enacted after our fiscal year 2025, its impact on the tax provision will be reflected in fiscal year 2026.

[0002023554-25-000034:mdna:68]
On August 16, 2022, the Inflation Reduction Act of 2022 was signed into law, which contained significant changes to laws related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. We do not expect to be subject to the CAMT of 15% for 2025 as our average annual AFSI did not exceed $1.0 billion for the preceding three-year period.

[0002023554-25-000034:mdna:69]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two”). Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, some of which are effective for us in 2025. For 2025, we currently expect to be able to meet certain transitional safe harbors and do not expect any material Pillar Two taxes. As more jurisdictions adopt this legislation in 2026, there may be material increases in our future tax obligations in certain jurisdictions.

[0002023554-25-000034:mdna:70]
The following table presents our Income tax expense and the effective tax rate:

[0002023554-25-000034:mdna:71]
|  | 2025 |  | 2024 |  | 2023 |  |
|  | (in millions) |
| Income (loss) before taxes | $ | (1,479) |  |  | $ | (503) |  |  | $ | (2,002) |  |  |
| Income tax expense | 162 |  |  | 169 |  |  | 141 |  |  |
| Effective tax rate | (11) | % |  | (34) | % |  | (7) | % |  |

[0002023554-25-000034:mdna:72]
The relative mix of earnings and losses by jurisdiction, the goodwill impairment, the foreign income inclusion, credits, and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the years ended June 27, 2025.

[0002023554-25-000034:mdna:73]
For additional information regarding income tax expense, see Part II, Item 8., Note 14, Income Tax Expense of the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:74]
Financial condition, liquidity and capital resources

[0002023554-25-000034:mdna:75]
The following table summarizes our Consolidated Statements of Cash Flows:

[0002023554-25-000034:mdna:76]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 84 |  |  | $ | (309) |  |  | $ | (713) |  |
| Investing activities | 556 |  |  | 210 |  |  | (189) |  |
| Financing activities | 518 |  |  | 136 |  |  | 860 |  |
| Effect of exchange rate changes on cash | (5) |  |  | (1) |  |  | (1) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 1,153 |  |  | $ | 36 |  |  | $ | (43) |  |

[0002023554-25-000034:mdna:77]
In alignment with market conditions, we have maintained a conservative capital expenditure strategy for 2025 and 2024. For fiscal year 2026, we anticipate increased capital investments as we transition to newer nodes to meet the demand and technology needs of our product portfolio.

[0002023554-25-000034:mdna:78]
We believe our cash and cash equivalents will be sufficient to meet our working capital needs for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A., Risk Factors included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:79]
A total of $692 million and $321 million of our cash and cash equivalents were held outside of the U.S. as of June 27, 2025 and June 28, 2024 respectively. There are no material tax consequences that were not previously accrued for the repatriation of this cash. Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities.

[0002023554-25-000034:mdna:80]
Operating Activities

[0002023554-25-000034:mdna:81]
Net cash provided by (used in) operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used as a result of changes in operating assets and liabilities was $380 million for 2025, compared to $86 million net cash provided for 2024, reflecting an increase in the volume of our business, as discussed above.

[0002023554-25-000034:mdna:82]
Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the volume of our business and the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0002023554-25-000034:mdna:83]
|  | 2025 |  | 2024 |  | 2023 |
| Days sales outstanding | 51 |  |  | 48 |  |  | 35 |  |
| Days in inventory | 135 |  |  | 158 |  |  | 134 |  |
| Days payable outstanding | (50) |  |  | (54) |  |  | (37) |  |
| Cash conversion cycle | 136 |  |  | 152 |  |  | 132 |  |

[0002023554-25-000034:mdna:84]
Changes in days sales outstanding, or DSO, are generally due to the timing of shipments. Changes in days in inventory, or DIO, are generally related to the timing of inventory builds. Changes in days payable outstanding, or DPO, are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make payment term modifications through negotiations with our vendors or by granting to or receiving from our vendors payment term accommodations.

[0002023554-25-000034:mdna:85]
In 2025, DSO increased 3 days when compared to the prior year, reflecting lower accounts receivable factoring and the timing of shipments and customer collections. DIO decreased 23 days over the prior year, primarily reflecting greater consumption of inventory. DPO decreased 4 days over the prior year, primarily due to routine variations in the timing of purchases and payments.

[0002023554-25-000034:mdna:86]
51

[0002023554-25-000034:mdna:87]
Investing Activities

[0002023554-25-000034:mdna:88]
Net cash provided by investing activities in 2025 primarily consisted of $401 million in net proceeds from our sale of a majority interest in one of our subsidiaries and $358 million in net proceeds from activity related to Flash Ventures, partially offset by $204 million in capital expenditures. Net cash provided by investing activities in 2024 primarily consisted of $239 million in net proceeds from activity related to Flash Ventures and $137 million of proceeds from the sale-leaseback of our Milpitas, California facility, partially offset by $166 million in capital expenditures.

[0002023554-25-000034:mdna:89]
Financing Activities

[0002023554-25-000034:mdna:90]
Net cash provided by financing activities in 2025 primarily consisted of $1,970 million in proceeds from borrowings from the Term Loan Facility, $550 million in proceeds from borrowings on notes due to WDC, and $101 million in proceeds from principal repayments on notes due from WDC, partially offset by $1,887 million transferred to WDC, $100 million in repayment on the Term Loan Facility, and $76 million in net repayments on notes due to WDC. Net cash provided by financing activities in 2024 primarily consisted of $394 million in net transfers from WDC, partially offset by $170 million in origination of notes due from WDC and $102 million in net repayments on notes due to WDC.

[0002023554-25-000034:mdna:91]
A discussion of our cash flows for 2024, including a comparison of such cash flows to 2023, is included in Item 2., Management’s Discussion and Analysis of Financial Condition and Results of Operations in our Form 10.

[0002023554-25-000034:mdna:92]
Off-Balance Sheet Arrangements

[0002023554-25-000034:mdna:93]
Other than the Flash Ventures and SDSS-related commitments incurred in the normal course of business and certain indemnification provisions (see “Short-and-Long-term Liquidity - Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligations arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, with the exception of Flash Ventures, the SDSS Venture and the Unis Venture, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8., Note 10, Related Parties and Related Commitments and Contingencies of the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:94]
Short-and-Long-term Liquidity

[0002023554-25-000034:mdna:95]
Material Cash Requirements

[0002023554-25-000034:mdna:96]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of June 27, 2025. In addition, see the discussions further below related to unrecognized tax benefits, foreign exchange contracts and indemnifications.

[0002023554-25-000034:mdna:97]
|  | Total |  | 1 year (2026) |  | 2-3 Years (2027-2028) |  | 4-5 Years (2029-2030) |  | More than 5 Years (Beyond 2030) |
|  | (in millions) |
| Long-term debt, including current portion (1) | $ | 1,900 |  |  | $ | 20 |  |  | $ | 40 |  |  | $ | 40 |  |  | $ | 1,800 |  |
| Interest on debt | 905 |  |  | 143 |  |  | 276 |  |  | 267 |  |  | 219 |  |
| Flash Ventures related commitments(2) | 4,539 |  |  | 2,226 |  |  | 1,583 |  |  | 667 |  |  | 63 |  |
| Operating leases | 331 |  |  | 41 |  |  | 63 |  |  | 44 |  |  | 183 |  |
| Purchase obligations and other commitments | 2,633 |  |  | 250 |  |  | 1,153 |  |  | 1,140 |  |  | 90 |  |
| Total | $ | 10,308 |  |  | $ | 2,680 |  |  | $ | 3,115 |  |  | $ | 2,158 |  |  | $ | 2,355 |  |

[0002023554-25-000034:mdna:98]
(1) Principal portion of debt, excluding issuance costs.

[0002023554-25-000034:mdna:99]
(2) Includes reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including R&D and building depreciation. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0002023554-25-000034:mdna:100]
Debt

[0002023554-25-000034:mdna:101]
In connection with the separation, on February 21, 2025, we entered into a loan agreement (the “Loan Agreement”) comprised of a $1.5 billion revolving credit facility, on which no amounts have been drawn, and a $2.0 billion term loan facility due in 2032. The Company used a portion of the proceeds received from the term loan facility, as well as cash on hand, to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities and certain legal entities of WDC associated with the Company.

[0002023554-25-000034:mdna:102]
As of June 27, 2025, we were in compliance with the Loan Agreement financial covenant that requires us to maintain a maximum Leverage Ratio. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8., Note 8, Debt of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:103]
Flash Ventures

[0002023554-25-000034:mdna:104]
Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements, of which we guarantee half of all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of June 27, 2025, and as of June 28, 2024, we were in compliance with all covenants under these Japanese lease facilities. See Part II, Item 8., Note 10, Related Parties and Related Commitments and Contingencies of the Notes to the Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding Flash Ventures.

[0002023554-25-000034:mdna:105]
Purchase Obligations and Other Commitments

[0002023554-25-000034:mdna:106]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0002023554-25-000034:mdna:107]
Unrecognized Tax Benefits

[0002023554-25-000034:mdna:108]
As of June 27, 2025, our liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $140 million. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 27, 2025 and June 28, 2024 was $11 million and $9 million, respectively. Of these amounts, approximately $138 million could result in potential cash payments.

[0002023554-25-000034:mdna:109]
Foreign Exchange Contracts

[0002023554-25-000034:mdna:110]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. See Part II, Item 7A., Quantitative and Qualitative Disclosures About Market Risk included in this Annual Report on Form 10-K for additional information.

[0002023554-25-000034:mdna:111]
Indemnifications

[0002023554-25-000034:mdna:112]
Concurrent with the separation, we and WDC entered into a Tax Matters Agreement under which we and WDC agreed to indemnify each other for certain tax positions. As a result of this agreement, we recorded a tax indemnification liability of $112 million on February 21, 2025, which was recognized as an adjustment to the Net investment from Western Digital Corporation. This liability was subsequently reduced by approximately $2 million, reflecting the outstanding balance as of June 27, 2025. The remaining tax indemnification liability of $110 million is classified as Other liabilities in the Consolidated Balance Sheets as of June 27, 2025.

[0002023554-25-000034:mdna:113]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners, and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance, or intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0002023554-25-000034:mdna:114]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0002023554-25-000034:mdna:115]
Recent Accounting Pronouncements

[0002023554-25-000034:mdna:116]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0002023554-25-000034:mdna:117]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” This ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026, with early adoption permitted. The Company expects to provide any required disclosures at that time.

[0002023554-25-000034:mdna:118]
In November 2024, the FASB issued ASU 2024-03, “Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses,” which is intended to improve disclosures about the expenses of public entities. This ASU requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This ASU is effective on either a prospective or retrospective basis for fiscal years beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption. The Company expects to provide any required disclosures for annual reporting periods included in the Company’s financial statements for the year ending June 30, 2028.

[0002023554-25-000034:mdna:119]
Critical Accounting Estimates

[0002023554-25-000034:mdna:120]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, and liabilities. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material. Our accounting policies are fully described in Part II, Item 8., Note 1, Organization, Basis of Presentation and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0002023554-25-000034:mdna:121]
Revenue

[0002023554-25-000034:mdna:122]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. We record estimates of variable consideration related to these items as a reduction of revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. We constrain variable consideration until the likelihood of a significant revenue reversal is not probable and believe that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0002023554-25-000034:mdna:123]
For sales to OEMs, our methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from agreed-upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on several factors, including historical pricing information, current pricing trends and channel inventory levels. Estimating the impact of these factors requires significant judgment and differences between the estimated and actual amounts of variable consideration can be significant.

[0002023554-25-000034:mdna:124]
Inventories

[0002023554-25-000034:mdna:125]
We value inventories at the lower of cost or net realizable value, or “NRV,” with cost determined on a first-in, first-out basis. We record inventory write-downs of our inventory to the lower of cost or net realizable value or for obsolete or excess inventory based on assumptions, which requires significant judgment. The determination of NRV involves estimating the average selling prices less any selling expenses of inventory based on market conditions and customer demand. To estimate the average selling prices and selling expenses of inventory, we review historical sales, future demand, economic conditions, contract prices and other information.

[0002023554-25-000034:mdna:126]
We periodically perform an excess and obsolete analysis of our inventory based on assumptions, which includes changes in business and economic conditions, changes in technology and projected demand of our products. If in any period we anticipate a change in those assumptions to be less favorable than our previous estimates, additional inventory write-downs may be required and could materially and negatively impact our gross margin. If in any period, we can sell inventories that had been written down to a level below the realized selling price in the previous period, higher gross profit would be recognized in that period. Although adjustments to these reserves have typically been immaterial, in 2024, we recorded a charge to cost of revenue of $95 million, primarily to reduce component inventory to NRV as a result of a sudden change in demand for certain products. Adjustments to the reserve in 2025 were immaterial.

[0002023554-25-000034:mdna:127]
Goodwill

[0002023554-25-000034:mdna:128]
Goodwill attributed to us represents the amount by which the purchase price of businesses acquired in a business combination exceeded the estimated fair value of acquired net assets.

[0002023554-25-000034:mdna:129]
Goodwill is not amortized. Instead, it is tested for impairment at least annually, as of the beginning of the Company’s fourth quarter, or more frequently if events or changes in circumstances indicate that goodwill may be impaired. We use qualitative factors to determine whether goodwill is more-likely-than-not impaired and whether a quantitative test for impairment is considered necessary. If we conclude from the qualitative assessment that goodwill is more-likely-than-not impaired, we are required to perform a quantitative assessment to determine the amount of impairment.

[0002023554-25-000034:mdna:130]
We are required to use judgment when assessing goodwill for impairment, including evaluating the impact of industry and macroeconomic conditions and the determination of the fair value of the reporting unit. In addition, the estimates and assumptions used to determine the fair value as well as the actual carrying value may change based on future changes in our results of operations, macroeconomic conditions, or other factors. Changes in these estimates and assumptions could materially affect our assessment of the fair value and goodwill impairment. In addition, if negative macroeconomic conditions continue or worsen, goodwill could become impaired, which could result in an impairment charge and materially adversely affect our financial condition and results of operations.

[0002023554-25-000034:mdna:131]
Subsequent to the completion of the separation in February 2025, we identified potential impairment indicators related to macroeconomic indicators, industry developments, the trading price of our common stock and resulting market capitalization that warranted a quantitative impairment analysis of long-lived assets and goodwill.

[0002023554-25-000034:mdna:132]
Subsequently, we performed a quantitative test, which indicated that the carrying value of our reporting unit exceeded its estimated fair value, resulting in the recognition of a $1.8 billion impairment charge during the third quarter of the year ended June 27, 2025 which was recorded in the accompanying Consolidated Statements of Operations.

[0002023554-25-000034:mdna:133]
We performed a qualitative impairment test on the first day of the fourth fiscal quarter, which did not indicate that goodwill was more-likely-than-not impaired. As a result, no additional quantitative analysis was required and no additional impairment charge was recorded during the fiscal year ended June 27, 2025, other than as stated above.

[0002023554-25-000034:mdna:134]
The tests for goodwill and long-lived asset impairment are further explained in Part II, Item 8., Note 5, Supplemental Financial Statement Data of the Notes to the Consolidated Financial Statements. Determining the fair value used in our impairment calculations involves using significant estimates and assumptions, including revenue forecasts, terminal growth rate, tax rate, and a weighted average cost of capital adjusted for company-specific risk. These estimates and assumptions are based on the most current information available to the Company, and there is no assurance that these estimates and assumptions will accurately predict future outcomes. If our assumptions are not realized, or if any of these assumptions change due to changes in economic conditions, our results of operations, or other factors, it is possible that an additional impairment charge may be recorded.
