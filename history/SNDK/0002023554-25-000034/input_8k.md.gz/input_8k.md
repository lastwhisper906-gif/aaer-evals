# SNDK 8-K — 0001193125-25-180782 filed 2025-08-14

## item codes, every 8-K on or before 2025-08-21

- 2025-08-14 0001193125-25-180782 — 2.02, 9.01
- 2025-05-07 0002023554-25-000021 — 2.02, 9.01
- 2025-03-11 0002023554-25-000007 — 5.02
- 2025-02-24 0001193125-25-033433 — 1.01, 2.03, 3.03, 5.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2025-02-14 0001193125-25-027285 — 3.03, 5.03, 9.01
- 2025-02-03 0001193125-25-019298 — 8.01, 9.01

## late-filing notifications on or before 2025-08-21

- none on or before 2025-08-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-25-180782:8k_2_02:1]
EX-99.1
2
d926236dex991.htm
EX-99.1

[0001193125-25-180782:8k_2_02:2]
EX-99.1

[0001193125-25-180782:8k_2_02:3]
Exhibit 99.1

[0001193125-25-180782:8k_2_02:4]
Sandisk Reports Fiscal Fourth Quarter 2025 Financial Results

[0001193125-25-180782:8k_2_02:5]
News Summary

[0001193125-25-180782:8k_2_02:6]
|  | • |  | Fiscal fourth quarter revenue was $1.90 billion, up 12% sequentially and above the guidance range. |

[0001193125-25-180782:8k_2_02:7]
|  | • |  | Fiscal fourth quarter GAAP loss was $23 million ($0.16 diluted loss per share), and fourth quarter Non-GAAP diluted earnings per share (EPS) was $0.29. |

[0001193125-25-180782:8k_2_02:8]
|  | • |  | Fiscal first quarter 2026 revenue expected to be in the range of $2.10 billion to $2.20 billion. |

[0001193125-25-180782:8k_2_02:9]
|  | • |  | Fiscal first quarter 2026 Non-GAAP diluted earnings per share expected to be in the range of $0.70 to $0.90. |

[0001193125-25-180782:8k_2_02:10]
MILPITAS, Calif. — August 14, 2025 — Sandisk Corporation (Nasdaq: SNDK)
today reported fiscal fourth quarter financial results.

[0001193125-25-180782:8k_2_02:11]
“Sandisk delivered strong results this quarter, with revenue and non-GAAP EPS exceeding our guidance. We continue to execute with discipline, balancing innovation and operational focus,” said David Goeckeler, Sandisk CEO. “The ramp of BiCS8 brings new levels of
performance, density and energy efficiency to our customers. With High Bandwidth Flash (HBF), we are creating a new paradigm for AI inference solutions. With demand improving and industry fundamentals strengthening, we are well-positioned to drive
sustainable growth, expand margins, and generate strong cash flow.”

[0001193125-25-180782:8k_2_02:12]
1

[0001193125-25-180782:8k_2_02:13]
Q4 2025 Financial Highlights

[0001193125-25-180782:8k_2_02:14]
|  |  | GAAP |  |  | Non-GAAP |  |
| ($ in millions, except per share amounts) |  | Q4 2025 |  |  | Q3 2025 |  |  | Q/Q |  |  | Q4 2025 |  |  | Q3 2025 |  |  | Q/Q |  |
| Revenue |  | $ | 1,901 |  |  | $ | 1,695 |  |  |  | up 12% |  |  | $ | 1,901 |  |  | $ | 1,695 |  |  |  | up 12% |  |
| Gross Margin |  |  | 26.2 | % |  |  | 22.5 | % |  |  | up 3.7 ppt |  |  |  | 26.4 | % |  |  | 22.7 | % |  |  | up 3.7 ppt |  |
| Operating Expenses |  | $ | 480 |  |  | $ | 2,263 |  |  |  | down 79% |  |  | $ | 402 |  |  | $ | 383 |  |  |  | up 5% |  |
| Operating Income (Loss) |  | $ | 18 |  |  | $ | (1,881 | ) |  |  | up 101% |  |  | $ | 100 |  |  | $ | 2 |  |  |  | up 4900% |  |
| Net Income (Loss) |  | $ | (23 | ) |  | $ | (1,933 | ) |  |  | up 99% |  |  | $ | 42 |  |  | $ | (43 | ) |  |  | up 198% |  |
| Net Income (Loss) Per Share |  | $ | (0.16 | ) |  | $ | (13.33 | ) |  |  | up 99% |  |  | $ | 0.29 |  |  | $ | (0.30 | ) |  |  | up 197% |  |
|  |  | GAAP |  |  | Non-GAAP |  |
| ($ in millions, except per share amounts) |  | Q4 2025 |  |  | Q4 2024 |  |  | Y/Y |  |  | Q4 2025 |  |  | Q4 2024 |  |  | Y/Y |  |
| Revenue |  | $ | 1,901 |  |  | $ | 1,760 |  |  |  | up 8% |  |  | $ | 1,901 |  |  | $ | 1,760 |  |  |  | up 8% |  |
| Gross Margin |  |  | 26.2 | % |  |  | 36.1 | % |  |  | down 9.9 ppt |  |  |  | 26.4 | % |  |  | 36.4 | % |  |  | down 10 ppt |  |
| Operating Expenses |  | $ | 480 |  |  | $ | 437 |  |  |  | up 10% |  |  | $ | 402 |  |  | $ | 386 |  |  |  | up 4% |  |
| Operating Income |  | $ | 18 |  |  | $ | 199 |  |  |  | down 91% |  |  | $ | 100 |  |  | $ | 255 |  |  |  | down 61% |  |
| Net Income (Loss) |  | $ | (23 | ) |  | $ | 120 |  |  |  | down 119% |  |  | $ | 42 |  |  | $ | 180 |  |  |  | down 77% |  |
| Net Income (Loss) Per Share |  | $ | (0.16 | ) |  | $ | 0.83 |  |  |  | down 119% |  |  | $ | 0.29 |  |  | $ | 1.24 |  |  |  | down 77% |  |
| Fiscal Year 2025 Financial Highlights |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | GAAP |  |  | Non-GAAP |  |
| ($ in millions, except per share amounts) |  | 2025 |  |  | 2024 |  |  | Y/Y |  |  | 2025 |  |  | 2024 |  |  | Y/Y |  |
| Revenue |  | $ | 7,355 |  |  | $ | 6,663 |  |  |  | up 10% |  |  | $ | 7,355 |  |  | $ | 6,663 |  |  |  | up 10% |  |
| Gross Margin |  |  | 30.1 | % |  |  | 16.1 | % |  |  | up 14 ppt |  |  |  | 30.3 | % |  |  | 15.8 | % |  |  | up 14.5 ppt |  |
| Operating Expenses |  | $ | 3,589 |  |  | $ | 1,540 |  |  |  | up 133% |  |  | $ | 1,539 |  |  | $ | 1,365 |  |  |  | up 13% |  |
| Operating Income (Loss) |  | $ | (1,377 | ) |  | $ | (468 | ) |  |  | down 194% |  |  | $ | 689 |  |  | $ | (309 | ) |  |  | up 323% |  |
| Net Income (Loss) |  | $ | (1,641 | ) |  | $ | (672 | ) |  |  | down 144% |  |  | $ | 440 |  |  | $ | (502 | ) |  |  | up 188% |  |
| Net Income (Loss) Per Share |  | $ | (11.32 | ) |  | $ | (4.63 | ) |  |  | down 144% |  |  | $ | 2.99 |  |  | $ | (3.46 | ) |  |  | up 186% |  |

[0001193125-25-180782:8k_2_02:15]
End Market Summary

[0001193125-25-180782:8k_2_02:16]
| Revenue ($M) |  | Q4 2025 |  |  | Q3 2025 |  |  | Q/Q |  | Q4 2024 |  |  | Y/Y |  | 2025 |  |  | 2024 |  |  | Y/Y |
| Cloud |  | $ | 213 |  |  | $ | 197 |  |  | up 8% |  | $ | 170 |  |  | up 25% |  | $ | 960 |  |  | $ | 325 |  |  | up 195% |
| Client |  |  | 1,103 |  |  |  | 927 |  |  | up 19% |  |  | 1,067 |  |  | up 3% |  |  | 4,127 |  |  |  | 4,069 |  |  | up 1% |
| Consumer |  |  | 585 |  |  |  | 571 |  |  | up 2% |  |  | 523 |  |  | up 12% |  |  | 2,268 |  |  |  | 2,269 |  |  | — |
| Total Revenue |  | $ | 1,901 |  |  | $ | 1,695 |  |  | up 12% |  | $ | 1,760 |  |  | up 8% |  | $ | 7,355 |  |  | $ | 6,663 |  |  | up 10% |

[0001193125-25-180782:8k_2_02:17]
Additional details can be found within the Company’s earnings presentation, which is accessible online at
investor.sandisk.com.

[0001193125-25-180782:8k_2_02:18]
2

[0001193125-25-180782:8k_2_02:19]
Business Outlook for Fiscal First Quarter of 2026

[0001193125-25-180782:8k_2_02:20]
|  |  | GAAP(1) |  | Non-GAAP(1) |
| Revenue ($B) |  | $2.10 - $2.20 |  | $2.10 - $2.20 |
| Gross margin |  | 28.3% - 29.2% |  | 28.5% - 29.5% |
| Operating expenses ($M) |  | $475 - $490 |  | $415 - $430 |
| Interest and other expense, net ($M) |  | $38 - $43 |  | $40 - $45 |
| Tax expense ($M)(2) |  | N/A |  | $35 - $40 |
| Diluted earnings (loss) per share |  | N/A |  | $0.70 - $0.90 |
| Diluted shares outstanding (in millions) |  | ~148 |  | ~148 |

[0001193125-25-180782:8k_2_02:21]
| (1) | Non-GAAP gross margin guidance excludes stock-based compensation expense and expense for short term incentives granted in connection with the separation, totaling approximately $4 million to $6 million. The Company’s Non-GAAP operating expenses guidance excludes stock-based compensation expense and expense for short term incentives granted in connection with the separation, totaling approximately $51 million to $69 million. The Company’s Non-GAAP interest and other expenses, net guidance excludes the accretion of the present value discount on consideration receivable from the sale of an interest in a subsidiary, totaling approximately $2 million. In the aggregate, Non-GAAP diluted earnings (loss) per share guidance excludes these items totaling $57 million to $77 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other expenses, net, and Non-GAAP diluted earnings (loss) per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the Company excludes from its Non-GAAP diluted earnings (loss) per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other expenses, net, and Non-GAAP diluted earnings (loss) per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, and diluted earnings (loss) per share, respectively) are not available without unreasonable effort. |

[0001193125-25-180782:8k_2_02:22]
| (2) | Non-GAAP tax expense is determined based on a Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax expense may differ from our GAAP tax expense (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income or loss; (ii) due to the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax expense for the full year, excluding loss jurisdictions; and (iii) because our GAAP taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses. |

[0001193125-25-180782:8k_2_02:23]
3

[0001193125-25-180782:8k_2_02:24]
Basis of Presentation

[0001193125-25-180782:8k_2_02:25]
On February 21, 2025, Sandisk Corporation (the “Company”) completed its separation from Western Digital Corporation (“WDC”) and
became a standalone publicly traded company.

[0001193125-25-180782:8k_2_02:26]
The Company’s financial and operating results after the separation are presented on a consolidated
basis. For periods prior to the separation, the Company’s historical combined financial statements were prepared on a carve-out basis and were derived from WDC’s consolidated financial statements
and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as
“Condensed Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”).

[0001193125-25-180782:8k_2_02:27]
Investor Communications

[0001193125-25-180782:8k_2_02:28]
The investment community
conference call to discuss these results and the Company’s business outlook for the fiscal first quarter of 2026 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the
earnings presentation can be accessed online at investor.sandisk.com.

[0001193125-25-180782:8k_2_02:29]
About Sandisk

[0001193125-25-180782:8k_2_02:30]
Sandisk is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated
innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for AI workloads in datacenters, edge devices, and consumers. Our technologies enable
everyone from students, gamers and home offices, to the largest enterprises and public clouds to produce, analyze, and store data. Our solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus
drives, and wafers and components. Learn more about Sandisk at www.Sandisk.com.

[0001193125-25-180782:8k_2_02:31]
4

[0001193125-25-180782:8k_2_02:32]
Forward-Looking Statements

[0001193125-25-180782:8k_2_02:33]
###

[0001193125-25-180782:8k_2_02:34]
Sandisk and the Sandisk logo are registered
trademarks or trademarks of Sandisk Corporation or its affiliates in the United States and/or other countries.

[0001193125-25-180782:8k_2_02:35]
5

[0001193125-25-180782:8k_2_02:36]
SANDISK CORPORATION

[0001193125-25-180782:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-25-180782:8k_2_02:38]
(in millions; except par value, unaudited)

[0001193125-25-180782:8k_2_02:39]
|  |  | June 27,2025 |  |  | June 28,2024 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,481 |  |  | $ | 328 |  |
| Accounts receivable, net |  |  | 1,068 |  |  |  | 935 |  |
| Inventories |  |  | 2,079 |  |  |  | 1,955 |  |
| Income tax receivable |  |  | 66 |  |  |  | 7 |  |
| Other current assets |  |  | 392 |  |  |  | 221 |  |
| Notes due from Western Digital Corporation |  |  | — |  |  |  | 102 |  |
| Total current assets |  |  | 5,086 |  |  |  | 3,548 |  |
| Property, plant and equipment, net |  |  | 619 |  |  |  | 791 |  |
| Notes receivable and investments in Flash Ventures |  |  | 654 |  |  |  | 1,001 |  |
| Goodwill |  |  | 4,999 |  |  |  | 7,207 |  |
| Deferred tax assets |  |  | 58 |  |  |  | 96 |  |
| Income tax receivable, non-current |  |  | 80 |  |  |  | 11 |  |
| Other non-current assets |  |  | 1,489 |  |  |  | 852 |  |
| Total assets |  | $ | 12,985 |  |  | $ | 13,506 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 366 |  |  | $ | 357 |  |
| Accounts payable to related parties |  |  | 400 |  |  |  | 313 |  |
| Accrued expenses |  |  | 425 |  |  |  | 424 |  |
| Accrued compensation |  |  | 173 |  |  |  | 195 |  |
| Income tax payables |  |  | 43 |  |  |  | 20 |  |
| Notes due to Western Digital Corporation |  |  | — |  |  |  | 814 |  |
| Current portion of long-term debt |  |  | 20 |  |  |  | — |  |
| Total current liabilities |  |  | 1,427 |  |  |  | 2,123 |  |
| Deferred tax liabilities |  |  | 17 |  |  |  | 15 |  |
| Long-term debt |  |  | 1,829 |  |  |  | — |  |
| Other liabilities |  |  | 496 |  |  |  | 286 |  |
| Total liabilities |  |  | 3,769 |  |  |  | 2,424 |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, $0.01 par value; authorized — 450 shares; issued and outstanding — 146 shares |  | $ | 1 |  |  | $ | — |  |
| Additional paid-in capital |  |  | 11,248 |  |  |  | — |  |
| Accumulated deficit |  |  | (1,784 | ) |  |  | — |  |
| Accumulated other comprehensive loss |  |  | (249 | ) |  |  | (452 | ) |
| Net investment from Western Digital Corporation |  |  | — |  |  |  | 11,534 |  |
| Total shareholders’ equity |  |  | 9,216 |  |  |  | 11,082 |  |
| Total liabilities and shareholders’ equity |  | $ | 12,985 |  |  | $ | 13,506 |  |

[0001193125-25-180782:8k_2_02:40]
6

[0001193125-25-180782:8k_2_02:41]
SANDISK CORPORATION

[0001193125-25-180782:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-25-180782:8k_2_02:43]
(in millions, except per share amounts; unaudited)

[0001193125-25-180782:8k_2_02:44]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 27,2025 |  |  | June 28,2024 |  |  | June 27,2025 |  |  | June 28,2024 |  |
| Revenue, net |  | $ | 1,901 |  |  | $ | 1,760 |  |  | $ | 7,355 |  |  | $ | 6,663 |  |
| Cost of revenue |  |  | 1,403 |  |  |  | 1,124 |  |  |  | 5,143 |  |  |  | 5,591 |  |
| Gross profit |  |  | 498 |  |  |  | 636 |  |  |  | 2,212 |  |  |  | 1,072 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 285 |  |  |  | 298 |  |  |  | 1,132 |  |  |  | 1,061 |  |
| Selling, general and administrative |  |  | 162 |  |  |  | 117 |  |  |  | 573 |  |  |  | 455 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | 1,830 |  |  |  | — |  |
| Business separation costs |  |  | 17 |  |  |  | 18 |  |  |  | 67 |  |  |  | 64 |  |
| Employee termination and other |  |  | 16 |  |  |  | 4 |  |  |  | 21 |  |  |  | (40 | ) |
| Gain on business divestiture |  |  | — |  |  |  | — |  |  |  | (34 | ) |  |  | — |  |
| Total operating expenses |  |  | 480 |  |  |  | 437 |  |  |  | 3,589 |  |  |  | 1,540 |  |
| Operating income (loss) |  |  | 18 |  |  |  | 199 |  |  |  | (1,377 | ) |  |  | (468 | ) |
| Interest and other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 11 |  |  |  | 3 |  |  |  | 22 |  |  |  | 12 |  |
| Interest expense |  |  | (41 | ) |  |  | (9 | ) |  |  | (63 | ) |  |  | (40 | ) |
| Other income (expense), net |  |  | (6 | ) |  |  | 4 |  |  |  | (61 | ) |  |  | (7 | ) |
| Total interest and other income (expense), net |  |  | (36 | ) |  |  | (2 | ) |  |  | (102 | ) |  |  | (35 | ) |
| Income (loss) before taxes |  |  | (18 | ) |  |  | 197 |  |  |  | (1,479 | ) |  |  | (503 | ) |
| Income tax expense |  |  | 5 |  |  |  | 77 |  |  |  | 162 |  |  |  | 169 |  |
| Net income (loss) |  | $ | (23 | ) |  | $ | 120 |  |  | $ | (1,641 | ) |  | $ | (672 | ) |
| Net income (loss) per common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic and diluted |  | $ | (0.16 | ) |  | $ | 0.83 |  |  | $ | (11.32 | ) |  | $ | (4.63 | ) |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic and diluted |  |  | 145 |  |  |  | 145 |  |  |  | 145 |  |  |  | 145 |  |

[0001193125-25-180782:8k_2_02:45]
7

[0001193125-25-180782:8k_2_02:46]
SANDISK CORPORATION

[0001193125-25-180782:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-25-180782:8k_2_02:48]
(in millions; unaudited)

[0001193125-25-180782:8k_2_02:49]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 27,2025 |  |  | June 28,2024 |  |  | June 27,2025 |  |  | June 28,2024 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (23 | ) |  | $ | 120 |  |  | $ | (1,641 | ) |  | $ | (672 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 36 |  |  |  | 54 |  |  |  | 163 |  |  |  | 224 |  |
| Stock-based compensation |  |  | 49 |  |  |  | 34 |  |  |  | 182 |  |  |  | 149 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | 1,830 |  |  |  | — |  |
| Deferred income taxes |  |  | (19 | ) |  |  | (19 | ) |  |  | (12 | ) |  |  | (16 | ) |
| Asset Impairment |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Gain on disposal of assets |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (60 | ) |
| Non-cash portion of impairment of cost method investments |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Unrealized foreign exchange (gain) loss |  |  | (19 | ) |  |  | 1 |  |  |  | (25 | ) |  |  | 13 |  |
| Gain on business divestiture |  |  | — |  |  |  | — |  |  |  | (34 | ) |  |  | — |  |
| Amortization of debt issuance costs and discounts |  |  | 2 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |
| Equity loss in investees, net of dividends received |  |  | 6 |  |  |  | 38 |  |  |  | 74 |  |  |  | 49 |  |
| Gain on sale of investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Other non-cash operating activities, net |  |  | 6 |  |  |  | (9 | ) |  |  | 23 |  |  |  | 87 |  |
| Settlement of accrued interest on Notes due to Western Digital Corporation |  |  | — |  |  |  | — |  |  |  | (99 | ) |  |  | — |  |
| Changes in: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (89 | ) |  |  | (120 | ) |  |  | (100 | ) |  |  | (395 | ) |
| Inventories |  |  | 81 |  |  |  | (225 | ) |  |  | (160 | ) |  |  | 314 |  |
| Accounts payable |  |  | (6 | ) |  |  | (48 | ) |  |  | 93 |  |  |  | 32 |  |
| Accounts payable to related parties |  |  | 5 |  |  |  | 3 |  |  |  | (23 | ) |  |  | 21 |  |
| Accrued expenses |  |  | 10 |  |  |  | 45 |  |  |  | 13 |  |  |  | (51 | ) |
| Accrued compensation |  |  | 59 |  |  |  | 56 |  |  |  | 21 |  |  |  | 99 |  |
| Other assets and liabilities, net |  |  | (4 | ) |  |  | (64 | ) |  |  | (224 | ) |  |  | (106 | ) |
| Net cash provided by (used in) operating activities |  |  | 94 |  |  |  | (130 | ) |  |  | 84 |  |  |  | (309 | ) |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (45 | ) |  |  | (38 | ) |  |  | (204 | ) |  |  | (166 | ) |
| Proceeds from the sale of property, plant and equipment |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 137 |  |
| Proceeds from dispositions of business |  |  | — |  |  |  | — |  |  |  | 401 |  |  |  | — |  |
| Notes receivable issuances to Flash Ventures |  |  | (59 | ) |  |  | (59 | ) |  |  | (333 | ) |  |  | (243 | ) |
| Notes receivable proceeds from Flash Ventures |  |  | 87 |  |  |  | 91 |  |  |  | 515 |  |  |  | 482 |  |
| Distributions from Flash Ventures |  |  | — |  |  |  | — |  |  |  | 176 |  |  |  | — |  |
| Strategic investments and other, net |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | (17 | ) |  |  | (3 | ) |  |  | 556 |  |  |  | 210 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Taxes paid on vested stock awards under employee stock plans |  |  | (7 | ) |  |  | — |  |  |  | (13 | ) |  |  | — |  |

[0001193125-25-180782:8k_2_02:50]
8

[0001193125-25-180782:8k_2_02:51]
| Proceeds from debt |  |  | — |  |  |  | — |  |  |  | 1,970 |  |  |  | — |  |
| Repayments of debt |  |  | (100 | ) |  |  | — |  |  |  | (100 | ) |  |  | — |  |
| Debt issuance costs |  |  | — |  |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| Proceeds from borrowings on Notes due to Western Digital Corporation |  |  | — |  |  |  | — |  |  |  | 550 |  |  |  | — |  |
| Proceeds from principal repayments on Notes due from Western Digital Corporation |  |  | — |  |  |  | 14 |  |  |  | 101 |  |  |  | 14 |  |
| Repayments of principal on Notes due to Western Digital Corporation |  |  | — |  |  |  | — |  |  |  | (76 | ) |  |  | (102 | ) |
| Transfers from (to) Western Digital Corporation |  |  | — |  |  |  | 54 |  |  |  | (1,887 | ) |  |  | 394 |  |
| Origination of Notes due from Western Digital Corporation |  |  | — |  |  |  | 17 |  |  |  | — |  |  |  | (170 | ) |
| Net cash provided by (used in) financing activities |  |  | (102 | ) |  |  | 85 |  |  |  | 518 |  |  |  | 136 |  |
| Effect of exchange rate changes on cash |  |  | (1 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | (1 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (26 | ) |  |  | (49 | ) |  |  | 1,153 |  |  |  | 36 |  |
| Cash and cash equivalents, beginning of period |  |  | 1,507 |  |  |  | 377 |  |  |  | 328 |  |  |  | 292 |  |
| Cash and cash equivalents, end of period |  | $ | 1,481 |  |  | $ | 328 |  |  | $ | 1,481 |  |  | $ | 328 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 37 |  |  | $ | 2 |  |  | $ | 139 |  |  | $ | 12 |  |
| Cash received for interest |  |  | — |  |  |  | 2 |  |  |  | 2 |  |  |  | 10 |  |
| Cash paid for income taxes |  |  | 30 |  |  |  | — |  |  |  | 40 |  |  |  | — |  |
| Non-cash transfers of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Notes due to (from) Western Digital Corporation |  |  | — |  |  |  | — |  |  |  | 1,223 |  |  |  | (113 | ) |
| Other assets and liabilities, net, from Western Digital Corporation |  |  | — |  |  |  | — |  |  |  | 105 |  |  |  | — |  |
| Contribution of equity interest in Unis Venture from Western Digital Corporation |  |  | — |  |  |  | — |  |  |  | 61 |  |  |  | — |  |
| Property, plant and equipment from Western Digital Corporation |  |  | — |  |  |  | 6 |  |  |  | 27 |  |  |  | 11 |  |
| Tax balances to Western Digital Corporation |  |  | — |  |  |  | (19 | ) |  |  | 8 |  |  |  | (17 | ) |
| Tax indemnification liability to Western Digital Corporation |  |  | — |  |  |  | — |  |  |  | (112 | ) |  |  | — |  |

[0001193125-25-180782:8k_2_02:52]
9

[0001193125-25-180782:8k_2_02:53]
SANDISK CORPORATION

[0001193125-25-180782:8k_2_02:54]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001193125-25-180782:8k_2_02:55]
(in millions; unaudited)

[0001193125-25-180782:8k_2_02:56]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 27,2025 |  |  | March 28,2025 |  |  | June 28,2024 |  |  | June 27,2025 |  |  | June 28,2024 |  |
| GAAP gross profit |  | $ | 498 |  |  | $ | 382 |  |  | $ | 636 |  |  | $ | 2,212 |  |  | $ | 1,072 |  |
| Stock-based compensation expense |  |  | 4 |  |  |  | 3 |  |  |  | 5 |  |  |  | 16 |  |  |  | 20 |  |
| Recoveries of contamination related charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (36 | ) |
| Non-GAAP gross profit |  | $ | 502 |  |  | $ | 385 |  |  | $ | 641 |  |  | $ | 2,228 |  |  | $ | 1,056 |  |
| GAAP operating expenses |  | $ | 480 |  |  | $ | 2,263 |  |  | $ | 437 |  |  | $ | 3,589 |  |  | $ | 1,540 |  |
| Gain on business divestiture |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |  | — |  |
| Stock-based compensation expense |  |  | (45 | ) |  |  | (41 | ) |  |  | (29 | ) |  |  | (166 | ) |  |  | (129 | ) |
| Employee termination and other |  |  | (16 | ) |  |  | — |  |  |  | (4 | ) |  |  | (21 | ) |  |  | 40 |  |
| Business separation costs |  |  | (17 | ) |  |  | (9 | ) |  |  | (18 | ) |  |  | (67 | ) |  |  | (64 | ) |
| Goodwill impairment |  |  | — |  |  |  | (1,830 | ) |  |  | — |  |  |  | (1,830 | ) |  |  | — |  |
| Strategic review |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (20 | ) |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Non-GAAP operating expenses |  | $ | 402 |  |  | $ | 383 |  |  | $ | 386 |  |  | $ | 1,539 |  |  | $ | 1,365 |  |
| GAAP operating income (loss) |  | $ | 18 |  |  | $ | (1,881 | ) |  | $ | 199 |  |  | $ | (1,377 | ) |  | $ | (468 | ) |
| Gross profit adjustments |  |  | 4 |  |  |  | 3 |  |  |  | 5 |  |  |  | 16 |  |  |  | (16 | ) |
| Operating expense adjustments |  |  | 78 |  |  |  | 1,880 |  |  |  | 51 |  |  |  | 2,050 |  |  |  | 175 |  |
| Non-GAAP operating income (loss) |  | $ | 100 |  |  | $ | 2 |  |  | $ | 255 |  |  | $ | 689 |  |  | $ | (309 | ) |
| GAAP interest and other expense, net |  | $ | (36 | ) |  | $ | (20 | ) |  | $ | (2 | ) |  | $ | (102 | ) |  | $ | (35 | ) |
| Interest and other expense, net adjustments |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |  |  | (7 | ) |  |  | (2 | ) |
| Non-GAAP interest and other expense, net |  | $ | (37 | ) |  | $ | (22 | ) |  | $ | (3 | ) |  | $ | (109 | ) |  | $ | (37 | ) |
| GAAP income tax expense |  | $ | 5 |  |  | $ | 32 |  |  | $ | 77 |  |  | $ | 162 |  |  | $ | 169 |  |
| Income tax adjustments |  |  | 16 |  |  |  | (9 | ) |  |  | (5 | ) |  |  | (22 | ) |  |  | (13 | ) |
| Non-GAAP income tax expense |  | $ | 21 |  |  | $ | 23 |  |  | $ | 72 |  |  | $ | 140 |  |  | $ | 156 |  |

[0001193125-25-180782:8k_2_02:57]
10

[0001193125-25-180782:8k_2_02:58]
SANDISK CORPORATION

[0001193125-25-180782:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001193125-25-180782:8k_2_02:60]
(in millions, except per share amounts; unaudited)

[0001193125-25-180782:8k_2_02:61]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 27,2025 |  |  | March 28,2025 |  |  | June 28,2024 |  |  | June 27,2025 |  |  | June 28,2024 |  |
| GAAP net income (loss) |  | $ | (23 | ) |  | $ | (1,933 | ) |  | $ | 120 |  |  | $ | (1,641 | ) |  | $ | (672 | ) |
| Goodwill impairment |  |  | — |  |  |  | 1,830 |  |  |  | — |  |  |  | 1,830 |  |  |  | — |  |
| Stock-based compensation expense |  |  | 49 |  |  |  | 44 |  |  |  | 34 |  |  |  | 182 |  |  |  | 149 |  |
| Business separation costs |  |  | 17 |  |  |  | 9 |  |  |  | 18 |  |  |  | 67 |  |  |  | 64 |  |
| Employee termination and other |  |  | 16 |  |  |  | — |  |  |  | 4 |  |  |  | 21 |  |  |  | (40 | ) |
| Recoveries of contamination related charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (36 | ) |
| Strategic review |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20 |  |
| Gain on business divestiture |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (34 | ) |  |  | — |  |
| Other |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |  |  | (7 | ) |  |  | — |  |
| Income tax adjustments |  |  | (16 | ) |  |  | 9 |  |  |  | 5 |  |  |  | 22 |  |  |  | 13 |  |
| Non-GAAP net income (loss) |  | $ | 42 |  |  | $ | (43 | ) |  | $ | 180 |  |  | $ | 440 |  |  | $ | (502 | ) |
| Diluted income (loss) per common share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | (0.16 | ) |  | $ | (13.33 | ) |  | $ | 0.83 |  |  | $ | (11.32 | ) |  | $ | (4.63 | ) |
| Non-GAAP |  | $ | 0.29 |  |  | $ | (0.30 | ) |  | $ | 1.24 |  |  | $ | 2.99 |  |  | $ | (3.46 | ) |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  |  | 145 |  |  |  | 145 |  |  |  | 145 |  |  |  | 145 |  |  |  | 145 |  |
| Non-GAAP |  |  | 147 |  |  |  | 145 |  |  |  | 145 |  |  |  | 147 |  |  |  | 145 |  |
| Cash flows |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow provided by (used in) operating activities |  | $ | 94 |  |  | $ | 26 |  |  | $ | (130 | ) |  | $ | 84 |  |  | $ | (309 | ) |
| Purchases of property, plant and equipment, net |  |  | (45 | ) |  |  | (44 | ) |  |  | (35 | ) |  |  | (204 | ) |  |  | (29 | ) |
| Free cash flow |  |  | 49 |  |  |  | (18 | ) |  |  | (165 | ) |  |  | (120 | ) |  |  | (338 | ) |
| Activity related to Flash Ventures, net |  |  | 28 |  |  |  | 238 |  |  |  | 32 |  |  |  | 358 |  |  |  | 239 |  |
| Adjusted free cash flow |  | $ | 77 |  |  | $ | 220 |  |  | $ | (133 | ) |  | $ | 238 |  |  | $ | (99 | ) |

[0001193125-25-180782:8k_2_02:62]
11

[0001193125-25-180782:8k_2_02:63]
To supplement the condensed consolidated financial statements presented in accordance with GAAP, the table
above sets forth Non-GAAP gross profit; Non-GAAP operating expenses; Non-GAAP operating income (loss); Non-GAAP interest and other expense, net; Non-GAAP income tax expense; Non-GAAP net income (loss);
Non-GAAP diluted income (loss) per common share; Non-GAAP diluted weighted average shares outstanding; Free cash flow; and Adjusted free cash flow (collectively, the “Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or alternatives for measures prepared in accordance with GAAP and may be different from
similarly titled Non-GAAP measures used by other companies. The Company believes the presentation of these Non-GAAP measures, when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors for measuring the Company’s earnings performance and comparing it against prior periods. Specifically, the Company believes these
Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains, and losses that the Company believes are not indicative of its core operating results or
because they are consistent with the financial models and estimates published by many analysts who follow the Company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable,
goodwill impairment, stock-based compensation expense, business separation costs, employee termination and other, recoveries of contamination related charges, expenses related to our strategic review, gain on business divestiture, other adjustments,
and income tax adjustments. The Company believes these measures, along with the related reconciliations to the most directly comparable GAAP measures, provide additional detail and comparability for assessing the Company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the Company’s performance and planning and forecasting future periods. These measures should be considered in addition to
results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0001193125-25-180782:8k_2_02:64]
As described above, the Company
excludes the following items from its Non-GAAP measures:

[0001193125-25-180782:8k_2_02:65]
Goodwill impairment. After the completion of the
separation, in the third quarter of fiscal 2025, the Company identified potential impairment indicators related to the trading price of the Company’s common stock and resulting market capitalization that warranted a quantitative impairment
analysis of long-lived assets and goodwill. Management performed a quantitative impairment analysis and determined that the carrying value of the reporting unit exceeded its fair value, resulting in the recognition of a $1.8 billion impairment
charge for the three months ended March 28, 2025. The Company believes this charge does not reflect the Company’s operating results and is not indicative of the underlying performance of the business.

[0001193125-25-180782:8k_2_02:66]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based
compensation expense, the subjective assumptions involved in those determinations and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding stock-based compensation
expense enhances the ability of management and investors to understand and assess the underlying performance of the business over time and compare it against the Company’s peers, a majority of whom also exclude stock-based compensation expense
from their Non-GAAP results.

[0001193125-25-180782:8k_2_02:67]
12

[0001193125-25-180782:8k_2_02:68]
Business separation costs. On October 30, 2023, Western Digital Corporation (“WDC”)
announced that its board of directors (the “WDC Board of Directors”) authorized management to pursue a plan to separate the Company into an independent public company. The separation received final approval by the WDC Board of Directors
and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly-owned by WDC. As a result of the plan, the Company incurred separation and transition costs through the completion of the separation of the
companies. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations. The Company believes these charges do not reflect the Company’s operating results and that
they are not indicative of the underlying results of its business.

[0001193125-25-180782:8k_2_02:69]
Employee termination and other. From time to time, in order to realign the
Company’s operations with anticipated market demand, the Company may terminate employees and/or restructure its operations. From time to time, the Company may also incur charges from the impairment of long-lived assets. In addition, the
Company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods as well as from taking actions to reduce the amount of capital invested in facilities, including the
sale-leaseback of facilities. These charges or credits are inconsistent in amount and frequency, and the Company believes they are not indicative of the underlying performance of its business.

[0001193125-25-180782:8k_2_02:70]
Recoveries of contamination related charges. In February 2022, a contamination of certain materials used in the Company’s manufacturing process
occurred and affected production at Flash Ventures manufacturing facilities. The contamination resulted in scrapped inventory, rework costs, decontamination and other expenses needed to restore the facilities to normal capacity. During the second
quarter of fiscal year 2024, the Company received insurance recoveries for losses from contamination-related charges. The charges and recoveries are inconsistent in amount and frequency, and the Company believes they are not part of the ongoing
production operation of its business.

[0001193125-25-180782:8k_2_02:71]
Strategic review. The Company incurred expenses associated with its review of potential strategic
alternatives aimed at further optimizing the long-term value for stockholders. The Company believes these charges do not reflect the Company’s operating results and that they are not indicative of the underlying performance of its business.

[0001193125-25-180782:8k_2_02:72]
Gain on business divestiture. In connection with the Company’s strategic decision to outsource the manufacturing of certain components and
assemblies, on September 28, 2024, the Company completed the sale of 80% of its equity interest in one of its manufacturing subsidiaries. The transaction resulted in a discrete gain, which the Company believes it is not indicative of the
underlying performance of its ongoing business operations.

[0001193125-25-180782:8k_2_02:73]
Other adjustments. From time to time, the Company incurs charges or gains that the
Company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0001193125-25-180782:8k_2_02:74]
13

[0001193125-25-180782:8k_2_02:75]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a
forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax
adjustments. The income tax adjustments also include the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments
are excluded because the Company believes that they are not indicative of the underlying performance of its ongoing business.

[0001193125-25-180782:8k_2_02:76]
Additionally, free cash
flow is defined as cash flows provided by (used in) operating activities less purchases of property, plant and equipment, net, and adjusted free cash flow is defined as free cash flow plus the activity related to Flash Ventures, net. The Company
considers free cash flow and adjusted free cash flow generated in any period to be useful indicators of cash that is available for strategic opportunities, including, among others, investing in the Company’s business, making strategic
acquisitions, repaying debt and strengthening the balance sheet.

[0001193125-25-180782:8k_2_02:77]
| Company Contacts: |
| Sandisk Corporation |  |  |
| Investor Contact: |  | Media Contact: |
| Ivan Donaldson |  | Media Relations |
| E: ivan.donaldson@sandisk.com |  | mediainquiries@sandisk.com |
| investors@sandisk.com |  |  |

[0001193125-25-180782:8k_2_02:78]
14
