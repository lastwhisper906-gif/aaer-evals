# SNDK note change history — 0002023554-25-000004 → 0002023554-25-000027


## sndk:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0002023554-25-000027:note_history:1]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 37 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 38 |  |  | 5 |  |
| Notes receivable, Flash Forward | 296 |  |  | 485 |  |
| Investment in Flash Partners | 46 |  |  | 148 |  |
| Investment in Flash Alliance | 116 |  |  | 219 |  |
| Investment in Flash Forward | 129 |  |  | 143 |  |
| Total notes receivable and investments in Flash Ventures | $ | 662 |  |  | $ | 1,001 |  |
  (was, 2025-03-07, similarity 0.9848):
[0002023554-25-000004:note_history:1]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 72 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 5 |  |
| Notes receivable, Flash Forward | 476 |  |  | 485 |  |
| Investment in Flash Partners | 41 |  |  | 148 |  |
| Investment in Flash Alliance | 118 |  |  | 219 |  |
| Investment in Flash Forward | 129 |  |  | 143 |  |
| Total notes receivable and investments in Flash Ventures | $ | 871 |  |  | $ | 1,001 |  |

- changed (2025-05-12):
[0002023554-25-000027:note_history:2]
During the three and nine months ended March 28, 2025, and March 29, 2024, the Company made net payments to Flash Ventures of $0.9 billion and $2.9 billion and $0.7 billion and $2.5 billion, respectively, for purchases of flash-based memory wafers and net loans.
  (was, 2025-03-07, similarity 0.8272):
[0002023554-25-000004:note_history:2]
During the three and six months ended December 27, 2024, and December 29, 2023, the Company made net payments to Flash Ventures of $1.1 billion and $2.0 billion and $0.8 billion and $1.8 billion, respectively, for purchased flash-based memory wafers and net loans.

- changed (2025-05-12):
[0002023554-25-000027:note_history:3]
As of March 28, 2025, and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $283 million and $313 million, respectively.
  (was, 2025-03-07, similarity 0.9673):
[0002023554-25-000004:note_history:3]
As of December 27, 2024, and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $252 million and $313 million, respectively.

- changed (2025-05-12):
[0002023554-25-000027:note_history:4]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 28, 2025, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.
  (was, 2025-03-07, similarity 0.9851):
[0002023554-25-000004:note_history:4]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at December 27, 2024, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- changed (2025-05-12):
[0002023554-25-000027:note_history:5]
|  | March 28,2025 |
|  | (in millions) |
| Notes receivable | $ | 371 |  |
| Equity investments | 291 |  |
| Operating lease guarantees | 1,379 |  |
| Inventory and prepayments | 1,318 |  |
| Maximum estimable loss exposure | $ | 3,359 |  |
  (was, 2025-03-07, similarity 0.9742):
[0002023554-25-000004:note_history:5]
|  | December 27,2024 |
|  | (in millions) |
| Notes receivable | $ | 583 |  |
| Equity investments | 288 |  |
| Operating lease guarantees | 1,343 |  |
| Inventory and prepayments | 1,393 |  |
| Maximum estimable loss exposure | $ | 3,607 |  |

- added (2025-05-12):
[0002023554-25-000027:note_history:6]
Flash Ventures has historically operated at nearly 100% of its manufacturing capacity. During the three months ended March 28, 2025 and first two quarters of 2024, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and nine months ended March 28, 2025 the Company incurred costs of $24 million, and during the nine months ended March 29, 2024 the Company incurred costs of $249 million, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended March 29, 2024.

- changed (2025-05-12):
[0002023554-25-000027:note_history:7]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of March 28, 2025, $938 million, with $127 million recorded within Other current assets and $811 million recorded within Other non-current assets in the Condensed Consolidated Balance Sheets, remain to be credited against future building depreciation charges. As of March 28, 2025, the Company is also committed to making additional building depreciation prepayments of $292 million, based on the Japanese yen to U.S. dollars exchange rate of ¥150.43 as of such date, payable as follows: $39 million for the remaining of fiscal year 2025, $31 million in fiscal year 2026, $116 million in fiscal year 2027, $93 million in fiscal year 2028 and $13 million in fiscal year 2029. As of March 28, 2025, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $263 million at varying dates through fiscal year 2035.
  (was, 2025-03-07, similarity 0.982):
[0002023554-25-000004:note_history:7]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of December 27, 2024, $944 million, with $124 million recorded within Other current assets and $840 million recorded within Other non-current assets in the Condensed Combined Balance Sheets, remain to be credited against future building depreciation charges. As of December 27, 2024, the Company is also committed to making additional building depreciation prepayments of $303 million, based on the Japanese yen to U.S. dollars exchange rate of ¥157.86 as of such date, payable as follows: $60 million for the remaining of fiscal year 2025, $30 million in fiscal year 2026, $111 million in fiscal year 2027, $89 million in fiscal year 2028 and $13 million in fiscal year 2029. As of December 27, 2024, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $107 million at varying dates through fiscal year 2035.

- changed (2025-05-12):
[0002023554-25-000027:note_history:8]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for the remaining three months of 2025 are $40 million.
  (was, 2025-03-07, similarity 0.7878):
[0002023554-25-000004:note_history:8]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments are immaterial to the Condensed Combined Financial Statements.

- changed (2025-05-12):
[0002023554-25-000027:note_history:9]
Off-Balance Sheet Liabilities. Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.
  (was, 2025-03-07, similarity 0.9982):
[0002023554-25-000004:note_history:9]
Off-Balance Sheet Liabilities. Flash Ventures sells to and leases back from a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

- changed (2025-05-12):
[0002023554-25-000027:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 28, 2025:
  (was, 2025-03-07, similarity 0.9786):
[0002023554-25-000004:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024:

- changed (2025-05-12):
[0002023554-25-000027:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 28, 2025:
  (was, 2025-03-07, similarity 0.9811):
[0002023554-25-000004:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of December 27, 2024:

- changed (2025-05-12):
[0002023554-25-000027:note_history:12]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| Remaining three months of 2025 | $ | 104 |  |  | $ | 26 |  |  | $ | 130 |  |
| 2026 | 462 |  |  | 119 |  |  | 581 |  |
| 2027 | 227 |  |  | 102 |  |  | 329 |  |
| 2028 | 102 |  |  | 98 |  |  | 200 |  |
| 2029 | 36 |  |  | 53 |  |  | 89 |  |
| 2030 | 9 |  |  | 41 |  |  | 50 |  |
| Total guarantee obligations | $ | 940 |  |  | $ | 439 |  |  | $ | 1,379 |  |
  (was, 2025-03-07, similarity 0.9906):
[0002023554-25-000004:note_history:12]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| Remaining six months of 2025 | $ | 201 |  |  | $ | 49 |  |  | $ | 250 |  |
| 2026 | 406 |  |  | 113 |  |  | 519 |  |
| 2027 | 198 |  |  | 97 |  |  | 295 |  |
| 2028 | 83 |  |  | 93 |  |  | 176 |  |
| 2029 | 25 |  |  | 50 |  |  | 75 |  |
| 2030 | 4 |  |  | 24 |  |  | 28 |  |
| Total guarantee obligations | $ | 917 |  |  | $ | 426 |  |  | $ | 1,343 |  |

- changed (2025-05-12):
[0002023554-25-000027:note_history:13]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of March 28, 2025, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2025-03-07, similarity 0.9754):
[0002023554-25-000004:note_history:13]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of December 27, 2024, no amounts have been accrued in the Condensed Combined Financial Statements with respect to these indemnification agreements.

- changed (2025-05-12):
[0002023554-25-000027:note_history:14]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”) an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.
  (was, 2025-03-07, similarity 0.9987):
[0002023554-25-000004:note_history:14]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”) an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly-listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

- added (2025-05-12):
[0002023554-25-000027:note_history:15]
Proceeds from the sale, including working capital adjustments, were $659 million (pre-tax). On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million and expects to receive the remaining $187 million pre-tax proceeds in five equal installments of approximately $37 million on September 28 of each year through September 28, 2029. As of March 28, 2025, the outstanding consideration receivable was recognized at its present value of $166 million, with $36 million classified as Other current assets and $130 million classified as Other non-current assets in the Condensed Consolidated Balance Sheets. The remaining present value discount of $21 million as of March 28, 2025 will be recognized using the effective interest method over the next five years as Interest income in the Condensed Consolidated Statements of Operations.

- changed (2025-05-12):
[0002023554-25-000027:note_history:16]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other expense, net in the Condensed Consolidated Statements of Operations. As of March 28, 2025, the 20% retained interest in SDSS was valued at $160 million.
  (was, 2025-03-07, similarity 0.9024):
[0002023554-25-000004:note_history:16]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Combined Balance Sheets. The Company’s 20% interest in the earnings of SDSS will be recognized one quarter in arrears and will be reported in Other expense, net in the Condensed Combined Statements of Operations.

- changed (2025-05-12):
[0002023554-25-000027:note_history:17]
The Transaction resulted in a pre-tax gain of $34 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $382 million of goodwill that was allocated to SDSS.
  (was, 2025-03-07, similarity 0.9892):
[0002023554-25-000004:note_history:17]
The Transaction resulted in a pre-tax gain of $34 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $382 million of goodwill allocated to SDSS.

- changed (2025-05-12):
[0002023554-25-000027:note_history:18]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT”) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if SDSS fails to meet its minimum annual commitment. The Supply Agreement also provides that if SDSS purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the three and nine months ended March 28, 2025, the Company made purchases of $108 million and $219 million, respectively, under the Supply Agreement and had a $112 million accounts payable balance due to SDSS as of March 28, 2025.
  (was, 2025-03-07, similarity 0.9095):
[0002023554-25-000004:note_history:18]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT”) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if SDSS fails to meet its minimum annual commitment. The Supply Agreement also provides that if SDSS purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the six months ended December 27, 2024, the Company made purchases of $111 million under the Supply Agreement and had an accounts payable balance due to SDSS of $117 million as of December 27, 2024.

- added (2025-05-12):
[0002023554-25-000027:note_history:19]
On January 24, 2025, the Company and WDC entered into an equity transfer agreement (the “Equity Transfer Agreement”) to transfer WDC’s entire equity interest in its venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to the Company. The Unis Venture is 49% owned by the Company and 51% owned by Unis. The Unis Venture markets and sells the Company’s products in China and develops data storage systems for the Chinese market.

- added (2025-05-12):
[0002023554-25-000027:note_history:20]
Prior to the execution of the Equity Transfer Agreement, the Unis Venture was not historically managed as a component of the Company and as such, the related equity method investment was not reflected within our Condensed Consolidated Financial Statements. After the execution of the Equity Transfer Agreement, the Company accounts for its investment in the Unis Venture under the equity method of accounting. The Company’s 49% interest in the earnings of the Unis Venture will be recognized one quarter in arrears from the date the Unis Venture was transferred to the Company and will be reported in Other expense, net in the Condensed Consolidated Statements of Operations.

- added (2025-05-12):
[0002023554-25-000027:note_history:21]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the three and nine months ended March 28, 2025, and March 29, 2024, the Company recognized approximately 1% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 2% and 4% of Accounts receivable, net, as of March 28, 2025 and June 28, 2024, respectively.

- added (2025-05-12):
[0002023554-25-000027:note_history:22]
Separation and Distribution Agreement and Other Related Party Transactions with WDC

- added (2025-05-12):
[0002023554-25-000027:note_history:23]
As described in Note 1, Organization and Basis of Presentation of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, on February 21, 2025, in connection with the separation, the Company entered into several agreements that provide a framework for Sandisk’s relationship with WDC after the separation. These include, but are not limited to, the following, which were active and in effect during the third quarter of fiscal year 2025:

- added (2025-05-12):
[0002023554-25-000027:note_history:24]
•Separation and Distribution Agreement - The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Condensed Combined Balance Sheets as of December 27, 2024 were retained by WDC and certain assets and liabilities not included in the Company’s Condensed Combined Balance Sheets as of December 27, 2024 were transferred to the Company as of the date of the separation.

- added (2025-05-12):
[0002023554-25-000027:note_history:25]
Separation-related adjustments resulted in a decrease to net assets and total equity of $1.1 billion and are reflected in the “Net transfers from (to) WDC, including spin-off related adjustments” line item of the Condensed Consolidated Statements of Shareholders’ Equity.

- added (2025-05-12):
[0002023554-25-000027:note_history:26]
•Transition Services Agreement – The Transition Services Agreement (“TSA”) governs the provision of transition services from WDC to Sandisk, and from Sandisk to WDC and its affiliates, on an interim, transitional basis following the separation.

- added (2025-05-12):
[0002023554-25-000027:note_history:27]
For the three months ended March 28, 2025, the Company recognized $2 million in expenses related to the TSA, and the Company expects to recognize an additional expense related to the TSA of approximately $10 million during the next twelve months.

- added (2025-05-12):
[0002023554-25-000027:note_history:28]
•Tax Matters Agreement - The Tax Matters Agreement governs, among other things, WDC’s and the Company’s respective rights, responsibilities and obligations after the spin-off with respect to tax liabilities and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings and other matters regarding taxes. In addition, the Tax Matters Agreement imposes certain restrictions on the Company and its subsidiaries (including restrictions on share issuances, business combinations, sales of assets, and similar transactions) that are designed to preserve the tax-free status of the spin-off and certain related transactions.

- added (2025-05-12):
[0002023554-25-000027:note_history:29]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently reduced by approximately $2 million reflecting the outstanding balance as of March 28, 2025. The remaining tax indemnification liability of $110 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of March 28, 2025.

- changed (2025-05-12):
[0002023554-25-000027:note_history:30]
Notes Due to (from) Western Digital Corporation
  (was, 2025-03-07, similarity 0.6027):
[0002023554-25-000004:note_history:30]
Notes Due to (from) Parent

- changed (2025-05-12):
[0002023554-25-000027:note_history:31]
Prior to the separation, the Company received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additionally, cash generated by the Company was lent from time to time via promissory notes to certain of WDC’s subsidiaries for use in general corporate purposes. Outstanding balances due under these financing arrangements were due on demand.
  (was, 2025-03-07, similarity 0.9968):
[0002023554-25-000004:note_history:31]
Prior to the separation, the Company received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additionally, cash generated by the Company was lent from time to time via promissory notes to certain of WDC’s subsidiaries for use in general corporate purposes. Outstanding balances due under these financing arrangements are due on demand.

- added (2025-05-12):
[0002023554-25-000027:note_history:32]
Prior to the separation, the Company had outstanding borrowings due to WDC’s subsidiaries of $553 million, inclusive of interest payable. As part of the separation, WDC contributed $550 million to the Company, and the Company repaid $6 million in cash, which included interest accrued until the date of the separation.

- changed (2025-05-12):
[0002023554-25-000027:note_history:33]
The following presents Interest expense and Interest income on notes due to (from) Western Digital Corporation, which were recorded within Interest expense and Interest income in the Condensed Consolidated Statements of Operations for the periods presented:
  (was, 2025-03-07, similarity 0.8178):
[0002023554-25-000004:note_history:33]
The following presents interest expense and interest income on notes due to (from) Parent, which have been recorded within Interest expense and Interest income in the Condensed Combined Statements of Operations for the periods presented:

- added (2025-05-12):
[0002023554-25-000027:note_history:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Interest expense on notes due to Western Digital Corporation | $ | 3 |  |  | $ | 9 |  |  | $ | 7 |  |  | $ | 29 |  |
| Interest (income) on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |  | $ | (4) |  |

- added (2025-05-12):
[0002023554-25-000027:note_history:35]
Prior to the separation, WDC provided various corporate services to the Company in the ordinary course of business, including executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue or other relevant measures. Management believes the basis on which the expenses were allocated to be a reasonable reflection of the utilization of services provided to us or the benefit received by us.

- changed (2025-05-12):
[0002023554-25-000027:note_history:36]
Effective at the beginning of the second quarter of fiscal year 2025, the Company was operationally separated from the operations that were ultimately retained by WDC following completion of the spin-off transaction. In connection with this operational separation, personnel serving the Company in shared service functions were transferred into legal entities dedicated to the Company, and substantially all assets, liabilities, and contracts pertaining to operations of the Company were transferred to legal entities dedicated to the Company as well. Accordingly, there was a substantial reduction in the pool of shared corporate overhead costs of WDC that were subject to allocation in the second and third quarters of fiscal year 2025.
  (was, 2025-03-07, similarity 0.9924):
[0002023554-25-000004:note_history:36]
Effective at the beginning of the second quarter of fiscal year 2025, the Company was operationally separated from the operations that were ultimately retained by WDC following completion of the spin-off transaction. In connection with this operational separation, personnel serving the Company in shared service functions were transferred into legal entities dedicated to the Company, and substantially all assets, liabilities, and contracts pertaining to operations of the Company were transferred to legal entities dedicated to the Company as well. Accordingly, there was a substantial reduction in the pool of shared corporate overhead costs of WDC that were subject to allocation in the second quarter of fiscal year 2025.

- changed (2025-05-12):
[0002023554-25-000027:note_history:37]
The table below summarizes the impact of expense allocations from WDC within the Condensed Consolidated Statements of Operations for the periods presented:
  (was, 2025-03-07, similarity 0.9673):
[0002023554-25-000004:note_history:37]
The table below summarizes the impact of expense allocations from WDC within the Condensed Combined Statements of Operations for the periods presented:

- changed (2025-05-12):
[0002023554-25-000027:note_history:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 190 |  |  | $ | 189 |  |  | $ | 520 |  |
| Selling general, and administrative | 10 |  |  | 109 |  |  | 158 |  |  | 328 |  |
| Business separation costs | 9 |  |  | — |  |  | 50 |  |  | — |  |
| Employee termination and other charges | — |  |  | 2 |  |  | 5 |  |  | (44) |  |
| Total allocation of Corporate Expenses | $ | 19 |  |  | $ | 301 |  |  | $ | 402 |  |  | $ | 804 |  |
  (was, 2025-03-07, similarity 0.8175):
[0002023554-25-000004:note_history:38]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Research and development | $ | 2 |  |  | $ | 161 |  |  | $ | 189 |  |  | $ | 330 |  |
| Selling general, and administrative | 35 |  |  | 107 |  |  | 148 |  |  | 219 |  |
| Business separation costs | 21 |  |  | 34 |  |  | 41 |  |  | 34 |  |
| Employee termination and other charges | 3 |  |  | 13 |  |  | 5 |  |  | (46) |  |
| Total allocation of Corporate Expenses | $ | 61 |  |  | $ | 315 |  |  | $ | 383 |  |  | $ | 537 |  |

- changed (2025-05-12):
[0002023554-25-000027:note_history:39]
Our historical financial statements do not purport to reflect what results of operations, financial position, equity or cash flows would have been if we had operated as a standalone company during the periods presented.
  (was, 2025-03-07, similarity 0.9977):
[0002023554-25-000004:note_history:39]
Our historical financial statements do not purport to reflect what results of operations, financial position, equity or cash flows would have been if we had operated as a stand-alone company during the periods presented.

- changed (2025-05-12):
[0002023554-25-000027:note_history:40]
Prior to the separation, WDC provided funding for our operating and investing activities, including pooled cash managed by WDC’s treasury, to fund operating expenses and capital expenditures. WDC also directly collected certain of our receivables. These activities were reflected as a component of the Net investment from Western Digital Corporation, and this arrangement is not reflective of the manner in which we would operate on a standalone company separate from WDC during the periods presented.
  (was, 2025-03-07, similarity 0.8528):
[0002023554-25-000004:note_history:40]
Prior to the separation, WDC provided funding for our operating and investing activities, including pooled cash managed by WDC’s treasury, to fund operating expenses and capital expenditures. WDC also directly collected certain of our receivables. These activities are reflected as a component of the Parent’s net investment, and this arrangement is not reflective of the manner in which we would operate on a stand-alone company separate from WDC during the periods presented.

- changed (2025-05-12):
[0002023554-25-000027:note_history:41]
Western Digital Corporation Net Investment
  (was, 2025-03-07, similarity 0.6479):
[0002023554-25-000004:note_history:41]
Parent Company Net Investment

- changed (2025-05-12):
[0002023554-25-000027:note_history:42]
Prior to the separation, the Net investment from Western Digital Corporation on the Condensed Consolidated Balance Sheets represented WDC’s historical investment in the Company, the net effect of transactions with and allocations from WDC, the Company’s retained earnings and the allocation to the Company of cumulative effect adjustments from the adoption of new accounting standards.
  (was, 2025-03-07, similarity 0.7521):
[0002023554-25-000004:note_history:42]
Parent company net investment on the Condensed Combined Balance Sheets represents WDC’s historical investment in the Company, the net effect of transactions with and allocations from WDC, the Company’s retained earnings and the allocation to the Company of cumulative effect adjustments from the adoption of new accounting standards.

- changed (2025-05-12):
[0002023554-25-000027:note_history:43]
Net Transfers from (to) Western Digital Corporation
  (was, 2025-03-07, similarity 0.642):
[0002023554-25-000004:note_history:43]
Net Transfers from (to) Parent

- added (2025-05-12):
[0002023554-25-000027:note_history:44]
A reconciliation of Net transfers from (to) Western Digital Corporation on the Condensed Consolidated Statements of Shareholders’ Equity to the corresponding amounts on the Condensed Consolidated Statements of Cash Flows is as follows:

- added (2025-05-12):
[0002023554-25-000027:note_history:45]
|  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | (585) |  |  | $ | 234 |  |
| Notes due (to) from Western Digital Corporation | (1,223) |  |  | 113 |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | (105) |  |  | — |  |
| Unis venture transferred from Western Digital Corporation | (61) |  |  | — |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | (27) |  |  | (5) |  |
| Tax balances transferred from Western Digital Corporation | (8) |  |  | (2) |  |
| Accumulated other comprehensive loss transferred to Western Digital Corporation | 10 |  |  | — |  |
| Tax indemnification liability transferred to Western Digital Corporation | 112 |  |  | — |  |
| Net transfers (to) from Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | (1,887) |  |  | $ | 340 |  |

- removed (2025-05-12):
[0002023554-25-000004:note_history:46]
Flash Ventures has historically operated nearly 100% of its manufacturing capacity. During the three and six months ended December 29, 2023, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and six months ended December 29, 2023, the Company incurred costs of $107 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three and six months ended December 27, 2024.

- removed (2025-05-12):
[0002023554-25-000004:note_history:47]
WDC also has a venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture,” to market and sell the Company’s products in China and to develop data storage systems for the Chinese market in the future. On January 24, 2025, the Company and WDC entered into an equity transfer agreement (the “Equity Transfer Agreement”) to transfer WDC’s entire equity interest in the Unis Venture to us. Therefore, subsequent to the end of the second quarter of fiscal 2025, the Unis Venture will be minority owned by the Company and majority-owned by Unis.

- removed (2025-05-12):
[0002023554-25-000004:note_history:48]
Prior to the execution of the Equity Transfer Agreement, the Unis Venture was not historically managed as a component of the Company and as such, the related equity method investment is not reflected within our Condensed Combined Financial Statements. For the three and six months ended December 27, 2024, and December 29, 2023, the Company recognized approximately 1% and 1%, respectively, of its combined revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 1% and 4% of Accounts receivable, net, as of December 27, 2024 and June 28, 2024, respectively.

- removed (2025-05-12):
[0002023554-25-000004:note_history:49]
Proceeds from the sale, including working capital adjustments, were $659 million (pre-tax). On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million and expects to receive remaining pre-tax proceeds of $187 million in five installments of approximately $37 million on September 28 of each year through September 28, 2029. As of December 27, 2024, the outstanding consideration receivable was recognized at its present value of $370 million, with $243 million classified as Other current assets and $127 million classified as Other non-current assets in the Condensed Combined Balance Sheets. The present value discount of $27 million as of December 27, 2024 will be recognized using the effective interest method over the next five years as Interest income in the Condensed Combined Statements of Operations.

- removed (2025-05-12):
[0002023554-25-000004:note_history:50]
The following presents a summary of the outstanding borrowings between the Company and subsidiaries of WDC for the periods presented, inclusive of any associated interest payable or interest receivable:

- removed (2025-05-12):
[0002023554-25-000004:note_history:51]
|  |  | Interest Rate |  | December 27,2024 |  | June 28,2024 |
|  |  |  |  | (in millions) |
| Notes due from Parent |  |  |  |  |  |  |
| Revolving Credit Agreement due from Parent $101M - Oct. 3, 2019 |  | AFR Rate (USD) or TIBOR + .35% (YEN) |  | $ | — |  |  | $ | (102) |  |
| Total Notes due from Parent |  |  |  | — |  |  | (102) |  |
| Notes due to Parent |  |  |  |  |  |  |
| Revolving Credit Agreement due to Parent $1B - Sep. 27, 2024 |  | SOFR + 1.6% |  | 553 |  |  | — |  |
| Notes due to Parent $500M - Nov. 25, 2014 |  | 1-year swap + 2% |  | — |  |  | 475 |  |
| Notes Due to Parent $42B Yen - Apr. 29, 2014 |  | TIBOR + .35% |  | — |  |  | 262 |  |
| Revolving Credit Agreement due to Parent $100M - Aug. 20, 2021 |  | LIBOR Rate + 150 basis points |  | — |  |  | 77 |  |
| Total Notes due to Parent |  |  |  | 553 |  |  | 814 |  |
|  |  | Total Notes due to Parent, net |  | $ | 553 |  |  | $ | 712 |  |

- removed (2025-05-12):
[0002023554-25-000004:note_history:52]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Interest expense on notes due to Parent | $ | 2 |  |  | $ | 9 |  |  | $ | 4 |  |  | $ | 20 |  |
| Interest income on notes due from Parent | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |  | $ | (3) |  |

- removed (2025-05-12):
[0002023554-25-000004:note_history:53]
WDC has provided various corporate services to the Company in the ordinary course of business, including executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement and other shared services. These corporate expenses have been allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue or other relevant measures. Management believes the basis on which the expenses have been allocated to be a reasonable reflection of the utilization of services provided to or the benefit received by us.

- removed (2025-05-12):
[0002023554-25-000004:note_history:54]
A reconciliation of Net transfers from (to) Parent on the Condensed Combined Statements of Changes in Parent Company Net Investment to the corresponding amounts on the Condensed Combined Statements of Cash Flows is as follows:

- removed (2025-05-12):
[0002023554-25-000004:note_history:55]
|  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Net transfers from Parent per Condensed Combined Statements of Changes in Parent Company Net Investment | $ | 491 |  |  | $ | 171 |  |
| Liability for unrecognized tax benefits transferred from Parent | 14 |  |  | — |  |
| Accumulated other comprehensive loss transferred from Parent | 6 |  |  | — |  |
| Strategic investments transferred from Parent | (7) |  |  | — |  |
| Other assets and liabilities, net transferred from Parent | (37) |  |  | — |  |
| Property, plant and equipment, net transferred from Parent | (25) |  |  | (2) |  |
| Notes due to Parent transferred from Parent | (673) |  |  | — |  |
| Notes due from Parent transferred to Parent | — |  |  | 113 |  |
| Deferred taxes, net transferred from Parent | — |  |  | (8) |  |
| Net transfers from (to) Parent per Condensed Combined Statements of Cash Flows | $ | (231) |  |  | $ | 274 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0002023554-25-000027:note_history:56]
Sandisk Corporation (“Company,” “we,” “us,” or “our”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data. The Company operates primarily in the United States (“U.S.”), and also internationally, with a significant concentration in the Asia Pacific region.
  (was, 2025-03-07, similarity 0.9898):
[0002023554-25-000004:note_history:56]
Sandisk Corporation (“Company,” “we,” “us,” or “our”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data. The Company operates primarily in the United States (“U.S.”) and internationally, with a significant concentration in the Asia Pacific region.

- added (2025-05-12):
[0002023554-25-000027:note_history:57]
On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized WDC management to pursue a plan to separate the Company into an independent public company (the “separation” or the “spin-off”). The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly owned by WDC. On February 24, 2025, following the separation, the Company began trading as an independent, publicly traded company under the stock symbol “SNDK” on Nasdaq.

- added (2025-05-12):
[0002023554-25-000027:note_history:58]
WDC executed the spin-off of the Company through WDC’s pro rata distribution of 80.1% of the Company’s outstanding shares of common stock to holders of WDC’s common stock as of the close of business on February 21, 2025. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 19.9% of the shares of the Company’s common stock, which WDC is expected to retain for a period of up to twelve months following the distribution.

- added (2025-05-12):
[0002023554-25-000027:note_history:59]
In connection with the separation, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the spin-off and provided a framework for the relationship between WDC and the Company following the separation. These agreements include the Separation and Distribution Agreement, which contains certain key provisions related to the spin-off, as well as a Transition Services Agreement, a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025 and incorporated by reference to this Quarterly Report on Form 10-Q. Additionally, the Company adopted certain compensation plans filed as Exhibits to the Company’s Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025 (as amended, the “Form 10”). The Company also entered into various sublease agreements and established a stock compensation incentive plan in connection with the separation.

- added (2025-05-12):
[0002023554-25-000027:note_history:60]
On February 21, 2025, in connection with the separation, the Company entered into a $1.5 billion revolving credit facility, which was undrawn at the separation date, and a $2.0 billion term loan facility due in 2032. The Company used a portion of the proceeds received from the term loan facility and cash on hand to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities, and certain legal entities of WDC associated with the Company.

- added (2025-05-12):
[0002023554-25-000027:note_history:61]
After the separation, outstanding restricted stock units (“RSU”) and performance stock units (“PSU”) previously granted by WDC to employees of the Company were adjusted per the terms of the Employee Matters Agreement, in an attempt to maintain the economic value of those awards before and after the separation. Generally, continuing Sandisk employees with outstanding RSU awards held as of the spin-off date were converted solely to equivalent RSU awards of the Company, and any outstanding WDC RSU awards held as of the spin-off date were canceled. Outstanding RSU and PSU awards at the time of the spin-off, held by employees at levels equal to Vice President and above, were converted into RSU and PSU awards of both the Company and WDC.

- added (2025-05-12):
[0002023554-25-000027:note_history:62]
The completion of the separation was subject to certain conditions as described in our Form 10.

- changed (2025-05-12):
[0002023554-25-000027:note_history:63]
The accounting policies followed by the Company are set forth in Note 1, Organization and Basis of Presentation of the Notes to the Combined Financial Statements for the year ended June 28, 2024, included in Exhibit 99.1 to our Form 10.
  (was, 2025-03-07, similarity 0.9978):
[0002023554-25-000004:note_history:63]
The accounting policies followed by the Company are set forth in Note 1, Organization and Basis of Presentation, of the Notes to the Combined Financial Statements for the year ended June 28, 2024, included in Exhibit 99.1 to our Form 10.

- added (2025-05-12):
[0002023554-25-000027:note_history:64]
On February 21, 2025, the Company became a standalone publicly traded company, and our financial statements are now presented on a consolidated basis. Prior to the separation, the Company’s historical combined financial information was derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Condensed Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”).

- added (2025-05-12):
[0002023554-25-000027:note_history:65]
All intercompany accounts and transactions within the Company have been eliminated in the preparation of the Condensed Consolidated Financial Statements.

- added (2025-05-12):
[0002023554-25-000027:note_history:66]
Unless otherwise noted, all figures within the Condensed Consolidated Financial Statements are stated in U.S. Dollars (USD) and millions.

- added (2025-05-12):
[0002023554-25-000027:note_history:67]
Periods Prior to the Separation

- added (2025-05-12):
[0002023554-25-000027:note_history:68]
Prior to the separation on February 21, 2025, the Company was an operating segment of WDC. Consequently, standalone interim financial statements were not historically prepared for the Company. The accompanying Condensed Consolidated Financial Statements were prepared based upon WDC’s historical consolidated interim financial statements and accounting records. They were presented on a standalone basis as if the Company’s operations had been conducted independently from WDC. The Company utilized allocations and carve-out methodologies to prepare these historic Condensed Consolidated Financial Statements. The Condensed Consolidated Financial Statements included the historical results of operations, financial position, and cash flows of the Company and were prepared in accordance with GAAP, and the Company has adopted accounting policies and practices generally accepted in the industry in which it operates. As no single legal entity of the Company had a controlling financial interest in any other legal entities, Condensed Consolidated Financial Statements were prepared.

- added (2025-05-12):
[0002023554-25-000027:note_history:69]
Intercompany transactions were eliminated. With the exception of balances associated with lending arrangements reflected within Notes due to (from) Western Digital Corporation in the Condensed Consolidated Balance Sheets, transactions between the Company and WDC were generally considered to be effectively settled in the Condensed Consolidated Financial Statements at the time the transactions were recorded. The total net effect of the settlement of these transactions was reflected in the Condensed Consolidated Statements of Cash Flows as a financing activity and in the Condensed Consolidated Balance Sheets as Net investment from Western Digital Corporation. General financing activities included the net impact of any cash movements resulting from WDC’s centralized treasury cash management.

- added (2025-05-12):
[0002023554-25-000027:note_history:70]
The Condensed Consolidated Balance Sheets included all assets and liabilities that were identifiable or otherwise attributable to the Company. Assets and liabilities shared between the Company and WDC were included in the standalone financial statements to the extent that the asset was primarily used by the Company. If the Company was not the primary user of the asset, it was excluded entirely from the Condensed Consolidated Financial Statements. WDC historically used a centralized approach to cash management and financing of its operations, as needed. Certain of our cash was transferred to WDC according to centrally managed cash programs by treasury, and WDC funded our operating and investing activities, as needed. Cash transfers to and from WDC’s cash management accounts were reflected as a component of the Net investment from Western Digital Corporation in the Condensed Consolidated Balance Sheets. Cash and cash equivalents in our Condensed Consolidated Balance Sheets primarily represented cash held locally by entities included in our Condensed Consolidated Financial Statements.

- added (2025-05-12):
[0002023554-25-000027:note_history:71]
None of the debt obligations of WDC or corresponding interest expense were included in the Condensed Consolidated Financial Statements, as the Company was neither the legal obligor nor transferee for any portion of such debt. WDC’s debt obligations were secured by a lien on substantially all assets and properties of WDC and certain key subsidiaries, which included assets and properties of the Company prior to the completion of the separation.

- changed (2025-05-12):
[0002023554-25-000027:note_history:72]
The Condensed Consolidated Statements of Operations and Comprehensive Income (Loss) included all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions, and services provided by WDC. Allocation of general corporate expenses from WDC included, but was not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs were deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Condensed Consolidated Statements of Operations. The Condensed Consolidated Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on our behalf. We consider these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expense the Company would have incurred as a standalone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a standalone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.
  (was, 2025-03-07, similarity 0.9811):
[0002023554-25-000004:note_history:72]
The Condensed Combined Statements of Operations and Comprehensive Income (Loss) include all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions and services provided by WDC. Allocation of general corporate expenses from WDC include, but are not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses have been allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs are deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Condensed Combined Statements of Operations. The Condensed Combined Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on our behalf. We consider these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expense the Company would have incurred as a stand-alone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a stand-alone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.

- added (2025-05-12):
[0002023554-25-000027:note_history:73]
WDC maintains various stock-based compensation plans at a corporate level. Employees of the Company participated in those programs, and a portion of the compensation cost associated with those plans was included in the Company’s Condensed Consolidated Statements of Operations for the periods presented in this Quarterly Report on Form 10-Q. Before the spin-off, stock-based compensation expense was included within Net investment from Western Digital Corporation. The amounts presented in the Condensed Consolidated Financial Statements are not necessarily indicative of future awards and may not reflect the results that the Company would have experienced as a standalone entity.

- changed (2025-05-12):
[0002023554-25-000027:note_history:74]
Current and deferred income taxes and related tax expenses were determined based on the standalone results of the Company by applying Accounting Standards Codification (“ASC”) No. 740, Income Taxes, to the Company’s operations in each country as if it were a separate taxpayer (i.e., following the “Separate Return Methodology”).
  (was, 2025-03-07, similarity 0.7938):
[0002023554-25-000004:note_history:74]
Current and deferred income taxes and related tax expenses have been determined based on the stand-alone results of the Company by applying Accounting Standards Codification No. 740, Income Taxes, to the Company’s operations in each country as if it were a separate taxpayer (i.e., following the “Separate Return Methodology”).

- added (2025-05-12):
[0002023554-25-000027:note_history:75]
Periods Post Separation

- added (2025-05-12):
[0002023554-25-000027:note_history:76]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025, through March 28, 2025 are consolidated financial statements based on the Company’s reported results as a standalone company. All significant transactions and accounts within the Company were eliminated. Intercompany transactions between the Company and WDC prior to the separation were included within Net investment from Western Digital Corporation on the accompanying Consolidated Financial Statements or were paid in cash.

- added (2025-05-12):
[0002023554-25-000027:note_history:77]
Following the separation, certain functions continue to be provided by or for WDC for up to fifteen months under the Transition Services Agreement (“TSA”) or are being performed using the Company’s own resources or third-party service providers. As of March 28, 2025, charges under the TSA were not material.

- added (2025-05-12):
[0002023554-25-000027:note_history:78]
The Company incurred certain costs in its establishment as a standalone public company and expects to incur ongoing additional costs associated with operating as an independent, publicly traded company. Costs incurred for the three and nine months ended March 28, 2025, are included in Business separation costs within our Condensed Consolidated Statements of Operations.

- changed (2025-05-12):
[0002023554-25-000027:note_history:79]
The Company has prepared the accompanying Condensed Consolidated Financial Statements pursuant to the rules and regulations of the SEC for interim financial reporting. These Condensed Consolidated Financial Statements are unaudited and, in our opinion, include all adjustments, consisting of normal recurring adjustments and accruals necessary for a fair presentation of our operations, financial position, and cash flows for the periods presented. Operating results for the periods presented are not necessarily indicative of the results that may be expected for the full fiscal year due to seasonal and other factors. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been omitted in accordance with the rules and regulations of the SEC. These Condensed Consolidated Financial Statements should be read in conjunction with the Company’s audited Combined Financial Statements and accompanying notes for the year ended June 28, 2024, included in our Form 10.
  (was, 2025-03-07, similarity 0.9559):
[0002023554-25-000004:note_history:79]
The Company has prepared the accompanying Condensed Combined Financial Statements pursuant to the rules and regulations of the SEC for interim financial reporting. These Condensed Combined Financial Statements are unaudited and, in our opinion, include all adjustments, consisting of normal recurring adjustments and accruals necessary for a fair presentation of our operations, financial position, and cash flows for the periods presented. Operating results for the periods presented are not necessarily indicative of the results that may be expected for the full fiscal year due to seasonal and other factors. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been omitted in accordance with the rules and regulations of the SEC. These Condensed Combined Financial Statements should be read in conjunction with the Company’s audited Combined Financial Statements and accompanying notes for the year ended June 28, 2024, included in our Form 10.

- changed (2025-05-12):
[0002023554-25-000027:note_history:80]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which will end on June 27, 2025, and fiscal year 2024, which ended on June 28, 2024, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a condensed, consolidated basis.
  (was, 2025-03-07, similarity 0.9784):
[0002023554-25-000004:note_history:80]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which will end on June 27, 2025, and fiscal year 2024, which ended on June 28, 2024, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a condensed combined basis.

- added (2025-05-12):
[0002023554-25-000027:note_history:81]
The Company has incurred separation and transition costs related to the completion of its separation from WDC. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations.

- changed (2025-05-12):
[0002023554-25-000027:note_history:82]
Management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented, with consideration given to the potential impacts of current macroeconomic conditions, including the evolving impacts from tariffs. However, actual results could differ materially from these estimates.
  (was, 2025-03-07, similarity 0.7798):
[0002023554-25-000004:note_history:82]
Management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with U.S. GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented, with consideration given to the potential impacts of current macroeconomic conditions. However, actual results could differ materially from these estimates.

- removed (2025-05-12):
[0002023554-25-000004:note_history:83]
On October 30, 2023, our parent company, Western Digital Corporation (collectively “WDC” or “Parent”), announced that its board of directors (“WDC Board of Directors”) authorized management to pursue a plan to separate the Company into an independent public company. The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025.

- removed (2025-05-12):
[0002023554-25-000004:note_history:84]
WDC executed the spin-off of the Company through WDC’s pro rata distribution of 80.1% of the outstanding shares of common stock of the Company to holders of WDC’s common stock. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 19.9% of the shares of the Company’s common stock, which WDC is expected to retain for a period of up to 12 months following the distribution.

- removed (2025-05-12):
[0002023554-25-000004:note_history:85]
The completion of the spin-off was subject to certain conditions as described in our Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025 (as amended, the “Form 10”).

- removed (2025-05-12):
[0002023554-25-000004:note_history:86]
In connection with the spin-off, the Company entered into or adopted several agreements that provide a framework for the relationships between the Company and WDC. See Part 1, Item 1, Note 9, Related Parties and Related Commitments and Contingencies, of the Notes to the Combined Financial Statements included in this Quarterly Report on Form 10-Q.

- removed (2025-05-12):
[0002023554-25-000004:note_history:87]
Throughout the periods covered by the Condensed Combined Financial Statements, the Company was an operating segment of WDC. Consequently, stand-alone interim financial statements were not historically prepared for the Company. The accompanying Condensed Combined Financial Statements have been prepared from WDC’s historical consolidated interim financial statements and accounting records and are presented on a stand-alone basis as if the Company’s operations had been conducted independently from WDC. The Company utilized allocations and carve-out methodologies to prepare these historic Condensed Combined Financial Statements. The Condensed Combined Financial Statements include the historical results of operations, financial position, and cash flows of the Company in accordance with GAAP, and the Company has adopted accounting policies and practices that are generally accepted in the industry in which it operates. As no single legal entity of the Company had a controlling financial interest in all other legal entities as of the reporting date, Condensed Combined Financial Statements have been prepared.

- removed (2025-05-12):
[0002023554-25-000004:note_history:88]
Intercompany transactions have been eliminated. With the exception of balances associated with lending arrangements reflected within Notes due to (from) Parent in the Condensed Combined Balance Sheets, transactions between the Company and WDC are generally considered to be effectively settled in the Condensed Combined Financial Statements at the time the transactions are recorded. The total net effect of the settlement of these transactions is reflected in the Condensed Combined Statements of Cash Flows as a financing activity and in the Condensed Combined Balance Sheets as Parent company net investment. General financing activities include the net impact of any cash movements resulting from WDC’s centralized treasury cash management.

- removed (2025-05-12):
[0002023554-25-000004:note_history:89]
The Condensed Combined Balance Sheets include all assets and liabilities that are specifically identifiable or otherwise attributable to the Company. Assets and liabilities shared between the Company and WDC are included in the stand-alone financial statements to the extent the asset is primarily used by the Company. If the Company is not the primary user of the asset, it is excluded entirely from the Condensed Combined Financial Statements. WDC has historically used a centralized approach to cash management and financing of its operations, as needed. Certain of our cash was transferred to WDC according to centrally managed cash programs by treasury, and WDC funded our operating and investing activities as needed. Cash transfers to and from WDC’s cash management accounts are reflected as a component of the Parent company net investment in the Condensed Combined Balance Sheets. Cash and cash equivalents in our Condensed Combined Balance Sheets primarily represent cash held locally by entities included in our Condensed Combined Financial Statements.

- removed (2025-05-12):
[0002023554-25-000004:note_history:90]
None of the debt obligations of WDC or corresponding interest expense have been included in the accompanying Condensed Combined Financial Statements, as the Company is neither the legal obligor nor transferee for any portion of such debt. WDC’s debt obligations were secured by a lien on substantially all assets and properties of WDC and certain key subsidiaries, which included assets and properties of the Company prior to the completion of the separation.

- removed (2025-05-12):
[0002023554-25-000004:note_history:91]
WDC maintains various stock-based compensation plans at a corporate level. Employees of the Company participated in those programs and a portion of the compensation cost associated with those plans is included in the Company’s Condensed Combined Statements of Operations for the periods presented in this Quarterly Report on Form 10-Q. Stock-based compensation expense has been included within Parent company net investment. The amounts presented in the Condensed Combined Financial Statements are not necessarily indicative of future awards and may not reflect the results that the Company would have experienced as a stand-alone entity.

- removed (2025-05-12):
[0002023554-25-000004:note_history:92]
On October 30, 2023, WDC announced that its Board of Directors had completed its strategic review and, after evaluating a comprehensive range of alternatives, authorized WDC to pursue a plan to separate its flash business from its hard disk drive business to create two independent public companies. As a result of the plan, the Company has incurred separation and transition costs related to the completion of its separation from WDC. The separation and transition costs are recorded within Business separation costs in the Condensed Combined Statements of Operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-05-12):
[0002023554-25-000027:note_history:93]
Debt
Loan Agreement

- added (2025-05-12):
[0002023554-25-000027:note_history:94]
Debt consisted of the following:

- added (2025-05-12):
[0002023554-25-000027:note_history:95]
|  | March 28,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 2,000 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |
| Total Debt | 2,000 |  |
| Unamortized Issuance Costs | 53 |  |
| Subtotal | 1,947 |  |
| Less: current portion of long-term debt | 20 |  |
| Long term debt | $ | 1,927 |  |

- added (2025-05-12):
[0002023554-25-000027:note_history:96]
On February 21, 2025, the Company entered into a Loan Agreement (the “Loan Agreement”) by and among the Company, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent and the other parties party thereto. The Loan Agreement comprises a term loan B facility in the principal amount of $2 billion (the “Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”).

- added (2025-05-12):
[0002023554-25-000027:note_history:97]
The obligations under the Loan Agreement are guaranteed by the Company’s wholly-owned subsidiary, Sandisk Technologies, Inc. (“SDT”), and are required to be guaranteed by any of the Company’s future material U.S. wholly-owned subsidiaries, subject to certain exceptions outlined in the Loan Agreement. The obligations under the Loan Agreement are secured by the Company’s assets and SDT’s assets and are required to be secured by the assets of any of the Company’s future material U.S. wholly-owned subsidiaries, subject, in each case, to certain exceptions outlined in the Loan Agreement.

- added (2025-05-12):
[0002023554-25-000027:note_history:98]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that requires the Company to maintain a maximum Leverage Ratio (as defined in the Loan Agreement).

- added (2025-05-12):
[0002023554-25-000027:note_history:99]
On February 21, 2025, the Company borrowed $2 billion under its Term Loan Facility. The Company used a portion of the proceeds of the borrowing to make a net distribution payment of $1.5 billion to WDC, with the remainder to be used for general corporate purposes of the Company. The Revolving Credit Facility may be borrowed by the Company from time to time for general corporate purposes.

- added (2025-05-12):
[0002023554-25-000027:note_history:100]
In connection with the Loan Agreement, the Company and SDT entered into a security agreement to secure the obligations under the Facilities on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and SDT, subject to certain exceptions.

- added (2025-05-12):
[0002023554-25-000027:note_history:101]
In connection with the Loan Agreement, the Company (solely with respect to obligations of any additional Borrower under the Loan Agreement) and SDT entered into a guaranty agreement to secure and unconditionally guarantee the obligations under the Loan Agreement, respectively, in each case, subject to certain exceptions.

- added (2025-05-12):
[0002023554-25-000027:note_history:102]
Term Loan Facility

- added (2025-05-12):
[0002023554-25-000027:note_history:103]
The Term Loan Facility bears interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an interest rate margin of 3.00% per annum or (y) a base rate plus an interest rate margin of 2.00% per annum.

- added (2025-05-12):
[0002023554-25-000027:note_history:104]
The outstanding principal balance of the Term Loan Facility is required to be repaid in quarterly installments beginning on June 27, 2025, in an aggregate amount equal to 0.25% of the aggregate principal amount of the Term Loan Facility and a final payment comprised of all principal and interest due and payable at maturity on February 20, 2032.

- added (2025-05-12):
[0002023554-25-000027:note_history:105]
In connection with the issuance of the Term Loan Facility, the Company recognized issuance costs of $54 million, which will be amortized to Interest expense over the life of the facility.

- added (2025-05-12):
[0002023554-25-000027:note_history:106]
Revolving Credit Facility

- added (2025-05-12):
[0002023554-25-000027:note_history:107]
Borrowings under the Revolving Credit Facility, for U.S. dollar borrowings, will bear interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement), which rate includes a credit spread adjustment of 0.10%, plus an interest rate margin of 2.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)), or (y) a base rate plus an interest rate margin of 1.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)). The Company will pay a commitment fee of 0.30% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)) in respect of undrawn revolving commitments under the Revolving Credit Facility. The Revolving Credit Facility will also provide for borrowings in Euros, Yen, and additional currencies agreed to by the lenders under the Revolving Credit Facility. The Revolving Credit Facility will mature on February 21, 2030, at which time the commitments thereunder shall be terminated and will not have any amortization.

- added (2025-05-12):
[0002023554-25-000027:note_history:108]
In connection with the issuance of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which will be amortized to Interest expense over the life of the facility.

- added (2025-05-12):
[0002023554-25-000027:note_history:109]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that requires the Company to maintain a maximum Leverage Ratio (as defined in the Loan Agreement). As of March 28, 2025, the Company was in compliance with the financial covenant.

- added (2025-05-12):
[0002023554-25-000027:note_history:110]
As of March 28, 2025, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-05-12):
[0002023554-25-000027:note_history:111]
Debt consisted of the following:

- added (2025-05-12):
[0002023554-25-000027:note_history:112]
|  | March 28,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 2,000 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |
| Total Debt | 2,000 |  |
| Unamortized Issuance Costs | 53 |  |
| Subtotal | 1,947 |  |
| Less: current portion of long-term debt | 20 |  |
| Long term debt | $ | 1,927 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0002023554-25-000027:note_history:113]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 37 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 38 |  |  | 5 |  |
| Notes receivable, Flash Forward | 296 |  |  | 485 |  |
| Investment in Flash Partners | 46 |  |  | 148 |  |
| Investment in Flash Alliance | 116 |  |  | 219 |  |
| Investment in Flash Forward | 129 |  |  | 143 |  |
| Total notes receivable and investments in Flash Ventures | $ | 662 |  |  | $ | 1,001 |  |
  (was, 2025-03-07, similarity 0.9848):
[0002023554-25-000004:note_history:113]
|  | December 27,2024 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 72 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 35 |  |  | 5 |  |
| Notes receivable, Flash Forward | 476 |  |  | 485 |  |
| Investment in Flash Partners | 41 |  |  | 148 |  |
| Investment in Flash Alliance | 118 |  |  | 219 |  |
| Investment in Flash Forward | 129 |  |  | 143 |  |
| Total notes receivable and investments in Flash Ventures | $ | 871 |  |  | $ | 1,001 |  |

- changed (2025-05-12):
[0002023554-25-000027:note_history:114]
The following presents Interest expense and Interest income on notes due to (from) Western Digital Corporation, which were recorded within Interest expense and Interest income in the Condensed Consolidated Statements of Operations for the periods presented:
  (was, 2025-03-07, similarity 0.8178):
[0002023554-25-000004:note_history:114]
The following presents interest expense and interest income on notes due to (from) Parent, which have been recorded within Interest expense and Interest income in the Condensed Combined Statements of Operations for the periods presented:

- added (2025-05-12):
[0002023554-25-000027:note_history:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Interest expense on notes due to Western Digital Corporation | $ | 3 |  |  | $ | 9 |  |  | $ | 7 |  |  | $ | 29 |  |
| Interest (income) on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |  | $ | (4) |  |

- changed (2025-05-12):
[0002023554-25-000027:note_history:116]
The table below summarizes the impact of expense allocations from WDC within the Condensed Consolidated Statements of Operations for the periods presented:
  (was, 2025-03-07, similarity 0.9673):
[0002023554-25-000004:note_history:116]
The table below summarizes the impact of expense allocations from WDC within the Condensed Combined Statements of Operations for the periods presented:

- changed (2025-05-12):
[0002023554-25-000027:note_history:117]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 190 |  |  | $ | 189 |  |  | $ | 520 |  |
| Selling general, and administrative | 10 |  |  | 109 |  |  | 158 |  |  | 328 |  |
| Business separation costs | 9 |  |  | — |  |  | 50 |  |  | — |  |
| Employee termination and other charges | — |  |  | 2 |  |  | 5 |  |  | (44) |  |
| Total allocation of Corporate Expenses | $ | 19 |  |  | $ | 301 |  |  | $ | 402 |  |  | $ | 804 |  |
  (was, 2025-03-07, similarity 0.8175):
[0002023554-25-000004:note_history:117]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Research and development | $ | 2 |  |  | $ | 161 |  |  | $ | 189 |  |  | $ | 330 |  |
| Selling general, and administrative | 35 |  |  | 107 |  |  | 148 |  |  | 219 |  |
| Business separation costs | 21 |  |  | 34 |  |  | 41 |  |  | 34 |  |
| Employee termination and other charges | 3 |  |  | 13 |  |  | 5 |  |  | (46) |  |
| Total allocation of Corporate Expenses | $ | 61 |  |  | $ | 315 |  |  | $ | 383 |  |  | $ | 537 |  |

- added (2025-05-12):
[0002023554-25-000027:note_history:118]
A reconciliation of Net transfers from (to) Western Digital Corporation on the Condensed Consolidated Statements of Shareholders’ Equity to the corresponding amounts on the Condensed Consolidated Statements of Cash Flows is as follows:

- added (2025-05-12):
[0002023554-25-000027:note_history:119]
|  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | (585) |  |  | $ | 234 |  |
| Notes due (to) from Western Digital Corporation | (1,223) |  |  | 113 |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | (105) |  |  | — |  |
| Unis venture transferred from Western Digital Corporation | (61) |  |  | — |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | (27) |  |  | (5) |  |
| Tax balances transferred from Western Digital Corporation | (8) |  |  | (2) |  |
| Accumulated other comprehensive loss transferred to Western Digital Corporation | 10 |  |  | — |  |
| Tax indemnification liability transferred to Western Digital Corporation | 112 |  |  | — |  |
| Net transfers (to) from Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | (1,887) |  |  | $ | 340 |  |

- removed (2025-05-12):
[0002023554-25-000004:note_history:120]
The following presents a summary of the outstanding borrowings between the Company and subsidiaries of WDC for the periods presented, inclusive of any associated interest payable or interest receivable:

- removed (2025-05-12):
[0002023554-25-000004:note_history:121]
|  |  | Interest Rate |  | December 27,2024 |  | June 28,2024 |
|  |  |  |  | (in millions) |
| Notes due from Parent |  |  |  |  |  |  |
| Revolving Credit Agreement due from Parent $101M - Oct. 3, 2019 |  | AFR Rate (USD) or TIBOR + .35% (YEN) |  | $ | — |  |  | $ | (102) |  |
| Total Notes due from Parent |  |  |  | — |  |  | (102) |  |
| Notes due to Parent |  |  |  |  |  |  |
| Revolving Credit Agreement due to Parent $1B - Sep. 27, 2024 |  | SOFR + 1.6% |  | 553 |  |  | — |  |
| Notes due to Parent $500M - Nov. 25, 2014 |  | 1-year swap + 2% |  | — |  |  | 475 |  |
| Notes Due to Parent $42B Yen - Apr. 29, 2014 |  | TIBOR + .35% |  | — |  |  | 262 |  |
| Revolving Credit Agreement due to Parent $100M - Aug. 20, 2021 |  | LIBOR Rate + 150 basis points |  | — |  |  | 77 |  |
| Total Notes due to Parent |  |  |  | 553 |  |  | 814 |  |
|  |  | Total Notes due to Parent, net |  | $ | 553 |  |  | $ | 712 |  |

- removed (2025-05-12):
[0002023554-25-000004:note_history:122]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Interest expense on notes due to Parent | $ | 2 |  |  | $ | 9 |  |  | $ | 4 |  |  | $ | 20 |  |
| Interest income on notes due from Parent | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |  | $ | (3) |  |

- removed (2025-05-12):
[0002023554-25-000004:note_history:123]
A reconciliation of Net transfers from (to) Parent on the Condensed Combined Statements of Changes in Parent Company Net Investment to the corresponding amounts on the Condensed Combined Statements of Cash Flows is as follows:

- removed (2025-05-12):
[0002023554-25-000004:note_history:124]
|  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Net transfers from Parent per Condensed Combined Statements of Changes in Parent Company Net Investment | $ | 491 |  |  | $ | 171 |  |
| Liability for unrecognized tax benefits transferred from Parent | 14 |  |  | — |  |
| Accumulated other comprehensive loss transferred from Parent | 6 |  |  | — |  |
| Strategic investments transferred from Parent | (7) |  |  | — |  |
| Other assets and liabilities, net transferred from Parent | (37) |  |  | — |  |
| Property, plant and equipment, net transferred from Parent | (25) |  |  | (2) |  |
| Notes due to Parent transferred from Parent | (673) |  |  | — |  |
| Notes due from Parent transferred to Parent | — |  |  | 113 |  |
| Deferred taxes, net transferred from Parent | — |  |  | (8) |  |
| Net transfers from (to) Parent per Condensed Combined Statements of Cash Flows | $ | (231) |  |  | $ | 274 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0002023554-25-000027:note_history:125]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Cloud | $ | 197 |  |  | $ | 97 |  |  | $ | 747 |  |  | $ | 155 |  |
| Client | 927 |  |  | 1,035 |  |  | 3,024 |  |  | 3,002 |  |
| Consumer | 571 |  |  | 573 |  |  | 1,683 |  |  | 1,746 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,038 |  |  | $ | 1,140 |  |  | $ | 3,274 |  |  | $ | 3,313 |  |
| Americas | 375 |  |  | 272 |  |  | 1,207 |  |  | 759 |  |
| Europe, Middle East and Africa | 282 |  |  | 293 |  |  | 973 |  |  | 831 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |
  (was, 2025-03-07, similarity 0.9186):
[0002023554-25-000004:note_history:125]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 250 |  |  | $ | 40 |  |  | $ | 550 |  |  | $ | 58 |  |
| Client | 1,028 |  |  | 970 |  |  | 2,097 |  |  | 1,967 |  |
| Consumer | 598 |  |  | 655 |  |  | 1,112 |  |  | 1,173 |  |
| Total revenue | $ | 1,876 |  |  | $ | 1,665 |  |  | $ | 3,759 |  |  | $ | 3,198 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,086 |  |  | $ | 1,112 |  |  | $ | 2,236 |  |  | $ | 2,173 |  |
| Americas | 389 |  |  | 257 |  |  | 832 |  |  | 487 |  |
| Europe, Middle East and Africa | 401 |  |  | 296 |  |  | 691 |  |  | 538 |  |
| Total revenue | $ | 1,876 |  |  | $ | 1,665 |  |  | $ | 3,759 |  |  | $ | 3,198 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-12):
[0002023554-25-000027:note_history:126]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Cloud | $ | 197 |  |  | $ | 97 |  |  | $ | 747 |  |  | $ | 155 |  |
| Client | 927 |  |  | 1,035 |  |  | 3,024 |  |  | 3,002 |  |
| Consumer | 571 |  |  | 573 |  |  | 1,683 |  |  | 1,746 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,038 |  |  | $ | 1,140 |  |  | $ | 3,274 |  |  | $ | 3,313 |  |
| Americas | 375 |  |  | 272 |  |  | 1,207 |  |  | 759 |  |
| Europe, Middle East and Africa | 282 |  |  | 293 |  |  | 973 |  |  | 831 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |
  (was, 2025-03-07, similarity 0.9186):
[0002023554-25-000004:note_history:126]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
|  | (in millions) |
| Revenue by end market |  |  |  |  |  |  |  |
| Cloud | $ | 250 |  |  | $ | 40 |  |  | $ | 550 |  |  | $ | 58 |  |
| Client | 1,028 |  |  | 970 |  |  | 2,097 |  |  | 1,967 |  |
| Consumer | 598 |  |  | 655 |  |  | 1,112 |  |  | 1,173 |  |
| Total revenue | $ | 1,876 |  |  | $ | 1,665 |  |  | $ | 3,759 |  |  | $ | 3,198 |  |
| Revenue by geography |  |  |  |  |  |  |  |
| Asia | $ | 1,086 |  |  | $ | 1,112 |  |  | $ | 2,236 |  |  | $ | 2,173 |  |
| Americas | 389 |  |  | 257 |  |  | 832 |  |  | 487 |  |
| Europe, Middle East and Africa | 401 |  |  | 296 |  |  | 691 |  |  | 538 |  |
| Total revenue | $ | 1,876 |  |  | $ | 1,665 |  |  | $ | 3,759 |  |  | $ | 3,198 |  |

- changed (2025-05-12):
[0002023554-25-000027:note_history:127]
The Company’s top 10 customers accounted for 41% and 43% of its net revenue for the three and nine months ended March 28, 2025, respectively, and 43% and 41% of its net revenue for the three and nine months ended March 29, 2024, respectively. For the three months ended March 28, 2025, one customer accounted for more than 10% of the Company’s net revenue. For the nine months ended March 28, 2025 and the three and nine months ended March 29, 2024, no customer accounted for 10% of the Company’s net revenue.
Revenues
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company had no contract assets as of March 28, 2025 or June 28, 2024. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service, support, and maintenance contracts. Contract liabilities as of March 28, 2025, and June 28, 2024, and changes in contract liabilities for the three and nine months ended March 28, 2025, and March 29, 2024, were not material.
  (was, 2025-03-07, similarity 0.7902):
[0002023554-25-000004:note_history:127]
The Company’s top 10 customers accounted for 42% and 46% of its net revenue for the three and six months ended December 27, 2024, respectively, and 45% and 43% of its net revenue for the three and six months ended December 29, 2023, respectively. For the three and six months ended December 27, 2024, no customer accounted for more than 10% of the Company’s net revenue. For the three and six months ended December 29, 2023, one customer accounted for 10% of the Company’s net revenue.
Revenues
Contract assets represent the Company’s rights to consideration where performance obligations are completed, but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of December 27, 2024, or June 28, 2024. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service and support and maintenance contracts. Contract liabilities as of December 27, 2024 and June 28, 2024, and changes in contract liabilities for the three and six months ended December 27, 2024 and December 29, 2023, were not material.

- changed (2025-05-12):
[0002023554-25-000027:note_history:128]
The Company incurs sales commissions as direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize sales commissions as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no other direct incremental costs to obtain contracts with an expected benefit of more than one year.
  (was, 2025-03-07, similarity 0.9754):
[0002023554-25-000004:note_history:128]
The Company incurs sales commissions as direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize sales commissions as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no other direct incremental costs to obtain contracts that have an expected benefit of greater than one year.

- changed (2025-05-12):
[0002023554-25-000027:note_history:129]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements, and customer support and service contracts, which will be recognized over their contract period. The transaction price allocated to the remaining performance obligations as of March 28, 2025, was not material.
  (was, 2025-03-07, similarity 0.7522):
[0002023554-25-000004:note_history:129]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements and customer support and service contracts, which will be recognized over their contract period. The transaction price allocated to the remaining performance obligations as of December 27, 2024, was not material.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-05-12):
[0002023554-25-000004:note_history:130]
Subsequent Events
Completion of the spin-off

- removed (2025-05-12):
[0002023554-25-000004:note_history:131]
On January 31, 2025, the Company’s Form 10 was declared effective by the SEC.

- removed (2025-05-12):
[0002023554-25-000004:note_history:132]
On February 21, 2025, the Company completed its spin-off from WDC (the “Spin-Off”) through WDC’s pro rata distribution of 80.1% of the outstanding shares of common stock of the Company to WDC’s existing stockholders. Each of WDC’s stockholders received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the Spin-Off, WDC owned 19.9% of the outstanding shares of the Company’s common stock, which WDC is expected to retain for a period of up to 12 months following the separation. The Company is also subject to various agreements with WDC in connection with the separation. On February 24, 2025, the Company began trading as an independent, publicly traded company under the stock symbol “SNDK” on the Nasdaq Stock Market LLC (“Nasdaq”).

- removed (2025-05-12):
[0002023554-25-000004:note_history:133]
In connection with, and as of the closing date of the Spin-Off, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the Spin-Off and provide a framework for WDC’s relationship with the Company following the Spin-Off. These agreements include the Separation and Distribution Agreement (as described below), which contains certain key provisions related to the Spin-Off, as well as a Transition Services Agreement, a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025. Additionally, the Company adopted certain compensation plans, which were filed as Exhibits to our Form 10.

- removed (2025-05-12):
[0002023554-25-000004:note_history:134]
Loan Agreement

- removed (2025-05-12):
[0002023554-25-000004:note_history:135]
On February 21, 2025, the Company entered into a Loan Agreement (the “Loan Agreement”) by and among the Company, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent and the other parties party thereto. The Loan Agreement comprises a term loan B facility in the principal amount of $2 billion (the “Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). The Term Loan Facility bears interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an interest rate margin of 3.00% per annum or (y) a base rate plus an interest rate margin of 2.00% per annum. The Term Loan Facility will mature on February 20, 2032, and amortizes at 1.00% per annum.

- removed (2025-05-12):
[0002023554-25-000004:note_history:136]
Borrowings under the Revolving Credit Facility, for U.S. dollar borrowings, will bear interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement), which rate includes a credit spread adjustment of 0.10%, plus an interest rate margin of 2.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)), or (y) a base rate plus an interest rate margin of 1.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)). The Company will pay a commitment fee of 0.30% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)) in respect of undrawn revolving commitments under the Revolving Credit Facility. The Revolving Credit Facility will also provide for borrowings in Euros, Yen and additional currencies agreed to by the lenders under the Revolving Credit Facility. The Revolving Credit Facility will mature on February 21, 2030, at which time the commitments thereunder shall be terminated and will not have any amortization.

- removed (2025-05-12):
[0002023554-25-000004:note_history:137]
The obligations under the Loan Agreement are guaranteed by the Company’s wholly owned subsidiary, Sandisk Technologies, Inc. (“SDT”) and are required to be guaranteed by any of the Company’s future material U.S. wholly owned subsidiaries, subject to certain exceptions outlined in the Loan Agreement. The obligations under the Loan Agreement are secured by the Company’s assets and SDT’s assets and are required to be secured by the assets of any of the Company’s future material U.S. wholly owned subsidiaries, subject, in each case, to certain exceptions outlined in the Loan Agreement.

- removed (2025-05-12):
[0002023554-25-000004:note_history:138]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that requires the Company to maintain a maximum Leverage Ratio (as defined in the Loan Agreement).

- removed (2025-05-12):
[0002023554-25-000004:note_history:139]
On February 21, 2025, the Company borrowed $2 billion under its Term Loan Facility. The Company used a portion of the proceeds of the borrowing to pay a dividend to WDC in the amount of approximately $1.5 billion, with the remainder to be used for general corporate purposes of the Company. The Revolving Credit Facility may be borrowed by the Company from time to time for general corporate purposes.

- removed (2025-05-12):
[0002023554-25-000004:note_history:140]
In connection with the Loan Agreement, the Company and SDT entered into a security agreement (the “Security Agreement”) to secure the obligations under the Facilities on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and SDT, subject to certain exceptions.

- removed (2025-05-12):
[0002023554-25-000004:note_history:141]
In connection with the Loan Agreement, the Company (solely with respect to obligations of any additional Borrower under the Loan Agreement) and SDT entered into a guaranty agreement (the “Guaranty Agreement”) to secure and unconditionally guarantee the obligations under the Loan Agreement, respectively, in each case subject to certain exceptions.

- removed (2025-05-12):
[0002023554-25-000004:note_history:142]
The foregoing description of the Loan Agreement, Security Agreement and Guaranty Agreement do not purport to be complete and are subject to, and qualified in its entirety by, the full text of the Loan Agreement, Security Agreement and Guaranty Agreement, copies of which are filed as Exhibits 10.7 to 10.9 hereto and are incorporated herein by reference.

- removed (2025-05-12):
[0002023554-25-000004:note_history:143]
Potential Impairment of Goodwill and Long-lived Assets

- removed (2025-05-12):
[0002023554-25-000004:note_history:144]
Subsequent to the completion of the separation, the Company identified potential impairment indicators related to the trading price of the Company’s common stock and a resulting market capitalization that was below its December 27, 2024 net book value. In accordance with Accounting Standards Codification No. 350, Intangibles - Goodwill and Other, the Company initiated a quantitative analysis of potential impairment of goodwill and long-lived assets. That analysis is ongoing, and the Company believes it is more likely than not that it will record an impairment charge in the three months ending March 28, 2025. See Part 1, Item 1, Note 5, Supplemental Financial Statement Data, for information about how goodwill is tested for impairment.
