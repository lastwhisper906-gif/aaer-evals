# SNDK 10-K controls and the auditor's report


## auditors_report

[0002023554-25-000034:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0002023554-25-000034:auditors_report:2]
To the Shareholders and Board of Directors

[0002023554-25-000034:auditors_report:3]
Sandisk Corporation:

[0002023554-25-000034:auditors_report:4]
Opinion on the Consolidated Financial Statements

[0002023554-25-000034:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Sandisk Corporation and subsidiaries (the Company) as of June 27, 2025 and June 28, 2024, the related consolidated statements of operations, comprehensive income (loss), shareholders’ equity, and cash flows for each of the fiscal years in the three-year period ended June 27, 2025, and the related notes (collectively, the consolidated financial statements). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of June 27, 2025 and June 28, 2024, and the results of its operations and its cash flows for each of the fiscal years in the three-year period ended June 27, 2025, in conformity with U.S. generally accepted accounting principles.

[0002023554-25-000034:auditors_report:6]
Basis for Opinion

[0002023554-25-000034:auditors_report:7]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on these consolidated financial statements based on our audit. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0002023554-25-000034:auditors_report:8]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0002023554-25-000034:auditors_report:9]
Critical Audit Matter

[0002023554-25-000034:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of a critical audit matter does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0002023554-25-000034:auditors_report:11]
Assessment of variable consideration for sales to resellers

[0002023554-25-000034:auditors_report:12]
As discussed in Note 1 to the consolidated financial statements, the Company provides resellers with price protection for inventories held by resellers at the time of published list price reductions and other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction to revenue at the time of revenue recognition. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. For sales to resellers, the Company’s methodology for estimating variable consideration is based on several factors, including historical pricing information, current pricing trends, and channel inventory levels.

[0002023554-25-000034:auditors_report:13]
58

[0002023554-25-000034:auditors_report:14]
We identified the assessment of variable consideration for sales to resellers as a critical audit matter. A high degree of subjective auditor judgment was required to evaluate the Company’s assumptions for historical pricing information and the level of channel inventory used to estimate variable consideration for sales to resellers as minor changes in these assumptions could cause significant changes in the estimate.

[0002023554-25-000034:auditors_report:15]
The following are the primary procedures we performed to address this critical audit matter. To assess the reasonableness of the estimated variable consideration for sales to resellers, we developed an independent expectation of the variable consideration for sales to resellers based on historically recorded payments and issued credits and then compared our expectation to the estimated variable consideration recorded.

[0002023554-25-000034:auditors_report:16]
We have served as the Company’s auditor since 2023.

[0002023554-25-000034:auditors_report:17]
Irvine, California

[0002023554-25-000034:auditors_report:18]
August 20, 2025

[0002023554-25-000034:auditors_report:19]
59

[0002023554-25-000034:auditors_report:20]
SANDISK CORPORATION CONSOLIDATED BALANCE SHEETS

[0002023554-25-000034:auditors_report:21]
(in millions, except par value)

[0002023554-25-000034:auditors_report:22]
|  | June 27,2025 |  | June 28,2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,481 |  |  | $ | 328 |  |
| Accounts receivable, net | 1,068 |  |  | 935 |  |
| Inventories | 2,079 |  |  | 1,955 |  |
| Income tax receivable | 66 |  |  | 7 |  |
| Other current assets | 392 |  |  | 221 |  |
| Notes due from Western Digital Corporation | — |  |  | 102 |  |
| Total current assets | 5,086 |  |  | 3,548 |  |
| Property, plant and equipment, net | 619 |  |  | 791 |  |
| Notes receivable and investments in Flash Ventures | 654 |  |  | 1,001 |  |
| Goodwill | 4,999 |  |  | 7,207 |  |
| Deferred tax assets | 58 |  |  | 96 |  |
| Income tax receivable, non-current | 80 |  |  | 11 |  |
| Other non-current assets | 1,489 |  |  | 852 |  |
| Total assets | $ | 12,985 |  |  | $ | 13,506 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 366 |  |  | $ | 357 |  |
| Accounts payable to related parties | 400 |  |  | 313 |  |
| Accrued expenses | 425 |  |  | 424 |  |
| Accrued compensation | 173 |  |  | 195 |  |
| Income tax payables | 43 |  |  | 20 |  |
| Notes due to Western Digital Corporation | — |  |  | 814 |  |
| Current portion of long-term debt | 20 |  |  | — |  |
| Total current liabilities | 1,427 |  |  | 2,123 |  |
| Deferred tax liabilities | 17 |  |  | 15 |  |
| Long-term debt | 1,829 |  |  | — |  |
| Other liabilities | 496 |  |  | 286 |  |
| Total liabilities | 3,769 |  |  | 2,424 |  |
| Commitments and contingencies (Notes 10, 11, 14 and 16) |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock, $0.01 par value; authorized — 450 shares; issued and outstanding — 146 shares | $ | 1 |  |  | $ | — |  |
| Additional paid-in capital | 11,248 |  |  | — |  |
| Accumulated deficit | (1,784) |  |  | — |  |
| Accumulated other comprehensive loss | (249) |  |  | (452) |  |
| Net investment from Western Digital Corporation | — |  |  | 11,534 |  |
| Total shareholders’ equity | 9,216 |  |  | 11,082 |  |
| Total liabilities and shareholders’ equity | $ | 12,985 |  |  | $ | 13,506 |  |

[0002023554-25-000034:auditors_report:23]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0002023554-25-000034:auditors_report:24]
SANDISK CORPORATION CONSOLIDATED STATEMENTS OF OPERATIONS

[0002023554-25-000034:auditors_report:25]
(in millions, except per share amounts)

[0002023554-25-000034:auditors_report:26]
|  | Year Ended |
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Revenue, net | $ | 7,355 |  |  | $ | 6,663 |  |  | $ | 6,086 |  |
| Cost of revenue | 5,143 |  |  | 5,591 |  |  | 5,656 |  |
| Gross profit | 2,212 |  |  | 1,072 |  |  | 430 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 1,132 |  |  | 1,061 |  |  | 1,167 |  |
| Selling, general and administrative | 573 |  |  | 455 |  |  | 558 |  |
| Goodwill impairment | 1,830 |  |  | — |  |  | 671 |  |
| Business separation costs | 67 |  |  | 64 |  |  | — |  |
| Employee termination and other | 21 |  |  | (40) |  |  | 69 |  |
| Gain on business divestiture | (34) |  |  | — |  |  | — |  |
| Total operating expenses | 3,589 |  |  | 1,540 |  |  | 2,465 |  |
| Operating loss | (1,377) |  |  | (468) |  |  | (2,035) |  |
| Interest and other income (expense), net: |  |  |  |  |  |
| Interest income | 22 |  |  | 12 |  |  | 21 |  |
| Interest expense | (63) |  |  | (40) |  |  | (31) |  |
| Other income (expense), net | (61) |  |  | (7) |  |  | 43 |  |
| Total interest and other income (expense), net | (102) |  |  | (35) |  |  | 33 |  |
| Loss before taxes | (1,479) |  |  | (503) |  |  | (2,002) |  |
| Income tax expense | 162 |  |  | 169 |  |  | 141 |  |
| Net loss | $ | (1,641) |  |  | $ | (672) |  |  | $ | (2,143) |  |
| Net loss per common share: |  |  |  |  |  |
| Basic and diluted | $ | (11.32) |  |  | $ | (4.63) |  |  | $ | (14.78) |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic and diluted | 145 |  |  | 145 |  |  | 145 |  |

[0002023554-25-000034:auditors_report:27]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0002023554-25-000034:auditors_report:28]
61

[0002023554-25-000034:auditors_report:29]
SANDISK CORPORATION CONSOLIDATED STATEMENTS OF COMPREHENSIVE LOSS

[0002023554-25-000034:auditors_report:30]
(in millions)

[0002023554-25-000034:auditors_report:31]
|  | Year Ended |
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Net loss | $ | (1,641) |  |  | $ | (672) |  |  | $ | (2,143) |  |
| Other comprehensive income (loss), before tax: |  |  |  |  |  |
| Foreign currency translation adjustment | 10 |  |  | (43) |  |  | (35) |  |
| Net unrealized gain (loss) on derivative contracts | 222 |  |  | (87) |  |  | 128 |  |
| Total other comprehensive income (loss), before tax | 232 |  |  | (130) |  |  | 93 |  |
| Income tax benefit (expense) related to items of other comprehensive income (loss), before tax | (19) |  |  | 21 |  |  | (29) |  |
| Other comprehensive income (loss), net of tax | 213 |  |  | (109) |  |  | 64 |  |
| Total comprehensive loss | $ | (1,428) |  |  | $ | (781) |  |  | $ | (2,079) |  |

[0002023554-25-000034:auditors_report:32]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0002023554-25-000034:auditors_report:33]
62

[0002023554-25-000034:auditors_report:34]
SANDISK CORPORATION CONSOLIDATED STATEMENTS OF CASH FLOWS

[0002023554-25-000034:auditors_report:35]
(in millions)

[0002023554-25-000034:auditors_report:36]
|  | Year Ended |
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Cash flows from operating activities |  |  |  |  |  |
| Net loss | $ | (1,641) |  |  | $ | (672) |  |  | $ | (2,143) |  |
| Adjustments to reconcile net loss to net cash provided by (used in) operations: |  |  |  |  |  |
| Depreciation and amortization | 163 |  |  | 224 |  |  | 448 |  |
| Stock-based compensation | 182 |  |  | 149 |  |  | 165 |  |
| Goodwill impairment | 1,830 |  |  | — |  |  | 671 |  |
| Deferred income taxes | (12) |  |  | (16) |  |  | (81) |  |
| Asset Impairment | — |  |  | 4 |  |  | 1 |  |
| Gain on disposal of assets | (1) |  |  | (60) |  |  | — |  |
| Non-cash portion of impairment of cost method investments | 1 |  |  | — |  |  | — |  |
| Unrealized foreign exchange (gain) loss | (25) |  |  | 13 |  |  | (37) |  |
| Gain on business divestiture | (34) |  |  | — |  |  | — |  |
| Amortization of debt issuance costs and discounts | 3 |  |  | — |  |  | — |  |
| Equity loss in investees, net of dividends received | 74 |  |  | 49 |  |  | (45) |  |
| Gain on sale of investments | — |  |  | (1) |  |  | (3) |  |
| Other non-cash operating activities, net | 23 |  |  | 87 |  |  | 114 |  |
| Settlement of accrued interest on Notes due to Western Digital Corporation | (99) |  |  | — |  |  | — |  |
| Changes in: |  |  |  |  |  |
| Accounts receivable, net | (100) |  |  | (395) |  |  | 750 |  |
| Inventories | (160) |  |  | 314 |  |  | (277) |  |
| Accounts payable | 93 |  |  | 32 |  |  | (124) |  |
| Accounts payable to related parties | (23) |  |  | 21 |  |  | (23) |  |
| Accrued expenses | 13 |  |  | (51) |  |  | (104) |  |
| Accrued compensation | 21 |  |  | 99 |  |  | (56) |  |
| Other assets and liabilities, net | (224) |  |  | (106) |  |  | 31 |  |
| Net cash provided by (used in) operating activities | 84 |  |  | (309) |  |  | (713) |  |
| Cash flows from investing activities |  |  |  |  |  |
| Purchases of property, plant and equipment | (204) |  |  | (166) |  |  | (219) |  |
| Proceeds from the sale of property, plant and equipment | — |  |  | 137 |  |  | — |  |
| Proceeds from dispositions of business | 401 |  |  | — |  |  | — |  |
| Notes receivable issuances to Flash Ventures | (333) |  |  | (243) |  |  | (627) |  |
| Notes receivable proceeds from Flash Ventures | 515 |  |  | 482 |  |  | 641 |  |
| Distributions from Flash Ventures | 176 |  |  | — |  |  | — |  |
| Strategic investments and other, net | 1 |  |  | — |  |  | 16 |  |
| Net cash provided by (used in) investing activities | 556 |  |  | 210 |  |  | (189) |  |
| Cash flows from financing activities |  |  |  |  |  |
| Issuance of stock under employee stock plans | 5 |  |  | — |  |  | — |  |
| Taxes paid on vested stock awards under employee stock plans | (13) |  |  | — |  |  | — |  |
| Proceeds from debt | 1,970 |  |  | — |  |  | — |  |
| Repayments of debt | (100) |  |  | — |  |  | — |  |
| Debt issuance costs | (32) |  |  | — |  |  | — |  |
| Proceeds from borrowings on Notes due to Western Digital Corporation | 550 |  |  | — |  |  | 54 |  |
| Proceeds from principal repayments on Notes due from Western Digital Corporation | 101 |  |  | 14 |  |  | 216 |  |
| Repayments of principal on Notes due to Western Digital Corporation | (76) |  |  | (102) |  |  | (86) |  |
| Transfers from (to) Western Digital Corporation | (1,887) |  |  | 394 |  |  | 676 |  |
| Origination of Notes due from Western Digital Corporation | — |  |  | (170) |  |  | — |  |
| Net cash provided by financing activities | 518 |  |  | 136 |  |  | 860 |  |
| Effect of exchange rate changes on cash | (5) |  |  | (1) |  |  | (1) |  |
| Net increase (decrease) in cash and cash equivalents | 1,153 |  |  | 36 |  |  | (43) |  |
| Cash and cash equivalents, beginning of year | 328 |  |  | 292 |  |  | 335 |  |
| Cash and cash equivalents, end of year | $ | 1,481 |  |  | $ | 328 |  |  | $ | 292 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |
| Cash paid for interest | $ | 139 |  |  | $ | 12 |  |  | $ | 7 |  |
| Cash received for interest | 2 |  |  | 10 |  |  | 12 |  |
| Cash paid for income taxes | 50 |  |  | — |  |  | — |  |
| Non-cash transfers of: |  |  |  |  |  |
| Notes due to (from) Western Digital Corporation | 1,223 |  |  | (113) |  |  | (316) |  |
| Other assets and liabilities, net, from Western Digital Corporation | 105 |  |  | — |  |  | — |  |
| Contribution of equity interest in Unis Venture from Western Digital Corporation | 61 |  |  | — |  |  | — |  |
| Property, plant and equipment from Western Digital Corporation | 27 |  |  | 11 |  |  | 18 |  |
| Tax balances from (to) Western Digital Corporation | 8 |  |  | (17) |  |  | (2) |  |
| Tax indemnification liability to Western Digital Corporation | (112) |  |  | — |  |  | — |  |

[0002023554-25-000034:auditors_report:37]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0002023554-25-000034:auditors_report:38]
63

[0002023554-25-000034:auditors_report:39]
SANDISK CORPORATION CONSOLIDATED STATEMENTS OF SHAREHOLDERS’ EQUITY

[0002023554-25-000034:auditors_report:40]
(in millions)

[0002023554-25-000034:auditors_report:41]
|  | Common Stock |  |  |  |  |  |  |  |  |  |  |
|  | Shares |  | Amount |  | Additional Paid in Capital |  | Accumulated Deficit |  | Accumulated Other Comprehensive Loss |  | Net Investment from Western Digital Corporation |  | Total |
| Balance at July 01, 2022 | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (407) |  |  | $ | 13,384 |  |  | $ | 12,977 |  |
| Net loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (2,143) |  |  | (2,143) |  |
| Foreign currency translation adjustment | — |  |  | — |  |  | — |  |  | — |  |  | (35) |  |  | — |  |  | (35) |  |
| Net unrealized gain on derivative contracts | — |  |  | — |  |  | — |  |  | — |  |  | 99 |  |  | — |  |  | 99 |  |
| Stock-based compensation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 165 |  |  | 165 |  |
| Net transfer from Western Digital Corporation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 376 |  |  | 376 |  |
| Balance at June 30, 2023 | — |  |  | — |  |  | — |  |  | — |  |  | (343) |  |  | 11,782 |  |  | 11,439 |  |
| Net loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (672) |  |  | (672) |  |
| Foreign currency translation adjustment | — |  |  | — |  |  | — |  |  | — |  |  | (43) |  |  | — |  |  | (43) |  |
| Net unrealized loss on derivative contracts | — |  |  | — |  |  | — |  |  | — |  |  | (66) |  |  | — |  |  | (66) |  |
| Stock-based compensation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 149 |  |  | 149 |  |
| Net transfer from Western Digital Corporation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 275 |  |  | 275 |  |
| Balance at June 28, 2024 | — |  |  | — |  |  | — |  |  | — |  |  | (452) |  |  | 11,534 |  |  | 11,082 |  |
| Net income / (loss) | — |  |  | — |  |  | — |  |  | (1,784) |  |  | — |  |  | 143 |  |  | (1,641) |  |
| Net transfers to Western Digital Corporation, including spin-off-related adjustments | — |  |  | — |  |  | — |  |  | — |  |  | (10) |  |  | (602) |  |  | (612) |  |
| Issuance of common stock and reclassification of net transfers from Western Digital Corporation | 145 |  |  | 1 |  |  | 11,189 |  |  | — |  |  | — |  |  | (11,190) |  |  | — |  |
| Employee stock plans | 1 |  |  | — |  |  | (8) |  |  | — |  |  | — |  |  | — |  |  | (8) |  |
| Foreign currency translation adjustment | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Net unrealized gain on derivative contracts | — |  |  | — |  |  | — |  |  | — |  |  | 203 |  |  | — |  |  | 203 |  |
| Stock-based compensation |  |  |  |  | 67 |  |  |  |  |  |  | 115 |  |  | 182 |  |
| Balance at June 27, 2025 | 146 |  |  | $ | 1 |  |  | $ | 11,248 |  |  | $ | (1,784) |  |  | $ | (249) |  |  | $ | — |  |  | $ | 9,216 |  |

[0002023554-25-000034:auditors_report:42]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0002023554-25-000034:auditors_report:43]
64

[0002023554-25-000034:auditors_report:44]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:45]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:46]
Note 1.    Organization, Basis of Presentation and Summary of Significant Accounting Policies

[0002023554-25-000034:auditors_report:47]
Description of the Company

[0002023554-25-000034:auditors_report:48]
Sandisk Corporation (“Sandisk, or ” the “Company”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, Sandisk’s broad and ever-expanding portfolio delivers powerful flash storage solutions for AI workloads in datacenters, edge devices, and consumers. Sandisk’s technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. The Company’s solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives and wafers and components. The Company’s broad portfolio of technology and products addresses multiple end markets of “Cloud,” “Client” and Consumer.” The Company operates primarily in the United States (“U.S.”), and also internationally, with a significant concentration in the Asia Pacific region.

[0002023554-25-000034:auditors_report:49]
On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized WDC management to pursue a plan to separate the Company into an independent public company (the “separation” or the “spin-off”). The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly owned by WDC. On February 24, 2025, following the separation, the Company began trading as an independent, publicly traded company under the stock symbol “SNDK” on Nasdaq.

[0002023554-25-000034:auditors_report:50]
WDC executed the spin-off of the Company through WDC’s pro rata distribution of 116,035,464, or 80.1%, of the Company’s outstanding shares of common stock to holders of WDC’s common stock as of the close of business on February 21, 2025. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 28,827,787 or 19.9% of the shares of the Company’s common stock. On June 6, 2025, WDC disposed of 21,314,768 or 14.6% of the Company’s common stock through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors.

[0002023554-25-000034:auditors_report:51]
In connection with the separation, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the spin-off and provided a framework for the relationship between WDC and the Company following the separation. These agreements include the Separation and Distribution Agreement, which contains certain key provisions related to the spin-off, as well as a Transition Services Agreement, a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025 and incorporated by reference to this Annual Report on Form 10-K. Additionally, the Company adopted certain compensation plans filed as Exhibits to the Company’s Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025 (as amended, the “Form 10”). The Company also entered into various sublease agreements and established a stock compensation incentive plan in connection with the separation.

[0002023554-25-000034:auditors_report:52]
On February 21, 2025, in connection with the separation, the Company entered into a $1.5 billion revolving credit facility that remains undrawn to date, and a $2.0 billion term loan facility due in 2032. The Company used a portion of the proceeds received from the term loan facility and cash on hand to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities, and certain legal entities of WDC associated with the Company.

[0002023554-25-000034:auditors_report:53]
After the separation, outstanding restricted stock units (“RSU”) and performance stock units (“PSU”) previously granted by WDC to employees of the Company were adjusted per the terms of the Employee Matters Agreement, in an attempt to maintain the economic value of those awards before and after the separation. Generally, continuing Sandisk employees with outstanding RSU awards held as of the spin-off date were converted solely to equivalent RSU awards of the Company, and any outstanding WDC RSU awards held as of the spin-off date were canceled. Outstanding RSU and PSU awards at the time of the spin-off, held by employees at levels equal to Vice President and above, were converted into RSU and PSU awards of both the Company and WDC.

[0002023554-25-000034:auditors_report:54]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:55]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:56]
Basis of Presentation

[0002023554-25-000034:auditors_report:57]
On February 21, 2025, the Company became a standalone publicly-traded company, and the Company’s financial statements are now presented on a consolidated basis. Prior to the separation, the Company’s historical combined financial information was derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and policies and practices that are generally accepted in the industry in which it operates. The Company’s significant accounting policies are summarized below.

[0002023554-25-000034:auditors_report:58]
Basis of Consolidation

[0002023554-25-000034:auditors_report:59]
The Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in the preparation of the Consolidated Financial Statements. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from the remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in Accumulated other comprehensive income (loss), a component of shareholders’ equity.

[0002023554-25-000034:auditors_report:60]
Unless otherwise noted, all figures within the Consolidated Financial Statements are stated in U.S. Dollars and millions.

[0002023554-25-000034:auditors_report:61]
Periods Prior to the Separation

[0002023554-25-000034:auditors_report:62]
Prior to the separation on February 21, 2025, the Company was an operating segment of WDC. Consequently, standalone financial statements were not historically prepared for the Company. The accompanying Consolidated Financial Statements were prepared based upon WDC’s historical consolidated financial statements and accounting records. They were presented on a standalone basis as if the Company’s operations had been conducted independently from WDC. The Company utilized allocations and carve-out methodologies to prepare these historical Consolidated Financial Statements. The Consolidated Financial Statements included the historical results of operations, financial position, and cash flows of the Company and were prepared in accordance with GAAP, and the Company adopted accounting policies and practices generally accepted in the industry in which it operates.

[0002023554-25-000034:auditors_report:63]
Intercompany transactions were eliminated. With the exception of balances associated with lending arrangements reflected within Notes due to (from) Western Digital Corporation in the Consolidated Balance Sheets, transactions between the Company and WDC were generally considered to be effectively settled in the Consolidated Financial Statements at the time the transactions were recorded. The total net effect of the settlement of these transactions was reflected in the Consolidated Statements of Cash Flows as a financing activity and in the Consolidated Balance Sheets as Net investment from Western Digital Corporation. General financing activities included the net impact of any cash movements resulting from WDC’s centralized treasury cash management.

[0002023554-25-000034:auditors_report:64]
The Consolidated Balance Sheets included all assets and liabilities that were identifiable or otherwise attributable to the Company. Assets and liabilities shared between the Company and WDC were included in the standalone financial statements to the extent that the asset was primarily used by the Company. If the Company was not the primary user of the asset, it was excluded entirely from the Consolidated Financial Statements. WDC historically used a centralized approach to cash management and financing of its operations, as needed. Certain of the Company’s cash was transferred to WDC according to centrally managed cash programs by treasury, and WDC funded the Company’s operating and investing activities, as needed. Cash transfers to and from WDC’s cash management accounts were reflected as a component of the Net investment from Western Digital Corporation in the Consolidated Balance Sheets. Cash and cash equivalents in the Company’s Consolidated Balance Sheets primarily represented cash held locally by entities included in the Company’s Consolidated Financial Statements.

[0002023554-25-000034:auditors_report:65]
None of the debt obligations of WDC or corresponding interest expense were included in the Consolidated Financial Statements, as the Company was neither the legal obligor nor transferee for any portion of such debt. WDC’s debt obligations were secured by a lien on substantially all assets and properties of WDC and certain key subsidiaries, which included assets and properties of the Company prior to the completion of the separation.

[0002023554-25-000034:auditors_report:66]
66

[0002023554-25-000034:auditors_report:67]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:68]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:69]
The Consolidated Statements of Operations and Comprehensive Income (Loss) included all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions, and services provided by WDC. Allocation of general corporate expenses from WDC included, but was not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs were deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Consolidated Statements of Operations. The Consolidated Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on the Company’s behalf. The Company considers these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expenses the Company would have incurred as a standalone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a standalone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.

[0002023554-25-000034:auditors_report:70]
WDC maintains various stock-based compensation plans at a corporate level. Employees of the Company participated in those programs, and a portion of the compensation costs associated with those plans was included in the Company’s Consolidated Statements of Operations for the periods presented in this Annual Report on Form 10-K. Before the spin-off, stock-based compensation expense was included within Net investment from Western Digital Corporation. The amounts presented in the Consolidated Financial Statements are not necessarily indicative of future awards and may not reflect the results that the Company would have experienced as a standalone entity.

[0002023554-25-000034:auditors_report:71]
Current and deferred income taxes and related tax expenses were determined based on the standalone results of the Company by applying Accounting Standards Codification (“ASC”) No. 740, Income Taxes, to the Company’s operations in each country as if it were a separate taxpayer (i.e., following the “Separate Return Methodology”).

[0002023554-25-000034:auditors_report:72]
Periods Post Separation

[0002023554-25-000034:auditors_report:73]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025, through June 27, 2025, are consolidated financial statements based on the Company’s reported results as a standalone company. All significant transactions and accounts between controlled entities within the Company were eliminated.

[0002023554-25-000034:auditors_report:74]
Following the separation, certain functions continue to be provided by or for WDC under the Transition Services Agreement (“TSA”) for up to fifteen months or are being performed using the Company’s own resources or third-party service providers. As of June 27, 2025, charges under the TSA were not material.

[0002023554-25-000034:auditors_report:75]
Fiscal Year

[0002023554-25-000034:auditors_report:76]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2025, 2024, and 2023, which ended on June 27, 2025, June 28, 2024, and June 30, 2023, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Fiscal year 2026 will be comprised of 52 weeks and end on July 3, 2026. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a consolidated basis.

[0002023554-25-000034:auditors_report:77]
Segment Reporting

[0002023554-25-000034:auditors_report:78]
The Company develops, manufactures, markets, and sells data storage devices and solutions based on NAND flash technology in the United States (“U.S.”) and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports its business operations under a single reportable operating segment. Operating segments are components of an enterprise for which separate financial information is available and are evaluated regularly by the Company’s Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources and in assessing performance.

[0002023554-25-000034:auditors_report:79]
The Chief Executive Officer, who is the CODM, evaluates the performance of the Company and makes resource allocation decisions for its single reportable operating segment based upon the Company’s consolidated net income (loss). The CODM considers variances of actual performance to forecasted amounts when making decisions. Asset information is not used by the CODM to evaluate performance or allocate resources.

[0002023554-25-000034:auditors_report:80]
67

[0002023554-25-000034:auditors_report:81]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:82]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:83]
See Note 9, Segment Reporting, for additional disclosures.

[0002023554-25-000034:auditors_report:84]
Use of Estimates

[0002023554-25-000034:auditors_report:85]
Management has made estimates and assumptions relating to the reporting of certain assets and liabilities in conformity with GAAP. These estimates and assumptions have been applied using methodologies that are consistent throughout the periods presented, with consideration given to the potential impacts of current macroeconomic conditions, including the evolving impacts from tariffs. However, actual results could differ materially from these estimates.

[0002023554-25-000034:auditors_report:86]
Business Separation Costs

[0002023554-25-000034:auditors_report:87]
The Company has incurred separation and transition costs related to the completion of its separation from WDC. The separation and transition costs are recorded in Business separation costs in the Consolidated Statements of Operations.

[0002023554-25-000034:auditors_report:88]
Cash Equivalents

[0002023554-25-000034:auditors_report:89]
The Company’s cash equivalents represent highly liquid investments in money market funds, which are invested in U.S. Treasury securities and U.S. Government agency securities as well as time deposits with original maturities at purchase of three months or less. These deposits are maintained at financial institutions which may exceed U.S. federal insured limits. Cash equivalents are carried at cost which approximates fair value.

[0002023554-25-000034:auditors_report:90]
Equity Investments

[0002023554-25-000034:auditors_report:91]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. The equity method of accounting is used if the Company’s ownership interest is greater than or equal to 20.0% but less than a majority or where the Company has the ability to exercise significant influence over operating and financial policies. The Company’s equity in the earnings or losses in equity-method investments is recognized in Other income (expense), net, in the Consolidated Statements of Operations. Equity earnings or losses in the Company’s equity method investments (as defined in Note 10, Related Parties and Related Commitments and Contingencies) are reported on a three-month lag.

[0002023554-25-000034:auditors_report:92]
If the Company’s ownership interest is less than 20.0% and the Company does not have the ability to exercise significant influence over operating and financial policies of the investee, the Company accounts for these investments at fair value, or if these equity securities do not have a readily determinable fair value, these securities are measured at cost minus impairment, if any, plus or minus changes resulting from observable price changes. These investments are recorded in Other non-current assets in the Consolidated Balance Sheets and are periodically analyzed to determine whether or not impairment indicators exist.

[0002023554-25-000034:auditors_report:93]
Variable Interest Entities

[0002023554-25-000034:auditors_report:94]
The Company evaluates its investments and other significant relationships to determine whether any investee is a variable interest entity (“VIE”). If the Company concludes that an investee is a VIE, the Company evaluates its power to direct the activities of the investee, its obligation to absorb the expected losses of the investee and its right to receive the expected residual returns of the investee to determine whether the Company is the primary beneficiary of the investee. If the Company is the primary beneficiary of a VIE, the Company consolidates such entity and reflects the non-controlling interest of other beneficiaries of that entity. For the period presented, the Company determined that it did not have any VIEs that are required to be consolidated.

[0002023554-25-000034:auditors_report:95]
Fair Value of Financial Instruments

[0002023554-25-000034:auditors_report:96]
The carrying amounts of cash equivalents, accounts receivable, accounts payable and accrued expenses approximate fair value for all periods presented because of the short-term maturity of these assets and liabilities. The carrying value of notes receivable from Flash Ventures (as defined in Note 10, Related Parties and Related Commitments and Contingencies) also approximates fair value for all periods presented because they bear variable market rates of interest. The fair value of investments that are not accounted for under the equity method is based on appropriate market information. The carrying amounts of Notes due to (from) Western Digital Corporation approximate their fair value as the notes were due on demand.

[0002023554-25-000034:auditors_report:97]
Inventories

[0002023554-25-000034:auditors_report:98]
The Company values inventories at the lower of cost (first-in, first-out) or net realizable value. Inventory write-downs are recorded for the valuation of inventory at the lower of cost or net realizable value by analyzing market conditions and estimates of future sales prices as compared to inventory costs and inventory balances.

[0002023554-25-000034:auditors_report:99]
68

[0002023554-25-000034:auditors_report:100]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:101]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:102]
The Company evaluates inventory balances for excess quantities and obsolescence on a regular basis by analyzing estimated demand, inventory on hand, sales levels and other information, and reduces inventory balances to net realizable value for excess and obsolete inventory based on this analysis. Unanticipated changes in technology or customer demand could result in a decrease in demand for one or more of the Company’s products, which may require a write-down of inventory that could materially affect operating results.

[0002023554-25-000034:auditors_report:103]
Property, Plant and Equipment

[0002023554-25-000034:auditors_report:104]
Property, plant, and equipment are carried at cost less accumulated depreciation and amortization. The cost of property, plant and equipment is depreciated over the estimated useful lives of the respective assets. The Company’s buildings and improvements are depreciated over periods ranging from fifteen to thirty years. The majority of the Company’s machinery and equipment, software and furniture and fixtures are depreciated on a straight-line basis over a period of two to seven years. Leasehold improvements are amortized over the lesser of the estimated useful lives of the assets or the related lease terms.

[0002023554-25-000034:auditors_report:105]
Goodwill

[0002023554-25-000034:auditors_report:106]
Goodwill attributed to the Company represents the amount by which the purchase price of businesses acquired in a business combination exceeded the estimated fair value of acquired net assets.

[0002023554-25-000034:auditors_report:107]
Goodwill is not amortized. Instead, it is tested for impairment on at least an annual basis or more frequently whenever events or changes in circumstances indicate that goodwill may be impaired. The Company performs an annual impairment test as of the beginning of its fourth quarter or sooner if an indicator of impairment exists. The Company uses qualitative factors to determine whether goodwill is more-likely-than-not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more-likely-than-not impaired, the Company is required to perform a quantitative approach to determine the amount of impairment.

[0002023554-25-000034:auditors_report:108]
The Company is required to use judgment when applying the goodwill impairment test including the identification of reporting units, assignment of assets, liabilities and goodwill to reporting units, and determination of the fair value of each reporting unit. In addition, the estimates used to determine the fair value of reporting units may change based on results of operations, macroeconomic conditions or other factors. Changes in these estimates could materially affect the Company’s assessment of the fair value and goodwill impairment.

[0002023554-25-000034:auditors_report:109]
The Company’s assessment resulted in no impairment of goodwill in 2024. In 2025 and 2023, certain macroeconomic conditions caused the Company to perform a quantitative impairment analysis which resulted in a $1.8 billion and $671 million impairment of goodwill for the years ended June 27, 2025 and June 30, 2023, respectively. See Note 5, Supplemental Financial Statement Data for additional disclosures.

[0002023554-25-000034:auditors_report:110]
Revenue and Accounts Receivable

[0002023554-25-000034:auditors_report:111]
The Company recognizes revenue when it satisfies a performance obligation by transferring control over a product or service to the customer. The transaction price to be recognized as revenue is adjusted for variable consideration, such as sales incentives, and excludes amounts collected on behalf of third parties, including taxes imposed by governmental authorities. The Company’s performance obligations are typically not constrained based on the Company’s history with similar transactions and the fact that uncertainties are resolved in a fairly short period of time.

[0002023554-25-000034:auditors_report:112]
Substantially all of the Company’s revenue is derived from the sale of tangible products for which the performance obligations are satisfied at a point in time, generally upon delivery. The Company’s services revenue mainly includes professional service arrangements and post-contract customer support, warranty as a service and maintenance contracts and was not material for the periods presented. The performance obligations for the Company’s services are generally satisfied ratably over the service period based on the nature of the service provided and contract terms. Similarly, revenue from patent licensing arrangements is recognized based on whether the arrangement provides the customer a right-to-use or right-to-access the IP. Revenue for a right to use arrangement is recognized at the time the control of the license is transferred to the customer. Revenue for a right to access arrangement is recognized over the contract period as the access is provided to the customer. For the sales-based royalty arrangements, the Company estimates and recognizes revenue in the period in which customers’ licensable sales occur.

[0002023554-25-000034:auditors_report:113]
The Company’s customer payment terms are typically less than two months from the date control over the product or service is transferred to the customer. The Company uses the practical expedient and does not recognize a significant financing component for payment considerations of less than one year.

[0002023554-25-000034:auditors_report:114]
69

[0002023554-25-000034:auditors_report:115]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:116]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:117]
The Company provides distributors and retailers, which we refer to collectively as resellers, with limited price protection for inventories held by resellers at the time of published list price reductions. The Company also provides resellers and OEMs with other sales incentive programs. The Company records estimated variable consideration related to these items as a reduction of revenue at the time of revenue recognition. The Company uses judgment in its assessment of variable consideration in contracts to be included in the transaction price. The Company uses the expected value method to arrive at the amount of variable consideration. The Company constrains variable consideration until the likelihood of a significant revenue reversal is not probable and believes that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that the Company has a large number of contracts with similar characteristics.

[0002023554-25-000034:auditors_report:118]
For sales to OEMs, the Company’s methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases from the Company or other agreed-upon sales incentive programs. For sales to resellers, the Company’s methodology for estimating variable consideration is based on several factors including historical pricing information, current pricing trends and channel inventory levels. Differences between the estimated and actual amounts of variable consideration are recognized as adjustments to revenue.

[0002023554-25-000034:auditors_report:119]
Marketing development program costs are typically recorded as a reduction of the transaction price and, therefore, of revenue. The Company nets sales rebates against open customer receivable balances if the criteria to offset are met, otherwise they are recorded in other accrued liabilities.

[0002023554-25-000034:auditors_report:120]
For contracts with multiple performance obligations, the Company evaluates whether each deliverable is a distinct promise and should be accounted for as a separate performance obligation. If a promised good or service is not distinct in accordance with the revenue guidance, the Company combines that good or service with the other promised goods or services in the arrangement until a distinct bundle of goods is identified. If applicable, the Company allocates the transaction price to the performance obligations of each distinct product or service, or distinct bundle, based on their relative standalone selling prices.

[0002023554-25-000034:auditors_report:121]
The Company records an allowance for doubtful accounts by analyzing specific customer accounts and assessing the risk of loss based on insolvency or other collection issues. In addition, the Company routinely analyzes the various receivable aging categories to establish reserves based on a combination of past due receivables and expected future losses. If the financial condition of a significant customer deteriorates resulting in its inability to pay its accounts when due, or if the Company’s overall loss trajectory changes significantly, an adjustment in the Company’s allowance for doubtful accounts would be required, which could materially affect operating results.

[0002023554-25-000034:auditors_report:122]
Warranty

[0002023554-25-000034:auditors_report:123]
The Company records an accrual for estimated warranty costs when revenue is recognized. The Company generally warrants its products for a period of one to five years, with a small number of products having a warranty ranging up to ten years or more. The warranty provision considers estimated product failure rates and trends, estimated replacement costs, estimated repair costs which include scrap costs and estimated costs for customer compensatory claims related to product quality issues, if any. For warranties ten years or greater, including lifetime warranties, the Company uses the estimated useful life of the product to calculate the warranty exposure. A statistical warranty tracking model is used to help prepare estimates and assist the Company in exercising judgment in determining the underlying estimates. The statistical tracking model captures specific details on product reliability, such as factory test data, historical field return rates and costs to repair by product type. Management’s judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited field experience with those products upon which to base warranty estimates. Management reviews the warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact current period gross profit and income. Such changes are generally a result of differences between forecasted and actual return rate experience and costs to repair and could differ significantly from the estimates.

[0002023554-25-000034:auditors_report:124]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:125]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:126]
Litigation and Other Contingencies

[0002023554-25-000034:auditors_report:127]
When the Company becomes aware of a claim or potential claim, the Company assesses the likelihood of any loss or exposure. The Company discloses information regarding each material claim where the likelihood of a loss contingency is probable or reasonably possible. If a loss contingency is probable and the amount of the loss can be reasonably estimated, the Company records an accrual for the calculated loss exposure. In such cases, there may be an exposure to potential loss in excess of the amount accrued. Where a loss is not probable but is reasonably possible or where a loss in excess of the amount accrued is reasonably possible, the Company discloses an estimate of the amount of the loss or range of possible losses for the claim if a reasonable estimate can be made, unless the amount of such reasonably possible losses is not material to the Company’s financial position, results of operations or cash flows. The ability to predict the ultimate outcome of such matters involves judgments, estimates and inherent uncertainties. The actual outcome of such matters could differ materially from management’s estimates. See Note 16, Legal Proceedings for additional disclosures related to the Company’s litigation.

[0002023554-25-000034:auditors_report:128]
Advertising Expense

[0002023554-25-000034:auditors_report:129]
Advertising costs are expensed as incurred and amounted to $29 million, $31 million, and $35 million in 2025, 2024 and 2023, respectively. These expenses are included in Selling, general and administrative in the Consolidated Statements of Operations.

[0002023554-25-000034:auditors_report:130]
Research and Development Expense

[0002023554-25-000034:auditors_report:131]
Research and Development (“R&D”) expenditures are expensed as incurred.

[0002023554-25-000034:auditors_report:132]
Income Taxes

[0002023554-25-000034:auditors_report:133]
Income taxes are calculated as if the Company filed U.S. tax returns on a stand-alone basis separate from WDC for the pre-spin period. The Company accounts for income taxes under the asset and liability method, which provides that deferred tax assets and liabilities be recognized for temporary differences between the financial reporting basis and the tax basis of assets and liabilities and expected benefits of utilizing net operating loss (“NOL”) and tax credit carryforwards. The Company records a valuation allowance when it is more-likely-than-not that the deferred tax assets will not be realized. Each quarter, the Company evaluates the need for a valuation allowance for its deferred tax assets and adjusts the valuation allowance so that the Company records net deferred tax assets only to the extent that it has concluded it is more-likely-than-not that these deferred tax assets will be realized. The assessment of valuation allowances against the Company’s deferred tax assets requires estimation and significant judgment. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. The Company accounts for interest and penalties related to income taxes as a component of the provision for income taxes.

[0002023554-25-000034:auditors_report:134]
The Company recognizes liabilities for uncertain tax positions based on a two-step process. To the extent a tax position does not meet a more-likely-than-not level of certainty, no benefit is recognized in the financial statements. If a position meets the more-likely-than-not level of certainty, it is recognized in the financial statements at the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. The actual liability for unrealized tax benefits in any such contingency may be materially different from the Company’s estimates, which could result in the need to record additional liabilities for unrecognized tax benefits or potentially adjust previously recorded liabilities for unrealized tax benefits and may materially affect the Company’s operating results.

[0002023554-25-000034:auditors_report:135]
Net Income (Loss) Per Common Share

[0002023554-25-000034:auditors_report:136]
Basic net income (loss) per common share is computed using the weighted average number of shares of common stock outstanding during the period. Diluted net income (loss) per common share is computed using the weighted average shares of common stock outstanding during the period and potentially dilutive common shares, including the effect of RSUs, PSUs, and right to purchase shares of common stock under the Company’s Employee Stock Purchase Program (“ESPP”) using the treasury stock method.

[0002023554-25-000034:auditors_report:137]
71

[0002023554-25-000034:auditors_report:138]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:139]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:140]
Stock-based Compensation Expense

[0002023554-25-000034:auditors_report:141]
Stock-based compensation represents the cost associated with stock-based awards granted to employees under stock-based compensation plans. The Company establishes stock-based compensation values at the grant date based on the estimated fair value of the award, and recognizes the cost on a straight-line basis over the requisite service period of the employee. The Company grants RSUs and PSUs subject to market conditions. RSUs are typically awarded to employees over a two- to four-year period. Market-conditioned PSUs are granted to employees with vesting conditions based on the Company’s stock price and are cliff-vested at the end of the service period. The fair value of RSUs is determined on the grant date based on the Company’s stock price at that time. The fair value of market-conditioned PSUs awards is determined on the grant date using a Monte Carlo simulation model, which estimates the probability of satisfying the market conditions of the award. Forfeitures are recognized as they occur. Stock-based compensation cost is recorded in Cost of Revenue and Operating Expenses in the Consolidated Statement of Income based on the employees’ respective functions.

[0002023554-25-000034:auditors_report:142]
Prior to the separation, the Consolidated Statements of Operations included all stock-based compensation expenses for WDC RSU and PSU awards directly attributable to Sandisk’s employees, as well as an allocation of WDC’s corporate and shared functional employees’ expenses. See Note 12, Shareholders’ Equity for additional disclosures.

[0002023554-25-000034:auditors_report:143]
Other comprehensive income (loss), net of tax

[0002023554-25-000034:auditors_report:144]
Other comprehensive income (loss), net of tax refers to gains and losses that are recorded as an element of equity but are excluded from net income (loss). The Company’s other comprehensive income (loss), net of tax, is primarily comprised of unrealized gains or losses on foreign exchange contracts designated as cash flow hedges and foreign currency translation.

[0002023554-25-000034:auditors_report:145]
Derivative Contracts

[0002023554-25-000034:auditors_report:146]
The majority of the Company’s transactions are in U.S. dollars; however, some transactions are based in various foreign currencies. The Company purchases foreign exchange contracts to hedge the impact of foreign currency exchange fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. The purpose of entering into these hedging transactions is to minimize the impact of foreign currency fluctuations on the Company’s results of operations. Substantially all of these contract maturity dates do not exceed 12 months. All foreign exchange contracts are for risk management purposes only. The Company does not purchase foreign exchange contracts for speculative or trading purposes. The Company had foreign exchange contracts with commercial banks for European euro, Canadian dollar, Japanese yen, Malaysian ringgit, Korean won and Israeli shekel, which had an aggregate notional amount of $2.5 billion and $2.9 billion at June 27, 2025 and June 28, 2024, respectively.

[0002023554-25-000034:auditors_report:147]
If the derivative is designated as a cash flow hedge and is determined to be highly effective, the change in fair value of the derivative is initially deferred in Other comprehensive income (loss), net of tax. These amounts are subsequently recognized into earnings when the underlying cash flow being hedged is recognized into earnings. Recognized gains and losses on foreign exchange contracts are reported in Cost of revenue and Operating expenses and presented in cash flows from operating activities. Hedge effectiveness is measured by comparing the hedging instrument’s cumulative change in fair value from inception to maturity to the underlying exposure’s terminal value. The Company determined the ineffectiveness associated with its cash flow hedges to be immaterial to the Consolidated Financial Statements for the periods presented.

[0002023554-25-000034:auditors_report:148]
A change in the fair value of undesignated hedges is recognized in earnings in the period incurred and is reported in Other income (expense), net.

[0002023554-25-000034:auditors_report:149]
Leases

[0002023554-25-000034:auditors_report:150]
The Company leases certain domestic and international facilities under long-term, non-cancelable operating leases that expire at various dates through 2039. These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise that option. Lease expense is recognized on a straight-line basis over the lease term.

[0002023554-25-000034:auditors_report:151]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:152]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:153]
Note 2.    Recent Accounting Pronouncements

[0002023554-25-000034:auditors_report:154]
Accounting Pronouncements Recently Adopted

[0002023554-25-000034:auditors_report:155]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands segment reporting requirements, primarily through enhanced disclosures surrounding significant segment expenses. This ASU expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity’s CODM, a description of other segment items by reportable segment, and any additional measures of a segment’s profit or loss used by the CODM when deciding how to allocate resources. These incremental disclosures are required beginning with the Company’s financial statements for the fiscal year ending 2025. The Company adopted the guidance retrospectively in the fourth quarter of fiscal 2025. See Note 9, Segment Reporting, for additional disclosures.

[0002023554-25-000034:auditors_report:156]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0002023554-25-000034:auditors_report:157]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” This ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026, with early adoption permitted. The Company expects to provide any required disclosures at that time.

[0002023554-25-000034:auditors_report:158]
In November 2024, the FASB issued ASU 2024-03, “Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses,” which is intended to improve disclosures about the expenses of public entities. This ASU requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This ASU is effective on either a prospective or retrospective basis for fiscal years beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption. The Company expects to provide any required disclosures for annual reporting periods included in the Company’s financial statements for the year ending June 30, 2028.

[0002023554-25-000034:auditors_report:159]
Note 3.    Geographic Information and Concentrations of Risk

[0002023554-25-000034:auditors_report:160]
Disaggregated Revenue

[0002023554-25-000034:auditors_report:161]
The Company’s broad portfolio of technology and products addresses multiple end markets. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its OEM and channel customers a broad array of high-performance flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

[0002023554-25-000034:auditors_report:162]
The Company’s disaggregated revenue information was as follows:

[0002023554-25-000034:auditors_report:163]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |
| Cloud | $ | 960 |  |  | $ | 325 |  |  | $ | 500 |  |
| Client | 4,127 |  |  | 4,069 |  |  | 3,637 |  |
| Consumer | 2,268 |  |  | 2,269 |  |  | 1,949 |  |
| Total revenue | $ | 7,355 |  |  | $ | 6,663 |  |  | $ | 6,086 |  |

[0002023554-25-000034:auditors_report:164]
73

[0002023554-25-000034:auditors_report:165]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:166]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:167]
The Company’s operations outside the United States include owned manufacturing facilities in Malaysia, manufacturing operations contracted via related parties in China and Japan, as well as sales offices throughout the Americas, Asia Pacific, Europe and the Middle East. The following tables summarize the Company’s operations by geographic area:

[0002023554-25-000034:auditors_report:168]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Net Revenue(1) |  |  |  |  |  |
| United States | $ | 1,447 |  |  | $ | 933 |  |  | $ | 1,133 |  |
| China | 2,040 |  |  | 2,549 |  |  | 2,302 |  |
| Hong Kong | 1,301 |  |  | 1,044 |  |  | 690 |  |
| Europe, Middle East and Africa | 1,280 |  |  | 1,058 |  |  | 930 |  |
| Rest of Asia | 1,116 |  |  | 917 |  |  | 898 |  |
| Other | 171 |  |  | 162 |  |  | 133 |  |
| Total revenue | $ | 7,355 |  |  | $ | 6,663 |  |  | $ | 6,086 |  |

[0002023554-25-000034:auditors_report:169]
(1)Net revenue is attributed to geographic regions based on the ship-to location of the customer. License and royalty revenue is attributed to countries based upon the location of the headquarters of the licensee.

[0002023554-25-000034:auditors_report:170]
Disaggregated Long-lived Assets

[0002023554-25-000034:auditors_report:171]
The Company’s long-lived assets, including property, plant and equipment by geographic area, are as follows:

[0002023554-25-000034:auditors_report:172]
|  | 2025 |  | 2024 |
|  | (in millions) |
| Long-lived assets |  |  |  |
| United States | $ | 93 |  |  | $ | 77 |  |
| China | 14 |  |  | 249 |  |
| Malaysia | 398 |  |  | 388 |  |
| Rest of Asia | 67 |  |  | 4 |  |
| Europe, Middle East and Africa | 47 |  |  | 73 |  |
| Total Long-lived assets | $ | 619 |  |  | $ | 791 |  |

[0002023554-25-000034:auditors_report:173]
Customer Concentration and Credit Risk

[0002023554-25-000034:auditors_report:174]
The Company sells its products to computer manufacturers and OEMs, cloud service providers, resellers, distributors and retailers throughout the world. For 2025 and 2024 no single customer accounted for more than 10% of the Company’s net revenue. For 2023, one customer accounted for 15% of the Company’s net revenue. For 2025, 2024 and 2023, the Company’s top 10 customers accounted for 40%, 41% and 47% of the Company’s net revenue, respectively.

[0002023554-25-000034:auditors_report:175]
The Company performs ongoing credit evaluations of its customers’ financial condition and generally requires no collateral. The Company maintains allowances for potential credit losses, and such losses have historically been within management’s expectations. At any given point in time, the total amount outstanding from any one of a number of its customers may be individually significant to the Company’s financial results. As of June 27, 2025, the Company had net accounts receivable of $1.1 billion, and one customer accounted for approximately 11% of the Company’s outstanding accounts receivable. As of June 28, 2024, the Company had net accounts receivable of $935 million, and one customer accounted for 10% of the Company’s outstanding accounts receivable. Reserves for potential credit losses were not material as of each period end.

[0002023554-25-000034:auditors_report:176]
The Company also has cash equivalent and investment policies that limit the amount of credit exposure to any one financial institution or investment instrument and requires that investments be made only with financial institutions or in investment instruments evaluated as highly credit-worthy.

[0002023554-25-000034:auditors_report:177]
74

[0002023554-25-000034:auditors_report:178]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:179]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:180]
Supplier Concentration

[0002023554-25-000034:auditors_report:181]
All of the Company’s flash products require silicon wafers for the memory and controller components. Substantially all of the Company’s flash memory wafers are currently supplied from Flash Ventures, and the Company’s controller wafers are all manufactured by third-party sources. The failure of any of these sources to deliver silicon wafers could have a material adverse effect on the Company’s business, financial condition and results of operations. See Note 10, Related Parties and Related Commitments and Contingencies for additional disclosures.

[0002023554-25-000034:auditors_report:182]
In addition, some key components are purchased from single-source vendors for which alternative sources are currently not available. Shortages could occur in these essential materials due to an interruption of supply or increased demand in the industry. If the Company was unable to procure certain of such materials, the Company’s sales could decline, which could have a material adverse effect upon its results of operations. The Company also relies on third-party subcontractors to assemble and test a portion of its products. The Company does not have long-term contracts with some of these subcontractors and cannot directly control product delivery schedules or manufacturing processes. This could lead to product shortages or quality assurance problems that could increase the manufacturing costs of the Company’s products and have material adverse effects on the Company’s operating results.

[0002023554-25-000034:auditors_report:183]
Note 4.    Revenues

[0002023554-25-000034:auditors_report:184]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements, and customer support and service contracts, which will be recognized over their contract period. The transaction price allocated to the remaining performance obligations as of 2025, 2024, and 2023, was not material.

[0002023554-25-000034:auditors_report:185]
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company did not have any contract assets as of June 27, 2025, June 28, 2024, and June 30, 2023. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service, support, and maintenance contracts. Contract liabilities as of June 27, 2025, June 28, 2024, and June 30, 2023, and changes in contract liabilities during 2025, 2024, and 2023, were not material.

[0002023554-25-000034:auditors_report:186]
The Company incurs sales commissions as direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize sales commissions as an expense when incurred if the amortization period is expected to be one year or less or the amount is not material, with these costs charged to Selling, general and administrative expenses. The Company had no other direct incremental costs to obtain contracts with an expected benefit of more than one year.

[0002023554-25-000034:auditors_report:187]
Note 5.    Supplemental Financial Statement Data

[0002023554-25-000034:auditors_report:188]
Goodwill

[0002023554-25-000034:auditors_report:189]
The following table provides a summary of goodwill activity for the period presented:

[0002023554-25-000034:auditors_report:190]
|  | (in millions) |
| Balance at June 28, 2024 | $ | 7,207 |  |
| Divestiture (1) | (382) |  |
| Impairment charges | (1,830) |  |
| Foreign currency translation adjustment | 4 |  |
| Balance at June 27, 2025 | $ | 4,999 |  |

[0002023554-25-000034:auditors_report:191]
(1) On September 28, 2024, the Company sold its majority interest in a subsidiary. See Note 10, Related Parties and Related Commitments and Contingencies for additional disclosures.

[0002023554-25-000034:auditors_report:192]
Goodwill attributed to the Company represents the historical goodwill balances in WDC’s business arising from acquisitions specific to the Company.

[0002023554-25-000034:auditors_report:193]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:194]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:195]
The Company determined that its single operating segment was also its single reporting unit. Goodwill is not amortized. Instead, it is tested for impairment annually as of the beginning of the Company’s fourth quarter or more frequently if events or changes in circumstances indicate that goodwill may be impaired. The Company uses qualitative factors to determine whether goodwill is more-likely-than-not impaired and whether a quantitative test for impairment is considered necessary. If the Company concludes from the qualitative assessment that goodwill is more-likely-than-not impaired, the Company is required to perform a quantitative assessment to determine the amount of impairment.

[0002023554-25-000034:auditors_report:196]
The Company is required to use judgment when assessing goodwill for impairment, including evaluating the impact of industry and macroeconomic conditions and the determination of the fair value of the reporting unit. In addition, the estimates and assumptions used to determine the fair value as well as the actual carrying value may change based on future changes in the Company’s results of operations, macroeconomic conditions, or other factors. Changes in these estimates and assumptions could materially affect the Company’s assessment of the fair value and goodwill impairment. In addition, if negative macroeconomic conditions continue or worsen, goodwill could become impaired, which could result in an impairment charge and materially adversely affect the Company’s financial condition and results of operations.

[0002023554-25-000034:auditors_report:197]
Subsequent to the completion of the separation, the Company identified potential impairment indicators related to macroeconomic indicators, industry developments, the trading price of the Company’s common stock and resulting market capitalization that warranted a quantitative impairment analysis of long-lived assets and goodwill.

[0002023554-25-000034:auditors_report:198]
The Company performed a recoverability test at the asset group level, which was determined to be equivalent to its reporting unit, to assess potential impairment of long-lived assets. The results of the recoverability test showed that the estimated undiscounted net cash flows to be generated from the use and eventual disposition of the Company’s long-lived assets exceeded its net carrying value. As a result, no write-down of long-lived assets was recognized as of June 27, 2025.

[0002023554-25-000034:auditors_report:199]
Next, the Company performed a quantitative test by measuring the fair value of its reporting unit based on a weighing of two valuation methodologies: an income approach and a market approach.

[0002023554-25-000034:auditors_report:200]
The income approach valued the projected discounted cash flows that are expected to be generated by the Company’s reporting unit and required judgments and estimates surrounding general economic conditions and company-specific performance inputs such as revenue growth rates, gross margins, operating costs, capital expenditures, assumed tax rates and other assumptions deemed reasonable by management.

[0002023554-25-000034:auditors_report:201]
The market approach valued the reporting unit based on financial performance and market multiples of comparable public companies, including consideration of a control premium representing the estimated amount a market participant would pay to obtain a controlling interest in the Company.

[0002023554-25-000034:auditors_report:202]
The results of the quantitative test indicated that the carrying value of the Company’s reporting unit exceeded its estimated fair value, resulting in the recognition of a $1.8 billion impairment charge during the third quarter of the year ended June 27, 2025 which was recorded in the accompanying Consolidated Statements of Operations.

[0002023554-25-000034:auditors_report:203]
The Company’s policy is to perform an annual impairment test on the first day of the fourth fiscal quarter. The Company performed a qualitative analysis, which did not indicate that goodwill was more-likely-than-not impaired. As a result, no additional quantitative analysis was required and no additional impairment charge was recorded during the fiscal year ended June 27, 2025.

[0002023554-25-000034:auditors_report:204]
For the year ended June 28, 2024, there were no impairment charges recorded. For the year ended June 30, 2023, the Company recorded an impairment charge of $671 million.

[0002023554-25-000034:auditors_report:205]
Accounts receivable, net

[0002023554-25-000034:auditors_report:206]
Prior to the separation, from time to time and in connection with factoring agreements, WDC sold certain of the Company’s trade accounts receivable without recourse to third-party purchasers in exchange for cash.

[0002023554-25-000034:auditors_report:207]
During the year ended June 27, 2025, there were no trade accounts receivable sold by WDC or the Company. In 2024 and 2023, WDC sold trade accounts receivable of the Company and received cash proceeds of $339 million and $370 million, respectively. The discounts on the trade accounts receivable sold during the period were not material and were recorded in Other expense, net, in the Consolidated Statements of Operations. There were no factored receivables outstanding as of June 27, 2025 and June 28, 2024.

[0002023554-25-000034:auditors_report:208]
76

[0002023554-25-000034:auditors_report:209]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:210]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:211]
Inventories

[0002023554-25-000034:auditors_report:212]
|  | 2025 |  | 2024 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,517 |  |  | $ | 1,398 |  |
| Work-in-process | 262 |  |  | 237 |  |
| Finished goods | 300 |  |  | 320 |  |
| Total inventories | $ | 2,079 |  |  | $ | 1,955 |  |

[0002023554-25-000034:auditors_report:213]
Property, plant and equipment, net

[0002023554-25-000034:auditors_report:214]
|  | 2025 |  | 2024 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 10 |  |  | $ | 10 |  |
| Machinery and equipment | 1,480 |  |  | 2,340 |  |
| Buildings and improvements | 390 |  |  | 397 |  |
| Computer equipment and software | 176 |  |  | 123 |  |
| Furniture and fixtures | 18 |  |  | 16 |  |
| Construction-in-process | 51 |  |  | 108 |  |
| Property, plant and equipment, gross | 2,125 |  |  | 2,994 |  |
| Accumulated depreciation | (1,506) |  |  | (2,203) |  |
| Property, plant and equipment, net | $ | 619 |  |  | $ | 791 |  |

[0002023554-25-000034:auditors_report:215]
Depreciation expense for property, plant and equipment totaled $163 million, $224 million, and $315 million in 2025, 2024, and 2023, respectively.

[0002023554-25-000034:auditors_report:216]
Intangible assets

[0002023554-25-000034:auditors_report:217]
Intangibles are amortized over the estimated useful life based on the pattern in which the economic benefits are expected to be received. As of June 27, 2025 and June 28, 2024, all finite-lived intangible assets were fully amortized. During 2023, the Company recognized intangible amortization charges of $133 million.

[0002023554-25-000034:auditors_report:218]
Product warranty liability

[0002023554-25-000034:auditors_report:219]
Changes in the warranty accrual were as follows:

[0002023554-25-000034:auditors_report:220]
|  | 2025 |  | 2024 |  | 2023 |  |  |
|  | (in millions) |
| Warranty accrual, beginning of period | $ | 48 |  |  | $ | 42 |  |  | $ | 52 |  |  |  |
| Charges to operations | 27 |  |  | 28 |  |  | 30 |  |  |  |
| Utilization | (35) |  |  | (34) |  |  | (26) |  |  |  |
| Changes in estimate related to pre-existing warranties | 4 |  |  | 12 |  |  | (14) |  |  |  |
| Warranty accrual, end of period | $ | 44 |  |  | $ | 48 |  |  | $ | 42 |  |  |  |

[0002023554-25-000034:auditors_report:221]
77

[0002023554-25-000034:auditors_report:222]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:223]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:224]
The current portion of the warranty accrual was classified in Accrued expenses and the long-term portion was classified in Other liabilities as noted below:

[0002023554-25-000034:auditors_report:225]
|  | 2025 |  | 2024 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 22 |  |  | $ | 27 |  |  |  |  |  |  |  |
| Long-term portion | 22 |  |  | 21 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 44 |  |  | $ | 48 |  |  |  |  |  |  |  |

[0002023554-25-000034:auditors_report:226]
Other liabilities

[0002023554-25-000034:auditors_report:227]
|  | 2025 |  | 2024 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current lease liability | $ | 193 |  |  | $ | 171 |  |
| Non-current net tax payable | 131 |  |  | 56 |  |
| Tax indemnification liability | 110 |  |  | — |  |
| Other non-current liabilities | 62 |  |  | 59 |  |
| Total other liabilities | $ | 496 |  |  | $ | 286 |  |

[0002023554-25-000034:auditors_report:228]
In connection with the separation, the Company recorded an initial $112 million liability to indemnify WDC as a result of the Tax Matters Agreement entered into between the parties. The indemnification pertains to certain WDC tax positions where the underlying issues are determined to be related to the Company’s business before the spin-off. As WDC receives tax assessments, settles with tax authorities, or when the statute of limitation lapses, the indemnification liabilities will be reassessed and adjusted accordingly. This liability was subsequently reduced by approximately $2 million reflecting the outstanding balance as of June 27, 2025.

[0002023554-25-000034:auditors_report:229]
Accumulated other comprehensive loss

[0002023554-25-000034:auditors_report:230]
Accumulated other comprehensive loss (“AOCL”), net of tax, refers to expenses, gains, and losses that are recorded as an element of equity but are excluded from net income. The components of AOCL were as follows:

[0002023554-25-000034:auditors_report:231]
|  | Foreign Currency Translation Adjustment |  | Unrealized Income (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 30, 2023 | $ | (165) |  |  | $ | (178) |  |  | $ | (343) |  |
| Other comprehensive loss | (43) |  |  | (87) |  |  | (130) |  |
| Income tax benefit related to items of other comprehensive loss | — |  |  | 21 |  |  | 21 |  |
| Net current-period other comprehensive loss | (43) |  |  | (66) |  |  | (109) |  |
| Balance at June 28, 2024 | $ | (208) |  |  | $ | (244) |  |  | $ | (452) |  |
| Other comprehensive income | 10 |  |  | 222 |  |  | 232 |  |
| Income tax expense related to items of other comprehensive income | — |  |  | (19) |  |  | (19) |  |
| Net current-period other comprehensive income | 10 |  |  | 203 |  |  | 213 |  |
| Net transfer to Western Digital Corporation | (4) |  |  | (6) |  |  | (10) |  |
| Balance at June 27, 2025 | $ | (202) |  |  | $ | (47) |  |  | $ | (249) |  |

[0002023554-25-000034:auditors_report:232]
During the years ended June 27, 2025 and June 28, 2024 the amounts reclassified out of AOCL included losses of $189 million and $215 million related to foreign exchange contracts. The losses related to foreign contracts were substantially all charged to Cost of revenue in the Consolidated Statements of Operations.

[0002023554-25-000034:auditors_report:233]
78

[0002023554-25-000034:auditors_report:234]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:235]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:236]
As of June 27, 2025, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months.

[0002023554-25-000034:auditors_report:237]
Note 6.    Fair Value Measurements and Investments

[0002023554-25-000034:auditors_report:238]
Financial Instruments Carried at Fair Value

[0002023554-25-000034:auditors_report:239]
Financial assets and liabilities that are remeasured and reported at fair value at each reporting period are classified and disclosed in one of the following three levels:

[0002023554-25-000034:auditors_report:240]
Level 1.    Quoted prices in active markets for identical assets or liabilities.

[0002023554-25-000034:auditors_report:241]
Level 2.    Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

[0002023554-25-000034:auditors_report:242]
Level 3.    Inputs that are unobservable for the asset or liability and that are significant to the fair value of the assets or liabilities.

[0002023554-25-000034:auditors_report:243]
The following tables present information about the Company’s financial instruments that were measured at fair value on a recurring basis for the periods presented and indicate the fair value hierarchy of the valuation techniques utilized to determine such values:

[0002023554-25-000034:auditors_report:244]
|  | June 27, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 751 |  |  | $ | — |  |  | $ | — |  |  | $ | 751 |  |
| Foreign exchange contracts (included in Other current assets) | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Total assets at fair value | $ | 751 |  |  | $ | 17 |  |  | $ | — |  |  | $ | 768 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts (included in Accrued expenses) | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |

[0002023554-25-000034:auditors_report:245]
|  | June 28, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 28 |  |  | $ | — |  |  | $ | — |  |  | $ | 28 |  |
| Foreign exchange contracts (included in Other current assets) | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total assets at fair value | $ | 28 |  |  | $ | 7 |  |  | $ | — |  |  | $ | 35 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts (included in Accrued expenses) | $ | — |  |  | $ | 179 |  |  | $ | — |  |  | $ | 179 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 179 |  |  | $ | — |  |  | $ | 179 |  |

[0002023554-25-000034:auditors_report:246]
Money Market Funds. The Company’s money market funds are funds invested in U.S. Treasury and U.S. Government agency securities. Money market funds are valued based on quoted market prices.

[0002023554-25-000034:auditors_report:247]
Foreign Exchange Contracts. The Company’s foreign exchange contracts are short-term contracts to hedge the Company’s foreign currency risk. Foreign exchange contracts are valued using an income approach that is based on the present value of a future cash flows model. The market-based observable inputs for the model include forward rates and credit default swap rates. See Note 7, Derivative Instruments and Hedging Activities for additional disclosures.

[0002023554-25-000034:auditors_report:248]
79

[0002023554-25-000034:auditors_report:249]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:250]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:251]
During the periods presented, the Company had no transfers of financial instruments between levels, and there were no changes in valuation techniques or the inputs used in the fair value measurement.

[0002023554-25-000034:auditors_report:252]
Financial Instruments Not Carried at Fair value

[0002023554-25-000034:auditors_report:253]
Financial instruments not recorded at fair value on a recurring basis (debt) had an estimated fair value of $1.9 billion as of June 27, 2025. The fair value of the debt was determined based on observable market prices in less active markets. See Note 8, Debt for additional disclosures.

[0002023554-25-000034:auditors_report:254]
Note 7.    Derivative Instruments and Hedging Activities

[0002023554-25-000034:auditors_report:255]
As of June 27, 2025, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed twelve months. As of June 27, 2025, the Company did not have any derivative contracts with credit-risk-related contingent features.

[0002023554-25-000034:auditors_report:256]
Changes in the fair values of the non-designated foreign exchange contracts are recognized in Other income (expense), net, and are largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For 2025, 2024, and 2023, total net realized and unrealized transactions and foreign exchange contract currency losses were $29 million, $4 million, and $5 million respectively.

[0002023554-25-000034:auditors_report:257]
Unrealized gains or losses on designated cash flow hedges are recognized in AOCL. See Note 5, Supplemental Financial Statement Data—Accumulated other comprehensive loss for additional disclosures.

[0002023554-25-000034:auditors_report:258]
Note 8.    Debt

[0002023554-25-000034:auditors_report:259]
Loan Agreement

[0002023554-25-000034:auditors_report:260]
Debt consisted of the following:

[0002023554-25-000034:auditors_report:261]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 1,900 |  |  | $ | — |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | — |  |
| Total Debt | 1,900 |  |  | — |  |
| Unamortized Issuance Costs | 51 |  |  | — |  |
| Subtotal | 1,849 |  |  | — |  |
| Less: current portion of long-term debt | 20 |  |  | — |  |
| Long term debt | $ | 1,829 |  |  | $ | — |  |

[0002023554-25-000034:auditors_report:262]
On February 21, 2025, the Company entered into a Loan Agreement (the “Loan Agreement”) by and among the Company, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent and the other parties party thereto. The Loan Agreement comprises a term loan B facility in the principal amount of $2.0 billion (the “Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”).

[0002023554-25-000034:auditors_report:263]
The obligations under the Loan Agreement are guaranteed by the Company’s wholly-owned subsidiary, Sandisk Technologies, Inc. (“SDT”), and are required to be guaranteed by any of the Company’s future material U.S. wholly-owned subsidiaries, subject to certain exceptions outlined in the Loan Agreement. The obligations under the Loan Agreement are secured by the Company’s assets and SDT’s assets and are required to be secured by the assets of any of the Company’s future material U.S. wholly-owned subsidiaries, subject, in each case, to certain exceptions outlined in the Loan Agreement.

[0002023554-25-000034:auditors_report:264]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that requires the Company to maintain a maximum Leverage Ratio (as defined in the Loan Agreement).

[0002023554-25-000034:auditors_report:265]
80

[0002023554-25-000034:auditors_report:266]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:267]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:268]
On February 21, 2025, the Company borrowed $2.0 billion under its Term Loan Facility. The Company used a portion of the proceeds of the borrowing to make a net distribution payment of $1.5 billion to WDC, with the remainder to be used for general corporate purposes of the Company. The Revolving Credit Facility may be borrowed by the Company from time to time for general corporate purposes.

[0002023554-25-000034:auditors_report:269]
In connection with the Loan Agreement, the Company and SDT entered into a security agreement to secure the obligations under the Facilities on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and SDT, subject to certain exceptions.

[0002023554-25-000034:auditors_report:270]
In connection with the Loan Agreement, the Company (solely with respect to obligations of any additional Borrower under the Loan Agreement) and SDT entered into a guaranty agreement to secure and unconditionally guarantee the obligations under the Loan Agreement, respectively, in each case, subject to certain exceptions.

[0002023554-25-000034:auditors_report:271]
Term Loan Facility

[0002023554-25-000034:auditors_report:272]
The Term Loan Facility bears interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an interest rate margin of 3.00% per annum or (y) a base rate plus an interest rate margin of 2.00% per annum. The selection of the interest rate index determines the interest payment frequency, which is either monthly or quarterly. The Company may elect the applicable rate at the beginning of each interest period, subject to the terms of the agreement.

[0002023554-25-000034:auditors_report:273]
The outstanding principal balance of the Term Loan Facility is required to be repaid in quarterly installments beginning on June 27, 2025, in an aggregate amount equal to 0.25% of the aggregate principal amount of the Term Loan Facility and a final payment comprised of all principal and interest due and payable at maturity on February 20, 2032.

[0002023554-25-000034:auditors_report:274]
The annualized interest rate for Term Loan Facility as of June 27, 2025 was 7%. During the year ending June 27, 2025, the Company made scheduled and voluntary payments totaling $100 million.

[0002023554-25-000034:auditors_report:275]
In connection with the issuance of the Term Loan Facility, the Company recognized issuance costs of $54 million, which will be amortized to Interest expense over the life of the facility.

[0002023554-25-000034:auditors_report:276]
For the year ended June 27, 2025, the total interest expense was $51 million and amortization of issuance cost was $3 million.

[0002023554-25-000034:auditors_report:277]
Revolving Credit Facility

[0002023554-25-000034:auditors_report:278]
Borrowings under the Revolving Credit Facility, for U.S. dollar borrowings, will bear interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement), which rate includes a credit spread adjustment of 0.10%, plus an interest rate margin of 2.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)), or (y) a base rate plus an interest rate margin of 1.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)). The Company will pay a commitment fee of 0.30% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)) in respect of undrawn revolving commitments under the Revolving Credit Facility. The Revolving Credit Facility will also provide for borrowings in Euros, Yen, and additional currencies agreed to by the lenders under the Revolving Credit Facility. The Revolving Credit Facility will mature on February 21, 2030, at which time the commitments thereunder shall be terminated and will not have any amortization.

[0002023554-25-000034:auditors_report:279]
In connection with the issuance of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which will be amortized to Interest expense over the life of the facility.

[0002023554-25-000034:auditors_report:280]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that requires the Company to maintain a maximum Leverage Ratio (as defined in the Loan Agreement). As of June 27, 2025, the Company was in compliance with the financial covenant.

[0002023554-25-000034:auditors_report:281]
As of June 27, 2025, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.

[0002023554-25-000034:auditors_report:282]
For the year ended June 27, 2025, the total commitment fee expense was $2 million and amortization of issuance costs was $1 million.

[0002023554-25-000034:auditors_report:283]
81

[0002023554-25-000034:auditors_report:284]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:285]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:286]
Maturity of Debt

[0002023554-25-000034:auditors_report:287]
As of June 27, 2025, the Company is subject to required principal payment as follows:

[0002023554-25-000034:auditors_report:288]
|  | Contractual Maturity |
|  | (in millions) |
| Fiscal year: |  |
| 2026 | $ | 20 |  |
| 2027 | 20 |  |
| 2028 | 20 |  |
| 2029 | 20 |  |
| 2030 | 20 |  |
| 2031 and thereafter | 1,800 |  |
| Total debt maturities | 1,900 |  |
| Issuance costs | (51) |  |
| Net carrying value | $ | 1,849 |  |

[0002023554-25-000034:auditors_report:289]
Subsequent to the June 27, 2025 fiscal year end, on August 4, 2025, the Company made a voluntary $100 million payment on its Term Loan Facility.

[0002023554-25-000034:auditors_report:290]
Note 9.    Segment Reporting

[0002023554-25-000034:auditors_report:291]
The following table presents the revenue, costs of revenue, operating expenses, and operating income (loss) of the Company’s reportable operating segment under its internal management reporting system, along with a reconciliation to consolidated net income (loss) before taxes. This presentation aligns with how the CODM evaluates performance and allocates resources.

[0002023554-25-000034:auditors_report:292]
|  | Year Ended |
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Revenue | $ | 7,355 |  |  | $ | 6,663 |  |  | $ | 6,086 |  |
| Costs of revenue (1) | (5,127) |  |  | (5,607) |  |  | (5,637) |  |
| Operating expenses (1) | (1,539) |  |  | (1,365) |  |  | (1,425) |  |
| Stock-based compensation expenses | (182) |  |  | (149) |  |  | (165) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | (133) |  |
| Employee termination and other | (21) |  |  | 40 |  |  | (69) |  |
| Goodwill impairment | (1,830) |  |  | — |  |  | (671) |  |
| Business separation costs | (67) |  |  | (64) |  |  | — |  |
| Strategic review | — |  |  | (20) |  |  | (20) |  |
| Gain on business divestiture | 34 |  |  | — |  |  | — |  |
| Recoveries of contamination related charges | — |  |  | 36 |  |  | — |  |
| Other | — |  |  | (2) |  |  | (1) |  |
| Total interest and other income (expense), net | (102) |  |  | (35) |  |  | 33 |  |
| Income tax expense | (162) |  |  | (169) |  |  | (141) |  |
| Net loss | $ | (1,641) |  |  | $ | (672) |  |  | $ | (2,143) |  |

[0002023554-25-000034:auditors_report:293]
(1) For the management view, Costs of revenue excludes stock-based compensation and Operating expenses excludes stock-based compensation, amortization of intangibles, employee termination, goodwill impairment, business separation/strategic review costs, gain on business divestiture and recoveries of contamination-related charges, that are presented separately in the table above.

[0002023554-25-000034:auditors_report:294]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:295]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:296]
Note 10.    Related Parties and Related Commitments and Contingencies

[0002023554-25-000034:auditors_report:297]
Flash Ventures

[0002023554-25-000034:auditors_report:298]
The Company procures substantially all of its flash-based memory wafers from its business ventures with Kioxia Corporation (“Kioxia”), which consists of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures.” The Company has a 49.9% ownership interest and Kioxia has a 50.1% ownership interest in each of these entities. Through Flash Ventures, the Company and Kioxia collaborate in the development and manufacture of flash-based memory wafers, which are manufactured by Kioxia at its wafer fabrication facilities located in Japan using semiconductor manufacturing equipment individually owned or leased by each Flash Ventures entity. Each Flash Ventures entity purchases wafers from Kioxia at cost and then resells those wafers to the Company and Kioxia at cost plus a markup.

[0002023554-25-000034:auditors_report:299]
Flash Partners. Flash Partners was formed in 2004 in connection with the construction of Kioxia’s “Y3” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0002023554-25-000034:auditors_report:300]
Flash Alliance. Flash Alliance was formed in 2006 in connection with the construction of Kioxia’s “Y4” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan.

[0002023554-25-000034:auditors_report:301]
Flash Forward. Flash Forward was formed in 2010 in connection with the construction of Kioxia’s “Y5” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. Y5 was built in two phases of approximately equal size.

[0002023554-25-000034:auditors_report:302]
New Y2. The Company has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “New Y2” 300-millimeter wafer fabrication facility located in Yokkaichi, Japan. New Y2 primarily provided additional clean room space to convert a portion of 2-dimensional (“2D”) flash-based wafer production capacity to 3-dimensional (“3D”) flash-based wafer production capacity. Production of flash-based wafers in New Y2 started in 2016.

[0002023554-25-000034:auditors_report:303]
Y6. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “Y6” 300-millimeter wafer fabrication facility in Yokkaichi, Japan. Y6 is primarily intended to provide clean room space to continue the transition of existing 2D flash-based wafer capacity to 3D flash-based wafer production capacity. Production of flash-based wafers in Y6 started in 2018.

[0002023554-25-000034:auditors_report:304]
K1. The Company also has a facility agreement with Kioxia related to the construction and operation of Kioxia’s “K1” 300-millimeter wafer fabrication facility in Kitakami, Japan. The primary purpose of K1 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer technology nodes. Production of flash-based wafers in K1 started in 2019.

[0002023554-25-000034:auditors_report:305]
Y7. In January 2022, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”. The primary purpose of Y7 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. Production of flash-based wafers in Y7 started in 2022.

[0002023554-25-000034:auditors_report:306]
K2. In June 2024, the Company entered into additional agreements regarding Flash Ventures’ investment in a new wafer fabrication facility in Kitakami, Japan, referred to as “K2”. The primary purpose of K2 is to provide clean room space to continue the transition of existing flash-based wafer capacity to newer flash technology nodes. Output from K2 is expected to begin in the first half of 2026.

[0002023554-25-000034:auditors_report:307]
In connection with the construction of these facilities, the Company makes prepayments toward future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of June 27, 2025, $946 million, with $131 million recorded in Other current assets and $815 million recorded in Other non-current assets in the Consolidated Balance Sheets, remain to be credited against future building depreciation charges. As of June 27, 2025, the Company is also committed to making additional building depreciation prepayments of $264 million, based on the Japanese yen to U.S. dollars exchange rate of ¥144.73 as of such date, payable as follows: $32 million in 2026, $121 million in 2027, $97 million in 2028 and $14 million in 2029. As of June 27, 2025, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $209 million at varying dates through fiscal 2035.

[0002023554-25-000034:auditors_report:308]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:309]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:310]
The Company accounts for its ownership position of each entity within Flash Ventures under the equity method of accounting. The financial and other support provided by the Company in all periods presented was either contractually required or the result of a joint decision to expand wafer capacity, transition to new technologies or refinance existing equipment lease commitments. Entities within Flash Ventures are VIEs. The Company evaluated whether it is the primary beneficiary of any of the entities within Flash Ventures for all periods presented and determined that it is not the primary beneficiary of any of the entities within Flash Ventures because it does not have a controlling financial interest in any of those entities. In determining whether the Company is the primary beneficiary, the Company analyzed the primary purpose and design of Flash Ventures, the activities that most significantly impact Flash Ventures’ economic performance, and whether the Company had the power to direct those activities. The Company concluded, based upon its 49.9% ownership, the voting structure and the manner in which the day-to-day operations are conducted for each entity within Flash Ventures, that the Company lacked the power to direct most of the activities that most significantly impact the economic performance of each entity within Flash Ventures.

[0002023554-25-000034:auditors_report:311]
The following table presents the notes receivable from, and equity investments in, Flash Ventures for the periods presented:

[0002023554-25-000034:auditors_report:312]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 7 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 36 |  |  | 5 |  |
| Notes receivable, Flash Forward | 316 |  |  | 485 |  |
| Investment in Flash Partners | 55 |  |  | 148 |  |
| Investment in Flash Alliance | 115 |  |  | 219 |  |
| Investment in Flash Forward | 125 |  |  | 143 |  |
| Total notes receivable and investments in Flash Ventures | $ | 654 |  |  | $ | 1,001 |  |

[0002023554-25-000034:auditors_report:313]
During 2025, the Company received distributions from Flash Ventures of $176 million.

[0002023554-25-000034:auditors_report:314]
During 2025, 2024, and 2023 the Company made net payments to Flash Ventures of $3.4 billion, $3.4 billion, and $4.2 billion respectively, for purchases of flash-based memory wafers and net loans. During 2025, 2024, and 2023 the Company received distributions from Flash Ventures of $176 million, $0 and $0 respectively.

[0002023554-25-000034:auditors_report:315]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Ventures entity. For all reporting periods presented, no loans were past due, and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0002023554-25-000034:auditors_report:316]
As of June 27, 2025, and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $279 million and $313 million, respectively.

[0002023554-25-000034:auditors_report:317]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at June 27, 2025, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0002023554-25-000034:auditors_report:318]
|  | June 27,2025 |
|  | (in millions) |
| Notes receivable | $ | 359 |  |
| Equity investments | 295 |  |
| Operating lease guarantees | 1,404 |  |
| Inventory and prepayments | 1,326 |  |
| Maximum estimable loss exposure | $ | 3,384 |  |

[0002023554-25-000034:auditors_report:319]
As of June 27, 2025, the Company’s net equity included undistributed earnings of Flash Ventures of $85 million.

[0002023554-25-000034:auditors_report:320]
84

[0002023554-25-000034:auditors_report:321]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:322]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:323]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its rolling three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that the Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0002023554-25-000034:auditors_report:324]
Flash Ventures has historically operated near 100% of its manufacturing capacity. During 2025 and 2024, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. In 2025 and 2024 the Company incurred costs of $75 million and $249 million, respectively, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue.

[0002023554-25-000034:auditors_report:325]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed with Flash Ventures for up to three months are binding and cannot be canceled.

[0002023554-25-000034:auditors_report:326]
Research and Development Activities. The Company participates in common R&D activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for 2026 are $130 million.

[0002023554-25-000034:auditors_report:327]
Off-Balance Sheet Liabilities. Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0002023554-25-000034:auditors_report:328]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of June 27, 2025:

[0002023554-25-000034:auditors_report:329]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 203 |  |  | $ | 1,404 |  |

[0002023554-25-000034:auditors_report:330]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of June 27, 2025:

[0002023554-25-000034:auditors_report:331]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| 2026 | $ | 507 |  |  | $ | 124 |  |  | $ | 631 |  |
| 2027 | 259 |  |  | 106 |  |  | 365 |  |
| 2028 | 124 |  |  | 102 |  |  | 226 |  |
| 2029 | 48 |  |  | 55 |  |  | 103 |  |
| 2030 | 16 |  |  | 63 |  |  | 79 |  |
| Total guarantee obligations | $ | 954 |  |  | $ | 450 |  |  | $ | 1,404 |  |

[0002023554-25-000034:auditors_report:332]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of June 27, 2025, no amounts have been accrued in the Consolidated Financial Statements with respect to these indemnification agreements.

[0002023554-25-000034:auditors_report:333]
85

[0002023554-25-000034:auditors_report:334]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:335]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:336]
Sale of a Majority Interest in a Subsidiary

[0002023554-25-000034:auditors_report:337]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”) an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

[0002023554-25-000034:auditors_report:338]
The Transaction closed on September 28, 2024, and SanDisk China completed the sale of 80% of its equity interest in SDSS to JCET.

[0002023554-25-000034:auditors_report:339]
Proceeds from the sale, including working capital adjustments, were $659 million (pre-tax). On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million and expects to receive the remaining $187 million pre-tax proceeds in five equal installments of approximately $37 million on September 28 of each year through September 28, 2029. As of June 27, 2025, the outstanding consideration receivable was recognized at its present value of $168 million, with $37 million classified as Other current assets and $131 million classified as Other non-current assets in the Consolidated Balance Sheets. The remaining present value discount of $19 million as of June 27, 2025 will be recognized using the effective interest method over the next five years as Interest income in the Consolidated Statements of Operations.

[0002023554-25-000034:auditors_report:340]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment in Other non-current assets in the Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other income (expense), net in the Consolidated Statements of Operations. As of June 27, 2025, the 20% retained interest in SDSS was valued at $161 million.

[0002023554-25-000034:auditors_report:341]
The Transaction resulted in a pre-tax gain of $34 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $382 million of goodwill that was allocated to SDSS.

[0002023554-25-000034:auditors_report:342]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT”) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if SDSS fails to meet its minimum annual commitment. The Supply Agreement also provides that if SDSS purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the year ended June 27, 2025, the Company made purchases of $341 million under the Supply Agreement and had a $121 million accounts payable balance due to SDSS as of June 27, 2025.

[0002023554-25-000034:auditors_report:343]
The Company also entered into an arrangement to provide certain transition services for a limited period following the closing of the Transaction. Charges under this arrangement were not material.

[0002023554-25-000034:auditors_report:344]
Unis Venture

[0002023554-25-000034:auditors_report:345]
On January 24, 2025, the Company and WDC entered into an equity transfer agreement (the “Equity Transfer Agreement”) to transfer WDC’s entire equity interest in its venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to the Company. The Unis Venture is 48% owned by the Company and 52% owned by Unis. The Unis Venture markets and sells the Company’s products in China.

[0002023554-25-000034:auditors_report:346]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:347]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:348]
Prior to the execution of the Equity Transfer Agreement, the Unis Venture was not historically managed as a component of the Company and as such, the related equity method investment was not reflected in the Company’s Consolidated Financial Statements. After the execution of the Equity Transfer Agreement, the Company accounts for its investment in the Unis Venture under the equity method of accounting. The Company’s 48% interest in the earnings of the Unis Venture will be recognized one quarter in arrears from the date the Unis Venture was transferred to the Company and will be reported in Other income (expense), net in the Consolidated Statements of Operations and was not material for the year ended June 27, 2025.

[0002023554-25-000034:auditors_report:349]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the years ended June 27, 2025, June 28, 2024, and June 30, 2023, the Company recognized approximately 1%, 1%, and 2% respectively, of its consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 1% and 4% of Accounts receivable, net, as of June 27, 2025 and June 28, 2024, respectively.

[0002023554-25-000034:auditors_report:350]
Related Party Transactions

[0002023554-25-000034:auditors_report:351]
Separation and Distribution Agreement and Other Related Party Transactions with WDC

[0002023554-25-000034:auditors_report:352]
As described in Note 1, Organization, Basis of Presentation and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, on February 21, 2025, in connection with the separation, the Company entered into several agreements that provide a framework for Sandisk’s relationship with WDC after the separation. These include, but are not limited to, the following:

[0002023554-25-000034:auditors_report:353]
•Separation and Distribution Agreement – The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Consolidated Balance Sheets were retained by WDC and certain assets and liabilities not included in the Company’s Consolidated Balance Sheets were transferred to the Company as of the date of the separation.

[0002023554-25-000034:auditors_report:354]
Separation-related adjustments resulted in a decrease to net assets and total equity of $0.6 billion and are reflected in the “Net transfers from (to) WDC, including spin-off related adjustments” line item of the Consolidated Statements of Shareholders’ Equity.

[0002023554-25-000034:auditors_report:355]
•Transition Services Agreement – The TSA governs the provision of transition services from WDC to Sandisk, and from Sandisk to WDC and its affiliates, on an interim, transitional basis following the separation.

[0002023554-25-000034:auditors_report:356]
For the year ended June 27, 2025, the Company recognized $5 million in expenses related to the TSA, and the Company expects to recognize an additional expense related to the TSA of approximately $4 million during the next twelve months.

[0002023554-25-000034:auditors_report:357]
•Tax Matters Agreement – The Tax Matters Agreement governs, among other things, WDC’s and the Company’s respective rights, responsibilities and obligations after the spin-off with respect to tax liabilities and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings and other matters regarding taxes. In addition, the Tax Matters Agreement imposes certain restrictions on the Company and its subsidiaries (including restrictions on share issuances, business combinations, sales of assets, and similar transactions) that are designed to preserve the tax-free status of the spin-off and certain related transactions.

[0002023554-25-000034:auditors_report:358]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently reduced by approximately $2 million reflecting the outstanding balance as of June 27, 2025. The remaining tax indemnification liability of $110 million is classified as Other liabilities in the Consolidated Balance Sheets as of June 27, 2025.

[0002023554-25-000034:auditors_report:359]
Notes Due to (from) Western Digital Corporation

[0002023554-25-000034:auditors_report:360]
Prior to the separation, the Company received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additionally, cash generated by the Company was lent from time to time via promissory notes to certain of WDC’s subsidiaries for use in general corporate purposes. Outstanding balances due under these financing arrangements were due on demand.

[0002023554-25-000034:auditors_report:361]
Prior to the separation, the Company had outstanding borrowings due to WDC’s subsidiaries of $553 million, inclusive of interest payable. As part of the separation, WDC contributed $550 million to the Company, and the Company repaid $6 million in cash, which included interest accrued until the date of the separation.

[0002023554-25-000034:auditors_report:362]
87

[0002023554-25-000034:auditors_report:363]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:364]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:365]
The following presents Interest expense and Interest income on notes due to (from) Western Digital Corporation, which were recorded in Interest expense and Interest income in the Consolidated Statements of Operations for the periods presented:

[0002023554-25-000034:auditors_report:366]
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Interest expense on notes due to Western Digital Corporation | $ | 7 |  |  | $ | 6 |  |  | $ | 16 |  |
| Interest (income) on notes due from Western Digital Corporation | $ | (1) |  |  | $ | (37) |  |  | $ | (29) |  |

[0002023554-25-000034:auditors_report:367]
Allocation of Corporate Expenses

[0002023554-25-000034:auditors_report:368]
Prior to the separation, WDC provided various corporate services to the Company in the ordinary course of business, including executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue or other relevant measures. Management believes the basis on which the expenses were allocated to be a reasonable reflection of the utilization of services provided to us or the benefit received by us.

[0002023554-25-000034:auditors_report:369]
Effective at the beginning of the second quarter of 2025, the Company was operationally separated from the operations that were ultimately retained by WDC following completion of the spin-off transaction. In connection with this operational separation, personnel serving the Company in shared service functions were transferred into legal entities dedicated to the Company, and substantially all assets, liabilities, and contracts pertaining to operations of the Company were transferred to legal entities dedicated to the Company as well. Accordingly, there was a substantial reduction in the pool of shared corporate overhead costs of WDC that were subject to allocation in the second and third quarters of 2025.

[0002023554-25-000034:auditors_report:370]
The table below summarizes the impact of expense allocations from WDC in the Consolidated Statements of Operations for the periods presented:

[0002023554-25-000034:auditors_report:371]
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Research and development | $ | 189 |  |  | $ | 723 |  |  | $ | 750 |  |
| Selling general, and administrative | 158 |  |  | 418 |  |  | 452 |  |
| Business separation costs | 50 |  |  | (40) |  |  | 61 |  |
| Employee termination and other charges | 5 |  |  | 64 |  |  | — |  |
| Total allocation of Corporate Expenses | $ | 402 |  |  | $ | 1,165 |  |  | $ | 1,263 |  |

[0002023554-25-000034:auditors_report:372]
The Company’s historical financial statements do not purport to reflect what results of operations, financial position, equity or cash flows would have been if Sandisk had operated as a standalone company during the periods presented.

[0002023554-25-000034:auditors_report:373]
Cash Management

[0002023554-25-000034:auditors_report:374]
Prior to the separation, WDC provided funding for the Company’s operating and investing activities, including pooled cash managed by WDC’s treasury, to fund operating expenses and capital expenditures. WDC also directly collected certain of the Company’s receivables. These activities were reflected as a component of the Net investment from Western Digital Corporation, and this arrangement is not reflective of the manner in which Sandisk would operate on a standalone company separate from WDC during the periods presented.

[0002023554-25-000034:auditors_report:375]
Western Digital Corporation Net Investment

[0002023554-25-000034:auditors_report:376]
Prior to the separation, the Net investment from Western Digital Corporation on the Consolidated Balance Sheets represented WDC’s historical investment in the Company, the net effect of transactions with and allocations from WDC, the Company’s retained earnings and the allocation to the Company of cumulative effect adjustments from the adoption of new accounting standards.

[0002023554-25-000034:auditors_report:377]
88

[0002023554-25-000034:auditors_report:378]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:379]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:380]
Net Transfers from (to) Western Digital Corporation

[0002023554-25-000034:auditors_report:381]
A reconciliation of Net transfers from (to) Western Digital Corporation on the Consolidated Statements of Shareholders’ Equity to the corresponding amounts on the Consolidated Statements of Cash Flows is as follows:

[0002023554-25-000034:auditors_report:382]
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Consolidated Statements of Shareholders’ Equity | $ | (585) |  |  | $ | 275 |  |  | $ | 376 |  |
| Notes due (to) from Western Digital Corporation | (1,223) |  |  | 113 |  |  | 316 |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | (105) |  |  | — |  |  | — |  |
| Unis venture transferred from Western Digital Corporation | (61) |  |  | — |  |  | — |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | (27) |  |  | (11) |  |  | (18) |  |
| Tax balances transferred from Western Digital Corporation | (8) |  |  | 17 |  |  | 2 |  |
| Accumulated other comprehensive loss transferred to Western Digital Corporation | 10 |  |  | — |  |  | — |  |
| Tax indemnification liability transferred to Western Digital Corporation | 112 |  |  | — |  |  | — |  |
| Net transfers (to) from Western Digital Corporation per Consolidated Statements of Cash Flows | $ | (1,887) |  |  | $ | 394 |  |  | $ | 676 |  |

[0002023554-25-000034:auditors_report:383]
As of June 27, 2025, the outstanding accounts receivable from WDC were $65 million, related to the sale of NAND components, and the outstanding accounts payable and accrued expenses due to WDC, primarily related to the TSA were $11 million.

[0002023554-25-000034:auditors_report:384]
Note 11.    Leases and Other Commitments

[0002023554-25-000034:auditors_report:385]
Leases

[0002023554-25-000034:auditors_report:386]
The Company leases certain domestic and international facilities and data center space under long-term, non-cancelable operating leases that expire at various dates through 2039. In connection with and subsequent to the separation, the Company entered into various sublease agreements with WDC under long-term, non-cancelable operating leases that expire at various dates through 2031.

[0002023554-25-000034:auditors_report:387]
These leases include no material variable or contingent lease payments. Operating lease assets and liabilities are recognized based on the present value of the remaining lease payments discounted using the Company’s incremental borrowing rate. Operating lease assets also include prepaid lease payments minus any lease incentives. Extension or termination options present in the Company’s lease agreements are included in determining the right-of-use asset and lease liability when it is reasonably certain the Company will exercise those options. Lease expense is recognized on a straight-line basis over the lease term.

[0002023554-25-000034:auditors_report:388]
The following table presents right-of-use lease assets and lease liabilities included in the Company’s Consolidated Balance Sheets:

[0002023554-25-000034:auditors_report:389]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Operating lease right-of-use assets (included in other non-current assets) | $ | 214 |  |  | $ | 179 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in accrued expenses) | 26 |  |  | 11 |  |
| Long-term operating lease liabilities (included in other liabilities) | 193 |  |  | 171 |  |
| Total operating lease liabilities | $ | 219 |  |  | $ | 182 |  |

[0002023554-25-000034:auditors_report:390]
89

[0002023554-25-000034:auditors_report:391]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:392]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:393]
The following table summarizes supplemental disclosures of operating cost and cash flow information related to operating leases:

[0002023554-25-000034:auditors_report:394]
|  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
|  | (in millions) |
| Cost of operating leases | $ | 38 |  |  | $ | 29 |  |  | $ | 21 |  |
| Cash paid for operating leases | 33 |  |  | 30 |  |  | 14 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 49 |  |  | 167 |  |  | 3 |  |
| Decrease in operating lease liabilities and right-of-use assets due to lease remeasurement | — |  |  | 71 |  |  | — |  |

[0002023554-25-000034:auditors_report:395]
The weighted average remaining lease term and discount rate for the Company’s operating leases were as follows:

[0002023554-25-000034:auditors_report:396]
|  | June 27,2025 |  | June 28,2024 |  |  |
| Weighted average remaining lease term in years | 11.00 |  | 13.7 |  |  |
| Weighted average discount rate | 7.3 | % |  | 7.5 | % |  |  |

[0002023554-25-000034:auditors_report:397]
As of June 27, 2025, minimum lease payments were as follows:

[0002023554-25-000034:auditors_report:398]
|  | Lease Amounts |
|  | (in millions) |
| Minimum lease payments by fiscal year: |  |
| 2026 | $ | 41 |  |
| 2027 | 35 |  |
| 2028 | 28 |  |
| 2029 | 24 |  |
| 2030 | 20 |  |
| Thereafter | 183 |  |
| Total future minimum lease payments | 331 |  |
| Less: Imputed interest | 112 |  |
| Present value of lease liabilities | $ | 219 |  |

[0002023554-25-000034:auditors_report:399]
Sale-Leaseback

[0002023554-25-000034:auditors_report:400]
In September 2023, WDC completed a sale and leaseback of its facility in Milpitas, California and received net proceeds of $191 million in cash. A substantial majority of these assets are associated with the Company, and as a result, $134 million of the net proceeds from the sale-leaseback transaction were allocated to us on a relative square footage basis and reflected as a cash inflow from investing activities in the Consolidated Statements of Cash Flows for the year ended March 29, 2024. In connection with the sale and leaseback, the Company recorded a gain of $60 million upon the closing of the transaction. For more information, see Note 15, Employee Termination and Other Charges for additional disclosures.

[0002023554-25-000034:auditors_report:401]
The property is being leased back to the Company at a total annual rate of $16 million for the first year and increasing by 3% per year thereafter through January 1, 2039. The lease includes three five-year renewal options and one four-year renewal option for the ability to extend through December 2057. The associated operating lease liability and right-of-use asset for this facility has been included in the Consolidated Balance Sheets as of June 27, 2025 and June 28, 2024.

[0002023554-25-000034:auditors_report:402]
90

[0002023554-25-000034:auditors_report:403]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:404]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:405]
Purchase Agreements and Other Commitments

[0002023554-25-000034:auditors_report:406]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the coming months, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into long-term agreements with suppliers that contain fixed future commitments, which are contingent upon certain conditions such as performance, quality and technology of the vendor’s components. As of June 27, 2025, the Company had the following minimum long-term commitments:

[0002023554-25-000034:auditors_report:407]
|  | Long-term commitments |
|  | (in millions) |
| Fiscal year: |  |
| 2026 | $ | 250 |  |
| 2027 | 583 |  |
| 2028 | 570 |  |
| 2029 | 570 |  |
| 2030 | 570 |  |
| Thereafter | 90 |  |
| Total | $ | 2,633 |  |

[0002023554-25-000034:auditors_report:408]
Note 12.     Shareholders’ Equity

[0002023554-25-000034:auditors_report:409]
Prior to the separation, certain of the Company’s employees participated in WDC’s stock incentive plans (the “WDC Plans”), whereby all awards granted under the plans consisted of WDC common stock. The Stock-based compensation expense recognized in the Company’s Consolidated Financial Statements was determined based upon employees who participated in the WDC Plans and exclusively supported the Company’s operations, as well as an allocation of WDC’s corporate and shared employee stock-based compensation expenses.

[0002023554-25-000034:auditors_report:410]
In connection with the separation, all outstanding RSU and PSU awards held by former employees of WDC and its affiliates, who became Sandisk employees after the separation, were adjusted pursuant to conversion ratios determined in accordance with the terms of the Employee Matters Agreement. Outstanding RSU and PSU awards held by employees in the positions of Vice President and above as of the separation date were converted into RSU or PSU awards of Sandisk shares and RSU awards of WDC shares on a ratio of one-third (1/3) of one share of the Company’s common stock for each WDC award held by each such employee. For all other employees, the value of the converted RSU awards was designed to preserve the aggregate intrinsic value of the award immediately after the separation when compared to the aggregate intrinsic value of those award immediately prior to separation. Pursuant to the Employee Matters Agreement, the converted awards shall generally continue to be subject to the same terms and conditions as were applicable to the original WDC awards, including with respect to vesting, except as described in the Employee Matters Agreement. As a result of the conversion, the Company will incur approximately $41 million of incremental stock-based compensation expense over the remaining service period for the awards. Of this amount, $11 million was recognized during the year ended June 27, 2025, and approximately $30 million will be recognized over the awards’ remaining service periods.

[0002023554-25-000034:auditors_report:411]
Additionally, the Company adopted the following incentive plans for Sandisk employees: (i) Sandisk Corporation 2025 Long-Term Incentive Plan (the “2025 Long-Term Incentive Plan”), and (ii) Sandisk Corporation 2025 Employee Stock Purchase Plan. Grants of equity awards made after the separation to the Company’s executive officers and other employees will be made under the 2025 Long-Term Incentive Plan, which became effective on January 25, 2025.

[0002023554-25-000034:auditors_report:412]
2025 Long-Term Incentive Plan

[0002023554-25-000034:auditors_report:413]
The types of awards that may be granted include stock options, stock appreciation rights, RSUs, PSUs, cash awards, and other stock-based awards. Persons eligible to receive awards include officers and employees of the Company or any of its subsidiaries, members of the Board and certain consultants and advisors. The vesting of awards is determined at the grant date. Each award expires on a date determined at the grant date. RSUs typically vest over periods ranging from two to four years from the grant date. PSUs are granted to certain employees and vest only after the achievement of a predetermined performance or market conditions and completion of requisite service periods. Once the performance or market conditions are met, the employee’s vesting of PSUs is generally subject to continued service.

[0002023554-25-000034:auditors_report:414]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:415]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:416]
As of June 27, 2025, the maximum number of shares of the Company’s common stock that was authorized for award grants was 23.8 million shares. The 2025 Long-Term Incentive Plan terminates on January 25, 2035, unless terminated earlier by the Company’s Board of Directors.

[0002023554-25-000034:auditors_report:417]
2025 Employee Stock Purchase Plan

[0002023554-25-000034:auditors_report:418]
The Company has an ESPP under which WDC, as its then sole stockholder, has approved an aggregate of approximately 4.3 million shares of common stock for issuance to eligible employees. The fair value of the award at the grant date is based on the Black-Scholes valuation model. The plan permits eligible employees to purchase common stock, through payroll deductions, at 95% of the fair market value of a share of common stock on the first day of the 24-month offering period in which the employees are participating or 95% of the fair market value of a share of common stock on the applicable exercise date, whichever is lower. Rights to purchase shares are granted during the second and fourth quarters of each year.

[0002023554-25-000034:auditors_report:419]
After the separation, the Company had an offering period starting on April 1, 2025 and ending on May 31, 2025. Following the end of this offering period, the Company will initiate regular offering periods of six months each generally beginning on June 1st and December 1st.

[0002023554-25-000034:auditors_report:420]
As of June 27, 2025, the Company issued 0.1 million shares under the ESPP for aggregate purchase amounts of $5 million.

[0002023554-25-000034:auditors_report:421]
Stock-based Compensation Expense

[0002023554-25-000034:auditors_report:422]
The following tables present the Company’s stock-based compensation expense for equity-settled awards by type, financial statement line, and the related tax benefit included in the Company’s Consolidated Statements of Operations:

[0002023554-25-000034:auditors_report:423]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| RSUs and PSUs | $ | 171 |  |  | $ | 133 |  |  | $ | 148 |  |
| ESPP | 11 |  |  | 16 |  |  | 17 |  |
| Total | $ | 182 |  |  | $ | 149 |  |  | $ | 165 |  |

[0002023554-25-000034:auditors_report:424]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Cost of revenue | $ | 16 |  |  | $ | 20 |  |  | $ | 19 |  |
| Research and development | 81 |  |  | 71 |  |  | 88 |  |
| Selling general, and administrative | 85 |  |  | 58 |  |  | 58 |  |
| Subtotal | $ | 182 |  |  | $ | 149 |  |  | $ | 165 |  |
| Tax benefit | (22) |  |  | (21) |  |  | (22) |  |
| Total | $ | 160 |  |  | $ | 128 |  |  | $ | 143 |  |

[0002023554-25-000034:auditors_report:425]
Any shortfalls or excess windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, were not material for the periods presented.

[0002023554-25-000034:auditors_report:426]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP are amortized on a straight-line basis over the remaining service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of June 27, 2025:

[0002023554-25-000034:auditors_report:427]
|  | Unamortized Compensation Costs |  | Weighted average service period |
|  | (in millions) |  | (years) |
| RSUs and PSUs | $ | 315 |  |  | 2.27 |
| ESPP | 16 |  |  | 1.81 |
| Total unamortized compensation cost | $ | 331 |  |  |  |

[0002023554-25-000034:auditors_report:428]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:429]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:430]
RSUs and PSUs

[0002023554-25-000034:auditors_report:431]
The following table summarizes RSU and PSU award activity under the Company’s incentive plans during the year ended June 27, 2025:

[0002023554-25-000034:auditors_report:432]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  |  |
| RSUs and PSUs outstanding at June 28, 2024 | — |  |  | $ | — |  |  | $ | — |  |
| Awards converted from Western Digital Corporation Plans (1) | 6.4 |  |  | 35.32 |  |  | — |  |
| Granted | 1.5 |  |  | 50.47 |  |  | — |  |
| Vested | (1.1) |  |  | 34.07 |  |  | 46.95 |  |
| Canceled/forfeited | (0.2) |  |  | 36.14 |  |  | — |  |
| RSUs and PSUs outstanding at June 27, 2025 | 6.6 |  |  | $ | 38.98 |  |  | $ | — |  |

[0002023554-25-000034:auditors_report:433]
(1) This amount excludes 3.1 million of WDC equity awards held by Sandisk employees, which upon vesting will be issued in WDC shares instead of the Company’s shares.

[0002023554-25-000034:auditors_report:434]
RSUs and PSUs are generally settled in an equal number of shares of the Company’s common stock upon vesting. Forfeitures are recognized as they occur.

[0002023554-25-000034:auditors_report:435]
Fair Value Assumptions

[0002023554-25-000034:auditors_report:436]
RSU and PSU Grants

[0002023554-25-000034:auditors_report:437]
The fair value of the Company’s RSU and PSU awards with a performance condition is determined based upon the closing price of the Company’s stock price on the grant date. The fair value of PSU awards with a market condition is estimated using a Monte Carlo simulation model on the grant date.

[0002023554-25-000034:auditors_report:438]
ESPP - Black-Scholes-Merton Model

[0002023554-25-000034:auditors_report:439]
The fair value of ESPP purchase rights issued is estimated at the grant date of the purchase rights using the Black-Scholes-Merton option pricing model. The Black-Scholes-Merton option pricing model requires the input of assumptions such as the expected stock price volatility and the expected period until options are exercised. Purchase rights under the ESPP are generally granted on either June 1st or December 1st of each year.

[0002023554-25-000034:auditors_report:440]
The fair values of ESPP purchase rights have been estimated at the grant date using a Black-Scholes-Merton option pricing model with the following weighted average assumptions:

[0002023554-25-000034:auditors_report:441]
|  | 2025 |  |  |  |  |
| Weighted-average expected term (in years) | 0.93 |  |  |  |  |
| Risk-free interest rate | 4.02 | % |  |  |  |  |
| Stock price volatility | 0.56 |  |  |  |  |  |
| Dividend yield | — | % |  |  |  |  |
| Fair value | $ | 11.85 |  |  |  |  |  |

[0002023554-25-000034:auditors_report:442]
Note 13.     Net Income (loss) per Common Share

[0002023554-25-000034:auditors_report:443]
The separation was executed through WDC’s pro rata distribution of 80.1% of the outstanding shares of common stock of the Company to holders of WDC’s common stock as of February 21, 2025. On the separation date, the Company issued 145 million shares of common stock, par value $0.01 per share. This share amount is utilized for the calculation of basic and diluted earnings per share for all periods presented prior to the separation, and these shares are treated as issued and outstanding for purposes of calculating historical earnings per share. For periods prior to the separation, it is assumed that there are no dilutive equity instruments as there were no equity awards of Sandisk outstanding prior to the separation.

[0002023554-25-000034:auditors_report:444]
93

[0002023554-25-000034:auditors_report:445]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:446]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:447]
The following table presents the computation of basic and diluted income (loss) per common share:

[0002023554-25-000034:auditors_report:448]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions, except per share amounts) |
| Net income (loss) | $ | (1,641) |  |  | $ | (672) |  |  | $ | (2,143) |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic and diluted | 145 |  |  | 145 |  |  | 145 |  |
| Net loss per common share: |  |  |  |  |  |
| Basic and diluted | $ | (11.32) |  |  | $ | (4.63) |  |  | $ | (14.78) |  |
| Dilutive weighted-average shares (1) | 2 |  | — |  | — |

[0002023554-25-000034:auditors_report:449]
(1) Dilutive stock-based awards were excluded from the calculation of diluted shares because their effect would have been anti-dilutive.

[0002023554-25-000034:auditors_report:450]
Basic net income (loss) per share is computed using (i) net income (loss) divided by (ii) weighted average basic shares outstanding. Diluted net income (loss) per share is computed as (i) net income divided by (ii) weighted average diluted shares outstanding. The treasury stock method is used to determine the dilutive impact of unvested equity awards.

[0002023554-25-000034:auditors_report:451]
Potentially dilutive shares include dilutive outstanding employee RSUs, PSUs, and rights to purchase shares of common stock under the ESPP. For the year ended June 27, 2025, the Company recorded net losses, and as such, all potentially dilutive securities have been excluded from those periods as including them would be anti-dilutive.

[0002023554-25-000034:auditors_report:452]
Note 14.    Income Tax Expense

[0002023554-25-000034:auditors_report:453]
Income (Loss) Before Taxes

[0002023554-25-000034:auditors_report:454]
The domestic and foreign components of Income (loss) before taxes were as follows:

[0002023554-25-000034:auditors_report:455]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Foreign | $ | (1,348) |  |  | $ | (543) |  |  | $ | (2,253) |  |
| Domestic | (131) |  |  | 40 |  |  | 251 |  |
| Income (loss) before taxes | $ | (1,479) |  |  | $ | (503) |  |  | $ | (2,002) |  |

[0002023554-25-000034:auditors_report:456]
Income Tax Expense

[0002023554-25-000034:auditors_report:457]
The components of income tax expense were as follows:

[0002023554-25-000034:auditors_report:458]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Foreign | $ | 165 |  |  | $ | 158 |  |  | $ | 138 |  |
| U.S. - Federal | 7 |  |  | 20 |  |  | 76 |  |
| U.S. - State | 2 |  |  | 7 |  |  | 8 |  |
|  | 174 |  |  | 185 |  |  | 222 |  |
| Deferred: |  |  |  |  |  |
| Foreign | (13) |  |  | 7 |  |  | (15) |  |
| U.S. - Federal | 1 |  |  | (19) |  |  | (65) |  |
| U.S. - State | — |  |  | (4) |  |  | (1) |  |
|  | (12) |  |  | (16) |  |  | (81) |  |
| Income tax expense | $ | 162 |  |  | $ | 169 |  |  | $ | 141 |  |

[0002023554-25-000034:auditors_report:459]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:460]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:461]
H.R.1, more widely known as the One Big Beautiful Bill Act, was recently signed into law on July 4, 2025. It reversed the requirement for capitalization of U.S. research and development expenditures that came into law under the Tax Cuts and Jobs Act of 2017, but the mandatory requirement of capitalization of foreign research and development expenditures remains. The tax rates for income earned by our foreign subsidiaries will also be changed under H.R. 1. Depending on the Company’s operating results, these changes can materially impact the Company’s effective tax rate and reduce its operating cash flows. As H.R.1 was enacted after our fiscal year 2025, its impact on the tax provision will be reflected in fiscal year 2026.

[0002023554-25-000034:auditors_report:462]
On August 16, 2022, the Inflation Reduction Act of 2022 was signed into law, which contained significant changes to laws related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. The Company does not expect to be subject to the CAMT of 15% for 2025 as its average annual AFSI did not exceed $1.0 billion for the preceding three-year period.

[0002023554-25-000034:auditors_report:463]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 (“OECD/G20”) Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two”). Several non-U.S. jurisdictions have either enacted legislation or announced their intention to enact future legislation to adopt certain or all components of Pillar Two, some of which are effective for the Company in 2025. For 2025, the Company currently expects to be able to meet certain transitional safe harbors and does not expect any material Pillar Two taxes. As more jurisdictions adopt this legislation in 2026, there may be material increases in the Company’s future tax obligations in certain jurisdictions.

[0002023554-25-000034:auditors_report:464]
The following table presents the Company’s Income tax expense and the effective tax rate:

[0002023554-25-000034:auditors_report:465]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Income (loss) before taxes | $ | (1,479) |  |  | $ | (503) |  |  | $ | (2,002) |  |
| Income tax expense | 162 |  |  | 169 |  |  | 141 |  |
| Effective tax rate | (11) | % |  | (34) | % |  | (7) | % |

[0002023554-25-000034:auditors_report:466]
The relative mix of earnings and losses by jurisdiction, the goodwill impairment, the foreign income inclusion, credits, and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the year ended June 27, 2025.

[0002023554-25-000034:auditors_report:467]
The primary drivers of the difference between the effective tax rate for the years ended June 28, 2024 and the U.S. federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the foreign income inclusion, credits, and tax holidays in Malaysia.

[0002023554-25-000034:auditors_report:468]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:469]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:470]
Deferred Taxes

[0002023554-25-000034:auditors_report:471]
Temporary differences and carryforwards, which give rise to a significant portion of deferred tax assets and liabilities were as follows:

[0002023554-25-000034:auditors_report:472]
|  | June 27,2025 |  | June 28,2024 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Sales related reserves and accrued expenses not currently deductible | $ | 38 |  | $ | $ | 45 |  |
| Accrued compensation and benefits not currently deductible | 29 |  | 34 |
| Net operating loss carryforward | 41 |  | 19 |
| Business credit carryforward | 44 |  | — |  |
| Long-lived assets | 22 |  | 15 |
| Interest and hedging costs not currently deductible | 15 |  | 67 |
| Other | 15 |  | 27 |
| Total deferred tax assets | 204 |  |  | 207 |  |
| Deferred tax liabilities: |  |  |  |
| Long-lived assets | (7) |  |  | (3) |  |
| Unremitted Earnings of Certain Non-US Entities | (77) |  |  | (86) |  |
| Other | (18) |  |  | (10) |  |
| Total deferred tax liabilities | (102) |  |  | (99) |  |
| Valuation allowances | (61) |  |  | (27) |  |
| Deferred tax assets, net | $ | 41 |  |  | $ | 81 |  |

[0002023554-25-000034:auditors_report:473]
The decrease in the net deferred tax assets is attributable primarily to a decrease in hedging costs not currently deductible and is based on the Company’s position in its foreign exchange contracts. The Company continues to assess and adjust its valuation allowance based on operating results and market conditions. After weighing both the positive and negative evidence available, including, but not limited to, earnings history, projected future outcomes, industry and market trends and the nature of each of the deferred tax assets, the Company determined that it is able to realize its deferred tax assets except for certain loss and credit carryforwards.

[0002023554-25-000034:auditors_report:474]
The Company is permanently reinvested with respect to certain foreign earnings. There is no unrecognized deferred tax liability associated with the repatriation of these foreign undistributed earnings as it can be achieved without additional federal tax consequences.

[0002023554-25-000034:auditors_report:475]
96

[0002023554-25-000034:auditors_report:476]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:477]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:478]
Effective Tax Rate

[0002023554-25-000034:auditors_report:479]
Reconciliation of the U.S. federal statutory rate to the Company’s effective tax rate is as follows:

[0002023554-25-000034:auditors_report:480]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| U.S. federal statutory rate | 21 | % |  | 21 | % |  | 21 | % |
| Tax rate differential on international incomes | (1) |  |  | (42) |  |  | (29) |  |
| Foreign withholding tax | (1) |  |  | (11) |  |  | (2) |  |
| Change in valuation allowance | — |  |  | (2) |  |  | — |  |
| Tax effect of U.S foreign income inclusion | (7) |  |  | (1) |  |  | — |  |
| Tax effect of U.S. foreign derived intangible income | 1 |  |  | 2 |  |  | 3 |  |
| Tax effect of permanent differences | — |  |  | (2) |  |  | (1) |  |
| Tax effect of goodwill impairment | (26) |  |  | — |  |  | (7) |  |
| Tax effect of intangible assets | — |  |  | 1 |  |  | 4 |  |
| Tax rate change | — |  |  | 1 |  |  | — |  |
| Unremitted earnings of certain non-U.S. entities | (2) |  |  | 2 |  |  | — |  |
| Change in uncertain tax positions | (1) |  |  | (12) |  |  | 1 |  |
| Return to provision adjustment | 1 |  |  | (1) |  |  | — |  |
| Foreign income tax credits | 4 |  |  | 5 |  |  | 1 |  |
| R&D tax credits | 1 |  |  | 3 |  |  | 1 |  |
| Federal audit settlements | — |  |  | 3 |  |  | — |  |
| Other | (1) |  |  | (1) |  |  | 1 |  |
| Effective income tax rate | (11) | % |  | (34) | % |  | (7) | % |

[0002023554-25-000034:auditors_report:481]
Tax Holidays and Carryforwards

[0002023554-25-000034:auditors_report:482]
A substantial portion of the Company’s manufacturing operations in Malaysia operate under various tax holidays and tax incentive programs, which will expire in whole or in part at various dates during 2028 through 2031. Certain tax holidays and tax incentive programs may be extended if specific conditions are met.

[0002023554-25-000034:auditors_report:483]
The net impact of these tax holidays and tax incentives was an increase to the Company’s net earnings by $82 million, or $0.56 per share, in 2025. The Company was at loss in Malaysia during 2024 and 2023. The tax incentives had no impact on the Company’s net earnings.

[0002023554-25-000034:auditors_report:484]
As of June 27, 2025, the Company had $38 million of state tax credit carryforwards that do not expire.

[0002023554-25-000034:auditors_report:485]
As of June 27, 2025, the Company had varying amounts of NOL carryforwards, totaling $2.1 billion, that do not expire or, if not used, expire in various years beginning in 2028, depending on the country. The majority of the NOL carryforwards reside in Malaysia.

[0002023554-25-000034:auditors_report:486]
Uncertain Tax Positions

[0002023554-25-000034:auditors_report:487]
With the exception of certain unrecognized tax benefits that are directly associated with the tax position taken, unrecognized tax benefits are presented gross in the Consolidated Balance Sheets.

[0002023554-25-000034:auditors_report:488]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:489]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:490]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits, excluding accrued interest and penalties for the year ended June 27, 2025:

[0002023554-25-000034:auditors_report:491]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Unrecognized tax benefit, beginning balance | $ | 47 |  |  | $ | 25 |  |  | $ | 17 |  |
| Gross increases related to prior year tax positions | 6 |  |  | 10 |  |  | 1 |  |
| Gross increases related to current year tax positions | 17 |  |  | 15 |  |  | 10 |  |
| Gross decrease related to prior year tax positions | (1) |  |  | (3) |  |  | (3) |  |
| Gross increase related to transfer from Western Digital Corporation | 78 |  |  | — |  |  | — |  |
| Gross decrease related to settlement | (7) |  |  | — |  |  | — |  |
| Unrecognized tax benefit, ending balance | $ | 140 |  |  | $ | 47 |  |  | $ | 25 |  |

[0002023554-25-000034:auditors_report:492]
As of June 27, 2025 and June 28, 2024, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $140 million and $47 million, respectively. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of June 27, 2025 and June 28, 2024 was $11 million and $9 million, respectively.

[0002023554-25-000034:auditors_report:493]
The Company files U.S. federal, U.S. state, and foreign tax returns. Its U.S. federal and state tax returns for fiscal year 2025 are initial filings. The Company is currently subject to, or could become subject to, tax authority examinations in various jurisdictions for previously filed returns dating back as early as 2009.

[0002023554-25-000034:auditors_report:494]
The Company believes that an adequate provision has been made for any adjustments that may result from any other tax examinations. However, the outcome of such tax examinations cannot be predicted with certainty. If any issues addressed in the Company’s tax examinations are resolved in a manner inconsistent with management’s expectations, the Company may be required to adjust its provision for income taxes in the period in which such resolution occurs. As of June 27, 2025, it was not possible to estimate the amount of change, if any, in the unrecognized tax benefits that is reasonably possible within the next twelve months. Any significant change in the amount of the Company’s liability for unrecognized tax benefits would most likely result from additional information resulting from the examination of the Company’s tax returns.

[0002023554-25-000034:auditors_report:495]
Note 15.    Employee Termination and Other Charges

[0002023554-25-000034:auditors_report:496]
Business Realignment

[0002023554-25-000034:auditors_report:497]
The Company periodically incurs charges to realign its operations with anticipated market demand, primarily consisting of organization rationalization designed to streamline its business, reduce its cost structure and focus its resources. The Company has taken actions to reduce the amount of capital invested in facilities, including the sale-leaseback of its facility in Milpitas, California, in September 2023, as discussed in Note 11, Leases and Other Commitments.

[0002023554-25-000034:auditors_report:498]
The Company recorded the following net charges related to these actions for the periods presented:

[0002023554-25-000034:auditors_report:499]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Employee termination benefits | $ | 18 |  |  | $ | 15 |  |  | $ | 68 |  |
| Other charges (gains): |  |  |  |  |  |
| Asset impairments and other charges (gains) | — |  |  | 5 |  |  | 1 |  |
| Contract termination and other | 3 |  |  | — |  |  | — |  |
| Gain on sale-leaseback of facility | — |  |  | (60) |  |  | — |  |
| Total employee termination and other charges | $ | 21 |  |  | $ | (40) |  |  | $ | 69 |  |

[0002023554-25-000034:auditors_report:500]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:501]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:502]
The following table presents an analysis of the components of the activity against the reserve during the years ended June 27, 2025, and June 28, 2024, which consisted entirely of employee termination benefits:

[0002023554-25-000034:auditors_report:503]
|  | Employee Termination Benefits |
|  | (in millions) |
| Accrual balance at June 30, 2023 | $ | 3 |  |
| Charges | 15 |  |
| Cash payments | (18) |  |
| Accrual balance at June 28, 2024 | — |  |
| Charges | 18 |  |
| Cash payments | (3) |  |
| Accrual balance at June 27, 2025 | $ | 15 |  |

[0002023554-25-000034:auditors_report:504]
Note 16.    Legal Proceedings

[0002023554-25-000034:auditors_report:505]
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.

[0002023554-25-000034:auditors_report:506]
Note 17.    Summarized Financial Information

[0002023554-25-000034:auditors_report:507]
Pursuant to Rule 4-08(g) of Regulation S-X under the Securities Act of 1933, as amended, the Company presents, on an equity method basis, summarized financial information for its non-consolidated joint ventures, including the Flash Ventures, the Unis Venture, and SDSS. The summarized financial information below includes the portions attributable to both the Company and the other investees in these entities.

[0002023554-25-000034:auditors_report:508]
The Company has been an investee in the Flash Ventures for all periods presented. The Company’s investment in SDSS was established upon the divestiture of the business on September 28, 2024, and its investment in the Unis Venture was transferred to the Company on January 24, 2025, See Note 10, Related Parties and Related Commitments and Contingencies for additional disclosures.

[0002023554-25-000034:auditors_report:509]
Accordingly, the summarized financial information of these ventures for the year ended June 30, 2025 includes the results of Flash Ventures, the Unis Venture and SDSS; whereas the comparative periods for the years ended June 28, 2024 and June 30, 2023, include only the Flash Ventures.

[0002023554-25-000034:auditors_report:510]
The table below presents the combined summarized financial information for these periods:

[0002023554-25-000034:auditors_report:511]
|  | 2025 |  | 2024 |
|  | (in millions) |
| Current assets | $ | 1,423 |  |  | $ | 777 |  |
| Non-current assets | 6,185 |  |  | 5,783 |  |
| Total Assets | 7,608 |  |  | 6,560 |  |
| Current Liabilities | 2,797 |  |  | 2,225 |  |
| Non-current Liabilities | 3,701 |  |  | 3,312 |  |
| Total Liabilities | 6,498 |  |  | 5,537 |  |
| Total net equity of investees | $ | 1,110 |  |  | $ | 1,023 |  |

[0002023554-25-000034:auditors_report:512]
99

[0002023554-25-000034:auditors_report:513]
SANDISK CORPORATION

[0002023554-25-000034:auditors_report:514]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0002023554-25-000034:auditors_report:515]
|  | 2025 |  | 2024 |  | 2023 |
|  | (in millions) |
| Net sales | $ | 2,315 |  |  | $ | 2,252 |  |  | $ | 2,788 |  |
| Gross profit (loss) | (101) |  |  | (51) |  |  | 138 |  |
| Net income (loss) | $ | (63) |  |  | $ | (9) |  |  | $ | 89 |  |

[0002023554-25-000034:auditors_report:516]
100


## item_9a

[0002023554-25-000034:item_9a:1]
Item 9A.    Controls and Procedures

[0002023554-25-000034:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0002023554-25-000034:item_9a:3]
As required by Rule 13a-15(b) promulgated by the U.S. Securities and Exchange Commission under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Annual Report on Form 10-K. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Annual Report on Form 10-K, our disclosure controls and procedures were effective.

[0002023554-25-000034:item_9a:4]
Internal Control over Financial Reporting

[0002023554-25-000034:item_9a:5]
Due to a transition period established by SEC rules applicable to newly public companies, this Annual Report on Form 10-K does not include a report of management’s assessment regarding internal control over financial reporting or an attestation report of our independent registered public accounting firm.

[0002023554-25-000034:item_9a:6]
Changes in Internal Control over Financial Reporting

[0002023554-25-000034:item_9a:7]
Due to a transition period established by SEC rules applicable to newly public companies, our management is not required to evaluate the effectiveness of our internal control over financial reporting until after the filing of our Annual Report on Form 10-K for the year ended June 27, 2025. As a result, this Annual Report on Form 10-K does not address whether there have been any changes in our internal control over financial reporting.
