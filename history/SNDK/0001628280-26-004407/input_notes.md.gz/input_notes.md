# SNDK notes — 0001628280-26-004407


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-26-004407:notes:1]
[same as prior period, unchanged from 0001628280-25-050698:notes:1]

[0001628280-26-004407:notes:2]
Sandisk Corporation (“Sandisk” or the “Company”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, Sandisk’s broad and ever-expanding portfolio delivers powerful flash storage solutions for artificial intelligence (“AI”) workloads in datacenters, edge devices, and consumer applications. Sandisk’s technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. The Company’s solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. The Company’s broad portfolio of technology and products addresses multiple end markets of “Datacenter” (formerly referred to as “Cloud”), “Edge” (formerly referred to as “Client”), and “Consumer.” The Company operates primarily in the United States (“U.S.”) and also internationally, with a significant concentration in the Asia Pacific region.

[0001628280-26-004407:notes:3]
[same as prior period, unchanged from 0001628280-25-050698:notes:3]

[0001628280-26-004407:notes:4]
On February 21, 2025, WDC executed the spin-off of the Company through WDC’s pro rata distribution of 116,035,464, or 80.1%, of the Company’s outstanding shares of common stock to holders of WDC’s common stock. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 28,827,787, or 19.9%, of the outstanding shares of the Company’s common stock. Following the distribution, the Company became an independent publicly listed company, and on February 24, 2025, the Company began trading as an independent, publicly traded company under the stock symbol “SNDK” on Nasdaq.

[0001628280-26-004407:notes:5]
In connection with the separation, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the spin-off and provided a framework for the relationship between WDC and the Company following the separation. These agreements include the Separation and Distribution Agreement, which contains certain key provisions related to the spin-off, as well as a Transition Services Agreement (“TSA”), a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025. Additionally, the Company adopted certain compensation plans filed as Exhibits to the Company’s Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025. The Company also entered into various sublease agreements and established a stock compensation incentive plan in connection with the separation.

[0001628280-26-004407:notes:6]
Also on February 21, 2025, in connection with the separation, the Company entered into a $1.5 billion revolving credit facility, which was undrawn at the separation date, and a $2.0 billion term loan facility due in 2032. The Company used a portion of the proceeds received from the term loan facility and cash on hand to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities, and certain legal entities of WDC associated with the Company.

[0001628280-26-004407:notes:7]
After the separation, outstanding restricted stock units (“RSU”) and performance stock units (“PSU”) previously granted by WDC to employees of the Company were adjusted per the terms of the Employee Matters Agreement in an attempt to maintain the economic value of those awards before and after the separation. Generally, continuing Sandisk employees with outstanding RSU awards held as of the spin-off date were converted solely to equivalent RSU awards of the Company, and any outstanding WDC RSU awards held as of the spin-off date were canceled. Outstanding RSU and PSU awards at the time of the spin-off, held by employees at levels equal to Vice President and above, were converted into RSU and PSU awards of both the Company and WDC.

[0001628280-26-004407:notes:8]
On June 9, 2025, WDC disposed of 21,314,768, or 14.6%, of the Company’s common stock through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. All expenses for the offering were paid for by the Company. As of January 2, 2026, WDC continued to retain 7,513,019, or 5.1%, of the outstanding shares of the Company’s common stock.

[0001628280-26-004407:notes:9]
[same as prior period, unchanged from 0001628280-25-050698:notes:9]

[0001628280-26-004407:notes:10]
On February 21, 2025, the Company became a standalone publicly traded company, and the Company’s financial statements are now presented on a consolidated basis. Prior to the separation, the Company’s historical consolidated financial information was derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the policies and practices that are generally accepted in the industry in which it operates.

[0001628280-26-004407:notes:11]
[same as prior period, unchanged from 0001628280-25-050698:notes:11]

[0001628280-26-004407:notes:12]
[same as prior period, unchanged from 0001628280-25-050698:notes:12]

[0001628280-26-004407:notes:13]
[same as prior period, unchanged from 0001628280-25-050698:notes:13]

[0001628280-26-004407:notes:14]
[same as prior period, unchanged from 0001628280-25-050698:notes:14]

[0001628280-26-004407:notes:15]
[same as prior period, unchanged from 0001628280-25-050698:notes:15]

[0001628280-26-004407:notes:16]
Intercompany transactions were eliminated, with the exception of balances associated with lending arrangements reflected within Notes due to (from) Western Digital Corporation in the Condensed Consolidated Balance Sheets, and transactions between the Company and WDC were generally considered to be effectively settled in the Condensed Consolidated Financial Statements at the time the transactions were recorded. The total net effect of the settlement of these transactions was reflected in the Condensed Consolidated Statements of Cash Flows as a financing activity and in the Condensed Consolidated Balance Sheets as Net investment from Western Digital Corporation. General financing activities included the net impact of any cash movements resulting from WDC’s centralized treasury cash management.

[0001628280-26-004407:notes:17]
The Condensed Consolidated Statements of Operations and Comprehensive Income (Loss) included all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions, and services provided by WDC. Allocation of general corporate expenses from WDC included, but was not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs were deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Condensed Consolidated Statements of Operations. The Condensed Consolidated Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on the Company’s behalf. The Company considers these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expense the Company would have incurred as a standalone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a standalone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.

[0001628280-26-004407:notes:18]
WDC maintains various stock-based compensation plans at a corporate level. Employees of the Company participated in those programs, and a portion of the compensation cost associated with those plans is included in the Company’s Condensed Consolidated Statements of Operations for the periods presented in this Quarterly Report on Form 10-Q. Before the spin-off, stock-based compensation expense was included within Net investment from Western Digital Corporation. The amounts presented in the Condensed Consolidated Financial Statements are not necessarily indicative of future awards and may not reflect the results that the Company would have experienced as a standalone entity.

[0001628280-26-004407:notes:19]
[same as prior period, unchanged from 0001628280-25-050698:notes:19]

[0001628280-26-004407:notes:20]
[same as prior period, unchanged from 0001628280-25-050698:notes:20]

[0001628280-26-004407:notes:21]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025 through January 2, 2026 are Condensed Consolidated Financial Statements based on the Company’s reported results as a standalone company. All transactions and accounts between controlled entities within the Company have been eliminated.

[0001628280-26-004407:notes:22]
Following the separation, certain functions continue to be provided by or for WDC for up to fifteen months under the TSA or are being performed using the Company’s own resources or third-party service providers. For the period ended January 2, 2026, charges under the TSA were not material.

[0001628280-26-004407:notes:23]
[same as prior period, unchanged from 0001628280-25-050698:notes:23]

[0001628280-26-004407:notes:24]
[same as prior period, unchanged from 0001628280-25-050698:notes:24]

[0001628280-26-004407:notes:25]
[same as prior period, unchanged from 0001628280-25-050698:notes:25]

[0001628280-26-004407:notes:26]
[same as prior period, unchanged from 0001628280-25-050698:notes:26]

[0001628280-26-004407:notes:27]
[same as prior period, unchanged from 0001628280-25-050698:notes:27]

[0001628280-26-004407:notes:28]
[same as prior period, unchanged from 0001628280-25-050698:notes:28]

[0001628280-26-004407:notes:29]
[same as prior period, unchanged from 0001628280-25-050698:notes:29]

[0001628280-26-004407:notes:30]
[same as prior period, unchanged from 0001628280-25-050698:notes:30]

[0001628280-26-004407:notes:31]
[same as prior period, unchanged from 0001628280-25-050698:notes:31]

[0001628280-26-004407:notes:32]
[same as prior period, unchanged from 0001628280-25-050698:notes:32]

[0001628280-26-004407:notes:33]
[same as prior period, unchanged from 0001628280-25-050698:notes:33]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-26-004407:notes:34]
[same as prior period, unchanged from 0001628280-25-050698:notes:34]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-26-004407:notes:35]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0001628280-26-004407:notes:36]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands segment reporting requirements, primarily through enhanced disclosures surrounding significant segment expenses. This ASU expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity’s CODM, a description of other segment items by reportable segment, and any additional measures of a segment’s profit or loss used by the CODM when deciding how to allocate resources. The Company adopted the guidance retrospectively in the fourth quarter of fiscal 2025. See Note 9, Segment Reporting, for additional disclosures.

[0001628280-26-004407:notes:37]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0001628280-26-004407:notes:38]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” This ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026, with early adoption permitted. The Company expects to provide any required disclosures at that time.
In November 2024, the FASB issued ASU 2024-03, “Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses,” which is intended to improve disclosures about the expenses of public entities. This ASU requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This ASU is effective on either a prospective or retrospective basis for fiscal years beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption. The Company expects to provide any required disclosures for annual reporting periods included in the Company’s financial statements for the year ending June 30, 2028.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-26-004407:notes:39]
[same as prior period, unchanged from 0001628280-25-050698:notes:39]

[0001628280-26-004407:notes:40]
[same as prior period, unchanged from 0001628280-25-050698:notes:40]

[0001628280-26-004407:notes:41]
[same as prior period, unchanged from 0001628280-25-050698:notes:41]

[0001628280-26-004407:notes:42]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 440 |  |  | $ | 250 |  |  | $ | 709 |  |  | $ | 550 |  |
| Edge | 1,678 |  |  | 1,028 |  |  | 3,065 |  |  | 2,097 |  |
| Consumer | 907 |  |  | 598 |  |  | 1,559 |  |  | 1,112 |  |
| Total revenue | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 2,063 |  |  | $ | 1,086 |  |  | $ | 3,578 |  |  | $ | 2,236 |  |
| Americas | 513 |  |  | 389 |  |  | 919 |  |  | 832 |  |
| Europe, Middle East and Africa | 449 |  |  | 401 |  |  | 836 |  |  | 691 |  |
| Total revenue | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |

[0001628280-26-004407:notes:43]
The Company’s top 10 customers accounted for 44% and 40% of its net revenue for the three and six months ended January 2, 2026, respectively, and 42% and 46% of its net revenue for the three and six months ended December 27, 2024, respectively. For the three and six months ended January 2, 2026 and December 27, 2024, no customer accounted for more than 10% of the Company’s net revenue. 
Revenue
Contract assets represent the Company’s right to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company had no contract assets as of January 2, 2026 and June 27, 2025. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service, support, and maintenance contracts. Contract liabilities as of January 2, 2026, and June 27, 2025, and changes in contract liabilities for the three and six months ended January 2, 2026 and December 27, 2024 were not material.

[0001628280-26-004407:notes:44]
[same as prior period, unchanged from 0001628280-25-050698:notes:44]

[0001628280-26-004407:notes:45]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements, and customer support and service contracts, which will be recognized over their contract period. As of January 2, 2026, the transaction price allocated to the remaining performance obligations was not material.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-26-004407:notes:46]
[same as prior period, unchanged from 0001628280-25-050698:notes:46]

[0001628280-26-004407:notes:47]
[same as prior period, unchanged from 0001628280-25-050698:notes:47]

[0001628280-26-004407:notes:48]
|  | Goodwill |
|  | (in millions) |
| Balance at June 27, 2025 | $ | 4,999 |  |
| Impairment charges | — |  |
| Foreign currency translation adjustment | (4) |  |
| Balance at January 2, 2026 | $ | 4,995 |  |

[0001628280-26-004407:notes:49]
Goodwill represents the historical goodwill balances arising from acquisitions specific to the Company prior to the spin-off from WDC.

[0001628280-26-004407:notes:50]
[same as prior period, unchanged from 0001628280-25-050698:notes:50]

[0001628280-26-004407:notes:51]
For the three and six months ended January 2, 2026 and December 27, 2024, the Company recorded no goodwill impairment charges.

[0001628280-26-004407:notes:52]
[same as prior period, unchanged from 0001628280-25-050698:notes:52]

[0001628280-26-004407:notes:53]
From time to time, in connection with factoring agreements, WDC sold certain of the Company’s trade accounts receivable without recourse to third-party purchasers in exchange for cash. During the three and six months ended January 2, 2026, there were no trade accounts receivable sold by the Company. During the three and six months ended December 27, 2024, there were no trade accounts receivable sold by WDC. There were no factored receivables outstanding as of January 2, 2026 or June 27, 2025.

[0001628280-26-004407:notes:54]
[same as prior period, unchanged from 0001628280-25-050698:notes:54]

[0001628280-26-004407:notes:55]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,377 |  |  | $ | 1,517 |  |
| Work-in-process | 221 |  |  | 262 |  |
| Finished goods | 372 |  |  | 300 |  |
| Total inventories | $ | 1,970 |  |  | $ | 2,079 |  |

[0001628280-26-004407:notes:56]
[same as prior period, unchanged from 0001628280-25-050698:notes:56]

[0001628280-26-004407:notes:57]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 10 |  |  | $ | 10 |  |
| Machinery and equipment | 1,495 |  |  | 1,480 |  |
| Buildings and improvements | 395 |  |  | 390 |  |
| Computer equipment and software | 167 |  |  | 176 |  |
| Furniture and fixtures | 17 |  |  | 18 |  |
| Construction-in-process | 45 |  |  | 51 |  |
| Property, plant and equipment, gross | 2,129 |  |  | 2,125 |  |
| Accumulated depreciation | (1,498) |  |  | (1,506) |  |
| Property, plant and equipment, net | $ | 631 |  |  | $ | 619 |  |

[0001628280-26-004407:notes:58]
[same as prior period, unchanged from 0001628280-25-050698:notes:58]

[0001628280-26-004407:notes:59]
[same as prior period, unchanged from 0001628280-25-050698:notes:59]

[0001628280-26-004407:notes:60]
|  |  |  |  |  | Product Warranty Liability |  |  |
|  |  |  |  |  | (in millions) |  |  |
| Balance at June 27, 2025 |  |  |  |  | $ | 44 |  |  |  |
| Charges to operations |  |  |  |  | 33 |  |  |  |
| Utilization |  |  |  |  | (17) |  |  |  |
| Changes in estimate related to pre-existing warranties |  |  |  |  | (4) |  |  |  |
| Balance at January 2, 2026 |  |  |  |  | $ | 56 |  |  |  |

[0001628280-26-004407:notes:61]
[same as prior period, unchanged from 0001628280-25-050698:notes:61]

[0001628280-26-004407:notes:62]
|  | January 2,2026 |  | June 27,2025 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 26 |  |  | $ | 22 |  |  |  |  |  |  |  |
| Long-term portion | 30 |  |  | 22 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 56 |  |  | $ | 44 |  |  |  |  |  |  |  |

[0001628280-26-004407:notes:63]
[same as prior period, unchanged from 0001628280-25-050698:notes:63]

[0001628280-26-004407:notes:64]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current lease liability | $ | 186 |  |  | $ | 193 |  |
| Non-current net tax payable | 140 |  |  | 131 |  |
| Tax indemnification liability | 128 |  |  | 110 |  |
| Other non-current liabilities | 72 |  |  | 62 |  |
| Total other liabilities | $ | 526 |  |  | $ | 496 |  |

[0001628280-26-004407:notes:65]
In connection with, and at the time of, the separation, the Company recorded a $112 million liability to indemnify WDC as a result of the Tax Matters Agreement entered into between the parties in connection with the separation. The indemnification pertains to certain WDC tax positions where the underlying issues are determined to be related to the Company’s business before the spin-off. As WDC receives tax assessments, settles with tax authorities, or when the statute of limitation lapses, the indemnification liabilities will be reassessed and adjusted accordingly. The outstanding balance of the liability as of January 2, 2026 was $128 million.

[0001628280-26-004407:notes:66]
[same as prior period, unchanged from 0001628280-25-050698:notes:66]

[0001628280-26-004407:notes:67]
[same as prior period, unchanged from 0001628280-25-050698:notes:67]

[0001628280-26-004407:notes:68]
|  | Foreign Currency Translation Adjustment |  | Unrealized Income (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 27, 2025 | $ | (202) |  |  | $ | (47) |  |  | $ | (249) |  |
| Other comprehensive income (loss) | (42) |  |  | 48 |  |  | 6 |  |
| Income tax expense related to items of other comprehensive income | — |  |  | (12) |  |  | (12) |  |
| Net current-period other comprehensive income (loss) | (42) |  |  | 36 |  |  | (6) |  |
| Balance at January 2, 2026 | $ | (244) |  |  | $ | (11) |  |  | $ | (255) |  |

[0001628280-26-004407:notes:69]
As of January 2, 2026, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-004407:notes:70]
[same as prior period, unchanged from 0001628280-25-050698:notes:70]

[0001628280-26-004407:notes:71]
[same as prior period, unchanged from 0001628280-25-050698:notes:71]

[0001628280-26-004407:notes:72]
[same as prior period, unchanged from 0001628280-25-050698:notes:72]

[0001628280-26-004407:notes:73]
[same as prior period, unchanged from 0001628280-25-050698:notes:73]

[0001628280-26-004407:notes:74]
[same as prior period, unchanged from 0001628280-25-050698:notes:74]

[0001628280-26-004407:notes:75]
[same as prior period, unchanged from 0001628280-25-050698:notes:75]

[0001628280-26-004407:notes:76]
|  | January 2, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 390 |  |  | $ | — |  |  | $ | — |  |  | $ | 390 |  |
| Foreign exchange contracts (included in Other current assets) | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets at fair value | $ | 390 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 393 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts (included in Accrued expenses) | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |

[0001628280-26-004407:notes:77]
[same as prior period, unchanged from 0001628280-25-050698:notes:77]

[0001628280-26-004407:notes:78]
[same as prior period, unchanged from 0001628280-25-050698:notes:78]

[0001628280-26-004407:notes:79]
Financial Instruments Not Carried at Fair value
Financial instruments not recorded at fair value on a recurring basis (debt) had an estimated fair value of $654 million as of January 2, 2026. The fair value of the debt was determined based on observable market prices in less active markets. The fair values do not indicate the amount the Company would have to pay to extinguish the debt. For more information regarding debt, see Note 8, Debt for additional disclosures.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-26-004407:notes:80]
Derivative Instruments and Hedging Activities
As of January 2, 2026, the Company had outstanding foreign exchange forward contracts that were designated as either cash flow hedges or non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed twelve months.

[0001628280-26-004407:notes:81]
Changes in the fair values of the non-designated foreign exchange contracts are recognized in Other expense, net, and are largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For the three months ended January 2, 2026 and December 27, 2024, total net realized and unrealized transactions and foreign exchange contract currency were losses of $5 million and $10 million, respectively. For the six months ended January 2, 2026 and December 27, 2024, total net realized and unrealized transactions and foreign exchange contract currency were losses of $9 million and $25 million, respectively.
Unrealized gains or losses on designated cash flow hedges are recognized in AOCL. For more information regarding cash flow hedges, see Note 5, Supplemental Financial Statement Data—Accumulated other comprehensive loss for additional disclosures.


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-004407:notes:82]
Debt
Loan Agreement

[0001628280-26-004407:notes:83]
Debt consisted of the following:

[0001628280-26-004407:notes:84]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 650 |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | — |  |
| Total debt | 650 |  |  | 1,900 |  |
| Unamortized issuance costs | 47 |  |  | 51 |  |
| Subtotal | 603 |  |  | 1,849 |  |
| Less: Current portion of long-term debt | 20 |  |  | 20 |  |
| Long term debt | $ | 583 |  |  | $ | 1,829 |  |

[0001628280-26-004407:notes:85]
On February 21, 2025, the Company entered into a Loan Agreement (the “Loan Agreement”) by and among the Company, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, and the other parties party thereto. The Loan Agreement comprises a term loan B facility in the principal amount of $2.0 billion (the “Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”).

[0001628280-26-004407:notes:86]
The obligations under the Loan Agreement are guaranteed by the Company’s wholly-owned subsidiary, Sandisk Technologies, Inc. (“SDT”), and are required to be guaranteed by any of the Company’s future material U.S. wholly-owned subsidiaries, subject to certain exceptions outlined in the Loan Agreement. The obligations under the Loan Agreement are secured by the Company’s assets and SDT’s assets and are required to be secured by the assets of any of the Company’s future material U.S. wholly-owned subsidiaries, subject, in each case, to certain exceptions outlined in the Loan Agreement.

[0001628280-26-004407:notes:87]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose of or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements, or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement).

[0001628280-26-004407:notes:88]
On February 21, 2025, the Company borrowed $2.0 billion under its Term Loan Facility. The Company used a portion of the proceeds of the borrowing to make a net distribution payment of $1.5 billion to WDC, with the remainder to be used for general corporate purposes of the Company. The Revolving Credit Facility may be borrowed by the Company from time to time for general corporate purposes.

[0001628280-26-004407:notes:89]
In connection with the Loan Agreement, the Company and SDT entered into a security agreement to secure the obligations under the Facilities on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and SDT, subject to certain exceptions.

[0001628280-26-004407:notes:90]
In connection with the Loan Agreement, the Company (solely with respect to obligations of any additional Borrower under the Loan Agreement) and SDT entered into a guaranty agreement to secure and unconditionally guarantee the obligations under the Loan Agreement, respectively, in each case, subject to certain exceptions.

[0001628280-26-004407:notes:91]
Term Loan Facility

[0001628280-26-004407:notes:92]
The Term Loan Facility bears interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an interest rate margin of 3.00% per annum or (y) a base rate plus an interest rate margin of 2.00% per annum.

[0001628280-26-004407:notes:93]
The outstanding principal balance of the Term Loan Facility is required to be repaid in quarterly installments that began on June 27, 2025, in an aggregate amount equal to 0.25% of the aggregate principal amount of the Term Loan Facility. A final payment comprised of all principal and interest is due and payable at maturity on February 20, 2032.

[0001628280-26-004407:notes:94]
For the three months ended January 2, 2026, interest expense was $22 million and amortization of issuance costs was $2 million. For the six months ended January 2, 2026, interest expense was $59 million and amortization of issuance costs was $5 million.

[0001628280-26-004407:notes:95]
Revolving Credit Facility

[0001628280-26-004407:notes:96]
Borrowings under the Revolving Credit Facility, for U.S. dollar borrowings, will bear interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement), which rate includes a credit spread adjustment of 0.10%, plus an interest rate margin of 2.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)), or (y) a base rate plus an interest rate margin of 1.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)). The Company will pay a commitment fee of 0.30% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)) in respect of undrawn revolving commitments under the Revolving Credit Facility. The Revolving Credit Facility will also provide for borrowings in Euros, Yen, and additional currencies agreed to by the lenders under the Revolving Credit Facility. The Revolving Credit Facility will mature on February 21, 2030, at which time the commitments thereunder shall be terminated and will not have any amortization.

[0001628280-26-004407:notes:97]
In connection with the establishment of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which are amortized to Interest expense over the life of the facility.

[0001628280-26-004407:notes:98]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement). As of January 2, 2026, the Company was in compliance with the financial covenant.

[0001628280-26-004407:notes:99]
As of January 2, 2026, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-004407:notes:100]
[same as prior period, unchanged from 0001628280-25-050698:notes:100]

[0001628280-26-004407:notes:101]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |
| Costs of revenue (1) | 1,479 |  |  | 1,267 |  |  | 3,096 |  |  | 2,418 |  |
| Operating expenses (1) | 413 |  |  | 376 |  |  | 859 |  |  | 754 |  |
| Stock-based compensation expenses | 58 |  |  | 48 |  |  | 111 |  |  | 89 |  |
| Employee termination and other | 1 |  |  | 3 |  |  | (2) |  |  | 5 |  |
| Business separation costs | 9 |  |  | 21 |  |  | 18 |  |  | 41 |  |
| (Gain) loss on business divestiture | — |  |  | (34) |  |  | 10 |  |  | (34) |  |
| Total interest and other expense, net | 128 |  |  | 22 |  |  | 180 |  |  | 46 |  |
| Income tax expense | 134 |  |  | 69 |  |  | 146 |  |  | 125 |  |
| Net income | $ | 803 |  |  | $ | 104 |  |  | $ | 915 |  |  | $ | 315 |  |

[0001628280-26-004407:notes:102]
[same as prior period, unchanged from 0001628280-25-050698:notes:102]


## sndk:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0001628280-26-004407:notes:103]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0001628280-26-004407:notes:104]
The Company procures substantially all of its flash-based memory wafers from its business ventures with Kioxia Corporation (“Kioxia”), which consists of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures.”

[0001628280-26-004407:notes:105]
The following table presents the notes receivable from, and equity investments in, Flash Ventures for the periods presented:

[0001628280-26-004407:notes:106]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 1 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 20 |  |  | 36 |  |
| Notes receivable, Flash Forward | 432 |  |  | 316 |  |
| Investment in Flash Partners | 33 |  |  | 55 |  |
| Investment in Flash Alliance | 102 |  |  | 115 |  |
| Investment in Flash Forward | 89 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 677 |  |  | $ | 654 |  |

[0001628280-26-004407:notes:107]
During the three and six months ended January 2, 2026, the Company made net payments to Flash Ventures of $0.9 billion and $1.8 billion, respectively, for purchases of flash-based memory wafers and net loans. During the three and six months ended December 27, 2024, the Company made net payments to Flash Ventures of $1.1 billion and $2.0 billion, respectively, for purchases of flash-based memory wafers and net loans. In addition, during the six months ended January 2, 2026, the Company received a $15 million dividend distribution from Flash Ventures.

[0001628280-26-004407:notes:108]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Ventures entity. For all reporting periods presented, no loans were past due, and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0001628280-26-004407:notes:109]
As of January 2, 2026 and June 27, 2025, the Company had accounts payable balances due to Flash Ventures of $274 million and $279 million, respectively.

[0001628280-26-004407:notes:110]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at January 2, 2026, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

[0001628280-26-004407:notes:111]
|  | January 2,2026 |
|  | (in millions) |
| Notes receivable | $ | 453 |  |
| Equity investments | 224 |  |
| Operating lease guarantees | 1,076 |  |
| Inventory and prepayments | 1,351 |  |
| Maximum estimable loss exposure | $ | 3,104 |  |

[0001628280-26-004407:notes:112]
The Company is obligated to pay for variable costs incurred by Flash Ventures in producing the Company’s share of Flash Ventures’ flash-based memory wafer supply, based on its rolling three-month forecast. The Company’s share generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company cannot estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that the Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0001628280-26-004407:notes:113]
Flash Ventures has historically operated at nearly 100% of its manufacturing capacity. During the six months ended January 2, 2026, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to a level that more closely aligned the Company’s flash-based wafer supply with projected demand. During the six months ended January 2, 2026, the Company incurred costs of $11 million associated with the reduction in utilization related to Flash Ventures, which were recorded as charges to Cost of revenue. No such charges were incurred during the three months ended January 2, 2026 or during the three and six months ended December 27, 2024.

[0001628280-26-004407:notes:114]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward Kioxia’s future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of January 2, 2026, $881 million, with $131 million recorded within Other current assets and $750 million recorded within Other non-current assets in the Condensed Consolidated Balance Sheets, remain to be credited against future building depreciation charges and ultimately released within Costs of revenue when the Company’s inventory is sold. As of January 2, 2026, the Company is also committed to making additional building depreciation prepayments of $387 million, based on the Japanese yen to U.S. dollar exchange rate of ¥156.87 as of such date, payable as follows: $25 million for the remaining of fiscal year 2026, $121 million in fiscal year 2027, $177 million in fiscal year 2028 and $64 million in fiscal year 2029. As of January 2, 2026, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $155 million at varying dates through fiscal year 2035.

[0001628280-26-004407:notes:115]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed with Flash Ventures for up to three months are binding and cannot be canceled.

[0001628280-26-004407:notes:116]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for the remaining six months of 2026 are $44 million.

[0001628280-26-004407:notes:117]
Off-Balance Sheet Liabilities. Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0001628280-26-004407:notes:118]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of January 2, 2026:

[0001628280-26-004407:notes:119]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 169 |  |  | $ | 1,076 |  |

[0001628280-26-004407:notes:120]
The following table details the components of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of January 2, 2026:

[0001628280-26-004407:notes:121]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| 2026 | $ | 186 |  |  | $ | 42 |  |  | $ | 228 |  |
| 2027 | 270 |  |  | 96 |  |  | 366 |  |
| 2028 | 139 |  |  | 94 |  |  | 233 |  |
| 2029 | 61 |  |  | 51 |  |  | 112 |  |
| 2030 | 27 |  |  | 58 |  |  | 85 |  |
| 2031 | 4 |  |  | 48 |  |  | 52 |  |
| Total guarantee obligations | $ | 687 |  |  | $ | 389 |  |  | $ | 1,076 |  |

[0001628280-26-004407:notes:122]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of January 2, 2026, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0001628280-26-004407:notes:123]
Sale of a Majority Interest in a Subsidiary

[0001628280-26-004407:notes:124]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly-listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

[0001628280-26-004407:notes:125]
The Transaction closed on September 28, 2024, and SanDisk China completed the sale of 80% of its equity interest in SDSS to JCET. The Transaction resulted in a pre-tax gain of $34 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $382 million of goodwill that was allocated to SDSS.

[0001628280-26-004407:notes:126]
Proceeds from the sale, including working capital adjustments, were $659 million (pre-tax). On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million. The remaining $187 million pre-tax proceeds are payable in five equal installments of approximately $37 million on September 28 of each year through September 28, 2029.

[0001628280-26-004407:notes:127]
On September 25, 2025, SanDisk China and JCET entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support, resulting in a reduction of the September 28, 2025 installment payment from JCET to $27 million. The Company recognized the adjustment as a Loss on business divestiture for the six months ended January 2, 2026.

[0001628280-26-004407:notes:128]
As of January 2, 2026, the outstanding consideration receivable was recognized at its present value of $135 million, with $36 million classified as Other current assets and $99 million classified as Other non-current assets in the Condensed Consolidated Balance Sheets. The remaining present value discount of $15 million as of January 2, 2026 will be recognized using the effective interest method over the next four years as Interest income in the Condensed Consolidated Statements of Operations.

[0001628280-26-004407:notes:129]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other expense, net in the Condensed Consolidated Statements of Operations. As of January 2, 2026, the 20% retained interest in SDSS was valued at $163 million.

[0001628280-26-004407:notes:130]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT,” a WDC affiliate) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if it fails to meet its minimum annual commitment. The Supply Agreement also provides that if the Company’s purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the three and six months ended January 2, 2026, the Company made purchases of $138 million and $277 million, respectively, under the Supply Agreement. As of January 2, 2026, the Company had a $159 million accounts payable balance due to SDSS.

[0001628280-26-004407:notes:131]
The Company also entered into an arrangement to provide certain transition services for a limited period following the closing of the Transaction. Charges under this arrangement were not material.

[0001628280-26-004407:notes:132]
Unis Venture

[0001628280-26-004407:notes:133]
On January 24, 2025, the Company and WDC entered into an equity transfer agreement (the “Equity Transfer Agreement”) to transfer WDC’s entire equity interest in its venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to the Company. The Unis Venture is 48% owned by the Company and 52% owned by Unis. The Unis Venture markets and sells the Company’s products in China and develops data storage systems for the Chinese market.

[0001628280-26-004407:notes:134]
Prior to the execution of the Equity Transfer Agreement, the Unis Venture was not historically managed as a component of the Company and as such, the related equity method investment was not reflected within the Company’s Condensed Consolidated Financial Statements. After the execution of the Equity Transfer Agreement, the Company accounts for its investment in the Unis Venture under the equity method of accounting. The Company’s 48% interest in the earnings of the Unis Venture will be recognized one quarter in arrears from the date the Unis Venture was transferred to the Company and will be reported in Other expense, net in the Condensed Consolidated Statements of Operations.

[0001628280-26-004407:notes:135]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the three and six months ended January 2, 2026, the Company recognized approximately 2% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. For the three and six months ended December 27, 2024, the Company recognized approximately 1% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 2% and 1% of Accounts receivable, net, as of January 2, 2026 and June 27, 2025, respectively.

[0001628280-26-004407:notes:136]
Related Party Transactions

[0001628280-26-004407:notes:137]
Separation and Distribution Agreement and Other Related Party Transactions with WDC

[0001628280-26-004407:notes:138]
As described in Note 1, Organization and Basis of Presentation, on February 21, 2025, in connection with the separation, the Company entered into several agreements that provide a framework for Sandisk’s relationship with WDC after the separation. These include, but are not limited to, the following:

[0001628280-26-004407:notes:139]
•Separation and Distribution Agreement - The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Condensed Consolidated Balance Sheets were retained by WDC and certain assets and liabilities not included in the Company’s Condensed Consolidated Balance Sheets were transferred to the Company as of the date of the separation.

[0001628280-26-004407:notes:140]
As of quarter end January 2, 2026, the separation between the Company and WDC has been finalized, and no separation-related adjustments have been, or are expected to be, incurred going forward.

[0001628280-26-004407:notes:141]
•Employee Matters Agreement - The Employee Matters Agreement allocates liabilities and responsibilities relating to employment matters, employee compensation and benefit plans and programs and other related matters. Pursuant to this agreement, during the six months ended January 2, 2026, the Company received reimbursement of short-term employee incentives totaling $22 million from WDC. The Company did not receive any reimbursements from this agreement for the three months ended January 2, 2026.

[0001628280-26-004407:notes:142]
•Transition Services Agreement - The Transition Services Agreement governs the provision of transition services from WDC to Sandisk, and from Sandisk to WDC and its affiliates, on an interim, transitional basis following the separation.

[0001628280-26-004407:notes:143]
•Tax Matters Agreement - The Tax Matters Agreement governs, among other things, WDC’s and the Company’s respective rights, responsibilities and obligations after the spin-off with respect to tax liabilities and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings, and other matters regarding taxes. In addition, the Tax Matters Agreement imposes certain restrictions on the Company and its subsidiaries (including restrictions on share issuances, business combinations, sales of assets, and similar transactions) that are designed to preserve the tax-free status of the spin-off and certain related transactions.

[0001628280-26-004407:notes:144]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently increased to reflect changes in indemnification obligations under the Tax Matters Agreement, which is recorded in Other expense, net in the Condensed Consolidated Statements of Operations. The remaining tax indemnification liability of $128 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of January 2, 2026.

[0001628280-26-004407:notes:145]
Notes Due to (from) Western Digital Corporation

[0001628280-26-004407:notes:146]
Prior to the separation, the Company received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additionally, cash generated by the Company was lent from time to time via promissory notes to certain of WDC’s subsidiaries for use in general corporate purposes. Outstanding balances due under these financing arrangements were due on demand.

[0001628280-26-004407:notes:147]
Prior to the separation, the Company had outstanding borrowings due to WDC’s subsidiaries of $553 million, inclusive of interest payable. As part of the separation, WDC contributed $550 million to the Company, and the Company repaid $6 million in cash, which included interest accrued until the date of the separation.

[0001628280-26-004407:notes:148]
The following presents Interest expense and Interest income on notes due to (from) Western Digital Corporation, which were recorded within Interest expense and Interest income in the Condensed Consolidated Statements of Operations for the periods presented:

[0001628280-26-004407:notes:149]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4 |  |

[0001628280-26-004407:notes:150]
Allocation of Corporate Expenses

[0001628280-26-004407:notes:151]
Prior to the separation, WDC provided various corporate services to the Company in the ordinary course of business, including executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue or other relevant measures. Management believes the basis on which the expenses were allocated to be a reasonable reflection of the utilization of services provided to the Company or the benefit received by the Company.

[0001628280-26-004407:notes:152]
Effective at the beginning of the second quarter of fiscal year 2025, the Company was operationally separated from the operations that were ultimately retained by WDC following completion of the spin-off. In connection with this operational separation, personnel serving the Company in shared service functions were transferred into legal entities dedicated to the Company, and substantially all assets, liabilities, and contracts pertaining to operations of the Company were transferred to legal entities dedicated to the Company as well. Accordingly, there was a substantial reduction in the pool of shared corporate overhead costs of WDC that were subject to allocation in the second and third quarters of fiscal year 2025 and those allocations ceased post-separation.

[0001628280-26-004407:notes:153]
The table below summarizes the impact of expense allocations from WDC within the Condensed Consolidated Statements of Operations for the periods presented:

[0001628280-26-004407:notes:154]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 189 |  |
| Selling general, and administrative | — |  |  | 35 |  |  | — |  |  | 148 |  |
| Business separation costs | — |  |  | 21 |  |  | — |  |  | 41 |  |
| Employee termination and other charges | — |  |  | 3 |  |  | — |  |  | 5 |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 61 |  |  | $ | — |  |  | $ | 383 |  |

[0001628280-26-004407:notes:155]
The Company’s historical financial statements do not purport to reflect what results of operations, financial position, equity or cash flows would have been if the Company had operated as a standalone company during the periods presented.

[0001628280-26-004407:notes:156]
Cash Management

[0001628280-26-004407:notes:157]
Prior to the separation, WDC provided funding for the Company’s operating and investing activities, including pooled cash managed by WDC’s treasury, to fund operating expenses and capital expenditures. WDC also directly collected certain of the Company’s receivables. These activities were reflected as a component of the Net investment from Western Digital Corporation, and this arrangement is not reflective of the manner in which the Company would operate on a standalone company separate from WDC during the periods presented.

[0001628280-26-004407:notes:158]
Western Digital Corporation Net Investment

[0001628280-26-004407:notes:159]
Prior to the separation, the Net investment from Western Digital Corporation on the Condensed Consolidated Balance Sheets represented WDC’s historical investment in the Company, the net effect of transactions with and allocations from WDC, the Company’s retained earnings and the allocation to the Company of cumulative effect adjustments from the adoption of new accounting standards.

[0001628280-26-004407:notes:160]
Net Transfers from (to) Western Digital Corporation

[0001628280-26-004407:notes:161]
A reconciliation of Net transfers from (to) Western Digital Corporation on the Condensed Consolidated Statements of Shareholders’ Equity to the corresponding amounts on the Condensed Consolidated Statements of Cash Flows is as follows:

[0001628280-26-004407:notes:162]
|  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | 491 |  |
| Notes due to Western Digital Corporation | — |  |  | (673) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (44) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (25) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | 14 |  |
| Accumulated other comprehensive loss transferred from Western Digital Corporation | — |  |  | 6 |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | (231) |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-26-004407:notes:163]
[same as prior period, unchanged from 0001628280-25-050698:notes:163]

[0001628280-26-004407:notes:164]
[same as prior period, unchanged from 0001628280-25-050698:notes:164]

[0001628280-26-004407:notes:165]
[same as prior period, unchanged from 0001628280-25-050698:notes:165]

[0001628280-26-004407:notes:166]
[same as prior period, unchanged from 0001628280-25-050698:notes:166]

[0001628280-26-004407:notes:167]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Operating lease right-of-use assets (included in other non-current assets) | $ | 203 |  |  | $ | 214 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in accrued expenses) | 24 |  |  | 26 |  |
| Long-term operating lease liabilities (included in other liabilities) | 186 |  |  | 193 |  |
| Total operating lease liabilities | $ | 210 |  |  | $ | 219 |  |

[0001628280-26-004407:notes:168]
[same as prior period, unchanged from 0001628280-25-050698:notes:168]

[0001628280-26-004407:notes:169]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Cost of operating leases | $ | 12 |  |  | $ | 8 |  |  | $ | 23 |  |  | $ | 16 |  |
| Cash paid for operating leases | 10 |  |  | 7 |  |  | 20 |  |  | 14 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 5 |  |  | 4 |  |  | 7 |  |  | 4 |  |

[0001628280-26-004407:notes:170]
[same as prior period, unchanged from 0001628280-25-050698:notes:170]

[0001628280-26-004407:notes:171]
|  | January 2,2026 |  | December 27,2024 |  |  |
| Weighted average remaining lease term in years | 10.7 |  | 12.6 |  |  |
| Weighted average discount rate | 7.3 | % |  | 7.4 | % |  |  |

[0001628280-26-004407:notes:172]
As of January 2, 2026, remaining minimum lease payments were as follows:

[0001628280-26-004407:notes:173]
|  | Lease Amounts |
|  | (in millions) |
| Minimum lease payments by fiscal year: |  |
| Remaining six months of 2026 | $ | 19 |  |
| 2027 | 37 |  |
| 2028 | 29 |  |
| 2029 | 25 |  |
| 2030 | 22 |  |
| Thereafter | 183 |  |
| Total future minimum lease payments | 315 |  |
| Less: Imputed interest | 105 |  |
| Present value of lease liabilities | $ | 210 |  |

[0001628280-26-004407:notes:174]
[same as prior period, unchanged from 0001628280-25-050698:notes:174]

[0001628280-26-004407:notes:175]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the coming months, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into certain long-term agreements with suppliers that contain fixed future commitments, which are contingent upon certain conditions such as performance, quality and technology of the vendor’s components. As of January 2, 2026, the Company had the following minimum long-term commitments:

[0001628280-26-004407:notes:176]
|  | Long-term commitments |
|  | (in millions) |
| Fiscal year: |  |
| Remaining six months of 2026 | $ | 60 |  |
| 2027 | 601 |  |
| 2028 | 631 |  |
| 2029 | 584 |  |
| 2030 | 571 |  |
| Thereafter | 92 |  |
| Total | $ | 2,539 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-26-004407:notes:177]
Shareholders’ Equity
Prior to the separation, certain of the Company’s employees participated in WDC’s stock incentive plans (the “WDC Plans”), whereby all awards granted under the plans consisted of WDC common stock. The Stock-based compensation expense recognized in the Company’s Condensed Consolidated Financial Statements was determined based upon employees who participated in the WDC Plans and exclusively supported the Company’s operations, as well as an allocation of WDC’s corporate and shared employee stock-based compensation expenses.

[0001628280-26-004407:notes:178]
In connection with the separation, all outstanding RSU and PSU awards held by former employees of WDC and its affiliates, who became Sandisk employees after the separation, were adjusted pursuant to conversion ratios determined in accordance with the terms of the Employee Matters Agreement. Outstanding RSU and PSU awards held by employees in the positions of Vice President and above as of the separation date were converted into RSU or PSU awards of Sandisk shares and RSU awards of WDC shares on a ratio of one-third (1/3) of one share of the Company’s common stock for each WDC award held by each such employee. For all other employees, the value of the converted RSU awards was designed to preserve the aggregate intrinsic value of the award immediately after the separation when compared to the aggregate intrinsic value of those awards immediately prior to separation. Pursuant to the Employee Matters Agreement, the converted awards shall generally continue to be subject to the same terms and conditions as were applicable to the original WDC awards, including with respect to vesting, except as described in the Employee Matters Agreement. As a result of the conversion, the Company will incur approximately $41 million of incremental stock-based compensation expense from the date of the separation through the remaining service period for the awards. Of this amount, $4 million and $9 million was recognized during the three and six months ended January 2, 2026, respectively, and approximately $20 million is expected to be recognized over the awards’ remaining service periods.

[0001628280-26-004407:notes:179]
[same as prior period, unchanged from 0001628280-25-050698:notes:179]

[0001628280-26-004407:notes:180]
[same as prior period, unchanged from 0001628280-25-050698:notes:180]

[0001628280-26-004407:notes:181]
[same as prior period, unchanged from 0001628280-25-050698:notes:181]

[0001628280-26-004407:notes:182]
[same as prior period, unchanged from 0001628280-25-050698:notes:182]

[0001628280-26-004407:notes:183]
The following table summarizes RSU and PSU award activity under the Company’s incentive plans during the six months ended January 2, 2026:

[0001628280-26-004407:notes:184]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vest Date |
|  | (in millions) |  |  |  |  |
| RSUs and PSUs outstanding at June 27, 2025 | 6.6 |  |  | $ | 38.98 |  |  | $ | — |  |
| Granted | 3.3 |  |  | 53.91 |  |  | — |  |
| Vested | (1.5) |  |  | 37.18 |  |  | 163.88 |  |
| Canceled/forfeited | (0.3) |  |  | 38.06 |  |  | — |  |
| RSUs and PSUs outstanding at January 2, 2026 | 8.1 |  |  | $ | 45.42 |  |  | $ | 163.88 |  |

[0001628280-26-004407:notes:185]
[same as prior period, unchanged from 0001628280-25-050698:notes:185]

[0001628280-26-004407:notes:186]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP is amortized on a straight-line basis over the remaining service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of January 2, 2026:

[0001628280-26-004407:notes:187]
|  | Unamortized Compensation Costs |  | Weighted average service period |
|  | (in millions) |  | (years) |
| RSUs and PSUs | $ | 385 |  |  | 2.61 |
| ESPP | 23 |  |  | 1.41 |
| Total unamortized compensation cost | $ | 408 |  |  |  |

[0001628280-26-004407:notes:188]
[same as prior period, unchanged from 0001628280-25-050698:notes:188]

[0001628280-26-004407:notes:189]
The Company has an ESPP under which WDC, as its previous sole stockholder, approved an aggregate of approximately 4.3 million shares of common stock for issuance to eligible employees. The fair value of the award at the grant date is based on the Black-Scholes valuation model. The plan permits eligible employees to purchase common stock, through payroll deductions, at 95% of the fair market value of a share of common stock on the first day of the 24-month offering period in which the employees are participating or 95% of the fair market value of a share of common stock on the applicable exercise date, whichever is lower. Rights to purchase shares are granted during the second and fourth quarters of each fiscal year.

[0001628280-26-004407:notes:190]
[same as prior period, unchanged from 0001628280-25-050698:notes:190]

[0001628280-26-004407:notes:191]
[same as prior period, unchanged from 0001628280-25-050698:notes:191]

[0001628280-26-004407:notes:192]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| RSUs and PSUs | $ | 50 |  |  | $ | 45 |  |  | $ | 101 |  |  | $ | 81 |  |
| ESPP | 8 |  |  | 3 |  |  | 10 |  |  | 8 |  |
| Total | $ | 58 |  |  | $ | 48 |  |  | $ | 111 |  |  | $ | 89 |  |

[0001628280-26-004407:notes:193]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Cost of revenue | $ | 5 |  |  | $ | 3 |  |  | $ | 9 |  |  | $ | 9 |  |
| Research and development | 27 |  |  | 20 |  |  | 50 |  |  | 40 |  |
| Selling general, and administrative | 26 |  |  | 25 |  |  | 52 |  |  | 40 |  |
| Subtotal | $ | 58 |  |  | $ | 48 |  |  | $ | 111 |  |  | $ | 89 |  |
| Tax benefit | (6) |  |  | (7) |  |  | (12) |  |  | (12) |  |
| Total | $ | 52 |  |  | $ | 41 |  |  | $ | 99 |  |  | $ | 77 |  |

[0001628280-26-004407:notes:194]
Any shortfalls or excess windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, are excluded from the tax benefit above.


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-004407:notes:195]
[same as prior period, unchanged from 0001628280-25-050698:notes:195]

[0001628280-26-004407:notes:196]
[same as prior period, unchanged from 0001628280-25-050698:notes:196]

[0001628280-26-004407:notes:197]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions, except per share amounts) |
| Net income | $ | 803 |  |  | $ | 104 |  |  | $ | 915 |  |  | $ | 315 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 147 |  |  | 145 |  |  | 146 |  |  | 145 |  |
| Diluted (1) | 156 |  |  | 145 |  |  | 152 |  |  | 145 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 5.46 |  |  | $ | 0.72 |  |  | $ | 6.27 |  |  | $ | 2.17 |  |
| Diluted (1) | $ | 5.15 |  |  | $ | 0.72 |  |  | $ | 6.02 |  |  | $ | 2.17 |  |

[0001628280-26-004407:notes:198]
(1) For the three months ended January 2, 2026, 0.1 million weighted average outstanding awards were excluded from the calculation of diluted earnings per share because their effect would have been anti-dilutive. For the six months ended January 2, 2026, 0.1 million weighted average outstanding awards were excluded from the calculation of diluted earnings per share because their effect would have been anti-dilutive.

[0001628280-26-004407:notes:199]
[same as prior period, unchanged from 0001628280-25-050698:notes:199]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-004407:notes:200]
Income Tax Expense 
H.R.1, more widely known as the One Big Beautiful Bill Act (“OBBBA”), was signed into law on July 4, 2025. It reversed the requirement for capitalization of U.S. research and development expenditures that came into law under the Tax Cuts and Jobs Act of 2017, but the mandatory requirement of capitalization of foreign research and development expenditures remains. The tax rates for income earned by the Company’s foreign subsidiaries are changed under H.R. 1, which applies to the Company’s fiscal years 2027 and onwards. Depending on the Company’s operating results, these changes can materially impact the Company’s effective tax rate and its operating cash flows. During the six months ended January 2, 2026, the Company recorded a $10 million tax benefit in relation to the OBBBA’s impact on its 2025 tax provision.

[0001628280-26-004407:notes:201]
[same as prior period, unchanged from 0001628280-25-050698:notes:201]

[0001628280-26-004407:notes:202]
On December 20, 2021, the Organization for Economic Co-operation and Development G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two”). Pillar Two is currently effective in most of the jurisdictions in which we operate. Accordingly, these taxes are included in the Company’s Income tax expense for the three and six months ended January 2, 2026.

[0001628280-26-004407:notes:203]
[same as prior period, unchanged from 0001628280-25-050698:notes:203]

[0001628280-26-004407:notes:204]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Income before taxes | $ | 937 |  |  | $ | 173 |  |  | $ | 1,061 |  |  | $ | 440 |  |
| Income tax expense | 134 |  |  | 69 |  |  | 146 |  |  | 125 |  |
| Effective tax rate | 14 | % |  | 40 | % |  | 14 | % |  | 28 | % |

[0001628280-26-004407:notes:205]
The relative mix of earnings and losses by jurisdiction, credits and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the three and six months ended January 2, 2026.

[0001628280-26-004407:notes:206]
The relative mix of earnings and losses by jurisdiction, the deduction for foreign-derived intangible income, credits and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the six months ended December 27, 2024. However, the tax effects of the mandatory capitalization of R&D expenses offset these decreases, resulting in the effective tax rate being greater than the U.S. Federal statutory rate for the three and six months ended December 27, 2024.

[0001628280-26-004407:notes:207]
[same as prior period, unchanged from 0001628280-25-050698:notes:207]

[0001628280-26-004407:notes:208]
[same as prior period, unchanged from 0001628280-25-050698:notes:208]

[0001628280-26-004407:notes:209]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits, excluding accrued interest and penalties for the six months ended January 2, 2026:

[0001628280-26-004407:notes:210]
|  | (in millions) |
| Accrual balance at June 27, 2025 | $ | 140 |  |
| Gross increases related to prior year tax positions | 35 |  |
| Gross increases related to current year tax positions | 29 |  |
| Gross decrease related to prior year tax positions | (8) |  |
| Accrual balance at January 2, 2026 | $ | 196 |  |

[0001628280-26-004407:notes:211]
As of January 2, 2026 and June 27, 2025, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $196 million and $140 million, respectively. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of January 2, 2026 and June 27, 2025 was $14 million and $11 million, respectively.

[0001628280-26-004407:notes:212]
[same as prior period, unchanged from 0001628280-25-050698:notes:212]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001628280-26-004407:notes:213]
Legal ProceedingsIn the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations


## us-gaap:SubsequentEventsTextBlock

[0001628280-26-004407:notes:214]
Note 16.    Subsequent Events

[0001628280-26-004407:notes:215]
On January 29, 2026, the Company and Kioxia Corporation entered into an FAL Second Commitment and Extension Agreement (the “FAL Second Extension Agreement”) and FPL Second Commitment and Extension Agreement (the “FPL Second Extension Agreement”, and together with the FAS Second Extension Agreement, collectively, the “Extension Agreements”), under which the parties thereto extended the term of the Flash Alliance and Flash Partners joint ventures to December 31, 2034. Following the execution of the Extension Agreements, all of the Flash Ventures across the Yokkaichi and Kitakami sites now co-terminate on December 31, 2034.
In addition to the Extension Agreements, the Company entered into Agreement to Enhance Collaboration with Kioxia, pursuant to which the Company will pay Kioxia $1.2 billion, with payments made over the years 2026 through 2029, in consideration of Kioxia’s manufacturing services and the continued availability of supply.
