# SNDK 8-K — 0001628280-26-004121 filed 2026-01-29

## item codes, every 8-K on or before 2026-01-30

- 2026-01-29 0001628280-26-004121 — 2.02, 9.01
- 2026-01-02 0001628280-26-000127 — 5.02
- 2025-11-20 0001193125-25-289885 — 5.07
- 2025-11-06 0001628280-25-050180 — 2.02, 9.01
- 2025-08-14 0001193125-25-180782 — 2.02, 9.01
- 2025-05-07 0002023554-25-000021 — 2.02, 9.01
- 2025-03-11 0002023554-25-000007 — 5.02
- 2025-02-24 0001193125-25-033433 — 1.01, 2.03, 3.03, 5.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2025-02-14 0001193125-25-027285 — 3.03, 5.03, 9.01
- 2025-02-03 0001193125-25-019298 — 8.01, 9.01

## late-filing notifications on or before 2026-01-30

- none on or before 2026-01-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-004121:8k_2_02:1]
EX-99.1
2
sndkq2fy26ex991-pressrelea.htm
EX-99.1

[0001628280-26-004121:8k_2_02:2]
Document

[0001628280-26-004121:8k_2_02:3]
Exhibit 99.1

[0001628280-26-004121:8k_2_02:4]
Sandisk Reports Fiscal Second Quarter 2026 Financial Results

[0001628280-26-004121:8k_2_02:5]
News Summary

[0001628280-26-004121:8k_2_02:6]
•Second quarter revenue was $3.03 billion, up 31% sequentially and above the guidance range, with GAAP net income reported at $803 million ($5.15 diluted net income per share). Second quarter Non-GAAP diluted net income per share was $6.20.

[0001628280-26-004121:8k_2_02:7]
•Datacenter revenue was up 64% sequentially, driven by strong adoption among AI infrastructure builders, semi-custom customers, and technology companies deploying AI at scale.

[0001628280-26-004121:8k_2_02:8]
•Expect third quarter revenue to be in the range of $4.40 billion to $4.80 billion, with expected Non-GAAP diluted net income per share to be in the range of $12.00 to $14.00.

[0001628280-26-004121:8k_2_02:9]
MILPITAS, Calif. — January 29, 2026 — Sandisk Corporation (Nasdaq: SNDK) today reported fiscal second quarter financial results.

[0001628280-26-004121:8k_2_02:10]
“This quarter’s performance underscores our agility in capitalizing on better product mix, accelerating enterprise SSD deployments, and strengthening market demand dynamics, all at a time when the critical role that our products play in powering AI and the world’s technology is being recognized,” said David Goeckeler, CEO, Sandisk. “Our structural reset to align supply with attractive, sustained demand positions us to drive disciplined growth and deliver industry-leading financial performance.”

[0001628280-26-004121:8k_2_02:11]
1

[0001628280-26-004121:8k_2_02:12]
Q2 2026 Financial Highlights

[0001628280-26-004121:8k_2_02:13]
|  | GAAP |  | Non-GAAP |
| ($ in millions, except per share amounts) | Q2 2026 |  | Q1 2026 |  | Q/Q |  | Q2 2026 |  | Q1 2026 |  | Q/Q |
| Revenue | $3,025 |  | $2,308 |  | up 31% |  | $3,025 |  | $2,308 |  | up 31% |
| Gross Margin | 50.9% |  | 29.8% |  | up 21.1 ppt |  | 51.1% |  | 29.9% |  | up 21.2 ppt |
| Operating Expenses | $476 |  | $511 |  | down 7% |  | $413 |  | $446 |  | down 7% |
| Operating Income | $1,065 |  | $176 |  | up 505% |  | $1,133 |  | $245 |  | up 362% |
| Net Income | $803 |  | $112 |  | up 617% |  | $967 |  | $181 |  | up 434% |
| Diluted Net Income Per Share | $5.15 |  | $0.75 |  | up 587% |  | $6.20 |  | $1.22 |  | up 408% |

[0001628280-26-004121:8k_2_02:14]
|  | GAAP |  | Non-GAAP |
| ($ in millions, except per share amounts) | Q2 2026 |  | Q2 2025 |  | Y/Y |  | Q2 2026 |  | Q2 2025 |  | Y/Y |
| Revenue | $3,025 |  | $1,876 |  | up 61% |  | $3,025 |  | $1,876 |  | up 61% |
| Gross Margin | 50.9% |  | 32.3% |  | up 18.6 ppt |  | 51.1% |  | 32.5% |  | up 18.6 ppt |
| Operating Expenses | $476 |  | $411 |  | up 16% |  | $413 |  | $376 |  | up 10% |
| Operating Income | $1,065 |  | $195 |  | up 446% |  | $1,133 |  | $233 |  | up 386% |
| Net Income | $803 |  | $104 |  | up 672% |  | $967 |  | $178 |  | up 443% |
| Diluted Net Income Per Share | $5.15 |  | $0.72 |  | up 615% |  | $6.20 |  | $1.23 |  | up 404% |

[0001628280-26-004121:8k_2_02:15]
End Market Summary

[0001628280-26-004121:8k_2_02:16]
| Revenue ($ in millions) | Q2 2026 |  | Q1 2026 |  | Q/Q |  | Q2 2025 |  | Y/Y |
| Datacenter | $440 |  | $269 |  | up 64% |  | $250 |  | up 76% |
| Edge | $1,678 |  | $1,387 |  | up 21% |  | $1,028 |  | up 63% |
| Consumer | $907 |  | $652 |  | up 39% |  | $598 |  | up 52% |
| Total Revenue | $3,025 |  | $2,308 |  | up 31% |  | $1,876 |  | up 61% |

[0001628280-26-004121:8k_2_02:17]
Additional details can be found within the Company’s earnings presentation, which is accessible online at investor.sandisk.com.

[0001628280-26-004121:8k_2_02:18]
2

[0001628280-26-004121:8k_2_02:19]
Business Outlook for Fiscal Third Quarter of 2026

[0001628280-26-004121:8k_2_02:20]
| (in millions, except per share amounts) | GAAP(1) | Non-GAAP(1) |
| Revenue | $4,400 to $4,800 | $4,400 to $4,800 |
| Gross Margin | 64.9% to 66.9% | 65.0% to 67.0% |
| Operating Expenses | $496 to $532 | $450 to $470 |
| Interest and Other Expense, Net | $23 to $28 | $25 to $30 |
| Tax Expense (2) | N/A | $325 to $375 |
| Diluted Net Income Per Share | N/A | $12.00 to $14.00 |
| Diluted Shares Outstanding | ~157 | ~157 |

[0001628280-26-004121:8k_2_02:21]
(1) Non-GAAP gross margin guidance excludes stock-based compensation expense and expense for short-term incentives granted in connection with the separation, totaling approximately $3 million to $5 million. The Company’s Non-GAAP operating expenses guidance excludes stock-based compensation expense and expense for short-term incentives granted in connection with the separation, totaling approximately $46 million to $62 million . The Company’s Non-GAAP interest and other expenses, net guidance excludes the accretion of the present value discount on consideration receivable from the sale of an interest in a subsidiary, totaling approximately $2 million. In the aggregate, Non-GAAP diluted net income per share guidance excludes these items totaling $47 million to $65 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other expenses, net, and Non-GAAP diluted net income per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the Company excludes from its Non-GAAP diluted net income per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other expenses, net, and Non-GAAP diluted net income per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, interest and other expenses, net and diluted net income per share, respectively) are not available without unreasonable effort.

[0001628280-26-004121:8k_2_02:22]
(2) Non-GAAP tax expense is determined based on a Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax expense may differ from our GAAP tax expense (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income or loss; (ii) due to the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax expense for the full year, excluding loss jurisdictions; and (iii) because our GAAP taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses.

[0001628280-26-004121:8k_2_02:23]
3

[0001628280-26-004121:8k_2_02:24]
Basis of Presentation

[0001628280-26-004121:8k_2_02:25]
On February 21, 2025, Sandisk Corporation (the “Company”) completed its separation from Western Digital Corporation (“WDC”) and became a standalone publicly traded company.

[0001628280-26-004121:8k_2_02:26]
The Company’s financial and operating results after the separation are presented on a consolidated basis. For periods prior to the separation, the Company’s historical combined financial statements were prepared on a carve-out basis and were derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”).

[0001628280-26-004121:8k_2_02:27]
Investor Communications

[0001628280-26-004121:8k_2_02:28]
The investment community conference call to discuss these results and the Company’s business outlook for the fiscal third quarter of 2026 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.sandisk.com.

[0001628280-26-004121:8k_2_02:29]
About Sandisk

[0001628280-26-004121:8k_2_02:30]
Sandisk is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for everyone from students, gamers and home offices, to the largest enterprises and public clouds to capture, preserve, access and transform an ever-increasing diversity of data. Our solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. Learn more about Sandisk at www.Sandisk.com.

[0001628280-26-004121:8k_2_02:31]
4

[0001628280-26-004121:8k_2_02:32]
Forward-Looking Statements

[0001628280-26-004121:8k_2_02:33]
###

[0001628280-26-004121:8k_2_02:34]
Sandisk and the Sandisk logo are registered trademarks or trademarks of Sandisk Corporation or its affiliates in the United States and/or other countries.

[0001628280-26-004121:8k_2_02:35]
5

[0001628280-26-004121:8k_2_02:36]
SANDISK CORPORATION

[0001628280-26-004121:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-004121:8k_2_02:38]
(in millions; except par value, unaudited)

[0001628280-26-004121:8k_2_02:39]
|  | January 2,2026 |  | June 27,2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,539 |  |  | $ | 1,481 |  |
| Accounts receivable, net | 1,239 |  |  | 1,068 |  |
| Inventories | 1,970 |  |  | 2,079 |  |
| Income tax receivable | 45 |  |  | 66 |  |
| Other current assets | 357 |  |  | 392 |  |
| Total current assets | 5,150 |  |  | 5,086 |  |
| Property, plant and equipment, net | 631 |  |  | 619 |  |
| Notes receivable and investments in Flash Ventures | 677 |  |  | 654 |  |
| Goodwill | 4,995 |  |  | 4,999 |  |
| Deferred tax assets | 62 |  |  | 58 |  |
| Income tax receivable, non-current | 98 |  |  | 80 |  |
| Other non-current assets | 1,385 |  |  | 1,489 |  |
| Total assets | $ | 12,998 |  |  | $ | 12,985 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 436 |  |  | $ | 366 |  |
| Accounts payable to related parties | 433 |  |  | 400 |  |
| Accrued expenses | 393 |  |  | 425 |  |
| Accrued compensation | 273 |  |  | 173 |  |
| Income tax payable | 99 |  |  | 43 |  |
| Current portion of long-term debt | 20 |  |  | 20 |  |
| Total current liabilities | 1,654 |  |  | 1,427 |  |
| Deferred tax liabilities | 22 |  |  | 17 |  |
| Long-term debt | 583 |  |  | 1,829 |  |
| Other liabilities | 526 |  |  | 496 |  |
| Total liabilities | 2,785 |  |  | 3,769 |  |
| Commitments and contingencies (Notes 10, 11, 14 and 15) |  |  |  |
| Shareholders’ equity: |  |  |  |
| Common stock, $0.01 par value; authorized — 450 shares; issued and outstanding — 148 shares and 146 shares, respectively | $ | 1 |  |  | $ | 1 |  |
| Additional paid-in capital | 11,336 |  |  | 11,248 |  |
| Accumulated deficit | (869) |  |  | (1,784) |  |
| Accumulated other comprehensive loss | (255) |  |  | (249) |  |
| Total shareholders’ equity | 10,213 |  |  | 9,216 |  |
| Total liabilities and shareholders’ equity | $ | 12,998 |  |  | $ | 12,985 |  |

[0001628280-26-004121:8k_2_02:40]
6

[0001628280-26-004121:8k_2_02:41]
SANDISK CORPORATION

[0001628280-26-004121:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-004121:8k_2_02:43]
(in millions, except per share amounts; unaudited)

[0001628280-26-004121:8k_2_02:44]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
| Revenue, net | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |
| Cost of revenue | 1,484 |  |  | 1,270 |  |  | 3,105 |  |  | 2,427 |  |
| Gross profit | 1,541 |  |  | 606 |  |  | 2,228 |  |  | 1,332 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 327 |  |  | 279 |  |  | 643 |  |  | 562 |  |
| Selling, general and administrative | 139 |  |  | 142 |  |  | 318 |  |  | 272 |  |
| Business separation costs | 9 |  |  | 21 |  |  | 18 |  |  | 41 |  |
| Employee termination and other | 1 |  |  | 3 |  |  | (2) |  |  | 5 |  |
| (Gain) loss on business divestiture | — |  |  | (34) |  |  | 10 |  |  | (34) |  |
| Total operating expenses | 476 |  |  | 411 |  |  | 987 |  |  | 846 |  |
| Operating income | 1,065 |  |  | 195 |  |  | 1,241 |  |  | 486 |  |
| Interest and other expense: |  |  |  |  |  |  |  |
| Interest income | 12 |  |  | 2 |  |  | 28 |  |  | 5 |  |
| Interest expense | (25) |  |  | (4) |  |  | (65) |  |  | (6) |  |
| Other expense, net | (115) |  |  | (20) |  |  | (143) |  |  | (45) |  |
| Total interest and other expense, net | (128) |  |  | (22) |  |  | (180) |  |  | (46) |  |
| Income before taxes | 937 |  |  | 173 |  |  | 1,061 |  |  | 440 |  |
| Income tax expense | 134 |  |  | 69 |  |  | 146 |  |  | 125 |  |
| Net income | $ | 803 |  |  | $ | 104 |  |  | $ | 915 |  |  | $ | 315 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 5.46 |  |  | $ | 0.72 |  |  | $ | 6.27 |  |  | $ | 2.17 |  |
| Diluted | $ | 5.15 |  |  | $ | 0.72 |  |  | $ | 6.02 |  |  | $ | 2.17 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 147 |  |  | 145 |  |  | 146 |  |  | 145 |  |
| Diluted | 156 |  |  | 145 |  |  | 152 |  |  | 145 |  |

[0001628280-26-004121:8k_2_02:45]
7

[0001628280-26-004121:8k_2_02:46]
SANDISK CORPORATION

[0001628280-26-004121:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-26-004121:8k_2_02:48]
(in millions; unaudited)

[0001628280-26-004121:8k_2_02:49]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
| Cash flows from operating activities |  |  |  |  |  |  |  |
| Net income | $ | 803 |  |  | $ | 104 |  |  | $ | 915 |  |  | $ | 315 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 38 |  |  | 36 |  |  | 74 |  |  | 90 |  |
| Stock-based compensation | 58 |  |  | 48 |  |  | 111 |  |  | 89 |  |
| Deferred income taxes | (13) |  |  | 28 |  |  | (10) |  |  | 23 |  |
| Gain on disposal of assets | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Impairment of cost method investments | 5 |  |  | 1 |  |  | 5 |  |  | 1 |  |
| Unrealized foreign exchange (gain) loss | 19 |  |  | 3 |  |  | 20 |  |  | (5) |  |
| (Gain) loss on sale of business divestiture | — |  |  | (34) |  |  | 10 |  |  | (34) |  |
| Amortization of debt issuance costs and discounts | 3 |  |  | — |  |  | 5 |  |  | — |  |
| Equity loss in investees, net of dividends received | 19 |  |  | 49 |  |  | 46 |  |  | 59 |  |
| Gain on sale of investments | (9) |  |  | — |  |  | (9) |  |  | — |  |
| Other non-cash operating activities, net | 33 |  |  | 4 |  |  | 27 |  |  | 10 |  |
| Settlement of accrued interest on Notes due to Western Digital Corporation | — |  |  | — |  |  | — |  |  | (96) |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | (46) |  |  | 133 |  |  | (171) |  |  | 31 |  |
| Inventories | (63) |  |  | (103) |  |  | 109 |  |  | (252) |  |
| Accounts payable | 45 |  |  | 24 |  |  | 75 |  |  | 57 |  |
| Accounts payable to related parties | (53) |  |  | (93) |  |  | 33 |  |  | (54) |  |
| Accrued expenses | 5 |  |  | 185 |  |  | (38) |  |  | 13 |  |
| Accrued compensation | 65 |  |  | 19 |  |  | 100 |  |  | 6 |  |
| Other assets and liabilities, net | 110 |  |  | (308) |  |  | 205 |  |  | (288) |  |
| Net cash provided by (used in) operating activities | 1,019 |  |  | 95 |  |  | 1,507 |  |  | (36) |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | (39) |  |  | (48) |  |  | (89) |  |  | (115) |  |
| Proceeds from dispositions of business | — |  |  | 191 |  |  | 25 |  |  | 191 |  |
| Notes receivable issuances to Flash Ventures | (169) |  |  | (252) |  |  | (256) |  |  | (266) |  |
| Notes receivable proceeds from Flash Ventures | 32 |  |  | 120 |  |  | 129 |  |  | 182 |  |
| Distributions from Flash Ventures | — |  |  | 176 |  |  | — |  |  | 176 |  |
| Strategic investments and other, net | 11 |  |  | 1 |  |  | 11 |  |  | 1 |  |
| Net cash provided by (used in) investing activities | (165) |  |  | 188 |  |  | (180) |  |  | 169 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | 24 |  |  | — |  |  | 24 |  |  | — |  |
| Taxes paid on vested stock awards under employee stock plans | (32) |  |  | — |  |  | (47) |  |  | — |  |
| Repayment of debt | (750) |  |  | — |  |  | (1,250) |  |  | — |  |
| Proceeds from borrowings on Notes due to Western Digital Corporation | — |  |  | 550 |  |  | — |  |  | 550 |  |
| Proceeds from principal repayments on Notes due from Western Digital Corporation | — |  |  | — |  |  | — |  |  | 101 |  |
| Repayments of principal on Notes due to Western Digital Corporation | — |  |  | — |  |  | — |  |  | (76) |  |
| Transfers to Western Digital Corporation | — |  |  | (420) |  |  | — |  |  | (231) |  |
| Net cash provided by (used in) financing activities | (758) |  |  | 130 |  |  | (1,273) |  |  | 344 |  |
| Effect of exchange rate changes on cash | 1 |  |  | (2) |  |  | 4 |  |  | (1) |  |
| Changes in cash and cash equivalents classified as assets held for sale | — |  |  | 71 |  |  | — |  |  | — |  |
| Net increase in cash and cash equivalents | 97 |  |  | 482 |  |  | 58 |  |  | 476 |  |
| Cash and cash equivalents, beginning of year | 1,442 |  |  | 322 |  |  | 1,481 |  |  | 328 |  |
| Cash and cash equivalents, end of period | $ | 1,539 |  |  | $ | 804 |  |  | $ | 1,539 |  |  | $ | 804 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for interest | $ | 14 |  |  | $ | 1 |  |  | $ | 62 |  |  | $ | 99 |  |
| Cash received for interest | 12 |  |  | 1 |  |  | 28 |  |  | 2 |  |
| Cash paid for income taxes | 53 |  |  | — |  |  | 92 |  |  | — |  |
| Non-cash transfers of: |  |  |  |  |  |  |  |
| Notes due to (from) Western Digital Corporation | — |  |  | 295 |  |  | — |  |  | 673 |  |
| Other assets and liabilities, net, from Western Digital Corporation | — |  |  | 38 |  |  | — |  |  | 44 |  |
| Property, plant and equipment from Western Digital Corporation | — |  |  | 22 |  |  | — |  |  | 25 |  |
| Tax balances to Western Digital Corporation | — |  |  | (21) |  |  | — |  |  | (14) |  |

[0001628280-26-004121:8k_2_02:50]
8

[0001628280-26-004121:8k_2_02:51]
SANDISK CORPORATION

[0001628280-26-004121:8k_2_02:52]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-26-004121:8k_2_02:53]
(in millions; unaudited)

[0001628280-26-004121:8k_2_02:54]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | October 3,2025 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
| GAAP gross profit | $ | 1,541 |  |  | $ | 687 |  |  | $ | 606 |  |  | $ | 2,228 |  |  | $ | 1,332 |  |
| Stock-based compensation expense | 5 |  |  | 4 |  |  | 3 |  |  | 9 |  |  | 9 |  |
| Non-GAAP gross profit | $ | 1,546 |  |  | $ | 691 |  |  | $ | 609 |  |  | $ | 2,237 |  |  | $ | 1,341 |  |
| GAAP operating expenses | $ | 476 |  |  | $ | 511 |  |  | $ | 411 |  |  | $ | 987 |  |  | $ | 846 |  |
| Stock-based compensation expense | (53) |  |  | (49) |  |  | (45) |  |  | (102) |  |  | (80) |  |
| Business separation costs | (9) |  |  | (9) |  |  | (21) |  |  | (18) |  |  | (41) |  |
| Employee termination and other | (1) |  |  | 3 |  |  | (3) |  |  | 2 |  |  | (5) |  |
| (Loss) gain on business divestiture | — |  |  | (10) |  |  | 34 |  |  | (10) |  |  | 34 |  |
| Non-GAAP operating expenses | $ | 413 |  |  | $ | 446 |  |  | $ | 376 |  |  | $ | 859 |  |  | $ | 754 |  |
| GAAP operating income | $ | 1,065 |  |  | $ | 176 |  |  | $ | 195 |  |  | $ | 1,241 |  |  | $ | 486 |  |
| Gross profit adjustments | 5 |  |  | 4 |  |  | 3 |  |  | 9 |  |  | 9 |  |
| Operating expense adjustments | 63 |  |  | 65 |  |  | 35 |  |  | 128 |  |  | 92 |  |
| Non-GAAP operating income | $ | 1,133 |  |  | $ | 245 |  |  | $ | 233 |  |  | $ | 1,378 |  |  | $ | 587 |  |
| GAAP interest and other expense, net | $ | (128) |  |  | $ | (52) |  |  | $ | (22) |  |  | $ | (180) |  |  | $ | (46) |  |
| Other, net | 94 |  |  | 10 |  |  | (4) |  |  | 104 |  |  | (4) |  |
| Non-GAAP interest and other expense, net | $ | (34) |  |  | $ | (42) |  |  | $ | (26) |  |  | $ | (76) |  |  | $ | (50) |  |
| GAAP income tax expense | $ | 134 |  |  | $ | 12 |  |  | $ | 69 |  |  | $ | 146 |  |  | $ | 125 |  |
| Income tax adjustments | (2) |  |  | 10 |  |  | (40) |  |  | 8 |  |  | (29) |  |
| Non-GAAP income tax expense | $ | 132 |  |  | $ | 22 |  |  | $ | 29 |  |  | $ | 154 |  |  | $ | 96 |  |

[0001628280-26-004121:8k_2_02:55]
9

[0001628280-26-004121:8k_2_02:56]
SANDISK CORPORATION

[0001628280-26-004121:8k_2_02:57]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-26-004121:8k_2_02:58]
(in millions, except per share amounts; unaudited)

[0001628280-26-004121:8k_2_02:59]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | October 3,2025 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
| GAAP net income | $ | 803 |  |  | $ | 112 |  |  | $ | 104 |  |  | $ | 915 |  |  | $ | 315 |  |
| Stock-based compensation expense | 58 |  |  | 53 |  |  | 48 |  |  | 111 |  |  | 89 |  |
| Business separation costs | 9 |  |  | 9 |  |  | 21 |  |  | 18 |  |  | 41 |  |
| Employee termination and other | 1 |  |  | (3) |  |  | 3 |  |  | (2) |  |  | 5 |  |
| (Gain) loss on business divestiture | — |  |  | 10 |  |  | (34) |  |  | 10 |  |  | (34) |  |
| Other, net | 94 |  |  | 10 |  |  | (4) |  |  | 104 |  |  | (4) |  |
| Income tax adjustments | 2 |  |  | (10) |  |  | 40 |  |  | (8) |  |  | 29 |  |
| Non-GAAP net income | $ | 967 |  |  | $ | 181 |  |  | $ | 178 |  |  | $ | 1,148 |  |  | $ | 441 |  |
| Diluted net income per share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | 5.15 |  |  | $ | 0.75 |  |  | $ | 0.72 |  |  | $ | 6.02 |  |  | $ | 2.17 |  |
| Non-GAAP | $ | 6.20 |  |  | $ | 1.22 |  |  | $ | 1.23 |  |  | $ | 7.55 |  |  | $ | 3.04 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 156 |  |  | 149 |  |  | 145 |  |  | 152 |  |  | 145 |  |
| Non-GAAP | 156 |  |  | 149 |  |  | 145 |  |  | 152 |  |  | 145 |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by (used in) operating activities | $ | 1,019 |  |  | $ | 488 |  |  | $ | 95 |  |  | $ | 1,507 |  |  | $ | (36) |  |
| Purchases of property, plant and equipment, net | (39) |  |  | (50) |  |  | (48) |  |  | (89) |  |  | (115) |  |
| Free cash flow | 980 |  |  | 438 |  |  | 47 |  |  | 1,418 |  |  | (151) |  |
| Activity related to Flash Ventures, net | (137) |  |  | 10 |  |  | 44 |  | (127) |  |  | 92 |
| Adjusted free cash flow | $ | 843 |  |  | $ | 448 |  |  | $ | 91 |  |  | $ | 1,291 |  |  | $ | (59) |  |

[0001628280-26-004121:8k_2_02:60]
10

[0001628280-26-004121:8k_2_02:61]
To supplement the condensed consolidated financial statements presented in accordance with GAAP, the table above sets forth Non-GAAP gross profit; Non-GAAP operating expenses; Non-GAAP operating income; Non-GAAP interest and other expense, net; Non-GAAP income tax expense; Non-GAAP net income; Non-GAAP diluted net income per share; Non-GAAP diluted weighted average shares outstanding; Free cash flow; and Adjusted free cash flow (collectively, the “Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or alternatives for measures prepared in accordance with GAAP and may be different from similarly titled Non-GAAP measures used by other companies. The Company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the Company’s earnings performance and comparing it against prior periods. Specifically, the Company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains, and losses that the Company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the Company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, stock-based compensation expense, business separation costs, employee termination and other, (gain) loss on business divestiture, other adjustments, and income tax adjustments. The Company believes these measures, along with the related reconciliations to the most directly comparable GAAP measures, provide additional detail and comparability for assessing the Company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the Company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0001628280-26-004121:8k_2_02:62]
As described above, the Company excludes the following items from its Non-GAAP measures:

[0001628280-26-004121:8k_2_02:63]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of the business over time and compare it against the Company’s peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0001628280-26-004121:8k_2_02:64]
Business separation costs. On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized management to pursue a plan to separate the Company into an independent public company. The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly-owned by WDC. As a result of the plan, the Company incurred separation and transition costs through the completion of the separation of the companies. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations. The Company believes these charges do not reflect the Company’s operating results and that they are not indicative of the underlying results of its business.

[0001628280-26-004121:8k_2_02:65]
Employee termination and other. From time to time, in order to realign the Company’s operations with anticipated market demand, the Company may terminate employees and/or restructure its operations. From time to time, the Company may also incur charges from the impairment of long-lived assets. In addition, the Company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods as well as from taking actions to reduce the amount of capital invested in facilities, including the sale-leaseback of facilities. These charges or credits are inconsistent in amount and frequency, and the Company believes they are not indicative of the underlying performance of its business.

[0001628280-26-004121:8k_2_02:66]
11

[0001628280-26-004121:8k_2_02:67]
(Gain) loss on business divestiture. In connection with the Company’s strategic decision to outsource the manufacturing of certain components and assemblies, on September 28, 2024, the Company completed the sale of 80% of its equity interest in one of its manufacturing subsidiaries. On September 25, 2025, the Company entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support. The Company recognized the adjustment as a Loss on business divestiture for the three months ended October 3, 2025. The overall transaction resulted in a discrete gain, which the Company believes is not indicative of the underlying performance of its ongoing business operations.

[0001628280-26-004121:8k_2_02:68]
Other adjustments. From time to time, the Company incurs charges or gains that the Company believes are not a part of the ongoing operation of its business. For the three and six months ended January 2, 2026, Other adjustments include charges for the settlement of certain previously existing legal matters and the impairment of an investment, partially offset by a gain upon sale of an investment. The resulting expense or benefit is inconsistent in amount and frequency.

[0001628280-26-004121:8k_2_02:69]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the Company believes that they are not indicative of the underlying performance of its ongoing business.

[0001628280-26-004121:8k_2_02:70]
Additionally, Free cash flow is defined as cash flows provided by (used in) operating activities less purchases of property, plant and equipment, net, and Adjusted free cash flow is defined as free cash flow plus the activity related to Flash Ventures, net. The Company considers Free cash flow and Adjusted free cash flow generated in any period to be useful indicators of cash that is available for strategic opportunities, including, among others, investing in the Company’s business, making strategic acquisitions, repaying debt, and strengthening the balance sheet.

[0001628280-26-004121:8k_2_02:71]
| Company Contacts: |
| Sandisk Corporation |  |  |
| Investor Contact: |  | Media Contact: |
| Ivan Donaldson |  | Media Relations |
| E: ivan.donaldson@sandisk.com |  | mediainquiries@sandisk.com |
| investors@sandisk.com |  |  |

[0001628280-26-004121:8k_2_02:72]
12
