# SNDK note change history — 0001628280-25-050698 → 0001628280-26-004407


## sndk:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004407:note_history:1]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 1 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 20 |  |  | 36 |  |
| Notes receivable, Flash Forward | 432 |  |  | 316 |  |
| Investment in Flash Partners | 33 |  |  | 55 |  |
| Investment in Flash Alliance | 102 |  |  | 115 |  |
| Investment in Flash Forward | 89 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 677 |  |  | $ | 654 |  |
  (was, 2025-11-07, similarity 0.9837):
[0001628280-25-050698:note_history:1]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 39 |  |  | 36 |  |
| Notes receivable, Flash Forward | 296 |  |  | 316 |  |
| Investment in Flash Partners | 39 |  |  | 55 |  |
| Investment in Flash Alliance | 112 |  |  | 115 |  |
| Investment in Flash Forward | 110 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 602 |  |  | $ | 654 |  |

- added (2026-01-30):
[0001628280-26-004407:note_history:2]
During the three and six months ended January 2, 2026, the Company made net payments to Flash Ventures of $0.9 billion and $1.8 billion, respectively, for purchases of flash-based memory wafers and net loans. During the three and six months ended December 27, 2024, the Company made net payments to Flash Ventures of $1.1 billion and $2.0 billion, respectively, for purchases of flash-based memory wafers and net loans. In addition, during the six months ended January 2, 2026, the Company received a $15 million dividend distribution from Flash Ventures.

- changed (2026-01-30):
[0001628280-26-004407:note_history:3]
As of January 2, 2026 and June 27, 2025, the Company had accounts payable balances due to Flash Ventures of $274 million and $279 million, respectively.
  (was, 2025-11-07, similarity 0.9565):
[0001628280-25-050698:note_history:3]
As of October 3, 2025 and June 27, 2025, the Company had accounts payable balances due to Flash Ventures of $338 million and $279 million, respectively.

- added (2026-01-30):
[0001628280-26-004407:note_history:4]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at January 2, 2026, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2026-01-30):
[0001628280-26-004407:note_history:5]
|  | January 2,2026 |
|  | (in millions) |
| Notes receivable | $ | 453 |  |
| Equity investments | 224 |  |
| Operating lease guarantees | 1,076 |  |
| Inventory and prepayments | 1,351 |  |
| Maximum estimable loss exposure | $ | 3,104 |  |

- changed (2026-01-30):
[0001628280-26-004407:note_history:6]
Flash Ventures has historically operated at nearly 100% of its manufacturing capacity. During the six months ended January 2, 2026, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to a level that more closely aligned the Company’s flash-based wafer supply with projected demand. During the six months ended January 2, 2026, the Company incurred costs of $11 million associated with the reduction in utilization related to Flash Ventures, which were recorded as charges to Cost of revenue. No such charges were incurred during the three months ended January 2, 2026 or during the three and six months ended December 27, 2024.
  (was, 2025-11-07, similarity 0.8467):
[0001628280-25-050698:note_history:6]
Flash Ventures has historically operated at nearly 100% of its manufacturing capacity. During the three months ended October 3, 2025, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to a level that more closely aligned the Company’s flash-based wafer supply with projected demand. During the three months ended October 3, 2025, the Company incurred costs of $11 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 27, 2024.

- added (2026-01-30):
[0001628280-26-004407:note_history:7]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward Kioxia’s future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of January 2, 2026, $881 million, with $131 million recorded within Other current assets and $750 million recorded within Other non-current assets in the Condensed Consolidated Balance Sheets, remain to be credited against future building depreciation charges and ultimately released within Costs of revenue when the Company’s inventory is sold. As of January 2, 2026, the Company is also committed to making additional building depreciation prepayments of $387 million, based on the Japanese yen to U.S. dollar exchange rate of ¥156.87 as of such date, payable as follows: $25 million for the remaining of fiscal year 2026, $121 million in fiscal year 2027, $177 million in fiscal year 2028 and $64 million in fiscal year 2029. As of January 2, 2026, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $155 million at varying dates through fiscal year 2035.

- changed (2026-01-30):
[0001628280-26-004407:note_history:8]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for the remaining six months of 2026 are $44 million.
  (was, 2025-11-07, similarity 0.9864):
[0001628280-25-050698:note_history:8]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for the remaining nine months of 2026 are $87 million.

- changed (2026-01-30):
[0001628280-26-004407:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of January 2, 2026:
  (was, 2025-11-07, similarity 0.9728):
[0001628280-25-050698:note_history:9]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 3, 2025:

- changed (2026-01-30):
[0001628280-26-004407:note_history:10]
The following table details the components of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of January 2, 2026:
  (was, 2025-11-07, similarity 0.9521):
[0001628280-25-050698:note_history:10]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 3, 2025:

- added (2026-01-30):
[0001628280-26-004407:note_history:11]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| 2026 | $ | 186 |  |  | $ | 42 |  |  | $ | 228 |  |
| 2027 | 270 |  |  | 96 |  |  | 366 |  |
| 2028 | 139 |  |  | 94 |  |  | 233 |  |
| 2029 | 61 |  |  | 51 |  |  | 112 |  |
| 2030 | 27 |  |  | 58 |  |  | 85 |  |
| 2031 | 4 |  |  | 48 |  |  | 52 |  |
| Total guarantee obligations | $ | 687 |  |  | $ | 389 |  |  | $ | 1,076 |  |

- changed (2026-01-30):
[0001628280-26-004407:note_history:12]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of January 2, 2026, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2025-11-07, similarity 0.9863):
[0001628280-25-050698:note_history:12]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of October 3, 2025, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2026-01-30):
[0001628280-26-004407:note_history:13]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly-listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.
  (was, 2025-11-07, similarity 0.9993):
[0001628280-25-050698:note_history:13]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”) an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly-listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

- changed (2026-01-30):
[0001628280-26-004407:note_history:14]
On September 25, 2025, SanDisk China and JCET entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support, resulting in a reduction of the September 28, 2025 installment payment from JCET to $27 million. The Company recognized the adjustment as a Loss on business divestiture for the six months ended January 2, 2026.
  (was, 2025-11-07, similarity 0.926):
[0001628280-25-050698:note_history:14]
On September 25, 2025, SanDisk China and JCET entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support, resulting in a reduction of the September 28, 2025 installment payment from JCET to $27 million. The Company recognized the adjustment as a Loss on business divestiture for the three months ended October 3, 2025.

- added (2026-01-30):
[0001628280-26-004407:note_history:15]
As of January 2, 2026, the outstanding consideration receivable was recognized at its present value of $135 million, with $36 million classified as Other current assets and $99 million classified as Other non-current assets in the Condensed Consolidated Balance Sheets. The remaining present value discount of $15 million as of January 2, 2026 will be recognized using the effective interest method over the next four years as Interest income in the Condensed Consolidated Statements of Operations.

- changed (2026-01-30):
[0001628280-26-004407:note_history:16]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other expense, net in the Condensed Consolidated Statements of Operations. As of January 2, 2026, the 20% retained interest in SDSS was valued at $163 million.
  (was, 2025-11-07, similarity 0.989):
[0001628280-25-050698:note_history:16]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other expense, net in the Condensed Consolidated Statements of Operations. As of October 3, 2025, the 20% retained interest in SDSS was valued at $162 million.

- changed (2026-01-30):
[0001628280-26-004407:note_history:17]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT,” a WDC affiliate) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if it fails to meet its minimum annual commitment. The Supply Agreement also provides that if the Company’s purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the three and six months ended January 2, 2026, the Company made purchases of $138 million and $277 million, respectively, under the Supply Agreement. As of January 2, 2026, the Company had a $159 million accounts payable balance due to SDSS.
  (was, 2025-11-07, similarity 0.9128):
[0001628280-25-050698:note_history:17]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT,” a WDC affiliate) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if it fails to meet its minimum annual commitment. The Supply Agreement also provides that if the Company’s purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the three months ended October 3, 2025, the Company made purchases of $139 million under the Supply Agreement and had a $147 million accounts payable balance due to SDSS as of October 3, 2025.

- added (2026-01-30):
[0001628280-26-004407:note_history:18]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the three and six months ended January 2, 2026, the Company recognized approximately 2% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. For the three and six months ended December 27, 2024, the Company recognized approximately 1% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 2% and 1% of Accounts receivable, net, as of January 2, 2026 and June 27, 2025, respectively.

- changed (2026-01-30):
[0001628280-26-004407:note_history:19]
•Separation and Distribution Agreement - The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Condensed Consolidated Balance Sheets were retained by WDC and certain assets and liabilities not included in the Company’s Condensed Consolidated Balance Sheets were transferred to the Company as of the date of the separation.
  (was, 2025-11-07, similarity 0.9777):
[0001628280-25-050698:note_history:19]
•Separation and Distribution Agreement - The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Condensed Combined Balance Sheets were retained by WDC and certain assets and liabilities not included in the Company’s Condensed Combined Balance Sheets were transferred to the Company as of the date of the separation.

- changed (2026-01-30):
[0001628280-26-004407:note_history:20]
As of quarter end January 2, 2026, the separation between the Company and WDC has been finalized, and no separation-related adjustments have been, or are expected to be, incurred going forward.
  (was, 2025-11-07, similarity 0.9681):
[0001628280-25-050698:note_history:20]
As of quarter end October 3, 2025, the separation between the Company and WDC has been finalized, and no separation-related adjustments have been, or are expected to be, incurred going forward.

- changed (2026-01-30):
[0001628280-26-004407:note_history:21]
•Employee Matters Agreement - The Employee Matters Agreement allocates liabilities and responsibilities relating to employment matters, employee compensation and benefit plans and programs and other related matters. Pursuant to this agreement, during the six months ended January 2, 2026, the Company received reimbursement of short-term employee incentives totaling $22 million from WDC. The Company did not receive any reimbursements from this agreement for the three months ended January 2, 2026.
  (was, 2025-11-07, similarity 0.8211):
[0001628280-25-050698:note_history:21]
•Employee Matters Agreement - The Employee Matters Agreement allocates liabilities and responsibilities relating to employment matters, employee compensation and benefit plans and programs and other related matters. Pursuant to this agreement, during the three months ended October 3, 2025, the Company received reimbursement of short-term employee incentives totaling $22 million from WDC.

- changed (2026-01-30):
[0001628280-26-004407:note_history:22]
•Tax Matters Agreement - The Tax Matters Agreement governs, among other things, WDC’s and the Company’s respective rights, responsibilities and obligations after the spin-off with respect to tax liabilities and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings, and other matters regarding taxes. In addition, the Tax Matters Agreement imposes certain restrictions on the Company and its subsidiaries (including restrictions on share issuances, business combinations, sales of assets, and similar transactions) that are designed to preserve the tax-free status of the spin-off and certain related transactions.
  (was, 2025-11-07, similarity 0.9993):
[0001628280-25-050698:note_history:22]
•Tax Matters Agreement - The Tax Matters Agreement governs, among other things, WDC’s and the Company’s respective rights, responsibilities and obligations after the spin-off with respect to tax liabilities and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings and other matters regarding taxes. In addition, the Tax Matters Agreement imposes certain restrictions on the Company and its subsidiaries (including restrictions on share issuances, business combinations, sales of assets, and similar transactions) that are designed to preserve the tax-free status of the spin-off and certain related transactions.

- changed (2026-01-30):
[0001628280-26-004407:note_history:23]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently increased to reflect changes in indemnification obligations under the Tax Matters Agreement, which is recorded in Other expense, net in the Condensed Consolidated Statements of Operations. The remaining tax indemnification liability of $128 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of January 2, 2026.
  (was, 2025-11-07, similarity 0.9776):
[0001628280-25-050698:note_history:23]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently increased to reflect changes in indemnification obligations under the Tax Matters Agreement, which is recorded in Other expense, net in the Condensed Consolidated Statements of Operations. The remaining tax indemnification liability of $125 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of October 3, 2025.

- added (2026-01-30):
[0001628280-26-004407:note_history:24]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4 |  |

- changed (2026-01-30):
[0001628280-26-004407:note_history:25]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 189 |  |
| Selling general, and administrative | — |  |  | 35 |  |  | — |  |  | 148 |  |
| Business separation costs | — |  |  | 21 |  |  | — |  |  | 41 |  |
| Employee termination and other charges | — |  |  | 3 |  |  | — |  |  | 5 |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 61 |  |  | $ | — |  |  | $ | 383 |  |
  (was, 2025-11-07, similarity 0.826):
[0001628280-25-050698:note_history:25]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 187 |  |  |  |  |  |
| Selling general, and administrative | — |  |  | 113 |  |  |  |  |  |
| Business separation costs | — |  |  | 2 |  |  |  |  |  |
| Employee termination and other charges | — |  |  | 20 |  |  |  |  |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 322 |  |  |  |  |  |

- changed (2026-01-30):
[0001628280-26-004407:note_history:26]
|  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | 491 |  |
| Notes due to Western Digital Corporation | — |  |  | (673) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (44) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (25) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | 14 |  |
| Accumulated other comprehensive loss transferred from Western Digital Corporation | — |  |  | 6 |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | (231) |  |
  (was, 2025-11-07, similarity 0.7189):
[0001628280-25-050698:note_history:26]
|  | Three Months Ended |
|  | October 3,2025 |  | September 27,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | 583 |  |
| Notes due to Western Digital Corporation | — |  |  | (378) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (6) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (3) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | (7) |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | 189 |  |

- removed (2026-01-30):
[0001628280-25-050698:note_history:27]
During the three months ended October 3, 2025 and September 27, 2024, the Company made net payments to Flash Ventures of $0.9 billion and $0.9 billion, respectively, for purchases of flash-based memory wafers and net loans. In addition, during the three months ended October 3, 2025, the Company received a $15 million dividend distribution from Flash Ventures.

- removed (2026-01-30):
[0001628280-25-050698:note_history:28]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 3, 2025, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2026-01-30):
[0001628280-25-050698:note_history:29]
|  | October 3,2025 |
|  | (in millions) |
| Notes receivable | $ | 341 |  |
| Equity investments | 261 |  |
| Operating lease guarantees | 1,219 |  |
| Inventory and prepayments | 1,273 |  |
| Maximum estimable loss exposure | $ | 3,094 |  |

- removed (2026-01-30):
[0001628280-25-050698:note_history:30]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward Kioxia’s future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of October 3, 2025, $914 million, with $131 million recorded within Other current assets and $783 million recorded within Other non-current assets in the Condensed Consolidated Balance Sheets, remain to be credited against future building depreciation charges and ultimately released within Costs of revenue when the Company’s inventory is sold. As of October 3, 2025, the Company is also committed to making additional building depreciation prepayments of $259 million, based on the Japanese yen to U.S. dollars exchange rate of ¥147.34 as of such date, payable as follows: $32 million for the remaining of fiscal year 2026, $119 million in fiscal year 2027, $95 million in fiscal year 2028 and $14 million in fiscal year 2029. As of October 3, 2025, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $186 million at varying dates through fiscal year 2035.

- removed (2026-01-30):
[0001628280-25-050698:note_history:31]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| 2026 | 297 |  |  | 70 |  |  | 367 |  |
| 2027 | 274 |  |  | 104 |  |  | 378 |  |
| 2028 | 138 |  |  | 100 |  |  | 238 |  |
| 2029 | 58 |  |  | 54 |  |  | 112 |  |
| 2030 | 25 |  |  | 62 |  |  | 87 |  |
| 2031 | 2 |  |  | 35 |  |  | 37 |  |
| Total guarantee obligations | $ | 794 |  |  | $ | 425 |  |  | $ | 1,219 |  |

- removed (2026-01-30):
[0001628280-25-050698:note_history:32]
As of October 3, 2025, the outstanding consideration receivable was recognized at its present value of $133 million, with $36 million classified as Other current assets and $97 million classified as Other non-current assets in the Condensed Consolidated Balance Sheets. The remaining present value discount of $17 million as of October 3, 2025 will be recognized using the effective interest method over the next four years as Interest income in the Condensed Consolidated Statements of Operations.

- removed (2026-01-30):
[0001628280-25-050698:note_history:33]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the three months ended October 3, 2025, and September 27, 2024, the Company recognized approximately 1% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 2% and 1% of Accounts receivable, net, as of October 3, 2025 and June 27, 2025, respectively.

- removed (2026-01-30):
[0001628280-25-050698:note_history:34]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  |  |  |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 2 |  |  |  |  |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004407:note_history:35]
Sandisk Corporation (“Sandisk” or the “Company”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, Sandisk’s broad and ever-expanding portfolio delivers powerful flash storage solutions for artificial intelligence (“AI”) workloads in datacenters, edge devices, and consumer applications. Sandisk’s technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. The Company’s solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. The Company’s broad portfolio of technology and products addresses multiple end markets of “Datacenter” (formerly referred to as “Cloud”), “Edge” (formerly referred to as “Client”), and “Consumer.” The Company operates primarily in the United States (“U.S.”) and also internationally, with a significant concentration in the Asia Pacific region.
  (was, 2025-11-07, similarity 0.9865):
[0001628280-25-050698:note_history:35]
Sandisk Corporation (“Sandisk” or the “Company”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, Sandisk’s broad and ever-expanding portfolio delivers powerful flash storage solutions for AI workloads in datacenters, edge devices, and consumer applications. Sandisk’s technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. The Company’s solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. The Company’s broad portfolio of technology and products addresses multiple end markets of “Datacenter” (formerly referred to as “Cloud”), “Edge” (formerly referred to as “Client”), and “Consumer.” The Company operates primarily in the United States (“U.S.”) and also internationally, with a significant concentration in the Asia Pacific region.

- changed (2026-01-30):
[0001628280-26-004407:note_history:36]
In connection with the separation, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the spin-off and provided a framework for the relationship between WDC and the Company following the separation. These agreements include the Separation and Distribution Agreement, which contains certain key provisions related to the spin-off, as well as a Transition Services Agreement (“TSA”), a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025. Additionally, the Company adopted certain compensation plans filed as Exhibits to the Company’s Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025. The Company also entered into various sublease agreements and established a stock compensation incentive plan in connection with the separation.
  (was, 2025-11-07, similarity 0.972):
[0001628280-25-050698:note_history:36]
In connection with the separation, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the spin-off and provided a framework for the relationship between WDC and the Company following the separation. These agreements include the Separation and Distribution Agreement, which contains certain key provisions related to the spin-off, as well as a Transition Services Agreement (“TSA”), a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025 and incorporated by reference to this Quarterly Report on Form 10-Q. Additionally, the Company adopted certain compensation plans filed as Exhibits to the Company’s Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025. The Company also entered into various sublease agreements and established a stock compensation incentive plan in connection with the separation.

- changed (2026-01-30):
[0001628280-26-004407:note_history:37]
After the separation, outstanding restricted stock units (“RSU”) and performance stock units (“PSU”) previously granted by WDC to employees of the Company were adjusted per the terms of the Employee Matters Agreement in an attempt to maintain the economic value of those awards before and after the separation. Generally, continuing Sandisk employees with outstanding RSU awards held as of the spin-off date were converted solely to equivalent RSU awards of the Company, and any outstanding WDC RSU awards held as of the spin-off date were canceled. Outstanding RSU and PSU awards at the time of the spin-off, held by employees at levels equal to Vice President and above, were converted into RSU and PSU awards of both the Company and WDC.
  (was, 2025-11-07, similarity 0.9993):
[0001628280-25-050698:note_history:37]
After the separation, outstanding restricted stock units (“RSU”) and performance stock units (“PSU”) previously granted by WDC to employees of the Company were adjusted per the terms of the Employee Matters Agreement, in an attempt to maintain the economic value of those awards before and after the separation. Generally, continuing Sandisk employees with outstanding RSU awards held as of the spin-off date were converted solely to equivalent RSU awards of the Company, and any outstanding WDC RSU awards held as of the spin-off date were canceled. Outstanding RSU and PSU awards at the time of the spin-off, held by employees at levels equal to Vice President and above, were converted into RSU and PSU awards of both the Company and WDC.

- changed (2026-01-30):
[0001628280-26-004407:note_history:38]
On June 9, 2025, WDC disposed of 21,314,768, or 14.6%, of the Company’s common stock through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. All expenses for the offering were paid for by the Company. As of January 2, 2026, WDC continued to retain 7,513,019, or 5.1%, of the outstanding shares of the Company’s common stock.
  (was, 2025-11-07, similarity 0.9677):
[0001628280-25-050698:note_history:38]
On June 9, 2025, WDC disposed of 21,314,768, or 14.6%, of the Company’s common stock through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. All expenses for the offering were paid for by us. As of October 3, 2025, WDC continued to retain 7,513,019, or 5.1%, of the outstanding shares of the Company’s common stock.

- changed (2026-01-30):
[0001628280-26-004407:note_history:39]
Intercompany transactions were eliminated, with the exception of balances associated with lending arrangements reflected within Notes due to (from) Western Digital Corporation in the Condensed Consolidated Balance Sheets, and transactions between the Company and WDC were generally considered to be effectively settled in the Condensed Consolidated Financial Statements at the time the transactions were recorded. The total net effect of the settlement of these transactions was reflected in the Condensed Consolidated Statements of Cash Flows as a financing activity and in the Condensed Consolidated Balance Sheets as Net investment from Western Digital Corporation. General financing activities included the net impact of any cash movements resulting from WDC’s centralized treasury cash management.
  (was, 2025-11-07, similarity 0.9975):
[0001628280-25-050698:note_history:39]
Intercompany transactions were eliminated, with the exception of balances associated with lending arrangements reflected within Notes due to (from) Western Digital Corporation in the Condensed Consolidated Balance Sheets, transactions between the Company and WDC were generally considered to be effectively settled in the Condensed Consolidated Financial Statements at the time the transactions were recorded. The total net effect of the settlement of these transactions was reflected in the Condensed Consolidated Statements of Cash Flows as a financing activity and in the Condensed Consolidated Balance Sheets as Net investment from Western Digital Corporation. General financing activities included the net impact of any cash movements resulting from WDC’s centralized treasury cash management.

- changed (2026-01-30):
[0001628280-26-004407:note_history:40]
The Condensed Consolidated Statements of Operations and Comprehensive Income (Loss) included all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions, and services provided by WDC. Allocation of general corporate expenses from WDC included, but was not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs were deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Condensed Consolidated Statements of Operations. The Condensed Consolidated Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on the Company’s behalf. The Company considers these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expense the Company would have incurred as a standalone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a standalone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.
  (was, 2025-11-07, similarity 0.9983):
[0001628280-25-050698:note_history:40]
The Condensed Consolidated Statements of Operations and Comprehensive Income included all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions, and services provided by WDC. Allocation of general corporate expenses from WDC included, but was not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs were deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Condensed Consolidated Statements of Operations. The Condensed Consolidated Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on the Company’s behalf. The Company considers these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expense the Company would have incurred as a standalone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a standalone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.

- changed (2026-01-30):
[0001628280-26-004407:note_history:41]
WDC maintains various stock-based compensation plans at a corporate level. Employees of the Company participated in those programs, and a portion of the compensation cost associated with those plans is included in the Company’s Condensed Consolidated Statements of Operations for the periods presented in this Quarterly Report on Form 10-Q. Before the spin-off, stock-based compensation expense was included within Net investment from Western Digital Corporation. The amounts presented in the Condensed Consolidated Financial Statements are not necessarily indicative of future awards and may not reflect the results that the Company would have experienced as a standalone entity.
  (was, 2025-11-07, similarity 0.9978):
[0001628280-25-050698:note_history:41]
WDC maintains various stock-based compensation plans at a corporate level. Employees of the Company participated in those programs, and a portion of the compensation cost associated with those plans was included in the Company’s Condensed Consolidated Statements of Operations for the periods presented in this Quarterly Report on Form 10-Q. Before the spin-off, stock-based compensation expense was included within Net investment from Western Digital Corporation. The amounts presented in the Condensed Consolidated Financial Statements are not necessarily indicative of future awards and may not reflect the results that the Company would have experienced as a standalone entity.

- changed (2026-01-30):
[0001628280-26-004407:note_history:42]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025 through January 2, 2026 are Condensed Consolidated Financial Statements based on the Company’s reported results as a standalone company. All transactions and accounts between controlled entities within the Company have been eliminated.
  (was, 2025-11-07, similarity 0.9792):
[0001628280-25-050698:note_history:42]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025, through October 3, 2025 are Condensed Consolidated Financial Statements based on the Company’s reported results as a standalone company. All transactions and accounts between controlled entities within the Company have been eliminated.

- changed (2026-01-30):
[0001628280-26-004407:note_history:43]
Following the separation, certain functions continue to be provided by or for WDC for up to fifteen months under the TSA or are being performed using the Company’s own resources or third-party service providers. For the period ended January 2, 2026, charges under the TSA were not material.
  (was, 2025-11-07, similarity 0.9261):
[0001628280-25-050698:note_history:43]
Following the separation, certain functions continue to be provided by or for WDC for up to fifteen months under the TSA or are being performed using the Company’s own resources or third-party service providers. As of October 3, 2025, charges under the TSA were not material.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-01-30):
[0001628280-26-004407:note_history:44]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 650 |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | — |  |
| Total debt | 650 |  |  | 1,900 |  |
| Unamortized issuance costs | 47 |  |  | 51 |  |
| Subtotal | 603 |  |  | 1,849 |  |
| Less: Current portion of long-term debt | 20 |  |  | 20 |  |
| Long term debt | $ | 583 |  |  | $ | 1,829 |  |

- changed (2026-01-30):
[0001628280-26-004407:note_history:45]
On February 21, 2025, the Company entered into a Loan Agreement (the “Loan Agreement”) by and among the Company, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, and the other parties party thereto. The Loan Agreement comprises a term loan B facility in the principal amount of $2.0 billion (the “Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”).
  (was, 2025-11-07, similarity 0.999):
[0001628280-25-050698:note_history:45]
On February 21, 2025, the Company entered into a Loan Agreement (the “Loan Agreement”) by and among the Company, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent and the other parties party thereto. The Loan Agreement comprises a term loan B facility in the principal amount of $2.0 billion (the “Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”).

- changed (2026-01-30):
[0001628280-26-004407:note_history:46]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose of or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements, or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement).
  (was, 2025-11-07, similarity 0.9972):
[0001628280-25-050698:note_history:46]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement).

- changed (2026-01-30):
[0001628280-26-004407:note_history:47]
For the three months ended January 2, 2026, interest expense was $22 million and amortization of issuance costs was $2 million. For the six months ended January 2, 2026, interest expense was $59 million and amortization of issuance costs was $5 million.
  (was, 2025-11-07, similarity 0.6354):
[0001628280-25-050698:note_history:47]
For the three months ended October 3, 2025, interest expense was $37 million and amortization of issuance costs was $2 million.

- changed (2026-01-30):
[0001628280-26-004407:note_history:48]
In connection with the establishment of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which are amortized to Interest expense over the life of the facility.
  (was, 2025-11-07, similarity 0.9546):
[0001628280-25-050698:note_history:48]
In connection with the issuance of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which are amortized to Interest expense over the life of the facility.

- changed (2026-01-30):
[0001628280-26-004407:note_history:49]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement). As of January 2, 2026, the Company was in compliance with the financial covenant.
  (was, 2025-11-07, similarity 0.8931):
[0001628280-25-050698:note_history:49]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement). As of October 3, 2025, the Company was in compliance with the financial covenant.

- changed (2026-01-30):
[0001628280-26-004407:note_history:50]
As of January 2, 2026, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.
  (was, 2025-11-07, similarity 0.961):
[0001628280-25-050698:note_history:50]
As of October 3, 2025, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.

- removed (2026-01-30):
[0001628280-25-050698:note_history:51]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 1,400 |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | $ | — |  |
| Total debt | 1,400 |  |  | $ | 1,900 |  |
| Unamortized issuance costs | 49 |  |  | $ | 51 |  |
| Subtotal | 1,351 |  |  | $ | 1,849 |  |
| Less: Current portion of long-term debt | 20 |  |  | $ | 20 |  |
| Long term debt | $ | 1,331 |  |  | $ | 1,829 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-01-30):
[0001628280-26-004407:note_history:52]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 650 |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | — |  |
| Total debt | 650 |  |  | 1,900 |  |
| Unamortized issuance costs | 47 |  |  | 51 |  |
| Subtotal | 603 |  |  | 1,849 |  |
| Less: Current portion of long-term debt | 20 |  |  | 20 |  |
| Long term debt | $ | 583 |  |  | $ | 1,829 |  |

- removed (2026-01-30):
[0001628280-25-050698:note_history:53]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 1,400 |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | $ | — |  |
| Total debt | 1,400 |  |  | $ | 1,900 |  |
| Unamortized issuance costs | 49 |  |  | $ | 51 |  |
| Subtotal | 1,351 |  |  | $ | 1,849 |  |
| Less: Current portion of long-term debt | 20 |  |  | $ | 20 |  |
| Long term debt | $ | 1,331 |  |  | $ | 1,829 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004407:note_history:54]
|  | January 2,2026 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 1 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 20 |  |  | 36 |  |
| Notes receivable, Flash Forward | 432 |  |  | 316 |  |
| Investment in Flash Partners | 33 |  |  | 55 |  |
| Investment in Flash Alliance | 102 |  |  | 115 |  |
| Investment in Flash Forward | 89 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 677 |  |  | $ | 654 |  |
  (was, 2025-11-07, similarity 0.9837):
[0001628280-25-050698:note_history:54]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 39 |  |  | 36 |  |
| Notes receivable, Flash Forward | 296 |  |  | 316 |  |
| Investment in Flash Partners | 39 |  |  | 55 |  |
| Investment in Flash Alliance | 112 |  |  | 115 |  |
| Investment in Flash Forward | 110 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 602 |  |  | $ | 654 |  |

- added (2026-01-30):
[0001628280-26-004407:note_history:55]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4 |  |

- changed (2026-01-30):
[0001628280-26-004407:note_history:56]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 189 |  |
| Selling general, and administrative | — |  |  | 35 |  |  | — |  |  | 148 |  |
| Business separation costs | — |  |  | 21 |  |  | — |  |  | 41 |  |
| Employee termination and other charges | — |  |  | 3 |  |  | — |  |  | 5 |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 61 |  |  | $ | — |  |  | $ | 383 |  |
  (was, 2025-11-07, similarity 0.826):
[0001628280-25-050698:note_history:56]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 187 |  |  |  |  |  |
| Selling general, and administrative | — |  |  | 113 |  |  |  |  |  |
| Business separation costs | — |  |  | 2 |  |  |  |  |  |
| Employee termination and other charges | — |  |  | 20 |  |  |  |  |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 322 |  |  |  |  |  |

- changed (2026-01-30):
[0001628280-26-004407:note_history:57]
|  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | 491 |  |
| Notes due to Western Digital Corporation | — |  |  | (673) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (44) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (25) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | 14 |  |
| Accumulated other comprehensive loss transferred from Western Digital Corporation | — |  |  | 6 |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | (231) |  |
  (was, 2025-11-07, similarity 0.7189):
[0001628280-25-050698:note_history:57]
|  | Three Months Ended |
|  | October 3,2025 |  | September 27,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | 583 |  |
| Notes due to Western Digital Corporation | — |  |  | (378) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (6) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (3) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | (7) |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | 189 |  |

- removed (2026-01-30):
[0001628280-25-050698:note_history:58]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  |  |  |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 2 |  |  |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004407:note_history:59]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 440 |  |  | $ | 250 |  |  | $ | 709 |  |  | $ | 550 |  |
| Edge | 1,678 |  |  | 1,028 |  |  | 3,065 |  |  | 2,097 |  |
| Consumer | 907 |  |  | 598 |  |  | 1,559 |  |  | 1,112 |  |
| Total revenue | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 2,063 |  |  | $ | 1,086 |  |  | $ | 3,578 |  |  | $ | 2,236 |  |
| Americas | 513 |  |  | 389 |  |  | 919 |  |  | 832 |  |
| Europe, Middle East and Africa | 449 |  |  | 401 |  |  | 836 |  |  | 691 |  |
| Total revenue | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |
  (was, 2025-11-07, similarity 0.8265):
[0001628280-25-050698:note_history:59]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 269 |  |  | $ | 300 |  |  |  |  |  |
| Edge | 1,387 |  |  | 1,069 |  |  |  |  |  |
| Consumer | 652 |  |  | 514 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,515 |  |  | $ | 1,150 |  |  |  |  |  |
| Americas | 406 |  |  | 443 |  |  |  |  |  |
| Europe, Middle East and Africa | 387 |  |  | 290 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001628280-26-004407:note_history:60]
|  | Three Months Ended |  | Six Months Ended |
|  | January 2,2026 |  | December 27,2024 |  | January 2,2026 |  | December 27,2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 440 |  |  | $ | 250 |  |  | $ | 709 |  |  | $ | 550 |  |
| Edge | 1,678 |  |  | 1,028 |  |  | 3,065 |  |  | 2,097 |  |
| Consumer | 907 |  |  | 598 |  |  | 1,559 |  |  | 1,112 |  |
| Total revenue | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 2,063 |  |  | $ | 1,086 |  |  | $ | 3,578 |  |  | $ | 2,236 |  |
| Americas | 513 |  |  | 389 |  |  | 919 |  |  | 832 |  |
| Europe, Middle East and Africa | 449 |  |  | 401 |  |  | 836 |  |  | 691 |  |
| Total revenue | $ | 3,025 |  |  | $ | 1,876 |  |  | $ | 5,333 |  |  | $ | 3,759 |  |
  (was, 2025-11-07, similarity 0.8265):
[0001628280-25-050698:note_history:60]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 269 |  |  | $ | 300 |  |  |  |  |  |
| Edge | 1,387 |  |  | 1,069 |  |  |  |  |  |
| Consumer | 652 |  |  | 514 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,515 |  |  | $ | 1,150 |  |  |  |  |  |
| Americas | 406 |  |  | 443 |  |  |  |  |  |
| Europe, Middle East and Africa | 387 |  |  | 290 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |

- added (2026-01-30):
[0001628280-26-004407:note_history:61]
The Company’s top 10 customers accounted for 44% and 40% of its net revenue for the three and six months ended January 2, 2026, respectively, and 42% and 46% of its net revenue for the three and six months ended December 27, 2024, respectively. For the three and six months ended January 2, 2026 and December 27, 2024, no customer accounted for more than 10% of the Company’s net revenue. 
Revenue
Contract assets represent the Company’s right to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company had no contract assets as of January 2, 2026 and June 27, 2025. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service, support, and maintenance contracts. Contract liabilities as of January 2, 2026, and June 27, 2025, and changes in contract liabilities for the three and six months ended January 2, 2026 and December 27, 2024 were not material.

- changed (2026-01-30):
[0001628280-26-004407:note_history:62]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements, and customer support and service contracts, which will be recognized over their contract period. As of January 2, 2026, the transaction price allocated to the remaining performance obligations was not material.
  (was, 2025-11-07, similarity 0.9713):
[0001628280-25-050698:note_history:62]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements, and customer support and service contracts, which will be recognized over their contract period. For the three months ended October 3, 2025, the transaction price allocated to the remaining performance obligations was not material.

- removed (2026-01-30):
[0001628280-25-050698:note_history:63]
The Company’s top 10 customers accounted for 40% and 53% of its net revenue for the three months ended October 3, 2025 and September 27, 2024, respectively. For the three months ended October 3, 2025 and September 27, 2024, no customer accounted for more than 10% of the Company’s net revenue. 
Revenue
Contract assets represent the Company’s right to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company had no contract assets as of October 3, 2025 or June 27, 2025. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service, support, and maintenance contracts. Contract liabilities as of October 3, 2025, and June 27, 2025, and changes in contract liabilities for the three months ended October 3, 2025 and September 27, 2024, were not material.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2026-01-30):
[0001628280-26-004407:note_history:64]
Note 16.    Subsequent Events

- added (2026-01-30):
[0001628280-26-004407:note_history:65]
On January 29, 2026, the Company and Kioxia Corporation entered into an FAL Second Commitment and Extension Agreement (the “FAL Second Extension Agreement”) and FPL Second Commitment and Extension Agreement (the “FPL Second Extension Agreement”, and together with the FAS Second Extension Agreement, collectively, the “Extension Agreements”), under which the parties thereto extended the term of the Flash Alliance and Flash Partners joint ventures to December 31, 2034. Following the execution of the Extension Agreements, all of the Flash Ventures across the Yokkaichi and Kitakami sites now co-terminate on December 31, 2034.
In addition to the Extension Agreements, the Company entered into Agreement to Enhance Collaboration with Kioxia, pursuant to which the Company will pay Kioxia $1.2 billion, with payments made over the years 2026 through 2029, in consideration of Kioxia’s manufacturing services and the continued availability of supply.
