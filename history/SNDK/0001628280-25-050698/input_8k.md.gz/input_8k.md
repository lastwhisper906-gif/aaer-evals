# SNDK 8-K — 0001628280-25-050180 filed 2025-11-06

## item codes, every 8-K on or before 2025-11-07

- 2025-11-06 0001628280-25-050180 — 2.02, 9.01
- 2025-08-14 0001193125-25-180782 — 2.02, 9.01
- 2025-05-07 0002023554-25-000021 — 2.02, 9.01
- 2025-03-11 0002023554-25-000007 — 5.02
- 2025-02-24 0001193125-25-033433 — 1.01, 2.03, 3.03, 5.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2025-02-14 0001193125-25-027285 — 3.03, 5.03, 9.01
- 2025-02-03 0001193125-25-019298 — 8.01, 9.01

## late-filing notifications on or before 2025-11-07

- none on or before 2025-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-050180:8k_2_02:1]
EX-99.1
2
sndkq1fy26ex991-pressrelea.htm
EX-99.1

[0001628280-25-050180:8k_2_02:2]
Document

[0001628280-25-050180:8k_2_02:3]
Exhibit 99.1

[0001628280-25-050180:8k_2_02:4]
Sandisk Reports Fiscal First Quarter 2026 Financial Results

[0001628280-25-050180:8k_2_02:5]
News Summary

[0001628280-25-050180:8k_2_02:6]
•First quarter revenue was $2.31 billion, up 21% sequentially and above the guidance range, with GAAP net income reported at $112 million ($0.75 diluted net income per share). First quarter Non-GAAP diluted net income per share was $1.22.

[0001628280-25-050180:8k_2_02:7]
•Datacenter revenue was up 26% sequentially, with two hyperscalers in qualification, a third hyperscaler and top storage OEM planned for CY26, and engagement with five major hyperscale customers.

[0001628280-25-050180:8k_2_02:8]
•BiCS8 technology accounted for 15% of total bits shipped; expected to reach majority of bit production exiting fiscal year 2026.

[0001628280-25-050180:8k_2_02:9]
•Expect second quarter revenue to be in the range of $2.55 billion to $2.65 billion, with expected Non-GAAP diluted net income per share to be in the range of $3.00 to $3.40.

[0001628280-25-050180:8k_2_02:10]
MILPITAS, Calif. — November 6, 2025 — Sandisk Corporation (Nasdaq: SNDK) today reported fiscal first quarter financial results.

[0001628280-25-050180:8k_2_02:11]
“Customers are turning to Sandisk for our leading technology and products, which are exceptionally well positioned at a time when demand is strengthening,” said David Goeckeler, CEO, Sandisk. “Our strong balance sheet and leading portfolio, combined with this phase of renewed growth and profitability, enabled us to achieve our net cash positive milestone ahead of plan and is positioning us to drive meaningful long-term value for our shareholders.”

[0001628280-25-050180:8k_2_02:12]
1

[0001628280-25-050180:8k_2_02:13]
Q1 2026 Financial Highlights

[0001628280-25-050180:8k_2_02:14]
|  | GAAP |  | Non-GAAP |
| ($ in millions, except per share amounts) | Q1 2026 |  | Q4 2025 |  | Q/Q |  | Q1 2026 |  | Q4 2025 |  | Q/Q |
| Revenue | $2,308 |  | $1,901 |  | up 21% |  | $2,308 |  | $1,901 |  | up 21% |
| Gross Margin | 29.8% |  | 26.2% |  | up 3.6 ppt |  | 29.9% |  | 26.4% |  | up 3.5 ppt |
| Operating Expenses | $511 |  | $480 |  | up 6% |  | $446 |  | $402 |  | up 11% |
| Operating Income | $176 |  | $18 |  | up 878% |  | $245 |  | $100 |  | up 145% |
| Net Income (Loss) | $112 |  | $(23) |  | up 587% |  | $181 |  | $42 |  | up 331% |
| Diluted Net Income (Loss) Per Share | $0.75 |  | $(0.16) |  | up 569% |  | $1.22 |  | $0.29 |  | up 321% |

[0001628280-25-050180:8k_2_02:15]
|  | GAAP |  | Non-GAAP |
| ($ in millions, except per share amounts) | Q1 2026 |  | Q1 2025 |  | Y/Y |  | Q1 2026 |  | Q1 2025 |  | Y/Y |
| Revenue | $2,308 |  | $1,883 |  | up 23% |  | $2,308 |  | $1,883 |  | up 23% |
| Gross Margin | 29.8% |  | 38.6% |  | down 8.8 ppt |  | 29.9% |  | 38.9% |  | down 9 ppt |
| Operating Expenses | $511 |  | $435 |  | up 17% |  | $446 |  | $378 |  | up 18% |
| Operating Income | $176 |  | $291 |  | down 40% |  | $245 |  | $354 |  | down 31% |
| Net Income | $112 |  | $211 |  | down 47% |  | $181 |  | $263 |  | down 31% |
| Diluted Net Income Per Share | $0.75 |  | $1.46 |  | down 49% |  | $1.22 |  | $1.81 |  | down 33% |

[0001628280-25-050180:8k_2_02:16]
End Market Summary

[0001628280-25-050180:8k_2_02:17]
| Revenue ($M) | Q1 2026 |  | Q4 2025 |  | Q/Q |  | Q1 2025 |  | Y/Y |
| Datacenter | $269 |  | $213 |  | up 26% |  | $300 |  | down 10% |
| Edge | 1,387 |  | 1,103 |  | up 26% |  | 1,069 |  | up 30% |
| Consumer | 652 |  | 585 |  | up 11% |  | 514 |  | up 27% |
| Total Revenue | $2,308 |  | $1,901 |  | up 21% |  | $1,883 |  | up 23% |

[0001628280-25-050180:8k_2_02:18]
Additional details can be found within the Company’s earnings presentation, which is accessible online at investor.sandisk.com.

[0001628280-25-050180:8k_2_02:19]
2

[0001628280-25-050180:8k_2_02:20]
Business Outlook for Fiscal Second Quarter of 2026

[0001628280-25-050180:8k_2_02:21]
|  | GAAP(1) | Non-GAAP(1) |
| Revenue ($M) | $2,550 to $2,650 | $2,550 to $2,650 |
| Gross Margin | 40.8% to 42.8% | 41.0% to 43.0% |
| Operating Expenses ($M) | $497 to $538 | $450 to $475 |
| Interest and Other Expense, Net ($M) | $38 to $43 | $40 to $45 |
| Tax Expense ($M)(2) | N/A | $80 to $90 |
| Diluted Net Income Per Share | N/A | $3.00 to $3.40 |
| Diluted Shares Outstanding (in millions) | ~ 155 | ~ 155 |

[0001628280-25-050180:8k_2_02:22]
(1) Non-GAAP gross margin guidance excludes stock-based compensation expense and expense for short-term incentives granted in connection with the separation, totaling approximately $4 million to $6 million. The Company’s Non-GAAP operating expenses guidance excludes stock-based compensation expense and expense for short-term incentives granted in connection with the separation, totaling approximately $47 million to $63 million . The Company’s Non-GAAP interest and other expenses, net guidance excludes the accretion of the present value discount on consideration receivable from the sale of an interest in a subsidiary, totaling approximately $2 million. In the aggregate, Non-GAAP diluted net income per share guidance excludes these items totaling $49 million to $67 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other expenses, net, and Non-GAAP diluted net income per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the Company excludes from its Non-GAAP diluted net income per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other expenses, net, and Non-GAAP diluted net income per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, and diluted net income per share, respectively) are not available without unreasonable effort.

[0001628280-25-050180:8k_2_02:23]
(2) Non-GAAP tax expense is determined based on a Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax expense may differ from our GAAP tax expense (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income or loss; (ii) due to the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax expense for the full year, excluding loss jurisdictions; and (iii) because our GAAP taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses.

[0001628280-25-050180:8k_2_02:24]
3

[0001628280-25-050180:8k_2_02:25]
Basis of Presentation

[0001628280-25-050180:8k_2_02:26]
On February 21, 2025, Sandisk Corporation (the “Company”) completed its separation from Western Digital Corporation (“WDC”) and became a standalone publicly traded company.

[0001628280-25-050180:8k_2_02:27]
The Company’s financial and operating results after the separation are presented on a consolidated basis. For periods prior to the separation, the Company’s historical combined financial statements were prepared on a carve-out basis and were derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”).

[0001628280-25-050180:8k_2_02:28]
Investor Communications

[0001628280-25-050180:8k_2_02:29]
The investment community conference call to discuss these results and the Company’s business outlook for the fiscal second quarter of 2026 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.sandisk.com.

[0001628280-25-050180:8k_2_02:30]
About Sandisk

[0001628280-25-050180:8k_2_02:31]
Sandisk is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for everyone from students, gamers and home offices, to the largest enterprises and public clouds to capture, preserve, access and transform an ever-increasing diversity of data. Our solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. Learn more about Sandisk at www.Sandisk.com.

[0001628280-25-050180:8k_2_02:32]
4

[0001628280-25-050180:8k_2_02:33]
Forward-Looking Statements

[0001628280-25-050180:8k_2_02:34]
###

[0001628280-25-050180:8k_2_02:35]
Sandisk and the Sandisk logo are registered trademarks or trademarks of Sandisk Corporation or its affiliates in the United States and/or other countries.

[0001628280-25-050180:8k_2_02:36]
5

[0001628280-25-050180:8k_2_02:37]
SANDISK CORPORATION

[0001628280-25-050180:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-050180:8k_2_02:39]
(in millions; except par value, unaudited)

[0001628280-25-050180:8k_2_02:40]
|  | October 3,2025 |  | June 27,2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,442 |  |  | $ | 1,481 |  |
| Accounts receivable, net | 1,193 |  |  | 1,068 |  |
| Inventories | 1,907 |  |  | 2,079 |  |
| Income tax receivable | 72 |  |  | 66 |  |
| Other current assets | 370 |  |  | 392 |  |
| Total current assets | 4,984 |  |  | 5,086 |  |
| Property, plant and equipment, net | 630 |  |  | 619 |  |
| Notes receivable and investments in Flash Ventures | 602 |  |  | 654 |  |
| Goodwill | 4,998 |  |  | 4,999 |  |
| Deferred tax assets | 57 |  |  | 58 |  |
| Income tax receivable, non-current | 61 |  |  | 80 |  |
| Other non-current assets | 1,417 |  |  | 1,489 |  |
| Total assets | $ | 12,749 |  |  | $ | 12,985 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 398 |  |  | $ | 366 |  |
| Accounts payable to related parties | 486 |  |  | 400 |  |
| Accrued expenses | 382 |  |  | 425 |  |
| Accrued compensation | 208 |  |  | 173 |  |
| Income tax payables | 22 |  |  | 43 |  |
| Current portion of long-term debt | 20 |  |  | 20 |  |
| Total current liabilities | 1,516 |  |  | 1,427 |  |
| Deferred tax liabilities | 28 |  |  | 17 |  |
| Long-term debt | 1,331 |  |  | 1,829 |  |
| Other liabilities | 493 |  |  | 496 |  |
| Total liabilities | 3,368 |  |  | 3,769 |  |
| Shareholders’ equity: |  |  |  |
| Common stock, $0.01 par value; authorized — 450 shares; issued and outstanding — 147 shares and 146 shares, respectively | $ | 1 |  |  | $ | 1 |  |
| Additional paid-in capital | 11,286 |  |  | 11,248 |  |
| Accumulated deficit | (1,672) |  |  | (1,784) |  |
| Accumulated other comprehensive loss | (234) |  |  | (249) |  |
| Total shareholders’ equity | 9,381 |  |  | 9,216 |  |
| Total liabilities and shareholders’ equity | $ | 12,749 |  |  | $ | 12,985 |  |

[0001628280-25-050180:8k_2_02:41]
6

[0001628280-25-050180:8k_2_02:42]
SANDISK CORPORATION

[0001628280-25-050180:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-25-050180:8k_2_02:44]
(in millions, except per share amounts; unaudited)

[0001628280-25-050180:8k_2_02:45]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
| Revenue, net | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |
| Cost of revenue | 1,621 |  |  | 1,157 |  |  |  |  |  |
| Gross profit | 687 |  |  | 726 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 316 |  |  | 283 |  |  |  |  |  |
| Selling, general and administrative | 179 |  |  | 130 |  |  |  |  |  |
| Business separation costs | 9 |  |  | 20 |  |  |  |  |  |
| Employee termination and other | (3) |  |  | 2 |  |  |  |  |  |
| Loss on business divestiture | 10 |  |  | — |  |  |  |  |  |
| Total operating expenses | 511 |  |  | 435 |  |  |  |  |  |
| Operating income | 176 |  |  | 291 |  |  |  |  |  |
| Interest and other expense: |  |  |  |  |  |  |  |
| Interest income | 16 |  |  | 3 |  |  |  |  |  |
| Interest expense | (40) |  |  | (2) |  |  |  |  |  |
| Other expense, net | (28) |  |  | (25) |  |  |  |  |  |
| Total interest and other expense, net | (52) |  |  | (24) |  |  |  |  |  |
| Income before taxes | 124 |  |  | 267 |  |  |  |  |  |
| Income tax expense | 12 |  |  | 56 |  |  |  |  |  |
| Net income | $ | 112 |  |  | $ | 211 |  |  |  |  |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 0.77 |  |  | $ | 1.46 |  |  |  |  |  |
| Diluted | $ | 0.75 |  |  | $ | 1.46 |  |  |  |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 146 |  |  | 145 |  |  |  |  |  |
| Diluted | 149 |  |  | 145 |  |  |  |  |  |

[0001628280-25-050180:8k_2_02:46]
7

[0001628280-25-050180:8k_2_02:47]
SANDISK CORPORATION

[0001628280-25-050180:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-25-050180:8k_2_02:49]
(in millions; unaudited)

[0001628280-25-050180:8k_2_02:50]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |
| Net income | $ | 112 |  |  | $ | 211 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by (used in) operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 36 |  |  | 54 |  |  |  |  |  |
| Stock-based compensation | 53 |  |  | 41 |  |  |  |  |  |
| Deferred income taxes | 3 |  |  | (5) |  |  |  |  |  |
| Unrealized foreign exchange (gain) loss | 1 |  |  | (8) |  |  |  |  |  |
| Loss on sale of business divestiture | 10 |  |  | — |  |  |  |  |  |
| Amortization of debt issuance costs and discounts | 2 |  |  | — |  |  |  |  |  |
| Equity loss in investees, net of dividends received | 27 |  |  | 10 |  |  |  |  |  |
| Other non-cash operating activities, net | (6) |  |  | 6 |  |  |  |  |  |
| Settlement of accrued interest on Notes due to Western Digital Corporation | — |  |  | (96) |  |  |  |  |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | (125) |  |  | (102) |  |  |  |  |  |
| Inventories | 172 |  |  | (149) |  |  |  |  |  |
| Accounts payable | 30 |  |  | 33 |  |  |  |  |  |
| Accounts payable to related parties | 86 |  |  | 39 |  |  |  |  |  |
| Accrued expenses | (43) |  |  | (172) |  |  |  |  |  |
| Accrued compensation | 35 |  |  | (13) |  |  |  |  |  |
| Other assets and liabilities, net | 95 |  |  | 20 |  |  |  |  |  |
| Net cash provided by (used in) operating activities | 488 |  |  | (131) |  |  |  |  |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | (50) |  |  | (67) |  |  |  |  |  |
| Proceeds from dispositions of business | 25 |  |  | — |  |  |  |  |  |
| Notes receivable issuances to Flash Ventures | (87) |  |  | (14) |  |  |  |  |  |
| Notes receivable proceeds from Flash Ventures | 97 |  |  | 62 |  |  |  |  |  |
| Net cash used in investing activities | (15) |  |  | (19) |  |  |  |  |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |
| Taxes paid on vested stock awards under employee stock plans | (15) |  |  | — |  |  |  |  |  |
| Repayment of debt | (500) |  |  | — |  |  |  |  |  |
| Proceeds from principal repayments on Notes due from Western Digital Corporation | — |  |  | 101 |  |  |  |  |  |
| Repayments of principal on Notes due to Western Digital Corporation | — |  |  | (76) |  |  |  |  |  |
| Transfers from Western Digital Corporation | — |  |  | 189 |  |  |  |  |  |
| Net cash provided by (used in) financing activities | (515) |  |  | 214 |  |  |  |  |  |
| Effect of exchange rate changes on cash | 3 |  |  | 1 |  |  |  |  |  |
| Changes in cash and cash equivalents classified as assets held for sale | — |  |  | (71) |  |  |  |  |  |
| Net decrease in cash and cash equivalents | (39) |  |  | (6) |  |  |  |  |  |
| Cash and cash equivalents, beginning of year | 1,481 |  |  | 328 |  |  |  |  |  |
| Cash and cash equivalents, end of period | $ | 1,442 |  |  | $ | 322 |  |  |  |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for interest | $ | 48 |  |  | $ | 98 |  |  |  |  |  |
| Cash received for interest | 16 |  |  | 1 |  |  |  |  |  |
| Cash paid for income taxes | 39 |  |  | — |  |  |  |  |  |
| Non-cash transfers of: |  |  |  |  |  |  |  |
| Notes due to Western Digital Corporation | — |  |  | 378 |  |  |  |  |  |
| Changes in other assets and liabilities, net, from Western Digital Corporation | — |  |  | 6 |  |  |  |  |  |
| Property, plant and equipment from Western Digital Corporation | — |  |  | 3 |  |  |  |  |  |
| Tax balances to Western Digital Corporation | — |  |  | 7 |  |  |  |  |  |

[0001628280-25-050180:8k_2_02:51]
SANDISK CORPORATION

[0001628280-25-050180:8k_2_02:52]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-25-050180:8k_2_02:53]
(in millions; unaudited)

[0001628280-25-050180:8k_2_02:54]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | June 27,2025 |  | September 27,2024 |  |  |  |  |
| GAAP gross profit | $ | 687 |  |  | $ | 498 |  |  | $ | 726 |  |  |  |  |  |
| Stock-based compensation expense | 4 |  |  | 4 |  |  | 6 |  |  |  |  |  |
| Non-GAAP gross profit | $ | 691 |  |  | $ | 502 |  |  | $ | 732 |  |  |  |  |  |
| GAAP operating expenses | $ | 511 |  |  | $ | 480 |  |  | $ | 435 |  |  |  |  |  |
| Stock-based compensation expense | (49) |  |  | (45) |  |  | (35) |  |  |  |  |  |
| Business separation costs | (9) |  |  | (17) |  |  | (20) |  |  |  |  |  |
| Employee termination and other | 3 |  |  | (16) |  |  | (2) |  |  |  |  |  |
| Loss on business divestiture | (10) |  |  | — |  |  | — |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 446 |  |  | $ | 402 |  |  | $ | 378 |  |  |  |  |  |
| GAAP operating income | $ | 176 |  |  | $ | 18 |  |  | $ | 291 |  |  |  |  |  |
| Gross profit adjustments | 4 |  |  | 4 |  |  | 6 |  |  |  |  |  |
| Operating expense adjustments | 65 |  |  | 78 |  |  | 57 |  |  |  |  |  |
| Non-GAAP operating income | $ | 245 |  |  | $ | 100 |  |  | $ | 354 |  |  |  |  |  |
| GAAP interest and other expense, net | $ | (52) |  |  | $ | (36) |  |  | $ | (24) |  |  |  |  |  |
| Interest and other expense, net adjustments | 10 |  |  | (1) |  |  | — |  |  |  |  |  |
| Non-GAAP interest and other expense, net | $ | (42) |  |  | $ | (37) |  |  | $ | (24) |  |  |  |  |  |
| GAAP income tax expense | $ | 12 |  |  | $ | 5 |  |  | $ | 56 |  |  |  |  |  |
| Income tax adjustments | 10 |  |  | 16 |  |  | 11 |  |  |  |  |  |
| Non-GAAP income tax expense | $ | 22 |  |  | $ | 21 |  |  | $ | 67 |  |  |  |  |  |

[0001628280-25-050180:8k_2_02:55]
9

[0001628280-25-050180:8k_2_02:56]
SANDISK CORPORATION

[0001628280-25-050180:8k_2_02:57]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-25-050180:8k_2_02:58]
(in millions, except per share amounts; unaudited)

[0001628280-25-050180:8k_2_02:59]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | June 27,2025 |  | September 27,2024 |  |  |  |  |
| GAAP net income (loss) | $ | 112 |  |  | $ | (23) |  |  | $ | 211 |  |  |  |  |  |
| Stock-based compensation expense | 53 |  |  | 49 |  |  | 41 |  |  |  |  |  |
| Business separation costs | 9 |  |  | 17 |  |  | 20 |  |  |  |  |  |
| Employee termination and other | (3) |  |  | 16 |  |  | 2 |  |  |  |  |  |
| Loss on business divestiture | 10 |  |  | — |  |  | — |  |  |  |  |  |
| Other | 10 |  |  | (1) |  |  | — |  |  |  |  |  |
| Income tax adjustments | (10) |  |  | (16) |  |  | (11) |  |  |  |  |  |
| Non-GAAP net income | $ | 181 |  |  | $ | 42 |  |  | $ | 263 |  |  |  |  |  |
| Diluted net income (loss) per share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | 0.75 |  |  | $ | (0.16) |  |  | $ | 1.46 |  |  |  |  |  |
| Non-GAAP: | $ | 1.22 |  |  | $ | 0.29 |  |  | $ | 1.81 |  |  |  |  |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 149 |  |  | 145 |  |  | 145 |  |  |  |  |  |
| Non-GAAP: | 149 |  |  | 147 |  |  | 145 |  |  |  |  |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by (used in) operating activities | $ | 488 |  |  | $ | 94 |  |  | $ | (131) |  |  |  |  |  |
| Purchases of property, plant and equipment, net | (50) |  |  | (45) |  |  | (67) |  |  |  |  |  |
| Free cash flow | 438 |  |  | 49 |  |  | (198) |  |  |  |  |  |
| Activity related to Flash Ventures, net | 10 |  | 28 |  |  | 48 |  |  |  |  |
| Adjusted free cash flow | $ | 448 |  |  | $ | 77 |  |  | $ | (150) |  |  |  |  |  |

[0001628280-25-050180:8k_2_02:60]
10

[0001628280-25-050180:8k_2_02:61]
To supplement the condensed consolidated financial statements presented in accordance with GAAP, the table above sets forth Non-GAAP gross profit; Non-GAAP operating expenses; Non-GAAP operating income; Non-GAAP interest and other expense, net; Non-GAAP income tax expense; Non-GAAP net income; Non-GAAP diluted net income per share; Non-GAAP diluted weighted average shares outstanding; Free cash flow; and Adjusted free cash flow (collectively, the “Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or alternatives for measures prepared in accordance with GAAP and may be different from similarly titled Non-GAAP measures used by other companies. The Company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the Company’s earnings performance and comparing it against prior periods. Specifically, the Company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains, and losses that the Company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the Company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, stock-based compensation expense, business separation costs, employee termination and other, loss on business divestiture, other adjustments, and income tax adjustments. The Company believes these measures, along with the related reconciliations to the most directly comparable GAAP measures, provide additional detail and comparability for assessing the Company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the Company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0001628280-25-050180:8k_2_02:62]
As described above, the Company excludes the following items from its Non-GAAP measures:

[0001628280-25-050180:8k_2_02:63]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of the business over time and compare it against the Company’s peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0001628280-25-050180:8k_2_02:64]
Business separation costs. On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized management to pursue a plan to separate the Company into an independent public company. The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly-owned by WDC. As a result of the plan, the Company incurred separation and transition costs through the completion of the separation of the companies. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations. The Company believes these charges do not reflect the Company’s operating results and that they are not indicative of the underlying results of its business.

[0001628280-25-050180:8k_2_02:65]
Employee termination and other. From time to time, in order to realign the Company’s operations with anticipated market demand, the Company may terminate employees and/or restructure its operations. From time to time, the Company may also incur charges from the impairment of long-lived assets. In addition, the Company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods as well as from taking actions to reduce the amount of capital invested in facilities, including the sale-leaseback of facilities. These charges or credits are inconsistent in amount and frequency, and the Company believes they are not indicative of the underlying performance of its business.

[0001628280-25-050180:8k_2_02:66]
11

[0001628280-25-050180:8k_2_02:67]
Loss on business divestiture. In connection with the Company’s strategic decision to outsource the manufacturing of certain components and assemblies, on September 28, 2024, the Company completed the sale of 80% of its equity interest in one of its manufacturing subsidiaries. On September 25, 2025, the Company entered into an Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support. The Company recognized the adjustment as a Loss on business divestiture for the three months ended October 3, 2025. The overall transaction resulted in a discrete gain, which the Company believes is not indicative of the underlying performance of its ongoing business operations.

[0001628280-25-050180:8k_2_02:68]
Other adjustments. From time to time, the Company incurs charges or gains that the Company believes are not a part of the ongoing operation of its business. The resulting expense or benefit is inconsistent in amount and frequency.

[0001628280-25-050180:8k_2_02:69]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the Company believes that they are not indicative of the underlying performance of its ongoing business.

[0001628280-25-050180:8k_2_02:70]
Additionally, Free cash flow is defined as cash flows provided by (used in) operating activities less purchases of property, plant and equipment, net, and Adjusted free cash flow is defined as free cash flow plus the activity related to Flash Ventures, net. The Company considers Free cash flow and Adjusted free cash flow generated in any period to be useful indicators of cash that is available for strategic opportunities, including, among others, investing in the Company’s business, making strategic acquisitions, repaying debt and strengthening the balance sheet.

[0001628280-25-050180:8k_2_02:71]
| Company Contacts: |
| Sandisk Corporation |  |  |
| Investor Contact: |  | Media Contact: |
| Ivan Donaldson |  | Media Relations |
| E: ivan.donaldson@sandisk.com |  | mediainquiries@sandisk.com |
| investors@sandisk.com |  |  |

[0001628280-25-050180:8k_2_02:72]
12
