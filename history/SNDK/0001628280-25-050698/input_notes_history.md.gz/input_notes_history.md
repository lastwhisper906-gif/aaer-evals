# SNDK note change history — 0002023554-25-000027 → 0001628280-25-050698


## sndk:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001628280-25-050698:note_history:1]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 39 |  |  | 36 |  |
| Notes receivable, Flash Forward | 296 |  |  | 316 |  |
| Investment in Flash Partners | 39 |  |  | 55 |  |
| Investment in Flash Alliance | 112 |  |  | 115 |  |
| Investment in Flash Forward | 110 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 602 |  |  | $ | 654 |  |
  (was, 2025-05-12, similarity 0.986):
[0002023554-25-000027:note_history:1]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 37 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 38 |  |  | 5 |  |
| Notes receivable, Flash Forward | 296 |  |  | 485 |  |
| Investment in Flash Partners | 46 |  |  | 148 |  |
| Investment in Flash Alliance | 116 |  |  | 219 |  |
| Investment in Flash Forward | 129 |  |  | 143 |  |
| Total notes receivable and investments in Flash Ventures | $ | 662 |  |  | $ | 1,001 |  |

- added (2025-11-07):
[0001628280-25-050698:note_history:2]
During the three months ended October 3, 2025 and September 27, 2024, the Company made net payments to Flash Ventures of $0.9 billion and $0.9 billion, respectively, for purchases of flash-based memory wafers and net loans. In addition, during the three months ended October 3, 2025, the Company received a $15 million dividend distribution from Flash Ventures.

- changed (2025-11-07):
[0001628280-25-050698:note_history:3]
As of October 3, 2025 and June 27, 2025, the Company had accounts payable balances due to Flash Ventures of $338 million and $279 million, respectively.
  (was, 2025-05-12, similarity 0.9635):
[0002023554-25-000027:note_history:3]
As of March 28, 2025, and June 28, 2024, the Company had accounts payable balances due to Flash Ventures of $283 million and $313 million, respectively.

- added (2025-11-07):
[0001628280-25-050698:note_history:4]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at October 3, 2025, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- added (2025-11-07):
[0001628280-25-050698:note_history:5]
|  | October 3,2025 |
|  | (in millions) |
| Notes receivable | $ | 341 |  |
| Equity investments | 261 |  |
| Operating lease guarantees | 1,219 |  |
| Inventory and prepayments | 1,273 |  |
| Maximum estimable loss exposure | $ | 3,094 |  |

- changed (2025-11-07):
[0001628280-25-050698:note_history:6]
The Company is obligated to pay for variable costs incurred by Flash Ventures in producing the Company’s share of Flash Ventures’ flash-based memory wafer supply, based on its rolling three-month forecast. The Company’s share generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company cannot estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that the Flash Ventures entity’s operating cash flow is insufficient to fund these investments.
  (was, 2025-05-12, similarity 0.9254):
[0002023554-25-000027:note_history:6]
The Company is obligated to pay for variable costs incurred in producing its share of Flash Ventures’ flash-based memory wafer supply, based on its rolling three-month forecast, which generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company is not able to estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that the Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

- changed (2025-11-07):
[0001628280-25-050698:note_history:7]
Flash Ventures has historically operated at nearly 100% of its manufacturing capacity. During the three months ended October 3, 2025, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to a level that more closely aligned the Company’s flash-based wafer supply with projected demand. During the three months ended October 3, 2025, the Company incurred costs of $11 million associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended September 27, 2024.
  (was, 2025-05-12, similarity 0.6001):
[0002023554-25-000027:note_history:7]
Flash Ventures has historically operated at nearly 100% of its manufacturing capacity. During the three months ended March 28, 2025 and first two quarters of 2024, as a result of flash market conditions, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity to an abnormally low level to more closely align the Company’s flash-based wafer supply with projected demand. During the three and nine months ended March 28, 2025 the Company incurred costs of $24 million, and during the nine months ended March 29, 2024 the Company incurred costs of $249 million, associated with the reduction in utilization related to Flash Ventures, which was recorded as a charge to Cost of revenue. No such charges were incurred during the three months ended March 29, 2024.

- added (2025-11-07):
[0001628280-25-050698:note_history:8]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward Kioxia’s future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of October 3, 2025, $914 million, with $131 million recorded within Other current assets and $783 million recorded within Other non-current assets in the Condensed Consolidated Balance Sheets, remain to be credited against future building depreciation charges and ultimately released within Costs of revenue when the Company’s inventory is sold. As of October 3, 2025, the Company is also committed to making additional building depreciation prepayments of $259 million, based on the Japanese yen to U.S. dollars exchange rate of ¥147.34 as of such date, payable as follows: $32 million for the remaining of fiscal year 2026, $119 million in fiscal year 2027, $95 million in fiscal year 2028 and $14 million in fiscal year 2029. As of October 3, 2025, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $186 million at varying dates through fiscal year 2035.

- changed (2025-11-07):
[0001628280-25-050698:note_history:9]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for the remaining nine months of 2026 are $87 million.
  (was, 2025-05-12, similarity 0.9864):
[0002023554-25-000027:note_history:9]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for the remaining three months of 2025 are $40 million.

- changed (2025-11-07):
[0001628280-25-050698:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of October 3, 2025:
  (was, 2025-05-12, similarity 0.9766):
[0002023554-25-000027:note_history:10]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of March 28, 2025:

- changed (2025-11-07):
[0001628280-25-050698:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of October 3, 2025:
  (was, 2025-05-12, similarity 0.9825):
[0002023554-25-000027:note_history:11]
The following table details the breakdown of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of March 28, 2025:

- changed (2025-11-07):
[0001628280-25-050698:note_history:12]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| 2026 | 297 |  |  | 70 |  |  | 367 |  |
| 2027 | 274 |  |  | 104 |  |  | 378 |  |
| 2028 | 138 |  |  | 100 |  |  | 238 |  |
| 2029 | 58 |  |  | 54 |  |  | 112 |  |
| 2030 | 25 |  |  | 62 |  |  | 87 |  |
| 2031 | 2 |  |  | 35 |  |  | 37 |  |
| Total guarantee obligations | $ | 794 |  |  | $ | 425 |  |  | $ | 1,219 |  |
  (was, 2025-05-12, similarity 0.912):
[0002023554-25-000027:note_history:12]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| Remaining three months of 2025 | $ | 104 |  |  | $ | 26 |  |  | $ | 130 |  |
| 2026 | 462 |  |  | 119 |  |  | 581 |  |
| 2027 | 227 |  |  | 102 |  |  | 329 |  |
| 2028 | 102 |  |  | 98 |  |  | 200 |  |
| 2029 | 36 |  |  | 53 |  |  | 89 |  |
| 2030 | 9 |  |  | 41 |  |  | 50 |  |
| Total guarantee obligations | $ | 940 |  |  | $ | 439 |  |  | $ | 1,379 |  |

- changed (2025-11-07):
[0001628280-25-050698:note_history:13]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of October 3, 2025, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.
  (was, 2025-05-12, similarity 0.9471):
[0002023554-25-000027:note_history:13]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of March 28, 2025, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

- changed (2025-11-07):
[0001628280-25-050698:note_history:14]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”) an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly-listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.
  (was, 2025-05-12, similarity 0.9987):
[0002023554-25-000027:note_history:14]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”) an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

- added (2025-11-07):
[0001628280-25-050698:note_history:15]
The Transaction closed on September 28, 2024, and SanDisk China completed the sale of 80% of its equity interest in SDSS to JCET. The Transaction resulted in a pre-tax gain of $34 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $382 million of goodwill that was allocated to SDSS.

- added (2025-11-07):
[0001628280-25-050698:note_history:16]
Proceeds from the sale, including working capital adjustments, were $659 million (pre-tax). On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million. The remaining $187 million pre-tax proceeds are payable in five equal installments of approximately $37 million on September 28 of each year through September 28, 2029.

- added (2025-11-07):
[0001628280-25-050698:note_history:17]
On September 25, 2025, SanDisk China and JCET entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support, resulting in a reduction of the September 28, 2025 installment payment from JCET to $27 million. The Company recognized the adjustment as a Loss on business divestiture for the three months ended October 3, 2025.

- changed (2025-11-07):
[0001628280-25-050698:note_history:18]
As of October 3, 2025, the outstanding consideration receivable was recognized at its present value of $133 million, with $36 million classified as Other current assets and $97 million classified as Other non-current assets in the Condensed Consolidated Balance Sheets. The remaining present value discount of $17 million as of October 3, 2025 will be recognized using the effective interest method over the next four years as Interest income in the Condensed Consolidated Statements of Operations.
  (was, 2025-05-12, similarity 0.6238):
[0002023554-25-000027:note_history:18]
Proceeds from the sale, including working capital adjustments, were $659 million (pre-tax). On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million and expects to receive the remaining $187 million pre-tax proceeds in five equal installments of approximately $37 million on September 28 of each year through September 28, 2029. As of March 28, 2025, the outstanding consideration receivable was recognized at its present value of $166 million, with $36 million classified as Other current assets and $130 million classified as Other non-current assets in the Condensed Consolidated Balance Sheets. The remaining present value discount of $21 million as of March 28, 2025 will be recognized using the effective interest method over the next five years as Interest income in the Condensed Consolidated Statements of Operations.

- changed (2025-11-07):
[0001628280-25-050698:note_history:19]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other expense, net in the Condensed Consolidated Statements of Operations. As of October 3, 2025, the 20% retained interest in SDSS was valued at $162 million.
  (was, 2025-05-12, similarity 0.9906):
[0002023554-25-000027:note_history:19]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other expense, net in the Condensed Consolidated Statements of Operations. As of March 28, 2025, the 20% retained interest in SDSS was valued at $160 million.

- added (2025-11-07):
[0001628280-25-050698:note_history:20]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT,” a WDC affiliate) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if it fails to meet its minimum annual commitment. The Supply Agreement also provides that if the Company’s purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the three months ended October 3, 2025, the Company made purchases of $139 million under the Supply Agreement and had a $147 million accounts payable balance due to SDSS as of October 3, 2025.

- changed (2025-11-07):
[0001628280-25-050698:note_history:21]
Prior to the execution of the Equity Transfer Agreement, the Unis Venture was not historically managed as a component of the Company and as such, the related equity method investment was not reflected within the Company’s Condensed Consolidated Financial Statements. After the execution of the Equity Transfer Agreement, the Company accounts for its investment in the Unis Venture under the equity method of accounting. The Company’s 48% interest in the earnings of the Unis Venture will be recognized one quarter in arrears from the date the Unis Venture was transferred to the Company and will be reported in Other expense, net in the Condensed Consolidated Statements of Operations.
  (was, 2025-05-12, similarity 0.9882):
[0002023554-25-000027:note_history:21]
Prior to the execution of the Equity Transfer Agreement, the Unis Venture was not historically managed as a component of the Company and as such, the related equity method investment was not reflected within our Condensed Consolidated Financial Statements. After the execution of the Equity Transfer Agreement, the Company accounts for its investment in the Unis Venture under the equity method of accounting. The Company’s 49% interest in the earnings of the Unis Venture will be recognized one quarter in arrears from the date the Unis Venture was transferred to the Company and will be reported in Other expense, net in the Condensed Consolidated Statements of Operations.

- changed (2025-11-07):
[0001628280-25-050698:note_history:22]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the three months ended October 3, 2025, and September 27, 2024, the Company recognized approximately 1% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 2% and 1% of Accounts receivable, net, as of October 3, 2025 and June 27, 2025, respectively.
  (was, 2025-05-12, similarity 0.902):
[0002023554-25-000027:note_history:22]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the three and nine months ended March 28, 2025, and March 29, 2024, the Company recognized approximately 1% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 2% and 4% of Accounts receivable, net, as of March 28, 2025 and June 28, 2024, respectively.

- changed (2025-11-07):
[0001628280-25-050698:note_history:23]
As described in Note 1, Organization and Basis of Presentation, on February 21, 2025, in connection with the separation, the Company entered into several agreements that provide a framework for Sandisk’s relationship with WDC after the separation. These include, but are not limited to, the following:
  (was, 2025-05-12, similarity 0.7646):
[0002023554-25-000027:note_history:23]
As described in Note 1, Organization and Basis of Presentation of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, on February 21, 2025, in connection with the separation, the Company entered into several agreements that provide a framework for Sandisk’s relationship with WDC after the separation. These include, but are not limited to, the following, which were active and in effect during the third quarter of fiscal year 2025:

- changed (2025-11-07):
[0001628280-25-050698:note_history:24]
•Separation and Distribution Agreement - The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Condensed Combined Balance Sheets were retained by WDC and certain assets and liabilities not included in the Company’s Condensed Combined Balance Sheets were transferred to the Company as of the date of the separation.
  (was, 2025-05-12, similarity 0.9656):
[0002023554-25-000027:note_history:24]
•Separation and Distribution Agreement - The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Condensed Combined Balance Sheets as of December 27, 2024 were retained by WDC and certain assets and liabilities not included in the Company’s Condensed Combined Balance Sheets as of December 27, 2024 were transferred to the Company as of the date of the separation.

- added (2025-11-07):
[0001628280-25-050698:note_history:25]
As of quarter end October 3, 2025, the separation between the Company and WDC has been finalized, and no separation-related adjustments have been, or are expected to be, incurred going forward.

- added (2025-11-07):
[0001628280-25-050698:note_history:26]
•Employee Matters Agreement - The Employee Matters Agreement allocates liabilities and responsibilities relating to employment matters, employee compensation and benefit plans and programs and other related matters. Pursuant to this agreement, during the three months ended October 3, 2025, the Company received reimbursement of short-term employee incentives totaling $22 million from WDC.

- changed (2025-11-07):
[0001628280-25-050698:note_history:27]
•Transition Services Agreement - The Transition Services Agreement governs the provision of transition services from WDC to Sandisk, and from Sandisk to WDC and its affiliates, on an interim, transitional basis following the separation.
  (was, 2025-05-12, similarity 0.9792):
[0002023554-25-000027:note_history:27]
•Transition Services Agreement – The Transition Services Agreement (“TSA”) governs the provision of transition services from WDC to Sandisk, and from Sandisk to WDC and its affiliates, on an interim, transitional basis following the separation.

- changed (2025-11-07):
[0001628280-25-050698:note_history:28]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently increased to reflect changes in indemnification obligations under the Tax Matters Agreement, which is recorded in Other expense, net in the Condensed Consolidated Statements of Operations. The remaining tax indemnification liability of $125 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of October 3, 2025.
  (was, 2025-05-12, similarity 0.6393):
[0002023554-25-000027:note_history:28]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently reduced by approximately $2 million reflecting the outstanding balance as of March 28, 2025. The remaining tax indemnification liability of $110 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of March 28, 2025.

- added (2025-11-07):
[0001628280-25-050698:note_history:29]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  |  |  |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 2 |  |  |  |  |  |

- changed (2025-11-07):
[0001628280-25-050698:note_history:30]
Prior to the separation, WDC provided various corporate services to the Company in the ordinary course of business, including executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue or other relevant measures. Management believes the basis on which the expenses were allocated to be a reasonable reflection of the utilization of services provided to the Company or the benefit received by the Company.
  (was, 2025-05-12, similarity 0.9417):
[0002023554-25-000027:note_history:30]
Prior to the separation, WDC provided various corporate services to the Company in the ordinary course of business, including executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue or other relevant measures. Management believes the basis on which the expenses were allocated to be a reasonable reflection of the utilization of services provided to us or the benefit received by us.

- changed (2025-11-07):
[0001628280-25-050698:note_history:31]
Effective at the beginning of the second quarter of fiscal year 2025, the Company was operationally separated from the operations that were ultimately retained by WDC following completion of the spin-off. In connection with this operational separation, personnel serving the Company in shared service functions were transferred into legal entities dedicated to the Company, and substantially all assets, liabilities, and contracts pertaining to operations of the Company were transferred to legal entities dedicated to the Company as well. Accordingly, there was a substantial reduction in the pool of shared corporate overhead costs of WDC that were subject to allocation in the second and third quarters of fiscal year 2025 and those allocations ceased post-separation.
  (was, 2025-05-12, similarity 0.9612):
[0002023554-25-000027:note_history:31]
Effective at the beginning of the second quarter of fiscal year 2025, the Company was operationally separated from the operations that were ultimately retained by WDC following completion of the spin-off transaction. In connection with this operational separation, personnel serving the Company in shared service functions were transferred into legal entities dedicated to the Company, and substantially all assets, liabilities, and contracts pertaining to operations of the Company were transferred to legal entities dedicated to the Company as well. Accordingly, there was a substantial reduction in the pool of shared corporate overhead costs of WDC that were subject to allocation in the second and third quarters of fiscal year 2025.

- added (2025-11-07):
[0001628280-25-050698:note_history:32]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 187 |  |  |  |  |  |
| Selling general, and administrative | — |  |  | 113 |  |  |  |  |  |
| Business separation costs | — |  |  | 2 |  |  |  |  |  |
| Employee termination and other charges | — |  |  | 20 |  |  |  |  |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 322 |  |  |  |  |  |

- added (2025-11-07):
[0001628280-25-050698:note_history:33]
The Company’s historical financial statements do not purport to reflect what results of operations, financial position, equity or cash flows would have been if the Company had operated as a standalone company during the periods presented.

- added (2025-11-07):
[0001628280-25-050698:note_history:34]
Prior to the separation, WDC provided funding for the Company’s operating and investing activities, including pooled cash managed by WDC’s treasury, to fund operating expenses and capital expenditures. WDC also directly collected certain of the Company’s receivables. These activities were reflected as a component of the Net investment from Western Digital Corporation, and this arrangement is not reflective of the manner in which the Company would operate on a standalone company separate from WDC during the periods presented.

- added (2025-11-07):
[0001628280-25-050698:note_history:35]
|  | Three Months Ended |
|  | October 3,2025 |  | September 27,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | 583 |  |
| Notes due to Western Digital Corporation | — |  |  | (378) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (6) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (3) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | (7) |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | 189 |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:36]
During the three and nine months ended March 28, 2025, and March 29, 2024, the Company made net payments to Flash Ventures of $0.9 billion and $2.9 billion and $0.7 billion and $2.5 billion, respectively, for purchases of flash-based memory wafers and net loans.

- removed (2025-11-07):
[0002023554-25-000027:note_history:37]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at March 28, 2025, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to revaluation from the Japanese yen to the U.S. dollar.

- removed (2025-11-07):
[0002023554-25-000027:note_history:38]
|  | March 28,2025 |
|  | (in millions) |
| Notes receivable | $ | 371 |  |
| Equity investments | 291 |  |
| Operating lease guarantees | 1,379 |  |
| Inventory and prepayments | 1,318 |  |
| Maximum estimable loss exposure | $ | 3,359 |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:39]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of March 28, 2025, $938 million, with $127 million recorded within Other current assets and $811 million recorded within Other non-current assets in the Condensed Consolidated Balance Sheets, remain to be credited against future building depreciation charges. As of March 28, 2025, the Company is also committed to making additional building depreciation prepayments of $292 million, based on the Japanese yen to U.S. dollars exchange rate of ¥150.43 as of such date, payable as follows: $39 million for the remaining of fiscal year 2025, $31 million in fiscal year 2026, $116 million in fiscal year 2027, $93 million in fiscal year 2028 and $13 million in fiscal year 2029. As of March 28, 2025, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $263 million at varying dates through fiscal year 2035.

- removed (2025-11-07):
[0002023554-25-000027:note_history:40]
The Transaction closed on September 28, 2024, and SanDisk China completed the sale of 80% of its equity interest in SDSS to JCET.

- removed (2025-11-07):
[0002023554-25-000027:note_history:41]
The Transaction resulted in a pre-tax gain of $34 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $382 million of goodwill that was allocated to SDSS.

- removed (2025-11-07):
[0002023554-25-000027:note_history:42]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT”) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which, WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if SDSS fails to meet its minimum annual commitment. The Supply Agreement also provides that if SDSS purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the three and nine months ended March 28, 2025, the Company made purchases of $108 million and $219 million, respectively, under the Supply Agreement and had a $112 million accounts payable balance due to SDSS as of March 28, 2025.

- removed (2025-11-07):
[0002023554-25-000027:note_history:43]
Separation-related adjustments resulted in a decrease to net assets and total equity of $1.1 billion and are reflected in the “Net transfers from (to) WDC, including spin-off related adjustments” line item of the Condensed Consolidated Statements of Shareholders’ Equity.

- removed (2025-11-07):
[0002023554-25-000027:note_history:44]
For the three months ended March 28, 2025, the Company recognized $2 million in expenses related to the TSA, and the Company expects to recognize an additional expense related to the TSA of approximately $10 million during the next twelve months.

- removed (2025-11-07):
[0002023554-25-000027:note_history:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Interest expense on notes due to Western Digital Corporation | $ | 3 |  |  | $ | 9 |  |  | $ | 7 |  |  | $ | 29 |  |
| Interest (income) on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |  | $ | (4) |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 190 |  |  | $ | 189 |  |  | $ | 520 |  |
| Selling general, and administrative | 10 |  |  | 109 |  |  | 158 |  |  | 328 |  |
| Business separation costs | 9 |  |  | — |  |  | 50 |  |  | — |  |
| Employee termination and other charges | — |  |  | 2 |  |  | 5 |  |  | (44) |  |
| Total allocation of Corporate Expenses | $ | 19 |  |  | $ | 301 |  |  | $ | 402 |  |  | $ | 804 |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:47]
Our historical financial statements do not purport to reflect what results of operations, financial position, equity or cash flows would have been if we had operated as a standalone company during the periods presented.

- removed (2025-11-07):
[0002023554-25-000027:note_history:48]
Prior to the separation, WDC provided funding for our operating and investing activities, including pooled cash managed by WDC’s treasury, to fund operating expenses and capital expenditures. WDC also directly collected certain of our receivables. These activities were reflected as a component of the Net investment from Western Digital Corporation, and this arrangement is not reflective of the manner in which we would operate on a standalone company separate from WDC during the periods presented.

- removed (2025-11-07):
[0002023554-25-000027:note_history:49]
|  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | (585) |  |  | $ | 234 |  |
| Notes due (to) from Western Digital Corporation | (1,223) |  |  | 113 |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | (105) |  |  | — |  |
| Unis venture transferred from Western Digital Corporation | (61) |  |  | — |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | (27) |  |  | (5) |  |
| Tax balances transferred from Western Digital Corporation | (8) |  |  | (2) |  |
| Accumulated other comprehensive loss transferred to Western Digital Corporation | 10 |  |  | — |  |
| Tax indemnification liability transferred to Western Digital Corporation | 112 |  |  | — |  |
| Net transfers (to) from Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | (1,887) |  |  | $ | 340 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-11-07):
[0001628280-25-050698:note_history:50]
Sandisk Corporation (“Sandisk” or the “Company”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, Sandisk’s broad and ever-expanding portfolio delivers powerful flash storage solutions for AI workloads in datacenters, edge devices, and consumer applications. Sandisk’s technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. The Company’s solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. The Company’s broad portfolio of technology and products addresses multiple end markets of “Datacenter” (formerly referred to as “Cloud”), “Edge” (formerly referred to as “Client”), and “Consumer.” The Company operates primarily in the United States (“U.S.”) and also internationally, with a significant concentration in the Asia Pacific region.

- changed (2025-11-07):
[0001628280-25-050698:note_history:51]
On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized WDC management to pursue a plan to separate the Company into an independent public company (the “separation” or the “spin-off”). The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly owned by WDC.
  (was, 2025-05-12, similarity 0.8471):
[0002023554-25-000027:note_history:51]
On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized WDC management to pursue a plan to separate the Company into an independent public company (the “separation” or the “spin-off”). The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly owned by WDC. On February 24, 2025, following the separation, the Company began trading as an independent, publicly traded company under the stock symbol “SNDK” on Nasdaq.

- added (2025-11-07):
[0001628280-25-050698:note_history:52]
On February 21, 2025, WDC executed the spin-off of the Company through WDC’s pro rata distribution of 116,035,464, or 80.1%, of the Company’s outstanding shares of common stock to holders of WDC’s common stock. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 28,827,787, or 19.9%, of the outstanding shares of the Company’s common stock. Following the distribution, the Company became an independent publicly listed company, and on February 24, 2025, the Company began trading as an independent, publicly traded company under the stock symbol “SNDK” on Nasdaq.

- changed (2025-11-07):
[0001628280-25-050698:note_history:53]
In connection with the separation, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the spin-off and provided a framework for the relationship between WDC and the Company following the separation. These agreements include the Separation and Distribution Agreement, which contains certain key provisions related to the spin-off, as well as a Transition Services Agreement (“TSA”), a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025 and incorporated by reference to this Quarterly Report on Form 10-Q. Additionally, the Company adopted certain compensation plans filed as Exhibits to the Company’s Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025. The Company also entered into various sublease agreements and established a stock compensation incentive plan in connection with the separation.
  (was, 2025-05-12, similarity 0.9857):
[0002023554-25-000027:note_history:53]
In connection with the separation, on February 21, 2025, the Company entered into definitive agreements with WDC that set forth the terms and conditions of the spin-off and provided a framework for the relationship between WDC and the Company following the separation. These agreements include the Separation and Distribution Agreement, which contains certain key provisions related to the spin-off, as well as a Transition Services Agreement, a Tax Matters Agreement, an Employee Matters Agreement, an Intellectual Property Cross-License Agreement, a Transitional Trademark License Agreement, and a Stockholder and Registration Rights Agreement, as described in and filed as Exhibits to the Company’s Current Report on Form 8-K on February 24, 2025 and incorporated by reference to this Quarterly Report on Form 10-Q. Additionally, the Company adopted certain compensation plans filed as Exhibits to the Company’s Registration Statement on Form 10, initially filed with the U.S. Securities and Exchange Commission (“SEC”) on November 25, 2024, and as further amended thereafter and declared effective on January 31, 2025 (as amended, the “Form 10”). The Company also entered into various sublease agreements and established a stock compensation incentive plan in connection with the separation.

- changed (2025-11-07):
[0001628280-25-050698:note_history:54]
Also on February 21, 2025, in connection with the separation, the Company entered into a $1.5 billion revolving credit facility, which was undrawn at the separation date, and a $2.0 billion term loan facility due in 2032. The Company used a portion of the proceeds received from the term loan facility and cash on hand to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities, and certain legal entities of WDC associated with the Company.
  (was, 2025-05-12, similarity 0.9945):
[0002023554-25-000027:note_history:54]
On February 21, 2025, in connection with the separation, the Company entered into a $1.5 billion revolving credit facility, which was undrawn at the separation date, and a $2.0 billion term loan facility due in 2032. The Company used a portion of the proceeds received from the term loan facility and cash on hand to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities, and certain legal entities of WDC associated with the Company.

- added (2025-11-07):
[0001628280-25-050698:note_history:55]
On June 9, 2025, WDC disposed of 21,314,768, or 14.6%, of the Company’s common stock through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. All expenses for the offering were paid for by us. As of October 3, 2025, WDC continued to retain 7,513,019, or 5.1%, of the outstanding shares of the Company’s common stock.

- added (2025-11-07):
[0001628280-25-050698:note_history:56]
On February 21, 2025, the Company became a standalone publicly traded company, and the Company’s financial statements are now presented on a consolidated basis. Prior to the separation, the Company’s historical consolidated financial information was derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the policies and practices that are generally accepted in the industry in which it operates.

- added (2025-11-07):
[0001628280-25-050698:note_history:57]
Basis of Consolidation

- added (2025-11-07):
[0001628280-25-050698:note_history:58]
The Condensed Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in the preparation of the Condensed Consolidated Financial Statements. The accounts of these foreign subsidiaries have been remeasured using the U.S. dollar as the functional currency. Gains or losses resulting from the remeasurement of these accounts from local currencies into U.S. dollars were immaterial to the Condensed Consolidated Financial Statements. Financial statements of the Company’s foreign subsidiaries for which the functional currency is the local currency are translated into U.S. dollars using the exchange rate at each balance sheet date for assets and liabilities and a weighted average exchange rate for each period for statement of operations items. Translation adjustments are recorded in Accumulated other comprehensive loss, a component of shareholders’ equity.

- changed (2025-11-07):
[0001628280-25-050698:note_history:59]
Unless otherwise noted, all figures within the Condensed Consolidated Financial Statements are stated in U.S. dollars.
  (was, 2025-05-12, similarity 0.9255):
[0002023554-25-000027:note_history:59]
Unless otherwise noted, all figures within the Condensed Consolidated Financial Statements are stated in U.S. Dollars (USD) and millions.

- changed (2025-11-07):
[0001628280-25-050698:note_history:60]
Prior to the separation on February 21, 2025, the Company was an operating segment of WDC. Consequently, standalone interim financial statements were not historically prepared for the Company. The accompanying Condensed Consolidated Financial Statements were prepared based upon WDC’s historical consolidated interim financial statements and accounting records. They were presented on a standalone basis as if the Company’s operations had been conducted independently from WDC. The Company utilized allocations and carve-out methodologies to prepare these historic Condensed Consolidated Financial Statements. The Condensed Consolidated Financial Statements included the historical results of operations, financial position, and cash flows of the Company and were prepared in accordance with GAAP, and the Company has adopted accounting policies and practices generally accepted in the industry in which it operates.
  (was, 2025-05-12, similarity 0.9164):
[0002023554-25-000027:note_history:60]
Prior to the separation on February 21, 2025, the Company was an operating segment of WDC. Consequently, standalone interim financial statements were not historically prepared for the Company. The accompanying Condensed Consolidated Financial Statements were prepared based upon WDC’s historical consolidated interim financial statements and accounting records. They were presented on a standalone basis as if the Company’s operations had been conducted independently from WDC. The Company utilized allocations and carve-out methodologies to prepare these historic Condensed Consolidated Financial Statements. The Condensed Consolidated Financial Statements included the historical results of operations, financial position, and cash flows of the Company and were prepared in accordance with GAAP, and the Company has adopted accounting policies and practices generally accepted in the industry in which it operates. As no single legal entity of the Company had a controlling financial interest in any other legal entities, Condensed Consolidated Financial Statements were prepared.

- added (2025-11-07):
[0001628280-25-050698:note_history:61]
Intercompany transactions were eliminated, with the exception of balances associated with lending arrangements reflected within Notes due to (from) Western Digital Corporation in the Condensed Consolidated Balance Sheets, transactions between the Company and WDC were generally considered to be effectively settled in the Condensed Consolidated Financial Statements at the time the transactions were recorded. The total net effect of the settlement of these transactions was reflected in the Condensed Consolidated Statements of Cash Flows as a financing activity and in the Condensed Consolidated Balance Sheets as Net investment from Western Digital Corporation. General financing activities included the net impact of any cash movements resulting from WDC’s centralized treasury cash management.

- changed (2025-11-07):
[0001628280-25-050698:note_history:62]
The Condensed Consolidated Statements of Operations and Comprehensive Income included all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions, and services provided by WDC. Allocation of general corporate expenses from WDC included, but was not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs were deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Condensed Consolidated Statements of Operations. The Condensed Consolidated Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on the Company’s behalf. The Company considers these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expense the Company would have incurred as a standalone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a standalone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.
  (was, 2025-05-12, similarity 0.9862):
[0002023554-25-000027:note_history:62]
The Condensed Consolidated Statements of Operations and Comprehensive Income (Loss) included all revenues and costs directly attributable to the Company as well as an allocation of expenses related to facilities, functions, and services provided by WDC. Allocation of general corporate expenses from WDC included, but was not limited to, executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement, and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue, or other relevant measures. The allocated costs were deemed to be settled between the Company and WDC in the period in which the expense was recorded in the Condensed Consolidated Statements of Operations. The Condensed Consolidated Statements of Cash Flows present these corporate expenses as cash flows from operating activities, as these costs were incurred by WDC on our behalf. We consider these allocations to be a reasonable reflection of the utilization of services by, or the benefits provided to, the Company. The allocations may not, however, reflect the expense the Company would have incurred as a standalone company for the periods presented. Additionally, these costs may not be indicative of the expenses that the Company will incur in the future or would have incurred if the Company had obtained these services from an unrelated third party. It is not practicable to estimate the actual costs that would have been incurred had the Company been a standalone company during the periods presented. The actual costs that may have been incurred would depend on a number of factors, including the chosen organizational structure, whether functions were outsourced or performed by employees, and decisions with respect to areas such as facilities, information technology, and operating infrastructure.

- added (2025-11-07):
[0001628280-25-050698:note_history:63]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025, through October 3, 2025 are Condensed Consolidated Financial Statements based on the Company’s reported results as a standalone company. All transactions and accounts between controlled entities within the Company have been eliminated.

- changed (2025-11-07):
[0001628280-25-050698:note_history:64]
Following the separation, certain functions continue to be provided by or for WDC for up to fifteen months under the TSA or are being performed using the Company’s own resources or third-party service providers. As of October 3, 2025, charges under the TSA were not material.
  (was, 2025-05-12, similarity 0.9126):
[0002023554-25-000027:note_history:64]
Following the separation, certain functions continue to be provided by or for WDC for up to fifteen months under the Transition Services Agreement (“TSA”) or are being performed using the Company’s own resources or third-party service providers. As of March 28, 2025, charges under the TSA were not material.

- added (2025-11-07):
[0001628280-25-050698:note_history:65]
The Company has prepared the accompanying Condensed Consolidated Financial Statements pursuant to the rules and regulations of the SEC for interim financial reporting. These Condensed Consolidated Financial Statements are unaudited and, in management’s opinion, include all adjustments, consisting of normal recurring adjustments and accruals necessary for a fair presentation of the Company’s operations, financial position, and cash flows for the periods presented. Operating results for the periods presented are not necessarily indicative of the results that may be expected for the full fiscal year due to seasonal and other factors. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been omitted in accordance with the rules and regulations of the SEC. These Condensed Consolidated Financial Statements should be read in conjunction with the Company’s audited Consolidated Financial Statements and accompanying notes for the year ended June 27, 2025, included in the Company’s Annual Report on Form 10-K.

- added (2025-11-07):
[0001628280-25-050698:note_history:66]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which ended on June 27, 2025, was comprised of 52 weeks, with all quarters consisting of 13 weeks. Fiscal year 2026 will be comprised of 53 weeks and will end on July 3, 2026, with the first fiscal quarter consisting of 14 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a condensed consolidated basis.

- added (2025-11-07):
[0001628280-25-050698:note_history:67]
The Company develops, manufactures, markets, and sells data storage devices and solutions based on NAND flash technology in the U.S. and in foreign countries through its sales personnel, dealers, distributors, retailers, and subsidiaries. The Company manages and reports its business operations under a single reportable operating segment. Operating segments are components of an enterprise for which separate financial information is available and are evaluated regularly by the Company’s Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources and in assessing performance.

- added (2025-11-07):
[0001628280-25-050698:note_history:68]
The Chief Executive Officer, who is the CODM, evaluates the performance of the Company and makes resource allocation decisions for its single reportable operating segment based upon the Company’s condensed consolidated net income. The CODM considers variances of actual performance to forecasted amounts when making decisions. Asset information is not used by the CODM to evaluate performance or allocate resources.

- removed (2025-11-07):
[0002023554-25-000027:note_history:69]
Sandisk Corporation (“Company,” “we,” “us,” or “our”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for everyone from students, gamers, and home offices to the largest enterprises and public clouds to capture, preserve, access, and transform an ever-increasing diversity of data. The Company operates primarily in the United States (“U.S.”), and also internationally, with a significant concentration in the Asia Pacific region.

- removed (2025-11-07):
[0002023554-25-000027:note_history:70]
WDC executed the spin-off of the Company through WDC’s pro rata distribution of 80.1% of the Company’s outstanding shares of common stock to holders of WDC’s common stock as of the close of business on February 21, 2025. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 19.9% of the shares of the Company’s common stock, which WDC is expected to retain for a period of up to twelve months following the distribution.

- removed (2025-11-07):
[0002023554-25-000027:note_history:71]
The completion of the separation was subject to certain conditions as described in our Form 10.

- removed (2025-11-07):
[0002023554-25-000027:note_history:72]
The accounting policies followed by the Company are set forth in Note 1, Organization and Basis of Presentation of the Notes to the Combined Financial Statements for the year ended June 28, 2024, included in Exhibit 99.1 to our Form 10.

- removed (2025-11-07):
[0002023554-25-000027:note_history:73]
On February 21, 2025, the Company became a standalone publicly traded company, and our financial statements are now presented on a consolidated basis. Prior to the separation, the Company’s historical combined financial information was derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Condensed Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”).

- removed (2025-11-07):
[0002023554-25-000027:note_history:74]
All intercompany accounts and transactions within the Company have been eliminated in the preparation of the Condensed Consolidated Financial Statements.

- removed (2025-11-07):
[0002023554-25-000027:note_history:75]
Intercompany transactions were eliminated. With the exception of balances associated with lending arrangements reflected within Notes due to (from) Western Digital Corporation in the Condensed Consolidated Balance Sheets, transactions between the Company and WDC were generally considered to be effectively settled in the Condensed Consolidated Financial Statements at the time the transactions were recorded. The total net effect of the settlement of these transactions was reflected in the Condensed Consolidated Statements of Cash Flows as a financing activity and in the Condensed Consolidated Balance Sheets as Net investment from Western Digital Corporation. General financing activities included the net impact of any cash movements resulting from WDC’s centralized treasury cash management.

- removed (2025-11-07):
[0002023554-25-000027:note_history:76]
The Condensed Consolidated Balance Sheets included all assets and liabilities that were identifiable or otherwise attributable to the Company. Assets and liabilities shared between the Company and WDC were included in the standalone financial statements to the extent that the asset was primarily used by the Company. If the Company was not the primary user of the asset, it was excluded entirely from the Condensed Consolidated Financial Statements. WDC historically used a centralized approach to cash management and financing of its operations, as needed. Certain of our cash was transferred to WDC according to centrally managed cash programs by treasury, and WDC funded our operating and investing activities, as needed. Cash transfers to and from WDC’s cash management accounts were reflected as a component of the Net investment from Western Digital Corporation in the Condensed Consolidated Balance Sheets. Cash and cash equivalents in our Condensed Consolidated Balance Sheets primarily represented cash held locally by entities included in our Condensed Consolidated Financial Statements.

- removed (2025-11-07):
[0002023554-25-000027:note_history:77]
None of the debt obligations of WDC or corresponding interest expense were included in the Condensed Consolidated Financial Statements, as the Company was neither the legal obligor nor transferee for any portion of such debt. WDC’s debt obligations were secured by a lien on substantially all assets and properties of WDC and certain key subsidiaries, which included assets and properties of the Company prior to the completion of the separation.

- removed (2025-11-07):
[0002023554-25-000027:note_history:78]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025, through March 28, 2025 are consolidated financial statements based on the Company’s reported results as a standalone company. All significant transactions and accounts within the Company were eliminated. Intercompany transactions between the Company and WDC prior to the separation were included within Net investment from Western Digital Corporation on the accompanying Consolidated Financial Statements or were paid in cash.

- removed (2025-11-07):
[0002023554-25-000027:note_history:79]
The Company incurred certain costs in its establishment as a standalone public company and expects to incur ongoing additional costs associated with operating as an independent, publicly traded company. Costs incurred for the three and nine months ended March 28, 2025, are included in Business separation costs within our Condensed Consolidated Statements of Operations.

- removed (2025-11-07):
[0002023554-25-000027:note_history:80]
The Company has prepared the accompanying Condensed Consolidated Financial Statements pursuant to the rules and regulations of the SEC for interim financial reporting. These Condensed Consolidated Financial Statements are unaudited and, in our opinion, include all adjustments, consisting of normal recurring adjustments and accruals necessary for a fair presentation of our operations, financial position, and cash flows for the periods presented. Operating results for the periods presented are not necessarily indicative of the results that may be expected for the full fiscal year due to seasonal and other factors. Certain information and footnote disclosures normally included in financial statements prepared in accordance with GAAP have been omitted in accordance with the rules and regulations of the SEC. These Condensed Consolidated Financial Statements should be read in conjunction with the Company’s audited Combined Financial Statements and accompanying notes for the year ended June 28, 2024, included in our Form 10.

- removed (2025-11-07):
[0002023554-25-000027:note_history:81]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which will end on June 27, 2025, and fiscal year 2024, which ended on June 28, 2024, are each comprised of 52 weeks, with all quarters presented consisting of 13 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a condensed, consolidated basis.

- removed (2025-11-07):
[0002023554-25-000027:note_history:82]
Operating segments are components of an enterprise for which separate financial information is available and are evaluated regularly by the Company’s Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources and in assessing performance. The Company currently operates as both a single operating and reportable segment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-07):
[0001628280-25-050698:note_history:83]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 1,400 |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | $ | — |  |
| Total debt | 1,400 |  |  | $ | 1,900 |  |
| Unamortized issuance costs | 49 |  |  | $ | 51 |  |
| Subtotal | 1,351 |  |  | $ | 1,849 |  |
| Less: Current portion of long-term debt | 20 |  |  | $ | 20 |  |
| Long term debt | $ | 1,331 |  |  | $ | 1,829 |  |

- changed (2025-11-07):
[0001628280-25-050698:note_history:84]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement).
  (was, 2025-05-12, similarity 0.9596):
[0002023554-25-000027:note_history:84]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that requires the Company to maintain a maximum Leverage Ratio (as defined in the Loan Agreement).

- added (2025-11-07):
[0001628280-25-050698:note_history:85]
The outstanding principal balance of the Term Loan Facility is required to be repaid in quarterly installments that began on June 27, 2025, in an aggregate amount equal to 0.25% of the aggregate principal amount of the Term Loan Facility. A final payment comprised of all principal and interest is due and payable at maturity on February 20, 2032.

- added (2025-11-07):
[0001628280-25-050698:note_history:86]
For the three months ended October 3, 2025, interest expense was $37 million and amortization of issuance costs was $2 million.

- changed (2025-11-07):
[0001628280-25-050698:note_history:87]
In connection with the issuance of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which are amortized to Interest expense over the life of the facility.
  (was, 2025-05-12, similarity 0.9827):
[0002023554-25-000027:note_history:87]
In connection with the issuance of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which will be amortized to Interest expense over the life of the facility.

- changed (2025-11-07):
[0001628280-25-050698:note_history:88]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement). As of October 3, 2025, the Company was in compliance with the financial covenant.
  (was, 2025-05-12, similarity 0.8889):
[0002023554-25-000027:note_history:88]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that requires the Company to maintain a maximum Leverage Ratio (as defined in the Loan Agreement). As of March 28, 2025, the Company was in compliance with the financial covenant.

- changed (2025-11-07):
[0001628280-25-050698:note_history:89]
As of October 3, 2025, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.
  (was, 2025-05-12, similarity 0.9673):
[0002023554-25-000027:note_history:89]
As of March 28, 2025, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.

- removed (2025-11-07):
[0002023554-25-000027:note_history:90]
|  | March 28,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 2,000 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |
| Total Debt | 2,000 |  |
| Unamortized Issuance Costs | 53 |  |
| Subtotal | 1,947 |  |
| Less: current portion of long-term debt | 20 |  |
| Long term debt | $ | 1,927 |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:91]
The outstanding principal balance of the Term Loan Facility is required to be repaid in quarterly installments beginning on June 27, 2025, in an aggregate amount equal to 0.25% of the aggregate principal amount of the Term Loan Facility and a final payment comprised of all principal and interest due and payable at maturity on February 20, 2032.

- removed (2025-11-07):
[0002023554-25-000027:note_history:92]
In connection with the issuance of the Term Loan Facility, the Company recognized issuance costs of $54 million, which will be amortized to Interest expense over the life of the facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-07):
[0001628280-25-050698:note_history:93]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 1,400 |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | $ | — |  |
| Total debt | 1,400 |  |  | $ | 1,900 |  |
| Unamortized issuance costs | 49 |  |  | $ | 51 |  |
| Subtotal | 1,351 |  |  | $ | 1,849 |  |
| Less: Current portion of long-term debt | 20 |  |  | $ | 20 |  |
| Long term debt | $ | 1,331 |  |  | $ | 1,829 |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:94]
|  | March 28,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | 2,000 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |
| Total Debt | 2,000 |  |
| Unamortized Issuance Costs | 53 |  |
| Subtotal | 1,947 |  |
| Less: current portion of long-term debt | 20 |  |
| Long term debt | $ | 1,927 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001628280-25-050698:note_history:95]
|  | October 3,2025 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 6 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 39 |  |  | 36 |  |
| Notes receivable, Flash Forward | 296 |  |  | 316 |  |
| Investment in Flash Partners | 39 |  |  | 55 |  |
| Investment in Flash Alliance | 112 |  |  | 115 |  |
| Investment in Flash Forward | 110 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 602 |  |  | $ | 654 |  |
  (was, 2025-05-12, similarity 0.986):
[0002023554-25-000027:note_history:95]
|  | March 28,2025 |  | June 28,2024 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 37 |  |  | $ | 1 |  |
| Notes receivable, Flash Alliance | 38 |  |  | 5 |  |
| Notes receivable, Flash Forward | 296 |  |  | 485 |  |
| Investment in Flash Partners | 46 |  |  | 148 |  |
| Investment in Flash Alliance | 116 |  |  | 219 |  |
| Investment in Flash Forward | 129 |  |  | 143 |  |
| Total notes receivable and investments in Flash Ventures | $ | 662 |  |  | $ | 1,001 |  |

- added (2025-11-07):
[0001628280-25-050698:note_history:96]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  |  |  |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 2 |  |  |  |  |  |

- added (2025-11-07):
[0001628280-25-050698:note_history:97]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 187 |  |  |  |  |  |
| Selling general, and administrative | — |  |  | 113 |  |  |  |  |  |
| Business separation costs | — |  |  | 2 |  |  |  |  |  |
| Employee termination and other charges | — |  |  | 20 |  |  |  |  |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 322 |  |  |  |  |  |

- added (2025-11-07):
[0001628280-25-050698:note_history:98]
|  | Three Months Ended |
|  | October 3,2025 |  | September 27,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | 583 |  |
| Notes due to Western Digital Corporation | — |  |  | (378) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (6) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (3) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | (7) |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | 189 |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:99]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Interest expense on notes due to Western Digital Corporation | $ | 3 |  |  | $ | 9 |  |  | $ | 7 |  |  | $ | 29 |  |
| Interest (income) on notes due from Western Digital Corporation | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |  | $ | (4) |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:100]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | 190 |  |  | $ | 189 |  |  | $ | 520 |  |
| Selling general, and administrative | 10 |  |  | 109 |  |  | 158 |  |  | 328 |  |
| Business separation costs | 9 |  |  | — |  |  | 50 |  |  | — |  |
| Employee termination and other charges | — |  |  | 2 |  |  | 5 |  |  | (44) |  |
| Total allocation of Corporate Expenses | $ | 19 |  |  | $ | 301 |  |  | $ | 402 |  |  | $ | 804 |  |

- removed (2025-11-07):
[0002023554-25-000027:note_history:101]
|  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | (585) |  |  | $ | 234 |  |
| Notes due (to) from Western Digital Corporation | (1,223) |  |  | 113 |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | (105) |  |  | — |  |
| Unis venture transferred from Western Digital Corporation | (61) |  |  | — |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | (27) |  |  | (5) |  |
| Tax balances transferred from Western Digital Corporation | (8) |  |  | (2) |  |
| Accumulated other comprehensive loss transferred to Western Digital Corporation | 10 |  |  | — |  |
| Tax indemnification liability transferred to Western Digital Corporation | 112 |  |  | — |  |
| Net transfers (to) from Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | (1,887) |  |  | $ | 340 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001628280-25-050698:note_history:102]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 269 |  |  | $ | 300 |  |  |  |  |  |
| Edge | 1,387 |  |  | 1,069 |  |  |  |  |  |
| Consumer | 652 |  |  | 514 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,515 |  |  | $ | 1,150 |  |  |  |  |  |
| Americas | 406 |  |  | 443 |  |  |  |  |  |
| Europe, Middle East and Africa | 387 |  |  | 290 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |
  (was, 2025-05-12, similarity 0.6872):
[0002023554-25-000027:note_history:102]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Cloud | $ | 197 |  |  | $ | 97 |  |  | $ | 747 |  |  | $ | 155 |  |
| Client | 927 |  |  | 1,035 |  |  | 3,024 |  |  | 3,002 |  |
| Consumer | 571 |  |  | 573 |  |  | 1,683 |  |  | 1,746 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,038 |  |  | $ | 1,140 |  |  | $ | 3,274 |  |  | $ | 3,313 |  |
| Americas | 375 |  |  | 272 |  |  | 1,207 |  |  | 759 |  |
| Europe, Middle East and Africa | 282 |  |  | 293 |  |  | 973 |  |  | 831 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-07):
[0001628280-25-050698:note_history:103]
The Company’s broad portfolio of technology and products addresses multiple end markets. Datacenter represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers. Through the Edge end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.
  (was, 2025-05-12, similarity 0.9835):
[0002023554-25-000027:note_history:103]
The Company’s broad portfolio of technology and products addresses multiple end markets. Cloud represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers. Through the Client end market, the Company provides its original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash solutions across personal computer, mobile, gaming, automotive, virtual reality headsets, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by the Company’s broad range of retail and other end-user products, which capitalize on the strength of the Company’s product brand recognition and vast points of presence around the world.

- changed (2025-11-07):
[0001628280-25-050698:note_history:104]
|  | Three Months Ended |  |  |
|  | October 3,2025 |  | September 27,2024 |  |  |  |  |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 269 |  |  | $ | 300 |  |  |  |  |  |
| Edge | 1,387 |  |  | 1,069 |  |  |  |  |  |
| Consumer | 652 |  |  | 514 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,515 |  |  | $ | 1,150 |  |  |  |  |  |
| Americas | 406 |  |  | 443 |  |  |  |  |  |
| Europe, Middle East and Africa | 387 |  |  | 290 |  |  |  |  |  |
| Total revenue | $ | 2,308 |  |  | $ | 1,883 |  |  |  |  |  |
  (was, 2025-05-12, similarity 0.6872):
[0002023554-25-000027:note_history:104]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Cloud | $ | 197 |  |  | $ | 97 |  |  | $ | 747 |  |  | $ | 155 |  |
| Client | 927 |  |  | 1,035 |  |  | 3,024 |  |  | 3,002 |  |
| Consumer | 571 |  |  | 573 |  |  | 1,683 |  |  | 1,746 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 1,038 |  |  | $ | 1,140 |  |  | $ | 3,274 |  |  | $ | 3,313 |  |
| Americas | 375 |  |  | 272 |  |  | 1,207 |  |  | 759 |  |
| Europe, Middle East and Africa | 282 |  |  | 293 |  |  | 973 |  |  | 831 |  |
| Total revenue | $ | 1,695 |  |  | $ | 1,705 |  |  | $ | 5,454 |  |  | $ | 4,903 |  |

- added (2025-11-07):
[0001628280-25-050698:note_history:105]
The Company’s top 10 customers accounted for 40% and 53% of its net revenue for the three months ended October 3, 2025 and September 27, 2024, respectively. For the three months ended October 3, 2025 and September 27, 2024, no customer accounted for more than 10% of the Company’s net revenue. 
Revenue
Contract assets represent the Company’s right to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company had no contract assets as of October 3, 2025 or June 27, 2025. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service, support, and maintenance contracts. Contract liabilities as of October 3, 2025, and June 27, 2025, and changes in contract liabilities for the three months ended October 3, 2025 and September 27, 2024, were not material.

- changed (2025-11-07):
[0001628280-25-050698:note_history:106]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements, and customer support and service contracts, which will be recognized over their contract period. For the three months ended October 3, 2025, the transaction price allocated to the remaining performance obligations was not material.
  (was, 2025-05-12, similarity 0.8856):
[0002023554-25-000027:note_history:106]
The Company applies the practical expedients and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year. The remaining performance obligations are mainly attributed to right-to-access patent license arrangements, professional service arrangements, and customer support and service contracts, which will be recognized over their contract period. The transaction price allocated to the remaining performance obligations as of March 28, 2025, was not material.

- removed (2025-11-07):
[0002023554-25-000027:note_history:107]
The Company’s top 10 customers accounted for 41% and 43% of its net revenue for the three and nine months ended March 28, 2025, respectively, and 43% and 41% of its net revenue for the three and nine months ended March 29, 2024, respectively. For the three months ended March 28, 2025, one customer accounted for more than 10% of the Company’s net revenue. For the nine months ended March 28, 2025 and the three and nine months ended March 29, 2024, no customer accounted for 10% of the Company’s net revenue.
Revenues
Contract assets represent the Company’s rights to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The Company had no contract assets as of March 28, 2025 or June 28, 2024. Contract liabilities relate to customers’ payments in advance of performance under the contract and primarily relate to remaining performance obligations under professional service, support, and maintenance contracts. Contract liabilities as of March 28, 2025, and June 28, 2024, and changes in contract liabilities for the three and nine months ended March 28, 2025, and March 29, 2024, were not material.
