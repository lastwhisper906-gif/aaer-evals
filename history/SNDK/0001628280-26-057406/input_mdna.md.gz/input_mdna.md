# SNDK MD&A — 0001628280-26-057406


## mdna

[0001628280-26-057406:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-26-057406:mdna:2]
For management’s discussion of our consolidated results for the year ended June 27, 2025 in comparison with the combined results for the year ended June 28, 2024, and other financial information related to fiscal year 2025, refer to Part II, Item 7., “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” included in our 2025 Annual Report on Form 10-K, filed with the U.S. Securities and Exchange Commission (“SEC”) on August 21, 2025.

[0001628280-26-057406:mdna:3]
Unless otherwise indicated or the context requires, references herein to specific years and quarters are to our fiscal years and fiscal quarters. As used herein, the terms “we,” “us,” “our,” and the “Company” refer to Sandisk Corporation and its subsidiaries.

[0001628280-26-057406:mdna:4]
Overview

[0001628280-26-057406:mdna:5]
Our Business

[0001628280-26-057406:mdna:6]
Sandisk is a leading global semiconductor memory company with more than 30 years of innovation in NAND flash technology. We are a vertically integrated solutions provider with ownership of chip-level design and IP, front and back-end manufacturing, as well as systems engineering and design. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for artificial intelligence (“AI”) workloads in datacenters, edge devices, and consumer applications. Our technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. Our solutions include a broad range of solid-state drives (“SSDs”), embedded products, removable cards, universal serial bus drives and wafers and components. Our broad portfolio of technology and products addresses multiple end markets of “Datacenter” (formerly referred to as “Cloud”), “Edge” (formerly referred to as “Client”), and “Consumer.”

[0001628280-26-057406:mdna:7]
The Datacenter end market is comprised primarily of products for datacenters, cloud service providers, and private cloud customers. Through the Edge end market, we provide our original equipment manufacturer (“OEM”) and channel customers a broad array of high-performance flash solutions across personal computer, mobile, gaming, automotive, physical AI, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast presence around the world.

[0001628280-26-057406:mdna:8]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal years 2025 and 2024, which ended on June 27, 2025 and June 28, 2024, respectively, were each comprised of 52 weeks, with each fiscal quarter consisting of 13 weeks. Fiscal year 2026 was comprised of 53 weeks and ended on July 3, 2026, with the first fiscal quarter consisting of 14 weeks. Unless otherwise indicated or the context requires, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a consolidated basis.

[0001628280-26-057406:mdna:9]
The Separation

[0001628280-26-057406:mdna:10]
On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized WDC management to pursue a plan to separate the Company into an independent public company (the “separation” or “the spin-off”). The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, we were wholly owned by WDC.

[0001628280-26-057406:mdna:11]
On February 21, 2025, WDC executed the spin-off of the Company through WDC’s pro rata distribution of 116,035,464, or 80.1%, of the Company’s outstanding shares of common stock to holders of WDC’s common stock. Each WDC stockholder received one-third (1/3) of one share of the Company’s common stock for each share of WDC’s common stock held by such WDC stockholder as of February 12, 2025, the record date of the distribution. Upon completion of the separation, WDC owned 28,827,787, or 19.9%, of the outstanding shares of the Company’s common stock. Following the distribution, the Company became an independent publicly listed company, and on February 24, 2025, the Company began trading as an independent publicly traded company under the stock symbol “SNDK” on Nasdaq.

[0001628280-26-057406:mdna:12]
On June 9, 2025, WDC disposed of 21,314,768, or 14.6%, of our common stock through an exchange of our common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. On February 18, 2026, WDC disposed of an additional 5,821,135 outstanding shares of the Company through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by us. All expenses for these offerings were paid for by us. Following this transaction, WDC continued to retain 1,691,884 of the outstanding shares of the Company’s common stock and, as of March 19, 2026, the sale of such shares was no longer subject to restriction, and we were no longer required to pay any expenses associated with WDC’s eventual exchange or distribution of our shares. Subsequent to this date, WDC has disposed of additional outstanding shares of our common stock in exchange for shares of its outstanding common stock and has announced that it expects to monetize all remaining shares of Sandisk common stock held by it by the end of 2026 in one or more subsequent exchanges for its outstanding common stock.

[0001628280-26-057406:mdna:13]
Goodwill Impairment

[0001628280-26-057406:mdna:14]
As discussed in Part II, Item 8., Note 5, Supplemental Financial Statement Data of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, subsequent to the separation, we conducted a quantitative analysis of potential goodwill and long-lived assets impairments, in accordance with Accounting Standards Codification (“ASC”) No. 350, Intangibles - Goodwill and Other. This analysis indicated that the estimated carrying value of our reporting unit exceeded its fair value. Consequently, we recorded a goodwill impairment charge of $1.8 billion during the fiscal year ended June 27, 2025.

[0001628280-26-057406:mdna:15]
For the year ended July 3, 2026, there were no goodwill impairment charges recorded.

[0001628280-26-057406:mdna:16]
Financing Activities

[0001628280-26-057406:mdna:17]
Prior to the separation, we received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additional information regarding our outstanding notes due to (from) Western Digital Corporation is included in Part II, Item 8., Note 10, Related Parties and Related Commitments and Contingencies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:18]
As discussed in Part II, Item 8., Note 8, Debt of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K, on February 21, 2025, we entered into a loan agreement (the “Loan Agreement”) comprised of a seven-year Term Loan B facility in an aggregate principal amount of $2.0 billion (the “Term Loan Facility”) and a five-year revolving credit facility (the “Revolving Credit Facility”) in an aggregate principal amount of $1.5 billion, including up to $150 million for letters of credit.

[0001628280-26-057406:mdna:19]
On February 21, 2025, we borrowed $2.0 billion under the Term Loan Facility. We used a portion of the proceeds of the borrowing to make a net distribution payment of $1.5 billion to WDC, with the remainder used for general corporate purposes of the Company. The proceeds of the Revolving Credit Facility may be used by us for working capital and general corporate purposes.

[0001628280-26-057406:mdna:20]
On March 4, 2026, the Company settled in full the remaining outstanding principal amounts of the Term Loan Facility, plus accrued interest, using cash on hand. In connection with the early settlement of the Term Loan Facility, the Company recognized a loss on debt extinguishment of $46 million resulting from the write-off of the remaining unamortized issuance costs.

[0001628280-26-057406:mdna:21]
As of July 3, 2026, we have drawn no amounts under the Revolving Credit Facility.

[0001628280-26-057406:mdna:22]
Operational Update

[0001628280-26-057406:mdna:23]
In 2026, we continued to observe that the rapid growth of AI infrastructure is driving demand for high-performance storage products, and AI adoption is driving the need for NAND storage to support these workloads, leading to increased revenues when compared to prior periods. The current demand environment has led to pricing shifts that have positively impacted our business, and we expect these favorable pricing trends to have a positive impact on our revenue and cash flows from operations. We expect AI-driven demand to persist through calendar year 2027 and beyond. Accordingly, we expect to invest in, and allocate resources to, high-value opportunities for both the short-term and long-term benefit of our customers and us.

[0001628280-26-057406:mdna:24]
44

[0001628280-26-057406:mdna:25]
There are pending and ongoing investigations initiated by the United States under Section 232 of the Trade Expansion Act of 1962 and Section 301 of the Trade Act of 1974 that may impact tariff rates for our products. Currently, the majority of our products sold in the U.S. are exempt from tariffs, but additional tariff increases, or the loss of applicable exemptions, would increase the cost of goods sold for our products sold in the U.S., which could negatively impact our margins and financial performance. Increases in the price of our products in response to increased costs may adversely impact demand for those products in the U.S., which could also negatively impact our performance and financial results. Future trade policies and regulations in the U.S. and other countries, the terms of any trade arrangements that may be negotiated between the U.S. and other countries, the scope, amount, or duration of tariffs that may be imposed by any country, and the impact of these factors on our business are uncertain and may contribute to increased costs and reduced demand for our products, each of which could harm our financial performance.

[0001628280-26-057406:mdna:26]
Commencing in fiscal 2026, we entered into long-term agreements, which we also refer to as New Business Models, or “NBMs,” with several Datacenter and Edge customers. These agreements generally commit us to deliver, and our customers to purchase, a stated volume of products, mostly over multi-year periods. The agreements include pricing mechanisms consisting of fixed and variable components and are supported by financial guarantees that are intended to provide additional protection in the event a customer does not satisfy their contractual purchase obligations. As NBMs are expected to become our predominant way of doing business, we believe that this business model will contribute to greater predictability of revenue, support production planning, and enhance supply assurance for our customers. While these agreements do not eliminate the risks associated with customer demand, market conditions, or operational execution, we believe they reduce certain elements of industry cyclicality and support our long-term strategic and financial objectives.

[0001628280-26-057406:mdna:27]
We will continue to actively monitor developments impacting our business and may take additional responsive actions that we determine to be in the best interest of our business and stakeholders.

[0001628280-26-057406:mdna:28]
Basis of Presentation

[0001628280-26-057406:mdna:29]
On February 21, 2025, the Company became a standalone publicly traded company, and its financial statements are now presented on a consolidated basis. Prior to the separation, the Company’s historical consolidated financial information was derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the policies and practices that are generally accepted in the industry in which it operates, consistent with prior statements.

[0001628280-26-057406:mdna:30]
The following discussion reflects our financial condition and results of operations as set forth in the Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:31]
The Consolidated Statements of Operations include all revenues and costs directly attributable to us, including costs for facilities, functions, and services used by us. Prior to the separation, our business had historically functioned together with the other businesses controlled by WDC. Accordingly, we relied on WDC’s corporate overhead and other support functions. Therefore, certain corporate overhead and shared costs were allocated to us including (i) certain general and administrative expenses related to WDC’s support functions that are provided on a centralized basis within WDC (e.g., expenses for corporate facilities, executive oversight, treasury, finance, legal, human resources, compliance, information technology, employee benefit plans, stock compensation plans and other corporate functions), and (ii) certain operations support costs incurred by WDC, including product sourcing, maintenance and support services, and other supply chain functions. These expenses were specifically identified, when possible, or allocated based on revenues, headcount, usage or other allocation methods that are considered to be a reasonable reflection of the utilization of services provided or benefit received. While management considers that such allocations were made on a reasonable basis consistent with benefits received, the Consolidated Financial Statements included in this Annual Report on Form 10-K may not be indicative of our future performance, do not necessarily include the actual expenses that would have been incurred by us and may not reflect our results of operations, financial position, and cash flows had we been a separate, standalone company during the periods presented. For additional information, see Part II, Item 8., Note 1, Organization, Basis of Presentation and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:32]
Results of Operations

[0001628280-26-057406:mdna:33]
Overview

[0001628280-26-057406:mdna:34]
The following table sets forth, for the periods presented, selected summary information from our Consolidated Statements of Operations by U.S. dollars and percentage of net revenue(1):

[0001628280-26-057406:mdna:35]
|  | Year Ended |
|  | 2026 |  | 2025 |  | 2024 |  |  |  |
|  | (in millions, except percentages) |
| Revenue, net | $ | 20,248 |  |  | 100.0 | % |  | $ | 7,355 |  |  | 100.0 | % |  | $ | 6,663 |  |  | 100.0 | % |  |  |  |
| Cost of revenue | 5,776 |  |  | 28.5 |  |  | 5,143 |  |  | 69.9 |  |  | 5,591 |  |  | 83.9 |  |  |  |  |
| Gross profit | 14,472 |  |  | 71.5 |  |  | 2,212 |  |  | 30.1 |  |  | 1,072 |  |  | 16.1 |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,328 |  |  | 6.6 |  |  | 1,132 |  |  | 15.4 |  |  | 1,061 |  |  | 15.9 |  |  |  |  |
| Selling, general and administrative | 676 |  |  | 3.3 |  |  | 573 |  |  | 7.8 |  |  | 455 |  |  | 6.8 |  |  |  |  |
| Goodwill impairment | — |  |  | — |  |  | 1,830 |  |  | 24.9 |  |  | — |  |  | — |  |  |  |  |
| Loss on debt extinguishment | 46 |  |  | 0.2 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |
| Business separation costs | 25 |  |  | 0.1 |  |  | 67 |  |  | 0.9 |  |  | 64 |  |  | 1.0 |  |  |  |  |
| Employee termination and other | (2) |  |  | — |  |  | 21 |  |  | 0.3 |  |  | (40) |  |  | (0.6) |  |  |  |  |
| (Gain) loss on business divestiture | 10 |  |  | — |  |  | (34) |  |  | (0.5) |  |  | — |  |  | — |  |  |  |  |
| Total operating expenses | 2,083 |  |  | 10.2 |  |  | 3,589 |  |  | 48.8 |  |  | 1,540 |  |  | 23.1 |  |  |  |  |
| Operating income (loss) | 12,389 |  |  | 61.3 |  |  | (1,377) |  |  | (18.7) |  |  | (468) |  |  | (7.0) |  |  |  |  |
| Interest and other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain (loss) on equity securities, net | 808 |  |  | 4.0 |  |  | (2) |  |  | — |  |  | 1 |  |  | — |  |  |  |  |
| Interest income | 70 |  |  | 0.3 |  |  | 22 |  |  | 0.3 |  |  | 12 |  |  | 0.2 |  |  |  |  |
| Interest expense | (73) |  |  | (0.4) |  |  | (63) |  |  | (0.9) |  |  | (40) |  |  | (0.6) |  |  |  |  |
| Other income (expense), net | (177) |  |  | (0.9) |  |  | (59) |  |  | (0.8) |  |  | (8) |  |  | (0.1) |  |  |  |  |
| Total interest and other income (expense), net | 628 |  |  | 3.0 |  |  | (102) |  |  | (1.4) |  |  | (35) |  |  | (0.5) |  |  |  |  |
| Income (loss) before taxes | 13,017 |  |  | 64.3 |  |  | (1,479) |  |  | (20.1) |  |  | (503) |  |  | (7.5) |  |  |  |  |
| Income tax expense | 1,584 |  |  | 7.8 |  |  | 162 |  |  | 2.2 |  |  | 169 |  |  | 2.5 |  |  |  |  |
| Net income (loss) | $ | 11,433 |  |  | 56.5 | % |  | $ | (1,641) |  |  | (22.3) | % |  | $ | (672) |  |  | (10.0) | % |  |  |  |

[0001628280-26-057406:mdna:36]
(1) Percentage may not total due to rounding.

[0001628280-26-057406:mdna:37]
The following table sets forth, for the periods presented, summary information regarding our disaggregated revenue:

[0001628280-26-057406:mdna:38]
|  | 2026 |  | 2025 |  | 2024 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |
| Datacenter | $ | 5,153 |  |  | $ | 960 |  | $ | 325 |  |
| Edge | 12,160 |  |  | 4,127 |  | 4,069 |  |
| Consumer | 2,935 |  |  | 2,268 |  | 2,269 |  |
| Total revenue | $ | 20,248 |  |  | $ | 7,355 |  |  | $ | 6,663 |  |
| Revenue by geography: |  |  |  |  |  |
| Asia | $ | 14,241 |  |  | $ | 4,457 |  | $ | 4,510 |  |
| Americas | 4,275 |  |  | 1,618 |  | 1,095 |  |
| Europe, Middle East and Africa | 1,732 |  |  | 1,280 |  | 1,058 |  |
| Total revenue | $ | 20,248 |  |  | $ | 7,355 |  |  | $ | 6,663 |  |

[0001628280-26-057406:mdna:39]
46

[0001628280-26-057406:mdna:40]
Our broad portfolio of technology and products addresses multiple end markets. Datacenter represents a large and growing end market comprised primarily of products for public or private cloud environments and enterprise customers. Through the Edge end market, we provide our OEM and channel customers a broad array of high-performance flash solutions across personal computer, mobile, gaming, automotive, physical AI, at-home entertainment, and industrial spaces. The Consumer end market is highlighted by our broad range of retail and other end-user products, which capitalize on the strength of our product brand recognition and vast presence around the world.

[0001628280-26-057406:mdna:41]
Net Revenue

[0001628280-26-057406:mdna:42]
Net revenue increased 175%, or $12,893 million, in 2026 compared to 2025, due to a 437% increase in Datacenter revenue, a 195% increase in Edge revenue, and a 29% increase in Consumer revenue. Total products sold increased by mid-teens percent on an exabyte basis.

[0001628280-26-057406:mdna:43]
Datacenter revenue increased 437%, or $4,193 million, in 2026 compared to 2025, primarily due to higher sales and higher pricing. Total products sold increased by almost 120% on an exabyte basis. Revenue per gigabyte increased by almost 150%.

[0001628280-26-057406:mdna:44]
Edge revenue increased 195%, or $8,033 million, in 2026 compared to 2025, primarily due to higher sales and higher pricing. Total products sold increased by high single-digits percent on an exabyte basis. Revenue per gigabyte increased by almost 180%.

[0001628280-26-057406:mdna:45]
Consumer revenue increased 29%, or $667 million in 2026 compared to 2025, primarily due to higher pricing partially offset by lower sales. Total products sold decreased by mid-teens percent on an exabyte basis. Revenue per gigabyte increased by low-fifties percent.

[0001628280-26-057406:mdna:46]
The changes in net revenue by geography in 2026 compared to 2025 primarily reflected higher revenue in the Asia and Americas regions from Edge and Datacenter customers, respectively.

[0001628280-26-057406:mdna:47]
Consistent with standard industry practice, we offer sales incentives and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as reductions of gross revenue. For 2026, 2025 and 2024, these programs represented 11%, 19%, and 19%, respectively, of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix, and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0001628280-26-057406:mdna:48]
Gross Profit and Gross Margin

[0001628280-26-057406:mdna:49]
Gross profit increased $12,260 million in 2026 compared to 2025, primarily due to higher sales and higher pricing in 2026 compared to 2025 as described above.

[0001628280-26-057406:mdna:50]
Gross profit margin increased 4,100 basis points in 2026 compared to 2025 primarily due to higher sales and higher pricing.

[0001628280-26-057406:mdna:51]
Operating Expenses

[0001628280-26-057406:mdna:52]
Research and development

[0001628280-26-057406:mdna:53]
Research and development (“R&D”) expenses increased $196 million in 2026 compared to 2025, primarily due to a $136 million increase in compensation and benefits due to variable compensation associated with company performance and increased headcount, a $28 million increase in spending for R&D projects as we continue to invest in innovation, and a $24 million increase in stock based compensation.

[0001628280-26-057406:mdna:54]
Selling, general and administrative

[0001628280-26-057406:mdna:55]
Selling, general and administrative expenses increased $103 million in 2026 compared to 2025, primarily due to a $68 million increase in compensation and benefits due to variable compensation associated with company performance and increased headcount, partially offset by a $51 million decrease in materials due to a change in business practice for the launch of new products whereby the Company is distributing fewer free samples and has started entering into contracts to sell certain qualification units to customers. The costs of qualification units are recorded in inventory until sold to customers and recognized as cost of revenue. The change contributed to a decrease in materials and production costs classified as selling expenses when compared to the prior year period, partially offset by a $32 million increase in sales and marketing expenses, and a $15 million increase in outside services.

[0001628280-26-057406:mdna:56]
Goodwill impairment

[0001628280-26-057406:mdna:57]
Goodwill impairment decreased $1.8 billion in 2026 compared to 2025 due to an impairment charge resulting from the difference between the carrying value of our reporting unit and its fair value that was recognized in the previous fiscal year. No such impairment charge was incurred during the current fiscal year.

[0001628280-26-057406:mdna:58]
Loss on debt extinguishment

[0001628280-26-057406:mdna:59]
Loss on debt extinguishment increased $46 million in 2026 compared to 2025 due to the write-off of the remaining unamortized issuance costs in connection with the early settlement of the Company’s Term Loan Facility.

[0001628280-26-057406:mdna:60]
Business separation costs

[0001628280-26-057406:mdna:61]
Business separation costs decreased $42 million in 2026 compared to 2025, primarily due to the completion of the separation from WDC.

[0001628280-26-057406:mdna:62]
Employee termination and other

[0001628280-26-057406:mdna:63]
Employee termination and other charges decreased $23 million in 2026 compared to 2025 as there were no restructuring actions taken in the current period.

[0001628280-26-057406:mdna:64]
Gain on business divestiture

[0001628280-26-057406:mdna:65]
Gain on business divestiture decreased $44 million in 2026 compared to 2025 primarily due to the pre-tax gain on the sale of 80% of the Company’s interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”) recognized in the prior fiscal year and no comparable transaction in the current fiscal year.

[0001628280-26-057406:mdna:66]
Interest and Other Income (Expense), net

[0001628280-26-057406:mdna:67]
Interest and other income (expense), net increased $730 million in 2026 compared to 2025, primarily due to a gain on equity securities, due to the Company’s investment in Nanya Technology Corporation (“Nanya”), for which there was no activity in the comparable year. This $807 million gain was offset by a $118 million increase in other expenses which was primarily due to the settlement of certain non-operating legal matters, partially offset by a $48 million increase in interest income related to cash and investment accounts.

[0001628280-26-057406:mdna:68]
Income Tax Expense

[0001628280-26-057406:mdna:69]
H.R. 1, more widely known as the One Big Beautiful Bill Act (“OBBBA”), was signed into law on July 4, 2025. It reversed the requirement for capitalization of U.S. research and development expenditures that came into law under the Tax Cuts and Jobs Act of 2017, but the mandatory requirement of capitalization of foreign research and development expenditures remains. The tax rates for income earned by our foreign subsidiaries will also be changed under H.R. 1, which applies to our fiscal years 2027 and onward. Depending on our operating results, these changes can materially impact our effective tax rate and reduce our operating cash flows. During the fiscal year ended July 3, 2026, we recorded a $10 million tax benefit in relation to the OBBBA’s impact on the Company’s 2025 tax provision.

[0001628280-26-057406:mdna:70]
On August 16, 2022, the Inflation Reduction Act of 2022 was signed into law, which contained significant changes to laws related to tax, climate, energy, and health care. The tax measures include, among other things, a corporate alternative minimum tax (“CAMT”) of 15% on corporations with three-year average annual adjusted financial statement income (“AFSI”) exceeding $1.0 billion. We do not expect to be subject to the CAMT of 15% for fiscal year 2026 as our average annual AFSI did not exceed $1.0 billion for the preceding three-year period. We expect to be subject to CAMT in fiscal year 2027.

[0001628280-26-057406:mdna:71]
On December 20, 2021, the Organisation for Economic Co-operation and Development G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two”). Pillar Two is currently effective in most of the jurisdictions in which we operate. Accordingly, these taxes are included in the Company’s Income tax expense for the year ended July 3, 2026.

[0001628280-26-057406:mdna:72]
The following table presents our Income tax expense and the effective tax rate:

[0001628280-26-057406:mdna:73]
|  | 2026 |  | 2025 |  | 2024 |
|  | (in millions) |
| Income (loss) before taxes | $ | 13,017 |  |  | $ | (1,479) |  |  | $ | (503) |  |
| Income tax expense | 1,584 |  |  | 162 |  |  | 169 |  |
| Effective tax rate | 12 | % |  | (11) | % |  | (34) | % |

[0001628280-26-057406:mdna:74]
48

[0001628280-26-057406:mdna:75]
The relative mix of earnings and losses by jurisdiction, foreign-derived deduction-eligible income, credits, and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the year ended July 3, 2026.

[0001628280-26-057406:mdna:76]
The primary drivers of the difference between the effective tax rate for the year ended June 27, 2025 and the U.S. federal statutory rate of 21% are the relative mix of earnings and losses by jurisdiction, the goodwill impairment, the foreign income inclusion, credits, and tax holidays in Malaysia.

[0001628280-26-057406:mdna:77]
For additional information regarding income tax expense, see Part II, Item 8., Note 14, Income Tax Expense of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:78]
Financial condition, liquidity and capital resources

[0001628280-26-057406:mdna:79]
The following table summarizes our Consolidated Statements of Cash Flows:

[0001628280-26-057406:mdna:80]
|  | 2026 |  | 2025 |  | 2024 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 11,671 |  |  | $ | 84 |  |  | $ | (309) |  |
| Investing activities | (1,386) |  |  | 556 |  |  | 210 |  |
| Financing activities | (7,001) |  |  | 518 |  |  | 136 |  |
| Effect of exchange rate changes on cash | (3) |  |  | (5) |  |  | (1) |  |
| Net increase in cash and cash equivalents | $ | 3,281 |  |  | $ | 1,153 |  |  | $ | 36 |  |

[0001628280-26-057406:mdna:81]
In alignment with market conditions, we maintained what we believe to be a conservative capital expenditure strategy for fiscal years 2026 and 2025. For fiscal year 2027, we anticipate increased capital investments as we transition to newer nodes to meet the demand and technology needs of our product portfolio.

[0001628280-26-057406:mdna:82]
We believe our cash and cash equivalents will be sufficient to meet our working capital and capital expenditure needs, as well as to fund any repurchases of our shares under the Repurchase Program (as defined under Share Repurchase Authorization below). We believe we can also access the various capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part I, Item 1A., Risk Factors included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:83]
A total of $2,879 million and $692 million of our cash and cash equivalents were held outside of the U.S. as of July 3, 2026 and June 27, 2025, respectively. There are no material tax consequences that were not previously accrued for the repatriation of this cash. Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities.

[0001628280-26-057406:mdna:84]
Operating Activities

[0001628280-26-057406:mdna:85]
Net cash provided by operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used as a result of changes in operating assets and liabilities was $212 million for 2026, compared to $380 million net cash provided for 2025 and to $86 million net cash provided for 2024, reflecting an increase in the volume of our business, as discussed above.

[0001628280-26-057406:mdna:86]
Changes in our operating assets and liabilities are largely affected by our working capital requirements, which are dependent on the volume of our business and the effective management of our cash conversion cycle as well as timing of payments for taxes. Our cash conversion cycle measures how quickly we can convert our products into cash through sales. The cash conversion cycles were as follows (in days):

[0001628280-26-057406:mdna:87]
|  | 2026 |  | 2025 |  | 2024 |
| Days sales outstanding | 48 |  |  | 51 |  |  | 48 |  |
| Days in inventory | 178 |  |  | 135 |  |  | 158 |  |
| Days payable outstanding | (64) |  |  | (50) |  |  | (54) |  |
| Cash conversion cycle | 162 |  |  | 136 |  |  | 152 |  |

[0001628280-26-057406:mdna:88]
Changes in days sales outstanding, or DSO, are generally due to the timing of shipments. Changes in days in inventory, or DIO, are generally related to the timing of inventory builds. Changes in days payable outstanding, or DPO, are generally related to production volume and the timing of purchases during the period. From time to time, we modify the timing of payments to our vendors. We make modifications primarily to manage our vendor relationships and to manage our cash flows, including our cash balances. Generally, we make payment term modifications through negotiations with our vendors or by granting to, or receiving from, our vendors’ payment term accommodations.

[0001628280-26-057406:mdna:89]
In 2026, DSO decreased 3 days when compared to the prior year, primarily due to the timing of shipments and continued strong receivables collections. DIO increased 43 days over the prior year, primarily due to inventory builds to meet demand. DPO increased 14 days over the prior year, primarily due to routine variations in the timing of purchases and payments.

[0001628280-26-057406:mdna:90]
Investing Activities

[0001628280-26-057406:mdna:91]
Net cash used in investing activities in 2026 primarily consisted of $970 million in purchases of marketable equity securities, $275 million in net issuances from activity related to Flash Ventures and $177 million in capital expenditures, partially offset by $25 million in net proceeds from our sale of a majority interest in one of our subsidiaries. Net cash provided by investing activities in 2025 primarily consisted of $401 million in net proceeds from our sale of a majority interest in one of our subsidiaries and $358 million in net proceeds from activity related to Flash Ventures, partially offset by $204 million in capital expenditures.

[0001628280-26-057406:mdna:92]
Financing Activities

[0001628280-26-057406:mdna:93]
Net cash used in financing activities in 2026 primarily consisted of $4.5 billion in repurchases of the Company’s common stock pursuant to the Initial Repurchase Program (as defined under Share Repurchase Authorization below), $1.9 billion for repayments and eventual settlement of the Term Loan Facility, and $630 million in payments of taxes on vested stock awards. Net cash provided by financing activities in 2025 primarily consisted of $2.0 billion in proceeds from borrowings from the Term Loan Facility, $550 million in proceeds from borrowings on notes due to WDC, and $101 million in proceeds from principal repayments on notes due from WDC, partially offset by $1.9 billion transferred to WDC, $100 million in repayment on the Term Loan Facility, and $76 million in net repayments on notes due to WDC.

[0001628280-26-057406:mdna:94]
A discussion of our cash flows for 2024, including a comparison of such cash flows to 2023, is included in Part II, Item 7., “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” included in our 2025 Annual Report on Form 10-K, filed with the U.S. Securities and Exchange Commission (“SEC”) on August 21, 2025.

[0001628280-26-057406:mdna:95]
Off-Balance Sheet Arrangements

[0001628280-26-057406:mdna:96]
Other than the Flash Ventures, SDSS and Nanya-related commitments incurred in the normal course of business and certain indemnification provisions (see “Short-and-Long-term Liquidity—Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligations arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Consolidated Financial Statements. Additionally, with the exception of Flash Ventures, the SDSS Venture and the Unis Venture, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part II, Item 8., Note 10, Related Parties and Related Commitments and Contingencies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:97]
Short-and-Long-term Liquidity

[0001628280-26-057406:mdna:98]
Material Cash Requirements

[0001628280-26-057406:mdna:99]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of July 3, 2026. In addition, see the discussions further below related to unrecognized tax benefits, foreign exchange contracts, indemnifications, long term agreements and share repurchase authorization.

[0001628280-26-057406:mdna:100]
|  | Total |  | 1 year (2027) |  | 2-3 Years (2028 - 2029) |  | 4-5 Years (2030 - 2031) |  | More than 5 Years (Beyond 2031) |
|  | (in millions) |
| Flash Ventures related commitments (1) | $ | 6,559 |  |  | $ | 2,627 |  |  | $ | 2,577 |  |  | $ | 1,318 |  |  | $ | 37 |  |
| Purchase obligations and other commitments | 4,902 |  |  | 726 |  |  | 2,993 |  |  | 1,111 |  |  | 72 |  |
| Operating leases | 299 |  |  | 38 |  |  | 55 |  |  | 44 |  |  | 162 |  |
| Total | $ | 11,760 |  |  | $ | 3,391 |  |  | $ | 5,625 |  |  | $ | 2,473 |  |  | $ | 271 |  |

[0001628280-26-057406:mdna:101]
(1) Includes Flash Ventures depreciation reimbursement and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including research and development and building depreciation and payments made directly to Kioxia in consideration for the manufacturing services and continued availability of supply. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0001628280-26-057406:mdna:102]
Debt

[0001628280-26-057406:mdna:103]
In connection with the separation, on February 21, 2025, we entered into the Loan Agreement, comprised of the $1.5 billion Revolving Credit Facility, on which no amounts have been drawn, and the $2.0 billion Term Loan Facility which was due in 2032. The Company used a portion of the proceeds received from the Term Loan Facility, as well as cash on hand, to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities and certain legal entities of WDC associated with the Company.

[0001628280-26-057406:mdna:104]
On March 4, 2026, the Company settled in full the remaining outstanding principal amounts of the Term Loan Facility, plus accrued interest, using cash on hand. In connection with the early settlement of the Term Loan Facility, the Company recognized a loss on debt extinguishment of $46 million resulting from the write-off of the remaining unamortized issuance costs.

[0001628280-26-057406:mdna:105]
As of July 3, 2026, we were in compliance with the Loan Agreement financial covenant that prohibits us from exceeding a maximum Leverage Ratio. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part II, Item 8., Note 8, Debt of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:106]
Flash Ventures

[0001628280-26-057406:mdna:107]
Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements, of which we guarantee half of all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of July 3, 2026, and as of June 27, 2025, we were in compliance with all covenants under these Japanese lease facilities. See Part II, Item 8., Note 10, Related Parties and Related Commitments and Contingencies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding Flash Ventures.

[0001628280-26-057406:mdna:108]
Purchase Obligations and Other Commitments

[0001628280-26-057406:mdna:109]
In the normal course of business, we enter into purchase orders with suppliers for the purchase of components used to manufacture our products. These purchase orders generally cover forecasted component supplies needed for production during the next quarter, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. We also enter into long-term agreements with suppliers that contain fixed future commitments, which are contingent on certain conditions such as performance, quality and technology of the vendor’s components. These arrangements are included under “Purchase obligations and other commitments” in the table above.

[0001628280-26-057406:mdna:110]
51

[0001628280-26-057406:mdna:111]
Unrecognized Tax Benefits

[0001628280-26-057406:mdna:112]
As of July 3, 2026, our liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $323 million. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of July 3, 2026 and June 27, 2025 was $16 million and $11 million, respectively. Of these amounts, approximately $259 million could result in potential cash payments.

[0001628280-26-057406:mdna:113]
Foreign Exchange Contracts

[0001628280-26-057406:mdna:114]
We purchase foreign exchange contracts to hedge the impact of foreign currency fluctuations on certain underlying assets, liabilities and commitments for operating expenses and product costs denominated in foreign currencies. See Part II, Item 7A., Quantitative and Qualitative Disclosures About Market Risk included in this Annual Report on Form 10-K for additional disclosures.

[0001628280-26-057406:mdna:115]
Indemnifications

[0001628280-26-057406:mdna:116]
Concurrent with the separation, we and WDC entered into a Tax Matters Agreement under which we and WDC agreed to indemnify each other for certain tax positions. As a result of this agreement, we recorded a tax indemnification liability of $112 million on February 21, 2025, which was recognized as an adjustment to the Net investment from Western Digital Corporation. The remaining tax indemnification liability of $128 million is classified as Other liabilities in the Consolidated Balance Sheets as of July 3, 2026.

[0001628280-26-057406:mdna:117]
In the ordinary course of business, we may provide indemnifications of varying scope and terms to customers, vendors, lessors, business partners, and other parties with respect to certain matters, including, but not limited to, losses arising out of our breach of agreements, products or services to be provided by us, environmental compliance, or intellectual property infringement claims made by third parties. In addition, we have entered into indemnification agreements with our directors and certain of our officers that will require us, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. We maintain director and officer insurance, which may cover certain liabilities arising from our obligation to indemnify our directors and officers in certain circumstances.

[0001628280-26-057406:mdna:118]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Such indemnification agreements may not be subject to maximum loss clauses. Historically, we have not incurred material costs as a result of obligations under these agreements.

[0001628280-26-057406:mdna:119]
Long-Term Agreements

[0001628280-26-057406:mdna:120]
In connection with entering into long-term agreements with certain customers, we received customer advances that increased our available cash and cash equivalents. We record these customer payments as contract liabilities in advance of performance under such contract. As of July 3, 2026, our contract liabilities were $1,242 million, which primarily relate to the remaining performance obligations under these long-term agreements. Our long-term agreements may also require customers to maintain refundable security deposits with the Company or establish and maintain collateral with third-party financial institutions during the contract term. Security deposits are recorded as refund liabilities within the Consolidated Balance Sheets. As of July 3, 2026, our refund liabilities were $1,500 million. See Part II, Item 8., Note 4, Revenue of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for information regarding our contract liabilities.

[0001628280-26-057406:mdna:121]
Share Repurchase Authorization

[0001628280-26-057406:mdna:122]
On April 30, 2026, we announced that our Board of Directors had approved a $6.0 billion (exclusive of fees and commissions) share repurchase program (the “Initial Repurchase Program”). On August 5, 2026, we announced that our Board of Directors had approved an additional $14.0 billion share repurchase program (exclusive of fees and commissions) (each of the share repurchase programs, collectively and separately, the “Repurchase Program”). The acquisition of shares under the Repurchase Program may be effected from time to time through open market purchases (including under a plan adopted pursuant to Rule 10b5-1 promulgated under the Securities Exchange Act of 1934) or other methods of acquiring shares, in each case on such terms and at such times as shall be permitted by applicable securities laws and determined by our management. We expect shares repurchased under the Repurchase Program to be funded by operating cash flows. The amount and timing of share repurchases will depend on market conditions and other relevant factors. We may suspend or discontinue the Repurchase Program at any time. The approval of the Repurchase Program does not obligate us to repurchase any common shares. During the year ended July 3, 2026, we repurchased 3 million shares of our common stock for an aggregate purchase price of $4.5 billion, and $1.5 billion remained available for future repurchases under the Repurchase Program as of July 3, 2026.

[0001628280-26-057406:mdna:123]
Recent Accounting Pronouncements

[0001628280-26-057406:mdna:124]
For a description of recently issued and adopted accounting pronouncements, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part II, Item 8., Note 2, Recent Accounting Pronouncements of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:125]
Critical Accounting Estimates

[0001628280-26-057406:mdna:126]
We have prepared the accompanying Consolidated Financial Statements in accordance with accounting principles generally accepted in the United States. The preparation of the financial statements requires the use of judgments and estimates that affect the reported amounts of revenues, expenses, assets, and liabilities. We have adopted accounting policies and practices that are generally accepted in the industry in which we operate. If these estimates differ significantly from actual results, the impact to the Consolidated Financial Statements may be material. Our accounting policies are fully described in Part II, Item 8., Note 1, Organization, Basis of Presentation and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001628280-26-057406:mdna:127]
Revenue

[0001628280-26-057406:mdna:128]
We provide distributors and retailers (collectively referred to as “resellers”) with limited price protection for inventories held by resellers at the time of published list price reductions. We also provide resellers and OEMs with other sales incentive programs. We record estimates of variable consideration related to these items as a reduction of revenue at the time of revenue recognition. We use judgment in our assessment of variable consideration in contracts to be included in the transaction price. We use the expected value method to arrive at the amount of variable consideration. We constrain variable consideration until the likelihood of a significant revenue reversal is not probable and believe that the expected value method is the appropriate estimate of the amount of variable consideration based on the fact that we have a large number of contracts with similar characteristics.

[0001628280-26-057406:mdna:129]
For sales to OEMs, the methodology for estimating variable consideration is based on the amount of consideration expected to be earned based on the OEMs’ volume of purchases under agreed-upon sales incentive programs. For sales to resellers, the methodology for estimating variable consideration is based on the amount of consideration expected to be earned from sell-through activity under agreed-upon sales incentive programs. The amount of consideration expected to be earned by the reseller is based on historical pricing information, current pricing trends and channel inventory levels. Estimating the impact of these factors requires judgment and differences between estimated and actual amounts of variable consideration can occur.

[0001628280-26-057406:mdna:130]
Inventories

[0001628280-26-057406:mdna:131]
We value inventories at the lower of cost or net realizable value, or “NRV,” with cost determined on a first-in, first-out basis. We record inventory write-downs of our inventory to the lower of cost or net realizable value or for obsolete or excess inventory based on assumptions, which requires significant judgment. The determination of NRV involves estimating the average selling prices less any selling expenses of inventory based on market conditions and customer demand. To estimate the average selling prices and selling expenses of inventory, we review historical sales, future demand, economic conditions, contract prices and other information.

[0001628280-26-057406:mdna:132]
We periodically perform an excess and obsolete analysis of our inventory based on assumptions, which includes changes in business and economic conditions, changes in technology and projected demand of our products. If in any period we anticipate a change in those assumptions to be less favorable than our previous estimates, additional inventory write-downs may be required and could materially and negatively impact our gross margin. If in any period, we can sell inventories that had been written down to a level below the realized selling price in the previous period, higher gross profit would be recognized in that period. Adjustments to the reserve in 2026 were immaterial.
