# SNDK MD&A — 0001628280-26-029401


## mdna

[0001628280-26-029401:mdna:1]
[same as prior period, unchanged from 0001628280-26-004407:mdna:1]

[0001628280-26-029401:mdna:2]
[same as prior period, unchanged from 0001628280-26-004407:mdna:2]

[0001628280-26-029401:mdna:3]
[same as prior period, unchanged from 0001628280-26-004407:mdna:3]

[0001628280-26-029401:mdna:4]
Sandisk is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for artificial intelligence (“AI”) workloads in datacenters, edge devices, and consumer applications. Our technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. Our solutions include a broad range of solid-state drives (“SSD”), embedded products, removable cards, universal serial bus drives and wafers and components. Our broad portfolio of technology and products addresses multiple end markets of “Datacenter” (formerly referred to as “Cloud”), “Edge” (formerly referred to as “Client”), and “Consumer.”

[0001628280-26-029401:mdna:5]
[same as prior period, unchanged from 0001628280-26-004407:mdna:5]

[0001628280-26-029401:mdna:6]
Our fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, we report a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which ended on June 27, 2025, was comprised of 52 weeks, with each fiscal quarter consisting of 13 weeks. Fiscal year 2026 is comprised of 53 weeks and ends on July 3, 2026, with the first fiscal quarter consisting of 14 weeks.

[0001628280-26-029401:mdna:7]
[same as prior period, unchanged from 0001628280-26-004407:mdna:7]

[0001628280-26-029401:mdna:8]
On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized WDC management to pursue a plan to separate the Company into an independent public company (the “separation” or the “spin-off”). The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly owned by WDC.

[0001628280-26-029401:mdna:9]
[same as prior period, unchanged from 0001628280-26-004407:mdna:9]

[0001628280-26-029401:mdna:10]
On June 9, 2025, WDC disposed of 21,314,768, or 14.6%, of our common stock through an exchange of our common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. On February 18, 2026, WDC disposed of 5,821,135 outstanding shares of the Company through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by us. All expenses for these offerings were paid for by us. Following this transaction, WDC continued to retain 1,691,884 of the outstanding shares of the Company’s common stock and, as of March 19, 2026, the sale of such shares is no longer subject to restriction.

[0001628280-26-029401:mdna:11]
[same as prior period, unchanged from 0001628280-26-004407:mdna:15]

[0001628280-26-029401:mdna:12]
Prior to the separation, the Company received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additional information regarding our outstanding notes due to (from) Western Digital Corporation is included in Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-26-029401:mdna:13]
As discussed in Part I, Item 1, Note 8, Debt of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q, on February 21, 2025, the Company entered into a loan agreement comprised of a seven-year Term Loan B facility in an aggregate principal amount of $2.0 billion (the “Term Loan Facility”) and a five-year revolving credit facility (the “Revolving Credit Facility”) in an aggregate principal amount of $1.5 billion, including up to $150 million for letters of credit.

[0001628280-26-029401:mdna:14]
On February 21, 2025, the Company borrowed $2.0 billion under its Term Loan Facility. The Company used a portion of the proceeds of the borrowing to make a net distribution payment of $1.5 billion to WDC, with the remainder to be used for general corporate purposes of the Company. The proceeds of the Revolving Credit Facility may be used by the Company for working capital and general corporate purposes.

[0001628280-26-029401:mdna:15]
On March 4, 2026, the Company settled in full the remaining outstanding principal amounts of the Term Loan Facility, plus accrued interest, using cash on hand. In connection with the early settlement of the Term Loan Facility, the Company recognized a loss on debt extinguishment of $46 million resulting from the write-off of the remaining unamortized issuance costs.

[0001628280-26-029401:mdna:16]
As of April 3, 2026, the Company has drawn no amounts under the Revolving Credit Facility.

[0001628280-26-029401:mdna:17]
[same as prior period, unchanged from 0001628280-26-004407:mdna:20]

[0001628280-26-029401:mdna:18]
In the third quarter, we continued to observe that the rapid growth of AI infrastructure is driving demand for high-performance storage products, and AI adoption is driving the need for NAND storage to support these workloads, leading to increased revenues when compared to prior periods. The current demand environment has led to pricing shifts that have positively impacted our business, and we expect these favorable pricing trends to have a positive impact on our revenue and cash flows from operations. We expect these conditions to persist through calendar year 2026 and beyond. Accordingly, we expect to invest in, and allocate resources to, high-value opportunities for both the short-term and long-term benefit of our customers and the Company.

[0001628280-26-029401:mdna:19]
The Trump Administration has made a number of changes in U.S. trade policy, including the imposition of tariffs under the authority of the International Emergency Economic Powers Act, which the U.S. Supreme Court found unlawful in February 2026, the creation of a refund process for such tariff duties, and the imposition of new tariffs under other statutory authorities. Currently, the majority of our products sold in the U.S. are exempt from tariffs, but additional tariff increases, or the loss of applicable exemptions, would increase the cost of goods sold for our products sold in the U.S., which could negatively impact our margins and financial performance. Increases in the price of our products in response to increased costs may adversely impact demand for those products in the U.S., which could also negatively impact our performance and financial results. Future trade policies and regulations in the U.S. and other countries, the terms of any trade arrangements that may be negotiated between the U.S. and other countries, the scope, amount, or duration of tariffs that may be imposed by any country, and the impact of these factors on our business are uncertain and may contribute to increased costs and reduced demand for our products, each of which could harm our financial performance.

[0001628280-26-029401:mdna:20]
[same as prior period, unchanged from 0001628280-26-004407:mdna:26]

[0001628280-26-029401:mdna:21]
[same as prior period, unchanged from 0001628280-26-004407:mdna:27]

[0001628280-26-029401:mdna:22]
[same as prior period, unchanged from 0001628280-26-004407:mdna:28]

[0001628280-26-029401:mdna:23]
[same as prior period, unchanged from 0001628280-26-004407:mdna:29]

[0001628280-26-029401:mdna:24]
[same as prior period, unchanged from 0001628280-26-004407:mdna:30]

[0001628280-26-029401:mdna:25]
38

[0001628280-26-029401:mdna:26]
[same as prior period, unchanged from 0001628280-26-004407:mdna:31]

[0001628280-26-029401:mdna:27]
[same as prior period, unchanged from 0001628280-26-004407:mdna:32]

[0001628280-26-029401:mdna:28]
[same as prior period, unchanged from 0001628280-26-004407:mdna:33]

[0001628280-26-029401:mdna:29]
|  | Three Months Ended |
|  | April 3, 2026 |  | March 28, 2025 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 5,950 |  |  | 100.0 | % |  | $ | 1,695 |  |  | 100.0 | % |  | $ | 4,255 |  |  | 251 | % |
| Cost of revenue | 1,288 |  |  | 21.6 |  |  | 1,313 |  |  | 77.5 |  |  | (25) |  |  | (2) |  |
| Gross profit | 4,662 |  |  | 78.4 |  |  | 382 |  |  | 22.5 |  |  | 4,280 |  |  | 1120 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 337 |  |  | 5.7 |  |  | 285 |  |  | 16.8 |  |  | 52 |  |  | 18 |  |
| Selling, general and administrative | 161 |  |  | 2.7 |  |  | 139 |  |  | 8.2 |  |  | 22 |  |  | 16 |  |
| Goodwill impairment | — |  |  | — |  |  | 1,830 |  | 108.0 |  |  | (1,830) |  |  | (100) |  |
| Loss on debt extinguishment | 46 |  |  | 0.8 |  |  | — |  |  | — |  |  | 46 |  |  | 100 |  |
| Business separation costs | 7 |  |  | 0.1 |  |  | 9 |  |  | 0.5 |  |  | (2) |  |  | (22) |  |
| Total operating expenses | 551 |  |  | 9.3 |  |  | 2,263 |  |  | 133.5 |  |  | (1,712) |  |  | (76) |  |
| Operating income (loss) | 4,111 |  |  | 69.1 |  |  | (1,881) |  |  | (111.0) |  |  | 5,992 |  |  | (319) |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 12 |  |  | 0.2 |  |  | 6 |  |  | 0.4 |  |  | 6 |  |  | 100 |  |
| Interest expense | (6) |  |  | (0.1) |  |  | (16) |  |  | (0.9) |  |  | 10 |  |  | (63) |  |
| Other income (expense), net | (10) |  |  | (0.2) |  |  | (10) |  |  | (0.6) |  |  | — |  |  | — |  |
| Total interest and other income (expense), net | (4) |  |  | (0.1) |  |  | (20) |  |  | (1.1) |  |  | 16 |  |  | (80) |  |
| Income (loss) before taxes | 4,107 |  |  | 69.0 |  |  | (1,901) |  |  | (112.1) |  |  | 6,008 |  |  | (316) |  |
| Income tax expense | 492 |  |  | 8.3 |  |  | 32 |  |  | 1.9 |  |  | 460 |  |  | 1438 |  |
| Net income (loss) | $ | 3,615 |  |  | 60.7 |  |  | $ | (1,933) |  |  | (114.0) |  |  | 5,548 |  |  | (287) |  |

[0001628280-26-029401:mdna:30]
|  | Nine Months Ended |
|  | April 3, 2026 |  | March 28, 2025 |  | $ Change |  | % Change |
|  | (in millions, except percentages) |
| Revenue, net | $ | 11,283 |  |  | 100.0 | % |  | $ | 5,454 |  |  | 100.0 | % |  | $ | 5,829 |  |  | 107 | % |
| Cost of revenue | 4,393 |  |  | 38.9 |  |  | 3,740 |  |  | 68.6 |  |  | 653 |  |  | 17 |  |
| Gross profit | 6,890 |  |  | 61.1 |  |  | 1,714 |  |  | 31.4 |  |  | 5,176 |  |  | 302 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 980 |  |  | 8.7 |  |  | 847 |  |  | 15.5 |  |  | 133 |  |  | 16 |  |
| Selling, general and administrative | 479 |  |  | 4.2 |  |  | 411 |  |  | 7.5 |  |  | 68 |  |  | 17 |  |
| Goodwill impairment | — |  |  | — |  |  | 1,830 |  |  | 33.6 |  |  | (1,830) |  |  | (100) |  |
| Loss on debt extinguishment | 46 |  |  | 0.4 |  |  | — |  |  | — |  |  | 46 |  |  | 100 |  |
| Business separation costs | 25 |  |  | 0.2 |  |  | 50 |  |  | 0.9 |  |  | (25) |  |  | (50) |  |
| Employee termination and other | (2) |  |  | — |  |  | 5 |  |  | 0.1 |  |  | (7) |  |  | (140) |  |
| (Gain) loss on business divestiture | 10 |  |  | 0.1 |  |  | (34) |  |  | (0.6) |  |  | 44 |  |  | (129) |  |
| Total operating expenses | 1,538 |  |  | 13.6 |  |  | 3,109 |  |  | 57.0 |  |  | (1,571) |  |  | (51) |  |
| Operating income (loss) | 5,352 |  |  | 47.5 |  |  | (1,395) |  |  | (25.6) |  |  | 6,747 |  |  | (484) |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | 40 |  |  | 0.4 |  |  | 11 |  |  | 0.2 |  |  | 29 |  |  | 264 |  |
| Interest expense | (71) |  |  | (0.6) |  |  | (22) |  |  | (0.4) |  |  | (49) |  |  | 223 |  |
| Other income (expense), net | (153) |  |  | (1.4) |  |  | (55) |  |  | (1.0) |  |  | (98) |  |  | 178 |  |
| Total interest and other income (expense), net | (184) |  |  | (1.6) |  |  | (66) |  |  | (1.2) |  |  | (118) |  |  | 179 |  |
| Income (loss) before taxes | 5,168 |  |  | 45.9 |  |  | (1,461) |  |  | (26.8) |  |  | 6,629 |  |  | (454) |  |
| Income tax expense | 638 |  |  | 5.7 |  |  | 157 |  |  | 2.9 |  |  | 481 |  |  | 306 |  |
| Net income (loss) | $ | 4,530 |  |  | 40.2 |  |  | $ | (1,618) |  |  | (29.7) |  |  | 6,148 |  |  | (380) |  |

[0001628280-26-029401:mdna:31]
[same as prior period, unchanged from 0001628280-26-004407:mdna:37]

[0001628280-26-029401:mdna:32]
[same as prior period, unchanged from 0001628280-26-004407:mdna:38]

[0001628280-26-029401:mdna:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 1,467 |  |  | $ | 197 |  |  | $ | 2,176 |  |  | $ | 747 |  |
| Edge | 3,663 |  |  | 927 |  |  | 6,728 |  |  | 3,024 |  |
| Consumer | 820 |  |  | 571 |  |  | 2,379 |  |  | 1,683 |  |
| Total revenue | $ | 5,950 |  |  | $ | 1,695 |  |  | $ | 11,283 |  |  | $ | 5,454 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 4,272 |  |  | $ | 1,038 |  |  | $ | 7,850 |  |  | $ | 3,274 |  |
| Americas | 1,209 |  |  | 375 |  |  | 2,128 |  |  | 1,207 |  |
| Europe, Middle East and Africa | 469 |  |  | 282 |  |  | 1,305 |  |  | 973 |  |
| Total revenue | $ | 5,950 |  |  | $ | 1,695 |  |  | $ | 11,283 |  |  | $ | 5,454 |  |

[0001628280-26-029401:mdna:34]
[same as prior period, unchanged from 0001628280-26-004407:mdna:80]

[0001628280-26-029401:mdna:35]
[same as prior period, unchanged from 0001628280-26-004407:mdna:41]

[0001628280-26-029401:mdna:36]
Net revenue increased 251% in the three months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 248% increase in average selling prices (“ASP”) per gigabyte. The exabytes sold remained flat from the comparable period in the prior year.

[0001628280-26-029401:mdna:37]
Net revenue increased 107% in the nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 76% increase in ASP per gigabyte and an 18% increase in exabytes sold due to stronger demand for our data storage products.

[0001628280-26-029401:mdna:38]
Datacenter revenue increased 645% in the three months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 186% increase in ASP per gigabyte and a 160% increase in exabytes sold.

[0001628280-26-029401:mdna:39]
Datacenter revenue increased 191% in the nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 79% increase in exabytes sold and a 63% increase in ASP per gigabyte.

[0001628280-26-029401:mdna:40]
Edge revenue increased 295% in the three months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 343% increase in ASP per gigabyte, partially offset by a 10% decrease in exabytes sold.

[0001628280-26-029401:mdna:41]
Edge revenue increased 123% in the nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 99% increase in ASP per gigabyte and a 12% increase in exabytes sold.

[0001628280-26-029401:mdna:42]
Consumer revenue increased 44% in the three months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 139% increase in ASP per gigabyte, partially offset by a 40% decrease in exabytes sold.

[0001628280-26-029401:mdna:43]
Consumer revenue increased 41% in the nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to a 39% increase in ASP per gigabyte and a 2% increase in exabytes sold.

[0001628280-26-029401:mdna:44]
The changes in net revenue by geography in the three and nine months ended April 3, 2026 from the comparable period in the prior year primarily reflected higher revenue in the Asia and Americas regions from Edge and Datacenter customers.

[0001628280-26-029401:mdna:45]
Consistent with standard industry practice, we offer sales incentive and marketing programs that provide customers with price protection and other incentives or reimbursements that are recorded as a reduction to gross revenue. For the three months ended April 3, 2026 and March 28, 2025, these programs represented 12% and 19%, respectively, of gross revenues. For the nine months ended April 3, 2026 and March 28, 2025, these programs represented 13% and 19%, respectively, of gross revenues. The amounts attributed to our sales incentive and marketing programs generally vary according to several factors, including industry conditions, list pricing strategies, seasonal demand, competitor actions, channel mix and overall availability of products. Changes in future customer demand and market conditions may require us to adjust our incentive programs as a percentage of gross revenue.

[0001628280-26-029401:mdna:46]
[same as prior period, unchanged from 0001628280-26-004407:mdna:52]

[0001628280-26-029401:mdna:47]
Gross profit increased by $4,280 million and $5,176 million, respectively, for the three and nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to a higher ASP and an increase in exabytes sold.

[0001628280-26-029401:mdna:48]
Gross margin increased by 5,600 basis points and 3,000 basis points, respectively, for the three and nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to a higher ASP and an increase in exabytes sold.

[0001628280-26-029401:mdna:49]
The higher ASP was primarily driven by favorable pricing conditions in the industry. As a result, for the three and nine months ended April 3, 2026, the increase in ASP has outpaced the movement in costs per gigabyte.

[0001628280-26-029401:mdna:50]
[same as prior period, unchanged from 0001628280-26-004407:mdna:56]

[0001628280-26-029401:mdna:51]
Research and development (“R&D”) expenses increased $52 million in the three months ended April 3, 2026 from the comparable period in the prior year, primarily due to a $42 million increase in compensation and benefits due to variable compensation associated with company performance and increased headcount and a $5 million increase in stock-based compensation.

[0001628280-26-029401:mdna:52]
R&D expenses increased $133 million in the nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to an $88 million increase in compensation and benefits due to variable compensation associated with company performance and increased headcount, a $19 million increase in spending for R&D projects as we continue to invest in innovation and a $15 million increase in stock-based compensation.

[0001628280-26-029401:mdna:53]
Selling, general and administrative expenses increased $22 million in the three months ended April 3, 2026 from the comparable period in the prior year, primarily due to a $15 million increase in compensation and benefits, mainly due to variable compensation associated with company performance and increased headcount, and a $6 million increase in customer marketing engagements, offset by a $5 million decrease in materials due to a change in business practice for the launch of new products whereby the Company is distributing fewer free samples and has started entering into contracts to sell certain qualification units to customers. The costs of qualification units are recorded in inventory until sold to customers and recognized as cost of revenue. The change contributed to a decrease in materials and production costs classified as selling expenses when compared to the prior year period, partially offset by a $4 million increase in stock-based compensation.

[0001628280-26-029401:mdna:54]
Selling, general and administrative expenses increased $68 million in the nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to a $43 million increase in compensation and benefits and employee-related costs mainly due to variable compensation associated with company performance and an increase in headcount, offset by a $35 million decrease in materials due to a change in business practice for the launch of new products whereby the Company is distributing fewer free samples and has started entering into contracts to sell certain qualification units to customers. The costs of qualification units are recorded in inventory until sold to customers and recognized as cost of revenue. The change contributed to a decrease in materials and production costs classified as selling expenses when compared to the prior year period, partially offset by a $22 million increase in customer marketing engagements, a $16 million increase in stock-based compensation and a $9 million increase in outside service costs supporting operations.

[0001628280-26-029401:mdna:55]
Employee termination and other charges decreased $7 million in the nine months ended April 3, 2026 from the comparable period in the prior year as there were no restructuring actions taken in the current period.

[0001628280-26-029401:mdna:56]
Goodwill impairment

[0001628280-26-029401:mdna:57]
Goodwill impairment decreased $1.8 billion in the three and nine months ended April 3, 2026 from the comparable period in the prior year. In the three and nine months ended March 28, 2025, we recorded an impairment charge resulting from the difference between the carrying value of our reporting unit and its fair value in the prior year. No such impairment charge was incurred during the current year.

[0001628280-26-029401:mdna:58]
Loss on debt extinguishment

[0001628280-26-029401:mdna:59]
Loss on debt extinguishment increased $46 million in the three and nine months ended April 3, 2026 from the comparable period in the prior year due to the write-off of the remaining unamortized issuance costs in connection with the early settlement of the Company’s Term Loan Facility.

[0001628280-26-029401:mdna:60]
[same as prior period, unchanged from 0001628280-26-004407:mdna:63]

[0001628280-26-029401:mdna:61]
Business separation costs decreased $2 million in the three months ended April 3, 2026 from the comparable period in the prior year due to post-separation-related costs decreasing.

[0001628280-26-029401:mdna:62]
Business separation costs decreased $25 million in the nine months ended April 3, 2026 from the comparable period in the prior year due to post-separation-related costs decreasing.

[0001628280-26-029401:mdna:63]
[same as prior period, unchanged from 0001628280-26-004407:mdna:66]

[0001628280-26-029401:mdna:64]
(Gain) loss on business divestiture decreased $44 million in the nine months ended April 3, 2026 from the comparable period in the prior year as a result of the closing of the sale of SDSS on September 28, 2024 and an amendment to the Amended and Restated Equity Purchase Agreement with JCET, related to our prior sale of SDSS, in the current period that resulted in a loss. On September 25, 2025, SanDisk China and JCET entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support, resulting in a reduction of the September 28, 2025 installment payment from JCET. The Company recognized the adjustment as a loss on business divestiture for the nine months ended April 3, 2026, as discussed in Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies—Flash Ventures of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-26-029401:mdna:65]
[same as prior period, unchanged from 0001628280-26-004407:mdna:107]

[0001628280-26-029401:mdna:66]
Interest and Other Income (Expense), net

[0001628280-26-029401:mdna:67]
Interest and other income (expense), net decreased $16 million in the three months ended April 3, 2026 from the comparable period in the prior year, primarily due a decrease in interest expense from our Term Loan Facility, and the impairment of an investment, partially offset by an increase in interest income related to cash and investment accounts.

[0001628280-26-029401:mdna:68]
Interest and other income (expense), net increased $118 million in the nine months ended April 3, 2026 from the comparable period in the prior year, primarily due to the settlement of certain non-operating legal matters, an increase in interest expense from our Term Loan Facility, and the impairment of an investment, partially offset by an increase in interest income related to cash and investment accounts and a gain on sale of investment.

[0001628280-26-029401:mdna:69]
[same as prior period, unchanged from 0001628280-26-004407:mdna:72]

[0001628280-26-029401:mdna:70]
H.R. 1, more widely known as the One Big Beautiful Bill Act (“OBBBA”), was signed into law on July 4, 2025. It reversed the requirement for capitalization of U.S. research and development expenditures that came into law under the Tax Cuts and Jobs Act of 2017, but the mandatory requirement of capitalization of foreign research and development expenditures remains. The tax rates for income earned by our foreign subsidiaries will also be changed under H.R. 1, which applies to our fiscal years 2027 and onward. Depending on our operating results, these changes can materially impact our effective tax rate and operating cash flows. During the nine months ended April 3, 2026, we recorded a $10 million tax benefit in relation to the OBBBA’s impact on the Company’s 2025 tax provision.

[0001628280-26-029401:mdna:71]
[same as prior period, unchanged from 0001628280-26-004407:mdna:74]

[0001628280-26-029401:mdna:72]
On December 20, 2021, the Organisation for Economic Co-operation and Development G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two”). Pillar Two is currently effective in most of the jurisdictions in which we operate. Accordingly, these taxes are included in the Company’s Income tax expense for the three and nine months ended April 3, 2026.

[0001628280-26-029401:mdna:73]
[same as prior period, unchanged from 0001628280-26-004407:mdna:76]

[0001628280-26-029401:mdna:74]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |
|  | (in millions) |
| Income (loss) before taxes | $ | 4,107 |  |  | $ | (1,901) |  |  | $ | 5,168 |  |  | $ | (1,461) |  |
| Income tax expense | 492 |  |  | 32 |  |  | 638 |  |  | 157 |  |
| Effective tax rate | 12 | % |  | (2) | % |  | 12 | % |  | (11) | % |

[0001628280-26-029401:mdna:75]
The relative mix of earnings and losses by jurisdiction, credits and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the three and nine months ended April 3, 2026.

[0001628280-26-029401:mdna:76]
[same as prior period, unchanged from 0001628280-26-004407:mdna:79]

[0001628280-26-029401:mdna:77]
[same as prior period, unchanged from 0001628280-26-004407:mdna:81]

[0001628280-26-029401:mdna:78]
The following table summarizes our Condensed Consolidated Statements of Cash Flows for the periods ended April 3, 2026 and March 28, 2025:

[0001628280-26-029401:mdna:79]
|  | Nine Months Ended |
|  | April 3, 2026 |  | March 28, 2025 |
|  | (in millions) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 4,545 |  |  | $ | (10) |  |
| Investing activities | (263) |  |  | 573 |  |
| Financing activities | (2,025) |  |  | 620 |  |
| Effect of exchange rate changes on cash | (3) |  |  | (4) |  |
| Net increase in cash and cash equivalents | $ | 2,254 |  |  | $ | 1,179 |  |

[0001628280-26-029401:mdna:80]
In alignment with market conditions, we maintained what we believe to be a conservative capital expenditure strategy for fiscal year 2025. For fiscal year 2026, we increased our capital investments as we transition to newer nodes to meet the demand and technology needs of our product portfolio.

[0001628280-26-029401:mdna:81]
We believe our cash and cash equivalents will be sufficient to meet our working capital and, capital expenditure needs, as well as to fund any repurchases of our shares under the Repurchase Program, for at least the next twelve months and for the foreseeable future thereafter. We believe we can also access the various capital markets to further supplement our liquidity position if necessary. Our ability to sustain our working capital position is subject to a number of risks that we discuss under the heading “Risk Factors” included in Part I, Item 1A. Risk Factors included in our Annual Report on Form 10-K.

[0001628280-26-029401:mdna:82]
A total of $2,001 million and $692 million of our cash and cash equivalents were held outside of the U.S. as of April 3, 2026 and June 27, 2025, respectively. There are no material tax consequences that were not previously accrued for the repatriation of this cash. Our cash equivalents are primarily invested in money market funds that invest in U.S. Treasury securities and U.S. Government agency securities.

[0001628280-26-029401:mdna:83]
[same as prior period, unchanged from 0001628280-26-004407:mdna:87]

[0001628280-26-029401:mdna:84]
Net cash provided by operating activities primarily consists of net income or loss, adjusted for non-cash charges, plus or minus changes in operating assets and liabilities. Net cash used as a result of changes in operating assets and liabilities was $396 million in the nine months ended April 3, 2026, as compared to $436 million net cash used in the nine months ended March 28, 2025, reflecting an increase in the volume of our business, as discussed above.

[0001628280-26-029401:mdna:85]
[same as prior period, unchanged from 0001628280-26-004407:mdna:89]

[0001628280-26-029401:mdna:86]
|  | Three Months Ended |
|  | April 3, 2026 |  | March 28, 2025 |
| Days sales outstanding | 42 |  |  | 53 |  |
| Days in inventory | 158 |  |  | 150 |  |
| Days payable outstanding | (60) |  |  | (53) |  |
| Cash conversion cycle | 140 |  |  | 150 |  |

[0001628280-26-029401:mdna:87]
[same as prior period, unchanged from 0001628280-26-004407:mdna:91]

[0001628280-26-029401:mdna:88]
[same as prior period, unchanged from 0001628280-26-004407:mdna:128]

[0001628280-26-029401:mdna:89]
For the three months ended April 3, 2026, DSO decreased 11 days primarily due to higher revenue during the period and continued strong receivables collections. During the three months ended April 3, 2026, DIO increased 8 days over the three months ended March 28, 2025, primarily due to inventory builds to meet demand. DPO increased 7 days over the comparable period in the prior year, primarily due to routine variations in the timing of purchases and payments during the period.

[0001628280-26-029401:mdna:90]
[same as prior period, unchanged from 0001628280-26-004407:mdna:94]

[0001628280-26-029401:mdna:91]
Net cash used in investing activities in the nine months ended April 3, 2026 primarily consisted of $165 million in net issuances from activity related to Flash Ventures and $134 million in capital expenditures, partially offset by $25 million in net proceeds from our sale of a majority interest in one of our subsidiaries. Net cash provided by investing activities in the nine months ended March 28, 2025 primarily consisted of $401 million in net proceeds from our sale of a majority interest in one of our subsidiaries and $330 million in net proceeds from activity related to Flash Ventures, partially offset by $159 million in capital expenditures.

[0001628280-26-029401:mdna:92]
[same as prior period, unchanged from 0001628280-26-004407:mdna:96]

[0001628280-26-029401:mdna:93]
Net cash used in financing activities in the nine months ended April 3, 2026 primarily consisted of Term Loan Facility repayments totaling $1,900 million and $149 million of taxes paid on vested stock awards, partially offset by $24 million in stock issuances under employee stock plans. Net cash provided by financing activities in the nine months ended March 28, 2025 primarily consisted of $1,970 million in proceeds from borrowings from the Term Loan Facility, $550 million in proceeds from borrowings on notes due to WDC, and $101 million in proceeds from repayments on notes due from WDC, partially offset by $1,887 million transferred from WDC, $76 million in net repayments on notes due to WDC and a $32 million debt issuance discount.

[0001628280-26-029401:mdna:94]
[same as prior period, unchanged from 0001628280-26-004407:mdna:98]

[0001628280-26-029401:mdna:95]
Other than the Flash Ventures, SDSS and Nanya-related commitments incurred in the normal course of business and certain indemnification provisions (see “Short-and-Long-term Liquidity — Purchase Obligations and Other Commitments” below), we do not have any other material off-balance sheet financing arrangements or liabilities, guarantee contracts, retained or contingent interests in transferred assets, or any other obligations arising out of a material variable interest in an unconsolidated entity. We do not have any majority-owned subsidiaries that are not included in the Condensed Consolidated Financial Statements. Additionally, with the exception of Flash Ventures, the SDSS Venture, and the Unis Venture, we do not have an interest in, or relationships with, any variable interest entities. For additional information regarding our off-balance sheet arrangements, see Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-26-029401:mdna:96]
[same as prior period, unchanged from 0001628280-26-004407:mdna:100]

[0001628280-26-029401:mdna:97]
Material Cash Requirements as of April 3, 2026

[0001628280-26-029401:mdna:98]
The following is a summary of our known material cash requirements, including those for capital expenditures, as of April 3, 2026. In addition, see the discussions further below related to unrecognized tax benefits, foreign exchange contracts and indemnifications to address other material cash requirements discussed below that are not included in the table:

[0001628280-26-029401:mdna:99]
|  | Total |  | Remaining three months of 2026 |  | 2-3 Years (2027-2028) |  | 4-5 Years (2029-2030) |  | More than 5 Years (Beyond 2030) |
|  | (in millions) |
| Flash Ventures related commitments (1) | $ | 6,543 |  |  | $ | 1,072 |  |  | $ | 3,446 |  |  | $ | 1,725 |  |  | $ | 300 |  |
| Purchase obligations and other commitments | 4,970 |  |  | 32 |  |  | 2,236 |  |  | 2,610 |  |  | 92 |  |
| Investment commitment (2) | 972 |  |  | 972 |  |  | — |  |  | — |  |  | — |  |
| Operating leases | 308 |  |  | 10 |  |  | 66 |  |  | 49 |  |  | 183 |  |
| Total | $ | 12,793 |  |  | $ | 2,086 |  |  | $ | 5,748 |  |  | $ | 4,384 |  |  | $ | 575 |  |

[0001628280-26-029401:mdna:100]
(1) Includes Flash Ventures reimbursement for depreciation and lease payments on owned and committed equipment, funding commitments for loans and equity investments and payments for other committed expenses, including research and development and building depreciation and payments made directly to Kioxia in consideration for the manufacturing services and continued availability of supply. Funding commitments assume no additional operating lease guarantees. Additional operating lease guarantees can reduce funding commitments.

[0001628280-26-029401:mdna:101]
(2) On April 8, 2026, the Company satisfied its payment obligation under the Private Placement Subscription Agreement (the “Equity Investment Agreement”) with Nanya Technology Corporation (“Nanya”) by remitting the purchase price of $972 million to fully subscribe for 138,685,000 shares of Nanya, that were received on April 28, 2026, upon completion of the share issuance procedures, as set forth in the Equity Investment Agreement.

[0001628280-26-029401:mdna:102]
[same as prior period, unchanged from 0001628280-26-004407:mdna:108]

[0001628280-26-029401:mdna:103]
In connection with the separation, on February 21, 2025, the Company entered into a loan agreement comprised of a $1.5 billion revolving credit facility, which was undrawn at the separation date, and a $2.0 billion term loan facility (the “Term Loan Facility”) due in 2032. The Company used a portion of the proceeds received from the Term Loan Facility, as well as cash on hand, to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities and certain legal entities of WDC associated with the Company.

[0001628280-26-029401:mdna:104]
On March 4, 2026, the Company settled in full the remaining outstanding principal amounts of the Term Loan Facility, plus accrued interest, using cash on hand. In connection with the early settlement of the Term Loan Facility, the Company recognized a loss on debt extinguishment of $46 million resulting from the write-off of the remaining unamortized issuance costs.

[0001628280-26-029401:mdna:105]
As of April 3, 2026, the Company was in compliance with the loan agreement financial covenant that prohibits the Company from exceeding a maximum Leverage Ratio. Additional information regarding our indebtedness, including information about availability under our revolving credit facility and the principal repayment terms, interest rates, covenants, collateral and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Debt of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0001628280-26-029401:mdna:106]
[same as prior period, unchanged from 0001628280-26-004407:mdna:111]

[0001628280-26-029401:mdna:107]
Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements, of which we guarantee half of all of the outstanding obligations under each lease agreement. The leases are subject to customary covenants and cancellation events that relate to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of the lease obligations and a call on our guarantees. As of April 3, 2026, we were in compliance with all covenants under these Japanese lease facilities. See Part I, Item 1, Note 10, Related Parties and Related Commitments and Contingencies of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding Flash Ventures.

[0001628280-26-029401:mdna:108]
[same as prior period, unchanged from 0001628280-26-004407:mdna:113]

[0001628280-26-029401:mdna:109]
[same as prior period, unchanged from 0001628280-26-004407:mdna:114]

[0001628280-26-029401:mdna:110]
[same as prior period, unchanged from 0001628280-26-004407:mdna:115]

[0001628280-26-029401:mdna:111]
As of April 3, 2026, our liability for unrecognized tax benefits (excluding accrued interest and penalties) was approximately $253 million. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of April 3, 2026 and June 27, 2025 was $15 million and $11 million, respectively. Of these amounts, approximately $244 million could result in potential cash payments.

[0001628280-26-029401:mdna:112]
[same as prior period, unchanged from 0001628280-26-004407:mdna:117]

[0001628280-26-029401:mdna:113]
[same as prior period, unchanged from 0001628280-26-004407:mdna:118]

[0001628280-26-029401:mdna:114]
[same as prior period, unchanged from 0001628280-26-004407:mdna:119]

[0001628280-26-029401:mdna:115]
Concurrent with the separation, the Company and WDC entered into a Tax Matters Agreement under which the Company and WDC agreed to indemnify each other for certain tax positions. As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025, which was recognized as an adjustment to the Net investment from Western Digital Corporation. The remaining tax indemnification liability of $131 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of April 3, 2026.

[0001628280-26-029401:mdna:116]
46

[0001628280-26-029401:mdna:117]
[same as prior period, unchanged from 0001628280-26-004407:mdna:121]

[0001628280-26-029401:mdna:118]
[same as prior period, unchanged from 0001628280-26-004407:mdna:122]

[0001628280-26-029401:mdna:119]
Long-Term Agreements

[0001628280-26-029401:mdna:120]
In connection with entering into long-term agreements during the third quarter of fiscal 2026 with certain customers, we received customer advances that increased our available cash and cash equivalents. We record these customer payments as contract liabilities in advance of performance under the contract. As of April 3, 2026, our contract liabilities were $511 million, which primarily relates to the remaining performance obligations under these long-term agreements. See Part I, Item 1, Note 4, Revenue of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for information regarding our contract liabilities.

[0001628280-26-029401:mdna:121]
Share Repurchase Authorization

[0001628280-26-029401:mdna:122]
On April 30, 2026, we announced that our Board of Directors has approved a $6 billion (exclusive of fees and commissions) share repurchase program (the “Repurchase Program”). The acquisition of shares under the Repurchase Program may be effected from time to time through open market purchases (including under a plan adopted pursuant to Rule 10b5-1 promulgated under the Securities Exchange Act of 1934) or other methods of acquiring shares, in each case on such terms and at such times as shall be permitted by applicable securities laws and determined by our management. We expect shares repurchased under the Repurchase Program to be funded by operating cash flows.  The amount and timing of share repurchases will depend on market conditions and other relevant factors.  We may suspend or discontinue the Repurchase Program at any time. The approval of the Repurchase Program does not obligate us to repurchase any common shares.

[0001628280-26-029401:mdna:123]
[same as prior period, unchanged from 0001628280-26-004407:mdna:123]

[0001628280-26-029401:mdna:124]
[same as prior period, unchanged from 0001628280-26-004407:mdna:124]

[0001628280-26-029401:mdna:125]
[same as prior period, unchanged from 0001628280-26-004407:mdna:125]

[0001628280-26-029401:mdna:126]
[same as prior period, unchanged from 0001628280-26-004407:mdna:126]

[0001628280-26-029401:mdna:127]
There have been no material changes in our critical accounting policies and estimates from those disclosed in our Annual Report on Form 10-K, filed with the United States Securities and Exchange Commission for the year ended June 27, 2025.
