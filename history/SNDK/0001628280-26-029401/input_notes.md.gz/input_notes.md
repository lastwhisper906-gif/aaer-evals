# SNDK notes — 0001628280-26-029401


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-26-029401:notes:1]
[same as prior period, unchanged from 0001628280-26-004407:notes:1]

[0001628280-26-029401:notes:2]
Sandisk Corporation (“Sandisk” or the “Company”) is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, Sandisk’s broad and ever-expanding portfolio delivers powerful flash storage solutions for artificial intelligence (“AI”) workloads in datacenters, edge devices, and consumer applications. Sandisk’s technologies enable everyone from students, gamers, and home offices to the largest enterprises and public clouds to produce, analyze, and store data. The Company’s solutions include a broad range of solid-state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. The Company’s broad portfolio of technology and products addresses multiple end markets of “Datacenter” (formerly referred to as “Cloud”), “Edge” (formerly referred to as “Client”), and “Consumer.” The Company operates primarily in the United States (“U.S.”) and also internationally, with a significant concentration in the Asia Pacific region.

[0001628280-26-029401:notes:3]
[same as prior period, unchanged from 0001628280-26-004407:notes:3]

[0001628280-26-029401:notes:4]
[same as prior period, unchanged from 0001628280-26-004407:notes:4]

[0001628280-26-029401:notes:5]
[same as prior period, unchanged from 0001628280-26-004407:notes:5]

[0001628280-26-029401:notes:6]
Also on February 21, 2025, in connection with the separation, the Company entered into a $1.5 billion revolving credit facility, which was undrawn at the separation date, and a $2.0 billion term loan facility. The Company used a portion of the proceeds received from the term loan facility and cash on hand to make a net distribution payment of $1.5 billion to WDC in exchange for assets, liabilities, and certain legal entities of WDC associated with the Company. The remaining outstanding balance of the Company’s term loan facility was repaid in full on March 4, 2026.

[0001628280-26-029401:notes:7]
[same as prior period, unchanged from 0001628280-26-004407:notes:7]

[0001628280-26-029401:notes:8]
On June 9, 2025, WDC disposed of 21,314,768, or 14.6%, of the Company’s common stock through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. On February 18, 2026, WDC disposed of 5,821,135 outstanding shares of the Company through an exchange of Sandisk’s common stock for WDC debt held by WDC creditors, which shares were sold by affiliates of the WDC creditors in a registered public offering by the Company. All expenses for these offerings were paid for by the Company. Following this transaction, WDC continued to retain 1,691,884 of the outstanding shares of the Company’s common stock and, as of March 19, 2026, the sale of such shares is no longer subject to restriction.

[0001628280-26-029401:notes:9]
[same as prior period, unchanged from 0001628280-26-004407:notes:9]

[0001628280-26-029401:notes:10]
[same as prior period, unchanged from 0001628280-26-004407:notes:10]

[0001628280-26-029401:notes:11]
Reclassifications

[0001628280-26-029401:notes:12]
Certain prior period presentations in the Condensed Consolidated Financial Statements have been reclassified to conform to the current period presentation. These changes in presentation do not affect previously reported results.

[0001628280-26-029401:notes:13]
[same as prior period, unchanged from 0001628280-26-004407:notes:11]

[0001628280-26-029401:notes:14]
[same as prior period, unchanged from 0001628280-26-004407:notes:12]

[0001628280-26-029401:notes:15]
[same as prior period, unchanged from 0001628280-26-004407:notes:13]

[0001628280-26-029401:notes:16]
[same as prior period, unchanged from 0001628280-26-004407:notes:14]

[0001628280-26-029401:notes:17]
[same as prior period, unchanged from 0001628280-26-004407:notes:15]

[0001628280-26-029401:notes:18]
[same as prior period, unchanged from 0001628280-26-004407:notes:16]

[0001628280-26-029401:notes:19]
[same as prior period, unchanged from 0001628280-26-004407:notes:17]

[0001628280-26-029401:notes:20]
[same as prior period, unchanged from 0001628280-26-004407:notes:18]

[0001628280-26-029401:notes:21]
[same as prior period, unchanged from 0001628280-26-004407:notes:19]

[0001628280-26-029401:notes:22]
[same as prior period, unchanged from 0001628280-26-004407:notes:20]

[0001628280-26-029401:notes:23]
After the separation on February 21, 2025, the Company’s financial statements for the period from February 22, 2025 through April 3, 2026 are Condensed Consolidated Financial Statements based on the Company’s reported results as a standalone company. All transactions and accounts between controlled entities within the Company have been eliminated.

[0001628280-26-029401:notes:24]
Following the separation, certain functions continue to be provided by or for WDC for up to fifteen months under the TSA or are being performed using the Company’s own resources or third-party service providers. For the period ended April 3, 2026, charges under the TSA were not material.

[0001628280-26-029401:notes:25]
[same as prior period, unchanged from 0001628280-26-004407:notes:23]

[0001628280-26-029401:notes:26]
[same as prior period, unchanged from 0001628280-26-004407:notes:24]

[0001628280-26-029401:notes:27]
[same as prior period, unchanged from 0001628280-26-004407:notes:25]

[0001628280-26-029401:notes:28]
The Company’s fiscal year ends on the Friday nearest to June 30 and typically consists of 52 weeks. Approximately every five to six years, the Company reports a 53-week fiscal year to align the fiscal year with the foregoing policy. Fiscal year 2025, which ended on June 27, 2025, was comprised of 52 weeks, with all quarters consisting of 13 weeks. Fiscal year 2026 is comprised of 53 weeks and ends on July 3, 2026, with the first fiscal quarter consisting of 14 weeks. Unless otherwise indicated, references herein to specific years and quarters are to fiscal years and fiscal quarters, and references to financial information are on a condensed consolidated basis.

[0001628280-26-029401:notes:29]
[same as prior period, unchanged from 0001628280-26-004407:notes:27]

[0001628280-26-029401:notes:30]
[same as prior period, unchanged from 0001628280-26-004407:notes:28]

[0001628280-26-029401:notes:31]
The Chief Executive Officer, who is the CODM, evaluates the performance of the Company and makes resource allocation decisions for its single reportable operating segment based upon the Company’s condensed consolidated operating income (loss) and net income (loss). The CODM considers variances of actual performance to forecasted amounts of these profit measures when making decisions. Asset information is not used by the CODM to evaluate performance or allocate resources.

[0001628280-26-029401:notes:32]
[same as prior period, unchanged from 0001628280-26-004407:notes:30]

[0001628280-26-029401:notes:33]
[same as prior period, unchanged from 0001628280-26-004407:notes:31]

[0001628280-26-029401:notes:34]
[same as prior period, unchanged from 0001628280-26-004407:notes:32]

[0001628280-26-029401:notes:35]
[same as prior period, unchanged from 0001628280-26-004407:notes:33]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-26-029401:notes:36]
Recent Accounting Pronouncements
Accounting Pronouncements Recently Adopted

[0001628280-26-029401:notes:37]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands segment reporting requirements, primarily through enhanced disclosures surrounding significant segment expenses. This ASU expands on existing segment reporting requirements to require that a public entity disclose, on an annual and interim basis, significant segment expenses that are regularly provided to an entity’s CODM, a description of other segment items by reportable segment, and any additional measures of a segment’s profit or loss used by the CODM when deciding how to allocate resources. The Company adopted the guidance retrospectively in the fourth quarter of fiscal 2025. See Note 9, Segment Reporting, for additional disclosures.

[0001628280-26-029401:notes:38]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0001628280-26-029401:notes:39]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” This ASU calls for enhanced income tax disclosure requirements surrounding the tabular rate reconciliation and income taxes paid. The Company is currently compiling the information required for these disclosures. These incremental disclosures will be required beginning with the Company’s financial statements for the year ending July 3, 2026, with early adoption permitted. The Company expects to provide any required disclosures at that time.

[0001628280-26-029401:notes:40]
In November 2024, the FASB issued ASU 2024-03, “Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses,” which is intended to improve disclosures about the expenses of public entities. This ASU requires more detailed information about the types of expenses in commonly presented expense captions (such as cost of sales and selling, general and administrative expenses) and requires public entities to disclose, on an annual and interim basis, the amounts of expenses included in each relevant expense caption presented on the face of the income statement within continuing operations, in a tabular format. Additionally, public entities will be required to disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively, the total amount of selling expenses, and, in annual reporting periods, the definition of selling expenses. This ASU is effective on either a prospective or retrospective basis for fiscal years beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently compiling the information required for these disclosures and assessing the basis of adoption. The Company expects to provide any required disclosures for annual reporting periods included in the Company’s financial statements for the year ending June 30, 2028.

[0001628280-26-029401:notes:41]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software,” which is intended to modernize the accounting for software costs. The amendments eliminate references to software development project stages and introduce a new threshold for capitalization. This ASU requires an entity to start capitalizing software costs when both of the following occur: (i) management has authorized and committed to funding the software project and (ii) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the “probable-to-complete recognition threshold”). This ASU is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU in the Company’s financial statements. The ASU will be effective beginning with the Company’s financial statements for the year ending June 29, 2029.

[0001628280-26-029401:notes:42]
In December 2025, the FASB issued ASU 2025-10, “Accounting for Government Grants Received by Business Entities”, which is intended to clarify the accounting treatment for government grants received by business entities. This ASU establishes the accounting for a government grant received by a business entity, including guidance for a grant related to an asset and a grant related to income. This ASU also provides guidance on recognition, measurement and presentation of government grants received by a business entity. This ASU is effective for annual reporting periods beginning after December 15, 2028, and interim reporting periods within those annual reporting periods. The Company is currently assessing the impact of this ASU in the Company’s financial statements. This ASU will be effective beginning with the Company’s financial statements for the year ending June 28, 2030.

[0001628280-26-029401:notes:43]
In December 2025, the FASB issued ASU 2025-11, “Interim Reporting (Topic 270): Narrow-scope Improvements”. This ASU makes targeted, narrow-scope improvements to the interim reporting guidance to clarify application and to improve consistency in practice. The amendments do not change the underlying principles of interim reporting. This ASU is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU in the Company’s financial statements. The ASU will be effective beginning with the Company’s financial statements for the year ending June 29, 2029.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-26-029401:notes:44]
[same as prior period, unchanged from 0001628280-26-004407:notes:39]

[0001628280-26-029401:notes:45]
[same as prior period, unchanged from 0001628280-26-004407:notes:40]

[0001628280-26-029401:notes:46]
[same as prior period, unchanged from 0001628280-26-004407:notes:41]

[0001628280-26-029401:notes:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Revenue by end market: |  |  |  |  |  |  |  |
| Datacenter | $ | 1,467 |  |  | $ | 197 |  |  | $ | 2,176 |  |  | $ | 747 |  |
| Edge | 3,663 |  |  | 927 |  |  | 6,728 |  |  | 3,024 |  |
| Consumer | 820 |  |  | 571 |  |  | 2,379 |  |  | 1,683 |  |
| Total revenue | $ | 5,950 |  |  | $ | 1,695 |  |  | $ | 11,283 |  |  | $ | 5,454 |  |
| Revenue by geography: |  |  |  |  |  |  |  |
| Asia | $ | 4,272 |  |  | $ | 1,038 |  |  | $ | 7,850 |  |  | $ | 3,274 |  |
| Americas | 1,209 |  |  | 375 |  |  | 2,128 |  |  | 1,207 |  |
| Europe, Middle East and Africa | 469 |  |  | 282 |  |  | 1,305 |  |  | 973 |  |
| Total revenue | $ | 5,950 |  |  | $ | 1,695 |  |  | $ | 11,283 |  |  | $ | 5,454 |  |

[0001628280-26-029401:notes:48]
The Company’s top 10 customers accounted for 46% and 41% of its net revenue for the three and nine months ended April 3, 2026, respectively, and 41% and 43% of its net revenue for the three and nine months ended March 28, 2025, respectively. For the three months ended April 3, 2026, one customer accounted for more than 10% of the Company’s net revenue and for the three months ended March 28, 2025, a different customer accounted for more than 10% of the Company’s net revenue. For the nine months ended April 3, 2026 and March 28, 2025, no customer accounted for more than 10% of the Company’s net revenue.Revenue
Contract assets represent the Company’s right to consideration where performance obligations are completed but the customer payments are not due until another performance obligation is satisfied. The contract assets as of April 3, 2026 were not material and the Company had no contract assets as of June 27, 2025. Contract liabilities relate to customer payments in advance of performance under the contract and primarily include remaining performance obligations under long-term agreements. The contract liabilities as of June 27, 2025 were $25 million, of which $22 million were recognized as revenue during the nine months ended April 3, 2026. Total contract liabilities as of April 3, 2026 were $511 million. The increase in contract liabilities during the period was driven by customer advances associated with long‑term agreements entered into during the period.

[0001628280-26-029401:notes:49]
The Company incurs sales commissions as direct incremental costs to obtain sales contracts. The Company has applied the practical expedient to recognize sales commissions as an expense when incurred if the amortization period is expected to be one year or less, with these costs charged to Selling, general and administrative expenses. Direct incremental costs to obtain contracts with an expected benefit of more than one year were not material.

[0001628280-26-029401:notes:50]
As of April 3, 2026, the transaction price allocated to remaining performance obligations was $41.6 billion, of which $41.2 billion has not yet been billed and $0.4 billion has been recorded as contract liabilities. Approximately 15% of the remaining performance obligations from these contracts with customers are expected to be recognized as revenue over the next twelve months. The remaining performance obligations are mainly attributed to long-term agreements with customers. 
The Company applies the practical expedient and does not disclose the transaction price allocated to the remaining performance obligations for (i) arrangements with an original expected duration of one year or less, mainly consisting of sales of qualification units to customers, professional service, support, and maintenance contracts, and (ii) variable consideration for sale-based or usage-based royalties for intellectual property license arrangements, which typically range longer than one year.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-26-029401:notes:51]
[same as prior period, unchanged from 0001628280-26-004407:notes:46]

[0001628280-26-029401:notes:52]
[same as prior period, unchanged from 0001628280-26-004407:notes:47]

[0001628280-26-029401:notes:53]
|  | Goodwill |
|  | (in millions) |
| Balance at June 27, 2025 | $ | 4,999 |  |
| Impairment charges | — |  |
| Foreign currency translation adjustment | (5) |  |
| Balance at April 3, 2026 | $ | 4,994 |  |

[0001628280-26-029401:notes:54]
[same as prior period, unchanged from 0001628280-26-004407:notes:49]

[0001628280-26-029401:notes:55]
[same as prior period, unchanged from 0001628280-26-004407:notes:50]

[0001628280-26-029401:notes:56]
During the three and nine months ended March 28, 2025, the Company identified potential impairment indicators related to macroeconomic indicators, industry developments, the trading price of the Company’s common stock and resulting market capitalization that warranted a quantitative impairment analysis of long-lived assets and goodwill.

[0001628280-26-029401:notes:57]
In accordance with FASB ASC No. 360, “Property, Plant, and Equipment,” the Company performed a recoverability test at the asset group level, which was determined to be equivalent to its reporting unit to assess potential impairments of long-lived assets comprised of property, plant and equipment. The results of the recoverability test showed that the estimated undiscounted net cash flows to be generated from the use and eventual disposition of the Company’s long-lived assets exceeded its net carrying value. As a result, no write-down of depreciable long-lived assets was recognized as of March 28, 2025.

[0001628280-26-029401:notes:58]
In accordance with ASC No. 350, “Intangibles - Goodwill and Other,” the Company performed a quantitative test by measuring the fair value of its reporting unit based on a weighting of two valuation methodologies: an income approach and a market approach.

[0001628280-26-029401:notes:59]
The income approach valued the projected discounted cash flows that are expected to be generated by the Company’s reporting unit and required judgments and estimates surrounding general economic conditions and company-specific performance inputs such as revenue growth rates, gross margins, operating costs, capital expenditures, assumed tax rates and other assumptions deemed reasonable by management.

[0001628280-26-029401:notes:60]
The market approach valued the reporting unit based on financial performance and market multiples of comparable public companies, including consideration of a control premium representing the estimated amount a market participant would pay to obtain a controlling interest in the Company.

[0001628280-26-029401:notes:61]
The results of the quantitative test indicated that the carrying value of our reporting unit exceeded its estimated fair value, resulting in the recognition of a $1.8 billion goodwill impairment charge as of, and for the period ended, March 28, 2025, which was recorded in the accompanying Condensed Consolidated Statements of Operations.

[0001628280-26-029401:notes:62]
For the three and nine months ended April 3, 2026, the Company recorded no goodwill impairment charges.

[0001628280-26-029401:notes:63]
[same as prior period, unchanged from 0001628280-26-004407:notes:52]

[0001628280-26-029401:notes:64]
From time to time, in connection with factoring agreements, WDC sold certain of the Company’s trade accounts receivable without recourse to third-party purchasers in exchange for cash. During the three and nine months ended April 3, 2026, there were no trade accounts receivable sold by the Company. During the three and nine months ended March 28, 2025, there were no trade accounts receivable sold by the Company. There were no factored receivables outstanding as of April 3, 2026 or June 27, 2025.

[0001628280-26-029401:notes:65]
[same as prior period, unchanged from 0001628280-26-004407:notes:54]

[0001628280-26-029401:notes:66]
|  | April 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Inventories: |  |  |  |
| Raw materials and component parts | $ | 1,492 |  |  | $ | 1,517 |  |
| Work-in-process | 332 |  |  | 262 |  |
| Finished goods | 414 |  |  | 300 |  |
| Total inventories | $ | 2,238 |  |  | $ | 2,079 |  |

[0001628280-26-029401:notes:67]
[same as prior period, unchanged from 0001628280-26-004407:notes:56]

[0001628280-26-029401:notes:68]
|  | April 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Property, plant and equipment: |  |  |  |
| Land | $ | 10 |  |  | $ | 10 |  |
| Machinery and equipment | 1,522 |  |  | 1,480 |  |
| Buildings and improvements | 395 |  |  | 390 |  |
| Computer equipment and software | 168 |  |  | 176 |  |
| Furniture and fixtures | 17 |  |  | 18 |  |
| Construction-in-process | 60 |  |  | 51 |  |
| Property, plant and equipment, gross | 2,172 |  |  | 2,125 |  |
| Accumulated depreciation | (1,523) |  |  | (1,506) |  |
| Property, plant and equipment, net | $ | 649 |  |  | $ | 619 |  |

[0001628280-26-029401:notes:69]
[same as prior period, unchanged from 0001628280-26-004407:notes:58]

[0001628280-26-029401:notes:70]
[same as prior period, unchanged from 0001628280-26-004407:notes:59]

[0001628280-26-029401:notes:71]
|  |  |  |  |  | Product Warranty Liability |  |  |
|  |  |  |  |  | (in millions) |  |  |
| Balance at June 27, 2025 |  |  |  |  | $ | 44 |  |  |  |
| Charges to operations |  |  |  |  | 54 |  |  |  |
| Utilization |  |  |  |  | (21) |  |  |  |
| Changes in estimate related to pre-existing warranties |  |  |  |  | (4) |  |  |  |
| Balance at April 3, 2026 |  |  |  |  | $ | 73 |  |  |  |

[0001628280-26-029401:notes:72]
[same as prior period, unchanged from 0001628280-26-004407:notes:61]

[0001628280-26-029401:notes:73]
|  | April 3,2026 |  | June 27,2025 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty accrual: |  |  |  |  |  |  |  |  |  |
| Current portion | $ | 35 |  |  | $ | 22 |  |  |  |  |  |  |  |
| Long-term portion | 38 |  |  | 22 |  |  |  |  |  |  |  |
| Total warranty accrual | $ | 73 |  |  | $ | 44 |  |  |  |  |  |  |  |

[0001628280-26-029401:notes:74]
[same as prior period, unchanged from 0001628280-26-004407:notes:63]

[0001628280-26-029401:notes:75]
|  | April 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Other liabilities: |  |  |  |
| Non-current lease liability | $ | 182 |  |  | $ | 193 |  |
| Tax indemnification liability | 131 |  |  | 110 |  |
| Other non-current liabilities | 80 |  |  | 62 |  |
| Total other liabilities | $ | 393 |  |  | $ | 365 |  |

[0001628280-26-029401:notes:76]
In connection with, and at the time of, the separation, the Company recorded a $112 million liability to indemnify WDC as a result of the Tax Matters Agreement entered into between the parties in connection with the separation. The indemnification pertains to certain WDC tax positions where the underlying issues are determined to be related to the Company’s business before the spin-off. As WDC receives tax assessments, settles with tax authorities, or when the statute of limitations lapses, the indemnification liabilities will be reassessed and adjusted accordingly. The outstanding balance of the liability as of April 3, 2026 was $131 million.

[0001628280-26-029401:notes:77]
[same as prior period, unchanged from 0001628280-26-004407:notes:66]

[0001628280-26-029401:notes:78]
Accumulated other comprehensive loss (“AOCL”), net of tax, refers to expenses, gains, and losses that are recorded as an element of equity but are excluded from net income (loss). The components of AOCL were as follows:

[0001628280-26-029401:notes:79]
|  | Foreign Currency Translation Adjustment |  | Unrealized Income (Losses) on Derivative Contracts |  | Total Accumulated Comprehensive Loss |
|  | (in millions) |
| Balance at June 27, 2025 | $ | (202) |  |  | $ | (47) |  |  | $ | (249) |  |
| Other comprehensive income (loss) | (51) |  |  | 54 |  |  | 3 |  |
| Income tax expense related to items of other comprehensive income | — |  |  | (13) |  |  | (13) |  |
| Net current-period other comprehensive income (loss) | (51) |  |  | 41 |  |  | (10) |  |
| Balance at April 3, 2026 | $ | (253) |  |  | $ | (6) |  |  | $ | (259) |  |

[0001628280-26-029401:notes:80]
During the three and nine months ended April 3, 2026, the amounts reclassified out of AOCL were losses related to foreign exchange contracts, substantially all of which were charged to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0001628280-26-029401:notes:81]
As of April 3, 2026, substantially all existing net losses related to cash flow hedges recorded in AOCL are expected to be reclassified to earnings within the next twelve months.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-029401:notes:82]
[same as prior period, unchanged from 0001628280-26-004407:notes:70]

[0001628280-26-029401:notes:83]
[same as prior period, unchanged from 0001628280-26-004407:notes:71]

[0001628280-26-029401:notes:84]
[same as prior period, unchanged from 0001628280-26-004407:notes:72]

[0001628280-26-029401:notes:85]
[same as prior period, unchanged from 0001628280-26-004407:notes:73]

[0001628280-26-029401:notes:86]
[same as prior period, unchanged from 0001628280-26-004407:notes:74]

[0001628280-26-029401:notes:87]
[same as prior period, unchanged from 0001628280-26-004407:notes:75]

[0001628280-26-029401:notes:88]
|  | April 3, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents - Money market funds | $ | 1,836 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,836 |  |
| Foreign exchange contracts (included in Other current assets) | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Total assets at fair value | $ | 1,836 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 1,845 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange contracts (included in Accrued expenses) | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Total liabilities at fair value | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |

[0001628280-26-029401:notes:89]
[same as prior period, unchanged from 0001628280-26-004407:notes:77]

[0001628280-26-029401:notes:90]
[same as prior period, unchanged from 0001628280-26-004407:notes:78]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-26-029401:notes:91]
Derivative Instruments and Hedging Activities
As of April 3, 2026, the Company had outstanding foreign exchange forward contracts that were designated as non-designated hedges. Substantially all of the contract maturity dates of these foreign exchange forward contracts do not exceed twelve months.

[0001628280-26-029401:notes:92]
Changes in the fair values of any non-designated foreign exchange contracts are recognized in Other income (expense), net, and are largely offset by corresponding changes in the fair values of the foreign currency-denominated monetary assets and liabilities. For the three months ended April 3, 2026 and March 28, 2025, total net realized and unrealized transactions and foreign exchange contracts were a $2 million loss and an $8 million gain, respectively. For the nine months ended April 3, 2026 and March 28, 2025, total net realized and unrealized transactions and foreign exchange contracts were losses of $11 million and $17 million, respectively.
Unrealized gains or losses on any designated cash flow hedges are recognized in AOCL. For more information regarding cash flow hedges, see Note 5, Supplemental Financial Statement Data—Accumulated other comprehensive loss for additional disclosures.


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-029401:notes:93]
Debt
Loan Agreement

[0001628280-26-029401:notes:94]
Debt consisted of the following:

[0001628280-26-029401:notes:95]
|  | April 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Variable interest rate Term Loan Facility maturing 2032 | $ | — |  |  | $ | 1,900 |  |
| $1.5B Revolving Credit Facility maturing 2030 | — |  |  | — |  |
| Total debt | — |  |  | 1,900 |  |
| Unamortized issuance costs | — |  |  | 51 |  |
| Subtotal | — |  |  | 1,849 |  |
| Less: Current portion of long-term debt | — |  |  | 20 |  |
| Long term debt | $ | — |  |  | $ | 1,829 |  |

[0001628280-26-029401:notes:96]
On February 21, 2025, the Company entered into a Loan Agreement (the “Loan Agreement”) by and among the Company, the lenders party thereto, JPMorgan Chase Bank, N.A., as administrative agent and collateral agent, and the other parties party thereto. The Loan Agreement comprised a term loan B facility in the principal amount of $2.0 billion (the “Term Loan Facility”) and a revolving credit facility in the principal amount of $1.5 billion (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”).

[0001628280-26-029401:notes:97]
The obligations under the Loan Agreement are guaranteed by the Company’s wholly-owned subsidiary, Sandisk Technologies, Inc. (“SDT”), and are required to be guaranteed by any of the Company’s future material U.S. wholly-owned subsidiaries, subject to certain exceptions outlined in the Loan Agreement. The obligations under the Loan Agreement are secured by the Company’s assets and SDT’s assets and are required to be secured by the assets of any of the Company’s future material U.S. wholly-owned subsidiaries, subject, in each case, to certain exceptions outlined in the Loan Agreement.

[0001628280-26-029401:notes:98]
The Loan Agreement includes certain restrictions (subject to certain exceptions outlined in the Loan Agreement) on the ability of the Company and its subsidiaries to undertake certain activities, including to incur indebtedness and liens, merge or consolidate with other entities, dispose of or transfer their assets, pay dividends or make distributions, make investments, make payments on junior or subordinated debt, enter into burdensome agreements, or transact with affiliates. The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement).

[0001628280-26-029401:notes:99]
On February 21, 2025, the Company borrowed $2.0 billion under its Term Loan Facility. The Company used a portion of the proceeds of the borrowing to make a net distribution payment of $1.5 billion to WDC, with the remainder to be used for general corporate purposes of the Company. The Revolving Credit Facility may be borrowed by the Company from time to time for general corporate purposes.

[0001628280-26-029401:notes:100]
In connection with the Loan Agreement, the Company and SDT entered into a security agreement to secure the obligations under the Facilities on a first-priority basis (subject to permitted liens) by a lien on substantially all the assets and properties of the Company and SDT, subject to certain exceptions.

[0001628280-26-029401:notes:101]
In connection with the Loan Agreement, the Company (solely with respect to obligations of any additional Borrower under the Loan Agreement) and SDT entered into a guaranty agreement to secure and unconditionally guarantee the obligations under the Loan Agreement, respectively, in each case, subject to certain exceptions.

[0001628280-26-029401:notes:102]
Term Loan Facility

[0001628280-26-029401:notes:103]
The Term Loan Facility bore interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement) plus an interest rate margin of 3.00% per annum or (y) a base rate plus an interest rate margin of 2.00% per annum.

[0001628280-26-029401:notes:104]
The outstanding principal balance of the Term Loan Facility was required to be repaid in quarterly installments that began on June 27, 2025, in an aggregate amount equal to 0.25% of the aggregate principal amount of the Term Loan Facility. A final payment comprised of all principal and interest was due and payable at maturity on February 20, 2032.

[0001628280-26-029401:notes:105]
On March 4, 2026, the Company settled in full the remaining principal amounts due on the Term Loan Facility, plus accrued interest, using cash on hand. In connection with the early settlement of the Term Loan Facility, the Company recognized a loss on debt extinguishment of $46 million resulting from the write-off of the remaining unamortized issuance costs at settlement.

[0001628280-26-029401:notes:106]
Revolving Credit Facility

[0001628280-26-029401:notes:107]
Borrowings under the Revolving Credit Facility, for U.S. dollar borrowings, will bear interest, at the Company’s option, at (x) the Adjusted Term SOFR Rate (as defined in the Loan Agreement), which rate includes a credit spread adjustment of 0.10%, plus an interest rate margin of 2.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)), or (y) a base rate plus an interest rate margin of 1.00% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)). The Company pays a commitment fee of 0.30% per annum (subject to step-ups based on the Company’s Leverage Ratio (as defined in the Loan Agreement)) in respect of undrawn revolving commitments under the Revolving Credit Facility. The Revolving Credit Facility will also provide for borrowings in Euros, Japanese yen, and additional currencies agreed to by the lenders under the Revolving Credit Facility. The Revolving Credit Facility will mature on February 21, 2030, at which time the commitments thereunder shall be terminated and will not have any amortization.

[0001628280-26-029401:notes:108]
In connection with the establishment of the Revolving Credit Facility, the Company recognized deferred costs, classified as Other non-current assets of $8 million, which are amortized to Interest expense over the life of the facility.

[0001628280-26-029401:notes:109]
The Loan Agreement also includes a financial covenant, which is solely for the benefit of the lenders under the Revolving Credit Facility, that prohibits the Company from exceeding a maximum Leverage Ratio (as defined in the Loan Agreement). As of April 3, 2026, the Company was in compliance with the financial covenant.

[0001628280-26-029401:notes:110]
As of April 3, 2026, the Company had no outstanding standby letters of credit, and the available capacity under the Revolving Credit Facility was $1.5 billion.

[0001628280-26-029401:notes:111]
Interest expense and amortization of issuance costs
For the three months ended April 3, 2026, interest expense was $4 million and amortization of issuance costs was $2 million. For the nine months ended April 3, 2026, interest expense was $63 million and amortization of issuance costs was $6 million. For the three and nine months ended March 28, 2025, interest expense was $15 million and amortization of issuance costs was $1 million.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-029401:notes:112]
Segment Reporting
The following table presents the revenue, segment cost of revenue, significant segment expenses, and other segment items that are reflected in operating income (loss) of the Company’s reportable operating segment under its internal management reporting system, along with a reconciliation to consolidated net income (loss). This presentation aligns with how the CODM reviews financial information, using both operating income (loss) and net income (loss) to evaluate performance and allocate resources.

[0001628280-26-029401:notes:113]
In the financial information presented below, Segment cost of revenue, Segment research and development and Segment selling, general and administrative consist of Cost of revenue, Research and development and Selling, general and administrative, respectively, as reported in the Company’s Condensed Consolidated Statement of Operations, less stock-based compensation costs allocated to those captions. Additional significant segment expenses include Stock-based compensation and Goodwill impairment. Other segment items includes Loss on debt extinguishment, Business separation costs, Employee termination and other, Loss on business divestiture, and in past comparative periods, Gain on business divestiture.

[0001628280-26-029401:notes:114]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Revenue | $ | 5,950 |  |  | $ | 1,695 |  |  | $ | 11,283 |  |  | $ | 5,454 |  |
| Segment cost of revenue | (1,284) |  |  | (1,310) |  |  | (4,380) |  |  | (3,728) |  |
| Segment research and development | (312) |  |  | (265) |  |  | (905) |  |  | (787) |  |
| Segment selling, general and administrative | (136) |  |  | (118) |  |  | (402) |  |  | (350) |  |
| Stock-based compensation | (54) |  |  | (44) |  |  | (165) |  |  | (133) |  |
| Goodwill impairment | — |  |  | (1,830) |  |  | — |  |  | (1,830) |  |
| Other segment items | (53) |  |  | (9) |  |  | (79) |  |  | (21) |  |
| Operating income (loss) | 4,111 |  |  | (1,881) |  |  | 5,352 |  |  | (1,395) |  |
| Total interest and other income (expense), net | (4) |  |  | (20) |  |  | (184) |  |  | (66) |  |
| Income tax expense | (492) |  |  | (32) |  |  | (638) |  |  | (157) |  |
| Net income (loss) | $ | 3,615 |  |  | $ | (1,933) |  |  | $ | 4,530 |  |  | $ | (1,618) |  |


## sndk:RelatedPartiesAndRelatedCommitmentsAndContingenciesTextBlock

[0001628280-26-029401:notes:115]
Related Parties and Related Commitments and Contingencies 
Flash Ventures

[0001628280-26-029401:notes:116]
The Company procures substantially all of its flash-based memory wafers from its business ventures with Kioxia Corporation (“Kioxia”), which consists of three separate legal entities: Flash Partners Ltd. (“Flash Partners”), Flash Alliance Ltd. (“Flash Alliance”) and Flash Forward Ltd. (“Flash Forward”), collectively referred to as “Flash Ventures.”

[0001628280-26-029401:notes:117]
The following table presents the notes receivable from, and equity investments in, Flash Ventures for the periods presented:

[0001628280-26-029401:notes:118]
|  | April 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Notes receivable, Flash Partners | $ | 4 |  |  | $ | 7 |  |
| Notes receivable, Flash Alliance | 8 |  |  | 36 |  |
| Notes receivable, Flash Forward | 471 |  |  | 316 |  |
| Investment in Flash Partners | 30 |  |  | 55 |  |
| Investment in Flash Alliance | 98 |  |  | 115 |  |
| Investment in Flash Forward | 73 |  |  | 125 |  |
| Total notes receivable and investments in Flash Ventures | $ | 684 |  |  | $ | 654 |  |

[0001628280-26-029401:notes:119]
During the three and nine months ended April 3, 2026, the Company made net payments to Flash Ventures of $0.9 billion and $2.7 billion, respectively, for purchases of flash-based memory wafers and net loans. During the three and nine months ended March 28, 2025, the Company made net payments to Flash Ventures of $0.9 billion and $2.9 billion, respectively, for purchases of flash-based memory wafers and net loans. In addition, during the nine months ended April 3, 2026, the Company received a $15 million dividend distribution from Flash Ventures.

[0001628280-26-029401:notes:120]
The Company makes, or will make, loans to Flash Ventures to fund equipment investments for new process technologies and additional wafer capacity. The Company aggregates its Flash Ventures’ notes receivable into one class of financing receivables due to the similar ownership interest and common structure in each Flash Ventures entity. For all reporting periods presented, no loans were past due, and no loan impairments were recorded. The Company’s notes receivable from each Flash Ventures entity, denominated in Japanese yen, are secured by equipment owned by that Flash Ventures entity.

[0001628280-26-029401:notes:121]
As of April 3, 2026 and June 27, 2025, the Company had accounts payable balances due to Flash Ventures of $305 million and $279 million, respectively.

[0001628280-26-029401:notes:122]
The Company’s maximum reasonably estimable loss exposure (excluding lost profits) as a result of its involvement with Flash Ventures, based upon the Japanese yen to U.S. dollar exchange rate at April 3, 2026, is presented below. Investments in Flash Ventures are denominated in Japanese yen, and the maximum estimable loss exposure excludes any cumulative translation adjustment due to translation from the Japanese yen to the U.S. dollar.

[0001628280-26-029401:notes:123]
|  | April 3,2026 |
|  | (in millions) |
| Notes receivable | $ | 483 |  |
| Equity investments | 201 |  |
| Operating lease guarantees | 993 |  |
| Inventory and prepayments | 1,290 |  |
| Maximum estimable loss exposure | $ | 2,967 |  |

[0001628280-26-029401:notes:124]
The Company is obligated to pay for variable costs incurred by Flash Ventures in producing the Company’s share of Flash Ventures’ flash-based memory wafer supply, based on its rolling three-month forecast. The Company’s share generally equals 50% of Flash Ventures’ output. In addition, the Company is obligated to pay for half of Flash Ventures’ fixed costs regardless of the output the Company chooses to purchase. The Company cannot estimate its total wafer purchase commitment obligation beyond its rolling three-month purchase commitment because the price is determined by reference to the future cost of producing the semiconductor wafers. In addition, the Company is committed to fund 49.9% to 50.0% of each Flash Ventures entity’s capital investments to the extent that the Flash Ventures entity’s operating cash flow is insufficient to fund these investments.

[0001628280-26-029401:notes:125]
Flash Ventures has historically operated at nearly 100% of its manufacturing capacity. During the nine months ended April 3, 2026, the Company temporarily reduced its utilization of its share of Flash Ventures’ manufacturing capacity. During the nine months ended April 3, 2026 and three and nine months ended March 28, 2025, the Company incurred costs of $11 million and $24 million, respectively, associated with the reduction in utilization related to Flash Ventures, which were recorded as charges to Cost of revenue. No such charges were incurred during the three months ended April 3, 2026.

[0001628280-26-029401:notes:126]
The Company has facility agreements with Kioxia related to the construction and operation of Kioxia’s 300-millimeter wafer fabrication facility in Kitakami, Japan, referred to as “K1”, a wafer fabrication facility in Yokkaichi, Japan, referred to as “Y7”, and a wafer fabrication facility in Kitakami, Japan, referred to as “K2”. In connection with the construction of these facilities, the Company makes prepayments toward Kioxia’s future building depreciation. In connection with the start-up of the K1, Y7 and K2 facilities, the Company has made prepayments over time, and as of April 3, 2026, $856 million, with $131 million recorded within Other current assets and $725 million recorded within Other non-current assets in the Condensed Consolidated Balance Sheets, remain to be credited against future building depreciation charges and ultimately released within Cost of revenue when the Company’s inventory is sold. As of April 3, 2026, the Company is also committed to making additional building depreciation prepayments of $373 million, based on the Japanese yen to U.S. dollar exchange rate of ¥159.50 as of such date, payable as follows: $17 million for the remainder of fiscal year 2026, $119 million in fiscal year 2027, $174 million in fiscal year 2028 and $63 million in fiscal year 2029. As of April 3, 2026, in addition to the requirements to make building depreciation prepayments, the Company will also make payments for building depreciation of approximately $104 million at varying dates through fiscal year 2034.

[0001628280-26-029401:notes:127]
On January 29, 2026, Sandisk entered into an FAL Second Commitment and Extension Agreement (the “FAL Second Extension Agreement”) by and among Sandisk, Kioxia, SanDisk LLC (“SanDisk LLC”), and SanDisk (Ireland) Limited (“SanDisk Ireland”), under which the parties thereto extended the term of Flash Alliance from December 31, 2029 to December 31, 2034.

[0001628280-26-029401:notes:128]
On January 29, 2026, Sandisk entered into an FPL Second Commitment and Extension Agreement (the “FPL Second Extension Agreement”, and together with the FAL Second Extension Agreement, collectively, the “Extension Agreements”) by and among Sandisk, Kioxia, SanDisk LLC, and SanDisk (Cayman) Limited (“SanDisk Cayman”), under which the parties thereto extended the term of Flash Partners from December 31, 2029 to December 31, 2034.

[0001628280-26-029401:notes:129]
Following the execution of the Extension Agreements, all three of the joint ventures that comprise the Flash Ventures are scheduled to co-terminate on December 31, 2034.

[0001628280-26-029401:notes:130]
In connection with the Extension Agreements, on January 29, 2026, Sandisk entered into an Agreement to Enhance Collaboration by and among Sandisk, Kioxia, Sandisk Technologies, Inc. (“Sandisk Technologies”), SanDisk LLC, SanDisk Ireland and SanDisk Cayman, under which Sandisk Technologies will make certain payments directly to Kioxia totaling $1.2 billion over the years 2026 through 2029 in consideration of Kioxia’s manufacturing services and the continued availability of supply, from execution through December 31, 2034.

[0001628280-26-029401:notes:131]
Inventory Purchase Commitments with Flash Ventures. Purchase orders placed with Flash Ventures for up to three months are binding and cannot be canceled.

[0001628280-26-029401:notes:132]
Research and Development Activities. The Company participates in common research and development (“R&D”) activities with Kioxia and is contractually committed to a minimum funding level. R&D commitments due for the remaining three months of 2026 are $42 million.

[0001628280-26-029401:notes:133]
Off-Balance Sheet Liabilities. Flash Ventures sells to, and leases back from, a consortium of financial institutions a portion of its tools and has entered into equipment lease agreements of which the Company guarantees half of all of the outstanding obligations under each lease agreement. The lease agreements are subject to customary covenants and cancellation events related to Flash Ventures and each of the guarantors. The occurrence of a cancellation event could result in an acceleration of Flash Ventures’ obligations and a call on the Company’s guarantees.

[0001628280-26-029401:notes:134]
The following table presents the Company’s portion of the remaining guarantee obligations under the Flash Ventures’ lease facilities in both Japanese yen and U.S. dollar-equivalent, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2026:

[0001628280-26-029401:notes:135]
|  | Lease Amounts |
|  | (Japanese yen, in billions) |  | (U.S. dollar, in millions) |
| Total guarantee obligations | ¥ | 158 |  |  | $ | 993 |  |

[0001628280-26-029401:notes:136]
The following table details the components of the Company’s remaining guarantee obligations between the principal amortization and the purchase option exercise price at the end of the term of the Flash Ventures lease agreements, in annual installments, in U.S. dollars, based upon the Japanese yen to U.S. dollar exchange rate as of April 3, 2026:

[0001628280-26-029401:notes:137]
| Annual Installments | Payment of Principal Amortization |  | Purchase Option Exercise Price at Final Lease Terms |  | Guarantee Amount |
|  | (in millions) |
| 2026 | $ | 89 |  |  | $ | 18 |  |  | $ | 107 |  |
| 2027 | 276 |  |  | 95 |  |  | 371 |  |
| 2028 | 147 |  |  | 92 |  |  | 239 |  |
| 2029 | 70 |  |  | 49 |  |  | 119 |  |
| 2030 | 33 |  |  | 57 |  |  | 90 |  |
| 2031 | 5 |  |  | 62 |  |  | 67 |  |
| Total guarantee obligations | $ | 620 |  |  | $ | 373 |  |  | $ | 993 |  |

[0001628280-26-029401:notes:138]
The Company and Kioxia have agreed to mutually contribute to and indemnify each other and Flash Ventures for environmental remediation costs or liabilities resulting from Flash Ventures’ manufacturing operations in certain circumstances. The Company has not made any indemnification payments nor recorded any indemnification receivables under any such agreements. As of April 3, 2026, no amounts have been accrued in the Condensed Consolidated Financial Statements with respect to these indemnification agreements.

[0001628280-26-029401:notes:139]
Sale of a Majority Interest in a Subsidiary

[0001628280-26-029401:notes:140]
In March 2024, SanDisk China Limited (“SanDisk China”), an indirect wholly-owned subsidiary of WDC, entered into an equity purchase agreement to sell 80% of its equity interest in SanDisk Semiconductor (Shanghai) Co. Ltd. (“SDSS”), an indirect wholly-owned subsidiary of WDC which holds one of the Company’s manufacturing facilities, to JCET Management Co., Ltd. (“JCET”), a wholly-owned subsidiary of JCET Group Co., Ltd., a Chinese publicly-listed company, thereby forming a venture between SanDisk China and JCET (the “Transaction”). The venture aims to provide independent semiconductor assembly, testing, and other related services in the People’s Republic of China for customers including, but not limited to, the Company and its affiliates.

[0001628280-26-029401:notes:141]
The Transaction closed on September 28, 2024, and SanDisk China completed the sale of 80% of its equity interest in SDSS to JCET. The Transaction resulted in a pre-tax gain of $34 million, calculated as the difference between the total consideration for the sale, including the outstanding consideration receivable and the fair value of the Company’s 20% retained interest, less the carrying value of the net assets divested, which included, among other items, $71 million of cash and cash equivalents and $382 million of goodwill that was allocated to SDSS.

[0001628280-26-029401:notes:142]
Proceeds from the sale, including working capital adjustments, were $659 million (pre-tax). On October 1, 2024, the Company received an initial pre-tax installment of $262 million. On January 6, 2025, the Company received a second pre-tax installment of $210 million. The remaining $187 million pre-tax proceeds are payable in five equal installments of approximately $37 million on September 28 of each year through September 28, 2029.

[0001628280-26-029401:notes:143]
On September 25, 2025, SanDisk China and JCET entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support, resulting in a reduction of the September 28, 2025 installment payment from JCET to $27 million. The Company recognized the adjustment as a Loss on business divestiture for the nine months ended April 3, 2026.

[0001628280-26-029401:notes:144]
As of April 3, 2026, the outstanding consideration receivable was recognized at its present value of $138 million, with $37 million classified as Other current assets and $101 million classified as Other non-current assets in the Condensed Consolidated Balance Sheets. The remaining present value discount of $13 million as of April 3, 2026 will be recognized using the effective interest method over the next four years as Interest income in the Condensed Consolidated Statements of Operations.

[0001628280-26-029401:notes:145]
The Company’s 20% retained interest in SDSS was determined to be valued at $158 million based on the fair value of the total pre-tax consideration received and receivable from JCET for its purchase of its 80% interest in SDSS. The Company accounts for its 20% interest in SDSS as an equity method investment within Other non-current assets in the Condensed Consolidated Balance Sheets. The Company’s 20% interest in the earnings of SDSS is recognized one quarter in arrears and is reported in Other income (expense), net in the Condensed Consolidated Statements of Operations. As of April 3, 2026, the 20% retained interest in SDSS was valued at $166 million.

[0001628280-26-029401:notes:146]
Subsequent to and in connection with the Transaction, Western Digital Technologies, Inc. (“WDT,” a WDC affiliate) entered into a five-year supply agreement with SDSS (the “Supply Agreement”) to purchase certain flash-based products with a minimum annual commitment of $550 million (the “minimum annual commitment”). On January 10, 2025, the Company and WDT entered into an assignment agreement, pursuant to which WDT assigned all of its rights and obligations under the Supply Agreement to the Company. The Supply Agreement contains specific penalties the Company must pay if it fails to meet its minimum annual commitment. The Supply Agreement also provides that if the Company’s purchases exceed the minimum annual commitment in any of the two years immediately succeeding any annual period where a shortfall penalty has been paid, SDSS shall reimburse the Company an amount not exceeding the previously paid penalty amount. The Supply Agreement expires on September 28, 2029, and automatically renews for additional one-year terms unless earlier terminated by either of the parties. The Company also entered into an agreement to grant SDSS certain intellectual property rights on a royalty-free basis for use in manufacturing products on the Company’s behalf for the term of and under the Supply Agreement. For the three and nine months ended April 3, 2026, the Company made purchases of $112 million and $390 million, respectively, under the Supply Agreement. For the three and nine months ended March 28, 2025, the Company made purchases of $108 million and $219 million, respectively, under the Supply Agreement. As of April 3, 2026 and March 28, 2025, the Company had a $130 million and $112 million accounts payable balance due to SDSS, respectively.

[0001628280-26-029401:notes:147]
The Company also entered into an arrangement to provide certain transition services for a limited period following the closing of the Transaction. Charges under this arrangement were not material.

[0001628280-26-029401:notes:148]
Unis Venture

[0001628280-26-029401:notes:149]
On January 24, 2025, the Company and WDC entered into an equity transfer agreement (the “Equity Transfer Agreement”) to transfer WDC’s entire equity interest in its venture with Unisplendour Corporation Limited and Unissoft (Wuxi) Group Co. Ltd. (“Unis”), referred to as the “Unis Venture”, to the Company. The Unis Venture is 48% owned by the Company and 52% owned by Unis. The Unis Venture markets and sells the Company’s products in China and develops data storage systems for the Chinese market.

[0001628280-26-029401:notes:150]
Prior to the execution of the Equity Transfer Agreement, the Unis Venture was not historically managed as a component of the Company and, as such, the related equity method investment was not reflected within the Company’s Condensed Consolidated Financial Statements. After the execution of the Equity Transfer Agreement, the Company accounts for its investment in the Unis Venture under the equity method of accounting. The Company’s 48% interest in the earnings of the Unis Venture will be recognized one quarter in arrears from the date the Unis Venture was transferred to the Company and will be reported in Other income (expense), net in the Condensed Consolidated Statements of Operations.

[0001628280-26-029401:notes:151]
Revenue from products distributed by the Unis Venture is recognized upon sell-through to third-party customers. For the three and nine months ended April 3, 2026, the Company recognized approximately 3% and 2%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. For the three and nine months ended March 28, 2025, the Company recognized approximately 1% and 1%, respectively, of its condensed consolidated revenue on products distributed by the Unis Venture. The outstanding accounts receivable due from the Unis Venture were 5% and 1% of Accounts receivable, net, as of April 3, 2026 and June 27, 2025, respectively.

[0001628280-26-029401:notes:152]
Related Party Transactions

[0001628280-26-029401:notes:153]
Separation and Distribution Agreement and Other Related Party Transactions with WDC

[0001628280-26-029401:notes:154]
As described in Note 1, Organization and Basis of Presentation, on February 21, 2025, in connection with the separation, the Company entered into several agreements that provide a framework for Sandisk’s relationship with WDC after the separation. These include, but are not limited to, the following:

[0001628280-26-029401:notes:155]
•Separation and Distribution Agreement - The separation and distribution agreement contains key provisions related to the separation of the Company from WDC, including the transfer of assets and assumptions of liabilities. In connection with this agreement, certain assets and liabilities included in the Company’s Condensed Consolidated Balance Sheets were retained by WDC and certain assets and liabilities not included in the Company’s Condensed Consolidated Balance Sheets were transferred to the Company as of the date of the separation.

[0001628280-26-029401:notes:156]
As of quarter end April 3, 2026, the separation between the Company and WDC has been finalized, and no separation-related adjustments have been, or are expected to be, incurred going forward.

[0001628280-26-029401:notes:157]
•Employee Matters Agreement - The Employee Matters Agreement allocates liabilities and responsibilities relating to employment matters, employee compensation and benefit plans and programs and other related matters. Pursuant to this agreement, during the nine months ended April 3, 2026, the Company received reimbursement of short-term employee incentives totaling $22 million from WDC. The Company did not receive any reimbursements from this agreement for the three months ended April 3, 2026.

[0001628280-26-029401:notes:158]
•Transition Services Agreement - The Transition Services Agreement governs the provision of transition services from WDC to Sandisk, and from Sandisk to WDC and its affiliates, on an interim, transitional basis following the separation.

[0001628280-26-029401:notes:159]
•Tax Matters Agreement - The Tax Matters Agreement governs, among other things, WDC’s and the Company’s respective rights, responsibilities and obligations after the spin-off with respect to tax liabilities and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings, and other matters regarding taxes. In addition, the Tax Matters Agreement imposes certain restrictions on the Company and its subsidiaries (including restrictions on share issuances, business combinations, sales of assets, and similar transactions) that are designed to preserve the tax-free status of the spin-off and certain related transactions.

[0001628280-26-029401:notes:160]
As a result of this agreement, the Company recorded a tax indemnification liability of $112 million on February 21, 2025. This liability was subsequently increased to reflect changes in indemnification obligations under the Tax Matters Agreement, which is recorded in Other expense, net in the Condensed Consolidated Statements of Operations. The remaining tax indemnification liability of $131 million is classified as Other liabilities in the Condensed Consolidated Balance Sheets as of April 3, 2026.

[0001628280-26-029401:notes:161]
Notes Due to (from) Western Digital Corporation

[0001628280-26-029401:notes:162]
Prior to the separation, the Company received financing from certain of WDC’s subsidiaries in the form of borrowings under revolving credit agreements and promissory notes to fund activities primarily related to Flash Ventures. Additionally, cash generated by the Company was lent from time to time via promissory notes to certain of WDC’s subsidiaries for use in general corporate purposes. Outstanding balances due under these financing arrangements were due on demand.

[0001628280-26-029401:notes:163]
Prior to the separation, the Company had outstanding borrowings due to WDC’s subsidiaries of $553 million, inclusive of interest payable. As part of the separation, WDC contributed $550 million to the Company, and the Company repaid $6 million in cash, which included interest accrued until the date of the separation.

[0001628280-26-029401:notes:164]
The following presents Interest expense and Interest income on notes due to (from) Western Digital Corporation, which were recorded within Interest expense and Interest income in the Condensed Consolidated Statements of Operations for the periods presented:

[0001628280-26-029401:notes:165]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Interest income on notes due from Western Digital Corporation | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |
| Interest expense on notes due to Western Digital Corporation | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 7 |  |

[0001628280-26-029401:notes:166]
Allocation of Corporate Expenses

[0001628280-26-029401:notes:167]
Prior to the separation, WDC provided various corporate services to the Company in the ordinary course of business, including executive management, finance, tax, legal, information technology, employee benefits administration, treasury, risk management, procurement and other shared services. These corporate expenses were allocated to the Company based on direct usage or benefit, where identifiable, with the remainder allocated based on headcount, revenue or other relevant measures. Management believes the basis on which the expenses were allocated to be a reasonable reflection of the utilization of services provided to the Company or the benefit received by the Company.

[0001628280-26-029401:notes:168]
Effective at the beginning of the second quarter of fiscal year 2025, the Company was operationally separated from the operations that were ultimately retained by WDC following completion of the spin-off. In connection with this operational separation, personnel serving the Company in shared service functions were transferred into legal entities dedicated to the Company, and substantially all assets, liabilities, and contracts pertaining to operations of the Company were transferred to legal entities dedicated to the Company as well. Accordingly, there was a substantial reduction in the pool of shared corporate overhead costs of WDC that were subject to allocation in the second and third quarters of fiscal year 2025 and those allocations ceased post-separation.

[0001628280-26-029401:notes:169]
The table below summarizes the impact of expense allocations from WDC within the Condensed Consolidated Statements of Operations for the periods presented:

[0001628280-26-029401:notes:170]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Research and development | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 189 |  |
| Selling, general, and administrative | — |  |  | 10 |  |  | — |  |  | 158 |  |
| Business separation costs | — |  |  | 9 |  |  | — |  |  | 50 |  |
| Employee termination and other charges | — |  |  | — |  |  | — |  |  | 5 |  |
| Total allocation of Corporate Expenses | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 402 |  |

[0001628280-26-029401:notes:171]
The Company’s historical financial statements for periods prior to the separation do not purport to reflect what results of operations, financial position, equity or cash flows would have been if the Company had operated as a standalone company during the periods presented prior to the separation.

[0001628280-26-029401:notes:172]
Cash Management

[0001628280-26-029401:notes:173]
Prior to the separation, WDC provided funding for the Company’s operating and investing activities, including pooled cash managed by WDC’s treasury, to fund operating expenses and capital expenditures. WDC also directly collected certain of the Company’s receivables. These activities were reflected as a component of the Net investment from Western Digital Corporation, and this arrangement is not reflective of the manner in which the Company would operate as a standalone company separate from WDC during the periods presented.

[0001628280-26-029401:notes:174]
Western Digital Corporation Net Investment

[0001628280-26-029401:notes:175]
Prior to the separation, the Net investment from Western Digital Corporation on the Condensed Consolidated Balance Sheets represented WDC’s historical investment in the Company, the net effect of transactions with and allocations from WDC, the Company’s retained earnings and the allocation to the Company of cumulative effect adjustments from the adoption of new accounting standards.

[0001628280-26-029401:notes:176]
Net Transfers from (to) Western Digital Corporation

[0001628280-26-029401:notes:177]
A reconciliation of Net transfers from (to) Western Digital Corporation on the Condensed Consolidated Statements of Shareholders’ Equity to the corresponding amounts on the Condensed Consolidated Statements of Cash Flows is as follows:

[0001628280-26-029401:notes:178]
|  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Net transfers from Western Digital Corporation per Condensed Consolidated Statements of Shareholders’ Equity | $ | — |  |  | $ | (585) |  |
| Notes due to Western Digital Corporation | — |  |  | (1,223) |  |
| Other assets and liabilities, net transferred from Western Digital Corporation | — |  |  | (105) |  |
| Unis Venture transferred from Western Digital Corporation | — |  |  | (61) |  |
| Property, plant and equipment, net transferred from Western Digital Corporation | — |  |  | (27) |  |
| Tax balances transferred from Western Digital Corporation | — |  |  | (8) |  |
| Accumulated other comprehensive loss transferred from Western Digital Corporation | — |  |  | 10 |  |
| Tax indemnification liability transferred to Western Digital Corporation | — |  |  | 112 |  |
| Net transfers to Western Digital Corporation per Condensed Consolidated Statements of Cash Flows | $ | — |  |  | $ | (1,887) |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-26-029401:notes:179]
[same as prior period, unchanged from 0001628280-26-004407:notes:163]

[0001628280-26-029401:notes:180]
The Company leases certain domestic and international facilities and datacenter space under long-term, non-cancelable operating leases that expire at various dates through fiscal year 2039. In connection with and subsequent to the separation, the Company entered into various sublease agreements with WDC under long-term, non-cancelable operating leases that expire at various dates through fiscal year 2032.

[0001628280-26-029401:notes:181]
[same as prior period, unchanged from 0001628280-26-004407:notes:165]

[0001628280-26-029401:notes:182]
[same as prior period, unchanged from 0001628280-26-004407:notes:166]

[0001628280-26-029401:notes:183]
|  | April 3,2026 |  | June 27,2025 |
|  | (in millions) |
| Operating lease right-of-use assets (included in other non-current assets) | $ | 199 |  |  | $ | 214 |  |
| Operating lease liabilities: |  |  |  |
| Current portion of long-term operating lease liabilities (included in accrued expenses) | 25 |  |  | 26 |  |
| Long-term operating lease liabilities (included in other liabilities) | 182 |  |  | 193 |  |
| Total operating lease liabilities | $ | 207 |  |  | $ | 219 |  |

[0001628280-26-029401:notes:184]
[same as prior period, unchanged from 0001628280-26-004407:notes:168]

[0001628280-26-029401:notes:185]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Cost of operating leases | $ | 11 |  |  | $ | 11 |  |  | $ | 34 |  |  | $ | 27 |  |
| Cash paid for operating leases | 10 |  |  | 8 |  |  | 30 |  |  | 22 |  |
| Operating lease assets obtained in exchange for operating lease liabilities | 3 |  |  | 39 |  |  | 10 |  |  | 43 |  |

[0001628280-26-029401:notes:186]
[same as prior period, unchanged from 0001628280-26-004407:notes:170]

[0001628280-26-029401:notes:187]
|  | April 3,2026 |  | March 28,2025 |  |  |
| Weighted average remaining lease term in years | 10.6 |  | 11.3 |  |  |
| Weighted average discount rate | 7.4 | % |  | 7.3 | % |  |  |

[0001628280-26-029401:notes:188]
As of April 3, 2026, remaining minimum lease payments were as follows:

[0001628280-26-029401:notes:189]
|  | Lease Amounts |
|  | (in millions) |
| Minimum lease payments by fiscal year: |  |
| Remaining three months of 2026 | $ | 10 |  |
| 2027 | 37 |  |
| 2028 | 29 |  |
| 2029 | 26 |  |
| 2030 | 23 |  |
| Thereafter | 183 |  |
| Total future minimum lease payments | 308 |  |
| Less: Imputed interest | 101 |  |
| Present value of lease liabilities | $ | 207 |  |

[0001628280-26-029401:notes:190]
[same as prior period, unchanged from 0001628280-26-004407:notes:174]

[0001628280-26-029401:notes:191]
In the normal course of business, the Company enters into purchase orders with suppliers for the purchase of components used to manufacture its products. These purchase orders generally cover forecasted component supplies needed for production during the coming months, are recorded as a liability upon receipt of the components, and generally may be changed or canceled at any time prior to shipment of the components. The Company also enters into certain long-term agreements with suppliers that contain fixed future commitments, which are contingent upon certain conditions such as performance, quality and technology of the vendor’s components.

[0001628280-26-029401:notes:192]
On March 25, 2026, the Company entered into a Private Placement Subscription Agreement (the “Equity Investment Agreement”) with Nanya Technology Corporation (“Nanya”), pursuant to which the Company agreed to make a strategic equity investment in Nanya through a private placement of Nanya common stock (the “Transaction”).

[0001628280-26-029401:notes:193]
Under the Equity Investment Agreement, the Company agreed to purchase approximately 139 million shares of Nanya common stock for an aggregate purchase price of $972 million, representing approximately 3.9% of Nanya’s outstanding common stock on a fully diluted basis following the Transaction. The purchase price reflected a 15% discount to Nanya’s 30-day average trading price, consistent with the Taiwan Securities and Exchange Act (“SEA”) and applicable regulations. The private placement was conducted pursuant to Article 43-6 of the SEA and applicable regulations and was subject to post-closing filings with the Taiwan Stock Exchange and other Taiwanese regulatory authorities. The shares issued to the Company in the private placement are subject to a statutory lock-up period of three years following delivery, during which the Company will be restricted from transferring or selling the shares, subject to limited exceptions under applicable Taiwanese law. On April 8, 2026, the Company remitted the purchase price to fully subscribe for the shares of Nanya. See Note 16, Subsequent Events for additional disclosures.

[0001628280-26-029401:notes:194]
Concurrently with the Equity Investment Agreement, the Company and Nanya also entered into a multi-year strategic supply arrangement pursuant to which Nanya will supply the Company with DRAM products. The supply arrangement is intended to support the Company’s long-term DRAM sourcing strategy. The supply arrangement includes committed volumes per year, subject to variable pricing that is determined on a quarterly basis, based on the average selling price of Nanya’s DRAM products in the preceding quarter.

[0001628280-26-029401:notes:195]
As of April 3, 2026, the Company had the following minimum long-term commitments, which includes the commitment to purchase shares of Nanya that was satisfied on April 8, 2026, see Note 16, Subsequent Events:

[0001628280-26-029401:notes:196]
|  | Long-term commitments |
|  | (in millions) |
| Fiscal year: |  |
| Remaining three months of 2026 | $ | 1,179 |  |
| 2027 | 1,070 |  |
| 2028 | 1,596 |  |
| 2029 | 1,805 |  |
| 2030 | 1,365 |  |
| Thereafter | 92 |  |
| Total | $ | 7,107 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-26-029401:notes:197]
Shareholders’ Equity
Prior to the separation, certain of the Company’s employees participated in WDC’s stock incentive plans (the “WDC Plans”), whereby all awards granted under the plans consisted of WDC common stock. The stock-based compensation expense recognized in the Company’s Condensed Consolidated Financial Statements was determined based upon employees who participated in the WDC Plans and exclusively supported the Company’s operations, as well as an allocation of WDC’s corporate and shared employee stock-based compensation expenses.

[0001628280-26-029401:notes:198]
In connection with the separation, all outstanding RSU and PSU awards held by former employees of WDC and its affiliates, who became Sandisk employees after the separation, were adjusted pursuant to conversion ratios determined in accordance with the terms of the Employee Matters Agreement. Outstanding RSU and PSU awards held by employees in the positions of Vice President and above as of the separation date were converted into RSU or PSU awards of Sandisk shares and RSU awards of WDC shares at a ratio of one-third (1/3) of one share of the Company’s common stock for each WDC award held by each such employee. For all other employees, the value of the converted RSU awards was designed to preserve the aggregate intrinsic value of the awards immediately after the separation when compared to the aggregate intrinsic value of those awards immediately prior to separation. Pursuant to the Employee Matters Agreement, the converted awards shall generally continue to be subject to the same terms and conditions as were applicable to the original WDC awards, including with respect to vesting, except as described in the Employee Matters Agreement. As a result of the conversion, the Company will incur approximately $41 million of incremental stock-based compensation expense from the date of the separation through the remaining service period for the awards. Of this amount, $4 million and $13 million was recognized during the three and nine months ended April 3, 2026, respectively, and approximately $16 million is expected to be recognized over the awards’ remaining service periods.

[0001628280-26-029401:notes:199]
[same as prior period, unchanged from 0001628280-26-004407:notes:179]

[0001628280-26-029401:notes:200]
[same as prior period, unchanged from 0001628280-26-004407:notes:180]

[0001628280-26-029401:notes:201]
[same as prior period, unchanged from 0001628280-26-004407:notes:181]

[0001628280-26-029401:notes:202]
[same as prior period, unchanged from 0001628280-26-004407:notes:182]

[0001628280-26-029401:notes:203]
The following table summarizes RSU and PSU award activity under the Company’s incentive plans during the nine months ended April 3, 2026:

[0001628280-26-029401:notes:204]
|  | Number of Shares |  | Weighted Average Grant Date Fair Value |  | Aggregate Intrinsic Value at Vesting Date |
|  | (in millions) |  |  |  |  |
| RSUs and PSUs outstanding at June 27, 2025 | 6.6 |  |  | $ | 38.98 |  |  | $ | — |  |
| Granted | 3.3 |  |  | 62.59 |  |  | — |  |
| Vested | (2.0) |  |  | 36.60 |  |  | 492.42 |  |
| Canceled/forfeited | (0.3) |  |  | 39.18 |  |  | — |  |
| RSUs and PSUs outstanding at April 3, 2026 | 7.6 |  |  | $ | 49.98 |  |  | $ | 492.42 |  |

[0001628280-26-029401:notes:205]
[same as prior period, unchanged from 0001628280-26-004407:notes:185]

[0001628280-26-029401:notes:206]
Compensation cost related to unvested RSUs, PSUs, and rights to purchase shares of common stock under the ESPP is amortized on a straight-line basis over the remaining service period. The following table presents the unamortized compensation cost and weighted average service period of all unvested outstanding awards as of April 3, 2026:

[0001628280-26-029401:notes:207]
|  | Unamortized Compensation Costs |  | Weighted average service period |
|  | (in millions) |  | (years) |
| RSUs and PSUs | $ | 364 |  |  | 2.44 |
| ESPP | 19 |  |  | 1.17 |
| Total unamortized compensation cost | $ | 383 |  |  |  |

[0001628280-26-029401:notes:208]
[same as prior period, unchanged from 0001628280-26-004407:notes:188]

[0001628280-26-029401:notes:209]
[same as prior period, unchanged from 0001628280-26-004407:notes:189]

[0001628280-26-029401:notes:210]
[same as prior period, unchanged from 0001628280-26-004407:notes:190]

[0001628280-26-029401:notes:211]
[same as prior period, unchanged from 0001628280-26-004407:notes:191]

[0001628280-26-029401:notes:212]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| RSUs and PSUs | $ | 50 |  |  | $ | 43 |  |  | $ | 151 |  |  | $ | 124 |  |
| ESPP | 4 |  |  | 1 |  |  | 14 |  |  | 9 |  |
| Total | $ | 54 |  |  | $ | 44 |  |  | $ | 165 |  |  | $ | 133 |  |

[0001628280-26-029401:notes:213]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Cost of revenue | $ | 4 |  |  | $ | 3 |  |  | $ | 13 |  |  | $ | 12 |  |
| Research and development | 25 |  |  | 20 |  |  | 75 |  |  | 60 |  |
| Selling, general, and administrative | 25 |  |  | 21 |  |  | 77 |  |  | 61 |  |
| Subtotal | $ | 54 |  |  | $ | 44 |  |  | $ | 165 |  |  | $ | 133 |  |
| Tax expense (benefit) | (5) |  |  | 5 |  |  | (17) |  |  | (26) |  |
| Total | $ | 49 |  |  | $ | 49 |  |  | $ | 148 |  |  | $ | 107 |  |

[0001628280-26-029401:notes:214]
Any shortfalls or excess windfall tax benefits and tax deficiencies for shortfalls related to the vesting and exercise of stock-based awards, which are recognized as a component of the Company’s Income tax expense, are excluded from the tax expense (benefit) above.


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-029401:notes:215]
Net Income (Loss) per Common Share
The separation was executed through WDC’s pro rata distribution of 80.1% of the outstanding shares of common stock of the Company to holders of WDC’s common stock as of February 21, 2025. On the separation date, the Company issued 145 million shares of common stock, par value $0.01 per share. This share amount is utilized for the calculation of basic and diluted net income (loss) per share for all periods presented prior to the separation, and these shares are treated as issued and outstanding for purposes of calculating historical net income (loss) per share. For periods prior to the separation, it is assumed that there are no dilutive equity instruments as there were no equity awards of Sandisk outstanding prior to the separation.

[0001628280-26-029401:notes:216]
The following table presents the computation of basic and diluted net income (loss) per common share:

[0001628280-26-029401:notes:217]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions, except per share amounts) |
| Net income (loss) | $ | 3,615 |  |  | $ | (1,933) |  |  | $ | 4,530 |  |  | $ | (1,618) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 148 |  |  | 145 |  |  | 147 |  |  | 145 |  |
| Diluted (1) | 157 |  |  | 145 |  |  | 154 |  |  | 145 |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |
| Basic | $ | 24.43 |  |  | $ | (13.33) |  |  | $ | 30.82 |  |  | $ | (11.16) |  |
| Diluted (1) | $ | 23.03 |  |  | $ | (13.33) |  |  | $ | 29.42 |  |  | $ | (11.16) |  |

[0001628280-26-029401:notes:218]
(1) For the three months ended April 3, 2026, 0.1 million weighted average outstanding awards were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. For the nine months ended April 3, 2026, 0.1 million weighted average outstanding awards were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. For the three and nine months ended March 28, 2025, the Company recorded a net loss. Accordingly, the potential dilution from all equity awards would be anti-dilutive. As a result, basic net loss per share is equal to diluted net loss per share for such periods.

[0001628280-26-029401:notes:219]
Basic net income (loss) per share is computed using (i) net income (loss) divided by (ii) weighted average basic shares outstanding. Diluted net income (loss) per share is computed as (i) net income (loss) divided by (ii) weighted average diluted shares outstanding. The treasury stock method is used to determine the dilutive impact of unvested equity awards.
Potentially dilutive shares include dilutive outstanding employee RSUs, PSUs, and rights to purchase shares of common stock under the ESPP.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-029401:notes:220]
Income Tax Expense 
H.R. 1, more widely known as the One Big Beautiful Bill Act (“OBBBA”), was signed into law on July 4, 2025. It reversed the requirement for capitalization of U.S. research and development expenditures that came into law under the Tax Cuts and Jobs Act of 2017, but the mandatory requirement of capitalization of foreign research and development expenditures remains. The tax rates for income earned by the Company’s foreign subsidiaries are changed under H.R. 1, which applies to the Company’s fiscal years 2027 and onward. Depending on the Company’s operating results, these changes can materially impact the Company’s effective tax rate and its operating cash flows. During the nine months ended April 3, 2026, the Company recorded a $10 million tax benefit in relation to the OBBBA’s impact on its 2025 tax provision.

[0001628280-26-029401:notes:221]
[same as prior period, unchanged from 0001628280-26-004407:notes:201]

[0001628280-26-029401:notes:222]
On December 20, 2021, the Organisation for Economic Co-operation and Development G20 Inclusive Framework on Base Erosion and Profit Shifting released Model Global Anti-Base Erosion rules under Pillar Two (“Pillar Two”). Pillar Two is currently effective in most of the jurisdictions in which we operate. Accordingly, these taxes are included in the Company’s Income tax expense for the three and nine months ended April 3, 2026.

[0001628280-26-029401:notes:223]
[same as prior period, unchanged from 0001628280-26-004407:notes:203]

[0001628280-26-029401:notes:224]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
|  | (in millions) |
| Income (loss) before taxes | $ | 4,107 |  |  | $ | (1,901) |  |  | $ | 5,168 |  |  | $ | (1,461) |  |
| Income tax expense | 492 |  |  | 32 |  |  | 638 |  |  | 157 |  |
| Effective tax rate | 12 | % |  | (2) | % |  | 12 | % |  | (11) | % |

[0001628280-26-029401:notes:225]
The relative mix of earnings and losses by jurisdiction, credits and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the three and nine months ended April 3, 2026.

[0001628280-26-029401:notes:226]
The relative mix of earnings and losses by jurisdiction, the goodwill impairment, the deduction for foreign-derived intangible income, credits and tax holidays in Malaysia that will expire at various dates during years 2028 through 2031 resulted in decreases to the effective tax rate below the U.S. statutory rate for the three and nine months ended March 28, 2025.

[0001628280-26-029401:notes:227]
[same as prior period, unchanged from 0001628280-26-004407:notes:207]

[0001628280-26-029401:notes:228]
[same as prior period, unchanged from 0001628280-26-004407:notes:208]

[0001628280-26-029401:notes:229]
The following is a tabular reconciliation of the total amounts of unrecognized tax benefits, excluding accrued interest and penalties for the nine months ended April 3, 2026:

[0001628280-26-029401:notes:230]
|  | (in millions) |
| Accrual balance at June 27, 2025 | $ | 140 |  |
| Gross increases related to prior year tax positions | 29 |  |
| Gross increases related to current year tax positions | 95 |  |
| Gross decrease related to prior year tax positions | (11) |  |
| Accrual balance at April 3, 2026 | $ | 253 |  |

[0001628280-26-029401:notes:231]
As of April 3, 2026 and June 27, 2025, the liability for unrecognized tax benefits (excluding accrued interest and penalties) was $253 million and $140 million, respectively. Interest and penalties related to unrecognized tax benefits are recognized in liabilities recorded for uncertain tax positions and are recorded in the provision for income taxes. Accrued interest and penalties included in the Company’s liability related to unrecognized tax benefits as of April 3, 2026 and June 27, 2025 was $15 million and $11 million, respectively.

[0001628280-26-029401:notes:232]
[same as prior period, unchanged from 0001628280-26-004407:notes:212]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001628280-26-029401:notes:233]
Legal Proceedings
In the normal course of business, the Company is subject to legal proceedings, lawsuits and other claims. Although the ultimate aggregate amount of reasonably possible monetary liability or financial impact with respect to these other matters is subject to many uncertainties, management believes that any monetary liability or financial impact to the Company from these matters, individually and in the aggregate, would not be material to the Company’s financial condition, results of operations or cash flows. However, any monetary liability and financial impact to the Company from these matters could differ materially from the Company’s expectations.


## us-gaap:SubsequentEventsTextBlock

[0001628280-26-029401:notes:234]
Subsequent Events
On April 8, 2026, the Company satisfied its payment obligation under the Equity Investment Agreement with Nanya by remitting the purchase price of $972 million to fully subscribe for 138,685,000 shares of Nanya, that were received on April 28, 2026, upon completion of the share issuance procedures as set forth in the Equity Investment Agreement.

[0001628280-26-029401:notes:235]
On April 30, 2026, the Company announced that its Board of Directors had approved a $6 billion (exclusive of fees and commissions) share repurchase program (the “Repurchase Program”).  The acquisition of shares under the Repurchase Program may be effected from time to time through open market purchases (including under a plan adopted pursuant to Rule 10b5-1 promulgated under the Securities Exchange Act of 1934) or other methods of acquiring shares, in each case on such terms and at such times as shall be permitted by applicable securities laws and determined by the Company’s management. The Company expects shares repurchased under the Repurchase Program to be funded by operating cash flows.  The amount and timing of share repurchases will depend on market conditions and other relevant factors.  The Company may suspend or discontinue the Repurchase Program at any time. The approval of the Repurchase Program does not obligate the Company to repurchase any common shares.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-26-029401:notes:236]
Alper Ilkbahar, Executive Vice President, Chief Technology Officer of the Company, adopted a Rule 10b5-1 Plan on February 27, 2026. The aggregate number of shares that will be available for sale under his plan is not yet determinable because a portion of the shares will be withheld to satisfy tax withholding obligations at an approximate rate of 45%. The maximum amount of shares that may be sold before the plan expires on December 31, 2026 is expected to be up to an aggregate of 22,821 shares of the Company’s common stock.

[0001628280-26-029401:notes:237]
Bernard Shek, Chief Legal Officer and Secretary of the Company, adopted a 10b5-1 Plan on March 4, 2026. The aggregate number of shares that will be available for sale under his plan is not yet determinable because a portion of the shares will be withheld to satisfy tax withholding obligations at an approximate rate of 45%. The maximum amount of shares that may be sold before the plan expires on July 2, 2027 is expected to be up to an aggregate of 10,465 shares of the Company’s common stock.
