# SNDK 10-Q controls and the auditor's report


## item_4_controls

[0001628280-26-029401:item_4_controls:1]
Item 4.    Controls and Procedures

[0001628280-26-029401:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001628280-26-029401:item_4_controls:3]
As required by Rule 13a-15(b) promulgated by the U.S. Securities and Exchange Commission under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), we carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Exchange Act) as of the end of the period covered by this Quarterly Report on Form 10-Q. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that, as of the end of the period covered by this Quarterly Report on Form 10-Q, our disclosure controls and procedures were effective.

[0001628280-26-029401:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001628280-26-029401:item_4_controls:5]
Due to a transition period established by U.S. Securities and Exchange Commission rules applicable to newly public companies, our management is not required to evaluate the effectiveness of our internal control over financial reporting until the filing of our Annual Report on Form 10-K for the year ending July 3, 2026. As a result, this Quarterly Report on Form 10-Q does not address whether there have been any changes in our internal control over financial reporting.

[0001628280-26-029401:item_4_controls:6]
Our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives as specified above. Management does not expect, however, that our disclosure controls and procedures will prevent or detect all errors and fraud. Any control system, no matter how well designed and operated, is based upon certain assumptions and can provide only reasonable, not absolute, assurance that its objectives will be met. Further, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within the Company have been detected.

[0001628280-26-029401:item_4_controls:7]
48
