# SNDK 8-K — 0001628280-26-028879 filed 2026-04-30

## item codes, every 8-K on or before 2026-05-01

- 2026-04-30 0001628280-26-028879 — 2.02, 8.01, 9.01
- 2026-03-25 0001193125-26-122705 — 1.01, 8.01, 9.01
- 2026-01-29 0001628280-26-004121 — 2.02, 9.01
- 2026-01-02 0001628280-26-000127 — 5.02
- 2025-11-20 0001193125-25-289885 — 5.07
- 2025-11-06 0001628280-25-050180 — 2.02, 9.01
- 2025-08-14 0001193125-25-180782 — 2.02, 9.01
- 2025-05-07 0002023554-25-000021 — 2.02, 9.01
- 2025-03-11 0002023554-25-000007 — 5.02
- 2025-02-24 0001193125-25-033433 — 1.01, 2.03, 3.03, 5.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2025-02-14 0001193125-25-027285 — 3.03, 5.03, 9.01
- 2025-02-03 0001193125-25-019298 — 8.01, 9.01

## late-filing notifications on or before 2026-05-01

- none on or before 2026-05-01

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-028879:8k_2_02:1]
EX-99.1
2
sndkq3-26ex991xpressrelease.htm
EX-99.1

[0001628280-26-028879:8k_2_02:2]
Document

[0001628280-26-028879:8k_2_02:3]
Exhibit 99.1

[0001628280-26-028879:8k_2_02:4]
Sandisk Reports Fiscal Third Quarter 2026 Financial Results

[0001628280-26-028879:8k_2_02:5]
News Summary

[0001628280-26-028879:8k_2_02:6]
•Third quarter revenue was $5.95 billion, up 97% sequentially and above the guidance range, with GAAP net income reported at $3,615 million ($23.03 diluted net income per share). Revenue outperformance was driven by both our mix shift toward higher-value customers, with Datacenter up 233%, and higher pricing. Third quarter Non-GAAP diluted net income per share was $23.41.

[0001628280-26-028879:8k_2_02:7]
•Ended the fiscal third quarter with three signed New Business Model (“NBM”) agreements. Signed two additional NBM agreements in the fiscal fourth quarter.

[0001628280-26-028879:8k_2_02:8]
•Expect fourth quarter revenue to be in the range of $7.75 billion to $8.25 billion, with expected Non-GAAP diluted net income per share to be in the range of $30.00 to $33.00.

[0001628280-26-028879:8k_2_02:9]
MILPITAS, Calif. — April 30, 2026 — Sandisk Corporation (Nasdaq: SNDK) today reported fiscal third quarter financial results.

[0001628280-26-028879:8k_2_02:10]
“This quarter marks a fundamental inflection point for Sandisk — where our technology leadership is enabling a deliberate shift in our mix toward the highest-value end markets, led by Datacenter,” said David Goeckeler, CEO of Sandisk. “We are also advancing to a new business model built on multi-year customer engagements backed by firm financial commitments. Together, this transformation is driving structurally higher and more durable earnings power,” continued Mr. Goeckeler. “With a zero-debt balance sheet, strong cash generation, and a recently authorized share repurchase program, we are positioned to deliver substantial long-term value creation for our shareholders.”

[0001628280-26-028879:8k_2_02:11]
1

[0001628280-26-028879:8k_2_02:12]
Q3 2026 Financial Highlights

[0001628280-26-028879:8k_2_02:13]
|  | GAAP |  | Non-GAAP |
| ($ in millions, except per share amounts) | Q3 2026 |  | Q2 2026 |  | Q/Q |  | Q3 2026 |  | Q2 2026 |  | Q/Q |
| Revenue | $5,950 |  | $3,025 |  | up 97% |  | $5,950 |  | $3,025 |  | up 97% |
| Gross Margin | 78.4% |  | 50.9% |  | up 27.5 ppt |  | 78.4% |  | 51.1% |  | up 27.3 ppt |
| Operating Expenses | $551 |  | $476 |  | up 16% |  | $448 |  | $413 |  | up 8% |
| Operating Income | $4,111 |  | $1,065 |  | up 286% |  | $4,218 |  | $1,133 |  | up 272% |
| Net Income | $3,615 |  | $803 |  | up 350% |  | $3,675 |  | $967 |  | up 280% |
| Diluted Net Income Per Share | $23.03 |  | $5.15 |  | up 347% |  | $23.41 |  | $6.20 |  | up 278% |

[0001628280-26-028879:8k_2_02:14]
|  | GAAP |  | Non-GAAP |
| ($ in millions, except per share amounts) | Q3 2026 |  | Q3 2025 |  | Y/Y |  | Q3 2026 |  | Q3 2025 |  | Y/Y |
| Revenue | $5,950 |  | $1,695 |  | up 251% |  | $5,950 |  | $1,695 |  | up 251% |
| Gross Margin | 78.4% |  | 22.5% |  | up 55.9 ppt |  | 78.4% |  | 22.7% |  | up 55.7 ppt |
| Operating Expenses | $551 |  | $2,263 |  | down 76% |  | $448 |  | $383 |  | up 17% |
| Operating Income (Loss) | $4,111 |  | $(1,881) |  | up 319% |  | $4,218 |  | $2 |  | * |
| Net Income (Loss) | $3,615 |  | $(1,933) |  | up 287% |  | $3,675 |  | $(43) |  | * |
| Diluted Net Income (Loss) Per Share | $23.03 |  | $(13.33) |  | up 273% |  | $23.41 |  | $(0.30) |  | * |

[0001628280-26-028879:8k_2_02:15]
* Not a meaningful figure

[0001628280-26-028879:8k_2_02:16]
End Market Summary

[0001628280-26-028879:8k_2_02:17]
| Revenue ($ in millions) | Q3 2026 |  | Q2 2026 |  | Q/Q |  | Q3 2025 |  | Y/Y |
| Datacenter | $1,467 |  | $440 |  | up 233% |  | $197 |  | up 645% |
| Edge | $3,663 |  | $1,678 |  | up 118% |  | $927 |  | up 295% |
| Consumer | $820 |  | $907 |  | down 10% |  | $571 |  | up 44% |
| Total Revenue | $5,950 |  | $3,025 |  | up 97% |  | $1,695 |  | up 251% |

[0001628280-26-028879:8k_2_02:18]
Additional details can be found within the Company’s earnings presentation, which is accessible online at investor.sandisk.com.

[0001628280-26-028879:8k_2_02:19]
2

[0001628280-26-028879:8k_2_02:20]
Business Outlook for Fiscal Fourth Quarter of 2026

[0001628280-26-028879:8k_2_02:21]
| (in millions, except per share amounts) | GAAP | Non-GAAP(1) |
| Revenue | $7,750 - $8,250 | $7,750 - $8,250 |
| Gross Margin | 78.9% - 80.9% | 79.0% - 81.0% |
| Operating Expenses | $523 - $558 | $480 - $500 |
| Interest and Other Income (Expense), Net | $12 - $32 | $10 - $30 |
| Tax Expense (2) | N/A | $775 - $875 |
| Diluted Net Income Per Share | N/A | $30.00 - $33.00 |
| Diluted Shares Outstanding | ~ 158 | ~ 158 |

[0001628280-26-028879:8k_2_02:22]
(1) Non-GAAP gross margin guidance excludes stock-based compensation expense, totaling approximately $4 million to $6 million. The Company’s Non-GAAP operating expenses guidance excludes stock-based compensation expense, totaling approximately $43 million to $58 million. The Company’s Non-GAAP interest and other income (expense), net guidance excludes the accretion of the present value discount on consideration receivable from the sale of an interest in a subsidiary, totaling approximately $2 million. In the aggregate, Non-GAAP diluted net income per share guidance excludes these items totaling $45 million to $62 million. The timing and amount of these charges excluded from Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other income (expense), net, and Non-GAAP diluted net income per share cannot be further allocated or quantified with certainty. Additionally, the timing and amount of additional charges the Company excludes from its Non-GAAP diluted net income per share are dependent on the timing and determination of certain actions and cannot be reasonably predicted. Accordingly, full reconciliations of Non-GAAP gross margin, Non-GAAP operating expenses, Non-GAAP interest and other income (expense), net, and Non-GAAP diluted net income per share to the most directly comparable GAAP financial measures (gross margin, operating expenses, interest and other income (expense), net and diluted net income per share, respectively) are not available without unreasonable effort.

[0001628280-26-028879:8k_2_02:23]
(2) Non-GAAP tax expense is determined based on a Non-GAAP pre-tax income or loss. Our estimated Non-GAAP tax expense may differ from our GAAP tax expense (i) due to differences in the tax treatment of items excluded from our Non-GAAP net income or loss; (ii) due to the fact that our GAAP income tax expense or benefit recorded in any interim period is based on an estimated forecasted GAAP tax expense for the full year, excluding loss jurisdictions; and (iii) because our GAAP taxes recorded in any interim period are dependent on the timing and determination of certain GAAP operating expenses.

[0001628280-26-028879:8k_2_02:24]
3

[0001628280-26-028879:8k_2_02:25]
Basis of Presentation

[0001628280-26-028879:8k_2_02:26]
On February 21, 2025, Sandisk Corporation (the “Company”) completed its separation from Western Digital Corporation (“WDC”) and became a standalone publicly traded company.

[0001628280-26-028879:8k_2_02:27]
The Company’s financial and operating results after the separation are presented on a consolidated basis. For periods prior to the separation, the Company’s historical combined financial statements were prepared on a carve-out basis and were derived from WDC’s consolidated financial statements and accounting records and prepared as if the Company existed on a standalone basis. The financial statements for all periods presented, including the historical results of the Company prior to February 21, 2025, are now referred to as “Consolidated Financial Statements” and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”).

[0001628280-26-028879:8k_2_02:28]
Investor Communications

[0001628280-26-028879:8k_2_02:29]
The investment community conference call to discuss these results and the Company’s business outlook for the fiscal fourth quarter of 2026 will be broadcast live online today at 1:30 p.m. Pacific/4:30 p.m. Eastern. The live and archived conference call/webcast and the earnings presentation can be accessed online at investor.sandisk.com.

[0001628280-26-028879:8k_2_02:30]
About Sandisk

[0001628280-26-028879:8k_2_02:31]
Sandisk is a leading developer, manufacturer and provider of data storage devices and solutions based on NAND flash technology. With a differentiated innovation engine driving advancements in storage and semiconductor technologies, our broad and ever-expanding portfolio delivers powerful flash storage solutions for everyone from students, gamers and home offices, to the largest enterprises and public clouds to capture, preserve, access and transform an ever-increasing diversity of data. Our solutions include a broad range of solid state drives, embedded products, removable cards, universal serial bus drives, and wafers and components. Learn more about Sandisk at www.Sandisk.com.

[0001628280-26-028879:8k_2_02:32]
4

[0001628280-26-028879:8k_2_02:33]
Forward-Looking Statements

[0001628280-26-028879:8k_2_02:34]
###

[0001628280-26-028879:8k_2_02:35]
Sandisk and the Sandisk logo are registered trademarks or trademarks of Sandisk Corporation or its affiliates in the United States and/or other countries.

[0001628280-26-028879:8k_2_02:36]
5

[0001628280-26-028879:8k_2_02:37]
SANDISK CORPORATION

[0001628280-26-028879:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-028879:8k_2_02:39]
(in millions; except par value, unaudited)

[0001628280-26-028879:8k_2_02:40]
|  | April 3,2026 |  | June 27,2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 3,735 |  |  | $ | 1,481 |  |
| Accounts receivable, net | 2,726 |  |  | 1,068 |  |
| Inventories | 2,238 |  |  | 2,079 |  |
| Income tax receivable | 81 |  |  | 66 |  |
| Other current assets | 388 |  |  | 392 |  |
| Total current assets | 9,168 |  |  | 5,086 |  |
| Property, plant and equipment, net | 649 |  |  | 619 |  |
| Notes receivable and investments in Flash Ventures | 684 |  |  | 654 |  |
| Goodwill | 4,994 |  |  | 4,999 |  |
| Deferred tax assets | 87 |  |  | 58 |  |
| Income tax receivable, non-current | 134 |  |  | 80 |  |
| Other non-current assets | 1,359 |  |  | 1,489 |  |
| Total assets | $ | 17,075 |  |  | $ | 12,985 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 416 |  |  | $ | 366 |  |
| Accounts payable to related parties | 435 |  |  | 400 |  |
| Contract liabilities | 323 |  |  | 25 |  |
| Accrued expenses | 383 |  |  | 400 |  |
| Accrued compensation | 329 |  |  | 173 |  |
| Income tax payable, current | 31 |  |  | 43 |  |
| Current portion of long-term debt | — |  |  | 20 |  |
| Total current liabilities | 1,917 |  |  | 1,427 |  |
| Deferred tax liabilities | 17 |  |  | 17 |  |
| Income tax payable, non-current | 783 |  |  | 131 |  |
| Long-term debt | — |  |  | 1,829 |  |
| Non-current contract liabilities | 188 |  |  | — |  |
| Other liabilities | 393 |  |  | 365 |  |
| Total liabilities | 3,298 |  |  | 3,769 |  |
| Shareholders’ equity: |  |  |  |
| Common stock, $0.01 par value; authorized — 450 shares; issued and outstanding — 148 shares and 146 shares, respectively | $ | 1 |  |  | $ | 1 |  |
| Additional paid-in capital | 11,289 |  |  | 11,248 |  |
| Retained earnings (Accumulated deficit) | 2,746 |  |  | (1,784) |  |
| Accumulated other comprehensive loss | (259) |  |  | (249) |  |
| Total shareholders’ equity | 13,777 |  |  | 9,216 |  |
| Total liabilities and shareholders’ equity | $ | 17,075 |  |  | $ | 12,985 |  |

[0001628280-26-028879:8k_2_02:41]
6

[0001628280-26-028879:8k_2_02:42]
SANDISK CORPORATION

[0001628280-26-028879:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-028879:8k_2_02:44]
(in millions, except per share amounts; unaudited)

[0001628280-26-028879:8k_2_02:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
| Revenue, net | $ | 5,950 |  |  | $ | 1,695 |  |  | $ | 11,283 |  |  | $ | 5,454 |  |
| Cost of revenue | 1,288 |  |  | 1,313 |  |  | 4,393 |  |  | 3,740 |  |
| Gross profit | 4,662 |  |  | 382 |  |  | 6,890 |  |  | 1,714 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 337 |  |  | 285 |  |  | 980 |  |  | 847 |  |
| Selling, general and administrative | 161 |  |  | 139 |  |  | 479 |  |  | 411 |  |
| Goodwill impairment | — |  |  | 1,830 |  |  | — |  |  | 1,830 |  |
| Loss on debt extinguishment | 46 |  |  | — |  |  | 46 |  |  | — |  |
| Business separation costs | 7 |  |  | 9 |  |  | 25 |  |  | 50 |  |
| Employee termination and other | — |  |  | — |  |  | (2) |  |  | 5 |  |
| (Gain) loss on business divestiture | — |  |  | — |  |  | 10 |  |  | (34) |  |
| Total operating expenses | 551 |  |  | 2,263 |  |  | 1,538 |  |  | 3,109 |  |
| Operating income (loss) | 4,111 |  |  | (1,881) |  |  | 5,352 |  |  | (1,395) |  |
| Interest and other income (expense): |  |  |  |  |  |  |  |
| Interest income | 12 |  |  | 6 |  |  | 40 |  |  | 11 |  |
| Interest expense | (6) |  |  | (16) |  |  | (71) |  |  | (22) |  |
| Other income (expense), net | (10) |  |  | (10) |  |  | (153) |  |  | (55) |  |
| Total interest and other income (expense), net | (4) |  |  | (20) |  |  | (184) |  |  | (66) |  |
| Income (loss) before taxes | 4,107 |  |  | (1,901) |  |  | 5,168 |  |  | (1,461) |  |
| Income tax expense | 492 |  |  | 32 |  |  | 638 |  |  | 157 |  |
| Net income (loss) | $ | 3,615 |  |  | $ | (1,933) |  |  | $ | 4,530 |  |  | $ | (1,618) |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |
| Basic | $ | 24.43 |  |  | $ | (13.33) |  |  | $ | 30.82 |  |  | $ | (11.16) |  |
| Diluted | $ | 23.03 |  |  | $ | (13.33) |  |  | $ | 29.42 |  |  | $ | (11.16) |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 148 |  |  | 145 |  |  | 147 |  |  | 145 |  |
| Diluted | 157 |  |  | 145 |  |  | 154 |  |  | 145 |  |

[0001628280-26-028879:8k_2_02:46]
7

[0001628280-26-028879:8k_2_02:47]
SANDISK CORPORATION

[0001628280-26-028879:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-26-028879:8k_2_02:49]
(in millions; unaudited)

[0001628280-26-028879:8k_2_02:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
| Cash flows from operating activities |  |  |  |  |  |  |  |
| Net income (loss) | $ | 3,615 |  |  | $ | (1,933) |  |  | $ | 4,530 |  |  | $ | (1,618) |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operations: |  |  |  |  |  |  |  |
| Depreciation and amortization | 38 |  |  | 37 |  |  | 112 |  |  | 127 |  |
| Stock-based compensation | 54 |  |  | 44 |  |  | 165 |  |  | 133 |  |
| Goodwill impairment | — |  |  | 1,830 |  |  | — |  |  | 1,830 |  |
| Deferred income taxes | (32) |  |  | (16) |  |  | (42) |  |  | 7 |  |
| (Gain) loss on disposal of assets | 1 |  |  | — |  |  | 1 |  |  | (1) |  |
| Impairment of cost method investments | — |  |  | — |  |  | 5 |  |  | 1 |  |
| Unrealized foreign exchange (gain) loss | 19 |  |  | (1) |  |  | 39 |  |  | (6) |  |
| (Gain) loss on business divestiture | — |  |  | — |  |  | 10 |  |  | (34) |  |
| Loss on debt extinguishment | 46 |  |  | — |  |  | 46 |  |  | — |  |
| Amortization of debt issuance costs and discounts | 1 |  |  | 1 |  |  | 6 |  |  | 1 |  |
| Equity loss in investees, net of dividends received | 12 |  |  | 9 |  |  | 58 |  |  | 68 |  |
| Gain on sale of investments | — |  |  | — |  |  | (9) |  |  | — |  |
| Other non-cash operating activities, net | 2 |  |  | 7 |  |  | 20 |  |  | 17 |  |
| Settlement of accrued interest on Notes due to Western Digital Corporation | — |  |  | (3) |  |  | — |  |  | (99) |  |
| Changes in: |  |  |  |  |  |  |  |
| Accounts receivable, net | (1,487) |  |  | (42) |  |  | (1,658) |  |  | (11) |  |
| Inventories | (268) |  |  | 11 |  |  | (159) |  |  | (241) |  |
| Accounts payable | (39) |  |  | 42 |  |  | 36 |  |  | 99 |  |
| Accounts payable to related parties | 2 |  |  | 26 |  |  | 35 |  |  | (28) |  |
| Contract liabilities | 486 |  |  | — |  |  | 486 |  |  | — |  |
| Accrued expenses | 17 |  |  | (10) |  |  | (21) |  |  | 3 |  |
| Income taxes payable | 631 |  |  | — |  |  | 640 |  |  | — |  |
| Accrued compensation | 56 |  |  | (44) |  |  | 156 |  |  | (38) |  |
| Other assets and liabilities, net | (116) |  |  | 68 |  |  | 89 |  |  | (220) |  |
| Net cash provided by (used in) operating activities | 3,038 |  |  | 26 |  |  | 4,545 |  |  | (10) |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment | (45) |  |  | (44) |  |  | (134) |  |  | (159) |  |
| Proceeds from dispositions of business | — |  |  | 210 |  |  | 25 |  |  | 401 |  |
| Notes receivable issuances to Flash Ventures | (83) |  |  | (8) |  |  | (339) |  |  | (274) |  |
| Notes receivable proceeds from Flash Ventures | 45 |  |  | 246 |  |  | 174 |  |  | 428 |  |
| Distributions from Flash Ventures | — |  |  | — |  |  | — |  |  | 176 |  |
| Strategic investments and other, net | — |  |  | — |  |  | 11 |  |  | 1 |  |
| Net cash provided by (used in) investing activities | (83) |  |  | 404 |  |  | (263) |  |  | 573 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |
| Issuance of stock under employee stock plans | — |  |  | — |  |  | 24 |  |  | — |  |
| Taxes paid on vested stock awards under employee stock plans | (102) |  |  | (6) |  |  | (149) |  |  | (6) |  |
| Proceeds from debt | — |  |  | 1,970 |  |  | — |  |  | 1,970 |  |
| Repayment of debt | (650) |  |  | — |  |  | (1,900) |  |  | — |  |
| Debt issuance costs | — |  |  | (32) |  |  | — |  |  | (32) |  |
| Proceeds from borrowings on Notes due to Western Digital Corporation | — |  |  | — |  |  | — |  |  | 550 |  |
| Proceeds from principal repayments on Notes due from Western Digital Corporation | — |  |  | — |  |  | — |  |  | 101 |  |
| Repayments of principal on Notes due to Western Digital Corporation | — |  |  | — |  |  | — |  |  | (76) |  |
| Transfers to Western Digital Corporation | — |  |  | (1,656) |  |  | — |  |  | (1,887) |  |
| Net cash provided by (used in) financing activities | (752) |  |  | 276 |  |  | (2,025) |  |  | 620 |  |
| Effect of exchange rate changes on cash | (7) |  |  | (3) |  |  | (3) |  |  | (4) |  |
| Net increase in cash and cash equivalents | 2,196 |  |  | 703 |  |  | 2,254 |  |  | 1,179 |  |
| Cash and cash equivalents, beginning of year | 1,539 |  |  | 804 |  |  | 1,481 |  |  | 328 |  |
| Cash and cash equivalents, end of period | $ | 3,735 |  |  | $ | 1,507 |  |  | $ | 3,735 |  |  | $ | 1,507 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |
| Cash paid for interest | $ | 49 |  |  | $ | 3 |  |  | $ | 111 |  |  | $ | 102 |  |
| Cash received for interest | 12 |  |  | — |  |  | 40 |  |  | 2 |  |
| Cash paid for income taxes | 25 |  |  | 10 |  |  | 117 |  |  | 10 |  |
| Non-cash transfers of: |  |  |  |  |  |  |  |
| Notes due to (from) Western Digital Corporation | — |  |  | 550 |  |  | — |  |  | 1,223 |  |
| Other assets and liabilities, net, from Western Digital Corporation | — |  |  | 61 |  |  | — |  |  | 105 |  |
| Contribution of equity interest in Unis Venture from Western Digital Corporation | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Property, plant and equipment from Western Digital Corporation | — |  |  | 2 |  |  | — |  |  | 27 |  |
| Tax balances to Western Digital Corporation | — |  |  | 22 |  |  | — |  |  | 8 |  |
| Tax indemnification liability to Western Digital Corporation | — |  |  | (112) |  |  | — |  |  | (112) |  |

[0001628280-26-028879:8k_2_02:51]
8

[0001628280-26-028879:8k_2_02:52]
SANDISK CORPORATION

[0001628280-26-028879:8k_2_02:53]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-26-028879:8k_2_02:54]
(in millions; unaudited)

[0001628280-26-028879:8k_2_02:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | January 2,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
| GAAP gross profit | $ | 4,662 |  |  | $ | 1,541 |  |  | $ | 382 |  |  | $ | 6,890 |  |  | $ | 1,714 |  |
| Stock-based compensation expense | 4 |  |  | 5 |  |  | 3 |  |  | 13 |  |  | 12 |  |
| Non-GAAP gross profit | $ | 4,666 |  |  | $ | 1,546 |  |  | $ | 385 |  |  | $ | 6,903 |  |  | $ | 1,726 |  |
| GAAP operating expenses | $ | 551 |  |  | $ | 476 |  |  | $ | 2,263 |  |  | $ | 1,538 |  |  | $ | 3,109 |  |
| Goodwill impairment | — |  |  | — |  |  | (1,830) |  |  | — |  |  | (1,830) |  |
| Stock-based compensation expense | (50) |  |  | (53) |  |  | (41) |  |  | (152) |  |  | (121) |  |
| Business separation costs | (7) |  |  | (9) |  |  | (9) |  |  | (25) |  |  | (50) |  |
| Employee termination and other | — |  |  | (1) |  |  | — |  |  | 2 |  |  | (5) |  |
| (Loss) gain on business divestiture | — |  |  | — |  |  | — |  |  | (10) |  |  | 34 |  |
| Loss on debt extinguishment | (46) |  |  | — |  |  | — |  |  | (46) |  |  | — |  |
| Non-GAAP operating expenses | $ | 448 |  |  | $ | 413 |  |  | $ | 383 |  |  | $ | 1,307 |  |  | $ | 1,137 |  |
| GAAP operating income (loss) | $ | 4,111 |  |  | $ | 1,065 |  |  | $ | (1,881) |  |  | $ | 5,352 |  |  | $ | (1,395) |  |
| Gross profit adjustments | 4 |  |  | 5 |  |  | 3 |  |  | 13 |  |  | 12 |  |
| Operating expense adjustments | 103 |  |  | 63 |  |  | 1,880 |  |  | 231 |  |  | 1,972 |  |
| Non-GAAP operating income (loss) | $ | 4,218 |  |  | $ | 1,133 |  |  | $ | 2 |  |  | $ | 5,596 |  |  | $ | 589 |  |
| GAAP interest and other income (expense), net | $ | (4) |  |  | $ | (128) |  |  | $ | (20) |  |  | $ | (184) |  |  | $ | (66) |  |
| Other, net | 1 |  |  | 94 |  |  | (2) |  |  | 105 |  |  | (6) |  |
| Non-GAAP interest and other income (expense), net | $ | (3) |  |  | $ | (34) |  |  | $ | (22) |  |  | $ | (79) |  |  | $ | (72) |  |
| GAAP income tax expense | $ | 492 |  |  | $ | 134 |  |  | $ | 32 |  |  | $ | 638 |  |  | $ | 157 |  |
| Income tax adjustments | 48 |  |  | (2) |  |  | (9) |  |  | 56 |  |  | (38) |  |
| Non-GAAP income tax expense | $ | 540 |  |  | $ | 132 |  |  | $ | 23 |  |  | $ | 694 |  |  | $ | 119 |  |

[0001628280-26-028879:8k_2_02:56]
9

[0001628280-26-028879:8k_2_02:57]
SANDISK CORPORATION

[0001628280-26-028879:8k_2_02:58]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-26-028879:8k_2_02:59]
(in millions, except per share amounts; unaudited)

[0001628280-26-028879:8k_2_02:60]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3,2026 |  | January 2,2026 |  | March 28,2025 |  | April 3,2026 |  | March 28,2025 |
| GAAP net income (loss) | $ | 3,615 |  |  | $ | 803 |  |  | $ | (1,933) |  |  | $ | 4,530 |  |  | $ | (1,618) |  |
| Goodwill impairment | — |  |  | — |  |  | 1,830 |  |  | — |  |  | 1,830 |  |
| Stock-based compensation expense | 54 |  |  | 58 |  |  | 44 |  |  | 165 |  |  | 133 |  |
| Business separation costs | 7 |  |  | 9 |  |  | 9 |  |  | 25 |  |  | 50 |  |
| Employee termination and other | — |  |  | 1 |  |  | — |  |  | (2) |  |  | 5 |  |
| (Gain) loss on business divestiture | — |  |  | — |  |  | — |  |  | 10 |  |  | (34) |  |
| Loss on debt extinguishment | 46 |  |  | — |  |  | — |  |  | 46 |  |  | — |  |
| Other, net | 1 |  |  | 94 |  |  | (2) |  |  | 105 |  |  | (6) |  |
| Income tax adjustments | (48) |  |  | 2 |  |  | 9 |  |  | (56) |  |  | 38 |  |
| Non-GAAP net income (loss) | $ | 3,675 |  |  | $ | 967 |  |  | $ | (43) |  |  | $ | 4,823 |  |  | $ | 398 |  |
| Diluted net income (loss) per share |  |  |  |  |  |  |  |  |  |
| GAAP | $ | 23.03 |  |  | $ | 5.15 |  |  | $ | (13.33) |  |  | $ | 29.42 |  |  | $ | (11.16) |  |
| Non-GAAP | $ | 23.41 |  |  | $ | 6.20 |  |  | $ | (0.30) |  |  | $ | 31.32 |  |  | $ | 2.71 |  |
| Diluted weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| GAAP | 157 |  |  | 156 |  |  | 145 |  |  | 154 |  |  | 145 |  |
| Non-GAAP | 157 |  |  | 156 |  |  | 145 |  |  | 154 |  |  | 147 |  |
| Cash flows |  |  |  |  |  |  |  |  |  |
| Cash flow provided by (used in) operating activities | $ | 3,038 |  |  | $ | 1,019 |  |  | $ | 26 |  |  | $ | 4,545 |  |  | $ | (10) |  |
| Purchases of property, plant and equipment, net | (45) |  |  | (39) |  |  | (44) |  |  | (134) |  |  | (159) |  |
| Free cash flow | 2,993 |  |  | 980 |  |  | (18) |  |  | 4,411 |  |  | (169) |  |
| Activity related to Flash Ventures, net | (38) |  |  | (137) |  |  | 238 |  | (165) |  |  | 330 |
| Adjusted free cash flow | $ | 2,955 |  |  | $ | 843 |  |  | $ | 220 |  |  | $ | 4,246 |  |  | $ | 161 |  |

[0001628280-26-028879:8k_2_02:61]
10

[0001628280-26-028879:8k_2_02:62]
To supplement the condensed consolidated financial statements presented in accordance with GAAP, the table above sets forth Non-GAAP gross profit; Non-GAAP operating expenses; Non-GAAP operating income; Non-GAAP interest and other income (expense), net; Non-GAAP income tax expense; Non-GAAP net income (loss); Non-GAAP diluted net income (loss) per share; Non-GAAP diluted weighted average shares outstanding; Free cash flow; and Adjusted free cash flow (collectively, the “Non-GAAP measures”). These Non-GAAP measures are not in accordance with, or alternatives for measures prepared in accordance with GAAP and may be different from similarly titled Non-GAAP measures used by other companies. The Company believes the presentation of these Non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors for measuring the Company’s earnings performance and comparing it against prior periods. Specifically, the Company believes these Non-GAAP measures provide useful information to both management and investors as they exclude certain expenses, gains, and losses that the Company believes are not indicative of its core operating results or because they are consistent with the financial models and estimates published by many analysts who follow the Company and its peers. As discussed further below, these Non-GAAP measures exclude, as applicable, goodwill impairment, stock-based compensation expense, business separation costs, employee termination and other, (gain) loss on business divestiture, loss on debt extinguishment, other adjustments, and income tax adjustments. The Company believes these measures, along with the related reconciliations to the most directly comparable GAAP measures, provide additional detail and comparability for assessing the Company’s results. These Non-GAAP measures are some of the primary indicators management uses for assessing the Company’s performance and planning and forecasting future periods. These measures should be considered in addition to results prepared in accordance with GAAP, but should not be considered a substitute for, or superior to, GAAP results.

[0001628280-26-028879:8k_2_02:63]
As described above, the Company excludes the following items from its Non-GAAP measures:

[0001628280-26-028879:8k_2_02:64]
Goodwill impairment. After the completion of the separation, in the third quarter of fiscal 2025, the Company identified potential impairment indicators related to the trading price of the Company’s common stock and resulting market capitalization that warranted a quantitative impairment analysis of long-lived assets and goodwill. Management performed a quantitative impairment analysis and determined that the carrying value of the reporting unit exceeded its fair value, resulting in the recognition of a $1.8 billion impairment charge for the three and nine months ended March 28, 2025. The Company believes this charge does not reflect the Company’s operating results and is not indicative of the underlying performance of the business.

[0001628280-26-028879:8k_2_02:65]
Stock-based compensation expense. Because of the variety of equity awards used by companies, the varying methodologies for determining stock-based compensation expense, the subjective assumptions involved in those determinations and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding stock-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of the business over time and compare it against the Company’s peers, a majority of whom also exclude stock-based compensation expense from their Non-GAAP results.

[0001628280-26-028879:8k_2_02:66]
11

[0001628280-26-028879:8k_2_02:67]
Business separation costs. On October 30, 2023, Western Digital Corporation (“WDC”) announced that its board of directors (the “WDC Board of Directors”) authorized management to pursue a plan to separate the Company into an independent public company. The separation received final approval by the WDC Board of Directors and was completed on February 21, 2025. Prior to February 21, 2025, the Company was wholly-owned by WDC. As a result of the plan, the Company incurred separation and transition costs through the completion of the separation of the companies. The separation and transition costs are recorded within Business separation costs in the Condensed Consolidated Statements of Operations. The Company believes these charges do not reflect the Company’s operating results and that they are not indicative of the underlying results of its business.

[0001628280-26-028879:8k_2_02:68]
Employee termination and other. From time to time, in order to realign the Company’s operations with anticipated market demand, the Company may terminate employees and/or restructure its operations. From time to time, the Company may also incur charges from the impairment of long-lived assets. In addition, the Company may record credits related to gains upon sale of property due to restructuring or reversals of charges recorded in prior periods as well as from taking actions to reduce the amount of capital invested in facilities, including the sale-leaseback of facilities. These charges or credits are inconsistent in amount and frequency, and the Company believes they are not indicative of the underlying performance of its business.

[0001628280-26-028879:8k_2_02:69]
(Gain) loss on business divestiture. In connection with the Company’s strategic decision to outsource the manufacturing of certain components and assemblies, on September 28, 2024, the Company completed the sale of 80% of its equity interest in one of its manufacturing subsidiaries. On September 25, 2025, the Company entered into an Amendment No. 1 to the Amended and Restated Equity Purchase Agreement that included a $10 million provision for working capital support. The Company recognized the adjustment as a Loss on business divestiture during the first fiscal quarter of 2026. The overall transaction resulted in a discrete gain, which the Company believes is not indicative of the underlying performance of its ongoing business operations.

[0001628280-26-028879:8k_2_02:70]
Loss on debt extinguishment. From time to time, the Company incurs debt extinguishment charges consisting of the costs to call the existing debt and/or the write-off of any related unamortized debt issuance costs. These charges do not reflect the Company’s operating results, and the Company believes these charges are not indicative of the underlying performance of its business.

[0001628280-26-028879:8k_2_02:71]
Other adjustments. From time to time, the Company incurs charges or gains that the Company believes are not a part of the ongoing operation of its business. For the three months ended January 2, 2026 and nine months ended April 3, 2026, Other adjustments include charges for the settlement of certain previously existing legal matters and the impairment of an investment, partially offset by a gain upon sale of an investment. The resulting expense or benefit is inconsistent in amount and frequency.

[0001628280-26-028879:8k_2_02:72]
Income tax adjustments. Income tax adjustments include the difference between income taxes based on a forecasted annual Non-GAAP tax rate and a forecasted annual GAAP tax rate as a result of the timing of certain Non-GAAP pre-tax adjustments. The income tax adjustments also include the re-measurement of certain unrecognized tax benefits primarily related to tax positions taken in prior quarters, including interest. These adjustments are excluded because the Company believes that they are not indicative of the underlying performance of its ongoing business.

[0001628280-26-028879:8k_2_02:73]
12

[0001628280-26-028879:8k_2_02:74]
Additionally, Free cash flow is defined as cash flows provided by (used in) operating activities less purchases of property, plant and equipment, net, and Adjusted free cash flow is defined as free cash flow plus the activity related to Flash Ventures, net. The Company considers Free cash flow and Adjusted free cash flow generated in any period to be useful indicators of cash that is available for strategic opportunities, including, among others, investing in the Company’s business, making strategic acquisitions and strengthening the balance sheet. Gross Margin is calculated by dividing Gross Profit by Revenue. Non-GAAP Gross Margin is calculated by dividing Non-GAAP Gross Profit by Revenue.

[0001628280-26-028879:8k_2_02:75]
| Company Contacts: |
| Sandisk Corporation |  |  |
| Investor Contact: |  | Media Contact: |
| Ivan Donaldson |  | Media Relations |
| E: ivan.donaldson@sandisk.com |  | mediainquiries@sandisk.com |
| investors@sandisk.com |  |  |

[0001628280-26-028879:8k_2_02:76]
13
