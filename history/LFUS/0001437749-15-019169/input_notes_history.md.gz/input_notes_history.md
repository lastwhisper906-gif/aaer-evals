# LFUS note change history — 0001437749-15-014442 → 0001437749-15-019169


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-10-30):
[0001437749-15-019169:note_history:1]
The carrying amounts of debt at September 26, 2015 and December 27, 2014 are as follows (in thousands):
  (was, 2015-07-31, similarity 0.9392):
[0001437749-15-014442:note_history:1]
The carrying amounts of debt at June 27, 2015 and December 27, 2014 are as follows (in thousands):

- changed (2015-10-30):
[0001437749-15-019169:note_history:2]
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 90,000 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 107,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 11,517 |  |  |  | 17,908 |  |
| Total debt |  |  | 209,017 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 117,500 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 91,517 |  |  | $ | 106,658 |  |
  (was, 2015-07-31, similarity 0.9783):
[0001437749-15-014442:note_history:2]
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 91,250 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 73,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 14,493 |  |  |  | 17,908 |  |
| Total debt |  |  | 179,243 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 82,250 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 96,993 |  |  | $ | 106,658 |  |

- changed (2015-10-30):
[0001437749-15-019169:note_history:3]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of September 26, 2015, the company had available $167.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of September 26, 2015). At September 26, 2015, the company was in compliance with all covenants under the revolving credit facility.
  (was, 2015-07-31, similarity 0.7882):
[0001437749-15-014442:note_history:3]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of June 27, 2015, the company had available $200.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of June 27, 2015). At June 27, 2015, the company was in compliance with all covenants under the revolving credit facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-10-30):
[0001437749-15-019169:note_history:4]
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 90,000 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 107,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 11,517 |  |  |  | 17,908 |  |
| Total debt |  |  | 209,017 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 117,500 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 91,517 |  |  | $ | 106,658 |  |
  (was, 2015-07-31, similarity 0.9783):
[0001437749-15-014442:note_history:4]
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 91,250 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 73,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 14,493 |  |  |  | 17,908 |  |
| Total debt |  |  | 179,243 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 82,250 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 96,993 |  |  | $ | 106,658 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-10-30):
[0001437749-15-019169:note_history:5]
12. Subsequent Event

- added (2015-10-30):
[0001437749-15-019169:note_history:6]
On October 1, 2015, the company acquired Sigmar S.r.1. (“Sigmar”), an Italian company that produces sensors used in gas and diesel engine fuel systems, as well as urea level and quality sensors used in diesel emission reduction systems. Sigmar has annual revenues of approximately $6 million and will be reported in the Automotive business segment.
