# LFUS MD&A — 0001437749-15-019169


## mdna

[0001437749-15-019169:mdna:1]
[same as prior period, unchanged from 0001437749-15-014442:mdna:1]

[0001437749-15-019169:mdna:2]
[same as prior period, unchanged from 0001437749-15-014442:mdna:2]

[0001437749-15-019169:mdna:3]
[same as prior period, unchanged from 0001437749-15-014442:mdna:3]

[0001437749-15-019169:mdna:4]
[same as prior period, unchanged from 0001437749-15-014442:mdna:4]

[0001437749-15-019169:mdna:5]
[same as prior period, unchanged from 0001437749-15-014442:mdna:5]

[0001437749-15-019169:mdna:6]
[same as prior period, unchanged from 0001437749-15-014442:mdna:6]

[0001437749-15-019169:mdna:7]
[same as prior period, unchanged from 0001437749-15-014442:mdna:7]

[0001437749-15-019169:mdna:8]
[same as prior period, unchanged from 0001437749-15-014442:mdna:8]

[0001437749-15-019169:mdna:9]
[same as prior period, unchanged from 0001437749-15-014442:mdna:9]

[0001437749-15-019169:mdna:10]
[same as prior period, unchanged from 0001437749-15-014442:mdna:10]

[0001437749-15-019169:mdna:11]
[same as prior period, unchanged from 0001437749-15-014442:mdna:11]

[0001437749-15-019169:mdna:12]
[same as prior period, unchanged from 0001437749-15-014442:mdna:12]

[0001437749-15-019169:mdna:13]
[same as prior period, unchanged from 0001437749-15-014442:mdna:13]

[0001437749-15-019169:mdna:14]
[same as prior period, unchanged from 0001437749-15-014442:mdna:14]

[0001437749-15-019169:mdna:15]
[same as prior period, unchanged from 0001437749-15-014442:mdna:15]

[0001437749-15-019169:mdna:16]
[same as prior period, unchanged from 0001437749-15-014442:mdna:16]

[0001437749-15-019169:mdna:17]
The Electrical segment derives its revenues from power fuses, protection relays and custom products selling primarily into the industrial, mining, solar and oil and gas markets. Custom products sales, after several years of strong growth, declined due to the completion of several large Canadian potash mining projects. The company has expanded this business by moving into new markets such as non-potash mining and oil and gas. Protection relay sales have also slowed due to the general slowdown in the global mining market.

[0001437749-15-019169:mdna:18]
[same as prior period, unchanged from 0001437749-15-014442:mdna:18]

[0001437749-15-019169:mdna:19]
[same as prior period, unchanged from 0001437749-15-014442:mdna:19]

[0001437749-15-019169:mdna:20]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 102,616 |  |  | $ | 107,754 |  |  |  | (5 | %) |  | $ | 307,549 |  |  | $ | 313,726 |  |  |  | (2 | %) |
| Automotive |  |  | 81,475 |  |  |  | 80,639 |  |  |  | 1 | % |  |  | 251,464 |  |  |  | 245,083 |  |  |  | 3 | % |
| Electrical |  |  | 31,419 |  |  |  | 29,215 |  |  |  | 8 | % |  |  | 88,831 |  |  |  | 86,566 |  |  |  | 3 | % |
| Total |  | $ | 215,510 |  |  | $ | 217,608 |  |  |  | (1 | %) |  | $ | 647,844 |  |  | $ | 645,375 |  |  |  | 0 | % |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 98,974 |  |  | $ | 97,903 |  |  |  | 1 | % |  | $ | 299,061 |  |  | $ | 282,928 |  |  |  | 6 | % |
| Europe |  |  | 37,520 |  |  |  | 39,568 |  |  |  | (5 | %) |  |  | 115,613 |  |  |  | 127,791 |  |  |  | (10 | %) |
| Asia-Pacific |  |  | 79,016 |  |  |  | 80,137 |  |  |  | (1 | %) |  |  | 233,170 |  |  |  | 234,656 |  |  |  | (1 | %) |
| Total |  | $ | 215,510 |  |  | $ | 217,608 |  |  |  | (1 | %) |  | $ | 647,844 |  |  | $ | 645,375 |  |  |  | 0 | % |

[0001437749-15-019169:mdna:21]
[same as prior period, unchanged from 0001437749-15-014442:mdna:21]

[0001437749-15-019169:mdna:22]
Results of Operations – Third Quarter, 2015 compared to 2014

[0001437749-15-019169:mdna:23]
The following table summarizes the company’s consolidated results of operations for the periods presented. During the third quarter of 2015, there was approximately $33.4 million of special charges ($39.8 million year-to-date) primarily consisting of $1.2 million ($3.1 million year-to-date) related to the company’s transfer of its reed sensor manufacturing from the U.S. to the Philippines, $0.9 million ($3.8 million year-to-date) related to internal legal restructuring costs, $0.3 million ($0.7 million year-to-date) related to acquisition costs and $30.8 million ($32.2 million year-to-date) of expenses related to the wind down and settlement of the U.S. pension as described in Note 9.

[0001437749-15-019169:mdna:24]
| (In thousands, unaudited) |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Sales |  | $ | 215,510 |  |  | $ | 217,608 |  |  |  | (1 | %) |  | $ | 647,844 |  |  | $ | 645,375 |  |  |  | 0 | % |
| Gross Profit |  |  | 86,182 |  |  |  | 87,380 |  |  |  | (1 | %) |  |  | 247,793 |  |  |  | 248,869 |  |  |  | (0 | %) |
| Operating expense |  |  | 77,598 |  |  |  | 47,250 |  |  |  | 64 | % |  |  | 173,490 |  |  |  | 141,430 |  |  |  | 23 | % |
| Operating income |  |  | 8,584 |  |  |  | 40,130 |  |  |  | (79 | %) |  |  | 74,303 |  |  |  | 107,439 |  |  |  | (31 | %) |
| Other (income) expense, net |  |  | (4,057 | ) |  |  | (1,070 | ) |  |  | 279 | % |  |  | (2,461 | ) |  |  | 865 |  |  |  | (385 | %) |
| Income before income taxes |  |  | 12,641 |  |  |  | 41,200 |  |  |  | (69 | %) |  |  | 76,764 |  |  |  | 106,574 |  |  |  | (28 | %) |
| Net income |  | $ | 11,324 |  |  | $ | 29,940 |  |  |  | (62 | %) |  | $ | 60,003 |  |  | $ | 79,907 |  |  |  | (25 | %) |

[0001437749-15-019169:mdna:25]
Net sales decreased $2.1 million or 1% to $215.5 million in the third quarter of 2015 compared to $217.6 million in the third quarter of 2014 due primarily to $9.9 million in unfavorable foreign currency effects in the third quarter of 2015 as compared to the third quarter of 2014. The unfavorable foreign currency impact primarily resulted from sales denominated in the euro. Excluding currency effects, net sales increased $7.8 million or 4% year-over-year. This increase resulted from continued growth in automotive and improvement in the electrical business, offset by lower electronics sales.

[0001437749-15-019169:mdna:26]
Electronics sales decreased $5.1 million or 5% to $102.6 million in the third quarter of 2015 compared to $107.8 million in the third quarter of 2014 due to capacity constraints for sensor products as they are being transferred to the Philippines as well as a slightly weaker-than-normal seasonal ramp up for core products. The electronics segment experienced $3.2 million in unfavorable currency effects in the third quarter of 2015 primarily from sales denominated in euros. Excluding currency effects, net sales decreased $2.0 million or 2% year-over-year.

[0001437749-15-019169:mdna:27]
Automotive sales increased $0.8 million or 1% to $81.5 million in the third quarter of 2015 compared to $80.6 million in the third quarter of 2014 due to strong growth for sensors offset by lower fuse sales and a decline in commercial vehicle products, due to weak end markets. The automotive segment experienced $5.5 million in unfavorable currency effects in the third quarter of 2015 primarily due to sales denominated in euros. Excluding currency effects, net sales increased $6.3 million or 8% year-over-year.

[0001437749-15-019169:mdna:28]
Electrical sales increased $2.2 million or 8% to $31.4 million in the third quarter of 2015 compared to $29.2 million in the third quarter of 2014 due to solid growth in the core fuse business and continued recovery in custom products. The electrical segment experienced $1.3 million in unfavorable currency effects in the third quarter of 2015 primarily from sales denominated in Canadian dollars and the euro. Excluding currency effects, net sales increased $3.5 million or 12% year-over-year.

[0001437749-15-019169:mdna:29]
On a geographic basis, sales in the Americas increased $1.1 million or 1% to $99.0 million in the third quarter of 2015 compared to $97.9 million in the third quarter of 2014 due primarily to strong growth in automotive and electrical sales offset by $1.3 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding currency effects, the Americas sales increased $2.4 million or 2%.

[0001437749-15-019169:mdna:30]
Europe sales decreased $2.0 million or 5% to $37.5 million in the third quarter of 2015 compared to $39.6 million in the third quarter of 2014 mainly due to $7.4 million in unfavorable currency effects reflecting a decline in the euro during the current year quarter. Excluding currency effects, Europe sales increased $5.4 million or 14% reflecting strong demand for automotive products.

[0001437749-15-019169:mdna:31]
Asia-Pacific sales decreased $1.1 million or 1% to $79.0 million in the third quarter of 2015 compared to $80.1 million in the third quarter of 2014 due to a decline in electronics and $1.1 million in unfavorable currency effects offset by continued demand for automotive products. Excluding currency effects, Asia-Pacific sales were flat year-over-year.

[0001437749-15-019169:mdna:32]
Gross profit was $86.2 million or 40% of net sales for the third quarter of 2015 compared to $87.4 million or 40% of net sales in the same quarter last year. Gross profit for the third quarter of 2015 included $1.2 million of charges related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines. Excluding the impact of these charges, gross profit was 41% of net sales for the third quarter of 2015.

[0001437749-15-019169:mdna:33]
Total operating expense was $77.6 million or 36% of net sales for the third quarter of 2015 compared to $47.3 million or 22% of net sales for the same quarter in 2014. Operating expenses for the third quarter of 2015 included $30.2 million related to the settlement of the company’s U.S. pension plan. Excluding the pension settlement expense of $30.2 million, operating expenses were $47.4 million or 22% of net sales for the third quarter of 2015.

[0001437749-15-019169:mdna:34]
Operating income for the third quarter of 2015 was $8.6 million compared to operating income of $40.1 million for the same quarter in 2014. Excluding the impact of the $30.2 million pension settlement in the third quarter of 2015 as described above, operating income for the third quarter of 2015 was $38.8 million. The lower operating earnings is primarily as a result of lower sales in the third quarter of 2015 as discussed above.

[0001437749-15-019169:mdna:35]
Interest expense was $0.9 million in the third quarter of 2015 and $1.3 million in the third quarter of 2014 and reflects interest incurred for borrowing on the company’s credit agreement.

[0001437749-15-019169:mdna:36]
Foreign exchange loss (gain), reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $3.5 million of income for the third quarter of 2015 as compared to $0.1 million of income for the third quarter of 2014 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar.

[0001437749-15-019169:mdna:37]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $1.4 million of income for third quarter of 2015 and $2.3 million of income for the third quarter of 2014.

[0001437749-15-019169:mdna:38]
Income before income taxes was $12.6 million for the third quarter of 2015 compared to $41.2 million for the third quarter of 2014. The lower income before income taxes for 2015 was primarily due to the pension settlement charge of $30.2 million as described above. Income tax expense was $1.3 million with an effective tax rate of 10.4% for the third quarter of 2015 compared to income tax expense of $11.3 million with an effective tax rate of 27.3% in the third quarter of 2014. The lower effective tax rate for the third quarter of 2015 resulted from income earned in lower tax jurisdictions and the impact of the pension settlement partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations during the third quarter of 2015. The effective tax rates for both the third quarter of 2015 and 2014 were lower than the U.S. statutory tax rate primarily due to the factors discussed above and more income earned in lower tax jurisdictions.

[0001437749-15-019169:mdna:39]
Net income for the third quarter of 2015 was $11.3 million or $0.50 per diluted share compared to net income of $29.9 million or $1.32 per diluted share for the same quarter of 2014.

[0001437749-15-019169:mdna:40]
Results of Operations – Nine months, 2015 compared to 2014

[0001437749-15-019169:mdna:41]
Net sales increased $2.5 million or less than 1% to $647.8 million for the first nine months of 2015 compared to $645.4 million in the first nine months of 2014 due primarily to strong growth in automotive products and improvement in the electrical business partially offset by lower electronics sales. The company also experienced $31.1 million in unfavorable foreign currency effects in the first nine months of 2015 as compared to 2014 primarily resulting from sales denominated in the euro. Excluding currency effects, net sales increased $33.5 million or 5% year-over-year.

[0001437749-15-019169:mdna:42]
Electronics sales decreased $6.2 million or 2% to $307.5 million for the first nine months of 2015 compared to $313.7 million in the first nine months of 2014 due primarily to negative currency effects offset by strong growth for fuse products earlier in the first half of the year. The electronics segment experienced $9.7 million in unfavorable currency effects in the first nine months of 2015 primarily from sales denominated in euro. Excluding currency effects, net sales increased $3.5 million or 1% year-over-year.

[0001437749-15-019169:mdna:43]
Automotive sales increased $6.4 million or 3% to $251.5 million in the first nine months of 2015 compared to $245.1 million in the first nine months of 2014 due primarily to strong growth for sensors, fuses and commercial vehicle products. The automotive segment experienced $18.0 million in unfavorable currency effects in the first nine months of 2015 primarily due to sales denominated in euros. Excluding currency effects, net sales increased $24.4 million or 10% year-over-year.

[0001437749-15-019169:mdna:44]
Electrical sales, increased $2.3 million or 3% to $88.8 million in the first nine months of 2015 compared to $86.6 million in the first nine months of 2014 as higher custom and fuse sales were offset by weaker relay sales. The electrical segment experienced $3.4 million in unfavorable currency effects in the first nine months of 2015 primarily from sales denominated in Canadian dollars and the euro. Excluding currency effects, net sales increased $5.6 million or 6% year-over-year.

[0001437749-15-019169:mdna:45]
On a geographic basis, sales in the Americas increased $16.1 million or 6% to $299.1 million in the first nine months of 2015 compared to $282.9 million in the first nine months of 2014 due primarily to strong growth in automotive offset by $3.6 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding currency effects, the Americas sales increased $19.7 million or 7%.

[0001437749-15-019169:mdna:46]
Europe sales decreased $12.2 million or 10% to $115.6 million in the first nine months of 2015 compared to $127.8 million in the first nine months of 2014 mainly due to $25.3 million in unfavorable currency effects reflecting a decline in the euro during the first nine months. Excluding currency effects, Europe sales increased $13.2 million or 10% reflecting strong demand for automotive products.

[0001437749-15-019169:mdna:47]
Asia-Pacific sales decreased $1.5 million or 1% to $233.2 million in the first nine months of 2015 compared to $234.7 million in the first nine months of 2014 due primarily to strong demand for automotive products offset by lower electronics sales and unfavorable currency effects of $2.2 million. Excluding currency effects, Asia-Pacific sales increased $0.7 million or less than 1% year-over-year.

[0001437749-15-019169:mdna:48]
Gross profit was $247.8 million or 38% of net sales for the first nine months of 2015 compared to $248.9 million or 39% of net sales for the first nine months of 2014. Gross profit for the first nine months of 2015 included $3.1 million of charges related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines. Gross profit for the first nine months of 2014 included a $2.8 million non-cash charge to cost of goods sold for inventory that was stepped up to fair value as a result of the SymCom acquisition and $2.0 million in severance charges resulting from restructuring at the Hamlin-Mexico plant. Excluding the impact of these charges, gross profit was 39% of net sales for both the first nine months of 2015 and 2014, respectively.

[0001437749-15-019169:mdna:49]
Total operating expense was $173.5 million or 27% of net sales for the first nine months of 2015 compared to $141.4 million or 22% of net sales for the first nine months of 2014. Operating expenses for the first nine months of 2015 included $30.2 million related to the settlement of the company’s U.S. pension plan. Excluding the pension settlement expense, operating expenses were $143.3 million or 22% of net sales for the first nine months of 2015.

[0001437749-15-019169:mdna:50]
Operating income for the first nine months of 2015 was approximately $74.3 million compared to operating income of $107.4 million for the first nine months of 2014, primarily as a result of the negative impact of the pension settlement charge and the foreign exchange impact on sales and gross profit as discussed above.

[0001437749-15-019169:mdna:51]
Interest expense was $3.0 million for the first nine months of 2015 compared to $3.7 million for the first nine months of 2014 and reflects interest for borrowing on the company’s credit agreement.

[0001437749-15-019169:mdna:52]
Foreign exchange loss (gain), reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $1.7 million of income for the first nine months of 2015 compared to $2.0 million of expense for the first nine months of 2014 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar.

[0001437749-15-019169:mdna:53]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $3.8 million of income for the first nine months of 2015 compared to $4.9 million of income for the first nine months of 2014.

[0001437749-15-019169:mdna:54]
Income before income taxes was $76.8 million for the first nine months of 2015 compared to $106.6 million for the first nine months of 2014. The lower income before income taxes for 2015 was primarily due to the pension settlement charge of $30.2 million as described above. Income tax expense was $16.8 million with an effective tax rate of 21.8% for the first nine months of 2015 compared to income tax expense of $26.7 million with an effective tax rate of 25.0% in the first nine months of 2014. The lower effective tax rate for the first nine months of 2015 resulted from income earned in lower tax jurisdictions and the impact of the pension settlement partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations in the third quarter of 2015. The effective tax rates for both 2015 and 2014 were lower than the U.S. statutory tax rate primarily due to the factors discussed above as well as more income earned in lower tax jurisdictions.

[0001437749-15-019169:mdna:55]
Net income for the first nine months of 2015 was $60.0 million or $2.64 per diluted share compared to net income of $79.9 million or $3.52 per diluted share for the same period of 2014.

[0001437749-15-019169:mdna:56]
[same as prior period, unchanged from 0001437749-15-014442:mdna:56]

[0001437749-15-019169:mdna:57]
As of September 26, 2015, $317.5 million of the $336.6 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $317.5 million held by foreign subsidiaries, approximately $19.2 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $19.2 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-15-019169:mdna:58]
[same as prior period, unchanged from 0001437749-15-014442:mdna:58]

[0001437749-15-019169:mdna:59]
[same as prior period, unchanged from 0001437749-15-014442:mdna:59]

[0001437749-15-019169:mdna:60]
In 2013, the company entered into a credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consists of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The credit agreement is for a five year period.

[0001437749-15-019169:mdna:61]
On January 30, 2014, the company increased the unsecured revolving credit facility by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. At September 26, 2015, the company had available $167.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of September 26, 2015).

[0001437749-15-019169:mdna:62]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 26, 2015, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-15-019169:mdna:63]
The company also had $0.1 million outstanding in letters of credit at September 26, 2015. No amounts were drawn under these letters of credit at September 26, 2015.

[0001437749-15-019169:mdna:64]
[same as prior period, unchanged from 0001437749-15-014442:mdna:64]

[0001437749-15-019169:mdna:65]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Net Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 73.5 million (approximately $11.5 million) at September 26, 2015.

[0001437749-15-019169:mdna:66]
[same as prior period, unchanged from 0001437749-15-014442:mdna:66]

[0001437749-15-019169:mdna:67]
The company started 2015 with $297.6 million of cash and cash equivalents. Net cash provided by operating activities was approximately $113.6 million for the first nine months of 2015 reflecting $60.0 million in net income and $57.4 million in non-cash adjustments (primarily $31.1 million in depreciation and amortization) offset by $3.8 million in net changes to various operating assets and liabilities.

[0001437749-15-019169:mdna:68]
Changes in operating assets and liabilities for the first nine months of 2015 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivable ($18.3 million) and inventory ($4.2 million). Changes in operating assets and liabilities having a positive impact on cash flows were decreases in prepaid and other assets ($0.3 million), and increases in accrued payroll and severance ($3.6 million), accrued and deferred taxes ($4.0 million), accounts payable ($4.2 million) and accrued expenses ($6.6 million, including a $9.1 million payment for the pension settlement).

[0001437749-15-019169:mdna:69]
Net cash used in investing activities was approximately $29.0 million for the first nine months of 2015 and primarily represented additions to property, plant and equipment ($35.0 million) offset by a reduction in the entrusted loan receivable ($5.9 million) (see Note 5) .

[0001437749-15-019169:mdna:70]
Net cash used in financing activities was approximately $27.2 million and was primarily driven by the purchase of treasury stock ($31.3 million) and dividends paid ($17.9 million). Also included were payments on the entrusted loan ($5.9 million) (see Note 5). Offsetting net cash used in financing primarily were net proceeds from the company’s credit agreement ($20.3 million). The effects of exchange rate changes decreased cash and cash equivalents by approximately $18.3 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $39.1 million increase in cash, which left the company with a cash and cash equivalents balance of $336.6 million at September 26, 2015.

[0001437749-15-019169:mdna:71]
The ratio of current assets to current liabilities was 2.7 at the end of the third quarter of 2015 compared to 2.8 at year-end 2014 and 2.3 at the end of the third quarter of 2014. Days sales outstanding in accounts receivable was approximately 62 days at the end of the third quarter of 2015 compared to 56 days at the end of the third quarter of 2014 and 60 days at year-end 2014. Days inventory outstanding was approximately 70 days at the end of the third quarter of 2015 compared to 68 days at the year-end 2014 and 70 days at end of the third quarter of 2014.

[0001437749-15-019169:mdna:72]
[same as prior period, unchanged from 0001437749-15-014442:mdna:73]

[0001437749-15-019169:mdna:73]
Economic signals continue to be mixed and visibility continues to be limited. Although the company’s 0.95 book-to-bill for electronics is better than normal for the third quarter, order rates in the first few weeks of the fourth quarter have been relatively weak. At this point, the company expects normal sequential declines in both sales and margins in the fourth quarter.

[0001437749-15-019169:mdna:74]
The fourth quarter of 2015 includes an extra week (14 weeks rather than 13). Taking into account that the extra week is during the holidays, it is expected to add approximately $10 million to sales for the fourth quarter. Including this extra week, sales for the fourth quarter of 2015 are expected to be in the range of $212 to $222 million.

[0001437749-15-019169:mdna:75]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-15-019169:mdna:76]
[same as prior period, unchanged from 0001437749-15-014442:mdna:80]
