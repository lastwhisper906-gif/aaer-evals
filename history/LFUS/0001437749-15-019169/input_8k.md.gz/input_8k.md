# LFUS 8-K — 0001437749-15-018951 filed 2015-10-28

## item codes, every 8-K on or before 2015-10-30

- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2015-10-30

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-15-018951:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-15-018951:8k_2_02:2]
ex99-1.htm

[0001437749-15-018951:8k_2_02:3]
Exhibit 99.1

[0001437749-15-018951:8k_2_02:4]
NEWS RELEASE

[0001437749-15-018951:8k_2_02:5]
CONTACT: Phil Franklin,

[0001437749-15-018951:8k_2_02:6]
Executive Vice President and CFO (773) 628-0810

[0001437749-15-018951:8k_2_02:7]
LITTELFUSE REPORTS THIRD QUARTER RESULTS

[0001437749-15-018951:8k_2_02:8]
CHICAGO, October 28, 2015 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the third quarter ended September 26, 2015.

[0001437749-15-018951:8k_2_02:9]
Third Quarter Highlights

[0001437749-15-018951:8k_2_02:10]
|  | ● | Sales for the third quarter of 2015 were $215.5 million compared to $217.6 million for the prior-year quarter. Excluding currency effects, sales increased by 4% compared to the prior-year quarter due to continued growth in automotive and improvement in the electrical business. |

[0001437749-15-018951:8k_2_02:11]
|  | ● | GAAP earnings for the third quarter of 2015 were $0.50 per diluted share. This included a $30.2 million non-cash pension charge (pre-tax) related to settlement of the company’s U.S. pension plan and other special items (see Supplemental Financial Information on page 8). Excluding these special items, earnings for the third quarter of 2015 were $1.43 per diluted share. This was record performance driven largely by improvement in adjusted operating margin to 19.5%. |

[0001437749-15-018951:8k_2_02:12]
|  | ● | Sales trends by business unit for the third quarter were as follows: |

[0001437749-15-018951:8k_2_02:13]
|  | o | Electronics sales declined 5% year over year (2% excluding currency effects) due to capacity constraints for sensor products as they are being transferred to the Philippines as well as a slightly weaker-than-normal seasonal ramp up for core products. |

[0001437749-15-018951:8k_2_02:14]
|  | o | Automotive sales increased 1% year over year (8% excluding currency effects) reflecting strong constant-currency growth in Europe and moderate growth in both North America and Asia. |

[0001437749-15-018951:8k_2_02:15]
|  | o | Electrical sales increased 8% year over year (12% excluding currency effects) due to solid growth in the core fuse business and continued recovery in custom products. |

[0001437749-15-018951:8k_2_02:16]
|  | ● | The electronics book-to-bill ratio for the third quarter of 2015 was 0.95. |

[0001437749-15-018951:8k_2_02:17]
|  | ● | Cash provided by operating activities for the third quarter of 2015 was $51.6 million ($60.7 million excluding a $9.1 million pension contribution) and now stands at $113.6 million through nine months of 2015 compared to $103.8 million through nine months of 2014. Capital expenditures through nine months of 2015 were $35.0 million compared to $19.4 million through nine months of 2014. |

[0001437749-15-018951:8k_2_02:18]
-more-

[0001437749-15-018951:8k_2_02:19]
The increased capital spending is primarily related to the manufacturing transfer to the Philippines and capacity additions for new automotive products.

[0001437749-15-018951:8k_2_02:20]
|  | ● | The company repurchased 350,000 shares during the third quarter of 2015 at an average price of $89.29 for a total of $31.3 million. There are 650,000 shares remaining on the current repurchase authorization. |

[0001437749-15-018951:8k_2_02:21]
|  | ● | On September 30, the company closed on the acquisition of Sigmar, an Italian company that produces sensors used in gas and diesel engine fuel systems, as well as urea level and quality sensors used in diesel emission reduction systems. Annual revenue is approximately $6 million. |

[0001437749-15-018951:8k_2_02:22]
|  | ● | In the third quarter, the company entered into an agreement with an insurance company to purchase an annuity contract to settle its U.S. pension liability and transfer payment responsibility. Related to this transaction, the company contributed $9.1 million of cash to the plan and took a non-cash charge of $30.2 million to recognize unamortized losses on the balance sheet. |

[0001437749-15-018951:8k_2_02:23]
“Our teams continue to execute well in a generally challenging global economic environment,” said Gordon Hunter, chief executive officer. “Our electrical business is recovering on both the top and bottom lines; automotive is beginning to make progress on its margin improvement initiatives and electronics profitability continues to be strong. Manufacturing performed well across the board, with improvements at our Piedras Negras, Mexico site particularly notable.”

[0001437749-15-018951:8k_2_02:24]
Outlook

[0001437749-15-018951:8k_2_02:25]
“Economic signals continue to be mixed and visibility continues to be limited,” said Hunter. “Although our 0.95 book-to-bill for electronics is better than normal for the third quarter, order rates in the first few weeks of the fourth quarter have been relatively weak. At this point, we expect normal sequential declines in both sales and margins in the fourth quarter.”

[0001437749-15-018951:8k_2_02:26]
|  | ● | The fourth quarter of 2015 includes an extra week (14 weeks rather than 13). Taking into account that the extra week is during the holidays, it is expected to add approximately $10 million to sales for the fourth quarter. Including this extra week, sales for the fourth quarter of 2015 are expected to be in the range of $212 to $222 million. |

[0001437749-15-018951:8k_2_02:27]
|  | ● | Earnings for the fourth quarter of 2015 are expected to be in the range of $1.12 to $1.24 per diluted share assuming a tax rate of 24% and excluding any special items. This includes the estimated impact of $0.02 per diluted share for the extra week. |

[0001437749-15-018951:8k_2_02:28]
-more-

[0001437749-15-018951:8k_2_02:29]
Dividend

[0001437749-15-018951:8k_2_02:30]
The company will pay a cash dividend of $0.29 per common share on December 3, 2015 to shareholders of record at the close of business on November 19, 2015.

[0001437749-15-018951:8k_2_02:31]
Conference Call and Webcast Information

[0001437749-15-018951:8k_2_02:32]
Littelfuse will host a conference call today, Wednesday, October 28, 2015, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the third quarter results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay through December 31, 2015 on the company’s website.

[0001437749-15-018951:8k_2_02:33]
About Littelfuse

[0001437749-15-018951:8k_2_02:34]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power

[0001437749-15-018951:8k_2_02:35]
control and sensing. The company serves customers in the electronics, automotive and industrial markets

[0001437749-15-018951:8k_2_02:36]
with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 8,000 employees in more than 35 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: littelfuse.com.

[0001437749-15-018951:8k_2_02:37]
| “Safe Harbor” Statement under the Private Securities Litigation Reform Act of 1995. The statements in this press release that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended December 27, 2014. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended December 27, 2014. |

[0001437749-15-018951:8k_2_02:38]
# # #

[0001437749-15-018951:8k_2_02:39]
LITTELFUSE, INC.

[0001437749-15-018951:8k_2_02:40]
Net Sales and Operating Income by Business Unit

[0001437749-15-018951:8k_2_02:41]
(In thousands of USD, unaudited)

[0001437749-15-018951:8k_2_02:42]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 102,616 |  |  | $ | 107,754 |  |  |  | (5 | %) |  | $ | 307,549 |  |  | $ | 313,726 |  |  |  | (2 | %) |
| Automotive |  |  | 81,475 |  |  |  | 80,639 |  |  |  | 1 | % |  |  | 251,464 |  |  |  | 245,083 |  |  |  | 3 | % |
| Electrical |  |  | 31,419 |  |  |  | 29,215 |  |  |  | 8 | % |  |  | 88,831 |  |  |  | 86,566 |  |  |  | 3 | % |
| Total net sales |  | $ | 215,510 |  |  | $ | 217,608 |  |  |  | (1 | %) |  | $ | 647,844 |  |  | $ | 645,375 |  |  |  | 0 | % |

[0001437749-15-018951:8k_2_02:43]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 20,923 |  |  | $ | 25,800 |  |  |  | (19 | %) |  | $ | 61,755 |  |  | $ | 70,805 |  |  |  | (13 | %) |
| Automotive |  |  | 15,253 |  |  |  | 12,227 |  |  |  | 25 | % |  |  | 39,123 |  |  |  | 35,158 |  |  |  | 11 | % |
| Electrical |  |  | 5,781 |  |  |  | 3,224 |  |  |  | 79 | % |  |  | 13,220 |  |  |  | 7,541 |  |  |  | 75 | % |
| Other (1) |  |  | (33,373 | ) |  |  | (1,121 | ) |  |  | 2877 | % |  |  | (39,795 | ) |  |  | (6,065 | ) |  |  | 556 | % |
| Total operating income |  | $ | 8,584 |  |  | $ | 40,130 |  |  |  | (79 | %) |  | $ | 74,303 |  |  | $ | 107,439 |  |  |  | (31 | %) |
| Interest expense |  |  | 922 |  |  |  | 1,292 |  |  |  |  |  |  |  | 3,021 |  |  |  | 3,736 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | (3,549 | ) |  |  | (101 | ) |  |  |  |  |  |  | (1,724 | ) |  |  | 2,022 |  |  |  |  |  |
| Other (income) expense, net |  |  | (1,430 | ) |  |  | (2,261 | ) |  |  |  |  |  |  | (3,758 | ) |  |  | (4,893 | ) |  |  |  |  |
| Income before taxes |  | $ | 12,641 |  |  | $ | 41,200 |  |  |  | (69% | ) |  | $ | 76,764 |  |  | $ | 106,574 |  |  |  | (28 | %) |

[0001437749-15-018951:8k_2_02:44]
(1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details on page 8.)

[0001437749-15-018951:8k_2_02:45]
-more-

[0001437749-15-018951:8k_2_02:46]
LITTELFUSE, INC.

[0001437749-15-018951:8k_2_02:47]
Condensed Consolidated Balance Sheets

[0001437749-15-018951:8k_2_02:48]
(In thousands of USD, except share amounts)

[0001437749-15-018951:8k_2_02:49]
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 336,640 |  |  | $ | 297,571 |  |
| Short-term investments |  |  | 3,958 |  |  |  | 4,302 |  |
| Accounts receivable, less allowances |  |  | 145,655 |  |  |  | 135,356 |  |
| Inventories |  |  | 99,203 |  |  |  | 97,391 |  |
| Deferred income taxes |  |  | 14,139 |  |  |  | 17,481 |  |
| Prepaid expenses and other current assets |  |  | 14,179 |  |  |  | 13,904 |  |
| Assets held for sale |  |  | - |  |  |  | 5,500 |  |
| Total current assets |  |  | 613,774 |  |  |  | 571,505 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 5,292 |  |  |  | 5,697 |  |
| Buildings |  |  | 69,420 |  |  |  | 64,609 |  |
| Equipment |  |  | 378,716 |  |  |  | 370,179 |  |
|  |  |  | 453,428 |  |  |  | 440,485 |  |
| Accumulated depreciation |  |  | (290,663 | ) |  |  | (281,845 | ) |
| Net property, plant and equipment |  |  | 162,765 |  |  |  | 158,640 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 20,180 |  |  |  | 23,640 |  |
| Distribution network |  |  | 17,175 |  |  |  | 19,428 |  |
| Customer lists, trademarks and tradenames |  |  | 55,366 |  |  |  | 60,605 |  |
| Goodwill |  |  | 190,016 |  |  |  | 196,256 |  |
|  |  |  | 282,737 |  |  |  | 299,929 |  |
| Investments |  |  | 11,196 |  |  |  | 12,056 |  |
| Deferred income taxes |  |  | 5,189 |  |  |  | 5,393 |  |
| Other assets |  |  | 16,216 |  |  |  | 23,303 |  |
| Total assets |  | $ | 1,091,877 |  |  | $ | 1,070,826 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 53,308 |  |  | $ | 50,793 |  |
| Accrued payroll |  |  | 31,281 |  |  |  | 30,511 |  |
| Accrued expenses |  |  | 20,641 |  |  |  | 13,059 |  |
| Accrued severance |  |  | 2,619 |  |  |  | 790 |  |
| Accrued income taxes |  |  | 6,738 |  |  |  | 9,045 |  |
| Current portion of accrued post-retirement benefits |  |  | - |  |  |  | 11,768 |  |
| Current portion of long-term debt |  |  | 117,500 |  |  |  | 88,500 |  |
| Total current liabilities |  |  | 232,087 |  |  |  | 204,466 |  |
| Long-term debt, less current portion |  |  | 91,517 |  |  |  | 106,658 |  |
| Deferred income taxes |  |  | 18,565 |  |  |  | 11,076 |  |
| Accrued post-retirement benefits |  |  | 5,025 |  |  |  | 5,147 |  |
| Other long-term liabilities |  |  | 10,943 |  |  |  | 15,814 |  |
| Total equity |  |  | 733,740 |  |  |  | 727,665 |  |
| Total liabilities and equity |  | $ | 1,091,877 |  |  | $ | 1,070,826 |  |

[0001437749-15-018951:8k_2_02:50]
Common shares issued and outstanding of 22,379,901 and 22,585,529 at September 26, 2015 and December 27, 2014, respectively.

[0001437749-15-018951:8k_2_02:51]
-more-

[0001437749-15-018951:8k_2_02:52]
LITTELFUSE, INC.

[0001437749-15-018951:8k_2_02:53]
Consolidated Statements of Comprehensive Income

[0001437749-15-018951:8k_2_02:54]
(In thousands of USD, except per share data, unaudited)

[0001437749-15-018951:8k_2_02:55]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| Net sales |  | $ | 215,510 |  |  | $ | 217,608 |  |  | $ | 647,844 |  |  | $ | 645,375 |  |
| Cost of sales |  |  | 129,328 |  |  |  | 130,228 |  |  |  | 400,051 |  |  |  | 396,506 |  |
| Gross profit |  |  | 86,182 |  |  |  | 87,380 |  |  |  | 247,793 |  |  |  | 248,869 |  |
| Selling, general and administrative expenses |  |  | 37,002 |  |  |  | 36,647 |  |  |  | 112,119 |  |  |  | 109,146 |  |
| Research and development expenses |  |  | 7,479 |  |  |  | 7,449 |  |  |  | 22,224 |  |  |  | 22,833 |  |
| Pension settlement expense |  |  | 30,194 |  |  |  | - |  |  |  | 30,194 |  |  |  | - |  |
| Amortization of intangibles |  |  | 2,923 |  |  |  | 3,154 |  |  |  | 8,953 |  |  |  | 9,451 |  |
|  |  |  | 77,598 |  |  |  | 47,250 |  |  |  | 173,490 |  |  |  | 141,430 |  |
| Operating income |  |  | 8,584 |  |  |  | 40,130 |  |  |  | 74,303 |  |  |  | 107,439 |  |
| Interest expense |  |  | 922 |  |  |  | 1,292 |  |  |  | 3,021 |  |  |  | 3,736 |  |
| Foreign exchange (gain) loss |  |  | (3,549 | ) |  |  | (101 | ) |  |  | (1,724 | ) |  |  | 2,022 |  |
| Other (income) expense, net |  |  | (1,430 | ) |  |  | (2,261 | ) |  |  | (3,758 | ) |  |  | (4,893 | ) |
| Income before income taxes |  |  | 12,641 |  |  |  | 41,200 |  |  |  | 76,764 |  |  |  | 106,574 |  |
| Income taxes |  |  | 1,317 |  |  |  | 11,260 |  |  |  | 16,761 |  |  |  | 26,667 |  |
| Net income |  | $ | 11,324 |  |  | $ | 29,940 |  |  | $ | 60,003 |  |  | $ | 79,907 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 1.33 |  |  | $ | 2.65 |  |  | $ | 3.55 |  |
| Diluted |  | $ | 0.50 |  |  | $ | 1.32 |  |  | $ | 2.64 |  |  | $ | 3.52 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,581 |  |  |  | 22,536 |  |  |  | 22,623 |  |  |  | 22,536 |  |
| Diluted |  |  | 22,693 |  |  |  | 22,689 |  |  |  | 22,771 |  |  |  | 22,722 |  |
| Comprehensive income |  | $ | 2,187 |  |  | $ | 13,209 |  |  | $ | 45,896 |  |  | $ | 66,444 |  |

[0001437749-15-018951:8k_2_02:56]
-more-

[0001437749-15-018951:8k_2_02:57]
LITTELFUSE, INC.

[0001437749-15-018951:8k_2_02:58]
Consolidated Statements of Cash Flows

[0001437749-15-018951:8k_2_02:59]
(In thousands of USD, unaudited)

[0001437749-15-018951:8k_2_02:60]
|  |  | For the Nine Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 60,003 |  |  | $ | 79,907 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 22,154 |  |  |  | 21,736 |  |
| Amortization of intangibles |  |  | 8,952 |  |  |  | 9,451 |  |
| Non-cash inventory charge (1) |  |  | - |  |  |  | 2,769 |  |
| Stock-based compensation |  |  | 7,997 |  |  |  | 7,168 |  |
| Excess tax benefit on stock-based compensation |  |  | (1,500 | ) |  |  | (2,477 | ) |
| Net loss on pension settlement, net of tax |  |  | 19,472 |  |  |  | - |  |
| Loss on sale of assets |  |  | 308 |  |  |  | 673 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (18,274 | ) |  |  | (9,728 | ) |
| Inventories |  |  | (4,203 | ) |  |  | (4,118 | ) |
| Accounts payable |  |  | 4,216 |  |  |  | 3,024 |  |
| Accrued expenses (including post retirement) |  |  | 6,577 |  |  |  | (7,080 | ) |
| Accrued payroll and severance |  |  | 3,598 |  |  |  | (1,198 | ) |
| Accrued taxes |  |  | 4,006 |  |  |  | 5,756 |  |
| Prepaid expenses and other |  |  | 277 |  |  |  | (2,052 | ) |
| Net cash provided by operating activities |  |  | 113,583 |  |  |  | 103,831 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (35,016 | ) |  |  | (19,422 | ) |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (52,768 | ) |
| Proceeds from maturities of short-term investments |  |  | - |  |  |  | 6,770 |  |
| Decrease in entrusted loan receivable |  |  | 5,930 |  |  |  | - |  |
| Proceeds from sale of assets |  |  | 38 |  |  |  | 72 |  |
| Net cash used in investing activities |  |  | (29,048 | ) |  |  | (65,348 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 49,000 |  |  |  | 97,500 |  |
| Payments of revolving credit facility |  |  | (25,000 | ) |  |  | (37,000 | ) |
| Payments of term loan |  |  | (3,750 | ) |  |  | (3,750 | ) |
| Payments of entrusted loan |  |  | (5,930 | ) |  |  | - |  |
| Debt issuance costs paid |  |  | (42 | ) |  |  | (108 | ) |
| Cash dividends paid |  |  | (17,864 | ) |  |  | (15,543 | ) |
| Purchases of common stock |  |  | (31,252 | ) |  |  | (14,283 | ) |
| Proceeds from exercise of stock options |  |  | 6,186 |  |  |  | 12,170 |  |
| Excess tax benefit on share-based compensation |  |  | 1,500 |  |  |  | 2,477 |  |
| Net cash (used in) provided by financing activities |  |  | (27,152 | ) |  |  | 41,463 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (18,314 | ) |  |  | (6,862 | ) |
| Increase in cash and cash equivalents |  |  | 39,069 |  |  |  | 73,084 |  |
| Cash and cash equivalents at beginning of period |  |  | 297,571 |  |  |  | 305,192 |  |
| Cash and cash equivalents at end of period |  | $ | 336,640 |  |  | $ | 378,276 |  |

[0001437749-15-018951:8k_2_02:61]
| (1) Purchase accounting adjustment related to acquisitions. |

[0001437749-15-018951:8k_2_02:62]
-more-

[0001437749-15-018951:8k_2_02:63]
LITTELFUSE, INC.

[0001437749-15-018951:8k_2_02:64]
Supplemental Financial Information

[0001437749-15-018951:8k_2_02:65]
(in millions of USD except per share amounts)

[0001437749-15-018951:8k_2_02:66]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-15 |  |  | Q2-15 |  |  | Q3-15 |  |  | YTD-15 |  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | YTD-14 |  |
| GAAP diluted EPS |  | $ | 0.88 |  |  | $ | 1.26 |  |  | $ | 0.50 |  |  | $ | 2.64 |  |  | $ | 1.12 |  |  | $ | 1.08 |  |  | $ | 1.32 |  |  | $ | 3.52 |  |
| EPS impact of special items (below) |  |  | 0.20 |  |  |  | 0.07 |  |  |  | 0.93 |  |  |  | 1.20 |  |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.03 |  |  |  | 0.25 |  |
| Adjusted diluted EPS |  | $ | 1.08 |  |  | $ | 1.33 |  |  | $ | 1.43 |  |  | $ | 3.84 |  |  | $ | 1.16 |  |  | $ | 1.26 |  |  | $ | 1.35 |  |  | $ | 3.77 |  |
| Year-over-year adjusted EPS growth |  |  | (7 | %) |  |  | 6 | % |  |  | 6 | % |  |  | 2 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special Items (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.2 |  |  | $ | 3.1 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Restructuring |  |  | 1.2 |  |  |  | 1.7 |  |  |  | 0.9 |  |  |  | 3.8 |  |  |  | - |  |  |  | 2.0 |  |  |  | 1.1 |  |  |  | 3.1 |  |
| Acquisition expenses |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.7 |  |  |  | - |  |  |  | 0.2 |  |  |  | - |  |  |  | 0.2 |  |
| U.S. Pension wind-up and settlement costs |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 30.8 |  |  |  | 32.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Purchase accounting adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.4 |  |  |  | 1.4 |  |  |  | - |  |  |  | 2.8 |  |
| Other |  |  | - |  |  |  | - |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Adjustment to Operating income |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 33.4 |  |  |  | 39.8 |  |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 6.1 |  |
| Foreign exchange loss/(gain) |  |  | 3.1 |  |  |  | (1.3 | ) |  |  | (3.5 | ) |  |  | (1.7 | ) |  |  | (0.3 | ) |  |  | 2.4 |  |  |  | (0.1 | ) |  |  | 2.0 |  |
| Adjustment to pre-tax income |  | $ | 6.1 |  |  | $ | 2.1 |  |  | $ | 29.8 |  |  | $ | 38.1 |  |  | $ | 1.2 |  |  | $ | 6.0 |  |  | $ | 1.0 |  |  | $ | 8.1 |  |
| Total EPS impact |  | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 0.93 |  |  | $ | 1.20 |  |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.03 |  |  | $ | 0.25 |  |

[0001437749-15-018951:8k_2_02:67]
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-15 |  |  | Q2-15 |  |  | Q3-15 |  |  | YTD-15 |  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | YTD-14 |  |
| Net sales |  | $ | 210.3 |  |  | $ | 222.0 |  |  | $ | 215.5 |  |  | $ | 647.8 |  |  | $ | 206.9 |  |  | $ | 220.9 |  |  | $ | 217.6 |  |  | $ | 645.4 |  |
| GAAP operating income |  | $ | 29.5 |  |  | $ | 36.2 |  |  | $ | 8.6 |  |  | $ | 74.3 |  |  | $ | 33.6 |  |  | $ | 33.7 |  |  | $ | 40.1 |  |  | $ | 107.4 |  |
| GAAP operating margin |  |  | 14.0 | % |  |  | 16.3 | % |  |  | 4.0 | % |  |  | 11.5 | % |  |  | 16.2 | % |  |  | 15.3 | % |  |  | 18.4 | % |  |  | 16.6 | % |
| Add back special operating items |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 33.4 |  |  |  | 39.8 |  |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 6.1 |  |
| Adjusted operating income |  | $ | 32.5 |  |  | $ | 39.6 |  |  | $ | 42.0 |  |  | $ | 114.1 |  |  | $ | 35.0 |  |  | $ | 37.2 |  |  | $ | 41.3 |  |  | $ | 113.5 |  |
| Adjusted operating margin |  |  | 15.5 | % |  |  | 17.8 | % |  |  | 19.5 | % |  |  | 17.6 | % |  |  | 16.9 | % |  |  | 16.8 | % |  |  | 19.0 | % |  |  | 17.6 | % |
| Add back amortization |  |  | 3.1 |  |  |  | 2.9 |  |  |  | 3.0 |  |  |  | 9.0 |  |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 3.2 |  |  |  | 9.5 |  |
| Add back depreciation |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 22.1 |  |  |  | 7.0 |  |  |  | 7.5 |  |  |  | 7.3 |  |  |  | 21.7 |  |
| Adjusted EBITDA |  | $ | 43.0 |  |  | $ | 49.9 |  |  | $ | 52.4 |  |  | $ | 145.2 |  |  | $ | 45.2 |  |  | $ | 47.8 |  |  | $ | 51.8 |  |  | $ | 144.6 |  |
| Adjusted EBITDA margin |  |  | 20.4 | % |  |  | 22.5 | % |  |  | 24.3 | % |  |  | 22.4 | % |  |  | 21.8 | % |  |  | 21.6 | % |  |  | 23.8 | % |  |  | 22.4 | % |
| Year-over-year adjusted EBITDA growth |  |  | (5 | %) |  |  | 4 | % |  |  | 1 | % |  |  | 0 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-15-018951:8k_2_02:68]
Note: Totals will not always foot due to rounding

[0001437749-15-018951:8k_2_02:69]
###
