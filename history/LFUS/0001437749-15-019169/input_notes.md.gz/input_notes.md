# LFUS notes — 0001437749-15-019169


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-15-019169:notes:1]
[same as prior period, unchanged from 0001437749-15-014442:notes:1]

[0001437749-15-019169:notes:2]
[same as prior period, unchanged from 0001437749-15-014442:notes:2]

[0001437749-15-019169:notes:3]
| AOCI component |  | Balance at December 27, 2014 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Reclassification adjustment for pension settlement expense included in net income |  |  | Balance at September 27, 2015 |  |
| Pension liability adjustment(a) |  | $ | (29,615 | ) |  | $ | (140 | ) |  | $ | 1,457 |  |  | $ | 21,124 |  |  | $ | (7,174 | ) |
| Unrealized gain (loss) on investments(b) |  |  | 10,791 |  |  |  | (18 | ) |  |  | — |  |  |  | — |  |  |  | 10,773 |  |
| Foreign currency translation adjustment |  |  | (2,302 | ) |  |  | (36,530 | ) |  |  | — |  |  |  | — |  |  |  | (38,832 | ) |
| AOCI (loss) income |  | $ | (21,126 | ) |  | $ | (36,688 | ) |  | $ | 1,457 |  |  | $ | 21,124 |  |  | $ | (35,233 | ) |

[0001437749-15-019169:notes:4]
(a) Balances are net of tax of $3,115 and $12,587 for 2015 and 2014, respectively.

[0001437749-15-019169:notes:5]
[same as prior period, unchanged from 0001437749-15-014442:notes:5]


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0001437749-15-019169:notes:6]
[same as prior period, unchanged from 0001437749-15-014442:notes:6]

[0001437749-15-019169:notes:7]
[same as prior period, unchanged from 0001437749-15-014442:notes:7]

[0001437749-15-019169:notes:8]
[same as prior period, unchanged from 0001437749-15-014442:notes:8]

[0001437749-15-019169:notes:9]
[same as prior period, unchanged from 0001437749-15-014442:notes:9]

[0001437749-15-019169:notes:10]
The company’s other investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company. The Polytronics investment was acquired as part of the Heinrich Companies acquisition in 2004. The fair value of the Polytronics investment was €10.0 million (approximately $11.2 million) at September 26, 2015 and €9.9 million (approximately $12.1 million) at December 27, 2014. Included in 2015 other comprehensive income is an unrealized loss of less than $

[0001437749-15-019169:notes:11]
0.1 million, due to the decrease in fair market value of the Polytronics investment. The remaining movement was due to the impact of changes in exchange rates.


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-019169:notes:12]
5. Debt

[0001437749-15-019169:notes:13]
The carrying amounts of debt at September 26, 2015 and December 27, 2014 are as follows (in thousands):

[0001437749-15-019169:notes:14]
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 90,000 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 107,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 11,517 |  |  |  | 17,908 |  |
| Total debt |  |  | 209,017 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 117,500 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 91,517 |  |  | $ | 106,658 |  |

[0001437749-15-019169:notes:15]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of September 26, 2015, the company had available $167.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of September 26, 2015). At September 26, 2015, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-15-019169:notes:16]
Entrusted Loan

[0001437749-15-019169:notes:17]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-019169:notes:18]
[same as prior period, unchanged from 0001437749-15-014442:notes:17]

[0001437749-15-019169:notes:19]
[same as prior period, unchanged from 0001437749-15-014442:notes:18]

[0001437749-15-019169:notes:20]
The following table sets forth the computation of basic and diluted earnings per share for the periods ended September 26, 2015 and September 27, 2014 (in thousands except per share amounts).

[0001437749-15-019169:notes:21]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| Net income |  | $ | 11,324 |  |  | $ | 29,940 |  |  | $ | 60,003 |  |  | $ | 79,907 |  |
| Average shares outstanding - Basic |  |  | 22,581 |  |  |  | 22,536 |  |  |  | 22,623 |  |  |  | 22,536 |  |
| Net effect of dilutive stock options and restricted share units |  |  | 112 |  |  |  | 153 |  |  |  | 148 |  |  |  | 186 |  |
| Average shares - Diluted |  |  | 22,693 |  |  |  | 22,689 |  |  |  | 22,771 |  |  |  | 22,722 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | .50 |  |  | $ | 1.33 |  |  | $ | 2.65 |  |  | $ | 3.55 |  |
| Diluted |  | $ | .50 |  |  | $ | 1.32 |  |  | $ | 2.64 |  |  | $ | 3.52 |  |

[0001437749-15-019169:notes:22]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 144,031 and 64,520 for the three months ended September 26, 2015 and September 27, 2014, respectively, and 108,193 and 36,698 for the nine months ended September 26

[0001437749-15-019169:notes:23]
[same as prior period, unchanged from 0001437749-15-014442:notes:22]

[0001437749-15-019169:notes:24]
and September 27

[0001437749-15-019169:notes:25]
[same as prior period, unchanged from 0001437749-15-014442:notes:24]

[0001437749-15-019169:notes:26]
[same as prior period, unchanged from 0001437749-15-014442:notes:25]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-15-019169:notes:27]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 11,196 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,196 |  |
| Total |  | $ | 11,196 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,196 |  |

[0001437749-15-019169:notes:28]
[same as prior period, unchanged from 0001437749-15-014442:notes:26]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-019169:notes:29]
[same as prior period, unchanged from 0001437749-15-014442:notes:28]

[0001437749-15-019169:notes:30]
[same as prior period, unchanged from 0001437749-15-014442:notes:29]

[0001437749-15-019169:notes:31]
[same as prior period, unchanged from 0001437749-15-014442:notes:30]

[0001437749-15-019169:notes:32]
[same as prior period, unchanged from 0001437749-15-014442:notes:31]

[0001437749-15-019169:notes:33]
[same as prior period, unchanged from 0001437749-15-014442:notes:32]

[0001437749-15-019169:notes:34]
[same as prior period, unchanged from 0001437749-15-014442:notes:33]

[0001437749-15-019169:notes:35]
[same as prior period, unchanged from 0001437749-15-014442:notes:34]

[0001437749-15-019169:notes:36]
[same as prior period, unchanged from 0001437749-15-014442:notes:35]

[0001437749-15-019169:notes:37]
[same as prior period, unchanged from 0001437749-15-014442:notes:36]

[0001437749-15-019169:notes:38]
[same as prior period, unchanged from 0001437749-15-014442:notes:37]

[0001437749-15-019169:notes:39]
There were no changes during the nine months ended September 26, 2015 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 26, 2015 and December 27, 2014 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-15-019169:notes:40]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 26, 2015 (in thousands):

[0001437749-15-019169:notes:41]
N

[0001437749-15-019169:notes:42]
otes to

[0001437749-15-019169:notes:43]
CONDENSED

[0001437749-15-019169:notes:44]
Consolidated Financial Statements (Unaudited)

[0001437749-15-019169:notes:45]
, continued

[0001437749-15-019169:notes:46]
[same as prior period, unchanged from 0001437749-15-014442:notes:40]

[0001437749-15-019169:notes:47]
[same as prior period, unchanged from 0001437749-15-014442:notes:41]

[0001437749-15-019169:notes:48]
, short-term investments, accounts receivable and accounts payable approximate their fair values. The company’s debt fair value approximates book value at September 26, 2015 and December 27, 2014, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-019169:notes:49]
[same as prior period, unchanged from 0001437749-15-014442:notes:43]

[0001437749-15-019169:notes:50]
[same as prior period, unchanged from 0001437749-15-014442:notes:44]

[0001437749-15-019169:notes:51]
[same as prior period, unchanged from 0001437749-15-014442:notes:45]

[0001437749-15-019169:notes:52]
The effective tax rate for the third quarter of 2015 was 10.4% compared to an effective tax rate of 27.3% in the third quarter of 2014

[0001437749-15-019169:notes:53]
. The effective tax rate for the nine months ended September 26, 2015 was 21.8% as compared to an effective tax rate of 25.0% for the nine months ended September 27, 2014. The effective tax rates for both the third

[0001437749-15-019169:notes:54]
Notes to

[0001437749-15-019169:notes:55]
8. Income taxes, continued

[0001437749-15-019169:notes:56]
quarter and nine month periods of 2015 and 2014 are lower than the U.S. statutory tax rate primarily due to the result of income earned in lower tax jurisdictions and, with respect to the 2015 periods, the impact of the pension settlement partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations as of June 28, 2015.

[0001437749-15-019169:notes:57]
The following tables set forth the components of pre-tax income/(expense) and the effective tax rates for the three and nine months ended September 26, 2015 (in thousands).

[0001437749-15-019169:notes:58]
|  |  | For the Three Months ended September 26, 2015 |  |
| Pre-tax income/(expense) category |  | Pre-tax income/(expense) amount |  |  | Income tax (expense)/benefit |  |  | Effective tax rate |  |
| Pension settlement |  | $ | (30,194 | ) |  | $ | 10,722 |  |  |  | 35.5 | % |
| Legal restructuring tax impact |  |  | — |  |  |  | (1,949 | ) |  |  | — |  |
| All other income/(expense) |  |  | 42,835 |  |  |  | (10,090 | ) |  |  | 23.6 | % |
| Total consolidated |  | $ | 12,641 |  |  | $ | (1,317 | ) |  |  | 10.4 | % |

[0001437749-15-019169:notes:59]
|  |  | For the Nine Months ended September 26, 2015 |  |
| Pre-tax income/(expense) category |  | Pre-tax income/(expense) amount |  |  | Income tax (expense)/benefit |  |  | Effective tax rate |  |
| Pension settlement |  | $ | (30,194 | ) |  | $ | 10,722 |  |  |  | 35.5 | % |
| Legal restructuring tax impact |  |  | — |  |  |  | (1,949 | ) |  |  | — |  |
| All other income/(expense) |  |  | 106,958 |  |  |  | (25,534 | ) |  |  | 23.9 | % |
| Total consolidated |  | $ | 76,764 |  |  | $ | (16,761 | ) |  |  | 21.8 | % |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-15-019169:notes:60]
[same as prior period, unchanged from 0001437749-15-014442:notes:49]

[0001437749-15-019169:notes:61]
The components of inventories at September 26, 2015 and December 27, 2014 are as follows (in thousands):

[0001437749-15-019169:notes:62]
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
| Raw material |  | $ | 34,235 |  |  | $ | 29,756 |  |
| Work in process |  |  | 16,443 |  |  |  | 15,164 |  |
| Finished goods |  |  | 48,525 |  |  |  | 52,471 |  |
| Total inventories |  | $ | 99,203 |  |  | $ | 97,391 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-15-019169:notes:63]
[same as prior period, unchanged from 0001437749-15-014442:notes:52]

[0001437749-15-019169:notes:64]
[same as prior period, unchanged from 0001437749-15-014442:notes:53]

[0001437749-15-019169:notes:65]
[same as prior period, unchanged from 0001437749-15-014442:notes:54]

[0001437749-15-019169:notes:66]
[same as prior period, unchanged from 0001437749-15-014442:notes:55]

[0001437749-15-019169:notes:67]
[same as prior period, unchanged from 0001437749-15-014442:notes:56]

[0001437749-15-019169:notes:68]
SymCom final purchase price allocation (in thousands):

[0001437749-15-019169:notes:69]
| Cash |  | $ | 325 |  |
| Current assets, net |  |  | 9,154 |  |
| Property, plant and equipment |  |  | 11,193 |  |
| Goodwill |  |  | 15,018 |  |
| Trademarks |  |  | 17,020 |  |
| Patents |  |  | 1,500 |  |
| Other non-current assets |  |  | 20 |  |
| Current liabilities |  |  | (1,137 | ) |
|  |  | $ | 53,093 |  |

[0001437749-15-019169:notes:70]
[same as prior period, unchanged from 0001437749-15-014442:notes:58]

[0001437749-15-019169:notes:71]
As required by purchase accounting rules, the company recorded a $2.8 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. During the first six months of 2014, as a portion of this inventory was sold, cost of goods sold included a $2.8 million non-cash charge for this step-up.

[0001437749-15-019169:notes:72]
[same as prior period, unchanged from 0001437749-15-014442:notes:60]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-15-019169:notes:73]
[same as prior period, unchanged from 0001437749-15-014442:notes:61]

[0001437749-15-019169:notes:74]
The components of net periodic benefit cost for the three and nine months ended September 26, 2015, compared with the three and nine months ended September 27, 2014, were (in thousands):

[0001437749-15-019169:notes:75]
|  |  | U.S. Pension Benefits |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |  | September 26, 2015 |  |  | September 27, 2014 |  |  | September 26, 2015 |  |  | September 27, 2014 |  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| Service cost |  | $ | 250 |  |  | $ | 150 |  |  | $ | 750 |  |  | $ | 450 |  |  | $ | 314 |  |  | $ | 311 |  |  | $ | 944 |  |  | $ | 933 |  |
| Interest cost |  |  | 1,032 |  |  |  | 971 |  |  |  | 3,094 |  |  |  | 2,913 |  |  |  | 512 |  |  |  | 591 |  |  |  | 1,538 |  |  |  | 1,774 |  |
| Expected return on plan assets |  |  | (917 | ) |  |  | (1,412 | ) |  |  | (2,749 | ) |  |  | (4,234 | ) |  |  | (599 | ) |  |  | (572 | ) |  |  | (1,800 | ) |  |  | (1,718 | ) |
| Amortization of net loss |  |  | 290 |  |  |  | 137 |  |  |  | 870 |  |  |  | 411 |  |  |  | 62 |  |  |  | 47 |  |  |  | 185 |  |  |  | 142 |  |
| Total cost (credit) of the plan |  |  | 655 |  |  |  | (154 | ) |  |  | 1,965 |  |  |  | (460 | ) |  |  | 289 |  |  |  | 377 |  |  |  | 867 |  |  |  | 1,131 |  |
| Expected plan participants’ contribution |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net periodic benefit cost (credit) |  |  | 655 |  |  |  | (154 | ) |  |  | 1,965 |  |  |  | (460 | ) |  |  | 289 |  |  |  | 377 |  |  |  | 867 |  |  |  | 1,131 |  |
| Settlement charge |  |  | 30,194 |  |  |  | - |  |  |  | 30,194 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Total pension cost (credit) |  | $ | 30,849 |  |  | $ | (154 | ) |  | $ | 32,159 |  |  | $ | (460 | ) |  | $ | 289 |  |  | $ | 377 |  |  | $ | 867 |  |  | $ | 1,131 |  |

[0001437749-15-019169:notes:76]
[same as prior period, unchanged from 0001437749-15-014442:notes:64]

[0001437749-15-019169:notes:77]
9

[0001437749-15-019169:notes:78]
9. Pensions, continued

[0001437749-15-019169:notes:79]
U.S. Defined Benefit Pension

[0001437749-15-019169:notes:80]
[same as prior period, unchanged from 0001437749-15-014442:notes:65]

[0001437749-15-019169:notes:81]
The company received approval from the IRS on April 14, 2015 on its Application for Determination for Terminating Plan to terminate the U.S. defined benefit pension plan, the Littelfuse Inc. Retirement Plan, effective July 30, 2014. All plan liabilities were settled (either via lump sum payout or purchase of a group annuity contract) in the third quarter of 2015. A cash contribution of $9.1 million was made by the company to the U.S. defined benefit pension plan’s trust in the third quarter of 2015 to fully fund the plan on a buyout basis. The settlement of the plan’s liabilities resulted in a pre-tax settlement charge of $30.2 million in the third quarter of 2015.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-15-019169:notes:82]
|  |  | Long-lived assets(b) |  |
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
| United States |  | $ | 27,250 |  |  | $ | 34,179 |  |
| Mexico |  |  | 13,613 |  |  |  | 47,936 |  |
| China |  |  | 37,900 |  |  |  | 40,981 |  |
| Other countries |  |  | 84,002 |  |  |  | 35,544 |  |
| Total |  | $ | 162,765 |  |  | $ | 158,640 |  |

[0001437749-15-019169:notes:83]
|  |  | Additions to long-lived assets |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| United States |  | $ | 8,367 |  |  | $ | 5,215 |  |
| Mexico |  |  | 6,518 |  |  |  | 5,784 |  |
| China |  |  | 5,159 |  |  |  | 3,461 |  |
| Other countries |  |  | 15,082 |  |  |  | 4,962 |  |
| Total |  | $ | 35,126 |  |  | $ | 19,422 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001437749-15-019169:notes:84]
|  |  | For the Three Months Ended(a) |  |  | For the Nine Months Ended(a) |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| United States |  | $ | 85,049 |  |  | $ | 85,326 |  |  | $ | 258,030 |  |  | $ | 243,979 |  |
| China |  |  | 49,345 |  |  |  | 45,905 |  |  |  | 143,694 |  |  |  | 134,166 |  |
| Other countries |  |  | 81,116 |  |  |  | 86,377 |  |  |  | 246,120 |  |  |  | 267,230 |  |
| Total |  | $ | 215,510 |  |  | $ | 217,608 |  |  | $ | 647,844 |  |  | $ | 645,375 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-15-019169:notes:85]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 102,616 |  |  | $ | 107,754 |  |  | $ | 307,549 |  |  | $ | 313,726 |  |
| Automotive |  |  | 81,475 |  |  |  | 80,639 |  |  |  | 251,464 |  |  |  | 245,083 |  |
| Electrical |  |  | 31,419 |  |  |  | 29,215 |  |  |  | 88,831 |  |  |  | 86,566 |  |
| Total net sales |  | $ | 215,510 |  |  | $ | 217,608 |  |  | $ | 647,844 |  |  | $ | 645,375 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 5,811 |  |  | $ | 5,582 |  |  | $ | 17,384 |  |  | $ | 16,482 |  |
| Automotive |  |  | 3,244 |  |  |  | 3,435 |  |  |  | 9,883 |  |  |  | 10,609 |  |
| Electrical |  |  | 1,260 |  |  |  | 1,414 |  |  |  | 3,839 |  |  |  | 4,096 |  |
| Total depreciation and amortization |  | $ | 10,315 |  |  | $ | 10,431 |  |  | $ | 31,106 |  |  | $ | 31,187 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 20,923 |  |  | $ | 25,800 |  |  | $ | 61,755 |  |  | $ | 70,805 |  |
| Automotive |  |  | 15,253 |  |  |  | 12,227 |  |  |  | 39,123 |  |  |  | 35,158 |  |
| Electrical |  |  | 5,781 |  |  |  | 3,224 |  |  |  | 13,220 |  |  |  | 7,541 |  |
| Other(1) |  |  | (33,373 | ) |  |  | (1,121 | ) |  |  | (39,795 | ) |  |  | (6,065 | ) |
| Total operating income |  |  | 8,584 |  |  |  | 40,130 |  |  |  | 74,303 |  |  |  | 107,439 |  |
| Interest expense |  |  | 922 |  |  |  | 1,292 |  |  |  | 3,021 |  |  |  | 3,736 |  |
| Foreign exchange (gain) loss |  |  | (3,549 | ) |  |  | (101 | ) |  |  | (1,724 | ) |  |  | 2,022 |  |
| Other (income) expense, net |  |  | (1,430 | ) |  |  | (2,261 | ) |  |  | (3,758 | ) |  |  | (4,893 | ) |
| Income before income taxes |  | $ | 12,641 |  |  | $ | 41,200 |  |  | $ | 76,764 |  |  | $ | 106,574 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-019169:notes:86]
[same as prior period, unchanged from 0001437749-15-014442:notes:71]

[0001437749-15-019169:notes:87]
[same as prior period, unchanged from 0001437749-15-014442:notes:72]

[0001437749-15-019169:notes:88]
[same as prior period, unchanged from 0001437749-15-014442:notes:73]

[0001437749-15-019169:notes:89]
[same as prior period, unchanged from 0001437749-15-014442:notes:74]

[0001437749-15-019169:notes:90]
An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer (“CEO”).

[0001437749-15-019169:notes:91]
Business unit segment information for the three and nine months ended September 26, 2014 and September 27, 2014 are summarized as follows (in thousands):

[0001437749-15-019169:notes:92]
(1) For the three months ended September 26, 2015, “Other” consists of restructuring costs ($2.1 million), acquisition expenses ($0.3 million), pension settlement and wind-up costs ($30.9 million), and other ($0.1 million). For the nine months ended September 26, 2015, “Other” consist of restructuring costs ($6.8 million), acquisition expenses ($0.7 million), pension settlement and wind-up costs ($32.2 million) and other ($0.1 million).

[0001437749-15-019169:notes:93]
The company’s significant net sales by country for the three and nine months ended September 26, 2015 and September 27, 2014 are summarized as follows (in thousands):

[0001437749-15-019169:notes:94]
[same as prior period, unchanged from 0001437749-15-014442:notes:79]

[0001437749-15-019169:notes:95]
11

[0001437749-15-019169:notes:96]
Business Unit Segment Information, continued

[0001437749-15-019169:notes:97]
The company’s significant long-lived assets and additions to long-lived assets by country as of September 26, 2015 and December 27, 2014 are summarized as follows (in thousands):

[0001437749-15-019169:notes:98]
[same as prior period, unchanged from 0001437749-15-014442:notes:81]

[0001437749-15-019169:notes:99]
The company’s additions to long-lived assets for the nine months ended September 26, 2015 and September 27, 2014 are summarized as follows (in thousands):


## us-gaap:SubsequentEventsTextBlock

[0001437749-15-019169:notes:100]
12. Subsequent Event

[0001437749-15-019169:notes:101]
On October 1, 2015, the company acquired Sigmar S.r.1. (“Sigmar”), an Italian company that produces sensors used in gas and diesel engine fuel systems, as well as urea level and quality sensors used in diesel emission reduction systems. Sigmar has annual revenues of approximately $6 million and will be reported in the Automotive business segment.
