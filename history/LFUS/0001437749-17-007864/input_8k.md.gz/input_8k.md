# LFUS 8-K — 0001437749-17-007795 filed 2017-05-03

## item codes, every 8-K on or before 2017-05-03

- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2017-05-03

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-007795:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-17-007795:8k_2_02:2]
ex99-1.htm

[0001437749-17-007795:8k_2_02:3]
Exhibit 99.1

[0001437749-17-007795:8k_2_02:4]
| NEWS RELEASE |  |

[0001437749-17-007795:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS

[0001437749-17-007795:8k_2_02:6]
CHICAGO, May 3, 2017 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the first quarter ended April 1, 2017.

[0001437749-17-007795:8k_2_02:7]
First Quarter 2017 Highlights

[0001437749-17-007795:8k_2_02:8]
|  | ● | Net sales were $285.4 million, up 30% versus the prior year period. Organic revenue growth was 5%, excluding acquisitions, e-house business divestiture and currency effects. |

[0001437749-17-007795:8k_2_02:9]
|  | ● | Growth by segment versus the prior year period: |

[0001437749-17-007795:8k_2_02:10]
|  | o | Electronics sales increased 56% (up 15% excluding acquisitions and currency effects) |

[0001437749-17-007795:8k_2_02:11]
|  | o | Automotive sales increased 17% (down 2% excluding acquisitions and currency effects) |

[0001437749-17-007795:8k_2_02:12]
|  | o | Industrial sales decreased 17% (down 10% excluding divestiture and currency effects) |

[0001437749-17-007795:8k_2_02:13]
|  | ● | GAAP diluted EPS was $1.69; Adjusted EPS of $1.69 increased 22% over last year |

[0001437749-17-007795:8k_2_02:14]
|  | ● | Cash flow from operations was $22.9 million |

[0001437749-17-007795:8k_2_02:15]
|  | ● | The electronics book-to-bill ratio for the quarter was 1.20 |

[0001437749-17-007795:8k_2_02:16]
|  | ● | As previously announced, the company made an incremental $15 million investment in Monolith Semiconductor, a Texas-based start-up company developing silicon carbide technology. Littelfuse now has a majority ownership position in Monolith. |

[0001437749-17-007795:8k_2_02:17]
"We’re off to a strong start to 2017, with sales and adjusted earnings per share at the high end of our guidance range," said Dave Heinzmann, Chief Executive Officer. "We saw strong order rates continue through the first quarter in our electronics segment. Our automotive sales growth was negatively impacted by planned sensor product exits and challenging prior year comparisons from related last-time buys, as well as higher customer inventories. We were encouraged by sequential sales growth in both our commercial vehicle business and industrial segment, as end market weakness moderated.”

[0001437749-17-007795:8k_2_02:18]
-more-

[0001437749-17-007795:8k_2_02:19]
Second Quarter 2017 Outlook

[0001437749-17-007795:8k_2_02:20]
All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, foreign exchange adjustments and unusual gains and losses. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-17-007795:8k_2_02:21]
“Our positive momentum has carried into the second quarter as we continue to see strong order rates across our electronics segment,” continued Heinzmann. “With more stable trends in some heavy industrial markets, we expect stronger revenue growth to drive margin expansion for the second quarter.”

[0001437749-17-007795:8k_2_02:22]
|  | ● | Sales are expected to be in the range of $301 to $311 million, up 13% versus the prior year period at the midpoint |

[0001437749-17-007795:8k_2_02:23]
|  | ● | Adjusted earnings per share are expected to be in the range of $1.83 to $1.97 |

[0001437749-17-007795:8k_2_02:24]
|  | ● | Similar to prior years, stock compensation expense for the second quarter is expected to be approximately $2 million higher than other quarters of the year due to accelerated expensing of equity granted in the quarter to all those of retirement age |

[0001437749-17-007795:8k_2_02:25]
Dividend and Share Repurchase Authorization

[0001437749-17-007795:8k_2_02:26]
|  | ● | The company will pay a cash dividend on its common stock of $0.33 per share on June 8, 2017 to shareholders of record as of May 25, 2017. |

[0001437749-17-007795:8k_2_02:27]
|  | ● | The company’s previous share repurchase authorization expired on April 30, 2017 and has been replaced with a one million share repurchase authorization effective through April 30, 2018. No shares were repurchased under the former authorization. |

[0001437749-17-007795:8k_2_02:28]
Conference Call and Webcast Information

[0001437749-17-007795:8k_2_02:29]
Littelfuse will host a conference call today, Wednesday, May 3, 2017, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. The call will be available for replay on the company’s website.

[0001437749-17-007795:8k_2_02:30]
About Littelfuse

[0001437749-17-007795:8k_2_02:31]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 10,000 employees in more than 40 locations throughout the Americas, Europe and Asia. For more information, please visit the Littelfuse website: Littelfuse.com.

[0001437749-17-007795:8k_2_02:32]
-more-

[0001437749-17-007795:8k_2_02:33]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company's accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions, uncertainties related to political and regulatory changes and other risks which may be detailed in the company's other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 31, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-007795:8k_2_02:34]
Non-GAAP Financial Measures

[0001437749-17-007795:8k_2_02:35]
The information included in this press release includes the non-GAAP financial measures of adjusted net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is included herein.

[0001437749-17-007795:8k_2_02:36]
The company believes that adjusted net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-17-007795:8k_2_02:37]
CONTACT: Meenal Sethna

[0001437749-17-007795:8k_2_02:38]
Executive Vice President and CFO

[0001437749-17-007795:8k_2_02:39]
(773) 628-0616

[0001437749-17-007795:8k_2_02:40]
###

[0001437749-17-007795:8k_2_02:41]
LFUS-F

[0001437749-17-007795:8k_2_02:42]
LITTELFUSE, INC.

[0001437749-17-007795:8k_2_02:43]
Net Sales and Operating Income by Business Unit

[0001437749-17-007795:8k_2_02:44]
(In thousands of USD, unaudited)

[0001437749-17-007795:8k_2_02:45]
|  |  | First Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 153,767 |  |  | $ | 98,796 |  |  |  | 56% |  |
| Automotive |  |  | 107,839 |  |  |  | 91,933 |  |  |  | 17% |  |
| Industrial |  |  | 23,835 |  |  |  | 28,669 |  |  |  | (17%) |  |
| Total net sales |  | $ | 285,441 |  |  | $ | 219,398 |  |  |  | 30% |  |

[0001437749-17-007795:8k_2_02:46]
|  |  | First Quarter |  |
|  |  | 2017 |  |  | 2016 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 35,206 |  |  | $ | 22,416 |  |  |  | 57% |  |
| Automotive |  |  | 15,065 |  |  |  | 17,491 |  |  |  | (14%) |  |
| Industrial |  |  | 106 |  |  |  | 1,673 |  |  |  | (94%) |  |
| Other (1) |  |  | (1,525 | ) |  |  | (9,152 | ) |  |  | 83% |  |
| Total operating income |  | $ | 48,852 |  |  | $ | 32,428 |  |  |  | 51% |  |
| Interest expense |  |  | 3,120 |  |  |  | 2,045 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | (1,557 | ) |  |  | 3,823 |  |  |  |  |  |
| Other (income) expense, net |  |  | (139 | ) |  |  | (517 | ) |  |  |  |  |
| Income before taxes |  | $ | 47,428 |  |  | $ | 27,077 |  |  |  | 75% |  |

[0001437749-17-007795:8k_2_02:47]
(1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details on page 8.)

[0001437749-17-007795:8k_2_02:48]
LITTELFUSE, INC.

[0001437749-17-007795:8k_2_02:49]
Condensed Consolidated Balance Sheets

[0001437749-17-007795:8k_2_02:50]
(In thousands of USD, except share amounts)

[0001437749-17-007795:8k_2_02:51]
|  |  | April 1, 2017 |  |  | December 31, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 277,979 |  |  | $ | 275,124 |  |
| Short-term investments |  |  | 32 |  |  |  | 3,690 |  |
| Accounts receivable, less allowances |  |  | 212,586 |  |  |  | 198,095 |  |
| Inventories |  |  | 118,311 |  |  |  | 114,063 |  |
| Prepaid income taxes and income taxes receivable |  |  | 12,273 |  |  |  | 11,671 |  |
| Prepaid expenses and other current assets |  |  | 13,044 |  |  |  | 9,438 |  |
| Total current assets |  |  | 634,225 |  |  |  | 612,081 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 9,645 |  |  |  | 9,268 |  |
| Buildings |  |  | 83,060 |  |  |  | 80,553 |  |
| Equipment |  |  | 453,450 |  |  |  | 439,542 |  |
|  |  |  | 546,155 |  |  |  | 529,363 |  |
| Accumulated depreciation |  |  | (322,213 | ) |  |  | (312,188 | ) |
| Net property, plant and equipment |  |  | 223,942 |  |  |  | 217,175 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 88,147 |  |  |  | 83,607 |  |
| Distribution network |  |  | 18,713 |  |  |  | 18,995 |  |
| Customer lists, trademarks and tradenames |  |  | 109,234 |  |  |  | 110,425 |  |
| Goodwill |  |  | 428,343 |  |  |  | 403,544 |  |
|  |  |  | 644,437 |  |  |  | 616,571 |  |
| Investments |  |  | 11,657 |  |  |  | 13,933 |  |
| Deferred income taxes |  |  | 19,530 |  |  |  | 20,585 |  |
| Other assets |  |  | 10,255 |  |  |  | 10,849 |  |
| Total assets |  | $ | 1,544,046 |  |  | $ | 1,491,194 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 88,360 |  |  | $ | 90,712 |  |
| Accrued payroll |  |  | 24,740 |  |  |  | 42,810 |  |
| Accrued expenses |  |  | 47,849 |  |  |  | 36,138 |  |
| Accrued severance |  |  | 1,146 |  |  |  | 2,785 |  |
| Accrued income taxes |  |  | 8,827 |  |  |  | 8,846 |  |
| Current portion of long-term debt |  |  | 6,250 |  |  |  | 6,250 |  |
| Total current liabilities |  |  | 177,172 |  |  |  | 187,541 |  |
| Long-term debt, less current portion |  |  | 464,273 |  |  |  | 447,892 |  |
| Deferred income taxes |  |  | 8,539 |  |  |  | 7,066 |  |
| Accrued post-retirement benefits |  |  | 13,926 |  |  |  | 13,398 |  |
| Other long-term liabilities |  |  | 24,375 |  |  |  | 20,366 |  |
| Total equity |  |  | 855,761 |  |  |  | 814,931 |  |
| Total liabilities and equity |  | $ | 1,544,046 |  |  | $ | 1,491,194 |  |

[0001437749-17-007795:8k_2_02:52]
LITTELFUSE, INC.

[0001437749-17-007795:8k_2_02:53]
Consolidated Statements of Comprehensive Income

[0001437749-17-007795:8k_2_02:54]
(In thousands of USD, except per share data, unaudited)

[0001437749-17-007795:8k_2_02:55]
|  |  | For the Three Months Ended |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Net sales |  | $ | 285,441 |  |  | $ | 219,398 |  |
| Cost of sales |  |  | 171,791 |  |  |  | 132,243 |  |
| Gross profit |  |  | 113,650 |  |  |  | 87,155 |  |
| Selling, general and administrative expenses |  |  | 46,703 |  |  |  | 42,366 |  |
| Research and development expenses |  |  | 12,151 |  |  |  | 8,565 |  |
| Amortization of intangibles |  |  | 5,944 |  |  |  | 3,796 |  |
|  |  |  | 64,798 |  |  |  | 54,727 |  |
| Operating income |  |  | 48,852 |  |  |  | 32,428 |  |
| Interest expense |  |  | 3,120 |  |  |  | 2,045 |  |
| Foreign exchange (gain) loss |  |  | (1,557 | ) |  |  | 3,823 |  |
| Other (income) expense, net |  |  | (139 | ) |  |  | (517 | ) |
| Income before income taxes |  |  | 47,428 |  |  |  | 27,077 |  |
| Income taxes |  |  | 8,537 |  |  |  | 7,788 |  |
| Net income |  | $ | 38,891 |  |  | $ | 19,289 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.71 |  |  | $ | 0.86 |  |
| Diluted |  | $ | 1.69 |  |  | $ | 0.85 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,748 |  |  |  | 22,438 |  |
| Diluted |  |  | 22,989 |  |  |  | 22,621 |  |
| Comprehensive income |  | $ | 44,518 |  |  | $ | 29,975 |  |

[0001437749-17-007795:8k_2_02:56]
LITTELFUSE, INC.

[0001437749-17-007795:8k_2_02:57]
Consolidated Statements of Cash Flows

[0001437749-17-007795:8k_2_02:58]
(In thousands of USD, unaudited)

[0001437749-17-007795:8k_2_02:59]
|  |  | For the Three Months Ended |  |
|  |  | April 1, 2017 |  |  | April 2, 2016 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 38,891 |  |  | $ | 19,289 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 9,128 |  |  |  | 7,230 |  |
| Amortization of intangibles |  |  | 5,944 |  |  |  | 3,796 |  |
| Provision for bad debts |  |  | 351 |  |  |  | - |  |
| Loss on sale of product line |  |  | - |  |  |  | 1,391 |  |
| Stock-based compensation |  |  | 3,583 |  |  |  | 2,204 |  |
| Excess tax benefit on stock-based compensation |  |  | - |  |  |  | (706 | ) |
| Loss on sale of assets |  |  | 600 |  |  |  | 27 |  |
| Deferred income taxes |  |  | 616 |  |  |  | - |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (11,267 | ) |  |  | (10,413 | ) |
| Inventories |  |  | (3,296 | ) |  |  | (3,484 | ) |
| Accounts payable |  |  | (3,295 | ) |  |  | 3,716 |  |
| Accrued expenses (including post retirement) |  |  | 4,140 |  |  |  | 3,500 |  |
| Accrued payroll and severance |  |  | (20,221 | ) |  |  | (9,351 | ) |
| Accrued taxes |  |  | (220 | ) |  |  | (5,312 | ) |
| Prepaid expenses and other |  |  | (2,011 | ) |  |  | (2,395 | ) |
| Net cash provided by operating activities |  |  | 22,943 |  |  |  | 9,492 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (12,377 | ) |  |  | (9,139 | ) |
| Acquisition of business, net of cash acquired |  |  | (14,172 | ) |  |  | (264,098 | ) |
| Proceeds from maturities of short-term investments |  |  | 3,739 |  |  |  | - |  |
| Decrease in entrusted loan receivable |  |  | 655 |  |  |  | - |  |
| Proceeds from sale of assets |  |  | 57 |  |  |  | 18 |  |
| Net cash used in investing activities |  |  | (22,098 | ) |  |  | (273,219 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | - |  |  |  | 258,000 |  |
| Proceeds of term loan |  |  | - |  |  |  | 125,000 |  |
| Payments of revolving credit facility |  |  | (112,500 | ) |  |  | (90,500 | ) |
| Payments of term loan |  |  | (1,563 | ) |  |  | (85,000 | ) |
| Net Proceeds from Sr. Notes Payable |  |  | 125,000 |  |  |  | - |  |
| Payments of entrusted loan |  |  | (655 | ) |  |  | - |  |
| Debt issuance costs paid |  |  | (71 | ) |  |  | (1,700 | ) |
| Cash dividends paid |  |  | (7,472 | ) |  |  | (6,483 | ) |
| Proceeds from exercise of stock options |  |  | 199 |  |  |  | 3,710 |  |
| Excess tax benefit on share-based compensation |  |  | - |  |  |  | 706 |  |
| Net cash (used in) provided by financing activities |  |  | 2,938 |  |  |  | 203,733 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (928 | ) |  |  | 4,072 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 2,855 |  |  |  | (55,922 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275,124 |  |  |  | 328,786 |  |
| Cash and cash equivalents at end of period |  | $ | 277,979 |  |  | $ | 272,864 |  |

[0001437749-17-007795:8k_2_02:60]
Note: Prior year numbers have been restated to reflect the correction of immaterial errors as disclosed in recent quarterly filings with the SEC.

[0001437749-17-007795:8k_2_02:61]
LITTELFUSE, INC.

[0001437749-17-007795:8k_2_02:62]
Supplemental Financial Information

[0001437749-17-007795:8k_2_02:63]
(in millions of USD except share amounts)

[0001437749-17-007795:8k_2_02:64]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-17 |  |  | Q1-16 |  |  |  |  |  |  |  |  |  |
| GAAP diluted EPS |  | $ | 1.69 |  |  | $ | 0.85 |  |  |  |  |  |  |  |  |  |
| EPS impact of special items (below) |  |  | - |  |  |  | 0.53 |  |  |  |  |  |  |  |  |  |
| Adjusted diluted EPS |  | $ | 1.69 |  |  | $ | 1.38 |  |  |  |  |  |  |  |  |  |

[0001437749-17-007795:8k_2_02:65]
| Non-GAAP Adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-17 |  |  | Q1-16 |  |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | - |  |  | $ | 1.0 |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  | - |  |  |  | 0.4 |  |  |  |  |  |  |  |  |  |
| Acquisitions/divestiture/purchase acctg adjs |  |  | 1.5 |  |  |  | 6.2 |  |  |  |  |  |  |  |  |  |
| Pension wind-up |  |  | - |  |  |  | - |  |  |  |  |  |  |  |  |  |
| Impairment and severance charges |  |  | - |  |  |  | 1.6 |  |  |  |  |  |  |  |  |  |
| Adjustment to Operating income |  |  | 1.5 |  |  |  | 9.2 |  |  |  |  |  |  |  |  |  |
| Foreign exchange loss/(gain) |  |  | (1.6 | ) |  |  | 3.8 |  |  |  |  |  |  |  |  |  |
| Adjustment to income before income taxes |  | $ | (0.1 | ) |  | $ | 13.0 |  |  |  |  |  |  |  |  |  |
| Income taxes |  |  | - |  |  |  | 1.0 |  |  |  |  |  |  |  |  |  |
| Adjustment to net income |  | $ | (0.1 | ) |  | $ | 12.0 |  |  |  |  |  |  |  |  |  |
| Total EPS impact |  | $ | - |  |  | $ | 0.53 |  |  |  |  |  |  |  |  |  |

[0001437749-17-007795:8k_2_02:66]
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-17 |  |  | Q1-16 |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 285.4 |  |  | $ | 219.4 |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 48.9 |  |  | $ | 32.4 |  |  |  |  |  |  |  |  |  |
| Add back special operating items |  |  | 1.5 |  |  |  | 9.2 |  |  |  |  |  |  |  |  |  |
| Adjusted operating income |  | $ | 50.4 |  |  | $ | 41.6 |  |  |  |  |  |  |  |  |  |
| Adjusted operating margin |  |  | 17.7 | % |  |  | 19.0 | % |  |  |  |  |  |  |  |  |
| Add back amortization |  |  | 5.9 |  |  |  | 3.8 |  |  |  |  |  |  |  |  |  |
| Add back depreciation |  |  | 9.1 |  |  |  | 7.2 |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 65.4 |  |  | $ | 52.6 |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA margin |  |  | 23.0 | % |  |  | 24.0 | % |  |  |  |  |  |  |  |  |

[0001437749-17-007795:8k_2_02:67]
| Net sales reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 2017 vs. Q1 2016 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales growth |  |  | 56 | % |  |  | 17 | % |  |  | -17 | % |  |  | 30 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 42 | % |  |  | 21 | % |  |  | 0 | % |  |  | 28 | % |
| Divestitures |  |  | 0 | % |  |  | 0 | % |  |  | -7 | % |  |  | -1 | % |
| FX impact |  |  | -1 | % |  |  | -2 | % |  |  | 0 | % |  |  | -2 | % |
| Adjusted net sales growth |  |  | 15 | % |  |  | -2 | % |  |  | -10 | % |  |  | 5 | % |

[0001437749-17-007795:8k_2_02:68]
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-17 |  |  | Q1-16 |  |  |  |  |  |  |  |  |  |
| Income taxes |  | $ | 8.5 |  |  | $ | 7.8 |  |  |  |  |  |  |  |  |  |
| Effective rate |  |  | 18.0 | % |  |  | 28.8 | % |  |  |  |  |  |  |  |  |
| Non-GAAP adjustment - income taxes |  |  | - |  |  |  | 1.0 |  |  |  |  |  |  |  |  |  |
| Adjusted income taxes |  | $ | 8.5 |  |  | $ | 8.8 |  |  |  |  |  |  |  |  |  |
| Adjusted effective rate |  |  | 18.0 | % |  |  | 22.0 | % |  |  |  |  |  |  |  |  |

[0001437749-17-007795:8k_2_02:69]
| Free Cash Flow reconcilation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-17 |  |  | Q1-16 |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 22.9 |  |  | $ | 9.5 |  |  |  |  |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (12.4 | ) |  |  | (9.1 | ) |  |  |  |  |  |  |  |  |
| Free Cash Flow |  | $ | 10.5 |  |  | $ | 0.4 |  |  |  |  |  |  |  |  |  |

[0001437749-17-007795:8k_2_02:70]
Note: Totals will not always foot due to rounding

[0001437749-17-007795:8k_2_02:71]
# # #
