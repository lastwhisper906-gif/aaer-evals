# LFUS MD&A — 0001437749-17-007864


## mdna

[0001437749-17-007864:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001437749-17-007864:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-17-007864:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations,  should be read in conjunction with information provided in the financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-007864:mdna:4]
Management’s Discussion and Analysis of Financial Condition and Results of Operations ("MD&A") is designed to provide information that is supplemental to, and should be read together with, the consolidated financial statements and the accompanying notes. Information in MD&A is intended to assist the reader in obtaining an understanding of (i) the consolidated financial statements, (ii) the changes in certain key items within those financial statements from year-to-year, (iii) the primary factors that contributed to those changes, and (iv) any changes in known trends or uncertainties that we are aware of and that may have a material effect on future performance. In addition, MD&A provides information about the Company’s segments and how the results of those segments impact the results of operations and financial condition as a whole.

[0001437749-17-007864:mdna:5]
Executive Overview

[0001437749-17-007864:mdna:6]
Littelfuse is one of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensor and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s devices protect products in virtually every market that uses electrical energy, from various electronic devices to automobiles to industrial equipment.

[0001437749-17-007864:mdna:7]
The Company conducts its business through three reportable segments, which are defined by markets and consist of Electronics, Automotive, and Industrial. The Company’s customer base includes OEMs, Tier One automotive suppliers, and distributors.

[0001437749-17-007864:mdna:8]
Executive Summary

[0001437749-17-007864:mdna:9]
The Company experienced strong performance improvements in the first quarter of 2017 compared to the first quarter of 2016. For the first quarter of 2017, the Company recognized net sales of $285.4 million compared to $219.4 million in the first quarter of 2016. The increase of $66.0 million, or 30.0%, reflects increased net sales of $55.0 million, or 56%, in the Electronics segment and $15.9 million, or 17%, in the Automotive segment, partially offset by decreased net sales of $4.8 million, or 17%, in the Industrial segment. The increased net sales in the Electronics and Automotive segments were primarily due to the impact of prior year acquisitions. The Company recognized net income of $38.9 million, or $1.69 per diluted share, in the first quarter of 2017 compared to net income of $19.3 million, or $0.85 per diluted share in the first quarter of 2016. Increased net income reflects the impacts of the prior year acquisitions on the current year results as well of a decrease in acquisition-related costs, coupled with a lower effective tax rate.

[0001437749-17-007864:mdna:10]
Results of Operations

[0001437749-17-007864:mdna:11]
The following table summarizes the Company’s consolidated results of operations for the periods presented. The first quarter of 2017 includes approximately $1.5 million of non-segment charges.  These were primarily attributable to acquisition-related costs primarily related to legal and integration costs associated with the Company’s acquisitions in 2016 of the ON Portfolio PolySwitch.

[0001437749-17-007864:mdna:12]
The first quarter of 2016 includes approximately $9.2 million of other non-segment charges.  These included $6.2 million of acquisition-related costs primarily related to legal and integration costs associated with the Company’s PolySwitch acquisition, $1.6 million in impairment charges related to the closure of the Company’s manufacturing facility in Denmark, $1.0 million related to the Company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.4 million related to internal legal restructuring costs.

[0001437749-17-007864:mdna:13]
|  |  | Three Months Ended |  |  |  |  |  |  |  |  |  |
| (in thousands, except % change) |  | April 1, 2017 |  |  | April 2, 2016 |  |  | Change |  |  | % Change |  |
| Net sales |  | $ | 285,441 |  |  | $ | 219,398 |  |  | $ | 66,043 |  |  |  | 30% |  |
| Gross profit |  |  | 113,650 |  |  |  | 87,155 |  |  |  | 26,495 |  |  |  | 30% |  |
| Operating expenses |  |  | 64,798 |  |  |  | 54,727 |  |  |  | 10,071 |  |  |  | 18% |  |
| Operating income |  |  | 48,852 |  |  |  | 32,428 |  |  |  | 16,424 |  |  |  | 51% |  |
| Income before income taxes |  |  | 47,428 |  |  |  | 27,077 |  |  |  | 20,351 |  |  |  | 75% |  |
| Income taxes |  |  | 8,537 |  |  |  | 7,788 |  |  |  | 749 |  |  |  | 10% |  |
| Net income |  |  | 38,891 |  |  |  | 19,289 |  |  |  | 19,602 |  |  |  | 102% |  |

[0001437749-17-007864:mdna:14]
Net Sales

[0001437749-17-007864:mdna:15]
Net sales increased $66.0 million, or 30%, for the first quarter of 2017 compared to the first quarter of 2016, primarily due to a $60.9 million increase from the prior year PolySwitch, ON Portfolio, and Menbers’ acquisitions. Increased net sales in the Electronics segment of $55.0 million and the Automotive segment of $15.9 million were partially offset by a $4.8 million decrease in the Industrial segment.

[0001437749-17-007864:mdna:16]
Gross Profit

[0001437749-17-007864:mdna:17]
Gross profit was $113.7 million, or 39.8% of net sales, in the first quarter of 2017, compared to $87.2 million, or 39.7% of net sales in the first quarter of 2016. Gross profit reflects the incremental net sales and associated profits related to the prior year acquisitions.

[0001437749-17-007864:mdna:18]
Operating Expenses

[0001437749-17-007864:mdna:19]
Total operating expense was $64.8 million, or 22.7% of net sales, for the first quarter of 2017 compared to $54.7 million, or 24.9% of net sales, for the first quarter of 2016. The increase in operating expenses of $10.1 million is primarily due to incremental operating expenses related to the prior year acquisitions including increased selling costs and amortization of intangibles. The improvement in operating expenses as a percentage of net sales is due to operating efficiencies coupled with approximately $7.8 million of acquisition-related charges incurred in 2016.

[0001437749-17-007864:mdna:20]
Operating Income

[0001437749-17-007864:mdna:21]
Operating income was $48.9 million, or 17.1% of net sales, for the first quarter of 2017 compared to $32.4 million, or 14.8% of net sales, for the first quarter of 2016. The increase in operating income is the result of the above-described increased net sales and associated margins partially offset by increased operating expenses. The improvement in operating income as a percentage of net sales reflects the impact of the prior year acquisitions costs on operating expenses.

[0001437749-17-007864:mdna:22]
Income Before Income Taxes

[0001437749-17-007864:mdna:23]
Income before income taxes was $47.4 million, or 16.6% of net sales, for the first quarter of 2017 compared to $27.1 million, or 12.3% of net sales, for the first quarter of 2016. In addition to the factors impacting comparative results for operating income, income before income taxes was impacted by favorable comparative foreign exchange partially offset by increased interest expense. The effect of foreign exchange rate changes on various foreign currency transactions worldwide was approximately $1.6 million of income for the first quarter of 2017 compared to $3.8 million of expense for the first quarter of 2016 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar. Interest expense was $3.1 million in the first quarter of 2017 as compared to $2.0 million in the first quarter of 2016, primarily reflecting increased borrowings.

[0001437749-17-007864:mdna:24]
Income Taxes

[0001437749-17-007864:mdna:25]
Income tax expense was $8.5 million, or an effective tax rate of 18.0%, for the first quarter of 2017 compared to income tax expense of $7.8 million, or an effective tax rate of 28.8%, for the first quarter of 2016. The effective tax rates for both the first quarter of 2017 and the first quarter of 2016 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. Further, the effective tax rate for the first quarter of 2017 was lower than the effective tax rate for the first quarter of 2016 primarily due to a larger amount of income earned in lower tax jurisdictions in the first quarter of 2017 compared to the first quarter of 2016.

[0001437749-17-007864:mdna:26]
Segment Results of Operations

[0001437749-17-007864:mdna:27]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 10, Segment Information, of the Notes to Consolidated Financial Statements included in this Quarterly Report.

[0001437749-17-007864:mdna:28]
The following table is a summary of the Company’s net sales by segment:

[0001437749-17-007864:mdna:29]
|  |  | Three Months Ended |  |  |  |  |  |  |  |  |  |
| (in thousands) |  | April 1, 2017 |  |  | April 2, 2016 |  |  | Change |  |  | % Change |  |
| Electronics |  | $ | 153,767 |  |  | $ | 98,796 |  |  | $ | 54,971 |  |  |  | 56% |  |
| Automotive |  |  | 107,839 |  |  |  | 91,933 |  |  |  | 15,906 |  |  |  | 17% |  |
| Industrial |  |  | 23,835 |  |  |  | 28,669 |  |  |  | (4,834 | ) |  |  | (17%) |  |
| Total |  | $ | 285,441 |  |  | $ | 219,398 |  |  | $ | 66,043 |  |  |  | 30% |  |

[0001437749-17-007864:mdna:30]
[same as prior period, unchanged from 0001437749-16-041083:mdna:15]

[0001437749-17-007864:mdna:31]
The Electronics segment net sales increased $55.0 million, or 56%, in the first quarter of 2017 compared to the first quarter of 2016 primarily due to $41.5 million of incremental net sales related to the PolySwitch and ON Portfolio acquisitions in the prior year. Excluding the impact of the acquisitions, the increased Electronics segment net sales were primarily the result of increased net sales of passive and semiconductor products.

[0001437749-17-007864:mdna:32]
[same as prior period, unchanged from 0001437749-16-041083:mdna:17]

[0001437749-17-007864:mdna:33]
The Automotive segment net sales increased $15.9 million, or 17%, in the first quarter of 2017 compared to the first quarter of 2016 primarily due to $19.3 million of incremental net sales related to the PolySwitch and Menber’s acquisitions in the prior year. The segment also experienced unfavorable foreign exchange impacts of $1.7 million, primarly related to net sales denominated in euros and Chinese renminbi. Excluding the impact of prior year acquisitions and foreign currency, slight increases in net sales of passenger car products and commercial vehicle products were offset by a decrease in sensor net sales.

[0001437749-17-007864:mdna:34]
[same as prior period, unchanged from 0001437749-16-041083:mdna:19]

[0001437749-17-007864:mdna:35]
The Industrial segment net sales decreased $4.8 million, or 17%, in the first quarter of 2017 compared to the first quarter of 2016 primarily due to the divestiture of two non-core product lines, one in the first quarter of 2016 and the other in the fourth quarter of 2016, and decreased net sales in the custom products operations.

[0001437749-17-007864:mdna:36]
Geographic Net Sales Information

[0001437749-17-007864:mdna:37]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0001437749-17-007864:mdna:38]
|  |  | Three Months Ended |  |  |  |  |  |  |  |  |  |
| (in millions) |  | April 2, 2017 |  |  | April 1, 2016 |  |  | Change |  |  | % Change |  |
| Americas |  | $ | 98,025 |  |  | $ | 99,823 |  |  | $ | (1,798 | ) |  |  | (2%) |  |
| Europe |  |  | 58,905 |  |  |  | 42,813 |  |  |  | 16,092 |  |  |  | 38% |  |
| Asia-Pacific |  |  | 128,511 |  |  |  | 76,762 |  |  |  | 51,749 |  |  |  | 67% |  |
| Total |  | $ | 285,441 |  |  | $ | 219,398 |  |  | $ | 66,043 |  |  |  | 30% |  |

[0001437749-17-007864:mdna:39]
Americas

[0001437749-17-007864:mdna:40]
Net sales in the Americas decreased $1.8 million, or 2%, in the first quarter of 2017 compared to the first quarter of 2016. Increased net sales resulting from acquisitions in 2016 were more than offset by lower net sales of the Industrial segment’s custom products and the Automotive segment’s sensor products.

[0001437749-17-007864:mdna:41]
Europe

[0001437749-17-007864:mdna:42]
European net sales increased $16.1 million, or 38%, in the first quarter of 2017 compared to the first quarter of 2016 primarily due to a $15.0 million increase from prior year acquisitions partially offset by $1.7 million in unfavorable currency effects primarily results from sales denominated in euros.

[0001437749-17-007864:mdna:43]
Asia-Pacific

[0001437749-17-007864:mdna:44]
Asia-Pacific net sales increased $51.7 million, or 67%, in the first quarter of 2017 compared to the first quarter of 2016, primarily due to $38.3 million in incremental net sales from prior year acquisitions. The Asia-Pacific net sales increase also reflects increased net sales in all of the Electronics segment’s and Automotive segment’s business units.

[0001437749-17-007864:mdna:45]
[same as prior period, unchanged from 0001437749-16-041083:mdna:63]

[0001437749-17-007864:mdna:46]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0001437749-17-007864:mdna:47]
Revolving Credit Facility/Term Loan

[0001437749-17-007864:mdna:48]
On March 4, 2016, the Company entered into a new five-year credit agreement with a group of lenders for up to $700.0 million. The new credit agreement consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of $1.6 million through March 31, 2018 and $3.1 million from June 30, 2018 through December 31, 2020 with the remaining balance due on March 4, 2021.

[0001437749-17-007864:mdna:49]
Outstanding borrowings under the credit agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.30%, based on the Consolidated Leverage Ratio, as defined. The effective interest rate on outstanding borrowings under the credit facility was 2.48% at April 1, 2017. As of April 1, 2017, the Company had $0.1 million outstanding in letters of credit and had available $574.9 million of borrowing capacity under the revolving credit facility. Further information regarding the Company’s credit agreement is provided in Note 4, Debt, of the Notes to Consolidated Financial Statements included in this Quarterly Report.

[0001437749-17-007864:mdna:50]
Senior Notes

[0001437749-17-007864:mdna:51]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023, and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001437749-17-007864:mdna:52]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022, and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on February 15 and August 15, commencing August 15, 2017. Further information regarding the Company’s Senior Notes is provided in Note 4, Debt, of the Notes to Consolidated Financial Statements included in this Quarterly Report.

[0001437749-17-007864:mdna:53]
Cash Flow Overview

[0001437749-17-007864:mdna:54]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Net cash provided by operating activities |  | $ | 22,943 |  |  | $ | 9,492 |  |
| Net cash used in investing activities |  |  | (22,098 | ) |  |  | (273,219 | ) |
| Net cash provided by financing activities |  |  | 2,938 |  |  |  | 203,733 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (928 | ) |  |  | 4,072 |  |
| Decrease in cash and cash equivalents |  |  | 2,855 |  |  |  | (55,922 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275,124 |  |  |  | 328,786 |  |
| Cash and cash equivalents at end of period |  | $ | 277,979 |  |  | $ | 272,864 |  |

[0001437749-17-007864:mdna:55]
Cash Flow from Operating Activities

[0001437749-17-007864:mdna:56]
Net cash provided by operating activities was $22.9 million for the first three months of 2017 reflecting $38.9 million in net income and $20.2 million in non-cash adjustments (primarily $15.1 million in depreciation and amortization) offset by $36.2 million in net changes to various operating assets and liabilities.

[0001437749-17-007864:mdna:57]
Changes in operating assets and liabilities for the first three months of 2017 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivable ($11.3 million), inventory ($3.3 million), prepaid and other assets ($2.0 million), accrued payroll and severance ($20.2 million), accounts payable ($3.3 million) and accrued and deferred taxes ($0.2 million). The increase in accounts receivable was due to increased net sales in the first quarter. The decrease in accrued payroll and severance was due primarily to payouts for the 2016 management incentive plan which occurred in the first quarter.

[0001437749-17-007864:mdna:58]
Cash Flow from Investing Activities

[0001437749-17-007864:mdna:59]
Net cash used in investing activities was $22.1 million and primarily related to the acquisition of the Monolith business ($14.2 million), net of cash acquired, and capital expenditures ($12.4 million) both of which were partially offset by proceeds from maturities of short-term investments ($3.7 million) and a decrease in the entrusted loan ($0.7 million). The decrease in cash used in investing activities is due to cash used in the acquisition of PolySwitch in the first quarter of 2016.

[0001437749-17-007864:mdna:60]
Cash Flow from Financing Activities

[0001437749-17-007864:mdna:61]
Net cash provided by financing activities was $2.9 million and included $10.3 million in net proceeds on borrowings and $0.2 million from the exercise of stock options including tax benefits both of which are partially offset by dividends paid of $7.5 million and debt issuance costs related to the new credit agreement of $0.1 million. The decrease in cash provided by financing activities is due to the Company entering into the new credit agreement and term loan credit facility in the first quarter of 2016.

[0001437749-17-007864:mdna:62]
Share Repurchase Program

[0001437749-17-007864:mdna:63]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2016 to April 30, 2017 (“Share Repurchase Program”). The Company did not repurchase any shares of its common stock during fiscal 2016 or the first quarter of 2017. The Share Repurchase Program expired on April 30, 2017 with no shares repurchased. The Company’s Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company’s common stock for the period May 1, 2017 to April 30, 2018.

[0001437749-17-007864:mdna:64]
Off-Balance Sheet Arrangements

[0001437749-17-007864:mdna:65]
As of April 1, 2017, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-17-007864:mdna:66]
Recent Accounting Pronouncements

[0001437749-17-007864:mdna:67]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers" (Topic 606) which supersedes the revenue recognition requirements in ASC 605, "Revenue Recognition." This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. In August, 2015, the FASB issued ASU No. 2015-14, which postponed the effective date of ASU No. 2014-09 to fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted on the original effective date of fiscal years beginning after December 15, 2016. The Company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements and has not concluded on its adoption methodology. While the Company is currently assessing the impact of the new standards, the Company’s revenue is primarily generated from the sale of finished products to customers. Sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does not expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects may be affected. The Company has not yet quantified this potential impact.

[0001437749-17-007864:mdna:68]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company is currently evaluating the impact of this ASU on its consolidated financial statements.

[0001437749-17-007864:mdna:69]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles-Goodwill and Other” (Topic 350). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity no longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 2 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after December 15, 2020, with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company expects to adopt the new standard in 2017.

[0001437749-17-007864:mdna:70]
Critical Accounting Policies and Estimates

[0001437749-17-007864:mdna:71]
The Company’s Consolidated Financial Statements are prepared in accordance with U.S. GAAP. In connection with the preparation of the Consolidated Financial Statements, the Company uses estimates and makes judgments and assumptions about future events that affect the reported amounts of assets, liabilities, revenue, expenses, and the related disclosures. The assumptions, estimates, and judgments are based on historical experience, current trends, and other factors the Company believes are relevant at the time it prepares the Consolidated Financial Statements.

[0001437749-17-007864:mdna:72]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 31, 2016. During the three months ended April 1, 2017, there were no significant changes in the application of critical accounting policies.
