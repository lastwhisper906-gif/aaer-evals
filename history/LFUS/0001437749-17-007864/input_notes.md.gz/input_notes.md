# LFUS notes — 0001437749-17-007864


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-17-007864:notes:1]
Basis of Presentation

[0001437749-17-007864:notes:2]
The Company’s accompanying unaudited Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

[0001437749-17-007864:notes:3]
31,

[0001437749-17-007864:notes:4]
2016,
 which should be read in conjunction with the disclosures therein.

[0001437749-17-007864:notes:5]
In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-17-007864:notes:6]
| (in thousands) |  | Three Months Ended April 2, 2016 |  |
| Net sales |  | $ | 268,775 |  |
| Income before income taxes |  |  | 34,081 |  |
| Net income |  |  | 27,508 |  |
| Net income — basic |  |  | 1.23 |  |
| Net income — diluted |  |  | 1.22 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-007864:notes:7]
4

[0001437749-17-007864:notes:8]
. Debt

[0001437749-17-007864:notes:9]
The carrying amounts of debt at 
 April

[0001437749-17-007864:notes:10]
1,

[0001437749-17-007864:notes:11]
2017
 and 
 December

[0001437749-17-007864:notes:12]
2016
 are as follows:

[0001437749-17-007864:notes:13]
| (in thousands) |  | April 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 118,750 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 2,903 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 125,616 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 101,996 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,742 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 470,523 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 464,273 |  |  | $ | 447,892 |  |

[0001437749-17-007864:notes:14]
Revolving Credit Facility / Term Loan

[0001437749-17-007864:notes:15]
On 
 March

[0001437749-17-007864:notes:16]
4,

[0001437749-17-007864:notes:17]
2016,
 the Company entered into a new 
five
 year credit agreement with a group of lenders for up to 
$700.0
 million. The new credit agreement consists of an unsecured revolving credit facility of 
$575.0
 million and an unsecured term loan credit facility of up to 
$125.0
 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of 
$1.6
 million through 
 March

[0001437749-17-007864:notes:18]
2018
 and 
$3.1
 million from 
 June

[0001437749-17-007864:notes:19]
30,

[0001437749-17-007864:notes:20]
2018
 through 
 December

[0001437749-17-007864:notes:21]
2020
 with the remaining balance due on 
 March

[0001437749-17-007864:notes:22]
2021.

[0001437749-17-007864:notes:23]
Outstanding borrowings under the credit agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of 
one,

[0001437749-17-007864:notes:24]
two,

[0001437749-17-007864:notes:25]
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.48%
 at 
 April

[0001437749-17-007864:notes:26]
2017.

[0001437749-17-007864:notes:27]
As of 
 April

[0001437749-17-007864:notes:28]
2017,
 the Company had 
$0.1
 million outstanding in letters of credit and had available 
$574.9
 million of borrowing capacity under the revolving credit facility. At 
 April

[0001437749-17-007864:notes:29]
2017,
 the Company was in compliance with all covenants under the credit agreement.

[0001437749-17-007864:notes:30]
Senior Notes

[0001437749-17-007864:notes:31]
On 
 December

[0001437749-17-007864:notes:32]
8,

[0001437749-17-007864:notes:33]
2016,
 the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December

[0001437749-17-007864:notes:34]
2016
 for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December

[0001437749-17-007864:notes:35]
2023,
 and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December

[0001437749-17-007864:notes:36]
2028
 (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June

[0001437749-17-007864:notes:37]
8
 and 
 December

[0001437749-17-007864:notes:38]
8,
 commencing 
 June

[0001437749-17-007864:notes:39]
2016,
 the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February

[0001437749-17-007864:notes:40]
15,

[0001437749-17-007864:notes:41]
2017,

[0001437749-17-007864:notes:42]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February

[0001437749-17-007864:notes:43]
2022,
 and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February

[0001437749-17-007864:notes:44]
2027
 (together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on 
 February

[0001437749-17-007864:notes:45]
15
 and 
 August

[0001437749-17-007864:notes:46]
15,
 commencing 
 August

[0001437749-17-007864:notes:47]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001437749-17-007864:notes:48]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 April

[0001437749-17-007864:notes:49]
2017,
 the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.

[0001437749-17-007864:notes:50]
The Company 
 may
 redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001437749-17-007864:notes:51]
Entrusted Loan

[0001437749-17-007864:notes:52]
During 
2014,
 the Company entered into an entrusted loan arrangement (“Entrusted Loan”) of

[0001437749-17-007864:notes:53]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the Company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the Company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in 
 November

[0001437749-17-007864:notes:54]
2019.
 The balance of the Entrusted Loan was

[0001437749-17-007864:notes:55]
Chinese renminbi 
20.0
 million (approximately U.S. 
$2.9
 million) at 
 April


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-007864:notes:56]
9

[0001437749-17-007864:notes:57]
. Earnings Per Share

[0001437749-17-007864:notes:58]
The following table sets forth the computation of basic and diluted earnings per share:

[0001437749-17-007864:notes:59]
|  |  | For the Three Months Ended |  |
| (in thousands, except per share amounts) |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 38,891 |  |  | $ | 19,289 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,748 |  |  |  | 22,438 |  |
| Effect of dilutive securities |  |  | 241 |  |  |  | 183 |  |
| Diluted |  |  | 22,989 |  |  |  | 22,621 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.71 |  |  | $ | 0.86 |  |
| Diluted earnings per share |  | $ | 1.69 |  |  | $ | 0.85 |  |

[0001437749-17-007864:notes:60]
No potential shares of common stock attributable to stock options were excluded from the earnings per share calculation because their effect would be anti-dilutive for the 
three
 months ended 
 April

[0001437749-17-007864:notes:61]
2017
 while 
21,888
 shares were excluded for the 
three
 months ended 
 April

[0001437749-17-007864:notes:62]
2,

[0001437749-17-007864:notes:63]
2016.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-17-007864:notes:64]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 11,660 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,660 |  |

[0001437749-17-007864:notes:65]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,435 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001437749-17-007864:notes:66]
|  |  | April 1, 2017 |  |  | December 31, 2016 |  |
| (in thousands) |  | Carrying Value |  |  | Estimated Fair Value |  |  | Carrying Value |  |  | Estimated Fair Value |  |
| Euro Senior Notes, Series A due 2023 |  | $ | 125,616 |  |  | $ | 125,251 |  |  | $ | 122,313 |  |  | $ | 122,586 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 101,996 |  |  |  | 101,037 |  |  |  | 99,314 |  |  |  | 99,230 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 24,817 |  |  |  | — |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 99,208 |  |  |  | — |  |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-17-007864:notes:67]
5

[0001437749-17-007864:notes:68]
[same as prior period, unchanged from 0001437749-16-041083:notes:58]

[0001437749-17-007864:notes:69]
[same as prior period, unchanged from 0001437749-16-041083:notes:60]

[0001437749-17-007864:notes:70]
Level 
1—Valuations
 based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0001437749-17-007864:notes:71]
Level 
2—Valuations
 based upon quoted prices for 
similar
 instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable, and

[0001437749-17-007864:notes:72]
Level 
3—

[0001437749-17-007864:notes:73]
Valuations

[0001437749-17-007864:notes:74]
based upon 
one
 or more significant unobservable inputs.

[0001437749-17-007864:notes:75]
[same as prior period, unchanged from 0001437749-16-041083:notes:64]

[0001437749-17-007864:notes:76]
[same as prior period, unchanged from 0001437749-16-041083:notes:65]

[0001437749-17-007864:notes:77]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and are classified within Level 
1
 of the valuation hierarchy.

[0001437749-17-007864:notes:78]
There were no changes during the quarter ended 
 April

[0001437749-17-007864:notes:79]
2017
 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of 
 April

[0001437749-17-007864:notes:80]
2016,
 the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-17-007864:notes:81]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of 
 April

[0001437749-17-007864:notes:82]
2017:

[0001437749-17-007864:notes:83]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of 
 December

[0001437749-17-007864:notes:84]
2016:

[0001437749-17-007864:notes:85]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis.

[0001437749-17-007864:notes:86]
The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at 
 April

[0001437749-17-007864:notes:87]
2016,
 as the rates on these borrowings are variable in nature.

[0001437749-17-007864:notes:88]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of 
 April


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-007864:notes:89]
8.
 Income Taxes

[0001437749-17-007864:notes:90]
The effective tax rate for the 
first
 quarter of 
2017
 was 
18.0%
 compared to an effective tax rate of 
28.8%
 in the 
first
 quarter of 
2016.
 The effective tax rates for both the 
first
 quarter of 
2017
 and the 
first
 quarter of 
2016
 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. Further, the effective tax rate for the 
first
 quarter of 
2017
 was lower than the effective tax rate for the 
first
 quarter of 
2016
 primarily due to a larger amount of income earned in lower tax jurisdictions in the 
first
 quarter of 
2017
 compared to the 
first
 quarter of 
2016.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-17-007864:notes:91]
3

[0001437749-17-007864:notes:92]
[same as prior period, unchanged from 0001437749-16-041083:notes:82]

[0001437749-17-007864:notes:93]
The components of inventories at 
 April

[0001437749-17-007864:notes:94]
| (in thousands) |  | April 1, 2017 |  |  | December 31, 2016 |  |
| Raw materials |  | $ | 33,003 |  |  | $ | 32,231 |  |
| Work in process |  |  | 24,200 |  |  |  | 23,354 |  |
| Finished goods |  |  | 61,108 |  |  |  | 58,478 |  |
| Total |  | $ | 118,311 |  |  | $ | 114,063 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-17-007864:notes:95]
2

[0001437749-17-007864:notes:96]
. Acquisitions

[0001437749-17-007864:notes:97]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 
805,
 “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s consolidated financial statements from the date of the acquisition.

[0001437749-17-007864:notes:98]
Monolith

[0001437749-17-007864:notes:99]
In 
 December

[0001437749-17-007864:notes:100]
2015,
 the Company invested 
$3.5
 million in the preferred stock of Monolith Semiconductor Inc. (“Monolith”), a U.S. start-up company developing silicon carbide technology, which represented approximately 
12%
 of the common stock of Monolith on an as-converted basis. The Company accounted for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was 
$3.5
 million at 
 December

[0001437749-17-007864:notes:101]
On 
 February

[0001437749-17-007864:notes:102]
28,

[0001437749-17-007864:notes:103]
2017,
 pursuant to a Securities Purchase Agreement between the Company and the stockholders of Monolith and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired approximately 
62%
 of the outstanding common stock of Monolith for 
$15
 million. The Securities Purchase Agreement includes provisions whereby the Company will acquire the remaining outstanding stock of Monolith (“non-controlling interest”) at a time or times based on Monolith meeting certain technical and sales targets. Consideration for the additional investment(s) will range from 
$1.0
 million to 
$10
 million and will be paid no later than 
 June

[0001437749-17-007864:notes:104]
2019.

[0001437749-17-007864:notes:105]
The additional investment resulted in the Company gaining control of Monolith and was accounted for as a step-acquisition with the fair value of the original investment immediately before the acquisition estimated to be approximately 
$3.5
 million. As the fair value of the investment immediately prior to the transaction equaled the carrying value, there was no impact on the Company’s consolidated statement of net income. As the Securities Purchase Agreement includes an obligation of the Company to mandatorily redeem the non-controlling interest for cash, the fair value of the non-controlling interest was recognized as a liability on the Company’s consolidated balance sheet.

[0001437749-17-007864:notes:106]
Commencing 
 March

[0001437749-17-007864:notes:107]
2017,
 Monolith was reflected as a consolidated subsidiary within the Company’s consolidated financial statements. Had the acquisition occurred as of 
 January

[0001437749-17-007864:notes:108]
2017,
 the impact on the Company’s consolidated results of operations would not have been material.

[0001437749-17-007864:notes:109]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Monolith acquisition:

[0001437749-17-007864:notes:110]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Original investment |  | $ | 3,500 |  |
| Cash, net of cash acquired |  |  | 14,172 |  |
| Fair value of commitment to purchase non-controlling interest |  |  | 9,000 |  |
| Total purchase consideration |  | $ | 26,672 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 891 |  |
| Property, plant, and equipment |  |  | 789 |  |
| Patented and unpatented technologies |  |  | 6,720 |  |
| Non-compete agreement |  |  | 140 |  |
| Goodwill |  |  | 20,641 |  |
| Current liabilities |  |  | (639 | ) |
| Other non-current liabilities |  |  | (1,870 | ) |
|  |  | $ | 26,672 |  |

[0001437749-17-007864:notes:111]
All Monolith goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Monolith’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-17-007864:notes:112]
ON Portfolio

[0001437749-17-007864:notes:113]
On 
 August

[0001437749-17-007864:notes:114]
29,

[0001437749-17-007864:notes:115]
2016,
 the Company acquired certain assets of select businesses (the “ON Portfolio”) of ON Semiconductor Corporation for 
$104.0
 million. The Company funded the acquisition with available cash and proceeds from its credit facility

[0001437749-17-007864:notes:116]
[same as prior period, unchanged from 0001437749-16-041083:notes:88]

[0001437749-17-007864:notes:117]
consists of a product portfolio that includes transient voltage suppression (“TVS”) diodes, switching thyristors and insulated gate bipolar transistors (“IGBTs”) for automotive ignition applications. The acquisition expands the Company’s offerings in power semiconductor applications as well as increases its presence in the automotive electronics market. The ON Portfolio products have strong synergies with the Company’s existing circuit protection business and will strengthen its channel partnerships and customer engagement.

[0001437749-17-007864:notes:118]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the ON Portfolio acquisition:

[0001437749-17-007864:notes:119]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 104,000 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 4,816 |  |
| Customer relationships |  |  | 31,800 |  |
| Patented and unpatented technologies |  |  | 8,800 |  |
| Non-compete agreement |  |  | 2,500 |  |
| Goodwill |  |  | 56,084 |  |
|  |  | $ | 104,000 |  |

[0001437749-17-007864:notes:120]
All the ON Portfolio business goodwill and other assets were recorded in the Electronics segment and are reflected in the Americas and Europe geographic areas. The customer relationships are being amortized over 
13.5
 years. The patented and unpatented technologies are being amortized over 
6
-
8.5
 years. The non-compete agreement is being amortized over 
4
 years. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining the ON Portfolio products with the Company’s existing

[0001437749-17-007864:notes:121]
power semiconductor product portfolio. 
$7.3
 million of goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-17-007864:notes:122]
As required by purchase accounting rules, the Company recorded a 
$0.7
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. All of the step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-17-007864:notes:123]
[same as prior period, unchanged from 0001437749-16-041083:notes:96]

[0001437749-17-007864:notes:124]
On 
 April

[0001437749-17-007864:notes:125]
2016,
 the Company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy for 
$19.2
 million, net of acquired cash and after settlement of a working capital adjustment. The Company funded the acquisition with cash on hand and borrowings under the Company’s revolving credit facility. The acquired business is part of the Company's commercial vehicle product business within the Automotive segment and specializes in the design, manufacturing, and selling of manual and electrical high current switches and trailer connectors for commercial vehicles. The acquisition expands the Company’s commercial vehicle products business globally.

[0001437749-17-007864:notes:126]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Menber’s acquisition:

[0001437749-17-007864:notes:127]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash, net of acquired cash |  | $ | 19,162 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 12,919 |  |
| Property, plant, and equipment |  |  | 1,693 |  |
| Customer relationships |  |  | 3,050 |  |
| Patented and unpatented technologies |  |  | 224 |  |
| Trademarks and tradenames |  |  | 1,849 |  |
| Goodwill |  |  | 8,091 |  |
| Current liabilities |  |  | (7,220 | ) |
| Other non-current liabilities |  |  | (1,444 | ) |
|  |  | $ | 19,162 |  |

[0001437749-17-007864:notes:128]
All Menber’s goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The customer relationships are being amortized over 
10
 years. The patented and unpatented technologies are being amortized over 
5
 years. The trademarks and tradenames are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Menber’s products with the Company’s existing automotive product portfolio. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-17-007864:notes:129]
As required by purchase accounting rules, the Company recorded a 
$0.2
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, with the charge reflected as other non-segment costs.

[0001437749-17-007864:notes:130]
[same as prior period, unchanged from 0001437749-16-041083:notes:104]

[0001437749-17-007864:notes:131]
25,

[0001437749-17-007864:notes:132]
2016,
 the Company acquired 
100%
 of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for 
$348.3
 million, net of acquired cash and after settlement of certain post-closing adjustments. At 
 April

[0001437749-17-007864:notes:133]
$344.5
 million of the 
$348.3
 million purchase price has been paid with the remaining consideration expected to be paid in the 
second
 quarter of 
2017.
 The Company funded the acquisition with available cash on hand and borrowings under the Company’s revolving credit facility. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-17-007864:notes:134]
has a leading position in polymer based resettable circuit protection devices, with a strong global presence in the automotive, battery, industrial, communications and mobile computing markets. PolySwitch has manufacturing facilities in Shanghai and Kunshan, China and Tsukuba, Japan. The acquisition allows the Company to strengthen its global circuit protection product portfolio, as well as strengthen its presence in the automotive electronics and battery end markets. The acquisition also significantly increases the Company’s presence in Japan.

[0001437749-17-007864:notes:135]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the PolySwitch acquisition:

[0001437749-17-007864:notes:136]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Original consideration |  | $ | 350,000 |  |
| Post closing consideration adjustment received |  |  | (1,708 | ) |
| Acquired cash |  |  | (3,810 | ) |
| Acquired cash to be returned to seller |  |  | 3,810 |  |
| Total purchase consideration |  | $ | 348,292 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 60,228 |  |
| Property, plant, and equipment |  |  | 51,613 |  |
| Land lease |  |  | 4,290 |  |
| Patented and unpatented technologies |  |  | 56,425 |  |
| Customer relationships |  |  | 39,720 |  |
| Goodwill |  |  | 165,088 |  |
| Other long-term assets |  |  | 11,228 |  |
| Current liabilities |  |  | (35,280 | ) |
| Other non-current liabilities |  |  | (5,020 | ) |
|  |  | $ | 348,292 |  |

[0001437749-17-007864:notes:137]
All PolySwitch goodwill and other assets and liabilities were recorded in the Electronics and Automotive segments and reflected in all geographic areas. The customer relationships are being amortized over 
15
 years. The patented and unpatented technologies are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining PolySwitch products with the Company’s existing automotive and electronics product portfolio. 
$103.8
 million and 
$61.3
 million of the goodwill for the above acquisition has been assigned to the Electronics and Automotive segments, respectively, with 
$64.9
 million expected to be deductible for tax purposes.

[0001437749-17-007864:notes:138]
As required by purchase accounting rules, the Company recorded a 
$6.9
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the 
second
 quarter of 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-17-007864:notes:139]
[same as prior period, unchanged from 0001437749-16-041083:notes:120]

[0001437749-17-007864:notes:140]
The following table summarizes, on a pro forma basis, the combined results of operations of the Company and the acquired PolySwitch and the ON Portfolio businesses for the 
three
 months ended 
 April

[0001437749-17-007864:notes:141]
2016
 as though the acquisitions had occurred as of 
 January

[0001437749-17-007864:notes:142]
3,

[0001437749-17-007864:notes:143]
2016.
 The Company has not included pro forma results of operations for Menber’s or Monolith as these results were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the PolySwitch or ON Portfolio acquisitions occurred as of 
 January

[0001437749-17-007864:notes:144]
2016
 or of future consolidated operating results.

[0001437749-17-007864:notes:145]
Pro forma results presented above primarily reflect: (i) incremental depreciation relating to fair value adjustments to property, plant, and equipment; (ii) amortization adjustments relating to fair value estimates of intangible assets; (iii) incremental interest expense on assumed indebtedness; and (iv) additional cost of goods sold relating to the capitalization of gross profit as part of purchase accounting recognized for purposes of the pro forma as if it was recognized during the Company’s 
first
 quarter of 
2016.
 Pro forma adjustments described above have been tax affected using the Company's effective rate during the respective periods.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-17-007864:notes:146]
Recently

[0001437749-17-007864:notes:147]
Adopted

[0001437749-17-007864:notes:148]
Accounting Standards

[0001437749-17-007864:notes:149]
In 
 July

[0001437749-17-007864:notes:150]
2015,
 the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 
2015
-
11
 – “Inventory (Topic 
330):
 Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December

[0001437749-17-007864:notes:151]
2016,
 and interim periods within those fiscal years. The Company adopted the new standard on 
 January

[0001437749-17-007864:notes:152]
2017.
 The adoption of the update did not have a material impact on the Company’s consolidated financial statements. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

[0001437749-17-007864:notes:153]
In 
 March

[0001437749-17-007864:notes:154]
2016,
 the FASB issued ASU No. 
2016
-
09
 – “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December

[0001437749-17-007864:notes:155]
2017.
 As a result of the adoption, on a prospective basis, the Company recognized 
$0.5
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 months ended 
 April

[0001437749-17-007864:notes:156]
2017.
 Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Consolidated Statement of Cash Flows. The Company elected not to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had no impact on the results of operations.

[0001437749-17-007864:notes:157]
Recently Issued Accounting Standards

[0001437749-17-007864:notes:158]
In 
 May

[0001437749-17-007864:notes:159]
2014,
 the FASB issued ASU No. 
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606)
 which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August,

[0001437749-17-007864:notes:160]
2015,
 the FASB issued ASU No. 
2015
-
14,
 which postponed the effective date of ASU No. 
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December

[0001437749-17-007864:notes:161]
2017,
 with early adoption permitted on the original effective date of fiscal years beginning after 
 December

[0001437749-17-007864:notes:162]
2016.
 The Company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements and has not concluded on its adoption methodology. While the Company is currently assessing the impact of the new standards, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does not expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may
 be affected. The Company has not yet quantified this potential impact.

[0001437749-17-007864:notes:163]
In 
 February

[0001437749-17-007864:notes:164]
2016,
 the FASB issued ASU No. 
2016
-
02,
 "Leases" (Topic 
842).
 This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December

[0001437749-17-007864:notes:165]
2018,
 with early adoption permitted. Adoption will require a modified retrospective transition. The Company is currently evaluating the impact of this ASU on its consolidated financial statements.

[0001437749-17-007864:notes:166]
In 
 January

[0001437749-17-007864:notes:167]
2017,
 the FASB issued ASU No. 
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350).
 This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity no longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December

[0001437749-17-007864:notes:168]
2020,
 with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January

[0001437749-17-007864:notes:169]
2017.
 The Company expects to adopt the new standard in 
2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-17-007864:notes:170]
6

[0001437749-17-007864:notes:171]
. Benefit Plans

[0001437749-17-007864:notes:172]
The Company has company-sponsored defined benefit pension plans covering employees in the U.K., Germany, the Philippines, China, Japan, and France. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0001437749-17-007864:notes:173]
The components of net periodic benefit cost for the 
three
 months ended 
 April

[0001437749-17-007864:notes:174]
2017
 and 
 April

[0001437749-17-007864:notes:175]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 408 |  |  | $ | 332 |  |
| Interest cost |  |  | 360 |  |  |  | 497 |  |
| Expected return on plan assets |  |  | (476 | ) |  |  | (520 | ) |
| Amortization of prior service (credit) |  |  | 84 |  |  |  | 73 |  |
| Total cost of the plan |  |  | 376 |  |  |  | 382 |  |
| Expected plan participants’ contribution |  |  | — |  |  |  | — |  |
| Net periodic benefit cost |  | $ | 376 |  |  | $ | 382 |  |

[0001437749-17-007864:notes:176]
The expected return on pension assets is 
4.5%
 and 
4.9%
 in 
2017
 and 
2016,
 respectively.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001437749-17-007864:notes:177]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments (a) |  |  | Unrealized gains on investments |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 31, 2016 |  | $ | (11,983 | ) |  | $ | 10,769 |  |  | $ | (73,365 | ) |  | $ | (74,579 | ) |
| Activity in the period |  |  | (282 | ) |  |  | 947 |  |  |  | 4,962 |  |  |  | 5,627 |  |
| Balance at April 1, 2017 |  | $ | (12,265 | ) |  | $ | 11,716 |  |  | $ | (68,403 | ) |  | $ | (68,952 | ) |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-17-007864:notes:178]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 86,658 |  |  | $ | 85,149 |  |
| China |  |  | 74,690 |  |  |  | 48,509 |  |
| Other countries |  |  | 124,093 |  |  |  | 85,740 |  |
| Total net sales |  | $ | 285,441 |  |  | $ | 219,398 |  |

[0001437749-17-007864:notes:179]
| (in thousands) |  | April 1, 2017 |  |  | December 31, 2016 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 23,770 |  |  | $ | 23,731 |  |
| China |  |  | 65,073 |  |  |  | 65,345 |  |
| Mexico |  |  | 58,111 |  |  |  | 52,262 |  |
| Philippines |  |  | 32,615 |  |  |  | 33,345 |  |
| Other countries |  |  | 44,373 |  |  |  | 42,492 |  |
| Total long-lived assets |  | $ | 223,942 |  |  | $ | 217,175 |  |

[0001437749-17-007864:notes:180]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 332 |  |  | $ | 1,618 |  |
| China |  |  | 2,341 |  |  |  | 1,046 |  |
| Mexico |  |  | 6,978 |  |  |  | 4,653 |  |
| Philippines |  |  | 855 |  |  |  | 1,101 |  |
| Other countries |  |  | 1,871 |  |  |  | 721 |  |
| Total additions to long-lived assets |  | $ | 12,377 |  |  | $ | 9,139 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-007864:notes:181]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | April 1, 2017 |  |  | April 2, 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 153,767 |  |  | $ | 98,796 |  |
| Automotive |  |  | 107,839 |  |  |  | 91,933 |  |
| Industrial |  |  | 23,835 |  |  |  | 28,669 |  |
| Total net sales |  | $ | 285,441 |  |  | $ | 219,398 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 8,387 |  |  | $ | 5,372 |  |
| Automotive |  |  | 5,371 |  |  |  | 3,266 |  |
| Industrial |  |  | 1,314 |  |  |  | 1,451 |  |
| Other |  |  | — |  |  |  | 937 |  |
| Total depreciation and amortization |  | $ | 15,072 |  |  | $ | 11,026 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 35,206 |  |  | $ | 22,416 |  |
| Automotive |  |  | 15,065 |  |  |  | 17,491 |  |
| Industrial |  |  | 106 |  |  |  | 1,673 |  |
| Other(a) |  |  | (1,525 | ) |  |  | (9,152 | ) |
| Total operating income |  |  | 48,852 |  |  |  | 32,428 |  |
| Interest expense |  |  | 3,120 |  |  |  | 2,045 |  |
| Foreign exchange loss (gain) |  |  | (1,557 | ) |  |  | 3,823 |  |
| Other expense (income), net |  |  | (139 | ) |  |  | (517 | ) |
| Income before income taxes |  | $ | 47,428 |  |  | $ | 27,077 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-007864:notes:182]
1

[0001437749-17-007864:notes:183]
0

[0001437749-17-007864:notes:184]
. Segment Information

[0001437749-17-007864:notes:185]
The Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it 
 may
 earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”).  The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0001437749-17-007864:notes:186]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the 
three
 operating segments.  The Company does not report inter-segment revenue because the operating segments do not record it.  Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”.  Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments.  These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments.  Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in 
one
 segment 
 may
 benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001437749-17-007864:notes:187]
|  | ● | Electronics Segment: Provides circuit protection components for overcurrent and overvoltage protection, as well as sensor components and modules to leading global manufacturers of a wide range of electronic products. The segment covers a broad range of end markets, including consumer electronics, telecommunications equipment, medical devices, lighting products, and white goods. The Electronics segment supplies circuit protection, sensing and control products to various leading manufacturers. The Electronics segment has one of the broadest product offerings in the industry including fuses and protectors, positive temperature coefficient (“PTC”) resettable fuses, varistors, polymer electrostatic discharge (“ESD”) suppressors, discrete TVS diodes, TVS diode arrays protection and switching thyristors, gas discharge tubes, power switching components, fuseholders, reed switch and sensor assemblies, IGBT blocks, and related accessories. |

[0001437749-17-007864:notes:188]
|  | ● | Automotive Segment: Provides circuit protection and sensor products to the worldwide automotive original equipment manufacturers (“OEM”) and parts distributors of passenger automobiles, trucks, buses, and off-road equipment. In addition, the Company supplies heavy duty power distribution modules, switches and relays to the commercial vehicle industry. The Company also sells its fuses, including blade fuses and high current fuses, battery cable protectors, and varistors, in the automotive replacement parts market. The Company also supplies wiring harness manufacturers and auto parts suppliers worldwide. |

[0001437749-17-007864:notes:189]
|  | ● | Industrial Segment: Provides circuit protection products for industrial and commercial customers. Products include power fuses and other circuit protection devices, including protection and time delay relays, which are used in commercial and industrial buildings and large equipment such as HVAC systems, elevators, and machine tools. The Company also supplies industrial ground fault protection in mining and other large industrial operations. |

[0001437749-17-007864:notes:190]
Segment information is summarized as follows:

[0001437749-17-007864:notes:191]
(a) For the 
first
 quarter of 
2017,
 “Other” Operating income (loss) of 
$1.5
 million consists of acquisition and integration costs associated with the Company’s 
2016
 acquisitions (included in Cost of sales (“COS”) and Selling, general, and administrative expenses (“SG&A)).

[0001437749-17-007864:notes:192]
For the 
first
 quarter of 
2016,
 “Other” Operating income (loss) of 
$9.2
 million consists of: (i) 
$1.4
 million of internal reorganization costs with 
$1.1
 million included in COS and 
$0.3
 million included in SG&A, (ii) 
$6.2
 million of acquisition related expenses included in SG&A, and (iii) 
$1.6
 million of impairment and severance costs related to the planned shut-down of the Company’s Roskilde, Denmark operations with 
$0.2
 million included in COS, 
$0.9
 million included in amortization of intangibles, 
$0.3
 million included in research and development, and 
$0.2
 million included in SG&A.

[0001437749-17-007864:notes:193]
The Company’s net sales by country are as follows:

[0001437749-17-007864:notes:194]
The Company’s long-lived assets by country, as of 
 April

[0001437749-17-007864:notes:195]
2016,
 are as follows:

[0001437749-17-007864:notes:196]
The Company’s additions to long-lived assets by country are as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-17-007864:notes:197]
1.
 Summary of Significant Accounting Policies and Other Information

[0001437749-17-007864:notes:198]
Nature of Operations

[0001437749-17-007864:notes:199]
Littelfuse, Inc. and subsidiaries (the “Company”) design, manufacture, and sell circuit protection devices for use in the automotive, electronics, and industrial markets throughout the world. The Company is 
one
 of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.

[0001437749-17-007864:notes:200]
Goodwill and Indefinite-Lived Intangible Assets

[0001437749-17-007864:notes:201]
The Company annually tests goodwill and indefinite-lived intangible assets for impairment on the 
first
 day of its fiscal 
fourth
 quarter or at other dates if there is an event or change in circumstances that indicates the asset 
 may
 be impaired. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted 
five
-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after 
five
 years) to estimate market value. In addition, the Company compares its derived enterprise value on a consolidated basis to the Company’s market capitalization as of its test date to ensure its derived value approximates the market value of the Company when taken as a whole.

[0001437749-17-007864:notes:202]
Factors the Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does not believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the relays reporting unit if there are declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October

[0001437749-17-007864:notes:203]
2016,
 the Company concluded the fair value of the relays reporting unit exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. As of the 
2016
 annual test date, the relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 April

[0001437749-17-007864:notes:204]
2017,
 there were no events or circumstances that indicate the Relays intangible assets were impaired.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-17-007864:notes:205]
7.
 Shareholders’ Equity

[0001437749-17-007864:notes:206]
Accumulated Other Comprehensive Income (Loss) (“AOCI”): The following table sets forth the changes in the components of AOCI by component for the 
three
 months ended 
 April

[0001437749-17-007864:notes:207]
(a) The balances at 
 April

[0001437749-17-007864:notes:208]
2016
 are net of taxes of 
$1.2
 million and 
$1.1
 million, respectively.
