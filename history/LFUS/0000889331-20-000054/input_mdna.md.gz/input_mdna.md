# LFUS MD&A — 0000889331-20-000054


## mdna

[0000889331-20-000054:mdna:1]
[same as prior period, unchanged from 0000889331-20-000045:mdna:1]

[0000889331-20-000054:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-20-000054:mdna:3]
[same as prior period, unchanged from 0000889331-20-000045:mdna:3]

[0000889331-20-000054:mdna:4]
[same as prior period, unchanged from 0000889331-20-000045:mdna:4]

[0000889331-20-000054:mdna:5]
[same as prior period, unchanged from 0000889331-20-000045:mdna:5]

[0000889331-20-000054:mdna:6]
[same as prior period, unchanged from 0000889331-20-000045:mdna:6]

[0000889331-20-000054:mdna:7]
[same as prior period, unchanged from 0000889331-20-000045:mdna:7]

[0000889331-20-000054:mdna:8]
[same as prior period, unchanged from 0000889331-20-000045:mdna:8]

[0000889331-20-000054:mdna:9]
[same as prior period, unchanged from 0000889331-20-000045:mdna:9]

[0000889331-20-000054:mdna:10]
[same as prior period, unchanged from 0000889331-20-000045:mdna:10]

[0000889331-20-000054:mdna:11]
For the third quarter of 2020, the Company recognized net sales of $391.6 million compared to $362.0 million in the third quarter of 2019 representing an increase of $29.6 million, or 8.2%. The increase was primarily driven by higher volume in Electronics segment, and $4.4 million or 1.2% of favorable changes in foreign exchange rates. The Company recognized net income of $55.4 million, or $2.25 per diluted share, in the third quarter of 2020 compared to net income of $35.6 million, or $1.44 per diluted share in the third quarter of 2019. The increase in net income reflects higher operating income in the Electronics and Automotive segments, higher foreign exchange gains and lower acquisition-related and integration charges.

[0000889331-20-000054:mdna:12]
The Company continues to take actions to improve its cost structure. The Company expects to realize cost savings from the restructuring activities taken during 2019 and 2020, including the reorganization of certain research and development, selling and administrative functions across all segments. The Company is also in process of several restructuring activities across its manufacturing and supply chain footprint, including the consolidation of a manufacturing facility within the Industrial Segment, which is expected to be completed in the first half of 2021.

[0000889331-20-000054:mdna:13]
Net cash provided by operating activities was $164.3 million for the nine months ended September 26, 2020 as compared to $160.9 million for the nine months ended September 28, 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and favorable changes in net working capital partially offset by lower earnings largely due to the impact of COVID-19.

[0000889331-20-000054:mdna:14]
On March 25, 2020, the company borrowed $100.0 million from its current revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. On April 3, 2020, the Company amended the existing credit agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended credit agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $60.0 million on the amended revolving credit facility during the three months ended September 26, 2020. The balance under the facility was $180.0 million as of September 26, 2020.

[0000889331-20-000054:mdna:15]
[same as prior period, unchanged from 0000889331-20-000045:mdna:15]

[0000889331-20-000054:mdna:16]
[same as prior period, unchanged from 0000889331-20-000045:mdna:16]

[0000889331-20-000054:mdna:17]
The Company continued to manage through the COVID-19 impacts during the third quarter, with a lesser impact to its financial results compared to the first six months of 2020. Our manufacturing facilities generally operated at normal capacity levels as production disruptions were minimal during the third quarter. The effects from COVID-19 continued to drive higher freight cost, as well as spending on personal protective equipment ("PPE"), additional personnel and employee transportation costs, partially offset by certain international government subsidies and COVID-19 relief programs.

[0000889331-20-000054:mdna:18]
The Company’s priorities continue to be first, on our associates, their families and the communities in which we operate; second, our customers; and third, long-term financial health of the company. In an effort to protect the health and safety of our employees, the Company has enacted numerous proactive, aggressive actions at its facilities globally, and implemented a number of safety procedures including hygiene and disinfection protocols, social distancing and wearing PPE. The Company expects these actions will continue for the foreseeable future.

[0000889331-20-000054:mdna:19]
During the first half of 2020, governments around the world enacted various measures in an effort to contain COVID-19 and slow its spread. These measures included orders to close all businesses not deemed “essential”, isolate residents to their homes or places of residence, and practice social distancing when engaging in essential activities, which disrupted certain of our operating locations in around the world. During the third quarter, all of our manufacturing facilities have been operating and are generally at normal capacity levels.

[0000889331-20-000054:mdna:20]
[same as prior period, unchanged from 0000889331-20-000045:mdna:20]

[0000889331-20-000054:mdna:21]
The Company anticipates that the global health crisis caused by COVID-19 may continue to negatively impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a resurgence in COVID-19 cases and its impact on our employees, customers, suppliers and vendors.  The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business and operations, including the effects on our customers, employees, and prospects, or on our financial results for the remainder of fiscal 2020.

[0000889331-20-000054:mdna:22]
[same as prior period, unchanged from 0000889331-20-000045:mdna:23]

[0000889331-20-000054:mdna:23]
The Company performs its annual goodwill impairment tests on the first day of the fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. As part of its interim review for indicators of impairment, management analyzed potential changes in the value of individual reporting units with goodwill based on each reporting unit’s operating results for the nine months ended September 26, 2020 compared to expected results.  In addition, management considered how other key assumptions, including discount rates and expected long-term growth rates, used in last fiscal year’s impairment analysis, could be impacted by changes in market conditions and economic events.  Management considered trends in these factors when performing its assessment of whether an interim impairment review was required for any reporting unit. Based on September 26, 2020 interim assessment, Management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value. Nevertheless, a continued global economic slowdown and further business disruption due to COVID-19 could result in changes to expectations of future financial results and key valuation assumptions.

[0000889331-20-000054:mdna:24]
During the second quarter of  2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition, during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling an existing program. The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of September 26, 2020, the automotive sensors reporting unit had $9.4 million of remaining goodwill.

[0000889331-20-000054:mdna:25]
The semiconductor reporting unit has experienced declines in net sales for the nine months ended September 26, 2020 due to temporary shut-downs of its plants as well as outsourced manufacturing partners and lower customer demand primarily due to COVID-19. The Company continues to evaluate the impact of COVID-19 on its long-term expectations for this unit. Further negative developments having a significant impact on the estimated fair value of this reporting unit could result in future goodwill impairment charges. As of the September 30, 2019 annual goodwill impairment test, the semiconductors reporting unit estimated fair value exceeded its book value by approximately 42%. As of September 26, 2020, $473.3 million of goodwill was allocated to the semiconductors reporting unit. The semiconductors reporting unit is included within the Electronics segment.

[0000889331-20-000054:mdna:26]
[same as prior period, unchanged from 0000889331-20-000045:mdna:29]

[0000889331-20-000054:mdna:27]
While the Company has not historically or currently as of September 26, 2020 had significant credit risk on its accounts receivable, the impact of the COVID-19 pandemic and associated economic slowdown may increase the Company’s credit risk on accounts receivable. It is possible that the Company’s customers may experience liquidity issues which may impact the timing of the collections on receivables. The Company will continue to evaluate how the ongoing pandemic may impact collectability.

[0000889331-20-000054:mdna:28]
[same as prior period, unchanged from 0000889331-20-000045:mdna:31]

[0000889331-20-000054:mdna:29]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The third quarter of 2020 includes $0.3 million ($1.6 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $1.3 million ($40.9 million year-to-date) of restructuring, impairment and other charges, primarily related employee termination costs of $1.2 million ($4.6 million year-to-date), and other restructuring charges of $0.1 million ($0.2 million year-to-date), the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, and impairment charges of $2.2 million recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment.

[0000889331-20-000054:mdna:30]
The third quarter of 2019 includes $5.7 million ($17.9 million year-to-date) of non-segment charges, of which $2.5 million ($11.0 million year-to-date) of restructuring charges are primarily related to employee termination costs and other restructuring charges and $3.2 million ($6.9 million year-to-date) of acquisition-related and integration charges are primarily related to the IXYS acquisition and other contemplated acquisitions.

[0000889331-20-000054:mdna:31]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |  | 2020 |  | 2019 |  | Change |  | %Change |
| Net sales |  | $ | 391,566 |  |  | $ | 361,971 |  |  | $ | 29,595 |  |  | 8.2 | % |  | $ | 1,044,999 |  |  | $ | 1,165,350 |  |  | $ | (120,351) |  |  | (10.3) | % |
| Gross profit |  | 138,176 |  |  | 130,946 |  |  | 7,230 |  |  | 5.5 | % |  | 360,987 |  |  | 427,982 |  |  | (66,995) |  |  | (15.7) | % |
| Operating expenses |  | 73,618 |  |  | 83,779 |  |  | (10,161) |  |  | (12.1) | % |  | 263,629 |  |  | 267,508 |  |  | (3,879) |  |  | (1.5) | % |
| Operating income |  | 64,558 |  |  | 47,167 |  |  | 17,391 |  |  | 36.9 | % |  | 97,358 |  |  | 160,474 |  |  | (63,116) |  |  | (39.3) | % |
| Income before income taxes |  | 67,426 |  |  | 41,404 |  |  | 26,022 |  |  | 62.8 | % |  | 92,340 |  |  | 141,410 |  |  | (49,070) |  |  | (34.7) | % |
| Income taxes |  | 12,070 |  |  | 5,757 |  |  | 6,313 |  |  | 109.7 | % |  | 21,331 |  |  | 24,982 |  |  | (3,651) |  |  | (14.6) | % |
| Net income |  | $ | 55,356 |  |  | $ | 35,647 |  |  | $ | 19,709 |  |  | 55.3 | % |  | $ | 71,009 |  |  | $ | 116,428 |  |  | $ | (45,419) |  |  | (39.0) | % |

[0000889331-20-000054:mdna:32]
[same as prior period, unchanged from 0000889331-20-000045:mdna:35]

[0000889331-20-000054:mdna:33]
Net sales increased $29.6 million or 8.2% for the third quarter of 2020 compared to the third quarter of 2019 primarily due to  higher volume in Electronics segment, and $4.4 million or 1.2% of favorable changes in foreign exchange rates.

[0000889331-20-000054:mdna:34]
Net sales decreased $120.4 million or 10.3% for the first nine months of 2020 compared to the first nine months of 2019 primarily due to lower volume driven by the disruption across the Electronics and Automotive segments due to temporary closures of manufacturing facilities in the first half of the fiscal year resulting from government directives due to the impact of

[0000889331-20-000054:mdna:35]
COVID-19, lower volume across the Electronics segment from electronics distribution partners and end customers reducing excess inventories and production, and lower volume across the Automotive segment due to a decline in global auto production driven by lower global end market demand, and $1.2 million or 0.1% of unfavorable changes in foreign exchange rates.

[0000889331-20-000054:mdna:36]
[same as prior period, unchanged from 0000889331-20-000045:mdna:38]

[0000889331-20-000054:mdna:37]
Gross profit was $138.2 million, or 35.3% of net sales, in the third quarter of 2020 compared to $130.9 million, or 36.2% of net sales, for the third quarter of 2019. The increase in gross profit is primarily due to higher volume in the Electronics segment, partially offset by higher freight, supplies and other costs  due to the impact of COVID-19. The decrease in gross margin is primarily due to unfavorable price and product mix and changes in foreign exchange rates.

[0000889331-20-000054:mdna:38]
Gross profit was $361.0 million, or 34.5% of net sales, in the first nine months of 2020 compared to $428.0 million, or 36.7% of net sales, for the first nine months  of 2019. The decrease in gross profit reflected lower volume across all segments. The decrease in gross margin is primarily due to lower volumes across the Electronics and Automotive segments, additional costs associated with government-directed plant shutdowns and supply chain constraints, higher freight, supplies and other costs  due to the impact of COVID-19, and unfavorable price and product mix.

[0000889331-20-000054:mdna:39]
[same as prior period, unchanged from 0000889331-20-000045:mdna:41]

[0000889331-20-000054:mdna:40]
Total operating expenses were $73.6 million, or 18.8% of net sales, for the third quarter of 2020 compared to $83.8 million, or 23.1% of net sales, for the third quarter of 2019. The decrease in operating expenses of $10.2 million is primarily due to  lower research and development expenses of $6.7 million, a reduction in acquisition-related and integration charges of $2.9 million and reduced incentive compensation and travel expenses due to COVID-19.

[0000889331-20-000054:mdna:41]
Total operating expenses were $263.6 million, or 25.2% of net sales, for the first nine months of 2020 compared to $267.5 million, or 23.0% of net sales, for the first nine months of 2019. The decrease in operating expenses of $3.9 million is primarily due to lower research and development expenses of $21.6 million, lower incentive compensation, sales commissions and travel expenses due to COVID-19, and a $5.3 million reduction in acquisition-related and integration charges, partially offset by the second quarter goodwill impairment charge of $33.8 million, or 3.2% of net sales, in the automotive sensors reporting unit within the Automotive segment and impairment charges of $2.2 million related to the Company’s first quarter announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-20-000054:mdna:42]
Operating Income

[0000889331-20-000054:mdna:43]
Operating income was $64.6 million, an increase of $17.4 million, or 36.9%, for the third quarter of 2020 compared to $47.2 million for the third quarter of 2019. The increase is primarily due to higher gross margin in the Electronics segment and the lower operating expenses noted above. Operating margins increased from 13.0% in the third quarter of 2019 to 16.5% in the third quarter of 2020 driven by the factors mentioned above.

[0000889331-20-000054:mdna:44]
Operating income was $97.4 million, a decrease of $63.1 million, or 39.3%, for the first nine months of 2020 compared to $160.5 million for the first nine months of 2019. The decrease in operating income is primarily due to lower gross margin across all segments and higher operating expenses noted above. Operating margins decreased from 13.8% in the first nine months of 2019 to 9.3% in the first nine months of 2020 driven by the factors mentioned above. The second quarter goodwill impairment charge of $33.8 million negatively impacted the operating margin by 3.2% for the first nine months of 2020.

[0000889331-20-000054:mdna:45]
Income Before Income Taxes

[0000889331-20-000054:mdna:46]
Income before income taxes was $67.4 million, or 17.2% of net sales, for the third quarter of 2020 compared to  $41.4 million, or 11.4% of net sales, for the third quarter of 2019. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange gains of $6.2 million during the three months ended September 26, 2020 compared to foreign exchange losses of $5.0 million, lower interest expense of $0.6 million, partially offset by lower interest income of $1.1 million and a reduction in investment gains of $1.0 million associated with our equity investments during the three months ended September 26, 2020 compared to the three months ended September 28, 2019.

[0000889331-20-000054:mdna:47]
Income before income taxes was $92.3 million, or 8.8% of net sales, for the first nine months of 2020 compared to $141.4 million, or 12.1% of net sales, for the first nine months of 2019.  In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by foreign exchange gains of $9.6 million during the nine months ended September 26, 2020 compared to foreign exchange losses of $5.6 million during the nine months ended

[0000889331-20-000054:mdna:48]
September 28, 2019, impairment charges of $3.1 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment during the nine months ended September 28, 2019, partially offset by a $1.5 million increase in coal mining reserves, $1.5 million decreases in investment gains associated with our equity investments, and lower interest income of $1.0 million during the nine months ended September 26, 2020 compared to the nine months ended September 28, 2019

[0000889331-20-000054:mdna:49]
[same as prior period, unchanged from 0000889331-20-000045:mdna:50]

[0000889331-20-000054:mdna:50]
Income tax expense for the third quarter of 2020 was $12.1 million, or an effective tax rate of 17.9%, compared to income tax expense of $5.8 million, or an effective tax rate of 13.9%, for the the third quarter of 2019. The effective tax rate for the third quarter of 2020 is higher than the effective tax rate for the comparable 2019 period, primarily due to the impact of the goodwill impairment charge of  $33.8 million that was recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit in the annual estimated effective tax rate, as well as a reduction in the forecasted income earned in lower tax jurisdictions in 2020 driven by the uncertainty resulting from the impact of COVID-19.

[0000889331-20-000054:mdna:51]
Income tax expense for the first nine months of 2020 was $21.3 million, or an effective tax rate of 23.1%, compared to income tax expense of $25.0 million, or an effective tax rate of 17.7%, for the first nine months of 2019. The effective tax rate for the first nine months of 2020 is higher than the effective tax rate for the comparable 2019 period, primarily due to the impact of the goodwill impairment charge of  $33.8 million that was recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit in the annual estimated effective tax rate, as well as a reduction in the forecasted income earned in lower tax jurisdictions in 2020 driven by the uncertainty resulting from the impact of COVID-19.

[0000889331-20-000054:mdna:52]
The effective tax rate for the first nine months of 2020 is higher than the applicable U.S. statutory tax rate primarily due to the impact of the goodwill impairment charge of  $33.8 million that was recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit in the annual estimated effective tax rate, as well as the forecasted impact of non-U.S. losses and expenses with no tax benefit and the U.S. global intangible low-taxed income tax provisions (in the 2019 comparable period the impact of these items was more than offset by the impact of income earned in lower tax jurisdictions), offset in part by the impact of income earned in lower tax jurisdictions.

[0000889331-20-000054:mdna:53]
[same as prior period, unchanged from 0000889331-20-000045:mdna:53]

[0000889331-20-000054:mdna:54]
[same as prior period, unchanged from 0000889331-20-000045:mdna:54]

[0000889331-20-000054:mdna:55]
[same as prior period, unchanged from 0000889331-20-000045:mdna:55]

[0000889331-20-000054:mdna:56]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |  | 2020 |  | 2019 |  | Change |  | %Change |
| Electronics |  | $ | 255,349 |  |  | $ | 227,252 |  |  | $ | 28,097 |  |  | 12.4 | % |  | $ | 692,809 |  |  | $ | 752,199 |  |  | $ | (59,390) |  |  | (7.9) | % |
| Automotive |  | 104,724 |  |  | 104,681 |  |  | 43 |  |  | — | % |  | 271,493 |  |  | 326,814 |  |  | (55,321) |  |  | (16.9) | % |
| Industrial |  | 31,493 |  |  | 30,038 |  |  | 1,455 |  |  | 4.8 | % |  | 80,697 |  |  | 86,337 |  |  | (5,640) |  |  | (6.5) | % |
| Total |  | $ | 391,566 |  |  | $ | 361,971 |  |  | $ | 29,595 |  |  | 8.2 | % |  | $ | 1,044,999 |  |  | $ | 1,165,350 |  |  | $ | (120,351) |  |  | (10.3) | % |

[0000889331-20-000054:mdna:57]
[same as prior period, unchanged from 0000889331-20-000045:mdna:57]

[0000889331-20-000054:mdna:58]
Net sales increased $28.1 million, or 12.4%, in the third quarter of 2020 compared to the third quarter of 2019 primarily due to higher volume in the semiconductor and electronics products businesses and favorable changes in foreign exchange rates of $2.4 million.

[0000889331-20-000054:mdna:59]
Net sales decreased $59.4 million, or 7.9%, in the first nine months of 2020 compared to the first nine months of 2019 primarily due to lower volume in the semiconductor and electronics products businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, lower

[0000889331-20-000054:mdna:60]
volume from electronics distribution partners and end customers reducing excess inventories, and unfavorable changes in foreign exchange rates of $0.6 million.

[0000889331-20-000054:mdna:61]
[same as prior period, unchanged from 0000889331-20-000045:mdna:60]

[0000889331-20-000054:mdna:62]
Net sales were flat in the third quarter of 2020 compared to the third quarter of 2019 as favorable changes in foreign exchange rates of $2.0 million and increased volume in auto sensor business were offset by decreased volume in the passenger car products and commercial vehicle businesses.

[0000889331-20-000054:mdna:63]
Net sales decreased $55.3 million, or 16.9%, in the first nine months of 2020 compared to the first nine months of 2019 due to decreased volume across all businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, a decline in global auto production driven by lower global end market demand and temporary closures of customer manufacturing facilities, and unfavorable changes in foreign exchange rates of $0.4 million.

[0000889331-20-000054:mdna:64]
[same as prior period, unchanged from 0000889331-20-000045:mdna:63]

[0000889331-20-000054:mdna:65]
Net sales increased by $1.5 million, or 4.8%, in the third quarter of 2020 compared to the third quarter of 2019 primarily due to the transfer of the temperature sensor product line totaling $2.3 million which was previously reported in the Electronics segment, partially offset by lower volume in the relay business.

[0000889331-20-000054:mdna:66]
Net sales decreased by $5.6 million, or 6.5%, in the first nine months of 2020 compared to the first nine months of 2019 primarily due to decreased volume across all businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 in the first half of 2020, and unfavorable changes in foreign exchange rates of $0.2 million, partially offset by the transfer of the temperature sensor product line in the third quarter of 2020 previously reported in the Electronics segment.

[0000889331-20-000054:mdna:67]
[same as prior period, unchanged from 0000889331-20-000045:mdna:66]

[0000889331-20-000054:mdna:68]
[same as prior period, unchanged from 0000889331-20-000045:mdna:67]

[0000889331-20-000054:mdna:69]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |  | 2020 |  | 2019 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 186,956 |  |  | $ | 158,778 |  |  | $ | 28,178 |  |  | 17.7 | % |  | $ | 483,566 |  |  | $ | 504,453 |  |  | $ | (20,887) |  |  | (4.1) | % |
| Americas |  | 123,739 |  |  | 122,754 |  |  | 985 |  |  | 0.8 | % |  | 333,891 |  |  | 396,683 |  |  | (62,792) |  |  | (15.8) | % |
| Europe |  | 80,871 |  |  | 80,439 |  |  | 432 |  |  | 0.5 | % |  | 227,542 |  |  | 264,214 |  |  | (36,672) |  |  | (13.9) | % |
| Total |  | $ | 391,566 |  |  | $ | 361,971 |  |  | $ | 29,595 |  |  | 8.2 | % |  | $ | 1,044,999 |  |  | $ | 1,165,350 |  |  | $ | (120,351) |  |  | (10.3) | % |

[0000889331-20-000054:mdna:70]
[same as prior period, unchanged from 0000889331-20-000045:mdna:69]

[0000889331-20-000054:mdna:71]
Net sales increased $28.2 million, or 17.7%, in the third quarter of 2020 compared to the third quarter of 2019. The increase in net sales was primarily due to higher volume across all businesses within the Electronics segment, and favorable changes in foreign exchange rates of $1.0 million.

[0000889331-20-000054:mdna:72]
Net sales decreased $20.9 million, or 4.1%, in the first nine months of 2020 compared to the first nine months of 2019. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment and lower volume in the passenger car products business within the Automotive segment, and unfavorable changes in foreign exchange rates of $1.1 million.

[0000889331-20-000054:mdna:73]
[same as prior period, unchanged from 0000889331-20-000045:mdna:72]

[0000889331-20-000054:mdna:74]
Net sales increased $1.0 million, or 0.8%, in the third quarter of 2020 compared to the third quarter of 2019 primarily due to higher volume in the electronics products business within the Electronics segment, partially offset by lower volume in the

[0000889331-20-000054:mdna:75]
commercial vehicle business within the Automotive segment and unfavorable changes in foreign exchange rates of $0.1 million.

[0000889331-20-000054:mdna:76]
Net sales decreased $62.8 million, or 15.8%, in the first nine months of 2020 compared to the first nine months of 2019 primarily due to lower volume across all segments driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, lower volume across the Electronics segment from electronics distribution partners and end customers reducing excess inventories and production, lower volume in all businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $0.3 million.

[0000889331-20-000054:mdna:77]
[same as prior period, unchanged from 0000889331-20-000045:mdna:75]

[0000889331-20-000054:mdna:78]
Net sales increased $0.4 million, or 0.5%, in the third quarter of 2020 compared to the third quarter of 2019. The increase in net sales was primarily due to favorable changes in foreign exchange rates of $3.5 million and increased volume in auto sensor business within the Automotive segment, mostly offset by lower volume in the semiconductor business within the Electronics segment.

[0000889331-20-000054:mdna:79]
Net sales decreased $36.7 million, or 13.9%, in the first nine months of 2020 compared to the first nine months of 2019. The decrease in net sales was primarily due to lower volume in the semiconductor business within the Electronics segment, lower volume in all businesses within the Automotive segment, partially offset by favorable changes in foreign exchange rates of $0.2 million.

[0000889331-20-000054:mdna:80]
[same as prior period, unchanged from 0000889331-20-000045:mdna:78]

[0000889331-20-000054:mdna:81]
[same as prior period, unchanged from 0000889331-20-000045:mdna:79]

[0000889331-20-000054:mdna:82]
Cash and cash equivalents were $641.9 million as of September 26, 2020, an increase of $110.8 million as compared to December 28, 2019. As of September 26, 2020, $266.2 million of the Company's $641.9 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-20-000054:mdna:83]
Revolving Credit Facility/Term Loan

[0000889331-20-000054:mdna:84]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000054:mdna:85]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.

[0000889331-20-000054:mdna:86]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to coronavirus disease 2019 ("COVID-19").

[0000889331-20-000054:mdna:87]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial

[0000889331-20-000054:mdna:88]
covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $60.0 million on the amended revolving credit facility during the three months ended September 26, 2020. The balance under the facility was $180.0 million as of September 26, 2020.

[0000889331-20-000054:mdna:89]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.90% at September 26, 2020.

[0000889331-20-000054:mdna:90]
As of September 26, 2020, the Company had no amount outstanding in letters of credit and had available $245.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 26, 2020, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-20-000054:mdna:91]
[same as prior period, unchanged from 0000889331-20-000045:mdna:88]

[0000889331-20-000054:mdna:92]
[same as prior period, unchanged from 0000889331-20-000045:mdna:89]

[0000889331-20-000054:mdna:93]
[same as prior period, unchanged from 0000889331-20-000045:mdna:90]

[0000889331-20-000054:mdna:94]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000054:mdna:95]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 7, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-20-000054:mdna:96]
Debt Covenants

[0000889331-20-000054:mdna:97]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of September 26, 2020 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2020. As of September 26, 2020, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.  The ultimate magnitude of COVID-19, including the extent of its impact on our financial and operational results, which could be material, will be determined by the length of time that the pandemic continues, its effect on the demand for our products, as well as the effect of governmental regulations imposed in response to the pandemic. While we cannot at this time predict the impact of the COVID-19, it could have a material negative impact on our business, financial condition, results of operations and future cash flows which could impact the Company’s ability to comply with debt covenants in the future.

[0000889331-20-000054:mdna:98]
[same as prior period, unchanged from 0000889331-20-000045:mdna:96]

[0000889331-20-000054:mdna:99]
During the third quarter of 2020 the Company paid quarterly dividends of $11.7 million to the shareholders. On October 23, 2020, the Board of Directors of the Company declared a quarterly cash dividend of $0.48 per share, payable on December 3, 2020 to stockholders of record as of November 19, 2020. Future determinations regarding the declaration and payment of dividends will be at the discretion of our board of directors and will depend on then-existing conditions, including our results of operations, payout ratio, capital requirements, financial condition, prospects and other factors that our board of directors may deem relevant.

[0000889331-20-000054:mdna:100]
[same as prior period, unchanged from 0000889331-20-000045:mdna:98]

[0000889331-20-000054:mdna:101]
|  |  | First Nine Months |
| (in thousands) |  | 2020 |  | 2019 |
| Net cash provided by operating activities |  | $ | 164,256 |  |  | $ | 160,863 |  |
| Net cash used in investing activities |  | (41,388) |  |  | (32,960) |  |
| Net cash used in financing activities |  | (18,376) |  |  | (135,465) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 6,259 |  |  | (6,114) |  |
| Increase (decrease) in cash and cash equivalents |  | 110,751 |  |  | (13,676) |  |
| Cash and cash equivalents at beginning of period |  | 531,139 |  |  | 489,733 |  |
| Cash and cash equivalents at end of period |  | $ | 641,890 |  |  | $ | 476,057 |  |

[0000889331-20-000054:mdna:102]
[same as prior period, unchanged from 0000889331-20-000045:mdna:100]

[0000889331-20-000054:mdna:103]
[same as prior period, unchanged from 0000889331-20-000045:mdna:101]

[0000889331-20-000054:mdna:104]
Net cash provided by operating activities was $164.3 million for the nine months ended September 26, 2020, compared to $160.9 million during the nine months ended September 28, 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and favorable changes in net working capital partially offset by lower earnings largely due to the impact of COVID-19.

[0000889331-20-000054:mdna:105]
[same as prior period, unchanged from 0000889331-20-000045:mdna:103]

[0000889331-20-000054:mdna:106]
Net cash used in investing activities was $41.4 million for the nine months ended September 26, 2020 compared to $33.0 million during the nine months ended September 28, 2019. Capital expenditures were $41.5 million, representing an increase of $3.1 million compared to 2019. During the nine months ended September 28, 2019, the Company received proceeds of $6.4 million from the sale of a property within the Industrial segment.

[0000889331-20-000054:mdna:107]
[same as prior period, unchanged from 0000889331-20-000045:mdna:105]

[0000889331-20-000054:mdna:108]
Net cash used in financing activities was $18.4 million for the nine months ended September 26, 2020 compared to $135.5 million for the nine months ended September 28, 2019. During the nine months ended September 26, 2020, the company borrowed $100.0 million from its revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. On April 3, 2020, the Company amended the Credit Agreement to eliminate the $200.0 million unsecured term loan credit facility, with the remaining outstanding balance of $140.0 million repaid in full on April 3, 2020 through a new borrowing of $140.0 million under the recently amended revolving credit facility. The Company made payments of $60.0 million on the amended revolving credit facility during the third quarter of 2020.  The Company made principal payments of $5.0 million and $7.5 million on the term loan during the nine months ended September 26, 2020 and September 28, 2019, respectively. For the nine months ended September 26, 2020 and September 28, 2019, the Company repurchased 175,110 and 579,916 shares of its common stock totaling $22.9 million and $95.0 million, respectively, but made payments of $99.4 million related to settled share repurchases during the nine months ended September 28, 2019. Additionally, dividends paid increased $2.1 million from $33.0 million in the nine months ended September 28, 2019 to $35.1 million for the nine months ended September 26, 2020.

[0000889331-20-000054:mdna:109]
[same as prior period, unchanged from 0000889331-20-000045:mdna:108]

[0000889331-20-000054:mdna:110]
[same as prior period, unchanged from 0000889331-20-000045:mdna:109]

[0000889331-20-000054:mdna:111]
The Company did not repurchase shares of its common stock during the three months ended September 26, 2020, and for the three months ended September 28, 2019, the Company repurchased 311,786 shares of its common stock totaling  $49.5 million. For the nine months ended September 26, 2020 and September 28, 2019, the Company repurchased 175,110 and 579,916 shares of its common stock totaling $22.9 million and $95.0 million, respectively.

[0000889331-20-000054:mdna:112]
[same as prior period, unchanged from 0000889331-20-000045:mdna:111]

[0000889331-20-000054:mdna:113]
As of September 26, 2020, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-20-000054:mdna:114]
[same as prior period, unchanged from 0000889331-20-000045:mdna:113]

[0000889331-20-000054:mdna:115]
[same as prior period, unchanged from 0000889331-20-000045:mdna:114]

[0000889331-20-000054:mdna:116]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 28, 2019. During the nine months ended September 26, 2020, there were no significant changes in the application of critical accounting policies.
