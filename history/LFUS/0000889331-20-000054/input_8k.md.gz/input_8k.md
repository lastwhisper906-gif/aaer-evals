# LFUS 8-K — 0000889331-20-000052 filed 2020-10-28

## item codes, every 8-K on or before 2020-10-28

- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2020-10-28

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-20-000052:8k_2_02:1]
EX-99.1
2
q32020earningsreleasee.htm
EX-99.1

[0000889331-20-000052:8k_2_02:2]
Document

[0000889331-20-000052:8k_2_02:3]
Exhibit 99.1

[0000889331-20-000052:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-20-000052:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS FOR 2020

[0000889331-20-000052:8k_2_02:6]
Company performance exceeds expectations

[0000889331-20-000052:8k_2_02:7]
CHICAGO, October 28, 2020 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the third quarter ended September 26, 2020:

[0000889331-20-000052:8k_2_02:8]
•Net sales of $391.6 million were up 8% versus the prior year period, and up 7% organically; sequentially, net sales were up 27% largely due to higher than expected demand in automotive end markets, and strength in several electronics and industrial end markets

[0000889331-20-000052:8k_2_02:9]
•Segment performance versus the prior year period:

[0000889331-20-000052:8k_2_02:10]
◦Electronics sales grew 12% (up 13% organically)

[0000889331-20-000052:8k_2_02:11]
◦Automotive sales were flat (down 2% organically)

[0000889331-20-000052:8k_2_02:12]
◦Industrial sales grew 5% (down 3% organically)

[0000889331-20-000052:8k_2_02:13]
•GAAP diluted EPS was $2.25; adjusted diluted EPS was $2.16, which benefited from a lower effective tax rate versus the forecasted rate equating to approximately $0.22 in EPS

[0000889331-20-000052:8k_2_02:14]
•GAAP effective tax rate was 17.9% and the adjusted effective tax rate was 15.7%

[0000889331-20-000052:8k_2_02:15]
•Year-to-date, cash flow from operations was $164.3 million and free cash flow was $122.7 million

[0000889331-20-000052:8k_2_02:16]
“I am extremely proud of the extraordinary leadership demonstrated by our global associates and business partners amidst these challenging times,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Our commitment to operational execution enabled us to meet stronger than expected demand from our customers, driving year-over-year growth. We continued to capitalize on robust design activity with several strategic wins in high-growth industrial, electronics and transportation applications. As we near the end of 2020, we are confident the actions we have taken this year position us well for sustained profitable growth.”

[0000889331-20-000052:8k_2_02:17]
-more-

[0000889331-20-000052:8k_2_02:18]
Fourth Quarter of 2020 Outlook*

[0000889331-20-000052:8k_2_02:19]
•The company expects year-over-year sales growth of 7% to 10%, with an adjusted operating income flow-through of approximately 40%. The forecast assumes no new material disruptions from the pandemic

[0000889331-20-000052:8k_2_02:20]
*Littelfuse provides an estimate regarding operating income on a non-GAAP (adjusted) basis. GAAP items excluded may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to estimate the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-20-000052:8k_2_02:21]
Dividend

[0000889331-20-000052:8k_2_02:22]
•The company will pay a cash dividend on its common stock of $0.48 per share on December 3, 2020 to shareholders of record as of November 19, 2020

[0000889331-20-000052:8k_2_02:23]
Conference Call and Webcast Information

[0000889331-20-000052:8k_2_02:24]
Littelfuse will host a conference call today, Wednesday, October 28, 2020, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-20-000052:8k_2_02:25]
About Littelfuse

[0000889331-20-000052:8k_2_02:26]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics, and appliances. Our 11,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-20-000052:8k_2_02:27]
-more-

[0000889331-20-000052:8k_2_02:28]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. These statements may involve risks and uncertainties, including, but not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 28, 2019. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 28, 2019, under the caption "Risk Factors" in its Quarterly Report on Form 10-Q for the quarter ended June 27, 2020, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov.

[0000889331-20-000052:8k_2_02:29]
These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-20-000052:8k_2_02:30]
Non-GAAP Financial Measures

[0000889331-20-000052:8k_2_02:31]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth (decline), adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, consolidated total debt, consolidated EBITDA (as defined in the private placement senior notes), and ratio of consolidated total debt to consolidated EBITDA. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-20-000052:8k_2_02:32]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-20-000052:8k_2_02:33]
-more-

[0000889331-20-000052:8k_2_02:34]
The company believes that organic net sales growth (decline), adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that consolidated total debt, consolidated EBITDA, and ratio of consolidated total debt to consolidated EBITDA are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-20-000052:8k_2_02:35]
CONTACT: Trisha Tuntland

[0000889331-20-000052:8k_2_02:36]
Head of Investor Relations

[0000889331-20-000052:8k_2_02:37]
(773) 628-2163

[0000889331-20-000052:8k_2_02:38]
###

[0000889331-20-000052:8k_2_02:39]
LFUS-F

[0000889331-20-000052:8k_2_02:40]
LITTELFUSE, INC.

[0000889331-20-000052:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-20-000052:8k_2_02:42]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 641,890 |  |  | $ | 531,139 |  |
| Short-term investments |  | 52 |  |  | 44 |  |
| Trade receivables, less allowances of $42,737 and $42,043 at September 26, 2020 and December 28, 2019, respectively |  | 231,930 |  |  | 202,309 |  |
| Inventories |  | 243,832 |  |  | 237,507 |  |
| Prepaid income taxes and income taxes receivable |  | 1,218 |  |  | 4,831 |  |
| Prepaid expenses and other current assets |  | 30,012 |  |  | 28,564 |  |
| Total current assets |  | 1,148,934 |  |  | 1,004,394 |  |
| Net property, plant, and equipment |  | 339,870 |  |  | 344,617 |  |
| Intangible assets, net of amortization |  | 296,159 |  |  | 321,247 |  |
| Goodwill |  | 799,791 |  |  | 820,589 |  |
| Investments |  | 26,066 |  |  | 24,099 |  |
| Deferred income taxes |  | 7,173 |  |  | 8,069 |  |
| Right of use lease assets, net |  | 18,811 |  |  | 21,918 |  |
| Other assets |  | 17,566 |  |  | 14,965 |  |
| Total assets |  | $ | 2,654,370 |  |  | $ | 2,559,898 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 120,938 |  |  | $ | 117,320 |  |
| Accrued liabilities |  | 98,437 |  |  | 84,120 |  |
| Accrued income taxes |  | 15,231 |  |  | 14,122 |  |
| Current portion of long-term debt |  | — |  |  | 10,000 |  |
| Total current liabilities |  | 234,606 |  |  | 225,562 |  |
| Long-term debt, less current portion |  | 725,507 |  |  | 669,158 |  |
| Deferred income taxes |  | 46,584 |  |  | 49,763 |  |
| Accrued post-retirement benefits |  | 40,279 |  |  | 38,198 |  |
| Non-current operating lease liabilities |  | 14,193 |  |  | 17,166 |  |
| Other long-term liabilities |  | 63,639 |  |  | 64,037 |  |
| Total equity |  | 1,529,562 |  |  | 1,496,014 |  |
| Total liabilities and equity |  | $ | 2,654,370 |  |  | $ | 2,559,898 |  |

[0000889331-20-000052:8k_2_02:43]
LITTELFUSE, INC.

[0000889331-20-000052:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-20-000052:8k_2_02:45]
(Unaudited)

[0000889331-20-000052:8k_2_02:46]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
| (in thousands, except per share data) |  | September 26,2020 |  | September 28,2019 |  | September 26,2020 |  | September 28,2019 |
| Net sales |  | $ | 391,566 |  |  | $ | 361,971 |  |  | $ | 1,044,999 |  |  | $ | 1,165,350 |  |
| Cost of sales |  | 253,390 |  |  | 231,025 |  |  | 684,012 |  |  | 737,368 |  |
| Gross profit |  | 138,176 |  |  | 130,946 |  |  | 360,987 |  |  | 427,982 |  |
| Selling, general, and administrative expenses |  | 50,465 |  |  | 54,224 |  |  | 158,832 |  |  | 174,845 |  |
| Goodwill impairment charge |  | — |  |  | — |  |  | 33,841 |  |  | — |  |
| Research and development expenses |  | 13,049 |  |  | 19,728 |  |  | 41,044 |  |  | 62,595 |  |
| Amortization of intangibles |  | 10,104 |  |  | 9,827 |  |  | 29,912 |  |  | 30,068 |  |
| Total operating expenses |  | 73,618 |  |  | 83,779 |  |  | 263,629 |  |  | 267,508 |  |
| Operating income |  | 64,558 |  |  | 47,167 |  |  | 97,358 |  |  | 160,474 |  |
| Interest expense |  | 4,988 |  |  | 5,559 |  |  | 16,261 |  |  | 16,834 |  |
| Foreign exchange (gain) loss |  | (6,174) |  |  | 4,968 |  |  | (9,600) |  |  | 5,636 |  |
| Other income, net |  | (1,682) |  |  | (4,764) |  |  | (1,643) |  |  | (3,406) |  |
| Income before income taxes |  | 67,426 |  |  | 41,404 |  |  | 92,340 |  |  | 141,410 |  |
| Income taxes |  | 12,070 |  |  | 5,757 |  |  | 21,331 |  |  | 24,982 |  |
| Net income |  | $ | 55,356 |  |  | $ | 35,647 |  |  | $ | 71,009 |  |  | $ | 116,428 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.27 |  |  | $ | 1.46 |  |  | $ | 2.92 |  |  | $ | 4.72 |  |
| Diluted |  | $ | 2.25 |  |  | $ | 1.44 |  |  | $ | 2.89 |  |  | $ | 4.68 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,357 |  |  | 24,482 |  |  | 24,354 |  |  | 24,646 |  |
| Diluted |  | 24,573 |  |  | 24,684 |  |  | 24,535 |  |  | 24,894 |  |
| Comprehensive income |  | $ | 72,337 |  |  | $ | 18,621 |  |  | $ | 70,594 |  |  | $ | 101,744 |  |

[0000889331-20-000052:8k_2_02:47]
LITTELFUSE, INC.

[0000889331-20-000052:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-20-000052:8k_2_02:49]
(Unaudited)

[0000889331-20-000052:8k_2_02:50]
|  |  | Nine Months Ended |  |  |
| (in thousands) |  | September 26, 2020 |  | September 28, 2019 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 71,009 |  |  | $ | 116,428 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 113,867 |  |  | 93,511 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (29,362) |  |  | 2,781 |  |
| Inventories |  | (1,611) |  |  | 18,102 |  |
| Accounts payable |  | 6,661 |  |  | (29,453) |  |
| Accrued liabilities and income taxes |  | (2,095) |  |  | (44,241) |  |
| Prepaid expenses and other assets |  | 5,787 |  |  | 3,735 |  |
| Net cash provided by operating activities |  | 164,256 |  |  | 160,863 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (775) |  |
| Purchases of property, plant, and equipment |  | (41,536) |  |  | (38,397) |  |
| Net proceeds from sale of property, plant, and equipment |  | 148 |  |  | 6,212 |  |
| Net cash used in investing activities |  | (41,388) |  |  | (32,960) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net proceeds (payments) from credit facility |  | 35,000 |  |  | (7,500) |  |
| Purchases of common stock |  | (22,927) |  |  | (99,387) |  |
| Cash dividends paid |  | (35,100) |  |  | (32,990) |  |
| All other cash provided by financing activities |  | 4,651 |  |  | 4,412 |  |
| Net cash used in financing activities |  | (18,376) |  |  | (135,465) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 6,259 |  |  | (6,114) |  |
| Increase (decrease) in cash and cash equivalents |  | 110,751 |  |  | (13,676) |  |
| Cash and cash equivalents at beginning of period |  | 531,139 |  |  | 489,733 |  |
| Cash and cash equivalents at end of period |  | $ | 641,890 |  |  | $ | 476,057 |  |

[0000889331-20-000052:8k_2_02:51]
LITTELFUSE, INC.

[0000889331-20-000052:8k_2_02:52]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-20-000052:8k_2_02:53]
(Unaudited)

[0000889331-20-000052:8k_2_02:54]
|  |  | Third Quarter |  |  |  |  |  |  |  | Year-to-Date |  |  |  |  |  |  |
| (in thousands) |  | 2020 |  | 2019 |  |  |  | %Growth /(Decline) |  | 2020 |  | 2019 |  |  |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 255,349 |  |  | $ | 227,252 |  |  |  |  | 12.4 | % |  | $ | 692,809 |  |  | $ | 752,199 |  |  |  |  | (7.9) | % |
| Automotive |  | 104,724 |  |  | 104,681 |  |  |  |  | — | % |  | 271,493 |  |  | 326,814 |  |  |  |  | (16.9) | % |
| Industrial |  | 31,493 |  |  | 30,038 |  |  |  |  | 4.8 | % |  | 80,697 |  |  | 86,337 |  |  |  |  | (6.5) | % |
| Total net sales |  | $ | 391,566 |  |  | $ | 361,971 |  |  |  |  | 8.2 | % |  | $ | 1,044,999 |  |  | $ | 1,165,350 |  |  |  |  | (10.3) | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 45,860 |  |  | $ | 34,567 |  |  |  |  | 32.7 | % |  | $ | 110,783 |  |  | $ | 127,233 |  |  |  |  | (12.9) | % |
| Automotive |  | 15,383 |  |  | 11,437 |  |  |  |  | 34.5 | % |  | 20,642 |  |  | 34,987 |  |  |  |  | (41.0) | % |
| Industrial |  | 4,898 |  |  | 6,822 |  |  |  |  | (28.2) | % |  | 8,409 |  |  | 16,158 |  |  |  |  | (48.0) | % |
| Other(a) |  | (1,583) |  |  | (5,659) |  |  |  |  | N.M. |  | (42,476) |  |  | (17,904) |  |  |  |  | N.M. |
| Total operating income |  | $ | 64,558 |  |  | $ | 47,167 |  |  |  |  | 36.9 | % |  | $ | 97,358 |  |  | $ | 160,474 |  |  |  |  | (39.3) | % |
| Operating Margin |  | 16.5 | % |  | 13.0 | % |  |  |  |  |  | 9.3 | % |  | 13.8 | % |  |  |  |  |
| Interest expense |  | 4,988 |  |  | 5,559 |  |  |  |  |  |  | 16,261 |  |  | 16,834 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (6,174) |  |  | 4,968 |  |  |  |  |  |  | (9,600) |  |  | 5,636 |  |  |  |  |  |
| Other income, net |  | (1,682) |  |  | (4,764) |  |  |  |  |  |  | (1,643) |  |  | (3,406) |  |  |  |  |  |
| Income before income taxes |  | $ | 67,426 |  |  | $ | 41,404 |  |  |  |  | 62.8 | % |  | $ | 92,340 |  |  | $ | 141,410 |  |  |  |  | (34.7) | % |

[0000889331-20-000052:8k_2_02:55]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-20-000052:8k_2_02:56]
N.M. - Not meaningful

[0000889331-20-000052:8k_2_02:57]
|  |  | Third Quarter |  |  |  |  |  | Year-to-Date |  |  |  |  |
| (in thousands) |  | 2020 |  | 2019 |  | %Growth /(Decline) |  | 2020 |  | 2019 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 18.0 | % |  | 15.2 | % |  | 2.8 | % |  | 16.0 | % |  | 16.9 | % |  | (0.9) | % |
| Automotive |  | 14.7 | % |  | 10.9 | % |  | 3.8 | % |  | 7.6 | % |  | 10.7 | % |  | (3.1) | % |
| Industrial |  | 15.6 | % |  | 22.7 | % |  | (7.1) | % |  | 10.4 | % |  | 18.7 | % |  | (8.3) | % |

[0000889331-20-000052:8k_2_02:58]
LITTELFUSE, INC.

[0000889331-20-000052:8k_2_02:59]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-20-000052:8k_2_02:60]
(In millions of USD except per share amounts - unaudited)

[0000889331-20-000052:8k_2_02:61]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-20 |  | Q3-19 |  | YTD-20 |  | YTD-19 |
| GAAP diluted EPS |  | $ | 2.25 |  |  | $ | 1.44 |  |  | $ | 2.89 |  |  | $ | 4.68 |  |
| EPS impact of Non-GAAP adjustments (below) |  | (0.09) |  |  | 0.34 |  |  | 1.27 |  |  | 0.97 |  |
| Adjusted diluted EPS |  | $ | 2.16 |  |  | $ | 1.78 |  |  | $ | 4.16 |  |  | $ | 5.65 |  |

[0000889331-20-000052:8k_2_02:62]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q3-20 |  | Q3-19 |  | YTD-20 |  | YTD-19 |
| Acquisition-related and integration costs (a) |  | $ | 0.3 |  |  | $ | 3.2 |  |  | $ | 1.6 |  |  | $ | 6.9 |  |
| Goodwill impairment charge |  | — |  |  | — |  |  | 33.8 |  |  | — |  |
| Restructuring, impairment and other charges (b) |  | 1.3 |  |  | 2.5 |  |  | 7.1 |  |  | 11.0 |  |
| Non-GAAP adjustments to operating (loss) income |  | 1.6 |  |  | 5.7 |  |  | 42.5 |  |  | 17.9 |  |
| Other expense, net (c) |  | 0.1 |  |  | — |  |  | 2.1 |  |  | 5.8 |  |
| Non-operating foreign exchange (gain) loss |  | (6.2) |  |  | 5.0 |  |  | (9.6) |  |  | 5.6 |  |
| Non-GAAP adjustments to income before income taxes |  | (4.5) |  |  | 10.7 |  |  | 35.0 |  |  | 29.3 |  |
| Income taxes (d) |  | (2.2) |  |  | 2.3 |  |  | 3.9 |  |  | 5.1 |  |
| Non-GAAP adjustments to net income |  | $ | (2.3) |  |  | $ | 8.4 |  |  | $ | 31.1 |  |  | $ | 24.2 |  |
| Total EPS impact |  | $ | (0.09) |  |  | $ | 0.34 |  |  | $ | 1.27 |  |  | $ | 0.97 |  |

[0000889331-20-000052:8k_2_02:63]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-20 |  | Q3-19 |  | YTD-20 |  | YTD-19 |
| Net sales |  | $ | 391.6 |  |  | $ | 362.0 |  |  | $ | 1,045.0 |  |  | $ | 1,165.4 |  |
| GAAP operating income |  | 64.6 |  |  | $ | 47.2 |  |  | 97.4 |  |  | $ | 160.5 |  |
| Add back non-GAAP adjustments |  | 1.6 |  |  | 5.7 |  |  | 42.5 |  |  | 17.9 |  |
| Adjusted operating income |  | $ | 66.2 |  |  | $ | 52.9 |  |  | $ | 139.9 |  |  | $ | 178.4 |  |
| Adjusted operating margin |  | 16.9 | % |  | 14.6 | % |  | 13.4 | % |  | 15.3 | % |
| Add back amortization |  | 10.1 |  |  | 9.8 |  |  | 29.9 |  |  | 30.1 |  |
| Add back depreciation |  | 14.2 |  |  | 13.3 |  |  | 42.0 |  |  | 39.0 |  |
| Adjusted EBITDA |  | $ | 90.5 |  |  | $ | 76.0 |  |  | $ | 211.8 |  |  | $ | 247.5 |  |
| Adjusted EBITDA margin |  | 23.1 | % |  | 21.0 | % |  | 20.3 | % |  | 21.2 | % |

[0000889331-20-000052:8k_2_02:64]
| Net sales reconciliation |  | Q3-20 vs. Q3-19 |  |  |  |  |  |  |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | 12 | % |  | — | % |  | 5 | % |  | 8 | % |
| Less: |  |  |  |  |  |  |  |  |
| Transfer a product line between segments |  | (1) | % |  | — | % |  | 8 | % |  | — | % |
| FX impact |  | — | % |  | 2 | % |  | — | % |  | 1 | % |
| Organic net sales growth (decline) |  | 13 | % |  | (2) | % |  | (3) | % |  | 7 | % |

[0000889331-20-000052:8k_2_02:65]
| Net sales reconciliation |  | YTD-20 vs. YTD-19 |  |  |  |  |  |  |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales decline |  | (8) | % |  | (17) | % |  | (7) | % |  | (10) | % |
| Less: |  |  |  |  |  |  |  |  |
| Transfer a product line between segments |  | (1) | % |  | — | % |  | 3 | % |  | — | % |
| FX impact |  | — | % |  | — | % |  | (1) | % |  | — | % |
| Organic net sales decline |  | (7) | % |  | (17) | % |  | (9) | % |  | (10) | % |

[0000889331-20-000052:8k_2_02:66]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-20 |  | Q3-19 |  | YTD-20 |  | YTD-19 |
| Income taxes |  | $ | 12.1 |  |  | $ | 5.8 |  |  | $ | 21.3 |  |  | $ | 25.0 |  |
| Effective rate |  | 17.9 | % |  | 13.9 | % |  | 23.1 | % |  | 17.7 | % |
| Non-GAAP adjustments - income taxes |  | (2.2) |  |  | 2.3 |  |  | 3.9 |  |  | 5.1 |  |
| Adjusted income taxes |  | $ | 9.9 |  |  | $ | 8.1 |  |  | $ | 25.2 |  |  | $ | 30.1 |  |
| Adjusted effective rate |  | 15.7 | % |  | 15.5 | % |  | 19.8 | % |  | 17.6 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-20 |  | Q3-19 |  | YTD-20 |  | YTD-19 |
| Net cash provided by operating activities |  | $ | 63.0 |  |  | $ | 80.8 |  |  | $ | 164.3 |  |  | $ | 160.9 |  |
| Less: Purchases of property, plant and equipment |  | (12.1) |  |  | (13.1) |  |  | (41.6) |  |  | (38.4) |  |
| Free cash flow |  | $ | 50.9 |  |  | $ | 67.7 |  |  | $ | 122.7 |  |  | $ | 122.5 |  |

[0000889331-20-000052:8k_2_02:67]
| Consolidated Total Debt |  | As of September 26, 2020 |
| Consolidated Total Debt |  | $ | 725.5 |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | Twelve Months Ended September 26, 2020 |
| Net Income |  | $ | 93.7 |  |
| Interest expense |  | 21.7 |  |
| Income taxes |  | 23.1 |  |
| Depreciation |  | 55.4 |  |
| Amortization |  | 39.9 |  |
| Non-cash reductions: |  |  |
| Stock-based compensation expense |  | 17.8 |  |
| Unrealized loss on investments |  | 3.1 |  |
| Impairment charges |  | 36.1 |  |
| Other |  | (12.3) |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | $ | 278.5 |  |
| Ratio of Consolidated Total Debt to Consolidated EBITDA (as defined in Private Placement Senior Notes)* |  | 2.6x |

[0000889331-20-000052:8k_2_02:68]
* Our Private Placement Senior Notes, with maturities ranging from 2022 to 2030, contain a financial ratio covenant providing that if, as of the last day of each fiscal quarter, the ratio of Consolidated Total Debt at such time to Consolidated EBITDA for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Private Placement Senior Notes) is triggered

[0000889331-20-000052:8k_2_02:69]
(1) Represents Consolidated EBITDA as defined in our Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters

[0000889331-20-000052:8k_2_02:70]
Note: Total will not always foot due to rounding.

[0000889331-20-000052:8k_2_02:71]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-20-000052:8k_2_02:72]
(b) $0.7 million and $0.6 million and $1.8 million and $0.7 million reflected in cost of sales and SG&A, respectively for the three months ended September 26, 2020 and September 28, 2019, and $2.1 million and $5.0 million and $4.6 million and $6.4 million reflected in cost of sales and SG&A, respectively for the nine months ended September 26, 2020 and September 28, 2019.

[0000889331-20-000052:8k_2_02:73]
(c) 2020 quarter-to date amount included $0.1 million of impairment charges on certain other investments. 2020 year-to-date amount also included a $1.8 million increase in coal mining reserves and a $0.2 million charge for an asset retirement obligation related to the disposal of a business in 2019. 2019 year-to-date amounts included $2.8 million of impairment charges on certain other investments, a $2.6 million loss on the disposal of a business, and a $0.4 million gain primarily related to the final payments for the acquisition of Monolith.

[0000889331-20-000052:8k_2_02:74]
(d) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-20-000052:8k_2_02:75]
###
