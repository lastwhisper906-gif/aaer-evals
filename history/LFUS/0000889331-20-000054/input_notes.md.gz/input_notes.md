# LFUS notes — 0000889331-20-000054


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-20-000054:notes:1]
[same as prior period, unchanged from 0000889331-20-000045:notes:1]

[0000889331-20-000054:notes:2]
[same as prior period, unchanged from 0000889331-20-000045:notes:2]

[0000889331-20-000054:notes:3]
[same as prior period, unchanged from 0000889331-20-000045:notes:3]

[0000889331-20-000054:notes:4]
[same as prior period, unchanged from 0000889331-20-000045:notes:4]

[0000889331-20-000054:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2019 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-20-000054:notes:6]
[same as prior period, unchanged from 0000889331-20-000045:notes:6]

[0000889331-20-000054:notes:7]
[same as prior period, unchanged from 0000889331-20-000045:notes:7]

[0000889331-20-000054:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 26, 2020 and September 28, 2019:

[0000889331-20-000054:notes:9]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

[0000889331-20-000054:notes:10]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

[0000889331-20-000054:notes:11]
[same as prior period, unchanged from 0000889331-20-000045:notes:11]

[0000889331-20-000054:notes:12]
[same as prior period, unchanged from 0000889331-20-000045:notes:12]

[0000889331-20-000054:notes:13]
[same as prior period, unchanged from 0000889331-20-000045:notes:13]

[0000889331-20-000054:notes:14]
[same as prior period, unchanged from 0000889331-20-000045:notes:14]

[0000889331-20-000054:notes:15]
[same as prior period, unchanged from 0000889331-20-000045:notes:15]

[0000889331-20-000054:notes:16]
[same as prior period, unchanged from 0000889331-20-000045:notes:16]

[0000889331-20-000054:notes:17]
[same as prior period, unchanged from 0000889331-20-000045:notes:17]

[0000889331-20-000054:notes:18]
[same as prior period, unchanged from 0000889331-20-000045:notes:18]

[0000889331-20-000054:notes:19]
[same as prior period, unchanged from 0000889331-20-000045:notes:19]

[0000889331-20-000054:notes:20]
[same as prior period, unchanged from 0000889331-20-000045:notes:20]

[0000889331-20-000054:notes:21]
[same as prior period, unchanged from 0000889331-20-000045:notes:21]

[0000889331-20-000054:notes:22]
Recently Adopted Accounting Standards

[0000889331-20-000054:notes:23]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments." The standard modifies the measurement approach for credit losses on financial instruments, including trade receivables, from an incurred loss method to a current expected credit loss method ("CECL").  The standard requires the measurement of expected credit losses to be based on relevant information, including historical experiences, current conditions and a forecast that is supportable.  The Company adopted the new standard on December 29, 2019.  The adoption of the standard did not have a material effect on our Condensed Consolidated Financial Statements.

[0000889331-20-000054:notes:24]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement."  ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies other disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018-13 did not have a material impact on our Condensed Consolidated Financial Statements.

[0000889331-20-000054:notes:25]
In August 2018, the FASB issued ASU No. 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic: 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force)." ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The Company adopted the new standard on December 29, 2019.  The adoption of ASU 2018-15 did not have a material impact on our Condensed Consolidated Financial Statements.

[0000889331-20-000054:notes:26]
In March 2020, the FASB issued ASU 2020-04 Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting.” This ASU provides optional expedient and exceptions for applying generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by reference rate reform if certain criteria are met. The objective of this is to provide optional guidance for a limited period of time to ease the potential burden in accounting for (or recognizing the effects of) reference rate reform on financial reporting due to the cessation of the London Interbank Offered Rate (LIBOR). The amendments in this update are effective for all entities as of March 12, 2020 through December 31, 2022. The Company does not expect a material effect from the adoption of this guidance on its Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-20-000054:notes:27]
[same as prior period, unchanged from 0000889331-20-000045:notes:27]

[0000889331-20-000054:notes:28]
The components of inventories at September 26, 2020 and December 28, 2019 are as follows:

[0000889331-20-000054:notes:29]
| (in thousands) |  | September 26, 2020 |  | December 28, 2019 |
| Raw materials |  | $ | 81,849 |  |  | $ | 76,732 |  |
| Work in process |  | 90,494 |  |  | 84,561 |  |
| Finished goods |  | 105,425 |  |  | 110,388 |  |
| Inventory Reserves |  | (33,936) |  |  | (34,174) |  |
| Total |  | $ | 243,832 |  |  | $ | 237,507 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-20-000054:notes:30]
[same as prior period, unchanged from 0000889331-20-000045:notes:30]

[0000889331-20-000054:notes:31]
The components of net property, plant, and equipment at September 26, 2020 and December 28, 2019 are as follows:

[0000889331-20-000054:notes:32]
| (in thousands) |  | September 26, 2020 |  | December 28, 2019 |
| Land |  | $ | 23,438 |  |  | $ | 24,758 |  |
| Building |  | 122,914 |  |  | 108,501 |  |
| Equipment |  | 656,681 |  |  | 631,273 |  |
| Accumulated depreciation and amortization |  | (463,163) |  |  | (419,915) |  |
| Total |  | $ | 339,870 |  |  | $ | 344,617 |  |

[0000889331-20-000054:notes:33]
The Company recorded depreciation expense of $14.2 million and $13.3 million for the three months ended September 26, 2020 and September 28, 2019, respectively, and $42.0 million and $39.0 million for nine months ended September 26, 2020 and September 28, 2019, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-20-000054:notes:34]
[same as prior period, unchanged from 0000889331-20-000045:notes:34]

[0000889331-20-000054:notes:35]
The amounts for goodwill and changes in the carrying value by segment for the nine months ended September 26, 2020 are as follows:

[0000889331-20-000054:notes:36]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 28, 2019 |  | $ | 650,796 |  |  | $ | 131,321 |  |  | $ | 38,472 |  |  | $ | 820,589 |  |
| Impairments |  | — |  |  | (33,841) |  |  | — |  |  | (33,841) |  |
| Currency translation |  | 11,122 |  |  | 1,988 |  |  | (67) |  |  | 13,043 |  |
| As of September 26, 2020 |  | $ | 661,918 |  |  | $ | 99,468 |  |  | $ | 38,405 |  |  | $ | 799,791 |  |

[0000889331-20-000054:notes:37]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition, during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling their existing program. The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of September 26, 2020, the automotive sensors reporting unit had $9.4 million of remaining goodwill.

[0000889331-20-000054:notes:38]
The components of other intangible assets as of September 26, 2020 and December 28, 2019 are as follows:

[0000889331-20-000054:notes:39]
|  |  |  | As of September 26, 2020 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 9,913 |  |  | $ | 1,895 |  |  | $ | 8,018 |  |
| Patents, licenses and software |  |  | 133,737 |  |  | $ | 88,142 |  |  | $ | 45,595 |  |
| Distribution network |  |  | 43,547 |  |  | 38,107 |  |  | 5,440 |  |
| Customer relationships, trademarks, and tradenames |  |  | 365,300 |  |  | 128,194 |  |  | 237,106 |  |
| Total |  |  | $ | 552,497 |  |  | $ | 256,338 |  |  | $ | 296,159 |  |

[0000889331-20-000054:notes:40]
|  | As of December 28, 2019 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 9,649 |  |  | $ | 1,730 |  |  | $ | 7,919 |  |
| Patents, licenses and software | 131,164 |  |  | 78,828 |  |  | 52,336 |  |
| Distribution network | 43,239 |  |  | 36,163 |  |  | 7,076 |  |
| Customer relationships, trademarks, and tradenames | 360,534 |  |  | 106,618 |  |  | 253,916 |  |
| Total | $ | 544,586 |  |  | $ | 223,339 |  |  | $ | 321,247 |  |

[0000889331-20-000054:notes:41]
During the three months ended September 26, 2020 and September 28, 2019, the Company recorded amortization expense of $10.1 million and $9.8 million, respectively. During the nine months ended September 26, 2020 and September 28, 2019, the Company recorded amortization expense of $29.9 million and $30.1 million, respectively.

[0000889331-20-000054:notes:42]
The Company recognized a $0.3 million non-cash impairment charge in the first quarter of 2020 on a certain patent triggered by the Company’s announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-20-000054:notes:43]
Estimated annual amortization expense related to intangible assets with definite lives as of September 26, 2020 is as follows:

[0000889331-20-000054:notes:44]
| (in thousands) | Amount |
| 2020 | $ | 41,742 |  |
| 2021 | 38,258 |  |
| 2022 | 37,274 |  |
| 2023 | 32,492 |  |
| 2024 | 29,695 |  |
| 2025 and thereafter | 146,610 |  |
| Total | $ | 326,071 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-20-000054:notes:45]
[same as prior period, unchanged from 0000889331-20-000045:notes:45]

[0000889331-20-000054:notes:46]
The components of accrued liabilities as of September 26, 2020 and December 28, 2019 are as follows:

[0000889331-20-000054:notes:47]
| (in thousands) |  | September 26, 2020 |  | December 28, 2019 |
| Employee-related liabilities |  | $ | 49,805 |  |  | $ | 40,774 |  |
| Operating lease liability |  | 6,866 |  |  | 7,259 |  |
| Interest |  | 2,747 |  |  | 5,058 |  |
| Professional services |  | 2,869 |  |  | 3,986 |  |
| Restructuring liability |  | 4,542 |  |  | 2,679 |  |
| Other non-income taxes |  | 3,509 |  |  | 1,940 |  |
| Other |  | 28,099 |  |  | 22,424 |  |
| Total |  | $ | 98,437 |  |  | $ | 84,120 |  |

[0000889331-20-000054:notes:48]
[same as prior period, unchanged from 0000889331-20-000045:notes:48]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-20-000054:notes:49]
Restructuring, Impairment and Other Charges
The Company recorded restructuring, impairment and other charges for the three and nine months ended September 26, 2020 and September 28, 2019 as follows:

[0000889331-20-000054:notes:50]
|  | Three months ended September 26, 2020 |  | Nine months ended September 26, 2020 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 388 |  |  | $ | 162 |  |  | $ | 648 |  |  | $ | 1,198 |  |  | $ | 2,125 |  |  | $ | 770 |  |  | $ | 1,719 |  |  | $ | 4,614 |  |
| Other restructuring charges | — |  |  | — |  |  | 79 |  |  | 79 |  |  | — |  |  | 108 |  |  | 104 |  |  | 212 |  |
| Total restructuring charges | 388 |  |  | 162 |  |  | 727 |  |  | 1,277 |  |  | 2,125 |  |  | 878 |  |  | 1,823 |  |  | 4,826 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33,841 |  |  | 2,237 |  |  | 36,078 |  |
| Total | $ | 388 |  |  | $ | 162 |  |  | $ | 727 |  |  | $ | 1,277 |  |  | $ | 2,125 |  |  | $ | 34,719 |  |  | $ | 4,060 |  |  | $ | 40,904 |  |

[0000889331-20-000054:notes:51]
|  | Three months ended September 28, 2019 |  | Nine months ended September 28, 2019 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 655 |  |  | $ | 109 |  |  | $ | 49 |  |  | $ | 813 |  |  | $ | 4,153 |  |  | $ | 3,955 |  |  | $ | 770 |  |  | $ | 8,878 |  |
| Other restructuring charges | 128 |  |  | 1,150 |  |  | 124 |  |  | 1,402 |  |  | 141 |  |  | 1,240 |  |  | 374 |  |  | 1,755 |  |
| Total restructuring charges | 783 |  |  | 1,259 |  |  | 173 |  |  | 2,215 |  |  | 4,294 |  |  | 5,195 |  |  | 1,144 |  |  | 10,633 |  |
| Impairment | — |  |  | 322 |  |  | — |  |  | 322 |  |  | — |  |  | 322 |  |  | — |  |  | 322 |  |
| Total | $ | 783 |  |  | $ | 1,581 |  |  | $ | 173 |  |  | $ | 2,537 |  |  | $ | 4,294 |  |  | $ | 5,517 |  |  | $ | 1,144 |  |  | $ | 10,955 |  |

[0000889331-20-000054:notes:52]
[same as prior period, unchanged from 0000889331-20-000045:notes:52]

[0000889331-20-000054:notes:53]
For the three and nine months ended September 26, 2020, the Company recorded total restructuring charges of $1.3 million and $4.8 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the previously announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $36.1 million of impairment charges for the nine months ended September 26, 2020, which included a $33.8 million goodwill impairment charge associated with the automotive sensors reporting unit within the Automotive segment in the second quarter of 2020 and a $2.2 million impairment charge related to the land and building associated with the Company’s previously announced consolidation of a manufacturing facility within the Industrial segment in the first quarter of 2020. The impairment charges of the land and building were included in selling, general and administrative expenses. See Note 4, Goodwill and Other Intangible Assets for further discussion regarding the goodwill impairment charge.

[0000889331-20-000054:notes:54]
[same as prior period, unchanged from 0000889331-20-000045:notes:55]

[0000889331-20-000054:notes:55]
For the three and nine months ended September 28, 2019, the Company recorded total restructuring charges of $2.2 million, and $10.6 million, respectively, for employee termination costs and other restructuring charges. These charges primarily related to reorganization of operations and selling, general and administrative functions as well as integration of IXYS within the Electronics segment and the reorganization of operations in the commercial vehicle products and automotive sensors businesses within the Automotive segment.

[0000889331-20-000054:notes:56]
The restructuring liability as of September 26, 2020 and December 28, 2019 are $4.5 million and $2.7 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by September 2021.


## us-gaap:DebtDisclosureTextBlock

[0000889331-20-000054:notes:57]
Debt

[0000889331-20-000054:notes:58]
The carrying amounts of debt at September 26, 2020 and December 28, 2019 are as follows:

[0000889331-20-000054:notes:59]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 180,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,417 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,295) |  |  | (3,669) |  |
| Total debt |  | 725,507 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 725,507 |  |  | $ | 669,158 |  |

[0000889331-20-000054:notes:60]
Revolving Credit Facility / Term Loan

[0000889331-20-000054:notes:61]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000054:notes:62]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size

[0000889331-20-000054:notes:63]
of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.

[0000889331-20-000054:notes:64]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to coronavirus disease 2019 ("COVID-19").

[0000889331-20-000054:notes:65]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $60.0 million on the amended revolving credit facility during the three months ended September 26, 2020. The balance under the facility was $180.0 million as of September 26, 2020.

[0000889331-20-000054:notes:66]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.90% at September 26, 2020.

[0000889331-20-000054:notes:67]
As of September 26, 2020, the Company had no amount outstanding in letters of credit and had available $245.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 26, 2020, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-20-000054:notes:68]
Senior Notes

[0000889331-20-000054:notes:69]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-20-000054:notes:70]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000054:notes:71]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-20-000054:notes:72]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-20-000054:notes:73]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 26, 2020, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-20-000054:notes:74]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-20-000054:notes:75]
Interest paid on all Company debt was $6.4 million for the three months ended September 26, 2020 and September 28, 2019, and $17.2 million and $17.9 million for the nine months ended September 26, 2020 and September 28, 2019, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-20-000054:notes:76]
[same as prior period, unchanged from 0000889331-20-000045:notes:75]

[0000889331-20-000054:notes:77]
[same as prior period, unchanged from 0000889331-20-000045:notes:76]

[0000889331-20-000054:notes:78]
[same as prior period, unchanged from 0000889331-20-000045:notes:77]

[0000889331-20-000054:notes:79]
[same as prior period, unchanged from 0000889331-20-000045:notes:78]

[0000889331-20-000054:notes:80]
[same as prior period, unchanged from 0000889331-20-000045:notes:79]

[0000889331-20-000054:notes:81]
[same as prior period, unchanged from 0000889331-20-000045:notes:80]

[0000889331-20-000054:notes:82]
[same as prior period, unchanged from 0000889331-20-000045:notes:81]

[0000889331-20-000054:notes:83]
[same as prior period, unchanged from 0000889331-20-000045:notes:82]

[0000889331-20-000054:notes:84]
[same as prior period, unchanged from 0000889331-20-000045:notes:83]

[0000889331-20-000054:notes:85]
[same as prior period, unchanged from 0000889331-20-000045:notes:84]

[0000889331-20-000054:notes:86]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the three months ended September 26, 2020, the Company recorded impairment charges of $0.1 million and during the nine months ended September 28, 2019, the Company recorded impairment charges of $2.8 million in Other income, net in the Condensed Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value. As of September 26, 2020 and December 28, 2019, the balances of these investments were $0.5 million and $0.4 million, respectively. The fair value of these investments are measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-20-000054:notes:87]
[same as prior period, unchanged from 0000889331-20-000045:notes:86]

[0000889331-20-000054:notes:88]
[same as prior period, unchanged from 0000889331-20-000045:notes:87]

[0000889331-20-000054:notes:89]
There were no changes during the quarter ended September 26, 2020 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. On October 30, 2019, the Company entered a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Chinese renminbi and U.S. dollar.  The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly basis. The notional value of the forward contracts at December 28, 2019 was $16.0 million and expired on May 5, 2020.  On March 23, 2020, the Company unwound the foreign currency exchange forward contract entered on October 30, 2019 and recognized a gain of $0.2 million within Other income, net during the nine months ended September 26, 2020. The fair value of the foreign currency forward contract was valued using market exchange rates and classified as a Level 2 input under the fair value hierarchy.

[0000889331-20-000054:notes:90]
As of September 26, 2020 and December 28, 2019, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-20-000054:notes:91]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 26, 2020:

[0000889331-20-000054:notes:92]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 92,472 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,472 |  |
| Investments in equity securities |  | 15,042 |  |  | — |  |  | — |  |  | 15,042 |  |
| Mutual funds |  | 11,692 |  |  | — |  |  | — |  |  | 11,692 |  |

[0000889331-20-000054:notes:93]
[same as prior period, unchanged from 0000889331-20-000045:notes:92]

[0000889331-20-000054:notes:94]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 118,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,999 |  |
| Investments in equity securities |  | 12,969 |  |  | — |  |  | — |  |  | 12,969 |  |
| Mutual funds |  | 10,464 |  |  | — |  |  | — |  |  | 10,464 |  |

[0000889331-20-000054:notes:95]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at September 26, 2020 and December 28, 2019, as the rates on these borrowings are variable in nature.

[0000889331-20-000054:notes:96]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of September 26, 2020 and December 28, 2019 were as follows:

[0000889331-20-000054:notes:97]
|  |  | September 26, 2020 |  | December 28, 2019 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 136,417 |  |  | $ | 136,686 |  |  | $ | 129,808 |  |  | $ | 131,710 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 114,947 |  |  | 105,400 |  |  | 110,336 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,460 |  |  | 25,000 |  |  | 25,054 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 109,367 |  |  | 100,000 |  |  | 102,548 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 53,323 |  |  | 50,000 |  |  | 50,775 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 138,340 |  |  | 125,000 |  |  | 127,701 |  |

[0000889331-20-000054:notes:98]
[same as prior period, unchanged from 0000889331-20-000045:notes:97]

[0000889331-20-000054:notes:99]
The second quarter of 2020 goodwill impairment charge was the result of measuring a reporting unit at fair value on a nonrecurring basis as shown below:

[0000889331-20-000054:notes:100]
|  |  |  |  | Nine Months Ended September 26, 2020 |  | September 26, 2020 |
| (in thousands) |  |  |  |  |  | Impairment Charge |  | Estimated Fair Value Measurement (Level 3) |  | Carrying Value |
| Goodwill |  |  |  |  |  | $33,841 |  | $8,953 |  | $ | 9,449 |  |

[0000889331-20-000054:notes:101]
See Note 4, Goodwill and Other Intangible Assets for further discussion regarding goodwill impairment charges.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-20-000054:notes:102]
[same as prior period, unchanged from 0000889331-20-000045:notes:100]

[0000889331-20-000054:notes:103]
[same as prior period, unchanged from 0000889331-20-000045:notes:101]

[0000889331-20-000054:notes:104]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income,, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended September 26, 2020 and September 28, 2019 were as follows:

[0000889331-20-000054:notes:105]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 615 |  |  | $ | 509 |  |  | $ | 1,825 |  |  | $ | 1,523 |  |
| Interest cost |  | 511 |  |  | 777 |  |  | 1,655 |  |  | 2,374 |  |
| Expected return on plan assets |  | (422) |  |  | (773) |  |  | (1,551) |  |  | (2,384) |  |
| Amortization of prior service and net actuarial loss |  | 279 |  |  | 60 |  |  | 688 |  |  | 184 |  |
| Net periodic benefit cost |  | $ | 983 |  |  | $ | 573 |  |  | $ | 2,617 |  |  | $ | 1,697 |  |

[0000889331-20-000054:notes:106]
[same as prior period, unchanged from 0000889331-20-000045:notes:104]

[0000889331-20-000054:notes:107]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded $0.5 million and $0.2 million expense for the three months ended September 26, 2020 and September 28, 2019,

[0000889331-20-000054:notes:108]
respectively, and $1.5 million and $0.6 million expense for the nine months ended September 26, 2020 and September 28, 2019, respectively, in Cost of Sales and Other income, net within the Condensed Consolidated Statements of Net Income. For three and nine months ended September 26, 2020, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.2 million and $0.5 million.

[0000889331-20-000054:notes:109]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries, who have been receiving pension payments. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $36 million, representing approximately 30% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge in the second half of 2021 currently estimated between $18 million and $22 million, reflecting the accelerated recognition of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses. Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million (£10.9 million) to both the net pension liability and unamortized actuarial loss within other comprehensive income (loss) during the second quarter. Additionally, the Company made a cash contribution of $10.4 million (£8.4 million) under this agreement during the second quarter.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-20-000054:notes:110]
Other Comprehensive Income
Changes in other comprehensive income (loss) by component were as follows:

[0000889331-20-000054:notes:111]
| (in thousands) |  | Three Months EndedSeptember 26, 2020 |  | Three Months EndedSeptember 28, 2019 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 273 |  |  | $ | (290) |  |  | $ | 563 |  |  | $ | 155 |  |  | $ | 18 |  |  | $ | 137 |  |
| Foreign currency translation adjustments |  | 16,418 |  |  | — |  |  | 16,418 |  |  | (17,163) |  |  | — |  |  | (17,163) |  |
| Total change in other comprehensive income (loss) |  | $ | 16,691 |  |  | $ | (290) |  |  | $ | 16,981 |  |  | $ | (17,008) |  |  | $ | 18 |  |  | $ | (17,026) |  |

[0000889331-20-000054:notes:112]
| (in thousands) |  | Nine Months Ended September 26, 2020 |  | Nine Months Ended September 28, 2019 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | (12,270) |  |  | $ | (2,555) |  |  | $ | (9,715) |  |  | $ | 278 |  |  | $ | 29 |  |  | $ | 249 |  |
| Foreign currency translation adjustments |  | 9,300 |  |  | — |  |  | 9,300 |  |  | (14,933) |  |  | — |  |  | (14,933) |  |
| Total change in other comprehensive loss |  | $ | (2,970) |  |  | $ | (2,555) |  |  | $ | (415) |  |  | $ | (14,655) |  |  | $ | 29 |  |  | $ | (14,684) |  |

[0000889331-20-000054:notes:113]
Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million to unamortized actuarial loss within other comprehensive income (loss). See Note 9, Benefits Plans for further discussion.

[0000889331-20-000054:notes:114]
The following tables set forth the changes in accumulated other comprehensive income (loss) by component for the nine months ended September 26, 2020 and September 28, 2019:

[0000889331-20-000054:notes:115]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  |  |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensive (loss) income |
| Balance at December 28, 2019 |  | $ | (18,046) |  |  |  |  | $ | (88,777) |  |  | $ | (106,823) |  |
| Activity in the period |  | (9,715) |  |  |  |  | 9,300 |  |  | (415) |  |
| Balance at September 26, 2020 |  | $ | (27,761) |  |  |  |  | $ | (79,477) |  |  | $ | (107,238) |  |

[0000889331-20-000054:notes:116]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  |  |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensive (loss) income |
| Balance at December 29, 2018 |  | $ | (9,959) |  |  |  |  | $ | (87,965) |  |  | $ | (97,924) |  |
| Activity in the period |  | 249 |  |  |  |  | (14,933) |  |  | (14,684) |  |
| Balance at September 28, 2019 |  | $ | (9,710) |  |  |  |  | $ | (102,898) |  |  | $ | (112,608) |  |

[0000889331-20-000054:notes:117]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for the three and nine months ended September 26, 2020 and September 28, 2019 were as follows:

[0000889331-20-000054:notes:118]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
| (in thousands) |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |  |  |  |  |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 452 |  |  | $ | 60 |  |  | $ | 1,226 |  |  | $ | 184 |  |  |  |  |  |

[0000889331-20-000054:notes:119]
The Company recognizes the amortization of prior service costs in Other income, net within the Condensed Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-20-000054:notes:120]
Income Taxes

[0000889331-20-000054:notes:121]
The effective tax rate for the three and nine months ended September 26, 2020 was 17.9% and 23.1% respectively, compared to the effective tax rate for the three and nine months ended September 28, 2019 of 13.9% and 17.7%. The effective tax rates for the 2020 periods are higher than the effective tax rates for the comparable 2019 periods, primarily due to the impact of the goodwill impairment charge of  $33.8 million that was recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit in the annual estimated effective tax rate, as well as a reduction in the forecasted income earned in lower tax jurisdictions in 2020 driven by the uncertainty resulting from the impact of COVID-19.

[0000889331-20-000054:notes:122]
The effective tax rate for the first nine months of 2020 is higher than the applicable U.S. statutory tax rate primarily due to the impact of the goodwill impairment charge of $33.8 million that was recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit in the annual estimated effective tax rate, as well as the forecasted impact of non-U.S. losses and expenses with no tax benefit and the U.S. global intangible low-taxed income tax provisions (in the 2019 comparable period the impact of these items was more than offset by the impact of income earned in lower tax jurisdictions), offset in part by the impact of income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-20-000054:notes:123]
[same as prior period, unchanged from 0000889331-20-000045:notes:118]

[0000889331-20-000054:notes:124]
[same as prior period, unchanged from 0000889331-20-000045:notes:119]

[0000889331-20-000054:notes:125]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 55,356 |  |  | $ | 35,647 |  |  | $ | 71,009 |  |  | $ | 116,428 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,357 |  |  | 24,482 |  |  | 24,354 |  |  | 24,646 |  |
| Effect of dilutive securities |  | 216 |  |  | 202 |  |  | 181 |  |  | 248 |  |
| Diluted |  | 24,573 |  |  | 24,684 |  |  | 24,535 |  |  | 24,894 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.27 |  |  | $ | 1.46 |  |  | $ | 2.92 |  |  | $ | 4.72 |  |
| Diluted earnings per share |  | $ | 2.25 |  |  | $ | 1.44 |  |  | $ | 2.89 |  |  | $ | 4.68 |  |

[0000889331-20-000054:notes:126]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 290,262 and 205,516 for the three months ended September 26, 2020 and September 28, 2019, respectively, and 194,857 and 147,090 for the nine months ended September 26, 2020 and September 28, 2019, respectively.

[0000889331-20-000054:notes:127]
[same as prior period, unchanged from 0000889331-20-000045:notes:122]

[0000889331-20-000054:notes:128]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized to a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program") to replace its previous expired 2018 program. On April 23, 2020, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. The Company has suspended share repurchases for the near-term due to the uncertainty of the impact and duration of COVID-19 and to focus on other capital allocation priorities.
The Company did not repurchase any shares of its common stock for the three months ended September 26, 2020. During the three months ended September 28, 2019, the Company repurchased 311,786 shares of its common stock totaling $49.5 million. For the nine months ended September 26, 2020 and September 28, 2019, the Company repurchased 175,110 and 579,916 shares of its common stock totaling $22.9 million and $95.0 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-20-000054:notes:129]
Related Party Transactions

[0000889331-20-000054:notes:130]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-20-000054:notes:131]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-20-000054:notes:132]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-20-000054:notes:133]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-20-000054:notes:134]
|  |  | For the Three Months Ended September 26, 2020 |  | For the Three Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 2.4 |  |  | 0.8 |  | 0.1 |  | 1.7 |  |
|  |  | For the Nine Months Ended September 26, 2020 |  | For the Nine Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.1 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | — |  | 5.8 |  |  | 2.4 |  | 0.3 |  | 5.5 |  |
|  |  | September 26, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |

[0000889331-20-000054:notes:135]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.5 million as of September 26, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

[0000889331-20-000054:notes:136]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income, net in the Condensed Consolidated Statements of Net Income. The operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-20-000054:notes:137]
[same as prior period, unchanged from 0000889331-20-000045:notes:132]

[0000889331-20-000054:notes:138]
[same as prior period, unchanged from 0000889331-20-000045:notes:133]

[0000889331-20-000054:notes:139]
[same as prior period, unchanged from 0000889331-20-000045:notes:134]

[0000889331-20-000054:notes:140]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, metal-oxide-semiconductor field effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial and

[0000889331-20-000054:notes:141]
automotive electronics, electric vehicle and related infrastructure, data and telecommunications, medical devices, alternative energy, consumer electronics and white goods.

[0000889331-20-000054:notes:142]
[same as prior period, unchanged from 0000889331-20-000045:notes:136]

[0000889331-20-000054:notes:143]
[same as prior period, unchanged from 0000889331-20-000045:notes:137]

[0000889331-20-000054:notes:144]
[same as prior period, unchanged from 0000889331-20-000045:notes:138]

[0000889331-20-000054:notes:145]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 255,349 |  |  | $ | 227,252 |  |  | $ | 692,809 |  |  | $ | 752,199 |  |
| Automotive |  | 104,724 |  |  | 104,681 |  |  | 271,493 |  |  | 326,814 |  |
| Industrial |  | 31,493 |  |  | 30,038 |  |  | 80,697 |  |  | 86,337 |  |
| Total net sales |  | $ | 391,566 |  |  | $ | 361,971 |  |  | $ | 1,044,999 |  |  | $ | 1,165,350 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,819 |  |  | $ | 14,960 |  |  | $ | 46,967 |  |  | 45,031 |  |
| Automotive |  | 7,370 |  |  | 7,067 |  |  | 21,628 |  |  | 20,848 |  |
| Industrial |  | 1,140 |  |  | 1,061 |  |  | 3,270 |  |  | 3,177 |  |
| Total depreciation and amortization |  | $ | 24,329 |  |  | $ | 23,088 |  |  | $ | 71,865 |  |  | $ | 69,056 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 45,860 |  |  | $ | 34,567 |  |  | $ | 110,783 |  |  | $ | 127,233 |  |
| Automotive |  | 15,383 |  |  | 11,437 |  |  | 20,642 |  |  | 34,987 |  |
| Industrial |  | 4,898 |  |  | 6,822 |  |  | 8,409 |  |  | 16,158 |  |
| Other(a) |  | (1,583) |  |  | (5,659) |  |  | (42,476) |  |  | (17,904) |  |
| Total operating income |  | 64,558 |  |  | 47,167 |  |  | 97,358 |  |  | 160,474 |  |
| Interest expense |  | 4,988 |  |  | 5,559 |  |  | 16,261 |  |  | 16,834 |  |
| Foreign exchange (gain) loss |  | (6,174) |  |  | 4,968 |  |  | (9,600) |  |  | 5,636 |  |
| Other income, net |  | (1,682) |  |  | (4,764) |  |  | (1,643) |  |  | (3,406) |  |
| Income before income taxes |  | $ | 67,426 |  |  | $ | 41,404 |  |  | $ | 92,340 |  |  | $ | 141,410 |  |

[0000889331-20-000054:notes:146]
(a) Included in “Other” Operating income for the third quarter of 2020 is $0.3 million ($1.6 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there was $1.3 million ($40.9 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs of $1.2 million ($4.6 million year-to-date), and other restructuring charges of $0.1 million ($0.2 million year-to-date), the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, and impairment charges of $2.2 million recorded in the first quarter associated with the

[0000889331-20-000054:notes:147]
announced consolidation of a manufacturing facility within the Industrial segment. See Note 4, Goodwill and Other Intangible Assets and Note 6, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-20-000054:notes:148]
Included in "Other" Operating income for the third quarter of 2019 is $3.2 million ($6.9 million year-to-date) of acquisition integration charges primarily related to the IXYS acquisition. In addition, there were $2.5 million ($11.0 million year-to-date) of restructuring charges primarily related to employee termination costs.

[0000889331-20-000054:notes:149]
[same as prior period, unchanged from 0000889331-20-000045:notes:142]

[0000889331-20-000054:notes:150]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 106,121 |  |  | $ | 105,292 |  |  | $ | 285,901 |  |  | $ | 340,811 |  |
| China |  | 126,506 |  |  | 101,960 |  |  | 314,547 |  |  | 316,553 |  |
| Other countries(a) |  | 158,939 |  |  | 154,719 |  |  | 444,551 |  |  | 507,986 |  |
| Total net sales |  | $ | 391,566 |  |  | $ | 361,971 |  |  | $ | 1,044,999 |  |  | $ | 1,165,350 |  |

[0000889331-20-000054:notes:151]
[same as prior period, unchanged from 0000889331-20-000045:notes:144]

[0000889331-20-000054:notes:152]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 52,009 |  |  | $ | 58,081 |  |
| China |  | 82,956 |  |  | 88,306 |  |
| Mexico |  | 68,346 |  |  | 73,096 |  |
| Germany |  | 37,611 |  |  | 36,025 |  |
| Philippines |  | 64,171 |  |  | 51,738 |  |
| Other countries(a) |  | 34,777 |  |  | 37,371 |  |
| Total long-lived assets |  | $ | 339,870 |  |  | $ | 344,617 |  |

[0000889331-20-000054:notes:153]
[same as prior period, unchanged from 0000889331-20-000045:notes:146]

[0000889331-20-000054:notes:154]
|  |  | Nine Months Ended |
| (in thousands) |  | September 26, 2020 |  | September 28, 2019 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 2,712 |  |  | $ | 4,972 |  |
| China |  | 6,414 |  |  | 12,418 |  |
| Mexico |  | 7,291 |  |  | 12,650 |  |
| Germany |  | 3,793 |  |  | 4,335 |  |
| Philippines |  | 15,331 |  |  | 9,546 |  |
| Other countries(a) |  | 1,152 |  |  | 3,454 |  |
| Total additions to long-lived assets |  | $ | 36,693 |  |  | $ | 47,375 |  |

[0000889331-20-000054:notes:155]
[same as prior period, unchanged from 0000889331-20-000045:notes:148]
