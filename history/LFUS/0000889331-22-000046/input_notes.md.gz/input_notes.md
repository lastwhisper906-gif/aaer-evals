# LFUS notes — 0000889331-22-000046


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-22-000046:notes:1]
[same as prior period, unchanged from 0000889331-22-000040:notes:1]

[0000889331-22-000046:notes:2]
[same as prior period, unchanged from 0000889331-22-000040:notes:2]

[0000889331-22-000046:notes:3]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with approximately 19,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-22-000046:notes:4]
[same as prior period, unchanged from 0000889331-22-000040:notes:4]

[0000889331-22-000046:notes:5]
[same as prior period, unchanged from 0000889331-22-000040:notes:5]

[0000889331-22-000046:notes:6]
[same as prior period, unchanged from 0000889331-22-000040:notes:6]

[0000889331-22-000046:notes:7]
[same as prior period, unchanged from 0000889331-22-000040:notes:7]

[0000889331-22-000046:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended October 1, 2022 and September 25, 2021:

[0000889331-22-000046:notes:9]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  | — |  |  | — |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |

[0000889331-22-000046:notes:10]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  |  |  |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

[0000889331-22-000046:notes:11]
[same as prior period, unchanged from 0000889331-22-000040:notes:11]

[0000889331-22-000046:notes:12]
[same as prior period, unchanged from 0000889331-22-000040:notes:12]

[0000889331-22-000046:notes:13]
[same as prior period, unchanged from 0000889331-22-000040:notes:13]

[0000889331-22-000046:notes:14]
[same as prior period, unchanged from 0000889331-22-000040:notes:14]

[0000889331-22-000046:notes:15]
[same as prior period, unchanged from 0000889331-22-000040:notes:15]

[0000889331-22-000046:notes:16]
[same as prior period, unchanged from 0000889331-22-000040:notes:16]

[0000889331-22-000046:notes:17]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference

[0000889331-22-000046:notes:18]
between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-22-000046:notes:19]
[same as prior period, unchanged from 0000889331-22-000040:notes:19]

[0000889331-22-000046:notes:20]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-22-000046:notes:21]
[same as prior period, unchanged from 0000889331-22-000040:notes:21]

[0000889331-22-000046:notes:22]
[same as prior period, unchanged from 0000889331-22-000040:notes:22]

[0000889331-22-000046:notes:23]
[same as prior period, unchanged from 0000889331-22-000040:notes:23]

[0000889331-22-000046:notes:24]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at October 1, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-22-000046:notes:25]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Cash and cash equivalents |  | $ | 474,003 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 824 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,428 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 476,255 |  |  | $ | 482,836 |  |

[0000889331-22-000046:notes:26]
Recently Adopted Accounting Standards

[0000889331-22-000046:notes:27]
In November 2021, the Financial Accounting Standards Board ("FASB") issued ASU No. 2021-10, "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance". The standard, requires annual disclosures about transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy: 1) Information about the nature of the transactions and the related accounting policy used to account for the transactions; 2) The line items on the balance sheet and income statement that are affected by the transactions, and the amounts applicable to each financial statement line item; 3) Significant terms and conditions of the transactions, including commitments and contingencies. The guidance is effective for fiscal years beginning after December 15, 2021 with early adoption permitted. The adoption of ASU 2021-10 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

[0000889331-22-000046:notes:28]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The adoption of ASU 2021-08 did not have a material impact on the Company's Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-22-000046:notes:29]
[same as prior period, unchanged from 0000889331-22-000040:notes:29]

[0000889331-22-000046:notes:30]
[same as prior period, unchanged from 0000889331-22-000040:notes:30]

[0000889331-22-000046:notes:31]
C&K Switches

[0000889331-22-000046:notes:32]
On July 19, 2022, the Company completed the previously announced acquisition of C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and

[0000889331-22-000046:notes:33]
interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment.

[0000889331-22-000046:notes:34]
The acquisition was funded through a combination of cash on hand and debt. The total purchase consideration of $523.0 million, net of cash acquired, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-22-000046:notes:35]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the C&K acquisition:

[0000889331-22-000046:notes:36]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 523,014 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 26,231 |  |
| Inventories | 42,968 |  |
| Other current assets | 2,932 |  |
| Property, plant, and equipment | 32,559 |  |
| Intangible assets | 254,700 |  |
| Goodwill | 278,016 |  |
| Other non-current assets | 14,797 |  |
| Current liabilities | (50,871) |  |
| Long- term debt | (14,889) |  |
| Other non-current liabilities | (63,429) |  |
|  | $ | 523,014 |  |

[0000889331-22-000046:notes:37]
All C&K goodwill, other assets and liabilities were recorded in the Electronics segment and are reflected in the Americas, Europe and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining C&K’s products and technology with the Company’s existing Electronics products portfolio. Goodwill resulting from the C&K acquisition is not expected to be deductible for tax purposes.

[0000889331-22-000046:notes:38]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three months ended October 1, 2022 are net sales of approximately $37.9 million, and a loss before income taxes of $6.1 million, since the July 19, 2022 acquisition of C&K.

[0000889331-22-000046:notes:39]
As required by purchase accounting rules, the Company recorded a $10.8 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was partially amortized as a non-cash charge to cost of sales during the three months ended October 1, 2022, as the acquired inventory was sold, and reflected as other non-segment costs. The Company recognized a non-cash charge of $6.8 million to cost of sales during the three months ended October 1, 2022.

[0000889331-22-000046:notes:40]
During the three and nine months ended October 1, 2022, the Company incurred approximately $3.5 million and $9.2 million, respectively, of legal and professional fees related to C&K acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-22-000046:notes:41]
[same as prior period, unchanged from 0000889331-22-000040:notes:31]

[0000889331-22-000046:notes:42]
On April 12, 2022, the Company acquired Embed Ltd. (“Embed”).  Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets. The business is included in the commercial vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand. The total purchase consideration was $9.2 million, net of cash.

[0000889331-22-000046:notes:43]
[same as prior period, unchanged from 0000889331-22-000040:notes:34]

[0000889331-22-000046:notes:44]
[same as prior period, unchanged from 0000889331-22-000040:notes:35]

[0000889331-22-000046:notes:45]
[same as prior period, unchanged from 0000889331-22-000040:notes:36]

[0000889331-22-000046:notes:46]
[same as prior period, unchanged from 0000889331-22-000040:notes:37]

[0000889331-22-000046:notes:47]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 314,094 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 26,232 |  |
| Inventories | 56,479 |  |
| Other current assets | 3,454 |  |
| Property, plant, and equipment | 56,128 |  |
| Intangible assets | 126,390 |  |
| Goodwill | 97,975 |  |
| Other non-current assets | 4,007 |  |
| Current liabilities | (21,522) |  |
| Other non-current liabilities | (35,049) |  |
|  | $ | 314,094 |  |

[0000889331-22-000046:notes:48]
[same as prior period, unchanged from 0000889331-22-000040:notes:39]

[0000889331-22-000046:notes:49]
During the nine months ended October 1, 2022, the Company paid $0.5 million related to the final working capital adjustment and made measurement period adjustments to reduce the fair value of property, plant and equipment of $8.2 million, inventories of $0.8 million, and an increase in net accounts receivable of $0.6 million and intangible assets attributable to customer relationships of $0.5 million. As a result of these adjustments along with a corresponding reduction of deferred tax liabilities of $2.5 million, goodwill was increased by $5.9 million.

[0000889331-22-000046:notes:50]
As required by purchase accounting rules, the Company recorded a $6.4 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of sales during the fourth quarter of 2021 and first quarter of 2022, as the acquired inventory was sold, and reflected as other non-segment costs. The Company recognized a non-cash charge of $4.8 million to cost of sales during the nine months ended October 1, 2022.

[0000889331-22-000046:notes:51]
[same as prior period, unchanged from 0000889331-22-000040:notes:42]

[0000889331-22-000046:notes:52]
[same as prior period, unchanged from 0000889331-22-000040:notes:43]

[0000889331-22-000046:notes:53]
The total purchase consideration of $108.5 million, net of cash, cash equivalents, and restricted cash has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. As of October 1, 2022, the Company had restricted cash of $0.8 million in an escrow account for general indemnification purposes.

[0000889331-22-000046:notes:54]
[same as prior period, unchanged from 0000889331-22-000040:notes:45]

[0000889331-22-000046:notes:55]
[same as prior period, unchanged from 0000889331-22-000040:notes:46]

[0000889331-22-000046:notes:56]
[same as prior period, unchanged from 0000889331-22-000040:notes:47]

[0000889331-22-000046:notes:57]
The Company recorded a $6.8 million step-up of inventory to its fair value as of the acquisition date. The step-up was amortized as a non-cash charge to cost of sales during the first and second quarters of 2021, as the acquired inventory was sold, and is reflected as other non-segment costs. During the three and nine months ended September 25, 2021, the Company recognized a charge of $3.3 million and 6.8 million, respectively, for the amortization of this fair value inventory step-up.

[0000889331-22-000046:notes:58]
During the nine months ended September 25, 2021, the Company incurred approximately $0.8 million of legal and professional fees related to Hartland acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-22-000046:notes:59]
[same as prior period, unchanged from 0000889331-22-000040:notes:50]

[0000889331-22-000046:notes:60]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company, C&K as though the acquisition had occurred as of December 27, 2020, and Hartland and Carling as though the acquisitions had occurred as of December 29, 2019. The Company has not included pro forma results of operations for Embed as its operations were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the C&K acquisition occurred as of December 27, 2020 and had the Hartland and Carling acquisitions occurred as of December 29, 2019 or of future consolidated operating results.

[0000889331-22-000046:notes:61]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands, except per share amounts) |  | October 1, 2022 |  | September 25, 2021 |  | October 1, 2022 |  | September 25, 2021 |
| Net sales |  | $ | 663,741 |  |  | $ | 638,583 |  |  | $ | 2,025,881 |  |  | $ | 1,823,333 |  |
| Income before income taxes |  | 106,333 |  |  | 112,325 |  |  | 375,735 |  |  | 274,406 |  |
| Net income |  | 82,619 |  |  | 89,491 |  |  | 303,341 |  |  | 220,048 |  |
| Net income per share — basic |  | 3.34 |  |  | 3.63 |  |  | 12.27 |  |  | 8.95 |  |
| Net income per share — diluted |  | 3.31 |  |  | 3.59 |  |  | 12.14 |  |  | 8.84 |  |

[0000889331-22-000046:notes:62]
[same as prior period, unchanged from 0000889331-22-000040:notes:53]

[0000889331-22-000046:notes:63]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  | September 25, 2021 |  | October 1, 2022 |  | September 25, 2021 |
| Amortization (a) |  | $ | (85) |  |  | $ | (4,775) |  |  | $ | (4,646) |  |  | $ | (14,620) |  |
| Depreciation |  | 451 |  |  | 697 |  |  | 1,979 |  |  | 1,902 |  |
| Transaction costs (b) |  | 3,548 |  |  | (2,096) |  |  | 9,218 |  |  | (6,931) |  |
| Amortization of inventory step-up (c) |  | 6,765 |  |  | — |  |  | 11,534 |  |  | (4,016) |  |
| Interest expense (d) |  | 497 |  |  | 432 |  |  | 815 |  |  | 2,328 |  |
| Income tax (expense) benefit of above items |  | (2,794) |  |  | 1,412 |  |  | (4,582) |  |  | 5,456 |  |

[0000889331-22-000046:notes:64]
(a)The amortization adjustment for the three and nine months ended October 1, 2022 and September 25, 2021 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-22-000046:notes:65]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three and nine months ended October 1, 2022 and September 25, 2021, and recognition of those fees during the three and nine months ended September 25, 2021.

[0000889331-22-000046:notes:66]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the three and nine months ended October 1, 2022, and the recognition of the amortization during the nine months ended September 25, 2021. The inventory step-up was amortized over four months as the inventory was sold.

[0000889331-22-000046:notes:67]
(d)The interest expense adjustment reflects incremental interest expense related to the financing of the C&K acquisition.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-22-000046:notes:68]
[same as prior period, unchanged from 0000889331-22-000040:notes:58]

[0000889331-22-000046:notes:69]
The components of inventories at October 1, 2022 and January 1, 2022 are as follows:

[0000889331-22-000046:notes:70]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Raw materials |  | $ | 225,987 |  |  | $ | 168,409 |  |
| Work in process |  | 130,943 |  |  | 117,506 |  |
| Finished goods |  | 220,344 |  |  | 195,656 |  |
| Inventory reserves |  | (41,248) |  |  | (35,900) |  |
| Total |  | $ | 536,026 |  |  | $ | 445,671 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-22-000046:notes:71]
Property, Plant, and Equipment 
The components of net property, plant, and equipment at October 1, 2022 and January 1, 2022 are as follows:

[0000889331-22-000046:notes:72]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Land and land improvements |  | $ | 21,122 |  |  | $ | 23,470 |  |
| Building and building improvements |  | 182,312 |  |  | 151,297 |  |
| Machinery and equipment |  | 775,532 |  |  | 779,559 |  |
| Accumulated depreciation |  | (520,732) |  |  | (516,437) |  |
| Total |  | $ | 458,234 |  |  | $ | 437,889 |  |

[0000889331-22-000046:notes:73]
The Company recorded depreciation expense of $17.0 million and $14.2 million for the three months ended October 1, 2022 and September 25, 2021, respectively, and $48.3 million and $41.4 million for the nine months ended October 1, 2022 and September 25, 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-22-000046:notes:74]
[same as prior period, unchanged from 0000889331-22-000040:notes:65]

[0000889331-22-000046:notes:75]
Changes in the carrying value of goodwill by segment for the nine months ended October 1, 2022 are as follows:

[0000889331-22-000046:notes:76]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net book value of goodwill as of January 1, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of January 1, 2022 |  | $ | 660,245 |  |  | $ | 228,555 |  |  | $ | 86,232 |  |  | $ | 975,032 |  |
| Accumulated impairment losses as of January 1, 2022 |  | — |  |  | (36,177) |  |  | (9,065) |  |  | (45,242) |  |
| Total |  | 660,245 |  |  | 192,378 |  |  | 77,167 |  |  | 929,790 |  |
| Changes during 2022 |  |  |  |  |  |  |  |  |
| Additions(a) |  | 278,016 |  |  | 15,174 |  |  | — |  |  | 293,190 |  |
| Currency translation |  | (42,086) |  |  | (11,440) |  |  | (996) |  |  | (54,522) |  |
| Net book value of goodwill as of October 1, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of October 1, 2022 |  | 896,175 |  |  | 227,927 |  |  | 84,616 |  |  | 1,208,718 |  |
| Accumulated impairment losses as of October 1, 2022 |  | — |  |  | (31,815) |  |  | $ | (8,445) |  |  | (40,260) |  |
| Total |  | $ | 896,175 |  |  | $ | 196,112 |  |  | $ | 76,171 |  |  | $ | 1,168,458 |  |

[0000889331-22-000046:notes:77]
(a) The additions resulted from the acquisitions of C&K, Embed and Carling.

[0000889331-22-000046:notes:78]
The components of other intangible assets as of October 1, 2022 and January 1, 2022 are as follows:

[0000889331-22-000046:notes:79]
|  |  |  | As of October 1, 2022 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 17,459 |  |  | $ | 2,081 |  |  | $ | 15,378 |  |
| Patents, licenses and software |  |  | 260,478 |  |  | 134,234 |  |  | 126,244 |  |
| Distribution network |  |  | 41,250 |  |  | 39,989 |  |  | 1,261 |  |
| Customer relationships, trademarks, and tradenames |  |  | 614,571 |  |  | 152,144 |  |  | 462,427 |  |
| Total |  |  | $ | 933,758 |  |  | $ | 328,448 |  |  | $ | 605,310 |  |

[0000889331-22-000046:notes:80]
[same as prior period, unchanged from 0000889331-22-000040:notes:71]

[0000889331-22-000046:notes:81]
During the three months ended October 1, 2022 and September 25, 2021, the Company recorded amortization expense of $15.6 million and $10.4 million, respectively. During the nine months ended October 1, 2022 and September 25, 2021, the Company recorded amortization expense of $39.9 million and $31.6 million, respectively.

[0000889331-22-000046:notes:82]
During the three months ended October 1, 2022, the Company recorded additions to intangible assets of $254.7 million, related to the C&K acquisition, the components of which were as follows:

[0000889331-22-000046:notes:83]
| (in thousands) | Weighted Average Useful Life |  | Amount |
| Patents, licenses and software | 12 |  | $ | 55,700 |  |
| Customer relationships, trademarks, and tradenames | 17 |  | 199,000 |  |
| Total |  |  | $ | 254,700 |  |

[0000889331-22-000046:notes:84]
Estimated annual amortization expense related to intangible assets with definite lives as of October 1, 2022 is as follows:

[0000889331-22-000046:notes:85]
| (in thousands) | Amount |
| 2022 | $ | 55,735 |  |
| 2023 | 59,823 |  |
| 2024 | 56,539 |  |
| 2025 | 56,201 |  |
| 2026 | 49,944 |  |
| 2027 and thereafter | 366,951 |  |
| Total | $ | 645,193 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-22-000046:notes:86]
[same as prior period, unchanged from 0000889331-22-000040:notes:75]

[0000889331-22-000046:notes:87]
The components of accrued liabilities as of October 1, 2022 and January 1, 2022 are as follows:

[0000889331-22-000046:notes:88]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Employee-related liabilities |  | $ | 92,177 |  |  | $ | 92,018 |  |
| Operating lease liability |  | 11,880 |  |  | 9,018 |  |
| Professional services |  | 11,475 |  |  | 4,299 |  |
| Other non-income taxes |  | 7,709 |  |  | 4,280 |  |
| Restructuring liability |  | 3,556 |  |  | 2,944 |  |
| Interest |  | 3,408 |  |  | 4,402 |  |
| Current post-retirement benefits liability |  | 1,606 |  |  | 1,248 |  |
| Deferred revenue |  | 1,129 |  |  | 1,105 |  |
| Other |  | 44,187 |  |  | 40,375 |  |
| Total |  | $ | 177,127 |  |  | $ | 159,689 |  |

[0000889331-22-000046:notes:89]
[same as prior period, unchanged from 0000889331-22-000040:notes:78]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-22-000046:notes:90]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment and other charges for the three and nine months ended October 1, 2022 and September 25, 2021 as follows:

[0000889331-22-000046:notes:91]
|  | Three months ended October 1, 2022 |  | Nine months ended October 1, 2022 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,401 |  |  | $ | 1,574 |  |  | $ | — |  |  | $ | 2,975 |  |  | $ | 1,807 |  |  | $ | 1,997 |  |  | $ | — |  |  | $ | 3,804 |  |
| Other restructuring charges | 73 |  |  | 365 |  |  | — |  |  | 438 |  |  | 76 |  |  | 385 |  |  | — |  |  | 461 |  |
| Total restructuring charges | 1,474 |  |  | 1,939 |  |  | — |  |  | 3,413 |  |  | 1,883 |  |  | 2,382 |  |  | — |  |  | 4,265 |  |
| Total | $ | 1,474 |  |  | $ | 1,939 |  |  | $ | — |  |  | $ | 3,413 |  |  | $ | 1,883 |  |  | $ | 2,382 |  |  | $ | — |  |  | $ | 4,265 |  |

[0000889331-22-000046:notes:92]
|  | Three months ended September 25, 2021 |  | Nine months ended September 25, 2021 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 542 |  |  | $ | — |  |  | $ | 133 |  |  | $ | 675 |  |  | $ | 1,094 |  |  | $ | 416 |  |  | $ | 302 |  |  | $ | 1,812 |  |
| Other restructuring charges | — |  |  | 97 |  |  | — |  |  | 97 |  |  | — |  |  | 186 |  |  | — |  |  | 186 |  |
| Total restructuring charges | 542 |  |  | 97 |  |  | 133 |  |  | 772 |  |  | 1,094 |  |  | 602 |  |  | 302 |  |  | 1,998 |  |
| Total | $ | 542 |  |  | $ | 97 |  |  | $ | 133 |  |  | $ | 772 |  |  | $ | 1,094 |  |  | $ | 602 |  |  | $ | 302 |  |  | $ | 1,998 |  |

[0000889331-22-000046:notes:93]
[same as prior period, unchanged from 0000889331-22-000040:notes:82]

[0000889331-22-000046:notes:94]
For the three and nine months ended October 1, 2022, the Company recorded total restructuring charges of $3.4 million and $4.3 million, respectively, primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions within the passenger vehicle and automotive sensor businesses in the Transportation segment and the reorganization of selling and administrative functions due to the C&K acquisition within the Electronics segment.

[0000889331-22-000046:notes:95]
[same as prior period, unchanged from 0000889331-22-000040:notes:84]

[0000889331-22-000046:notes:96]
For the three and nine months ended September 25, 2021, the Company recorded total restructuring charges of $0.8 million and $2.0 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Electronic and Transportation segments.

[0000889331-22-000046:notes:97]
The restructuring liability as of October 1, 2022 and January 1, 2022 is $3.6 million and $2.9 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in fiscal year 2022.


## us-gaap:DebtDisclosureTextBlock

[0000889331-22-000046:notes:98]
Debt

[0000889331-22-000046:notes:99]
The carrying amounts of debt at October 1, 2022 and January 1, 2022 are as follows:

[0000889331-22-000046:notes:100]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 298,125 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 114,958 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 93,342 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | — |  |
| Other |  | 9,376 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,971) |  |  | (3,087) |  |
| Total debt |  | 985,830 |  |  | 636,897 |  |
| Less: Current maturities |  | (10,220) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 975,610 |  |  | $ | 611,897 |  |

[0000889331-22-000046:notes:101]
Revolving Credit Facility and Term Loan

[0000889331-22-000046:notes:102]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-22-000046:notes:103]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-22-000046:notes:104]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended October 1, 2022, the Company paid  $1.9 million of term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $298.1 million, respectively, as of October 1, 2022.

[0000889331-22-000046:notes:105]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-22-000046:notes:106]
As of October 1, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 4.13%.

[0000889331-22-000046:notes:107]
As of October 1, 2022, the Company had no outstanding in letters of credit under the Credit Facility and had available $600.0 million of borrowing capacity under the revolving Credit Facility. As of October 1, 2022, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-22-000046:notes:108]
Debt Issuance Costs

[0000889331-22-000046:notes:109]
During three and nine months ended October 1, 2022, the Company paid debt issuance costs of $0.4 million and  $2.6 million in connection with the new amended Credit Agreement on June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new amended Credit Agreement.

[0000889331-22-000046:notes:110]
Senior Notes

[0000889331-22-000046:notes:111]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-22-000046:notes:112]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the nine months ended October 1, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

[0000889331-22-000046:notes:113]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-22-000046:notes:114]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-22-000046:notes:115]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2032.

[0000889331-22-000046:notes:116]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-22-000046:notes:117]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At October 1, 2022, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-22-000046:notes:118]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
Interest paid on all Company debt was $8.5 million and $6.1 million for the three months ended October 1, 2022 and September 25, 2021, respectively, and $16.9 million and $14.8 million for the nine months ended October 1, 2022 and September 25, 2021, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-22-000046:notes:119]
[same as prior period, unchanged from 0000889331-22-000040:notes:109]

[0000889331-22-000046:notes:120]
[same as prior period, unchanged from 0000889331-22-000040:notes:110]

[0000889331-22-000046:notes:121]
[same as prior period, unchanged from 0000889331-22-000040:notes:111]

[0000889331-22-000046:notes:122]
[same as prior period, unchanged from 0000889331-22-000040:notes:112]

[0000889331-22-000046:notes:123]
Level 3—Valuations based upon one or more significant unobservable inputs

[0000889331-22-000046:notes:124]
.

[0000889331-22-000046:notes:125]
There were no transfers in or out of Level 1, Level 2 and Level 3 during the period.

[0000889331-22-000046:notes:126]
[same as prior period, unchanged from 0000889331-22-000040:notes:114]

[0000889331-22-000046:notes:127]
[same as prior period, unchanged from 0000889331-22-000040:notes:115]

[0000889331-22-000046:notes:128]
[same as prior period, unchanged from 0000889331-22-000040:notes:116]

[0000889331-22-000046:notes:129]
[same as prior period, unchanged from 0000889331-22-000040:notes:117]

[0000889331-22-000046:notes:130]
[same as prior period, unchanged from 0000889331-22-000040:notes:118]

[0000889331-22-000046:notes:131]
Derivatives Designated as Hedging Instruments

[0000889331-22-000046:notes:132]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive (loss) income until the underlying transactions are recognized in earnings. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by market observable data.

[0000889331-22-000046:notes:133]
[same as prior period, unchanged from 0000889331-22-000040:notes:121]

[0000889331-22-000046:notes:134]
Derivatives Not Designated as Hedging Instruments

[0000889331-22-000046:notes:135]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at July 14, 2023 was €117.0 million and expires on December 7, 2023. The foreign currency contract was not designated as a hedge instrument and is marked to market on a monthly basis. As a result, changes in fair value are reported in Foreign exchange loss in the Consolidated Statements of Operations. The fair value of the foreign currency forward contract was valued using market exchange rates by a third party and classified as a Level 2 input under the fair value hierarchy.

[0000889331-22-000046:notes:136]
As of October 1, 2022, the fair values of our derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-22-000046:notes:137]
| (in thousands) | Consolidated Balance Sheet Classification |  | October 1, 2022 |  |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 2,726 |  |  |  |
|  | Other long-term assets |  | $ | 6,574 |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |
| Foreign exchange forward contract | Other long-term liabilities |  | $ | 3,179 |  |  |  |

[0000889331-22-000046:notes:138]
The pre-tax losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Operations for the three and nine months ended October 1, 2022 were as follows:

[0000889331-22-000046:notes:139]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | Classification of Loss Recognized in theCondensed Consolidated Statements of Operations |  | October 1, 2022 |  |  |  | October 1, 2022 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense, net |  | $ | 314 |  |  |  |  | $ | 335 |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  | Foreign exchange loss |  | $ | 3,209 |  |  |  |  | $ | 3,209 |  |  |  |

[0000889331-22-000046:notes:140]
The pre-tax gain recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and nine months ended October 1, 2022 was as follows:

[0000889331-22-000046:notes:141]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  |  |  | October 1, 2022 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | (10,012) |  |  |  |  | $ | (9,300) |  |  |  |

[0000889331-22-000046:notes:142]
The pre-tax gain of $2.7 million from accumulated other comprehensive (loss) to earnings is expected to be recognized  during the next twelve months.

[0000889331-22-000046:notes:143]
[same as prior period, unchanged from 0000889331-22-000040:notes:129]

[0000889331-22-000046:notes:144]
[same as prior period, unchanged from 0000889331-22-000040:notes:130]

[0000889331-22-000046:notes:145]
There were no changes during the quarter ended October 1, 2022 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of October 1, 2022 and January 1, 2022, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-22-000046:notes:146]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of October 1, 2022:

[0000889331-22-000046:notes:147]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 83,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 83,012 |  |
| Investments in equity securities |  | 10,123 |  |  | — |  |  | — |  |  | 10,123 |  |
| Mutual funds |  | 13,037 |  |  | — |  |  | — |  |  | 13,037 |  |
| Total |  | $ | 106,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 106,172 |  |

[0000889331-22-000046:notes:148]
[same as prior period, unchanged from 0000889331-22-000040:notes:134]

[0000889331-22-000046:notes:149]
[same as prior period, unchanged from 0000889331-22-000040:notes:135]

[0000889331-22-000046:notes:150]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s Credit Facilities’ fair values approximate book value at October 1, 2022 and January 1, 2022, as the rates on these borrowings are variable in nature.

[0000889331-22-000046:notes:151]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of October 1, 2022 and January 1, 2022 were as follows:

[0000889331-22-000046:notes:152]
|  |  | October 1, 2022 |  | January 1, 2022 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 114,958 |  |  | $ | 111,435 |  |  | $ | 132,444 |  |  | $ | 134,119 |  |
| Euro Senior Notes, Series B due 2028 |  | 93,342 |  |  | 80,581 |  |  | 107,540 |  |  | 110,837 |  |
| USD Senior Notes, Series A due 2022 |  | — |  |  | — |  |  | 25,000 |  |  | 25,055 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 93,233 |  |  | 100,000 |  |  | 104,828 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 47,905 |  |  | 50,000 |  |  | 51,720 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 111,309 |  |  | 125,000 |  |  | 131,837 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 89,598 |  |  | — |  |  | — |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-22-000046:notes:153]
[same as prior period, unchanged from 0000889331-22-000040:notes:139]

[0000889331-22-000046:notes:154]
[same as prior period, unchanged from 0000889331-22-000040:notes:140]

[0000889331-22-000046:notes:155]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other (income) expense, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended October 1, 2022 and September 25, 2021 were as follows:

[0000889331-22-000046:notes:156]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  | September 25, 2021 |  | October 1, 2022 |  | September 25, 2021 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 725 |  |  | $ | 684 |  |  | $ | 2,243 |  |  | $ | 2,086 |  |
| Interest cost |  | 607 |  |  | 434 |  |  | 1,879 |  |  | 1,317 |  |
| Expected return on plan assets |  | (361) |  |  | (361) |  |  | (1,144) |  |  | (1,099) |  |
| Amortization of prior service and net actuarial loss |  | 92 |  |  | 327 |  |  | 289 |  |  | 992 |  |
| Net periodic benefit cost |  | $ | 1,063 |  |  | $ | 1,084 |  |  | $ | 3,267 |  |  | $ | 3,296 |  |

[0000889331-22-000046:notes:157]
The Company expects to make approximately $2.6 million of contributions to the plans and pay $1.8 million of benefits directly in 2022.
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.5 million and $0.6 million for the three months ended October 1, 2022 and September 25, 2021, respectively, and $1.5 million and $1.6 million for the nine months ended October 1, 2022 and September 25, 2021, respectively, in Cost of Sales and Other (income) expense, net within the Condensed Consolidated Statements of Net Income. The pre-tax amounts recognized in other comprehensive loss (income) as components of net periodic benefit costs for these plans were $0.1 million and $0.2 million for the three months ended October 1, 2022 and September 25, 2021, respectively, and $0.3 million and $0.5 million for the nine months ended October 1, 2022 and September 25, 2021, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-22-000046:notes:158]
Other Comprehensive (Loss) IncomeChanges in other comprehensive (loss) income by component were as follows:

[0000889331-22-000046:notes:159]
| (in thousands) |  | Three Months EndedOctober 1, 2022 |  | Three Months EndedSeptember 25, 2021 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 673 |  |  | $ | 74 |  |  | $ | 599 |  |  | $ | 601 |  |  | $ | 114 |  |  | $ | 487 |  |
| Cash flow hedge |  | 10,012 |  |  | 2,403 |  |  | 7,609 |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustments (1) |  | (37,289) |  |  | (893) |  |  | (36,396) |  |  | (5,441) |  |  | — |  |  | (5,441) |  |
| Total change in other comprehensive (loss) income |  | $ | (26,604) |  |  | $ | 1,584 |  |  | $ | (28,188) |  |  | $ | (4,840) |  |  | $ | 114 |  |  | $ | (4,954) |  |
| (in thousands) |  | Nine Months EndedOctober 1, 2022 |  | Nine Months EndedSeptember 25, 2021 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 1,718 |  |  | $ | 170 |  |  | $ | 1,548 |  |  | 1,479 |  |  | 209 |  |  | $ | 1,270 |  |
| Cash flow hedge |  | 9,300 |  |  | 2,232 |  |  | 7,068 |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustments (1) |  | (72,671) |  |  | (2,315) |  |  | (70,356) |  |  | $ | (5,641) |  |  | $ | — |  |  | $ | (5,641) |  |
| Total change in other comprehensive (loss) income |  | $ | (61,653) |  |  | $ | 87 |  |  | $ | (61,740) |  |  | $ | (4,162) |  |  | $ | 209 |  |  | $ | (4,371) |  |

[0000889331-22-000046:notes:160]
[same as prior period, unchanged from 0000889331-22-000040:notes:146]

[0000889331-22-000046:notes:161]
The following tables set forth the changes in accumulated other comprehensive (loss) income by component for the nine months ended October 1, 2022 and September 25, 2021:

[0000889331-22-000046:notes:162]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at January 1, 2022 |  | $ | (11,928) |  |  | $ | — |  |  | $ | (61,535) |  |  | $ | (73,463) |  |
| Activity in the period |  | 1,548 |  |  | 7,068 |  |  | (70,356) |  |  | (61,740) |  |
| Balance at October 1, 2022 |  | $ | (10,380) |  |  | $ | 7,068 |  |  | $ | (131,891) |  |  | $ | (135,203) |  |

[0000889331-22-000046:notes:163]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at December 26, 2020 |  | $ | (34,141) |  |  |  |  | $ | (57,016) |  |  | $ | (91,157) |  |
| Activity in the period |  | 1,270 |  |  |  |  | (5,641) |  |  | (4,371) |  |
| Balance at September 25, 2021 |  | $ | (32,871) |  |  |  |  | $ | (62,657) |  |  | $ | (95,528) |  |

[0000889331-22-000046:notes:164]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three and nine months ended October 1, 2022 and September 25, 2021 were as follows:

[0000889331-22-000046:notes:165]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  | September 25, 2021 |  | October 1, 2022 |  | September 25, 2021 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 193 |  |  | $ | 501 |  |  | $ | 588 |  |  | $ | 1,514 |  |

[0000889331-22-000046:notes:166]
The Company recognizes the amortization of prior service costs in Other (income) expense, net within the Condensed Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-22-000046:notes:167]
Income Taxes
The effective tax rate for the three and nine months ended October 1, 2022 was 21.4% and 17.6%, respectively, compared to the effective tax rate for the three and nine months ended September 25, 2021 of 19.0% and 17.6%, respectively. The effective tax rate for the third quarter of 2022 is higher than the effective tax rate for the comparable 2021 period, primarily due to higher foreign exchange losses with no related tax benefit in the 2022 period, as compared to the comparable 2021 period.

[0000889331-22-000046:notes:168]
The effective tax rate for the first nine months of the 2022 period is lower than the applicable U.S. statutory tax rate due to a one-time deduction that resulted from the dissolution of one of the Company’s affiliates, as well as the forecasted impact of income earned in lower tax jurisdictions. The effective tax rate for the comparable 2021 period is lower than the applicable U.S. statutory tax rate primarily due to the forecasted impact of income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-22-000046:notes:169]
[same as prior period, unchanged from 0000889331-22-000040:notes:154]

[0000889331-22-000046:notes:170]
[same as prior period, unchanged from 0000889331-22-000040:notes:155]

[0000889331-22-000046:notes:171]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | October 1, 2022 |  | September 25, 2021 |  | October 1, 2022 |  | September 25, 2021 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 75,468 |  |  | $ | 92,054 |  |  | $ | 280,002 |  |  | $ | 231,862 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,755 |  |  | 24,622 |  |  | 24,726 |  |  | 24,582 |  |
| Effect of dilutive securities |  | 233 |  |  | 304 |  |  | 260 |  |  | 322 |  |
| Diluted |  | 24,988 |  |  | 24,926 |  |  | 24,986 |  |  | 24,904 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 3.05 |  |  | $ | 3.74 |  |  | $ | 11.32 |  |  | $ | 9.43 |  |
| Diluted earnings per share |  | $ | 3.02 |  |  | $ | 3.69 |  |  | $ | 11.21 |  |  | $ | 9.31 |  |

[0000889331-22-000046:notes:172]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 92,052 and 57,936 for the three months ended October 1, 2022 and September 25, 2021, respectively, and 84,027 and 32,773 for the nine months ended October 1, 2022 and September 25, 2021, respectively.

[0000889331-22-000046:notes:173]
[same as prior period, unchanged from 0000889331-22-000040:notes:158]

[0000889331-22-000046:notes:174]
[same as prior period, unchanged from 0000889331-22-000040:notes:159]

[0000889331-22-000046:notes:175]
The Company did not repurchase any shares of its common stock for the three and nine months ended October 1, 2022, and September 25, 2021.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-22-000046:notes:176]
Related Party Transactions

[0000889331-22-000046:notes:177]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-22-000046:notes:178]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-22-000046:notes:179]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-22-000046:notes:180]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-22-000046:notes:181]
|  |  | Three Months Ended October 1, 2022 |  | Three Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | — |  | $ | 0.1 |  | $ | 2.9 |  |  | $ | 0.8 |  | $ | 0.1 |  | $ | 3.1 |  |
|  |  | For the Nine Months Ended October 1, 2022 |  | For the Nine Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.3 |  | 8.8 |  |  | 2.6 |  | 0.3 |  | 8.9 |  |
|  |  | October 1, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.7 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-22-000046:notes:182]
[same as prior period, unchanged from 0000889331-22-000040:notes:167]

[0000889331-22-000046:notes:183]
[same as prior period, unchanged from 0000889331-22-000040:notes:168]

[0000889331-22-000046:notes:184]
[same as prior period, unchanged from 0000889331-22-000040:notes:169]

[0000889331-22-000046:notes:185]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related infrastructure, aerospace, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-22-000046:notes:186]
•Transportation Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicle, heavy-duty truck, off-road vehicle, material handling, agricultural, construction and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and

[0000889331-22-000046:notes:187]
units used in applications serving a number of end markets, including heavy-duty truck, construction, agriculture, material handling and marine.

[0000889331-22-000046:notes:188]
[same as prior period, unchanged from 0000889331-22-000040:notes:172]

[0000889331-22-000046:notes:189]
[same as prior period, unchanged from 0000889331-22-000040:notes:173]

[0000889331-22-000046:notes:190]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  | September 25, 2021 |  | October 1, 2022 |  | September 25, 2021 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 397,629 |  |  | $ | 347,240 |  |  | $ | 1,121,626 |  |  | $ | 959,122 |  |
| Transportation |  | 181,735 |  |  | 124,415 |  |  | 548,266 |  |  | 386,262 |  |
| Industrial |  | 79,516 |  |  | 67,926 |  |  | 230,754 |  |  | 181,479 |  |
| Total net sales |  | $ | 658,880 |  |  | $ | 539,581 |  |  | $ | 1,900,646 |  |  | $ | 1,526,863 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 19,080 |  |  | $ | 15,503 |  |  | $ | 48,984 |  |  | 45,998 |  |
| Transportation |  | 11,331 |  |  | 7,075 |  |  | 32,703 |  |  | 21,094 |  |
| Industrial |  | 2,180 |  |  | 2,058 |  |  | 6,522 |  |  | 5,957 |  |
| Total depreciation and amortization |  | $ | 32,591 |  |  | $ | 24,636 |  |  | $ | 88,209 |  |  | $ | 73,049 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 113,140 |  |  | $ | 100,524 |  |  | $ | 339,675 |  |  | $ | 230,283 |  |
| Transportation |  | 12,987 |  |  | 15,806 |  |  | 57,604 |  |  | 55,380 |  |
| Industrial |  | 12,178 |  |  | 6,571 |  |  | 39,968 |  |  | 18,452 |  |
| Other(a) |  | (16,435) |  |  | (2,794) |  |  | (30,623) |  |  | (11,270) |  |
| Total operating income |  | 121,870 |  |  | 120,107 |  |  | 406,624 |  |  | 292,845 |  |
| Interest expense |  | 8,399 |  |  | 4,602 |  |  | 17,069 |  |  | 13,901 |  |
| Foreign exchange loss |  | 18,191 |  |  | 3,154 |  |  | 40,051 |  |  | 8,315 |  |
| Other (income) expense, net |  | (698) |  |  | (1,240) |  |  | 9,789 |  |  | (10,867) |  |
| Income before income taxes |  | $ | 95,978 |  |  | $ | 113,591 |  |  | $ | 339,715 |  |  | $ | 281,496 |  |

[0000889331-22-000046:notes:191]
(a) Included in “Other” Operating income for the third quarter of 2022 was $6.8 million ($11.6 million year-to-date) of purchase accounting inventory step-up charges, $6.2 million ($14.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $3.4 million ($4.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-22-000046:notes:192]
Included in “Other” Operating income for the third quarter of 2021 was $6.8 million year-to-date of purchase accounting inventory step-up charges, $2.0 million ($3.4 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.8 million ($2.0 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a year-to-date gain of $0.9 million recorded for the sale of a building within the Electronics segment.

[0000889331-22-000046:notes:193]
[same as prior period, unchanged from 0000889331-22-000040:notes:177]

[0000889331-22-000046:notes:194]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  | September 25, 2021 |  | October 1, 2022 |  | September 25, 2021 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 244,907 |  |  | $ | 172,995 |  |  | $ | 689,888 |  |  | $ | 458,723 |  |
| China |  | 165,091 |  |  | 160,628 |  |  | 492,195 |  |  | 455,872 |  |
| Other countries(a) |  | 248,882 |  |  | 205,958 |  |  | 718,563 |  |  | 612,268 |  |
| Total net sales |  | $ | 658,880 |  |  | $ | 539,581 |  |  | $ | 1,900,646 |  |  | $ | 1,526,863 |  |

[0000889331-22-000046:notes:195]
[same as prior period, unchanged from 0000889331-22-000040:notes:179]

[0000889331-22-000046:notes:196]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 76,191 |  |  | $ | 57,923 |  |
| China |  | 120,079 |  |  | 122,867 |  |
| Mexico |  | 105,290 |  |  | 107,283 |  |
| Germany |  | 36,033 |  |  | 39,055 |  |
| Philippines |  | 74,967 |  |  | 74,918 |  |
| Other countries(a) |  | 45,674 |  |  | 35,843 |  |
| Total long-lived assets |  | $ | 458,234 |  |  | $ | 437,889 |  |

[0000889331-22-000046:notes:197]
[same as prior period, unchanged from 0000889331-22-000040:notes:181]

[0000889331-22-000046:notes:198]
|  |  | Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  | September 25, 2021 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 9,761 |  |  | $ | 3,696 |  |
| China |  | 23,449 |  |  | 13,790 |  |
| Mexico |  | 21,169 |  |  | 22,518 |  |
| Germany |  | 3,246 |  |  | 6,994 |  |
| Philippines |  | 13,118 |  |  | 10,109 |  |
| Other countries(a) |  | 4,269 |  |  | 3,527 |  |
| Total additions to long-lived assets |  | $ | 75,012 |  |  | $ | 60,634 |  |

[0000889331-22-000046:notes:199]
[same as prior period, unchanged from 0000889331-22-000040:notes:183]
