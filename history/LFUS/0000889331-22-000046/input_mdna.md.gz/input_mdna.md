# LFUS MD&A — 0000889331-22-000046


## mdna

[0000889331-22-000046:mdna:1]
[same as prior period, unchanged from 0000889331-22-000040:mdna:1]

[0000889331-22-000046:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-22-000046:mdna:3]
[same as prior period, unchanged from 0000889331-22-000040:mdna:3]

[0000889331-22-000046:mdna:4]
[same as prior period, unchanged from 0000889331-22-000040:mdna:4]

[0000889331-22-000046:mdna:5]
[same as prior period, unchanged from 0000889331-22-000040:mdna:5]

[0000889331-22-000046:mdna:6]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with approximately 19,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-22-000046:mdna:7]
[same as prior period, unchanged from 0000889331-22-000040:mdna:7]

[0000889331-22-000046:mdna:8]
[same as prior period, unchanged from 0000889331-22-000040:mdna:8]

[0000889331-22-000046:mdna:9]
For the third quarter of 2022, the Company recognized net sales of $658.9 million, an increase of $119.3 million, or 22.1% as compared to $539.6 million in the third quarter of 2021. The increase was primarily driven by higher volumes in the Electronics and Industrial segments, $58.8 million or 10.9% of net sales from the Carling acquisition within the Transportation segment and $37.9 million or 7.0% of net sales from the C&K acquisition within the Electronics segment, partially offset by $21.5 million or 4.0% of unfavorable changes in foreign exchange rates. The Company recognized net income of $75.5 million, or $3.02 per diluted share, in the third quarter of 2022 compared to $92.1 million, or $3.69 per diluted share in the third quarter of 2021. The decrease in net income was primarily due to higher foreign exchange losses of $15.0 million.

[0000889331-22-000046:mdna:10]
Supply chain constraints, including material and transportation capacity shortages impacted the Company, its suppliers and customers to a lesser extent during the third quarter of 2022 as compared to previous quarters. The Company expects ongoing improvement during the remainder of 2022.

[0000889331-22-000046:mdna:11]
Net cash provided by operating activities was $313.4 million for the nine months ended October 1, 2022 as compared to $240.7 million for the nine months ended September 25, 2021. The increase in net cash provided by operating activities was primarily due to higher cash earnings, partially offset by increases in working capital resulting from higher sales growth and higher annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-22-000046:mdna:12]
On July 19, 2022, the Company completed the previously announced acquisition of C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The Company financed the transaction through a combination of cash on hand and debt.

[0000889331-22-000046:mdna:13]
[same as prior period, unchanged from 0000889331-22-000040:mdna:15]

[0000889331-22-000046:mdna:14]
[same as prior period, unchanged from 0000889331-22-000040:mdna:16]

[0000889331-22-000046:mdna:15]
[same as prior period, unchanged from 0000889331-22-000040:mdna:18]

[0000889331-22-000046:mdna:16]
[same as prior period, unchanged from 0000889331-22-000040:mdna:19]

[0000889331-22-000046:mdna:17]
The Company continues to operate in a more volatile macro environment given events related to the war in Ukraine. The Company does not have any direct operations in Ukraine or Russia. The war has had a modest impact on the Company, including higher transportation costs due to the Company modifying its shipping logistics as well as suspending sales into and purchases from Russia. Additionally, the war has impacted certain OEM customers who have had lower production levels due to shut-downs and ongoing material shortages.

[0000889331-22-000046:mdna:18]
[same as prior period, unchanged from 0000889331-22-000040:mdna:21]

[0000889331-22-000046:mdna:19]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The third quarter of 2022 includes $6.8 million ($11.6 million year-to-date) of purchase accounting inventory step-up charges, $6.2 million ($14.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $3.4 million ($4.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-22-000046:mdna:20]
The third quarter of 2021 includes $6.8 million year-to-date of purchase accounting inventory step-up charges, $2.0 million ($3.4 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.8 million ($2.0 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a year-to-date gain of $0.9 million recorded for the sale of a building within the Electronics segment.

[0000889331-22-000046:mdna:21]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  | 2022 |  | 2021 |  | Change |  | %Change |
| Net sales |  | $ | 658,880 |  |  | $ | 539,581 |  |  | $ | 119,299 |  |  | 22.1 | % |  | $ | 1,900,646 |  |  | $ | 1,526,863 |  |  | $ | 373,783 |  |  | 24.5 | % |
| Cost of sales |  | 402,059 |  |  | 325,009 |  |  | 77,050 |  |  | 23.7 | % |  | 1,122,258 |  |  | 954,429 |  |  | 167,829 |  |  | 17.6 | % |
| Gross profit |  | 256,821 |  |  | 214,572 |  |  | 42,249 |  |  | 19.7 | % |  | 778,388 |  |  | 572,434 |  |  | 205,954 |  |  | 36.0 | % |
| Operating expenses |  | 134,951 |  |  | 94,465 |  |  | 40,486 |  |  | 42.9 | % |  | 371,764 |  |  | 279,589 |  |  | 92,175 |  |  | 33.0 | % |
| Operating income |  | 121,870 |  |  | 120,107 |  |  | 1,763 |  |  | 1.5 | % |  | 406,624 |  |  | 292,845 |  |  | 113,779 |  |  | 38.9 | % |
| Income before income taxes |  | 95,978 |  |  | 113,591 |  |  | (17,613) |  |  | (15.5) | % |  | 339,715 |  |  | 281,496 |  |  | 58,219 |  |  | 20.7 | % |
| Income taxes |  | 20,510 |  |  | 21,537 |  |  | (1,027) |  |  | (4.8) | % |  | 59,713 |  |  | 49,634 |  |  | 10,079 |  |  | 20.3 | % |
| Net income |  | $ | 75,468 |  |  | $ | 92,054 |  |  | $ | (16,586) |  |  | (18.0) | % |  | $ | 280,002 |  |  | $ | 231,862 |  |  | $ | 48,140 |  |  | 20.8 | % |

[0000889331-22-000046:mdna:22]
[same as prior period, unchanged from 0000889331-22-000040:mdna:25]

[0000889331-22-000046:mdna:23]
Net sales increased $119.3 million, or 22.1%, for the third quarter of 2022 compared to the third quarter of 2021, including $58.8 million or 10.9% from the Carling acquisition within the Transportation segment and $37.9 million or 7.0% of net sales from the C&K acquisition within the Electronics segment, and included $21.5 million or 4.0% of unfavorable changes in foreign exchange rates. The remaining increase of $12.5 million in the Electronics segment was due to demand primarily in primarily in the semiconductors business within the Electronics segment while the Industrial segment increased $11.6 million driven by higher volume and price realization across all businesses.

[0000889331-22-000046:mdna:24]
Net sales increased $373.8 million, or 24.5%, including $172.4 million or 11.3% from the Carling acquisition within the Transportation segment and $37.9 million or 2.5% of net sales from the C&K acquisition within the Electronics segment, and included $46.5 million or 3.0% of unfavorable changes in foreign exchange rates for the first nine months of 2022 compared to the first nine months of 2021. The remaining increase of $124.6 million in the Electronics segment was due to higher volume and price realization across numerous end markets while the Industrial segment increased $49.3 million driven by higher volume and price realization across all businesses and incremental one month net sales of $9.1 million from the Hartland acquisition.

[0000889331-22-000046:mdna:25]
[same as prior period, unchanged from 0000889331-22-000040:mdna:28]

[0000889331-22-000046:mdna:26]
Cost of sales was $402.1 million, or 61.0% of net sales, in the third quarter of 2022, compared to $325.0 million, or 60.2% of net sales, in the third quarter of 2021. The increase in cost of sales was primarily due to greater volume across the Electronics and Industrial segments driven by the factors discussed above along with the acquisitions of Carling and C&K. As a percent of net sales, cost of sales increased 0.8% driven by purchase accounting inventory charges of $6.8 million or 1.0%, partially offset by volume leverage, and favorable product mix predominantly in the Electronics segment.

[0000889331-22-000046:mdna:27]
Cost of sales was $1,122.3 million, or 59.0% of net sales for the first nine months of 2022, compared to $954.4 million, or 62.5% of net sales for the first nine months of 2021. The increase in cost of sales was primarily due to greater volume across the Electronics and Industrial segments driven by the factors discussed above along with the acquisitions of Carling and C&K. As a percent of net sales, cost of sales decreased 3.5% driven by volume leverage, partially offset by higher purchase accounting inventory charges of $4.7 million or 0.3% in 2022.

[0000889331-22-000046:mdna:28]
[same as prior period, unchanged from 0000889331-22-000040:mdna:31]

[0000889331-22-000046:mdna:29]
Gross profit was $256.8 million, or 39.0% of net sales, in the third quarter of 2022 compared to $214.6 million, or 39.8% of net sales, for the third quarter of 2021. The $42.2 million increase in gross profit was primarily due to higher volume and price realization in the Electronics and Industrial segments along with the acquisitions of Carling and C&K. The decrease in gross margin of 0.8% was primarily driven by purchase accounting inventory charges of $6.8 million or 1.0%, partially offset by volume leverage and favorable price and product mix predominantly in the Electronics segment.

[0000889331-22-000046:mdna:30]
Gross profit was $778.4 million, or 41.0% of net sales, in the first nine months of 2022 compared to $572.4 million, or 37.5% of net sales, for the first nine months of 2021. The $206.0 million increase in gross profit was primarily due to higher volume and price realization in the Electronics and Industrial segments along with the acquisitions of Carling and C&K. The increase in gross margin of 3.5% was primarily driven by volume leverage and price realization, partially offset by higher purchase accounting inventory charges of $4.7 million or 0.2% in 2022.

[0000889331-22-000046:mdna:31]
[same as prior period, unchanged from 0000889331-22-000040:mdna:34]

[0000889331-22-000046:mdna:32]
Total operating expenses were $135.0 million, or 20.5% of net sales, for the third quarter of 2022 compared to $94.5 million, or 17.5% of net sales, for the third quarter of 2021. The increase in operating expenses of $40.5 million was primarily due to  higher selling, general, and administrative expenses of $22.8 million, research and development expenses of $10.0 million, and increased amortization expense of $5.1 million and acquisition-related expenses of $4.2 million largely due to the Carling and C&K acquisitions.

[0000889331-22-000046:mdna:33]
Total operating expenses were $371.8 million, or 19.6% of net sales, for the first nine months of 2022 compared to $279.6 million, or 18.3% of net sales, for the first nine months of 2021. The increase in operating expenses of $92.2 million was primarily due to higher selling, general, and administrative expenses of $59.7 million, research and development expenses of $21.9 million and increased acquisition-related expenses of $11.4 million and amortization expense of $8.3 million largely due to the Carling and C&K acquisitions.

[0000889331-22-000046:mdna:34]
[same as prior period, unchanged from 0000889331-22-000040:mdna:37]

[0000889331-22-000046:mdna:35]
Operating income was $121.9 million, an increase of $1.8 million, or 1.5%, for the third quarter of 2022 compared to $120.1 million for the third quarter of 2021. The increase in operating income was due to higher gross profit from the Electronics and Industrial segments, partially offset by higher operating expenses as noted above. Operating margins decreased from 22.3% in the third quarter of 2021 to 18.5% in the third quarter of 2022 driven by the higher operating expenses associated with the acquisitions mentioned above.

[0000889331-22-000046:mdna:36]
Operating income was $406.6 million, an increase of $113.8 million, or 38.9%, for the first nine months of 2022 compared to $292.8 million for the first nine months of 2021. The increase in operating income was due to higher gross profit from all segments, particularly in the Electronics segment, partially offset by higher operating expenses as noted above. Operating margins increased from 19.2% in the first nine months of 2021 to 21.4% in the first nine months of 2022 driven by higher operating income of $109.4 million in the Electronics segment.

[0000889331-22-000046:mdna:37]
[same as prior period, unchanged from 0000889331-22-000040:mdna:41]

[0000889331-22-000046:mdna:38]
Income before income taxes was $96.0 million, or 14.6% of net sales, for the third quarter of 2022 compared to $113.6 million, or 21.1% of net sales, for the third quarter of 2021. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by higher foreign exchange losses of $15.0 million in the third quarter of 2022, and increased interest expense of $3.8 million due to higher borrowings.

[0000889331-22-000046:mdna:39]
Income before income taxes was $339.7 million, or 17.9% of net sales, for the first nine months of 2022 compared to $281.5 million, or 18.4% of net sales, for the first nine months of 2021. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by higher foreign exchange losses of $31.7 million during the nine months ended October 1, 2022 and $13.7 million of unrealized losses during the nine months ended October 1, 2022 compared to unrealized gains of $9.2 million during nine months ended September 25, 2021 related to the Company's equity investment.

[0000889331-22-000046:mdna:40]
[same as prior period, unchanged from 0000889331-22-000040:mdna:44]

[0000889331-22-000046:mdna:41]
Income tax expense for the third quarter of 2022 was $20.5 million, or an effective tax rate of 21.4%, compared to $21.5 million, or an effective tax rate of 19.0%, for the third quarter of 2021. The effective tax rate for the third quarter of 2022 is higher than the effective tax rate for the comparable 2021 period, primarily due to higher foreign exchange losses with no related tax benefit in the 2022 period, as compared to the comparable 2021 period.

[0000889331-22-000046:mdna:42]
Income tax expense for the first nine months of 2022 was $59.7 million, or an effective tax rate of 17.6%, compared to income tax expense of $49.6 million, or an effective tax rate of 17.6%, for the first nine months of 2021. The effective tax rate for the first nine months of the 2022 period is lower than the applicable U.S. statutory tax rate due to a one-time deduction that resulted from the dissolution of one of the Company’s affiliates, as well as the forecasted impact of income earned in lower tax jurisdictions.  The effective tax rate for the comparable 2021 period is lower than the applicable U.S. statutory tax rate primarily due to the forecasted impact of income earned in lower tax jurisdictions.

[0000889331-22-000046:mdna:43]
[same as prior period, unchanged from 0000889331-22-000040:mdna:47]

[0000889331-22-000046:mdna:44]
[same as prior period, unchanged from 0000889331-22-000040:mdna:48]

[0000889331-22-000046:mdna:45]
[same as prior period, unchanged from 0000889331-22-000040:mdna:49]

[0000889331-22-000046:mdna:46]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  | 2022 |  | 2021 |  | Change |  | %Change |
| Electronics |  | $ | 397,629 |  |  | $ | 347,240 |  |  | $ | 50,389 |  |  | 14.5 | % |  | $ | 1,121,626 |  |  | $ | 959,122 |  |  | $ | 162,504 |  |  | 16.9 | % |
| Transportation |  | 181,735 |  |  | 124,415 |  |  | 57,320 |  |  | 46.1 | % |  | 548,266 |  |  | 386,262 |  |  | 162,004 |  |  | 41.9 | % |
| Industrial |  | 79,516 |  |  | 67,926 |  |  | 11,590 |  |  | 17.1 | % |  | 230,754 |  |  | 181,479 |  |  | 49,275 |  |  | 27.2 | % |
| Total |  | $ | 658,880 |  |  | $ | 539,581 |  |  | $ | 119,299 |  |  | 22.1 | % |  | $ | 1,900,646 |  |  | $ | 1,526,863 |  |  | $ | 373,783 |  |  | 24.5 | % |

[0000889331-22-000046:mdna:47]
[same as prior period, unchanged from 0000889331-22-000040:mdna:51]

[0000889331-22-000046:mdna:48]
Net sales increased $50.4 million, or 14.5%, in the third quarter of 2022 compared to the third quarter of 2021 and included unfavorable changes in foreign exchange rates of $12.9 million. The sales increase was primarily due to the acquisition of C&K which contributed net sales of $37.9 million. The remaining sales increase was due to $32.8 million of higher volume for the semiconductor business driven by increased demand predominantly in the data center and electric vehicle end markets along with capacity growth and price realization.

[0000889331-22-000046:mdna:49]
Net sales increased $162.5 million, or 16.9%, in the first nine months of 2022 compared to the first nine months of 2021 and included unfavorable changes in foreign exchange rates of $27.3 million. The sales increase was primarily due to increased volume and price realization for the semiconductor business of $100.3 million and $62.2 million in the electronics products business, which included the incremental $37.9 million of sales from the acquisition of C&K. These volume increases were driven by continued broad-based demand across numerous end markets.

[0000889331-22-000046:mdna:50]
[same as prior period, unchanged from 0000889331-22-000040:mdna:54]

[0000889331-22-000046:mdna:51]
Net sales increased $57.3 million, or 46.1%, in the third quarter of 2022 compared to the third quarter of 2021 and included unfavorable changes in foreign exchange rates of $8.0 million. The sales increase was primarily due to the acquisition of Carling which contributed net sales of $58.8 million. Net sales in the commercial vehicle business increased by $60.8 million,

[0000889331-22-000046:mdna:52]
largely due to the Carling acquisition noted previously and continued demand across a number of commercial vehicle end markets. The passenger car products and automotive sensors businesses had sales decreases of $2.4 million and $1.1 million, respectively, mostly due to unfavorable changes in foreign exchange rates, certain automotive customer’s rebalancing their inventory levels of the Company's products given lower car build forecasts and softer demand for some products, partially offset by continued content growth in standard and electric vehicles.

[0000889331-22-000046:mdna:53]
Net sales increased $162.0 million, or 41.9%, in the first nine months of 2022 compared to the first nine months of 2021 and included unfavorable changes in foreign exchange rates of $17.8 million. The sales increase was primarily due to the acquisition of Carling which contributed net sales of $172.4 million. Net sales in the commercial vehicle business increased by $182.8 million, largely due to the Carling acquisition noted previously and continued demand across a number of commercial vehicle end markets. The passenger car products and automotive sensors businesses had sales decreases of $14.0 million and $6.7 million, respectively, primarily driven by unfavorable changes in foreign exchange rates, certain automotive customer’s rebalancing their inventory levels of the Company's products given lower car build forecasts and softer demand for some products  due to supply chain constraints and OEM shut downs caused by market shortages of semiconductor chips as well as a reduction of demand in Europe due to Ukraine/Russia conflict partially offset by greater content growth from vehicle mix and electric vehicles.

[0000889331-22-000046:mdna:54]
[same as prior period, unchanged from 0000889331-22-000040:mdna:57]

[0000889331-22-000046:mdna:55]
Net sales increased by $11.6 million, or 17.1%, in the third quarter of 2022 compared to the third quarter of 2021, which included unfavorable changes in foreign exchange rates of $0.6 million. The increase in net sales was primarily due to higher volume and demand across a number of end markets along with price realization. The higher volume was favorably impacted by increased manufacturing capacity and material availability.

[0000889331-22-000046:mdna:56]
Net sales increased by $49.3 million, or 27.2%, in the first nine months of 2022 compared to the first nine months of 2021, which included unfavorable changes in foreign exchange rates of $1.4 million. The increase in net sales was primarily due to higher volume and demand across a number of end markets, price realization, and incremental one month net sales of $9.1 million or 13.3% from the Hartland acquisition.

[0000889331-22-000046:mdna:57]
[same as prior period, unchanged from 0000889331-22-000040:mdna:60]

[0000889331-22-000046:mdna:58]
[same as prior period, unchanged from 0000889331-22-000040:mdna:61]

[0000889331-22-000046:mdna:59]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  | 2022 |  | 2021 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 263,963 |  |  | $ | 250,880 |  |  | $ | 13,083 |  |  | 5.2 | % |  | $ | 776,990 |  |  | $ | 702,542 |  |  | $ | 74,448 |  |  | 10.6 | % |
| Americas |  | 264,894 |  |  | 167,314 |  |  | 97,580 |  |  | 58.3 | % |  | 749,715 |  |  | 500,555 |  |  | 249,160 |  |  | 49.8 | % |
| Europe |  | 130,023 |  |  | 121,387 |  |  | 8,636 |  |  | 7.1 | % |  | 373,941 |  |  | 323,766 |  |  | 50,175 |  |  | 15.5 | % |
| Total |  | $ | 658,880 |  |  | $ | 539,581 |  |  | $ | 119,299 |  |  | 22.1 | % |  | $ | 1,900,646 |  |  | $ | 1,526,863 |  |  | $ | 373,783 |  |  | 24.5 | % |

[0000889331-22-000046:mdna:60]
[same as prior period, unchanged from 0000889331-22-000040:mdna:63]

[0000889331-22-000046:mdna:61]
Net sales increased $13.1 million, or 5.2%, in the third quarter of 2022 compared to the third quarter of 2021 and included unfavorable changes in foreign exchange rates of $5.9 million. The increase in net sales was primarily due to incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment, incremental sales from the acquisition of C&K, and higher volume and price realization from the semiconductor business within the Electronics segment, partially offset by lower net sales from electronics products business.

[0000889331-22-000046:mdna:62]
Net sales increased $74.4 million, or 10.6%, in the first nine months of 2022 compared to the first nine months of 2021, and included unfavorable changes in foreign exchange rates of $11.4 million. The increase in net sales was primarily due to higher volume and price realization across all businesses within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the first nine months of 2021.

[0000889331-22-000046:mdna:63]
[same as prior period, unchanged from 0000889331-22-000040:mdna:66]

[0000889331-22-000046:mdna:64]
Net sales increased $97.6 million, or 58.3%, in the third quarter of 2022 compared to the third quarter of 2021 and included unfavorable changes in foreign exchange rates of $0.5 million. The increase in net sales was primarily due to incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment and higher volume and price realization from all businesses within the Electronics including incremental sales from C&K acquisition and higher volume and price realization from all businesses within Industrial segments compared to the third quarter of 2021.

[0000889331-22-000046:mdna:65]
Net sales increased $249.2 million, or 49.8%, in the first nine months of 2022 compared to the first nine months of 2021 and included unfavorable changes in foreign exchange rates of $1.0 million. The increase in net sales was primarily due to incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment and higher volume and price realization from all businesses within the Electronics and Industrial segments compared to the first nine months of 2021.

[0000889331-22-000046:mdna:66]
[same as prior period, unchanged from 0000889331-22-000040:mdna:69]

[0000889331-22-000046:mdna:67]
Net sales increased $8.6 million, or 7.1%, in the third quarter of 2022 compared to the third quarter of 2021 and included unfavorable changes in foreign exchange rates of $15.1 million. The increase in net sales was primarily due to incremental sales from the acquisition of C&K, increased volume from the semiconductor business within the Electronics segment, and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the third quarter of 2021.

[0000889331-22-000046:mdna:68]
Net sales increased $50.2 million, or 15.5%, in the first nine months of 2022 compared to the first nine months of 2021 and included unfavorable changes in foreign exchange rates of $34.1 million. The increase in net sales was primarily due to increased volume across all businesses within the Electronics segment including incremental sales from C&K acquisition, and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the first nine months of 2021.

[0000889331-22-000046:mdna:69]
[same as prior period, unchanged from 0000889331-22-000040:mdna:72]

[0000889331-22-000046:mdna:70]
[same as prior period, unchanged from 0000889331-22-000040:mdna:73]

[0000889331-22-000046:mdna:71]
Cash and cash equivalents were $474.0 million as of October 1, 2022, a decrease of $4.5 million as compared to January 1, 2022. As of October 1, 2022, $115.9 million of the Company's $474.0 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-22-000046:mdna:72]
Revolving Credit Facility and Term Loan

[0000889331-22-000046:mdna:73]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-22-000046:mdna:74]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-22-000046:mdna:75]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing

[0000889331-22-000046:mdna:76]
September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended October 1, 2022, the Company paid  $1.9 million of term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $298.1 million, respectively, as of October 1, 2022.

[0000889331-22-000046:mdna:77]
[same as prior period, unchanged from 0000889331-22-000040:mdna:79]

[0000889331-22-000046:mdna:78]
As of October 1, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 4.134%.

[0000889331-22-000046:mdna:79]
As of October 1, 2022, the Company had no outstanding in letters of credit under the Credit Facility and had available $600.0 million of borrowing capacity under the revolving Credit Facility. As of October 1, 2022, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-22-000046:mdna:80]
[same as prior period, unchanged from 0000889331-22-000040:mdna:82]

[0000889331-22-000046:mdna:81]
[same as prior period, unchanged from 0000889331-22-000040:mdna:83]

[0000889331-22-000046:mdna:82]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the nine months ended October 1, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

[0000889331-22-000046:mdna:83]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-22-000046:mdna:84]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-22-000046:mdna:85]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2032.

[0000889331-22-000046:mdna:86]
Debt Covenants

[0000889331-22-000046:mdna:87]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of October 1, 2022 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2022. As of October 1, 2022, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-22-000046:mdna:88]
[same as prior period, unchanged from 0000889331-22-000040:mdna:90]

[0000889331-22-000046:mdna:89]
On July 19, 2022, the Company completed the previously announced acquisition of C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment.  The Company financed the transaction through a combination of cash on hand and debt.

[0000889331-22-000046:mdna:90]
[same as prior period, unchanged from 0000889331-22-000040:mdna:92]

[0000889331-22-000046:mdna:91]
During the third quarter of 2022 the Company paid quarterly dividends of $41.1 million to the shareholders. On November 1, 2022, the Board of Directors of the Company declared quarterly cash dividend of $0.60 per share, payable on December 8, 2022 to stockholders of record as of November 24, 2022.

[0000889331-22-000046:mdna:92]
[same as prior period, unchanged from 0000889331-22-000040:mdna:94]

[0000889331-22-000046:mdna:93]
|  |  | First Nine Months |
| (in thousands) |  | 2022 |  | 2021 |
| Net cash provided by operating activities |  | $ | 313,439 |  |  | $ | 240,664 |  |
| Net cash used in investing activities |  | (609,980) |  |  | (165,611) |  |
| Net cash used in financing activities |  | 321,923 |  |  | (60,877) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (31,963) |  |  | (5,832) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (6,581) |  |  | 8,344 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 482,836 |  |  | 687,525 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 476,255 |  |  | $ | 695,869 |  |

[0000889331-22-000046:mdna:94]
[same as prior period, unchanged from 0000889331-22-000040:mdna:96]

[0000889331-22-000046:mdna:95]
[same as prior period, unchanged from 0000889331-22-000040:mdna:97]

[0000889331-22-000046:mdna:96]
Net cash provided by operating activities was $313.4 million for the nine months ended October 1, 2022 as compared to $240.7 million for the nine months ended September 25, 2021. The increase in net cash provided by operating activities was primarily due to higher cash earnings, partially offset by increases in working capital resulting from higher sales growth and higher annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-22-000046:mdna:97]
[same as prior period, unchanged from 0000889331-22-000040:mdna:100]

[0000889331-22-000046:mdna:98]
Net cash used in investing activities was $610.0 million for the nine months ended October 1, 2022 compared to $165.6 million during the nine months ended September 25, 2021. Net cash paid for acquisitions was $532.8 million and $110.6 million for the nine months ended October 1, 2022 and September 25, 2021, respectively. Capital expenditures were $77.8 million, representing an increase of $20.2 million compared to 2021. During nine months ended October 1, 2022 and September 25, 2021, the Company received proceeds of $0.6 million from the sale of a property within the Transportation segment and $2.6 million from the sale of a property within the Electronics segment, respectively.

[0000889331-22-000046:mdna:99]
[same as prior period, unchanged from 0000889331-22-000040:mdna:102]

[0000889331-22-000046:mdna:100]
Net cash provided by financing activities was $321.9 million for the nine months ended October 1, 2022 compared to net cash used in financing activities $60.9 million for the nine months ended September 25, 2021. On July 18, 2022, the Company issued and funded $100 million in aggregate principal amount of 4.33% U.S. Senior Notes, due 2032. On June 30, 2022, the Company amended its Credit Agreement and borrowed of $300.0 million through a term loan. During the nine months ended October 1, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022 and $1.9 million on the term loan. During the nine months ended September 25, 2021, the Company made payments of $30.0 million on the

[0000889331-22-000046:mdna:101]
amended revolving credit facility. Additionally, the Company paid dividends $41.1 million and $36.6 million in the nine months ended October 1, 2022 and September 25, 2021, respectively.

[0000889331-22-000046:mdna:102]
[same as prior period, unchanged from 0000889331-22-000040:mdna:104]

[0000889331-22-000046:mdna:103]
[same as prior period, unchanged from 0000889331-22-000040:mdna:105]

[0000889331-22-000046:mdna:104]
The Company did not repurchase any shares of its common stock for the three and nine months ended October 1, 2022, and September 25, 2021.

[0000889331-22-000046:mdna:105]
[same as prior period, unchanged from 0000889331-22-000040:mdna:107]

[0000889331-22-000046:mdna:106]
As of October 1, 2022, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-22-000046:mdna:107]
[same as prior period, unchanged from 0000889331-22-000040:mdna:109]

[0000889331-22-000046:mdna:108]
[same as prior period, unchanged from 0000889331-22-000040:mdna:110]

[0000889331-22-000046:mdna:109]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended January 1, 2022. During the nine months ended October 1, 2022, there were no significant changes in the application of critical accounting policies.
