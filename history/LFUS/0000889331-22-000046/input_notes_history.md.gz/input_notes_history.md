# LFUS note change history — 0000889331-22-000040 → 0000889331-22-000046


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000889331-22-000046:note_history:1]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with approximately 19,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.
  (was, 2022-08-03, similarity 0.9842):
[0000889331-22-000040:note_history:1]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 17,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

- changed (2022-11-02):
[0000889331-22-000046:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended October 1, 2022 and September 25, 2021:
  (was, 2022-08-03, similarity 0.9059):
[0000889331-22-000040:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 2, 2022 and June 26, 2021:

- changed (2022-11-02):
[0000889331-22-000046:note_history:3]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  | — |  |  | — |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |
  (was, 2022-08-03, similarity 0.9754):
[0000889331-22-000040:note_history:3]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  | — |  |  | — |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- added (2022-11-02):
[0000889331-22-000046:note_history:4]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  |  |  |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- changed (2022-11-02):
[0000889331-22-000046:note_history:5]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference
  (was, 2022-08-03, similarity 0.9271):
[0000889331-22-000040:note_history:5]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on

- changed (2022-11-02):
[0000889331-22-000046:note_history:6]
between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2022-08-03, similarity 0.6843):
[0000889331-22-000040:note_history:6]
historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- changed (2022-11-02):
[0000889331-22-000046:note_history:7]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.
  (was, 2022-08-03, similarity 0.9972):
[0000889331-22-000040:note_history:7]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

- changed (2022-11-02):
[0000889331-22-000046:note_history:8]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at October 1, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2022-08-03, similarity 0.7574):
[0000889331-22-000040:note_history:8]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at July 2, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2022-11-02):
[0000889331-22-000046:note_history:9]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Cash and cash equivalents |  | $ | 474,003 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 824 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,428 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 476,255 |  |  | $ | 482,836 |  |
  (was, 2022-08-03, similarity 0.984):
[0000889331-22-000040:note_history:9]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Cash and cash equivalents |  | $ | 809,122 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 1,653 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,522 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 812,297 |  |  | $ | 482,836 |  |

- removed (2022-11-02):
[0000889331-22-000040:note_history:10]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  |  |  |  |  | 64,823 |  |  | 64,823 |  |  |  |  |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000889331-22-000046:note_history:11]
The carrying amounts of debt at October 1, 2022 and January 1, 2022 are as follows:
  (was, 2022-08-03, similarity 0.9252):
[0000889331-22-000040:note_history:11]
The carrying amounts of debt at July 2, 2022 and January 1, 2022 are as follows:

- added (2022-11-02):
[0000889331-22-000046:note_history:12]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 298,125 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 114,958 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 93,342 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | — |  |
| Other |  | 9,376 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,971) |  |  | (3,087) |  |
| Total debt |  | 985,830 |  |  | 636,897 |  |
| Less: Current maturities |  | (10,220) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 975,610 |  |  | $ | 611,897 |  |

- changed (2022-11-02):
[0000889331-22-000046:note_history:13]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.
  (was, 2022-08-03, similarity 0.9994):
[0000889331-22-000040:note_history:13]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement,, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

- changed (2022-11-02):
[0000889331-22-000046:note_history:14]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended October 1, 2022, the Company paid  $1.9 million of term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $298.1 million, respectively, as of October 1, 2022.
  (was, 2022-08-03, similarity 0.8671):
[0000889331-22-000040:note_history:14]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $300.0 million, respectively, as of July 2, 2022.

- changed (2022-11-02):
[0000889331-22-000046:note_history:15]
As of October 1, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 4.13%.
  (was, 2022-08-03, similarity 0.9484):
[0000889331-22-000040:note_history:15]
As of July 2, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 2.875%.

- added (2022-11-02):
[0000889331-22-000046:note_history:16]
As of October 1, 2022, the Company had no outstanding in letters of credit under the Credit Facility and had available $600.0 million of borrowing capacity under the revolving Credit Facility. As of October 1, 2022, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2022-11-02):
[0000889331-22-000046:note_history:17]
During three and nine months ended October 1, 2022, the Company paid debt issuance costs of $0.4 million and  $2.6 million in connection with the new amended Credit Agreement on June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new amended Credit Agreement.
  (was, 2022-08-03, similarity 0.7796):
[0000889331-22-000040:note_history:17]
During three and six months ended July 2, 2022, the Company paid debt issuance costs of $2.2 million in connection with the new amended Credit Agreement on June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new amended Credit Agreement.

- changed (2022-11-02):
[0000889331-22-000046:note_history:18]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the nine months ended October 1, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.
  (was, 2022-08-03, similarity 0.9695):
[0000889331-22-000040:note_history:18]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the six months ended July 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

- changed (2022-11-02):
[0000889331-22-000046:note_history:19]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.
  (was, 2022-08-03, similarity 0.9261):
[0000889331-22-000040:note_history:19]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the 2022 Purchase Agreement, as defined below.

- changed (2022-11-02):
[0000889331-22-000046:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At October 1, 2022, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2022-08-03, similarity 0.9904):
[0000889331-22-000040:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At July 2, 2022, the Company was in compliance with all covenants under the Senior Notes.

- changed (2022-11-02):
[0000889331-22-000046:note_history:21]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
Interest paid on all Company debt was $8.5 million and $6.1 million for the three months ended October 1, 2022 and September 25, 2021, respectively, and $16.9 million and $14.8 million for the nine months ended October 1, 2022 and September 25, 2021, respectively.
  (was, 2022-08-03, similarity 0.6871):
[0000889331-22-000040:note_history:21]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

- removed (2022-11-02):
[0000889331-22-000040:note_history:22]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 300,000 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 122,533 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 99,494 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Unamortized debt issuance costs |  | (4,958) |  |  | (3,087) |  |
| Total debt |  | 892,069 |  |  | 636,897 |  |
| Less: Current maturities |  | (7,500) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 884,569 |  |  | $ | 611,897 |  |

- removed (2022-11-02):
[0000889331-22-000040:note_history:23]
As of July 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the revolving Credit Facility. As of July 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.

- removed (2022-11-02):
[0000889331-22-000040:note_history:24]
Interest paid on all Company debt was $2.3 million and $2.5 million for the three months ended July 2, 2022 and June 26, 2021, respectively, and $8.4 million and $8.7 million for the six months ended July 2, 2022 and June 26, 2021, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000889331-22-000046:note_history:25]
The carrying amounts of debt at October 1, 2022 and January 1, 2022 are as follows:
  (was, 2022-08-03, similarity 0.9252):
[0000889331-22-000040:note_history:25]
The carrying amounts of debt at July 2, 2022 and January 1, 2022 are as follows:

- added (2022-11-02):
[0000889331-22-000046:note_history:26]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 298,125 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 114,958 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 93,342 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | — |  |
| Other |  | 9,376 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,971) |  |  | (3,087) |  |
| Total debt |  | 985,830 |  |  | 636,897 |  |
| Less: Current maturities |  | (10,220) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 975,610 |  |  | $ | 611,897 |  |

- removed (2022-11-02):
[0000889331-22-000040:note_history:27]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 300,000 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 122,533 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 99,494 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Unamortized debt issuance costs |  | (4,958) |  |  | (3,087) |  |
| Total debt |  | 892,069 |  |  | 636,897 |  |
| Less: Current maturities |  | (7,500) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 884,569 |  |  | $ | 611,897 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-11-02):
[0000889331-22-000046:note_history:28]
|  |  | Three Months Ended October 1, 2022 |  | Three Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | — |  | $ | 0.1 |  | $ | 2.9 |  |  | $ | 0.8 |  | $ | 0.1 |  | $ | 3.1 |  |
|  |  | For the Nine Months Ended October 1, 2022 |  | For the Nine Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.3 |  | 8.8 |  |  | 2.6 |  | 0.3 |  | 8.9 |  |
|  |  | October 1, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.7 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2022-11-02):
[0000889331-22-000040:note_history:29]
|  |  | Three Months Ended July 2, 2022 |  | Three Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | 0.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.7 |  | $ | 0.1 |  | $ | 2.8 |  |
|  |  | For the Six Months Ended July 2, 2022 |  | For the Six Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.2 |  | 5.9 |  |  | 1.8 |  | 0.2 |  | 5.8 |  |
|  |  | July 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.8 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-11-02):
[0000889331-22-000046:note_history:30]
|  |  | Three Months Ended October 1, 2022 |  | Three Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | — |  | $ | 0.1 |  | $ | 2.9 |  |  | $ | 0.8 |  | $ | 0.1 |  | $ | 3.1 |  |
|  |  | For the Nine Months Ended October 1, 2022 |  | For the Nine Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.3 |  | 8.8 |  |  | 2.6 |  | 0.3 |  | 8.9 |  |
|  |  | October 1, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.7 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2022-11-02):
[0000889331-22-000040:note_history:31]
|  |  | Three Months Ended July 2, 2022 |  | Three Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | 0.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.7 |  | $ | 0.1 |  | $ | 2.8 |  |
|  |  | For the Six Months Ended July 2, 2022 |  | For the Six Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.2 |  | 5.9 |  |  | 1.8 |  | 0.2 |  | 5.8 |  |
|  |  | July 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.8 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000889331-22-000046:note_history:32]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended October 1, 2022 and September 25, 2021:
  (was, 2022-08-03, similarity 0.9059):
[0000889331-22-000040:note_history:32]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 2, 2022 and June 26, 2021:

- changed (2022-11-02):
[0000889331-22-000046:note_history:33]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  | — |  |  | — |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |
  (was, 2022-08-03, similarity 0.9754):
[0000889331-22-000040:note_history:33]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  | — |  |  | — |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- added (2022-11-02):
[0000889331-22-000046:note_history:34]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  |  |  |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- removed (2022-11-02):
[0000889331-22-000040:note_history:35]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  |  |  |  |  | 64,823 |  |  | 64,823 |  |  |  |  |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-02):
[0000889331-22-000046:note_history:36]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference
  (was, 2022-08-03, similarity 0.9271):
[0000889331-22-000040:note_history:36]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on

- changed (2022-11-02):
[0000889331-22-000046:note_history:37]
between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2022-08-03, similarity 0.6843):
[0000889331-22-000040:note_history:37]
historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- changed (2022-11-02):
[0000889331-22-000046:note_history:38]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.
  (was, 2022-08-03, similarity 0.9972):
[0000889331-22-000040:note_history:38]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-11-02):
[0000889331-22-000040:note_history:39]
Subsequent eventsOn July 19, 2022, the Company acquired C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The Company financed the transaction through a combination of cash on hand and debt.
