# LFUS 8-K — 0000889331-22-000044 filed 2022-11-01

## item codes, every 8-K on or before 2022-11-02

- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2022-11-02

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-22-000044:8k_2_02:1]
EX-99.1
2
q32022earningsreleaseex991.htm
EX-99.1

[0000889331-22-000044:8k_2_02:2]
Document

[0000889331-22-000044:8k_2_02:3]
Exhibit 99.1

[0000889331-22-000044:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-22-000044:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS FOR 2022

[0000889331-22-000044:8k_2_02:6]
Year-to-date record performance driven by global business execution

[0000889331-22-000044:8k_2_02:7]
CHICAGO, November 1, 2022  - Littelfuse, Inc. (NASDAQ: LFUS), an industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the third quarter ended October 1, 2022:

[0000889331-22-000044:8k_2_02:8]
•Net sales of $658.9 million were up 22% versus the prior year period, and up 8% organically

[0000889331-22-000044:8k_2_02:9]
•GAAP diluted EPS was $3.02; adjusted diluted EPS was $4.28, up 8% versus the prior year period

[0000889331-22-000044:8k_2_02:10]
•Cash flow from operations was $148.1 million; free cash flow was $126.5 million, 41% higher than the prior year period

[0000889331-22-000044:8k_2_02:11]
•On September 29, the company released its 2021 Sustainability Report

[0000889331-22-000044:8k_2_02:12]
“In the third quarter, we continued the outstanding performance we achieved during the first half of this year, once again exceeding our expectations,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Our strong results were driven by growth from global business wins, additions from acquisitions, and progress on our operational excellence initiatives. Our significant achievements to date position us for ongoing long-term profitable growth within the mega themes of sustainability, connectivity, and safety.”

[0000889331-22-000044:8k_2_02:13]
Fourth Quarter of 2022*

[0000889331-22-000044:8k_2_02:14]
Based on current market conditions, for the fourth quarter the company expects,

[0000889331-22-000044:8k_2_02:15]
•Net sales in the range of $603 to $623 million, the midpoint of which represents 11% growth over the prior year and 4% organic growth; includes an approximately 700 basis point year-over-year sales headwind from foreign exchange and last year’s extra “14th week”

[0000889331-22-000044:8k_2_02:16]
•Adjusted diluted EPS in the range of $3.14 to $3.34; the midpoint of which represents 11% growth over the prior year when excluding last year’s combined $0.25 benefit from a tax holiday and “14th week”

[0000889331-22-000044:8k_2_02:17]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-22-000044:8k_2_02:18]
-more-

[0000889331-22-000044:8k_2_02:19]
Dividend

[0000889331-22-000044:8k_2_02:20]
•The company will pay a cash dividend on its common stock of $0.60 per share on December 8, 2022, to shareholders of record as of November 24, 2022

[0000889331-22-000044:8k_2_02:21]
Conference Call and Webcast Information

[0000889331-22-000044:8k_2_02:22]
Littelfuse will host a conference call on Wednesday, November 2, 2022, at 9:00 a.m. Central Time to discuss the results.The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-22-000044:8k_2_02:23]
About Littelfuse

[0000889331-22-000044:8k_2_02:24]
Littelfuse (NASDAQ: LFUS) is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with approximately 19,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-22-000044:8k_2_02:25]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse's accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 1, 2022. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended January 1, 2022, its Quarterly Report on Form 10-Q for the quarter ended July 2, 2022, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-22-000044:8k_2_02:26]
-more

[0000889331-22-000044:8k_2_02:27]
Non-GAAP Financial Measures

[0000889331-22-000044:8k_2_02:28]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-22-000044:8k_2_02:29]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-22-000044:8k_2_02:30]
The company believes that organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-22-000044:8k_2_02:31]
CONTACT: Trisha Tuntland

[0000889331-22-000044:8k_2_02:32]
Head of Investor Relations

[0000889331-22-000044:8k_2_02:33]
(773) 628-2163

[0000889331-22-000044:8k_2_02:34]
LFUS-F

[0000889331-22-000044:8k_2_02:35]
###

[0000889331-22-000044:8k_2_02:36]
LITTELFUSE, INC.

[0000889331-22-000044:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-22-000044:8k_2_02:38]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | October 1,2022 |  | January 1,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 474,003 |  |  | $ | 478,473 |  |
| Short-term investments |  | 79 |  |  | 28 |  |
| Trade receivables, less allowances of $83,872 and $59,232 at October 1, 2022 and January 1, 2022, respectively |  | 339,729 |  |  | 275,192 |  |
| Inventories |  | 536,026 |  |  | 445,671 |  |
| Prepaid income taxes and income taxes receivable |  | 5,833 |  |  | 2,035 |  |
| Prepaid expenses and other current assets |  | 75,643 |  |  | 68,812 |  |
| Total current assets |  | 1,431,313 |  |  | 1,270,211 |  |
| Net property, plant, and equipment |  | 458,234 |  |  | 437,889 |  |
| Intangible assets, net of amortization |  | 605,310 |  |  | 407,126 |  |
| Goodwill |  | 1,168,458 |  |  | 929,790 |  |
| Investments |  | 23,770 |  |  | 39,211 |  |
| Deferred income taxes |  | 10,461 |  |  | 13,127 |  |
| Right of use lease assets, net |  | 46,175 |  |  | 29,616 |  |
| Other long-term assets |  | 34,207 |  |  | 24,734 |  |
| Total assets |  | $ | 3,777,928 |  |  | $ | 3,151,704 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 219,447 |  |  | $ | 222,039 |  |
| Accrued liabilities |  | 177,127 |  |  | 159,689 |  |
| Accrued income taxes |  | 42,016 |  |  | 27,905 |  |
| Current portion of long-term debt |  | 10,220 |  |  | 25,000 |  |
| Total current liabilities |  | 448,810 |  |  | 434,633 |  |
| Long-term debt, less current portion |  | 975,610 |  |  | 611,897 |  |
| Deferred income taxes |  | 116,595 |  |  | 81,289 |  |
| Accrued post-retirement benefits |  | 36,842 |  |  | 37,037 |  |
| Non-current operating lease liabilities |  | 35,778 |  |  | 22,305 |  |
| Other long-term liabilities |  | 75,402 |  |  | 71,023 |  |
| Total equity |  | 2,088,891 |  |  | 1,893,520 |  |
| Total liabilities and equity |  | $ | 3,777,928 |  |  | $ | 3,151,704 |  |

[0000889331-22-000044:8k_2_02:39]
LITTELFUSE, INC.

[0000889331-22-000044:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-22-000044:8k_2_02:41]
(Unaudited)

[0000889331-22-000044:8k_2_02:42]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) |  | October 1,2022 |  | September 25,2021 |  | October 1,2022 |  | September 25,2021 |
| Net sales |  | $ | 658,880 |  |  | $ | 539,581 |  |  | $ | 1,900,646 |  |  | $ | 1,526,863 |  |
| Cost of sales |  | 402,059 |  |  | 325,009 |  |  | 1,122,258 |  |  | 954,429 |  |
| Gross profit |  | 256,821 |  |  | 214,572 |  |  | 778,388 |  |  | 572,434 |  |
| Selling, general, and administrative expenses |  | 90,219 |  |  | 67,468 |  |  | 258,820 |  |  | 199,071 |  |
| Research and development expenses |  | 25,752 |  |  | 15,779 |  |  | 68,796 |  |  | 46,912 |  |
| Amortization of intangibles |  | 15,567 |  |  | 10,446 |  |  | 39,883 |  |  | 31,608 |  |
| Restructuring, impairment, and other charges |  | 3,413 |  |  | 772 |  |  | 4,265 |  |  | 1,998 |  |
| Total operating expenses |  | 134,951 |  |  | 94,465 |  |  | 371,764 |  |  | 279,589 |  |
| Operating income |  | 121,870 |  |  | 120,107 |  |  | 406,624 |  |  | 292,845 |  |
| Interest expense |  | 8,399 |  |  | 4,602 |  |  | 17,069 |  |  | 13,901 |  |
| Foreign exchange loss |  | 18,191 |  |  | 3,154 |  |  | 40,051 |  |  | 8,315 |  |
| Other (income) expense, net |  | (698) |  |  | (1,240) |  |  | 9,789 |  |  | (10,867) |  |
| Income before income taxes |  | 95,978 |  |  | 113,591 |  |  | 339,715 |  |  | 281,496 |  |
| Income taxes |  | 20,510 |  |  | 21,537 |  |  | 59,713 |  |  | 49,634 |  |
| Net income |  | $ | 75,468 |  |  | $ | 92,054 |  |  | $ | 280,002 |  |  | $ | 231,862 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.05 |  |  | $ | 3.74 |  |  | $ | 11.32 |  |  | $ | 9.43 |  |
| Diluted |  | $ | 3.02 |  |  | $ | 3.69 |  |  | $ | 11.21 |  |  | $ | 9.31 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,755 |  |  | 24,622 |  |  | 24,726 |  |  | 24,582 |  |
| Diluted |  | 24,988 |  |  | 24,926 |  |  | 24,986 |  |  | 24,904 |  |
| Comprehensive income |  | $ | 47,280 |  |  | $ | 87,100 |  |  | $ | 218,262 |  |  | $ | 227,491 |  |

[0000889331-22-000044:8k_2_02:43]
LITTELFUSE, INC.

[0000889331-22-000044:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-22-000044:8k_2_02:45]
(Unaudited)

[0000889331-22-000044:8k_2_02:46]
|  |  | Nine Months Ended |
| (in thousands) |  | October 1, 2022 |  | September 25, 2021 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 280,002 |  |  | $ | 231,862 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 183,942 |  |  | 96,824 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (56,431) |  |  | (83,793) |  |
| Inventories |  | (83,803) |  |  | (71,232) |  |
| Accounts payable |  | (3,838) |  |  | 53,945 |  |
| Accrued liabilities and income taxes |  | (4,399) |  |  | 23,294 |  |
| Prepaid expenses and other assets |  | (2,034) |  |  | (10,236) |  |
| Net cash provided by operating activities |  | 313,439 |  |  | 240,664 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (532,772) |  |  | (110,646) |  |
| Purchases of property, plant, and equipment |  | (77,773) |  |  | (57,526) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 565 |  |  | 2,561 |  |
| Net cash used in investing activities |  | (609,980) |  |  | (165,611) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net proceeds (payments) of credit facility |  | 373,125 |  |  | (30,000) |  |
| Cash dividends paid |  | (41,055) |  |  | (36,648) |  |
| All other cash provided by financing activities |  | (10,147) |  |  | 5,771 |  |
| Net cash provided by (used in) financing activities |  | 321,923 |  |  | (60,877) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (31,963) |  |  | (5,832) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (6,581) |  |  | 8,344 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 482,836 |  |  | 687,525 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 476,255 |  |  | $ | 695,869 |  |

[0000889331-22-000044:8k_2_02:47]
LITTELFUSE, INC.

[0000889331-22-000044:8k_2_02:48]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-22-000044:8k_2_02:49]
(Unaudited)

[0000889331-22-000044:8k_2_02:50]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2022 |  | 2021 |  |  |  | %Growth /(Decline) |  | 2022 |  | 2021 |  |  |  | %Growth |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 397,629 |  |  | $ | 347,240 |  |  |  |  | 14.5 | % |  | $ | 1,121,626 |  |  | $ | 959,122 |  |  |  |  | 16.9 | % |
| Transportation |  | 181,735 |  |  | 124,415 |  |  |  |  | 46.1 | % |  | 548,266 |  |  | 386,262 |  |  |  |  | 41.9 | % |
| Industrial |  | 79,516 |  |  | 67,926 |  |  |  |  | 17.1 | % |  | 230,754 |  |  | 181,479 |  |  |  |  | 27.2 | % |
| Total net sales |  | $ | 658,880 |  |  | $ | 539,581 |  |  |  |  | 22.1 | % |  | $ | 1,900,646 |  |  | $ | 1,526,863 |  |  |  |  | 24.5 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 113,140 |  |  | $ | 100,524 |  |  |  |  | 12.6 | % |  | $ | 339,675 |  |  | $ | 230,283 |  |  |  |  | 47.5 | % |
| Transportation |  | 12,987 |  |  | 15,806 |  |  |  |  | (17.8) | % |  | 57,604 |  |  | 55,380 |  |  |  |  | 4.0 | % |
| Industrial |  | 12,178 |  |  | 6,571 |  |  |  |  | 85.3 | % |  | 39,968 |  |  | 18,452 |  |  |  |  | 116.6 | % |
| Other(a) |  | (16,435) |  |  | (2,794) |  |  |  |  | N.M. |  | (30,623) |  |  | (11,270) |  |  |  |  | N.M. |
| Total operating income |  | $ | 121,870 |  |  | $ | 120,107 |  |  |  |  | 1.5 | % |  | $ | 406,624 |  |  | $ | 292,845 |  |  |  |  | 38.9 | % |
| Operating Margin |  | 18.5 | % |  | 22.3 | % |  |  |  |  |  | 21.4 | % |  | 19.2 | % |  |  |  |  |
| Interest expense |  | 8,399 |  |  | 4,602 |  |  |  |  |  |  | 17,069 |  |  | 13,901 |  |  |  |  |  |
| Foreign exchange loss |  | 18,191 |  |  | 3,154 |  |  |  |  |  |  | 40,051 |  |  | 8,315 |  |  |  |  |  |
| Other (income) expense, net |  | (698) |  |  | (1,240) |  |  |  |  |  |  | 9,789 |  |  | (10,867) |  |  |  |  |  |
| Income before income taxes |  | $ | 95,978 |  |  | $ | 113,591 |  |  |  |  | (15.5) | % |  | $ | 339,715 |  |  | $ | 281,496 |  |  |  |  | 20.7 | % |

[0000889331-22-000044:8k_2_02:51]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-22-000044:8k_2_02:52]
N.M. - Not meaningful

[0000889331-22-000044:8k_2_02:53]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2022 |  | 2021 |  | %Growth /(Decline) |  | 2022 |  | 2021 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 28.5 | % |  | 28.9 | % |  | (0.4) | % |  | 30.3 | % |  | 24.0 | % |  | 6.3 | % |
| Transportation |  | 7.1 | % |  | 12.7 | % |  | (5.6) | % |  | 10.5 | % |  | 14.3 | % |  | (3.8) | % |
| Industrial |  | 15.3 | % |  | 9.7 | % |  | 5.6 | % |  | 17.3 | % |  | 10.2 | % |  | 7.1 | % |

[0000889331-22-000044:8k_2_02:54]
LITTELFUSE, INC.

[0000889331-22-000044:8k_2_02:55]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-22-000044:8k_2_02:56]
(In millions of USD except per share amounts - unaudited)

[0000889331-22-000044:8k_2_02:57]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-22 |  | Q3-21 |  | YTD-22 |  | YTD-21 |
| GAAP diluted EPS |  | $ | 3.02 |  |  | $ | 3.69 |  |  | $ | 11.21 |  |  | $ | 9.31 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 1.26 |  |  | 0.26 |  |  | 2.32 |  |  | 0.73 |  |
| Adjusted diluted EPS |  | $ | 4.28 |  |  | $ | 3.95 |  |  | $ | 13.53 |  |  | $ | 10.04 |  |

[0000889331-22-000044:8k_2_02:58]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q3-22 |  | Q3-21 |  | YTD-22 |  | YTD-21 |
| Acquisition-related and integration costs (a) |  | $ | 6.2 |  |  | $ | 2.0 |  |  | $ | 14.8 |  |  | $ | 3.4 |  |
| Purchase accounting inventory adjustments (b) |  | 6.8 |  |  | — |  |  | 11.6 |  |  | 6.8 |  |
| Restructuring, impairment and other charges (c) |  | 3.4 |  |  | 0.8 |  |  | 4.3 |  |  | 2.0 |  |
| Gain on sale of fixed assets (d) |  | — |  |  | — |  |  | — |  |  | (0.9) |  |
| Non-GAAP adjustments to operating income |  | 16.4 |  |  | 2.8 |  |  | 30.7 |  |  | 11.3 |  |
| Other expense (income), net (e) |  | — |  |  | 0.1 |  |  | (0.5) |  |  | 0.6 |  |
| Non-operating foreign exchange loss |  | 18.2 |  |  | 3.2 |  |  | 40.1 |  |  | 8.3 |  |
| Non-GAAP adjustments to income before income taxes |  | 34.6 |  |  | 6.1 |  |  | 70.3 |  |  | 20.2 |  |
| Income taxes (f) |  | 3.0 |  |  | (0.4) |  |  | 12.2 |  |  | 2.1 |  |
| Non-GAAP adjustments to net income |  | $ | 31.6 |  |  | $ | 6.5 |  |  | $ | 58.1 |  |  | $ | 18.1 |  |
| Total EPS impact |  | $ | 1.26 |  |  | $ | 0.26 |  |  | $ | 2.32 |  |  | $ | 0.73 |  |

[0000889331-22-000044:8k_2_02:59]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-22 |  | Q3-21 |  | YTD-22 |  | YTD-21 |
| Net sales |  | $ | 658.9 |  |  | $ | 539.6 |  |  | $ | 1,900.6 |  |  | $ | 1,526.9 |  |
| GAAP operating income |  | $ | 121.9 |  |  | $ | 120.1 |  |  | $ | 406.6 |  |  | $ | 292.8 |  |
| Add back non-GAAP adjustments |  | 16.4 |  |  | 2.8 |  |  | 30.7 |  |  | 11.3 |  |
| Adjusted operating income |  | $ | 138.3 |  |  | $ | 122.9 |  |  | $ | 437.3 |  |  | $ | 304.1 |  |
| Adjusted operating margin |  | 21.0 | % |  | 22.8 | % |  | 23.0 | % |  | 19.9 | % |
| Add back amortization |  | 15.6 |  |  | 10.4 |  |  | 39.9 |  |  | 31.6 |  |
| Add back depreciation |  | 17.0 |  |  | 14.2 |  |  | 48.3 |  |  | 41.4 |  |
| Adjusted EBITDA |  | $ | 170.9 |  |  | $ | 147.5 |  |  | $ | 525.5 |  |  | $ | 377.1 |  |
| Adjusted EBITDA margin |  | 25.9 | % |  | 27.3 | % |  | 27.6 | % |  | 24.7 | % |

[0000889331-22-000044:8k_2_02:60]
| Adjusted EBITDA by Segment |  | Q3-22 |  | Q3-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 113.1 |  |  | $ | 13.0 |  |  | $ | 12.2 |  |  | $ | 100.5 |  |  | $ | 15.8 |  |  | $ | 6.6 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 9.7 |  |  | 4.7 |  |  | 1.2 |  |  | 6.8 |  |  | 2.4 |  |  | 1.2 |  |
| Add back depreciation |  | 9.4 |  |  | 6.7 |  |  | 1.0 |  |  | 8.7 |  |  | 4.6 |  |  | 0.8 |  |
| Adjusted EBITDA |  | $ | 132.2 |  |  | $ | 24.4 |  |  | $ | 14.4 |  |  | $ | 116.0 |  |  | $ | 22.9 |  |  | $ | 8.6 |  |
| Adjusted EBITDA Margin |  | 33.3 | % |  | 13.4 | % |  | 18.1 | % |  | 33.4 | % |  | 18.4 | % |  | 12.7 | % |

[0000889331-22-000044:8k_2_02:61]
| Adjusted EBITDA by Segment |  | YTD-22 |  | YTD-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 339.7 |  |  | $ | 57.6 |  |  | $ | 40.0 |  |  | $ | 230.3 |  |  | $ | 55.4 |  |  | $ | 18.5 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 22.5 |  |  | 13.7 |  |  | 3.7 |  |  | $ | 21.0 |  |  | $ | 7.1 |  |  | $ | 3.5 |  |
| Add back depreciation |  | 26.5 |  |  | 19.0 |  |  | 2.9 |  |  | $ | 25.0 |  |  | $ | 14.0 |  |  | $ | 2.5 |  |
| Adjusted EBITDA |  | $ | 388.7 |  |  | $ | 90.3 |  |  | $ | 46.5 |  |  | $ | 276.3 |  |  | $ | 76.5 |  |  | $ | 24.5 |  |
| Adjusted EBITDA Margin |  | 34.7 | % |  | 16.5 | % |  | 20.1 | % |  | 28.8 | % |  | 19.8 | % |  | 13.5 | % |

[0000889331-22-000044:8k_2_02:62]
| Net sales reconciliation |  | Q3-22 vs. Q3-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 15 | % |  | 46 | % |  | 17 | % |  | 22 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 11 | % |  | 49 | % |  | — | % |  | 18 | % |
| FX impact |  | (3) | % |  | (7) | % |  | (1) | % |  | (4) | % |
| Organic net sales growth |  | 7 | % |  | 4 | % |  | 18 | % |  | 8 | % |

[0000889331-22-000044:8k_2_02:63]
| Net sales reconciliation |  | YTD-22 vs. YTD-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 17 | % |  | 42 | % |  | 27 | % |  | 24 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | 46 | % |  | 5 | % |  | 14 | % |
| FX impact |  | (3) | % |  | (5) | % |  | (1) | % |  | (3) | % |
| Organic net sales growth |  | 16 | % |  | 1 | % |  | 23 | % |  | 13 | % |

[0000889331-22-000044:8k_2_02:64]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-22 |  | Q3-21 |  | YTD-22 |  | YTD-21 |
| Income taxes |  | $ | 20.5 |  |  | $ | 21.5 |  |  | $ | 59.7 |  |  | $ | 49.6 |  |
| Effective rate |  | 21.4 | % |  | 19.0 | % |  | 17.6 | % |  | 17.6 | % |
| Non-GAAP adjustments - income taxes |  | 3.0 |  |  | (0.4) |  |  | 12.2 |  |  | 2.1 |  |
| Adjusted income taxes |  | $ | 23.4 |  |  | $ | 21.1 |  |  | $ | 71.9 |  |  | $ | 51.7 |  |
| Adjusted effective rate |  | 18.0 | % |  | 17.6 | % |  | 17.5 | % |  | 17.1 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-22 |  | Q3-21 |  | YTD-22 |  | YTD-21 |
| Net cash provided by operating activities |  | $ | 148.1 |  |  | $ | 114.3 |  |  | $ | 313.4 |  |  | $ | 240.7 |  |
| Less: Purchases of property, plant and equipment |  | (21.7) |  |  | (24.9) |  |  | (77.8) |  |  | (57.5) |  |
| Free cash flow |  | $ | 126.5 |  |  | $ | 89.4 |  |  | $ | 235.7 |  |  | $ | 183.2 |  |

[0000889331-22-000044:8k_2_02:65]
| Consolidated Total Debt |  | As of October 1, 2022 |
| Consolidated Total Debt |  | $ | 985.8 |  |
| Unamortized debt issuance costs |  | 5.0 |  |
| Consolidated funded indebtedness |  | 990.8 |
| Cash held in U.S. (up to $400 million) |  | 115.9 |
| Net debt |  | $ | 874.9 |  |
| Consolidated EBITDA |  | Twelve Months Ended October 1, 2022 |
| Net Income |  | $ | 331.9 |  |
| Interest expense |  | 21.7 |  |
| Income taxes |  | 67.3 |  |
| Depreciation |  | 62.8 |  |
| Amortization |  | 51.0 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 23.3 |  |
| Non-cash pension settlement charge |  | 19.9 |  |
| Purchase accounting inventory step-up charge |  | 13.1 |  |
| Unrealized loss on investments |  | 14.6 |  |
| Other |  | 126.4 |  |
| Consolidated EBITDA (1) |  | $ | 732.0 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.2x |

[0000889331-22-000044:8k_2_02:66]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2023 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-22-000044:8k_2_02:67]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-22-000044:8k_2_02:68]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-22-000044:8k_2_02:69]
Note: Total will not always foot due to rounding.

[0000889331-22-000044:8k_2_02:70]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-22-000044:8k_2_02:71]
(b) reflected in cost of sales.

[0000889331-22-000044:8k_2_02:72]
(c) reflected in restructuring, impairment and other charges.

[0000889331-22-000044:8k_2_02:73]
(d) reflected in SG&A,  a total year-to-date gain of $0.9 million from the sale of a building within the Electronics segment 2021.

[0000889331-22-000044:8k_2_02:74]
(e) 2022 year-to-date amount included $0.5 million gain from the sale of a building within Transportation segment. Q3 2021 included a $0.1 million charge for an asset retirement obligation related to the disposal of a business in 2019.  2021 year-to-date amount included $0.5 million of impairment charges on certain other investments.

[0000889331-22-000044:8k_2_02:75]
(f) reflected the tax impact associated with the non-GAAP adjustments, and 2022 year-to-date amount include the one-time net benefit of $7.2 million that resulted from the dissolution of one of the Company’s affiliates.

[0000889331-22-000044:8k_2_02:76]
###
