# LFUS note change history — 0001437749-18-008370 → 0001437749-18-014196


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0001437749-18-014196:note_history:1]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 and 
six
 months ended 
 June 30, 2018:
  (was, 2018-05-02, similarity 0.9306):
[0001437749-18-008370:note_history:1]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 months ended 
 March 31, 2018:

- added (2018-08-01):
[0001437749-18-014196:note_history:2]
|  |  | For the three months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |
| Electronics – Semiconductor |  |  | 171,036 |  |  |  | — |  |  |  | — |  |  |  | 171,036 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,581 |  |  |  | — |  |  |  | 63,581 |  |
| Automotive Sensors |  |  | — |  |  |  | 30,729 |  |  |  | — |  |  |  | 30,729 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 32,862 |  |  |  | — |  |  |  | 32,862 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 32,654 |  |  |  | 32,654 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |

- added (2018-08-01):
[0001437749-18-014196:note_history:3]
|  |  | For the six months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  |  | 320,952 |  |  |  | — |  |  |  | — |  |  |  | 320,952 |  |
| Passenger Car Products |  |  | — |  |  |  | 127,160 |  |  |  | — |  |  |  | 127,160 |  |
| Automotive Sensors |  |  | — |  |  |  | 62,052 |  |  |  | — |  |  |  | 62,052 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 64,090 |  |  |  | — |  |  |  | 64,090 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 59,926 |  |  |  | 59,926 |  |
| Total |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- changed (2018-08-01):
[0001437749-18-014196:note_history:4]
Ship and Debit Program
  (was, 2018-05-02, similarity 0.7429):
[0001437749-18-008370:note_history:4]
Debit Program

- changed (2018-08-01):
[0001437749-18-014196:note_history:5]
2016
-
01,
 “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on 
 December 31, 2017, 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings. As a result of the adoption of the new standard and change in fair value of our equity investments, for the 
six
 months ended 
 June 30, 2018, 
the Company recognized an unrealized gain of 
$2.8
 million in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.
  (was, 2018-05-02, similarity 0.974):
[0001437749-18-008370:note_history:5]
2016
-
01,
 “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on 
 December 31, 2017, 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings.  As a result of the adoption of the new standard and change in fair value of our equity investments, for the 
three
 months ended 
 March 31, 2018, 
the Company recognized an unrealized gain of 
$1.9
 million  in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.

- added (2018-08-01):
[0001437749-18-014196:note_history:6]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the 
first
 quarter of 
2019.
 The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has 
not
 yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.

- added (2018-08-01):
[0001437749-18-014196:note_history:7]
In 
 January 2018, 
the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions of the 
2017
 U.S. Tax Cuts and Jobs Act (the “Tax Act”). The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has 
not
 yet completed its assessment and therefore has 
not
 yet elected an accounting policy.

- removed (2018-08-01):
[0001437749-18-008370:note_history:8]
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics - Semiconductor |  |  | 149,916 |  |  |  | — |  |  |  | — |  |  |  | 149,916 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,580 |  |  |  | — |  |  |  | 63,580 |  |
| Automotive Sensors |  |  | — |  |  |  | 31,323 |  |  |  | — |  |  |  | 31,323 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 31,228 |  |  |  | — |  |  |  | 31,228 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 27,271 |  |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |

- removed (2018-08-01):
[0001437749-18-008370:note_history:9]
Ship

- removed (2018-08-01):
[0001437749-18-008370:note_history:10]
and

- removed (2018-08-01):
[0001437749-18-008370:note_history:11]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the 
first
 quarter of 
2019.
 The Company is currently evaluating the impact of ASU 
2016
-
02.

- removed (2018-08-01):
[0001437749-18-008370:note_history:12]
In 
 January 2018, 
the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions in the Tax Act. The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has 
not
 yet completed its assessment and therefore has 
not
 yet elected an accounting policy.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0001437749-18-014196:note_history:13]
5.
 Debt
  (was, 2018-05-02, similarity 0.8333):
[0001437749-18-008370:note_history:13]
. Debt

- changed (2018-08-01):
[0001437749-18-014196:note_history:14]
The carrying amounts of debt at 
 June 30, 2018 
and 
 December 30, 2017 
are as follows:
  (was, 2018-05-02, similarity 0.9388):
[0001437749-18-008370:note_history:14]
The carrying amounts of debt at 
 March 31, 2018 
and 
 December 30, 2017 
are as follows:

- changed (2018-08-01):
[0001437749-18-014196:note_history:15]
| (in thousands) |  | June 30, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | — |  |  | $ | — |  |
| Term Loan |  |  | 157,500 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 135,335 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 109,887 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 60 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,184 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 697,598 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,060 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 687,538 |  |  | $ | 489,361 |  |
  (was, 2018-05-02, similarity 0.9924):
[0001437749-18-008370:note_history:15]
| (in thousands) |  | March 31, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | 3,000 |  |  | $ | — |  |
| Term Loan |  |  | 195,000 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 144,041 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 116,956 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 111 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,560 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 753,548 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,111 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 743,437 |  |  | $ | 489,361 |  |

- changed (2018-08-01):
[0001437749-18-014196:note_history:16]
On 
 March 4, 2016, 
the Company entered into a 
five
-year credit agreement (“Credit Agreement”) with a group of lenders for up to 
$700.0
 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of 
$575.0
 million and an unsecured term loan credit facility (“Term Loan”) of up to 
$125.0
 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders.
  (was, 2018-05-02, similarity 0.8606):
[0001437749-18-008370:note_history:16]
On 
 March 4, 2016, 
the Company entered into a 
five
-year credit agreement (“Credit Agreement”) with a group of lenders for up to 
$700.0
 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of 
$575.0
 million and an unsecured term loan credit facility (“Term Loan”) of up to 
$125.0
 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the Term Loan, the Company was required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.

- changed (2018-08-01):
[0001437749-18-014196:note_history:17]
On 
 October 13, 2017, 
the Company amended the Credit Agreement to increase the Revolving Credit Facility from 
$575.0
 million to 
$700.0
 million and increase the Term Loan from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans 
 may 
be made in up to 
two
 advances. The 
first
 advance of 
$125.0
 million occurred on 
 October 13, 2017 
and the 
second
 advance of 
$75.0
 million occurred on 
 January 16, 2018. 
For the Term Loan, the Company is required to make quarterly principal payments of 
1.25%
 of the original term loan (
$2.5
 million with the 
second
 advance on 
 January 16, 2018) 
through maturity, with the remaining balance due on 
 October 13, 2022. 
In addition to the quarterly principal payments, the Company paid 
$35.0
 million of principal on the term loan during the 
three
 months ended 
 June 30, 2018.
  (was, 2018-05-02, similarity 0.9259):
[0001437749-18-008370:note_history:17]
On 
 October 13, 2017, 
the Company amended the Credit Agreement to increase the Revolving Credit Facility from 
$575.0
 million to 
$700.0
 million and increase the Term Loan from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans 
 may 
be made in up to 
two
 advances. The 
first
 advance of 
$125.0
 million occurred on 
 October 13, 2017 
and the 
second
 advance of 
$75.0
 million occurred on 
 January 16, 2018. 
For the Term Loan, the Company is required to make quarterly principal payments of 
1.25%
 of the original term loan (
$2.5
 million with the 
second
 advance on 
 January 16, 2018) 
through maturity, with the remaining balance due on 
 October 13, 2022.

- changed (2018-08-01):
[0001437749-18-014196:note_history:18]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
-month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.25%,
 based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
3.59%
 at 
 June 30, 2018.
  (was, 2018-05-02, similarity 0.9768):
[0001437749-18-008370:note_history:18]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
-month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.25%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
3.13%
 at 
 March 31, 2018.

- added (2018-08-01):
[0001437749-18-014196:note_history:19]
As of 
 June 30, 2018, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$699.9
 million of borrowing capacity under the Revolving Credit Facility. At 
 June 30, 2018, 
the Company was in compliance with all covenants under the Credit Agreement.

- changed (2018-08-01):
[0001437749-18-014196:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 June 30, 2018, 
the Company was in compliance with all covenants under the Senior Notes.
  (was, 2018-05-02, similarity 0.9921):
[0001437749-18-008370:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 March 31, 2018, 
the Company was in compliance with all covenants under the Senior Notes.

- removed (2018-08-01):
[0001437749-18-008370:note_history:21]
5

- removed (2018-08-01):
[0001437749-18-008370:note_history:22]
As of 
 March 31, 2018, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$696.9
 million of borrowing capacity under the Revolving Credit Facility. At 
 March 31, 2018, 
the Company was in compliance with all covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0001437749-18-014196:note_history:23]
| (in thousands) |  | June 30, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | — |  |  | $ | — |  |
| Term Loan |  |  | 157,500 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 135,335 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 109,887 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 60 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,184 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 697,598 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,060 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 687,538 |  |  | $ | 489,361 |  |
  (was, 2018-05-02, similarity 0.9924):
[0001437749-18-008370:note_history:23]
| (in thousands) |  | March 31, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | 3,000 |  |  | $ | — |  |
| Term Loan |  |  | 195,000 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 144,041 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 116,956 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 111 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,560 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 753,548 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,111 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 743,437 |  |  | $ | 489,361 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0001437749-18-014196:note_history:24]
11.
 Related Party Transactions
  (was, 2018-05-02, similarity 0.9643):
[0001437749-18-008370:note_history:24]
. Related Party Transactions

- added (2018-08-01):
[0001437749-18-014196:note_history:25]
Powersem GmbH:
 The Company owns 
45%
 of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company recorded revenues of 
$0.3
 million and 
$0.4
 million, respectively from sales of products to Powersem for use as components in their products. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company purchased 
$1.0
 million and 
$2.1
 million, respectively of products from Powersem. At 
 June 30, 2018, 
the accounts receivable balance from Powersem was 
$0.1
 million and the accounts payable balance to Powersem was 
$0.3
 million.

- changed (2018-08-01):
[0001437749-18-014196:note_history:26]
EB Tech Ltd.:
 The Company owns approximately 
20%
 of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the 
three
 and 
six
 months ended 
 June 30, 2018 
EB Tech rendered processing services for the Company totaling approximately 
$0.1
 million and 
$0.2
 million, respectively. As of 
 June
  (was, 2018-05-02, similarity 0.8775):
[0001437749-18-008370:note_history:26]
EB Tech Ltd.:
 The Company owns approximately 
20%
 of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the 
three
 months ended 
 March 31, 2018 
EB Tech rendered processing services for the Company totaling approximately 
$0.1
 million. As of 
 March

- changed (2018-08-01):
[0001437749-18-014196:note_history:27]
Automated Technology, Inc.
: The Company owns approximately 
24%
 of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
ATEC rendered assembly and test services to the Company totaling approximately 
$2.8
 million and 
$5.2
 million, respectively. As of 
 June
  (was, 2018-05-02, similarity 0.8919):
[0001437749-18-008370:note_history:27]
Automated Technology, Inc.
: The Company owns approximately 
24%
 of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the 
three
 months ended 
 March 31, 2018, 
ATEC rendered assembly and test services to the Company totaling approximately 
$2.4
 million. As of 
 March

- removed (2018-08-01):
[0001437749-18-008370:note_history:28]
Powersem

- removed (2018-08-01):
[0001437749-18-008370:note_history:29]
GmbH

- removed (2018-08-01):
[0001437749-18-008370:note_history:30]
:
 The Company owns 
45%
 of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the 
three
 months ended 
 March 31, 2018, 
the Company recorded revenues of 
$0.1
 million from sales of products to Powersem for use as components in their products. During the 
three
 months ended 
 March 31, 2018, 
the Company purchased 
$1.1
 million of products from Powersem. At 
 March

- removed (2018-08-01):
[0001437749-18-008370:note_history:31]
2018,
 the accounts receivable balance from Powersem was 
$0.1
 million and the accounts payable balance to Powersem was 
$0.3
 million.

- removed (2018-08-01):
[0001437749-18-008370:note_history:32]
31,

- removed (2018-08-01):
[0001437749-18-008370:note_history:33]
31,


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-08-01):
[0001437749-18-014196:note_history:34]
|  |  | For the three months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |
| Electronics – Semiconductor |  |  | 171,036 |  |  |  | — |  |  |  | — |  |  |  | 171,036 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,581 |  |  |  | — |  |  |  | 63,581 |  |
| Automotive Sensors |  |  | — |  |  |  | 30,729 |  |  |  | — |  |  |  | 30,729 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 32,862 |  |  |  | — |  |  |  | 32,862 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 32,654 |  |  |  | 32,654 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |

- added (2018-08-01):
[0001437749-18-014196:note_history:35]
|  |  | For the six months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  |  | 320,952 |  |  |  | — |  |  |  | — |  |  |  | 320,952 |  |
| Passenger Car Products |  |  | — |  |  |  | 127,160 |  |  |  | — |  |  |  | 127,160 |  |
| Automotive Sensors |  |  | — |  |  |  | 62,052 |  |  |  | — |  |  |  | 62,052 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 64,090 |  |  |  | — |  |  |  | 64,090 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 59,926 |  |  |  | 59,926 |  |
| Total |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- removed (2018-08-01):
[0001437749-18-008370:note_history:36]
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics - Semiconductor |  |  | 149,916 |  |  |  | — |  |  |  | — |  |  |  | 149,916 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,580 |  |  |  | — |  |  |  | 63,580 |  |
| Automotive Sensors |  |  | — |  |  |  | 31,323 |  |  |  | — |  |  |  | 31,323 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 31,228 |  |  |  | — |  |  |  | 31,228 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 27,271 |  |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0001437749-18-014196:note_history:37]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 and 
six
 months ended 
 June 30, 2018:
  (was, 2018-05-02, similarity 0.9306):
[0001437749-18-008370:note_history:37]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 months ended 
 March 31, 2018:

- added (2018-08-01):
[0001437749-18-014196:note_history:38]
|  |  | For the three months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |
| Electronics – Semiconductor |  |  | 171,036 |  |  |  | — |  |  |  | — |  |  |  | 171,036 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,581 |  |  |  | — |  |  |  | 63,581 |  |
| Automotive Sensors |  |  | — |  |  |  | 30,729 |  |  |  | — |  |  |  | 30,729 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 32,862 |  |  |  | — |  |  |  | 32,862 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 32,654 |  |  |  | 32,654 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |

- added (2018-08-01):
[0001437749-18-014196:note_history:39]
|  |  | For the six months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  |  | 320,952 |  |  |  | — |  |  |  | — |  |  |  | 320,952 |  |
| Passenger Car Products |  |  | — |  |  |  | 127,160 |  |  |  | — |  |  |  | 127,160 |  |
| Automotive Sensors |  |  | — |  |  |  | 62,052 |  |  |  | — |  |  |  | 62,052 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 64,090 |  |  |  | — |  |  |  | 64,090 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 59,926 |  |  |  | 59,926 |  |
| Total |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- removed (2018-08-01):
[0001437749-18-008370:note_history:40]
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics - Semiconductor |  |  | 149,916 |  |  |  | — |  |  |  | — |  |  |  | 149,916 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,580 |  |  |  | — |  |  |  | 63,580 |  |
| Automotive Sensors |  |  | — |  |  |  | 31,323 |  |  |  | — |  |  |  | 31,323 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 31,228 |  |  |  | — |  |  |  | 31,228 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 27,271 |  |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |
