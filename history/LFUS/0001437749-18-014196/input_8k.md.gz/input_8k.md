# LFUS 8-K — 0001437749-18-014136 filed 2018-08-01

## item codes, every 8-K on or before 2018-08-01

- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2018-08-01

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-014136:8k_2_02:1]
EX-99.1
2
ex_119409.htm
EXHIBIT 99.1

[0001437749-18-014136:8k_2_02:2]
ex_119409.htm

[0001437749-18-014136:8k_2_02:3]
Exhibit 99.1

[0001437749-18-014136:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc. |
| 8755 West Higgins Road, Suite 500 |
| Chicago, Illinois 60631 |
| p: (773) 628-1000 f: (773) 628-0802 |
| www.littelfuse.com |

[0001437749-18-014136:8k_2_02:5]
LITTELFUSE REPORTS SECOND QUARTER RESULTS

[0001437749-18-014136:8k_2_02:6]
Company delivers record sales and adjusted earnings per share

[0001437749-18-014136:8k_2_02:7]
CHICAGO, August 1, 2018 – Littelfuse, Inc. (NASDAQ: LFUS), the global leader in circuit protection with advancing platforms in power control and sensor technologies, today reported financial results for the second quarter ended June 30, 2018:

[0001437749-18-014136:8k_2_02:8]
| ● | Net sales were $459.2 million, up 47% versus the prior year. Organic revenue growth was 11%. |

[0001437749-18-014136:8k_2_02:9]
| ● | Growth by segment versus the prior year period: |

[0001437749-18-014136:8k_2_02:10]
|  | o | Electronics sales increased 77% (up 14% organically) |

[0001437749-18-014136:8k_2_02:11]
|  | o | Automotive sales increased 9% (up 5% organically) |

[0001437749-18-014136:8k_2_02:12]
|  | o | Industrial sales increased 19% (up 18% organically) |

[0001437749-18-014136:8k_2_02:13]
| ● | GAAP diluted EPS was $1.67; this includes $26 million of after-tax charges primarily related to certain purchase accounting adjustments, acquisition and integration costs related to IXYS Corporation and non-operating foreign exchange losses |

[0001437749-18-014136:8k_2_02:14]
| ● | Adjusted diluted EPS of $2.68 increased 28% over last year |

[0001437749-18-014136:8k_2_02:15]
| ● | GAAP and adjusted effective tax rate were both 19.1% for the quarter |

[0001437749-18-014136:8k_2_02:16]
| ● | Cash flow from operations was $71.6 million and free cash flow was $49.2 million |

[0001437749-18-014136:8k_2_02:17]
| ● | During the quarter, the company exited its Custom business within its Industrial segment; this is not expected to have a material impact to the company’s future sales and earnings |

[0001437749-18-014136:8k_2_02:18]
| ● | The electronics segment book-to-bill ratio exiting the second quarter was 1.02 (excluding the IXYS business) |

[0001437749-18-014136:8k_2_02:19]
"We are pleased with our record second quarter results driven by strong demand for our products across all segments and consistent operational performance, including the ongoing integration of the IXYS business,” said Dave Heinzmann, Littelfuse Chief Executive Officer. “With our diversified product portfolio and global presence, we are benefiting from broad-based market demand. Looking ahead, we remain well-positioned to leverage the global mega trends of a safer, greener and increasingly connected world as we execute our long-term strategy and drive double-digit sales and earnings growth.”

[0001437749-18-014136:8k_2_02:20]
-more-

[0001437749-18-014136:8k_2_02:21]
For the third quarter of 2018*:

[0001437749-18-014136:8k_2_02:22]
| ● | Net sales are expected to be in the range of $434 to $446 million, up 38% on a reported basis and up 8% organically, at the midpoint versus the prior year quarter |

[0001437749-18-014136:8k_2_02:23]
| ● | Adjusted diluted earnings per share are expected to be in the range of $2.31 to $2.45, representing 13% growth over the prior year quarter at the midpoint |

[0001437749-18-014136:8k_2_02:24]
| ● | Adjusted effective tax rate is expected to be approximately 21% |

[0001437749-18-014136:8k_2_02:25]
For the 2018 full year, the company expects an adjusted effective tax rate in the range of 18% – 21%.

[0001437749-18-014136:8k_2_02:26]
*All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, certain purchase accounting adjustments, foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-18-014136:8k_2_02:27]
Dividend

[0001437749-18-014136:8k_2_02:28]
| ● | The company’s Board of Directors approved a 16% increase in the quarterly cash dividend from $0.37 to $0.43. This equates to an annualized dividend of $1.72 per share. The dividend will be paid on September 6, 2018 to shareholders of record as of August 23, 2018. |

[0001437749-18-014136:8k_2_02:29]
Conference Call and Webcast Information

[0001437749-18-014136:8k_2_02:30]
Littelfuse will host a conference call today, Wednesday, August 1, 2018, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0001437749-18-014136:8k_2_02:31]
-more-

[0001437749-18-014136:8k_2_02:32]
About Littelfuse

[0001437749-18-014136:8k_2_02:33]
Founded in 1927, Littelfuse is the global leader in circuit protection with advancing platforms in power control and sensor technologies. The company serves customers in the electronics, automotive and industrial markets with products that include fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has more than 11,000 employees in more than 50 locations worldwide. For more information, please visit Littelfuse.com.

[0001437749-18-014136:8k_2_02:34]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; the integration of the recently acquired business of IXYS Corporation ("IXYS") and the risk that expected benefits, synergies and growth prospects of the acquisition of IXYS may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 30, 2017. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 30, 2017.

[0001437749-18-014136:8k_2_02:35]
Non-GAAP Financial Measures

[0001437749-18-014136:8k_2_02:36]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0001437749-18-014136:8k_2_02:37]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-18-014136:8k_2_02:38]
CONTACT: Trisha Tuntland

[0001437749-18-014136:8k_2_02:39]
Head of Investor Relations

[0001437749-18-014136:8k_2_02:40]
(773) 628-2163

[0001437749-18-014136:8k_2_02:41]
###

[0001437749-18-014136:8k_2_02:42]
LFUS-F

[0001437749-18-014136:8k_2_02:43]
| LITTELFUSE, INC. |
| Net Sales and Operating Income by Segment |
| (In thousands of USD, unaudited) |

[0001437749-18-014136:8k_2_02:44]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2018 |  |  | 2017 |  |  | % Growth / (Decline) |  |  | 2018 |  |  | 2017 |  |  | % Growth / (Decline) |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 299,357 |  |  | $ | 169,387 |  |  |  | 77% |  |  | $ | 563,768 |  |  | $ | 323,154 |  |  |  | 74% |  |
| Automotive |  |  | 127,172 |  |  |  | 116,457 |  |  |  | 9% |  |  |  | 253,302 |  |  |  | 224,297 |  |  |  | 13% |  |
| Industrial |  |  | 32,654 |  |  |  | 27,511 |  |  |  | 19% |  |  |  | 59,926 |  |  |  | 51,346 |  |  |  | 17% |  |
| Total net sales |  | $ | 459,183 |  |  | $ | 313,355 |  |  |  | 47% |  |  | $ | 876,996 |  |  | $ | 598,797 |  |  |  | 46% |  |

[0001437749-18-014136:8k_2_02:45]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2018 |  |  | 2017 |  |  | % Growth / (Decline) |  |  | 2018 |  |  | 2017 |  |  | % Growth / (Decline) |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 67,311 |  |  | $ | 42,967 |  |  |  | 57% |  |  | $ | 121,275 |  |  | $ | 78,173 |  |  |  | 55% |  |
| Automotive |  |  | 15,711 |  |  |  | 15,713 |  |  |  | - |  |  |  | 34,102 |  |  |  | 30,778 |  |  |  | 11% |  |
| Industrial |  |  | 5,279 |  |  |  | 1,905 |  |  |  | 177% |  |  |  | 9,988 |  |  |  | 2,012 |  |  |  | 396% |  |
| Other (1) |  |  | (28,679 | ) |  |  | (315 | ) |  | N.M. |  |  |  | (68,172 | ) |  |  | (1,840 | ) |  |  | N.M. |  |
| Total operating income |  | $ | 59,622 |  |  | $ | 60,270 |  |  |  | (1%) |  |  | $ | 97,193 |  |  | $ | 109,123 |  |  |  | (11%) |  |
| Operating margin |  |  | 13.0 | % |  |  | 19.2 | % |  |  |  |  |  |  | 11.1 | % |  |  | 18.2 | % |  |  |  |  |
| Interest expense |  |  | 5,782 |  |  |  | 3,281 |  |  |  |  |  |  |  | 11,205 |  |  |  | 6,401 |  |  |  |  |  |
| Foreign exchange loss (gain) |  |  | 3,200 |  |  |  | (558 | ) |  |  |  |  |  |  | (7,354 | ) |  |  | (2,115 | ) |  |  |  |  |
| Other (income) expense, net |  |  | (1,678 | ) |  |  | 190 |  |  |  |  |  |  |  | (3,621 | ) |  |  | 52 |  |  |  |  |  |
| Income before taxes |  | $ | 52,318 |  |  | $ | 57,357 |  |  |  | (9%) |  |  | $ | 96,963 |  |  | $ | 104,785 |  |  |  | (7%) |  |

[0001437749-18-014136:8k_2_02:46]
| N.M. - Not meaningful |

[0001437749-18-014136:8k_2_02:47]
| (1) "Other" typically includes non-GAAP adjustments such as acquisition-related costs, purchase accounting inventory adjustments and other charges, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details.) |

[0001437749-18-014136:8k_2_02:48]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2018 |  |  | 2017 |  |  | Growth / (Decline) |  |  | 2018 |  |  | 2017 |  |  | Growth / (Decline) |  |
| Operating Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  |  | 22.5 | % |  |  | 25.4 | % |  |  | (2.9% | ) |  |  | 21.5 | % |  |  | 24.2 | % |  |  | (2.7% | ) |
| Automotive |  |  | 12.4 | % |  |  | 13.5 | % |  |  | (1.1% | ) |  |  | 13.5 | % |  |  | 13.7 | % |  |  | (0.2% | ) |
| Industrial |  |  | 16.2 | % |  |  | 6.9 | % |  |  | 9.3 | % |  |  | 16.7 | % |  |  | 3.9 | % |  |  | 12.8 | % |

[0001437749-18-014136:8k_2_02:49]
| LITTELFUSE, INC. |
| Condensed Consolidated Balance Sheets |
| (In thousands of USD) |

[0001437749-18-014136:8k_2_02:50]
|  |  | June 30, 2018 |  |  | December 30, 2017 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 408,147 |  |  | $ | 429,676 |  |
| Short-term investments |  |  | 34 |  |  |  | 35 |  |
| Accounts receivable, less allowances |  |  | 260,444 |  |  |  | 182,699 |  |
| Inventories |  |  | 239,201 |  |  |  | 140,789 |  |
| Prepaid income taxes and income taxes receivable |  |  | 4,648 |  |  |  | 1,689 |  |
| Prepaid expenses and other current assets |  |  | 45,727 |  |  |  | 37,452 |  |
| Total current assets |  |  | 958,201 |  |  |  | 792,340 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 29,198 |  |  |  | 9,547 |  |
| Buildings |  |  | 118,432 |  |  |  | 86,599 |  |
| Equipment |  |  | 558,855 |  |  |  | 505,838 |  |
|  |  |  | 706,485 |  |  |  | 601,984 |  |
| Accumulated depreciation |  |  | (367,730 | ) |  |  | (351,407 | ) |
| Net property, plant and equipment |  |  | 338,755 |  |  |  | 250,577 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 124,798 |  |  |  | 81,911 |  |
| Distribution network |  |  | 10,434 |  |  |  | 12,872 |  |
| Customer lists, trademarks and tradenames |  |  | 248,007 |  |  |  | 109,067 |  |
| Backlog |  |  | 6,813 |  |  |  | - |  |
| Goodwill |  |  | 832,227 |  |  |  | 453,414 |  |
|  |  |  | 1,222,279 |  |  |  | 657,264 |  |
| Investments |  |  | 31,326 |  |  |  | 10,993 |  |
| Deferred income taxes |  |  | 10,320 |  |  |  | 11,858 |  |
| Other assets |  |  | 27,113 |  |  |  | 17,070 |  |
| Total assets |  | $ | 2,587,994 |  |  | $ | 1,740,102 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 127,290 |  |  | $ | 101,844 |  |
| Accrued payroll |  |  | 43,047 |  |  |  | 49,962 |  |
| Accrued expenses |  |  | 66,341 |  |  |  | 48,994 |  |
| Accrued severance |  |  | 1,049 |  |  |  | 1,459 |  |
| Accrued income taxes |  |  | 19,376 |  |  |  | 16,285 |  |
| Current portion of long-term debt |  |  | 10,060 |  |  |  | 6,250 |  |
| Total current liabilities |  |  | 267,163 |  |  |  | 224,794 |  |
| Long-term debt, less current portion |  |  | 687,538 |  |  |  | 489,361 |  |
| Deferred income taxes |  |  | 53,996 |  |  |  | 17,069 |  |
| Accrued post-retirement benefits |  |  | 33,210 |  |  |  | 18,742 |  |
| Other long-term liabilities |  |  | 76,067 |  |  |  | 62,580 |  |
| Total equity |  |  | 1,470,020 |  |  |  | 927,556 |  |
| Total liabilities and equity |  | $ | 2,587,994 |  |  | $ | 1,740,102 |  |

[0001437749-18-014136:8k_2_02:51]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Comprehensive Income |
| (In thousands of USD, except per share data, unaudited) |

[0001437749-18-014136:8k_2_02:52]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 30, 2018 |  |  | July 1, 2017 |  |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Net sales |  | $ | 459,183 |  |  | $ | 313,355 |  |  | $ | 876,996 |  |  | $ | 598,797 |  |
| Cost of sales |  |  | 290,196 |  |  |  | 180,747 |  |  |  | 558,386 |  |  |  | 352,539 |  |
| Gross profit |  |  | 168,987 |  |  |  | 132,608 |  |  |  | 318,610 |  |  |  | 246,258 |  |
| Selling, general and administrative expenses |  |  | 73,244 |  |  |  | 53,438 |  |  |  | 150,758 |  |  |  | 100,139 |  |
| Research and development expenses |  |  | 22,748 |  |  |  | 12,729 |  |  |  | 45,288 |  |  |  | 24,881 |  |
| Amortization of intangibles |  |  | 13,373 |  |  |  | 6,171 |  |  |  | 25,371 |  |  |  | 12,115 |  |
|  |  |  | 109,365 |  |  |  | 72,338 |  |  |  | 221,417 |  |  |  | 137,135 |  |
| Operating income |  |  | 59,622 |  |  |  | 60,270 |  |  |  | 97,193 |  |  |  | 109,123 |  |
| Interest expense |  |  | 5,782 |  |  |  | 3,281 |  |  |  | 11,205 |  |  |  | 6,401 |  |
| Foreign exchange loss (gain) |  |  | 3,200 |  |  |  | (558 | ) |  |  | (7,354 | ) |  |  | (2,115 | ) |
| Other (income) expense, net |  |  | (1,678 | ) |  |  | 190 |  |  |  | (3,621 | ) |  |  | 52 |  |
| Income before income taxes |  |  | 52,318 |  |  |  | 57,357 |  |  |  | 96,963 |  |  |  | 104,785 |  |
| Income taxes |  |  | 9,992 |  |  |  | 8,719 |  |  |  | 18,609 |  |  |  | 17,255 |  |
| Net income |  | $ | 42,326 |  |  | $ | 48,638 |  |  | $ | 78,354 |  |  | $ | 87,530 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.69 |  |  | $ | 2.13 |  |  | $ | 3.18 |  |  | $ | 3.84 |  |
| Diluted |  | $ | 1.67 |  |  | $ | 2.11 |  |  | $ | 3.12 |  |  | $ | 3.80 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 25,004 |  |  |  | 22,822 |  |  |  | 24,671 |  |  |  | 22,785 |  |
| Diluted |  |  | 25,401 |  |  |  | 23,023 |  |  |  | 25,086 |  |  |  | 23,005 |  |
| Comprehensive income |  | $ | 26,384 |  |  | $ | 44,485 |  |  | $ | 62,133 |  |  | $ | 89,004 |  |

[0001437749-18-014136:8k_2_02:53]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Cash Flows |
| (In thousands of USD, unaudited) |

[0001437749-18-014136:8k_2_02:54]
|  |  | For the Six Months Ended |  |
|  |  | June 30, 2018 |  |  | July 1, 2017 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 78,354 |  |  | $ | 87,530 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 24,431 |  |  |  | 18,575 |  |
| Amortization of intangibles |  |  | 25,371 |  |  |  | 12,115 |  |
| Provision for bad debts |  |  | (2 | ) |  |  | 1,895 |  |
| Deferred revenue |  |  | 1,921 |  |  |  | - |  |
| Stock-based compensation |  |  | 15,883 |  |  |  | 8,590 |  |
| Non-cash inventory charges |  |  | 36,927 |  |  |  | - |  |
| Impairment charges |  |  | 1,125 |  |  |  | - |  |
| Unrealized gain on investments |  |  | (3,311 | ) |  |  | - |  |
| Loss on sale of property, plant and equipment |  |  | 780 |  |  |  | 593 |  |
| Deferred income taxes |  |  | 2,434 |  |  |  | 1,514 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (33,481 | ) |  |  | (32,039 | ) |
| Inventories |  |  | (1,502 | ) |  |  | (8,739 | ) |
| Accounts payable |  |  | 13,684 |  |  |  | 7,985 |  |
| Accrued expenses (including post-retirement) |  |  | 3,773 |  |  |  | 3,912 |  |
| Accrued payroll and severance |  |  | (13,745 | ) |  |  | (13,190 | ) |
| Accrued taxes |  |  | (6,411 | ) |  |  | 515 |  |
| Prepaid expenses and other |  |  | (5,316 | ) |  |  | 4,317 |  |
| Net cash provided by operating activities |  |  | 140,915 |  |  |  | 93,573 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (40,315 | ) |  |  | (28,278 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (310,487 | ) |  |  | (14,172 | ) |
| Proceeds from maturities of short-term investments |  |  | - |  |  |  | 3,739 |  |
| Decrease in entrusted loan receivable |  |  | - |  |  |  | 2,416 |  |
| Proceeds from sale of property, plant and equipment |  |  | 68 |  |  |  | 178 |  |
| Net cash used in investing activities |  |  | (350,734 | ) |  |  | (36,117 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 60,000 |  |  |  | - |  |
| Proceeds of term loan |  |  | 75,000 |  |  |  | - |  |
| Payments of revolving credit facility |  |  | (60,000 | ) |  |  | (112,500 | ) |
| Payments of term loan |  |  | (40,025 | ) |  |  | (3,125 | ) |
| Net proceeds from senior notes payable |  |  | 175,000 |  |  |  | 125,000 |  |
| Payments of entrusted loan |  |  | - |  |  |  | (2,416 | ) |
| Debt issuance costs paid |  |  | (878 | ) |  |  | (1 | ) |
| Cash dividends paid |  |  | (18,458 | ) |  |  | (14,963 | ) |
| Net proceeds (payments) related to stock-based award activities |  |  | 5,568 |  |  |  | (2,074 | ) |
| Net cash provided by (used in) financing activities |  |  | 196,207 |  |  |  | (10,079 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (7,917 | ) |  |  | (608 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (21,529 | ) |  |  | 46,769 |  |
| Cash and cash equivalents at beginning of period |  |  | 429,676 |  |  |  | 275,124 |  |
| Cash and cash equivalents at end of period |  | $ | 408,147 |  |  | $ | 321,893 |  |

[0001437749-18-014136:8k_2_02:55]
| LITTELFUSE, INC. |
| Supplemental Financial Information |
| (in millions of USD except per share amounts, unaudited) |

[0001437749-18-014136:8k_2_02:56]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-18 |  |  | Q2-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| GAAP diluted EPS |  | $ | 1.67 |  |  | $ | 2.11 |  |  | $ | 3.12 |  |  | $ | 3.80 |  |
| EPS impact of Non-GAAP adjustments (below) |  |  | 1.01 |  |  |  | (0.01 | ) |  |  | 1.95 |  |  |  | (0.01 | ) |
| Adjusted diluted EPS |  | $ | 2.68 |  |  | $ | 2.10 |  |  | $ | 5.07 |  |  | $ | 3.79 |  |

[0001437749-18-014136:8k_2_02:57]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-18 |  |  | Q2-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Acquisition related and integration costs |  | $ | 2.3 |  |  | $ | 0.3 |  |  | $ | 14.1 |  |  | $ | 1.8 |  |
| Restructuring and other charges |  |  | 3.2 |  |  |  | - |  |  |  | 3.9 |  |  |  | - |  |
| Amortization backlog - IXYS |  |  | 3.1 |  |  |  | - |  |  |  | 5.6 |  |  |  | - |  |
| Impairments |  |  | 1.1 |  |  |  | - |  |  |  | 1.1 |  |  |  | - |  |
| Change in control - IXYS |  |  | - |  |  |  | - |  |  |  | 2.1 |  |  |  | - |  |
| Acquisition related stock-based compensation charge |  |  | - |  |  |  | - |  |  |  | 4.5 |  |  |  | - |  |
| Purchase accounting inventory adjustments |  |  | 19.0 |  |  |  | - |  |  |  | 36.9 |  |  |  | - |  |
| Non-GAAP adjustments to operating income |  |  | 28.7 |  |  |  | 0.3 |  |  |  | 68.2 |  |  |  | 1.8 |  |
| Non-operating foreign exchange loss (gain) |  |  | 3.2 |  |  |  | (0.6 | ) |  |  | (7.4 | ) |  |  | (2.2 | ) |
| Non-GAAP adjustments to income before income taxes |  |  | 31.9 |  |  |  | (0.3 | ) |  |  | 60.8 |  |  |  | (0.4 | ) |
| Income taxes |  |  | 6.1 |  |  |  | - |  |  |  | 11.9 |  |  |  | - |  |
| Non-GAAP adjustments to net income |  | $ | 25.8 |  |  | $ | (0.3 | ) |  | $ | 48.9 |  |  | $ | (0.4 | ) |
| Total EPS impact |  | $ | 1.01 |  |  | $ | (0.01 | ) |  | $ | 1.95 |  |  | $ | (0.01 | ) |

[0001437749-18-014136:8k_2_02:58]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-18 |  |  | Q2-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Net sales |  | $ | 459.2 |  |  | $ | 313.4 |  |  | $ | 877.0 |  |  | $ | 598.8 |  |
| GAAP operating income |  | $ | 59.6 |  |  | $ | 60.3 |  |  | $ | 97.2 |  |  | $ | 109.2 |  |
| Add back non-GAAP adjustments |  |  | 28.7 |  |  |  | 0.3 |  |  |  | 68.2 |  |  |  | 1.8 |  |
| Adjusted operating income |  | $ | 88.3 |  |  | $ | 60.6 |  |  | $ | 165.4 |  |  | $ | 111.0 |  |
| Adjusted operating margin |  |  | 19.2 | % |  |  | 19.3 | % |  |  | 18.9 | % |  |  | 18.5 | % |
| Add back amortization |  |  | 10.3 |  |  |  | 6.2 |  |  |  | 19.8 |  |  |  | 12.1 |  |
| Add back depreciation |  |  | 12.8 |  |  |  | 9.4 |  |  |  | 24.4 |  |  |  | 18.5 |  |
| Adjusted EBITDA |  | $ | 111.4 |  |  | $ | 76.2 |  |  | $ | 209.6 |  |  | $ | 141.6 |  |
| Adjusted EBITDA margin |  |  | 24.3 | % |  |  | 24.3 | % |  |  | 23.9 | % |  |  | 23.6 | % |

[0001437749-18-014136:8k_2_02:59]
| Net sales reconciliation |  | Q2-18 vs. Q2-17 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales growth |  |  | 77 | % |  |  | 9 | % |  |  | 19 | % |  |  | 47 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 61 | % |  |  | - |  |  |  | - |  |  |  | 33 | % |
| Divestitures |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| FX impact |  |  | 2 | % |  |  | 4 | % |  |  | 1 | % |  |  | 3 | % |
| Organic net sales growth |  |  | 14 | % |  |  | 5 | % |  |  | 18 | % |  |  | 11 | % |

[0001437749-18-014136:8k_2_02:60]
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-18 |  |  | Q2-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Income taxes |  | $ | 10.0 |  |  | $ | 8.7 |  |  | $ | 18.6 |  |  | $ | 17.2 |  |
| Effective rate |  |  | 19.1 | % |  |  | 15.2 | % |  |  | 19.2 | % |  |  | 16.5 | % |
| Non-GAAP adjustments - income taxes |  |  | 6.1 |  |  |  | - |  |  |  | 11.9 |  |  |  | - |  |
| Adjusted income taxes |  | $ | 16.1 |  |  | $ | 8.7 |  |  | $ | 30.5 |  |  | $ | 17.2 |  |
| Adjusted effective rate |  |  | 19.1 | % |  |  | 15.2 | % |  |  | 19.3 | % |  |  | 15.2 | % |

[0001437749-18-014136:8k_2_02:61]
| Free cash flow reconcilation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-18 |  |  | Q2-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Net cash provided by operating activities |  | $ | 71.6 |  |  | $ | 70.6 |  |  | $ | 140.9 |  |  | $ | 93.6 |  |
| Less: Purchases of property, plant and equipment |  |  | (22.4 | ) |  |  | (15.9 | ) |  |  | (40.3 | ) |  |  | (28.3 | ) |
| Free cash flow |  | $ | 49.2 |  |  | $ | 54.7 |  |  | $ | 100.6 |  |  | $ | 65.3 |  |

[0001437749-18-014136:8k_2_02:62]
| Note: Totals will not always foot due to rounding |

[0001437749-18-014136:8k_2_02:63]
| LITTELFUSE, INC. |
| Condensed Consolidated Statement of Comprehensive Income |
| Supplemental GAAP to Non-GAAP Reconciliation |
| (In thousands of USD, except per share data, unaudited) |

[0001437749-18-014136:8k_2_02:64]
|  |  | GAAP As Reported |  |  | Non-GAAP Adjustments |  |  |  | Non-GAAP |  |  | GAAP As Reported |  |  | Non-GAAP Adjustments |  |  |  | Non-GAAP |  |
|  |  | June 30, 2018 QTD |  |  | June 30, 2018 QTD |  |  |  | June 30, 2018 QTD |  |  | July 1, 2017 QTD |  |  | July 1, 2017 QTD |  |  |  | July 1, 2017 QTD |  |
| Net sales |  | $ | 459,183 |  |  | $ | - |  |  |  | $ | 459,183 |  |  | $ | 313,355 |  |  | $ | - |  |  |  | $ | 313,355 |  |
| Cost of sales |  |  | 290,196 |  |  |  | (19,454 | ) | (a) |  |  | 270,742 |  |  |  | 180,747 |  |  |  | - |  |  |  |  | 180,747 |  |
| Gross profit |  |  | 168,987 |  |  |  | 19,454 |  |  |  |  | 188,441 |  |  |  | 132,608 |  |  |  | - |  |  |  |  | 132,608 |  |
| Selling, general and administrative expenses |  |  | 73,244 |  |  |  | (6,123 | ) | (b) |  |  | 67,121 |  |  |  | 53,438 |  |  |  | (315 | ) | (d) |  |  | 53,123 |  |
| Research and development expenses |  |  | 22,748 |  |  |  | - |  |  |  |  | 22,748 |  |  |  | 12,729 |  |  |  | - |  |  |  |  | 12,729 |  |
| Amortization of intangibles |  |  | 13,373 |  |  |  | (3,103 | ) | (c) |  |  | 10,270 |  |  |  | 6,171 |  |  |  | - |  |  |  |  | 6,171 |  |
| Total operating expenses |  |  | 109,365 |  |  |  | (9,226 | ) |  |  |  | 100,139 |  |  |  | 72,338 |  |  |  | (315 | ) |  |  |  | 72,023 |  |
| Operating income |  |  | 59,622 |  |  |  | 28,680 |  |  |  |  | 88,302 |  |  |  | 60,270 |  |  |  | 315 |  |  |  |  | 60,585 |  |
| Interest expense |  |  | 5,782 |  |  |  | - |  |  |  |  | 5,782 |  |  |  | 3,281 |  |  |  | - |  |  |  |  | 3,281 |  |
| Foreign exchange loss (gain) |  |  | 3,200 |  |  |  | (3,200 | ) |  |  |  | - |  |  |  | (558 | ) |  |  | 558 |  |  |  |  | - |  |
| Other (income) expense, net |  |  | (1,678 | ) |  |  | - |  |  |  |  | (1,678 | ) |  |  | 190 |  |  |  | - |  |  |  |  | 190 |  |
| Income before income taxes |  |  | 52,318 |  |  |  | 31,880 |  |  |  |  | 84,198 |  |  |  | 57,357 |  |  |  | (243 | ) |  |  |  | 57,114 |  |
| Income taxes |  |  | 9,992 |  |  |  | 6,073 |  |  |  |  | 16,065 |  |  |  | 8,719 |  |  |  | (38 | ) |  |  |  | 8,681 |  |
| Net income |  | $ | 42,326 |  |  | $ | 25,807 |  |  |  | $ | 68,133 |  |  | $ | 48,638 |  |  | $ | (205 | ) |  |  | $ | 48,433 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.69 |  |  | $ | 1.03 |  |  |  | $ | 2.72 |  |  | $ | 2.13 |  |  | $ | (0.01 | ) |  |  | $ | 2.12 |  |
| Diluted |  | $ | 1.67 |  |  | $ | 1.01 |  |  |  | $ | 2.68 |  |  | $ | 2.11 |  |  | $ | (0.01 | ) |  |  | $ | 2.10 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 25,004 |  |  |  |  |  |  |  |  | 25,004 |  |  |  | 22,822 |  |  |  |  |  |  |  |  | 22,822 |  |
| Diluted |  |  | 25,401 |  |  |  |  |  |  |  |  | 25,401 |  |  |  | 23,023 |  |  |  |  |  |  |  |  | 23,023 |  |
| Comprehensive income |  | $ | 26,384 |  |  |  |  |  |  |  | $ | 52,191 |  |  | $ | 44,486 |  |  |  |  |  |  |  | $ | 44,281 |  |

[0001437749-18-014136:8k_2_02:65]
| (a) Cost of sales included $19.0 million for purchase accounting inventory adjustments and $0.5 million of restructuring charges |
| (b) Selling, general and administrative included $2.3 million for acquisition related and integration costs and $3.8 million of restructuring, impairment and other charges |
| (c) Amortization of intangibles included $3.1 million of IXYS backlog amortization |
| (d) Selling, general and administrative included $0.3 million for acquisition related costs |
| The Company believes that certain non-GAAP measures, when presented in conjunction with comparable GAAP measures, are useful because that information is an appropriate measure for evaluating the Company’s operating performance. Internally, the Company uses this non-GAAP information as an indicator of business performance, and evaluates management’s effectiveness with specific reference to this indicator. These measures should be considered in addition to, not a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. |

[0001437749-18-014136:8k_2_02:66]
| LITTELFUSE, INC. |  |
| Condensed Consolidated Statement of Comprehensive Income |  |
| Supplemental GAAP to Non-GAAP Reconciliation |  |
| (In thousands of USD, except per share data, unaudited) |  |

[0001437749-18-014136:8k_2_02:67]
|  |  | GAAP As Reported |  |  | Non-GAAP Adjustments |  |  |  | Non-GAAP |  |  | GAAP As Reported |  |  | Non-GAAP Adjustments |  |  |  | Non-GAAP |  |
|  |  | June 30, 2018 YTD |  |  | June 30, 2018 YTD |  |  |  | June 30, 2018 YTD |  |  | July 1, 2017 YTD |  |  | July 1, 2017 YTD |  |  |  | July 1, 2017 YTD |  |
| Net sales |  | $ | 876,996 |  |  | $ | - |  |  |  | $ | 876,996 |  |  | $ | 598,797 |  |  | $ | - |  |  |  | $ | 598,797 |  |
| Cost of sales |  |  | 558,386 |  |  |  | (38,332 | ) | (a) |  |  | 520,054 |  |  |  | 352,539 |  |  |  | (22 | ) |  |  |  | 352,517 |  |
| Gross profit |  |  | 318,610 |  |  |  | 38,332 |  |  |  |  | 356,942 |  |  |  | 246,258 |  |  |  | 22 |  |  |  |  | 246,280 |  |
| Selling, general and administrative expenses |  |  | 150,758 |  |  |  | (22,627 | ) | (b) |  |  | 128,131 |  |  |  | 100,139 |  |  |  | (1,818 | ) | (e) |  |  | 98,321 |  |
| Research and development expenses |  |  | 45,288 |  |  |  | (1,606 | ) | (c) |  |  | 43,682 |  |  |  | 24,881 |  |  |  | - |  |  |  |  | 24,881 |  |
| Amortization of intangibles |  |  | 25,371 |  |  |  | (5,607 | ) | (d) |  |  | 19,764 |  |  |  | 12,115 |  |  |  | - |  |  |  |  | 12,115 |  |
| Total operating expenses |  |  | 221,417 |  |  |  | (29,840 | ) |  |  |  | 191,577 |  |  |  | 137,135 |  |  |  | (1,818 | ) |  |  |  | 135,317 |  |
| Operating income |  |  | 97,193 |  |  |  | 68,172 |  |  |  |  | 165,365 |  |  |  | 109,123 |  |  |  | 1,840 |  |  |  |  | 110,963 |  |
| Interest expense |  |  | 11,205 |  |  |  | - |  |  |  |  | 11,205 |  |  |  | 6,401 |  |  |  | - |  |  |  |  | 6,401 |  |
| Foreign exchange loss (gain) |  |  | (7,354 | ) |  |  | 7,354 |  |  |  |  | - |  |  |  | (2,115 | ) |  |  | 2,115 |  |  |  |  | - |  |
| Other (income) expense, net |  |  | (3,621 | ) |  |  | - |  |  |  |  | (3,621 | ) |  |  | 52 |  |  |  | - |  |  |  |  | 52 |  |
| Income before income taxes |  |  | 96,963 |  |  |  | 60,818 |  |  |  |  | 157,781 |  |  |  | 104,785 |  |  |  | (275 | ) |  |  |  | 104,510 |  |
| Income taxes |  |  | 18,609 |  |  |  | 11,878 |  |  |  |  | 30,487 |  |  |  | 17,255 |  |  |  | (42 | ) |  |  |  | 17,213 |  |
| Net income |  | $ | 78,354 |  |  | $ | 48,940 |  |  |  | $ | 127,294 |  |  | $ | 87,530 |  |  | $ | (233 | ) |  |  | $ | 87,297 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.18 |  |  | $ | 1.98 |  |  |  | $ | 5.16 |  |  | $ | 3.84 |  |  | $ | (0.01 | ) |  |  | $ | 3.83 |  |
| Diluted |  | $ | 3.12 |  |  | $ | 1.95 |  |  |  | $ | 5.07 |  |  | $ | 3.80 |  |  | $ | (0.01 | ) |  |  | $ | 3.79 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 24,671 |  |  |  |  |  |  |  |  | 24,671 |  |  |  | 22,785 |  |  |  |  |  |  |  |  | 22,785 |  |
| Diluted |  |  | 25,086 |  |  |  |  |  |  |  |  | 25,086 |  |  |  | 23,005 |  |  |  |  |  |  |  |  | 23,005 |  |
| Comprehensive income |  | $ | 62,133 |  |  |  |  |  |  |  | $ | 111,073 |  |  | $ | 89,004 |  |  |  |  |  |  |  | $ | 88,771 |  |

[0001437749-18-014136:8k_2_02:68]
| (a) Cost of sales included $36.9 million for purchase accounting inventory adjustments, $0.5 million for acquisition related stock-based compensation charges and $0.9 million of restructuring charges |
| (b) Selling, general and administrative included $14.1 million for acquisition related and integration costs, $2.4 million for acquisition related stock-based compensation charges, $2.1 million for IXYS change in control and $4.1 million of restructuring, impairment and other charges |
| (c) Research and development expenses included $1.6 million for acquisition related stock-based compensation charges |
| (d) Amortization of intangibles included $5.6 million of IXYS backlog amortization |
| (e) Selling, general and administrative included $1.8 million for acquisition related and integration costs |
| The Company believes that certain non-GAAP measures, when presented in conjunction with comparable GAAP measures, are useful because that information is an appropriate measure for evaluating the Company’s operating performance. Internally, the Company uses this non-GAAP information as an indicator of business performance, and evaluates management’s effectiveness with specific reference to this indicator. These measures should be considered in addition to, not a substitute for, or superior to, measures of financial performance prepared in accordance with GAAP. |
