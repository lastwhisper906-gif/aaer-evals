# LFUS notes — 0001437749-18-014196


## lfus:RevenueRecognitionAndBillingPolicyTextBlock

[0001437749-18-014196:notes:1]
[same as prior period, unchanged from 0001437749-18-008370:notes:1]

[0001437749-18-014196:notes:2]
[same as prior period, unchanged from 0001437749-18-008370:notes:2]


## lfus:RevenueRecognitionReturnToStockPolicyTextBlock

[0001437749-18-014196:notes:3]
[same as prior period, unchanged from 0001437749-18-008370:notes:3]

[0001437749-18-014196:notes:4]
[same as prior period, unchanged from 0001437749-18-008370:notes:4]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-18-014196:notes:5]
[same as prior period, unchanged from 0001437749-18-008370:notes:5]

[0001437749-18-014196:notes:6]
[same as prior period, unchanged from 0001437749-18-008370:notes:6]

[0001437749-18-014196:notes:7]
[same as prior period, unchanged from 0001437749-18-008370:notes:7]

[0001437749-18-014196:notes:8]
[same as prior period, unchanged from 0001437749-18-008370:notes:8]


## us-gaap:BusinessAcquisitionProFormaInformationNonrecurringAdjustmentsTableTextBlock

[0001437749-18-014196:notes:9]
|  |  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands) |  | July 1, 2017 |  |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Amortization(a) |  | $ | (6,305 | ) |  | $ | 5,185 |  |  | $ | (12,601 | ) |
| Depreciation |  |  | 139 |  |  |  | — |  |  |  | 278 |  |
| Transaction costs(b) |  |  | — |  |  |  | 9,976 |  |  |  | (9,976 | ) |
| Amortization of inventory step-up(c) |  |  | (14,771 | ) |  |  | 36,927 |  |  |  | (36,927 | ) |
| Stock compensation(d) |  |  | (767 | ) |  |  | 4,689 |  |  |  | (5,780 | ) |
| Interest expense(e) |  |  | (2,582 | ) |  |  | — |  |  |  | (5,164 | ) |
| Income tax impact of above items |  |  | 7,596 |  |  |  | (13,329 | ) |  |  | 22,896 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-18-014196:notes:10]
|  |  | For the Three Months Ended |  |
| (in thousands, except per share amounts) |  | July 1, 2017 |  |
| Net sales |  | $ | 396,897 |  |
| Income before income taxes |  |  | 40,312 |  |
| Net income |  |  | 37,442 |  |
| Net income per share — basic |  |  | 1.50 |  |
| Net income per share — diluted |  |  | 1.48 |  |

[0001437749-18-014196:notes:11]
|  |  | For the Six Months Ended |  |
| (in thousands, except per share amounts) |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Net sales |  | $ | 893,709 |  |  | $ | 765,710 |  |
| Income before income taxes |  |  | 134,227 |  |  |  | 51,546 |  |
| Net income |  |  | 106,247 |  |  |  | 55,043 |  |
| Net income — basic |  |  | 4.26 |  |  |  | 2.21 |  |
| Net income — diluted |  |  | 4.22 |  |  |  | 2.18 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-18-014196:notes:12]
5.
 Debt

[0001437749-18-014196:notes:13]
The carrying amounts of debt at 
 June 30, 2018 
and 
 December 30, 2017 
are as follows:

[0001437749-18-014196:notes:14]
| (in thousands) |  | June 30, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | — |  |  | $ | — |  |
| Term Loan |  |  | 157,500 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 135,335 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 109,887 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 60 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,184 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 697,598 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,060 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 687,538 |  |  | $ | 489,361 |  |

[0001437749-18-014196:notes:15]
Revolving Credit Facility / Term Loan

[0001437749-18-014196:notes:16]
On 
 March 4, 2016, 
the Company entered into a 
five
-year credit agreement (“Credit Agreement”) with a group of lenders for up to 
$700.0
 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of 
$575.0
 million and an unsecured term loan credit facility (“Term Loan”) of up to 
$125.0
 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders.

[0001437749-18-014196:notes:17]
On 
 October 13, 2017, 
the Company amended the Credit Agreement to increase the Revolving Credit Facility from 
$575.0
 million to 
$700.0
 million and increase the Term Loan from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans 
 may 
be made in up to 
two
 advances. The 
first
 advance of 
$125.0
 million occurred on 
 October 13, 2017 
and the 
second
 advance of 
$75.0
 million occurred on 
 January 16, 2018. 
For the Term Loan, the Company is required to make quarterly principal payments of 
1.25%
 of the original term loan (
$2.5
 million with the 
second
 advance on 
 January 16, 2018) 
through maturity, with the remaining balance due on 
 October 13, 2022. 
In addition to the quarterly principal payments, the Company paid 
$35.0
 million of principal on the term loan during the 
three
 months ended 
 June 30, 2018.

[0001437749-18-014196:notes:18]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
-month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.25%,
 based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
3.59%
 at 
 June 30, 2018.

[0001437749-18-014196:notes:19]
As of 
 June 30, 2018, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$699.9
 million of borrowing capacity under the Revolving Credit Facility. At 
 June 30, 2018, 
the Company was in compliance with all covenants under the Credit Agreement.

[0001437749-18-014196:notes:20]
Senior Notes

[0001437749-18-014196:notes:21]
On 
 December 8, 2016, 
the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023 (
“Euro Senior Notes, Series A due 
2023”
), and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
“Euro Senior Notes, Series B due 
2028”
) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.

[0001437749-18-014196:notes:22]
On 
 December 8, 2016, 
the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February 15, 2017,

[0001437749-18-014196:notes:23]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022 (
“U.S. Senior Notes, Series A due 
2022”
), and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
“U.S. Senior Notes, Series B due 
2027”
) (together, the “U.S. Senior Notes due 
2022
 and 
2027”
) were funded. Interest on the U.S. Senior Notes due 
2022
 and 
2027
 is payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

[0001437749-18-014196:notes:24]
On 
 November 15, 2017, 
the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold 
$175
 million in aggregate principal amount of senior notes in 
two
 series. On 
 January 16, 2018,

[0001437749-18-014196:notes:25]
$50
 million aggregate principal amount of 
3.48%
 Senior Notes, Series A, due 
 February 15, 2025 (
“U.S. Senior Notes, Series A due 
2025”
) and 
$125
 million in aggregate principal amount of 
3.78%
 Senior Notes, Series B, due 
 February 15, 2030 (
“U.S. Senior Notes, Series B due 
2030”
) (together the “U.S. Senior Notes due 
2025
 and 
2030”
 and with the Euro Senior Notes and the U.S. Senior Notes 
2022
 and 
2027,
 the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 
2025
 and 
2030
 will be payable on 
 February 15 
and 
 August 15, 
commencing on 
 August 15, 2018.

[0001437749-18-014196:notes:26]
The Senior Notes have 
not
 been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001437749-18-014196:notes:27]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 June 30, 2018, 
the Company was in compliance with all covenants under the Senior Notes.

[0001437749-18-014196:notes:28]
The Company 
 may 
redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-18-014196:notes:29]
|  |  | For the three months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |
| Electronics – Semiconductor |  |  | 171,036 |  |  |  | — |  |  |  | — |  |  |  | 171,036 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,581 |  |  |  | — |  |  |  | 63,581 |  |
| Automotive Sensors |  |  | — |  |  |  | 30,729 |  |  |  | — |  |  |  | 30,729 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 32,862 |  |  |  | — |  |  |  | 32,862 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 32,654 |  |  |  | 32,654 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |

[0001437749-18-014196:notes:30]
|  |  | For the six months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  |  | 320,952 |  |  |  | — |  |  |  | — |  |  |  | 320,952 |  |
| Passenger Car Products |  |  | — |  |  |  | 127,160 |  |  |  | — |  |  |  | 127,160 |  |
| Automotive Sensors |  |  | — |  |  |  | 62,052 |  |  |  | — |  |  |  | 62,052 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 64,090 |  |  |  | — |  |  |  | 64,090 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 59,926 |  |  |  | 59,926 |  |
| Total |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-18-014196:notes:31]
[same as prior period, unchanged from 0001437749-18-008370:notes:30]

[0001437749-18-014196:notes:32]
[same as prior period, unchanged from 0001437749-18-008370:notes:31]

[0001437749-18-014196:notes:33]
[same as prior period, unchanged from 0001437749-18-008370:notes:32]

[0001437749-18-014196:notes:34]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands, except per share amounts) |  | June 30, 2018 |  |  | July 1, 2017 |  |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 42,326 |  |  | $ | 48,638 |  |  | $ | 78,354 |  |  | $ | 87,530 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 25,004 |  |  |  | 22,822 |  |  |  | 24,671 |  |  |  | 22,785 |  |
| Effect of dilutive securities |  |  | 397 |  |  |  | 201 |  |  |  | 415 |  |  |  | 220 |  |
| Diluted |  |  | 25,401 |  |  |  | 23,023 |  |  |  | 25,086 |  |  |  | 23,005 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.69 |  |  | $ | 2.13 |  |  | $ | 3.18 |  |  | $ | 3.84 |  |
| Diluted earnings per share |  | $ | 1.67 |  |  | $ | 2.11 |  |  | $ | 3.12 |  |  | $ | 3.80 |  |

[0001437749-18-014196:notes:35]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 
47,849
 and 
46,100
 for the 
three
 months ended 
 June 30, 2018 
and 
 July 1, 2017, 
respectively, and 
23,659
 and 
21,896
 for the 
six
 months ended 
 June 30, 2018 
and 
 July 1, 2017, 
respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-18-014196:notes:36]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investments in equity securities |  | $ | 15,328 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,328 |  |
| Mutual funds |  |  | 9,950 |  |  |  | — |  |  |  | — |  |  |  | 9,950 |  |

[0001437749-18-014196:notes:37]
[same as prior period, unchanged from 0001437749-18-008370:notes:37]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001437749-18-014196:notes:38]
|  |  | June 30, 2018 |  |  | December 30, 2017 |  |
| (in thousands) |  | Carrying Value |  |  | Estimated Fair Value |  |  | Carrying Value |  |  | Estimated Fair Value |  |
| Euro Senior Notes, Series A due 2023 |  | $ | 135,335 |  |  | $ | 134,332 |  |  | $ | 139,623 |  |  | $ | 138,294 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 109,887 |  |  |  | 107,963 |  |  |  | 113,369 |  |  |  | 111,579 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 24,154 |  |  |  | 25,000 |  |  |  | 24,737 |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 95,711 |  |  |  | 100,000 |  |  |  | 99,992 |  |
| USD Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | 47,769 |  |  |  | — |  |  |  | — |  |
| USD Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | 117,300 |  |  |  | — |  |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-18-014196:notes:39]
6.
 Fair Value of Assets and Liabilities

[0001437749-18-014196:notes:40]
[same as prior period, unchanged from 0001437749-18-008370:notes:41]

[0001437749-18-014196:notes:41]
[same as prior period, unchanged from 0001437749-18-008370:notes:42]

[0001437749-18-014196:notes:42]
[same as prior period, unchanged from 0001437749-18-008370:notes:43]

[0001437749-18-014196:notes:43]
[same as prior period, unchanged from 0001437749-18-008370:notes:44]

[0001437749-18-014196:notes:44]
[same as prior period, unchanged from 0001437749-18-008370:notes:45]

[0001437749-18-014196:notes:45]
[same as prior period, unchanged from 0001437749-18-008370:notes:46]

[0001437749-18-014196:notes:46]
[same as prior period, unchanged from 0001437749-18-008370:notes:47]

[0001437749-18-014196:notes:47]
[same as prior period, unchanged from 0001437749-18-008370:notes:48]

[0001437749-18-014196:notes:48]
[same as prior period, unchanged from 0001437749-18-008370:notes:49]

[0001437749-18-014196:notes:49]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 
1
 of the valuation hierarchy and recorded in other noncurrent assets.

[0001437749-18-014196:notes:50]
[same as prior period, unchanged from 0001437749-18-008370:notes:51]

[0001437749-18-014196:notes:51]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The marketable securities are classified as Level 
1
 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value and recorded in other noncurrent assets.

[0001437749-18-014196:notes:52]
There were 
no
 changes during the quarter ended 
 June 30, 2018 
to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of 
 June 30, 2018, 
and 
 December 30, 2017, 
the Company did

[0001437749-18-014196:notes:53]
not

[0001437749-18-014196:notes:54]
hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-18-014196:notes:55]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of 
 June 30, 2018:

[0001437749-18-014196:notes:56]
[same as prior period, unchanged from 0001437749-18-008370:notes:55]

[0001437749-18-014196:notes:57]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are 
not
 marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at 
 June 30, 2018 
and 
 December 30, 2017, 
as the rates on these borrowings are variable in nature.

[0001437749-18-014196:notes:58]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of 
 June 30, 2018 
and 
 December 30, 2017 
were as follows:


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-18-014196:notes:59]
[same as prior period, unchanged from 0001437749-18-008370:notes:58]

[0001437749-18-014196:notes:60]
The amounts for goodwill and changes in the carrying value by segment for the 
six
 months ended 
 June 30, 2018 
are as follows:

[0001437749-18-014196:notes:61]
| (in thousands) |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| As of December 30, 2017 |  | $ | 278,959 |  |  | $ | 135,829 |  |  | $ | 38,626 |  |  | $ | 453,414 |  |
| Additions(a) |  |  | 382,317 |  |  |  | — |  |  |  | — |  |  |  | 382,317 |  |
| Currency translation |  |  | (1,558 | ) |  |  | (1,748 | ) |  |  | (198 | ) |  |  | (3,504 | ) |
| As of June 30, 2018 |  | $ | 659,718 |  |  | $ | 134,081 |  |  | $ | 38,428 |  |  | $ | 832,227 |  |

[0001437749-18-014196:notes:62]
| (a) | The additions resulted from the acquisition of IXYS. |  |

[0001437749-18-014196:notes:63]
The components of other intangible assets at 
 June 30, 2018 
are as follows:

[0001437749-18-014196:notes:64]
| (in thousands, except weighted average useful life) |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Patents, licenses and software |  |  | 10.6 |  |  | $ | 192,326 |  |  | $ | 67,528 |  |  | $ | 124,798 |  |
| Distribution network |  |  | 12.6 |  |  |  | 44,001 |  |  |  | 33,567 |  |  |  | 10,434 |  |
| Customer relationships, trademarks, and tradenames |  |  | 18.1 |  |  |  | 311,333 |  |  |  | 63,326 |  |  |  | 248,007 |  |
| Order backlog |  |  | 1.0 |  |  |  | 12,420 |  |  |  | 5,607 |  |  |  | 6,813 |  |
| Total |  |  |  |  |  | $ | 560,080 |  |  | $ | 170,028 |  |  | $ | 390,052 |  |

[0001437749-18-014196:notes:65]
During the 
six
 months ended 
 June 30, 2018, 
the Company recorded additions to other intangible assets of 
$212.7
 million, related to the IXYS acquisition, the components of which were as follows:

[0001437749-18-014196:notes:66]
| (in thousands, except weighted average useful life) |  | Weighted Average Useful Life |  |  | Amount |  |
| Patents, licenses and software |  |  | 8.0 |  |  | $ | 51,500 |  |
| Customer relationships, trademarks, and tradenames |  |  | 17.2 |  |  |  | 148,800 |  |
| Order backlog |  |  | 1.0 |  |  |  | 12,420 |  |
| Total |  |  |  |  |  | $ | 212,720 |  |

[0001437749-18-014196:notes:67]
During the 
three
 and 
six
 months ended 
 June 30, 2018 
and 
 July 1, 2017, 
the Company recorded amortization expense of 
$13.4
 million and 
$6.2
 million and 
$25.4
 million and 
$12.1
 million, respectively for intangible assets with definite lives.

[0001437749-18-014196:notes:68]
Estimated annual amortization expense related to intangible assets with definite lives as of 
 June 30, 2018 
is as follows:

[0001437749-18-014196:notes:69]
| (in thousands) |  | Amount |  |
| 2018 |  | $ | 53,440 |  |
| 2019 |  |  | 40,511 |  |
| 2020 |  |  | 40,240 |  |
| 2021 |  |  | 38,457 |  |
| 2022 |  |  | 37,456 |  |
| 2023 and thereafter |  |  | 206,466 |  |
| Total |  | $ | 416,570 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-18-014196:notes:70]
9.
 Income Taxes

[0001437749-18-014196:notes:71]
The effective tax rates for the 
three
 and 
six
 months ended 
 June 30, 2018 
were 
19.1%
 and 
19.2%,
 respectively, compared to effective tax rates for the 
three
 and 
six
 months ended 
 July 1, 2017 
of 
15.2%
 and 
16.5%,
 respectively.

[0001437749-18-014196:notes:72]
The effective tax rates for the 
2018
 periods are higher than the effective tax rates for the 
2017
 periods primarily due to the impact of U.S. tax reform and the acquisition of IXYS. The effective tax rates for the 
2017
 periods were lower than the then applicable 
35%
 U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0001437749-18-014196:notes:73]
[same as prior period, unchanged from 0001437749-18-008370:notes:72]

[0001437749-18-014196:notes:74]
[same as prior period, unchanged from 0001437749-18-008370:notes:73]

[0001437749-18-014196:notes:75]
118,
 in the 
fourth
 quarter of 
2017
 the Company recorded a charge of 
$47
 million as a provisional reasonable estimate of the impact of the Tax Act, including 
$49
 million for the Toll Charge net of 
$2
 million for other net tax benefits. The Company did 
not
 adjust the provisional reasonable estimate in the 
first

[0001437749-18-014196:notes:76]
six
 months of 
2018.
 In addition, the Company recorded a preliminary estimate of 
$10
 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation. This adjustment was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities. The Company is continuing to analyze the Tax Act and plans to finalize the 
2017
 provisional reasonable estimate within the measurement period outlined in SAB 
No.

[0001437749-18-014196:notes:77]
118
 and the IXYS Toll Charge estimate during the purchase price allocation period. The final charges 
 may 
differ from the estimates if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining the estimates, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors. Aside from these interpretation issues, the final charges 
 may 
differ from the estimates due to refinements of accumulated non-U.S. earnings and tax pool data.

[0001437749-18-014196:notes:78]
The Company will elect to pay the 
2017
 (Littelfuse) and 
2018
 (IXYS) Toll Charges over the 
eight
-year period prescribed by the Tax Act. The long-term portion of these Toll Charges totaling 
$38.5
 million (which includes the 
2017
 Littelfuse provisional reasonable estimate and the 
2018
 IXYS provisional reasonable estimate, partially offset by foreign tax credits, the 
first
 annual installment payment and the anticipated 
second
 annual installment) is recorded in the Other long-term liabilities and the short-term portion of 
$3.4
 million is recorded in the Accrued income taxes on the Condensed Consolidated Balance Sheet as of 
 June 30, 2018.

[0001437749-18-014196:notes:79]
The Company recognized deferred tax liabilities of 
$12.0
 million (
$11.8
 million for non-U.S. taxes and 
$0.2
 million for U.S. state taxes) as of 
 December 30, 2017 
related to taxes on certain non-U.S. earnings which are 
not
 considered to be permanently reinvested. Some of these taxes 
 may 
provide a U.S. federal income tax benefit as a foreign tax credit. However, due to uncertainty in regard to the Tax Act’s provisions, 
no
 such tax benefit was recorded as of 
 December 30, 2017, 
and 
no
 such tax benefit was recorded in the 
first

[0001437749-18-014196:notes:80]
six
 months of 
2018.
 The Company will reconsider this provisional conclusion when it finalizes its 
2017
 preliminary reasonable estimate of the impact of the Tax Act, based upon interpretations and administrative guidance as of that time.

[0001437749-18-014196:notes:81]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has 
not
 adopted an accounting policy for GILTI. Thus, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions. The Company intends to adopt an accounting policy for GILTI within the measurement period outlined in SAB 
118.
 Although such an accounting policy has 
not
 been adopted, the Company considered GILTI when determining the current portion of income tax expense recorded for the 
second
 quarter and 
first

[0001437749-18-014196:notes:82]
six
 months of 
2018.

[0001437749-18-014196:notes:83]
Although certain administrative guidance has been issued, the appropriate application of many provisions of the Tax Act remain uncertain. The Company used its best judgement as to the application of these provisions in determining its income tax expense for the 
second
 quarter and 
first
 half of 
2018.
 Adjustments to income tax expense related to the 
first
 half of 
2018

[0001437749-18-014196:notes:84]
may 
be necessary if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining its estimates, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-18-014196:notes:85]
3.
 Inventories

[0001437749-18-014196:notes:86]
The components of inventories at 
 June 30, 2018 
and 
 December 30, 2017 
are as follows:

[0001437749-18-014196:notes:87]
| (in thousands) |  | June 30, 2018 |  |  | December 30, 2017 |  |
| Raw materials |  | $ | 65,607 |  |  | $ | 39,030 |  |
| Work in process |  |  | 81,448 |  |  |  | 27,454 |  |
| Finished goods |  |  | 92,146 |  |  |  | 74,305 |  |
| Total |  | $ | 239,201 |  |  | $ | 140,789 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-18-014196:notes:88]
2.
 Acquisitions

[0001437749-18-014196:notes:89]
[same as prior period, unchanged from 0001437749-18-008370:notes:85]

[0001437749-18-014196:notes:90]
[same as prior period, unchanged from 0001437749-18-008370:notes:86]

[0001437749-18-014196:notes:91]
[same as prior period, unchanged from 0001437749-18-008370:notes:87]

[0001437749-18-014196:notes:92]
[same as prior period, unchanged from 0001437749-18-008370:notes:88]

[0001437749-18-014196:notes:93]
Based on the 
$207.5
 per share opening price of Littelfuse common stock on 
 January 17, 2018, 
the consideration IXYS stockholders received in exchange of their IXYS common stock in the acquisition had a value of 
$814.8
 million comprised of 
$380.6
 million of cash and 
$434.2
 million of Littelfuse stock. In addition to the consideration transferred related to IXYS common stock, the value of consideration transferred, and included in the purchase price, related to IXYS stock options that were converted to Littelfuse stock options, or cash settled, had a value of 
$41.7
 million. As a result, total consideration was valued at 
$856.5
 million.

[0001437749-18-014196:notes:94]
The total purchase price of 
$856.5
 million has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary areas that are 
not
 yet finalized relate to the completion of the valuations of certain acquired income tax assets and liabilities, including the impact of the adoption of the Tax Act. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0001437749-18-014196:notes:95]
[same as prior period, unchanged from 0001437749-18-008370:notes:91]

[0001437749-18-014196:notes:96]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash, net of cash acquired |  | $ | 302,865 |  |
| Cash settled stock options |  |  | 3,622 |  |
| Littelfuse stock |  |  | 434,192 |  |
| Converted stock options |  |  | 38,109 |  |
| Total purchase consideration |  | $ | 778,788 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 155,959 |  |
| Property, plant, and equipment |  |  | 77,442 |  |
| Intangible assets |  |  | 212,720 |  |
| Goodwill |  |  | 382,317 |  |
| Other non-current assets |  |  | 31,570 |  |
| Other non-current liabilities |  |  | (81,220 | ) |
|  |  | $ | 778,788 |  |

[0001437749-18-014196:notes:97]
[same as prior period, unchanged from 0001437749-18-008370:notes:93]

[0001437749-18-014196:notes:98]
Included in the Company’s Condensed Consolidated Statements of Net Income for the 
three
 and 
six
 months ended 
 June 30, 2018 
are net sales of approximately 
$100.2
 million and 
$186.5
 million, respectively and a loss before income taxes of 
$13.9
 million and 
$31.7
 million, respectively since the 
 January 17, 2018 
acquisition of IXYS. The Company recognized approximately 
$1.6
 million and 
$7.5
 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the 
three
 and 
six
 months ended 
 June 30, 2018, 
of which 
$4.5
 million was recognized immediately as it related to prior services periods.

[0001437749-18-014196:notes:99]
As required by purchase accounting rules, the Company recorded a 
$36.9
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the 
first
 and 
second
 quarters of 
2018,
 as the acquired inventory was sold, and reflected as other non-segment costs. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company recognized a charge of 
$19.0
 million and 
$36.9
 million, respectively, for the amortization of this fair value inventory step-up.

[0001437749-18-014196:notes:100]
During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company incurred approximately 
$0.8
 million and 
$11.0
 million, respectively, of legal and professional fees related to this acquisition which were primarily recognized as 
selling, general, and administrative expenses
. These costs were reflected as other non-segment costs.

[0001437749-18-014196:notes:101]
2017

[0001437749-18-014196:notes:102]
Acquisitions

[0001437749-18-014196:notes:103]
[same as prior period, unchanged from 0001437749-18-008370:notes:98]

[0001437749-18-014196:notes:104]
[same as prior period, unchanged from 0001437749-18-008370:notes:99]

[0001437749-18-014196:notes:105]
[same as prior period, unchanged from 0001437749-18-008370:notes:100]

[0001437749-18-014196:notes:106]
[same as prior period, unchanged from 0001437749-18-008370:notes:101]

[0001437749-18-014196:notes:107]
[same as prior period, unchanged from 0001437749-18-008370:notes:102]

[0001437749-18-014196:notes:108]
[same as prior period, unchanged from 0001437749-18-008370:notes:103]

[0001437749-18-014196:notes:109]
[same as prior period, unchanged from 0001437749-18-008370:notes:104]

[0001437749-18-014196:notes:110]
[same as prior period, unchanged from 0001437749-18-008370:notes:105]

[0001437749-18-014196:notes:111]
On 
 February 28, 2017, 
pursuant to a Securities Purchase Agreement between the Company and the stockholders of Monolith (“Securities Purchase Agreement”) and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired 
62%
 of the outstanding common stock of Monolith for 
$15
 million. The Securities Purchase Agreement includes provisions whereby the Company will acquire the remaining outstanding stock of Monolith (“non-controlling interest”) at a time or times based on Monolith meeting certain technical and sales targets. During the 
first
 quarter of 
2018,
 Monolith met the next set of technical and sales targets. As a result, and pursuant to the Securities Purchase Agreement, in 
 April 2018 
the Company acquired an additional 
19%
 of the outstanding common stock of Monolith for 
$5
 million, of which 
$4
 million was paid to the stockholders of Monolith. Consideration for the purchase of the remaining 
19%
 outstanding common stock will be either 
$0.5
 million or 
$5
 million, based on Monolith meeting the remaining technical and sales targets, and will be paid 
no
 later than 
 June 30, 2019.

[0001437749-18-014196:notes:112]
[same as prior period, unchanged from 0001437749-18-008370:notes:107]

[0001437749-18-014196:notes:113]
[same as prior period, unchanged from 0001437749-18-008370:notes:108]

[0001437749-18-014196:notes:114]
[same as prior period, unchanged from 0001437749-18-008370:notes:109]

[0001437749-18-014196:notes:115]
[same as prior period, unchanged from 0001437749-18-008370:notes:110]

[0001437749-18-014196:notes:116]
[same as prior period, unchanged from 0001437749-18-008370:notes:111]

[0001437749-18-014196:notes:117]
[same as prior period, unchanged from 0001437749-18-008370:notes:112]

[0001437749-18-014196:notes:118]
[same as prior period, unchanged from 0001437749-18-008370:notes:113]

[0001437749-18-014196:notes:119]
[same as prior period, unchanged from 0001437749-18-008370:notes:114]

[0001437749-18-014196:notes:120]
[same as prior period, unchanged from 0001437749-18-008370:notes:115]

[0001437749-18-014196:notes:121]
[same as prior period, unchanged from 0001437749-18-008370:notes:116]

[0001437749-18-014196:notes:122]
|  | (a) | The amortization adjustment for the six months ended June 30, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and will be fully amortized in the fiscal 2017 pro forma results. The amortization adjustment for the three and six months ended July 1, 2017 reflects incremental amortization resulting for the measurement of intangibles at their fair values. |
|  | (b) | The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the six months ended June 30, 2018 and recognition of those fees during the six months ended July 1, 2017. |

[0001437749-18-014196:notes:123]
|  | (c) | The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the six months ended June 30, 2018 and the recognition of the full amortization during the six months end July 1, 2017. The inventory step-up was amortized over five months as the inventory is sold. |

[0001437749-18-014196:notes:124]
|  | (d) | The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the six months ended June 30, 2018. The adjustment for the six months ended July 1, 2017 reflect the incremental stock compensation for the converted stock options. |

[0001437749-18-014196:notes:125]
[same as prior period, unchanged from 0001437749-18-008370:notes:121]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-18-014196:notes:126]
Recently Adopted Accounting Standards

[0001437749-18-014196:notes:127]
In 
 March 2017, 
the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 
No.

[0001437749-18-014196:notes:128]
2017
-
07
 “Compensation-Retirement Benefits (Topic 
715
): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the previous guidance, net benefit cost was reported as an employee cost within operating income. The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU 
No.

[0001437749-18-014196:notes:129]
2017
-
07
 was effective for the 
first
 quarter of 
2018
 with the Company adopting the new standard on 
 December 31, 2017.

[0001437749-18-014196:notes:130]
In 
 January 2016, 
the FASB issued ASU 
No.

[0001437749-18-014196:notes:131]
2016
-
01,
 “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on 
 December 31, 2017, 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings. As a result of the adoption of the new standard and change in fair value of our equity investments, for the 
six
 months ended 
 June 30, 2018, 
the Company recognized an unrealized gain of 
$2.8
 million in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.

[0001437749-18-014196:notes:132]
In 
 May 2014, 
the FASB issued ASU 
No.

[0001437749-18-014196:notes:133]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on 
 December 31, 2017 
using the modified retrospective method, however, 
no
 adjustment to retained earnings was needed. The new guidance did 
not
 have a material effect on the Company’s Condensed Consolidated Statements of Income. See the 
Revenue Recognition
 section above for further discussion.

[0001437749-18-014196:notes:134]
In 
 October 2016, 
the FASB issued ASU 
No.

[0001437749-18-014196:notes:135]
2016
-
16,
 "Income Taxes” (Topic 
740
). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on 
 December 31, 2017 
and it did 
not
 have a material impact.

[0001437749-18-014196:notes:136]
Recently Issued Accounting Standards

[0001437749-18-014196:notes:137]
In 
 February 2016, 
the FASB issued ASU 
No.

[0001437749-18-014196:notes:138]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the 
first
 quarter of 
2019.
 The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has 
not
 yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.

[0001437749-18-014196:notes:139]
In 
 January 2018, 
the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions of the 
2017
 U.S. Tax Cuts and Jobs Act (the “Tax Act”). The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has 
not
 yet completed its assessment and therefore has 
not
 yet elected an accounting policy.

[0001437749-18-014196:notes:140]
In 
 February 2018, 
the FASB issued ASU 
No.

[0001437749-18-014196:notes:141]
2018
-
02
 “Income Statement—Reporting Comprehensive Income (Topic 
220
): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or 
not
 they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 
2018
-
02
 will be effective in the 
first
 quarter of 
2019;
 however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 
2018
-
02
 on the Consolidated Financial Statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-18-014196:notes:142]
[same as prior period, unchanged from 0001437749-18-008370:notes:138]

[0001437749-18-014196:notes:143]
[same as prior period, unchanged from 0001437749-18-008370:notes:139]

[0001437749-18-014196:notes:144]
[same as prior period, unchanged from 0001437749-18-008370:notes:140]

[0001437749-18-014196:notes:145]
The Company recognizes interest costs, expected return on plan assets, and amortization, net within 
Other (income) expense, net
 in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the 
three
 and 
six
 months ended 
 June 30, 2018 
and 
 July 1, 2017 
were as follows:

[0001437749-18-014196:notes:146]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands) |  | June 30, 2018 |  |  | July 1, 2017 |  |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 533 |  |  | $ | 408 |  |  | $ | 1,066 |  |  | $ | 816 |  |
| Interest cost |  |  | 501 |  |  |  | 360 |  |  |  | 1,002 |  |  |  | 720 |  |
| Expected return on plan assets |  |  | (540 | ) |  |  | (476 | ) |  |  | (1,080 | ) |  |  | (952 | ) |
| Amortization of prior service (credit) |  |  | 74 |  |  |  | 84 |  |  |  | 148 |  |  |  | 168 |  |
| Net periodic benefit cost |  | $ | 568 |  |  | $ | 376 |  |  | $ | 1,136 |  |  | $ | 752 |  |

[0001437749-18-014196:notes:147]
[same as prior period, unchanged from 0001437749-18-008370:notes:143]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001437749-18-014196:notes:148]
11.
 Related Party Transactions

[0001437749-18-014196:notes:149]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0001437749-18-014196:notes:150]
Powersem GmbH:
 The Company owns 
45%
 of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company recorded revenues of 
$0.3
 million and 
$0.4
 million, respectively from sales of products to Powersem for use as components in their products. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company purchased 
$1.0
 million and 
$2.1
 million, respectively of products from Powersem. At 
 June 30, 2018, 
the accounts receivable balance from Powersem was 
$0.1
 million and the accounts payable balance to Powersem was 
$0.3
 million.

[0001437749-18-014196:notes:151]
EB Tech Ltd.:
 The Company owns approximately 
20%
 of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the 
three
 and 
six
 months ended 
 June 30, 2018 
EB Tech rendered processing services for the Company totaling approximately 
$0.1
 million and 
$0.2
 million, respectively. As of 
 June

[0001437749-18-014196:notes:152]
2018,
 the Company’s accounts payable balance to EB Tech was immaterial.

[0001437749-18-014196:notes:153]
Automated Technology, Inc.
: The Company owns approximately 
24%
 of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
ATEC rendered assembly and test services to the Company totaling approximately 
$2.8
 million and 
$5.2
 million, respectively. As of 
 June

[0001437749-18-014196:notes:154]
2018,
 the Company’s accounts payable balance to ATEC was 
$0.7
 million.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001437749-18-014196:notes:155]
[same as prior period, unchanged from 0001437749-18-008370:notes:156]

[0001437749-18-014196:notes:156]
[same as prior period, unchanged from 0001437749-18-008370:notes:157]

[0001437749-18-014196:notes:157]
[same as prior period, unchanged from 0001437749-18-008370:notes:158]

[0001437749-18-014196:notes:158]
[same as prior period, unchanged from 0001437749-18-008370:notes:159]

[0001437749-18-014196:notes:159]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 and 
six
 months ended 
 June 30, 2018:

[0001437749-18-014196:notes:160]
[same as prior period, unchanged from 0001437749-18-008370:notes:161]

[0001437749-18-014196:notes:161]
[same as prior period, unchanged from 0001437749-18-008370:notes:162]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-18-014196:notes:162]
[same as prior period, unchanged from 0001437749-18-008370:notes:163]

[0001437749-18-014196:notes:163]
[same as prior period, unchanged from 0001437749-18-008370:notes:164]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001437749-18-014196:notes:164]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments (a) |  |  | Unrealized gain/(loss) on investments |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 30, 2017 |  | $ | (10,836 | ) |  | $ | 9,795 |  |  | $ | (62,627 | ) |  | $ | (63,668 | ) |
| Cumulative effect adjustment (b) |  |  | — |  |  |  | (9,795 | ) |  |  | — |  |  |  | (9,795 | ) |
| Activity in the period |  |  | 763 |  |  |  | — |  |  |  | (16,984 | ) |  |  | (16,221 | ) |
| Balance at June 30, 2018 |  | $ | (10,073 | ) |  | $ | — |  |  | $ | (79,611 | ) |  | $ | (89,684 | ) |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-18-014196:notes:165]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands) |  | June 30, 2018 |  |  | July 1, 2017 |  |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 137,236 |  |  | $ | 100,648 |  |  | $ | 261,112 |  |  | $ | 187,306 |  |
| China(a) |  |  | 127,776 |  |  |  | 86,891 |  |  |  | 234,284 |  |  |  | 165,111 |  |
| Other countries(b) |  |  | 194,171 |  |  |  | 125,816 |  |  |  | 381,600 |  |  |  | 246,380 |  |
| Total net sales |  | $ | 459,183 |  |  | $ | 313,355 |  |  | $ | 876,996 |  |  | $ | 598,797 |  |

[0001437749-18-014196:notes:166]
| (in thousands) |  | June 30, 2018 |  |  | December 30, 2017 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 59,097 |  |  | $ | 23,490 |  |
| China(a) |  |  | 92,832 |  |  |  | 86,866 |  |
| Mexico |  |  | 66,063 |  |  |  | 62,510 |  |
| Germany |  |  | 35,013 |  |  |  | 1,082 |  |
| Philippines |  |  | 31,481 |  |  |  | 31,129 |  |
| Other countries |  |  | 54,269 |  |  |  | 45,500 |  |
| Total long-lived assets |  | $ | 338,755 |  |  | $ | 250,577 |  |

[0001437749-18-014196:notes:167]
|  |  | For the Six Months Ended |  |
| (in thousands) |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 4,234 |  |  | $ | 1,149 |  |
| China(a) |  |  | 14,711 |  |  |  | 10,200 |  |
| Mexico |  |  | 8,874 |  |  |  | 10,925 |  |
| Germany |  |  | 5,182 |  |  |  | - |  |
| Philippines |  |  | 4,241 |  |  |  | 1,345 |  |
| Other countries |  |  | 3,073 |  |  |  | 5,259 |  |
| Total additions to long-lived assets |  | $ | 40,315 |  |  | $ | 28,878 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-18-014196:notes:168]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands) |  | June 30, 2018 |  |  | July 1, 2017 |  |  | June 30, 2018 |  |  | July 1, 2017 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 299,357 |  |  | $ | 169,387 |  |  | $ | 563,768 |  |  | $ | 323,154 |  |
| Automotive |  |  | 127,172 |  |  |  | 116,457 |  |  |  | 253,302 |  |  |  | 224,297 |  |
| Industrial |  |  | 32,654 |  |  |  | 27,511 |  |  |  | 59,926 |  |  |  | 51,346 |  |
| Total net sales |  | $ | 459,183 |  |  | $ | 313,355 |  |  | $ | 876,996 |  |  | $ | 598,797 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,651 |  |  | $ | 8,707 |  |  | $ | 29,329 |  |  | $ | 17,095 |  |
| Automotive |  |  | 5,969 |  |  |  | 5,580 |  |  |  | 11,939 |  |  |  | 10,950 |  |
| Industrial |  |  | 1,467 |  |  |  | 1,330 |  |  |  | 2,927 |  |  |  | 2,645 |  |
| Other |  |  | 3,103 |  |  |  | - |  |  |  | 5,607 |  |  |  | - |  |
| Total depreciation and amortization |  | $ | 26,190 |  |  | $ | 15,617 |  |  | $ | 49,802 |  |  | $ | 30,690 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 67,311 |  |  | $ | 42,967 |  |  | $ | 121,275 |  |  | $ | 78,173 |  |
| Automotive |  |  | 15,711 |  |  |  | 15,713 |  |  |  | 34,102 |  |  |  | 30,778 |  |
| Industrial |  |  | 5,279 |  |  |  | 1,905 |  |  |  | 9,988 |  |  |  | 2,012 |  |
| Other(a) |  |  | (28,679 | ) |  |  | (315 | ) |  |  | (68,172 | ) |  |  | (1,840 | ) |
| Total operating income |  |  | 59,622 |  |  |  | 60,270 |  |  |  | 97,193 |  |  |  | 109,123 |  |
| Interest expense |  |  | 5,782 |  |  |  | 3,281 |  |  |  | 11,205 |  |  |  | 6,401 |  |
| Foreign exchange loss (gain) |  |  | 3,200 |  |  |  | (558 | ) |  |  | (7,354 | ) |  |  | (2,115 | ) |
| Other expense (income), net |  |  | (1,678 | ) |  |  | 190 |  |  |  | (3,621 | ) |  |  | 52 |  |
| Income before income taxes |  | $ | 52,318 |  |  | $ | 57,357 |  |  | $ | 96,963 |  |  | $ | 104,785 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001437749-18-014196:notes:169]
| (in thousands) |  | Littelfuse, Inc. Shareholders’ Equity |  |  | Non- controlling Interest |  |  | Total |  |
| Balance at December 30, 2017 |  | $ | 927,419 |  |  | $ | 137 |  |  | $ | 927,556 |  |
| Net income |  |  | 78,354 |  |  |  | — |  |  |  | 78,354 |  |
| Other comprehensive income (loss) |  |  | (16,221 | ) |  |  | — |  |  |  | (16,221 | ) |
| Stock-based compensation |  |  | 15,883 |  |  |  | — |  |  |  | 15,883 |  |
| Withheld shares on restricted share units for withholding taxes |  |  | (7,042 | ) |  |  | — |  |  |  | (7,042 | ) |
| Stock options exercised |  |  | 17,654 |  |  |  | — |  |  |  | 17,654 |  |
| Issuance of common stock(a) |  |  | 472,301 |  |  |  | — |  |  |  | 472,301 |  |
| Cash dividends paid ($0.37 per share) |  |  | (18,458 | ) |  |  | — |  |  |  | (18,458 | ) |
| Non-controlling interest |  |  | — |  |  |  | (7 | ) |  |  | (7 | ) |
| Balance at June 30, 2018 |  | $ | 1,469,890 |  |  | $ | 130 |  |  | $ | 1,470,020 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-18-014196:notes:170]
12.
 Segment Information

[0001437749-18-014196:notes:171]
The Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it 
 may 
earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does 
not
 evaluate the operating segments using discrete balance sheet information.

[0001437749-18-014196:notes:172]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the 
three
 operating segments. The Company does 
not
 report inter-segment revenue because the operating segments do 
not
 record it. Certain expenses, determined by the CODM to be strategic in nature and 
not
 directly related to segments current results, are 
not
 allocated but identified as “Other”. Additionally, the Company does 
not
 allocate interest and other income, interest expense, or taxes to operating segments. These costs are 
not
 allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in 
one
 segment 
 may 
benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001437749-18-014196:notes:173]
|  | ● | Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, gas discharge tubes; semiconductor and power semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon carbide, metal-oxide-semiconductor field-effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including consumer electronics, automotive electronics, IT and telecommunications equipment, medical devices, lighting products, and white goods. |
|  | ● | Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in the automotive, commercial vehicle, and agricultural and construction equipment industries. Passenger car fuse products include fuses and fuse accessories, including blade fuses, battery cable protectors, varistors, high-current fuses, and high-voltage fuses for hybrid and electric vehicles. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle sensors designed to monitor the passenger compartment occupants and environment as well as the vehicle’s powertrain, emissions, speed and suspension. |
|  | ● | Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in heavy industrial applications such as mining, oil and gas, energy storage, construction, HVAC systems, elevator and other industrial equipment. |

[0001437749-18-014196:notes:174]
[same as prior period, unchanged from 0001437749-18-008370:notes:178]

[0001437749-18-014196:notes:175]
(a) Included in “Other” Operating income (loss) for the 
2018

[0001437749-18-014196:notes:176]
second
 quarter is 
$24.4
 million (
$63.2
 million year-to-date) of charges primarily related to IXYS acquisition and include 
$19.0
 million (
$36.9
 million year-to-date) of purchase accounting inventory charges, 
$2.3
 million (
$14.1
 million year-to-date) in acquisition-related and integration costs primarily related to legal, accounting and other expenses associated with the acquisition of IXYS, 
$3.1
 million (
$5.6
 million year-to-date) in backlog amortization costs, stock compensation expense recognized immediately upon close for converted IXYS options related to prior services periods 
$4.5
 million year-to-date and other charges of 
$2.1
 million year-to-date. In addition, there were 
$3.2
 million (
$3.9
 million year-to-date) of severance and other restructuring charges and 
$1.1
 million of impairment charges (
$1.1
 million year-to-date) associated with the exit of the Radio Pulse and Custom businesses, respectively.

[0001437749-18-014196:notes:177]
Included in “Other” Operating income (loss) for the 
2017

[0001437749-18-014196:notes:178]
second
 quarter is of 
$0.3
 million (
$1.8
 million year-to-date) of acquisition and integration costs associated with the Company’s 
2016
 acquisitions (included in Cost of sales (“COS”) and Selling, general, and administrative expenses (“SG&A”)).

[0001437749-18-014196:notes:179]
The Company’s net sales by country are as follows:

[0001437749-18-014196:notes:180]
(a) Includes mainland China, Taiwan, and Hong Kong.
 (b) Each country included in Other countries are less than 
10%
 of net sales.

[0001437749-18-014196:notes:181]
The Company’s long-lived assets by country, as of 
 June 30, 2018 
and 
 December 30, 2017, 
were as follows:

[0001437749-18-014196:notes:182]
[same as prior period, unchanged from 0001437749-18-008370:notes:182]

[0001437749-18-014196:notes:183]
[same as prior period, unchanged from 0001437749-18-008370:notes:185]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-18-014196:notes:184]
[same as prior period, unchanged from 0001437749-18-008370:notes:186]

[0001437749-18-014196:notes:185]
[same as prior period, unchanged from 0001437749-18-008370:notes:187]

[0001437749-18-014196:notes:186]
[same as prior period, unchanged from 0001437749-18-008370:notes:188]

[0001437749-18-014196:notes:187]
Ship and Debit Program

[0001437749-18-014196:notes:188]
[same as prior period, unchanged from 0001437749-18-008370:notes:192]

[0001437749-18-014196:notes:189]
[same as prior period, unchanged from 0001437749-18-008370:notes:193]

[0001437749-18-014196:notes:190]
[same as prior period, unchanged from 0001437749-18-008370:notes:194]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-18-014196:notes:191]
8.
 Shareholders’ Equity

[0001437749-18-014196:notes:192]
The following table sets forth the changes in shareholders’ equity for the 
six
 months ended 
 June 30, 2018:

[0001437749-18-014196:notes:193]
(a) The issuance of common stock (
2,092,491
 shares) during the 
six
 months ended 
 June 30, 2018 
relates to the acquisition of IXYS. See Note 
2,

[0001437749-18-014196:notes:194]
[same as prior period, unchanged from 0001437749-18-008370:notes:200]

[0001437749-18-014196:notes:195]
The following table sets forth the changes in the components of Accumulated Other Comprehensive Income (Loss) by component for the 
three
 months ended 
 June 30, 2018:

[0001437749-18-014196:notes:196]
(a) The balances at 
 June 30, 2018 
and 
 December 30, 2017 
are net of taxes of 
$0.4
 million and 
$1.4
 million, respectively.

[0001437749-18-014196:notes:197]
(b) The Company adopted ASU 
2016
-
01
 on 
 December 31, 2017 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings. See Note 
1,

[0001437749-18-014196:notes:198]
[same as prior period, unchanged from 0001437749-18-008370:notes:204]
