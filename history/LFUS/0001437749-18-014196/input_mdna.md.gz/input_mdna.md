# LFUS MD&A — 0001437749-18-014196


## mdna

[0001437749-18-014196:mdna:1]
[same as prior period, unchanged from 0001437749-18-008370:mdna:1]

[0001437749-18-014196:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-18-014196:mdna:3]
[same as prior period, unchanged from 0001437749-18-008370:mdna:3]

[0001437749-18-014196:mdna:4]
[same as prior period, unchanged from 0001437749-18-008370:mdna:4]

[0001437749-18-014196:mdna:5]
[same as prior period, unchanged from 0001437749-18-008370:mdna:5]

[0001437749-18-014196:mdna:6]
Founded in 1927, Littelfuse is a global leader in circuit protection products with advancing platforms in power control and sensor technologies, serving customers in the electronics, automotive, and industrial markets. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy, ranging across consumer electronics, IT and telecommunication applications, industrial electronics, automobiles and other transportation, and heavy industrial applications.

[0001437749-18-014196:mdna:7]
[same as prior period, unchanged from 0001437749-18-008370:mdna:7]

[0001437749-18-014196:mdna:8]
[same as prior period, unchanged from 0001437749-18-008370:mdna:8]

[0001437749-18-014196:mdna:9]
For the second quarter of 2018, the Company recognized net sales of $459.2 million compared to $313.4 million in the second quarter of 2017 representing an increase of $145.8 million, or 46.5%. The increase was primarily driven by the acquisition of IXYS, which added $100.2 million in sales along with higher volume across all three segments. Net sales for Electronics increased $130.0 million, or 76.7%, primarily due to the acquisition of IXYS and strong growth across all the business units and favorable changes in foreign exchange rates of $8.0 million. Net sales for the Automotive segment increased $10.7 million, or 9.2% due to volume growth across all the segment’s business units. Net sales in the Industrial segment increased $5.1 million or 18.7% due to volume growth across all the segment’s business units. The Company recognized net income of $42.3 million, or $1.67 per diluted share, in the second quarter of 2018 compared to net income of $48.6 million, or $2.11 per diluted share in the second quarter of 2017. The decrease in net income reflects the impact of $19.0 million of purchase accounting inventory charges, higher amortization expense of $7.2 million and foreign exchange losses of $3.2 million that were partially offset by the acquisition of IXYS and operating income increases across the Electronics and Industrial segments. Additionally, the per share results reflect an increase in the weighted average diluted shares outstanding of 2.1 million resulting from the shares issued in conjunction with the acquisition of IXYS.

[0001437749-18-014196:mdna:10]
Net cash provided by operating activities was $140.9 million for the six months ended June 30, 2018 as compared to $93.6 million for the six months ended July 1, 2017. The increase in net cash provided by operating activities reflected higher earnings and favorable working capital management that more than offset higher payments related to acquisition and integration costs and higher cash taxes.

[0001437749-18-014196:mdna:11]
During the second quarter of 2018, the Company announced as part of its strategic assessment and cost savings initiatives, the exit of the Custom business within the Industrial segment and the Radio Pulse business within the IXYS acquisition. The Company does not expect the exit of these businesses to have a material impact on the Company's future net sales and net earnings. The exit of the Custom business resulted in total impairment charges of $1.1 million for the tradename and real property. The exit of the Radio Pulse business resulted in restructuring charges of $2.1 million, of which $1.4 million was for severance charges and $0.7 million of other restructuring charges. The Company expects to realize future cost savings resulting from these restructuring activities.

[0001437749-18-014196:mdna:12]
On July 6, 2018, the Trump administration imposed Section 301 tariffs on products that are imported into the United States where the country of origin is China. This tariff primarily impacts our Electronics segment and to a lesser extent our Automotive and Industrial segments. The Company is currently evaluating the impact on our future results of operations.

[0001437749-18-014196:mdna:13]
[same as prior period, unchanged from 0001437749-18-008370:mdna:12]

[0001437749-18-014196:mdna:14]
The following table summarizes the Company’s consolidated results of operations for the periods presented. The second quarter of 2018 includes $28.7 million of non-segment charges. The charges related to the IXYS acquisition total $24.4 million ($63.2 million year-to-date) and include $19.0 million ($36.9 million year-to-date) of purchase accounting inventory charges, $2.3 million ($14.1 million year-to-date) in acquisition-related and integration costs primarily related to legal, accounting and other expenses associated with the acquisition of IXYS, $3.1 million ($5.6 million year-to-date) in backlog amortization costs, stock compensation expense recognized immediately upon close for converted IXYS options related to prior services periods of $4.5 million year-to-date and other charges of $2.1 million year-to-date. In addition, there were $3.2 million ($3.9 million year-to-date) of severance and other restructuring charges and $1.1 million of impairment charges ($1.1 million year-to-date) associated with the exit of the Radio Pulse and Custom businesses, respectively.

[0001437749-18-014196:mdna:15]
The second quarter of 2017 includes approximately $0.3 million of non-segment charges ($1.8 million year-to-date). These were primarily attributable to acquisition-related costs primarily related to legal and integration costs associated with the Company’s acquisitions in 2016 of the ON Portfolio.

[0001437749-18-014196:mdna:16]
|  |  | Second Quarter |  |  | First Six Months |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |
| Net sales |  | $ | 459,183 |  |  | $ | 313,355 |  |  | $ | 145,828 |  |  |  | 46.5 | % |  | $ | 876,996 |  |  | $ | 598,797 |  |  | $ | 278,199 |  |  |  | 46.5 | % |
| Gross profit |  |  | 168,987 |  |  |  | 132,608 |  |  |  | 36,379 |  |  |  | 27.4 | % |  |  | 318,610 |  |  |  | 246,258 |  |  |  | 72,352 |  |  |  | 29.4 | % |
| Operating expenses |  |  | 109,365 |  |  |  | 72,338 |  |  |  | 37,027 |  |  |  | 51.2 | % |  |  | 221,417 |  |  |  | 137,135 |  |  |  | 84,282 |  |  |  | 61.5 | % |
| Operating income |  |  | 59,622 |  |  |  | 60,270 |  |  |  | (648 | ) |  |  | (1.1% | ) |  |  | 97,193 |  |  |  | 109,123 |  |  |  | (11,930 | ) |  |  | (10.9% | ) |
| Income before income taxes |  |  | 52,318 |  |  |  | 57,357 |  |  |  | (5,039 | ) |  |  | (8.8% | ) |  |  | 96,963 |  |  |  | 104,785 |  |  |  | (7,822 | ) |  |  | (7.5% | ) |
| Income taxes |  |  | 9,992 |  |  |  | 8,719 |  |  |  | 1,273 |  |  |  | 14.6 | % |  |  | 18,609 |  |  |  | 17,255 |  |  |  | 1,354 |  |  |  | 7.8 | % |
| Net income |  | $ | 42,326 |  |  | $ | 48,638 |  |  | $ | (6,312 | ) |  |  | 13.0 | % |  | $ | 78,354 |  |  | $ | 87,530 |  |  | $ | (9,176 | ) |  |  | (10.5% | ) |

[0001437749-18-014196:mdna:17]
[same as prior period, unchanged from 0001437749-18-008370:mdna:17]

[0001437749-18-014196:mdna:18]
Net sales increased $145.8 million, or 46.5%, for the second quarter of 2018 compared to the second quarter of 2017 with increases of $100.2 million and $3.4 million resulting from incremental net sales related to the IXYS and U.S. Sensor acquisitions, respectively. The remaining increase in net sales was driven by higher volume across all businesses in the Electronics, Automotive and Industrial segments and $8.0 million of favorable changes in foreign exchange rates.

[0001437749-18-014196:mdna:19]
Net sales for the first six months of 2018 increased $278.2 million, or 46.5%, compared to the first six months of 2017 with increases of $186.5 million and $6.5 million resulting from incremental net sales related to the IXYS and U.S. Sensor acquisitions, respectively. The remaining increase in net sales was driven by higher volume across all businesses in the Electronics, Automotive and Industrial segments and $21.1 million of favorable changes in foreign exchange rates.

[0001437749-18-014196:mdna:20]
[same as prior period, unchanged from 0001437749-18-008370:mdna:19]

[0001437749-18-014196:mdna:21]
Gross profit was $169.0 million, or 36.8% of net sales, in the second quarter of 2018, compared to $132.6 million, or 42.3% of net sales, in the second quarter of 2017. The increase in gross profit reflects the impact of the IXYS acquisition and volume growth across all segments. The decrease in gross margin is primarily due to the purchase accounting inventory charges of $19.0 million which negatively impacted the second quarter of 2018 gross margin by 4.1 percentage points and unfavorable mix in products from the IXYS acquisition.

[0001437749-18-014196:mdna:22]
Gross profit was $318.6 million, or 36.3% of net sales, in the first six months of 2018, compared to $246.3 million, or 41.1% of net sales in the first six months of 2017. The increase in gross profit reflects the IXYS acquisition and volume growth across all segments and expense leverage across all segments. The decrease in gross margin is primarily due to the purchase accounting inventory charges of $36.9 million which negatively impacted the first six months of 2018 gross margin by 4.2 percentage points.

[0001437749-18-014196:mdna:23]
[same as prior period, unchanged from 0001437749-18-008370:mdna:21]

[0001437749-18-014196:mdna:24]
Total operating expenses were $109.4 million, or 23.8% of net sales, for the second quarter of 2018 compared to $72.3 million, or 23.1% of net sales, for the second quarter of 2017. The increase in operating expenses of $37.1 million is primarily due to incremental operating expenses related to the IXYS and U.S. Sensor acquisitions, an increase in amortization expense of $7.2 million resulting from the acquisition of IXYS, higher acquisition-related and integration costs of $2.0 million, and higher restructuring and impairment charges.

[0001437749-18-014196:mdna:25]
Total operating expense for the first six months of 2018 was $221.4 million, or 25.2% of net sales, compared to $137.1 million, or 22.9% of net sales, for the first six months of 2017. The increase in operating expenses of $84.3 million is primarily due to incremental operating expenses related to the IXYS and U.S. Sensor acquisitions, an increase in amortization expense of $13.3 million resulting from the acquisition of IXYS as well as higher acquisition-related and integration costs of $12.3 million. Total operating expenses as a percent of net sales increased from 22.9% for the first six months of 2017 to 25.2% for the first six months of 2018 primarily due to the higher amortization expense and acquisition-related and integration charges noted above.

[0001437749-18-014196:mdna:26]
[same as prior period, unchanged from 0001437749-18-008370:mdna:23]

[0001437749-18-014196:mdna:27]
Operating income was $59.6 million, a decrease of $0.6 million, or 1.1%, for the second quarter of 2018 compared to $60.3 million for the second quarter of 2017. Increases in operating income across the Electronics segment were more than offset by purchase accounting inventory charges of $19.0 million, higher amortization charges of $7.2 million and higher restructuring and impairment charges of $4.3 million along with the costs associated with the acquisition and integration of the IXYS acquisition as described above. Operating margins decreased from 19.2% in the second quarter of 2017 to 13.0% in the second quarter of 2018. The purchase accounting inventory charge negatively impacted margins by 4.1% with the remaining decrease driven by the above charges partially offset by higher volume across all segments.

[0001437749-18-014196:mdna:28]
Operating income for the first six months of 2018 was $97.2 million, or 11.1% of net sales, compared to $109.1 million, or 18.2% of net sales, for the first six months of 2017. The decrease in operating income is primarily due to the purchase accounting inventory charges of $36.9 million along with the costs associated with the acquisition and integration of IXYS as described above. The purchase accounting inventory charges, higher acquisition and integration charges and higher amortization expense negatively impacted margins by 4.2%, 1.3% and 0.8%, respectively.

[0001437749-18-014196:mdna:29]
[same as prior period, unchanged from 0001437749-18-008370:mdna:25]

[0001437749-18-014196:mdna:30]
Income before income taxes was $52.3 million, or 11.4% of net sales, for the second quarter of 2018 compared to $57.4 million, or 18.3% of net sales, for the second quarter of 2017. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by increased unfavorable foreign exchange losses of $3.8 million primarily due to fluctuations in the Euro and Mexican peso against the U.S. dollar and increased interest expense of $2.5 million associated with the increased borrowings for the IXYS acquisition. Additionally, partially offsetting the previously mentioned expense increases was an increase in other income of $1.9 million during the three months ended June 30, 2018 as compared to the three months ended July 1, 2017 primarily as a result of unrealized investment gains associated with our equity investments.

[0001437749-18-014196:mdna:31]
Income before income taxes for the first six months of 2018 was $97.0 million, or 11.1% of net sales compared to $104.8 million, or 17.5% of net sales, for the first six months of 2017. In addition to the factors impacting comparative results for operating income discussed above income before income taxes was favorably impacted by foreign exchange gains of $5.2 million and increases in other income of $3.7 million primarily due to unrealized investment gains in our equity investments partially offset by higher interest expense of $4.8 million resulting from increased borrowings for the IXYS acquisition.

[0001437749-18-014196:mdna:32]
[same as prior period, unchanged from 0001437749-18-008370:mdna:27]

[0001437749-18-014196:mdna:33]
Income tax expense was $10.0 million, or an effective tax rate of 19.1%, for the second quarter of 2018 compared to $8.7 million, or an effective tax rate of 15.2%, for the second quarter of 2017. The effective tax rate for the second quarter of 2017 was lower than the then applicable 35% U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. The effective tax rate for the second quarter of 2018 was higher than the effective tax rate for the second quarter of 2017 primarily due to the impact of U.S. tax reform and the acquisition of IXYS.

[0001437749-18-014196:mdna:34]
Income tax expense for the first six months of 2018 was $18.6 million, or an effective tax rate of 19.2%, compared to income tax expense of $17.3 million, or an effective tax rate of 16.5%, for the first six months of 2017. The effective tax rate for the first six months of 2017 was lower than the then applicable 35% U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. The effective tax rate for the first six months of 2018 was higher than the effective tax rate for the first six months of 2017 primarily due to the impact of U.S. tax reform and the acquisition of IXYS.

[0001437749-18-014196:mdna:35]
[same as prior period, unchanged from 0001437749-18-008370:mdna:29]

[0001437749-18-014196:mdna:36]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 12, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-18-014196:mdna:37]
The following table is a summary of the Company’s net sales by segment:

[0001437749-18-014196:mdna:38]
|  |  | Second Quarter |  |  | First Six Months |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |
| Electronics |  | $ | 299,357 |  |  | $ | 169,387 |  |  | $ | 129,970 |  |  |  | 76.7 | % |  | $ | 563,768 |  |  | $ | 323,154 |  |  | $ | 240,614 |  |  |  | 74.5 | % |
| Automotive |  |  | 127,172 |  |  |  | 116,457 |  |  |  | 10,715 |  |  |  | 9.2 | % |  |  | 253,302 |  |  |  | 224,297 |  |  |  | 29,005 |  |  |  | 12.9 | % |
| Industrial |  |  | 32,654 |  |  |  | 27,511 |  |  |  | 5,143 |  |  |  | 18.7 | % |  |  | 59,926 |  |  |  | 51,346 |  |  |  | 8,580 |  |  |  | 16.7 | % |
| Total |  | $ | 459,183 |  |  | $ | 313,355 |  |  | $ | 145,828 |  |  |  | 46.5 | % |  | $ | 876,996 |  |  | $ | 598,797 |  |  | $ | 278,199 |  |  |  | 46.5 | % |

[0001437749-18-014196:mdna:39]
[same as prior period, unchanged from 0001437749-18-008370:mdna:33]

[0001437749-18-014196:mdna:40]
The Electronics segment net sales increased $130.0 million, or 76.7%, in the second quarter of 2018 compared to the second quarter of 2017 due to incremental net sales related to the IXYS and U.S. Sensor acquisitions of $100.2 million and $3.4 million, respectively, higher volume across all businesses driven by the strong electronics cycle and favorable foreign exchange impacts of $3.2 million.

[0001437749-18-014196:mdna:41]
The Electronics segment net sales increased $240.6 million, or 74.5%, in the first six months of 2018 compared to the first six months of 2017 due to incremental net sales related to the IXYS and U.S. Sensor acquisitions of $186.5 million and $6.5 million, respectively, higher volume across all businesses driven by the continued strong electronics cycle and favorable foreign exchange impacts of $8.5 million.

[0001437749-18-014196:mdna:42]
[same as prior period, unchanged from 0001437749-18-008370:mdna:35]

[0001437749-18-014196:mdna:43]
The Automotive segment net sales increased $10.7 million, or 9.2%, in the second quarter of 2018 compared to the second quarter of 2017 due to increased volume across all businesses with the commercial vehicle business having the most growth as well as favorable changes in foreign exchange rates of $4.5 million.

[0001437749-18-014196:mdna:44]
The Automotive segment net sales increased $29.0 million, or 12.9%, in the first six months of 2018 compared to the first six months of 2017 due to increased volume across all businesses with the commercial vehicle and sensor businesses having the most growth as well as favorable changes in foreign exchange rates of $11.9 million.

[0001437749-18-014196:mdna:45]
[same as prior period, unchanged from 0001437749-18-008370:mdna:37]

[0001437749-18-014196:mdna:46]
The Industrial segment net sales increased $5.1 million, or 18.7%, in the second quarter of 2018 compared to the second quarter of 2017 primarily due to higher volume across the power fuse and relay businesses.

[0001437749-18-014196:mdna:47]
The Industrial segment net sales increased $8.6 million, or 16.7%, in the first six months of 2018 compared to the first six months of 2017 due to higher volume primarily in the power fuse and relay operations.

[0001437749-18-014196:mdna:48]
[same as prior period, unchanged from 0001437749-18-008370:mdna:39]

[0001437749-18-014196:mdna:49]
[same as prior period, unchanged from 0001437749-18-008370:mdna:40]

[0001437749-18-014196:mdna:50]
|  |  | Second Quarter |  |  | First Six Months |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |
| Americas |  | $ | 146,619 |  |  | $ | 115,039 |  |  | $ | 31,580 |  |  |  | 27.5 | % |  | $ | 285,348 |  |  | $ | 213,064 |  |  | $ | 72,284 |  |  |  | 33.9 | % |
| Europe |  |  | 108,983 |  |  |  | 60,263 |  |  |  | 48,720 |  |  |  | 80.8 | % |  |  | 208,795 |  |  |  | 119,168 |  |  |  | 89,627 |  |  |  | 75.2 | % |
| Asia-Pacific |  |  | 203,581 |  |  |  | 138,053 |  |  |  | 65,528 |  |  |  | 47.5 | % |  |  | 382,853 |  |  |  | 266,565 |  |  |  | 116,288 |  |  |  | 43.6 | % |
| Total |  | $ | 459,183 |  |  | $ | 313,355 |  |  | $ | 145,828 |  |  |  | 46.5 | % |  | $ | 876,996 |  |  | $ | 598,797 |  |  | $ | 278,199 |  |  |  | 46.5 | % |

[0001437749-18-014196:mdna:51]
[same as prior period, unchanged from 0001437749-18-008370:mdna:42]

[0001437749-18-014196:mdna:52]
Net sales in the Americas increased $31.6 million, or 27.5%, in the second quarter of 2018 compared to the second quarter of 2017 driven by incremental net sales related to the IXYS and U.S. Sensor acquisitions of $22.7 million and $2.9 million, respectively and increased volume in the Electronics and Industrial segments partially offset by decreased volume in the Automotive segment.

[0001437749-18-014196:mdna:53]
Net sales in the Americas increased $72.3 million, or 33.9%, in the first six months of 2018 compared to the first six months of 2017 driven by incremental net sales related to the IXYS and U.S. Sensor acquisitions of $43.8 million and $5.5 million, respectively and increased volume in the Electronics, Automotive and Industrial segments.

[0001437749-18-014196:mdna:54]
[same as prior period, unchanged from 0001437749-18-008370:mdna:44]

[0001437749-18-014196:mdna:55]
European net sales increased $48.7 million, or 80.8%, in the second quarter of 2018 compared to the second quarter of 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $28.8 million and higher volumes in the Electronics and Automotive segments with strong growth especially in the passive business in the Electronics segment and across all businesses in the Automotive segment as well as favorable foreign currency effects of $5.2 million.

[0001437749-18-014196:mdna:56]
European net sales increased $89.6 million, or 75.2%, in the first six months of 2018 compared to the first six months of 2017 The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $55.7 million and higher volumes in the Electronics and Automotive segments with strong growth especially in the passive business in the Electronics segment and across all businesses in the Automotive segment as well as favorable foreign currency effects of $14.7 million.

[0001437749-18-014196:mdna:57]
[same as prior period, unchanged from 0001437749-18-008370:mdna:46]

[0001437749-18-014196:mdna:58]
Asia-Pacific net sales increased $65.5 million, or 47.5%, in the second quarter of 2018 compared to the second quarter of 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $48.7 million and higher volumes in the Electronics and Automotive segments with strong growth across all businesses in the Electronics segment and in the passenger car business in the Automotive segment as well as favorable foreign currency effects of $2.5 million.

[0001437749-18-014196:mdna:59]
Asia-Pacific net sales increased $116.3 million, or 43.6%, in the first six months of 2018 compared to the first six months of 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $87.0 million and higher volumes in the Electronics and Automotive segments with strong growth across all businesses in the Electronics segment and in the passenger car business in the Automotive segment as well as favorable foreign currency effects of $5.6 million.

[0001437749-18-014196:mdna:60]
[same as prior period, unchanged from 0001437749-18-008370:mdna:48]

[0001437749-18-014196:mdna:61]
[same as prior period, unchanged from 0001437749-18-008370:mdna:49]

[0001437749-18-014196:mdna:62]
Revolving Credit Facility/Term Loan

[0001437749-18-014196:mdna:63]
On March 4, 2016, the Company entered into a new five-year credit agreement with a group of lenders for up to $700.0 million. The new credit agreement consisted of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0001437749-18-014196:mdna:64]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. . In addition to the quarterly principal payments, the Company paid $35.0 million of principal on the term loan during the three months ended June 30, 2018.

[0001437749-18-014196:mdna:65]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.59% at June 30, 2018. As of June 30, 2018, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At June 30, 2018, the Company was in compliance with all covenants under the Credit Agreement. Further information regarding the Company’s credit agreement is provided in Note 5, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-18-014196:mdna:66]
[same as prior period, unchanged from 0001437749-18-008370:mdna:54]

[0001437749-18-014196:mdna:67]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023, and €95 million in aggregate amount of 1.83% Senior Notes, Series B, due December 8, 2028 (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001437749-18-014196:mdna:68]
[same as prior period, unchanged from 0001437749-18-008370:mdna:56]

[0001437749-18-014196:mdna:69]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B, due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 will be payable on February 15 and August 15, commencing on August 15, 2018.

[0001437749-18-014196:mdna:70]
Dividends

[0001437749-18-014196:mdna:71]
During July 2018, the Company’s Board of Directors approved a 16% increase in the quarterly cash dividend from $0.37 to $0.43. This equates to an annualized dividend of $1.72 per share.

[0001437749-18-014196:mdna:72]
[same as prior period, unchanged from 0001437749-18-008370:mdna:58]

[0001437749-18-014196:mdna:73]
|  |  | First Six Months |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |
| Net cash provided by operating activities |  | $ | 140,915 |  |  | $ | 93,573 |  |
| Net cash used in investing activities |  |  | (350,734 | ) |  |  | (36,117 | ) |
| Net cash provided by (used in) financing activities |  |  | 196,207 |  |  |  | (10,079 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (7,917 | ) |  |  | (608 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (21,529 | ) |  |  | 46,769 |  |
| Cash and cash equivalents at beginning of period |  |  | 429,676 |  |  |  | 275,124 |  |
| Cash and cash equivalents at end of period |  | $ | 408,147 |  |  | $ | 321,893 |  |

[0001437749-18-014196:mdna:74]
[same as prior period, unchanged from 0001437749-18-008370:mdna:61]

[0001437749-18-014196:mdna:75]
[same as prior period, unchanged from 0001437749-18-008370:mdna:62]

[0001437749-18-014196:mdna:76]
Net cash provided by operating activities was $140.9 million for the first six months of 2018, compared to $93.6 million during the six months ended July 1, 2017. The increase in net cash provided by operating activities was primarily driven by higher earnings and favorable working capital management that more than offset higher payments related to acquisition and integration costs and higher cash taxes.

[0001437749-18-014196:mdna:77]
[same as prior period, unchanged from 0001437749-18-008370:mdna:64]

[0001437749-18-014196:mdna:78]
Net cash used in investing activities was $350.7 million for the six months ended June 30, 2018, compared to $36.1 million during the six months ended July 1, 2017. Net cash used for the acquisition of IXYS was $306.5 million for the six months ended June 30, 2018 as compared to net cash used for the acquisition of a majority stake in Monolith of $14.2 million for the six months ended July 1, 2017. Capital expenditures were $40.3 million, representing an increase of $12.0 million compared to 2017.

[0001437749-18-014196:mdna:79]
[same as prior period, unchanged from 0001437749-18-008370:mdna:66]

[0001437749-18-014196:mdna:80]
Net cash provided by financing activities was $196.2 million for the six months ended 2018 compared to net cash used in financing activities of $10.1 million for the six months ended 2017. The Company had $310.0 million of proceeds from the credit facility, term loan and senior notes payable partially offset by payments $100.0 million on the credit facility and term loan during the first six months ended June 30, 2018 as compared to $125.0 million of proceeds from the senior notes payable and $115.6 million of payments on the credit facility and term loan during the six months ended July 1, 2017. Additionally, dividends paid increased $3.5 million from $15.0 million in 2017 to $18.5 million for the six months ended June 30, 2018.

[0001437749-18-014196:mdna:81]
[same as prior period, unchanged from 0001437749-18-008370:mdna:68]

[0001437749-18-014196:mdna:82]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 (“Share Repurchase Program”). The Company did not repurchase any shares of its common stock during the second quarter of 2018.

[0001437749-18-014196:mdna:83]
[same as prior period, unchanged from 0001437749-18-008370:mdna:70]

[0001437749-18-014196:mdna:84]
As of June 30, 2018, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-18-014196:mdna:85]
[same as prior period, unchanged from 0001437749-18-008370:mdna:72]

[0001437749-18-014196:mdna:86]
[same as prior period, unchanged from 0001437749-18-008370:mdna:73]

[0001437749-18-014196:mdna:87]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 30, 2017. During the three months ended June 30, 2018, there were no significant changes in the application of critical accounting policies.

[0001437749-18-014196:mdna:88]
[same as prior period, unchanged from 0001437749-18-008370:mdna:75]

[0001437749-18-014196:mdna:89]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the first quarter of 2019. The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has not yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and  lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.

[0001437749-18-014196:mdna:90]
In January 2018, the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions of the Tax Act. The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has not yet completed its assessment and therefore has not yet elected an accounting policy.

[0001437749-18-014196:mdna:91]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 2018-02 will be effective in the first quarter of 2019; however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 2018-02 on the Consolidated Financial Statements.
