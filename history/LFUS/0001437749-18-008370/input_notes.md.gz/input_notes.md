# LFUS notes — 0001437749-18-008370


## lfus:RevenueRecognitionAndBillingPolicyTextBlock

[0001437749-18-008370:notes:1]
Revenue and Billing

[0001437749-18-008370:notes:2]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than 
one
 year, the Company has elected the practical expedient under ASC 
606
-
10
-
32
-
18
 to 
not
 assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 
606
-
10
-
25
-
18B
 to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.


## lfus:RevenueRecognitionReturnToStockPolicyTextBlock

[0001437749-18-008370:notes:3]
Return to Stock

[0001437749-18-008370:notes:4]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-18-008370:notes:5]
[same as prior period, unchanged from 0001437749-17-018040:notes:1]

[0001437749-18-008370:notes:6]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

[0001437749-18-008370:notes:7]
30,

[0001437749-18-008370:notes:8]
2017,
 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are 
not
 necessarily indicative of annual operating results.


## us-gaap:BusinessAcquisitionProFormaInformationNonrecurringAdjustmentsTableTextBlock

[0001437749-18-008370:notes:9]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Amortization(a) |  | $ | 1,902 |  |  | $ | (6,276 | ) |
| Depreciation |  |  | — |  |  |  | (94 | ) |
| Transaction costs(b) |  |  | 9,976 |  |  |  | (9,976 | ) |
| Amortization of inventory step-up(c) |  |  | 17,896 |  |  |  | (22,156 | ) |
| Stock compensation(d) |  |  | 4,479 |  |  |  | (5,013 | ) |
| Interest expense(e) |  |  | — |  |  |  | (2,582 | ) |
| Income tax impact of above items |  |  | (7,701 | ) |  |  | 15,374 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-18-008370:notes:10]
|  |  | For the Three Months Ended |  |
| (in thousands, except per share amounts) |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Net sales |  | $ | 434,526 |  |  | $ | 368,813 |  |
| Income before income taxes |  |  | 81,924 |  |  |  | 11,021 |  |
| Net income |  |  | 63,933 |  |  |  | 17,462 |  |
| Net income per share — basic |  |  | 2.57 |  |  |  | 0.70 |  |
| Net income per share — diluted |  |  | 2.53 |  |  |  | 0.69 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-18-008370:notes:11]
5

[0001437749-18-008370:notes:12]
. Debt

[0001437749-18-008370:notes:13]
The carrying amounts of debt at 
 March 31, 2018 
and 
 December 30, 2017 
are as follows:

[0001437749-18-008370:notes:14]
| (in thousands) |  | March 31, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | 3,000 |  |  | $ | — |  |
| Term Loan |  |  | 195,000 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 144,041 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 116,956 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 111 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,560 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 753,548 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,111 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 743,437 |  |  | $ | 489,361 |  |

[0001437749-18-008370:notes:15]
Revolving Credit Facility / Term Loan

[0001437749-18-008370:notes:16]
On 
 March 4, 2016, 
the Company entered into a 
five
-year credit agreement (“Credit Agreement”) with a group of lenders for up to 
$700.0
 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of 
$575.0
 million and an unsecured term loan credit facility (“Term Loan”) of up to 
$125.0
 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the Term Loan, the Company was required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.

[0001437749-18-008370:notes:17]
On 
 October 13, 2017, 
the Company amended the Credit Agreement to increase the Revolving Credit Facility from 
$575.0
 million to 
$700.0
 million and increase the Term Loan from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans 
 may 
be made in up to 
two
 advances. The 
first
 advance of 
$125.0
 million occurred on 
 October 13, 2017 
and the 
second
 advance of 
$75.0
 million occurred on 
 January 16, 2018. 
For the Term Loan, the Company is required to make quarterly principal payments of 
1.25%
 of the original term loan (
$2.5
 million with the 
second
 advance on 
 January 16, 2018) 
through maturity, with the remaining balance due on 
 October 13, 2022.

[0001437749-18-008370:notes:18]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
-month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.25%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
3.13%
 at 
 March 31, 2018.

[0001437749-18-008370:notes:19]
As of 
 March 31, 2018, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$696.9
 million of borrowing capacity under the Revolving Credit Facility. At 
 March 31, 2018, 
the Company was in compliance with all covenants under the Credit Agreement.

[0001437749-18-008370:notes:20]
Senior Notes

[0001437749-18-008370:notes:21]
On 
 December 8, 2016, 
the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023 (
“Euro Senior Notes, Series A due 
2023”
), and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
“Euro Senior Notes, Series B due 
2028”
) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.

[0001437749-18-008370:notes:22]
On 
 December 8, 2016, 
the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February 15, 2017,

[0001437749-18-008370:notes:23]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022 (
“U.S. Senior Notes, Series A due 
2022”
), and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
“U.S. Senior Notes, Series B due 
2027”
) (together, the “U.S. Senior Notes due 
2022
 and 
2027”
) were funded. Interest on the U.S. Senior Notes due 
2022
 and 
2027
 is payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

[0001437749-18-008370:notes:24]
On 
 November 15, 2017, 
the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold 
$175
 million in aggregate principal amount of senior notes in 
two
 series. On 
 January 16, 2018,

[0001437749-18-008370:notes:25]
$50
 million aggregate principal amount of 
3.48%
 Senior Notes, Series A, due 
 February 15, 2025 (
“U.S. Senior Notes, Series A due 
2025”
) and 
$125
 million in aggregate principal amount of 
3.78%
 Senior Notes, Series B, due 
 February 15, 2030 (
“U.S. Senior Notes, Series B due 
2030”
) (together the “U.S. Senior Notes due 
2025
 and 
2030”
 and with the Euro Senior Notes and the U.S. Senior Notes 
2022
 and 
2027,
 the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 
2025
 and 
2030
 will be payable on 
 February 15 
and 
 August 15, 
commencing on 
 August 15, 2018.

[0001437749-18-008370:notes:26]
The Senior Notes have 
not
 been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001437749-18-008370:notes:27]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 March 31, 2018, 
the Company was in compliance with all covenants under the Senior Notes.

[0001437749-18-008370:notes:28]
The Company 
 may 
redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-18-008370:notes:29]
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics - Semiconductor |  |  | 149,916 |  |  |  | — |  |  |  | — |  |  |  | 149,916 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,580 |  |  |  | — |  |  |  | 63,580 |  |
| Automotive Sensors |  |  | — |  |  |  | 31,323 |  |  |  | — |  |  |  | 31,323 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 31,228 |  |  |  | — |  |  |  | 31,228 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 27,271 |  |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-18-008370:notes:30]
10

[0001437749-18-008370:notes:31]
[same as prior period, unchanged from 0001437749-17-018040:notes:37]

[0001437749-18-008370:notes:32]
[same as prior period, unchanged from 0001437749-17-018040:notes:38]

[0001437749-18-008370:notes:33]
|  |  | For the Three Months Ended |  |
| (in thousands, except per share amounts) |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 36,029 |  |  | $ | 38,891 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  |  | 24,339 |  |  |  | 22,748 |  |
| Effect of dilutive securities |  |  | 436 |  |  |  | 241 |  |
| Diluted |  |  | 24,775 |  |  |  | 22,989 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.48 |  |  | $ | 1.71 |  |
| Diluted earnings per share |  | $ | 1.45 |  |  | $ | 1.69 |  |

[0001437749-18-008370:notes:34]
No

[0001437749-18-008370:notes:35]
potential shares of common stock attributable to stock options were excluded from the diluted earnings per share calculation for the 
three
 months ended 
 March 31, 2018 
and 
 April 1, 2017, 
respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-18-008370:notes:36]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investments in equity securities |  | $ | 14,754 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,754 |  |
| Mutual funds |  |  | 9,852 |  |  |  | — |  |  |  | — |  |  |  | 9,852 |  |

[0001437749-18-008370:notes:37]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investments in equity securities |  | $ | 10,993 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,993 |  |
| Mutual funds |  |  | 7,962 |  |  |  | — |  |  |  | — |  |  |  | 7,962 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001437749-18-008370:notes:38]
|  |  | March 31, 2018 |  |  | December 30, 2017 |  |
| (in thousands) |  | Carrying Value |  |  | Estimated Fair Value |  |  | Carrying Value |  |  | Estimated Fair Value |  |
| Euro Senior Notes, Series A due 2023 |  | $ | 144,041 |  |  | $ | 142,038 |  |  | $ | 139,623 |  |  | $ | 138,294 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 116,956 |  |  |  | 113,953 |  |  |  | 113,369 |  |  |  | 111,579 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 24,301 |  |  |  | 25,000 |  |  |  | 24,737 |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 96,475 |  |  |  | 100,000 |  |  |  | 99,992 |  |
| USD Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | 48,081 |  |  |  | — |  |  |  | — |  |
| USD Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | 118,303 |  |  |  | — |  |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-18-008370:notes:39]
6

[0001437749-18-008370:notes:40]
[same as prior period, unchanged from 0001437749-17-018040:notes:46]

[0001437749-18-008370:notes:41]
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a 
three
-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows:

[0001437749-18-008370:notes:42]
[same as prior period, unchanged from 0001437749-17-018040:notes:48]

[0001437749-18-008370:notes:43]
[same as prior period, unchanged from 0001437749-17-018040:notes:49]

[0001437749-18-008370:notes:44]
[same as prior period, unchanged from 0001437749-17-018040:notes:50]

[0001437749-18-008370:notes:45]
—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are 
not
 active, or model-derived valuations, all of whose significant inputs are observable, and

[0001437749-18-008370:notes:46]
[same as prior period, unchanged from 0001437749-17-018040:notes:52]

[0001437749-18-008370:notes:47]
—Valuations based upon 
one
 or more significant unobservable inputs.

[0001437749-18-008370:notes:48]
[same as prior period, unchanged from 0001437749-17-018040:notes:56]

[0001437749-18-008370:notes:49]
Investments in Equity Securities

[0001437749-18-008370:notes:50]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 
1
 of the valuation hierarchy.

[0001437749-18-008370:notes:51]
Mutual Funds

[0001437749-18-008370:notes:52]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The marketable securities are classified as Level 
1
 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value.

[0001437749-18-008370:notes:53]
There were 
no
 changes during the quarter ended 
 March 31, 2018 
to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of 
 March 31, 2018 
and 
 December 30, 2017, 
the Company did 
not
 hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-18-008370:notes:54]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of 
 March 31, 2018:

[0001437749-18-008370:notes:55]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of 
 December 30, 2017:

[0001437749-18-008370:notes:56]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are 
not
 marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at 
 March 31, 2018 
and 
 December 30, 2017, 
as the rates on these borrowings are variable in nature.

[0001437749-18-008370:notes:57]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of 
 September 30, 2017 
and 
 December 31, 2016 
were as follows:


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-18-008370:notes:58]
4.
 Goodwill and Other Intangible Assets

[0001437749-18-008370:notes:59]
The amounts for goodwill and changes in the carrying value by segment for the 
three
 months ended 
 March 31, 2018 
are as follows:

[0001437749-18-008370:notes:60]
| (in thousands) |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| As of December 30, 2017 |  | $ | 278,959 |  |  | $ | 135,829 |  |  | $ | 38,626 |  |  | $ | 453,414 |  |
| Additions(a) |  |  | 381,599 |  |  |  | — |  |  |  | — |  |  |  | 381,599 |  |
| Currency translation |  |  | 2,455 |  |  |  | 3,195 |  |  |  | (89 | ) |  |  | 5,561 |  |
| As of March 31, 2018 |  | $ | 663,013 |  |  | $ | 139,024 |  |  | $ | 38,537 |  |  | $ | 840,574 |  |

[0001437749-18-008370:notes:61]
|  | (a) | The additions resulted from the acquisition of IXYS. |

[0001437749-18-008370:notes:62]
The components of other intangible assets at 
 March 31, 2018 
are as follows:

[0001437749-18-008370:notes:63]
| (in thousands, except weighted average useful life) |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Patents, licenses and software |  | 10.6 |  |  |  | $ | 193,622 |  |  | $ | 64,012 |  |  | $ | 129,610 |  |
| Distribution network |  | 12.6 |  |  |  |  | 44,473 |  |  |  | 33,434 |  |  |  | 11,039 |  |
| Customer relationships, trademarks, and tradenames |  | 18.1 |  |  |  |  | 314,452 |  |  |  | 59,591 |  |  |  | 254,861 |  |
| Order backlog |  | 1.0 |  |  |  |  | 12,400 |  |  |  | 2,504 |  |  |  | 9,896 |  |
| Total |  |  |  |  |  | $ | 564,947 |  |  | $ | 159,541 |  |  | $ | 405,406 |  |

[0001437749-18-008370:notes:64]
During the 
three
 months ended 
 March 31, 2018, 
the Company recorded additions to other intangible assets of 
$211.6
 million, related to the IXYS acquisition, the components of which were as follows:

[0001437749-18-008370:notes:65]
| (in thousands, except weighted average useful life) |  | Weighted Average Useful Life |  |  | Amount |  |
| Patents, licenses and software |  | 8.0 |  |  |  | $ | 51,500 |  |
| Customer relationships, trademarks,and tradenames |  | 17.2 |  |  |  |  | 147,700 |  |
| Order backlog |  | 1.0 |  |  |  |  | 12,400 |  |
| Total |  |  |  |  |  | $ | 211,600 |  |

[0001437749-18-008370:notes:66]
During the 
three
 months ended 
 March 31, 2018 
and 
 April 1, 2017, 
the Company recorded amortization expense of 
$12.0
 million and 
$5.9
 million, respectively for intangible assets with definite lives.

[0001437749-18-008370:notes:67]
Estimated annual amortization expense related to intangible assets with definite lives as of 
 March 31, 2018 
is as follows:

[0001437749-18-008370:notes:68]
| (in thousands) |  | Amount |  |
| 2018 |  | $ | 54,938 |  |
| 2019 |  |  | 42,005 |  |
| 2020 |  |  | 41,747 |  |
| 2021 |  |  | 39,928 |  |
| 2022 |  |  | 38,918 |  |
| 2023 and thereafter |  |  | 197,914 |  |
| Total |  | $ | 415,450 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-18-008370:notes:69]
9

[0001437749-18-008370:notes:70]
. Income Taxes

[0001437749-18-008370:notes:71]
The effective tax rate for the 
first
 quarter of 
2018
 was 
19.3%
 compared to an effective tax rate of 
18.0%
 in the 
first
 quarter of 
2017.
 The effective tax rate for the 
first
 quarter of 
2017
 was lower than the then applicable 
35%
 U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0001437749-18-008370:notes:72]
On 
 December 22, 2017, 
the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduces the U.S. corporate federal income tax rate from 
35%
 to 
21%,
 adds base broadening provisions which limit deductions and address excessive international tax planning, imposes a 
one
-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enables repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. Other than the Toll Charge (which, except for the IXYS impact, is applicable to the Company for 
2017
), the provisions will generally be applicable to the Company in 
2018
 and beyond.

[0001437749-18-008370:notes:73]
In accordance with the guidance provided in SEC Staff Accounting Bulletin (“SAB”) 
No.

[0001437749-18-008370:notes:74]
118,
 in the 
fourth
 quarter of 
2017
 the Company recorded a charge of 
$47
 million as a provisional reasonable estimate of the impact of the Tax Act, including 
$49
 million for the Toll Charge net of 
$2
 million for other net tax benefits. The Company did 
not
 adjust the provisional reasonable estimate in the 
first
 quarter of 
2018.
 In addition, the Company recorded a preliminary estimate of 
$10
 million for the toll charge associated with the acquisition of IXYS. This adjustment was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities. The Company is continuing to analyze the Tax Act and plans to finalize the estimate within the measurement period outlined in SAB 
No.

[0001437749-18-008370:notes:75]
118.
 The final charge 
 may 
differ from the provisional reasonable estimate if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining the estimate, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors. Aside from these interpretation issues, the final charge 
 may 
differ from the provisional reasonable estimate due to refinements of accumulated non-U.S. earnings and tax pool data.

[0001437749-18-008370:notes:76]
The Company recognized deferred tax liabilities of 
$12.0
 million (
$11.8
 million for non-U.S. taxes and 
$0.2
 million for U.S. state taxes) as of 
 December 30, 2017 
related to taxes on certain non-U.S. earnings which are 
not
 considered to be permanently reinvested. Some of these taxes 
 may 
provide a U.S. federal income tax benefit as a foreign tax credit. However, due to uncertainty in regard to the Tax Act’s provisions, 
no
 such tax benefit was recorded as of 
 December 30, 2017, 
and 
no
 such tax benefit was recorded in the 
first
 quarter of 
2018.
 The Company will reconsider this provisional conclusion when it finalizes its preliminary reasonable estimate of the impact of the Tax Act, based upon interpretations and administrative guidance as of that time.

[0001437749-18-008370:notes:77]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has 
not
 adopted an accounting policy for GILTI. Thus, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions. The Company intends to adopt an accounting policy for GILTI within the measurement period outlined in SAB 
118.
 Although such an accounting policy has 
not
 been adopted, the Company considered GILTI when determining the current portion of income tax expense recorded for the 
first
 quarter of 
2018.

[0001437749-18-008370:notes:78]
Although certain administrative guidance has been issued, the appropriate application of many provisions of the Tax Act remain uncertain. The Company used its best judgement as to the application of these provisions in determining its income tax expense for the 
first
 quarter of 
2018.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-18-008370:notes:79]
[same as prior period, unchanged from 0001437749-17-018040:notes:74]

[0001437749-18-008370:notes:80]
[same as prior period, unchanged from 0001437749-17-018040:notes:75]

[0001437749-18-008370:notes:81]
The components of inventories at 
 March 31, 2018 
and 
 December 30, 2017 
are as follows:

[0001437749-18-008370:notes:82]
| (in thousands) |  | March 31, 2018 |  |  | December 30, 2017 |  |
| Raw materials |  | $ | 66,259 |  |  | $ | 39,030 |  |
| Work in process |  |  | 96,826 |  |  |  | 27,454 |  |
| Finished goods |  |  | 100,884 |  |  |  | 74,305 |  |
| Total |  | $ | 263,969 |  |  | $ | 140,789 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-18-008370:notes:83]
[same as prior period, unchanged from 0001437749-17-018040:notes:78]

[0001437749-18-008370:notes:84]
[same as prior period, unchanged from 0001437749-17-018040:notes:79]

[0001437749-18-008370:notes:85]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 
805,
 “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0001437749-18-008370:notes:86]
[same as prior period, unchanged from 0001437749-17-018040:notes:82]

[0001437749-18-008370:notes:87]
On 
 January 17, 2018, 
the Company acquired IXYS Corporation (“IXYS”), a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 
3,500
 customers through its direct sales force and global distribution partners. The acquisition of IXYS is expected to accelerate the Company’s growth across the power control market driven by IXYS’s extensive power semiconductor portfolio and technology expertise. With IXYS, the Company will be able to diversify and expand its presence within industrial electronics markets, leveraging the strong IXYS industrial OEM customer base. The Company also expects to increase long-term penetration of its power semiconductor portfolio in automotive markets, expanding its global content per vehicle.

[0001437749-18-008370:notes:88]
Upon completion of the acquisition, at IXYS stockholders’ election and subject to proration, each share of IXYS common stock, par value 
$0.01
 per share, owned immediately prior to the effective time was cancelled and extinguished and automatically converted into the right to receive: (i) 
$23.00
 in cash (subject to applicable withholding tax), without interest (referred to as the cash consideration), or (ii) 
0.1265
 of a share of common stock, par value 
$0.01
 per share, of Littelfuse (referred to as the stock consideration). IXYS stockholders received cash in lieu of any fractional shares of Littelfuse common stock that the IXYS stockholders would otherwise have been entitled to receive. Additionally, each outstanding option to purchase shares of IXYS common stock granted under an IXYS equity plan were assumed by Littelfuse and converted into an option to acquire (i) a number of shares of Littelfuse common stock equal to the number of shares of IXYS common stock subject to such option immediately prior to the effective time multiplied by 
0.1265,
 rounded down to the nearest whole share, with (ii) an exercise price per share of Littelfuse common stock equal to the exercise price of such IXYS stock option immediately prior to the effective time divided by 
0.1265,
 rounded up to the nearest whole cent.

[0001437749-18-008370:notes:89]
Based on the 
$207.5
 per share opening price of Littelfuse common stock on 
 January 17, 2018, 
the consideration IXYS stockholders received in exchange of their IXYS common stock in the acquisition had a value of 
$814.8
 million comprised of 
$380.5
 million of cash and 
$434.2
 million of Littelfuse stock. In addition to the consideration transferred related to IXYS common stock, the value of consideration transferred, and included in the purchase price, related to IXYS stock options that were converted to Littelfuse stock options, or cash settled, had a value of 
$41.7
 million. As a result, total consideration was valued at 
$856.5
 million.

[0001437749-18-008370:notes:90]
The total purchase price of 
$856.5
 million has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary areas that are 
not
 yet finalized relate to the completion of the valuations of certain acquired income tax assets and liabilities, including the impact of the adoption of the Tax Cuts and Job Act (“Tax Act”) and certain acquired investments. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0001437749-18-008370:notes:91]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the IXYS acquisition:

[0001437749-18-008370:notes:92]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash, net of cash acquired |  | $ | 302,865 |  |
| Cash settled stock options |  |  | 3,622 |  |
| Littelfuse stock |  |  | 434,192 |  |
| Converted stock options |  |  | 38,109 |  |
| Total purchase consideration |  | $ | 778,788 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 154,254 |  |
| Property, plant, and equipment |  |  | 76,580 |  |
| Intangible assets |  |  | 211,600 |  |
| Goodwill |  |  | 381,599 |  |
| Other non-current assets |  |  | 31,570 |  |
| Other non-current liabilities |  |  | (76,815 | ) |
|  |  | $ | 778,788 |  |

[0001437749-18-008370:notes:93]
Included in IXYS’s current assets, net was approximately 
$49.1
 million of receivables. All IXYS goodwill, other assets and liabilities were recorded in the Electronics segment and primarily reflected in the Americas and European geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining IXYS’s products and technology with the Company’s existing electronics product portfolio. Goodwill resulting from the IXYS acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-18-008370:notes:94]
Included in the Company’s Condensed Consolidated Statements of Net Income for the 
three
 months ended 
 March 31, 2018 
are net sales of approximately 
$86.3
 million and a loss before income taxes of approximately 
$17.8
 million since the 
 January 17, 2018 
acquisition of IXYS. The Company recognized approximately 
$5.9
 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the 
three
 months ended 
 March 31, 2018 
of which 
$4.5
 million was recognized immediately as it related to prior services periods.

[0001437749-18-008370:notes:95]
As required by purchase accounting rules, the Company recorded a 
$36.9
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up is being amortized as a non-cash charge to cost of goods sold during the 
first
 and 
second
 quarters of 
2018,
 as the acquired inventory is sold, and reflected as other non-segment costs. During the 
three
 months ended 
 March 31, 2018, 
the Company recognized a charge of 
$17.9
 million for the amortization of this fair value inventory step-up.

[0001437749-18-008370:notes:96]
During the 
three
 months ended 
 March 31, 2018, 
the Company incurred approximately 
$10.2
 million of legal and professional fees related to this acquisition which were primarily recognized as 
selling, general, and administrative expenses
. These costs were reflected as other non-segment costs.

[0001437749-18-008370:notes:97]
[same as prior period, unchanged from 0001437749-17-018040:notes:81]

[0001437749-18-008370:notes:98]
[same as prior period, unchanged from 0001437749-17-018040:notes:88]

[0001437749-18-008370:notes:99]
On 
 July 7, 2017, 
the Company acquired the assets of U.S. Sensor Corporation (“U.S. Sensor”). The acquisition purchase price of 
$24.3
 million, net of the finalization of an income tax gross up which was settled in the 
fourth
 quarter of 
2017,
 was funded with available cash. The acquired business expands the Company’s existing sensor portfolio in several key electronics and industrial end markets. U.S. Sensor manufactures a variety of high quality negative temperature coefficient thermistors as well as thermistor probes and assemblies. Product lines also include thin film platinum resistance temperature detectors (“RTDs”) and RTD assemblies.

[0001437749-18-008370:notes:100]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the U.S. Sensor acquisition:

[0001437749-18-008370:notes:101]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 24,340 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 4,635 |  |
| Patented and unpatented technologies |  |  | 1,090 |  |
| Trademarks and tradenames |  |  | 200 |  |
| Non-compete agreement |  |  | 50 |  |
| Customer relationships |  |  | 2,830 |  |
| Goodwill |  |  | 16,075 |  |
| Current liabilities |  |  | (540 | ) |
|  |  | $ | 24,340 |  |

[0001437749-18-008370:notes:102]
Included in U.S. Sensor’s current assets, net was approximately 
$1.5
 million of receivables. All U.S. Sensor goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining U.S. Sensor’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-18-008370:notes:103]
As required by purchase accounting rules, the Company recorded a 
$1.6
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the 
third
 quarter of 
2017,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-18-008370:notes:104]
[same as prior period, unchanged from 0001437749-17-018040:notes:96]

[0001437749-18-008370:notes:105]
In 
 December 2015, 
the Company invested 
$3.5
 million in the preferred stock of Monolith Semiconductor Inc. (“Monolith”), a U.S. start-up Company developing silicon carbide technology, which represented approximately 
12%
 of the common stock of Monolith on an as-converted basis. The Company accounted for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was 
$3.5
 million at 
 December 31, 2016.

[0001437749-18-008370:notes:106]
On 
 February 28, 2017, 
pursuant to a Securities Purchase Agreement between the Company and the stockholders of Monolith (“Securities Purchase Agreement”) and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired 
62%
 of the outstanding common stock of Monolith for 
$15
 million. The Securities Purchase Agreement includes provisions whereby the Company will acquire the remaining outstanding stock of Monolith (“non-controlling interest”) at a time or times based on Monolith meeting certain technical and sales targets. During the 
first
 quarter of 
2018,
 Monolith met the next set of technical and sales targets. As a result, and pursuant to the Securities Purchase Agreement, in 
 April 2018 
the Company acquired an additional 
19%
 of the outstanding common stock of Monolith for 
$5
 million. Consideration for the purchase of the remaining 
19%
 outstanding common stock will be either 
$0.5
 million or 
$5
 million, based on Monolith meeting the remaining technical and sales targets, and will be paid 
no
 later than 
 June 30, 2019.

[0001437749-18-008370:notes:107]
The additional investment, in the 
first
 quarter of 
2017,
 resulted in the Company gaining control of Monolith and was accounted for as a step-acquisition with the fair value of the original investment immediately before the acquisition estimated to be approximately 
$3.5
 million. As the fair value of the investment immediately prior to the transaction equaled the carrying value, there was 
no
 impact on the Company’s Consolidated Statements of Net Income. As the Securities Purchase Agreement includes an obligation of the Company to mandatorily redeem the non-controlling interest for cash, the fair value of the non-controlling interest was recognized as a liability on the Company’s Consolidated Balance Sheets. The original investment of 
$3.5
 million, additional cash consideration of 
$14.2
 million (net of cash acquired), and the non-cash consideration of the fair value of the commitment to purchase the non-controlling interest of 
$9.0
 million resulted in a purchase price of 
$26.7
 million. Changes in the fair value of the non-controlling interest are recognized in the Company’s Consolidated Statements of Net Income.

[0001437749-18-008370:notes:108]
Commencing 
 March 1, 2017, 
Monolith was reflected as a consolidated subsidiary within the Company’s Consolidated Financial Statements. Had the acquisition occurred as of 
 January

[0001437749-18-008370:notes:109]
[same as prior period, unchanged from 0001437749-17-018040:notes:101]

[0001437749-18-008370:notes:110]
[same as prior period, unchanged from 0001437749-17-018040:notes:102]

[0001437749-18-008370:notes:111]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the Monolith acquisition:

[0001437749-18-008370:notes:112]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Original investment |  | $ | 3,500 |  |
| Cash, net of cash acquired |  |  | 14,172 |  |
| Non-cash, fair value of commitment to purchase non-controlling interest |  |  | 9,000 |  |
| Total purchase consideration |  | $ | 26,672 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 891 |  |
| Property, plant, and equipment |  |  | 789 |  |
| Patented and unpatented technologies |  |  | 6,720 |  |
| Non-compete agreement |  |  | 140 |  |
| Goodwill |  |  | 20,641 |  |
| Current liabilities |  |  | (639 | ) |
| Other non-current liabilities |  |  | (1,870 | ) |
|  |  | $ | 26,672 |  |

[0001437749-18-008370:notes:113]
Included in Monolith’s current assets, net was approximately 
$0.7
 million of receivables. All Monolith goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Monolith’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-18-008370:notes:114]
[same as prior period, unchanged from 0001437749-17-018040:notes:130]

[0001437749-18-008370:notes:115]
The following table summarizes, on a pro forma basis, the combined results of operations of the Company and IXYS as though the acquisition had occurred as of 
 January 1, 2017. 
The Company has 
not
 included pro forma results of operations for U.S. Sensor or Monolith as these results were 
not
 material to the Company. The pro forma amounts presented are 
not
 necessarily indicative of either the actual consolidated results had the IXYS acquisition occurred as of 
 January 1, 2017 
or of future consolidated operating results.

[0001437749-18-008370:notes:116]
Pro forma results presented above primarily reflect the following adjustments:

[0001437749-18-008370:notes:117]
|  | (a) | The amortization adjustment for the three months ended March 31, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and will be fully amortized in the fiscal 2017 pro forma results. The amortization adjustment for the three months ended April 1, 2017 reflects incremental amortization resulting for the measurement of intangibles at their fair values. |

[0001437749-18-008370:notes:118]
|  | (b) | The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the three months ended March 31, 2018 and recognition of those fees during the three months ended April 1, 2017. |

[0001437749-18-008370:notes:119]
|  | (c) | The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the three months ended March 31, 2018 and the recognition of a full quarter of the amortization during the three months end April 1, 2017. The inventory step-up is being amortized over five months as the inventory is sold. |

[0001437749-18-008370:notes:120]
|  | (d) | The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the three months ended March 31, 2018. The adjustment for the three months ended April 1, 2017 reflect the incremental stock compensation for the converted stock options. |

[0001437749-18-008370:notes:121]
|  | (e) | The interest expense adjustment reflects incremental interest expense related to the financing of the transaction. |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-18-008370:notes:122]
Recently Adopted Accounting Standards

[0001437749-18-008370:notes:123]
In 
 March 2017, 
the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)  
No.

[0001437749-18-008370:notes:124]
2017
-
07
 “Compensation-Retirement Benefits (Topic 
715
): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income.  Under the previous guidance, net benefit cost was reported as an employee cost within operating income.  The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations.  ASU 
No.

[0001437749-18-008370:notes:125]
2017
-
07
 was effective for the 
first
 quarter of 
2018
 with the Company adopting the new standard on 
 December 31, 2017.

[0001437749-18-008370:notes:126]
In 
 January 2016, 
the FASB issued ASU 
No.

[0001437749-18-008370:notes:127]
2016
-
01,
 “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on 
 December 31, 2017, 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings.  As a result of the adoption of the new standard and change in fair value of our equity investments, for the 
three
 months ended 
 March 31, 2018, 
the Company recognized an unrealized gain of 
$1.9
 million  in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.

[0001437749-18-008370:notes:128]
In 
 May 2014, 
the FASB issued ASU 
No.

[0001437749-18-008370:notes:129]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on 
 December 31, 2017 
using the modified retrospective method, however, 
no
 adjustment to retained earnings was needed. The new guidance did 
not
 have a material effect on the Company’s Condensed Consolidated Statements of Income. See the 
Revenue Recognition
 section above for further discussion.

[0001437749-18-008370:notes:130]
In 
 October 2016, 
the FASB issued ASU 
No.

[0001437749-18-008370:notes:131]
2016
-
16,
 "Income Taxes” (Topic 
740
). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on 
 December 31, 2017 
and it did 
not
 have a material impact.

[0001437749-18-008370:notes:132]
Recently Issued Accounting Standards

[0001437749-18-008370:notes:133]
In 
 February 2016, 
the FASB issued ASU 
No.

[0001437749-18-008370:notes:134]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the 
first
 quarter of 
2019.
 The Company is currently evaluating the impact of ASU 
2016
-
02.

[0001437749-18-008370:notes:135]
In 
 January 2018, 
the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions in the Tax Act. The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has 
not
 yet completed its assessment and therefore has 
not
 yet elected an accounting policy.

[0001437749-18-008370:notes:136]
In 
 February 2018, 
the FASB issued ASU 
No.

[0001437749-18-008370:notes:137]
2018
-
02
 “Income Statement—Reporting Comprehensive Income (Topic 
220
): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or 
not
 they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 
2018
-
02
 will be effective in the 
first
 quarter of 
2019;
 however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 
2018
-
02
 on the Consolidated Financial Statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-18-008370:notes:138]
7

[0001437749-18-008370:notes:139]
[same as prior period, unchanged from 0001437749-17-018040:notes:156]

[0001437749-18-008370:notes:140]
The Company has company-sponsored defined benefit pension plans covering employees in the U.K., Germany, the Philippines, China, Japan, and France. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0001437749-18-008370:notes:141]
The Company recognizes interest costs, expected return on plan assets, and amortization, net within 
Other (income) expense, net
 in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the 
three
 months ended 
 March 31, 2018 
and 
 April 1, 2017 
were as follows:

[0001437749-18-008370:notes:142]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 533 |  |  | $ | 408 |  |
| Interest cost |  |  | 501 |  |  |  | 360 |  |
| Expected return on plan assets |  |  | (540 | ) |  |  | (476 | ) |
| Amortization, net |  |  | 74 |  |  |  | 84 |  |
| Net periodic benefit cost |  | $ | 568 |  |  | $ | 376 |  |

[0001437749-18-008370:notes:143]
The Company expects to make approximately 
$2.3
 million of cash contributions to its pension plans in 
2018.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001437749-18-008370:notes:144]
11

[0001437749-18-008370:notes:145]
. Related Party Transactions

[0001437749-18-008370:notes:146]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0001437749-18-008370:notes:147]
Powersem

[0001437749-18-008370:notes:148]
GmbH

[0001437749-18-008370:notes:149]
:
 The Company owns 
45%
 of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the 
three
 months ended 
 March 31, 2018, 
the Company recorded revenues of 
$0.1
 million from sales of products to Powersem for use as components in their products. During the 
three
 months ended 
 March 31, 2018, 
the Company purchased 
$1.1
 million of products from Powersem. At 
 March

[0001437749-18-008370:notes:150]
31,

[0001437749-18-008370:notes:151]
2018,
 the accounts receivable balance from Powersem was 
$0.1
 million and the accounts payable balance to Powersem was 
$0.3
 million.

[0001437749-18-008370:notes:152]
EB Tech Ltd.:
 The Company owns approximately 
20%
 of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the 
three
 months ended 
 March 31, 2018 
EB Tech rendered processing services for the Company totaling approximately 
$0.1
 million. As of 
 March

[0001437749-18-008370:notes:153]
2018,
 the Company’s accounts payable balance to EB Tech was immaterial.

[0001437749-18-008370:notes:154]
Automated Technology, Inc.
: The Company owns approximately 
24%
 of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the 
three
 months ended 
 March 31, 2018, 
ATEC rendered assembly and test services to the Company totaling approximately 
$2.4
 million. As of 
 March

[0001437749-18-008370:notes:155]
2018,
 the Company’s accounts payable balance to ATEC was 
$0.8
 million.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001437749-18-008370:notes:156]
Revenue Recognition

[0001437749-18-008370:notes:157]
Adoption

[0001437749-18-008370:notes:158]
On 
 December 31, 2017, 
the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did 
not
 have a significant impact on the Company’s consolidated financial statements.

[0001437749-18-008370:notes:159]
Revenue Disaggregation

[0001437749-18-008370:notes:160]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 months ended 
 March 31, 2018:

[0001437749-18-008370:notes:161]
See Note 
12,

[0001437749-18-008370:notes:162]
Segment Information
 for net sales by segment and countries.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-18-008370:notes:163]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do 
not
 transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and 
 may 
include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent 
third
-party distributors.

[0001437749-18-008370:notes:164]
The Company has elected the practical expedient under ASC 
340
-
40
-
25
-
4
 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than 
one
 year.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001437749-18-008370:notes:165]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments (a) |  |  | Unrealized gain/(loss) on investments |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 30, 2017 |  | $ | (10,836 | ) |  | $ | 9,795 |  |  | $ | (62,627 | ) |  | $ | (63,668 | ) |
| Cumulative effect adjustment (b) |  |  | — |  |  |  | (9,795 | ) |  |  | — |  |  |  | (9,795 | ) |
| Activity in the period |  |  | (3 | ) |  |  | — |  |  |  | (276 | ) |  |  | (279 | ) |
| Balance at March 31, 2018 |  | $ | (10,839 | ) |  | $ | — |  |  | $ | (62,903 | ) |  | $ | (73,742 | ) |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-18-008370:notes:166]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 123,877 |  |  | $ | 86,658 |  |
| China(a) |  |  | 106,508 |  |  |  | 78,219 |  |
| Other countries(b) |  |  | 187,428 |  |  |  | 120,564 |  |
| Total net sales |  | $ | 417,813 |  |  | $ | 285,441 |  |

[0001437749-18-008370:notes:167]
| (in thousands) |  | March 31, 2018 |  |  | December 30, 2017 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 49,132 |  |  | $ | 23,490 |  |
| China(a) |  |  | 91,676 |  |  |  | 86,866 |  |
| Mexico |  |  | 64,176 |  |  |  | 62,510 |  |
| Germany |  |  | 36,232 |  |  |  | 1,082 |  |
| Philippines |  |  | 30,734 |  |  |  | 31,129 |  |
| Other countries |  |  | 65,255 |  |  |  | 45,500 |  |
| Total long-lived assets |  | $ | 337,205 |  |  | $ | 250,577 |  |

[0001437749-18-008370:notes:168]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 2,909 |  |  | $ | 332 |  |
| China(a) |  |  | 5,144 |  |  |  | 2,392 |  |
| Mexico |  |  | 3,310 |  |  |  | 6,978 |  |
| Germany |  |  | 3,038 |  |  |  | 45 |  |
| Philippines |  |  | 2,162 |  |  |  | 855 |  |
| Other countries |  |  | 1,346 |  |  |  | 1,775 |  |
| Total additions to long-lived assets |  | $ | 17,909 |  |  | $ | 12,377 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-18-008370:notes:169]
|  |  | For the Three Months Ended |  |
| (in thousands) |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 264,411 |  |  | $ | 153,767 |  |
| Automotive |  |  | 126,131 |  |  |  | 107,839 |  |
| Industrial |  |  | 27,271 |  |  |  | 23,835 |  |
| Total net sales |  | $ | 417,813 |  |  | $ | 285,441 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 13,678 |  |  | $ | 8,387 |  |
| Automotive |  |  | 5,970 |  |  |  | 5,371 |  |
| Industrial |  |  | 1,460 |  |  |  | 1,314 |  |
| Other |  |  | 2,504 |  |  |  | — |  |
| Total depreciation and amortization |  | $ | 23,612 |  |  | $ | 15,072 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 53,964 |  |  | $ | 35,206 |  |
| Automotive |  |  | 18,390 |  |  |  | 15,065 |  |
| Industrial |  |  | 4,709 |  |  |  | 106 |  |
| Other(a) |  |  | (39,492 | ) |  |  | (1,525 | ) |
| Total operating income |  |  | 37,571 |  |  |  | 48,852 |  |
| Interest expense |  |  | 5,423 |  |  |  | 3,120 |  |
| Foreign exchange loss (gain) |  |  | (10,555 | ) |  |  | (1,557 | ) |
| Other income, net |  |  | (1,943 | ) |  |  | (139 | ) |
| Income before income taxes |  | $ | 44,646 |  |  | $ | 47,428 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001437749-18-008370:notes:170]
| (in thousands) |  | Littelfuse, Inc. Shareholders’ Equity |  |  | Non- controlling Interest |  |  | Total |  |
| Balance at December 30, 2017 |  | $ | 927,419 |  |  | $ | 137 |  |  | $ | 927,556 |  |
| Net income |  |  | 36,029 |  |  |  | — |  |  |  | 36,029 |  |
| Other comprehensive income |  |  | (279 | ) |  |  | — |  |  |  | (279 | ) |
| Stock-based compensation |  |  | 8,714 |  |  |  | — |  |  |  | 8,714 |  |
| Withheld shares on restricted share units for withholding taxes |  |  | (2,758 | ) |  |  | — |  |  |  | (2,758 | ) |
| Stock options exercised |  |  | 9,609 |  |  |  | — |  |  |  | 9,609 |  |
| Issuance of common stock(a) |  |  | 472,301 |  |  |  | — |  |  |  | 472,301 |  |
| Cash dividends paid ($0.37 per share) |  |  | (9,198 | ) |  |  | — |  |  |  | (9,198 | ) |
| Non-controlling interest |  |  | — |  |  |  | — |  |  |  | — |  |
| Balance at March 31, 2018 |  | $ | 1,441,837 |  |  | $ | 137 |  |  | $ | 1,441,974 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-18-008370:notes:171]
[same as prior period, unchanged from 0001437749-17-018040:notes:167]

[0001437749-18-008370:notes:172]
[same as prior period, unchanged from 0001437749-17-018040:notes:169]

[0001437749-18-008370:notes:173]
The Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it 
 may 
earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”).  The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does 
not
 evaluate the operating segments using discrete balance sheet information.

[0001437749-18-008370:notes:174]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the 
three
 operating segments.  The Company does 
not
 report inter-segment revenue because the operating segments do 
not
 record it.  Certain expenses, determined by the CODM to be strategic in nature and 
not
 directly related to segments current results, are 
not
 allocated but identified as “Other”.  Additionally, the Company does 
not
 allocate interest and other income, interest expense, or taxes to operating segments.  These costs are 
not
 allocated to the segments, as management excludes such costs when assessing the performance of the segments.  Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in 
one
 segment 
 may 
benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001437749-18-008370:notes:175]
|  | ● | Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, gas discharge tubes; semiconductor and power semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon carbide, metal-oxide-semiconductor field-effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including consumer electronics, automotive electronics, IT and telecommunications equipment, medical devices, lighting products, and white goods. |

[0001437749-18-008370:notes:176]
|  | ● | Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in the automotive, commercial vehicle, and agricultural and construction equipment industries. Passenger car fuse products include fuses and fuse accessories, including blade fuses, battery cable protectors, varistors, high-current fuses, and high-voltage fuses for hybrid and electric vehicles. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle sensors designed to monitor the passenger compartment occupants and environment as well as the vehicle’s powertrain, emissions, speed and suspension. |

[0001437749-18-008370:notes:177]
|  | ● | Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in heavy industrial applications such as mining, oil and gas, energy storage, construction, HVAC systems, elevator and other industrial equipment. |

[0001437749-18-008370:notes:178]
[same as prior period, unchanged from 0001437749-17-018040:notes:175]

[0001437749-18-008370:notes:179]
(a) For the 
first
 quarter of 
2018,
 “Other” Operating income (loss) of 
$39.5
 million consists of 
$38.6
 million in acquisition and integration costs associated with the Company’s 
2018
 acquisition of IXYS (
$18.4
 million included in Cost of sales (“COS”), of which 
$17.9
 million relates to fair value inventory adjustments, 
$16.1
 million included in Selling, general, and administrative expenses (“SG&A), 
$1.6
 million in Research and development (“R&D”) 
$2.5
 million in backlog amortization expense), 
$0.8
 million in restructuring costs (
$0.5
 million included in COS and 
$0.3
 million in SG&A) and 
$0.1
 million in year acquisition and integration costs associated with the Company’s 
2017
 acquisitions in SG&A.

[0001437749-18-008370:notes:180]
For the 
first
 quarter of 
2017,
 “Other” Operating income (loss) of 
$1.5
 million consists of acquisition and integration costs associated with the Company’s 
2016
 acquisitions (included in COS and SG&A).

[0001437749-18-008370:notes:181]
The Company’s net sales by country were as follows:

[0001437749-18-008370:notes:182]
(a) Includes mainland China, Taiwan, and Hong Kong.

[0001437749-18-008370:notes:183]
(b) Each country included in Other countries are less than 
10%
 of net sales.

[0001437749-18-008370:notes:184]
The Company’s long-lived assets by country, as of 
 March 31, 2018 
and 
 April 1, 2017, 
were as follows:

[0001437749-18-008370:notes:185]
The Company’s additions to long-lived assets by country were as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-18-008370:notes:186]
[same as prior period, unchanged from 0001437749-17-018040:notes:183]

[0001437749-18-008370:notes:187]
[same as prior period, unchanged from 0001437749-17-018040:notes:184]

[0001437749-18-008370:notes:188]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global leader in circuit protection products with advancing platforms in power control and sensor technologies, serving customers in the electronics, automotive, and industrial markets. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy, ranging across consumer electronics, IT and telecommunication applications, industrial electronics, automobiles and other transportation, and heavy industrial applications. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance.

[0001437749-18-008370:notes:189]
Ship

[0001437749-18-008370:notes:190]
and

[0001437749-18-008370:notes:191]
Debit Program

[0001437749-18-008370:notes:192]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-18-008370:notes:193]
Volume Rebates

[0001437749-18-008370:notes:194]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-18-008370:notes:195]
8

[0001437749-18-008370:notes:196]
.

[0001437749-18-008370:notes:197]
Shareholders’ Equity

[0001437749-18-008370:notes:198]
The following table sets forth the changes in shareholders’ equity for the 
three
 months ended 
 March 31, 2018:

[0001437749-18-008370:notes:199]
(a) The issuance of common stock (
2,092,491
 shares) during the 
three
 months ended 
 March 31, 2018 
relates to the acquisition of IXYS. See Note 
2,

[0001437749-18-008370:notes:200]
Acquisitions 
for further discussion.

[0001437749-18-008370:notes:201]
The following table sets forth the changes in the components of Accumulated Other Comprehensive Income (Loss) by component for the 
three
 months ended 
 March 31, 2018:

[0001437749-18-008370:notes:202]
(a) The balances at 
 March 31, 2018 
and 
 December 30, 2017 
are net of taxes of 
$0.2
 million and 
$1.4
 million, respectively.

[0001437749-18-008370:notes:203]
(b) The Company adopted ASU 
2016
-
01
 on 
 December 31, 2018 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings. See Note 
1,

[0001437749-18-008370:notes:204]
Summary of Significant Accounting Policies and Other Information
, for further discussion.
