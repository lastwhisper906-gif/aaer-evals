# LFUS 8-K — 0001437749-18-008297 filed 2018-05-02

## item codes, every 8-K on or before 2018-05-02

- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2018-05-02

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-008297:8k_2_02:1]
EX-99.1
2
ex_112059.htm
EXHIBIT 99.1

[0001437749-18-008297:8k_2_02:2]
ex_112059.htm

[0001437749-18-008297:8k_2_02:3]
Exhibit 99.1

[0001437749-18-008297:8k_2_02:4]
| NEWS RELEASE |  | Littelfuse Inc. 8755 West Higgins Road, Suite 500 Chicago, Illinois 60631 p: (773) 682-1000 f: (773) 628-0802 www.littelfuse.com |

[0001437749-18-008297:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS

[0001437749-18-008297:8k_2_02:6]
Company delivers record sales and adjusted earnings per share

[0001437749-18-008297:8k_2_02:7]
CHICAGO, May 2, 2018 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the first quarter ended March 31, 2018:

[0001437749-18-008297:8k_2_02:8]
| ● | Net sales were $417.8 million, up 46% versus the prior year. Organic revenue growth was 10%. |

[0001437749-18-008297:8k_2_02:9]
| ● | Growth by segment versus the prior year period: |

[0001437749-18-008297:8k_2_02:10]
|  | o | Electronics sales increased 72% (up 10% organically) |

[0001437749-18-008297:8k_2_02:11]
|  | o | Automotive sales increased 17% (up 10% organically) |

[0001437749-18-008297:8k_2_02:12]
|  | o | Industrial sales increased 14% (up 13% organically) |

[0001437749-18-008297:8k_2_02:13]
| ● | GAAP diluted EPS was $1.45; this includes $23 million of after-tax charges primarily related to certain purchase accounting adjustments and costs for the acquisition of IXYS Corporation, net of non-operating foreign exchange gains |

[0001437749-18-008297:8k_2_02:14]
| ● | Adjusted diluted EPS of $2.39 increased 41% over last year |

[0001437749-18-008297:8k_2_02:15]
| ● | GAAP effective tax rate was 19.3% and the adjusted effective tax rate was 19.6% |

[0001437749-18-008297:8k_2_02:16]
| ● | Cash flow from operations was $69.3 million and free cash flow was $51.4 million |

[0001437749-18-008297:8k_2_02:17]
| ● | The electronics segment book-to-bill ratio for the first quarter was 1.14 (excluding IXYS) |

[0001437749-18-008297:8k_2_02:18]
"We continued our momentum with an exceptional start to 2018,” said Dave Heinzmann, Littelfuse Chief Executive Officer. “With our focus on the secular trends of a safer, greener and increasingly connected world, and consistent operational performance, we delivered sales and adjusted earnings that meaningfully exceeded our guidance. We are off to a strong start integrating the IXYS business, and have taken initial steps to drive synergy realization. Leveraging the broad-based demand across our businesses, we expect robust top-line growth and consistent operating margins in the second quarter. We are focused on the right growth opportunities to continue executing our long-term strategy and driving double digit sales and earnings growth.”

[0001437749-18-008297:8k_2_02:19]
-more-

[0001437749-18-008297:8k_2_02:20]
For the second quarter of 2018*:

[0001437749-18-008297:8k_2_02:21]
| ● | Net sales are expected to be in the range of $450 to $462 million, up 45% on a reported basis and up 8% organically, at the midpoint versus the prior year quarter |
| ● | Adjusted diluted earnings per share are expected to be in the range of $2.39 to $2.53, representing 17% growth over the prior year quarter at the midpoint |
| ● | Similar to prior years, second quarter stock compensation expense is higher than other quarters due to equity grant provisions, equating to approximately eight cents of earnings per share |
| ● | Adjusted effective tax rate is expected to be in the range of 19.5% to 20.5%; the midpoint is approximately 500 basis points higher than the prior year quarter. At a constant year-over-year tax rate, EPS growth would be 25% |

[0001437749-18-008297:8k_2_02:22]
The guidance includes a full quarter of IXYS results, along with a full quarter of related share dilution and interest expense from the debt issued in conjunction with the transaction.

[0001437749-18-008297:8k_2_02:23]
For the 2018 full year, the company expects an adjusted effective tax rate in the range of 18% – 21%.

[0001437749-18-008297:8k_2_02:24]
*All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, certain purchase accounting adjustments, foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-18-008297:8k_2_02:25]
Dividend and Share Repurchase Authorization

[0001437749-18-008297:8k_2_02:26]
| ● | The company will pay a cash dividend on its common stock of $0.37 per share on June 7, 2018 to shareholders of record as of May 24, 2018 |

[0001437749-18-008297:8k_2_02:27]
| ● | The company’s previous share repurchase authorization expired on April 30, 2018 and has been replaced with a one million share repurchase authorization effective through April 30, 2019. No shares were repurchased under the former authorization |

[0001437749-18-008297:8k_2_02:28]
Conference Call and Webcast Information

[0001437749-18-008297:8k_2_02:29]
Littelfuse will host a conference call today, Wednesday, May 2, 2018, at 9:00 a.m. Central / 10:00 a.m. Eastern time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0001437749-18-008297:8k_2_02:30]
About Littelfuse

[0001437749-18-008297:8k_2_02:31]
Founded in 1927, Littelfuse is the global leader in circuit protection with advancing platforms in power control and sensor technologies. The company serves customers in the electronics, automotive and industrial markets with products that include fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has more than 11,000 employees in more than 50 locations worldwide. For more information, please visit Littelfuse.com.

[0001437749-18-008297:8k_2_02:32]
-more-

[0001437749-18-008297:8k_2_02:33]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; the integration of the recently acquired business of IXYS Corporation ("IXYS") and the risk that expected benefits, synergies and growth prospects of the acquisition of IXYS may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 30, 2017. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 30, 2017.

[0001437749-18-008297:8k_2_02:34]
Non-GAAP Financial Measures

[0001437749-18-008297:8k_2_02:35]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0001437749-18-008297:8k_2_02:36]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-18-008297:8k_2_02:37]
-more-

[0001437749-18-008297:8k_2_02:38]
CONTACT:  Meenal Sethna

[0001437749-18-008297:8k_2_02:39]
Executive Vice President and CFO

[0001437749-18-008297:8k_2_02:40]
(773) 628-0616

[0001437749-18-008297:8k_2_02:41]
###

[0001437749-18-008297:8k_2_02:42]
LFUS-F

[0001437749-18-008297:8k_2_02:43]
| LITTELFUSE, INC. |
| Net Sales and Operating Income by Segment |
| (In thousands of USD, unaudited) |

[0001437749-18-008297:8k_2_02:44]
|  |  | First Quarter |  |
|  |  | 2018 |  |  | 2017 |  |  | % Growth / (Decline) |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 264,411 |  |  | $ | 153,767 |  |  | 72% |  |
| Automotive |  |  | 126,131 |  |  |  | 107,839 |  |  | 17% |  |
| Industrial |  |  | 27,271 |  |  |  | 23,835 |  |  | 14% |  |
| Total net sales |  | $ | 417,813 |  |  | $ | 285,441 |  |  | 46% |  |

[0001437749-18-008297:8k_2_02:45]
|  |  | First Quarter |  |
|  |  | 2018 |  |  | 2017 |  |  | % Growth / (Decline) |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 53,964 |  |  | $ | 35,206 |  |  | 53% |  |
| Automotive |  |  | 18,390 |  |  |  | 15,065 |  |  | 22% |  |
| Industrial |  |  | 4,709 |  |  |  | 106 |  |  | N.M. |  |
| Other (1) |  |  | (39,492 | ) |  |  | (1,525 | ) |  | N.M. |  |
| Total operating income |  | $ | 37,571 |  |  | $ | 48,852 |  |  | (23%) |  |
| Operating margin |  |  | 9.0 | % |  |  | 17.1 | % |  |  |  |
| Interest expense |  |  | 5,423 |  |  |  | 3,120 |  |  |  |  |
| Foreign exchange gain |  |  | (10,555 | ) |  |  | (1,557 | ) |  |  |  |
| Other income, net |  |  | (1,943 | ) |  |  | (139 | ) |  |  |  |
| Income before taxes |  | $ | 44,646 |  |  | $ | 47,428 |  |  | (6%) |  |

[0001437749-18-008297:8k_2_02:46]
| N.M. - Not meaningful |

[0001437749-18-008297:8k_2_02:47]
| (1) "Other" typically includes non-GAAP adjustments such as acquisition-related costs, purchase accounting inventory adjustments and other charges, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details.) |

[0001437749-18-008297:8k_2_02:48]
|  |  | First Quarter |  |
|  |  | 2018 |  |  | 2017 |  |  | Growth / (Decline) |  |
| Operating Margins |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  |  | 20.4 | % |  |  | 22.9 | % |  |  | (2.5% | ) |
| Automotive |  |  | 14.6 | % |  |  | 14.0 | % |  |  | 0.6 | % |
| Industrial |  |  | 17.3 | % |  |  | 0.4 | % |  |  | 16.8 | % |

[0001437749-18-008297:8k_2_02:49]
-more-

[0001437749-18-008297:8k_2_02:50]
| LITTELFUSE, INC. |  |
| Condensed Consolidated Balance Sheets |  |
| (In thousands of USD) |  |

[0001437749-18-008297:8k_2_02:51]
|  |  | March 31, 2018 |  |  | December 30, 2017 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 412,458 |  |  | $ | 429,676 |  |
| Short-term investments |  |  | 37 |  |  |  | 35 |  |
| Accounts receivable, less allowances |  |  | 244,905 |  |  |  | 182,699 |  |
| Inventories |  |  | 263,969 |  |  |  | 140,789 |  |
| Prepaid income taxes and income taxes receivable |  |  | 3,899 |  |  |  | 1,689 |  |
| Prepaid expenses and other current assets |  |  | 47,794 |  |  |  | 37,452 |  |
| Total current assets |  |  | 973,062 |  |  |  | 792,340 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 29,575 |  |  |  | 9,547 |  |
| Buildings |  |  | 118,170 |  |  |  | 86,599 |  |
| Equipment |  |  | 555,578 |  |  |  | 505,838 |  |
|  |  |  | 703,323 |  |  |  | 601,984 |  |
| Accumulated depreciation |  |  | (366,118 | ) |  |  | (351,407 | ) |
| Net property, plant and equipment |  |  | 337,205 |  |  |  | 250,577 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 129,610 |  |  |  | 81,911 |  |
| Distribution network |  |  | 11,038 |  |  |  | 12,872 |  |
| Customer lists, trademarks and tradenames |  |  | 254,755 |  |  |  | 109,067 |  |
| Backlog |  |  | 10,003 |  |  |  |  |  |
| Goodwill |  |  | 840,574 |  |  |  | 453,414 |  |
|  |  |  | 1,245,980 |  |  |  | 657,264 |  |
| Investments |  |  | 31,128 |  |  |  | 10,993 |  |
| Deferred income taxes |  |  | 12,039 |  |  |  | 11,858 |  |
| Other assets |  |  | 28,096 |  |  |  | 17,070 |  |
| Total assets |  | $ | 2,627,510 |  |  | $ | 1,740,102 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 120,817 |  |  | $ | 101,844 |  |
| Accrued payroll |  |  | 41,220 |  |  |  | 49,962 |  |
| Accrued expenses |  |  | 74,925 |  |  |  | 48,994 |  |
| Accrued severance |  |  | 1,367 |  |  |  | 1,459 |  |
| Accrued income taxes |  |  | 15,938 |  |  |  | 16,285 |  |
| Current portion of long-term debt |  |  | 10,111 |  |  |  | 6,250 |  |
| Total current liabilities |  |  | 264,378 |  |  |  | 224,794 |  |
| Long-term debt, less current portion |  |  | 743,437 |  |  |  | 489,361 |  |
| Deferred income taxes |  |  | 60,525 |  |  |  | 17,069 |  |
| Accrued post-retirement benefits |  |  | 35,817 |  |  |  | 18,742 |  |
| Other long-term liabilities |  |  | 81,379 |  |  |  | 62,580 |  |
| Total equity |  |  | 1,441,974 |  |  |  | 927,556 |  |
| Total liabilities and equity |  | $ | 2,627,510 |  |  | $ | 1,740,102 |  |

[0001437749-18-008297:8k_2_02:52]
-more-

[0001437749-18-008297:8k_2_02:53]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Comprehensive Income |
| (In thousands of USD, except per share data, unaudited) |

[0001437749-18-008297:8k_2_02:54]
|  |  | For the Three Months Ended |  |
|  |  | March 31, 2018 |  |  | April 1, 2017 |  |
| Net sales |  | $ | 417,813 |  |  | $ | 285,441 |  |
| Cost of sales |  |  | 268,190 |  |  |  | 171,791 |  |
| Gross profit |  |  | 149,623 |  |  |  | 113,650 |  |
| Selling, general and administrative expenses |  |  | 77,514 |  |  |  | 46,703 |  |
| Research and development expenses |  |  | 22,540 |  |  |  | 12,151 |  |
| Amortization of intangibles |  |  | 11,998 |  |  |  | 5,944 |  |
|  |  |  | 112,052 |  |  |  | 64,798 |  |
| Operating income |  |  | 37,571 |  |  |  | 48,852 |  |
| Interest expense |  |  | 5,423 |  |  |  | 3,120 |  |
| Foreign exchange gain |  |  | (10,555 | ) |  |  | (1,557 | ) |
| Other income, net |  |  | (1,943 | ) |  |  | (139 | ) |
| Income before income taxes |  |  | 44,646 |  |  |  | 47,428 |  |
| Income taxes |  |  | 8,617 |  |  |  | 8,537 |  |
| Net income |  | $ | 36,029 |  |  | $ | 38,891 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.48 |  |  | $ | 1.71 |  |
| Diluted |  | $ | 1.45 |  |  | $ | 1.69 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 24,339 |  |  |  | 22,748 |  |
| Diluted |  |  | 24,775 |  |  |  | 22,989 |  |
| Comprehensive income |  | $ | 35,750 |  |  | $ | 44,518 |  |

[0001437749-18-008297:8k_2_02:55]
-more-

[0001437749-18-008297:8k_2_02:56]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Cash Flows |
| (In thousands of USD, unaudited) |

[0001437749-18-008297:8k_2_02:57]
|  |  | For theThree Months Ended |  |
|  |  | March 31, 2018 |  |  | April 1, 2017 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 36,029 |  |  | $ | 38,891 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 11,614 |  |  |  | 9,128 |  |
| Amortization of intangibles |  |  | 11,998 |  |  |  | 5,944 |  |
| Provision for bad debts |  |  | (13 | ) |  |  | 351 |  |
| Stock-based compensation |  |  | 8,714 |  |  |  | 3,583 |  |
| Non-cash inventory charges |  |  | 17,896 |  |  |  | - |  |
| Unrealized gain on investments |  |  | (1,864 | ) |  |  | - |  |
| Loss on sale of assets |  |  | 99 |  |  |  | 600 |  |
| Deferred income taxes |  |  | 842 |  |  |  | 616 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (8,417 | ) |  |  | (2,719 | ) |
| Inventories |  |  | (269 | ) |  |  | (3,296 | ) |
| Accounts payable |  |  | 2,990 |  |  |  | (3,295 | ) |
| Accrued expenses (including post-retirement) |  |  | 12,573 |  |  |  | 4,140 |  |
| Accrued payroll and severance |  |  | (18,607 | ) |  |  | (20,221 | ) |
| Accrued income taxes |  |  | (1,174 | ) |  |  | (220 | ) |
| Prepaid expenses and other assets |  |  | (3,143 | ) |  |  | (10,559 | ) |
| Net cash provided by operating activities |  |  | 69,268 |  |  |  | 22,943 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (17,909 | ) |  |  | (12,377 | ) |
| Acquisition of business, net of cash acquired |  |  | (306,487 | ) |  |  | (14,172 | ) |
| Proceeds from maturities of short-term investments |  |  | - |  |  |  | 3,739 |  |
| Decrease in entrusted loan receivable |  |  | - |  |  |  | 655 |  |
| Proceeds from sale of assets |  |  | 19 |  |  |  | 57 |  |
| Net cash used in investing activities |  |  | (324,377 | ) |  |  | (22,098 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 50,000 |  |  |  | - |  |
| Proceeds of term loan |  |  | 75,000 |  |  |  | - |  |
| Payments of revolving credit facility |  |  | (47,000 | ) |  |  | (112,500 | ) |
| Payments of term loan |  |  | (2,500 | ) |  |  | (1,563 | ) |
| Net proceeds from senior notes payable |  |  | 175,000 |  |  |  | 125,000 |  |
| Payments of entrusted loan |  |  | - |  |  |  | (655 | ) |
| Debt issuance costs paid |  |  | (878 | ) |  |  | (71 | ) |
| Cash dividends paid |  |  | (9,198 | ) |  |  | (7,472 | ) |
| Net (payments) proceeds related to stock-based award activities |  |  | (116 | ) |  |  | 199 |  |
| Net cash provided by financing activities |  |  | 240,308 |  |  |  | 2,938 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,417 | ) |  |  | (928 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (17,218 | ) |  |  | 2,855 |  |
| Cash and cash equivalents at beginning of period |  |  | 429,676 |  |  |  | 275,124 |  |
| Cash and cash equivalents at end of period |  | $ | 412,458 |  |  | $ | 277,979 |  |

[0001437749-18-008297:8k_2_02:58]
-more-

[0001437749-18-008297:8k_2_02:59]
| LITTELFUSE, INC. |
| Supplemental Financial Information |
| (in millions of USD except per share amounts, unaudited) |

[0001437749-18-008297:8k_2_02:60]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-18 |  |  | Q1-17 |  |
| GAAP diluted EPS |  | $ | 1.45 |  |  | $ | 1.69 |  |
| EPS impact of Non-GAAP adjustments (below) |  |  | 0.94 |  |  |  | - |  |
| Adjusted diluted EPS |  | $ | 2.39 |  |  | $ | 1.69 |  |

[0001437749-18-008297:8k_2_02:61]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q1-18 |  |  | Q1-17 |  |
| Acquisition related and integration costs |  | $ | 11.7 |  |  | $ | 1.5 |  |
| Restructuring |  |  | 0.8 |  |  |  | - |  |
| Amortization backlog - IXYS |  |  | 2.5 |  |  |  | - |  |
| Change in control - IXYS |  |  | 2.1 |  |  |  | - |  |
| Acquisition related stock-based compensation charge |  |  | 4.5 |  |  |  | - |  |
| Purchase accounting inventory adjustments |  |  | 17.9 |  |  |  | - |  |
| Non-gaap adjustments to operating income |  |  | 39.5 |  |  |  | 1.5 |  |
| Non-operating foreign exchange gain |  |  | (10.6 | ) |  |  | (1.6 | ) |
| Non-gaap adjustments to income before income taxes |  |  | 28.9 |  |  |  | (0.1 | ) |
| Income taxes |  |  | 5.8 |  |  |  | - |  |
| Non-gaap adjustments to net income |  | $ | 23.1 |  |  | $ | (0.1 | ) |
| Total EPS impact |  | $ | 0.94 |  |  | $ | - |  |

[0001437749-18-008297:8k_2_02:62]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-18 |  |  | Q1-17 |  |
| Net sales |  | $ | 417.8 |  |  | $ | 284.4 |  |
| GAAP operating income |  | $ | 37.6 |  |  | $ | 48.9 |  |
| Add back non-gaap adjustments |  |  | 39.5 |  |  |  | 1.5 |  |
| Adjusted operating income |  | $ | 77.1 |  |  | $ | 50.4 |  |
| Adjusted operating margin |  |  | 18.5 | % |  |  | 17.7 | % |
| Add back amortization |  |  | 12.0 |  |  |  | 5.9 |  |
| Add back depreciation |  |  | 11.6 |  |  |  | 9.1 |  |
| Adjusted EBITDA |  | $ | 100.7 |  |  | $ | 65.4 |  |
| Adjusted EBITDA margin |  |  | 24.1 | % |  |  | 23.0 | % |

[0001437749-18-008297:8k_2_02:63]
| Net sales reconciliation |  | Q1-18 vs. Q1-17 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales growth |  |  | 72 | % |  |  | 17 | % |  |  | 14 | % |  |  | 46 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 58 | % |  |  | - |  |  |  | - |  |  |  | 31 | % |
| Divestitures |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| FX impact |  |  | 4 | % |  |  | 7 | % |  |  | 1 | % |  |  | 5 | % |
| Organic net sales growth |  |  | 10 | % |  |  | 10 | % |  |  | 13 | % |  |  | 10 | % |

[0001437749-18-008297:8k_2_02:64]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-18 |  |  | Q1-17 |  |
| Income taxes |  | $ | 8.6 |  |  | $ | 8.5 |  |
| Effective rate |  |  | 19.3 | % |  |  | 18.0 | % |
| Non-GAAP adjustments - income taxes |  |  | 5.8 |  |  |  | - |  |
| Adjusted income taxes |  | $ | 14.4 |  |  | $ | 8.5 |  |
| Adjusted effective rate |  |  | 19.6 | % |  |  | 18.0 | % |

[0001437749-18-008297:8k_2_02:65]
| Free cash flow reconcilation |  |  |  |  |  |  |  |  |
|  |  | Q1-18 |  |  | Q1-17 |  |
| Net cash provided by operating activities |  | $ | 69.3 |  |  | $ | 22.9 |  |
| Less: Purchases of property, plant and equipment |  |  | (17.9 | ) |  |  | (12.4 | ) |
| Free cash flow |  | $ | 51.4 |  |  | $ | 10.5 |  |

[0001437749-18-008297:8k_2_02:66]
| Note: Totals will not always foot due to rounding |

[0001437749-18-008297:8k_2_02:67]
#  #  #
