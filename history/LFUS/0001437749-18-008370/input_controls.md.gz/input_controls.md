# LFUS 10-Q controls and the auditor's report


## item_4_controls

[0001437749-18-008370:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001437749-18-008370:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001437749-18-008370:item_4_controls:3]
Disclosure controls and procedures (as defined in Rules 13a-15(b) and 15d-15(e) under the Exchange Act) are designed to ensure that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in the SEC rules and forms, and that such information is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001437749-18-008370:item_4_controls:4]
In connection with the preparation of this report, management, under the supervision and with the participation of the Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of March 31, 2018. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that, as of the quarter ended March 31, 2018, our disclosure controls and procedures were effective.

[0001437749-18-008370:item_4_controls:5]
(b) Changes in Internal Control over Financial Reporting

[0001437749-18-008370:item_4_controls:6]
The Company acquired IXYS Corporation on January 17, 2018.  IXYS Corporation operated with a different internal control environment than that of Littelfuse, Inc.  The Company’s evaluation of IXYS’ internal controls over financial reporting and integration of IXYS into the Company’s internal control structure is ongoing.  Otherwise, there were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15(f) and 15d-15(f) under the Exchange Act that occurred during the quarter ended March 31, 2018 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001437749-18-008370:item_4_controls:7]
29
