# LFUS note change history — 0001437749-17-018040 → 0001437749-18-008370


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-02):
[0001437749-18-008370:note_history:1]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global leader in circuit protection products with advancing platforms in power control and sensor technologies, serving customers in the electronics, automotive, and industrial markets. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy, ranging across consumer electronics, IT and telecommunication applications, industrial electronics, automobiles and other transportation, and heavy industrial applications. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance.

- changed (2018-05-02):
[0001437749-18-008370:note_history:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December
  (was, 2017-11-01, similarity 0.9994):
[0001437749-17-018040:note_history:2]
The 
Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

- added (2018-05-02):
[0001437749-18-008370:note_history:3]
2017,
 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are 
not
 necessarily indicative of annual operating results.

- added (2018-05-02):
[0001437749-18-008370:note_history:4]
Revenue Recognition

- added (2018-05-02):
[0001437749-18-008370:note_history:5]
Adoption

- added (2018-05-02):
[0001437749-18-008370:note_history:6]
On 
 December 31, 2017, 
the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did 
not
 have a significant impact on the Company’s consolidated financial statements.

- added (2018-05-02):
[0001437749-18-008370:note_history:7]
Revenue Disaggregation

- added (2018-05-02):
[0001437749-18-008370:note_history:8]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 months ended 
 March 31, 2018:

- added (2018-05-02):
[0001437749-18-008370:note_history:9]
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics - Semiconductor |  |  | 149,916 |  |  |  | — |  |  |  | — |  |  |  | 149,916 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,580 |  |  |  | — |  |  |  | 63,580 |  |
| Automotive Sensors |  |  | — |  |  |  | 31,323 |  |  |  | — |  |  |  | 31,323 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 31,228 |  |  |  | — |  |  |  | 31,228 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 27,271 |  |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |

- added (2018-05-02):
[0001437749-18-008370:note_history:10]
See Note 
12,

- added (2018-05-02):
[0001437749-18-008370:note_history:11]
Segment Information
 for net sales by segment and countries.

- added (2018-05-02):
[0001437749-18-008370:note_history:12]
Revenue Recognition

- added (2018-05-02):
[0001437749-18-008370:note_history:13]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do 
not
 transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and 
 may 
include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent 
third
-party distributors.

- added (2018-05-02):
[0001437749-18-008370:note_history:14]
The Company has elected the practical expedient under ASC 
340
-
40
-
25
-
4
 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than 
one
 year.

- added (2018-05-02):
[0001437749-18-008370:note_history:15]
Revenue and Billing

- added (2018-05-02):
[0001437749-18-008370:note_history:16]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than 
one
 year, the Company has elected the practical expedient under ASC 
606
-
10
-
32
-
18
 to 
not
 assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 
606
-
10
-
25
-
18B
 to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

- added (2018-05-02):
[0001437749-18-008370:note_history:17]
Ship

- added (2018-05-02):
[0001437749-18-008370:note_history:18]
and

- added (2018-05-02):
[0001437749-18-008370:note_history:19]
Debit Program

- added (2018-05-02):
[0001437749-18-008370:note_history:20]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2018-05-02):
[0001437749-18-008370:note_history:21]
Return to Stock

- added (2018-05-02):
[0001437749-18-008370:note_history:22]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

- added (2018-05-02):
[0001437749-18-008370:note_history:23]
Volume Rebates

- added (2018-05-02):
[0001437749-18-008370:note_history:24]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

- changed (2018-05-02):
[0001437749-18-008370:note_history:25]
In 
 March 2017, 
the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)  
No.
  (was, 2017-11-01, similarity 0.9533):
[0001437749-17-018040:note_history:25]
In 
 July 2015, 
the Financial Accounting Standards Board (
“FASB”) issued Accounting Standards Update (“ASU”) 
No.

- changed (2018-05-02):
[0001437749-18-008370:note_history:26]
2017
-
07
 “Compensation-Retirement Benefits (Topic 
715
): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income.  Under the previous guidance, net benefit cost was reported as an employee cost within operating income.  The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations.  ASU 
No.
  (was, 2017-11-01, similarity 0.9849):
[0001437749-17-018040:note_history:26]
2017
-
07
 “Compensation-Retirement Benefits (Topic 
715
): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changes the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the current guidance, net benefit cost is reported as an employee cost within operating income. The amendment requires the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU 
No.

- added (2018-05-02):
[0001437749-18-008370:note_history:27]
2017
-
07
 was effective for the 
first
 quarter of 
2018
 with the Company adopting the new standard on 
 December 31, 2017.

- added (2018-05-02):
[0001437749-18-008370:note_history:28]
2016
-
01,
 “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on 
 December 31, 2017, 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings.  As a result of the adoption of the new standard and change in fair value of our equity investments, for the 
three
 months ended 
 March 31, 2018, 
the Company recognized an unrealized gain of 
$1.9
 million  in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.

- changed (2018-05-02):
[0001437749-18-008370:note_history:29]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on 
 December 31, 2017 
using the modified retrospective method, however, 
no
 adjustment to retained earnings was needed. The new guidance did 
not
 have a material effect on the Company’s Condensed Consolidated Statements of Income. See the 
Revenue Recognition
 section above for further discussion.
  (was, 2017-11-01, similarity 0.7683):
[0001437749-17-018040:note_history:29]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August, 2015, 
the FASB issued ASU 
No.

- changed (2018-05-02):
[0001437749-18-008370:note_history:30]
In 
 October 2016, 
the FASB issued ASU 
No.
  (was, 2017-11-01, similarity 0.8571):
[0001437749-17-018040:note_history:30]
In 
 March 2016, 
the FASB issued ASU 
No.

- added (2018-05-02):
[0001437749-18-008370:note_history:31]
2016
-
16,
 "Income Taxes” (Topic 
740
). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on 
 December 31, 2017 
and it did 
not
 have a material impact.

- changed (2018-05-02):
[0001437749-18-008370:note_history:32]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the 
first
 quarter of 
2019.
 The Company is currently evaluating the impact of ASU 
2016
-
02.
  (was, 2017-11-01, similarity 0.9604):
[0001437749-17-018040:note_history:32]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition, however the Company plans to adopt the standard in the 
first
 quarter of 
2019.
 The Company is currently evaluating the impact of ASU 
2016
-
02.

- added (2018-05-02):
[0001437749-18-008370:note_history:33]
In 
 January 2018, 
the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions in the Tax Act. The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has 
not
 yet completed its assessment and therefore has 
not
 yet elected an accounting policy.

- changed (2018-05-02):
[0001437749-18-008370:note_history:34]
In 
 February 2018, 
the FASB issued ASU 
No.
  (was, 2017-11-01, similarity 0.9041):
[0001437749-17-018040:note_history:34]
In 
 January 2016, 
the FASB issued ASU 
No.

- added (2018-05-02):
[0001437749-18-008370:note_history:35]
2018
-
02
 “Income Statement—Reporting Comprehensive Income (Topic 
220
): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or 
not
 they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 
2018
-
02
 will be effective in the 
first
 quarter of 
2019;
 however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 
2018
-
02
 on the Consolidated Financial Statements.

- removed (2018-05-02):
[0001437749-17-018040:note_history:36]
Littelfuse, Inc. and subsidiaries (the “
Company”) is 
one
 of the world’s leading designer, manufacturer and supplier of circuit protection products, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s products protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.

- removed (2018-05-02):
[0001437749-17-018040:note_history:37]
2016,
 which should be read in conjunction with the disclosures therein.

- removed (2018-05-02):
[0001437749-17-018040:note_history:38]
In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are 
not
 necessarily indicative of annual operating results.

- removed (2018-05-02):
[0001437749-17-018040:note_history:39]
Certain reclassifications of prior year amounts for 
Trade receivables, net
 and

- removed (2018-05-02):
[0001437749-17-018040:note_history:40]
Prepaid expenses and other current assets
 were made to conform to the 
2017
 presentation.

- removed (2018-05-02):
[0001437749-17-018040:note_history:41]
Goodwill and Indefinite-Lived Intangible Assets

- removed (2018-05-02):
[0001437749-17-018040:note_history:42]
The 
Company annually tests goodwill and indefinite-lived intangible assets for impairment on the 
first
 day of its fiscal 
fourth
 quarter or at other dates if there is an event or change in circumstances that indicates the asset 
 may 
be impaired. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted 
five
-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after 
five
 years) to estimate market value. In addition, the Company compares its derived enterprise value on a consolidated basis to the Company’s market capitalization as of its test date to ensure its derived value approximates the market value of the Company when taken as a whole.

- removed (2018-05-02):
[0001437749-17-018040:note_history:43]
Factors the 
Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does 
not
 believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the Relays reporting unit if there are declines in profitability or projected future operating results and cash flows due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October 2, 2016, 
the Company concluded the fair value of the Relays reporting unit exceeded its carrying value of invested capital and therefore, 
no
 potential goodwill impairment existed. As of the 
2016
 annual test date, the Relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 September 30, 2017, 
there were 
no
 events or circumstances that indicate the Relays intangible assets were impaired.

- removed (2018-05-02):
[0001437749-17-018040:note_history:44]
In the 
third
 quarter of 
2016,
 due to continued declines in the potash market the Company conducted a goodwill impairment analysis of the Custom Products reporting unit and concluded that the 
reporting unit was impaired. The fair value of the unit was estimated using the expected present value of future cash flows over a 
seven
 year forecast period and appraisal of certain assets. This analysis required a write down of the reporting unit’s carrying value of 
$14.8
 million. A goodwill impairment loss of 
$8.8
 million and intangible assets impairments aggregating 
$6.0
 million were recognized during the 
third
 quarter, including a 
$3.8
 million reduction of the custom products trade names to a 
$0.7
 million remaining value and a 
$2.2
 million reduction of the reporting unit’s customer relationships to 
zero
 value.

- removed (2018-05-02):
[0001437749-17-018040:note_history:45]
2015
-
11
 – “Inventory (Topic 
330
): Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
The adoption of the update did 
not
 have a material impact on the Company’s consolidated financial position and results of operations. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

- removed (2018-05-02):
[0001437749-17-018040:note_history:46]
2016
-
09

- removed (2018-05-02):
[0001437749-17-018040:note_history:47]
– “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Condensed Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
As a result of the adoption, on a prospective basis, the Company recognized 
$0.1
 million and 
$1.9
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 and 
nine
 months ended 
 September 30, 2017, 
respectively. Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Condensed Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Condensed Consolidated Statement of Cash Flows. The Company elected 
not
 to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had 
no
 impact on the results of operations.

- removed (2018-05-02):
[0001437749-17-018040:note_history:48]
In 
 March 2017, 
the FASB issued ASU

- removed (2018-05-02):
[0001437749-17-018040:note_history:49]
No.

- removed (2018-05-02):
[0001437749-17-018040:note_history:50]
2017
-
07
 will be effective for the 
first
 quarter of 
2018
 and is required to be retrospectively adopted. Had this guidance been adopted as of 
 January 1, 2017, 
operating income within the Condensed Consolidated Statements of Income for the 
three
 months and 
nine
 months ended 
 September 30, 2017 
would have 
not
 changed by a material amount.

- removed (2018-05-02):
[0001437749-17-018040:note_history:51]
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350
). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity 
no
 longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December 15, 2020, 
with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January 1, 2017.

- removed (2018-05-02):
[0001437749-17-018040:note_history:52]
The Company expects to adopt the new standard in 
2017.

- removed (2018-05-02):
[0001437749-17-018040:note_history:53]
2016
-
01,
 “
Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU will require the Company to recognize any changes in the fair value of certain equity investments in net income. These changes are currently recognized in other comprehensive income ("OCI"). This guidance is effective for interim and fiscal years beginning after 
 December 15, 2017.

- removed (2018-05-02):
[0001437749-17-018040:note_history:54]
2015
-
14,
 which postponed the effective date of ASU 
No.

- removed (2018-05-02):
[0001437749-17-018040:note_history:55]
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted on the original effective date of fiscal years beginning after 
 December 15, 2016. 
The Company is in the process of performing its assessment of the potential impact on its consolidated financial statements, and anticipates adopting this standard using the modified retrospective method. While the Company is currently assessing the impact of the new standard, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does 
not
 expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may 
be affected. The Company has 
not
 yet quantified this potential impact.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001437749-18-008370:note_history:56]
The carrying amounts of debt at 
 March 31, 2018 
and 
 December 30, 2017 
are as follows:
  (was, 2017-11-01, similarity 0.6446):
[0001437749-17-018040:note_history:56]
September 30, 2017 
and 
 December 31, 2016 
were as follows:

- changed (2018-05-02):
[0001437749-18-008370:note_history:57]
| (in thousands) |  | March 31, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | 3,000 |  |  | $ | — |  |
| Term Loan |  |  | 195,000 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 144,041 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 116,956 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 111 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,560 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 753,548 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,111 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 743,437 |  |  | $ | 489,361 |  |
  (was, 2017-11-01, similarity 0.773):
[0001437749-17-018040:note_history:57]
| (in thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | 15,000 |  |  | $ | 112,500 |  |
| Term loan |  |  | 115,625 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | — |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 137,670 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 111,784 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,432 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 501,647 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (9,375 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 492,272 |  |  | $ | 447,892 |  |

- added (2018-05-02):
[0001437749-18-008370:note_history:58]
On 
 March 4, 2016, 
the Company entered into a 
five
-year credit agreement (“Credit Agreement”) with a group of lenders for up to 
$700.0
 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of 
$575.0
 million and an unsecured term loan credit facility (“Term Loan”) of up to 
$125.0
 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the Term Loan, the Company was required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.

- changed (2018-05-02):
[0001437749-18-008370:note_history:59]
On 
 October 13, 2017, 
the Company amended the Credit Agreement to increase the Revolving Credit Facility from 
$575.0
 million to 
$700.0
 million and increase the Term Loan from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans 
 may 
be made in up to 
two
 advances. The 
first
 advance of 
$125.0
 million occurred on 
 October 13, 2017 
and the 
second
 advance of 
$75.0
 million occurred on 
 January 16, 2018. 
For the Term Loan, the Company is required to make quarterly principal payments of 
1.25%
 of the original term loan (
$2.5
 million with the 
second
 advance on 
 January 16, 2018) 
through maturity, with the remaining balance due on 
 October 13, 2022.
  (was, 2017-11-01, similarity 0.6603):
[0001437749-17-018040:note_history:59]
On 
 October 13, 2017, 
the Company amended its existing 
Credit Agreement to increase the unsecured revolving credit facility from 
$575.0
 million to 
$700.0
 million and increase the unsecured term loan credit facility from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term loans 
 may 
be made in up to 
two
 advances, the 
first
 advance occurring on 
 October 13, 2017 
and the 
second
 advance, in the aggregate amount 
not
 to exceed 
$75.0
 million, to occur in the 
first
 quarter of 
2018.

- changed (2018-05-02):
[0001437749-18-008370:note_history:60]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
-month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.25%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
3.13%
 at 
 March 31, 2018.
  (was, 2017-11-01, similarity 0.9841):
[0001437749-17-018040:note_history:60]
Outstanding borrowings under the credit agreement bear interest, at the 
Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.73%
 at 
 September 30, 2017.

- changed (2018-05-02):
[0001437749-18-008370:note_history:61]
As of 
 March 31, 2018, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$696.9
 million of borrowing capacity under the Revolving Credit Facility. At 
 March 31, 2018, 
the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2017-11-01, similarity 0.736):
[0001437749-17-018040:note_history:61]
September 30, 2017, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$559.9
 million of borrowing capacity under the revolving credit facility. At 
 September 30, 2017, 
the Company was in compliance with all covenants under the credit agreement and expects to remain in compliance based on management’s estimates of operating and financial results for 
2017
 and the foreseeable future.

- changed (2018-05-02):
[0001437749-18-008370:note_history:62]
On 
 December 8, 2016, 
the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023 (
“Euro Senior Notes, Series A due 
2023”
), and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
“Euro Senior Notes, Series B due 
2028”
) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.
  (was, 2017-11-01, similarity 0.8003):
[0001437749-17-018040:note_history:62]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023, 
and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.

- added (2018-05-02):
[0001437749-18-008370:note_history:63]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022 (
“U.S. Senior Notes, Series A due 
2022”
), and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
“U.S. Senior Notes, Series B due 
2027”
) (together, the “U.S. Senior Notes due 
2022
 and 
2027”
) were funded. Interest on the U.S. Senior Notes due 
2022
 and 
2027
 is payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

- added (2018-05-02):
[0001437749-18-008370:note_history:64]
On 
 November 15, 2017, 
the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold 
$175
 million in aggregate principal amount of senior notes in 
two
 series. On 
 January 16, 2018,

- added (2018-05-02):
[0001437749-18-008370:note_history:65]
$50
 million aggregate principal amount of 
3.48%
 Senior Notes, Series A, due 
 February 15, 2025 (
“U.S. Senior Notes, Series A due 
2025”
) and 
$125
 million in aggregate principal amount of 
3.78%
 Senior Notes, Series B, due 
 February 15, 2030 (
“U.S. Senior Notes, Series B due 
2030”
) (together the “U.S. Senior Notes due 
2025
 and 
2030”
 and with the Euro Senior Notes and the U.S. Senior Notes 
2022
 and 
2027,
 the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 
2025
 and 
2030
 will be payable on 
 February 15 
and 
 August 15, 
commencing on 
 August 15, 2018.

- changed (2018-05-02):
[0001437749-18-008370:note_history:66]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 March 31, 2018, 
the Company was in compliance with all covenants under the Senior Notes.
  (was, 2017-11-01, similarity 0.9593):
[0001437749-17-018040:note_history:66]
The Senior Notes are subject to certain customary covenants, including limitations on the 
Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 September 30, 2017, 
the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.

- removed (2018-05-02):
[0001437749-17-018040:note_history:67]
The carrying amounts of debt at

- removed (2018-05-02):
[0001437749-17-018040:note_history:68]
On 
 March 4, 2016, 
the 
Company entered into a new 
five
 year credit agreement with a group of lenders for up to 
$700.0
 million. The new credit agreement consists of an unsecured revolving credit facility of 
$575.0
 million and an unsecured term loan credit facility of up to 
$125.0
 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.

- removed (2018-05-02):
[0001437749-17-018040:note_history:69]
As of

- removed (2018-05-02):
[0001437749-17-018040:note_history:70]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022, 
and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

- removed (2018-05-02):
[0001437749-17-018040:note_history:71]
Entrusted Loan

- removed (2018-05-02):
[0001437749-17-018040:note_history:72]
During 
2014,
 the 
Company entered into an entrusted loan arrangement (“Entrusted Loan”) of

- removed (2018-05-02):
[0001437749-17-018040:note_history:73]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan was reflected as both a long-term asset and long-term debt on the Company’s Condensed Consolidated Balance Sheets and was reflected in the investing and financing activities in its Condensed Consolidated Statements of Cash Flows. Interest expense and interest income are recorded between the lender and borrower with 
no
 net impact on the Company’s Condensed Consolidated Statements of Income since the amounts were offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan was used to finance the operation and working capital needs of the borrower and was scheduled to mature in 
 November 2019. 
The balance of the Entrusted Loan was paid off as of 
 September 30, 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001437749-18-008370:note_history:74]
| (in thousands) |  | March 31, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | 3,000 |  |  | $ | — |  |
| Term Loan |  |  | 195,000 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 144,041 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 116,956 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 111 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,560 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 753,548 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,111 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 743,437 |  |  | $ | 489,361 |  |
  (was, 2017-11-01, similarity 0.773):
[0001437749-17-018040:note_history:74]
| (in thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | 15,000 |  |  | $ | 112,500 |  |
| Term loan |  |  | 115,625 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | — |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 137,670 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 111,784 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,432 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 501,647 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (9,375 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 492,272 |  |  | $ | 447,892 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2018-05-02):
[0001437749-18-008370:note_history:75]
11

- added (2018-05-02):
[0001437749-18-008370:note_history:76]
. Related Party Transactions

- added (2018-05-02):
[0001437749-18-008370:note_history:77]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

- added (2018-05-02):
[0001437749-18-008370:note_history:78]
Powersem

- added (2018-05-02):
[0001437749-18-008370:note_history:79]
GmbH

- added (2018-05-02):
[0001437749-18-008370:note_history:80]
:
 The Company owns 
45%
 of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the 
three
 months ended 
 March 31, 2018, 
the Company recorded revenues of 
$0.1
 million from sales of products to Powersem for use as components in their products. During the 
three
 months ended 
 March 31, 2018, 
the Company purchased 
$1.1
 million of products from Powersem. At 
 March

- added (2018-05-02):
[0001437749-18-008370:note_history:81]
31,

- added (2018-05-02):
[0001437749-18-008370:note_history:82]
2018,
 the accounts receivable balance from Powersem was 
$0.1
 million and the accounts payable balance to Powersem was 
$0.3
 million.

- added (2018-05-02):
[0001437749-18-008370:note_history:83]
EB Tech Ltd.:
 The Company owns approximately 
20%
 of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the 
three
 months ended 
 March 31, 2018 
EB Tech rendered processing services for the Company totaling approximately 
$0.1
 million. As of 
 March

- added (2018-05-02):
[0001437749-18-008370:note_history:84]
31,

- added (2018-05-02):
[0001437749-18-008370:note_history:85]
2018,
 the Company’s accounts payable balance to EB Tech was immaterial.

- added (2018-05-02):
[0001437749-18-008370:note_history:86]
Automated Technology, Inc.
: The Company owns approximately 
24%
 of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the 
three
 months ended 
 March 31, 2018, 
ATEC rendered assembly and test services to the Company totaling approximately 
$2.4
 million. As of 
 March

- added (2018-05-02):
[0001437749-18-008370:note_history:87]
31,

- added (2018-05-02):
[0001437749-18-008370:note_history:88]
2018,
 the Company’s accounts payable balance to ATEC was 
$0.8
 million.


## lfus:RevenueRecognitionAndBillingPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-02):
[0001437749-18-008370:note_history:89]
Revenue and Billing

- added (2018-05-02):
[0001437749-18-008370:note_history:90]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than 
one
 year, the Company has elected the practical expedient under ASC 
606
-
10
-
32
-
18
 to 
not
 assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 
606
-
10
-
25
-
18B
 to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.


## lfus:RevenueRecognitionReturnToStockPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-02):
[0001437749-18-008370:note_history:91]
Return to Stock

- added (2018-05-02):
[0001437749-18-008370:note_history:92]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-02):
[0001437749-18-008370:note_history:93]
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics - Semiconductor |  |  | 149,916 |  |  |  | — |  |  |  | — |  |  |  | 149,916 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,580 |  |  |  | — |  |  |  | 63,580 |  |
| Automotive Sensors |  |  | — |  |  |  | 31,323 |  |  |  | — |  |  |  | 31,323 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 31,228 |  |  |  | — |  |  |  | 31,228 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 27,271 |  |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-02):
[0001437749-18-008370:note_history:94]
Revenue Recognition

- added (2018-05-02):
[0001437749-18-008370:note_history:95]
Adoption

- added (2018-05-02):
[0001437749-18-008370:note_history:96]
On 
 December 31, 2017, 
the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did 
not
 have a significant impact on the Company’s consolidated financial statements.

- added (2018-05-02):
[0001437749-18-008370:note_history:97]
Revenue Disaggregation

- added (2018-05-02):
[0001437749-18-008370:note_history:98]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 months ended 
 March 31, 2018:

- added (2018-05-02):
[0001437749-18-008370:note_history:99]
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics - Semiconductor |  |  | 149,916 |  |  |  | — |  |  |  | — |  |  |  | 149,916 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,580 |  |  |  | — |  |  |  | 63,580 |  |
| Automotive Sensors |  |  | — |  |  |  | 31,323 |  |  |  | — |  |  |  | 31,323 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 31,228 |  |  |  | — |  |  |  | 31,228 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 27,271 |  |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |

- added (2018-05-02):
[0001437749-18-008370:note_history:100]
See Note 
12,

- added (2018-05-02):
[0001437749-18-008370:note_history:101]
Segment Information
 for net sales by segment and countries.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-02):
[0001437749-18-008370:note_history:102]
Revenue Recognition

- added (2018-05-02):
[0001437749-18-008370:note_history:103]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do 
not
 transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and 
 may 
include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent 
third
-party distributors.

- added (2018-05-02):
[0001437749-18-008370:note_history:104]
The Company has elected the practical expedient under ASC 
340
-
40
-
25
-
4
 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than 
one
 year.
