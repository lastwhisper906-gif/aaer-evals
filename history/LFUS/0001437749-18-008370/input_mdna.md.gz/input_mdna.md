# LFUS MD&A — 0001437749-18-008370


## mdna

[0001437749-18-008370:mdna:1]
[same as prior period, unchanged from 0001437749-17-018040:mdna:1]

[0001437749-18-008370:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-18-008370:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 30, 2017.

[0001437749-18-008370:mdna:4]
[same as prior period, unchanged from 0001437749-17-018040:mdna:4]

[0001437749-18-008370:mdna:5]
[same as prior period, unchanged from 0001437749-17-018040:mdna:5]

[0001437749-18-008370:mdna:6]
Founded in 1927, Littelfuse is a global leader in circuit protection products with advancing platforms in power control and sensor technologies, serving customers in the electronics, automotive, and industrial markets. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy, ranging across consumer electronics, IT and telecommunication applications, industrial electronics, automobiles and other transportation, and heavy industrial applications

[0001437749-18-008370:mdna:7]
The company maintains a network of global laboratories and engineering centers that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company conducts its business through three reportable segments: Electronics, Automotive, and Industrial. For each of these segments, the Company designs, manufactures and sells circuit protection products that protect against electrostatic discharge, power surges, short circuits, voltage spikes and other harmful occurrences; power control products that safely and efficiently control power to mitigate equipment damage, minimize electrical hazards and improve productivity; and sensor products used to identify and detect temperature, proximity, flow speed and fluid level in various applications. The Company’s customer base includes OEMs, Tier One automotive suppliers, and distributors.

[0001437749-18-008370:mdna:8]
[same as prior period, unchanged from 0001437749-17-018040:mdna:8]

[0001437749-18-008370:mdna:9]
For the first quarter of 2018, the Company recognized net sales of $417.8 million compared to $285.4 million in the first quarter of 2017 representing an increase of $132.4 million, or 46.4%. The increase was primarily driven by the acquisition of IXYS along with higher volume across all three segments. Net sales for Electronics increased $110.6 million, or 72.0%, due to the acquisition of IXYS and U.S. Sensor and strong growth across all the business units and geographic regions. Net sales for the Automotive segment increased $18.3 million, or 17.0% due to volume growth across all the segment’s business units and geographic regions. Net sales in the Industrial segment increased $3.4 million or 14.4% due to volume growth in the power fuse and relay businesses. The Company recognized net income of $36.0 million, or $1.45 per diluted share, in the first quarter of 2018 compared to net income of $38.9 million, or $1.69 per diluted share in the first quarter of 2017. The decrease in net income reflects the impact of the acquisition and integration related costs of $39.5 million associated with the IXYS acquisition that were mostly offset by operating income increases across all three segments and foreign exchange gains. Additionally, the per share results reflect an increase in the weighted average diluted shares outstanding of 1.5 million as a result of the shares issued in conjunction with the acquisition of IXYS.

[0001437749-18-008370:mdna:10]
Net cash provided by operating activities was $69.3 million for the three months ended March 31, 2018 as compared to $22.9 million for the three months ended April 1, 2017. The increase in net cash provided by operating activities reflected higher earnings and favorable working capital management that more than offset higher payments related to acquisition and integration costs.

[0001437749-18-008370:mdna:11]
On January 17, 2018, the Company completed its acquisition of IXYS for total purchase consideration of $778.8 million, net of cash acquired. IXYS is a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 3,500 customers through its direct salesforce and global distribution partners.

[0001437749-18-008370:mdna:12]
[same as prior period, unchanged from 0001437749-17-018040:mdna:15]

[0001437749-18-008370:mdna:13]
The following table summarizes the Company’s consolidated results of operations for the periods presented. The first quarter of 2018 includes $39.5 million of non-segment charges.  The charges related to the IXYS acquisition total $38.6 million and include $17.9 million of purchase accounting inventory charges, $11.7 million in acquisition-related and integration costs primarily related to legal, accounting and other expenses associated with the acquisition of IXYS, $4.5 million of stock compensation expense recognized immediately upon close for converted IXYS options related to prior services periods $2.5 million in backlog amortization costs and $2.1 million in other charges. In addition, there were $0.8 million of restructuring charges related to certain operations in the Electronics segment.

[0001437749-18-008370:mdna:14]
The first quarter of 2017 includes approximately $1.5 million of non-segment charges.  These were primarily attributable to acquisition-related costs primarily related to legal and integration costs associated with the Company’s acquisitions in 2016 of the ON Portfolio and PolySwitch.

[0001437749-18-008370:mdna:15]
|  |  | First Quarter |  |  |  |  |  |  |  |  |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |
| Sales |  | $ | 417,813 |  |  | $ | 285,441 |  |  | $ | 132,372 |  |  |  | 46.4 | % |
| Gross profit |  |  | 149,623 |  |  |  | 113,650 |  |  |  | 35,973 |  |  |  | 31.7 | % |
| Operating expenses |  |  | 112,052 |  |  |  | 64,798 |  |  |  | 47,254 |  |  |  | 72.9 | % |
| Operating income |  |  | 37,571 |  |  |  | 48,852 |  |  |  | (11,281 | ) |  |  | (23.1 | %) |
| Other (income) expense, net |  |  | (1,943 | ) |  |  | (139 | ) |  |  | 1,804 |  |  |  | N.M. |  |
| Income before income taxes |  |  | 44,646 |  |  |  | 47,428 |  |  |  | (2,782 | ) |  |  | (5.9 | %) |
| Net income |  |  | 36,029 |  |  |  | 38,891 |  |  |  | (2,862 | ) |  |  | (7.4 | ) |

[0001437749-18-008370:mdna:16]
N.M. - Not meaningful

[0001437749-18-008370:mdna:17]
[same as prior period, unchanged from 0001437749-17-018040:mdna:20]

[0001437749-18-008370:mdna:18]
Net sales increased $132.4 million, or 46.4%, for the first quarter of 2018 compared to the first quarter of 2017 with increases of $86.3 million and $3.1 million resulting from incremental net sales related to the IXYS and U.S Sensor acquisitions, respectively. The remaining increase in net sales was driven by higher volume across all businesses in the Electronics segment and Automotive segments as well as increases in the fuse and relay businesses in the Industrial segment.

[0001437749-18-008370:mdna:19]
[same as prior period, unchanged from 0001437749-17-018040:mdna:23]

[0001437749-18-008370:mdna:20]
Gross profit was $149.6 million, or 35.8% of net sales, in the first quarter of 2018, compared to $113.7 million, or 39.8% of net sales in the first quarter of 2017. The increase in gross profit reflects the lower gross profit of the IXYS acquisition and volume growth and expense leverage across all segments. The decrease in gross margin is due to the purchase accounting inventory charges of $17.9 million which negatively impacted the first quarter of 2018 gross margin by 4.3 percentage points.

[0001437749-18-008370:mdna:21]
[same as prior period, unchanged from 0001437749-17-018040:mdna:26]

[0001437749-18-008370:mdna:22]
Total operating expenses were $112.1 million, or 26.8% of net sales, for the first quarter of 2018 compared to $64.8 million, or 22.7% of net sales, for the first quarter of 2017. The increase in operating expenses of $47.3 million is primarily due to incremental operating expenses related to the IXYS and US Sensor acquisitions as well as higher acquisition-related and integration costs of $20.1 million and an increase in amortization expense of $6.1 million resulting from the acquisition of IXYS.

[0001437749-18-008370:mdna:23]
[same as prior period, unchanged from 0001437749-17-018040:mdna:29]

[0001437749-18-008370:mdna:24]
Operating income was $37.6 million, a decrease of $11.3 million or 23.1% for the first quarter of 2018 compared to $48.9 million for the first quarter of 2017. The decrease in operating income is primarily due to the purchase accounting inventory charges of $17.9 million along with the costs associated with the acquisition and integration of the IXYS acquisition as described above.  Operating margins decreased from 17.1% in the first quarter of 2017 to 9.0% in the first quarter of 2018.  The higher acquisition and integration charges negatively impacted operating margins by 9.0% in the first quarter of 2018.

[0001437749-18-008370:mdna:25]
[same as prior period, unchanged from 0001437749-17-018040:mdna:32]

[0001437749-18-008370:mdna:26]
Income before income taxes was $44.6 million, or 10.7% of net sales, for the first quarter of 2018 compared to $47.4 million, or 16.6% of net sales, for the first quarter of 2017.  In addition to the factors impacting comparative results for operating income, income before income taxes was impacted by favorable comparative foreign exchange gains that were partially offset by increased interest expense associated with the increased borrowings for the IXYS acquisition. The effect of foreign exchange rate changes on various foreign currency transactions worldwide was approximately $10.6 million of unrealized income for the first quarter of 2018 compared to income of unrealized $1.6 million for the first quarter of 2017 primarily due to fluctuations in the euro and Philippine peso against the U.S. dollar. Interest expense increased $2.3 million in the first quarter of 2018 primarily reflecting increased borrowings.  Additionally, other income increased by $1.9 million as a result of unrealized investment gains, primarily associated with our investment in Polytronics.

[0001437749-18-008370:mdna:27]
[same as prior period, unchanged from 0001437749-17-018040:mdna:35]

[0001437749-18-008370:mdna:28]
Income tax expense was $8.6 million, or an effective tax rate of 19.3%, for the first quarter of 2018 compared to $8.5 million, or an effective tax rate of 18.0%, for the first quarter of 2017. The effective tax rate for the first quarter of 2017 was lower than the then applicable 35% U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0001437749-18-008370:mdna:29]
[same as prior period, unchanged from 0001437749-17-018040:mdna:38]

[0001437749-18-008370:mdna:30]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 12, Segment Information, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-18-008370:mdna:31]
[same as prior period, unchanged from 0001437749-17-018040:mdna:40]

[0001437749-18-008370:mdna:32]
|  |  | First Quarter |  |  |  |  |  |  |  |  |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |
| Electronics |  | $ | 264,411 |  |  | $ | 153,767 |  |  | $ | 110,644 |  |  |  | 72.0 | % |
| Automotive |  |  | 126,131 |  |  |  | 107,839 |  |  |  | 18,292 |  |  |  | 17.0 | % |
| Industrial |  |  | 27,271 |  |  |  | 23,835 |  |  |  | 3,436 |  |  |  | 14.4 | % |
| Electronics |  | $ | 417,813 |  |  | $ | 285,441 |  |  | $ | 132,372 |  |  |  | 46.4 | % |

[0001437749-18-008370:mdna:33]
[same as prior period, unchanged from 0001437749-17-018040:mdna:43]

[0001437749-18-008370:mdna:34]
The Electronics segment net sales increased $110.6 million, or 72.0%, in the first quarter of 2018 compared to the first quarter of 2017 due to incremental net sales related to the IXYS and U.S. Sensor acquisitions of $86.3 million and $3.1 million, respectively, higher volume across all businesses driven by the strong electronics cycle and favorable foreign exchange impacts of $5.3 million.

[0001437749-18-008370:mdna:35]
[same as prior period, unchanged from 0001437749-17-018040:mdna:46]

[0001437749-18-008370:mdna:36]
The Automotive segment net sales increased $18.3 million, or 17.0%, in the first quarter of 2018 compared to the first quarter of 2017 due to increased volume across all businesses with the commercial vehicle business having the most growth as well as favorable changes in foreign exchange rates of $7.4 million.

[0001437749-18-008370:mdna:37]
[same as prior period, unchanged from 0001437749-17-018040:mdna:49]

[0001437749-18-008370:mdna:38]
The Industrial segment net sales increased $3.4 million, or 14.4%, in the first quarter of 2018 compared to the first quarter of 2017 primarily due to higher volume in the power fuse and relay operations partially offset by lower volume in the custom products business.

[0001437749-18-008370:mdna:39]
[same as prior period, unchanged from 0001437749-17-018040:mdna:52]

[0001437749-18-008370:mdna:40]
[same as prior period, unchanged from 0001437749-17-018040:mdna:53]

[0001437749-18-008370:mdna:41]
|  |  | First Quarter |  |  |  |  |  |  |  |  |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |
| Americas |  | $ | 138,729 |  |  | $ | 98,025 |  |  | $ | 40,704 |  |  |  | 41.5 | % |
| Europe |  |  | 99,812 |  |  |  | 58,905 |  |  |  | 40,907 |  |  |  | 69.4 | % |
| Asia-Pacific |  |  | 179,272 |  |  |  | 128,511 |  |  |  | 50,761 |  |  |  | 39.5 | % |
| Total |  | $ | 417,813 |  |  | $ | 285,441 |  |  | $ | 132,372 |  |  |  | 46.4 | % |

[0001437749-18-008370:mdna:42]
[same as prior period, unchanged from 0001437749-17-018040:mdna:56]

[0001437749-18-008370:mdna:43]
Net sales in the Americas increased $40.7 million, or 41.5%, in the first quarter of 2018 compared to the first quarter of 2017 driven by incremental sales from IXYS and U.S. Sensor acquisitions and increased volume across all businesses in the Electronics, Automotive and Industrial segments.

[0001437749-18-008370:mdna:44]
[same as prior period, unchanged from 0001437749-17-018040:mdna:59]

[0001437749-18-008370:mdna:45]
European net sales increased $40.9 million, or 69.4%, in the first quarter of 2018 compared to the first quarter of 2017. The increase in net sales was primarily due to incremental sales from the IXYS acquisition and higher volumes across all businesses in the Electronics and Automotive segments and the relay business in the Industrial segment as well as favorable foreign currency effects of $9.5 million.

[0001437749-18-008370:mdna:46]
[same as prior period, unchanged from 0001437749-17-018040:mdna:62]

[0001437749-18-008370:mdna:47]
Asia-Pacific net sales increased $50.8 million, or 39.5%, in the first quarter of 2018 compared to the first quarter of 2017 primarily due to incremental net sales from current year and prior year acquisitions and higher net sales in all of the Electronics and Automotive segments’ businesses as well as favorable foreign currency effects of $3.1 million.

[0001437749-18-008370:mdna:48]
[same as prior period, unchanged from 0001437749-17-018040:mdna:65]

[0001437749-18-008370:mdna:49]
[same as prior period, unchanged from 0001437749-17-018040:mdna:66]

[0001437749-18-008370:mdna:50]
Revolving Credit Facility/Term Loan

[0001437749-18-008370:mdna:51]
On March 4, 2016, the Company entered into a new five-year credit agreement with a group of lenders for up to $700.0 million. The new credit agreement consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of $1.6 million through March 31, 2018 and $3.1 million from June 30, 2018 through December 31, 2020 with the remaining balance due on March 4, 2021.

[0001437749-18-008370:mdna:52]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022.

[0001437749-18-008370:mdna:53]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.13% at March 31, 2018. As of March 31, 2018, the Company had $0.1 million outstanding in letters of credit and had available $696.9 million of borrowing capacity under the Revolving Credit Facility. At March 31, 2018, the Company was in compliance with all covenants under the Credit Agreement. Further information regarding the Company’s credit agreement is provided in Note 5, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-18-008370:mdna:54]
[same as prior period, unchanged from 0001437749-17-018040:mdna:71]

[0001437749-18-008370:mdna:55]
[same as prior period, unchanged from 0001437749-17-018040:mdna:72]

[0001437749-18-008370:mdna:56]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022, and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on February 15 and August 15, commencing August 15, 2017. Further information regarding the Company’s Senior Notes is provided in Note 5, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-18-008370:mdna:57]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 will be payable on February 15 and August 15, commencing on August 15, 2018.

[0001437749-18-008370:mdna:58]
[same as prior period, unchanged from 0001437749-17-018040:mdna:74]

[0001437749-18-008370:mdna:59]
|  |  | First Quarter |  |
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Net cash provided by operating activities |  | $ | 69,268 |  |  | $ | 22,943 |  |
| Net cash used in investing activities |  |  | (324,377 | ) |  |  | (22,098 | ) |
| Net cash provided by financing activities |  |  | 240,308 |  |  |  | 2,938 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,417 | ) |  |  | (928 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (17,218 | ) |  |  | 2,855 |  |
| Cash and cash equivalents at beginning of period |  |  | 429,676 |  |  |  | 275,124 |  |
| Cash and cash equivalents at end of period |  | $ | 412,458 |  |  | $ | 277,979 |  |

[0001437749-18-008370:mdna:60]
The following describes the Company’s cash flows for the three months ended March 31, 2018 and April 1, 2017.

[0001437749-18-008370:mdna:61]
[same as prior period, unchanged from 0001437749-17-018040:mdna:77]

[0001437749-18-008370:mdna:62]
[same as prior period, unchanged from 0001437749-17-018040:mdna:78]

[0001437749-18-008370:mdna:63]
Net cash provided by operating activities was $69.3 million for the first three months of 2018, compared to $22.9 million during the three months ended April 1, 2017. The increase in net cash provided by operating activities was primarily driven by higher earnings and favorable working capital management that more than offset higher payments related to acquisition and integration costs.

[0001437749-18-008370:mdna:64]
[same as prior period, unchanged from 0001437749-17-018040:mdna:80]

[0001437749-18-008370:mdna:65]
Net cash used in investing activities was $324.4 million for the three months ended March 31, 2018, compared to $22.1 million during the three months ended April 1, 2017.  Net cash used for the acquisition of IXYS was $306.5 million for the three months ended March 31, 2018 as compared to net cash used for the acquisition of a majority stake in Monolith of $14.2 million for the three months ended April 1, 2017. Capital expenditures were $17.9 million, representing an increase of $5.5 million compared to 2017.

[0001437749-18-008370:mdna:66]
[same as prior period, unchanged from 0001437749-17-018040:mdna:82]

[0001437749-18-008370:mdna:67]
Net cash provided by financing activities was $240.3 million for the three months ended 2018 compared to $2.9 million for the three months ended 2017.  The Company had $300.0 million of proceeds from the credit facility, term loan and senior notes payable and $49.5 million of payments on the term loan and credit facility in the first quarter of 2018 as compared to $125.0 million of proceeds from the senior notes payable and $114.1 million of payments on the term loan and credit facility in the first quarter of 2017.  Additionally, dividends paid increased $1.7 million from $7.5 million in 2017 to $9.2 million for the three months ended March 31, 2018.

[0001437749-18-008370:mdna:68]
[same as prior period, unchanged from 0001437749-17-018040:mdna:84]

[0001437749-18-008370:mdna:69]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2017 to April 30, 2018 (“Share Repurchase Program”). The Company did not repurchase any shares of its common stock during fiscal 2017 or the first quarter of 2018. The Share Repurchase Program expired on April 30, 2018 with no shares repurchased. In April 2018, the Company’s Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company’s common stock for the period May 1, 2018 to April 30, 2019.

[0001437749-18-008370:mdna:70]
[same as prior period, unchanged from 0001437749-17-018040:mdna:86]

[0001437749-18-008370:mdna:71]
As of March 31, 2018, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-18-008370:mdna:72]
[same as prior period, unchanged from 0001437749-17-018040:mdna:94]

[0001437749-18-008370:mdna:73]
[same as prior period, unchanged from 0001437749-17-018040:mdna:95]

[0001437749-18-008370:mdna:74]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 30, 2017. During the three months ended March 31, 2018, there were no significant changes in the application of critical accounting policies.

[0001437749-18-008370:mdna:75]
[same as prior period, unchanged from 0001437749-17-018040:mdna:88]

[0001437749-18-008370:mdna:76]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the first quarter of 2019. The Company is currently evaluating the impact of ASU 2016-02.

[0001437749-18-008370:mdna:77]
In January 2018, the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions in the Tax Act. The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has not yet completed its assessment and therefore has not yet elected an accounting policy.

[0001437749-18-008370:mdna:78]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 2018-02 will be effective in the first quarter of 2019; however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 2018-02 on the Consolidated Financial Statements.
