# LFUS 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 4 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001437749-17-003344:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES.

[0001437749-17-003344:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-17-003344:item_9a:3]
We maintain disclosure controls and procedures that are designed to ensure that information required to be disclosed in our reports filed under the Securities Exchange Act of 1934, as amended, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure. In designing and evaluating the disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives, and management is required to apply its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001437749-17-003344:item_9a:4]
As required by SEC Rule 15d-15(b), we carried out an evaluation, under the supervision and with the participation of our management, including the Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of our disclosure controls and procedures pursuant to SEC Rule 13a-15 as of the end of the period covered by this report. Based on the foregoing, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective as of December 31, 2016.

[0001437749-17-003344:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001437749-17-003344:item_9a:6]
Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in this Annual Report on Form 10-K a report on management’s assessment of the effectiveness of the company’s internal control over financial reporting, as well as an attestation report from the company’s independent registered public accounting firm on the effectiveness of the company’s internal control over financial reporting. The management of Littelfuse is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Exchange Act Rule 13a-15(f). The Littelfuse internal control system was designed to provide reasonable assurance to its management and the Board of Directors regarding the preparation and fair presentation of published financial statements.

[0001437749-17-003344:item_9a:7]
On March 25, 2016, the company acquired 100% of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for $348.3 million, net of acquired cash and after settlement of certain post-closing adjustments. The PolySwitch business has a leading position in polymer based resettable circuit protection devices, with a strong global presence in the automotive, battery, industrial, communications, and mobile computing markets. On April 4, 2016, the company acquired 100% of Menber’s S.p.A. (“Menber’s”) for $19.2 million, net of cash acquired and after settlement of a working capital adjustment. Located in Legnago, Italy, Menber’s specializes in the design, manufacturing, and selling of manual and electrical battery switches and trailer connectors for commercial vehicles. The acquisition expands the company’s commercial vehicle platform globally. On August 29, 2016, the company acquired certain assets of select businesses (the “ON Portfolio”) of ON Semiconductor Corporation for $104.0 million. The acquired business consists of a product portfolio that includes transient voltage suppression (“TVS”) diodes, switching thyristors and insulated gate bipolar transistors (“IGBT”) for automotive ignition applications.

[0001437749-17-003344:item_9a:8]
The company is now integrating processes, employees, technologies, systems and operations of these three acquisitions into Littelfuse. As permitted by the rules and regulations of the SEC we have excluded PolySwitch, Menber’s and the ON Portfolio businesses from our assessment of our control over financial reporting as of December 31, 2016. Management will continue to evaluate internal controls as we complete the integration of these acquisitions. As of December 31, 2016, PolySwitch, Menber’s and ON Portfolio businesses in aggregate represented 36% of Littelfuse total assets and 16% of total net revenue for the year ended.

[0001437749-17-003344:item_9a:9]
All internal control systems, no matter how well designed, have inherent limitations. Therefore, even those systems determined effective can provide only reasonable assurance with respect to financial statement preparation and presentation. A material weakness is a deficiency, or a combination of deficiencies, in the internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the annual or interim financial statement will not be prevented or detected on a timely basis.

[0001437749-17-003344:item_9a:10]
Littelfuse management, including the company’s principal executive officer and principal financial officer, assessed the effectiveness of the company’s internal control over financial reporting as of December 31, 2016, based upon the updated framework in Internal Control — Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in 1992 and updated in May 2013. Based on this assessment, the company’s management concluded that, as of December 31, 2016, the company’s internal control over financial reporting was effective.

[0001437749-17-003344:item_9a:11]
65

[0001437749-17-003344:item_9a:12]
Changes in Internal Control over Financial Reporting

[0001437749-17-003344:item_9a:13]
There has been no change in the company’s internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that occurred during the 12 months or fiscal quarter ended December 31, 2016, that has materially affected, or is reasonably likely to materially affect, the company’s internal control over financial reporting.
