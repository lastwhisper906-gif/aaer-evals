# LFUS 8-K — 0001437749-17-001426 filed 2017-02-01

## item codes, every 8-K on or before 2017-02-27

- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2017-02-27

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-001426:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-17-001426:8k_2_02:2]
ex99-1.htm

[0001437749-17-001426:8k_2_02:3]
Exhibit 99.1

[0001437749-17-001426:8k_2_02:4]
| NEWS RELEASE |  |

[0001437749-17-001426:8k_2_02:5]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS

[0001437749-17-001426:8k_2_02:6]
CHICAGO, February 1, 2017 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the fourth quarter and full year ended December 31, 2016.

[0001437749-17-001426:8k_2_02:7]
Fourth Quarter 2016 Highlights

[0001437749-17-001426:8k_2_02:8]
|  | ● | Net sales were $284.5 million, up 29% versus the prior year period. Excluding revenue from acquisitions, e-house business divestiture and the extra week in the fourth quarter of 2015, sales were up 6%. |

[0001437749-17-001426:8k_2_02:9]
|  | ● | Growth by segment versus the prior year period: |

[0001437749-17-001426:8k_2_02:10]
|  | o | Electronics sales increased 60% (up 19% excluding acquisitions and 2015 extra week) |

[0001437749-17-001426:8k_2_02:11]
|  | o | Automotive sales increased 19% (up 2% excluding acquisitions and 2015 extra week) |

[0001437749-17-001426:8k_2_02:12]
|  | o | Industrial sales decreased 33% (down 26% excluding divestiture and 2015 extra week) |

[0001437749-17-001426:8k_2_02:13]
|  | ● | GAAP diluted EPS was $1.19; Adjusted EPS of $1.57 increased 38% over last year |

[0001437749-17-001426:8k_2_02:14]
|  | ● | Cash flow from operations was $80 million |

[0001437749-17-001426:8k_2_02:15]
|  | ● | The electronics book-to-bill ratio for the quarter was 1.05, and excludes the ON product portfolio acquisition |

[0001437749-17-001426:8k_2_02:16]
|  | ● | Completed private placement of approximately $350 million of USD and Euro senior notes |

[0001437749-17-001426:8k_2_02:17]
"We’re pleased with our strong fourth quarter finish, with both sales and earnings exceeding the midpoint of our guidance," said Dave Heinzmann, Chief Executive Officer. "Our results were led by strength across our electronics segment, along with solid performance in both our automotive fuse and sensor businesses. We continued to see end market weaknesses across our industrial segment and our commercial vehicle business in our automotive segment, impacting our overall growth for the quarter. Despite these challenges, we finished the quarter with strong earnings and cash flow growth.”

[0001437749-17-001426:8k_2_02:18]
-more-

[0001437749-17-001426:8k_2_02:19]
Full Year 2016 Highlights

[0001437749-17-001426:8k_2_02:20]
|  | ● | Net sales were $1,056.2 million, a 22% increase versus the prior year period |

[0001437749-17-001426:8k_2_02:21]
|  | ● | Diluted GAAP EPS was $4.60; Adjusted EPS of $6.26 increased 26% over last year |

[0001437749-17-001426:8k_2_02:22]
|  | ● | GAAP effective tax rate of 15.2%, and adjusted effective tax rate of 18.1%, down nearly 900 and 700 basis points, respectively, over last year |

[0001437749-17-001426:8k_2_02:23]
|  | ● | Cash flow from operations was $180 million and capital expenditures were $46 million, resulting in free cash flow of $134 million |

[0001437749-17-001426:8k_2_02:24]
|  | ● | Expanded portfolio with acquisitions across circuit protection and power control platforms (PolySwitch, ON product portfolio and Menber’s) |

[0001437749-17-001426:8k_2_02:25]
"2016 was a milestone year for us, as we crossed $1 billion in revenue, with record earnings and cash flow. We also made substantial progress in growth from strategic acquisitions, adding approximately $250 million in annualized revenue from our three acquisitions,” said Gordon Hunter, Executive Chairman. “We are well positioned for success with our updated strategy, which focuses on accelerated organic growth, while continuing to add acquisitions aligned to our core circuit protection, sensor and power control platforms."

[0001437749-17-001426:8k_2_02:26]
2017 Outlook

[0001437749-17-001426:8k_2_02:27]
All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, foreign exchange adjustments and unusual gains and losses. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-17-001426:8k_2_02:28]
“With our strong finish in 2016, we head into the year with positive momentum, despite an environment of ongoing currency and commodity volatility,” said Meenal Sethna, Chief Financial Officer. “Considering this current environment, we remain focused on our financial goals of double-digit sales and earnings per share growth for 2017.”

[0001437749-17-001426:8k_2_02:29]
For the first quarter of 2017, sales are expected to be in the range of $278 to $288 million. Adjusted earnings per share are expected to be in the range of $1.56 to $1.70.

[0001437749-17-001426:8k_2_02:30]
For the full year, the company expects an adjusted effective tax rate in the range of 17 – 19%. In addition, capital expenditures are expected to be approximately $70 million. The capital expenditures include the incremental semiconductor manufacturing investment for the transfer of the ON product portfolio.

[0001437749-17-001426:8k_2_02:31]
-more-

[0001437749-17-001426:8k_2_02:32]
Dividend

[0001437749-17-001426:8k_2_02:33]
The company will pay a cash dividend on the company’s common stock of $0.33 per share on March 9, 2017 to shareholders of record as of February 23, 2017.

[0001437749-17-001426:8k_2_02:34]
Conference Call and Webcast Information

[0001437749-17-001426:8k_2_02:35]
Littelfuse will host a conference call today, Wednesday, February 1, 2017, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. The call will be available for replay on the company’s website.

[0001437749-17-001426:8k_2_02:36]
About Littelfuse

[0001437749-17-001426:8k_2_02:37]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 10,000 employees in more than 40 locations throughout the Americas, Europe and Asia. For more information, please visit the Littelfuse website: Littelfuse.com.

[0001437749-17-001426:8k_2_02:38]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company's accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions, uncertainties related to political and regulatory changes and other risks which may be detailed in the company's other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 2, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended January 2, 2016.

[0001437749-17-001426:8k_2_02:39]
Non-GAAP Financial Measures

[0001437749-17-001426:8k_2_02:40]
The information included in this press release includes the non-GAAP financial measures of adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted

[0001437749-17-001426:8k_2_02:41]
diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is included herein.

[0001437749-17-001426:8k_2_02:42]
-more-

[0001437749-17-001426:8k_2_02:43]
The company believes that adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-17-001426:8k_2_02:44]
CONTACT: Meenal Sethna

[0001437749-17-001426:8k_2_02:45]
Executive Vice President and CFO

[0001437749-17-001426:8k_2_02:46]
(773) 628-0616

[0001437749-17-001426:8k_2_02:47]
###

[0001437749-17-001426:8k_2_02:48]
LITTELFUSE, INC.

[0001437749-17-001426:8k_2_02:49]
Net Sales and Operating Income by Business Unit

[0001437749-17-001426:8k_2_02:50]
(In thousands of USD, unaudited)

[0001437749-17-001426:8k_2_02:51]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 156,495 |  |  | $ | 97,948 |  |  |  | 60 | % |  | $ | 535,191 |  |  | $ | 405,497 |  |  |  | 32 | % |
| Automotive |  |  | 105,556 |  |  |  | 88,493 |  |  |  | 19 | % |  |  | 415,200 |  |  |  | 339,957 |  |  |  | 22 | % |
| Industrial |  |  | 22,467 |  |  |  | 33,579 |  |  |  | (33 | %) |  |  | 105,768 |  |  |  | 122,410 |  |  |  | (14 | %) |
| Total net sales |  | $ | 284,518 |  |  | $ | 220,020 |  |  |  | 29 | % |  | $ | 1,056,159 |  |  | $ | 867,864 |  |  |  | 22 | % |

[0001437749-17-001426:8k_2_02:52]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 34,842 |  |  | $ | 16,439 |  |  |  | 112 | % |  | $ | 117,088 |  |  | $ | 78,194 |  |  |  | 50 | % |
| Automotive |  |  | 10,908 |  |  |  | 13,963 |  |  |  | (22 | %) |  |  | 59,905 |  |  |  | 53,086 |  |  |  | 13 | % |
| Industrial |  |  | (143 | ) |  |  | 4,874 |  |  |  | (103 | %) |  |  | 3,615 |  |  |  | 18,094 |  |  |  | (80 | %) |
| Other (1) |  |  | (4,619 | ) |  |  | (5,422 | ) |  |  | (15 | %) |  |  | (49,964 | ) |  |  | (45,217 | ) |  |  | 10 | % |
| Total operating income |  | $ | 40,988 |  |  | $ | 29,854 |  |  |  | 37 | % |  | $ | 130,644 |  |  | $ | 104,157 |  |  |  | 25 | % |
| Interest expense |  |  | 2,342 |  |  |  | 1,070 |  |  |  |  |  |  |  | 8,628 |  |  |  | 4,091 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | 7,586 |  |  |  | 259 |  |  |  |  |  |  |  | 472 |  |  |  | (1,465 | ) |  |  |  |  |
| Other (income) expense, net |  |  | (690 | ) |  |  | (1,659 | ) |  |  |  |  |  |  | (1,730 | ) |  |  | (5,417 | ) |  |  |  |  |
| Income before taxes |  | $ | 31,750 |  |  | $ | 30,184 |  |  |  | 5 | % |  | $ | 123,274 |  |  | $ | 106,948 |  |  |  | 15 | % |

[0001437749-17-001426:8k_2_02:53]
(1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details on page 8.)

[0001437749-17-001426:8k_2_02:54]
-more-

[0001437749-17-001426:8k_2_02:55]
LITTELFUSE, INC.

[0001437749-17-001426:8k_2_02:56]
Condensed Consolidated Balance Sheets

[0001437749-17-001426:8k_2_02:57]
(In thousands of USD, except share amounts)

[0001437749-17-001426:8k_2_02:58]
|  |  | December 31, 2016 |  |  | January 2, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 275,124 |  |  | $ | 328,786 |  |
| Short-term investments |  |  | 3,690 |  |  |  | 4,179 |  |
| Accounts receivable, less allowances |  |  | 198,095 |  |  |  | 142,882 |  |
| Inventories |  |  | 114,063 |  |  |  | 98,629 |  |
| Prepaid income taxes and income taxes receivable |  |  | 11,671 |  |  |  | 1,510 |  |
| Prepaid expenses and other current assets |  |  | 9,438 |  |  |  | 7,943 |  |
| Total current assets |  |  | 612,081 |  |  |  | 583,929 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 9,268 |  |  |  | 5,236 |  |
| Buildings |  |  | 80,553 |  |  |  | 71,383 |  |
| Equipment |  |  | 439,542 |  |  |  | 382,429 |  |
|  |  |  | 529,363 |  |  |  | 459,048 |  |
| Accumulated depreciation |  |  | (312,188 | ) |  |  | (296,480 | ) |
| Net property, plant and equipment |  |  | 217,175 |  |  |  | 162,568 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 83,607 |  |  |  | 20,221 |  |
| Distribution network |  |  | 18,995 |  |  |  | 16,490 |  |
| Customer lists, trademarks and tradenames |  |  | 110,425 |  |  |  | 54,912 |  |
| Goodwill |  |  | 403,544 |  |  |  | 189,767 |  |
|  |  |  | 616,571 |  |  |  | 281,390 |  |
| Investments |  |  | 13,933 |  |  |  | 15,197 |  |
| Deferred income taxes |  |  | 20,585 |  |  |  | 8,333 |  |
| Other assets |  |  | 10,849 |  |  |  | 14,058 |  |
| Total assets |  | $ | 1,491,194 |  |  | $ | 1,065,475 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 90,712 |  |  | $ | 51,658 |  |
| Accrued payroll |  |  | 42,810 |  |  |  | 32,611 |  |
| Accrued expenses |  |  | 36,138 |  |  |  | 24,145 |  |
| Accrued severance |  |  | 2,785 |  |  |  | 3,798 |  |
| Accrued income taxes |  |  | 8,846 |  |  |  | 11,836 |  |
| Current portion of long-term debt |  |  | 6,250 |  |  |  | 87,000 |  |
| Total current liabilities |  |  | 187,541 |  |  |  | 211,048 |  |
| Long-term debt, less current portion |  |  | 447,892 |  |  |  | 83,753 |  |
| Deferred income taxes |  |  | 7,066 |  |  |  | 8,014 |  |
| Accrued post-retirement benefits |  |  | 13,398 |  |  |  | 5,653 |  |
| Other long-term liabilities |  |  | 20,366 |  |  |  | 17,755 |  |
| Total equity |  |  | 814,931 |  |  |  | 739,252 |  |
| Total liabilities and equity |  | $ | 1,491,194 |  |  | $ | 1,065,475 |  |
| Common shares issued and outstanding of 22,738,895 and 22,420,785 at December 31, 2016 and January 2, 2016, respectively. |  |  |  |  |  |  |  |  |

[0001437749-17-001426:8k_2_02:59]
Note: Prior year numbers have been restated to reflect the correction of immaterial errors as disclosed in recent quarterly filings with the SEC.

[0001437749-17-001426:8k_2_02:60]
-more-

[0001437749-17-001426:8k_2_02:61]
LITTELFUSE, INC.

[0001437749-17-001426:8k_2_02:62]
Consolidated Statements of Comprehensive Income

[0001437749-17-001426:8k_2_02:63]
(In thousands of USD, except per share data, unaudited)

[0001437749-17-001426:8k_2_02:64]
|  |  | For the Three Months Ended |  |  | For the Twelve Months Ended |  |
|  |  | Dec. 31, 2016 |  |  | Jan. 2, 2016 |  |  | Dec. 31, 2016 |  |  | Jan. 2, 2016 |  |
| Net sales |  | $ | 284,518 |  |  | $ | 220,020 |  |  | $ | 1,056,159 |  |  | $ | 867,864 |  |
| Cost of sales |  |  | 170,181 |  |  |  | 137,314 |  |  |  | 643,042 |  |  |  | 537,365 |  |
| Gross profit |  |  | 114,337 |  |  |  | 82,706 |  |  |  | 413,117 |  |  |  | 330,499 |  |
| Selling, general and administrative expenses |  |  | 56,082 |  |  |  | 41,595 |  |  |  | 206,129 |  |  |  | 153,714 |  |
| Research and development expenses |  |  | 11,314 |  |  |  | 8,578 |  |  |  | 42,198 |  |  |  | 30,802 |  |
| Pension settlement expenses |  |  | - |  |  |  | (266 | ) |  |  | - |  |  |  | 29,928 |  |
| Amortization of intangibles |  |  | 5,953 |  |  |  | 2,945 |  |  |  | 19,337 |  |  |  | 11,898 |  |
| Impairment of goodwill and intangible assets |  |  | - |  |  |  | - |  |  |  | 14,809 |  |  |  | - |  |
|  |  |  | 73,349 |  |  |  | 52,852 |  |  |  | 282,473 |  |  |  | 226,342 |  |
| Operating income |  |  | 40,988 |  |  |  | 29,854 |  |  |  | 130,644 |  |  |  | 104,157 |  |
| Interest expense |  |  | 2,342 |  |  |  | 1,070 |  |  |  | 8,628 |  |  |  | 4,091 |  |
| Foreign exchange (gain) loss |  |  | 7,586 |  |  |  | 259 |  |  |  | 472 |  |  |  | (1,465 | ) |
| Other (income) expense, net |  |  | (690 | ) |  |  | (1,659 | ) |  |  | (1,730 | ) |  |  | (5,417 | ) |
| Income before income taxes |  |  | 31,750 |  |  |  | 30,184 |  |  |  | 123,274 |  |  |  | 106,948 |  |
| Income taxes |  |  | 4,505 |  |  |  | 9,321 |  |  |  | 18,786 |  |  |  | 26,082 |  |
| Net income |  | $ | 27,245 |  |  | $ | 20,863 |  |  | $ | 104,488 |  |  | $ | 80,866 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.20 |  |  | $ | 0.93 |  |  | $ | 4.63 |  |  | $ | 3.58 |  |
| Diluted |  | $ | 1.19 |  |  | $ | 0.92 |  |  | $ | 4.60 |  |  | $ | 3.56 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,692 |  |  |  | 22,403 |  |  |  | 22,559 |  |  |  | 22,565 |  |
| Diluted |  |  | 22,863 |  |  |  | 22,564 |  |  |  | 22,727 |  |  |  | 22,719 |  |
| Comprehensive income |  | $ | 7,818 |  |  | $ | 10,425 |  |  | $ | 75,580 |  |  | $ | 56,321 |  |

[0001437749-17-001426:8k_2_02:65]
Note: Prior year numbers have been restated to reflect the correction of immaterial errors as disclosed in recent quarterly filings with the SEC.

[0001437749-17-001426:8k_2_02:66]
-more-

[0001437749-17-001426:8k_2_02:67]
LITTELFUSE, INC.

[0001437749-17-001426:8k_2_02:68]
Consolidated Statements of Cash Flows

[0001437749-17-001426:8k_2_02:69]
(In thousands of USD, unaudited)

[0001437749-17-001426:8k_2_02:70]
|  |  | For the Twelve Months Ended |  |
|  |  | Dec. 31, 2016 |  |  | Jan. 2, 2016 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 104,488 |  |  | $ | 80,866 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 33,800 |  |  |  | 29,701 |  |
| Amortization of intangibles |  |  | 19,337 |  |  |  | 11,898 |  |
| Impairment of intangible assets and goodwill |  |  | 14,809 |  |  |  | - |  |
| Provision for bad debts |  |  | - |  |  |  | 164 |  |
| Loss on sale of product line |  |  | 1,391 |  |  |  | - |  |
| Stock-based compensation |  |  | 11,987 |  |  |  | 10,266 |  |
| Non-cash inventory charge |  |  | 7,834 |  |  |  | - |  |
| Net loss on pension settlement, net of tax |  |  | - |  |  |  | 19,308 |  |
| Excess tax benefit on stock-based compensation |  |  | (3,421 | ) |  |  | (1,891 | ) |
| Loss on sale of assets |  |  | 813 |  |  |  | 1,253 |  |
| Deferred income taxes |  |  | (5,269 | ) |  |  | 11,479 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (23,466 | ) |  |  | (14,377 | ) |
| Inventories |  |  | 8,539 |  |  |  | (3,577 | ) |
| Accounts payable |  |  | 19,190 |  |  |  | 2,573 |  |
| Accrued expenses (including post retirement) |  |  | 2,287 |  |  |  | 6,482 |  |
| Accrued payroll and severance |  |  | 6,131 |  |  |  | 5,883 |  |
| Accrued taxes |  |  | (18,062 | ) |  |  | 557 |  |
| Prepaid expenses and other |  |  | (255 | ) |  |  | 5,241 |  |
| Net cash provided by operating activities |  |  | 180,133 |  |  |  | 165,826 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (46,228 | ) |  |  | (44,019 | ) |
| Acquisition of business, net of cash acquired |  |  | (471,118 | ) |  |  | (4,558 | ) |
| Purchases of investments |  |  | - |  |  |  | (3,500 | ) |
| Proceeds from maturities of short-term investments |  |  | 345 |  |  |  | - |  |
| Decrease in entrusted loan receivable |  |  | 5,510 |  |  |  | 7,811 |  |
| Proceeds from sale of assets |  |  | 248 |  |  |  | 102 |  |
| Net cash used in investing activities |  |  | (511,243 | ) |  |  | (44,164 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 367,000 |  |  |  | 49,000 |  |
| Proceeds of term loan |  |  | 125,000 |  |  |  | - |  |
| Payments of revolving credit facility |  |  | (331,500 | ) |  |  | (55,500 | ) |
| Payments of term loan |  |  | (89,688 | ) |  |  | (8,750 | ) |
| Net Proceeds from Sr. Notes Payable |  |  | 226,428 |  |  |  | - |  |
| Payments of entrusted loan |  |  | (5,510 | ) |  |  | (7,811 | ) |
| Debt issuance costs paid |  |  | (3,583 | ) |  |  | (42 | ) |
| Cash dividends paid |  |  | (27,866 | ) |  |  | (24,341 | ) |
| Proceeds from exercise of stock options |  |  | 20,494 |  |  |  | 9,150 |  |
| Excess tax benefit on share-based compensation |  |  | 3,421 |  |  |  | 1,891 |  |
| Purchases of common stock |  |  | - |  |  |  | (31,252 | ) |
| Net cash (used in) provided by financing activities |  |  | 284,196 |  |  |  | (67,655 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (6,748 | ) |  |  | (22,792 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (53,662 | ) |  |  | 31,215 |  |
| Cash and cash equivalents at beginning of period |  |  | 328,786 |  |  |  | 297,571 |  |
| Cash and cash equivalents at end of period |  | $ | 275,124 |  |  | $ | 328,786 |  |

[0001437749-17-001426:8k_2_02:71]
Note: Prior year numbers have been restated to reflect the correction of immaterial errors as disclosed in recent quarterly filings with the SEC.

[0001437749-17-001426:8k_2_02:72]
-more-

[0001437749-17-001426:8k_2_02:73]
LITTELFUSE, INC.

[0001437749-17-001426:8k_2_02:74]
Supplemental Financial Information

[0001437749-17-001426:8k_2_02:75]
(in millions of USD except share amounts)

[0001437749-17-001426:8k_2_02:76]
|  |  | Q4-16 |  |  | Q4-15 |  |  | FY-16 |  |  | FY-15 |  |
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted EPS |  | $ | 1.19 |  |  | $ | 0.92 |  |  | $ | 4.60 |  |  | $ | 3.56 |  |
| EPS impact of special items (below) |  |  | 0.38 |  |  |  | 0.21 |  |  |  | 1.66 |  |  |  | 1.42 |  |
| Adjusted diluted EPS |  | $ | 1.57 |  |  | $ | 1.14 |  |  | $ | 6.26 |  |  | $ | 4.98 |  |
| Non-GAAP Adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | (0.1 | ) |  | $ | 2.1 |  |  | $ | 1.6 |  |  | $ | 5.2 |  |
| Restructuring |  |  | 1.2 |  |  |  | (0.3 | ) |  |  | 2.5 |  |  |  | 3.6 |  |
| Acquisitions/divestiture/purchase acctg adjs |  |  | 3.5 |  |  |  | 3.9 |  |  |  | 31.1 |  |  |  | 4.7 |  |
| Pension wind-up |  |  | - |  |  |  | (0.3 | ) |  |  | - |  |  |  | 31.9 |  |
| Impairment of intangible assets |  |  | - |  |  |  | - |  |  |  | 14.8 |  |  |  | - |  |
| Adjustment to Operating income |  |  | 4.6 |  |  |  | 5.4 |  |  |  | 50.0 |  |  |  | 45.2 |  |
| Foreign exchange loss/(gain) |  |  | 7.6 |  |  |  | 0.3 |  |  |  | 0.5 |  |  |  | (1.4 | ) |
| Adjustment to income before income taxes |  | $ | 12.2 |  |  | $ | 5.6 |  |  | $ | 50.5 |  |  | $ | 43.8 |  |
| Income taxes |  |  | 3.5 |  |  |  | 0.9 |  |  |  | 12.6 |  |  |  | 11.5 |  |
| Adjustment to net income |  | $ | 8.7 |  |  | $ | 4.7 |  |  | $ | 37.9 |  |  | $ | 32.3 |  |
| Total EPS impact |  | $ | 0.38 |  |  | $ | 0.21 |  |  | $ | 1.66 |  |  | $ | 1.42 |  |

[0001437749-17-001426:8k_2_02:77]
|  |  | Q4-16 |  |  | Q4-15 |  |  | FY-16 |  |  | FY-15 |  |
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 284.5 |  |  | $ | 220.0 |  |  | $ | 1,056.1 |  |  | $ | 867.8 |  |
| GAAP operating income |  | $ | 41.0 |  |  | $ | 29.9 |  |  | $ | 130.7 |  |  | $ | 104.2 |  |
| Add back special operating items |  |  | 4.6 |  |  |  | 5.4 |  |  |  | 49.9 |  |  |  | 45.2 |  |
| Adjusted operating income |  | $ | 45.6 |  |  | $ | 35.3 |  |  | $ | 180.6 |  |  | $ | 149.4 |  |
| Adjusted operating margin |  |  | 16.0 | % |  |  | 16.0 | % |  |  | 17.1 | % |  |  | 17.2 | % |
| Add back amortization |  |  | 6.0 |  |  |  | 2.9 |  |  |  | 19.4 |  |  |  | 11.9 |  |
| Add back depreciation |  |  | 9.0 |  |  |  | 7.5 |  |  |  | 33.8 |  |  |  | 29.7 |  |
| Adjusted EBITDA |  | $ | 60.6 |  |  | $ | 45.7 |  |  | $ | 233.8 |  |  | $ | 191.0 |  |
| Adjusted EBITDA margin |  |  | 21.3 | % |  |  | 20.8 | % |  |  | 22.1 | % |  |  | 22.0 | % |

[0001437749-17-001426:8k_2_02:78]
Note: Totals will not always foot due to rounding

[0001437749-17-001426:8k_2_02:79]
Note: Prior year numbers have been restated to reflect the correction of immaterial errors as disclosed in recent quarterly filings with the SEC.

[0001437749-17-001426:8k_2_02:80]
-more-

[0001437749-17-001426:8k_2_02:81]
|  |  | Q4 2016 vs. Q4 2015 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales growth |  |  | 60 | % |  |  | 19 | % |  |  | -33 | % |  |  | 29 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 45 | % |  |  | 21 | % |  |  | 0 | % |  |  | 29 | % |
| Divestitures |  |  | 0 | % |  |  | 0 | % |  |  | -4 | % |  |  | -1 | % |
| 53rd Week |  |  | -5 | % |  |  | -3 | % |  |  | -3 | % |  |  | -4 | % |
| Adjusted net sales growth |  |  | 19 | % |  |  | 2 | % |  |  | -26 | % |  |  | 6 | % |

[0001437749-17-001426:8k_2_02:82]
|  |  | Q4-16 |  |  | Q4-15 |  |  | FY-16 |  |  | FY-15 |  |
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes |  | $ | 4.5 |  |  | $ | 9.3 |  |  | $ | 18.8 |  |  | $ | 26.1 |  |
| Effective rate |  |  | 14.2 | % |  |  | 30.9 | % |  |  | 15.2 | % |  |  | 24.4 | % |
| Non-GAAP adjustment - income taxes |  |  | 3.5 |  |  |  | 0.9 |  |  |  | 12.6 |  |  |  | 11.5 |  |
| Adjusted income taxes |  | $ | 8.0 |  |  | $ | 10.2 |  |  | $ | 31.4 |  |  | $ | 37.6 |  |
| Adjusted effective rate |  |  | 18.3 | % |  |  | 28.5 | % |  |  | 18.1 | % |  |  | 25.0 | % |
| Free Cash Flow reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 80.1 |  |  | $ | 52.2 |  |  | $ | 180.1 |  |  | $ | 165.8 |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (11.7 | ) |  |  | (9.0 | ) |  |  | (46.2 | ) |  |  | (43.5 | ) |
| Free Cash Flow |  | $ | 68.4 |  |  | $ | 43.2 |  |  | $ | 133.9 |  |  | $ | 122.3 |  |

[0001437749-17-001426:8k_2_02:83]
Note: Totals will not always foot due to rounding

[0001437749-17-001426:8k_2_02:84]
Note: Prior year numbers have been restated to reflect the correction of immaterial errors as disclosed in recent quarterly filings with the SEC.

[0001437749-17-001426:8k_2_02:85]
####
