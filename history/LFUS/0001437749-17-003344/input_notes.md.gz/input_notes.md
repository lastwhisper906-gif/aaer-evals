# LFUS notes — 0001437749-17-003344


## lfus:CoalMiningLiabilityPolicyTextBlock

[0001437749-17-003344:notes:1]
Coal Mining Liability

[0001437749-17-003344:notes:2]
Included in other long-term liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of 
€1.4
 million 
($1.5
 million) and 
€1.8
 million 
($2.0
 million) at 
 December

[0001437749-17-003344:notes:3]
31,

[0001437749-17-003344:notes:4]
2016
 and 
 January

[0001437749-17-003344:notes:5]
2,

[0001437749-17-003344:notes:6]
2016,
 respectively.  Management, in conjunction with an independent 
third
-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time. The accrual is not discounted as management cannot reasonably estimate when such remediation efforts will take place.


## lfus:OtherIncomeExpensePolicyTextBlock

[0001437749-17-003344:notes:7]
Other Expense (Income), Net

[0001437749-17-003344:notes:8]
Other expense (income), net generally consists of interest income, royalties, and non-operating income.


## lfus:PensionPlanAssetsMeasuredAtFairValueTableTextBlock

[0001437749-17-003344:notes:9]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices in Active Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Equity 50:50 Index Fund |  | $ | — |  |  | $ | 6,321 |  |  | $ | — |  |  | $ | 6,321 |  |
| Global Equity 50:50 GBP Hedged Fund |  |  | — |  |  |  | 6,406 |  |  |  | — |  |  |  | 6,406 |  |
| Philippine Stock |  |  | 906 |  |  |  | — |  |  |  | — |  |  |  | 906 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment Grade Corporate Bond Funds |  |  | 5,372 |  |  |  | — |  |  |  | — |  |  |  | 5,372 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | 3,265 |  |  |  | — |  |  |  | 3,265 |  |
| Active Corp Bond – Over 10 Yr Fund |  |  | — |  |  |  | 5,902 |  |  |  | — |  |  |  | 5,902 |  |
| Over 5y Index-Linked Gilts Fund |  |  | — |  |  |  | 10,724 |  |  |  | — |  |  |  | 10,724 |  |
| Philippine Long Government Securities |  |  | 1,133 |  |  |  | — |  |  |  | — |  |  |  | 1,133 |  |
| Philippine Long Corporate Bonds |  |  | 751 |  |  |  | — |  |  |  | — |  |  |  | 751 |  |
| Cash and equivalents |  |  | 476 |  |  |  | 952 |  |  |  | — |  |  |  | 1,428 |  |
| Total pension plan assets |  | $ | 8,638 |  |  | $ | 33,570 |  |  | $ | — |  |  | $ | 42,208 |  |

[0001437749-17-003344:notes:10]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Equity 50:50 Index Fund |  | $ | — |  |  | $ | 12,801 |  |  | $ | — |  |  | $ | 12,801 |  |
| Philippine Stock |  |  | 836 |  |  |  | — |  |  |  | — |  |  |  | 836 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment Grade Corporate Bond Funds |  |  | 6,807 |  |  |  | — |  |  |  | — |  |  |  | 6,807 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | 3,428 |  |  |  | — |  |  |  | 3,428 |  |
| Active Corp Bond – Over 10 Year Fund |  |  | — |  |  |  | 6,440 |  |  |  | — |  |  |  | 6,440 |  |
| Over 5y Index-Linked Gilts Fund |  |  | — |  |  |  | 10,248 |  |  |  | — |  |  |  | 10,248 |  |
| Philippine Long Government Securities |  |  | 1,227 |  |  |  | — |  |  |  | — |  |  |  | 1,227 |  |
| Philippine Long Corporate Bonds |  |  | 781 |  |  |  | — |  |  |  | — |  |  |  | 781 |  |
| Cash and equivalents |  |  | 2,061 |  |  |  | — |  |  |  | — |  |  |  | 2,061 |  |
| Total pension plan assets |  | $ | 11,712 |  |  | $ | 32,917 |  |  | $ | — |  |  | $ | 44,629 |  |


## lfus:RevenueRecognitionAndBillingPolicyTextBlock

[0001437749-17-003344:notes:11]
Revenue and Billing

[0001437749-17-003344:notes:12]
The company accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the company’s published price lists. The customer is invoiced when the company’s products are shipped to them in accordance with the terms of the sales agreement.


## lfus:RevenueRecognitionReturnToStockPolicyTextBlock

[0001437749-17-003344:notes:13]
Return to Stock

[0001437749-17-003344:notes:14]
The company has a return to stock policy whereby a customer with prior authorization from Littelfuse management can return previously purchased goods for full or partial credit. The company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001437749-17-003344:notes:15]
2.
 Correction of immaterial errors

[0001437749-17-003344:notes:16]
In the 
second
 quarter of 
2016,
 management determined that the company 
 may
 incur additional income taxes and interest in a foreign jurisdiction with respect to the 
2011
 through 
2015
 fiscal years. The cumulative adjustment for this income tax (including interest of 
$1.5
 million) as of 
 January

[0001437749-17-003344:notes:17]
2016,
 is approximately 
$4.9
 million. The adjustment applicable to 
2015,

[0001437749-17-003344:notes:18]
2014,

[0001437749-17-003344:notes:19]
2013,

[0001437749-17-003344:notes:20]
2012,
 and 
2011
 was 
$1.6
 million, 
$1.3
 million, 
$1.0
 million, 
$0.9
 million, and 
$0.1
 million, respectively.

[0001437749-17-003344:notes:21]
Pursuant to the guidance of Staff Accounting Bulletin ("SAB") No. 
99,
 Materiality, the company concluded that the errors were not material to any of its applicable prior period annual and quarterly financial statements. Although the errors were immaterial to prior periods, the prior period annual and interim financial statements were revised, in accordance with SAB No. 
108,
 Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements, due to the significance of the out-of-period correction. The adjustment for each year has been treated as applicable to the 
fourth
 quarter of each year.

[0001437749-17-003344:notes:22]
The following is a reconciliation of the effects of the adjustments to the previously reported balance sheet at 
 January

[0001437749-17-003344:notes:23]
2016
 follows:

[0001437749-17-003344:notes:24]
|  |  | January 2, 2016 |  |
| (in thousands) |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Other long-term liabilities |  | $ | 12,809 |  |  | $ | 4,946 |  |  | $ | 17,755 |  |
| Total shareholders’ equity |  |  | 744,198 |  |  |  | (4,946 | ) |  |  | 739,252 |  |

[0001437749-17-003344:notes:25]
The following is a reconciliation of the effects of the adjustments to the previously reported statements of net income for the years ended 
 January

[0001437749-17-003344:notes:26]
2016
 and 
 December

[0001437749-17-003344:notes:27]
27,

[0001437749-17-003344:notes:28]
2014
 follows:

[0001437749-17-003344:notes:29]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
| (in thousands except per share amounts) |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Income taxes |  | $ | 24,482 |  |  | $ | 1,600 |  |  | $ | 26,082 |  |  | $ | 32,228 |  |  | $ | 1,318 |  |  | $ | 33,546 |  |
| Net income |  |  | 82,466 |  |  |  | (1,600 | ) |  |  | 80,866 |  |  |  | 99,418 |  |  |  | (1,318 | ) |  |  | 98,100 |  |
| Income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.65 |  |  | $ | (0.07 | ) |  | $ | 3.58 |  |  | $ | 4.41 |  |  | $ | (0.06 | ) |  | $ | 4.35 |  |
| Diluted |  | $ | 3.63 |  |  | $ | (0.07 | ) |  | $ | 3.56 |  |  | $ | 4.37 |  |  | $ | (0.05 | ) |  | $ | 4.32 |  |

[0001437749-17-003344:notes:30]
The following is a reconciliation of the effects of the adjustments to the previously reported statements of cash flows for the years ended 
 January

[0001437749-17-003344:notes:31]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
| (in thousands) |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Net income |  | $ | 82,466 |  |  | $ | (1,600 | ) |  | $ | 80,866 |  |  | $ | 99,418 |  |  | $ | (1,318 | ) |  | $ | 98,100 |  |
| Accrued taxes |  |  | (1,043 | ) |  |  | 1,600 |  |  |  | 557 |  |  |  | (549 | ) |  |  | 1,318 |  |  |  | 769 |  |
| Net cash provided by operating activities |  |  | 165,826 |  |  |  | — |  |  |  | 165,826 |  |  |  | 153,141 |  |  |  | — |  |  |  | 153,141 |  |

[0001437749-17-003344:notes:32]
The following is a reconciliation of the effects of the adjustments to the previously reported statements of equity for the years ended 
 January

[0001437749-17-003344:notes:33]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
| (in thousands) |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Net income |  | $ | 82,466 |  |  | $ | (1,600 | ) |  | $ | 80,866 |  |  | $ | 99,418 |  |  | $ | (1,318 | ) |  | $ | 98,100 |  |
| Comprehensive income |  |  | 57,921 |  |  |  | (1,600 | ) |  |  | 56,321 |  |  |  | 57,875 |  |  |  | (1,318 | ) |  |  | 56,557 |  |
| Retained earnings |  |  | 562,717 |  |  |  | (4,946 | ) |  |  | 557,771 |  |  |  | 523,302 |  |  |  | (3,346 | ) |  |  | 519,956 |  |
| Total shareholders’ equity |  |  | 744,198 |  |  |  | (4,946 | ) |  |  | 739,252 |  |  |  | 727,665 |  |  |  | (3,346 | ) |  |  | 724,319 |  |

[0001437749-17-003344:notes:34]
The following is a reconciliation of the effects of the adjustments to the previously reported statement of equity at 
 December

[0001437749-17-003344:notes:35]
28,

[0001437749-17-003344:notes:36]
2013
 follows:

[0001437749-17-003344:notes:37]
|  |  | December 28, 2013 |  |
| (in thousands) |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Retained earnings |  | $ | 445,059 |  |  | $ | (2,028 | ) |  | $ | 443,031 |  |
| Total shareholders’ equity |  |  | 686,916 |  |  |  | (2,028 | ) |  |  | 684,888 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001437749-17-003344:notes:38]
Advertising Costs

[0001437749-17-003344:notes:39]
The company expenses advertising costs as incurred, which amounted to 
$2.9
 million, 
$2.3
 million, and 
$2.8
 million in 
2016,

[0001437749-17-003344:notes:40]
2015,
 and 
2014,
 respectively, and are included as a component of selling, general, and administrative expenses.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-17-003344:notes:41]
Basis of Presentation

[0001437749-17-003344:notes:42]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America and include the assets, liabilities, sales and expenses of all wholly-owned subsidiaries and majority-owned subsidiaries over which the company exercises control.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-17-003344:notes:43]
|  |  | For the Year Ended |  |
| (in thousands, except per share amounts) |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 1,130,645 |  |  | $ | 1,104,838 |  |
| Income before income taxes |  |  | 143,110 |  |  |  | 120,370 |  |
| Net income |  |  | 124,388 |  |  |  | 92,983 |  |
| Net income per share — basic |  |  | 5.51 |  |  |  | 4.12 |  |
| Net income per share — diluted |  |  | 5.47 |  |  |  | 4.09 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001437749-17-003344:notes:44]
Cash Equivalents

[0001437749-17-003344:notes:45]
All highly liquid investments, with an original maturity of 
three
 months or less when purchased, are considered to be cash equivalents.


## us-gaap:CommitmentsDisclosureTextBlock

[0001437749-17-003344:notes:46]
7.
 Lease Commitments

[0001437749-17-003344:notes:47]
The company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was 
$12.6
 million, 
$11.1
 million, and 
$8.9
 million in 
2016,

[0001437749-17-003344:notes:48]
2015,
 and 
2014,
 respectively.

[0001437749-17-003344:notes:49]
Rent expense is recognized on a straight-line basis over the term of the leases. The difference between straight-line basis rent and the amount paid has been recorded as accrued lease obligations. The company also has leases that have lease renewal provisions. As of 
 December

[0001437749-17-003344:notes:50]
2016,
 all operating leases outstanding were with 
third
 parties. The company did not have any capital leases as of 
 December

[0001437749-17-003344:notes:51]
2016

[0001437749-17-003344:notes:52]
.

[0001437749-17-003344:notes:53]
Future minimum payments for all non-cancellable operating leases with initial terms of 
one
 year or more at 
 December

[0001437749-17-003344:notes:54]
2016
 are as follows:

[0001437749-17-003344:notes:55]
| (in thousands) |  | Future Minimum Payments |  |
| 2017 |  | $ | 11,971 |  |
| 2018 |  |  | 6,149 |  |
| 2019 |  |  | 4,963 |  |
| 2020 |  |  | 4,458 |  |
| 2021 |  |  | 3,756 |  |
| 2022 and thereafter |  |  | 8,025 |  |
|  |  | $ | 39,322 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-003344:notes:56]
8.
 Debt

[0001437749-17-003344:notes:57]
The carrying amounts of debt at 
 December

[0001437749-17-003344:notes:58]
| (in thousands) |  | 2016 |  |  | 2015 |  |
| Revolving credit facility |  | $ | 112,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 120,313 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 3,522 |  |  |  | 9,474 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 122,313 |  |  |  | — |  |
| Euro Senior Notes, Series B due 2028 |  |  | 99,314 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,820 | ) |  |  | (721 | ) |
| Total debt |  |  | 454,142 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (87,000 | ) |
| Total long-term debt |  | $ | 447,892 |  |  | $ | 83,753 |  |

[0001437749-17-003344:notes:59]
Revolving Credit Facility / Term Loan

[0001437749-17-003344:notes:60]
On 
 March

[0001437749-17-003344:notes:61]
4,

[0001437749-17-003344:notes:62]
2016,
 the company entered into a new 
five
 year credit agreement with a group of lenders for up to 
$700.0
 million. The new credit agreement consists of an unsecured revolving credit facility of 
$575.0
 million and an unsecured term loan credit facility of up to 
$125.0
 million. In addition, the company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the company is required to make quarterly principal payments of 
$1.6
 million through 
 March

[0001437749-17-003344:notes:63]
2018
 and 
$3.1
 million from 
 June

[0001437749-17-003344:notes:64]
30,

[0001437749-17-003344:notes:65]
2018
 through 
 December

[0001437749-17-003344:notes:66]
2020
 with the remaining balance due on 
 March

[0001437749-17-003344:notes:67]
2021.

[0001437749-17-003344:notes:68]
Outstanding borrowings under the credit agreement bear interest, at the company’s option, at either LIBOR, fixed for interest periods of 
one,

[0001437749-17-003344:notes:69]
two,

[0001437749-17-003344:notes:70]
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the company’s Consolidated Leverage Ratio, as defined. The company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.27%
 at 
 December

[0001437749-17-003344:notes:71]
2016.

[0001437749-17-003344:notes:72]
As of 
 December

[0001437749-17-003344:notes:73]
2016,
 the company had 
$0.1
 million outstanding in letters of credit and had available 
$462.4
 million of borrowing capacity under the revolving credit facility. At 
 December

[0001437749-17-003344:notes:74]
2016,
 the company was in compliance with all covenants under the credit agreement.

[0001437749-17-003344:notes:75]
The company previously entered into credit agreement with J.P. Morgan Securities LLC on 
 May

[0001437749-17-003344:notes:76]
2013,
 for up to 
$325.0
 million which consisted of an unsecured revolving credit facility of 
$225.0
 million and an unsecured term loan of 
$100.0
 million. The credit agreement was for a 
five
 year period. On 
 January

[0001437749-17-003344:notes:77]
2014,
 the company increased the unsecured revolving credit facility by 
$50.0
 million, thereby increasing the total revolver borrowing capacity from 
$225.0
 million to 
$275.0
 million. Along with entering into the new 
five
 year credit agreement on 
 March

[0001437749-17-003344:notes:78]
2016,
 the company terminated this credit agreement. At 
 January

[0001437749-17-003344:notes:79]
2016,
 the company had available borrowing capacity of 
$197.9
 million under the credit agreement at an interest rate of LIBOR plus 
1.25%,
 or a total interest rate of 
1.68%
 as of 
 January

[0001437749-17-003344:notes:80]
2016.
 For the fiscal years ended 
 January

[0001437749-17-003344:notes:81]
2016,
 the company had 
$0.1
 million outstanding in letters of credit and no amounts were drawn under these lines of credit at 
 January

[0001437749-17-003344:notes:82]
Senior Notes

[0001437749-17-003344:notes:83]
On 
 December

[0001437749-17-003344:notes:84]
8,

[0001437749-17-003344:notes:85]
2016,
 the company entered into a Note Purchase Agreement, pursuant to which the company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December

[0001437749-17-003344:notes:86]
2016
 for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December

[0001437749-17-003344:notes:87]
2023,
 and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December

[0001437749-17-003344:notes:88]
2028
 (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June

[0001437749-17-003344:notes:89]
8
 and 
 December

[0001437749-17-003344:notes:90]
8,
 commencing 
 June

[0001437749-17-003344:notes:91]
2017.

[0001437749-17-003344:notes:92]
2016,
 the company entered into a Note Purchase Agreement, pursuant to which the company will issue and sell 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February

[0001437749-17-003344:notes:93]
15,

[0001437749-17-003344:notes:94]
2017,

[0001437749-17-003344:notes:95]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February

[0001437749-17-003344:notes:96]
2022,
 and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February

[0001437749-17-003344:notes:97]
2027
 (together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on 
 February

[0001437749-17-003344:notes:98]
15
 and 
 August

[0001437749-17-003344:notes:99]
15,
 commencing 
 August

[0001437749-17-003344:notes:100]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the company.

[0001437749-17-003344:notes:101]
The Senior Notes are subject to certain customary covenants, including limitations on the company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the company, and to incur liens. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 December

[0001437749-17-003344:notes:102]
2016,
 the company was in compliance with all covenants under the revolving credit facility and the Senior Notes.

[0001437749-17-003344:notes:103]
The company 
 may
 redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001437749-17-003344:notes:104]
Debt Issuance Costs

[0001437749-17-003344:notes:105]
The company incurred debt issuance costs of 
$1.7
 million in relation to the new credit agreement which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement. This new credit agreement was determined to be a modification under ASC 
470
-
50
 of the previous credit agreement. The company additionally incurred debt issuance costs of 
$1.8
 million in relation to the Senior Notes which are being amortized over the respective lives of the Series A and B of each of the U.S. Senior Notes and Euro Senior Notes.

[0001437749-17-003344:notes:106]
Entrusted Loan

[0001437749-17-003344:notes:107]
During 
2014,
 the company entered into an entrusted loan arrangement (“Entrusted Loan”) of

[0001437749-17-003344:notes:108]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in 
 November

[0001437749-17-003344:notes:109]
2019.
 The balance of the Entrusted Loan was

[0001437749-17-003344:notes:110]
Chinese renminbi 
24.5
 million (approximately U.S. 
$3.5
 million) at 
 December

[0001437749-17-003344:notes:111]
Interest paid on all company debt was approximately 
$8.6
 million, 
$4.1
 million, and 
$4.9
 million in 
2016,

[0001437749-17-003344:notes:112]
Debt Maturities

[0001437749-17-003344:notes:113]
Scheduled maturities of the company’s long-term debt for each of the 
five
 years succeeding 
 December

[0001437749-17-003344:notes:114]
2016
 and thereafter are summarized as follows:

[0001437749-17-003344:notes:115]
| (in thousands) |  | Scheduled Maturities |  |
| 2017 |  | $ | 6,250 |  |
| 2018 |  |  | 10,937 |  |
| 2019 |  |  | 16,022 |  |
| 2020 |  |  | 12,500 |  |
| 2021 |  |  | 190,626 |  |
| 2022 and thereafter |  |  | 221,627 |  |
|  |  | $ | 457,962 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-003344:notes:116]
13.
 Earnings Per Share

[0001437749-17-003344:notes:117]
The following table sets forth the computation of basic and diluted earnings per share:

[0001437749-17-003344:notes:118]
| (in thousands, except per share amounts) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 104,488 |  |  | $ | 80,866 |  |  | $ | 98,100 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,559 |  |  |  | 22,565 |  |  |  | 22,543 |  |
| Effect of dilutive securities |  |  | 167 |  |  |  | 154 |  |  |  | 184 |  |
| Diluted |  |  | 22,727 |  |  |  | 22,719 |  |  |  | 22,727 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 4.63 |  |  | $ | 3.58 |  |  | $ | 4.35 |  |
| Diluted earnings per share |  | $ | 4.60 |  |  | $ | 3.56 |  |  | $ | 4.32 |  |

[0001437749-17-003344:notes:119]
Potential shares of common stock attributable to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 
53,448
 shares, 
113,130
 shares, and 
43,693
 shares in 
2016,


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-17-003344:notes:120]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,435 |  |

[0001437749-17-003344:notes:121]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 11,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,697 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-17-003344:notes:122]
9.
 Fair Value of Assets and Liabilities

[0001437749-17-003344:notes:123]
Applicable accounting literature establishes a hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Applicable accounting literature defines levels within the hierarchy based on the reliability of inputs as follows:

[0001437749-17-003344:notes:124]
Level 
1—Valuations
 based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0001437749-17-003344:notes:125]
Level 
2—Valuations
 based upon quoted prices for 
similar
 instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable, and

[0001437749-17-003344:notes:126]
Level 
3—

[0001437749-17-003344:notes:127]
Valuations

[0001437749-17-003344:notes:128]
based upon 
one
 or more significant unobservable inputs.

[0001437749-17-003344:notes:129]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0001437749-17-003344:notes:130]
Investments

[0001437749-17-003344:notes:131]
Investments in equity securities listed on a national market or exchange are valued at the last sales price. Such securities are further detailed in Note 
1,

[0001437749-17-003344:notes:132]
Summary of Significant Accounting Policies and Other Information
, and classified within Level 
1
 of the valuation hierarchy.

[0001437749-17-003344:notes:133]
There were no changes during 
2016
 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of 
 December

[0001437749-17-003344:notes:134]
2016,
 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-17-003344:notes:135]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of 
 December

[0001437749-17-003344:notes:136]
2016:

[0001437749-17-003344:notes:137]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of 
 January

[0001437749-17-003344:notes:138]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The company’s revolving and term loan debt facilities’ fair values approximate book value at 
 January

[0001437749-17-003344:notes:139]
2014,
 as the rates on these borrowings are variable in nature. The fair values of the company’s Euro Senior Notes, Series A and Series B were 
$122.6
 million and 
$99.2
 million, respectively, at 
 December

[0001437749-17-003344:notes:140]
2016
 and are considered Level 
2
 in the valuation hierarchy. Carrying values of the Euro Senior Notes, Series A and Series B were 
$122.3
 million and 
99.3
 million, respectively, at 
 December


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001437749-17-003344:notes:141]
Foreign Currency Translation

[0001437749-17-003344:notes:142]
/

[0001437749-17-003344:notes:143]
Remeasurement

[0001437749-17-003344:notes:144]
The company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. The amount of foreign currency gain or loss from remeasurement recognized in the income statement was a loss of 
$0.5
 million in 
2016,
 a gain of 
$1.5
 million in 
2015,
 and a loss of 
$3.9
 million in 
2014.
 Adjustments from the translation process are recognized in “Shareholders’ equity” as a component of “Accumulated other comprehensive income.”


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-17-003344:notes:145]
6.
 Goodwill and Other Intangible Assets

[0001437749-17-003344:notes:146]
The amounts for goodwill and changes in the carrying value by segment are as follows at 
 December

[0001437749-17-003344:notes:147]
| (in thousands) |  | 2016 |  |  | Additions (Reductions)(a) |  |  | Adjustments(c) |  |  | 2015 |  |  | Additions (Reductions)(b) |  |  | Adjustments(c) |  |  | 2014 |  |
| Electronics |  | $ | 215,765 |  |  | $ | 162,172 |  |  | $ | (4,653 | ) |  | $ | 58,246 |  |  | $ | (524 | ) |  | $ | (1,740 | ) |  | $ | 60,510 |  |
| Automotive |  |  | 144,585 |  |  |  | 70,762 |  |  |  | (6,439 | ) |  |  | 80,262 |  |  |  | 1,994 |  |  |  | (3,449 | ) |  |  | 81,717 |  |
| Industrial |  |  | 43,194 |  |  |  | (8,794 | ) |  |  | 729 |  |  |  | 51,259 |  |  |  | — |  |  |  | (2,770 | ) |  |  | 54,029 |  |
| Total |  | $ | 403,544 |  |  | $ | 224,140 |  |  | $ | (10,363 | ) |  | $ | 189,767 |  |  | $ | 1,470 |  |  | $ | (7,959 | ) |  | $ | 196,256 |  |

[0001437749-17-003344:notes:148]
| (a) | The net additions of $224,140 resulted primarily from the acquisitions of PolySwitch, ON and Menber’s, partially offset by the impairment of custom products reporting unit goodwill. |

[0001437749-17-003344:notes:149]
| (b) | Electronics reduction resulted from reclassification of goodwill to customer relationships. Automotive addition of $2.0 million resulted from business acquisitions. |

[0001437749-17-003344:notes:150]
| (c) | Adjustments reflect the impact of changes in foreign exchange rates. |

[0001437749-17-003344:notes:151]
The company recognized a goodwill impairment charge of 
$8.8
 million in 
2016,
 but

[0001437749-17-003344:notes:152]
none

[0001437749-17-003344:notes:153]
in 
2015
 and 
2014.
 The charge related to the custom products reporting unit in the Industrial segment.

[0001437749-17-003344:notes:154]
For intangible assets with definite lives, the company recorded amortization expense of 
$19.3
 million, 
$11.9
 million, and 
$12.5
 million in 
2016,

[0001437749-17-003344:notes:155]
2015,
 and 
2014,
 respectively. Additionally for 
2016,
 the company recognized an impairment charge of 
$6.0
 million. The details of other intangible assets and related future amortization expense of existing intangible assets at 
 December

[0001437749-17-003344:notes:156]
|  |  | 2016 |  |  | 2015 |  |
| (in thousands) |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |
| Patents, licenses and software |  |  | 11.4 |  |  | $ | 131,611 |  |  | $ | 48,004 |  |  |  | 11.6 |  |  | $ | 61,297 |  |  | $ | 41,076 |  |
| Distribution network |  |  | 12.1 |  |  |  | 49,150 |  |  |  | 30,155 |  |  |  | 12.4 |  |  |  | 45,564 |  |  |  | 29,074 |  |
| Customer relationships, trademarks and tradenames |  |  | 14.4 |  |  |  | 150,227 |  |  |  | 40,463 |  |  |  | 13.0 |  |  |  | 81,233 |  |  |  | 30,534 |  |
| Tradenames(a) |  |  | — |  |  |  | 4,319 |  |  |  | 3,659 |  |  |  | — |  |  |  | 4,213 |  |  |  | — |  |
| Total |  |  | 12.9 |  |  | $ | 335,307 |  |  | $ | 122,281 |  |  |  | 12.4 |  |  | $ | 192,307 |  |  | $ | 100,684 |  |

[0001437749-17-003344:notes:157]
| (a) | Tradenames with indefinite lives. |

[0001437749-17-003344:notes:158]
Estimated amortization expense related to intangible assets with definite lives at 
 December

[0001437749-17-003344:notes:159]
2016
 is as follows:

[0001437749-17-003344:notes:160]
| (in thousands) |  | Estimated Amortization |  |
| 2017 |  | $ | 23,945 |  |
| 2018 |  |  | 23,497 |  |
| 2019 |  |  | 23,786 |  |
| 2020 |  |  | 23,242 |  |
| 2021 |  |  | 21,816 |  |
| 2022 and thereafter |  |  | 96,740 |  |
|  |  | $ | 213,026 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-003344:notes:161]
12.
 Income Taxes

[0001437749-17-003344:notes:162]
Domestic and foreign income (loss) before income taxes is as follows:

[0001437749-17-003344:notes:163]
| (in thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Domestic |  | $ | (9,563 | ) |  | $ | 1,313 |  |  | $ | 35,264 |  |
| Foreign |  |  | 132,837 |  |  |  | 105,635 |  |  |  | 96,382 |  |
| Income before income taxes |  | $ | 123,274 |  |  | $ | 106,948 |  |  | $ | 131,646 |  |

[0001437749-17-003344:notes:164]
Federal, state and foreign income tax (benefit) expense consists of the following:

[0001437749-17-003344:notes:165]
| (in thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (3,992 | ) |  | $ | (6,686 | ) |  | $ | 8,003 |  |
| State |  |  | (648 | ) |  |  | 2,078 |  |  |  | 1,275 |  |
| Foreign |  |  | 28,695 |  |  |  | 19,211 |  |  |  | 28,756 |  |
| Subtotal |  |  | 24,055 |  |  |  | 14,603 |  |  |  | 38,034 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal and State |  |  | (1,594 | ) |  |  | 11,330 |  |  |  | (1,513 | ) |
| Foreign |  |  | (3,675 | ) |  |  | 149 |  |  |  | (2,975 | ) |
| Subtotal |  |  | (5,269 | ) |  |  | 11,479 |  |  |  | (4,488 | ) |
| Provision for income taxes |  | $ | 18,786 |  |  | $ | 26,082 |  |  | $ | 33,546 |  |

[0001437749-17-003344:notes:166]
The current federal tax benefit for 
2016
 includes an estimated 
$3
 million benefit as a result of the anticipated carry-back of the 
2016
 U.S. federal net operating loss to the 
2014
 tax year.

[0001437749-17-003344:notes:167]
The current federal tax benefit for 
2015
 includes an 
$11.7
 million benefit reclassified from accumulated other comprehensive income as a result of the company’s termination of the U.S. defined benefit pension plan as described in Note 
10,

[0001437749-17-003344:notes:168]
Benefit Plans
.

[0001437749-17-003344:notes:169]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0001437749-17-003344:notes:170]
| (in thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Tax expense at statutory rate of 35% |  | $ | 43,146 |  |  | $ | 37,432 |  |  | $ | 46,076 |  |
| State and local taxes, net of federal tax benefit |  |  | (415 | ) |  |  | 1,907 |  |  |  | 1,186 |  |
| Foreign income tax rate differential |  |  | (25,471 | ) |  |  | (18,253 | ) |  |  | (13,663 | ) |
| Impairment of goodwill without tax benefit |  |  | 3,088 |  |  |  | — |  |  |  | — |  |
| Tax on unremitted earnings |  |  | 2,747 |  |  |  | — |  |  |  | — |  |
| Mexico manufacturing operations restructuring |  |  | — |  |  |  | 4,841 |  |  |  | — |  |
| Nondeductible professional fees |  |  | 313 |  |  |  | 1,011 |  |  |  | — |  |
| Tax deduction for stock of foreign subsidiary |  |  | (3,896 | ) |  |  | — |  |  |  | — |  |
| Other, net |  |  | (726 | ) |  |  | (856 | ) |  |  | (53 | ) |
| Provision for income taxes |  | $ | 18,786 |  |  | $ | 26,082 |  |  | $ | 33,546 |  |

[0001437749-17-003344:notes:171]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the company’s assets and liabilities. Significant components of the company’s deferred tax assets and liabilities at 
 December

[0001437749-17-003344:notes:172]
2016,
 are as follows:

[0001437749-17-003344:notes:173]
| (in thousands) |  | 2016 |  |  | 2015 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 31,770 |  |  | $ | 19,738 |  |
| Foreign tax credit carryforwards |  |  | 6,472 |  |  |  | 1,529 |  |
| Accrued restructuring |  |  | 456 |  |  |  | 1,115 |  |
| Capital losses |  |  | 4,557 |  |  |  | 4,557 |  |
| Domestic and foreign net operating loss carryforwards |  |  | 2,223 |  |  |  | 684 |  |
| Gross deferred tax assets |  |  | 45,478 |  |  |  | 27,623 |  |
| Less: Valuation allowance |  |  | (6,738 | ) |  |  | (4,557 | ) |
| Total deferred tax assets |  |  | 38,740 |  |  |  | 23,066 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Tax depreciation and amortization in excess of book |  |  | 23,471 |  |  |  | 22,747 |  |
| Foreign tax on unremitted earnings |  |  | 1,750 |  |  |  | — |  |
| Total deferred tax liabilities |  |  | 25,221 |  |  |  | 22,747 |  |
| Net deferred tax assets |  | $ | 13,519 |  |  | $ | 319 |  |

[0001437749-17-003344:notes:174]
The deferred tax asset valuation allowance is related to a U.S. capital loss carryover and, with respect to 
2016,
 tax attributes of certain foreign subsidiaries which are not expected to be realized. The remaining domestic and foreign net operating losses either have no expiration date or are expected to be utilized prior to expiration. The foreign tax credit carryforwards begin to expire in 
2020.
 The company paid income taxes of 
$35.6
 million, 
$23.3
 million, and 
$26.6
 million in 
2016,

[0001437749-17-003344:notes:175]
U.S. income taxes were not provided on a cumulative total of approximately 
$498
 million of undistributed earnings for certain non-U.S. subsidiaries as of 
 December

[0001437749-17-003344:notes:176]
2016,
 and accordingly, no deferred tax liability has been established relative to these earnings. The determination of the deferred tax liability associated with the distribution of these earnings is not practicable. The company accrued 
$1.8
 million for certain foreign taxes on unremitted earnings of non-U.S. subsidiaries because of anticipated distributions (no U.S. tax is expected to be incurred on such distributions). The company has 
three
 subsidiaries in China on “tax holidays.” The tax holidays begin to expire in 
2017.
 The company expects to be granted extensions. Such tax holidays contributed 
$2.7
 million in tax benefits 
($0.12
 per diluted share) during 
2016
 with similar amounts expected in future years while tax holidays are in effect.

[0001437749-17-003344:notes:177]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of 
 December

[0001437749-17-003344:notes:178]
2016,

[0001437749-17-003344:notes:179]
January

[0001437749-17-003344:notes:180]
2016,
 and 
 December

[0001437749-17-003344:notes:181]
2014
 is as follows:

[0001437749-17-003344:notes:182]
| (in thousands) |  | Unrecognized Tax Benefits |  |
| Balance at December 27, 2014 |  | $ | 2,550 |  |
| Additions for tax positions taken in the current year |  |  | 982 |  |
| Balance at January 2, 2016 |  |  | 3,532 |  |
| Additions for tax positions taken in the current year |  |  | 2,696 |  |
| Additions for tax positions taken in the pre-acquisition periods of acquired subsidiaries |  |  | 2,491 |  |
| Settlements |  |  | (102 | ) |
| Balance at December 31, 2016 |  | $ | 8,617 |  |

[0001437749-17-003344:notes:183]
The company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense. The company recognized interest expense of 
$0.9
 million, 
$0.2
 million, and 
$0.3
 million in 
2016,

[0001437749-17-003344:notes:184]
2015,
 and 
2014
 respectively. Accrued interest was 
$2.4
 million, 
$1.5
 million, and 
$1.3
 million as of 
 December

[0001437749-17-003344:notes:185]
2014,
 respectively.

[0001437749-17-003344:notes:186]
The amount of unrecognized tax benefits at 
 December

[0001437749-17-003344:notes:187]
2016
 was 
$8.6
 million. This total represents the amount of tax benefits that, if recognized, would favorably affect the effective income tax rate in future periods. The company does not expect a decrease in unrecognized tax benefits in the next 
12
 months. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility. The U.S. federal statute of limitations remains open for 
2013
 onward although the company has been audited for 
2014
 (during 
2016)
 and the audit has been concluded with no additional tax due. Foreign and U.S. state statute of limitations generally range from 
three
 to 
seven
 years. The German tax authority concluded the examination of the company’s tax years 
2008
 through 
2010
 with less than 
$0.1
 million of additional tax due and is currently conducting its examination for tax years 
2011
 through 
2014.
 The company does not expect to recognize a significant amount of additional tax expense as a result of concluding German tax examination.


## us-gaap:IncomeTaxPolicyTextBlock

[0001437749-17-003344:notes:188]
Income Taxes

[0001437749-17-003344:notes:189]
The company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. Federal and state income taxes are provided on the portion of foreign income that is expected to be remitted to the U.S. and be taxable.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-17-003344:notes:190]
5.
 Inventories

[0001437749-17-003344:notes:191]
The components of inventories at 
 December

[0001437749-17-003344:notes:192]
| (in thousands) |  | 2016 |  |  | 2015 |  |
| Raw materials |  | $ | 32,231 |  |  | $ | 33,599 |  |
| Work in process |  |  | 23,354 |  |  |  | 16,479 |  |
| Finished goods |  |  | 58,478 |  |  |  | 48,551 |  |
| Total |  | $ | 114,063 |  |  | $ | 98,629 |  |


## us-gaap:InventoryPolicyTextBlock

[0001437749-17-003344:notes:193]
Inventories

[0001437749-17-003344:notes:194]
Inventories are stated at the lower of cost or market 
(first
 in, 
first
 out method), which approximates current replacement cost. The company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.


## us-gaap:InvestmentPolicyTextBlock

[0001437749-17-003344:notes:195]
Short-Term and Long-Term Investments

[0001437749-17-003344:notes:196]
The company has determined that certain of its investment securities are to be classified as available-for-sale. Available-for-sale securities are carried at fair value with the unrealized gains and losses reported as a component of “Accumulated Other Comprehensive Income (Loss).” Realized gains and losses and declines in unrealized value judged to be other-than-temporary on available-for-sale securities are included in other expense (income), net. The cost of securities sold is based on the specific identification method. Interest and dividends on securities classified as available-for-sale are included in interest income. Short-term investments, which are primarily certificates of deposits, are carried at cost which approximates fair value.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-17-003344:notes:197]
3.
 Acquisitions

[0001437749-17-003344:notes:198]
The company accounts for acquisitions using the acquisition method in accordance with ASC 
805,
 “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the company’s consolidated financial statements from the date of the acquisition.

[0001437749-17-003344:notes:199]
ON Portfolio

[0001437749-17-003344:notes:200]
On 
 August

[0001437749-17-003344:notes:201]
29,

[0001437749-17-003344:notes:202]
2016,
 the company acquired certain assets of select businesses (the “ON Portfolio”) of ON Semiconductor Corporation for 
$104.0
 million. The company funded the acquisition with available cash and proceeds from its credit facility

[0001437749-17-003344:notes:203]
. The acquired business, which is included in the Electronics segment,

[0001437749-17-003344:notes:204]
consists of a product portfolio that includes transient voltage suppression (“TVS”) diodes, switching thyristors and insulated gate bipolar transistors (“IGBTs”) for automotive ignition applications. The acquisition expands the company’s offerings in power semiconductor applications as well as increases its presence in the automotive electronics market. The ON Portfolio products have strong synergies with the company’s existing circuit protection business and will strengthen its channel partnerships and customer engagement.

[0001437749-17-003344:notes:205]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the ON Portfolio acquisition:

[0001437749-17-003344:notes:206]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 104,000 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 4,816 |  |
| Customer relationships |  |  | 31,800 |  |
| Patented and unpatented technologies |  |  | 8,800 |  |
| Non-compete agreement |  |  | 2,500 |  |
| Goodwill |  |  | 56,084 |  |
|  |  | $ | 104,000 |  |

[0001437749-17-003344:notes:207]
All the ON Portfolio business goodwill and other assets were recorded in the Electronics segment and are reflected in the Americas and Europe geographic areas. The customer relationships are being amortized over 
13.5
 years. The patented and unpatented technologies are being amortized over 
6
-
8.5
 years. The non-compete agreement is being amortized over 
4
 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining the ON Portfolio products with the company’s existing

[0001437749-17-003344:notes:208]
power semiconductor product portfolio. 
$7.3
 million of goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-17-003344:notes:209]
As required by purchase accounting rules, the company recorded a 
$0.7
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. All of the step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-17-003344:notes:210]
Included in the company’s consolidated statement of net income for the year ended 
 December

[0001437749-17-003344:notes:211]
2016
 are net sales of approximately 
$21.8
 million since the 
 August

[0001437749-17-003344:notes:212]
2016
 acquisition of the ON Portfolio business.

[0001437749-17-003344:notes:213]
Menber’s

[0001437749-17-003344:notes:214]
On 
 April

[0001437749-17-003344:notes:215]
2016,
 the company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy for 
$19.2
 million, net of acquired cash and after settlement of a working capital adjustment. The company funded the acquisition with cash on hand and borrowings under the company’s revolving credit facility. The acquired business is part of the company's commercial vehicle product business within the Automotive segment and specializes in the design, manufacturing, and selling of manual and electrical high current switches and trailer connectors for commercial vehicles. The acquisition expands the company’s commercial vehicle products business globally.

[0001437749-17-003344:notes:216]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Menber’s acquisition:

[0001437749-17-003344:notes:217]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash, net of acquired cash |  | $ | 19,162 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 12,919 |  |
| Property, plant, and equipment |  |  | 1,693 |  |
| Customer relationships |  |  | 3,050 |  |
| Patented and unpatented technologies |  |  | 224 |  |
| Trademarks and tradenames |  |  | 1,849 |  |
| Goodwill |  |  | 8,091 |  |
| Current liabilities |  |  | (7,220 | ) |
| Other non-current liabilities |  |  | (1,444 | ) |
|  |  | $ | 19,162 |  |

[0001437749-17-003344:notes:218]
All Menber’s goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The customer relationships are being amortized over 
10
 years. The patented and unpatented technologies are being amortized over 
5
 years. The trademarks and tradenames are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining Menber’s products with the company’s existing automotive product portfolio. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-17-003344:notes:219]
As required by purchase accounting rules, the company recorded a 
$0.2
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, with the charge reflected as other non-segment costs.

[0001437749-17-003344:notes:220]
Included in the company’s consolidated statements of net income for the year ended 
 December

[0001437749-17-003344:notes:221]
2016
 are net sales of approximately 
$17.3
 million since the 
 April

[0001437749-17-003344:notes:222]
2016
 acquisition of Menber’s.

[0001437749-17-003344:notes:223]
PolySwitch

[0001437749-17-003344:notes:224]
25,

[0001437749-17-003344:notes:225]
2016,
 the company acquired 
100%
 of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for 
$348.3
 million, net of acquired cash and after settlement of certain post-closing adjustments. At 
 December

[0001437749-17-003344:notes:226]
$344.5
 million of the 
$348.3
 million purchase price has been paid with the remaining consideration expected to be paid by the 
second
 quarter of 
2017.
 The company funded the acquisition with available cash on hand and borrowings under the company’s revolving credit facility. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-17-003344:notes:227]
has a leading position in polymer based resettable circuit protection devices, with a strong global presence in the automotive, battery, industrial, communications and mobile computing markets. PolySwitch has manufacturing facilities in Shanghai and Kunshan, China and Tsukuba, Japan. The acquisition allows the company to strengthen its global circuit protection product portfolio, as well as strengthen its presence in the automotive electronics and battery end markets. The acquisition also significantly increases the company’s presence in Japan.

[0001437749-17-003344:notes:228]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the PolySwitch acquisition:

[0001437749-17-003344:notes:229]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Original consideration |  | $ | 350,000 |  |
| Post closing consideration adjustment received |  |  | (1,708 | ) |
| Acquired cash |  |  | (3,810 | ) |
| Acquired cash to be returned to seller |  |  | 3,810 |  |
| Total purchase consideration |  | $ | 348,292 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 60,228 |  |
| Property, plant, and equipment |  |  | 51,613 |  |
| Land lease |  |  | 4,290 |  |
| Patented and unpatented technologies |  |  | 56,425 |  |
| Customer relationships |  |  | 39,720 |  |
| Goodwill |  |  | 165,088 |  |
| Other long-term assets |  |  | 11,228 |  |
| Current liabilities |  |  | (35,280 | ) |
| Other non-current liabilities |  |  | (5,020 | ) |
|  |  | $ | 348,292 |  |

[0001437749-17-003344:notes:230]
All PolySwitch goodwill and other assets and liabilities were recorded in the Electronics and Automotive segments and reflected in all geographic areas. The customer relationships are being amortized over 
15
 years. The patented and unpatented technologies are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining PolySwitch products with the company’s existing automotive and electronics product portfolio. 
$103.8
 million and 
$61.3
 million of the goodwill for the above acquisition has been assigned to the Electronics and Automotive segments, respectively, with 
$64.9
 million expected to be deductible for tax purposes.

[0001437749-17-003344:notes:231]
As required by purchase accounting rules, the company recorded a 
$6.9
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the 
second
 quarter of 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-17-003344:notes:232]
2016
 are net sales of approximately 
$126.5
 million since the 
 March

[0001437749-17-003344:notes:233]
2016
 acquisition of PolySwitch.

[0001437749-17-003344:notes:234]
Sigmar S.r.l

[0001437749-17-003344:notes:235]
On 
 October

[0001437749-17-003344:notes:236]
1,

[0001437749-17-003344:notes:237]
2015,
 the company acquired 
100%
 of Sigmar S.r.l. (“Sigmar”). The total purchase price for Sigmar was 
$6.5
 million, net of cash acquired and including estimated additional net payments of up to 
$0.9
 million, a portion of which is subject to the achievement of certain milestones.

[0001437749-17-003344:notes:238]
Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel sensors and also manufactures selective catalytic reduction (“SCR”) quality sensors and diesel fuel heaters for automotive and commercial vehicle applications. The acquisition further expanded the company’s automotive sensor product line offerings within its Automotive segment. The company funded the acquisition with available cash.

[0001437749-17-003344:notes:239]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the Sigmar acquisition:

[0001437749-17-003344:notes:240]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash, net of acquired cash |  | $ | 5,558 |  |
| Estimated additional consideration payable |  |  | 901 |  |
| Total purchase consideration |  | $ | 6,459 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 2,519 |  |
| Property, plant, and equipment |  |  | 1,097 |  |
| Goodwill |  |  | 4,084 |  |
| Patents |  |  | 2,845 |  |
| Current liabilities |  |  | (1,518 | ) |
| Other non-current liabilities |  |  | (2,568 | ) |
|  |  | $ | 6,459 |  |

[0001437749-17-003344:notes:241]
All Sigmar goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The patents are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining Sigmar’s products with the company’s existing automotive product offerings. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-17-003344:notes:242]
Pro Forma Results

[0001437749-17-003344:notes:243]
The following table summarizes, on a pro forma basis, the combined results of operations of the company and the acquired PolySwitch and the ON Portfolio businesses as though the acquisitions had occurred as of 
 December

[0001437749-17-003344:notes:244]
2014.
 The company has not included pro forma results of operations for Menber’s or Sigmar as these results were not material to the company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the PolySwitch or ON Portfolio acquisitions occurred as of 
 December

[0001437749-17-003344:notes:245]
2014
 or of future consolidated operating results.

[0001437749-17-003344:notes:246]
Pro forma results presented above primarily reflect: (i) incremental depreciation relating to fair value adjustments to property, plant, and equipment; (ii) amortization adjustments relating to fair value estimates of intangible assets; (iii) incremental interest expense on assumed indebtedness; and (iv) additional cost of goods sold relating to the capitalization of gross profit as part of purchase accounting recognized for purposes of the pro forma as if it was recognized during the company’s 
first
 quarter of 
2015.
 Pro forma adjustments described above have been tax affected using the company's effective rate during the respective periods.

[0001437749-17-003344:notes:247]
The historical PolySwitch and ON Portfolio business results for the years ended 
 December

[0001437749-17-003344:notes:248]
2016
 do not include a provision for income taxes. Income tax expense for the historical PolySwitch business was only provided at the end of the business’s fiscal year ended 
 September

[0001437749-17-003344:notes:249]
2015.
 Income tax expense for the historical ON Portfolio business was not provided on a standalone basis.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-17-003344:notes:250]
Recently Issued Accounting Standards

[0001437749-17-003344:notes:251]
In 
 May

[0001437749-17-003344:notes:252]
2014,
 the FASB issued ASU No. 
2014
-
09,
 "Revenue from Contracts with Customers" (Topic 
606)
 which supersedes the revenue recognition requirements in ASC 
605,
 "Revenue Recognition." This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August,

[0001437749-17-003344:notes:253]
2015,
 the FASB issued ASU No. 
2015
-
14,
 which postponed the effective date of ASU No. 
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December

[0001437749-17-003344:notes:254]
2017,
 with early adoption permitted on the original effective date of fiscal years beginning after 
 December

[0001437749-17-003344:notes:255]
2016.
 The company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements and has not concluded on its adoption methodology. While the company is currently assessing the impact of the new standards, the company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The company does not expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may
 be affected. The company has not yet quantified this potential impact.

[0001437749-17-003344:notes:256]
In 
 February

[0001437749-17-003344:notes:257]
2016,
 the FASB issued ASU No. 
2016
-
02,
 "Leases" (Topic 
842).
 This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December

[0001437749-17-003344:notes:258]
2018,
 with early adoption permitted. Adoption will require a modified retrospective transition. The company is currently evaluating the impact of this ASU on its consolidated financial statements.

[0001437749-17-003344:notes:259]
In 
 January

[0001437749-17-003344:notes:260]
2017,
 the FASB issued ASU No. 
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350).
 This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity no longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December

[0001437749-17-003344:notes:261]
2020,
 with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-17-003344:notes:262]
10

[0001437749-17-003344:notes:263]
. Benefit Plans

[0001437749-17-003344:notes:264]
The company has company-sponsored defined benefit pension plans covering employees in the U.K., Germany, the Philippines, China, Japan, and France. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0001437749-17-003344:notes:265]
PolySwitch Acquisition

[0001437749-17-003344:notes:266]
During 
2016,
 as a result of the PolySwitch acquisition, past service liabilities were assumed by the company in China, France, Germany, Japan, Mexico, and Taiwan, together with a small amount of plan assets in Taiwan.

[0001437749-17-003344:notes:267]
Littelfuse Inc. Retirement Plan Termination

[0001437749-17-003344:notes:268]
The company received approval from the IRS on 
 April

[0001437749-17-003344:notes:269]
14,

[0001437749-17-003344:notes:270]
2015
 on its Application for Determination for Terminating Plan to terminate the U.S. defined benefit pension plan, the Littelfuse Inc. Retirement Plan, effective 
 July

[0001437749-17-003344:notes:271]
2014.
 All plan liabilities were settled (either via lump sum payout or purchase of a group annuity contract) in the 
third
 quarter of 
2015.
 A cash contribution of 
$9.1
 million was made to the U.S. defined benefit plan’s trust in the 
third
 quarter of 
2015
 to fully fund the plan on a buyout basis, and the eventual settlement of the plan’s liabilities triggered a settlement charge of 
$30.2
 million in the 
third
 quarter of 
2015.
 In the 
fourth
 quarter of 
2015
 there was an adjustment to the price of the annuity contract which resulted in a refund of premium to the company of 
$0.3
 million. This refund of premium, effectively a re-measurement gain, was recognized in the 
fourth
 quarter of 
2015
 as a dollar-for-dollar adjustment to the 
$30.2
 million earnings charge recognized in the 
third
 quarter of 
2015,
 resulting in a final settlement loss of 
$29.9
 million for the fiscal year ended 
 January

[0001437749-17-003344:notes:272]
During 
2016,
 there were 
two
 further adjustments to the price of the annuity contract. Their combined effect resulted in a further refund of premium to the company of 
$0.3
 million. This refund of premium was considered additional actual return on the assets during 
2016,
 followed by a negative employer contribution of that same amount in the asset reconciliation table below.

[0001437749-17-003344:notes:273]
Total pension expense was 
$1.5
 million, 
$32.4
 million, and 
$0.3
 million in 
2016,

[0001437749-17-003344:notes:274]
2015,
 and 
2014,
 respectively. The changes in pension expense primarily resulted from the termination and settlement of the U.S. plan, together with the effect of the PolySwitch acquisition.

[0001437749-17-003344:notes:275]
Benefit plan related information is as follows:

[0001437749-17-003344:notes:276]
|  |  | 2016 |  |  | 2015 |  |
| (in thousands) |  | U.S. |  |  | Foreign |  |  | Total |  |  | U.S. |  |  | Foreign |  |  | Total |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year |  | $ | — |  |  | $ | 50,282 |  |  | $ | 50,282 |  |  | $ | 105,759 |  |  | $ | 52,740 |  |  | $ | 158,499 |  |
| Service cost |  |  | — |  |  |  | 1,509 |  |  |  | 1,509 |  |  |  | 750 |  |  |  | 824 |  |  |  | 1,574 |  |
| Interest cost |  |  | — |  |  |  | 1,662 |  |  |  | 1,662 |  |  |  | 3,093 |  |  |  | 1,735 |  |  |  | 4,828 |  |
| Net actuarial loss (gain) |  |  | — |  |  |  | 10,190 |  |  |  | 10,190 |  |  |  | (9,127 | ) |  |  | 648 |  |  |  | (8,479 | ) |
| Benefits paid from the trust |  |  | — |  |  |  | (2,329 | ) |  |  | (2,329 | ) |  |  | (100,475 | ) |  |  | (1,732 | ) |  |  | (102,207 | ) |
| Benefits paid directly by company |  |  | — |  |  |  | 250 |  |  |  | 250 |  |  |  | — |  |  |  | (410 | ) |  |  | (410 | ) |
| Curtailments and settlements |  |  | — |  |  |  | (427 | ) |  |  | (427 | ) |  |  | — |  |  |  | (294 | ) |  |  | (294 | ) |
| Acquisitions |  |  | — |  |  |  | 2,023 |  |  |  | 2,023 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Effect of exchange rate movements |  |  | — |  |  |  | (7,554 | ) |  |  | (7,554 | ) |  |  | — |  |  |  | (3,229 | ) |  |  | (3,229 | ) |
| Benefit obligation at end of year |  | $ | — |  |  | $ | 55,606 |  |  | $ | 55,606 |  |  | $ | — |  |  | $ | 50,282 |  |  | $ | 50,282 |  |
| Change in plan assets at fair value: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year |  | $ | — |  |  | $ | 44,629 |  |  | $ | 44,629 |  |  | $ | 93,991 |  |  | $ | 47,593 |  |  | $ | 141,584 |  |
| Actual return on plan assets |  |  | 341 |  |  |  | 6,588 |  |  |  | 6,929 |  |  |  | (2,375 | ) |  |  | 389 |  |  |  | (1,986 | ) |
| Employer contributions |  |  | (341 | ) |  |  | 215 |  |  |  | (126 | ) |  |  | 8,859 |  |  |  | 1,072 |  |  |  | 9,931 |  |
| Benefits paid |  |  | — |  |  |  | (2,329 | ) |  |  | (2,329 | ) |  |  | (100,475 | ) |  |  | (1,732 | ) |  |  | (102,207 | ) |
| Acquisitions |  |  | — |  |  |  | 24 |  |  |  | 24 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Effect of exchange rate movements |  |  | — |  |  |  | (6,919 | ) |  |  | (6,919 | ) |  |  | — |  |  |  | (2,693 | ) |  |  | (2,693 | ) |
| Fair value of plan assets at end of year |  |  | — |  |  |  | 42,208 |  |  |  | 42,208 |  |  |  | — |  |  |  | 44,629 |  |  |  | 44,629 |  |
| Net amount recognized/(unfunded status) |  | $ | — |  |  | $ | (13,398 | ) |  | $ | (13,398 | ) |  | $ | — |  |  | $ | (5,653 | ) |  | $ | (5,653 | ) |
| Amounts recognized in the Consolidated Balance Sheet consist of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of accrued benefit liability |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Accrued benefit liability |  |  | — |  |  |  | (13,398 | ) |  |  | (13,398 | ) |  |  | — |  |  |  | (5,653 | ) |  |  | (5,653 | ) |
| Total liability recognized |  |  | — |  |  |  | (13,398 | ) |  |  | (13,398 | ) |  |  | — |  |  |  | (5,653 | ) |  |  | (5,653 | ) |
| Accumulated other comprehensive loss |  | $ | — |  |  | $ | 13,107 |  |  | $ | 13,107 |  |  | $ | — |  |  | $ | 9,383 |  |  | $ | 9,383 |  |

[0001437749-17-003344:notes:277]
Amounts recognized in accumulated other comprehensive income (loss), pre-tax consist of:

[0001437749-17-003344:notes:278]
|  |  | 2016 |  |  | 2015 |  |
| (in thousands) |  | U.S. |  |  | Foreign |  |  | Total |  |  | U.S. |  |  | Foreign |  |  | Total |  |
| Net actuarial loss |  | $ | — |  |  | $ | 13,107 |  |  | $ | 13,107 |  |  | $ | — |  |  | $ | 9,383 |  |  | $ | 9,383 |  |
| Prior service (cost) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net amount recognized /occurring, pre-tax |  | $ | — |  |  | $ | 13,107 |  |  | $ | 13,107 |  |  | $ | — |  |  | $ | 9,383 |  |  | $ | 9,383 |  |

[0001437749-17-003344:notes:279]
The estimated net actuarial loss (gain) which will be amortized from accumulated other comprehensive income (loss) into benefit cost in 
2017
 is

[0001437749-17-003344:notes:280]
approximately 
$0.3
 million.

[0001437749-17-003344:notes:281]
The components of total pension expense (income) for the years 
2016,

[0001437749-17-003344:notes:282]
2015,
 and 
2014
 are as follows:

[0001437749-17-003344:notes:283]
|  |  | U.S. |  |  | Foreign |  |
| (in thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | — |  |  | $ | 750 |  |  | $ | 600 |  |  | $ | 1,509 |  |  | $ | 824 |  |  | $ | 925 |  |
| Interest cost |  |  | — |  |  |  | 3,093 |  |  |  | 3,884 |  |  |  | 1,662 |  |  |  | 1,735 |  |  |  | 2,060 |  |
| Expected return on plan assets |  |  | — |  |  |  | (2,749 | ) |  |  | (5,646 | ) |  |  | (1,935 | ) |  |  | (2,346 | ) |  |  | (2,292 | ) |
| Amortization of prior service (credit) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Amortization of losses |  |  | — |  |  |  | 870 |  |  |  | 549 |  |  |  | 306 |  |  |  | 221 |  |  |  | 216 |  |
| Total cost (credit) of the plan for the year |  |  | — |  |  |  | 1,964 |  |  |  | (613 | ) |  |  | 1,542 |  |  |  | 434 |  |  |  | 909 |  |
| Expected plan participants’ contributions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net periodic benefit cost (credit) |  |  | — |  |  |  | 1,964 |  |  |  | (613 | ) |  |  | 1,542 |  |  |  | 434 |  |  |  | 909 |  |
| Curtailment/Settlement loss (gain) |  |  | — |  |  |  | 29,928 |  |  |  | — |  |  |  | (36 | ) |  |  | — |  |  |  | — |  |
| Total expense (income) for the year |  | $ | — |  |  | $ | 31,892 |  |  | $ | (613 | ) |  | $ | 1,506 |  |  | $ | 434 |  |  | $ | 909 |  |

[0001437749-17-003344:notes:284]
Weighted average assumptions used to determine net periodic benefit cost for the years 
2016,

[0001437749-17-003344:notes:285]
|  |  | U.S. |  |  | Foreign |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Discount rate |  |  | — |  |  |  | 3.9 | % |  |  | 4.8 | % |  |  | 3.7 | % |  |  | 3.7 | % |  |  | 3.7 | % |
| Expected return on plan assets |  |  | — |  |  |  | 6.8 | % |  |  | 6.8 | % |  |  | 4.9 | % |  |  | 5.1 | % |  |  | 4.9 | % |
| Compensation increase rate |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.3 | % |  |  | 5.3 | % |  |  | 3.8 | % |
| Measurement dates |  |  | — |  |  |  | 12/31/14 |  |  |  | 12/31/13 |  |  |  | 12/31/15 |  |  |  | 12/31/14 |  |  |  | 12/31/13 |  |

[0001437749-17-003344:notes:286]
The accumulated benefit obligation for the foreign plans was 
$51.3
 million and 
$46.2
 million at 
 December

[0001437749-17-003344:notes:287]
2016,
 respectively.

[0001437749-17-003344:notes:288]
Weighted average assumptions used to determine benefit obligations at year-end 
2016,

[0001437749-17-003344:notes:289]
2015
 and 
2014
 are as follows:

[0001437749-17-003344:notes:290]
|  |  | U.S. |  |  | Foreign |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Discount rate |  |  | — |  |  |  | 3.9 | % |  |  | 3.9 | % |  |  | 2.6 | % |  |  | 3.8 | % |  |  | 3.7 | % |
| Compensation increase rate |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4.5 | % |  |  | 6.2 | % |  |  | 5.3 | % |
| Measurement dates |  |  | — |  |  |  | 9/30/15 |  |  |  | 12/31/14 |  |  |  | 12/31/16 |  |  |  | 12/31/15 |  |  |  | 12/31/14 |  |

[0001437749-17-003344:notes:291]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows:

[0001437749-17-003344:notes:292]
| (in thousands) |  | Expected Benefit Payments (Foreign) |  |
| 2017 |  | $ | 1,906 |  |
| 2018 |  |  | 1,961 |  |
| 2019 |  |  | 2,040 |  |
| 2020 |  |  | 2,165 |  |
| 2021 |  |  | 2,207 |  |
| 2022-2026 |  |  | 12,789 |  |

[0001437749-17-003344:notes:293]
Defined Benefit Plan Assets

[0001437749-17-003344:notes:294]
Based upon analysis of the target asset allocation and historical returns by type of investment, the company has assumed that the expected long-term rate of return will be 
4.9%
 on foreign plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0001437749-17-003344:notes:295]
|  |  | Foreign Asset Allocation |  |
|  |  | 2016 |  |  | 2015 |  |
| Equity securities |  |  | 32 | % |  |  | 30 | % |
| Debt securities |  |  | 65 | % |  |  | 65 | % |
| Cash |  |  | 3 | % |  |  | 5 | % |
|  |  |  | 100 | % |  |  | 100 | % |

[0001437749-17-003344:notes:296]
The following table presents the company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of 
 December

[0001437749-17-003344:notes:297]
The following table presents the company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of 
 January

[0001437749-17-003344:notes:298]
Defined Contribution Plans

[0001437749-17-003344:notes:299]
The company also maintains a 
401(k)
 savings plan covering substantially all U.S. employees. The company matches 
100%
 of the employee’s annual contributions for the 
first

[0001437749-17-003344:notes:300]
4%
 of the employee’s eligible compensation. Employees are immediately vested in their contributions plus actual earnings thereon, as well as the company contributions. Company matching contributions amounted to 
$3.2
 million, 
$2.8
 million, and 
$2.1
 million in 
2016,

[0001437749-17-003344:notes:301]
The company has a non-qualified Supplemental Retirement and Savings Plan. The company provides additional retirement benefits for certain management employees and named executive officers by allowing participants to contribute up to 
90%
 of their annual compensation with matching contributions of 
4%
 of the participant’s annual compensation in excess of the IRS compensation limits.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001437749-17-003344:notes:302]
Property, Plant

[0001437749-17-003344:notes:303]
,

[0001437749-17-003344:notes:304]
and Equipment

[0001437749-17-003344:notes:305]
Land, buildings, and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of 
21
 years for buildings, 
seven
 to 
nine
 years for equipment, 
seven
 years for furniture and fixtures, 
five
 years for tooling and 
three
 years for computer equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-17-003344:notes:306]
15.
 Selected Quarterly Financial Data (Unaudited)

[0001437749-17-003344:notes:307]
The quarterly periods for 
2016
 are for the 
13
-weeks ended 
 December

[0001437749-17-003344:notes:308]
October

[0001437749-17-003344:notes:309]
July

[0001437749-17-003344:notes:310]
2016,
 and 
 April

[0001437749-17-003344:notes:311]
2016,
 respectively. The quarterly periods listed in the table below for 
2015
 are for the 
14
-weeks ended 
 January

[0001437749-17-003344:notes:312]
2016
 and the 
13
-weeks ended 
 September

[0001437749-17-003344:notes:313]
26,

[0001437749-17-003344:notes:314]
2015,

[0001437749-17-003344:notes:315]
June

[0001437749-17-003344:notes:316]
2015,
 and 
 March

[0001437749-17-003344:notes:317]
2015,
 respectively.

[0001437749-17-003344:notes:318]
(

[0001437749-17-003344:notes:319]
i

[0001437749-17-003344:notes:320]
n thousands, except per share data)

[0001437749-17-003344:notes:321]
|  |  | 2016 |  |  | 2015 |  |
|  |  | 4Q(a) |  |  | 3Q(b) |  |  | 2Q(c) |  |  | 1Q(d) |  |  | 4Q(e) |  |  | 3Q(f) |  |  | 2Q(g) |  |  | 1Q(h) |  |
| Net sales |  | $ | 284,518 |  |  | $ | 280,331 |  |  | $ | 271,912 |  |  | $ | 219,398 |  |  | $ | 220,020 |  |  | $ | 215,510 |  |  | $ | 222,021 |  |  | $ | 210,313 |  |
| Gross profit |  |  | 114,337 |  |  |  | 113,759 |  |  |  | 97,866 |  |  |  | 87,155 |  |  |  | 82,706 |  |  |  | 86,182 |  |  |  | 85,281 |  |  |  | 76,330 |  |
| Operating income |  |  | 40,988 |  |  |  | 27,526 |  |  |  | 29,702 |  |  |  | 32,428 |  |  |  | 29,854 |  |  |  | 8,584 |  |  |  | 36,171 |  |  |  | 29,548 |  |
| Net income |  |  | 27,245 |  |  |  | 30,802 |  |  |  | 27,152 |  |  |  | 19,289 |  |  |  | 22,863 |  |  |  | 11,324 |  |  |  | 28,684 |  |  |  | 19,995 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.20 |  |  | $ | 1.36 |  |  | $ | 1.21 |  |  | $ | 0.86 |  |  | $ | 0.93 |  |  | $ | 0.50 |  |  | $ | 1.26 |  |  | $ | 0.88 |  |
| Diluted |  | $ | 1.19 |  |  | $ | 1.35 |  |  | $ | 1.20 |  |  | $ | 0.85 |  |  | $ | 0.92 |  |  | $ | 0.50 |  |  | $ | 1.26 |  |  | $ | 0.88 |  |

[0001437749-17-003344:notes:322]
| (a) | In the fourth quarter of 2016, the company recorded ($0.1) million gain related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, $1.2 million of restructuring costs, $3.2 million in acquisition and integration costs and $0.3 million in non-cash inventory charges related to the 2016 acquisitions. |

[0001437749-17-003344:notes:323]
| (b) | In the third quarter of 2016, the company recorded $0.9 million of restructuring costs, $5.9 million in acquisition and integration costs, $14.8 million of charges related to the impairment of the custom products reporting unit and $0.5 million in non-cash inventory charges as noted above. |

[0001437749-17-003344:notes:324]
| (c) | In the second quarter of 2016, the company recorded $0.7 million related to the reed sensor manufacturing transfer as noted above, $0.1 million of restructuring costs, $6.1 million in acquisition and integration costs, $0.3 million in charges related to the closure of the manufacturing facility in Denmark and $6.9 million in non-cash inventory charges as noted above. |

[0001437749-17-003344:notes:325]
| (d) | In the first quarter of 2016, the company recorded $1.0 million related to the reed sensor manufacturing transfer as noted above, $0.4 million of restructuring costs, $6.2 million in acquisition and integration costs, and $1.6 million in charges related to the closure of the manufacturing facility in Denmark. |

[0001437749-17-003344:notes:326]
| (e) | In the fourth quarter of 2015, the company recorded $2.1 million related to the company’s transfer of its reed switch manufacturing operations from the U.S. and China to the Philippines, ($0.1) million related to the reorganization of its internal legal structure, $4.0 million in acquisition costs, ($0.3) million in pension settlement refunds (See Note 10) and ($0.3) million in other. |

[0001437749-17-003344:notes:327]
| (f) | In the third quarter of 2015, the company recorded $1.2 million related to the reed switch manufacturing transfer as noted above, $0.9 million related to the company’s reorganization of its internal legal structure as noted above, $0.3 million in acquisition costs, $30.8 million in pension settlement and wind-up costs (See Note 10) and $0.1 million in other. |

[0001437749-17-003344:notes:328]
| (g) | In the second quarter of 2015, the company recorded $0.9 million related to the reed switch manufacturing transfer as noted above, $1.7 million related to the company’s reorganization of its internal legal structure as noted above, $0.2 million in acquisition costs, and $0.7 million in pension wind-up costs. |

[0001437749-17-003344:notes:329]
| (h) | In the first quarter of 2015, the company recorded $1.0 million related to the reed switch manufacturing transfer as noted above, $1.2 million in charges related to the reorganization of its internal legal structure as noted above, $0.2 million in acquisition costs, and $0.7 million in pension wind-up costs. |


## us-gaap:ReceivablesPolicyTextBlock

[0001437749-17-003344:notes:330]
Accounts Receivable

[0001437749-17-003344:notes:331]
The company performs credit evaluations of customers’ financial condition and generally does not require collateral. Credit losses are provided for in the financial statements based upon specific knowledge of a customer’s inability to meet its financial obligations to the company. Historically, credit losses have consistently been within management’s expectations and have not been a material amount. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0001437749-17-003344:notes:332]
The company also maintains allowances against accounts receivable for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-17-003344:notes:333]
Revenue Recognition

[0001437749-17-003344:notes:334]
The company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured, and the pricing is fixed and determinable.

[0001437749-17-003344:notes:335]
At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The company’s distribution channels are primarily through direct sales and independent 
third
 party distributors.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001437749-17-003344:notes:336]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments (a) |  |  | Gain on investments |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 27, 2014 |  | $ | (29,615 | ) |  | $ | 10,791 |  |  | $ | (2,302 | ) |  | $ | (21,126 | ) |
| 2015 activity |  |  | 20,893 |  |  |  | 793 |  |  |  | (46,231 | ) |  |  | (24,545 | ) |
| Balance at January 2, 2016 |  |  | (8,722 | ) |  |  | 11,584 |  |  |  | (48,533 | ) |  |  | (45,671 | ) |
| 2016 activity |  |  | (3,261 | ) |  |  | (815 | ) |  |  | (24,832 | ) |  |  | (28,908 | ) |
| Balance at December 31, 2016 |  | $ | (11,983 | ) |  | $ | 10,769 |  |  | $ | (73,365 | ) |  | $ | (74,579 | ) |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-17-003344:notes:337]
| (in thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 356,674 |  |  | $ | 344,305 |  |  | $ | 313,762 |  |
| China |  |  | 263,701 |  |  |  | 193,792 |  |  |  | 189,191 |  |
| Other countries |  |  | 435,784 |  |  |  | 329,767 |  |  |  | 349,042 |  |
| Total net sales |  | $ | 1,056,159 |  |  | $ | 867,864 |  |  | $ | 851,995 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 23,731 |  |  | $ | 23,965 |  |  | $ | 34,179 |  |
| China |  |  | 65,345 |  |  |  | 37,241 |  |  |  | 40,981 |  |
| Canada |  |  | 9,880 |  |  |  | 10,488 |  |  |  | 12,899 |  |
| Other countries |  |  | 118,219 |  |  |  | 90,874 |  |  |  | 70,581 |  |
| Total long-lived assets |  | $ | 217,175 |  |  | $ | 162,568 |  |  | $ | 158,640 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 4,694 |  |  | $ | 8,609 |  |  | $ | 9,134 |  |
| China |  |  | 13,181 |  |  |  | 9,710 |  |  |  | 7,265 |  |
| Canada |  |  | 177 |  |  |  | 506 |  |  |  | 555 |  |
| Other countries |  |  | 28,176 |  |  |  | 25,194 |  |  |  | 15,327 |  |
| Total additions to long-lived assets |  | $ | 46,228 |  |  | $ | 44,019 |  |  | $ | 32,281 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001437749-17-003344:notes:338]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
| Nonvested January 2, 2016 |  |  | 194,461 |  |  | $ | 89.32 |  |
| Granted |  |  | 115,121 |  |  |  | 117.79 |  |
| Vested |  |  | (93,742 | ) |  |  | 84.94 |  |
| Forfeited |  |  | (8,543 | ) |  |  | 93.85 |  |
| Nonvested December 31, 2016 |  |  | 207,297 |  |  |  | 106.92 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-003344:notes:339]
| (in thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 535,191 |  |  | $ | 405,497 |  |  | $ | 410,065 |  |
| Automotive |  |  | 415,200 |  |  |  | 339,957 |  |  |  | 325,415 |  |
| Industrial |  |  | 105,768 |  |  |  | 122,410 |  |  |  | 116,515 |  |
| Total net sales |  | $ | 1,056,159 |  |  | $ | 867,864 |  |  | $ | 851,995 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 29,141 |  |  | $ | 22,936 |  |  | $ | 22,177 |  |
| Automotive |  |  | 18,107 |  |  |  | 13,437 |  |  |  | 14,204 |  |
| Industrial |  |  | 5,889 |  |  |  | 5,268 |  |  |  | 5,494 |  |
| Total depreciation and amortization |  | $ | 53,137 |  |  | $ | 41,641 |  |  | $ | 41,875 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 117,088 |  |  | $ | 78,194 |  |  | $ | 86,981 |  |
| Automotive |  |  | 59,905 |  |  |  | 53,086 |  |  |  | 45,086 |  |
| Industrial |  |  | 3,615 |  |  |  | 18,094 |  |  |  | 10,674 |  |
| Other(a) |  |  | (49,964 | ) |  |  | (45,217 | ) |  |  | (8,911 | ) |
| Total operating income |  |  | 130,644 |  |  |  | 104,157 |  |  |  | 133,830 |  |
| Interest expense |  |  | 8,628 |  |  |  | 4,091 |  |  |  | 4,903 |  |
| Foreign exchange loss (gain) |  |  | 472 |  |  |  | (1,465 | ) |  |  | 3,925 |  |
| Other expense (income), net |  |  | (1,730 | ) |  |  | (5,417 | ) |  |  | (6,644 | ) |
| Income before income taxes |  | $ | 123,274 |  |  | $ | 106,948 |  |  | $ | 131,646 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001437749-17-003344:notes:340]
|  |  | Shares Under Option |  |  | Weighted Average Price |  |  | Weighted Average Remaining Contract Life (Years) |  |  | Aggregate Intrinsic Value (000’s) |  |
| Outstanding January 2, 2016 |  |  | 470,904 |  |  | $ | 80.53 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 123,435 |  |  |  | 120.15 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (229,319 | ) |  |  | 73.42 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (8,836 | ) |  |  | 87.86 |  |  |  |  |  |  |  |  |  |
| Outstanding December 31, 2016 |  |  | 356,184 |  |  |  | 98.65 |  |  |  | 5.0 |  |  | $ | 18,920 |  |
| Exercisable December 31, 2016 |  |  | 112,714 |  |  |  | 78.16 |  |  |  | 3.6 |  |  |  | 8,297 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001437749-17-003344:notes:341]
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Weighted average fair value of options granted |  | $ | 26.06 |  |  | $ | 21.99 |  |  | $ | 26.25 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 1.37 | % |  |  | 1.25 | % |  |  | 1.67 | % |
| Expected dividend yield |  |  | 0.97 | % |  |  | 1.04 | % |  |  | 0.93 | % |
| Expected stock price volatility |  |  | 26.0 | % |  |  | 28.0 | % |  |  | 33.0 | % |
| Expected life of options (years) |  |  | 4.6 |  |  |  | 4.6 |  |  |  | 4.6 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-17-003344:notes:342]
SCHEDULE II

[0001437749-17-003344:notes:343]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001437749-17-003344:notes:344]
| Description |  | Balance at Beginning of Year |  |  | Charged to Costs and Expenses (a) |  |  | Deductions (b) |  |  | Other (c) |  |  | Balance at End of Year |  |
| (in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 319 |  |  | $ | 1,769 |  |  | $ | (42 | ) |  | $ | 33 |  |  | $ | 2,079 |  |
| Reserves for sales discounts and allowances |  | $ | 17,168 |  |  | $ | 91,632 |  |  | $ | (90,837 | ) |  | $ | 5,862 |  |  | $ | 23,825 |  |
| Deferred tax valuation allowance |  | $ | 4,557 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,181 |  |  | $ | 6,738 |  |
| Year ended January 2, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 278 |  |  | $ | 164 |  |  | $ | 150 |  |  | $ | 27 |  |  | $ | 319 |  |
| Reserves for sales discounts and allowances |  | $ | 19,140 |  |  | $ | 81,335 |  |  | $ | 82,997 |  |  | $ | (310 | ) |  | $ | 17,168 |  |
| Deferred tax valuation allowance |  | $ | 4,557 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,557 |  |
| Year ended December 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 790 |  |  | $ | 130 |  |  | $ | 656 |  |  | $ | 14 |  |  | $ | 278 |  |
| Reserves for sales discounts and allowances |  | $ | 16,117 |  |  | $ | 85,825 |  |  | $ | 82,568 |  |  | $ | (234 | ) |  | $ | 19,140 |  |
| Deferred tax valuation allowance |  | $ | 6,250 |  |  | $ | — |  |  | $ | 1,693 |  |  | $ | — |  |  | $ | 4,557 |  |

[0001437749-17-003344:notes:345]
| (a) | Includes provision for doubtful accounts, sales returns and sales discounts granted to customers. |

[0001437749-17-003344:notes:346]
| (b) | Represents uncollectible accounts written off, net of recoveries and credits issued to customers and the write-off of certain deferred tax assets that previously had full valuation allowances. |

[0001437749-17-003344:notes:347]
| (c) | Represents business acquisitions, foreign subsidiary tax attributes and foreign currency translation adjustments. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-003344:notes:348]
14.
 Segment Information

[0001437749-17-003344:notes:349]
The company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it 
 may
 earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer (“CEO”).  The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0001437749-17-003344:notes:350]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the 
three
 operating segments.  The company does not report inter-segment revenue because the operating segments do not record it.  Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”.  Additionally, the company does not allocate interest and other income, interest expense, or taxes to operating segments.  These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments.  Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in 
one
 segment 
 may
 benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the company as a whole.

[0001437749-17-003344:notes:351]
|  | ● | Electronics Segment: Provides circuit protection components for overcurrent and overvoltage protection, as well as sensor components and modules to leading global manufacturers of a wide range of electronic products. The segment covers a broad range of end markets, including consumer electronics, telecommunications equipment, medical devices, lighting products, and white goods. The Electronics segment supplies circuit protection, sensing and control products to various leading manufacturers. The Electronics segment has one of the broadest product offerings in the industry including fuses and protectors, positive temperature coefficient (“PTC”) resettable fuses, varistors, polymer electrostatic discharge (“ESD”) suppressors, discrete TVS diodes, TVS diode arrays protection and switching thyristors, gas discharge tubes, power switching components, fuseholders, reed switch and sensor assemblies, IGBT blocks, and related accessories. |

[0001437749-17-003344:notes:352]
|  | ● | Automotive Segment: Provides circuit protection and sensor products to the worldwide automotive original equipment manufacturers (“OEM”) and parts distributors of passenger automobiles, trucks, buses, and off-road equipment. In addition, the company supplies heavy duty power distribution modules, switches and relays to the commercial vehicle industry. The company also sells its fuses, including blade fuses and high current fuses, battery cable protectors, and varistors, in the automotive replacement parts market. The company also supplies wiring harness manufacturers and auto parts suppliers worldwide. |

[0001437749-17-003344:notes:353]
|  | ● | Industrial Segment: Provides circuit protection products for industrial and commercial customers. Products include power fuses and other circuit protection devices, including protection and time delay relays, which are used in commercial and industrial buildings and large equipment such as HVAC systems, elevators, and machine tools. The company also supplies industrial ground fault protection in mining and other large industrial operations. |

[0001437749-17-003344:notes:354]
The company has provided this segment information for all comparable prior periods.

[0001437749-17-003344:notes:355]
Segment information is summarized as follows:

[0001437749-17-003344:notes:356]
(a) Included in “Other” Operating income (loss) for 
2016
 are costs related to the impairment of the custom products reporting unit 
($14.8
 million), acquisition and integration costs associated with the company’s 
2016
 acquisitions 
($29.2
 million in Cost of sales (“COS”) and SG&A), transfer of the company’s reed switch manufacturing operations from its Lake Mills, Wisconsin and Suzhou, China locations to the Philippines 
($1.6
 million in COS), impairment and severance costs related to the closure of the company’s manufacturing facility in Denmark 
($1.9
 million in SG&A), and restructuring costs 
($2.5
 million in SG&A and R&D).

[0001437749-17-003344:notes:357]
Included in “Other” Operating income (loss) for 
2015
 are costs related to the transfer of the company’s reed switch manufacturing operations from its Lake Mills, Wisconsin and Suzhou, China locations to the Philippines 
($5.2
 million in COS), acquisition related fees 
($4.6
 million included in SG&A), pension settlement and other costs 
($31.9
 million in SG&A), and restructuring costs 
($3.6
 million in SG&A).

[0001437749-17-003344:notes:358]
Included in “Other” Operating income (loss) for 
2014
 are acquisition related fees 
($0.4
 million included in SG&A), non-cash charges for the sale of inventory that had been stepped-up to fair value at the acquisition date of SymCom 
($2.8
 million included in COS), severance charges 
($2.7
 million in COS and 
$0.5
 million in SG&A), restructuring costs 
($2.2
 million in SG&A) and asset impairments 
($0.2
 million in Research and development and 
$0.1
 million in SG&A).

[0001437749-17-003344:notes:359]
The company’s significant net sales, long-lived assets and additions to long-lived assets by country for the fiscal years ended 
2016,

[0001437749-17-003344:notes:360]
For the year ended 
 January

[0001437749-17-003344:notes:361]
2016,
 approximately 
66%
 of the company’s net sales were to customers outside the United States (exports and foreign operations) including 
25%
 to China. No single customer accounted for more than 
10%
 of net sales during the last 
three
 years.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001437749-17-003344:notes:362]
Shipping and Handling Fees and Costs

[0001437749-17-003344:notes:363]
Amounts billed to customers related to shipping and handling is classified as revenue. Costs incurred for shipping and handling of 
$9.1
 million 
$7.0
 million, and 
$6.7
 million in 
2016,

[0001437749-17-003344:notes:364]
2015,
 and 
2014,
 respectively, are classified in selling, general, and administrative expenses.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-17-003344:notes:365]
1.
 Summary of Significant Accounting Policies and Other Information

[0001437749-17-003344:notes:366]
Nature of Operations

[0001437749-17-003344:notes:367]
Littelfuse, Inc. and subsidiaries (the “company”) design, manufacture, and sell circuit protection devices for use in the automotive, electronics, and industrial markets throughout the world. The company is 
one
 of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.

[0001437749-17-003344:notes:368]
Fiscal Year

[0001437749-17-003344:notes:369]
References herein to 
“2016”,
 “fiscal 
2016”
 or “fiscal year 
2016”
 refer to the fiscal year ended 
 December

[0001437749-17-003344:notes:370]
2016.
 References herein to 
“2015”,
 “fiscal 
2015”
 or “fiscal year 
2015”
 refer to the fiscal year ended 
 January

[0001437749-17-003344:notes:371]
2016.
 References herein to 
“2014”,
 “fiscal 
2014”
 or “fiscal year 
2014”
 refer to the fiscal year ended 
 December

[0001437749-17-003344:notes:372]
2014.
 The company operates on a 
52
-
53
 week fiscal year 
(4
-
4
-
5
 basis) ending on the Saturday closest to 
 December

[0001437749-17-003344:notes:373]
31.
 Therefore, the financial results of certain fiscal years and the associated 
14
 week quarters will not be exactly comparable to the prior and subsequent 
52
 week fiscal years and the associated quarters having only 
13
 weeks. As a result of using this convention, each of fiscal 
2016
 and fiscal 
2014
 contained 
52
 weeks whereas fiscal 
2015
 contained 
53
 weeks.

[0001437749-17-003344:notes:374]
Use of Estimates

[0001437749-17-003344:notes:375]
The process of preparing financial statements in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The company evaluates and updates its assumptions and estimates on an ongoing basis and 
 may
 employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0001437749-17-003344:notes:376]
Investment

[0001437749-17-003344:notes:377]
s

[0001437749-17-003344:notes:378]
2016
 the company had investments in Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese publicly traded company and Monolith Semiconductor, Inc. (“Monolith”), a Texas-based startup company.

[0001437749-17-003344:notes:379]
Polytronics

[0001437749-17-003344:notes:380]
The company’s Polytronics shares held at the end of fiscal 
2016
 and 
2015
 represent approximately

[0001437749-17-003344:notes:381]
7.2%

[0001437749-17-003344:notes:382]
of total Polytronics shares outstanding. The Polytronics investment is classified as available-for-sale and is carried at fair value with the unrealized gains and losses reported as a component of “Accumulated Other Comprehensive Income (Loss).” The fair value of the Polytronics investment was 
€10.0
 million (approximately 
$10.4
 million) at 
 December

[0001437749-17-003344:notes:383]
2016
 and 
€10.7
 million (approximately 
$11.7
 million) at 
 January

[0001437749-17-003344:notes:384]
2016.
 Included in 
2016
 and 
2015,
 other comprehensive income is an unrealized loss of 
$0.8
 million and an unrealized gain of 
$0.9
 million, respectively, due to changes in fair market value of the Polytronics investment. The remaining movement year over year was due to the impact of changes in exchange rates.

[0001437749-17-003344:notes:385]
Monolith

[0001437749-17-003344:notes:386]
In 
 December

[0001437749-17-003344:notes:387]
2015,
 the company invested 
$3.5
 million in the preferred stock of Monolith, a U.S. start-up company developing silicon carbide technology, which represents approximately 
12%
 of the common stock of Monolith on an as-converted basis. The company accounts for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was

[0001437749-17-003344:notes:388]
$3.5

[0001437749-17-003344:notes:389]
million at 
 December

[0001437749-17-003344:notes:390]
Goodwill and Indefinite-Lived Intangible Assets

[0001437749-17-003344:notes:391]
The company annually tests goodwill and indefinite-lived intangible assets for impairment on the 
first
 day of its fiscal 
fourth
 quarter or at other dates if there is an event or change in circumstances that indicates the asset 
 may
 be impaired. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted 
five
-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after 
five
 years) to estimate market value. In addition, the company compares its derived enterprise value on a consolidated basis to the company’s market capitalization as of its test date to ensure its derived value approximates the market value of the company when taken as a whole.

[0001437749-17-003344:notes:392]
Due to negative events in the potash market in 
2016,
 management revisited its long term projections and conducted a step 
one
 goodwill impairment analysis for its custom products reporting unit in the 
third
 quarter of 
2016.
 The reporting unit failed the step 
one
 test and management conducted a step 
two
 analysis with the revised projections. The fair value of the unit was estimated using the expected present value of future cash flows over a 
seven
 year forecast period and appraisal of certain assets. As a result, the company recognized a charge for goodwill impairment of 
$8.8
 million as it wrote off the entire goodwill balance. In addition, the company recognized intangible assets impairments aggregating 
$6.0
 million, including a 
$3.8
 million reduction of the custom products trade names to a 
$0.7
 million remaining value and a 
$2.2
 million reduction of the reporting unit’s customer relationships to 
zero
 value.

[0001437749-17-003344:notes:393]
As of the most recent annual test conducted on 
 October

[0001437749-17-003344:notes:394]
2016,
 the company had 
seven
 reporting units for goodwill testing purposes and concluded the fair value of each of the reporting units exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. Specifically, the company noted that the excess of fair value over the carrying value of invested capital, was 
65%,

[0001437749-17-003344:notes:395]
154%,

[0001437749-17-003344:notes:396]
218%,

[0001437749-17-003344:notes:397]
132%,

[0001437749-17-003344:notes:398]
70%,

[0001437749-17-003344:notes:399]
15%,
 and 
150%
 for its reporting units; electronics (non-silicon), electronics (silicon), passenger car, commercial vehicle products, sensors, relays, and power fuse, respectively, at 
 October

[0001437749-17-003344:notes:400]
Certain key assumptions used in the annual test included a discount rate of 
9.8%
 and a long-term growth rate of 
3.0%
 which were used for all reporting units except for relays which had a discount rate of 
10.3%
 as a result of a 
0.5%
 premium factor.

[0001437749-17-003344:notes:401]
The company will continue to perform a goodwill and indefinite-lived intangible asset impairment test as required on an annual basis and on an interim basis, if certain impairment conditions exist. Factors the company considers important, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the company does not believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that we could recognize impairment charges for the relays reporting unit if we have declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment. As of the 
2016
 annual test date, the relays reporting unit had 
$41.4
 million of goodwill and intangible assets.

[0001437749-17-003344:notes:402]
Other Intangible Assets

[0001437749-17-003344:notes:403]
Customer relationships, trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of 
five
 to 
20
 years. Patents, licenses and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of 
five
 to 
17
 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of 
three
 to 
20
 years. Other intangible assets are also tested for impairment when there is a significant event that 
 may
 cause the asset to be impaired. As described above, in 
2016
 the company recognized an impairment charge of 
$2.2
 million to reduce the custom products reporting unit’s customer relationships to 
zero
 value.

[0001437749-17-003344:notes:404]
Environmental Liabilities

[0001437749-17-003344:notes:405]
Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the company’s recorded liability for such claims, the company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0001437749-17-003344:notes:406]
Pension and Other Post-retirement Benefits

[0001437749-17-003344:notes:407]
Accounting for pensions requires estimating the future benefit cost and recognizing the cost over the employee’s expected period of employment with the company. Certain assumptions are required in the calculation of pension costs and obligations. These assumptions include the discount rate, salary scales and the expected long-term rate of return on plan assets. The discount rate is intended to represent the rate at which pension benefit obligations could be settled by purchase of an annuity contract. These assumptions are subject to change based on stock and bond market returns and other economic factors. Actual results that differ from the company’s assumptions are accumulated and amortized over future periods and therefore generally affect its recognized expense and accrued liability in such future periods. While the company believes that its assumptions are appropriate given current economic conditions and its actual experience, significant differences in results or significant changes in the company’s assumptions 
 may
 materially affect its pension obligations and related future expense. During 
2015,
 the company terminated the U.S. defined benefit pension plan which resulted in a settlement of the plan’s liabilities resulting in a pre-tax charge of 
$29.9
 million. See Note 
10,

[0001437749-17-003344:notes:408]
Benefit Plans
, for additional information.

[0001437749-17-003344:notes:409]
Returns and Credits

[0001437749-17-003344:notes:410]
Some of the terms of the company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-17-003344:notes:411]
Volume Rebates

[0001437749-17-003344:notes:412]
The company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-17-003344:notes:413]
Allowance for Doubtful Accounts

[0001437749-17-003344:notes:414]
The company evaluates the collectability of its trade receivables based on a combination of factors. The company regularly analyzes its significant customer accounts and, when the company becomes aware of a specific customer’s inability to meet its financial obligations, the company records a specific reserve for bad debt to reduce the related receivable to the amount the company reasonably believes is collectible. The company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Accounts receivable balances that are deemed to be uncollectible, are written off against the reserve on a case-by-case basis. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted. However, due to the company’s diverse customer base and lack of credit concentration, the company does not believe its estimates would be materially impacted by changes in its assumptions.

[0001437749-17-003344:notes:415]
Stock-based Compensation

[0001437749-17-003344:notes:416]
The company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as both operating and financing cash flows. See Note 
11,

[0001437749-17-003344:notes:417]
Shareholders’ Equity
, for additional information on stock-based compensation.

[0001437749-17-003344:notes:418]
Reclassifications

[0001437749-17-003344:notes:419]
Certain amounts presented in the 
2015
 financial statements have been reclassified to conform to the 
2016
 presentation. In 
 April

[0001437749-17-003344:notes:420]
2015,
 the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 
2015
-
03,

[0001437749-17-003344:notes:421]
Interest - Imputation of Interest
 (Subtopic 
835
-
30):
 Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The amended guidance is effective for financial statements issued for fiscal years beginning after 
 December

[0001437749-17-003344:notes:422]
2015,
 including interim periods within those fiscal years. The amended guidance is to be applied on a retrospective basis. The company adopted the new guidance on 
 January

[0001437749-17-003344:notes:423]
3,

[0001437749-17-003344:notes:424]
2016
 and has made the corresponding reclassification on its balance sheet for the fiscal year ended 
 January

[0001437749-17-003344:notes:425]
2016.
 The adoption of the new guidance had no effect on the company’s net income, cash flows or shareholders’ equity. Additionally, the company has reclassified a portion of its current tax position at 
 January

[0001437749-17-003344:notes:426]
2016
 to more accurately reflect its prepaid/liability position at a jurisdictional level.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-17-003344:notes:427]
11.
 Shareholders’ Equity

[0001437749-17-003344:notes:428]
Equity Plans
: The company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, performance shares and other stock rights of employees and directors. As of 
 December

[0001437749-17-003344:notes:429]
2016,
 there were 
0.4
 million shares available for issuance of future awards under the company’s equity-based compensation plans.

[0001437749-17-003344:notes:430]
Stock options granted prior to 
2002
 vested over a 
five
-year period and are exercisable over a 
ten
-year period commencing from the date of vesting. The stock options granted in 
2002
 through 
 February

[0001437749-17-003344:notes:431]
2005
 vested over a 
five
-year period and are exercisable over a 
ten
-year period commencing from the date of the grant. Stock options granted after 
 February

[0001437749-17-003344:notes:432]
2005
 vest over a 
three,

[0001437749-17-003344:notes:433]
four
 or 
five
-year period and are exercisable over either a 
seven
 or 
ten
-year period commencing from the date of the grant. Restricted shares and share units granted by the company generally vest over 
three
 to 
four
 years.

[0001437749-17-003344:notes:434]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended 
 December

[0001437749-17-003344:notes:435]
The following table provides a reconciliation of non-vested restricted share and share unit awards for the fiscal year ended 
 December

[0001437749-17-003344:notes:436]
The total intrinsic value of options exercised during 
2016,

[0001437749-17-003344:notes:437]
2015,
 and 
2014
 was 
$13.3
 million, 
$5.0
 million, and 
$9.6
 million, respectively. The total fair value of shares vested was 
$10.7
 million, 
$8.1
 million, and 
$7.6
 million for 
2016,

[0001437749-17-003344:notes:438]
2015,
 and 
2014,
 respectively. The total amount of share-based liabilities paid was 
$0.6
 million, 
$0.4
 million and 
$0.3
 million for 
2016,

[0001437749-17-003344:notes:439]
The company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At 
 December

[0001437749-17-003344:notes:440]
2016,
 the unrecognized compensation cost for options, restricted shares and performance shares was 
$17.0
 million before tax, and will be recognized over a weighted-average period of 
1.9
 years. Compensation cost included as a component of selling, general, and administrative expense for all equity compensation plans discussed above was 
$12.8
 million, 
$10.7
 million, and 
$9.4
 million for 
2016,

[0001437749-17-003344:notes:441]
2015,
 and 
2014

[0001437749-17-003344:notes:442]
, respectively. The total income tax benefit recognized in the Consolidated Statements of Net Income was 
$4.4
 million, 
$3.7
 million and 
$3.3
 million for 
2016,

[0001437749-17-003344:notes:443]
, respectively.

[0001437749-17-003344:notes:444]
The company uses the Black-Scholes option valuation model to determine the fair value of awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0001437749-17-003344:notes:445]
Expected volatilities are based on the historical volatility of the company’s stock price. The expected life of options is based on historical data for options granted by the company. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption.

[0001437749-17-003344:notes:446]
Accumulated Other Comprehensive Income (Loss) (

[0001437749-17-003344:notes:447]
“

[0001437749-17-003344:notes:448]
AOCI

[0001437749-17-003344:notes:449]
”

[0001437749-17-003344:notes:450]
)
:

[0001437749-17-003344:notes:451]
The following table sets forth the changes in the components of AOCI by component for fiscal years 
2016,

[0001437749-17-003344:notes:452]
2015,
 and 
2014:

[0001437749-17-003344:notes:453]
(a) Net of tax of 
$1

[0001437749-17-003344:notes:454]
.1
 million, 
$0.7
 million

[0001437749-17-003344:notes:455]
, and $

[0001437749-17-003344:notes:456]
12.6
 million for 
2016,

[0001437749-17-003344:notes:457]
Preferred Stock
: The Board of Directors 
 may
 authorize the issuance of preferred stock from time to time in 
one
 or more series with such designations, preferences, qualifications, limitations, restrictions, and optional or other special rights as the Board 
 may
 fix by resolution.

[0001437749-17-003344:notes:458]
The company’s Board of Directors authorized the repurchase of up to 
1,000,000
 shares of the company’s common stock under a program for the period 
 May

[0001437749-17-003344:notes:459]
2016
 to 
 April

[0001437749-17-003344:notes:460]
2017.
 The company’s prior share repurchase authorization of 
1,000,000
 shares expired on 
 April

[0001437749-17-003344:notes:461]
2016
 with 
650,000
 shares remaining in the program. The company did not repurchase any shares of its common stock during fiscal 
2016
 under the either stock repurchase program. The company repurchased 
350,000
 of its shares in fiscal 
2015
 under the prior share repurchase program.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001437749-17-003344:notes:462]
4.
 Divestitures

[0001437749-17-003344:notes:463]
During the 
first
 quarter of 
2016,
 the company sold its tangible and intangible assets relating to a marine product line that it acquired as part of its acquisition of Selco A/S in 
2011.
 In connection with this sale, the company recorded a loss on sale of the product line of 
$1.4
 million reflected within selling, general, and administrative expenses for the year ended 
 December

[0001437749-17-003344:notes:464]
2016.
 This loss was recognized as an “other” charge for segment reporting purposes.
