# LFUS MD&A — 0001437749-17-003344


## mdna

[0001437749-17-003344:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001437749-17-003344:mdna:2]
Management’s Discussion and Analysis of Financial Condition and Results of Operations ("MD&A") is designed to provide information that is supplemental to, and should be read together with, our consolidated financial statements and the accompanying notes. Information in MD&A is intended to assist the reader in obtaining an understanding of (i) our consolidated financial statements, (ii) the changes in certain key items within those financial statements from year-to-year, (iii) the primary factors that contributed to those changes, and (iv) any changes in known trends or uncertainties that we are aware of and that may have a material effect on our future performance. In addition, MD&A provides information about our segments and how the results of those segments impact our results of operations and financial condition as a whole.

[0001437749-17-003344:mdna:3]
Executive Overview

[0001437749-17-003344:mdna:4]
Littelfuse is one of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensor and power control components and modules. In addition to circuit protection products and solutions, the company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The company’s devices protect products in virtually every market that uses electrical energy, from various electronic devices to automobiles to industrial equipment.

[0001437749-17-003344:mdna:5]
The company conducts its business through three reportable segments, which are defined by markets and consist of Electronics, Automotive, and Industrial. The company’s customer base includes OEMs, Tier One automotive suppliers, and distributors.

[0001437749-17-003344:mdna:6]
Executive Summary

[0001437749-17-003344:mdna:7]
We experienced strong performance improvements in 2016 including crossing the milestone of $1 billion in revenue and recognizing record earnings and cash flow. We made substantial progress in growth from our strategic 2016 acquisitions which contributed approximately $250 million in annualized revenue. We are well positioned for success with our updated strategy, which focuses on accelerated organic growth, while continuing to add acquisitions aligned to our core circuit protection, sensor, and power control platforms.

[0001437749-17-003344:mdna:8]
For 2016, we recognized net sales of $1,056.2 million, a 22% increase versus the prior year period. Acquisitions contributed significantly to the growth in revenue. Organic growth was due to growth in most end markets across our electronics segment as well as our automotive fuses and sensor business. This was partially offset by declines in our industrial segment and our commercial vehicle products business within our automotive segment.

[0001437749-17-003344:mdna:9]
We recognized Net Income of $104.5 million, an increase of 29.2%. Diluted EPS was $4.60, a 29.2% increase over last year.

[0001437749-17-003344:mdna:10]
Business Outlook and Key Trends & Events

[0001437749-17-003344:mdna:11]
We continually look for ways to improve the efficiency and performance of our operations. Certain trends have affected our results of operations for 2016 compared to 2015 and 2014. These trends, as well as the key trends that we expect will impact our future results of operations, are as follows.

[0001437749-17-003344:mdna:12]
| ● | Business Acquisitions – The company continues to review its existing product portfolio and looks for additional strategic acquisitions that complement existing product offerings or provide for further expansion of its portfolio. During 2016 and 2015, the company completed the following acquisitions: |

[0001437749-17-003344:mdna:13]
|  | ● | On August 29, 2016, the company acquired the ON portfolio for $104.0 million. The acquired business, which is included in the Electronics segment, consists of a product portfolio that includes TVS diodes, switching thyristors and IGBTs for automotive ignition applications. This transaction expands the company’s presence in each of these product categories. |

[0001437749-17-003344:mdna:14]
|  | ● | On April 4, 2016, the company acquired 100% of Menber’s for $19.2 million, net of cash acquired and after settlement of a working capital adjustment. Located in Legnago, Italy, Menber’s specializes in the design, manufacturing, and selling of manual and electrical battery switches and trailer connectors for commercial vehicles. The acquisition expands the company’s commercial vehicle platform globally. |

[0001437749-17-003344:mdna:15]
|  | ● | On March 25, 2016, the company acquired PolySwitch, the circuit protection business of TE Connectivity Ltd., for $348.3 million, net of cash acquired and after settlement of certain post-closing adjustments. PolySwitch has operations in Fremont, California and manufacturing facilities in Shanghai and Kunshan, China, and Tsukuba, Japan. The acquisition allows the company to strengthen its global circuit protection product portfolio, as well as strengthen its presence in the automotive electronics and battery end markets. The acquisition also significantly increases the company’s presence in Japan. |

[0001437749-17-003344:mdna:16]
|  | ● | On October 1, 2015, the company acquired 100% of Sigmar. The total purchase price for Sigmar was $6.5 million, net of cash acquired and including estimated additional net payments of up to $0.9 million, a portion of which is subject to the achievement of certain milestones. Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel and SCR quality sensors, as well as diesel fuel heaters, solenoid valves, and rotating oil filters for automotive and commercial vehicle applications. The acquisition further expands the company’s automotive sensor product line offerings. |

[0001437749-17-003344:mdna:17]
| ● | Financing – The company increased its already strong liquidity position during 2016. Cash flow from operations was $180.1 million for 2016, which was a 9% increase compared to the prior year. In March 2016, the company completed the refinancing of its credit facility, increasing capacity to $700 million with the potential for future increases of up to an additional $150 million and extending the maturity to March 2021. In December 2016, the company completed a private placement of approximately $350 million of senior notes denominated in both U.S. dollars and Euros, a portion of which was funded in December with the remaining funding occurring in February 2017. The senior notes range from five to twelve year maturities and have an average interest rate of approximately 2.25%. |

[0001437749-17-003344:mdna:18]
| ● | Asset Impairment – During 2016, the potash mining industry experienced a continued decline in market pricing. Due to this continuing decline in potash pricing, the custom products reporting unit recognized charges of $14.8 million to write down the reporting unit’s carrying value. The charges included a goodwill impairment loss of $8.8 million and intangible assets impairments aggregating $6.0 million, including a $3.8 million reduction of the custom products trade names to a $0.7 million remaining value and a $2.2 million reduction of the reporting unit’s customer relationships to zero value. |

[0001437749-17-003344:mdna:19]
| ● | Outlook – Sales for the first quarter of 2017 are expected to be in the range of $277 to $287 million which represents 29% revenue growth over the first quarter of 2016, at the midpoint of the range. |

[0001437749-17-003344:mdna:20]
Results of Operations — 2016 compared with 2015

[0001437749-17-003344:mdna:21]
The following table summarizes the company’s consolidated results of operations for periods presented. The fiscal year 2016 includes approximately $50.0 million of non-segment charges.  These included $14.8 million of charges related to the impairment of the custom products reporting unit, $21.4 million of acquisition and integration costs associated with the company’s 2016 acquisitions, primarily PolySwitch, $7.8 million of non-cash fair value step-up inventory charges relating to the company’s 2016 acquisitions, primarily PolySwitch, as described in Note 3, Acquisitions, of the Notes to Consolidated Financial Statements included in this Annual Report, $1.9 million in charges related to the closure of the company’s manufacturing facility in Denmark, $1.6 million related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, and $2.5 million related to restructuring costs.

[0001437749-17-003344:mdna:22]
19

[0001437749-17-003344:mdna:23]
Fiscal year 2015 includes approximately $45.2 million of other non-segment charges.  These included $5.2 million related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, $3.6 million related to restructuring, $4.6 million related to acquisition costs and $31.9 million of expense related to the planned termination of the U.S. pension as described in Note 10, Benefit Plans, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-17-003344:mdna:24]
Fiscal year 2016 also included approximately $0.5 million in foreign currency expenses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar, while fiscal year 2015 also included $1.5 million in foreign currency gains primarily attributable to changes in the value of both the euro and Philippine peso against the U.S. dollar.

[0001437749-17-003344:mdna:25]
|  |  | Fiscal Year |  |  |  |  |  |
| (in thousands, except % change) |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Sales |  | $ | 1,056,159 |  |  | $ | 867,864 |  |  |  | 22% |  |
| Gross profit |  |  | 413,117 |  |  |  | 330,499 |  |  |  | 25% |  |
| Operating expenses |  |  | 282,473 |  |  |  | 226,342 |  |  |  | 25% |  |
| Operating income |  |  | 130,644 |  |  |  | 104,157 |  |  |  | 25% |  |
| Other expense (income), net |  |  | (1,730 | ) |  |  | (5,417 | ) |  |  | (68%) |  |
| Income before income taxes |  |  | 123,274 |  |  |  | 106,948 |  |  |  | 15% |  |
| Income taxes |  |  | 18,786 |  |  |  | 26,082 |  |  |  | (28%) |  |
| Net income |  |  | 104,488 |  |  |  | 80,866 |  |  |  | 29% |  |

[0001437749-17-003344:mdna:26]
Sales

[0001437749-17-003344:mdna:27]
Net sales for 2016 of $1,056.2 million increased $188.3 million, or 22%, compared to the prior year, reflecting $170.2 million of incremental revenues from businesses acquired over the previous two years as well as organic growth in the Electronics and Automotive segments, partially offset by lower sales from the Industrial segment due to weaker end markets. The company also experienced $7.3 million in unfavorable foreign currency effects in 2016 compared to 2015 primarily resulting from sales denominated in Chinese renminbi.

[0001437749-17-003344:mdna:28]
The increase in sales in 2016 reflects a $75.2 million, or 22%, increase in Automotive segment sales and a $129.7 million, or 32%, increase in Electronics segment sales, partially offset by a $16.6 million, or 14%, decrease in Industrial segment sales.

[0001437749-17-003344:mdna:29]
Gross Profit

[0001437749-17-003344:mdna:30]
Gross profit was $413.1 million, or 39.1% of sales, in 2016, compared to $330.5 million, or 38.1% of sales, in 2015. Gross profit for 2016 was negatively impacted by $10.8 million of charges primarily related to the inventory step-up from the acquisition of PolySwitch and to a lesser extent the ON Portfolio and Menber’s acquisitions. Gross profit for 2015 was negatively impacted by $5.2 million of charges related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines.

[0001437749-17-003344:mdna:31]
Operating Expenses

[0001437749-17-003344:mdna:32]
Total operating expense was $282.5 million, or 26.7% of net sales, for 2016 compared to $226.3 million, or 26.1% of net sales, for 2015. Operating expense in 2016 included $39.1 million of charges primarily consisting of acquisition and integration costs of $21.4 million and $14.8 million of charges related to the impairment of the custom products reporting unit. Operating expense in 2015 included $39.9 million of charges, primarily related to the U.S. pension settlement of $31.9 million and restructuring and acquisition costs of $8.0 million.

[0001437749-17-003344:mdna:33]
Operating Income

[0001437749-17-003344:mdna:34]
Operating income was $130.6 million, or 12.4% of net sales, in 2016 compared to $104.2 million, or 12.0% of net sales, in the prior year. The increase in operating income in the current year was due primarily to higher revenue as well as the factors affecting operating expenses discussed above.

[0001437749-17-003344:mdna:35]
Interest expense was $8.6 million in 2016 compared to $4.1 million in 2015 and is primarily related to the company’s increased borrowing to fund acquisitions.

[0001437749-17-003344:mdna:36]
Foreign exchange (gain) loss was $0.5 million of loss in 2016 compared to $1.5 million of gain in 2015. The fluctuation in foreign exchange was primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar in 2016 and 2015.

[0001437749-17-003344:mdna:37]
Other Expense (Income), Net

[0001437749-17-003344:mdna:38]
Other expense (income), net, consisting of interest income, royalties and non-operating income was $1.7 million of income in 2016 compared to $5.4 million of income in 2015. The year-over-year decrease in income primarily reflects lower interest income in 2016.

[0001437749-17-003344:mdna:39]
Income Taxes

[0001437749-17-003344:mdna:40]
Income tax expense was $18.8 million with an effective tax rate of 15.2% in 2016 compared to income tax expense of $26.1 million with an effective tax rate of 24.4% in 2015. The effective tax rates for these periods are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions and, with respect to the 2016 period, a one-time deduction with respect to the stock of one of the company’s affiliates partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded and taxes on unremitted earnings, and, with respect to the 2015 period, the impact of a pension settlement partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations.

[0001437749-17-003344:mdna:41]
Segment Information

[0001437749-17-003344:mdna:42]
The company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 14, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-17-003344:mdna:43]
The following table is a summary of the company’s net sales by segment:

[0001437749-17-003344:mdna:44]
|  |  | Fiscal Year |  |  |  |  |  |
| (in millions) |  | 2016 |  |  | 2015 |  |  | Change |  |
| Electronics |  | $ | 535.2 |  |  | $ | 405.5 |  |  | $ | 129.7 |  |
| Automotive |  |  | 415.2 |  |  |  | 340.0 |  |  |  | 75.2 |  |
| Industrial |  |  | 105.8 |  |  |  | 122.4 |  |  |  | (16.6 | ) |
| Total |  | $ | 1,056.2 |  |  | $ | 867.9 |  |  | $ | 188.3 |  |

[0001437749-17-003344:mdna:45]
Electronics Segment

[0001437749-17-003344:mdna:46]
The Electronics segment, which accounted for approximately 51% of total sales in 2016, has produced modest organic revenue growth over the last few years. In 2016, sales increased $129.7 million, or 32%, compared to the prior year, reflecting $110.0 million of sales from businesses acquired in 2016 as well as organic growth in sensor products and to a lesser extent passive and semiconductor products. Operating margins also improved in 2016 compared to 2015 due to better leverage from the higher sales, as well as favorable product and regional mix.

[0001437749-17-003344:mdna:47]
Fourth quarter 2016 sales were unseasonably strong due to higher demand in some markets including electric vehicle, mobile phone charging and base stations, along with an earlier than usual Chinese New Year. The book-to-bill ratio of 1.05 at the end of the fourth quarter is primarily due to stronger than normal seasonal trends.

[0001437749-17-003344:mdna:48]
Automotive Segment

[0001437749-17-003344:mdna:49]
The Automotive segment, which accounted for approximately 39% of total sales in 2016, has been the company’s fastest growing business over the last few years. In 2016, sales increased $75.2 million, or 22%, compared to the prior year, reflecting $60.2 million of incremental sales from businesses acquired in 2016 and the fourth quarter of 2015 as well as organic growth related to sensor and passenger car products. These increases in sales were partially offset by lower sales of legacy commercial vehicle products, reflecting weakness in the North American heavy truck, construction, and agricultural end markets.

[0001437749-17-003344:mdna:50]
The segment realized growth in fuse content which was driven by more sophisticated electronics in vehicles and sales of our high-current products, especially the Masterfuse® line. Also contributing to segment performance was our automotive sensor business which experienced strong growth in sales and a significant improvement in margins. Sales in China were strong due to the Chinese government’s tax incentives for smaller cars driving higher growth in the China car industry.

[0001437749-17-003344:mdna:51]
Industrial Segment

[0001437749-17-003344:mdna:52]
The Industrial segment, which accounted for approximately 10% of total sales in 2016, experienced a sales decrease of 14% over the prior year with declines across all businesses. The company also divested certain non-core product lines during 2016. See Note 4, Divestitures, for additional information. The company’s power fuse business has benefited from a strong U.S. solar market in recent years; however, this market slowed in the second half of 2016. Sales in the protection relay business continued to be impacted by weakness in the heavy industrial and oil and gas markets, as those customers have restricted their capital spending. In the custom products business, the company continued to see a decline in the potash market, which has resulted in the aforementioned impairment charge in the third quarter of 2016. It is possible that we could recognize impairment charges for the relays reporting unit if we have declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment.

[0001437749-17-003344:mdna:53]
Geographic Sales Information

[0001437749-17-003344:mdna:54]
Sales by geography represent sales to customer or distributor locations. The following table is a summary of the company’s net sales by geography:

[0001437749-17-003344:mdna:55]
|  |  | Fiscal Year |  |  |  |  |  |
| (in millions) |  | 2016 |  |  | 2015 |  |  | Change |  |
| Americas |  | $ | 411.1 |  |  | $ | 401.2 |  |  | $ | 9.9 |  |
| Europe |  |  | 200.3 |  |  |  | 152.7 |  |  |  | 47.6 |  |
| Asia-Pacific |  |  | 444.8 |  |  |  | 314.0 |  |  |  | 130.8 |  |
| Total |  | $ | 1,056.2 |  |  | $ | 867.9 |  |  | $ | 188.3 |  |

[0001437749-17-003344:mdna:56]
Americas

[0001437749-17-003344:mdna:57]
Sales in the Americas increased $9.9 million, or 2%, in 2016 compared to 2015, primarily due to acquisitions and increased demand for Electronics products, partially offset by lower Industrial sales. Electronics sales increased $23.3 million, or 20%, primarily due to acquisitions as well as increased sales for passive and sensor products. Industrial sales decreased $14.0 million, or 13%, resulting from decreases in demand for power fuses, custom products, and relay products.

[0001437749-17-003344:mdna:58]
Europe

[0001437749-17-003344:mdna:59]
European sales increased $47.6 million, or 31%, in 2016 compared to 2015 primarily due to acquisitions and increased demand for Automotive and Electronics products, partially offset by lower Industrial sales. Automotive sales increased $26.8 million, or 27%, in 2016 primarily due to acquisitions and increased sales for sensor products. Electronics sales increased $22.4 million, or 46%, primarily due to acquisitions as well as increased sales for the passive and sensor products. Industrial sales decreased $1.5 million, or 24%, in 2016 primarily from lower sales of fuse and relay products.

[0001437749-17-003344:mdna:60]
Asia-Pacific

[0001437749-17-003344:mdna:61]
Asia-Pacific sales increased $130.8 million, or 42%, in 2016 compared to 2015, primarily due to acquisitions and increased demand for Automotive and Electronics products offset by lower Industrial sales. Excluding currency effects, Asia-Pacific sales increased $136.2 million, or 43%. Electronics sales increased $84.0 million, or 35%, primarily due to acquisitions as well as increased sales for passive and sensor products. Excluding currency effects, Electronics sales increased $86.3 million, or 36%. Automotive sales increased $47.8 million, or 72%, primarily due to acquisitions as well as increased sales for passenger car and sensor products, partially offset by net unfavorable currency effects. Excluding currency effects, Automotive sales increased $51.1 million, or 77%. Industrial sales decreased $1.2 million, or 13%.

[0001437749-17-003344:mdna:62]
Results of Operations — 2015 compared with 2014

[0001437749-17-003344:mdna:63]
The following table summarizes the company’s consolidated results of operations for the periods presented. The fiscal year 2015 includes approximately $45.2 million of other non-segment charges.  These included $4.6 million in acquisition-related costs primarily related to the transaction and integration planning costs for the PolySwitch acquisition, $5.2 million in charges related to the transfer of the company’s reed switch manufacturing operations from its Lake Mills, Wisconsin and Suzhou, China locations to the Philippines, $3.6 million in internal restructuring costs that will improve the company’s worldwide legal structure and $31.9 million in U.S. pension settlement and wind-up costs.

[0001437749-17-003344:mdna:64]
Fiscal year 2015 also included $1.5 million in foreign currency gains primarily attributable to changes in the value of both the euro and Philippine peso against the U.S. dollar while fiscal year 2014 included $3.9 million in foreign currency losses primarily related to the value of the Philippine peso against the U.S. dollar.

[0001437749-17-003344:mdna:65]
|  |  | Fiscal Year |  |  |  |  |  |
| (in thousands, except % change) |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Sales |  | $ | 867,864 |  |  | $ | 851,995 |  |  |  | 2% |  |
| Gross profit |  |  | 330,499 |  |  |  | 324,428 |  |  |  | 2% |  |
| Operating expenses |  |  | 226,342 |  |  |  | 190,598 |  |  |  | 19% |  |
| Operating income |  |  | 104,157 |  |  |  | 133,830 |  |  |  | (22%) |  |
| Other expense (income), net |  |  | (5,417 | ) |  |  | (6,644 | ) |  |  | (18%) |  |
| Income before income taxes |  |  | 106,948 |  |  |  | 131,646 |  |  |  | (19%) |  |
| Net income |  |  | 80,866 |  |  |  | 98,100 |  |  |  | (18%) |  |

[0001437749-17-003344:mdna:66]
Sales

[0001437749-17-003344:mdna:67]
Net sales increased $15.9 million, or 2%, to $867.9 million for 2015 compared to $852.0 million in 2014 due primarily to strong growth in the Automotive segment and improvement in the Industrial segment partially offset by lower sales in the Electronics segment. The company also experienced $38.9 million in unfavorable foreign currency effects in 2015 compared to 2014 primarily resulting from sales denominated in the euro. Excluding currency effects, net sales increased $54.7 million, or 6%, in 2015 compared to 2014.

[0001437749-17-003344:mdna:68]
The increase in sales in 2015 reflects a $14.5 million, or 4%, increase in Automotive segment sales and a $5.9 million, or 5%, increase in Industrial segment sales, partially offset by a $4.6 million, or 1%, decrease in Electronics segment sales.

[0001437749-17-003344:mdna:69]
Gross Profit

[0001437749-17-003344:mdna:70]
Gross profit was $330.5 million, or 38.1% of sales, in 2015, compared to $324.4 million, or 38.1% of sales, in 2014. Gross profit for 2015 was negatively impacted by $5.3 million of charges related to costs incurred to transfer of the company’s reed switch production from the U.S. and China to the Philippines. Gross profit for 2014 was negatively impacted by $2.8 million for accounting adjustments related to the SymCom inventory which had been stepped up to fair value at the acquisition date as required by purchase accounting rules. Additionally, 2014 gross profit was negatively impacted by $2.7 million in severance charges. These severance charges primarily related to post-Hamlin acquisition reorganization changes. Excluding the impact of these charges, gross profit was $335.8 million, or 38.7% of sales, in 2015 compared to $329.9 million, or 38.7% of sales, in 2014.

[0001437749-17-003344:mdna:71]
Operating Expenses

[0001437749-17-003344:mdna:72]
Total operating expense was $226.3 million, or 26.1% of net sales, for 2015 compared to $190.6 million, or 22.4% of net sales, for 2014. Operating expense in 2015 included $39.9 million of charges that primarily related to U.S. pension settlement and wind-up costs of $31.9 million and restructuring and acquisition costs of $8.0 million. Operating expense in 2014 included $3.5 million in restructuring, acquisition, and impairment costs, $2.2 million of which was to effect changes in the company’s legal structure. Excluding these charges, total operating expense was $186.4 million, or 21.5% of net sales, for 2015 compared to $187.1 million, or 22.0% of net sales, in 2014.

[0001437749-17-003344:mdna:73]
Operating Income

[0001437749-17-003344:mdna:74]
Operating income was $104.2 million, or 12.0% of net sales, in 2015 compared to $133.8 million, or 15.7% of net sales, in the prior year. The decrease in operating income in the current year was due primarily to the factors affecting operating expenses discussed above.

[0001437749-17-003344:mdna:75]
Interest expense was $4.1 million in 2015 compared to $4.9 million in 2014 and is primarily related to the company’s increased borrowings to fund acquisitions. The lower interest expense in 2015 resulted from lower average debt balances compared to the prior year.

[0001437749-17-003344:mdna:76]
Foreign exchange (gain) loss was $1.5 million of gain in 2015 compared to $3.9 million of loss in 2014. The fluctuation in foreign exchange was primarily attributable to changes in the value of both the euro and the Philippine peso against the U.S. dollar in 2015 and 2014.

[0001437749-17-003344:mdna:77]
Other Expense (Income), Net

[0001437749-17-003344:mdna:78]
Other expense (income), net, consisting of interest income, royalties, and non-operating income was $5.4 million of income in 2015 compared to $6.6 million of income in 2014. The year-over-year decrease in income primarily reflects lower interest income in 2015.

[0001437749-17-003344:mdna:79]
Income Taxes

[0001437749-17-003344:mdna:80]
Income tax expense was $26.1 million in 2015 compared to $33.5 million in 2014. The 2015 effective income tax rate was 24.4% compared to 25.5% in 2014. The lower effective tax rate in 2015 is primarily related to more income earned in lower-tax jurisdictions in 2015 compared to 2014 and the impact of a pension settlement, partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations.

[0001437749-17-003344:mdna:81]
Segment Information

[0001437749-17-003344:mdna:82]
The following table is a summary of the company’s net sales by segment:

[0001437749-17-003344:mdna:83]
|  |  | Fiscal Year |  |  |  |  |  |
| (in millions) |  | 2015 |  |  | 2014 |  |  | Change |  |
| Electronics |  | $ | 405.5 |  |  | $ | 410.1 |  |  | $ | (4.6 | ) |
| Automotive |  |  | 340.0 |  |  |  | 325.4 |  |  |  | 14.6 |  |
| Industrial |  |  | 122.4 |  |  |  | 116.5 |  |  |  | 5.9 |  |
| Total |  | $ | 867.9 |  |  | $ | 852.0 |  |  | $ | 15.9 |  |

[0001437749-17-003344:mdna:84]
Electronics Segment

[0001437749-17-003344:mdna:85]
The decrease in Electronics sales primarily resulted from net unfavorable currency effects of $11.7 million in 2015. Excluding currency effects, Electronics sales increased $7.2 million, or 2%, compared to 2014 reflecting solid growth for passive components offset by lower sensor sales. Strong sales of electronic products in Europe and China helped to offset continued adjustments in channel inventory and capacity constraints for our electronic sensor products as the company continues to transfer production from the U.S. and China to the Philippines.

[0001437749-17-003344:mdna:86]
Automotive Segment

[0001437749-17-003344:mdna:87]
The increase in Automotive sales was primarily due to strong growth for automotive sensor products. Sales in the commercial vehicle market were up slightly compared to 2014 as continued strength in the heavy truck market was offset by general market weakness in construction, agriculture, and the global mining industry. Automotive sales were negatively impacted by net unfavorable currency effects of $22.4 million in 2015 compared to 2014, primarily resulting from sales denominated in the euro. Excluding currency effects, Automotive sales increased $37.0 million, or 11% compared to 2014.

[0001437749-17-003344:mdna:88]
Industrial Segment

[0001437749-17-003344:mdna:89]
The increase in Industrial sales was primarily from higher custom and power fuse sales which were offset by lower relay sales. The Industrial segment experienced net unfavorable currency effects of $4.7 million, primarily from sales denominated in Canadian dollars and the euro. Excluding currency effects, Industrial sales increased $10.6 million, or 9%, compared to 2014. The increase in fuse sales is primarily due to continuing strength in the solar market, while higher custom product sales benefited from some recovery in the potash mining end market.

[0001437749-17-003344:mdna:90]
Geographic Sales Information

[0001437749-17-003344:mdna:91]
Sales by geography represent sales to customer or distributor locations. The following table is a summary of the company’s net sales by and geography:

[0001437749-17-003344:mdna:92]
|  |  | Fiscal Year |  |  |  |  |  |
| (in millions) |  | 2015 |  |  | 2014 |  |  | Change |  |
| Americas |  | $ | 401.2 |  |  | $ | 377.7 |  |  |  | 23.5 |  |
| Europe |  |  | 152.7 |  |  |  | 163.9 |  |  |  | (11.2 | ) |
| Asia-Pacific |  |  | 314.0 |  |  |  | 310.4 |  |  |  | 3.6 |  |
| Total |  | $ | 867.9 |  |  | $ | 852.0 |  |  |  | 15.9 |  |

[0001437749-17-003344:mdna:93]
Americas

[0001437749-17-003344:mdna:94]
Sales in the Americas increased $23.5 million, or 6%, in 2015 compared to 2014 due primarily to growth in all segments offset by $3.6 million in unfavorable currency effects resulting from sales denominated in Canadian dollars. Excluding currency effects, Americas sales increased $27.1 million, or 7%. Automotive sales increased $15.1 million, or 9% primarily reflecting strong growth in the automotive sensor and passenger vehicle markets. Electronics sales increased $3.2 million, or 3%, primarily reflecting higher demand for passive products. Industrial sales increased $5.2 million, or 5%, resulting from increases in demand for power fuses and custom products.

[0001437749-17-003344:mdna:95]
Europe

[0001437749-17-003344:mdna:96]
European sales decreased $11.3 million, or 7%, in 2015 compared to 2014 primarily due to net unfavorable currency effects of $32.8 million primarily from sales denominated in the euro. Excluding currency effects, European sales increased $21.5 million, or 13%, reflecting strong demand across all segments. Automotive sales decreased $6.9 million, or 7%, in 2015 reflecting net unfavorable currency effects. Excluding currency effects, Automotive sales increased $14.2 million, or 13%, reflecting strong demand for automotive sensor products. Electronics sales decreased $3.7 million, or 7%, reflecting the impact of net unfavorable currency effects. Excluding currency effects, Electronics sales increased $6.6 million, or 13%, reflecting strong demand for semiconductor products. Industrial sales decreased $0.7 million, or 10%, in 2015 primarily from the impact of net unfavorable currency effects. Excluding currency effects, Industrial sales increased $0.7 million, or 10%.

[0001437749-17-003344:mdna:97]
Asia-Pacific

[0001437749-17-003344:mdna:98]
Asia-Pacific sales increased $3.6 million, or 1%, in 2015 compared to 2014 primarily due to increased demand for Automotive and Industrial products offset by lower Electronics sales. Net unfavorable currency effects amounted to $2.5 million. Excluding currency effects, Asia-Pacific sales increased $6.1 million, or 2%. Electronics sales decreased $4.1 million, or 2%, reflecting weakness in the Taiwan, Japan, and Korea markets. Automotive sales increased $6.4 million, or 11%, reflecting continued increased demand for passenger vehicles in China as well as gains in market share. Industrial sales increased $1.4 million, or 19%.

[0001437749-17-003344:mdna:99]
Liquidity and Capital Resources

[0001437749-17-003344:mdna:100]
As of December 31, 2016, $266.7 million of the $275.1 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $266.7 million held by foreign subsidiaries, at least $50 million can be repatriated with minimal tax consequences, considering both U.S. and foreign taxes. Other than amounts which can be repatriated with minimal tax consequences, the company expects to maintain its foreign cash balances for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions and does not expect to repatriate these funds to the U.S.

[0001437749-17-003344:mdna:101]
The company has historically supported its liquidity needs through cash flows from operations. Management expects that the company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0001437749-17-003344:mdna:102]
Revolving Credit Facility/Term Loan

[0001437749-17-003344:mdna:103]
On March 4, 2016, the company entered into a new five-year credit agreement with a group of lenders for up to $700.0 million and terminated the company’s previous credit agreement. The new credit agreement consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. In addition, the company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the company is required to make quarterly principal payments of $1.6 million through March 31, 2018 and $3.1 million from June 30, 2018 through December 31, 2020 with the remaining balance due on March 4, 2021.

[0001437749-17-003344:mdna:104]
Outstanding borrowings under the credit agreement bear interest, at the company’s option, at either LIBOR, fixed for interest periods of one, two, three or six month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the company’s Consolidated Leverage Ratio, as defined. The company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.30%, based on the Consolidated Leverage Ratio, as defined. The effective interest rate on outstanding borrowings under the credit facility was 2.27% at December 31, 2016. As of December 31, 2016, the company had $0.1 million outstanding in letters of credit and had available $462.4 million of borrowing capacity under the revolving credit facility. Further information regarding the company’s credit agreement is provided in Note 8, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-17-003344:mdna:105]
Senior Notes

[0001437749-17-003344:mdna:106]
On December 8, 2016, the company entered into a Note Purchase Agreement, pursuant to which the company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023, and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001437749-17-003344:mdna:107]
On December 8, 2016, the company entered into a Note Purchase Agreement, pursuant to which the company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022, and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on February 15 and August 15, commencing August 15, 2017. Further information regarding the company’s Senior Notes is provided in Note 8, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-17-003344:mdna:108]
Cash Flow Overview

[0001437749-17-003344:mdna:109]
|  |  | Fiscal Year |  |
| (in millions) |  | 2016 |  |  | 2015 |  |
| Net cash provided by operating activities |  | $ | 180.1 |  |  | $ | 165.8 |  |
| Net cash provided used in investing activities |  |  | (511.2 | ) |  |  | (44.2 | ) |
| Net cash provided by (used in) financing activities |  |  | 284.2 |  |  |  | (67.6 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (6.8 | ) |  |  | (22.8 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (53.7 | ) |  |  | 31.2 |  |
| Cash and cash equivalents at beginning of period |  |  | 328.8 |  |  |  | 297.6 |  |
| Cash and cash equivalents at end of period |  | $ | 275.1 |  |  | $ | 328.8 |  |

[0001437749-17-003344:mdna:110]
Cash Flow from Operating Activities

[0001437749-17-003344:mdna:111]
Net cash provided by operating activities increased $14.3 million in 2016 compared to 2015. Cash provided by operating activities in 2016 included $104.5 million in net income, $83.0 million in non-cash adjustments (primarily $53.1 million in depreciation and amortization) and $7.4 million of unfavorable changes in operating assets and liabilities.

[0001437749-17-003344:mdna:112]
Changes in operating assets and liabilities (including short-term and long-term items) that negatively impacted cash flows in 2016 consisted of changes in accounts receivable ($25.2 million), accrued taxes ($18.1 million) and prepaid expenses and other ($0.3 million). The increase in accounts receivable reflects increased sales in 2016 compared to the prior year. Positively impacting cash flows were changes in inventory ($8.5 million), accrued expenses including post-retirement ($2.3 million), accounts payable ($19.2 million) and accrued payroll and severance ($6.1 million).

[0001437749-17-003344:mdna:113]
Cash Flow from Investing Activities

[0001437749-17-003344:mdna:114]
Net cash used in investing activities increased $467.1 million in 2016 compared to 2015 primarily due to the acquisitions of PolySwitch ($344.5 million, net of cash acquired), the ON portfolio business ($104.0 million), and Menber’s ($19.2 million).

[0001437749-17-003344:mdna:115]
Cash Flow from Financing Activities

[0001437749-17-003344:mdna:116]
Net cash provided by financing activities increased $351.9 million in 2016 compared to 2015. The increase was primarily due to an increase in net proceeds from debt of $314.8 million in 2016 compared to 2015. In March the company replaced its credit agreement with a new agreement and in December the company received proceeds from the issuance of senior notes. Also contributing to the increase in comparative periods was the use of cash for the share repurchase in 2015 of $31.3 million. Information regarding the company’s debt is provided in Note 8, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-17-003344:mdna:117]
|  |  | Fiscal Year |  |
| (in millions) |  | 2015 |  |  | 2014 |  |
| Net cash provided by operating activities |  | $ | 165.8 |  |  | $ | 153.1 |  |
| Net cash used in investing activities |  |  | (44.2 | ) |  |  | (104.0 | ) |
| Net cash used in financing activities |  |  | (67.6 | ) |  |  | (43.2 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (22.8 | ) |  |  | (13.5 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 31.2 |  |  |  | (7.6 | ) |
| Cash and cash equivalents at beginning of period |  |  | 297.6 |  |  |  | 305.2 |  |
| Cash and cash equivalents at end of period |  | $ | 328.8 |  |  | $ | 297.6 |  |

[0001437749-17-003344:mdna:118]
Cash Flow from Operating Activities

[0001437749-17-003344:mdna:119]
Net cash provided by operating activities increased $12.7 million in 2015 compared to 2014. Net cash provided by operating activities in 2015 was approximately $165.8 million and included $80.9 million in net income, $82.2 million in non-cash adjustments (primarily $41.7 million in depreciation and amortization) and $2.7 million of favorable changes in operating assets and liabilities.

[0001437749-17-003344:mdna:120]
Changes in operating assets and liabilities (including short-term and long-term items) that negatively impacted cash flows in 2015 consisted of changes in accounts receivable ($14.4 million), inventory ($3.6 million). Increases in accounts receivable and inventory resulted from higher sales volumes in 2015. Positively impacting cash flows were changes in accrued expenses including post-retirement ($6.5 million), accounts payable ($2.6 million), accrued payroll and severance ($5.9 million), accrued taxes ($0.6 million), and prepaid expenses and other ($5.2 million).

[0001437749-17-003344:mdna:121]
Cash Flow from Investing Activities

[0001437749-17-003344:mdna:122]
Net cash used in investing activities decreased $59.8 million in 2015 compared to 2014 primarily due to less cash used for business acquisitions in 2015 compared to 2014. In 2014 the company acquired Symcom for $52.8 million, net of cash acquired while in 2015 the company paid $4.6 million, net of cash acquired, toward the acquisition of Sigmar.

[0001437749-17-003344:mdna:123]
Cash Flow from Financing Activities

[0001437749-17-003344:mdna:124]
Net cash used in financing activities increased $24.4 million in 2015 compared to 2014 primarily due to increased use of cash for the repurchase of stock. The company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2015 to April 30, 2016. The company repurchased 350,000 shares of its common stock during 2015 under this program.

[0001437749-17-003344:mdna:125]
Capital Resources

[0001437749-17-003344:mdna:126]
We expend capital to support our operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0001437749-17-003344:mdna:127]
Share Repurchase Program

[0001437749-17-003344:mdna:128]
The company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2016 to April 30, 2017. The company did not repurchase any shares of its common stock during fiscal 2016 and the full 1,000,000 shares may yet be purchased under the program as of December 31, 2016.

[0001437749-17-003344:mdna:129]
Contractual Obligations and Commitments

[0001437749-17-003344:mdna:130]
The following table summarizes contractual obligations and commitments as of December 31, 2016:

[0001437749-17-003344:mdna:131]
| (in thousands) |  | Total |  |  | Less than 1 Year |  |  | 1 to 3 Years |  |  | 3 to 5 Years |  |  | Greater than 5 Years |  |
| Revolving credit facility |  | $ | 112,500 |  |  | $ | — |  |  | $ | — |  |  | $ | 112,500 |  |  | $ | — |  |
| Term loan |  |  | 120,313 |  |  |  | 6,250 |  |  |  | 23,437 |  |  |  | 90,626 |  |  |  | — |  |
| Entrusted loan |  |  | 3,522 |  |  |  | — |  |  |  | 3,522 |  |  |  | — |  |  |  | — |  |
| Euro Senior Notes, Series A |  |  | 122,313 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B |  |  | 99,314 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 99,314 |  |
| Interest payments |  |  | 52,002 |  |  |  | 8,611 |  |  |  | 16,534 |  |  |  | 11,614 |  |  |  | 15,243 |  |
| Supplemental Executive Retirement Plan |  |  | 2,470 |  |  |  | 1,886 |  |  |  | 359 |  |  |  | 63 |  |  |  | 162 |  |
| Operating lease payments |  |  | 39,322 |  |  |  | 11,971 |  |  |  | 11,112 |  |  |  | 8,214 |  |  |  | 8,025 |  |
| Purchase obligations |  |  | 90,712 |  |  |  | 90, 712 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 642,468 |  |  | $ | 119,430 |  |  | $ | 54,964 |  |  | $ | 223,017 |  |  | $ | 245,057 |  |

[0001437749-17-003344:mdna:132]
Off-Balance Sheet Arrangements

[0001437749-17-003344:mdna:133]
As of December 31, 2016, the company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the company was not liable for guarantees of indebtedness owed by third parties, the company was not directly liable for the debt of any unconsolidated entity and the company did not have any retained or contingent interest in assets. The company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-17-003344:mdna:134]
Recent Accounting Pronouncements

[0001437749-17-003344:mdna:135]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers" (Topic 606) which supersedes the revenue recognition requirements in ASC 605, "Revenue Recognition." This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. In August, 2015, the FASB issued ASU No. 2015-14, which postponed the effective date of ASU No. 2014-09 to fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted on the original effective date of fiscal years beginning after December 15, 2016. The company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements and has not concluded on its adoption methodology. While the company is currently assessing the impact of the new standards, the company’s revenue is primarily generated from the sale of finished products to customers. Sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The company does not expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects may be affected. The company has not yet quantified this potential impact.

[0001437749-17-003344:mdna:136]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The company is currently evaluating the impact of this ASU on its consolidated financial statements.

[0001437749-17-003344:mdna:137]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles-Goodwill and Other” (Topic 350). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity no longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 2 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after December 15, 2020, with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017.

[0001437749-17-003344:mdna:138]
Critical Accounting Policies and Estimates

[0001437749-17-003344:mdna:139]
Certain of the accounting policies as discussed below require the application of significant judgment by management in selecting the appropriate estimates and assumptions for calculating amounts to record in the financial statements. Actual results could differ from those estimates and assumptions, impacting the reported results of operations and financial position. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report. Certain accounting policies, however, are considered to be critical in that they are most important to the depiction of the company’s financial condition and results of operations and their application requires management’s subjective judgment in making estimates about the effect of matters that are inherently uncertain. The company believes the following accounting policies are the most critical to aid in fully understanding and evaluating its reported financial results, as they require management’s most difficult, subjective or complex judgments, resulting from the need to make estimates about the effect of matters that are inherently uncertain. The company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors.

[0001437749-17-003344:mdna:140]
Net Sales

[0001437749-17-003344:mdna:141]
Revenue Recognition: The company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured and the pricing is fixed and determinable. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the company adjusts sales and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The company’s distribution channels are primarily through direct sales and independent third party distributors.

[0001437749-17-003344:mdna:142]
Revenue and Billing: The company accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the company’s published price lists. The customer is invoiced when the company’s products are shipped to them in accordance with the terms of the sales agreement.

[0001437749-17-003344:mdna:143]
Returns and Credits: Some of the terms of the company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-17-003344:mdna:144]
Return to Stock: The company has a return to stock policy whereby a customer with previous authorization from Littelfuse management can return previously purchased goods for full or partial credit. The company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0001437749-17-003344:mdna:145]
Volume Rebates: The company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-17-003344:mdna:146]
Allowance for Doubtful Accounts: The company evaluates the collectability of its trade receivables based on a combination of factors. The company regularly analyzes its significant customer accounts and, when the company becomes aware of a specific customer’s inability to meet its financial obligations, the company records a specific reserve for bad debt to reduce the related receivable to the amount the company reasonably believes is collectible. The company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0001437749-17-003344:mdna:147]
Inventory

[0001437749-17-003344:mdna:148]
The company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life, and quality issues. Based on the analysis, the company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable values. During 2016, the company was required to step up the value of inventory acquired in business combinations to its selling prices less the cost to sell under business combination accounting. This step-up was approximately $7.8 million for the PolySwitch, ON portfolio, and Menber’s acquisitions in 2016.

[0001437749-17-003344:mdna:149]
Goodwill and Other Intangible Assets

[0001437749-17-003344:mdna:150]
The company annually tests goodwill for impairment on the first day of its fiscal fourth quarter or at an interim date if there is an event or change in circumstances that indicates the asset may be impaired. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted five-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after five years) to estimate market value. In addition, the company compares its derived enterprise value on a consolidated basis to the company’s market capitalization as of its test date to ensure its derived value approximates the market value of the company when taken as a whole.

[0001437749-17-003344:mdna:151]
Due to negative events in the potash market in 2016, management revisited its long term projections and conducted a step one goodwill impairment analysis for its custom products reporting unit in the third quarter of 2016. The reporting unit failed the step one test and management conducted a step two analysis with the revised projections. The fair value of the unit was estimated using the expected present value of future cash flows over a seven year forecast period and appraisal of certain assets. As a result, the company recognized a charge for goodwill impairment of $8.8 million as it wrote off the entire goodwill balance. In addition, the company recognized intangible assets impairments aggregating $6.0 million, including a $3.8 million reduction of the custom products trade names to a $0.7 million remaining value and a $2.2 million reduction of the reporting unit’s customer relationships to zero value.

[0001437749-17-003344:mdna:152]
As of the most recent annual test conducted on October 2, 2016, the company had seven reporting units for goodwill testing purposes and concluded the fair value of each of the reporting units exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. Specifically, the company noted that the excess of fair value over the carrying value of invested capital, was 65%, 154%, 218%, 132%, 70%, 15%, and 150% for its reporting units; electronics (non-silicon), electronics (silicon), passenger car, commercial vehicle products, sensors, relays, and power fuse, respectively, at October 2, 2016.

[0001437749-17-003344:mdna:153]
Certain key assumptions used in the annual test included a discount rate of 9.8% and a long-term growth rate of 3.0% which were used for all reporting units except for relays which had a discount rate of 10.3% as a result of a 0.5% premium factor.

[0001437749-17-003344:mdna:154]
In addition, the company performed a sensitivity test at October 2, 2016 that showed either a 100 basis point increase in its discount rate or a 100 basis point decrease in the long-term growth rate for each reporting unit would not have changed the company’s conclusion that no potential goodwill impairment existed at October 2, 2016.

[0001437749-17-003344:mdna:155]
The company will continue to perform a goodwill impairment test as required on an annual basis and on an interim basis, if certain conditions exist. Factors the company considers important, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the company does not believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that we could recognize impairment charges for the relays reporting unit if we have declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment. As of the 2016 annual test date, the relays reporting unit had $41.4 million of goodwill and intangible assets.

[0001437749-17-003344:mdna:156]
Long-Lived Assets

[0001437749-17-003344:mdna:157]
The company evaluates long-lived asset groups on an ongoing basis. Long-lived asset groups are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the related asset may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of the asset to future undiscounted cash flows expected to be generated by the asset group. If it is determined to be impaired, the impairment recognized is measured by the amount by which the carrying value of the asset exceeds its fair value. The company’s estimates of future cash flows from such assets could be impacted if it underperforms relative to historical or projected future operating results. The company did not record asset impairment charges in 2016 or 2015, but did recognize asset impairment charges of $0.3 million in 2014.

[0001437749-17-003344:mdna:158]
Environmental Liabilities

[0001437749-17-003344:mdna:159]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The company evaluates its reserve for coal mine remediation annually utilizing a third party expert.

[0001437749-17-003344:mdna:160]
Pension and Supplemental Executive Retirement Plan

[0001437749-17-003344:mdna:161]
Littelfuse has a number of company-sponsored defined benefit plans primarily in Europe and the Asia-Pacific region. The company recognizes the full unfunded status of these plans on the balance sheet. Actuarial gains and losses and prior service costs and credits are recognized as a component of accumulated other comprehensive income. Accounting for pensions requires estimating the future benefit cost and recognizing the cost over the employee’s expected period of employment with the company. Certain assumptions are required in the calculation of pension costs and obligations. These assumptions include the discount rate, salary scales and the expected long-term rate of return on plan assets. The discount rate is intended to represent the rate at which pension benefit obligations could be settled by purchase of an annuity contract. These assumptions are subject to change based on stock and bond market returns and other economic factors. Actual results that differ from the company’s assumptions are accumulated and amortized over future periods and, therefore, generally affect its recognized expense and accrued liability in such future periods. While the company believes that its assumptions are appropriate given current economic conditions and its actual experience, significant differences in results or significant changes in the company’s assumptions may materially affect its pension obligations and related future expense. During 2015, the company settled its U.S. defined benefit pension plan as described in Note 10, Benefit Plans, of the Notes to Consolidated Financial Statements included in this Annual Report. Further information regarding these plans is also provided in Note 10, Benefit Plans, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-17-003344:mdna:162]
Equity-based Compensation

[0001437749-17-003344:mdna:163]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments in the foreseeable future.

[0001437749-17-003344:mdna:164]
Total equity-based compensation expense for all equity compensation plans was $12.8 million, $10.7 million, and $9.4 million in 2016, 2015, and 2014, respectively. Further information regarding this expense is provided in Note 11, Shareholders’ Equity, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-17-003344:mdna:165]
Income Taxes

[0001437749-17-003344:mdna:166]
The company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. Federal and state income taxes are provided on the portion of foreign income that is expected to be remitted to the U.S. and be taxable (and foreign income taxes are provided on the portion of foreign income that is expected to be remitted to an upper-tier foreign entity).

[0001437749-17-003344:mdna:167]
The company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001437749-17-003344:mdna:168]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 12, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.
