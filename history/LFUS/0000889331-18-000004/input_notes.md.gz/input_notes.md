# LFUS notes — 0000889331-18-000004


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000889331-18-000004:notes:1]
[same as prior period, unchanged from 0001437749-18-014196:notes:5]

[0000889331-18-000004:notes:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the year ended December 30, 2017, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.


## us-gaap:BusinessAcquisitionProFormaInformationNonrecurringAdjustmentsTableTextBlock

[0000889331-18-000004:notes:3]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-18-000004:notes:4]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Amortization(a) |  | $ | 3,104 |  |  | $ | (6,304 | ) |  | $ | 8,289 |  |  | $ | (18,905 | ) |
| Depreciation |  | — |  |  | 139 |  |  | — |  |  | 417 |  |
| Transaction costs(b) |  | — |  |  | — |  |  | 9,976 |  |  | (9,976 | ) |
| Amortization of inventory step-up(c) |  | — |  |  | — |  |  | 36,927 |  |  | (36,927 | ) |
| Stock compensation(d) |  | 421 |  |  | (426 | ) |  | 5,110 |  |  | (6,206 | ) |
| Interest expense(e) |  | — |  |  | (2,582 | ) |  | — |  |  | (7,746 | ) |
| Income tax impact of above items |  | $ | (1,011 | ) |  | $ | 2,906 |  |  | $ | (14,290 | ) |  | $ | 25,802 |  |

[0000889331-18-000004:notes:5]
| (a) | The amortization adjustment for the nine months ended September 29, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and will be fully amortized in the fiscal 2017 pro forma results. The amortization adjustment for the three and nine months ended September 30, 2017 reflects incremental amortization resulting for the measurement of intangibles at their fair values. |

[0000889331-18-000004:notes:6]
| (b) | The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the nine months ended September 29, 2018 and recognition of those fees during the nine months ended September 30, 2017. |

[0000889331-18-000004:notes:7]
| (c) | The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the nine months ended September 29, 2018 and the recognition of the full amortization during the nine months ended September 30, 2017. The inventory step-up was amortized over five months as the inventory was sold. |

[0000889331-18-000004:notes:8]
| (d) | The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the nine months ended September 29, 2018. The adjustment for the nine months ended September 30, 2017 reflect the incremental stock compensation for the converted stock options. |

[0000889331-18-000004:notes:9]
| (e) | The interest expense adjustment reflects incremental interest expense related to the financing of the transaction. |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000889331-18-000004:notes:10]
The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the IXYS acquisition occurred as of January 1, 2017 or of future consolidated operating results.

[0000889331-18-000004:notes:11]
|  |  | Three Months Ended |
| (in thousands, except per share amounts) |  | September 29, 2018 |  | September 30, 2017 |
| Net sales |  | $ | 439,191 |  |  | $ | 405,573 |  |
| Income before income taxes |  | 71,737 |  |  | 50,883 |  |
| Net income |  | 56,060 |  |  | 40,004 |  |
| Net income per share — basic |  | 2.23 |  |  | 1.61 |  |
| Net income per share — diluted |  | $ | 2.18 |  |  | $ | 1.59 |  |

[0000889331-18-000004:notes:12]
|  |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 29, 2018 |  | September 30, 2017 |
| Net sales |  | $ | 1,332,900 |  |  | $ | 1,171,283 |  |
| Income before income taxes |  | 228,503 |  |  | 102,429 |  |
| Net income |  | 179,264 |  |  | 95,047 |  |
| Net income — basic |  | 7.17 |  |  | 3.84 |
| Net income — diluted |  | $ | 7.16 |  |  | $ | 3.78 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-18-000004:notes:13]
Other Comprehensive (Loss) Income

[0000889331-18-000004:notes:14]
Change in other comprehensive (loss) income by component were as follows:

[0000889331-18-000004:notes:15]
| (in thousands) |  | Three Months Ended September 29, 2018 |  | Three Months Ended September 30, 2017 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plans adjustments |  | $ | (115 | ) |  | $ | — |  |  | $ | (115 | ) |  | $ | (149 | ) |  | $ | 89 |  |  | $ | (60 | ) |
| Unrealized loss on investments |  | — |  |  | — |  |  | — |  |  | (1,710 | ) |  | — |  |  | (1,710 | ) |
| Foreign currency translation adjustments |  | (7,832 | ) |  | — |  |  | (7,832 | ) |  | 1,531 |  |  | — |  |  | 1,531 |  |
| Total change in other comprehensive (loss) income |  | $ | (7,947 | ) |  | $ | — |  |  | $ | (7,947 | ) |  | $ | (328 | ) |  | $ | 89 |  |  | $ | (239 | ) |

[0000889331-18-000004:notes:16]
| (in thousands) |  | Nine Months Ended September 29, 2018 |  | Nine Months Ended September 30, 2017 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plans adjustments |  | $ | 630 |  |  | $ | (18 | ) |  | $ | 648 |  |  | $ | (585 | ) |  | $ | 144 |  |  | $ | (441 | ) |
| Unrealized loss on investments |  | — |  |  | — |  |  | — |  |  | (1,235 | ) |  | — |  |  | (1,235 | ) |
| Foreign currency translation adjustments |  | (24,816 | ) |  | — |  |  | (24,816 | ) |  | 2,912 |  |  | — |  |  | 2,912 |  |
| Total change in other comprehensive (loss) income |  | $ | (24,186 | ) |  | $ | (18 | ) |  | $ | (24,168 | ) |  | $ | 1,092 |  |  | $ | 144 |  |  | $ | 1,236 |  |

[0000889331-18-000004:notes:17]
The following table sets forth the changes in accumulated other comprehensive (loss) income by component for the nine months ended September 29, 2018:

[0000889331-18-000004:notes:18]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Unrealizedgain (loss) oninvestments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 30, 2017 |  | $ | (10,836 | ) |  | $ | 9,795 |  |  | $ | (62,627 | ) |  | $ | (63,668 | ) |
| Cumulative effect adjustment (a) |  | — |  |  | (9,795 | ) |  | — |  |  | (9,795 | ) |
| Activity in the period |  | 648 |  |  | — |  |  | (24,816 | ) |  | (24,168 | ) |
| Balance at September 29, 2018 |  | $ | (10,188 | ) |  | $ | — |  |  | $ | (87,443 | ) |  | $ | (97,631 | ) |

[0000889331-18-000004:notes:19]
| (a) | The Company adopted ASU 2016-01 on December 31, 2017 on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings. See Note 1, Summary of Significant Accounting Policies and Other Information, for further discussion. |

[0000889331-18-000004:notes:20]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three  and nine months ended September 29, 2018 and the three and nine months September 30, 2017 were as follows:

[0000889331-18-000004:notes:21]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service |  | $ | 74 |  |  | $ | 84 |  |  | $ | 222 |  |  | $ | 252 |  |

[0000889331-18-000004:notes:22]
The Company recognizes net periodic pension cost, which includes amortization of prior service costs, in both selling, general, and administrative expenses and cost of sales within the Condensed Consolidated Statements of Net Income, depending on the functional area of the underlying employees included in the plans.


## us-gaap:DebtDisclosureTextBlock

[0000889331-18-000004:notes:23]
Debt

[0000889331-18-000004:notes:24]
The carrying amounts of debt at September 29, 2018 and December 30, 2017 are as follows:

[0000889331-18-000004:notes:25]
| (in thousands) |  | September 29, 2018 |  | December 30, 2017 |
| Term Loan |  | $ | 155,000 |  |  | $ | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,819 |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,092 |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | — |  |
| Other |  | 2,694 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,892 | ) |  | (4,881 | ) |
| Total debt |  | 700,713 |  |  | 495,611 |  |
| Less: Current maturities |  | (10,076 | ) |  | (6,250 | ) |
| Total long-term debt |  | $ | 690,637 |  |  | $ | 489,361 |  |

[0000889331-18-000004:notes:26]
Revolving Credit Facility / Term Loan

[0000889331-18-000004:notes:27]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-18-000004:notes:28]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. In addition to the quarterly principal payments, the Company paid an additional $35.0 million of principal on the term loan during the nine months ended September 29, 2018.

[0000889331-18-000004:notes:29]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.49% at September 29, 2018.

[0000889331-18-000004:notes:30]
As of September 29, 2018, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At September 29, 2018, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-18-000004:notes:31]
Senior Notes

[0000889331-18-000004:notes:32]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-18-000004:notes:33]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-18-000004:notes:34]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-18-000004:notes:35]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-18-000004:notes:36]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 29, 2018, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-18-000004:notes:37]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000889331-18-000004:notes:38]
The following table disaggregates the Company’s revenue by primary business units for the three and nine months ended September 29, 2018:

[0000889331-18-000004:notes:39]
|  |  | Three Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |

[0000889331-18-000004:notes:40]
|  |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |


## us-gaap:EarningsPerShareTextBlock

[0000889331-18-000004:notes:41]
Earnings Per Share

[0000889331-18-000004:notes:42]
[same as prior period, unchanged from 0001437749-18-014196:notes:33]

[0000889331-18-000004:notes:43]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | 53,546 |  |  | 42,808 |  |  | 131,900 |  |  | 130,338 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 25,109 |  |  | 22,713 |  |  | 24,817 |  |  | 22,678 |  |
| Effect of dilutive securities |  | 362 |  |  | 240 |  |  | 395 |  |  | 228 |  |
| Diluted |  | 25,471 |  |  | 22,953 |  |  | 25,212 |  |  | 22,906 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | 2.13 |  |  | 1.88 |  |  | 5.31 |  |  | 5.75 |  |
| Diluted earnings per share |  | 2.10 |  |  | 1.87 |  |  | 5.23 |  |  | 5.69 |  |

[0000889331-18-000004:notes:44]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 38,082 and 30,579 for the three months ended September 29, 2018 and September 30, 2017, respectively, and 39,446 and 35,858 for the nine months ended September 29, 2018 and September 30, 2017, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000889331-18-000004:notes:45]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 30, 2017:

[0000889331-18-000004:notes:46]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Investments in equity securities |  | $ | 10,993 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,993 |  |
| Mutual funds |  | 7,962 |  |  | — |  |  | — |  |  | 7,962 |  |

[0000889331-18-000004:notes:47]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 29, 2018:

[0000889331-18-000004:notes:48]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Investments in equity securities |  | $ | 12,204 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,204 |  |
| Mutual funds |  | 10,546 |  |  | — |  |  | — |  |  | 10,546 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000889331-18-000004:notes:49]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of September 29, 2018 and December 30, 2017 were as follows:

[0000889331-18-000004:notes:50]
|  |  | September 29, 2018 |  | December 30, 2017 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 136,819 |  |  | $ | 135,392 |  |  | $ | 139,623 |  |  | $ | 138,294 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,092 |  |  | 108,511 |  |  | 113,369 |  |  | 111,579 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 24,052 |  |  | 25,000 |  |  | 24,737 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 94,474 |  |  | 100,000 |  |  | 99,992 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 47,333 |  |  | — |  |  | — |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 115,231 |  |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-18-000004:notes:51]
Fair Value of Assets and Liabilities

[0000889331-18-000004:notes:52]
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a three-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows:

[0000889331-18-000004:notes:53]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0000889331-18-000004:notes:54]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable, and

[0000889331-18-000004:notes:55]
Level 3—Valuations based upon one or more significant unobservable inputs.

[0000889331-18-000004:notes:56]
[same as prior period, unchanged from 0001437749-18-014196:notes:47]

[0000889331-18-000004:notes:57]
[same as prior period, unchanged from 0001437749-18-014196:notes:48]

[0000889331-18-000004:notes:58]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 1 of the valuation hierarchy and recorded in investments and other assets.

[0000889331-18-000004:notes:59]
[same as prior period, unchanged from 0001437749-18-014196:notes:50]

[0000889331-18-000004:notes:60]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value and recorded in other assets.

[0000889331-18-000004:notes:61]
There were no changes during the quarter ended September 29, 2018 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 29, 2018, and December 30, 2017, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-18-000004:notes:62]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at September 29, 2018 and December 30, 2017, as the rates on these borrowings are variable in nature.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-18-000004:notes:63]
Goodwill and Other Intangible Assets

[0000889331-18-000004:notes:64]
The amounts for goodwill and changes in the carrying value by segment for the nine months ended September 29, 2018 are as follows:

[0000889331-18-000004:notes:65]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 30, 2017 |  | $ | 278,959 |  |  | $ | 135,829 |  |  | $ | 38,626 |  |  | $ | 453,414 |  |
| Additions(a) |  | 380,199 |  |  | — |  |  | — |  |  | 380,199 |  |
| Currency translation |  | (1,090 | ) |  | (2,040 | ) |  | (129 | ) |  | (3,259 | ) |
| As of September 29, 2018 |  | $ | 658,068 |  |  | $ | 133,789 |  |  | $ | 38,497 |  |  | $ | 830,354 |  |

[0000889331-18-000004:notes:66]
(a)The additions resulted from the acquisition of IXYS and an immaterial acquisition.

[0000889331-18-000004:notes:67]
The components of other intangible assets at September 29, 2018 are as follows:

[0000889331-18-000004:notes:68]
| (in thousands, except weighted average useful life) |  | WeightedAverageUseful Life (Years) |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Patents, licenses and software |  | 10.5 |  | $ | 192,215 |  |  | $ | 71,451 |  |  | $ | 120,764 |  |
| Distribution network |  | 12.6 |  | 44,098 |  |  | 34,214 |  |  | 9,884 |  |
| Customer relationships, trademarks, and tradenames |  | 18 |  | 312,267 |  |  | 69,478 |  |  | 242,789 |  |
| Order backlog |  | 0.3 |  | 12,420 |  |  | 8,706 |  |  | 3,714 |  |
| Total |  |  |  | $ | 561,000 |  |  | $ | 183,849 |  |  | $ | 377,151 |  |

[0000889331-18-000004:notes:69]
During the nine months ended September 29, 2018, the Company recorded additions to other intangible assets of $212.7 million, related to the IXYS acquisition, the components of which were as follows:

[0000889331-18-000004:notes:70]
| (in thousands, except weighted average useful life) |  | WeightedAverageUseful Life (Years) |  | Amount |
| Patents, licenses and software |  | 8 |  | $ | 51,500 |  |
| Customer relationships, trademarks, and tradenames |  | 17.2 |  | 148,800 |  |
| Order backlog |  | 1 |  | 12,420 |  |
| Total |  |  |  | $ | 212,720 |  |

[0000889331-18-000004:notes:71]
During the three and nine months ended September 29, 2018 and September 30, 2017, the Company recorded amortization expense of $13.1 million and $38.5 million and $6.3 million and $18.4 million, respectively, for intangible assets with definite lives.

[0000889331-18-000004:notes:72]
Estimated annual amortization expense related to intangible assets with definite lives as of September 29, 2018 is as follows:

[0000889331-18-000004:notes:73]
| (in thousands) | Amount |
| 2018 | $ | 53,383 |  |
| 2019 | 40,454 |  |
| 2020 | 40,237 |  |
| 2021 | 38,403 |  |
| 2022 | 37,506 |  |
| 2023 and thereafter | 206,586 |  |
| Total | $ | 416,569 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-18-000004:notes:74]
Income Taxes

[0000889331-18-000004:notes:75]
The effective tax rates for the three and nine months ended September 29, 2018 were 21.5% and 20.1%, respectively, compared to effective tax rates for the three and nine months ended September 30, 2017 of 22.9% and 18.7%, respectively.

[0000889331-18-000004:notes:76]
The effective tax rate for the third quarter of 2018 was lower than the effective tax rate for the third quarter of 2017 primarily due to a third quarter 2017 accrual for taxes on certain undistributed earnings of non-US affiliates, offset in part by the impact of US tax reform and the acquisition of IXYS. The effective tax rate of the first nine months of 2018 is higher than the effective tax rates for the first nine months of 2017 primarily due to the impact of U.S. tax reform and the acquisition of IXYS. The effective tax rates for the 2017 periods were lower than the then applicable 35% U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-18-000004:notes:77]
On December 22, 2017, the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduces the U.S. corporate federal income tax rate from 35% to 21%, adds base broadening provisions which limit deductions and address excessive international tax planning, imposes a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enables repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. Other than the Toll Charge (which, except for the IXYS impact, is applicable to the Company for 2017), the provisions will generally be applicable to the Company in 2018 and beyond.

[0000889331-18-000004:notes:78]
In accordance with the guidance provided in SEC Staff Accounting Bulletin (“SAB”) No. 118, in the fourth quarter of 2017 the Company recorded a charge of $47.0 million as a provisional reasonable estimate of the impact of the Tax Act, including $49.0 million for the Toll Charge net of $2.0 million for other net tax benefits. The Company did not adjust the provisional reasonable estimate in the first nine months of 2018. In addition, the Company recorded a preliminary estimate of $8.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation (this estimate reflects a reduction of $2.0 million recorded in the third quarter of 2018). This estimate was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities. The Company is continuing to analyze the Tax Act and plans to finalize the 2017 provisional reasonable estimate within the measurement period outlined in SAB No. 118 and the IXYS Toll Charge estimate during the purchase price allocation period. The final charges may differ from the estimates if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining the estimates, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors. Aside from these interpretation issues, the final charges may differ from the estimates due to refinements of accumulated non-U.S. earnings and tax pool data.

[0000889331-18-000004:notes:79]
The Company has elected to pay the 2017 Littelfuse Toll Charge and will elect to pay the 2018 IXYS Toll Charge over the eight-year period prescribed by the Tax Act. The long-term portion of these Toll Charges totaling $29.7 million (which includes the 2017 Littelfuse provisional reasonable estimate and the 2018 IXYS provisional estimate, partially offset by foreign tax credits, other current deductions and the actual 2018 and anticipated 2019 annual installment payments) is recorded in the Other long-term liabilities on the Condensed Consolidated Balance Sheet as of September 29, 2018.

[0000889331-18-000004:notes:80]
The Company recognized deferred tax liabilities of $12.0 million ($11.8 million for non-U.S. taxes and $0.2 million for U.S. state taxes) as of December 30, 2017 related to taxes on certain non-U.S. earnings which are not considered to be permanently reinvested. Some of these taxes may provide a U.S. federal income tax benefit as a foreign tax credit. However, due to uncertainty in regard to the Tax Act’s provisions, no such tax benefit was recorded as of December 30, 2017, and no such tax benefit was recorded in the first nine months of 2018. The Company will reconsider this provisional conclusion when it finalizes its 2017 preliminary reasonable estimate of the impact of the Tax Act, based upon interpretations and administrative guidance as of that time.

[0000889331-18-000004:notes:81]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has not adopted an accounting policy for GILTI. Thus, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions. The Company intends to adopt an accounting policy for GILTI within the measurement period outlined in SAB 118. Although such an accounting policy has not been adopted, the Company considered GILTI when determining the current portion of income tax expense recorded for the three and nine months ended September 29, 2018.

[0000889331-18-000004:notes:82]
Although certain administrative guidance has been issued, the appropriate application of many provisions of the Tax Act remain uncertain. The Company used its best judgement as to the application of these provisions in determining its income tax expense for the three and nine months ended September 29, 2018. Adjustments to income tax expense related to the first nine months of 2018 may be necessary if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining its estimates, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-18-000004:notes:83]
Inventories

[0000889331-18-000004:notes:84]
The components of inventories at September 29, 2018 and December 30, 2017 are as follows:

[0000889331-18-000004:notes:85]
| (in thousands) |  | September 29 2018 |  | December 30 2017 |
| Raw materials |  | $ | 69,575 |  |  | $ | 39,030 |  |
| Work in process |  | 83,115 |  |  | 27,454 |  |
| Finished goods |  | 94,565 |  |  | 74,305 |  |
| Total |  | $ | 247,255 |  |  | $ | 140,789 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-18-000004:notes:86]
[same as prior period, unchanged from 0001437749-18-014196:notes:102]

[0000889331-18-000004:notes:87]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0000889331-18-000004:notes:88]
[same as prior period, unchanged from 0001437749-18-014196:notes:90]

[0000889331-18-000004:notes:89]
On January 17, 2018, the Company acquired IXYS Corporation (“IXYS”), a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 3,500 customers through its direct sales force and global distribution partners. The acquisition of IXYS is expected to accelerate the Company’s growth across the power control market driven by IXYS’s extensive power semiconductor portfolio and technology expertise. With IXYS, the Company will be able to diversify and expand its presence within industrial electronics markets, leveraging the strong IXYS industrial OEM customer base. The Company also expects to increase long-term penetration of its power semiconductor portfolio in automotive markets, expanding its global content per vehicle.

[0000889331-18-000004:notes:90]
Upon completion of the acquisition, at IXYS stockholders’ election and subject to proration, each share of IXYS common stock, par value $0.01 per share, owned immediately prior to the effective time was canceled and extinguished and automatically converted into the right to receive: (i) $23.00 in cash (subject to applicable withholding tax), without interest (referred to as the cash consideration), or (ii) 0.1265 of a share of common stock, par value $0.01 per share, of Littelfuse (referred to as the stock consideration). IXYS stockholders received cash in lieu of any fractional shares of Littelfuse common stock that the IXYS stockholders would otherwise have been entitled to receive. Additionally, each outstanding option to purchase shares of IXYS common stock granted under an IXYS equity plan were assumed by Littelfuse and converted into an option to acquire (i) a number of shares of Littelfuse common stock equal to the number of shares of IXYS common stock subject to such option immediately prior to the effective time multiplied by 0.1265, rounded down to the nearest whole share, with (ii) an exercise price per share of Littelfuse common stock equal to the exercise price of such IXYS stock option immediately prior to the effective time divided by 0.1265, rounded up to the nearest whole cent.

[0000889331-18-000004:notes:91]
Based on the $207.5 per share opening price of Littelfuse common stock on January 17, 2018, the consideration IXYS stockholders received in exchange of their IXYS common stock in the acquisition had a value of $814.8 million comprised of $380.6 million of cash and $434.2 million of Littelfuse stock. In addition to the consideration transferred related to IXYS common stock, the value of consideration transferred, and included in the purchase price, related to IXYS stock options that were converted to Littelfuse stock options, or cash settled, had a value of $41.7 million. As a result, total consideration was valued at $856.5 million.

[0000889331-18-000004:notes:92]
The total purchase price of $856.5 million has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary area that is not yet finalized relates to the completion of the computation of the adoption of the Tax Act. As a result, these allocations are subject to change during the purchase price allocation period as the computation is finalized.

[0000889331-18-000004:notes:93]
[same as prior period, unchanged from 0001437749-18-014196:notes:95]

[0000889331-18-000004:notes:94]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 302,865 |  |
| Cash settled stock options | 3,622 |  |
| Littelfuse stock | 434,192 |  |
| Converted stock options | 38,109 |  |
| Total purchase consideration | $ | 778,788 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | $ | 155,930 |  |
| Property, plant, and equipment | 77,442 |  |
| Intangible assets | 212,720 |  |
| Goodwill | 379,619 |  |
| Other non-current assets | 31,570 |  |
| Other non-current liabilities | (78,493 | ) |
|  | $ | 778,788 |  |

[0000889331-18-000004:notes:95]
Included in IXYS’s current assets, net was approximately $49.1 million of receivables. All IXYS goodwill, other assets and liabilities were recorded in the Electronics segment and primarily reflected in the Americas and European geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining IXYS’s products and technology with the Company’s existing electronics product portfolio. Goodwill resulting from the IXYS acquisition is not expected to be deductible for tax purposes.

[0000889331-18-000004:notes:96]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and nine months ended September 29, 2018 are net sales of approximately $99.7 million and $286.2 million, respectively, and a income (loss) before income taxes of $6.2 million and $(25.5) million, respectively, since the January 17, 2018 acquisition of IXYS. The Company recognized approximately $4.3 million and $11.8 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the three and nine months ended September 29, 2018, of which $4.5 million was recognized immediately as it related to prior service periods.

[0000889331-18-000004:notes:97]
As required by purchase accounting rules, the Company recorded a $36.9 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was fully amortized as a non-cash charge to cost of goods sold during the first and second quarters of 2018, as the acquired inventory was sold, and reflected as other non-segment costs.

[0000889331-18-000004:notes:98]
During the nine months ended September 29, 2018, the Company incurred approximately $11.0 million of legal and professional fees related to this acquisition which were primarily recognized as selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-18-000004:notes:99]
2017 Acquisitions

[0000889331-18-000004:notes:100]
[same as prior period, unchanged from 0001437749-18-014196:notes:103]

[0000889331-18-000004:notes:101]
On July 7, 2017, the Company acquired the assets of U.S. Sensor Corporation (“U.S. Sensor”). The acquisition purchase price of $24.3 million, net of the finalization of an income tax gross up which was settled in the fourth quarter of 2017, was funded with available cash. The acquired business expands the Company’s existing sensor portfolio in several key electronics and industrial end markets. U.S. Sensor manufactures a variety of high quality negative temperature coefficient thermistors as well as thermistor probes and assemblies. Product lines also include thin film platinum resistance temperature detectors (“RTDs”) and RTD assemblies.

[0000889331-18-000004:notes:102]
[same as prior period, unchanged from 0001437749-18-014196:notes:105]

[0000889331-18-000004:notes:103]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash | $ | 24,340 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | $ | 4,635 |  |
| Patented and unpatented technologies | 1,090 |  |
| Trademarks and tradenames | 200 |  |
| Non-compete agreement | 50 |  |
| Customer relationships | 2,830 |  |
| Goodwill | 16,075 |  |
| Current liabilities | (540 | ) |
|  | $ | 24,340 |  |

[0000889331-18-000004:notes:104]
Included in U.S. Sensor’s current assets, net was approximately $1.5 million of receivables. All U.S. Sensor goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining U.S. Sensor’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is expected to be deductible for tax purposes.

[0000889331-18-000004:notes:105]
As required by purchase accounting rules, the Company recorded a $1.6 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the third quarter of 2017, as the acquired inventory was sold, and reflected as other non-segment costs.

[0000889331-18-000004:notes:106]
[same as prior period, unchanged from 0001437749-18-014196:notes:109]

[0000889331-18-000004:notes:107]
In December 2015, the Company invested $3.5 million in the preferred stock of Monolith Semiconductor Inc. (“Monolith”), a U.S. start-up Company developing silicon carbide technology, which represented approximately 12% of the common stock of Monolith on an as-converted basis. The Company accounted for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was $3.5 million at December 31, 2016.

[0000889331-18-000004:notes:108]
On February 28, 2017, pursuant to a Securities Purchase Agreement between the Company and the stockholders of Monolith (“Securities Purchase Agreement”) and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired 62% of the outstanding common stock of Monolith for $15.0 million. The Securities Purchase Agreement includes provisions whereby the Company will acquire the remaining outstanding stock of Monolith (“non-controlling interest”) at a time or times based on Monolith meeting certain technical and sales targets. During the first quarter of 2018, Monolith met the next set of technical and sales targets. As a result, and pursuant to the Securities Purchase Agreement, in April 2018 the Company acquired an additional 19% of the outstanding common stock of Monolith for $5.0 million, of which $4.0 million was paid to the stockholders of Monolith. On October 5, 2018, the Company acquired the remaining 19% outstanding common stock for $5.0 million.

[0000889331-18-000004:notes:109]
The additional investment, in the first quarter of 2017, resulted in the Company gaining control of Monolith and was accounted for as a step-acquisition with the fair value of the original investment immediately before the acquisition estimated to be approximately $3.5 million. As the fair value of the investment immediately prior to the transaction equaled the carrying value, there was no impact on the Company’s Consolidated Statements of Net Income. As the Securities Purchase Agreement includes an obligation of the Company to mandatorily redeem the non-controlling interest for cash, the fair value of the non-controlling interest was recognized as a liability on the Company’s Consolidated Balance Sheets. The original investment of $3.5 million, additional cash consideration of $14.2 million (net of cash acquired), and the non-cash consideration of the fair value of the commitment to purchase the non-controlling interest of $9.0 million resulted in a purchase price of $26.7 million. Changes in the fair value of the non-controlling interest are recognized in the Company’s Consolidated Statements of Net Income.

[0000889331-18-000004:notes:110]
Commencing March 1, 2017, Monolith was reflected as a consolidated subsidiary within the Company’s Consolidated Financial Statements. Had the acquisition occurred as of January 1, 2017, the impact on the Company’s consolidated results of operations would not have been material.

[0000889331-18-000004:notes:111]
[same as prior period, unchanged from 0001437749-18-014196:notes:116]

[0000889331-18-000004:notes:112]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Original investment | $ | 3,500 |  |
| Cash, net of cash acquired | 14,172 |  |
| Non-cash, fair value of commitment to purchase non-controlling interest | 9,000 |  |
| Total purchase consideration | $ | 26,672 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | $ | 891 |  |
| Property, plant, and equipment | 789 |  |
| Patented and unpatented technologies | 6,720 |  |
| Non-compete agreement | 140 |  |
| Goodwill | 20,641 |  |
| Current liabilities | (639 | ) |
| Other non-current liabilities | (1,870 | ) |
|  | $ | 26,672 |  |

[0000889331-18-000004:notes:113]
Included in Monolith’s current assets, net was approximately $0.7 million of receivables. All Monolith goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Monolith’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0000889331-18-000004:notes:114]
[same as prior period, unchanged from 0001437749-18-014196:notes:119]

[0000889331-18-000004:notes:115]
The following table summarizes, on a pro forma basis, the combined results of operations of the Company and IXYS as though the acquisition had occurred as of January 1, 2017. The Company has not included pro forma results of operations for U.S. Sensor or Monolith as these results were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the IXYS acquisition occurred as of January 1, 2017 or of future consolidated operating results.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000889331-18-000004:notes:116]
Recently Adopted Accounting Standards

[0000889331-18-000004:notes:117]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-07 “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the previous guidance, net benefit cost was reported as an employee cost within operating income. The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU No. 2017-07 was effective for the first quarter of 2018 with the Company adopting the new standard on December 31, 2017.

[0000889331-18-000004:notes:118]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on December 31, 2017, on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings. As a result of the adoption of the new standard and change in fair value of our equity investments, for the nine months ended September 29, 2018, the Company recognized an unrealized loss of $0.3 million in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.

[0000889331-18-000004:notes:119]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers” (Topic 606) which supersedes the revenue recognition requirements in ASC 605, “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on December 31, 2017 using the modified retrospective method, however, no adjustment to retained earnings was needed. The new guidance did not have a material effect on the Company’s Condensed Consolidated Statements of Net Income. See the Revenue Recognition section above for further discussion.

[0000889331-18-000004:notes:120]
In October 2016, the FASB issued ASU No. 2016-16, "Income Taxes” (Topic 740). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on December 31, 2017 and it did not have a material impact.

[0000889331-18-000004:notes:121]
Recently Issued Accounting Standards

[0000889331-18-000004:notes:122]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the first quarter of 2019. The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has not yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.

[0000889331-18-000004:notes:123]
In January 2018, the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions of the 2017 U.S. Tax Cuts and Jobs Act (the “Tax Act”). The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has not yet completed its assessment and therefore has not yet elected an accounting policy.

[0000889331-18-000004:notes:124]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 2018-02 will be effective in the first quarter of 2019; however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 2018-02 on the Consolidated Financial Statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-18-000004:notes:125]
Benefit Plans

[0000889331-18-000004:notes:126]
[same as prior period, unchanged from 0001437749-18-014196:notes:144]

[0000889331-18-000004:notes:127]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended September 29, 2018 and September 30, 2017 were as follows:

[0000889331-18-000004:notes:128]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 533 |  |  | $ | 408 |  |  | $ | 1,599 |  |  | $ | 1,224 |  |
| Interest cost |  | 501 |  |  | 360 |  |  | 1,503 |  |  | 1,080 |  |
| Expected return on plan assets |  | (540 | ) |  | (476 | ) |  | (1,620 | ) |  | (1,428 | ) |
| Amortization of prior service |  | 74 |  |  | 84 |  |  | 222 |  |  | 252 |  |
| Net periodic benefit cost |  | $ | 568 |  |  | $ | 376 |  |  | $ | 1,704 |  |  | $ | 1,128 |  |

[0000889331-18-000004:notes:129]
The Company expects to make approximately $2.3 million of cash contributions to its pension plans in 2018.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-18-000004:notes:130]
Related Party Transactions

[0000889331-18-000004:notes:131]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-18-000004:notes:132]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the three and nine months ended September 29, 2018, the Company recorded revenues of $0.2 million and $0.6 million, respectively from sales of products to Powersem for use as components in their products. During the three and nine months ended September 29, 2018, the Company purchased $1.3 million and $3.4 million, respectively of products from Powersem. At September 29, 2018, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

[0000889331-18-000004:notes:133]
EB Tech Ltd.: The Company owns approximately 20% of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the three and nine months ended September 29, 2018 EB Tech rendered processing services for the Company totaling approximately $0.1 million and $0.3 million, respectively. As of September 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

[0000889331-18-000004:notes:134]
Automated Technology, Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three and nine months ended September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $2.5 million and $7.7 million, respectively. As of September 29, 2018, the Company’s accounts payable balance to ATEC was $0.6 million.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000889331-18-000004:notes:135]
[same as prior period, unchanged from 0001437749-18-014196:notes:155]

[0000889331-18-000004:notes:136]
[same as prior period, unchanged from 0001437749-18-014196:notes:156]

[0000889331-18-000004:notes:137]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.

[0000889331-18-000004:notes:138]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-18-000004:notes:139]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-18-000004:notes:140]
Revenue and Billing

[0000889331-18-000004:notes:141]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

[0000889331-18-000004:notes:142]
Ship and Debit Program

[0000889331-18-000004:notes:143]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-18-000004:notes:144]
Return to Stock

[0000889331-18-000004:notes:145]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-18-000004:notes:146]
Volume Rebates

[0000889331-18-000004:notes:147]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0000889331-18-000004:notes:148]
The Company’s long-lived assets by country, as of September 29, 2018 and December 30, 2017, were as follows:

[0000889331-18-000004:notes:149]
| (in thousands) |  | September 29, 2018 |  | December 30, 2017 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 66,098 |  |  | $ | 23,490 |  |
| China(a) |  | 89,856 |  |  | 86,866 |  |
| Mexico |  | 69,395 |  |  | 62,510 |  |
| Germany |  | 37,281 |  |  | 1,082 |  |
| Philippines |  | 31,589 |  |  | 31,129 |  |
| Other countries |  | 49,664 |  |  | 45,500 |  |
| Total long-lived assets |  | $ | 343,883 |  |  | $ | 250,577 |  |

[0000889331-18-000004:notes:150]
| (a) | Includes mainland China, Taiwan, and Hong Kong. |

[0000889331-18-000004:notes:151]
The Company’s additions to long-lived assets by country were as follows:

[0000889331-18-000004:notes:152]
|  |  | Nine Months Ended |
| (in thousands) |  | September 29, 2018 |  | September 30, 2017 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 5,636 |  |  | $ | 2,752 |  |
| China(a) |  | 19,043 |  |  | 22,165 |  |
| Mexico |  | 14,089 |  |  | 15,041 |  |
| Germany |  | 5,917 |  |  | 67 |  |
| Philippines |  | 6,133 |  |  | 2,018 |  |
| Other countries |  | 5,128 |  |  | 6,427 |  |
| Total additions to long-lived assets |  | $ | 55,946 |  |  | $ | 48,470 |  |

[0000889331-18-000004:notes:153]
The Company’s net sales by country are as follows:

[0000889331-18-000004:notes:154]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 125,867 |  |  | $ | 103,233 |  |  | $ | 386,980 |  |  | $ | 290,538 |  |
| China(a) |  | 117,813 |  |  | 82,986 |  |  | 352,097 |  |  | 240,731 |  |
| Other countries(b) |  | 195,511 |  |  | 131,670 |  |  | 577,110 |  |  | 385,416 |  |
| Total net sales |  | $ | 439,191 |  |  | $ | 317,889 |  |  | $ | 1,316,187 |  |  | $ | 916,685 |  |

[0000889331-18-000004:notes:155]
| (b) | Each country included in other countries are less than 10% of net sales. |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000889331-18-000004:notes:156]
Segment information is summarized as follows:

[0000889331-18-000004:notes:157]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 296,472 |  |  | $ | 175,899 |  |  | $ | 860,240 |  |  | $ | 499,052 |  |
| Automotive |  | 114,416 |  |  | 113,797 |  |  | 367,718 |  |  | 338,094 |  |
| Industrial |  | 28,303 |  |  | 28,193 |  |  | 88,229 |  |  | 79,539 |  |
| Total net sales |  | $ | 439,191 |  |  | $ | 317,889 |  |  | $ | 1,316,187 |  |  | $ | 916,685 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,898 |  |  | $ | 8,986 |  |  | $ | 45,227 |  |  | $ | 26,080 |  |
| Automotive |  | 5,891 |  |  | 5,622 |  |  | 17,830 |  |  | 16,572 |  |
| Industrial |  | 1,364 |  |  | 1,338 |  |  | 4,291 |  |  | 3,982 |  |
| Other |  | 3,105 |  |  | — |  |  | 8,712 |  |  | — |  |
| Total depreciation and amortization |  | $ | 26,258 |  |  | $ | 15,946 |  |  | $ | 76,060 |  |  | $ | 46,634 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 72,464 |  |  | $ | 44,345 |  |  | $ | 193,739 |  |  | $ | 122,518 |  |
| Automotive |  | 10,863 |  |  | 16,821 |  |  | 44,965 |  |  | 47,599 |  |
| Industrial |  | 4,134 |  |  | 3,757 |  |  | 14,123 |  |  | 5,769 |  |
| Other(a) |  | (11,233 | ) |  | (6,314 | ) |  | (79,406 | ) |  | (8,155 | ) |
| Total operating income |  | $ | 76,228 |  |  | $ | 58,609 |  |  | $ | 173,421 |  |  | $ | 167,731 |  |
| Interest expense |  | 5,775 |  |  | 3,467 |  |  | 16,980 |  |  | 9,868 |  |
| Foreign exchange loss (gain) |  | 982 |  |  | 632 |  |  | (6,372 | ) |  | (1,483 | ) |
| Other expense (income), net |  | 1,259 |  |  | (1,013 | ) |  | (2,362 | ) |  | (962 | ) |
| Income before income taxes |  | $ | 68,212 |  |  | $ | 55,523 |  |  | $ | 165,175 |  |  | $ | 160,308 |  |

[0000889331-18-000004:notes:158]
(a) Included in “Other” Operating income (loss) for the  2018  third quarter is  $11.2 million ($79.4 million year-to-date) of charges primarily related to IXYS acquisition, which include $36.9 million year-to-date of purchase accounting inventory step-up charges previously recorded during the first and second quarters of 2018, $2.5 million ($16.3 million year-to-date) in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $3.1 million ($8.7 million year-to-date) in backlog amortization costs,  $4.6 million ($9.4 million year-to-date) of severance and other restructuring charges, and $4.5 million year-to-date stock compensation expense recognized immediately upon close for converted IXYS options related to prior services periods. In addition, there were $1.0 million ($3.6 million year-to-date) of severance, other restructuring charges and acquisition-related expenses for other contemplated acquisitions which included $1.1 million year-to-date associated with the exit of the Custom business in the second quarter.


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000889331-18-000004:notes:159]
The following table sets forth the changes in shareholders’ equity for the nine months ended September 29, 2018:

[0000889331-18-000004:notes:160]
| (in thousands) |  | Littelfuse,Inc.Shareholders’Equity |  | Non-controllingInterest |  | Total |
| Balance at December 30, 2017 |  | 927,419 |  |  | 137 |  |  | 927,556 |  |
| Net income |  | 131,900 |  |  | — |  |  | 131,900 |  |
| Other comprehensive loss |  | (24,168 | ) |  | — |  |  | (24,168 | ) |
| Stock-based compensation |  | 23,153 |  |  | — |  |  | 23,153 |  |
| Withheld shares on restricted share units for withholding taxes |  | (7,252 | ) |  | — |  |  | (7,252 | ) |
| Stock options exercised |  | 25,171 |  |  | — |  |  | 25,171 |  |
| Issuance of common stock(a) |  | 472,301 |  |  | — |  |  | 472,301 |  |
| Cash dividends paid |  | (29,258 | ) |  | — |  |  | (29,258 | ) |
| Non-controlling interest |  | — |  |  | (7 | ) |  | (7 | ) |
| Balance at September 29, 2018 |  | 1,519,266 |  |  | 130 |  |  | 1,519,396 |  |

[0000889331-18-000004:notes:161]
| (a) | The issuance of common stock (2,092,491 shares) during the nine months ended September 29, 2018 relates to the acquisition of IXYS. See Note 2, Acquisitions for further discussion |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-18-000004:notes:162]
Segment Information

[0000889331-18-000004:notes:163]
The Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-18-000004:notes:164]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-18-000004:notes:165]
| • | Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, gas discharge tubes; semiconductor and power semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon carbide, metal-oxide-semiconductor field-effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including automotive electronics, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. |

[0000889331-18-000004:notes:166]
| • | Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in the automotive, commercial vehicle, and agricultural and construction equipment industries. Passenger car fuse products include fuses and fuse accessories for internal combustion engine vehicles and hybrid and electric vehicles, which are blade fuses, battery cable protectors, varistors, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle sensors designed to monitor the passenger compartment occupants and environment as well as the vehicle’s powertrain, emissions, speed and suspension. |

[0000889331-18-000004:notes:167]
| • | Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in heavy industrial applications such as mining, oil and gas, energy storage, construction, HVAC systems, elevator and other industrial equipment. |

[0000889331-18-000004:notes:168]
The third quarter of 2017 includes approximately $6.3 million of non-segment charges ($8.2 million year-to-date).  These charges were primarily attributable to acquisition-related and integration costs related to legal, accounting and other expenses associated with completed or contemplated acquisitions of approximately $4.8 million ($6.6 million year-to-date), including $1.6 million ($1.6 million year-to-date) of purchase accounting inventory charges related to the Company's 2017 acquisition of U.S. Sensor and $1.5 million ($1.5 million year-to-date) of charges related to restructuring and production transfers in our Asia operations.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-18-000004:notes:169]
Summary of Significant Accounting Policies and Other Information

[0000889331-18-000004:notes:170]
[same as prior period, unchanged from 0001437749-18-014196:notes:185]

[0000889331-18-000004:notes:171]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The Company has products in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance.

[0000889331-18-000004:notes:172]
Revenue Disaggregation

[0000889331-18-000004:notes:173]
See Note 13, Segment Information for net sales by segment and countries.

[0000889331-18-000004:notes:174]
In August 2018, the FASB issued ASU No. 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurement."  ASU 2018-13 modified the disclosure requirements in Topic 820, "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted.  The company is currently evaluating the potential effects of this guidance on its Consolidated Financial Statements.

[0000889331-18-000004:notes:175]
In August 2018, the FASB issued ASU No. 2018-14 "Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans, which amends ASC 715-20, Compensation - Retirement Benefits - Defined Benefit Plans - General. The amended guidance modifies the disclosure requirements for employers that sponsor defined benefit pension or other post-retirement plans by removing and adding certain disclosures for these plans. The eliminated disclosures include (a) the amounts in  OCI expected to be recognized in net periodic benefit costs over the next fiscal year, and (b) the effects of a one percentage point change in assumed health care cost trend rates on the net periodic benefit costs and the benefit obligation for post-retirement health care benefits. Additional disclosures include descriptions of significant gains and losses affecting the benefit obligation for the period. The adoption of this guidance will modify our disclosures but will not have a material effect on our Consolidated Financial Statements.

[0000889331-18-000004:notes:176]
In August 2018, the FASB issued ASU No. 2018-15, “Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force).” ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted. The Company is currently evaluating this guidance on its Consolidated Financial Statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000889331-18-000004:notes:177]
Shareholders’ Equity

[0000889331-18-000004:notes:178]
| (a) | The issuance of common stock (2,092,491 shares) during the nine months ended September 29, 2018 relates to the acquisition of IXYS. See Note 2, Acquisitions for further discussion. |

[0000889331-18-000004:notes:179]
As of October 29, 2018, the Company has repurchased 200,000 shares of its common stock totaling $35.9 million since the quarter ended September 29, 2018.
