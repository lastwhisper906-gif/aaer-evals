# LFUS 8-K — 0001437749-18-019099 filed 2018-10-31

## item codes, every 8-K on or before 2018-10-31

- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2018-10-31

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-019099:8k_2_02:1]
EX-99.1
2
ex_126918.htm
EXHIBIT 99.1

[0001437749-18-019099:8k_2_02:2]
ex_126918.htm

[0001437749-18-019099:8k_2_02:3]
Exhibit 99.1

[0001437749-18-019099:8k_2_02:4]
| NEWS RELEASE |  |

[0001437749-18-019099:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS

[0001437749-18-019099:8k_2_02:6]
Company delivers 8% organic revenue growth and adjusted earnings per share above high end of guidance

[0001437749-18-019099:8k_2_02:7]
CHICAGO, October 31, 2018 – Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the third quarter ended September 29, 2018:

[0001437749-18-019099:8k_2_02:8]
| ● | Net sales were $439.2 million, up 38% versus the prior year. Organic revenue growth was 8%. |

[0001437749-18-019099:8k_2_02:9]
| ● | Revenue by segment versus the prior year period: |

[0001437749-18-019099:8k_2_02:10]
|  | o | Electronics sales increased 69% (up 12% organically) |

[0001437749-18-019099:8k_2_02:11]
|  | o | Automotive sales increased 1% on flat global auto build (up 1% organically) |

[0001437749-18-019099:8k_2_02:12]
|  | o | Industrial sales were flat due to the exit of the Custom business this year (up 10% organically) |

[0001437749-18-019099:8k_2_02:13]
| ● | GAAP diluted EPS was $2.10, up 12% versus the prior year |

[0001437749-18-019099:8k_2_02:14]
| ● | Adjusted diluted EPS of $2.49 increased 17% over last year |

[0001437749-18-019099:8k_2_02:15]
| ● | GAAP effective tax rate was 21.5% and the adjusted effective tax rate was 21.0% |

[0001437749-18-019099:8k_2_02:16]
| ● | Cash flow from operations was $111.2 million and free cash flow was $95.6 million |

[0001437749-18-019099:8k_2_02:17]
| ● | The electronics segment book-to-bill ratio exiting the third quarter was 0.91 (excluding the IXYS business) |

[0001437749-18-019099:8k_2_02:18]
| ● | During October, the company completed its acquisition of Monolith Semiconductor and now owns 100% of the company |

[0001437749-18-019099:8k_2_02:19]
| ● | During October, the company purchased approximately 200,000 shares of common stock under its share repurchase program |

[0001437749-18-019099:8k_2_02:20]
"Sustained momentum in our Electronics and Industrial segments drove solid third quarter results,” said Dave Heinzmann, Littelfuse Chief Executive Officer. “We delivered a 20% adjusted operating margin and 17% adjusted earnings growth. During the quarter, we continued to capture design wins across a broad range of transportation, telecom and industrial electronics end markets, and we remain on track with the integration of the IXYS business. While we expect seasonally softer sales in our fourth quarter, our end markets continue to show long-term growth and content opportunities. We remain well positioned to deliver on our five-year double-digit sales and earnings growth strategy.”

[0001437749-18-019099:8k_2_02:21]
-more-

[0001437749-18-019099:8k_2_02:22]
For the fourth quarter of 2018*:

[0001437749-18-019099:8k_2_02:23]
| ● | Net sales are expected to be in the range of $408 to $420 million, up 36% on a reported basis and up 6% organically, at the midpoint versus the prior year quarter |

[0001437749-18-019099:8k_2_02:24]
| ● | Adjusted diluted earnings per share are expected to be in the range of $1.92 to $2.06, representing 10% growth over the prior year quarter at the midpoint |

[0001437749-18-019099:8k_2_02:25]
| ● | Adjusted effective tax rate is expected to be in the range of 20%-21% |

[0001437749-18-019099:8k_2_02:26]
For the 2018 full year, the company expects an adjusted effective tax rate of approximately 20%.

[0001437749-18-019099:8k_2_02:27]
*All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, certain purchase accounting adjustments, foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-18-019099:8k_2_02:28]
Conference Call and Webcast Information

[0001437749-18-019099:8k_2_02:29]
Littelfuse will host a conference call today, Wednesday, October 31, 2018, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0001437749-18-019099:8k_2_02:30]
About Littelfuse

[0001437749-18-019099:8k_2_02:31]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Sold in over 150 countries, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Our 12,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world – everywhere, every day. Learn more at Littelfuse.com.

[0001437749-18-019099:8k_2_02:32]
-more-

[0001437749-18-019099:8k_2_02:33]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; the integration of the recently acquired business of IXYS Corporation ("IXYS") and the risk that expected benefits, synergies and growth prospects of the acquisition of IXYS may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 30, 2017. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 30, 2017.

[0001437749-18-019099:8k_2_02:34]
Non-GAAP Financial Measures

[0001437749-18-019099:8k_2_02:35]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0001437749-18-019099:8k_2_02:36]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-18-019099:8k_2_02:37]
CONTACT: Trisha Tuntland

[0001437749-18-019099:8k_2_02:38]
Head of Investor Relations

[0001437749-18-019099:8k_2_02:39]
(773) 628-2163

[0001437749-18-019099:8k_2_02:40]
###

[0001437749-18-019099:8k_2_02:41]
LFUS-F

[0001437749-18-019099:8k_2_02:42]
LITTELFUSE, INC.

[0001437749-18-019099:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001437749-18-019099:8k_2_02:44]
|  |  | (Unaudited) |  |  |  |  |  |
| (in thousands) |  | September 29, 2018 |  |  | December 30, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 498,215 |  |  | $ | 429,676 |  |
| Short-term investments |  |  | 35 |  |  |  | 35 |  |
| Trade receivables, less allowances (September 29, 2018 - $36,392; December 30, 2017 - $27,516) |  |  | 251,644 |  |  |  | 182,699 |  |
| Inventories |  |  | 247,255 |  |  |  | 140,789 |  |
| Prepaid income taxes and income taxes receivable |  |  | 6,802 |  |  |  | 1,689 |  |
| Prepaid expenses and other current assets |  |  | 48,683 |  |  |  | 37,452 |  |
| Total current assets |  |  | 1,052,634 |  |  |  | 792,340 |  |
| Property, plant, and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 29,528 |  |  |  | 9,547 |  |
| Buildings |  |  | 119,380 |  |  |  | 86,599 |  |
| Equipment |  |  | 569,550 |  |  |  | 505,838 |  |
| Accumulated depreciation and amortization |  |  | (374,575 | ) |  |  | (351,407 | ) |
| Net property, plant, and equipment |  |  | 343,883 |  |  |  | 250,577 |  |
| Intangible assets, net of amortization |  |  | 377,151 |  |  |  | 203,850 |  |
| Goodwill |  |  | 830,354 |  |  |  | 453,414 |  |
| Investments |  |  | 29,084 |  |  |  | 10,993 |  |
| Deferred income taxes |  |  | 8,979 |  |  |  | 11,858 |  |
| Other assets |  |  | 21,401 |  |  |  | 17,070 |  |
| Total assets |  | $ | 2,663,486 |  |  | $ | 1,740,102 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 129,871 |  |  | $ | 101,844 |  |
| Accrued payroll |  |  | 52,208 |  |  |  | 49,962 |  |
| Accrued expenses |  |  | 74,084 |  |  |  | 48,994 |  |
| Accrued severance |  |  | 901 |  |  |  | 1,459 |  |
| Accrued income taxes |  |  | 36,746 |  |  |  | 16,285 |  |
| Current portion of long-term debt |  |  | 10,076 |  |  |  | 6,250 |  |
| Total current liabilities |  |  | 303,886 |  |  |  | 224,794 |  |
| Long-term debt, less current portion |  |  | 690,637 |  |  |  | 489,361 |  |
| Deferred income taxes |  |  | 49,262 |  |  |  | 17,069 |  |
| Accrued post-retirement benefits |  |  | 32,901 |  |  |  | 18,742 |  |
| Other long-term liabilities |  |  | 67,404 |  |  |  | 62,580 |  |
| Total equity |  |  | 1,519,396 |  |  |  | 927,556 |  |
| Total liabilities and equity |  | $ | 2,663,486 |  |  | $ | 1,740,102 |  |

[0001437749-18-019099:8k_2_02:45]
LITTELFUSE, INC.

[0001437749-18-019099:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME

[0001437749-18-019099:8k_2_02:47]
(Unaudited)

[0001437749-18-019099:8k_2_02:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (in thousands, except per share data) |  | September 29, 2018 |  |  | September 30, 2017 |  |  | September 29, 2018 |  |  | September 30, 2017 |  |
| Net sales |  | $ | 439,191 |  |  | $ | 317,889 |  |  | $ | 1,316,187 |  |  | $ | 916,685 |  |
| Cost of sales |  |  | 259,597 |  |  |  | 184,238 |  |  |  | 817,983 |  |  |  | 536,776 |  |
| Gross profit |  |  | 179,594 |  |  |  | 133,651 |  |  |  | 498,204 |  |  |  | 379,909 |  |
| Selling, general, and administrative expenses |  |  | 69,782 |  |  |  | 56,759 |  |  |  | 220,540 |  |  |  | 156,899 |  |
| Research and development expenses |  |  | 20,454 |  |  |  | 11,991 |  |  |  | 65,742 |  |  |  | 36,872 |  |
| Amortization of intangibles |  |  | 13,130 |  |  |  | 6,292 |  |  |  | 38,501 |  |  |  | 18,407 |  |
| Total operating expenses |  |  | 103,366 |  |  |  | 75,042 |  |  |  | 324,783 |  |  |  | 212,178 |  |
| Operating income |  |  | 76,228 |  |  |  | 58,609 |  |  |  | 173,421 |  |  |  | 167,731 |  |
| Interest expense |  |  | 5,775 |  |  |  | 3,467 |  |  |  | 16,980 |  |  |  | 9,868 |  |
| Foreign exchange loss (gain) |  |  | 982 |  |  |  | 632 |  |  |  | (6,372 | ) |  |  | (1,483 | ) |
| Other expense (income), net |  |  | 1,259 |  |  |  | (1,013 | ) |  |  | (2,362 | ) |  |  | (962 | ) |
| Income before income taxes |  |  | 68,212 |  |  |  | 55,523 |  |  |  | 165,175 |  |  |  | 160,308 |  |
| Income taxes |  |  | 14,666 |  |  |  | 12,715 |  |  |  | 33,275 |  |  |  | 29,970 |  |
| Net income |  | $ | 53,546 |  |  | $ | 42,808 |  |  | $ | 131,900 |  |  | $ | 130,338 |  |
| Income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.13 |  |  | $ | 1.88 |  |  | $ | 5.31 |  |  | $ | 5.75 |  |
| Diluted |  | $ | 2.10 |  |  | $ | 1.87 |  |  | $ | 5.23 |  |  | $ | 5.69 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 25,109 |  |  |  | 22,713 |  |  |  | 24,817 |  |  |  | 22,678 |  |
| Diluted |  |  | 25,471 |  |  |  | 22,953 |  |  |  | 25,212 |  |  |  | 22,906 |  |
| Comprehensive income |  | $ | 45,599 |  |  | $ | 42,569 |  |  | $ | 107,732 |  |  | $ | 131,574 |  |

[0001437749-18-019099:8k_2_02:49]
LITTELFUSE, INC.

[0001437749-18-019099:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001437749-18-019099:8k_2_02:51]
(Unaudited)

[0001437749-18-019099:8k_2_02:52]
|  |  | Nine Months Ended |  |
| (in thousands) |  | September 29, 2018 |  |  | September 30, 2017 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 131,900 |  |  | $ | 130,338 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 37,559 |  |  |  | 28,228 |  |
| Amortization of intangibles |  |  | 38,501 |  |  |  | 18,407 |  |
| Provision for bad debts |  |  | 83 |  |  |  | 1,586 |  |
| Deferred revenue |  |  | 3,965 |  |  |  | — |  |
| Non-cash inventory charges |  |  | 36,927 |  |  |  | 1,607 |  |
| Impairment charges |  |  | 1,125 |  |  |  | — |  |
| Loss on sale of property, plant, and equipment |  |  | 511 |  |  |  | 584 |  |
| Stock-based compensation |  |  | 23,153 |  |  |  | 12,437 |  |
| Unrealized gain on investments |  |  | (350 | ) |  |  | — |  |
| Deferred income taxes |  |  | (10,979 | ) |  |  | 1,863 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivables |  |  | (20,588 | ) |  |  | (26,792 | ) |
| Inventories |  |  | (17,624 | ) |  |  | (17,159 | ) |
| Accounts payable |  |  | 17,033 |  |  |  | 9,448 |  |
| Accrued expenses (including post-retirement) |  |  | 11,523 |  |  |  | 1,757 |  |
| Accrued payroll and severance |  |  | (5,330 | ) |  |  | (3,788 | ) |
| Accrued taxes |  |  | 14,543 |  |  |  | 7,267 |  |
| Prepaid expenses and other |  |  | (9,836 | ) |  |  | 15,537 |  |
| Net cash provided by operating activities |  |  | 252,116 |  |  |  | 181,320 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | (313,475 | ) |  |  | (38,610 | ) |
| Proceeds from maturities of short-term investments |  |  | — |  |  |  | 3,739 |  |
| Decrease in entrusted loan |  |  | — |  |  |  | 3,599 |  |
| Purchases of property, plant, and equipment |  |  | (55,946 | ) |  |  | (48,470 | ) |
| Proceeds from sale of property, plant, and equipment |  |  | 858 |  |  |  | 541 |  |
| Net cash used in investing activities |  |  | (368,563 | ) |  |  | (79,201 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 60,000 |  |  |  | 15,000 |  |
| Proceeds of term loan |  |  | 75,000 |  |  |  | — |  |
| Net proceeds from senior notes payable |  |  | 175,000 |  |  |  | 125,000 |  |
| Payments of term loan |  |  | (42,525 | ) |  |  | (4,687 | ) |
| Payments of revolving credit facility |  |  | (60,000 | ) |  |  | (112,500 | ) |
| Net proceeds (payments) related to stock-based award activities |  |  | 17,920 |  |  |  | (2,336 | ) |
| Payments of entrusted loan |  |  | — |  |  |  | (3,599 | ) |
| Debt issuance costs |  |  | (878 | ) |  |  | (2 | ) |
| Cash dividends paid |  |  | (29,258 | ) |  |  | (23,367 | ) |
| Net cash provided by (used in) financing activities |  |  | 195,259 |  |  |  | (6,491 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (10,273 | ) |  |  | 2,076 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 68,539 |  |  |  | 97,704 |  |
| Cash and cash equivalents at beginning of period |  |  | 429,676 |  |  |  | 275,124 |  |
| Cash and cash equivalents at end of period |  | $ | 498,215 |  |  | $ | 372,828 |  |

[0001437749-18-019099:8k_2_02:53]
LITTELFUSE, INC.

[0001437749-18-019099:8k_2_02:54]
NET SALES AND OPERTATING INCOME BY SEGMENT

[0001437749-18-019099:8k_2_02:55]
(Unaudited)

[0001437749-18-019099:8k_2_02:56]
|  |  | Third Quarter |  |  | Year-to-Date |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | % Growth /(Decline) |  |  | 2018 |  |  | 2017 |  |  | % Growth /(Decline) |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 296,472 |  |  | $ | 175,899 |  |  |  | 68.5 | % |  | $ | 860,240 |  |  | $ | 499,052 |  |  |  | 72.4 | % |
| Automotive |  |  | 114,416 |  |  |  | 113,797 |  |  |  | 0.5 | % |  |  | 367,718 |  |  |  | 338,094 |  |  |  | 8.8 | % |
| Industrial |  |  | 28,303 |  |  |  | 28,193 |  |  |  | 0.4 | % |  |  | 88,229 |  |  |  | 79,539 |  |  |  | 10.9 | % |
| Total net sales |  | $ | 439,191 |  |  | $ | 317,889 |  |  |  | 38.2 | % |  | $ | 1,316,187 |  |  | $ | 916,685 |  |  |  | 43.6 | % |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 72,464 |  |  | $ | 44,345 |  |  |  | 63.4 | % |  | $ | 193,739 |  |  | $ | 122,518 |  |  |  | 58.1 | % |
| Automotive |  |  | 10,863 |  |  |  | 16,821 |  |  |  | (35.4 | )% |  |  | 44,965 |  |  |  | 47,599 |  |  |  | (5.5 | )% |
| Industrial |  |  | 4,134 |  |  |  | 3,757 |  |  |  | 10.0 | % |  |  | 14,123 |  |  |  | 5,769 |  |  |  | 144.8 | % |
| Other(a) |  |  | (11,233 | ) |  |  | (6,314 | ) |  | N.M. |  |  |  | (79,406 | ) |  |  | (8,155 | ) |  | N.M. |  |
| Total operating income |  | $ | 76,228 |  |  | $ | 58,609 |  |  |  | 30.1 | % |  | $ | 173,421 |  |  | $ | 167,731 |  |  |  | 3.4 | % |
| Operating Margin |  |  | 17.4 | % |  |  | 18.4 | % |  |  |  |  |  |  | 13.2 | % |  |  | 18.3 | % |  |  |  |  |
| Interest expense |  |  | 5,775 |  |  |  | 3,467 |  |  |  |  |  |  |  | 16,980 |  |  |  | 9,868 |  |  |  |  |  |
| Foreign exchange loss (gain) |  |  | 982 |  |  |  | 632 |  |  |  |  |  |  |  | (6,372 | ) |  |  | (1,483 | ) |  |  |  |  |
| Other expense (income), net |  |  | 1,259 |  |  |  | (1,013 | ) |  |  |  |  |  |  | (2,362 | ) |  |  | (962 | ) |  |  |  |  |
| Income before income taxes |  | $ | 68,212 |  |  | $ | 55,523 |  |  |  | 22.9 | % |  | $ | 165,175 |  |  | $ | 160,308 |  |  |  | 3.0 | % |

[0001437749-18-019099:8k_2_02:57]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and other charges, restructuring costs, asset impairments, and gain and losses on asset sales. (See Supplemental Financial Information for details.)

[0001437749-18-019099:8k_2_02:58]
N.M. - Not meaningful

[0001437749-18-019099:8k_2_02:59]
|  |  | Third Quarter |  |  | Year-to-Date |  |
| (in thousands) |  | 2018 |  |  | 2017 |  |  | % Growth /(Decline) |  |  | 2018 |  |  | 2017 |  |  | % Growth /(Decline) |  |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  |  | 24.4 | % |  |  | 25.2 | % |  |  | (0.8 | )% |  |  | 22.5 | % |  |  | 24.6 | % |  |  | (2.0 | )% |
| Automotive |  |  | 9.5 | % |  |  | 14.8 | % |  |  | (5.3 | )% |  |  | 12.2 | % |  |  | 14.1 | % |  |  | (1.9 | )% |
| Industrial |  |  | 14.6 | % |  |  | 13.3 | % |  |  | 1.3 | % |  |  | 16.0 | % |  |  | 7.3 | % |  |  | 8.8 | % |

[0001437749-18-019099:8k_2_02:60]
LITTELFUSE, INC.

[0001437749-18-019099:8k_2_02:61]
SUPPLEMENTAL FINANCIAL INFORMATION

[0001437749-18-019099:8k_2_02:62]
(In millions of USD except per share amounts unaudited)

[0001437749-18-019099:8k_2_02:63]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-18 |  |  | Q3-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| GAAP diluted EPS |  | $ | 2.10 |  |  | $ | 1.87 |  |  | $ | 5.23 |  |  | $ | 5.69 |  |
| EPS impact of Non-GAAP adjustments (below) |  |  | 0.39 |  |  |  | 0.25 |  |  |  | 2.34 |  |  |  | 0.24 |  |
| Adjusted diluted EPS |  | $ | 2.49 |  |  | $ | 2.12 |  |  | $ | 7.57 |  |  | $ | 5.93 |  |

[0001437749-18-019099:8k_2_02:64]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-18 |  |  | Q3-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Acquisition related and integration costs (a) |  | $ | 2.9 |  |  | $ | 4.8 |  |  | $ | 17.0 |  |  | $ | 6.6 |  |
| Restructuring, impairment and other charges (b) |  |  | 5.2 |  |  |  | 1.5 |  |  |  | 10.2 |  |  |  | 1.5 |  |
| Amortization backlog - IXYS (c) |  |  | 3.1 |  |  |  | — |  |  |  | 8.7 |  |  |  | — |  |
| Change in control - IXYS (d) |  |  | — |  |  |  | — |  |  |  | 2.1 |  |  |  | — |  |
| Acquisition related stock-based compensation charge (e) |  |  | — |  |  |  | — |  |  |  | 4.5 |  |  |  | — |  |
| Purchase accounting inventory adjustments (f) |  |  | — |  |  |  | — |  |  |  | 36.9 |  |  |  | — |  |
| Non-GAAP adjustments to operating income |  |  | 11.2 |  |  |  | 6.3 |  |  |  | 79.4 |  |  |  | 8.1 |  |
| Non-operating foreign exchange loss (gain) |  |  | 1.0 |  |  |  | 0.6 |  |  |  | (6.4 | ) |  |  | (1.5 | ) |
| Non-GAAP adjustments to income before income taxes |  |  | 12.2 |  |  |  | 6.9 |  |  |  | 73.0 |  |  |  | 6.6 |  |
| Income taxes |  |  | 2.2 |  |  |  | 1.2 |  |  |  | 14.1 |  |  |  | 1.2 |  |
| Non-GAAP adjustments to net income |  | $ | 10.0 |  |  | $ | 5.7 |  |  | $ | 58.9 |  |  | $ | 5.4 |  |
| Total EPS impact |  | $ | 0.39 |  |  | $ | 0.25 |  |  | $ | 2.34 |  |  | $ | 0.24 |  |

[0001437749-18-019099:8k_2_02:65]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-18 |  |  | Q3-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Net sales |  | $ | 439.2 |  |  | $ | 317.9 |  |  | $ | 1,316.2 |  |  | $ | 916.7 |  |
| GAAP operating income |  | $ | 76.2 |  |  | $ | 58.6 |  |  | $ | 173.4 |  |  | $ | 167.7 |  |
| Add back non-GAAP adjustments |  |  | 11.2 |  |  |  | 6.3 |  |  |  | 79.4 |  |  |  | 8.1 |  |
| Adjusted operating income |  | $ | 87.4 |  |  | $ | 64.9 |  |  | $ | 252.8 |  |  | $ | 175.8 |  |
| Adjusted operating margin |  |  | 19.9 | % |  |  | 20.4 | % |  |  | 19.2 | % |  |  | 19.2 | % |
| Add back amortization |  |  | 10.0 |  |  |  | 6.3 |  |  |  | 29.8 |  |  |  | 18.4 |  |
| Add back depreciation |  |  | 13.1 |  |  |  | 9.7 |  |  |  | 37.6 |  |  |  | 28.2 |  |
| Adjusted EBITDA |  | $ | 110.5 |  |  | $ | 80.9 |  |  | $ | 320.2 |  |  | $ | 222.4 |  |
| Adjusted EBITDA margin |  |  | 25.2 | % |  |  | 25.4 | % |  |  | 24.3 | % |  |  | 24.3 | % |

[0001437749-18-019099:8k_2_02:66]
| Net sales reconciliation |  | Q3-18 vs. Q3-17 |  |  | YTD-18 vs. YTD-17 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |  | Total |  |
| Net sales growth |  |  | 69 | % |  |  | 1 | % |  |  | — | % |  |  | 38 | % |  |  | 44 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 57 | % |  |  | — |  |  |  | — |  |  |  | 31 | % |  |  | 32 | % |
| Divestitures |  |  | — |  |  |  | — |  |  |  | (9 | )% |  |  | (1 | )% |  |  |  |  |
| FX impact |  |  | — |  |  |  | — |  |  |  | (1 | )% |  |  | — | % |  |  | 2 | % |
| Organic net sales growth |  |  | 12 | % |  |  | 1 | % |  |  | 10 | % |  |  | 8 | % |  |  | 10 | % |

[0001437749-18-019099:8k_2_02:67]
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-18 |  |  | Q3-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Income taxes |  | $ | 14.7 |  |  | $ | 12.7 |  |  | $ | 33.3 |  |  | $ | 30.0 |  |
| Effective rate |  |  | 21.5 | % |  |  | 22.9 | % |  |  | 20.1 | % |  |  | 18.7 | % |
| Non-GAAP adjustments - income taxes |  |  | 2.2 |  |  |  | 1.3 |  |  |  | 14.1 |  |  |  | 1.2 |  |
| Adjusted income taxes |  | $ | 16.9 |  |  | $ | 14.0 |  |  | $ | 47.4 |  |  | $ | 31.2 |  |
| Adjusted effective rate |  |  | 21.0 | % |  |  | 22.4 | % |  |  | 19.9 | % |  |  | 18.7 | % |

[0001437749-18-019099:8k_2_02:68]
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-18 |  |  | Q3-17 |  |  | YTD-18 |  |  | YTD-17 |  |
| Net cash provided by operating activities |  | $ | 111.2 |  |  | $ | 87.7 |  |  | $ | 252.1 |  |  | $ | 181.3 |  |
| Less: Purchases of property, plant and equipment |  |  | (15.6 | ) |  |  | (20.2 | ) |  |  | (55.9 | ) |  |  | (48.5 | ) |
| Free cash flow |  | $ | 95.6 |  |  | $ | 67.5 |  |  | $ | 196.2 |  |  | $ | 132.8 |  |

[0001437749-18-019099:8k_2_02:69]
Note: Total will not always foot due to rounding.

[0001437749-18-019099:8k_2_02:70]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0001437749-18-019099:8k_2_02:71]
(b) $5.1 million and $0.1 million reflected in SG&A and cost of sales, respectively for the three months ended September 29, 2018 and $9.2 million and $1.0 million reflected in SG&A and cost of sales, respectively for the nine months ended September 29, 2018.

[0001437749-18-019099:8k_2_02:72]
(c) reflected in amortization of intangibles.

[0001437749-18-019099:8k_2_02:73]
(d) reflected in SG&A.

[0001437749-18-019099:8k_2_02:74]
(e) $2.4 million, $1.6 million and $0.5 million reflected in SG&A, research and development expenses and cost of sales, respectively.

[0001437749-18-019099:8k_2_02:75]
(f) reflected in cost of sales.
