# LFUS MD&A — 0000889331-18-000004


## mdna

[0000889331-18-000004:mdna:1]
[same as prior period, unchanged from 0001437749-18-014196:mdna:1]

[0000889331-18-000004:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-18-000004:mdna:3]
[same as prior period, unchanged from 0001437749-18-014196:mdna:3]

[0000889331-18-000004:mdna:4]
[same as prior period, unchanged from 0001437749-18-014196:mdna:4]

[0000889331-18-000004:mdna:5]
[same as prior period, unchanged from 0001437749-18-014196:mdna:5]

[0000889331-18-000004:mdna:6]
Founded in 1927, Littelfuse is a global manufacturer of leading technologies in circuit protection, power control and sensing. The Company has products in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy.

[0000889331-18-000004:mdna:7]
The Company maintains a network of global laboratories and engineering centers that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company conducts its business through three reportable segments: Electronics, Automotive, and Industrial. For each of these segments, the Company designs, manufactures and sells circuit protection products that protect against electrostatic discharge, power surges, short circuits, voltage spikes and other harmful occurrences; power control products that safely and efficiently control power to mitigate equipment damage, minimize electrical hazards and improve productivity; and sensor products used to identify and detect temperature, proximity, flow speed and fluid level in various applications. The Company’s customer base includes original equipment manufacturers ("OEMs"), Tier One automotive suppliers, and distributors.

[0000889331-18-000004:mdna:8]
[same as prior period, unchanged from 0001437749-18-014196:mdna:8]

[0000889331-18-000004:mdna:9]
For the third quarter of 2018, the Company recognized net sales of  $439.2 million compared to $317.9 million in the third quarter of 2017 representing an increase of $121.3 million, or 38.2%. The increase was primarily driven by the acquisition of IXYS, which added $99.7 million in sales. Additionally, net sales increased in the Electronics segment driven by higher volumes due to strong demand across various end markets and geographies within the segment.The Company recognized net income of $53.5 million, or $2.10 per diluted share, in the third quarter of 2018 compared to net income of $42.8 million, or $1.87 per diluted share in the third quarter of 2017. The increase in net income reflects operating income increases across the Electronics segment, partially offset by lower operating income in the Automotive segment.  Additionally, the per share results reflect an increase in the weighted average diluted shares outstanding of 2.1 million resulting from the shares issued in conjunction with the acquisition of IXYS.

[0000889331-18-000004:mdna:10]
Net cash provided by operating activities was $252.1 million for the nine months ended September 29, 2018 as compared to $181.3 million for the nine months ended September 30, 2017. The increase in net cash provided by operating activities reflected higher earnings and favorable working capital management, which more than offset higher payments related to acquisition and integration costs and higher cash tax payments.

[0000889331-18-000004:mdna:11]
On July 6, 2018, the Trump administration imposed Section 301 tariffs on certain products (known as List1) that are imported into the United States where the country of origin is China. Additionally, on August 23, 2018, List 2 was put into effect which imposed an additional 25% tariff to products on the list items. These tariffs primarily impact the Electronics segment and to a lesser extent our Automotive segment. The Company is currently evaluating the impact on our future results of operations.

[0000889331-18-000004:mdna:12]
In September 2018, the European Union began applying the Worldwide harmonized Light vehicles Test Procedure (WLTP) to all new car registrations, which defines a global standard for acceptable European Union wide emissions.  As a result of this incoming standard, there has been a slow down in the European passenger car market as manufacturers need to validate and test new cars under the new regulatory standards.

[0000889331-18-000004:mdna:13]
[same as prior period, unchanged from 0001437749-18-014196:mdna:13]

[0000889331-18-000004:mdna:14]
The following table summarizes the Company’s condensed consolidated results of operations for the periods presented. The third quarter of 2018 includes $11.2 million ($79.4 million year-to-date) of non-segment charges primarily related to the IXYS acquisition, which includes $36.9 million year-to-date of purchase accounting inventory step-up charges previously recorded during the first and second quarters of 2018, $2.5 million ($16.3 million year-to-date) in acquisition-related and integration costs related to legal, accounting and other expenses $3.1 million ($8.7 million year-to-date) in backlog amortization costs, $4.6 million ($9.4 million year-to-date) of severance and other restructuring charges, $4.5 million year-to-date stock compensation expense recognized immediately upon close for converted IXYS options related to prior services periods. In addition, for the three months ended September 29, 2018, there were charges of $1.0 million   ($3.6 million year-to-date) of severance, other restructuring charges and acquisition-related charges, of which $1.1 million of charges associated with the exit of the Custom business in the second quarter.

[0000889331-18-000004:mdna:15]
The third quarter of 2017 includes approximately $6.3 million of non-segment charges ($8.2 million year-to-date). These charges were primarily attributable to acquisition-related and integration costs related to legal, accounting and other expenses associated with completed or contemplated acquisitions of approximately $4.8 million ($6.6 million year-to-date), including $1.6 million ($1.6 million year-to-date) of purchase accounting inventory charges related to the Company’s 2017 acquisition of U.S. Sensor and $1.5 million ($1.5 million year-to-date) of charges related to restructuring and production transfers in our Asia operations.

[0000889331-18-000004:mdna:16]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2018 |  | 2017 |  | Change |  | %Change |  | 2018 |  | 2017 |  | Change |  | %Change |
| Net sales |  | $ | 439,191 |  |  | $ | 317,889 |  |  | $ | 121,302 |  |  | 38.2 | % |  | $ | 1,316,187 |  |  | $ | 916,685 |  |  | $ | 399,502 |  |  | 43.6 | % |
| Gross profit |  | 179,594 |  |  | 133,651 |  |  | 45,943 |  |  | 34.4 | % |  | 498,204 |  |  | 379,909 |  |  | 118,295 |  |  | 31.1 | % |
| Operating expenses |  | 103,366 |  |  | 75,042 |  |  | 28,324 |  |  | 37.7 | % |  | 324,783 |  |  | 212,178 |  |  | 112,605 |  |  | 53.1 | % |
| Operating income |  | 76,228 |  |  | 58,609 |  |  | 17,619 |  |  | 30.1 | % |  | 173,421 |  |  | 167,731 |  |  | 5,690 |  |  | 3.4 | % |
| Income before income taxes |  | 68,212 |  |  | 55,523 |  |  | 12,689 |  |  | 22.9 | % |  | 165,175 |  |  | 160,308 |  |  | 4,867 |  |  | 3.0 | % |
| Income taxes |  | 14,666 |  |  | 12,715 |  |  | 1,951 |  |  | 15.3 | % |  | 33,275 |  |  | 29,970 |  |  | 3,305 |  |  | 11.0 | % |
| Net income |  | $ | 53,546 |  |  | $ | 42,808 |  |  | $ | 10,738 |  |  | 25.1 | % |  | $ | 131,900 |  |  | $ | 130,338 |  |  | $ | 1,562 |  |  | 1.2 | % |

[0000889331-18-000004:mdna:17]
[same as prior period, unchanged from 0001437749-18-014196:mdna:17]

[0000889331-18-000004:mdna:18]
Net sales increased $121.3 million or 38.2%, for the third quarter of 2018 compared to the third quarter of 2017 with increases of $99.7 million resulting from incremental net sales related to the IXYS acquisition partially offset by $1.5 million of unfavorable changes in foreign exchange rates. The remaining increase in net sales was driven by higher volume primarily in the Electronics businesses and higher volume in the Industrial segment.

[0000889331-18-000004:mdna:19]
Net sales for the first nine months of 2018 increased $399.5 million, or 43.6%, compared to the first nine months of 2017 with increases of $286.2 million and $6.5 million resulting from incremental net sales related to the IXYS and U.S. Sensor acquisitions, respectively and $20.0 million of favorable changes in foreign exchange rates. The remaining increase in net sales was driven by higher volume across all three segments.

[0000889331-18-000004:mdna:20]
[same as prior period, unchanged from 0001437749-18-014196:mdna:20]

[0000889331-18-000004:mdna:21]
Gross profit was $179.6 million, or 40.9% of net sales, in the third quarter of 2018, compared to $133.7 million, or 42.0% of net sales, in the third quarter of 2017. The increase in gross profit reflects the impact of the IXYS acquisition and volume growth in Electronics and Industrial segments. The decrease in gross margin is primarily due to unfavorable mix in products from the IXYS acquisition, which historically has lower gross margin.

[0000889331-18-000004:mdna:22]
Gross profit was $498.2 million, or 37.9% of net sales, in the first nine months of 2018, compared to $379.9 million, or 41.4% of net sales in the first nine months of 2017. The increase in gross profit reflects the IXYS acquisition and volume growth and expense leverage across all segments. The decrease in gross margin is primarily due to the purchase accounting inventory charges of $36.9 million which negatively impacted gross margin by 2.8 percentage points.

[0000889331-18-000004:mdna:23]
[same as prior period, unchanged from 0001437749-18-014196:mdna:23]

[0000889331-18-000004:mdna:24]
Total operating expenses were $103.4 million, or 23.5% of net sales, for the third quarter of 2018 compared to $75.0 million, or 23.6% of net sales, for the third quarter of 2017. The increase in operating expenses of $28.3 million is primarily due to incremental operating expenses related to the IXYS acquisition and an increase of $6.8 million in amortization expense resulting from the acquisition of IXYS.

[0000889331-18-000004:mdna:25]
Total operating expense for the first nine months of 2018 was $324.8 million, or 24.7% of net sales, compared to $212.2 million, or 23.1% of net sales, for the first nine months of 2017. The increase in operating expenses of $112.6 million is primarily due to incremental operating expenses related to the IXYS and U.S. Sensor acquisitions, an increase in amortization expense of $20.1 million resulting from the acquisition of IXYS as well as higher acquisition-related and integration costs of $11.9 million. Total operating expenses as a percent of net sales increased from 23.1% for the first nine months of 2017 to 24.7% for the first nine months of 2018 primarily due to the higher amortization expense and acquisition-related and integration charges noted above.

[0000889331-18-000004:mdna:26]
[same as prior period, unchanged from 0001437749-18-014196:mdna:26]

[0000889331-18-000004:mdna:27]
Operating income was $76.2 million, an increase of $17.6 million, or 30.1%, for the third quarter of 2018 compared to $58.6 million for the third quarter of 2017. The increase in operating income is due to the acquisition of IXYS and higher volume due to the strong demand across various end markets and geographies within our Electronics segment that was partially offset by lower operating income in the Automotive segment. Operating margins decreased from 18.4% in the third quarter of 2017 to 17.4% in the third quarter of 2018 driven by higher amortization expense, restructuring and integration charges.

[0000889331-18-000004:mdna:28]
Operating income for the first nine months of 2018 was $173.4 million compared to $167.7 million for the first nine months of 2017. The increase in operating income is primarily due to the acquisition of IXYS and higher volume in the electronics and industrial businesses partially offset by $36.9 million of purchase accounting inventory charges, higher acquisition and integration charges and amortization expense. Operating margins decreased from 18.3% to 13.2% in 2018 driven by the purchase accounting inventory charges, higher amortization expense and acquisition and integration charges that negatively impacted margins by 2.8%, 1.5% and 1.2%, respectively.

[0000889331-18-000004:mdna:29]
[same as prior period, unchanged from 0001437749-18-014196:mdna:29]

[0000889331-18-000004:mdna:30]
Income before income taxes was $68.2 million, or 15.5% of net sales, for the third quarter of 2018 compared to $55.5 million, or 17.5% of net sales, for the third quarter of 2017.  In addition to the factors impacting comparative results for operating income discussed above, income before taxes was impacted by increased interest expense of $2.3 million associated with increased borrowings for the IXYS acquisition and other expense of $1.3 million as a result of unrealized investment losses associated with our equity investments during the three months ended September 29, 2018 as compared to other income of $1.0 million in the three months ended September 30, 2017

[0000889331-18-000004:mdna:31]
Income before income taxes for the first nine months of 2018 was $165.2 million, or 12.5% of net sales compared to $160.3 million, or 17.5% of net sales, for the first nine months of 2017. In addition to the factors impacting comparative results for operating income discussed above income before income taxes was favorably impacted by increases in foreign exchange gains of $4.9 million and increases in other income of $1.4 million primarily due to unrealized investment gains in our equity investments partially offset by higher interest expense of $7.1 million mainly resulting from increased borrowings for the IXYS acquisition.

[0000889331-18-000004:mdna:32]
[same as prior period, unchanged from 0001437749-18-014196:mdna:32]

[0000889331-18-000004:mdna:33]
Income tax expense was $14.7 million, or an effective tax rate of 21.5%, for the third quarter of 2018 compared to $12.7 million, or an effective tax rate of 22.9%, for the third quarter of 2017.  The effective tax rate for the third quarter of 2018 was lower than the effective tax rate for the third quarter of 2017 primarily due to a third quarter 2017 accrual of taxes on certain undistributed earnings of non-US affiliates, offset in part by the impact of U.S. tax reform and the acquisition of IXYS. The effective tax rate for the third quarter of 2017 was lower than the then applicable 35% U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-18-000004:mdna:34]
Income tax expense for the first nine months of 2018 was $33.3 million, or an effective tax rate of 20.1%, compared to income tax expense of $30.0 million, or an effective tax rate of 18.7%, for the first nine months of 2017.  The effective tax rate for the first nine months of 2018 was higher than the effective tax rate for the first nine months of 2017 primarily due to the impact of U.S. tax reform and the acquisition of IXYS. The effective tax rate for the first nine months of 2017 was lower than the then applicable 35% U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-18-000004:mdna:35]
[same as prior period, unchanged from 0001437749-18-014196:mdna:35]

[0000889331-18-000004:mdna:36]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 13, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-18-000004:mdna:37]
[same as prior period, unchanged from 0001437749-18-014196:mdna:37]

[0000889331-18-000004:mdna:38]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2018 |  | 2017 |  | Change |  | %Change |  | 2018 |  | 2017 |  | Change |  | %Change |
| Electronics |  | $ | 296,472 |  |  | $ | 175,899 |  |  | $ | 120,573 |  |  | 68.5 | % |  | $ | 860,240 |  |  | $ | 499,052 |  |  | $ | 361,188 |  |  | 72.4 | % |
| Automotive |  | 114,416 |  |  | 113,797 |  |  | 619 |  |  | 0.5 | % |  | 367,718 |  |  | 338,094 |  |  | 29,624 |  |  | 8.8 | % |
| Industrial |  | 28,303 |  |  | 28,193 |  |  | 110 |  |  | 0.4 | % |  | 88,229 |  |  | 79,539 |  |  | 8,690 |  |  | 10.9 | % |
| Total |  | $ | 439,191 |  |  | $ | 317,889 |  |  | $ | 121,302 |  |  | 38.2 | % |  | $ | 1,316,187 |  |  | $ | 916,685 |  |  | $ | 399,502 |  |  | 43.6 | % |

[0000889331-18-000004:mdna:39]
[same as prior period, unchanged from 0001437749-18-014196:mdna:39]

[0000889331-18-000004:mdna:40]
The Electronics segment net sales increased $120.6 million, or 68.5%, in the third quarter of 2018 compared to the third quarter of 2017 due to incremental net sales related to the IXYS acquisition of $99.7 million and the strong demand across various end markets and geographies within our Electronics segment.

[0000889331-18-000004:mdna:41]
The Electronics segment net sales increased $361.2 million, or 72.4%, in the first nine months of 2018 compared to the first nine months of 2017 due to incremental net sales related to the IXYS and U.S. Sensor acquisitions of $286.2 million and $6.5 million, respectively, higher volume driven by the continued strong demand across various end markets and geographies within our Electronics segment and favorable foreign exchange impacts of $7.9 million.

[0000889331-18-000004:mdna:42]
[same as prior period, unchanged from 0001437749-18-014196:mdna:42]

[0000889331-18-000004:mdna:43]
The Automotive segment net sales increased $0.6 million, or 0.5%, in the third quarter of 2018 compared to the third quarter of 2017 due to increased volume in automotive sensors and commercial vehicle businesses offset by lower volumes in the Passenger Car Products and unfavorable changes in foreign exchange rates of $0.8 million.

[0000889331-18-000004:mdna:44]
The Automotive segment net sales increased $29.6 million, or 8.8%, in the first nine months of 2018 compared to the first nine months of 2017 due to increased volume across all businesses with the commercial vehicle and sensor businesses having the most growth and favorable changes in foreign exchange rates of $11.6 million.

[0000889331-18-000004:mdna:45]
[same as prior period, unchanged from 0001437749-18-014196:mdna:45]

[0000889331-18-000004:mdna:46]
The Industrial segment net sales increased slightly by $0.1 million, or 0.4%, in the third quarter of 2018 compared to the third quarter of 2017 primarily due to higher volume across the power fuse and relay businesses despite the full exit of the Custom business during the second quarter of 2018.

[0000889331-18-000004:mdna:47]
The Industrial segment net sales increased $8.7 million, or 10.9% in the first nine months of 2018 compared to the first nine months of 2017 due to higher volumes primarily in the power fuse and relay operations.

[0000889331-18-000004:mdna:48]
[same as prior period, unchanged from 0001437749-18-014196:mdna:48]

[0000889331-18-000004:mdna:49]
[same as prior period, unchanged from 0001437749-18-014196:mdna:49]

[0000889331-18-000004:mdna:50]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2018 |  | 2017 |  | Change |  | %Change |  | 2018 |  | 2017 |  | Change |  | %Change |
| Americas |  | $ | 156,852 |  |  | $ | 115,499 |  |  | $ | 41,353 |  |  | 35.8 | % |  | $ | 442,200 |  |  | $ | 328,563 |  |  | $ | 113,637 |  |  | 34.6 | % |
| Europe |  | 89,090 |  |  | 63,365 |  |  | 25,725 |  |  | 40.6 | % |  | 297,884 |  |  | 182,534 |  |  | 115,350 |  |  | 63.2 | % |
| Asia-Pacific |  | 193,249 |  |  | 139,025 |  |  | 54,224 |  |  | 39.0 | % |  | 576,103 |  |  | 405,588 |  |  | 170,515 |  |  | 42.0 | % |
| Total |  | $ | 439,191 |  |  | $ | 317,889 |  |  | $ | 121,302 |  |  | 38.2 | % |  | $ | 1,316,187 |  |  | $ | 916,685 |  |  | $ | 399,502 |  |  | 43.6 | % |

[0000889331-18-000004:mdna:51]
[same as prior period, unchanged from 0001437749-18-014196:mdna:51]

[0000889331-18-000004:mdna:52]
Net sales in the Americas increased $41.4 million, or 35.8%, in the third quarter of 2018 compared to the third quarter of 2017 driven by incremental net sales related to the IXYS acquisitions of $25.0 million, continued strong volumes in the passives, electronic sensors, auto sensors, commercial vehicles, and relays partially offset by lower volumes in passenger car and exit from the Custom business.

[0000889331-18-000004:mdna:53]
Net sales in the Americas increased $113.6 million, or 34.6%, in the first nine months of 2018 compared to the first nine months of 2017 driven by incremental net sales related to the IXYS and U.S. Sensor acquisitions of $68.9 million and $5.5 million, respectively, increased volume in the Electronics, Automotive and Industrial segments and favorable foreign currency effects of $0.6 million.

[0000889331-18-000004:mdna:54]
[same as prior period, unchanged from 0001437749-18-014196:mdna:54]

[0000889331-18-000004:mdna:55]
European net sales increased $25.7 million, or 40.6%, in the third quarter of 2018 compared to the third quarter of 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $31.0 million partially offset by lower passenger car volumes in the Automotive segment and unfavorable foreign currency effects of $0.8 million.

[0000889331-18-000004:mdna:56]
European net sales increased $115.4 million, or 63.2%, in the first nine months of 2018 compared to the first nine months of 2017 .  The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $86.7 million with strong growth especially in the passive and sensor businesses in the Electronics segment and continued growth in commercial vehicle, automotive sensor businesses as well as favorable foreign currency effects of $14.4 million partially offset by lower volumes in the passenger car business.

[0000889331-18-000004:mdna:57]
[same as prior period, unchanged from 0001437749-18-014196:mdna:57]

[0000889331-18-000004:mdna:58]
Asia-Pacific net sales increased $54.2 million, or 39.0%, in the third quarter of 2018 compared to the third quarter of 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $43.7 million and higher volumes in the Electronics passives and sensor businesses partially offset by unfavorable foreign currency effects of $0.6 million.

[0000889331-18-000004:mdna:59]
Asia-Pacific net sales increased $170.5 million, or 42.0%, in the first nine months of 2018 compared to the first nine months of 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $130.6 million and higher volumes in the Electronics and Automotive segments as well as favorable foreign currency effects of $5.0 million.

[0000889331-18-000004:mdna:60]
[same as prior period, unchanged from 0001437749-18-014196:mdna:60]

[0000889331-18-000004:mdna:61]
[same as prior period, unchanged from 0001437749-18-014196:mdna:61]

[0000889331-18-000004:mdna:62]
Revolving Credit Facility/Term Loan

[0000889331-18-000004:mdna:63]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-18-000004:mdna:64]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million

[0000889331-18-000004:mdna:65]
occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. In addition to the quarterly principal payments, the Company paid $35.0 million of additional principal on the term loan during the nine months ended September 29, 2018.

[0000889331-18-000004:mdna:66]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.49% at September 29, 2018.

[0000889331-18-000004:mdna:67]
As of September 29, 2018, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At September 29, 2018, the Company was in compliance with all covenants under the Credit Agreement. Further information regarding the Company’s credit agreement is provided in Note 5, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-18-000004:mdna:68]
[same as prior period, unchanged from 0001437749-18-014196:mdna:66]

[0000889331-18-000004:mdna:69]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-18-000004:mdna:70]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-18-000004:mdna:71]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 5, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-18-000004:mdna:72]
[same as prior period, unchanged from 0001437749-18-014196:mdna:70]

[0000889331-18-000004:mdna:73]
During July 2018, the Company’s Board of Directors approved an increase in the quarterly cash dividend from $0.37 to $0.43. This equates to an annualized dividend of $1.72 per share.

[0000889331-18-000004:mdna:74]
[same as prior period, unchanged from 0001437749-18-014196:mdna:72]

[0000889331-18-000004:mdna:75]
|  |  | First Nine Months |
| (in thousands) |  | 2018 |  | 2017 |
| Net cash provided by operating activities |  | $ | 252,116 |  |  | $ | 181,320 |  |
| Net cash used in investing activities |  | (368,563 | ) |  | (79,201 | ) |
| Net cash provided by (used in) financing activities |  | 195,259 |  |  | (6,491 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (10,273 | ) |  | 2,076 |  |
| Increase in cash and cash equivalents |  | 68,539 |  |  | 97,704 |  |
| Cash and cash equivalents at beginning of period |  | 429,676 |  |  | 275,124 |  |
| Cash and cash equivalents at end of period |  | $ | 498,215 |  |  | $ | 372,828 |  |

[0000889331-18-000004:mdna:76]
[same as prior period, unchanged from 0001437749-18-014196:mdna:74]

[0000889331-18-000004:mdna:77]
[same as prior period, unchanged from 0001437749-18-014196:mdna:75]

[0000889331-18-000004:mdna:78]
Net cash provided by operating activities was $252.1 million for the  first nine months of 2018, compared to $181.3 million during the nine months September 30, 2017. The increase in net cash provided by operating activities was primarily driven by higher earnings and favorable working capital management that more than offset higher payments related to acquisition and integration costs and higher cash taxes.

[0000889331-18-000004:mdna:79]
[same as prior period, unchanged from 0001437749-18-014196:mdna:77]

[0000889331-18-000004:mdna:80]
Net cash used in investing activities was $368.6 million for the nine months ended September 29, 2018, compared to $79.2 million during the nine months ended September 30, 2017. Net cash used for the acquisition of IXYS was $306.5 million for the nine months ended September 29, 2018  as compared to net cash used for the acquisition of a majority stake in Monolith of $38.6 million for the nine months ended September 30, 2017. Capital expenditures were $55.9 million, representing an increase of $7.5 million compared to 2017.

[0000889331-18-000004:mdna:81]
[same as prior period, unchanged from 0001437749-18-014196:mdna:79]

[0000889331-18-000004:mdna:82]
Net cash provided by financing activities was $195.3 million for the nine months ended September 29, 2018 compared to net cash used in financing activities of $6.5 million for the nine months ended September 30, 2017. The Company had $310.0 million of proceeds from the credit facility, term loan and senior notes payable partially offset by payments $102.5 million on the credit facility and term loan during the nine months ended September 29, 2018 as compared to $140.0 million of proceeds from the credit facility and senior notes payable and $117.2 million of payments on the credit facility and term loan during the nine months September 30, 2017. Additionally, dividends paid increased $5.9 million from $23.4 million in 2017 to $29.3 million for the nine months ended September 29, 2018.

[0000889331-18-000004:mdna:83]
[same as prior period, unchanged from 0001437749-18-014196:mdna:81]

[0000889331-18-000004:mdna:84]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 (“Share Repurchase Program”). The Company did not repurchase any shares of its common stock during the third quarter of 2018.

[0000889331-18-000004:mdna:85]
As of October 29, 2018, the Company has repurchased 200,000 shares of its common stock totaling $35.9 million since the quarter ended September 29, 2018.

[0000889331-18-000004:mdna:86]
[same as prior period, unchanged from 0001437749-18-014196:mdna:83]

[0000889331-18-000004:mdna:87]
As of  September 29, 2018, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-18-000004:mdna:88]
[same as prior period, unchanged from 0001437749-18-014196:mdna:85]

[0000889331-18-000004:mdna:89]
[same as prior period, unchanged from 0001437749-18-014196:mdna:86]

[0000889331-18-000004:mdna:90]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 30, 2017. During the three months ended September 29,2018, there were no significant changes in the application of critical accounting policies.

[0000889331-18-000004:mdna:91]
[same as prior period, unchanged from 0001437749-18-014196:mdna:88]

[0000889331-18-000004:mdna:92]
In February 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the first quarter of 2019. The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has not yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and  lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.

[0000889331-18-000004:mdna:93]
[same as prior period, unchanged from 0001437749-18-014196:mdna:90]

[0000889331-18-000004:mdna:94]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 2018-02 will be effective in the first quarter of 2019; however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 2018-02 on the Consolidated Financial Statements.

[0000889331-18-000004:mdna:95]
In August 2018, the FASB issued ASU No. 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurement."  ASU 2018-13 modified the disclosure requirements in Topic 820, "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted.  The company is currently evaluating the potential effects of this guidance on its Consolidated Financial Statements.

[0000889331-18-000004:mdna:96]
In August 2018, the FASB issued ASU No. 2018-14 "Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans, which amends ASC 715-20, Compensation - Retirement Benefits - Defined Benefit Plans - General. The amended guidance modifies the disclosure requirements for employers that sponsor defined benefit pension or other post-retirement plans by removing and adding certain disclosures for these plans. The eliminated disclosures include (a) the amounts in accumulated other comprehensive income ("OCI") expected to be recognized in net periodic benefit costs over the next fiscal year, and (b) the effects of a one percentage point change in assumed health care cost trend rates on the net periodic benefit costs and the benefit obligation for post-retirement health care benefits. Additional disclosures include descriptions of significant gains and losses affecting the benefit obligation for the period. The adoption of this guidance will modify our disclosures but will not have a material effect on our Consolidated Financial Statements.

[0000889331-18-000004:mdna:97]
In August 2018, the FASB issued ASU No. 2018-15, “Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force).” ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).   The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted. The Company is currently evaluating this guidance on its Consolidated Financial Statements.
