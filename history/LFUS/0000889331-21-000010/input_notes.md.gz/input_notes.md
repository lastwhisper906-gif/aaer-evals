# LFUS notes — 0000889331-21-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000889331-21-000010:notes:1]
Portions of the Littelfuse, Inc. Proxy Statement for the 2021 Annual Meeting of Stockholders (the “Proxy Statement”) are incorporated by reference into Part III of this Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-21-000010:notes:2]
Summary of Significant Accounting Policies and Other Information

[0000889331-21-000010:notes:3]
Nature of Operations

[0000889331-21-000010:notes:4]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The company's  products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

[0000889331-21-000010:notes:5]
Fiscal Year

[0000889331-21-000010:notes:6]
References herein to “2020”, “fiscal 2020” or “fiscal year 2020” refer to the fiscal year ended December 26, 2020. References herein to “2019”, “fiscal 2019” or “fiscal year 2019” refer to the fiscal year ended December 28, 2019. References herein to “2018”, “fiscal 2018” or “fiscal year 2018” refer to the fiscal year ended December 29, 2018. The Company operates on a 52-53 week fiscal year (4-4-5 basis) ending on the Saturday closest to December 31.

[0000889331-21-000010:notes:7]
Basis of Presentation

[0000889331-21-000010:notes:8]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The Company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America and include the assets, liabilities, sales and expenses of all wholly-owned subsidiaries and majority-owned subsidiaries over which the Company exercises control.

[0000889331-21-000010:notes:9]
Use of Estimates

[0000889331-21-000010:notes:10]
The process of preparing financial statements in conformity with generally accepted accounting principles in the United States of America requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The Company evaluates and updates its assumptions and estimates on an ongoing basis and may employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0000889331-21-000010:notes:11]
Reclassification

[0000889331-21-000010:notes:12]
For fiscal year ended December 26, 2020, the Company began presenting restructuring, impairment and other charges as a separate caption in the Consolidated Statements of Net Income. Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements. The impact of this reclassification resulted in a decrease in cost of sales, selling, general and administrative expenses, and research and development expenses with the corresponding change reported in restructuring, impairment and other charges. As a result, costs of sales, selling, general and administrative expenses, and research and development expenses were reduced by $4.8 million, $7.6 million, and $0.5 million, respectively, for fiscal year 2019 and costs of sales and selling, general and administrative expenses were reduced by $0.9 million, $11.7 million, respectively for fiscal year 2018. This reclassification had no effect on the previously reported operating income and net income for the fiscal years ended December 28, 2019 and December 29, 2018.

[0000889331-21-000010:notes:13]
Cash Equivalents

[0000889331-21-000010:notes:14]
All highly liquid investments, with an original maturity of three months or less when purchased, are considered to be cash equivalents. The Company maintains a multi-currency notional cash pool for our participating entities with a third-party bank provider. Actual cash balances are not physically converted and are not commingled between participating legal entities. The Company will classify any overdraft balances within accrued expenses and other current liabilities on the accompanying consolidated balance sheets.

[0000889331-21-000010:notes:15]
Short-Term and Long-Term Investments

[0000889331-21-000010:notes:16]
As of December 26, 2020, the Company has an investment in Polytronics Technology Corporation Ltd. (“Polytronics”). The Company’s Polytronics shares held at the end of fiscal 2020 and 2019 represent approximately 7.2% of total Polytronics shares

[0000889331-21-000010:notes:17]
outstanding, respectively. The Polytronics investment is carried at fair value. The fair value of the Polytronics investment was €15.7 million (approximately $19.2 million) at December 26, 2020 and €11.6 million (approximately $12.8 million) at December 28, 2019.

[0000889331-21-000010:notes:18]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The Company owns 45% of the outstanding equity of Powersem GmbH, a module manufacturer based in Germany, approximately 19% of the outstanding equity of EB Tech Ltd., a company with expertise in radiation technology based in South Korea, and approximately 24% of the outstanding common shares of Automated Technology, Inc., a supplier located in the Philippines that provides assembly and test services. All equity-level investments are less than majority owned. The Company recognized no gains and losses and $0.6 million of losses from its equity method investments for the fiscal years ended December 26, 2020 and December 28, 2019, respectively. The balance of these equity method investments was $11.4 million and $11.1 million as of the fiscal years ended December 26, 2020 and December 28, 2019, respectively. See Note 18, Related Party Transactions, for further discussion.

[0000889331-21-000010:notes:19]
The balance of the Company's investments accounted for under the cost method was $0.5 million and $0.4 million for the fiscal years ended December 26, 2020 and December 28, 2019, respectively. During the twelve months ended December 26, 2020 and December 28, 2019, the Company recorded impairment charges of $0.1 million and $7.3 million, respectively, in Other income, net in the Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value. See Note 10, Fair Value of Assets and Liabilities, for further discussion.

[0000889331-21-000010:notes:20]
The Company has investments related to its non-qualified Supplemental Retirement and Savings Plan. The Company maintains accounts for participants through which participants make investment elections. The investment securities are subject to the claims of the Company’s creditors. The investment securities are all mutual funds. The investment securities are measured at net asset value. As of December 26, 2020 and December 28, 2019, the investment securities balance was $13.2 million and $10.5 million, respectively, related to the plan and are included in Other assets on the Consolidated Balance Sheets.

[0000889331-21-000010:notes:21]
Trade Receivables

[0000889331-21-000010:notes:22]
The Company performs credit evaluations of customers’ financial condition and generally does not require collateral. Credit losses are provided for in the financial statements based upon specific knowledge of a customer’s inability to meet its financial obligations to the Company. Historically, credit losses have consistently been within management’s expectations and have not been a material amount. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0000889331-21-000010:notes:23]
The Company also maintains allowances against trade receivables for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.

[0000889331-21-000010:notes:24]
Inventories

[0000889331-21-000010:notes:25]
Inventories are stated at the lower of cost or net realizable value, which approximates current replacement cost. Cost is principally determined using the first-in, first-out method. The Company maintains excess and obsolete reserves against inventory to reduce the carrying value to the expected net realizable value. These reserves are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

[0000889331-21-000010:notes:26]
Property, Plant, and Equipment

[0000889331-21-000010:notes:27]
Land, buildings, and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of up to 21 years for buildings, three to ten years for equipment, seven years for furniture and fixtures, five years for tooling and three years for computer equipment. Leasehold improvements are depreciated over the lesser of their useful life or the lease term. Maintenance and repair costs are charged to expense as incurred. Major overhauls that extend the useful lives of existing assets are capitalized.

[0000889331-21-000010:notes:28]
Goodwill

[0000889331-21-000010:notes:29]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.

[0000889331-21-000010:notes:30]
During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition, during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling an existing program. As of December 26, 2020, the automotive sensors reporting unit had $9.8 million of remaining goodwill.

[0000889331-21-000010:notes:31]
The Company compares each reporting unit’s fair value, estimated based on comparable company market valuations and expected future discounted cash flows to be generated by the reporting unit, to its carrying value. The results of the annual goodwill impairment test as of September 27, 2020 indicated that the estimated fair values for each of the seven reporting units exceeded their respective carrying values. As of the most recent annual test conducted on September 27, 2020, the Company noted that the excess of fair value over the carrying value, was 218%, 44%, 160%, 137%, 59%, 139%, and 210% for its reporting units; Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, Automotive Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test. See Note 5, Goodwill and Other Intangible Assets, for additional information.

[0000889331-21-000010:notes:32]
The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments as of December 26, 2020, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value.

[0000889331-21-000010:notes:33]
Long-Lived Assets

[0000889331-21-000010:notes:34]
Customer relationships, trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of 5 to 20 years. Patents, licenses and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of 5 to 17 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of 4 to 10 years.  Land use rights are amortized using the straight-line method over 50 years which is the term of the land use rights.

[0000889331-21-000010:notes:35]
The Company assesses potential impairments to its long-lived assets if events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. An impaired asset is written down to its estimated fair value based upon the most recent information available. Estimated fair market value is generally measured by discounting estimated future cash flows. Long-lived assets, other than goodwill and other intangible assets, that are held for sale are recorded at the lower of carrying value or the fair market value less the estimated cost to sell.

[0000889331-21-000010:notes:36]
Environmental Liabilities

[0000889331-21-000010:notes:37]
Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, the Company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0000889331-21-000010:notes:38]
Pension and Other Post-retirement Benefits

[0000889331-21-000010:notes:39]
The Company records annual income and expense amounts relating to its pension and post-retirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets, but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording

[0000889331-21-000010:notes:40]
its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors.

[0000889331-21-000010:notes:41]
Revenue Recognition

[0000889331-21-000010:notes:42]
Revenue Disaggregation

[0000889331-21-000010:notes:43]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 26, 2020 and December 28, 2019:

[0000889331-21-000010:notes:44]
|  |  | Fiscal Year Ended December 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 522,352 |  |  | $ | — |  |  | $ | — |  |  | $ | 522,352 |  |
| Electronics – Passive Products and Sensors |  | 415,410 |  |  | — |  |  | — |  |  | 415,410 |  |
| Passenger Car Products |  | — |  |  | 200,455 |  |  | — |  |  | 200,455 |  |
| Commercial Vehicle Products |  | — |  |  | 101,324 |  |  | — |  |  | 101,324 |  |
| Automotive Sensors |  | — |  |  | 93,985 |  |  | — |  |  | 93,985 |  |
| Industrial Products |  | — |  |  | — |  |  | 112,169 |  |  | 112,169 |  |
| Total |  | $ | 937,762 |  |  | $ | 395,764 |  |  | $ | 112,169 |  |  | $ | 1,445,695 |  |

[0000889331-21-000010:notes:45]
|  |  | Fiscal Year Ended December 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 539,820 |  |  | $ | — |  |  | $ | — |  |  | $ | 539,820 |  |
| Electronics – Passive Products and Sensors |  | 421,260 |  |  | — |  |  | — |  |  | 421,260 |  |
| Passenger Car Products |  | — |  |  | 218,560 |  |  | — |  |  | 218,560 |  |
| Commercial Vehicle Products |  | — |  |  | 111,972 |  |  | — |  |  | 111,972 |  |
| Automotive Sensors |  | — |  |  | 98,001 |  |  | — |  |  | 98,001 |  |
| Industrial Products |  | — |  |  | — |  |  | 114,260 |  |  | 114,260 |  |
| Total |  | $ | 961,080 |  |  | $ | 428,533 |  |  | $ | 114,260 |  |  | $ | 1,503,873 |  |

[0000889331-21-000010:notes:46]
During the fourth quarter of 2020, the Company transferred a business previously reported within the Electronics-Semiconductor reporting unit to the Electronics-Passive Products and Sensors reporting units. This transfer aligns with how this business will be managed and is complimentary with existing electronics passive products and sensors and markets into which they sell. The 2019 disaggregated revenue table has been reclassified to reflect this change. This transfer had no impact to the Electronics segment results.

[0000889331-21-000010:notes:47]
See Note 16, Segment Information, for net sales by segment and countries.

[0000889331-21-000010:notes:48]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-21-000010:notes:49]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-21-000010:notes:50]
Revenue and Billing

[0000889331-21-000010:notes:51]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0000889331-21-000010:notes:52]
Ship and Debit Program

[0000889331-21-000010:notes:53]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-21-000010:notes:54]
Return to Stock

[0000889331-21-000010:notes:55]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-21-000010:notes:56]
Volume Rebates

[0000889331-21-000010:notes:57]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-21-000010:notes:58]
Allowance for Doubtful Accounts

[0000889331-21-000010:notes:59]
The Company currently measures the expected credit losses based on our historical credit loss experience. The Company has not experienced significant recent or historical credit losses and is not forecasting any significant credit losses which would require adjustments to our methodology. If current conditions and supportable forecasts indicate that our historical loss experience is not reasonable and no longer supportable, the Company may adjust its historical credit loss experience and to reflect these conditions and forecasts. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also analyzes all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and historical collection and loss experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-21-000010:notes:60]
As of December 26, 2020 and December 28, 2019, the Company’s allowance for doubtful accounts was $1.4 million and $1.3 million, respectively. Additionally, the Company had less than $1.0 million of trade receivables greater than 90 days past due as of December 26, 2020 and December 28, 2019, respectively.

[0000889331-21-000010:notes:61]
Advertising Costs

[0000889331-21-000010:notes:62]
The Company expenses advertising costs as incurred, which amounted to $2.1 million, $2.7 million, and $2.8 million in fiscal years 2020, 2019 and 2018, respectively, and are included as a component of selling, general, and administrative expenses.

[0000889331-21-000010:notes:63]
Shipping and Handling Fees and Costs

[0000889331-21-000010:notes:64]
Amounts billed to customers related to shipping and handling is classified as revenue. Costs incurred for shipping and handling of $11.1 million, $11.0 million, and $12.3 million in fiscal years 2020, 2019, and 2018, respectively, are classified in selling, general, and administrative expenses.

[0000889331-21-000010:notes:65]
Foreign Currency Translation / Remeasurement

[0000889331-21-000010:notes:66]
The Company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. Adjustments from the translation process are recognized in “Shareholders’ equity” as a component of “Accumulated other comprehensive income/ (loss).” The amount of foreign currency gain or loss from remeasurement recognized in the income statement was a gain of $14.9 million in fiscal year 2020, a loss of $5.2 million in fiscal year 2019, and a gain of $0.9 million in fiscal year 2018.

[0000889331-21-000010:notes:67]
Stock-Based Compensation

[0000889331-21-000010:notes:68]
The Company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as operating cash flows. See Note 12, Stock-Based Compensation, for additional information on stock-based compensation.

[0000889331-21-000010:notes:69]
Coal Mining Liability

[0000889331-21-000010:notes:70]
Included in other long-term liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €2.3 million ($2.9 million) and €1.0 million ($1.1 million) at December 26, 2020 and December 28, 2019, respectively. Management, in conjunction with an independent third-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time.

[0000889331-21-000010:notes:71]
Other Income, Net

[0000889331-21-000010:notes:72]
Other income, net generally consists of interest income, royalties, change in fair value of available-for-sale securities, pension non-service costs and other non-operating expense (income).

[0000889331-21-000010:notes:73]
Income Taxes

[0000889331-21-000010:notes:74]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards, and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-21-000010:notes:75]
Deferred U.S. income taxes and non-U.S. taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries.  Changes in economic and business conditions, non-U.S. or U.S. tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-21-000010:notes:76]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits

[0000889331-21-000010:notes:77]
recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-21-000010:notes:78]
On December 22, 2017, the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduced the U.S. corporate federal income tax rate from 35% to 21%, added base broadening provisions which limit deductions and address excessive international tax planning, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enabled repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax.

[0000889331-21-000010:notes:79]
In the fourth quarter of 2018, within the measurement period outlined in SEC SAB No. 118, the Company finalized its estimates of the impact of the Tax Act and recorded a charge of $3.2 million, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. In addition, the Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation. This was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities.

[0000889331-21-000010:notes:80]
The Company elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The long-term portion of this Toll Charge which remains payable as of December 26, 2020, totaling $20.8 million, is included in Other long-term liabilities, and the anticipated 2021 annual installment payment of $3.0 million is included in Accrued income taxes, on the Consolidated Balance Sheet as of December 26, 2020. The Company did not elect to pay the 2018 IXYS Toll Charge over the eight year period provided by the Tax Act and therefore there is no 2018 IXYS Toll Charge which remains payable as of December 26, 2020.

[0000889331-21-000010:notes:81]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 26, 2020, December 28, 2019, and December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-21-000010:notes:82]
Fair Value Measurements

[0000889331-21-000010:notes:83]
Certain assets and liabilities are required to be recorded at fair value on a recurring basis. Fair value is determined based on the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants. The Company records the fair value of its available-for-sale securities and pension plan assets on a recurring basis. Assets measured at fair value on a nonrecurring basis include long-lived assets held and used, long-lived assets held for sale, goodwill and other intangible assets. The fair value of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The three-tier value hierarchy, which prioritizes valuation methodologies based on the reliability of the inputs, is:

[0000889331-21-000010:notes:84]
Level 1 – Valuations based on quoted prices for identical assets and liabilities in active markets.

[0000889331-21-000010:notes:85]
Level 2 – Valuations based on observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data.

[0000889331-21-000010:notes:86]
Level 3 – Valuations based on unobservable inputs reflecting the Company’s own assumptions, consistent with reasonably available assumptions made by other market participants.

[0000889331-21-000010:notes:87]
Recently Adopted Accounting Standards

[0000889331-21-000010:notes:88]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2018-14 "Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans," which amends ASC 715-20, Compensation - Retirement Benefits - Defined Benefit Plans - General. The amended guidance modifies the disclosure requirements for employers that sponsor defined benefit pension or other post-retirement plans by removing and adding certain disclosures for these plans. The eliminated disclosures include (a) the amounts in OCI expected to be recognized in net periodic benefit costs over the next fiscal year, and (b) the effects of a one percentage point change in assumed health care cost trend rates on the net periodic benefit costs and the benefit obligation for post-retirement health care benefits. Additional disclosures include descriptions of significant gains and losses affecting the benefit obligation for the period. This guidance is effective for financial statements

[0000889331-21-000010:notes:89]
issued for fiscal years ending after December 15, 2020. The Company adopted the standard as of December 26, 2020. The adoption of this guidance did not have a material effect on the Company's Consolidated Financial Statements.

[0000889331-21-000010:notes:90]
In March 2020, the FASB issued Accounting Standards Update (“ASU”) No. 2020-04 Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting.” This ASU provides optional expedient and exceptions for applying generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by reference rate reform if certain criteria are met. The objective of this is to provide optional guidance for a limited period of time to ease the potential burden in accounting for (or recognizing the effects of) reference rate reform on financial reporting due to the cessation of the London Interbank Offered Rate (LIBOR). The amendments in this update are effective for all entities as of March 12, 2020 through December 31, 2022. The adoption of this guidance did not have a material effect on the Company's Consolidated Financial Statements.

[0000889331-21-000010:notes:91]
In August 2018, the FASB issued ASU No. 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic: 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force)." ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The Company adopted the new standard on December 29, 2019.  The adoption of ASU 2018-15 did not have a material impact on our Consolidated Financial Statements.

[0000889331-21-000010:notes:92]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement." ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies other disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018-13 did not have a material impact on our Consolidated Financial Statements.

[0000889331-21-000010:notes:93]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments." The standard, including subsequently issued amendments (ASU 2019-11 and ASU 2019-04), modifies the measurement approach for credit losses on financial instruments, including trade receivables, from an incurred loss method to a current expected credit loss method ("CECL").  The standard requires the measurement of expected credit losses to be based on relevant information, including historical experiences, current conditions and a forecast that is supportable.  The Company adopted the new standard on December 29, 2019.  The adoption of the standard did not have a material effect on our Consolidated Financial Statements.

[0000889331-21-000010:notes:94]
Recently Issued Accounting Standards

[0000889331-21-000010:notes:95]
In December 2019, the FASB issued ASU No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The Company does not expect material effect from the adoption of this guidance on the Company's Consolidated Financial Statements.


## us-gaap:IncomeTaxPolicyTextBlock

[0000889331-21-000010:notes:96]
On December 22, 2017, the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduced the U.S. corporate federal income tax rate from 35% to 21%, added base broadening provisions which limit deductions and address excessive international tax planning, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enabled repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. 
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 26, 2020, December 28, 2019, and December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-21-000010:notes:97]
Acquisitions

[0000889331-21-000010:notes:98]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0000889331-21-000010:notes:99]
IXYS Corporation

[0000889331-21-000010:notes:100]
On January 17, 2018, the Company acquired IXYS Corporation (“IXYS”), a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power semiconductors across the industrial, communications, consumer and medical markets. IXYS had a broad customer base, serving more than 3,500 customers through its direct sales force and global distribution partners. The acquisition of IXYS accelerated the Company’s growth across the power control market driven by IXYS’s extensive power semiconductor portfolio and technology expertise. With IXYS, the Company was able to diversify and expand its presence within industrial electronics markets, leveraging the strong IXYS industrial OEM customer base. The Company leveraged its power semiconductor portfolio in automotive markets to expand its global content per vehicle.

[0000889331-21-000010:notes:101]
Upon completion of the acquisition, at IXYS stockholders’ election and subject to proration, each share of IXYS common stock, par value $0.01 per share, owned immediately prior to the effective time were canceled and extinguished and automatically converted into the right to receive: (i) $23.00 in cash (subject to applicable withholding tax), without interest (referred to as the cash consideration), or (ii) 0.1265 of a share of common stock, par value $0.01 per share, of Littelfuse (referred to as the stock consideration). IXYS stockholders received cash in lieu of any fractional shares of Littelfuse common stock that the IXYS stockholders would otherwise have been entitled to receive. Additionally, each outstanding option to purchase shares of IXYS common stock granted under an IXYS equity plan were assumed by Littelfuse and converted into an option to acquire (i) a number of shares of Littelfuse common stock equal to the number of shares of IXYS common stock subject to such option immediately prior to the effective time multiplied by 0.1265, rounded down to the nearest whole share, with (ii) an exercise price per share of Littelfuse common stock equal to the exercise price of such IXYS stock option immediately prior to the effective time divided by 0.1265, rounded up to the nearest whole cent.

[0000889331-21-000010:notes:102]
Based on the $207.5 per share opening price of Littelfuse common stock on January 17, 2018, the consideration IXYS stockholders received in exchange of their IXYS common stock in the acquisition had a value of $814.8 million comprised of $380.6 million of cash and $434.2 million of Littelfuse stock. In addition to the consideration transferred related to IXYS common stock, the value of consideration transferred, and included in the purchase price, related to IXYS stock options that were converted to Littelfuse stock options, or cash settled, had a value of $41.7 million. As a result, total consideration was valued at $856.5 million.

[0000889331-21-000010:notes:103]
The total purchase price of $856.5 million has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the IXYS acquisition:

[0000889331-21-000010:notes:104]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | 302,865 |  |
| Cash settled stock options | 3,622 |  |
| Littelfuse stock | 434,192 |  |
| Converted stock options | 38,109 |  |
| Total purchase consideration | 778,788 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | 155,930 |  |
| Property, plant, and equipment | 77,442 |  |
| Intangible assets | 212,720 |  |
| Goodwill | 382,360 |  |
| Other non-current assets | 28,706 |  |
| Other non-current liabilities | (78,370) |  |
|  | 778,788 |  |

[0000889331-21-000010:notes:105]
Approximately $49.1 million of net receivables was included in IXYS’s current assets, All IXYS goodwill, other assets and liabilities were recorded in the Electronics segment and primarily reflected in the Americas and European geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining IXYS’s products and technology with the Company’s existing electronics product portfolio. Goodwill resulting from the IXYS acquisition is not expected to be deductible for tax purposes. The Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation (this reflects a reduction of $1.0 million recorded in the fourth quarter of 2018 and $2.0 million recorded in the third quarter of 2018 as a consequence of revisions to the Company’s original estimates). As a result of the Company completing its fair value analysis, in the fourth quarter of 2018, the company recorded a reduction of $2.6 million in certain investments held by IXYS.

[0000889331-21-000010:notes:106]
Included in the Company’s Consolidated Statements of Net Income for the fiscal year ended December 29, 2018 are net sales of approximately $378.2 million, and loss before income taxes of $22.2 million, since the January 17, 2018 acquisition of IXYS. The Company recognized approximately $11.9 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the fiscal year ended December 29, 2018, of which $4.5 million was recognized immediately as it related to prior service periods.

[0000889331-21-000010:notes:107]
As required by purchase accounting rules, the Company recorded a $36.9 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was fully amortized as a non-cash charge to cost of goods sold during the first and second quarters of 2018, as the acquired inventory was sold, and reflected as other non-segment costs.

[0000889331-21-000010:notes:108]
During the fiscal year ended December 29, 2018, the Company incurred approximately $11.0 million of legal and professional fees related to this acquisition which were primarily recognized as selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-21-000010:notes:109]
Pro Forma Results

[0000889331-21-000010:notes:110]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and IXYS as though the acquisition had occurred as of January 1, 2017. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the IXYS acquisition occurred as of January 1, 2017 or of future consolidated operating results.

[0000889331-21-000010:notes:111]
|  |  | For the Fiscal Year Ended |
| (in thousands, except per share amounts) |  | December 29,2018 |
| Net sales |  | $ | 1,735,181 |  |
| Income before income taxes |  | 272,724 |  |
| Net income |  | 215,228 |  |
| Net income per share — basic |  | 8.61 |  |
| Net income per share — diluted |  | 8.53 |  |

[0000889331-21-000010:notes:112]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-21-000010:notes:113]
|  |  | For the Fiscal Year Ended |
| (in thousands) |  | December 29,2018 |
| Amortization(a) |  | $ | 12,009 |  |
| Transaction costs(b) |  | 9,976 |  |
| Amortization of inventory step-up(c) |  | 36,927 |  |
| Stock compensation(d) |  | 5,845 |  |
| Income tax impact of above items |  | (15,446) |  |

[0000889331-21-000010:notes:114]
(a)The amortization adjustment for the twelve months ended December 29, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and is fully amortized in the fiscal 2017 for  pro forma results.

[0000889331-21-000010:notes:115]
(b)The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the twelve months ended December 29, 2018.

[0000889331-21-000010:notes:116]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the twelve months ended December 29, 2018. The inventory step-up was amortized over five months as the inventory was sold.

[0000889331-21-000010:notes:117]
(d)The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the twelve months ended December 29, 2018.

[0000889331-21-000010:notes:118]
For the fiscal year ended December 26, 2020 and December 28, 2019, the Company recorded $0.8 million and $2.7 million of acquisition-related expenses associated with contemplated acquisitions within Selling, general and administrative expenses in the Consolidated Statements of Net Income.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-21-000010:notes:119]
The components of inventories at December 26, 2020 and December 28, 2019 are as follows:

[0000889331-21-000010:notes:120]
| (in thousands) | 2020 |  | 2019 |
| Raw materials | $ | 85,394 |  |  | $ | 76,732 |  |
| Work in process | 92,783 |  |  | 84,561 |  |
| Finished goods | 114,641 |  |  | 110,388 |  |
| Inventory reserves | (34,816) |  |  | (34,174) |  |
| Total | $ | 258,002 |  |  | $ | 237,507 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-21-000010:notes:121]
The components of net property, plant, and equipment at December 26, 2020 and December 28, 2019 are as follows:

[0000889331-21-000010:notes:122]
| (in thousands) | 2020 |  | 2019 |
| Land | $ | 22,851 |  |  | $ | 24,758 |  |
| Building | 123,497 |  |  | 108,501 |  |
| Equipment | 678,220 |  |  | 631,273 |  |
| Accumulated depreciation and amortization | (480,390) |  |  | (419,915) |  |
| Total | $ | 344,178 |  |  | $ | 344,617 |  |

[0000889331-21-000010:notes:123]
The Company recorded depreciation expense of $56.1 million, $52.5 million, and $51.0 million for the fiscal years ended December 26, 2020, December 28, 2019, and December 29, 2018, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-21-000010:notes:124]
Goodwill and Other Intangible Assets

[0000889331-21-000010:notes:125]
The amounts for goodwill and changes in the carrying value by segment are as follows:

[0000889331-21-000010:notes:126]
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Gross goodwill as of December 29, 2018 | $ | 656,039 |  |  | $ | 132,332 |  |  | $ | 46,830 |  |  | $ | 835,201 |  |
| Accumulated impairment losses as of December 29, 2018 | — |  |  | — |  |  | (8,486) |  |  | (8,486) |  |
| Net goodwill as of December 29, 2018 | $ | 656,039 |  |  | $ | 132,332 |  |  | $ | 38,344 |  |  | $ | 826,715 |  |
| Changes during 2019: |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (5,243) |  |  | (1,011) |  |  | 128 |  |  | (6,126) |  |
| Gross goodwill as of December 28, 2019 | 650,796 |  |  | 131,321 |  |  | 47,266 |  |  | 829,383 |  |
| Accumulated impairment losses as of December 28, 2019 | — |  |  | — |  |  | (8,794) |  |  | (8,794) |  |
| Net goodwill as of December 28, 2019 | $ | 650,796 |  |  | $ | 131,321 |  |  | $ | 38,472 |  |  | $ | 820,589 |  |
| Changes during 2020: |  |  |  |  |  |  |  |
| Impairments | — |  |  | (33,841) |  |  | — |  |  | (33,841) |  |
| Foreign currency translation adjustments | 25,529 |  |  | 4,451 |  |  | 84 |  |  | 30,064 |  |
| Gross goodwill as of December 26, 2020 | 676,325 |  |  | 138,354 |  |  | 47,551 |  |  | 862,230 |  |
| Accumulated impairment losses as of December 26, 2020 | — |  |  | (36,423) |  |  | (8,995) |  |  | (45,418) |  |
| Net goodwill as of December 26, 2020 | $ | 676,325 |  |  | $ | 101,931 |  |  | $ | 38,556 |  |  | $ | 816,812 |  |

[0000889331-21-000010:notes:127]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition, during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling their existing program. The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of December 26, 2020, the automotive sensors reporting unit had $9.8 million of remaining goodwill.

[0000889331-21-000010:notes:128]
The components of intangible assets at December 26, 2020 and December 28, 2019 are as follows:

[0000889331-21-000010:notes:129]
|  | As of December 26, 2020 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 10,280 |  |  | $ | 2,007 |  |  | $ | 8,273 |  |
| Patents, licenses and software | $ | 137,210 |  |  | $ | 92,868 |  |  | $ | 44,342 |  |
| Distribution network | 43,910 |  |  | 38,980 |  |  | 4,930 |  |
| Customer relationships, trademarks, and tradenames | 372,064 |  |  | 137,722 |  |  | 234,342 |  |
| Total | $ | 563,464 |  |  | $ | 271,577 |  |  | $ | 291,887 |  |

[0000889331-21-000010:notes:130]
|  | As of December 28, 2019 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 9,649 |  |  | $ | 1,730 |  |  | $ | 7,919 |  |
| Patents, licenses and software | $ | 131,164 |  |  | $ | 78,828 |  |  | $ | 52,336 |  |
| Distribution network | 43,239 |  |  | 36,163 |  |  | 7,076 |  |
| Customer relationships, trademarks, and tradenames | 360,534 |  |  | 106,618 |  |  | 253,916 |  |
| Total | $ | 544,586 |  |  | $ | 223,339 |  |  | $ | 321,247 |  |

[0000889331-21-000010:notes:131]
During the year ended December 29, 2018, the Company recorded additions to other intangible assets of $212.7 million, for acquisitions during 2018, the components of which were as follows:

[0000889331-21-000010:notes:132]
|  | 2018 |
| (in thousands, except weighted average useful life) | Weighted AverageUseful Life (Years) |  | Amount |
| Patents, licenses and software | 8.0 |  | $ | 51,500 |  |
| Customer relationships, trademarks, and tradenames | 17.2 |  | 148,800 |  |
| Order backlog | 1.0 |  | 12,420 |  |
| Total |  |  | $ | 212,720 |  |

[0000889331-21-000010:notes:133]
For intangible assets with definite lives, the Company recorded amortization expense of $40.0 million, $40.0 million, and $52.2 million in 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:134]
Estimated annual amortization expense related to intangible assets with definite lives at December 26, 2020 is as follows:

[0000889331-21-000010:notes:135]
| (in thousands) | Amount |
| 2021 | $ | 38,858 |  |
| 2022 | 37,851 |  |
| 2023 | 33,279 |  |
| 2024 | 30,121 |  |
| 2025 | 29,689 |  |
| 2026 and thereafter | 122,089 |  |
| Total | $ | 291,887 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-21-000010:notes:136]
Accrued Liabilities

[0000889331-21-000010:notes:137]
The components of accrued liabilities at December 26, 2020 and December 28, 2019 are as follows:

[0000889331-21-000010:notes:138]
| (in thousands) | 2020 |  | 2019 |
| Employee-related liabilities | $ | 50,689 |  |  | $ | 40,774 |  |
| Operating lease liability | 6,811 |  |  | 7,259 |  |
| Interest | 4,517 |  |  | 5,058 |  |
| Restructuring liability | 4,195 |  |  | 2,679 |  |
| Other customer reserves | 3,858 |  |  | 1,143 |  |
| Professional services | 3,321 |  |  | 3,986 |  |
| Deferred revenue | 2,959 |  |  | 828 |  |
| Current benefit liability | 2,751 |  |  | 1,106 |  |
| Other non-income taxes | 2,126 |  |  | 1,940 |  |
| Other | 29,251 |  |  | 19,347 |  |
| Total | $ | 110,478 |  |  | $ | 84,120 |  |

[0000889331-21-000010:notes:139]
Employee-related liabilities consist primarily of payroll, sales commission, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other client-related liabilities.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000889331-21-000010:notes:140]
Lease Commitments
Under ASC 842, a contract contains a lease if there is an identified asset and the Company has the right to control the asset. The Company determines whether a contract contains a lease at contract inception. The Company leases office and production space under various non-cancellable operating leases that expire no later than 2025. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The Company also has production equipment, office equipment and vehicles under operating leases. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants. The Company has elected to use the available practical expedient to account for the lease and non-lease components of its leases as a single component. As the Company elected not to separate lease and non-lease components and instead to account for them as a single lease component, the variable lease cost primarily represents variable payments such as common area maintenance and utilities.

[0000889331-21-000010:notes:141]
The Company does not have a published credit rating because it has no publicly traded debt; therefore, the Company is generating its incremental borrowing rate (IBR), using a synthetic credit rating model that compares its credit quality to other rated companies based on certain financial metrics and ratios. The reference rate will be based on the yield curve of companies with similar credit quality based on the metrics and adjusted for currency in regions where we have significant operations.

[0000889331-21-000010:notes:142]
All leases with an initial term of 12 months or less that do not include an option to extend or purchase the underlying asset that the Company is reasonably certain to exercise (“short-term leases”) are not recorded on the Consolidated Balance Sheets. Short-term lease expenses are recognized on a straight-line basis over the lease term.

[0000889331-21-000010:notes:143]
The following table presents the classification of ROU assets and lease liabilities as of December 26, 2020 and December 28, 2019:

[0000889331-21-000010:notes:144]
| Leases(in thousands) | Consolidated Balance Sheet Classification | December 26, 2020 |  | December 28, 2019 |
| Assets |  |  |  |  |
| Operating ROU assets | Right of use assets, net | $ | 17,615 |  |  | $ | 21,918 |  |
| Liabilities |  |  |  |  |
| Current operating lease liabilities | Accrued liabilities | $ | 6,811 |  |  | $ | 7,259 |  |
| Non-current operating lease liabilities | Non-current operating lease liabilities | 12,950 |  |  | 17,166 |  |
| Total lease liabilities |  | $ | 19,761 |  |  | $ | 24,425 |  |

[0000889331-21-000010:notes:145]
The following table represents the lease costs for 2020 and 2019:

[0000889331-21-000010:notes:146]
| Leases cost(in thousands) | Consolidated Statements of Net Income Classification | Fiscal Year Ended December 26, 2020 |  | Fiscal Year Ended December 28, 2019 |
| Short-term lease expenses | Cost of sales, SG&A expenses | $ | 512 |  |  | $ | 562 |  |
| Variable lease expenses | Cost of sales, SG&A expenses | 1,307 |  |  | 916 |  |
| Operating lease rent expenses | Cost of sales, SG&A expenses | 8,591 |  |  | 8,664 |  |
| Total operating lease costs | Cost of sales, SG&A expenses | $ | 10,410 |  |  | $ | 10,142 |  |

[0000889331-21-000010:notes:147]
The Company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was $10.4 million, $10.1 million, and $9.6 million in 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:148]
| Maturity of Lease Liabilities as of December 26, 2020(in thousands) | Operating leases |
| 2021 | $ | 7,660 |  |
| 2022 | 6,162 |  |
| 2023 | 3,952 |  |
| 2024 | 3,350 |  |
| 2025 | 262 |  |
| 2026 and thereafter | 302 |  |
| Total lease payments | $ | 21,688 |  |
| Present value of lease liabilities | $ | 19,761 |  |

[0000889331-21-000010:notes:149]
| Operating Lease Term and Discount Rate | Fiscal Year Ended December 26, 2020 | Fiscal Year Ended December 28, 2019 |
| Weighted-average remaining lease term (years) | 3.41 | 4.05 |
| Weighted-average discount rate | 5.06 | % | 5.11 | % |

[0000889331-21-000010:notes:150]
| Cash Flow Information related to Leases(in thousands) |  | Fiscal Year Ended December 26, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |
| Operating cash flow payments for operating leases |  | $ | (8,929) |  |
| Leased assets obtained in exchange for operating lease liabilities |  | 2,862 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-21-000010:notes:151]
Restructuring, Impairment and Other Charges
The Company recorded restructuring, impairment and other charges for fiscal years 2020, 2019, and 2018 as follows:

[0000889331-21-000010:notes:152]
|  | Fiscal Year Ended December 26, 2020 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 2,540 |  |  | $ | 682 |  |  | $ | 2,231 |  |  | $ | 5,453 |  |
| Other restructuring charges | — |  |  | 175 |  |  | 10 |  |  | 185 |  |
| Total restructuring charges | 2,540 |  |  | 857 |  |  | 2,241 |  |  | 5,638 |  |
| Impairment | — |  |  | 33,841 |  |  | 2,237 |  |  | 36,078 |  |
| Total | $ | 2,540 |  |  | $ | 34,698 |  |  | $ | 4,478 |  |  | $ | 41,716 |  |

[0000889331-21-000010:notes:153]
|  | Fiscal Year Ended December 28, 2019 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 5,313 |  |  | $ | 4,251 |  |  | $ | 795 |  |  | $ | 10,359 |  |
| Other restructuring charges | 188 |  |  | 1,714 |  |  | 450 |  |  | 2,352 |  |
| Total restructuring charges | 5,501 |  |  | 5,965 |  |  | 1,245 |  |  | 12,711 |  |
| Impairment | — |  |  | 322 |  |  | — |  |  | 322 |  |
| Total | $ | 5,501 |  |  | $ | 6,287 |  |  | $ | 1,245 |  |  | $ | 13,033 |  |

[0000889331-21-000010:notes:154]
|  | Fiscal Year Ended December 29, 2018 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 8,742 |  |  | $ | 634 |  |  | $ | 127 |  |  | $ | 9,503 |  |
| Other restructuring charges | 670 |  |  | 192 |  |  | — |  |  | 862 |  |
| Total restructuring charges | 9,412 |  |  | 826 |  |  | 127 |  |  | 10,365 |  |
| Impairment | — |  |  | 88 |  |  | 2,130 |  |  | 2,218 |  |
| Total | $ | 9,412 |  |  | $ | 914 |  |  | $ | 2,257 |  |  | $ | 12,583 |  |

[0000889331-21-000010:notes:155]
2020

[0000889331-21-000010:notes:156]
For the year ended December 26, 2020, the Company recorded total restructuring charges of $5.6 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the previously announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $36.1 million of impairment charges, which included a $33.8 million goodwill impairment charge associated with the automotive sensors reporting unit within the Automotive segment in the second quarter of 2020 and a $2.2 million impairment charge related to the land and building associated with the Company’s previously announced consolidation of a manufacturing facility within the Industrial segment in the first quarter of 2020. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the goodwill impairment charge.

[0000889331-21-000010:notes:157]
2019

[0000889331-21-000010:notes:158]
For the year ended December 28, 2019, the Company recorded total restructuring charges of $12.7 million for employee termination costs and other restructuring charges. These charges primarily related to the reorganization of operations and selling, general and administrative functions as well as the integration of IXYS within the Electronics segment and the reorganization of operations in the automotive sensors and commercial vehicle products businesses within the Automotive segment.

[0000889331-21-000010:notes:159]
In April 2019, we announced the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment. The Company recorded $1.7 million of employee termination costs and $1.4 million of other restructuring and impairment charges  associated with this plant closure.

[0000889331-21-000010:notes:160]
2018

[0000889331-21-000010:notes:161]
For the year ended December 29, 2018, the Company recorded total restructuring charges of $10.4 million for employee termination costs and other restructuring charges related to lease termination and facility closure. These charges primarily related to the integration of IXYS and the reorganization of the IXYS Radio Pulse business within the Electronics segment and the reorganization of operations in the Commercial Vehicle Products business within the Automotive segment.

[0000889331-21-000010:notes:162]
For the year ended  December 29, 2018, the Company recorded impairment charges of $2.2 million primarily related to the impairment of a building and a trade name associated with the exit of the Custom business within the Industrial segment.

[0000889331-21-000010:notes:163]
The restructuring reserves as of December 26, 2020 and December 28, 2019 are $4.2 million and $2.7 million, respectively. The restructuring reserves are included within accrued liabilities. Payments associated with employee terminations reflected in the above table were substantially completed by December 26, 2020. The Company anticipates that the remaining payments associated with employee terminations will be completed in fiscal 2021.


## us-gaap:DebtDisclosureTextBlock

[0000889331-21-000010:notes:164]
Debt

[0000889331-21-000010:notes:165]
The carrying amounts of debt at December 26, 2020 and December 28, 2019 are as follows:

[0000889331-21-000010:notes:166]
| (in thousands) | 2020 |  | 2019 |
| Revolving Credit Facility | $ | 130,000 |  |  | $ | — |  |
| Term Loan | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 | 142,679 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 | 115,850 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 | 125,000 |  |  | 125,000 |  |
| Other | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs | (4,114) |  |  | (3,669) |  |
| Total debt | 687,034 |  |  | 679,158 |  |
| Less: Current maturities | — |  |  | (10,000) |  |
| Total long-term debt | $ | 687,034 |  |  | $ | 669,158 |  |

[0000889331-21-000010:notes:167]
Interest paid on all Company debt was approximately $20.1 million,  $21.2 million, and $18.5 million in fiscal year 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:168]
Revolving Credit Facility / Term Loan

[0000889331-21-000010:notes:169]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-21-000010:notes:170]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.

[0000889331-21-000010:notes:171]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19.

[0000889331-21-000010:notes:172]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $110.0 million on the amended revolving credit facility during the fiscal year ended December 26, 2020. The balance under the facility was $130.0 million as of December 26, 2020.

[0000889331-21-000010:notes:173]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR fixed for interest periods of one, two, three or six-month periods plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined in the agreement. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.65% at December 26, 2020.

[0000889331-21-000010:notes:174]
As of December 26, 2020, the Company had no amounts outstanding in letters of credit and had available $383.5 million of borrowing capacity under the Revolving Credit Facility. At December 26, 2020, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-21-000010:notes:175]
Senior Notes

[0000889331-21-000010:notes:176]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-21-000010:notes:177]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000010:notes:178]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 will be payable on February 15 and August 15, commencing on August 15, 2018.

[0000889331-21-000010:notes:179]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-21-000010:notes:180]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At December 26, 2020, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-21-000010:notes:181]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-21-000010:notes:182]
Debt Issuance Costs

[0000889331-21-000010:notes:183]
During fiscal year 2020, the Company paid debt issuance costs of $1.8 million in relation to the amended the Credit Agreement on April 3, 2020 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the amended Credit Agreement.

[0000889331-21-000010:notes:184]
The Company paid debt issuance costs of $0.9 million in relation to the $175 million Note Purchase Agreement that was entered on November 15, 2017 during fiscal year 2018.

[0000889331-21-000010:notes:185]
Debt Maturities

[0000889331-21-000010:notes:186]
Scheduled maturities of the Company’s long-term debt for each of the five years succeeding December 26, 2020 and thereafter are summarized as follows:

[0000889331-21-000010:notes:187]
| (in thousands) | ScheduledMaturities |
| 2021 | $ | — |  |
| 2022 | 27,619 |  |
| 2023 | 142,679 |  |
| 2024 | — |  |
| 2025 | 180,000 |  |
| 2026 and thereafter | 340,850 |  |
|  | $ | 691,148 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-21-000010:notes:188]
Fair Value of Assets and Liabilities

[0000889331-21-000010:notes:189]
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a three-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows:

[0000889331-21-000010:notes:190]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0000889331-21-000010:notes:191]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable, and

[0000889331-21-000010:notes:192]
Level 3—Valuations based upon one or more significant unobservable inputs.

[0000889331-21-000010:notes:193]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0000889331-21-000010:notes:194]
Cash equivalents primarily consist of money market funds, which are held with an institution with sound credit rating and are highly liquid. The Company classified cash equivalents as Level 1 and are valued at cost, which approximates fair value.

[0000889331-21-000010:notes:195]
Investments in Equity Securities

[0000889331-21-000010:notes:196]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 1 of the valuation hierarchy. Such securities are further detailed in Note 1, Summary of Significant Accounting Policies and Other Information.

[0000889331-21-000010:notes:197]
Other Investments

[0000889331-21-000010:notes:198]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in Investments and Other assets in the Consolidated Balance Sheets. During the fiscal year ended December 26, 2020 and December 28, 2019, the Company recorded impairment charges of $0.1 million and $7.3 million, respectively, in Other income, net in the Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value. As of December 26, 2020 and December 28, 2019, the balances of these investments were $0.5 million and $0.4 million, respectively. The fair value of these investments are measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-21-000010:notes:199]
Defined Benefit Plan Assets / Non-qualified Supplemental Retirement and Savings Plan Investments

[0000889331-21-000010:notes:200]
See Note 11, Benefit Plans, for description of valuation methodologies and investment balances for defined benefit plan assets and investments related to the Company’s Non-Qualified Supplemental Retirement and Savings Plan.

[0000889331-21-000010:notes:201]
Foreign currency exchange forward contract

[0000889331-21-000010:notes:202]
There were no changes during 2020 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. On October 30, 2019, the Company entered a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Chinese renminbi and U.S dollar. The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly basis. The notional value of the forward contracts at December 28, 2019 was $16.0 million and expired on May 5, 2020. On March 23, 2020, the Company unwound the foreign currency exchange forward contract entered on October 30, 2019 and recognized a gain of $0.2 million within Other income, net during the fiscal year 2020. The fair value of the foreign currency forward contract was valued using market exchange rates and classified as a Level 2 input under the fair value hierarchy. As of December 26, 2020 and  December 28, 2019, the Company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-21-000010:notes:203]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 26, 2020:

[0000889331-21-000010:notes:204]
|  | Fair Value Measurements Using |  |  |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash Equivalents | $ | 73,461 |  |  | $ | — |  |  | $ | — |  |  | $ | 73,461 |  |
| Investments in equity securities | 19,186 |  |  | — |  |  | — |  |  | 19,186 |  |
| Mutual funds | 13,249 |  |  | — |  |  | — |  |  | 13,249 |  |
| Total: | $ | 105,896 |  |  | $ | — |  |  | $ | — |  |  | $ | 105,896 |  |

[0000889331-21-000010:notes:205]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 28, 2019:

[0000889331-21-000010:notes:206]
|  | Fair Value Measurements Using |  |  |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash Equivalents | $ | 118,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,999 |  |
| Investments in equity securities | 12,969 |  |  | — |  |  | — |  |  | 12,969 |  |
| Mutual funds | 10,464 |  |  | — |  |  | — |  |  | 10,464 |  |
| Total: | $ | 142,432 |  |  | $ | — |  |  | $ | — |  |  | $ | 142,432 |  |

[0000889331-21-000010:notes:207]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, trade receivables and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and trade receivables approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at December 26, 2020 and December 28, 2019, as the rates on these borrowings are variable in nature.

[0000889331-21-000010:notes:208]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of December 26, 2020 and December 28, 2019 were as follows:

[0000889331-21-000010:notes:209]
|  | December 26, 2020 |  | December 28, 2019 |
| (in thousands) | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 | $ | 142,679 |  |  | $ | 144,323 |  |  | $ | 129,808 |  |  | $ | 131,710 |  |
| Euro Senior Notes, Series B due 2028 | 115,850 |  |  | 123,588 |  |  | 105,400 |  |  | 110,336 |  |
| USD Senior Notes, Series A due 2022 | 25,000 |  |  | 25,437 |  |  | 25,000 |  |  | 25,054 |  |
| USD Senior Notes, Series B due 2027 | 100,000 |  |  | 109,552 |  |  | 100,000 |  |  | 102,548 |  |
| USD Senior Notes, Series A due 2025 | 50,000 |  |  | 53,474 |  |  | 50,000 |  |  | 50,775 |  |
| USD Senior Notes, Series B due 2030 | 125,000 |  |  | 138,036 |  |  | 125,000 |  |  | 127,701 |  |

[0000889331-21-000010:notes:210]
The Company recognized impairment charges of $1.9 million for the land and building and $0.3 million for a certain patent as a result of the Company’s announcement to consolidate a manufacturing facility within the Industrial segment during the first quarter of 2020. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. The fair value of the land and building was valued using a real estate appraisal and classified as a Level 3 input under the fair value hierarchy.

[0000889331-21-000010:notes:211]
The second quarter of 2020 goodwill impairment charge was the result of measuring a reporting unit at fair value on a nonrecurring basis as shown below:

[0000889331-21-000010:notes:212]
|  |  |  |  | Fiscal Year Ended December 26, 2020 |  | December 26, 2020 |
| (in thousands) |  |  |  |  |  | Impairment Charge |  | Estimated Fair Value Measurement (Level 3) |  | Carrying Value |
| Goodwill |  |  |  |  |  | $33,841 |  | $8,953 |  | $ | 9,832 |  |

[0000889331-21-000010:notes:213]
See Note 5, Goodwill and Other Intangible Assets for further discussion regarding goodwill impairment charges.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-21-000010:notes:214]
Benefit Plans

[0000889331-21-000010:notes:215]
The Company has Company-sponsored and mandatory defined benefit pension plans covering employees in the United Kingdom ("U.K."), Germany, the Philippines, China, Japan, Mexico, Italy and France. The amount of the retirement benefits provided under the plans is generally based on years of service and final average pay.

[0000889331-21-000010:notes:216]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to directly pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $55 million, representing approximately 37% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge in the second half of 2021 currently estimated between $18 million and $22 million, reflecting the accelerated recognition of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses. Due to the signing of the group annuity contract being a significant change in one of the U.K. pension plans, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million (£10.9 million) to both the net pension liability to bring the pension benefit obligation to the purchase price of the group annuity contract, and unamortized actuarial loss within other comprehensive income (loss) during the second quarter. Additionally, the Company made a cash contribution of $10.4 million (£8.4 million) under this agreement during the second quarter.

[0000889331-21-000010:notes:217]
Benefit plan related information is as follows for the years 2020 and 2019:

[0000889331-21-000010:notes:218]
| (in thousands) | 2020 |  | 2019 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 116,921 |  |  | $ | 102,833 |  |
| Service cost | 2,462 |  |  | 2,040 |  |
| Interest cost | 2,173 |  |  | 3,169 |  |
| Net actuarial loss | 25,306 |  |  | 11,286 |  |
| Benefits paid from the plan assets | (2,808) |  |  | (3,323) |  |
| Benefits paid directly by the Company | (2,302) |  |  | (1,540) |  |
| Curtailments and Settlements | 102 |  |  | (1,924) |  |
| Effect of exchange rate movements | 7,462 |  |  | 1,735 |  |
| Plan amendment and other | (324) |  |  | 2,645 |  |
| Benefit obligation at end of year | $ | 148,992 |  |  | $ | 116,921 |  |
| Change in plan assets at fair value: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 78,502 |  |  | $ | 70,676 |  |
| Actual return on plan assets | 7,053 |  |  | 8,222 |  |
| Employer contributions | 12,918 |  |  | 2,233 |  |
| Benefits paid from the plan assets | (2,808) |  |  | (3,323) |  |
| Settlements | — |  |  | (1,072) |  |
| Effect of exchange rate movements | 4,813 |  |  | 1,766 |  |
| Fair value of plan assets at end of year | 100,478 |  |  | 78,502 |  |
| Net amount unfunded status | $ | (48,514) |  |  | $ | (38,419) |  |

[0000889331-21-000010:notes:219]
Amounts recognized in the Consolidated Balance Sheets as of December 26, 2020 and December 28, 2019 consist of the following:

[0000889331-21-000010:notes:220]
| (in thousands) | 2020 |  | 2019 |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |
| Noncurrent assets | $ | 39 |  |  | $ | 885 |  |
| Current benefit liability | (2,751) |  |  | (1,106) |  |
| Noncurrent benefit liability | (45,802) |  |  | (38,198) |  |
| Net liability recognized | $ | (48,514) |  |  | $ | (38,419) |  |

[0000889331-21-000010:notes:221]
The amounts included in accumulated other comprehensive loss in the Consolidated Balance Sheets, excluding tax effects, that have not yet been recognized as components of net periodic benefit costs as of December 26, 2020 and December 28, 2019 were as following:

[0000889331-21-000010:notes:222]
| (in thousands) | 2020 |  | 2019 |
| Net actuarial loss | $ | 37,285 |  |  | $ | 15,635 |  |
| Prior service cost | 3,937 |  |  | 4,273 |  |
| Total | $ | 41,222 |  |  | $ | 19,908 |  |

[0000889331-21-000010:notes:223]
The pre-tax amounts recognized in other comprehensive income (loss) in 2020 as components of net periodic benefit costs were as follows:

[0000889331-21-000010:notes:224]
| (in thousands) | 2020 |
| Amortization of: |  |
| Prior service cost | $ | 181 |  |
| Net actuarial loss | 782 |  |
| Amount arising during the period: |  |
| Prior service cost | 324 |  |
| Net actuarial loss | (19,861) |  |
| Net settlement loss | 236 |  |
| Foreign currency adjustments | (1,298) |  |
| Total | $ | (19,636) |  |

[0000889331-21-000010:notes:225]
Due to the signing of the group annuity contract being a significant change in this U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million to unamortized actuarial loss within other comprehensive income (loss). In addition, the net actuarial loss and increase in benefit obligation arising during 2020 and 2019 were also impacted by lower discount rates in both 2020 and 2019 compared to previous years and changes in foreign exchange rates.

[0000889331-21-000010:notes:226]
The components of net periodic benefits costs for the fiscal years 2020, 2019, and 2018 are as follows:

[0000889331-21-000010:notes:227]
| (in thousands) | 2020 |  | 2019 |  | 2018 |
| Components of net periodic benefit cost: |  |  |  |  |  |
| Service cost | $ | 2,462 |  |  | $ | 2,040 |  |  | $ | 2,266 |  |
| Interest cost | 2,173 |  |  | 3,169 |  |  | 3,104 |  |
| Expected return on plan assets | (1,972) |  |  | (3,187) |  |  | (3,222) |  |
| Amortization of prior service and net actuarial loss | 963 |  |  | 243 |  |  | 291 |  |
| Net periodic benefit cost | 3,626 |  |  | 2,265 |  |  | 2,439 |  |
| Net settlement loss | 236 |  |  | 260 |  |  | 238 |  |
| Total expense for the year | $ | 3,862 |  |  | $ | 2,525 |  |  | $ | 2,677 |  |

[0000889331-21-000010:notes:228]
Weighted average assumptions used to determine net periodic benefit cost for the fiscal years 2020, 2019, and 2018 are as follows:

[0000889331-21-000010:notes:229]
|  | 2020 |  | 2019 |  | 2018 |
| Discount rate | 2.3 | % |  | 3.1 | % |  | 2.8 | % |
| Expected return on plan assets | 3.7 | % |  | 4.5 | % |  | 4.2 | % |
| Compensation increase rate | 4.7 | % |  | 4.6 | % |  | 5.0 | % |

[0000889331-21-000010:notes:230]
The accumulated benefit obligation for the plans was $137.7 million and $111.3 million at December 26, 2020 and December 28, 2019, respectively.

[0000889331-21-000010:notes:231]
The following table provides a summary of under-funded or unfunded pension benefit plans with projected benefit obligations in excess of plan assets as of December 26, 2020 and December 28, 2019:

[0000889331-21-000010:notes:232]
| (in thousands) | 2020 |  | 2019 |
| Projected benefit obligation | $ | 148,992 |  |  | $ | 81,362 |  |
| Fair value of plan assets | 100,439 |  |  | 42,058 |  |

[0000889331-21-000010:notes:233]
The following table provides a summary of under-funded or unfunded pension benefit plans with accumulated benefit obligations in excess of plan assets as of December 26, 2020 and December 28, 2019:

[0000889331-21-000010:notes:234]
| (in thousands) | 2020 |  | 2019 |
| Accumulated benefit obligation | $ | 130,453 |  |  | $ | 75,744 |  |
| Fair value of plan assets | 92,248 |  |  | 42,058 |  |

[0000889331-21-000010:notes:235]
Weighted average assumptions used to determine benefit obligations as of December 26, 2020, December 28, 2019 and December 29, 2018 are as follows:

[0000889331-21-000010:notes:236]
|  | 2020 |  | 2019 |  | 2018 |
| Discount rate | 1.2 | % |  | 2.3 | % |  | 3.1 | % |
| Compensation increase rate | 4.9 | % |  | 4.7 | % |  | 4.6 | % |

[0000889331-21-000010:notes:237]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows:

[0000889331-21-000010:notes:238]
| (in thousands) | Expected Benefit Payments |
| 2021 | $ | 6,562 |  |
| 2022 | 4,718 |  |
| 2023 | 4,902 |  |
| 2024 | 4,742 |  |
| 2025 | 5,357 |  |
| 2026-2030 and thereafter | 31,164 |  |

[0000889331-21-000010:notes:239]
The Company expects to make approximately $2.2 million of contributions to the plans and pay $3.8 million of benefits directly in 2021.

[0000889331-21-000010:notes:240]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. For the fiscal year ended December 26, 2020, December 28, 2019, and December 29, 2018, the Company recorded $2.0 million, $1.4 million, $1.8 million expense, respectively, in Cost of Sales and Other income, net within the Consolidated Statements of Net Income.  As of December 26, 2020 and December 28, 2019, the Company reported benefit liabilities of $3.5 million and $2.8 million for these plans, of which $1.2 million and $0.9 million was recorded in Accrued liabilities and $2.3 million and $1.9 million was recorded in Other long-term liabilities on the Consolidated Balance Sheets, respectively. For fiscal year ended December 26, 2020 and December 28, 2019, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.1 million and  $0.6 million, respectively.

[0000889331-21-000010:notes:241]
Defined Benefit Plan Assets

[0000889331-21-000010:notes:242]
Based upon analysis of the target asset allocation and historical returns by type of investment, the Company has assumed that the expected long-term rate of return will be 3.7% on plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0000889331-21-000010:notes:243]
|  | Asset Allocation |
|  | 2020 |  | 2019 |
| Cash and cash equivalents, and other | 7 | % |  | 1 | % |
| Equity securities | 9 | % |  | 27 | % |
| Fixed income securities | 31 | % |  | 72 | % |
| Bulk annuity contract | 53 | % |  | — | % |
|  | 100 | % |  | 100 | % |

[0000889331-21-000010:notes:244]
The Company segregated its plan assets by the following major categories and level for determining their fair value as of December 26, 2020 and December 28, 2019. All plan assets that are valued using the net asset value per share (“NAV”) practical expedient have not been included within the fair value hierarchy but are separately disclosed.

[0000889331-21-000010:notes:245]
Cash and cash equivalents – Carrying value approximates fair value. As such, these assets were classified as Level 1. The Company also invests in certain short-term investments which are valued using the amortized cost method and at NAV. Lastly, the Company has certain pooled pension funds that have short-term investments with third party mutual funds that are valued at unit value per share at measurement date. As such, these assets were classified as Level 2.

[0000889331-21-000010:notes:246]
Equity – The values of individual equity securities were based on quoted prices in active markets. As such, these assets are classified as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in certain equity securities that are not quoted on active markets; therefore, they were classified as Level 2.

[0000889331-21-000010:notes:247]
Fixed income – Fixed income securities are typically priced based on a last trade basis and are exchange-traded. Accordingly, the Company classified fixed income securities as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in fixed income securities and funds priced based on a valuation model rather than a last trade basis and are not exchange-traded.  As such, they were classified as Level 2. The Company also invests in certain fixed income funds which are valued at NAV.

[0000889331-21-000010:notes:248]
Insurance Contracts and other – This category includes pooled pension funds which have mutual funds with underlying investments in other assets and liabilities including alternatives priced based on a valuation model and are not exchange-traded. These were classified as Level 2. This category includes also insurance contracts that are valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market.  Accordingly, insurance contracts was categorized as Level 3.  Lastly, this category includes other assets and liabilities including futures or swaps valued at NAV.

[0000889331-21-000010:notes:249]
Bulk Annuity Contract – Bulk annuity contract includes a U.K insurance policy issued by an authorized U.K. life insurer. This bulk annuity contract is valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market.  Accordingly, this contract was categorized as Level 3.

[0000889331-21-000010:notes:250]
For any Level 2 and Level 3 plan assets, management reviews significant investments on a periodic basis including investigation of unusual fluctuations in price or returns and obtaining an understanding of the pricing methodology to assess the reliability of third-party pricing estimates.

[0000889331-21-000010:notes:251]
The valuation methodologies described above may generate a fair value calculation that may not be indicative of net realizable value or future fair values. While the Company believes the valuation methodologies used are appropriate, the use of different methodologies or assumptions in calculating fair value could result in different amounts. The Company invests in assets in which valuation is determined by NAV. The Company believes that the NAV is representative of fair value at the reporting date, as there are no significant restrictions on redemption of these investments or other reasons to indicate that the investment would be redeemed at an amount different than the NAV.

[0000889331-21-000010:notes:252]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 26, 2020:

[0000889331-21-000010:notes:253]
|  | Fair Value Measurements Using |  |  |  |  |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Insurance contracts and other | $ | — |  |  | $ | 1,880 |  |  | $ | 685 |  |  | $ | — |  |  | $ | 2,565 |  |
| Cash and cash equivalents | 654 |  |  | 3,868 |  |  | — |  |  | — |  |  | 4,522 |  |
| Equities | 1,719 |  |  | 6,904 |  |  | — |  |  | — |  |  | 8,623 |  |
| Fixed income | 6,164 |  |  | 19,433 |  |  | — |  |  | 6,078 |  |  | 31,675 |  |
| Bulk annuity contract | — |  |  | — |  |  | 53,093 |  |  | — |  |  | 53,093 |  |
| Total pension plan assets | $ | 8,537 |  |  | $ | 32,085 |  |  | $ | 53,778 |  |  | $ | 6,078 |  |  | $ | 100,478 |  |

[0000889331-21-000010:notes:254]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 28, 2019:

[0000889331-21-000010:notes:255]
|  | Fair Value Measurements Using |  |  |  |  |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Equities | $ | 1,796 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,139 |  |  | $ | 20,935 |  |
| Fixed income | 4,535 |  |  | — |  |  | — |  |  | 51,711 |  |  | 56,246 |  |
| Insurance contracts and other | — |  |  | — |  |  | 609 |  |  | 147 |  |  | 756 |  |
| Cash and cash equivalents | 387 |  |  | — |  |  | — |  |  | 178 |  |  | 565 |  |
| Total pension plan assets | $ | 6,718 |  |  | $ | — |  |  | $ | 609 |  |  | $ | 71,175 |  |  | $ | 78,502 |  |

[0000889331-21-000010:notes:256]
The fair value measurement of plan assets using significant unobservable inputs (Level 3) changed during 2020 due to the following:

[0000889331-21-000010:notes:257]
| (in thousands) | Level 3 |
| Balance at December 28, 2019 | $ | 609 |  |
| Level 3 assets transferred in from Level 1 and 2 assets valued at NAV: |  |
| Bulk annuity contract added during the year | 53,093 |  |
| Actual return on plan assets | 76 |  |
| Balance at December 26, 2020 | $ | 53,778 |  |

[0000889331-21-000010:notes:258]
Defined Contribution Plan

[0000889331-21-000010:notes:259]
The Company also maintains a 401(k) savings plan covering substantially all U.S. employees. The Company matches 100% of the employee’s annual contributions for the first 4% of the employee’s eligible compensation. The Company may provide an additional discretionary match to participants and made discretionary matches of 2% of the employee’s eligible compensation for each of the fiscal year ended December 26, 2020, December 28, 2019 and December 29, 2018. Employees are immediately vested in their contributions plus actual earnings thereon, as well as the Company contributions. Company matching contributions amounted to $4.6 million, $5.6 million, and $4.5 million in 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:260]
Non-qualified Supplemental Retirement and Savings Plan

[0000889331-21-000010:notes:261]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The investments are subject to the claims of the Company’s creditors and the Company is responsible for the payment of all benefits under the plan from its general assets. As of December 26, 2020, there was $13.2 million of marketable securities related to the plan included in Other assets and $13.2 million of accrued compensation benefits included in Other long-term liabilities. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily 
determinable fair value. The Company made matching contributions to the plan of $0.5 million, $0.4 million, and $0.4 million in 2020, 2019, and 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000889331-21-000010:notes:262]
Equity Plans: The Company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, and other stock rights to employees and directors. As of December 26, 2020, there were 0.9 million shares available for issuance of future awards under the Company’s equity-based compensation plans.

[0000889331-21-000010:notes:263]
Stock options generally vest over a three, four or five-year period and are exercisable over either a seven or ten-year period commencing from the date of the grant. Restricted shares and share units granted by the Company generally vest over three to four years. Stock options and restricted share units may have accelerated vesting upon meeting certain qualified conditions.

[0000889331-21-000010:notes:264]
Upon completion of the IXYS acquisition, IXYS outstanding options were assumed by  the Company and converted into options of 499,027 shares. The Company recognized approximately $11.9 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the fiscal year ended December 29, 2018, of which $4.5 million was recognized immediately as it related to prior service periods. See Note 2, Acquisitions and Dispositions, for further discussion.

[0000889331-21-000010:notes:265]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended December 26, 2020.

[0000889331-21-000010:notes:266]
|  | Shares UnderOption |  | WeightedAveragePrice |  | WeightedAverageRemainingContract Life(Years) |  | AggregateIntrinsicValue(000’s) |
| Outstanding December 28, 2019 | 600,465 |  |  | $ | 131.32 |  |  |  |  |  |
| Granted | 297,954 |  |  | 152.86 |  |  |  |  |  |
| Exercised | (209,093) |  |  | 104.18 |  |  |  |  |  |
| Forfeited | (22,377) |  |  | 173.95 |  |  |  |  |  |
| Outstanding December 26, 2020 | 666,949 |  |  | 148.01 |  |  | 5.1 |  | $ | 69,126 |  |
| Exercisable December 26, 2020 | 296,409 |  |  | 133.00 |  |  | 3.7 |  | 35,172 |  |

[0000889331-21-000010:notes:267]
The following table provides a reconciliation of non-vested restricted share and share unit awards ("RSU") for the fiscal year ended December 26, 2020.

[0000889331-21-000010:notes:268]
|  | Shares |  | Weighted Average Grant-Date Fair Value |
| Nonvested December 28, 2019 | 134,136 |  |  | $ | 185.86 |  |
| Granted | 115,349 |  |  | 130.14 |  |
| Vested | (68,550) |  |  | 177.78 |  |
| Forfeited | (8,933) |  |  | 175.38 |  |
| Nonvested December 26, 2020 | 172,002 |  |  | 152.25 |  |

[0000889331-21-000010:notes:269]
The total intrinsic value of options exercised during 2020, 2019, and 2018 was $20.6 million, $12.5 million, and $38.3 million, respectively. The total fair value of the vested RSU shares was $9.5 million, $15.5 million, and $20.8 million for 2020, 2019, and 2018, respectively. The total amount of share-based liabilities paid was $0.5 million, $0.9 million and $1.1 million for 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:270]
The Company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At December 26, 2020, the unrecognized compensation cost for options and restricted shares was $22.6 million before tax, and will be recognized over a weighted average period of 2.0 years. Compensation cost included as a component of cost of sales, research and development and selling, general, and administrative expenses for all equity

[0000889331-21-000010:notes:271]
compensation plans discussed above was $19.1 million, $19.9 million, and $28.2 million for 2020, 2019, and 2018, respectively. The total related income tax benefit recognized in the Consolidated Statements of Net Income was $3.1 million, $3.3 million and $6.0 million for 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:272]
The Company uses the Black-Scholes option valuation model to determine the fair value of stock option awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0000889331-21-000010:notes:273]
|  | 2020 |  | 2019 |  | 2018 |
| Weighted average fair value of options granted | $38.09 |  | $47.63 |  | $45.19 |
| Assumptions: |  |  |  |  |  |
| Risk-free interest rate | 0.30% |  | 2.33% |  | 2.79% |
| Expected dividend yield | 1.27% |  | 0.86% |  | 0.77% |
| Expected stock price volatility | 33.0% |  | 27.0% |  | 25.0% |
| Expected life of options (years) | 4.7 |  | 4.4 |  | 4.4 |

[0000889331-21-000010:notes:274]
Expected volatilities are based on the historical volatility of the Company’s stock price. The expected life of options is based on historical data for options granted by the Company. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption. Historical nonvested forfeiture information is the basis for the forfeiture rate assumptions.

[0000889331-21-000010:notes:275]
The fair value of RSU is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-21-000010:notes:276]
Preferred Stock: The Board of Directors may authorize the issuance of preferred stock from time to time in one or more series with such designations, preferences, qualifications, limitations, restrictions, and optional or other special rights as the Board may fix by resolution.

[0000889331-21-000010:notes:277]
Share Repurchase Program

[0000889331-21-000010:notes:278]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized to a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program") to replace its previous expired 2018 program. On April 23, 2020, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. There are 1,000,000 shares remaining available for purchase under the 2020 program as of December 26, 2020.

[0000889331-21-000010:notes:279]
During the fiscal year 2020, 2019, and 2018, the Company repurchased 175,110, 579,916, and 391,972 shares of its common stock totaling $22.9 million, $95.0 million, and  $67.9 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-21-000010:notes:280]
Other Comprehensive Income (Loss)
Changes in other comprehensive income (loss) by component for fiscal years 2020, 2019, and 2018 were as follows:

[0000889331-21-000010:notes:281]
|  | Fiscal Year Ended |
|  | December 26, 2020 |  | December 28, 2019 |  | December 29, 2018 |
| (in thousands) | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |
| Defined benefit pension plan and other adjustments | $ | (19,513) |  |  | $ | 3,418 |  |  | $ | (16,095) |  |  | $ | (9,149) |  |  | $ | 1,062 |  |  | $ | (8,087) |  |  | $ | 924 |  |  | $ | (47) |  |  | $ | 877 |  |
| Foreign currency translation adjustments (1) | 34,707 |  |  | (2,946) |  |  | 31,761 |  |  | (1,476) |  |  | 664 |  |  | (812) |  |  | (25,338) |  |  | — |  |  | (25,338) |  |
| Total change in other comprehensive (loss) income | $ | 15,194 |  |  | $ | 472 |  |  | $ | 15,666 |  |  | $ | (10,625) |  |  | $ | 1,726 |  |  | $ | (8,899) |  |  | $ | (24,414) |  |  | $ | (47) |  |  | $ | (24,461) |  |

[0000889331-21-000010:notes:282]
(1) The tax shown above within the foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries which have been previously taxed in the U.S. and are not permanently reinvested.

[0000889331-21-000010:notes:283]
Accumulated Other Comprehensive Income (Loss) (“AOCI”): The following table sets forth the changes in the components of AOCI by component for fiscal years 2020, 2019, and 2018:

[0000889331-21-000010:notes:284]
| (in thousands) | Pension and postretirement liability and reclassification adjustments |  | Gain (loss) on investments |  | Foreign currency translation adjustments |  | Accumulated other comprehensive income (loss) |
| Balance at December 30, 2017 | $ | (10,836) |  |  | $ | 9,795 |  |  | $ | (62,627) |  |  | $ | (63,668) |  |
| Cumulative effect adjustment (a) | — |  |  | (9,795) |  |  | — |  |  | (9,795) |  |
| 2018 activity | 877 |  |  | — |  |  | (25,338) |  |  | (24,461) |  |
| Balance at December 29, 2018 | (9,959) |  |  | — |  |  | (87,965) |  |  | (97,924) |  |
| 2019 activity | (8,087) |  |  | — |  |  | (812) |  |  | (8,899) |  |
| Balance at December 28, 2019 | (18,046) |  |  | — |  |  | (88,777) |  |  | (106,823) |  |
| 2020 activity | (16,095) |  |  | — |  |  | 31,761 |  |  | 15,666 |  |
| Balance at December 26, 2020 | (34,141) |  |  | — |  |  | (57,016) |  |  | (91,157) |  |

[0000889331-21-000010:notes:285]
(a)The Company adopted ASU 2016-01 on December 31, 2017 on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings. See Note 1, Summary of Significant Accounting Policies and Other Information, for further discussion.

[0000889331-21-000010:notes:286]
Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million to unamortized actuarial loss within other comprehensive income (loss). See Note 11, Benefits Plans for further discussion.

[0000889331-21-000010:notes:287]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for fiscal years 2020, 2019, and 2018 were as follows:

[0000889331-21-000010:notes:288]
|  |  | Fiscal Year Ended |
| (in thousands) |  | December 26, 2020 |  | December 28, 2019 |  | December 29, 2018 |
| Pension and postemployment and other plans: |  |  |  |  |  |  |
| Amortization of prior service, net actuarial loss, and other |  | $ | 1,694 |  |  | $ | 372 |  |  | $ | 291 |  |
| Net settlement loss |  | 236 |  |  | 260 |  |  | 238 |  |
| Total |  | $ | 1,930 |  |  | $ | 632 |  |  | $ | 529 |  |

[0000889331-21-000010:notes:289]
The Company recognizes the amortization of prior service costs and settlement loss and curtailment gain in other income, net within the Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-21-000010:notes:290]
On December 22, 2017, the U.S. enacted legislation referred to as the "Tax Act". Among other things, the Tax Act reduced the U.S. corporate federal income tax rate from 35% to 21%, added base broadening provisions which limit deductions and address excessive international tax planning, imposed a Toll Charge on accumulated earnings of certain non-U.S. subsidiaries and enabled repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax.

[0000889331-21-000010:notes:291]
The Company elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The long-term portion of this Toll Charge which remains payable as of December 26, 2020, totaling $20.8 million, is recorded in Other long-term liabilities, and the anticipated 2021 annual installment payment of $3.0 million is included in Accrued income taxes, on the Consolidated Balance Sheet as of December 26, 2020. The Company did not elect to pay the 2018 IXYS Toll Charge over the eight year period provided by the Tax Act and therefore there is no 2018 IXYS Toll Charge which remains payable as of December 26, 2020.

[0000889331-21-000010:notes:292]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 26, 2020, December 28, 2019 and December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-21-000010:notes:293]
Domestic and foreign income (loss) before income taxes is as follows:

[0000889331-21-000010:notes:294]
| (in thousands) | 2020 |  | 2019 |  | 2018 |
| Domestic | $ | (16,732) |  |  | $ | (11,970) |  |  | $ | (49,995) |  |
| Foreign | 177,985 |  |  | 177,854 |  |  | 254,937 |  |
| Income before income taxes | $ | 161,253 |  |  | $ | 165,884 |  |  | $ | 204,942 |  |

[0000889331-21-000010:notes:295]
Federal, state and foreign income tax expense (benefit) consists of the following:

[0000889331-21-000010:notes:296]
| (in thousands) | 2020 |  | 2019 |  | 2018 |
| Current: |  |  |  |  |  |
| Federal | $ | 437 |  |  | $ | (3,495) |  |  | $ | (3,193) |  |
| State | 203 |  |  | 834 |  |  | 119 |  |
| Foreign | 33,841 |  |  | 30,610 |  |  | 48,130 |  |
| Subtotal | 34,481 |  |  | 27,949 |  |  | 45,056 |  |
| Deferred: |  |  |  |  |  |
| Federal and State | (5,354) |  |  | 1,839 |  |  | (3,896) |  |
| Foreign | 2,140 |  |  | (2,986) |  |  | (783) |  |
| Subtotal | (3,214) |  |  | (1,147) |  |  | (4,679) |  |
| Provision for income taxes | $ | 31,267 |  |  | $ | 26,802 |  |  | $ | 40,377 |  |

[0000889331-21-000010:notes:297]
The current federal tax benefit for 2019 includes a benefit of $3.3 million from the recognition of previously unrecognized tax benefits (and the reversal of the related accrued interest) due to a lapse in the statute of limitations.

[0000889331-21-000010:notes:298]
The current federal tax benefit for 2018 includes the benefit of current year losses (which served to partially offset the amount of the IXYS Toll Charge that would otherwise have been payable).

[0000889331-21-000010:notes:299]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0000889331-21-000010:notes:300]
| (in thousands) | 2020 |  | 2019 |  | 2018 |
| Tax expense at statutory rate of 21% | $ | 33,863 |  |  | $ | 34,836 |  |  | $ | 43,038 |  |
| Non-U.S. income tax rate differential | (19,730) |  |  | (22,457) |  |  | (20,472) |  |
| Tax impact of non-deductible goodwill impairment charge | 5,642 |  |  | — |  |  | — |  |
| Tax on unremitted earnings | 3,955 |  |  | 2,136 |  |  | 4,660 |  |
| Net impact associated with the GILTI tax provisions | 3,731 |  |  | 6,469 |  |  | 5,075 |  |
| Non-U.S. losses and expenses with no tax benefit | 2,774 |  |  | 6,570 |  |  | 3,107 |  |
| Certain changes in unrecognized tax benefits and related accrued interest | 2,160 |  |  | (1,468) |  |  | 208 |  |
| State and local taxes, net of federal tax benefit | (584) |  |  | 1,080 |  |  | (1,238) |  |
| Nondeductible professional fees | 236 |  |  | 195 |  |  | 1,001 |  |
| 2017 Toll Charge (2018 adjustment) | — |  |  | — |  |  | 2,278 |  |
| Provisional Tax Act impact other than Toll Charge (2018 adjustment) | — |  |  | — |  |  | 966 |  |
| Other, net | (780) |  |  | (559) |  |  | 1,754 |  |
| Provision for income taxes | $ | 31,267 |  |  | $ | 26,802 |  |  | $ | 40,377 |  |

[0000889331-21-000010:notes:301]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the company’s assets and liabilities. Significant components of the company’s deferred tax assets and liabilities at December 26, 2020 and December 28, 2019, are as follows:

[0000889331-21-000010:notes:302]
| (in thousands) | 2020 |  | 2019 |
| Deferred tax assets: |  |  |  |
| Accrued expenses and reserves | $ | 31,123 |  |  | $ | 28,294 |  |
| Domestic and non-U.S. net operating loss carryforwards | 24,763 |  |  | 10,511 |  |
| Non-U.S. interest expense carryforwards | 10,352 |  |  | 5,324 |  |
| U.S. research credit carryforwards | 3,724 |  |  | 2,581 |  |
| Capitalized expenses | 4,178 |  |  | 2,400 |  |
| U.S. foreign tax credit carryforwards | 772 |  |  | 1,320 |  |
| Other | 117 |  |  | 1,261 |  |
| Gross deferred tax assets | 75,029 |  |  | 51,691 |  |
| Less: Valuation allowance | (13,131) |  |  | (5,957) |  |
| Total deferred tax assets | 61,898 |  |  | 45,734 |  |
| Deferred tax liabilities: |  |  |  |
| Excess of book basis over the tax basis for intangible assets and goodwill | 76,472 |  |  | 71,229 |  |
| Tax on unremitted earnings | 14,223 |  |  | 12,968 |  |
| Unrealized foreign currency exchange gains | 5,719 |  |  | — |  |
| Excess of book basis over the tax basis for property, plant, and equipment | 4,394 |  |  | 3,231 |  |
| Total deferred tax liabilities | 100,808 |  |  | 87,428 |  |
| Net deferred tax liabilities | $ | 38,910 |  |  | $ | 41,694 |  |

[0000889331-21-000010:notes:303]
The deferred tax asset valuation allowance is related to certain non-U.S. net operating loss and non-U.S. interest expense carryforwards which are not expected to be realized. The remaining U.S. and non-U.S. net operating loss and non-U.S. interest expense carryforwards either have no expiration date or are expected to be utilized prior to expiration. No deferred tax asset nor valuation allowance has been recorded for certain U.S. and non-U.S. net operating loss carryforwards for which the possibility of usage has been determined to be remote.

[0000889331-21-000010:notes:304]
The Company paid income taxes of $35.2 million, $47.6 million, and $46.2 million in 2020, 2019, and 2018, respectively, and received income tax refunds of $7.6 million, $7.1 million, and $4.3 million in 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:305]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. The Company believes the determination of the amount of such deferred income taxes is impractical as it would depend upon income tax laws and circumstances at the time of the hypothetical distributions or dispositions. As of December 26, 2020, unremitted earnings of the Company’s non-U.S. subsidiaries was approximately $767 million. A distribution of such earnings will generally not be subject to U.S. federal income tax. The Company recognized deferred tax liabilities of $14.2 million ($13.9 million for non-U.S. taxes net of related U.S. foreign tax credits, and $0.3 million for U.S. state taxes) as of December 26, 2020 and $13.0 million ($12.6 million for non-U.S. taxes net of related U.S. foreign tax credits, and $0.4 million for U.S. state taxes) as of December 28, 2019, related to taxes on certain non-U.S. earnings which are not considered to be permanently reinvested. Some of these non-U.S. taxes will provide a U.S. federal income tax benefit as a foreign tax credit, and the amounts as of December 26, 2020 and December 28, 2019 are net of such benefit.

[0000889331-21-000010:notes:306]
The Company has two subsidiaries in China which benefit from lowered income tax rates due to “tax holidays” which apply for three-year periods, subject to extension. The tax holiday for one of these subsidiaries expired at the end of 2020, and it will seek an extension. Such tax holidays contributed $4.1 million in tax benefits, or $0.17 per diluted share, during 2020. Future year tax benefits will depend upon the Company’s ability to obtain extensions, and the level of income earned by the two applicable subsidiaries.

[0000889331-21-000010:notes:307]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of December 26, 2020, December 28, 2019, and December 29, 2018 is as follows:

[0000889331-21-000010:notes:308]
| (in thousands) | Unrecognized Tax Benefits |
| Balance at December 29, 2018 | $ | 18,259 |  |
| Additions for tax positions taken in the current year | 1,305 |  |
| Decreases due to a lapse in the statute of limitations | (2,758) |  |
| Other | (85) |  |
| Balance at December 28, 2019 | 16,721 |  |
| Additions for tax positions taken in the current year | 700 |  |
| Decreases due to a lapse in the statute of limitations | (103) |  |
| Other | 119 |  |
| Balance at December 26, 2020 | 17,437 |  |

[0000889331-21-000010:notes:309]
The company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense. The company recognized such interest expense of $1.6 million, $1.3 million (net of a $0.6 million decrease due to a lapse in the statute of limitations), and $1.5 million (net of a $0.3 million decrease due to a lapse in the statute of limitations) in 2020, 2019, and 2018, respectively. Accrued interest for such matters included in Other long-term liabilities within the Consolidated Balance Sheets was $8.8 million and $7.2 million as of December 26, 2020 and December 28, 2019, respectively.

[0000889331-21-000010:notes:310]
The amount of unrecognized tax benefits included in Other long-term liabilities within the Consolidated Balance Sheets was $17.4 million and 16.7 million as of December 26, 2020 and December 28, 2019, respectively. The December 26, 2020 total represents the net amount of tax benefits that, if recognized, would favorably affect the effective tax rate in future periods. Of this amount, only an insignificant amount may be recognized in 2021 based upon the possible lapse in the statute of limitations. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility.

[0000889331-21-000010:notes:311]
The U.S. federal statute of limitations remains open for the Company for the 2017 tax year and later years. The U.S. federal statute of limitations remains open for the IXYS pre-acquisition tax period ending January 17, 2018. Non-U.S. and U.S. state statutes of limitations generally range from three to seven years, although certain jurisdictions do not have a statute expiration. Non-U.S. tax examinations occur from time to time, including examinations currently in process in Italy, the Philippines, and Hong Kong. The company does not expect to recognize a significant amount of additional tax expense as a result of concluding these examinations. The Company has been informed that it will receive a notice of assessment from the Canadian tax authorities as a consequence of concluding their recent audit. Although the exact amount of the assessment is not known, it is estimated to approximate $3 million. The Company believes the assessment is in error and intends to appeal. The Company does not expect to recognize a significant amount of additional tax expense upon conclusion of such appeal.


## us-gaap:EarningsPerShareTextBlock

[0000889331-21-000010:notes:312]
Earnings Per Share

[0000889331-21-000010:notes:313]
The following table sets forth the computation of basic and diluted earnings per share:

[0000889331-21-000010:notes:314]
| (in thousands, except per share amounts) | 2020 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |
| Net income as reported | $ | 129,986 |  |  | $ | 139,082 |  |  | $ | 164,565 |  |
| Denominator: |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |
| Basic | 24,371 |  |  | 24,576 |  |  | 24,870 |  |
| Effect of dilutive securities | 221 |  |  | 242 |  |  | 365 |  |
| Diluted | 24,592 |  |  | 24,818 |  |  | 25,235 |  |
| Earnings Per Share: |  |  |  |  |  |
| Basic earnings per share | $ | 5.33 |  |  | $ | 5.66 |  |  | $ | 6.62 |  |
| Diluted earnings per share | $ | 5.29 |  |  | $ | 5.60 |  |  | $ | 6.52 |  |

[0000889331-21-000010:notes:315]
Potential shares of common stock attributable to stock options and restricted shares excluded from the earnings per share calculation because their effect would be anti-dilutive were 222,526, 129,658, and 42,305 shares in 2020, 2019, and 2018, respectively.

[0000889331-21-000010:notes:316]
On January 17, 2018, the Company acquired IXYS through a combination of cash, Littelfuse common stock, and the value of converted, or cash settled IXYS equity awards. The Company issued approximately 2.1 million shares of Littelfuse common stock and converted IXYS equity awards into approximately 0.5 million Littelfuse equity awards.
During the fiscal year 2020, 2019, and 2018, the Company repurchased 175,110, 579,916, and 391,972 shares of its common stock totaling $22.9 million, $95.0 million, and $67.9 million, respectively. See Note 12 Stock-Based Compensation for further discussion.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-21-000010:notes:317]
Segment Information

[0000889331-21-000010:notes:318]
The Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-21-000010:notes:319]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it.  Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-21-000010:notes:320]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, metal-

[0000889331-21-000010:notes:321]
oxide-semiconductor field effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related infrastructure, power supplies, data centers and telecommunications, medical devices, alternative energy, building and home automation, appliances, and mobile electronics.

[0000889331-21-000010:notes:322]
•Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle end markets. Passenger car fuse products for internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules used in applications serving a number of end markets, including heavy truck, construction, agriculture and material handling. Automotive sensor products include a wide range of automotive and commercial vehicle products designed to monitor the passenger compartment occupant's safety and environment as well as the vehicle’s powertrain.

[0000889331-21-000010:notes:323]
•Industrial Segment: Consists of power fuses, protection relays and controls, temperature sensor and other circuit protection products for use in various industrial applications such as oil, gas, mining, renewables and energy storage, electric vehicle infrastructure, non-residential construction, HVAC systems, industrial safety, power conversion, elevators and other industrial equipment.

[0000889331-21-000010:notes:324]
The Company has provided this segment information for all comparable prior periods. Segment information is summarized as follows:

[0000889331-21-000010:notes:325]
| (in thousands) | 2020 |  | 2019 |  | 2018 |
| Net sales |  |  |  |  |  |
| Electronics | $ | 937,762 |  |  | $ | 961,080 |  |  | $ | 1,124,296 |  |
| Automotive | 395,764 |  |  | 428,533 |  |  | 479,791 |  |
| Industrial | 112,169 |  |  | 114,260 |  |  | 114,381 |  |
| Total net sales | $ | 1,445,695 |  |  | $ | 1,503,873 |  |  | $ | 1,718,468 |  |
| Depreciation and amortization |  |  |  |  |  |
| Electronics | $ | 62,702 |  |  | $ | 60,345 |  |  | $ | 61,779 |  |
| Automotive | 28,995 |  |  | 27,922 |  |  | 23,333 |  |
| Industrial | 4,481 |  |  | 4,236 |  |  | 5,661 |  |
| Other | — |  |  | — |  |  | 12,420 |  |
| Total depreciation and amortization | $ | 96,178 |  |  | $ | 92,503 |  |  | $ | 103,193 |  |
| Operating income (loss) |  |  |  |  |  |
| Electronics | $ | 152,695 |  |  | $ | 145,594 |  |  | $ | 241,426 |  |
| Automotive | 41,655 |  |  | 46,719 |  |  | 54,982 |  |
| Industrial | 11,996 |  |  | 22,407 |  |  | 17,335 |  |
| Other(a) | (43,974) |  |  | (21,929) |  |  | (88,694) |  |
| Total operating income | 162,372 |  |  | 192,791 |  |  | 225,049 |  |
| Interest expense | 21,077 |  |  | 22,266 |  |  | 22,569 |  |
| Foreign exchange (gain) loss | (14,875) |  |  | 5,224 |  |  | (863) |  |
| Other income, net | (5,083) |  |  | (583) |  |  | (1,599) |  |
| Income before income taxes | $ | 161,253 |  |  | $ | 165,884 |  |  | $ | 204,942 |  |

[0000889331-21-000010:notes:326]
(a) Included in “Other” Operating income (loss) for 2020 is $2.3 million of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $41.7 million of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, employee termination costs of $5.5 million, $2.2 million of impairment charges recorded in the first quarter associated with the announced consolidation of a

[0000889331-21-000010:notes:327]
manufacturing facility within the Industrial segment and other restructuring charges of $0.2 million. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-21-000010:notes:328]
Included in “Other” Operating income (loss) for 2019 is $8.9 million of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $13.0 million of restructuring charges primarily related to employee termination costs.

[0000889331-21-000010:notes:329]
Included in “Other” Operating income (loss) for 2018 is $88.7 million of charges primarily related to the IXYS acquisition, which include $36.9 million of purchase accounting inventory step-up charges, $18.7 million  in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $12.4 million in backlog amortization costs, $8.3 million of employee termination costs, impairment and other restructuring charges, and $4.5 million in stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million change in control expense related to IXYS. In addition, there were $5.8 million of employee termination costs, impairment and other restructuring charges and acquisition-related expenses for other contemplated acquisitions which included $2.2 million of impairment charges primarily related to the impairment of a building and a trade name associated with the exit of the Custom business within the Industrial segment.

[0000889331-21-000010:notes:330]
The Company’s net sales, long-lived assets and additions to long-lived assets by country for the fiscal years ended 2020, 2019, and 2018 are as follows:

[0000889331-21-000010:notes:331]
| (in thousands) | 2020 |  | 2019 |  | 2018 |
| Net sales |  |  |  |  |  |
| United States | $ | 392,544 |  |  | $ | 440,461 |  |  | $ | 511,544 |  |
| China | 438,000 |  |  | 416,385 |  |  | 468,174 |  |
| Other countries(a) | 615,151 |  |  | 647,027 |  |  | 738,750 |  |
| Total net sales | $ | 1,445,695 |  |  | $ | 1,503,873 |  |  | $ | 1,718,468 |  |
| Long-lived assets |  |  |  |  |  |
| United States | $ | 46,132 |  |  | $ | 58,081 |  |  | $ | 58,691 |  |
| China | 85,876 |  |  | 88,306 |  |  | 95,806 |  |
| Mexico | 70,125 |  |  | 73,096 |  |  | 70,495 |  |
| Germany | 37,976 |  |  | 36,025 |  |  | 36,548 |  |
| Philippines | 66,994 |  |  | 51,738 |  |  | 32,459 |  |
| Other countries | 37,075 |  |  | 37,371 |  |  | 45,895 |  |
| Total long-lived assets | $ | 344,178 |  |  | $ | 344,617 |  |  | $ | 339,894 |  |
| Additions to long-lived assets |  |  |  |  |  |
| United States | $ | 4,170 |  |  | $ | 5,864 |  |  | $ | 5,567 |  |
| China | 10,074 |  |  | 10,400 |  |  | 29,286 |  |
| Mexico | 9,977 |  |  | 13,827 |  |  | 18,723 |  |
| Germany | 5,600 |  |  | 4,017 |  |  | 5,208 |  |
| Philippines | 19,612 |  |  | 22,944 |  |  | 7,605 |  |
| Other countries | 1,775 |  |  | 9,314 |  |  | 8,364 |  |
| Total additions to long-lived assets | $ | 51,208 |  |  | $ | 66,366 |  |  | $ | 74,753 |  |

[0000889331-21-000010:notes:332]
(a)Each country included in other countries are less than 10% of net sales.

[0000889331-21-000010:notes:333]
For the year ended December 26, 2020, approximately 73% of the Company’s net sales were to customers outside the United States (exports and foreign operations), including approximately 30% to China. For the year ended December 28, 2019, approximately 71% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 28% to China. For the year ended December 29, 2018, approximately 70% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 27% to China. Sales to Arrow Electronics, Inc., which were included in the Electronics, Automotive, and Industrial segments, were 10.4%, 10.7%, and 10.7% 
of consolidated net sales in 2020, 2019, and 2018 respectively. No other single customer accounted for more than 10% of net sales during the last three years.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000889331-21-000010:notes:334]
Selected Quarterly Financial Data (Unaudited)

[0000889331-21-000010:notes:335]
The quarterly periods for 2020 are for the 13-weeks ended December 26, 2020, September 26, 2020, June 27, 2020, and March 28, 2020, respectively. The quarterly periods for 2019 are for the 13-weeks ended December 28, 2019, September 28, 2019, June 29, 2019, and March 30, 2019, respectively.

[0000889331-21-000010:notes:336]
| (in thousands, except per share data) |  |  |
|  | 2020 |  | 2019 |
|  | 4Q(a) |  | 3Q(b) |  | 2Q(c) |  | 1Q(d) |  | 4Q(e) |  | 3Q(f) |  | 2Q(g) |  | 1Q(h) |
| Net sales | $ | 400,696 |  |  | $ | 391,566 |  |  | $ | 307,337 |  |  | $ | 346,096 |  |  | $ | 338,523 |  |  | $ | 361,971 |  |  | $ | 397,879 |  |  | $ | 405,500 |  |
| Gross profit (1) | 138,083 |  |  | 138,831 |  |  | 99,902 |  |  | 124,356 |  |  | 113,735 |  |  | 132,708 |  |  | 144,308 |  |  | 155,544 |  |
| Operating income | 65,014 |  |  | 64,558 |  |  | (11,950) |  |  | 44,750 |  |  | 32,317 |  |  | 47,167 |  |  | 52,634 |  |  | 60,673 |  |
| Net income | 58,977 |  |  | 55,356 |  |  | (8,991) |  |  | 24,644 |  |  | 22,654 |  |  | 35,647 |  |  | 43,792 |  |  | 36,989 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 2.41 |  |  | $ | 2.27 |  |  | $ | (0.37) |  |  | $ | 1.01 |  |  | $ | 0.93 |  |  | $ | 1.46 |  |  | $ | 1.77 |  |  | $ | 1.50 |  |
| Diluted | $ | 2.39 |  |  | $ | 2.25 |  |  | $ | (0.37) |  |  | $ | 1.00 |  |  | $ | 0.92 |  |  | $ | 1.44 |  |  | $ | 1.75 |  |  | $ | 1.48 |  |

[0000889331-21-000010:notes:337]
(1) The prior year gross profit amounts have been reclassified to reflect a change in classification of certain costs presented on the Company’s Consolidated Statements of Income. See Note 1, Summary of Significant Accounting Policies and Other Information for further information and this change had no impact on previously reported operating income and net income amounts.

[0000889331-21-000010:notes:338]
(a)In the fourth quarter of 2020, the Company recorded $0.7 million in acquisition-related and integration costs and $0.8 million in restructuring, impairment and other charges.

[0000889331-21-000010:notes:339]
(b)In the third quarter of 2020, the Company recorded $1.3 million in restructuring, impairment and other charges, $0.3 million in acquisition-related and integration costs, and $0.1 million of impairment charges on certain other investments.

[0000889331-21-000010:notes:340]
(c)In the second quarter of 2020, the Company recorded a goodwill impairment charge of $33.8 million associated with the automotive sensors reporting unit within the Automotive segment, $1.8 million in employee termination costs and other restructuring charges, $1.8 million increase to coal mining reserve, $0.2 million charge for an asset retirement obligation related to the disposal of a business in 2019, and $0.1 million in acquisition-related and integration costs.

[0000889331-21-000010:notes:341]
(d)In the first quarter of 2020, the Company recorded $4.0 million in restructuring, impairment and other charges and $1.2 million in acquisition-related and integration costs.

[0000889331-21-000010:notes:342]
(e)In the fourth quarter of 2019, the Company recorded $1.9 million in acquisition-related and integration costs and $2.1 million in restructuring, impairment and other costs, and $4.2 million impairment charges related to certain other investments, partially offset by a $3.3 million benefit for previously unrecognized tax benefits in respect of which the statute of limitation has expired.

[0000889331-21-000010:notes:343]
(f)In the third quarter of 2019, the Company recorded $3.2 million in acquisition-related and integration costs and $2.5 million in restructuring and impairment charges.

[0000889331-21-000010:notes:344]
(g)In the second quarter of 2019, the Company recorded $5.7 million in restructuring and impairment charges, $1.5 million in acquisition-related and integration costs, and $0.4 million costs primarily related to a sale of building and $0.2 million impairment charges related to a certain other investment.

[0000889331-21-000010:notes:345]
(h)In the first quarter of 2019, the Company recorded $2.8 million impairment charges to certain other investments, $2.6 million loss on the disposal of a business, $2.7 million in restructuring costs, $2.4 million in acquisition-related and integration costs, and $0.3 million gain primarily related to the final payments for the acquisition of Monolith.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-21-000010:notes:346]
Related Party Transactions

[0000889331-21-000010:notes:347]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-21-000010:notes:348]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-21-000010:notes:349]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB-Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-21-000010:notes:350]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-21-000010:notes:351]
|  | Fiscal Year Ended |
|  | December 26, 2020 |  | December 29, 2019 |
| (in millions) | Powersem |  | EB Tech |  | ATEC |  | Powersem |  | EB Tech |  | ATEC |
| Sales to related party | $ | 1.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | — |  |  | $ | — |  |
| Purchase material/service from related party | 2.7 |  |  | — |  |  | 8.7 |  |  | 3.2 |  |  | 0.4 |  |  | 7.9 |  |
| Accounts receivable balance | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Accounts payable balance | $ | 0.1 |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.1 |  |

[0000889331-21-000010:notes:352]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.5 million as of December 26, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income, net in the Consolidated Statements of Net Income. The operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.


## us-gaap:SubsequentEventsTextBlock

[0000889331-21-000010:notes:353]
Subsequent EventsOn January 28, 2021, the Company acquired Hartland Controls, a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The cash purchase price for Hartland Controls was approximately $113 million and the operations of Hartland Controls will be included in the Industrial segment.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000889331-21-000010:notes:354]
SCHEDULE II

[0000889331-21-000010:notes:355]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0000889331-21-000010:notes:356]
| Description | Balance atBeginningof Year |  | Charged toCosts andExpenses (a) |  | Deductions (b) |  | Other (c) |  | Balance atEndof Year |
| (in thousands) |  |  |  |  |  |  |  |  |  |
| Fiscal year ended December 26, 2020 |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable | $ | 1,310 |  |  | $ | 1,170 |  |  | $ | (329) |  |  | $ | (751) |  |  | $ | 1,400 |  |
| Reserves for sales discounts and allowances | $ | 40,733 |  |  | $ | 113,709 |  |  | $ | (112,401) |  |  | $ | 1,796 |  |  | $ | 43,837 |  |
| Fiscal year ended December 28, 2019 |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable | $ | 1,062 |  |  | $ | 410 |  |  | $ | (172) |  |  | $ | 10 |  |  | $ | 1,310 |  |
| Reserves for sales discounts and allowances | $ | 34,976 |  |  | $ | 133,434 |  |  | $ | (127,330) |  |  | $ | (347) |  |  | $ | 40,733 |  |
| Fiscal year ended December 29, 2018 |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable | $ | 1,172 |  |  | $ | 319 |  |  | $ | (557) |  |  | $ | 128 |  |  | $ | 1,062 |  |
| Reserves for sales discounts and allowances | $ | 26,344 |  |  | $ | 124,638 |  |  | $ | (118,438) |  |  | $ | 2,432 |  |  | $ | 34,976 |  |

[0000889331-21-000010:notes:357]
(a)Includes provision for doubtful accounts, sales returns and sales discounts granted to customers.

[0000889331-21-000010:notes:358]
(b)Represents uncollectible accounts written off, net of recoveries and credits issued to customers.

[0000889331-21-000010:notes:359]
(c)Represents business acquisitions and foreign currency translation adjustments.
