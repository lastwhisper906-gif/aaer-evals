# LFUS note change history — 0000889331-20-000045 → 0000889331-20-000054


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-28):
[0000889331-20-000054:note_history:1]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2019 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2020-07-29, similarity 0.9941):
[0000889331-20-000045:note_history:1]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net (loss) income and comprehensive (loss) income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2019 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

- changed (2020-10-28):
[0000889331-20-000054:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 26, 2020 and September 28, 2019:
  (was, 2020-07-29, similarity 0.9066):
[0000889331-20-000045:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 27, 2020 and June 29, 2019:

- added (2020-10-28):
[0000889331-20-000054:note_history:3]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- added (2020-10-28):
[0000889331-20-000054:note_history:4]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- changed (2020-10-28):
[0000889331-20-000054:note_history:5]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement."  ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies other disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018-13 did not have a material impact on our Condensed Consolidated Financial Statements.
  (was, 2020-07-29, similarity 0.9993):
[0000889331-20-000045:note_history:5]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement."  ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies other disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018- 13 did not have a material impact on our Condensed Consolidated Financial Statements.

- removed (2020-10-28):
[0000889331-20-000045:note_history:6]
|  |  | Three Months Ended June 27, 2020 |  |  |  |  |  |  |  | Six Months Ended June 27, 2020 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

- removed (2020-10-28):
[0000889331-20-000045:note_history:7]
|  |  | Three Months Ended June 29, 2019 |  |  |  |  |  |  |  | Six Months Ended June 29, 2019 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-28):
[0000889331-20-000054:note_history:8]
The carrying amounts of debt at September 26, 2020 and December 28, 2019 are as follows:
  (was, 2020-07-29, similarity 0.9272):
[0000889331-20-000045:note_history:8]
The carrying amounts of debt at June 27, 2020 and December 28, 2019 are as follows:

- changed (2020-10-28):
[0000889331-20-000054:note_history:9]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 180,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,417 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,295) |  |  | (3,669) |  |
| Total debt |  | 725,507 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 725,507 |  |  | $ | 669,158 |  |
  (was, 2020-07-29, similarity 0.9751):
[0000889331-20-000045:note_history:9]
| (in thousands) |  | June 27,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 240,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,378 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,675 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,467) |  |  | (3,669) |  |
| Total debt |  | 776,205 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 776,205 |  |  | $ | 669,158 |  |

- added (2020-10-28):
[0000889331-20-000054:note_history:10]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size

- changed (2020-10-28):
[0000889331-20-000054:note_history:11]
of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.
  (was, 2020-07-29, similarity 0.6744):
[0000889331-20-000045:note_history:11]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $2.5 million and $5.0 million of principal payments on the term loan during the three and six months ended June 27, 2020, respectively.

- changed (2020-10-28):
[0000889331-20-000054:note_history:12]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $60.0 million on the amended revolving credit facility during the three months ended September 26, 2020. The balance under the facility was $180.0 million as of September 26, 2020.
  (was, 2020-07-29, similarity 0.8897):
[0000889331-20-000045:note_history:12]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.

- changed (2020-10-28):
[0000889331-20-000054:note_history:13]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.90% at September 26, 2020.
  (was, 2020-07-29, similarity 0.9862):
[0000889331-20-000045:note_history:13]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.70% at June 27, 2020.

- added (2020-10-28):
[0000889331-20-000054:note_history:14]
As of September 26, 2020, the Company had no amount outstanding in letters of credit and had available $245.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 26, 2020, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2020-10-28):
[0000889331-20-000054:note_history:15]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 26, 2020, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2020-07-29, similarity 0.9396):
[0000889331-20-000045:note_history:15]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 27, 2020, the Company was in compliance with all covenants under the Senior Notes.

- changed (2020-10-28):
[0000889331-20-000054:note_history:16]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
  (was, 2020-07-29, similarity 0.703):
[0000889331-20-000045:note_history:16]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
Interest paid on all Company debt was $3.4 million and $3.5 million for the three months ended June 27, 2020 and June 29, 2019, respectively, and $10.8 million and $11.5 million for the six months ended June 27, 2020 and June 29, 2019, respectively.

- added (2020-10-28):
[0000889331-20-000054:note_history:17]
Interest paid on all Company debt was $6.4 million for the three months ended September 26, 2020 and September 28, 2019, and $17.2 million and $17.9 million for the nine months ended September 26, 2020 and September 28, 2019, respectively.

- removed (2020-10-28):
[0000889331-20-000045:note_history:18]
As of June 27, 2020, the Company had no amount outstanding in letters of credit and had available $148.6 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At June 27, 2020, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2020-10-28):
[0000889331-20-000054:note_history:19]
The carrying amounts of debt at September 26, 2020 and December 28, 2019 are as follows:
  (was, 2020-07-29, similarity 0.9272):
[0000889331-20-000045:note_history:19]
The carrying amounts of debt at June 27, 2020 and December 28, 2019 are as follows:

- changed (2020-10-28):
[0000889331-20-000054:note_history:20]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 180,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,417 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,295) |  |  | (3,669) |  |
| Total debt |  | 725,507 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 725,507 |  |  | $ | 669,158 |  |
  (was, 2020-07-29, similarity 0.9751):
[0000889331-20-000045:note_history:20]
| (in thousands) |  | June 27,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 240,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,378 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,675 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,467) |  |  | (3,669) |  |
| Total debt |  | 776,205 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 776,205 |  |  | $ | 669,158 |  |

- added (2020-10-28):
[0000889331-20-000054:note_history:21]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size

- changed (2020-10-28):
[0000889331-20-000054:note_history:22]
of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.
  (was, 2020-07-29, similarity 0.6744):
[0000889331-20-000045:note_history:22]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $2.5 million and $5.0 million of principal payments on the term loan during the three and six months ended June 27, 2020, respectively.

- changed (2020-10-28):
[0000889331-20-000054:note_history:23]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $60.0 million on the amended revolving credit facility during the three months ended September 26, 2020. The balance under the facility was $180.0 million as of September 26, 2020.
  (was, 2020-07-29, similarity 0.8897):
[0000889331-20-000045:note_history:23]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.

- changed (2020-10-28):
[0000889331-20-000054:note_history:24]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.90% at September 26, 2020.
  (was, 2020-07-29, similarity 0.9862):
[0000889331-20-000045:note_history:24]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.70% at June 27, 2020.

- added (2020-10-28):
[0000889331-20-000054:note_history:25]
As of September 26, 2020, the Company had no amount outstanding in letters of credit and had available $245.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 26, 2020, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2020-10-28):
[0000889331-20-000054:note_history:26]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 26, 2020, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2020-07-29, similarity 0.9396):
[0000889331-20-000045:note_history:26]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 27, 2020, the Company was in compliance with all covenants under the Senior Notes.

- changed (2020-10-28):
[0000889331-20-000054:note_history:27]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
  (was, 2020-07-29, similarity 0.703):
[0000889331-20-000045:note_history:27]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
Interest paid on all Company debt was $3.4 million and $3.5 million for the three months ended June 27, 2020 and June 29, 2019, respectively, and $10.8 million and $11.5 million for the six months ended June 27, 2020 and June 29, 2019, respectively.

- added (2020-10-28):
[0000889331-20-000054:note_history:28]
Interest paid on all Company debt was $6.4 million for the three months ended September 26, 2020 and September 28, 2019, and $17.2 million and $17.9 million for the nine months ended September 26, 2020 and September 28, 2019, respectively.

- removed (2020-10-28):
[0000889331-20-000045:note_history:29]
As of June 27, 2020, the Company had no amount outstanding in letters of credit and had available $148.6 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At June 27, 2020, the Company was in compliance with all covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-28):
[0000889331-20-000054:note_history:30]
The carrying amounts of debt at September 26, 2020 and December 28, 2019 are as follows:
  (was, 2020-07-29, similarity 0.9272):
[0000889331-20-000045:note_history:30]
The carrying amounts of debt at June 27, 2020 and December 28, 2019 are as follows:

- changed (2020-10-28):
[0000889331-20-000054:note_history:31]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 180,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,417 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,295) |  |  | (3,669) |  |
| Total debt |  | 725,507 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 725,507 |  |  | $ | 669,158 |  |
  (was, 2020-07-29, similarity 0.9751):
[0000889331-20-000045:note_history:31]
| (in thousands) |  | June 27,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 240,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,378 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,675 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,467) |  |  | (3,669) |  |
| Total debt |  | 776,205 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 776,205 |  |  | $ | 669,158 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-10-28):
[0000889331-20-000054:note_history:32]
|  |  | For the Three Months Ended September 26, 2020 |  | For the Three Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 2.4 |  |  | 0.8 |  | 0.1 |  | 1.7 |  |
|  |  | For the Nine Months Ended September 26, 2020 |  | For the Nine Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.1 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | — |  | 5.8 |  |  | 2.4 |  | 0.3 |  | 5.5 |  |
|  |  | September 26, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |
  (was, 2020-07-29, similarity 0.8813):
[0000889331-20-000045:note_history:32]
|  |  | For the Three Months Ended June 27, 2020 |  |  |  | For the Three Months Ended June 29, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 1.6 |  |  | 0.9 |  | 0.1 |  | 2.3 |  |
|  |  | For the Six Months Ended June 27, 2020 |  |  |  | For the Six Months Ended June 29, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.0 |  | — |  | 3.4 |  |  | 1.7 |  | 0.2 |  | 3.8 |  |
|  |  | June 27, 2020 |  |  |  | December 28, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.2 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |

- added (2020-10-28):
[0000889331-20-000054:note_history:33]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.5 million as of September 26, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

- changed (2020-10-28):
[0000889331-20-000054:note_history:34]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income, net in the Condensed Consolidated Statements of Net Income. The operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.
  (was, 2020-07-29, similarity 0.9774):
[0000889331-20-000045:note_history:34]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net (Loss) Income. The 
operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.

- removed (2020-10-28):
[0000889331-20-000045:note_history:35]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.4 million as of June 27, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-10-28):
[0000889331-20-000054:note_history:36]
|  |  | For the Three Months Ended September 26, 2020 |  | For the Three Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 2.4 |  |  | 0.8 |  | 0.1 |  | 1.7 |  |
|  |  | For the Nine Months Ended September 26, 2020 |  | For the Nine Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.1 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | — |  | 5.8 |  |  | 2.4 |  | 0.3 |  | 5.5 |  |
|  |  | September 26, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |
  (was, 2020-07-29, similarity 0.8813):
[0000889331-20-000045:note_history:36]
|  |  | For the Three Months Ended June 27, 2020 |  |  |  | For the Three Months Ended June 29, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 1.6 |  |  | 0.9 |  | 0.1 |  | 2.3 |  |
|  |  | For the Six Months Ended June 27, 2020 |  |  |  | For the Six Months Ended June 29, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.0 |  | — |  | 3.4 |  |  | 1.7 |  | 0.2 |  | 3.8 |  |
|  |  | June 27, 2020 |  |  |  | December 28, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.2 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-28):
[0000889331-20-000054:note_history:37]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 26, 2020 and September 28, 2019:
  (was, 2020-07-29, similarity 0.9066):
[0000889331-20-000045:note_history:37]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 27, 2020 and June 29, 2019:

- added (2020-10-28):
[0000889331-20-000054:note_history:38]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- added (2020-10-28):
[0000889331-20-000054:note_history:39]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- removed (2020-10-28):
[0000889331-20-000045:note_history:40]
|  |  | Three Months Ended June 27, 2020 |  |  |  |  |  |  |  | Six Months Ended June 27, 2020 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

- removed (2020-10-28):
[0000889331-20-000045:note_history:41]
|  |  | Three Months Ended June 29, 2019 |  |  |  |  |  |  |  | Six Months Ended June 29, 2019 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-28):
[0000889331-20-000054:note_history:42]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 26, 2020 and September 28, 2019:
  (was, 2020-07-29, similarity 0.9066):
[0000889331-20-000045:note_history:42]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 27, 2020 and June 29, 2019:

- added (2020-10-28):
[0000889331-20-000054:note_history:43]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- added (2020-10-28):
[0000889331-20-000054:note_history:44]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- removed (2020-10-28):
[0000889331-20-000045:note_history:45]
|  |  | Three Months Ended June 27, 2020 |  |  |  |  |  |  |  | Six Months Ended June 27, 2020 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

- removed (2020-10-28):
[0000889331-20-000045:note_history:46]
|  |  | Three Months Ended June 29, 2019 |  |  |  |  |  |  |  | Six Months Ended June 29, 2019 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |
