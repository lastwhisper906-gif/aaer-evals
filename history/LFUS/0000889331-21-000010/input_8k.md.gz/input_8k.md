# LFUS 8-K — 0000889331-21-000006 filed 2021-02-03

## item codes, every 8-K on or before 2021-02-18

- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2021-02-18

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-21-000006:8k_2_02:1]
EX-99.1
2
q42020ex991.htm
EX-99.1

[0000889331-21-000006:8k_2_02:2]
Document

[0000889331-21-000006:8k_2_02:3]
Exhibit 99.1

[0000889331-21-000006:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-21-000006:8k_2_02:5]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS FOR 2020

[0000889331-21-000006:8k_2_02:6]
Company delivers solid performance amidst global pandemic

[0000889331-21-000006:8k_2_02:7]
CHICAGO, February 3, 2021 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the fourth quarter and full year ended December 26, 2020:

[0000889331-21-000006:8k_2_02:8]
Fourth Quarter 2020 Results

[0000889331-21-000006:8k_2_02:9]
•Net sales of $400.7 million were up 18% versus the prior year period, and up 16% organically, led by higher than expected demand across a number of automotive, electronics and industrial end markets

[0000889331-21-000006:8k_2_02:10]
•Segment performance versus the prior year period:

[0000889331-21-000006:8k_2_02:11]
◦Electronics sales grew 17% (up 16% organically)

[0000889331-21-000006:8k_2_02:12]
◦Automotive sales grew 22% (up 18% organically)

[0000889331-21-000006:8k_2_02:13]
◦Industrial sales grew 13% (up 5% organically)

[0000889331-21-000006:8k_2_02:14]
•GAAP diluted EPS was $2.39; adjusted diluted EPS was $2.23, which benefited from a lower effective tax rate versus the forecasted rate equating to approximately $0.14 in EPS

[0000889331-21-000006:8k_2_02:15]
•GAAP effective tax rate was 14.4% and the adjusted effective tax rate was 15.3%

[0000889331-21-000006:8k_2_02:16]
•On January 28, the company completed the acquisition of Hartland Controls, a manufacturer and leading supplier of electrical components used primarily in HVAC and other industrial applications, with annualized sales of approximately $70 million

[0000889331-21-000006:8k_2_02:17]
Full Year 2020 Results

[0000889331-21-000006:8k_2_02:18]
•Net sales of $1.45 billion were down 4% in total and organically versus the prior year

[0000889331-21-000006:8k_2_02:19]
•Segment performance versus the prior year:

[0000889331-21-000006:8k_2_02:20]
◦Electronics sales decreased 2% in total and organically

[0000889331-21-000006:8k_2_02:21]
◦Automotive sales decreased 8% (down 9% organically)

[0000889331-21-000006:8k_2_02:22]
◦Industrial sales decreased 2% (down 5% organically)

[0000889331-21-000006:8k_2_02:23]
•GAAP diluted EPS was $5.29; adjusted diluted EPS was $6.40

[0000889331-21-000006:8k_2_02:24]
•GAAP effective tax rate was 19.4% and the adjusted effective tax rate was 18.3%

[0000889331-21-000006:8k_2_02:25]
•Cash flow from operations was $258.0 million and free cash flow was $201.8 million, representing a 155% conversion from net income

[0000889331-21-000006:8k_2_02:26]
-more-

[0000889331-21-000006:8k_2_02:27]
“We finished the year with our fourth quarter well ahead of expectations, with double-digit sales growth across all of our segments,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “While 2020 was a challenging year, we continued to meet our customer commitments while advancing our strategic growth initiatives. Building on this momentum, we are seeing a strong start to 2021, which positions us for long-term growth and improved profitability.”

[0000889331-21-000006:8k_2_02:28]
First Quarter of 2021*

[0000889331-21-000006:8k_2_02:29]
For the first quarter, the company expects net sales in the range of $418 to $432 million, adjusted diluted EPS in the range of $1.76 to $1.92 and an adjusted effective tax rate of approximately 21%.

[0000889331-21-000006:8k_2_02:30]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-21-000006:8k_2_02:31]
Conference Call and Webcast Information

[0000889331-21-000006:8k_2_02:32]
Littelfuse will host a conference call today, Wednesday, February 3, 2021, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-21-000006:8k_2_02:33]
Virtual Investor and Analyst Event

[0000889331-21-000006:8k_2_02:34]
Littelfuse will host a virtual investor and analyst event on February 23, 2021, at 9:00 a.m. Central Time. Interested parties can register for the event here or via the registration link on the investor relations page of the company’s website, Littelfuse.com. Presentation materials will be posted, and archived webcast made available after the event.

[0000889331-21-000006:8k_2_02:35]
About Littelfuse

[0000889331-21-000006:8k_2_02:36]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics, and appliances. Our 11,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-21-000006:8k_2_02:37]
-more-

[0000889331-21-000006:8k_2_02:38]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. These statements may involve risks and uncertainties, including, but not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 28, 2019. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 28, 2019, under the caption "Risk Factors" in its Quarterly Report on Form 10-Q for the quarter ended September 26, 2020, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-21-000006:8k_2_02:39]
Non-GAAP Financial Measures

[0000889331-21-000006:8k_2_02:40]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth (decline), adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, consolidated total gross debt, consolidated EBITDA (as defined in the private placement senior notes), and ratio of consolidated total gross debt to consolidated EBITDA. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-21-000006:8k_2_02:41]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-21-000006:8k_2_02:42]
The company believes that organic net sales growth (decline), adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that consolidated total gross debt, consolidated EBITDA, and ratio of consolidated total gross debt to consolidated EBITDA are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-21-000006:8k_2_02:43]
CONTACT: Trisha Tuntland

[0000889331-21-000006:8k_2_02:44]
Head of Investor Relations

[0000889331-21-000006:8k_2_02:45]
(773) 628-2163

[0000889331-21-000006:8k_2_02:46]
###

[0000889331-21-000006:8k_2_02:47]
LFUS-F

[0000889331-21-000006:8k_2_02:48]
LITTELFUSE, INC.

[0000889331-21-000006:8k_2_02:49]
CONSOLIDATED BALANCE SHEETS

[0000889331-21-000006:8k_2_02:50]
| (in thousands) | December 26, 2020 |  | December 28, 2019 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 687,525 |  |  | $ | 531,139 |  |
| Short-term investments | 54 |  |  | 44 |  |
| Trade receivables, less allowances of $45,237 and $42,043, respectively | 232,760 |  |  | 202,309 |  |
| Inventories | 258,002 |  |  | 237,507 |  |
| Prepaid income taxes and income taxes receivable | 3,029 |  |  | 4,831 |  |
| Prepaid expenses and other current assets | 35,939 |  |  | 28,564 |  |
| Total current assets | 1,217,309 |  |  | 1,004,394 |  |
| Net property, plant, and equipment | 344,178 |  |  | 344,617 |  |
| Intangible assets, net of amortization | 291,887 |  |  | 321,247 |  |
| Goodwill | 816,812 |  |  | 820,589 |  |
| Investments | 30,547 |  |  | 24,099 |  |
| Deferred income taxes | 11,224 |  |  | 8,069 |  |
| Right of use assets, net | 17,615 |  |  | 21,918 |  |
| Other assets | 18,021 |  |  | 14,965 |  |
| Total assets | $ | 2,747,593 |  |  | $ | 2,559,898 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 145,984 |  |  | $ | 117,320 |  |
| Accrued liabilities | 110,478 |  |  | 84,120 |  |
| Accrued income taxes | 19,186 |  |  | 14,122 |  |
| Current portion of long-term debt | — |  |  | 10,000 |  |
| Total current liabilities | 275,648 |  |  | 225,562 |  |
| Long-term debt, less current portion | 687,034 |  |  | 669,158 |  |
| Deferred income taxes | 50,134 |  |  | 49,763 |  |
| Accrued post-retirement benefits | 45,802 |  |  | 38,198 |  |
| Non-current operating lease liabilities | 12,950 |  |  | 17,166 |  |
| Other long-term liabilities | 67,252 |  |  | 64,037 |  |
| Total equity | 1,608,773 |  |  | 1,496,014 |  |
| Total liabilities and equity | $ | 2,747,593 |  |  | $ | 2,559,898 |  |

[0000889331-21-000006:8k_2_02:51]
LITTELFUSE, INC.

[0000889331-21-000006:8k_2_02:52]
CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-21-000006:8k_2_02:53]
(Unaudited)

[0000889331-21-000006:8k_2_02:54]
|  |  | Three Months Ended |  | Fiscal Year Ended |
| (in thousands, except per share data) |  | December 26, 2020 |  | December 28, 2019 |  | December 26, 2020 |  | December 28, 2019 |
| Net sales |  | $ | 400,696 |  |  | $ | 338,523 |  |  | $ | 1,445,695 |  |  | $ | 1,503,873 |  |
| Cost of sales |  | 262,613 |  |  | 224,788 |  |  | 944,523 |  |  | 957,578 |  |
| Gross profit |  | 138,083 |  |  | 113,735 |  |  | 501,172 |  |  | 546,295 |  |
| Selling, general, and administrative expenses |  | 50,179 |  |  | 51,554 |  |  | 204,507 |  |  | 220,448 |  |
| Research and development expenses |  | 11,951 |  |  | 17,828 |  |  | 52,538 |  |  | 79,997 |  |
| Amortization of intangibles |  | 10,127 |  |  | 9,958 |  |  | 40,039 |  |  | 40,026 |  |
| Restructuring, impairment, and other charges |  | 812 |  |  | 2,078 |  |  | 41,716 |  |  | 13,033 |  |
| Total operating expenses |  | 73,069 |  |  | 81,418 |  |  | 338,800 |  |  | 353,504 |  |
| Operating income |  | 65,014 |  |  | 32,317 |  |  | 162,372 |  |  | 192,791 |  |
| Interest expense |  | 4,816 |  |  | 5,432 |  |  | 21,077 |  |  | 22,266 |  |
| Foreign exchange (gain) loss |  | (5,275) |  |  | (412) |  |  | (14,875) |  |  | 5,224 |  |
| Other (income) expense, net |  | (3,440) |  |  | 2,823 |  |  | (5,083) |  |  | (583) |  |
| Income before income taxes |  | 68,913 |  |  | 24,474 |  |  | 161,253 |  |  | 165,884 |  |
| Income taxes |  | 9,936 |  |  | 1,820 |  |  | 31,267 |  |  | 26,802 |  |
| Net income |  | $ | 58,977 |  |  | $ | 22,654 |  |  | $ | 129,986 |  |  | $ | 139,082 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.41 |  |  | $ | 0.93 |  |  | $ | 5.33 |  |  | $ | 5.66 |  |
| Diluted |  | $ | 2.39 |  |  | $ | 0.92 |  |  | $ | 5.29 |  |  | $ | 5.60 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,423 |  |  | 24,366 |  |  | 24,371 |  |  | 24,576 |  |
| Diluted |  | 24,726 |  |  | 24,598 |  |  | 24,592 |  |  | 24,818 |  |
| Comprehensive income |  | 75,058 |  |  | 28,439 |  |  | 145,652 |  |  | 130,183 |  |

[0000889331-21-000006:8k_2_02:55]
LITTELFUSE, INC.

[0000889331-21-000006:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-21-000006:8k_2_02:57]
|  | Year Ended |
| (in thousands) | December 26, 2020 |  | December 28, 2019 |
|  | (Unaudited) |  |  |
| OPERATING ACTIVITIES |  |  |  |
| Net income | $ | 129,986 |  |  | $ | 139,082 |  |
| Adjustments to reconcile net income to net cash provided by operating activities, net: | 123,685 |  |  | 121,898 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Trade receivables | (25,588) |  |  | 28,497 |  |
| Inventories | (12,425) |  |  | 22,094 |  |
| Accounts payable | 28,820 |  |  | (22,574) |  |
| Accrued liabilities | 6,765 |  |  | (54,242) |  |
| Prepaid expenses and other assets | 6,788 |  |  | 10,573 |  |
| Net cash provided by operating activities | 258,031 |  |  | 245,328 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisitions of businesses, net of cash acquired | — |  |  | (775) |  |
| Purchases of property, plant, and equipment | (56,191) |  |  | (61,895) |  |
| All other cash provided by investing activities | 4,758 |  |  | 6,213 |  |
| Net cash used in investing activities | (51,433) |  |  | (56,457) |  |
| FINANCING ACTIVITIES |  |  |  |
| Net payments of credit facility and senior notes | (15,000) |  |  | (10,000) |  |
| Cash dividends paid | (46,839) |  |  | (44,689) |  |
| Purchases of common stock | (22,927) |  |  | (99,387) |  |
| All other cash provided by financing activities | 16,958 |  |  | 7,800 |  |
| Net cash used in financing activities | (67,808) |  |  | (146,276) |  |
| Effect of exchange rate changes on cash and cash equivalents | 17,596 |  |  | (1,189) |  |
| Increase in cash and cash equivalents | 156,386 |  |  | 41,406 |  |
| Cash and cash equivalents at beginning of year | 531,139 |  |  | 489,733 |  |
| Cash and cash equivalents at end of year | $ | 687,525 |  |  | $ | 531,139 |  |

[0000889331-21-000006:8k_2_02:58]
LITTELFUSE, INC.

[0000889331-21-000006:8k_2_02:59]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-21-000006:8k_2_02:60]
(Unaudited)

[0000889331-21-000006:8k_2_02:61]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2020 |  | 2019 |  |  |  | %Growth /(Decline) |  | 2020 |  | 2019 |  |  |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 244,953 |  |  | $ | 208,881 |  |  |  |  | 17.3 | % |  | $ | 937,762 |  |  | $ | 961,080 |  |  |  |  | (2.4) | % |
| Automotive |  | 124,271 |  |  | 101,719 |  |  |  |  | 22.2 | % |  | 395,764 |  |  | 428,533 |  |  |  |  | (7.6) | % |
| Industrial |  | 31,472 |  |  | 27,923 |  |  |  |  | 12.7 | % |  | 112,169 |  |  | 114,260 |  |  |  |  | (1.8) | % |
| Total net sales |  | $ | 400,696 |  |  | $ | 338,523 |  |  |  |  | 18.4 | % |  | $ | 1,445,695 |  |  | $ | 1,503,873 |  |  |  |  | (3.9) | % |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 41,912 |  |  | $ | 18,361 |  |  |  |  | 128.3 | % |  | $ | 152,695 |  |  | $ | 145,594 |  |  |  |  | 4.9 | % |
| Automotive |  | 21,013 |  |  | 11,732 |  |  |  |  | 79.1 | % |  | 41,655 |  |  | 46,719 |  |  |  |  | (10.8) | % |
| Industrial |  | 3,587 |  |  | 6,249 |  |  |  |  | (42.6) | % |  | 11,996 |  |  | 22,407 |  |  |  |  | (46.5) | % |
| Other(a) |  | (1,498) |  |  | (4,025) |  |  |  |  | N.M. |  | (43,974) |  |  | (21,929) |  |  |  |  | N.M. |
| Total operating income |  | 65,014 |  |  | 32,317 |  |  |  |  | 101.2 | % |  | 162,372 |  |  | 192,791 |  |  |  |  | (15.8) | % |
| Operating Margin |  | 16.2 | % |  | 9.5 | % |  |  |  |  |  | 11.2 | % |  | 12.8 | % |  |  |  |  |
| Interest expense |  | 4,816 |  |  | 5,432 |  |  |  |  |  |  | 21,077 |  |  | 22,266 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (5,275) |  |  | (412) |  |  |  |  |  |  | (14,875) |  |  | 5,224 |  |  |  |  |  |
| Other (income) expense, net |  | (3,440) |  |  | 2,823 |  |  |  |  |  |  | (5,083) |  |  | (583) |  |  |  |  |  |
| Income before income taxes |  | $ | 68,913 |  |  | $ | 24,474 |  |  |  |  | 181.6 | % |  | $ | 161,253 |  |  | $ | 165,884 |  |  |  |  | (2.8) | % |

[0000889331-21-000006:8k_2_02:62]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs and restructuring, impairment and other charges. (See Supplemental Financial Information for details.)

[0000889331-21-000006:8k_2_02:63]
N.M. - Not meaningful

[0000889331-21-000006:8k_2_02:64]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2020 |  | 2019 |  |  |  | %Growth /(Decline) |  | 2020 |  | 2019 |  |  |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 17.1 | % |  | 8.8 | % |  |  |  | 8.3 | % |  | 16.3 | % |  | 15.1 | % |  |  |  | 1.2 | % |
| Automotive |  | 16.9 | % |  | 11.5 | % |  |  |  | 5.4 | % |  | 10.5 | % |  | 10.9 | % |  |  |  | (0.4) | % |
| Industrial |  | 11.4 | % |  | 22.4 | % |  |  |  | (11.0) | % |  | 10.7 | % |  | 19.6 | % |  |  |  | (8.9) | % |

[0000889331-21-000006:8k_2_02:65]
LITTELFUSE, INC.

[0000889331-21-000006:8k_2_02:66]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-21-000006:8k_2_02:67]
(In millions of USD except per share amounts unaudited)

[0000889331-21-000006:8k_2_02:68]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-20 |  | Q4-19 |  | YTD-20 |  | YTD-19 |
| GAAP diluted EPS |  | $ | 2.39 |  |  | $ | 0.92 |  |  | $ | 5.29 |  |  | $ | 5.60 |  |
| EPS impact of Non-GAAP adjustments (below) |  | (0.16) |  |  | 0.25 |  |  | 1.11 |  |  | 1.22 |  |
| Adjusted diluted EPS |  | $ | 2.23 |  |  | $ | 1.17 |  |  | $ | 6.40 |  |  | $ | 6.82 |  |

[0000889331-21-000006:8k_2_02:69]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q4-20 |  | Q4-19 |  | YTD-20 |  | YTD-19 |
| Acquisition-related and integration costs (a) |  | $ | 0.7 |  |  | $ | 2.0 |  |  | $ | 2.3 |  |  | $ | 8.9 |  |
| Restructuring, impairment and other charges (d) |  | 0.8 |  |  | 2.0 |  |  | 41.7 |  |  | 13.0 |  |
| Non-GAAP adjustments to operating income |  | 1.5 |  |  | 4.0 |  |  | 44.0 |  |  | 21.9 |  |
| Other expense, net (b) |  | — |  |  | 4.2 |  |  | 2.1 |  |  | 10.0 |  |
| Non-operating foreign exchange (gain) loss |  | (5.3) |  |  | (0.4) |  |  | (14.9) |  |  | 5.2 |  |
| Non-GAAP adjustments to income before income taxes |  | (3.8) |  |  | 7.8 |  |  | 31.2 |  |  | 37.1 |  |
| Income taxes (c) |  | — |  |  | 2.0 |  |  | 3.9 |  |  | 7.1 |  |
| Non-GAAP adjustments to net income |  | $ | (3.8) |  |  | $ | 5.8 |  |  | $ | 27.3 |  |  | $ | 30.0 |  |
| Total EPS impact |  | $ | (0.16) |  |  | $ | 0.25 |  |  | $ | 1.11 |  |  | $ | 1.22 |  |

[0000889331-21-000006:8k_2_02:70]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-20 |  | Q4-19 |  | YTD-20 |  | YTD-19 |
| Net sales |  | $ | 400.7 |  |  | $ | 338.5 |  |  | $ | 1,445.7 |  |  | $ | 1,503.9 |  |
| GAAP operating income |  | $ | 65.0 |  |  | $ | 32.3 |  |  | $ | 162.4 |  |  | $ | 192.8 |  |
| Add back non-GAAP adjustments |  | 1.5 |  |  | 4.0 |  |  | 44.0 |  |  | 21.9 |  |
| Adjusted operating income |  | $ | 66.5 |  |  | $ | 36.3 |  |  | $ | 206.4 |  |  | $ | 214.7 |  |
| Adjusted operating margin |  | 16.6 | % |  | 10.7 | % |  | 14.3 | % |  | 14.3 | % |
| Add back amortization |  | 10.1 |  |  | 9.9 |  |  | 40.0 |  |  | 40.0 |  |
| Add back depreciation |  | 14.2 |  |  | 13.5 |  |  | 56.1 |  |  | 52.5 |  |
| Adjusted EBITDA |  | $ | 90.8 |  |  | $ | 59.7 |  |  | $ | 302.5 |  |  | $ | 307.2 |  |
| Adjusted EBITDA margin |  | 22.7 | % |  | 17.6 | % |  | 20.9 | % |  | 20.4 | % |

[0000889331-21-000006:8k_2_02:71]
| Net sales reconciliation |  | Q4-20 vs. Q4-19 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | 17 | % |  | 22 | % |  | 13 | % |  | 18 | % |
| Less: |  |  |  |  |  |  |  |  |
| Transfer a product line between segments |  | (1) | % |  | — | % |  | 7 | % |  | — | % |
| FX impact |  | 2 | % |  | 4 | % |  | 1 | % |  | 2 | % |
| Organic net sales growth |  | 16 | % |  | 18 | % |  | 5 | % |  | 16 | % |

[0000889331-21-000006:8k_2_02:72]
| Net sales reconciliation |  | YTD-20 vs. YTD-19 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales decline |  | (2) | % |  | (8) | % |  | (2) | % |  | (4) | % |
| Less: |  |  |  |  |  |  |  |  |
| Transfer a product line between segments |  | — | % |  | — |  |  | 3 | % |  | — | % |
| FX impact |  | — | % |  | 1 | % |  | — | % |  | — | % |
| Organic net sales decline |  | (2) | % |  | (9) | % |  | (5) | % |  | (4) | % |

[0000889331-21-000006:8k_2_02:73]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-20 |  | Q4-19 |  | YTD-20 |  | YTD-19 |
| Income taxes |  | $ | 9.9 |  |  | $ | 1.8 |  |  | $ | 31.3 |  |  | $ | 26.8 |  |
| Effective rate |  | 14.4 | % |  | 7.4 | % |  | 19.4 | % |  | 16.2 | % |
| Non-GAAP adjustments - income taxes |  | — |  |  | 2.0 |  |  | 3.9 |  |  | 7.1 |  |
| Adjusted income taxes |  | $ | 9.9 |  |  | $ | 3.8 |  |  | $ | 35.2 |  |  | $ | 33.9 |  |
| Adjusted effective rate |  | 15.3 | % |  | 11.9 | % |  | 18.3 | % |  | 16.7 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-20 |  | Q4-19 |  | YTD-20 |  | YTD-19 |
| Net cash provided by operating activities |  | $ | 93.7 |  |  | $ | 84.4 |  |  | $ | 258.0 |  |  | $ | 245.3 |  |
| Less: Purchases of property, plant and equipment |  | (14.6) |  |  | (23.5) |  |  | (56.2) |  |  | (61.9) |  |
| Free cash flow |  | $ | 79.1 |  |  | $ | 60.9 |  |  | $ | 201.8 |  |  | $ | 183.4 |  |

[0000889331-21-000006:8k_2_02:74]
| Consolidated Total Debt |  | As of December 26, 2020 |
| Consolidated total gross debt |  | $ | 691.1 |  |
| Unamortized debt issuance costs |  | (4.1) |  |
| Consolidated Total Debt |  | $ | 687.0 |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | Twelve Months EndedDecember 26, 2020 |
| Net Income |  | $ | 130.0 |  |
| Interest expense |  | 21.1 |  |
| Income taxes |  | 31.3 |  |
| Depreciation |  | 56.1 |  |
| Amortization |  | 40.0 |  |
| Non-cash reductions: |  |  |
| Stock-based compensation expense |  | 18.1 |  |
| Unrealized gain on investments |  | (4.7) |  |
| Impairment charges |  | 36.1 |  |
| Other |  | (21.0) |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | $ | 307.0 |  |
| Ratio of Consolidated total gross debt to Consolidated EBITDA (as defined in Private Placement Senior Notes)* |  | 2.3x |

[0000889331-21-000006:8k_2_02:75]
* Our Private Placement Senior Notes, with maturities ranging from 2022 to 2030, contain a financial ratio covenant providing that if, as of the last day of each fiscal quarter, the ratio of Consolidated total gross debt at such time to Consolidated EBITDA for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Private Placement Senior Notes) is triggered

[0000889331-21-000006:8k_2_02:76]
Note: Totals will not always foot due to rounding.

[0000889331-21-000006:8k_2_02:77]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-21-000006:8k_2_02:78]
(b) 2020 year-to-date amount included a $1.8 million increase in coal mining reserves, a $0.2 million charge for an asset retirement obligation related to the disposal of a business in 2019, and  $0.1 million of impairment charges on certain other investments. 2019 quarter-to-date amount included $4.2 million of impairment charges related to certain other investments. 2019 year-to-date primarily consisted of $7.3 million of impairment charges related to certain other investments and a $2.6 million loss on the disposal of a business.

[0000889331-21-000006:8k_2_02:79]
(c) reflected the tax impact associated with the non-GAAP adjustments. The three and twelve months ended December 28, 2019 reflected a $3.3 million reversal for previously unrecognized tax benefits as the statute of limitations expired.

[0000889331-21-000006:8k_2_02:80]
(d) for fiscal year ended December 26, 2020, the Company began presenting restructuring, impairment and other charges as a separate caption in the Consolidated Statements of Net Income. Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements.
