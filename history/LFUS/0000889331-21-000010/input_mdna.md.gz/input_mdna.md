# LFUS MD&A — 0000889331-21-000010


## mdna

[0000889331-21-000010:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0000889331-21-000010:mdna:2]
The following discussion of the Company's financial condition and results of operations should be read together with the Consolidated Financial Statements and notes to those statements included in Item 8 of Part II of this Annual Report on Form 10-K.

[0000889331-21-000010:mdna:3]
BUSINESS

[0000889331-21-000010:mdna:4]
For a description of the Company’s business, segments and product offerings, see Item 1, Business.

[0000889331-21-000010:mdna:5]
2020 EXECUTIVE OVERVIEW

[0000889331-21-000010:mdna:6]
Net sales decreased by $58.2 million, or 3.9%, in 2020 compared to 2019. The decrease was primarily driven by production disruptions during the first half of 2020 due to temporary closures of several of the company’s manufacturing facilities and reduced demand due to customer shutdowns, resulting from government directives due to the impact of COVID-19. This was partially offset by volume increases across all of the company’s businesses in the second half of 2020, led by higher production levels, increased demand from work-from-home and stay-at-home trends, and higher demand in a number of other end markets that the Company sells into, such as passenger vehicles, and $7.7 million or 0.5% of favorable changes in foreign exchange rates. The Company recognized net income of $130.0 million, or $5.29 per diluted share, in 2020 compared to net income of $139.1 million, or $5.60 per diluted share in 2019. The decrease in net income is primarily due to the second quarter goodwill impairment charge of $33.8 million, lower sales in the first half of 2020 driven by COVID-19 production disruptions partially offset by a net increase in foreign exchange gains of $20.1 million and operating expense cost reductions.

[0000889331-21-000010:mdna:7]
The Company continues to take actions to improve its cost structure. The Company expects to realize cost savings from the restructuring activities taken during 2019 and 2020, including the reorganization of certain research and development, selling and administrative functions across all segments. The Company is also in process of several restructuring activities across its manufacturing and supply chain footprint, including the consolidation of a manufacturing facility within the Industrial Segment, which is expected to be completed in the first half of 2021.

[0000889331-21-000010:mdna:8]
Net cash provided by operating activities was $258.0 million for the year ended December 26, 2020 as compared to $245.3 million for the year ended December 28, 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and reductions in net working capital partially offset by lower earnings largely due to the impact of COVID-19.

[0000889331-21-000010:mdna:9]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $110.0 million on the amended revolving credit facility during the fiscal year ended December 26, 2020. The balance under the facility was $130.0 million as of December 26, 2020.

[0000889331-21-000010:mdna:10]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to directly pay and administer pension payments to certain of the Company’s UK pension plan participants, or their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $55 million, representing approximately 37% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge in the second half of 2021 currently estimated between $18 million and $22 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-21-000010:mdna:11]
On January 28, 2021, the Company acquired Hartland Controls, a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The cash purchase price for Hartland Controls was approximately $113 million and the operations of Hartland Controls will be included in the Industrial segment.

[0000889331-21-000010:mdna:12]
Impact of COVID-19 on Business

[0000889331-21-000010:mdna:13]
The Company continued to manage through the COVID-19 impacts throughout the year, with significant improvement to its financial results in the second half of 2020 compared to the first half of 2020. Our manufacturing facilities generally operated at normal capacity levels during the second half of the year as production disruptions were minimal. The effects from COVID-19 are continuing to drive increased costs, from spending on personal protective equipment ("PPE"), additional personnel and employee transportation costs, and manufacturing inefficiencies, as well as an increase in freight costs for our products due to the transportation capacity constraints across the world. This was partially offset during 2020 by the receipt of cash subsidies from international  government COVID-19 relief programs.

[0000889331-21-000010:mdna:14]
The Company’s priorities continue to be first, on our associates, their families and the communities in which we operate; second, our customers; and third, long-term financial health of the company. In an effort to protect the health and safety of our employees, the Company enacted numerous proactive, aggressive actions at its facilities globally in the first quarter of 2020, and implemented a number of safety procedures including hygiene and disinfection protocols, social distancing and wearing PPE. The Company expects these actions will continue for the foreseeable future.

[0000889331-21-000010:mdna:15]
During 2020, governments around the world enacted various measures in an effort to contain COVID-19 and slow its spread. These measures included orders to close all businesses not deemed “essential”, isolate residents to their homes or places of residence, and practice social distancing when engaging in essential activities, which disrupted certain of our operating locations in around the world in the first half of 2020. During the second half of 2020, all of our manufacturing facilities were operational and were generally running at normal capacity levels.

[0000889331-21-000010:mdna:16]
The Company continues to work with customers to meet production requirements for their products, many of which are considered essential, including healthcare and medical devices, transportation, communication and energy infrastructure.

[0000889331-21-000010:mdna:17]
The Company anticipates that the global health crisis caused by COVID-19 may continue to negatively impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a resurgence in COVID-19 cases and its impact on our employees, customers, suppliers and

[0000889331-21-000010:mdna:18]
vendors. The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business and operations, including the effects on our customers, employees, and prospects, or on our financial results for the fiscal year 2021.

[0000889331-21-000010:mdna:19]
OUTLOOK

[0000889331-21-000010:mdna:20]
Vision and Strategy

[0000889331-21-000010:mdna:21]
The Company closely collaborates with its customers to design and manufacture innovative and reliable solutions for a safer, connected, and more sustainable world in virtually every market that uses electrical energy; for example, transportation applications like passenger and commercial vehicles, including eMobility, industrial applications like renewables and energy storage, HVAC and industrial automation and safety, motor drives and power conversion, and electronics applications like data centers and telecommunications, medical devices, home and building automation, appliances, and mobile and consumer electronics. Built upon that framework, the secular growth themes of a safer, connected, and more sustainable world, drive increased product content opportunities.

[0000889331-21-000010:mdna:22]
The Company’s strategic plan is focused on increasing shareholder value by driving profitable sales growth, earnings per share growth, strong cash flow generation, and deploying capital to drive value creation. The Company pursues the following major strategic initiatives, which are summarized below, along with more specific areas of focus.

[0000889331-21-000010:mdna:23]
| Strategic Objectives |  | Priorities |
| Double digit sales growth |  | ● | Grow through increased product content with existing customers and increased market share |
|  |  | ● | Expand portfolio into new and underpenetrated geographies and end markets |
|  |  | ● | Increase innovation capabilities and investments |
|  |  | ● | Expand presence in products and applications that are converging across business segments |
|  |  | ● | Targeted mergers and acquisitions |
| EPS growth |  | ● | Focus on higher profitability growth opportunities |
|  |  | ● | Improve operating margins through operational excellence |
|  |  | ● | Disciplined approach to balancing costs with long-term strategic investments |
| Cash flow and liquidity |  | ● | Disciplined management of working capital |
|  |  | ● | Deployment of capital consistent with capital allocation priorities |
|  |  | ● | Mergers and acquisitions that align with strategy and financial metrics |
|  |  | ● | Grow dividend in line with earnings |
|  |  | ● | Opportunistic share repurchases |

[0000889331-21-000010:mdna:24]
The Company’s strategy is to generate profitable sales growth. In order to accomplish this, the Company is focusing on accelerating organic growth by increasing its content and share gains, enhancing technology efforts to drive innovation, capitalizing on cross segment opportunities, and gaining traction in underpenetrated geographies and markets. The Company will continue to make targeted strategic acquisitions that align to its strategy and financial metrics to support new business, products, markets, and technologies while leveraging existing customers and targeting new customers.

[0000889331-21-000010:mdna:25]
Management believes that profitable growth through a combination of organic growth and strategic acquisitions is critical to the Company’s competitiveness, while enhancing value the Company delivers to all of its stakeholders. In addition, the Company continues to implement initiatives across all platforms to enhance productivity while managing its cost structure to align with business conditions, including integration of operations and streamlining administrative and support activities to drive improved operating margins.

[0000889331-21-000010:mdna:26]
The Company seeks to deploy its capital consistent with capital allocation priorities. Priorities for capital deployment, over time, include investments to drive increased organic growth, targeted acquisitions that align to the Company’s strategic and financial metrics and returning capital to shareholders through dividends and opportunistic share repurchases.

[0000889331-21-000010:mdna:27]
The Company has entered the last year of its current five-year growth strategy which is defined below. As such, the Company will host a virtual investor and analyst event on February 23, 2021 to share the specific details of its new five-year strategic plan, which reinforces the Company’s continued commitment to profitable growth building on its achievements from its previous five-year plans.

[0000889331-21-000010:mdna:28]
The Company uses several key indicators to gauge progress toward achieving these objectives. These indicators include organic sales growth, operating margins, cash flow from operations and capital expenditures. Through cycles, the Company targets double-digit long-term sales growth, split between 5-7% average annual accelerated organic sales growth and 5-7% average annual accelerated growth from strategic acquisitions, while targeting operating margins between 17% and 19% and double-digit earnings per share growth. Cash flow from operations less capital expenditures is targeted to approximate or exceed net income but in any given year can be significantly impacted by the timing of non-recurring or infrequent expenditures.

[0000889331-21-000010:mdna:29]
Significant Accounting Policies and Critical Estimates

[0000889331-21-000010:mdna:30]
Critical Accounting Policies and Estimates

[0000889331-21-000010:mdna:31]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The Company’s most critical accounting policies are those that are most important to the portrayal of its financial condition and results of operations, and which require the Company to make its most difficult and subjective judgments, often as a result of the need to make estimates of matters that are inherently uncertain. The Company has identified the following as its most critical accounting policies and judgments. Although management believes that its estimates and assumptions are reasonable, they are based upon information available when they are made, and therefore, actual results may differ from these estimates under different assumptions or conditions. The Company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0000889331-21-000010:mdna:32]
Revenue Recognition

[0000889331-21-000010:mdna:33]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.

[0000889331-21-000010:mdna:34]
Revenue Disaggregation

[0000889331-21-000010:mdna:35]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 26, 2020 and December 28, 2019:

[0000889331-21-000010:mdna:36]
|  |  | Fiscal Year Ended December 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 522,352 |  |  | $ | — |  |  | $ | — |  |  | $ | 522,352 |  |
| Electronics – Passive Products and Sensors |  | 415,410 |  |  | — |  |  | — |  |  | 415,410 |  |
| Passenger Car Products |  | — |  |  | 200,455 |  |  | — |  |  | 200,455 |  |
| Commercial Vehicle Products |  | — |  |  | 101,324 |  |  | — |  |  | 101,324 |  |
| Automotive Sensors |  | — |  |  | 93,985 |  |  | — |  |  | 93,985 |  |
| Industrial Products |  | — |  |  | — |  |  | 112,169 |  |  | 112,169 |  |
| Total |  | $ | 937,762 |  |  | $ | 395,764 |  |  | $ | 112,169 |  |  | $ | 1,445,695 |  |

[0000889331-21-000010:mdna:37]
|  |  | Fiscal Year Ended December 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 539,820 |  |  | $ | — |  |  | $ | — |  |  | $ | 539,820 |  |
| Electronics – Passive Products and Sensors |  | 421,260 |  |  | — |  |  | — |  |  | 421,260 |  |
| Passenger Car Products |  | — |  |  | 218,560 |  |  | — |  |  | 218,560 |  |
| Commercial Vehicle Products |  | — |  |  | 111,972 |  |  | — |  |  | 111,972 |  |
| Automotive Sensors |  | — |  |  | 98,001 |  |  | — |  |  | 98,001 |  |
| Industrial Products |  | — |  |  | — |  |  | 114,260 |  |  | 114,260 |  |
| Total |  | $ | 961,080 |  |  | $ | 428,533 |  |  | $ | 114,260 |  |  | $ | 1,503,873 |  |

[0000889331-21-000010:mdna:38]
During the fourth quarter of 2020, the Company transferred a business previously reported within the Electronics-Semiconductor reporting unit to the Electronics-Passive Products and Sensors reporting units. This transfer aligns with how this business will be managed and is complimentary with existing electronics passive products and sensors and markets into which they sell. The 2019 disaggregated revenue table has been reclassified to reflect this change. This transfer had no impact to the Electronics segment results.

[0000889331-21-000010:mdna:39]
See Note 16, Segment Information, for net sales by segment and countries.

[0000889331-21-000010:mdna:40]
Revenue Recognition

[0000889331-21-000010:mdna:41]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s sales channels are primarily through direct sales and independent third-party distributors.

[0000889331-21-000010:mdna:42]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-21-000010:mdna:43]
Revenue and Billing

[0000889331-21-000010:mdna:44]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0000889331-21-000010:mdna:45]
Ship and Debit Program

[0000889331-21-000010:mdna:46]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on

[0000889331-21-000010:mdna:47]
historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-21-000010:mdna:48]
Return to Stock

[0000889331-21-000010:mdna:49]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-21-000010:mdna:50]
Volume Rebates

[0000889331-21-000010:mdna:51]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-21-000010:mdna:52]
Allowance for Doubtful Accounts:

[0000889331-21-000010:mdna:53]
The Company currently measures the expected credit losses based on our historical credit loss experience. The Company has not experienced significant recent or historical credit losses and is not forecasting any significant credit losses which would require adjustments to our methodology. If current conditions and supportable forecasts indicate that our historical loss experience is not reasonable and no longer supportable, the Company may adjust its historical credit loss experience and to reflect these conditions and forecasts. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also analyzes all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and historical collection and loss experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-21-000010:mdna:54]
Inventory

[0000889331-21-000010:mdna:55]
The Company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life, and quality issues. Based on the analysis, the Company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable value.

[0000889331-21-000010:mdna:56]
Goodwill

[0000889331-21-000010:mdna:57]
The Company’s methodology for allocating the purchase price of acquisitions is based on established valuation techniques that reflect the consideration of a number of factors, including valuations performed by third-party appraisers when appropriate. Goodwill is measured as the excess of the cost of an acquired entity over the fair value assigned to identifiable assets acquired and liabilities assumed. Based on its current organization structure, the Company has seven reporting units for which cash flows are determinable and to which goodwill has been allocated.

[0000889331-21-000010:mdna:58]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events.

[0000889331-21-000010:mdna:59]
During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition,

[0000889331-21-000010:mdna:60]
during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling an existing program. As of December 26, 2020, the automotive sensors reporting unit had $9.8 million of remaining goodwill.

[0000889331-21-000010:mdna:61]
Quantitative Assessment for Impairment

[0000889331-21-000010:mdna:62]
For the seven reporting units with goodwill, the Company compares the estimated fair value of each reporting unit to its carrying value. If the carrying value of a reporting unit exceeds the estimated fair value, the difference between the estimated fair value and carrying value is recorded as the amount of the goodwill impairment charge. The results of the goodwill impairment test as of September 27, 2020 indicated that the estimated fair values for each of the seven reporting units exceeded their respective carrying values. Accordingly, there were no goodwill impairment charges recorded as part of the Company’s 2020 annual goodwill impairment test.

[0000889331-21-000010:mdna:63]
As part of its impairment test for these reporting units, the Company engaged a third-party appraisal firm to assist in the Company’s determination of the estimated fair values. This determination included estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping. The Company weighted both the income and market approach equally to estimate the concluded fair value of each reporting unit. The determination of fair value requires the Company to make significant estimates and assumptions, which primarily include, but are not limited to: the selection of appropriate peer group companies; control premiums appropriate for acquisitions in which the Company competes; the discount rate; terminal growth rates; and forecasts of revenue, operating income, depreciation and amortization and capital expenditures.

[0000889331-21-000010:mdna:64]
Goodwill Impairment Assumptions

[0000889331-21-000010:mdna:65]
Although the Company believes its estimates of fair value are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results or other underlying assumptions could have a significant impact on the fair value of the reporting units. Future declines in the overall market value of the Company’s equity may also result in a conclusion that the fair value of one or more reporting units has declined below its carrying value.

[0000889331-21-000010:mdna:66]
One measure of the sensitivity of the amount of goodwill impairment charges to key assumptions is the amount by which each reporting unit “passed” (fair value exceeds the carrying value) the goodwill impairment test. All seven of the reporting units passed the goodwill impairment test, with fair values that exceeded the carrying values between 44% and 218% of their respective estimated fair values. As of the most recent annual test conducted on September 27, 2020, the Company noted that the excess of fair value over the carrying value was 218%, 44%, 160%, 137%, 59%, 139%, and 210% for its reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, Automotive Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test.

[0000889331-21-000010:mdna:67]
Generally, changes in estimates of expected future cash flows would have a similar effect on the estimated fair value of the reporting unit. That is, a 1.0% decrease in estimated annual future cash flows would decrease the estimated fair value of the reporting unit by approximately 1.0%. The estimated long-term net sales growth rate can have a significant impact on the estimated future cash flows, and therefore, the fair value of each reporting unit. A 1.0% decrease in the long-term net sales growth rate would have resulted in no reporting units failing the goodwill impairment test. Of the other key assumptions that impact the estimated fair values, most reporting units have the greatest sensitivity to changes in the estimated discount rate. The estimated discount rate was 10.2% for the Electronics-Passive Products and Sensor and the Electronics-Semiconductor reporting units, 9.2% for the Passenger Car Products and Commercial Vehicle Products reporting units, 11.2% for the Automotive Sensors reporting unit, 12.2% for the Relays reporting unit and 11.2% for the Power Fuse reporting unit. A 1.0% increase in the estimated discount rates would have resulted in no reporting units failing the annual goodwill impairment test. The Company believes that its estimates of future cash flows and discount rates are reasonable, but future changes in the underlying assumptions could differ due to the inherent uncertainty in making such estimates. Additionally, price deterioration or lower volume could have a significant impact on the fair values of the reporting units.

[0000889331-21-000010:mdna:68]
Long-Lived Assets

[0000889331-21-000010:mdna:69]
The Company evaluates the recoverability of other long-lived assets, including property, plant and equipment and certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset

[0000889331-21-000010:mdna:70]
group may not be recoverable. Factors which could trigger an impairment review include significant underperformance relative to historical or projected operating results, significant changes in the manner of use of the assets or the strategy for the overall business, a significant decrease in the market value of the assets or significant negative industry or economic trends. When the Company determines that the carrying value of long-lived assets may not be recoverable based upon the existence of one or more of the indicators, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition. If the carrying value of an asset exceeds its estimated future undiscounted cash flows, an impairment loss is recorded for the excess of the asset’s carrying value over its fair value. During the first quarter of 2020, the Company recognized a $2.2 million impairment charge related to the land and building associated with the Company’s announced consolidation of a manufacturing facility within the Industrial segment. For the year-ended December 28, 2019, the Company recognized non-cash impairment charges of $0.3 million for certain machinery and equipment related to the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment.

[0000889331-21-000010:mdna:71]
Environmental Liabilities

[0000889331-21-000010:mdna:72]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The Company evaluates its reserve for coal mine remediation annually utilizing a third-party expert.

[0000889331-21-000010:mdna:73]
Pension and Supplemental Executive Retirement Plan

[0000889331-21-000010:mdna:74]
The Company records annual income and expense amounts relating to its pension and postretirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors. The Company maintains several pension plans in international locations. The expected returns on plan assets and discount rates are determined based on each plan’s investment approach, local interest rates and plan participant profiles. The weighted-average discount rates for the Company’s defined benefit plans primarily in Europe and the Asia-Pacific regions at December 26, 2020 and December 28, 2019 were 1.2% and 2.3%, respectively.

[0000889331-21-000010:mdna:75]
A 50 basis point change in the discount rates at December 26, 2020 would have the following effect on the projected benefit obligation:

[0000889331-21-000010:mdna:76]
| (in millions) | 0.5%Increase |  | 0.5%Decrease |
| Projected benefit obligation | $ | (11.3) |  |  | $ | 12.4 |  |

[0000889331-21-000010:mdna:77]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to directly pay and administer pension payments to certain of the Company’s UK pension plan participants, or their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $55 million, representing approximately 37% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge in the second half of 2021 currently estimated between $18 million and $22 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-21-000010:mdna:78]
Equity-based Compensation

[0000889331-21-000010:mdna:79]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based

[0000889331-21-000010:mdna:80]
on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments for the foreseeable future. The fair value of restricted share units is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-21-000010:mdna:81]
Total equity-based compensation expense for all equity compensation plans was $19.1 million, $19.9 million, and $28.2 million in 2020, 2019, and 2018, respectively. Further information regarding this expense is provided in Note 12, Stock-Based Compensation, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-21-000010:mdna:82]
Income Taxes

[0000889331-21-000010:mdna:83]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-21-000010:mdna:84]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-21-000010:mdna:85]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-21-000010:mdna:86]
On December 22, 2017, the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduced the U.S. corporate federal income tax rate from 35% to 21%, added base broadening provisions which limit deductions and address excessive international tax planning, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enabled repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax.

[0000889331-21-000010:mdna:87]
In the fourth quarter of 2018, within the measurement period outlined in SEC Staff Accounting Bulletin (“SAB”) No. 118, the Company finalized its estimates of the impact of the Tax Act and recorded a charge of $3.2 million, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. In addition, the Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation. This was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities.

[0000889331-21-000010:mdna:88]
One of the base broadening provisions of the Tax Act is the global intangible low-taxed income provisions ("GILTI"). In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 26, 2020, December 28, 2019, and December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-21-000010:mdna:89]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-21-000010:mdna:90]
Off-Balance Sheet Arrangements

[0000889331-21-000010:mdna:91]
The Company does not have off-balance sheet arrangements as defined under SEC rules. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-21-000010:mdna:92]
In the financial review that follows, the Company discusses its consolidated results of operations, financial position, cash flows and certain other information. This discussion should be read in conjunction with the Company’s Consolidated Financial Statements and related notes.

[0000889331-21-000010:mdna:93]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 26, 2020 AS COMPARED TO THE YEAR ENDED DECEMBER 28, 2019

[0000889331-21-000010:mdna:94]
The fiscal year 2020 included approximately $44.0 million of non-segment charges, of which $2.3 million of charges are acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $41.7 million of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, employee termination costs of $5.5 million, $2.2 million of impairment charges recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment and other restructuring charges of $0.2 million. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-21-000010:mdna:95]
The fiscal year 2019 included approximately $21.9 million of non-segment charges, of which $8.9 million of charges are acquisition-related and integration charges primarily related to the IXYS acquisition and other contemplated acquisitions, and $13.0 million of restructuring charges primarily related to employee termination costs.

[0000889331-21-000010:mdna:96]
Fiscal year 2020 also included approximately $14.9 million in foreign currency exchange gains primarily attributable to changes in the value of the Euro, Philippine peso, and Chinese renminbi against the U.S. dollar, while fiscal year 2019 included approximately $5.2 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Chinese renminbi, and Japanese yen against the U.S. dollar

[0000889331-21-000010:mdna:97]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2020 |  | 2019 |  | Change |  | % Change |
| Net sales | $ | 1,445,695 |  |  | $ | 1,503,873 |  |  | $ | (58,178) |  |  | (3.9) | % |
| Cost of sales | 944,523 |  |  | 957,578 |  |  | (13,055) |  |  | (1.4) | % |
| Gross profit | 501,172 |  |  | 546,295 |  |  | (45,123) |  |  | (8.3) | % |
| Operating expenses | 338,800 |  |  | 353,504 |  |  | (14,704) |  |  | (4.2) | % |
| Operating income | 162,372 |  |  | 192,791 |  |  | (30,419) |  |  | (15.8) | % |
| Other income, net | (5,083) |  |  | (583) |  |  | (4,500) |  |  | 771.9 | % |
| Income before income taxes | 161,253 |  |  | 165,884 |  |  | (4,631) |  |  | (2.8) | % |
| Income taxes | 31,267 |  |  | 26,802 |  |  | 4,465 |  |  | 16.7 | % |
| Net income | 129,986 |  |  | 139,082 |  |  | (9,096) |  |  | (6.5) | % |

[0000889331-21-000010:mdna:98]
Net Sales

[0000889331-21-000010:mdna:99]
Net sales of $1,445.7 million decreased $58.2 million, or 3.9%, for 2020 compared to the prior year primarily due to lower volume in the Automotive and Electronics segments which had net sales decreases of $32.7 million and $23.4 million, respectively, partially offset by $7.7 million or 0.5% of favorable changes in foreign exchange rates. These decreases were primarily driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 and a decline in global auto production driven by the temporary closures of customer manufacturing facilities during the first half of 2020. These sales declines were partially offset by increases in customer demand for consumer devices for work from home needs and strength in various end market demand across all businesses in the second half of the year. All businesses within the Automotive segment experienced lower sales in 2020 due to the production disruptions in the first half of 2020 mentioned above, which was partially offset in the second half of the year, driven by stronger end market demand.

[0000889331-21-000010:mdna:100]
Cost of Sales

[0000889331-21-000010:mdna:101]
Cost of sales was $944.5 million, or 65.3% of net sales, in 2020, compared to $957.6 million, or 63.7% of net sales, in 2019. The decrease in cost of sales was primarily due to lower volume in the Electronics and Automotive segments driven by the factors discussed above. As a percent of net sales, cost of sales increased 1.6% driven by higher freight costs of $5.6 million, additional costs associated with government-directed plant shutdowns and supply chain constraints, supplies and other costs  due to the impact of COVID-19, and unfavorable product mix.

[0000889331-21-000010:mdna:102]
Gross Profit

[0000889331-21-000010:mdna:103]
Gross profit was $501.2 million, or 34.7% of net sales, in 2020, compared to $546.3 million, or 36.3% of net sales, in 2019. The decrease of $45.1 million in gross profit reflected lower volume across all segments driven by the disruption across all segments due to temporary closures of manufacturing facilities in the first half of the year resulting from government directives due to the impact of COVID-19. The decrease in gross margin of 1.6% was primarily from the lower volume mentioned previously, unfavorable price and product mix primarily in the Industrial segment. Additionally, higher freight cost of $5.6 million, costs associated with government-directed plant shutdowns and supply chain constraints, supplies and other costs due to the impact of COVID-19 negatively impacted gross margins.

[0000889331-21-000010:mdna:104]
Operating Expenses

[0000889331-21-000010:mdna:105]
Total operating expenses were $338.8 million, or 23.4% of net sales, for 2020 compared to $353.5 million, or 23.5% of net sales, for 2019. The decrease in operating expenses of $14.7 million is primarily due to lower research and development expenses of $27.5 million, or 1.7% of net sales, a reduction in discretionary expenses including travel and marketing expenses and a $6.6 million reduction in acquisition-related and integration charges, partially offset by the second quarter goodwill impairment charge of $33.8 million, or 2.3% of net sales, in the automotive sensors reporting unit within the Automotive segment and impairment charges of $2.2 million related to the Company’s first quarter announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-21-000010:mdna:106]
Operating Income

[0000889331-21-000010:mdna:107]
Operating income for 2020 was $162.4 million, a decrease of $30.4 million or 15.8% compared to $192.8 million for 2019. The decrease in operating income is primarily due to lower gross margin across all segments and the $33.8 million goodwill impairment charge noted above partially offset by a reduction in operating expenses described above. Operating margins decreased from 12.8% in 2019 to 11.2% in 2020 primarily driven by the factors mentioned above. The second quarter goodwill impairment charge of $33.8 million negatively impacted the 2020 operating margin by 2.3% which was partially offset by the lower operating expenses and cost reductions noted above.

[0000889331-21-000010:mdna:108]
Income Before Income Taxes

[0000889331-21-000010:mdna:109]
Income before income taxes for 2020 was $161.3 million, or 11.2% of net sales compared to $165.9 million, or 11.0% of net sales, for 2019. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes benefited from foreign exchange gains of $14.9 million during the fiscal year ended December 26, 2020 compared to foreign exchange losses of $5.2 million during the fiscal year ended December 28, 2019. Additionally, the increase in other income of $4.5 million was primarily due to the 2019 fiscal year impairment charges of $7.3 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment and $1.7 million increase in unrealized investment gains associated with our equity investments, partially offset by lower interest income of $2.0 million and a $1.2 million increase in coal mining reserves in 2020 versus 2019.

[0000889331-21-000010:mdna:110]
Income Taxes

[0000889331-21-000010:mdna:111]
Income tax expense for 2020 was $31.3 million, or an effective tax rate of 19.4% compared to income tax expense of $26.8 million, or an effective tax rate of 16.2% for 2019. The Company’s tax rates are lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by the impact of taxes on unremitted earnings, the GILTI tax provisions, and non-U.S. losses and expenses with no tax benefit. Changes in the amount of these items from year to year impact the effective tax rates. In addition, the 2020 income tax expense included the impact of  the goodwill impairment charge of $33.8 million that was recorded in the second quarter of 2020, the substantial majority of which related to non-U.S. entities and did not result in a tax benefit, and the 2019 income tax expense included a benefit of $3.3 million from the recognition of previously unrecognized tax benefits (and the reversal of the related accrued interest) due to a lapse in the statute of limitations. The impact of the items discussed above resulted in an increase in the effective tax rate in 2020, as compared to the effective tax rate in 2019. Further information regarding these items is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-21-000010:mdna:112]
Segment Information

[0000889331-21-000010:mdna:113]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-21-000010:mdna:114]
The following table is a summary of the Company’s net sales by segment:

[0000889331-21-000010:mdna:115]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | % Change |
| Electronics | $ | 937.7 |  |  | $ | 961.1 |  |  | $ | (23.4) |  |  | (2.4) | % |
| Automotive | 395.8 |  |  | 428.5 |  |  | (32.7) |  |  | (7.6) | % |
| Industrial | 112.2 |  |  | 114.3 |  |  | (2.1) |  |  | (1.9) | % |
| Total | $ | 1,445.7 |  |  | $ | 1,503.9 |  |  | $ | (58.2) |  |  | (3.9) | % |

[0000889331-21-000010:mdna:116]
Electronics Segment

[0000889331-21-000010:mdna:117]
Net sales for the Electronics segment decreased $23.4 million, or 2.4%, in 2020 compared to 2019 primarily due to declines in net sales for the semiconductor and electronics products businesses of $17.5 million and $5.9 million, respectively, driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 during the first half of the year. These declines were partially offset by increases in customer demand for consumer devices for work from home needs and strength in various end markets during the second half of the year along with favorable changes in foreign exchange rates of $3.6 million.

[0000889331-21-000010:mdna:118]
Automotive Segment

[0000889331-21-000010:mdna:119]
Net sales in the Automotive segment decreased $32.7 million, or 7.6%, in 2020 compared to 2019 due to decreased volume in passenger car products, commercial vehicle products, and automotive sensors businesses of $18.1 million, $10.6 million, and $4.0 million, respectively, driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 and a decline in global auto production driven by the temporary closures of customer manufacturing facilities during the first half of 2020. These sales declines were partially offset by increases in end market demand across all businesses in the second half of 2020 and favorable changes in foreign exchange rates of $4.1 million.

[0000889331-21-000010:mdna:120]
Industrial Segment

[0000889331-21-000010:mdna:121]
The Industrial segment net sales decreased slightly by $2.1 million, or 1.9%, in 2020 compared to 2019 primarily due to decreased volume across all businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 in the first half of 2020, partially offset by the transfer of the temperature sensor product line in the third quarter of 2020 previously reported in the Electronics segment.

[0000889331-21-000010:mdna:122]
Geographic Net Sales Information

[0000889331-21-000010:mdna:123]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-21-000010:mdna:124]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | % Change |
| Asia-Pacific | $ | 670.5 |  |  | $ | 656.8 |  |  | $ | 13.7 |  |  | 2.1 | % |
| Americas | 457.8 |  |  | 508.4 |  |  | (50.6) |  |  | (10.0) | % |
| Europe | 317.4 |  |  | 338.7 |  |  | (21.3) |  |  | (6.3) | % |
| Total | $ | 1,445.7 |  |  | $ | 1,503.9 |  |  | $ | (58.2) |  |  | (3.9) | % |

[0000889331-21-000010:mdna:125]
Asia-Pacific

[0000889331-21-000010:mdna:126]
Asia-Pacific net sales increased $13.7 million, or 2.1%, in 2020 compared to 2019. The increase in net sales was primarily due to higher volume in the semiconductor business within the Electronics segment and favorable changes in foreign exchange rates of $2.2 million, partially offset by lower volume in the passenger car products business within the Automotive segment due to the production disruption associated with temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 in the first half of 2020.

[0000889331-21-000010:mdna:127]
Americas

[0000889331-21-000010:mdna:128]
Net sales in the Americas decreased $50.6 million, or 10.0%, in 2020 compared to 2019 primarily due to lower volume across all segments driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, the temporary closures of customer manufacturing facilities during the first half of 2020 and unfavorable changes in foreign exchange rates of  $0.3 million. These sales declines were partially offset by increases in end market demand across all businesses in the second half of the year.

[0000889331-21-000010:mdna:129]
Europe

[0000889331-21-000010:mdna:130]
European net sales decreased $21.3 million, or 6.3%, in 2020 compared to 2019. The decrease in net sales was primarily due to lower volume in the semiconductor business within the Electronics segment, lower volume in passenger car products and commercial vehicle products businesses within the Automotive segment driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 and the temporary closures of customer manufacturing facilities during the first half of 2020, partially offset by increased volume in the second half of 2020 due to higher end market demand in Electronics and Automotive businesses and favorable changes in foreign exchange rates of $5.8 million.

[0000889331-21-000010:mdna:131]
32

[0000889331-21-000010:mdna:132]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 28, 2019 AS COMPARED TO THE YEAR ENDED DECEMBER 29, 2018

[0000889331-21-000010:mdna:133]
The fiscal year 2019 included approximately $21.9 million of non-segment charges, of which $8.9 million of charges are acquisition-related and integration charges primarily related to the IXYS acquisition and other contemplated acquisitions, and $13.0 million of restructuring charges primarily related to employee termination costs. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-21-000010:mdna:134]
The fiscal year 2018 included approximately $88.7 million of non-segment charges, of which $82.9 million of charges are primarily related to the IXYS acquisition as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report. These charges include $36.9 million of purchase accounting inventory step-up charges, $18.7 million in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $12.4 million in backlog amortization costs, $8.3 million of employee termination costs and other restructuring charges, $4.5 million of stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods, and $2.1 million change in control expense related to IXYS. In addition, there were $5.8 million of employee termination costs, impairment and other restructuring charges and acquisition-related expenses for other contemplated acquisitions, which included charges associated with the exit of the Custom business in the second quarter within the Industrial segment.

[0000889331-21-000010:mdna:135]
Fiscal year 2019 also included approximately $5.2 million in foreign currency exchange losses primarily attributable to changes in the value of the euro, Chinese renminbi, and Japanese Yen against the U.S. dollar, while fiscal year 2018 also included approximately $0.9 million in foreign currency exchange gains primarily attributable to changes in the value of the euro, Mexico peso, Philippine peso and Chinese renminbi against the U.S. dollar.

[0000889331-21-000010:mdna:136]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2019 |  | 2018 |  | Change |  | % Change |
| Net sales | $ | 1,503,873 |  |  | $ | 1,718,468 |  |  | $ | (214,595) |  |  | (12.5) | % |
| Cost of sales | 957,578 |  |  | 1,065,053 |  |  | (107,475) |  |  | (10.1) | % |
| Gross profit | 546,295 |  |  | 653,415 |  |  | (107,120) |  |  | (16.4) | % |
| Operating expenses | 353,504 |  |  | 428,366 |  |  | (74,862) |  |  | (17.5) | % |
| Operating income | 192,791 |  |  | 225,049 |  |  | (32,258) |  |  | (14.3) | % |
| Other income, net | (583) |  |  | (1,599) |  |  | 1,016 |  |  | (63.5) | % |
| Income before income taxes | 165,884 |  |  | 204,942 |  |  | (39,058) |  |  | (19.1) | % |
| Income taxes | 26,802 |  |  | 40,377 |  |  | (13,575) |  |  | (33.6) | % |
| Net income | 139,082 |  |  | 164,565 |  |  | (25,483) |  |  | (15.5) | % |

[0000889331-21-000010:mdna:137]
Net Sales

[0000889331-21-000010:mdna:138]
Net sales for 2019 of $1,503.9 million decreased $214.6 million, or 12.5%, compared to the prior year primarily due to lower volume across the Electronics and Automotive segments driven by electronics distribution partners and end customers reducing excess inventories, a decline in global auto production and a decline in global end market demand, and $25.0 million or 1.5% of unfavorable changes in foreign exchange rates.

[0000889331-21-000010:mdna:139]
Cost of Sales

[0000889331-21-000010:mdna:140]
Cost of sales was $957.6 million, or 63.7% of net sales, in 2019, compared to $1,065.0 million, or 62.0% of net sales, in 2018. The $107.5 million decrease in cost of sales is primarily due to lower volume across the Electronics and Automotive segments driven by electronics distribution partners and end customers reducing excess inventories, a decline in global auto production and global end market demand. As a percent of net sales, cost of sales increased 1.7 percentage points driven by unfavorable expense leverage associated with the lower net sales in Electronics and Automotive segments.

[0000889331-21-000010:mdna:141]
Gross Profit

[0000889331-21-000010:mdna:142]
Gross profit was $546.3 million, or 36.3% of net sales, in 2019, compared to $653.4 million, or 38.0% of net sales, in 2018. The decrease in gross profit is primarily due to lower volumes across the Electronics and Automotive segments driven by

[0000889331-21-000010:mdna:143]
electronics distribution partners and end customers reducing excess inventories, a decline in global auto production and a decline in global end market demand, unfavorable price and product mix. In 2018 the IXYS purchase accounting inventory step-up charge of $36.9 million negatively impacted the 2018 gross margin by 2.1%.

[0000889331-21-000010:mdna:144]
Operating Expenses

[0000889331-21-000010:mdna:145]
Total operating expenses were $353.5 million, or 23.5% of net sales, for 2019 compared to $428.4 million, or 24.9% of net sales, for 2018. The decrease in operating expenses of $78.8 million was primarily due to lower annual incentive compensation expenses, reduced backlog amortization expense of $12.4 million, lower acquisition-related and integration costs of $11.3 million, global cost saving initiatives, and $4.5 million stock compensation expense and $2.1 million of change in control expense related to the 2018 IXYS acquisition.

[0000889331-21-000010:mdna:146]
Operating Income

[0000889331-21-000010:mdna:147]
Operating income for 2019 was $192.8 million, a decrease of $32.3 million or 14.3% compared to $225.0 million for 2018. The decrease in operating income is primarily due to lower gross profit across the Electronics and Automotive segments, partially offset by lower operating expenses noted above and the $36.9 million purchase accounting inventory step-up charges in 2018. Operating margins decreased from 13.1% in 2018 to 12.8% in 2019 primarily driven by lower gross profit margin discussed above.

[0000889331-21-000010:mdna:148]
Income Before Income Taxes

[0000889331-21-000010:mdna:149]
Income before income taxes for 2019 was $165.9 million, or 11.0% of net sales compared to $204.9 million, or 11.9% of net sales, for 2018. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was unfavorably impacted by foreign exchange losses of $5.2 million during the fiscal year ended December 28, 2019 compared to foreign exchange gains of $0.9 million during the fiscal year ended December 29, 2018, and decreases of $1.0 million in other income primarily due to the impairment charges of $7.3 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment during the fiscal year 2019, partially offset by unrealized investment gains associated with our equity investments and higher interest income.

[0000889331-21-000010:mdna:150]
Income Taxes

[0000889331-21-000010:mdna:151]
Income tax expense for 2019 was $26.8 million, or an effective tax rate of 16.2% compared to income tax expense of $40.4 million, or an effective tax rate of 19.7%, for 2018. The 2019 income tax expense includes a benefit of $3.3 million from the recognition of previously unrecognized tax benefits (and the reversal of the related accrued interest) due to a lapse in the statute of limitations. The 2018 income tax expense includes a charge of $3.2 million associated with finalizing the 2017 provisional reasonable estimate, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. Additionally, our tax rates are lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by the impact of taxes on unremitted earnings, the GILTI tax provisions and non-U.S. losses and expenses with no tax benefit.

[0000889331-21-000010:mdna:152]
Segment Information

[0000889331-21-000010:mdna:153]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-21-000010:mdna:154]
The following table is a summary of the Company’s net sales by segment:

[0000889331-21-000010:mdna:155]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | % Change |
| Electronics | $ | 961.1 |  |  | $ | 1,124.3 |  |  | $ | (163.2) |  |  | (14.5) | % |
| Automotive | 428.5 |  |  | 479.8 |  |  | (51.3) |  |  | (10.7) | % |
| Industrial | 114.3 |  |  | 114.4 |  |  | (0.1) |  |  | (0.1) | % |
| Total | $ | 1,503.9 |  |  | $ | 1,718.5 |  |  | $ | (214.6) |  |  | (12.5) | % |

[0000889331-21-000010:mdna:156]
Electronics Segment

[0000889331-21-000010:mdna:157]
The Electronics segment net sales decreased $163.2 million, or 14.5%, in 2019 compared to 2018 primarily due to lower volume across all businesses due to electronics distribution partners and end customer reducing excess inventories, a decline in global end market demand, and unfavorable changes in foreign exchange rates of $13.5 million.

[0000889331-21-000010:mdna:158]
Automotive Segment

[0000889331-21-000010:mdna:159]
Net sales in the Automotive segment decreased $51.3 million, or 10.7%, in 2019 compared to 2018 due to lower volume across all businesses primarily from a decline in global auto production, declines in commercial vehicle end market demand, and unfavorable changes in foreign exchange rates of $10.9 million.

[0000889331-21-000010:mdna:160]
Industrial Segment

[0000889331-21-000010:mdna:161]
The Industrial segment net sales decreased slightly by $0.1 million, or 0.1%, in 2019 compared to 2018 primarily due to the exit of the Custom business during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.6 million, partially offset by higher volume across all businesses..

[0000889331-21-000010:mdna:162]
Geographic Net Sales Information

[0000889331-21-000010:mdna:163]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-21-000010:mdna:164]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | % Change |
| Asia-Pacific | $ | 656.8 |  |  | $ | 753.3 |  |  | $ | (96.5) |  |  | (12.8) | % |
| Americas | 508.4 |  |  | 578.6 |  |  | (70.2) |  |  | (12.1) | % |
| Europe | 338.7 |  |  | 386.6 |  |  | (47.9) |  |  | (12.4) | % |
| Total | $ | 1,503.9 |  |  | $ | 1,718.5 |  |  | $ | (214.6) |  |  | (12.5) | % |

[0000889331-21-000010:mdna:165]
Asia-Pacific

[0000889331-21-000010:mdna:166]
Asia-Pacific net sales decreased $96.5 million, or 12.8%, in 2019 compared to 2018. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment and the Automotive segment, and unfavorable changes in foreign exchange rates of $6.8 million.

[0000889331-21-000010:mdna:167]
Americas

[0000889331-21-000010:mdna:168]
Net sales in the Americas decreased $70.2 million, or 12.1%, in 2019 compared to 2018 primarily due to lower volume across all businesses within the Electronics segment and the Automotive segment, the exit of the Custom business within Industrial segment during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.8 million, partially offset by higher volume in the power fuse and relay business within Industrial segments.

[0000889331-21-000010:mdna:169]
Europe

[0000889331-21-000010:mdna:170]
European net sales decreased $47.8 million, or 12.4%, in 2019 compared to 2018. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment and the Automotive segment, and unfavorable changes in foreign exchange rates of $17.4 million, partially offset by higher volume in the power fuse business within the Industrial segment.

[0000889331-21-000010:mdna:171]
Liquidity and Capital Resources

[0000889331-21-000010:mdna:172]
Cash and cash equivalents were $687.5 million as of December 26, 2020, an increase of $156.4 million as compared to December 28, 2019.

[0000889331-21-000010:mdna:173]
As of December 26, 2020, $352.8 million of the Company's $687.5 million cash and cash equivalents was held by non-U.S. subsidiaries. Of the $352.8 million, at least $147.4 million can be repatriated with minimal tax consequences, although in certain cases a non-U.S. withholding tax would be payable but subsequently refunded. With respect to the remaining $205.4 million, the Company has recognized deferred tax liabilities on approximately $113.3 million as of December 26, 2020 because the amounts are not considered to be permanently reinvested, and the Company may access additional amounts through loans and other means. Repatriation of some non-U.S. cash balances is restricted by local laws. Management regularly evaluates whether foreign earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its foreign subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-21-000010:mdna:174]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0000889331-21-000010:mdna:175]
Revolving Credit Facility/Term Loan

[0000889331-21-000010:mdna:176]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-21-000010:mdna:177]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.

[0000889331-21-000010:mdna:178]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19.

[0000889331-21-000010:mdna:179]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $110.0 million on the amended revolving credit facility during the fiscal year ended December 26, 2020. The balance under the facility was $130.0 million as of December 26, 2020.

[0000889331-21-000010:mdna:180]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR fixed for interest periods of one, two, three or six-month periods plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.65% at December 26, 2020.

[0000889331-21-000010:mdna:181]
As of December 26, 2020, the Company had no amounts outstanding in letters of credit and had available $383.5 million of borrowing capacity under the Revolving Credit Facility.

[0000889331-21-000010:mdna:182]
Senior Notes

[0000889331-21-000010:mdna:183]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-21-000010:mdna:184]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000010:mdna:185]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing August 15, 2018.

[0000889331-21-000010:mdna:186]
The Company was in compliance with its debt covenants as of December 26, 2020 and expects to remain in compliance based on management’s estimates of operating and financial results for 2020 and the foreseeable future. As of December 26, 2020, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-21-000010:mdna:187]
Acquisitions

[0000889331-21-000010:mdna:188]
On January 28, 2021, the Company acquired Hartland Controls, a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The cash purchase price for Hartland Controls was approximately $113 million and the operations of Hartland Controls will be included in the Industrial segment. The Company funded the acquisition with cash on hand.

[0000889331-21-000010:mdna:189]
During the year ended December 29, 2018, the Company paid $306.5 million, net of cash acquired, for the acquisition of IXYS. Pursuant to the Securities Purchase Agreement, the Company paid $9.0 million for the acquisition of the remaining 38% outstanding common stock of Monolith during the year ended December 29, 2018. The Company financed the cash portion of the IXYS acquisition with a combination of cash on hand and borrowings under the Senior Notes and credit facility.

[0000889331-21-000010:mdna:190]
Cash Flow Overview

[0000889331-21-000010:mdna:191]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes and other operating activities.

[0000889331-21-000010:mdna:192]
The following describes the Company’s cash flows for the twelve months ended December 26, 2020 and December 28, 2019:

[0000889331-21-000010:mdna:193]
|  | Fiscal Year |
| (in millions) | 2020 |  | 2019 |
| Net cash provided by operating activities | $ | 258.0 |  |  | $ | 245.3 |  |
| Net cash used in investing activities | (51.4) |  |  | (56.4) |  |
| Net cash used in financing activities | (67.8) |  |  | (146.3) |  |
| Effect of exchange rate changes on cash and cash equivalents | 17.6 |  |  | (1.2) |  |
| Increase in cash and cash equivalents | 156.4 |  |  | 41.4 |  |
| Cash and cash equivalents at beginning of year | 531.1 |  |  | 489.7 |  |
| Cash and cash equivalents at end of year | $ | 687.5 |  |  | $ | 531.1 |  |

[0000889331-21-000010:mdna:194]
Cash Flow from Operating Activities

[0000889331-21-000010:mdna:195]
Net cash provided by operating activities was $258.0 million for 2020, compared to $245.3 million during 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and favorable changes in net working capital partially offset by lower earnings largely due to the impact of COVID-19.

[0000889331-21-000010:mdna:196]
Cash Flow from Investing Activities

[0000889331-21-000010:mdna:197]
Net cash used in investing activities was $51.4 million for 2020, compared to $56.4 million during 2019. Capital expenditures were $56.2 million, representing a decrease of $5.7 million compared to 2019. The Company also received proceeds of $4.8 million and $6.2 million, respectively, in 2020 and 2019 primarily as a result of the sale of properties within the Industrial segment.

[0000889331-21-000010:mdna:198]
Cash Flow from Financing Activities

[0000889331-21-000010:mdna:199]
Net cash used in financing activities was $67.8 million for 2020 compared to $146.3 million for 2019. The Company made principal payments of $5.0 million and $10.0 million on the term loan during fiscal year 2020 and 2019, respectively. During fiscal year 2020, the company borrowed $100.0 million from its revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. On April 3, 2020, the Company amended the Credit Agreement to eliminate the $200.0 million unsecured term loan credit facility, with the remaining outstanding balance of $140.0 million repaid in full on April 3, 2020 through a new borrowing of $140.0 million under the recently amended revolving credit facility. The Company made payments of $110.0 million on the amended revolving credit facility during the fiscal year 2020. The balance under the facility was $130.0 million as of December 26, 2020.

[0000889331-21-000010:mdna:200]
For the fiscal year 2020 and 2019, the Company repurchased 175,110 and 579,916 shares of its common stock totaling $22.9 million and $95.0 million, respectively, but made payments of $99.4 million related to settled share repurchases during the fiscal year 2019. Additionally, dividends paid increased $2.2 million from $44.7 million for the fiscal year 2019 to $46.8 million for the fiscal year 2020.

[0000889331-21-000010:mdna:201]
The following describes the Company’s cash flows for the twelve months ended December 28, 2019 and December 29, 2018:

[0000889331-21-000010:mdna:202]
|  | Fiscal Year |
| (in millions) | 2019 |  | 2018 |
| Net cash provided by operating activities | $ | 245.3 |  |  | $ | 331.8 |  |
| Net cash used in investing activities | (56.4) |  |  | (382.3) |  |
| Net cash (used in) provided by financing activities | (146.3) |  |  | 121.9 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1.2) |  |  | (11.4) |  |
| Increase in cash and cash equivalents | 41.4 |  |  | 60.0 |  |
| Cash and cash equivalents at beginning of year | 489.7 |  |  | 429.7 |  |
| Cash and cash equivalents at end of year | $ | 531.1 |  |  | $ | 489.7 |  |

[0000889331-21-000010:mdna:203]
Cash Flow from Operating Activities

[0000889331-21-000010:mdna:204]
Net cash provided by operating activities was $245.3 million for 2019, compared to $331.8 million during 2018. The decrease in net cash provided by operating activities was primarily driven by lower earnings and higher working capital levels primarily due to the timing of supplier payments, payroll year-end cut off and higher annual incentive compensation payments in 2019.

[0000889331-21-000010:mdna:205]
Cash Flow from Investing Activities

[0000889331-21-000010:mdna:206]
Net cash used in investing activities was $56.4 million for 2019, compared to $382.3 million during 2019. Net cash used for the acquisition of IXYS was $306.5 million and $9.0 million for the acquisition of the remaining 38% outstanding common stock of Monolith in 2018. Capital expenditures were $61.9 million, representing a decrease of $12.9 million compared to 2018. The Company also received proceeds of $6.2 million in 2019 primarily as a result of the sale of a property within the Industrial segment.

[0000889331-21-000010:mdna:207]
Cash Flow from Financing Activities

[0000889331-21-000010:mdna:208]
Net cash used in financing activities was $146.3 million for 2019 compared to net cash provided by financing activities of $121.9 million for 2018. The Company repurchased 579,916 shares of its common stock during fiscal 2019 totaling $95.0 million, but made payments of $99.4 million related to settled share repurchases. The Company made payments of $10.0 million on the term loan in 2019 as compared to $310.0 million of proceeds from the credit facility, term loan and senior notes payable and $102.5 million of payments on the credit facility and term loan during 2018.

[0000889331-21-000010:mdna:209]
Contractual Obligations and Commitments

[0000889331-21-000010:mdna:210]
The following table summarizes outstanding contractual obligations and commitments as of December 26, 2020:

[0000889331-21-000010:mdna:211]
|  | Payments Due By Period |
| (in thousands) | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | Greaterthan 5 Years |
| Long-term debt(a) | $ | 691,148 |  |  | $ | — |  |  | $ | 170,298 |  |  | $ | 180,000 |  |  | $ | 340,850 |  |
| Interest payments(b) | 100,473 |  |  | 16,048 |  |  | 30,806 |  |  | 24,639 |  |  | 28,980 |  |
| Operating lease payments(c) | 21,688 |  |  | 7,660 |  |  | 10,114 |  |  | 3,612 |  |  | 302 |  |
| Income Tax Obligation(d) | 23,754 |  |  | 3,000 |  |  | 7,579 |  |  | 13,175 |  |  | — |  |
| Purchase obligations(e) | 18,214 |  |  | 15,089 |  |  | 1,008 |  |  | 1,008 |  |  | 1,109 |  |
| Total | $ | 855,277 |  |  | $ | 41,797 |  |  | $ | 219,805 |  |  | $ | 222,434 |  |  | $ | 371,241 |  |

[0000889331-21-000010:mdna:212]
(a)Excludes offsetting issuance costs of $4.1 million. Euro denominated debt amounts are converted based on the Euro to U.S. Dollar spot rate at year end. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-21-000010:mdna:213]
(b)Amounts represent estimated contractual interest payments on outstanding debt. Rates in effect as of December 26, 2020 are used for variable rate debt. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-21-000010:mdna:214]
(c)For more information see Note 7, Lease Commitments, of the Notes to Consolidated Financial Statements.

[0000889331-21-000010:mdna:215]
(d)The Income Tax Obligation represents the remaining amounts payable regarding the 2017 Littelfuse Toll Charge. The Company has elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. For more information see Note 14, Income Taxes, of the Notes to Consolidated Financial Statements.

[0000889331-21-000010:mdna:216]
(e)Purchase obligations include purchase commitments and commitments for capital expenditures not recognized in the Company’s Consolidated Balance Sheets.

[0000889331-21-000010:mdna:217]
In addition to the above contractual obligations and commitments, the Company had the following obligations at December 26, 2020:

[0000889331-21-000010:mdna:218]
The Company has Company-sponsored defined benefit pension plans covering employees at various non-U.S. subsidiaries including the U.K., Germany, the Philippines, China, Japan, Mexico, Italy and France. At December 26, 2020, the Company

[0000889331-21-000010:mdna:219]
had a net unfunded status of $48.5 million. The Company expects to make approximately $2.2 million of contributions to the plans in 2021. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0000889331-21-000010:mdna:220]
Dividends

[0000889331-21-000010:mdna:221]
Cash dividends paid totaled $46.8 million, $44.7 million and $40.0 million for 2020, 2019 and 2018, respectively. On January 21, 2021, the Board of Directors of the Company declared a quarterly cash dividend of $0.48 per share, payable on March 4, 2021 to stockholders of record as of February 18, 2021.

[0000889331-21-000010:mdna:222]
Capital Resources

[0000889331-21-000010:mdna:223]
The Company expends capital to support its operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0000889331-21-000010:mdna:224]
Share Repurchase Program

[0000889331-21-000010:mdna:225]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized to a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program") to replace its previous expired 2018 program. On April 23, 2020, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. There are 1,000,000 shares remaining available for purchase under the 2020 program as of December 26, 2020.

[0000889331-21-000010:mdna:226]
During the fiscal year 2020, 2019, and 2018, the Company repurchased 175,110, 579,916, and 391,972 shares of its common stock totaling $22.9 million, $95.0 million, and  $67.9 million, respectively.

[0000889331-21-000010:mdna:227]
Off-Balance Sheet Arrangements

[0000889331-21-000010:mdna:228]
As of December 26, 2020, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-21-000010:mdna:229]
Recent Accounting Pronouncements

[0000889331-21-000010:mdna:230]
Recently issued accounting standards and their estimated effect on the Company’s Consolidated Financial Statements are described in Note 1, Summary of Significant Accounting Policies and Other Information, of the Notes to Consolidated Financial Statements.
