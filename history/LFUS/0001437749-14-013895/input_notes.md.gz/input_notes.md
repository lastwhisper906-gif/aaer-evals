# LFUS notes — 0001437749-14-013895


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-14-013895:notes:1]
[same as prior period, unchanged from 0001437749-14-007780:notes:1]

[0001437749-14-013895:notes:2]
The company accounts for acquisitions using the purchase method in accordance with ASC 805, “Business Combinations.” The results of operations of each acquisition have been included in the accompanying consolidated financial statements as of the dates of the acquisition.

[0001437749-14-013895:notes:3]
[same as prior period, unchanged from 0001437749-14-007780:notes:2]

[0001437749-14-013895:notes:4]
On January 3, 2014, the company acquired 100% of SymCom, Inc. (“SymCom”) for $52.8 million net of cash acquired. Headquartered in Rapid City, South Dakota, SymCom provides overload relays and pump controllers primarily to the industrial market. The acquisition allows the company to strengthen its position in the relay products market by adding new products and new customers within its Electrical business unit segment. SymCom is based in Rapid City, South Dakota. The company funded the acquisition with available cash and proceeds from credit facilities.

[0001437749-14-013895:notes:5]
[same as prior period, unchanged from 0001437749-14-007780:notes:4]

[0001437749-14-013895:notes:6]
| SymCom preliminary purchase price allocation (in thousands): |  |
| Cash |  | $ | 325 |  |
| Current assets, net |  |  | 9,479 |  |
| Property, plant and equipment |  |  | 11,193 |  |
| Goodwill |  |  | 14,738 |  |
| Trademarks |  |  | 17,020 |  |
| Patents |  |  | 1,500 |  |
| Other non-current assets |  |  | 20 |  |
| Current liabilities |  |  | (1,182 | ) |
|  |  | $ | 53,093 |  |

[0001437749-14-013895:notes:7]
[same as prior period, unchanged from 0001437749-14-007780:notes:6]

[0001437749-14-013895:notes:8]
As required by purchase accounting rules, the company initially recorded a $2.6 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. During the first quarter of 2014, as a portion of this inventory was sold, cost of goods sold included a $1.4 million non-cash charge for this step-up.

[0001437749-14-013895:notes:9]
During the second quarter of 2014, the inventory step-up valuation was finalized at $2.8 million which resulted in an additional $1.4 million non-cash charge to cost of goods sold for the second quarter of 2014.

[0001437749-14-013895:notes:10]
[same as prior period, unchanged from 0001437749-14-007780:notes:8]

[0001437749-14-013895:notes:11]
[same as prior period, unchanged from 0001437749-14-007780:notes:9]

[0001437749-14-013895:notes:12]
On May 31, 2013, the company acquired 100% of Hamlin, Inc. (“Hamlin”) from Key Safety Systems, for $144.4 million (net of cash acquired). Hamlin is a manufacturer of sensor technology providing standard products and custom solutions for leading global manufacturers in the automotive and electronic industries. The acquisition allows the company to expand its automotive and electronics product offerings in the global sensor market in both the Automotive and Electronics business segments. Hamlin is headquartered in Lake Mills, Wisconsin and has manufacturing, engineering and sales offices in the U.S., Mexico, Europe and Asia. The company funded the acquisition with available cash raised from borrowings on the company’s new credit arrangement. (See Note 6).

[0001437749-14-013895:notes:13]
The following table sets forth the final purchase price allocation, as of May 31, 2014, for Hamlin acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values.

[0001437749-14-013895:notes:14]
| Hamlin final purchase price allocation (in thousands): |  |
| Cash |  | $ | 15,984 |  |
| Current assets, net |  |  | 27,811 |  |
| Property, plant and equipment |  |  | 24,728 |  |
| Goodwill |  |  | 51,218 |  |
| Distribution network |  |  | 35,327 |  |
| Patents and licenses |  |  | 16,276 |  |
| Trademarks |  |  | 6,522 |  |
| Non-current assets |  |  | 2,452 |  |
| Current liabilities |  |  | (7,734 | ) |
| Non-current liabilities |  |  | (12,217 | ) |
|  |  | $ | 160,367 |  |

[0001437749-14-013895:notes:15]
[same as prior period, unchanged from 0001437749-14-007780:notes:13]

[0001437749-14-013895:notes:16]
As required by purchase accounting rules, the company recorded a $2.1 million step-up of inventory to its fair value as of the acquisition date. During the second quarter of 2013, as a portion of this inventory was sold, cost of goods sold included $1.7 million of non-cash charges for this step-up.

[0001437749-14-013895:notes:17]
The following unaudited pro forma results are provided below for the company’s acquisition of Hamlin and assume that the acquisition of Hamlin had been completed as of the beginning of fiscal year 2012.

[0001437749-14-013895:notes:18]
|  |  | (In thousands except for per share amounts) |  |
|  |  | For the three months ended |  |  | For the six months ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (As restated) |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |  |
| Revenues |  | $ | 220,908 |  |  | $ | 201,346 |  |  | $ | 427,767 |  |  | $ | 390,055 |  |
| Net income |  | $ | 24,578 |  |  | $ | 26,224 |  |  | $ | 49,967 |  |  | $ | 38,435 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.09 |  |  | $ | 1.17 |  |  | $ | 2.22 |  |  | $ | 1.89 |  |
| Diluted |  | $ | 1.08 |  |  | $ | 1.16 |  |  | $ | 2.20 |  |  | $ | 1.87 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,579 |  |  |  | 22,296 |  |  |  | 22,536 |  |  |  | 22,197 |  |
| Diluted |  |  | 22,750 |  |  |  | 22,499 |  |  |  | 22,738 |  |  |  | 22,431 |  |

[0001437749-14-013895:notes:19]
For the three three months ended June 28, 2014, Hamlin added approximately $14.7 million in revenue and $0.9 million net income to the company’s consolidated results. For the six months ended June 28, 2014, Hamlin added approximately $36.5 million in revenue and $1.2 million net income to the company’s consolidated results.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-14-013895:notes:20]
[same as prior period, unchanged from 0001437749-14-007780:notes:17]

[0001437749-14-013895:notes:21]
The components of inventories at June 28, 2014 and December 28, 2013 are as follows (in thousands):

[0001437749-14-013895:notes:22]
|  |  | June 28, 2014 |  |  | December 28, 2013 |  |
| Raw material |  | $ | 28,609 |  |  | $ | 28,228 |  |
| Work in process |  |  | 18,449 |  |  |  | 17,576 |  |
| Finished goods |  |  | 49,616 |  |  |  | 46,787 |  |
| Total inventories |  | $ | 96,674 |  |  | $ | 92,591 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-14-013895:notes:23]
[same as prior period, unchanged from 0001437749-14-007780:notes:20]

[0001437749-14-013895:notes:24]
The company’s other investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company. The Polytronics investment was acquired as part of the Heinrich Companies acquisition in 2004. The fair value of the Polytronics investment was €11.6 million (approximately $15.8 million) at June 28, 2014 and €9.0 million (approximately $12.3 million) at December 28, 2013. Included in 2014 other comprehensive income is an unrealized gain of $2.3 million, due to the increase in fair market value of the Polytronics investment. The remaining movement was due to the impact of changes in exchange rates.


## us-gaap:AssetImpairmentChargesTextBlock

[0001437749-14-013895:notes:25]
[same as prior period, unchanged from 0001437749-14-007780:notes:22]

[0001437749-14-013895:notes:26]
During the first quarter of 2013, the company fully impaired its investment in and loan receivable from Shocking Technologies, Inc. owing to their filing for Chapter 7 bankruptcy on March 12, 2013. The impairment charge of approximately $10.7 million consisted of the remaining equity method investment of $8.7 million and a $2.0 million loan receivable, and reduced the carrying value of both the investment and loan receivable to zero at March 30, 2013.

[0001437749-14-013895:notes:27]
The loss was recorded as a component of impairment and equity loss of unconsolidated affiliate in the Consolidated Statements of Net Income for the six months ended June 29, 2013.


## us-gaap:DebtDisclosureTextBlock

[0001437749-14-013895:notes:28]
6. Debt

[0001437749-14-013895:notes:29]
The carrying amounts of long-term debt at June 28, 2014 and December 28, 2013 are as follows (in thousands):

[0001437749-14-013895:notes:30]
|  |  | June 28, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 96,250 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 199,000 |  |  |  | 121,000 |  |
| Total debt |  |  | 295,250 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 204,000 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 91,250 |  |  | $ | 93,750 |  |

[0001437749-14-013895:notes:31]
On May 31, 2013, the company entered into a new credit agreement with J.P Morgan Securities LLC for up to $325.0 million which consisted of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of June 28, 2014, the company had available $75.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.250% (1.4% as of June 28, 2014). At June 28, 2014, the company was in compliance with all covenants under the revolving credit facility.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-14-013895:notes:32]
[same as prior period, unchanged from 0001437749-14-007780:notes:29]

[0001437749-14-013895:notes:33]
[same as prior period, unchanged from 0001437749-14-007780:notes:30]

[0001437749-14-013895:notes:34]
[same as prior period, unchanged from 0001437749-14-007780:notes:31]

[0001437749-14-013895:notes:35]
[same as prior period, unchanged from 0001437749-14-007780:notes:32]

[0001437749-14-013895:notes:36]
[same as prior period, unchanged from 0001437749-14-007780:notes:33]

[0001437749-14-013895:notes:37]
[same as prior period, unchanged from 0001437749-14-007780:notes:34]

[0001437749-14-013895:notes:38]
[same as prior period, unchanged from 0001437749-14-007780:notes:35]

[0001437749-14-013895:notes:39]
[same as prior period, unchanged from 0001437749-14-007780:notes:36]

[0001437749-14-013895:notes:40]
The company holds an investment in the equity securities of Polytronics as described in Note 4. Equity securities listed on a national market or exchange are valued at the last sales price. Such securities are classified within Level 1 of the valuation hierarchy.

[0001437749-14-013895:notes:41]
There were no changes during the six months ended June 28, 2014 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of June 28, 2014 and December 28, 2013 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-14-013895:notes:42]
The following table presents assets and liabilities measured at fair value by classification within the fair value hierarchy as of June 28, 2014 (in thousands):

[0001437749-14-013895:notes:43]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 15,787 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,787 |  |
| Total |  | $ | 15,787 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,787 |  |

[0001437749-14-013895:notes:44]
[same as prior period, unchanged from 0001437749-14-007780:notes:41]

[0001437749-14-013895:notes:45]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 12,286 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,286 |  |
| Total |  | $ | 12,286 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,286 |  |

[0001437749-14-013895:notes:46]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt. The carrying amounts of cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt approximate their fair values. The company’s debt fair value approximates book value at June 28, 2014 and December 28, 2013, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:EarningsPerShareTextBlock

[0001437749-14-013895:notes:47]
[same as prior period, unchanged from 0001437749-14-007780:notes:44]

[0001437749-14-013895:notes:48]
[same as prior period, unchanged from 0001437749-14-007780:notes:45]

[0001437749-14-013895:notes:49]
[same as prior period, unchanged from 0001437749-14-007780:notes:46]

[0001437749-14-013895:notes:50]
The following table sets forth the computation of basic and diluted earnings per share under the treasury share method as of June 28, 2014 and the two-class method as of June 29, 2013.

[0001437749-14-013895:notes:51]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands except per share amounts) |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Net income as reported |  | $ | 24,578 |  |  | $ | 26,648 |  |  | $ | 49,967 |  |  | $ | 38,136 |  |
| Less: Distributed earnings available to participating securities |  |  | — |  |  |  | (10 | ) |  |  | — |  |  |  | (18 | ) |
| Less: Undistributed earnings available to participating securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (14 | ) |
| Numerator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 24,578 |  |  | $ | 26,638 |  |  | $ | 49,967 |  |  | $ | 38,104 |  |
| Add: Undistributed earnings allocated to participating securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |
| Less: Undistributed earnings reallocated to participating securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (14 | ) |
| Numerator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 24,578 |  |  | $ | 26,638 |  |  | $ | 49,967 |  |  | $ | 38,104 |  |
| Denominator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares |  |  | 22,579 |  |  |  | 22,296 |  |  |  | 22,536 |  |  |  | 22,196 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Common stock equivalents |  |  | 171 |  |  |  | 203 |  |  |  | 202 |  |  |  | 234 |  |
| Denominator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted for weighted-average shares & assumed conversions |  |  | 22,750 |  |  |  | 22,499 |  |  |  | 22,738 |  |  |  | 22,431 |  |
| Basic earnings per share |  | $ | 1.09 |  |  | $ | 1.19 |  |  | $ | 2.22 |  |  | $ | 1.72 |  |
| Diluted earnings per share |  | $ | 1.08 |  |  | $ | 1.18 |  |  | $ | 2.20 |  |  | $ | 1.70 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-14-013895:notes:52]
[same as prior period, unchanged from 0001437749-14-007780:notes:49]

[0001437749-14-013895:notes:53]
The effective tax rate for the second quarter of 2014 was 22.1% compared to an effective tax rate of 24.7% in the second quarter of 2013. The effective tax rate for the six months ended June 28, 2014 was 23.6% as compared to an effective tax rate of 28.5% for the six months ended June 29, 2013. The effective tax rates for both the second quarter and six month periods of 2014 and 2013 are lower than the U.S. statutory tax rate primarily due to the result of more income earned in low tax jurisdictions.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-14-013895:notes:54]
[same as prior period, unchanged from 0001437749-14-007780:notes:51]

[0001437749-14-013895:notes:55]
The components of net periodic benefit cost for the three and six and months ended June 28, 2014, compared with the three and six months ended June 29, 2013, were (in thousands):

[0001437749-14-013895:notes:56]
|  |  | U.S. Pension Benefits |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Service cost |  | $ | 150 |  |  | $ | 150 |  |  | $ | 300 |  |  | $ | 300 |  |  | $ | 311 |  |  | $ | 268 |  |  | $ | 622 |  |  | $ | 523 |  |
| Interest cost |  |  | 971 |  |  |  | 892 |  |  |  | 1,942 |  |  |  | 1,783 |  |  |  | 592 |  |  |  | 299 |  |  |  | 1,183 |  |  |  | 482 |  |
| Expected return on plan assets |  |  | (1,411 | ) |  |  | (1,340 | ) |  |  | (2,822 | ) |  |  | (2,680 | ) |  |  | (573 | ) |  |  | (197 | ) |  |  | (1,146 | ) |  |  | (271 | ) |
| Amortization of net loss |  |  | 137 |  |  |  | 235 |  |  |  | 274 |  |  |  | 471 |  |  |  | 47 |  |  |  | 38 |  |  |  | 95 |  |  |  | 77 |  |
| Total cost (credit) of the plan |  |  | (153 | ) |  |  | (63 | ) |  |  | (306 | ) |  |  | (126 | ) |  |  | 377 |  |  |  | 408 |  |  |  | 754 |  |  |  | 811 |  |
| Expected plan participants’ contribution |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net periodic benefit (credit) cost |  | $ | (153 | ) |  | $ | (63 | ) |  | $ | (306 | ) |  | $ | (126 | ) |  | $ | 377 |  |  | $ | 408 |  |  | $ | 754 |  |  | $ | 811 |  |

[0001437749-14-013895:notes:57]
The expected rate of return assumption on domestic pension assets is approximately 6.75% in 2014 and 2013. The expected return on foreign pension assets is approximately 5.14% and 3.00% in 2014 and 2013, respectively.

[0001437749-14-013895:notes:58]
As described in Note 13, on July 31, 2014, the company terminated the Littelfuse, Inc. Retirement Plan (the “Pension Plan”, a plan that was previously offered to all full-time Company employees but frozen as to new participants and benefit accruals as of April 1, 2009.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-14-013895:notes:59]
[same as prior period, unchanged from 0001437749-14-007780:notes:55]

[0001437749-14-013895:notes:60]
[same as prior period, unchanged from 0001437749-14-007780:notes:56]

[0001437749-14-013895:notes:61]
[same as prior period, unchanged from 0001437749-14-007780:notes:57]

[0001437749-14-013895:notes:62]
[same as prior period, unchanged from 0001437749-14-007780:notes:58]

[0001437749-14-013895:notes:63]
Business unit segment information for the three and six months ended June 28, 2014 and June 29, 2013 are summarized as follows (in thousands):

[0001437749-14-013895:notes:64]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 109,947 |  |  | $ | 91,450 |  |  | $ | 205,972 |  |  | $ | 170,865 |  |
| Automotive |  |  | 82,042 |  |  |  | 64,548 |  |  |  | 164,444 |  |  |  | 123,933 |  |
| Electrical |  |  | 28,919 |  |  |  | 31,768 |  |  |  | 57,351 |  |  |  | 63,886 |  |
| Total net sales |  | $ | 220,908 |  |  | $ | 187,766 |  |  | $ | 427,767 |  |  | $ | 358,684 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 5,530 |  |  | $ | 5,131 |  |  | $ | 10,900 |  |  | $ | 9,992 |  |
| Automotive |  |  | 3,646 |  |  |  | 2,319 |  |  |  | 7,174 |  |  |  | 4,303 |  |
| Electrical |  |  | 1,414 |  |  |  | 997 |  |  |  | 2,682 |  |  |  | 1,955 |  |
| Total depreciation and amortization |  | $ | 10,590 |  |  | $ | 8,447 |  |  | $ | 20,756 |  |  | $ | 16,250 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 26,210 |  |  | $ | 19,779 |  |  | $ | 45,581 |  |  | $ | 31,922 |  |
| Automotive |  |  | 10,472 |  |  |  | 8,913 |  |  |  | 22,354 |  |  |  | 18,396 |  |
| Electrical |  |  | 571 |  |  |  | 5,623 |  |  |  | 4,317 |  |  |  | 12,114 |  |
| Other(1) |  |  | (3,534 | ) |  |  | (2,933 | ) |  |  | (4,943 | ) |  |  | (2,933 | ) |
| Total operating income |  |  | 33,719 |  |  |  | 31,382 |  |  |  | 67,309 |  |  |  | 59,499 |  |
| Interest expense |  |  | 1,228 |  |  |  | 644 |  |  |  | 2,444 |  |  |  | 1,020 |  |
| Impairment, loan loss and equity in net loss or unconsolidated affiliate (2) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 10,678 |  |
| Foreign exchange (gain) loss |  |  | 2,375 |  |  |  | (3,724 | ) |  |  | 2,123 |  |  |  | (3,405 | ) |
| Other (income) expense, net |  |  | (1,446 | ) |  |  | (935 | ) |  |  | (2,632 | ) |  |  | (2,163 | ) |
| Income before income taxes |  | $ | 31,562 |  |  | $ | 35,397 |  |  | $ | 65,374 |  |  | $ | 53,369 |  |

[0001437749-14-013895:notes:65]
(1) “Other” consists of acquisition related costs and severance charges. (2) During the first quarter of 2013, the company recorded an impairment of its investment in Shocking Technologies. (See Note 5).

[0001437749-14-013895:notes:66]
The company’s significant net sales by country for the three and six months ended June 28, 2014 and June 29, 2013 are summarized as follows (in thousands):

[0001437749-14-013895:notes:67]
|  |  | For the Three Months Ended(a) |  |  | For the Six Months Ended(a) |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| United States |  | $ | 80,492 |  |  | $ | 68,633 |  |  | $ | 152,366 |  |  | $ | 126,547 |  |
| China |  |  | 39,987 |  |  |  | 37,694 |  |  |  | 77,200 |  |  |  | 71,308 |  |
| Other countries |  |  | 100,429 |  |  |  | 81,439 |  |  |  | 198,201 |  |  |  | 160,829 |  |
| Total |  | $ | 220,908 |  |  | $ | 187,766 |  |  | $ | 427,767 |  |  | $ | 358,684 |  |

[0001437749-14-013895:notes:68]
[same as prior period, unchanged from 0001437749-14-007780:notes:65]

[0001437749-14-013895:notes:69]
The company’s significant long-lived assets by country as of June 28, 2014 and December 28, 2013 are summarized as follows (in thousands):

[0001437749-14-013895:notes:70]
|  |  | Long-lived assets(b) |  |
|  |  | June 28, 2014 |  |  | December 28, 2013 |  |
| United States |  | $ | 38,620 |  |  | $ | 27,294 |  |
| China |  |  | 42,096 |  |  |  | 45,843 |  |
| Canada |  |  | 14,275 |  |  |  | 14,429 |  |
| Other countries |  |  | 63,668 |  |  |  | 62,607 |  |
| Total |  | $ | 158,659 |  |  | $ | 150,173 |  |

[0001437749-14-013895:notes:71]
(b) Long-lived assets consist of net property, plant and equipment.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-14-013895:notes:72]
[same as prior period, unchanged from 0001437749-14-007780:notes:69]

[0001437749-14-013895:notes:73]
[same as prior period, unchanged from 0001437749-14-007780:notes:70]

[0001437749-14-013895:notes:74]
| AOCI component |  | Balance at December 28, 2013 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Balance at June 28, 2014 |  |
| Pension liability adjustment(a) |  | $ | (17,140 | ) |  | $ | (180 | ) |  | $ | 175 |  |  | $ | (17,145 | ) |
| Unrealized gain on investments(b) |  |  | 9,393 |  |  |  | 3,584 |  |  |  | — |  |  |  | 12,977 |  |
| Foreign currency translation adjustment |  |  | 28,164 |  |  |  | (311 | ) |  |  | — |  |  |  | 27,853 |  |
| AOCI income (loss) |  | $ | 20,417 |  |  | $ | 3,093 |  |  | $ | 175 |  |  | $ | 23,685 |  |

[0001437749-14-013895:notes:75]
(a) Balances are net of tax of $6,551 and $6,549 for 2014 and 2013, respectively.

[0001437749-14-013895:notes:76]
[same as prior period, unchanged from 0001437749-14-007780:notes:73]


## us-gaap:SubsequentEventsTextBlock

[0001437749-14-013895:notes:77]
13. Subsequent Events

[0001437749-14-013895:notes:78]
On July 31, 2014, the company terminated the Pension Plan. Distribution of plan assets resulting from the Pension Plan termination will not be made until the Internal Revenue Service and the Pension Benefit Guaranty Corporation determine that the termination satisfies applicable regulatory requirements. As a result of the termination of the Pension Plan, each participant will become fully vested in his or her benefits under the Pension Plan without regard to age and years of service. All participants will have a choice of receiving a lump sum payment or an annuity in full payment of their benefits accrued under the Pension Plan.
