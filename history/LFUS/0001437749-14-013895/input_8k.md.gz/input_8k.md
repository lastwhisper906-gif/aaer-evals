# LFUS 8-K — 0001437749-14-013652 filed 2014-07-30

## item codes, every 8-K on or before 2014-08-01

- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2014-08-01

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-14-013652:8k_2_02:1]
EX-99
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-14-013652:8k_2_02:2]
ex99-1.htm

[0001437749-14-013652:8k_2_02:3]
Exhibit 99.1

[0001437749-14-013652:8k_2_02:4]
NEWS RELEASE

[0001437749-14-013652:8k_2_02:5]
CONTACT: Phil Franklin,

[0001437749-14-013652:8k_2_02:6]
Senior Vice President and CFO (773) 628-0810

[0001437749-14-013652:8k_2_02:7]
LITTELFUSE REPORTS SECOND QUARTER RESULTS

[0001437749-14-013652:8k_2_02:8]
CHICAGO, July 30, 2014 – Littelfuse, Inc. (NASDAQ:LFUS) today reported sales and earnings for the second quarter of 2014 and announced a 14% increase in the quarterly cash dividend.

[0001437749-14-013652:8k_2_02:9]
Second Quarter Highlights

[0001437749-14-013652:8k_2_02:10]
|  | ● | Sales for the second quarter of 2014 were $220.9 million, an 18% increase compared to the prior-year quarter. This strong sales performance was due to double-digit organic growth for both automotive and electronics as well as the Hamlin and SymCom acquisitions, partially offset by continued weakness in the electrical business. Excluding acquisitions, sales increased 7% compared to the prior year. |

[0001437749-14-013652:8k_2_02:11]
|  | ● | On a GAAP basis, second quarter 2014 earnings were $1.08 per diluted share. This included $3.6 million of special operating items including severance charges resulting from restructuring at the Hamlin-Mexico plant and purchase accounting charges related to the SymCom acquisition. In addition, there was a non-operating foreign exchange loss of $2.4 million due primarily to balance sheet revaluation in the Philippines. Excluding these special items, earnings for the second quarter of 2014 were $1.26 per diluted share. |

[0001437749-14-013652:8k_2_02:12]
|  | ● | Earnings for the second quarter of 2014 were negatively impacted by higher scrap and obsolete inventory charges of approximately $1.9 million and a $2.3 million increase in stock compensation expense compared to the first quarter of 2014. The additional scrap and obsolete inventory charges were primarily the result of quality and performance issues at one of our North American plants as well as the downturn in the company’s mining business. The increase in stock compensation expense in the second quarter relates to technical accounting issues and will return to more normal levels in the third quarter. |

[0001437749-14-013652:8k_2_02:13]
|  | ● | Sales trends by business unit were as follows: |

[0001437749-14-013652:8k_2_02:14]
|  | o | Electronics sales increased 20% year over year due to strong growth across all product lines and the addition of the Hamlin electronic sensor business. Excluding acquisitions, electronics sales increased 13% compared to the prior year. |

[0001437749-14-013652:8k_2_02:15]
-more-

[0001437749-14-013652:8k_2_02:16]
|  | o | Automotive sales increased 27% year over year reflecting continued strong growth for passenger car fuses and Accel sensors, solid performance for commercial vehicle products and the acquisition of Hamlin. Excluding acquisitions, automotive sales increased 15% compared to the prior year. |

[0001437749-14-013652:8k_2_02:17]
|  | o | Electrical sales declined 9% year over year due to the sharp decline in the mining market and a weak quarter for electrical fuses, partially offset by the acquisition of SymCom. Excluding acquisitions, electrical sales declined 26% compared to the prior year. |

[0001437749-14-013652:8k_2_02:18]
|  | ● | The electronics book-to-bill ratio for the second quarter of 2014 was 1.08. |

[0001437749-14-013652:8k_2_02:19]
|  | ● | Cash provided by operating activities was $31.0 million for the second quarter of 2014 compared to $23.0 million for the second quarter of 2013. Capital expenditures for the second quarter of 2014 were $6.7 million compared to $9.0 million for the second quarter of 2013. |

[0001437749-14-013652:8k_2_02:20]
|  | ● | The company repurchased 161,751 shares of its common stock in the second quarter of 2014 at an average price of $88.30. The company has 838,249 shares left on its current share repurchase authorization which is effective through April 30, 2015. |

[0001437749-14-013652:8k_2_02:21]
|  | ● | In the second quarter, the company restructured its labor contracts at the Hamlin-Mexico plant. This resulted in a one-time charge of $2.0 million for severance, as employees had to be terminated and re-hired under a new contract. This is expected to result in savings of approximately $1.5 million annually beginning in the third quarter. |

[0001437749-14-013652:8k_2_02:22]
“The positive top-line trends in our automotive and electronics businesses continued through the second quarter,” said Gordon Hunter, Chief Executive Officer. “On the other hand, the electrical segment had its challenges as weakness in the mining sector continues, and electrical fuse sales declined in the second quarter after six consecutive quarters of growth.”

[0001437749-14-013652:8k_2_02:23]
“Despite achieving our sales forecast for the second quarter, we did not see the expected margin improvement,” said Phil Franklin, Chief Financial Officer. “Improved electronics margins were offset by margin declines in automotive and electrical. However, several of the factors that depressed margins in the second quarter have either been corrected or are believed to be non-recurring, and therefore margins are expected to improve significantly in the third quarter.”

[0001437749-14-013652:8k_2_02:24]
Outlook

[0001437749-14-013652:8k_2_02:25]
|  | ● | Sales for the third quarter of 2014 are expected to be in the range of $215 to $225 million which represents 9% year-over-year growth at the midpoint. |

[0001437749-14-013652:8k_2_02:26]
|  | ● | Operating margin for the third quarter (excluding special items) is expected to improve by 150 to 200 basis points compared to the second quarter of 2014 due primarily to lower stock compensation expense and reduced scrap and obsolete inventory charges. |

[0001437749-14-013652:8k_2_02:27]
-more-

[0001437749-14-013652:8k_2_02:28]
|  | ● | Earnings for the third quarter of 2014 are expected to be in the range of $1.29 to $1.43 per diluted share. |

[0001437749-14-013652:8k_2_02:29]
|  | ● | Capital expenditures are expected to be approximately $35 million for the year. |

[0001437749-14-013652:8k_2_02:30]
Dividend

[0001437749-14-013652:8k_2_02:31]
The Board has approved a 14% increase in the quarterly cash dividend from $0.22 to $0.25. This dividend is payable on September 4, 2014 to shareholders of record at the close of business on August 21, 2014.

[0001437749-14-013652:8k_2_02:32]
“Since the dividend was initiated in 2010, we have increased it at a compound annual growth rate of 14%,” said Franklin.

[0001437749-14-013652:8k_2_02:33]
Conference Call and Webcast Information

[0001437749-14-013652:8k_2_02:34]
Littelfuse will host a conference call today, Wednesday, July 30, 2014, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the second quarter results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay through September 30, 2014 on the company’s website.

[0001437749-14-013652:8k_2_02:35]
About Littelfuse

[0001437749-14-013652:8k_2_02:36]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power

[0001437749-14-013652:8k_2_02:37]
control and sensing. The company serves customers in the electronics, automotive and industrial markets

[0001437749-14-013652:8k_2_02:38]
with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 7,500 employees in more than 35 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: littelfuse.com.

[0001437749-14-013652:8k_2_02:39]
| “Safe Harbor” Statement under the Private Securities Litigation Reform Act of 1995. The statements in this press release that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended December 28, 2013. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended December 28, 2013. |

[0001437749-14-013652:8k_2_02:40]
LFUS-F

[0001437749-14-013652:8k_2_02:41]
# # #

[0001437749-14-013652:8k_2_02:42]
LITTELFUSE, INC.

[0001437749-14-013652:8k_2_02:43]
Consolidated Statements of Comprehensive Income

[0001437749-14-013652:8k_2_02:44]
(In thousands of USD, except per share data, unaudited)

[0001437749-14-013652:8k_2_02:45]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics (2) |  | $ | 109,947 |  |  | $ | 91,450 |  |  |  | 20 | % |  | $ | 205,972 |  |  | $ | 170,865 |  |  |  | 21 | % |
| Automotive (3) |  |  | 82,042 |  |  |  | 64,548 |  |  |  | 27 | % |  |  | 164,444 |  |  |  | 123,933 |  |  |  | 33 | % |
| Electrical (4) |  |  | 28,919 |  |  |  | 31,768 |  |  |  | (9% | ) |  |  | 57,351 |  |  |  | 63,886 |  |  |  | (10% | ) |
| Total net sales (1) |  | $ | 220,908 |  |  | $ | 187,766 |  |  |  | 18 | % |  | $ | 427,767 |  |  | $ | 358,684 |  |  |  | 19 | % |

[0001437749-14-013652:8k_2_02:46]
(1) Total net sales for 2014 include $19.9M for the quarter and $46.3M year-to-date from business acquisitions.

[0001437749-14-013652:8k_2_02:47]
(2) Total Electronics net sales for 2014 include $6.9M for the quarter and $16.3M year-to-date from the Hamlin acquisition.

[0001437749-14-013652:8k_2_02:48]
(3) Total Automotive net sales for 2014 include $7.7M for the quarter and $20.2M year-to-date from the Hamlin acquisition.

[0001437749-14-013652:8k_2_02:49]
(4) Total Electrical net sales for 2014 include $5.3M for the quarter and $9.8M year-to-date from the SymCom acquisition.

[0001437749-14-013652:8k_2_02:50]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 25,634 |  |  | $ | 19,779 |  |  |  | 30 | % |  | $ | 45,005 |  |  | $ | 31,922 |  |  |  | 41 | % |
| Automotive |  |  | 11,049 |  |  |  | 8,913 |  |  |  | 24 | % |  |  | 22,931 |  |  |  | 18,396 |  |  |  | 25 | % |
| Electrical |  |  | 571 |  |  |  | 5,623 |  |  |  | (90% | ) |  |  | 4,317 |  |  |  | 12,114 |  |  |  | (64% | ) |
| Other (5) |  |  | (3,535 | ) |  |  | (2,933 | ) |  |  | 21 | % |  |  | (4,944 | ) |  |  | (2,933 | ) |  |  | 69 | % |
| Total operating income |  | $ | 33,719 |  |  | $ | 31,382 |  |  |  | 7 | % |  | $ | 67,309 |  |  | $ | 59,499 |  |  |  | 13 | % |
| Interest expense |  |  | 1,228 |  |  |  | 644 |  |  |  |  |  |  |  | 2,444 |  |  |  | 1,020 |  |  |  |  |  |
| Investment impairment (6) |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |  |  | 10,678 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | 2,375 |  |  |  | (3,724 | ) |  |  |  |  |  |  | 2,123 |  |  |  | (3,405 | ) |  |  |  |  |
| Other (income) expense, net |  |  | (1,446 | ) |  |  | (935 | ) |  |  |  |  |  |  | (2,632 | ) |  |  | (2,163 | ) |  |  |  |  |
| Income before taxes |  | $ | 31,562 |  |  | $ | 35,397 |  |  |  | (11% | ) |  | $ | 65,374 |  |  | $ | 53,369 |  |  |  | 22 | % |

[0001437749-14-013652:8k_2_02:51]
(5) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. For the second quarter of 2014, Other included a purchase accounting charge (ASC 805) related to the SymCom acquisition ($1.4M) and severance charges related to restructuring at the Hamlin - Mexico plant ($2.0M) all in Cost of sales and other acquisition costs ($0.2M) all in Selling, general and administrative.

[0001437749-14-013652:8k_2_02:52]
(6) Impairment and loan losses from investment in Shocking Technologies.

[0001437749-14-013652:8k_2_02:53]
-more-

[0001437749-14-013652:8k_2_02:54]
LITTELFUSE, INC.

[0001437749-14-013652:8k_2_02:55]
Supplemental Financial Information

[0001437749-14-013652:8k_2_02:56]
(in millions of USD except share amounts)

[0001437749-14-013652:8k_2_02:57]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-14 |  |  | Q2-14 |  |  | YTD-14 |  |  | Q1-13 |  |  | Q2-13 |  |  | YTD-13 |  |
| GAAP diluted EPS |  | $ | 1.12 |  |  | $ | 1.08 |  |  | $ | 2.20 |  |  | $ | 0.51 |  |  | $ | 1.18 |  |  | $ | 1.70 |  |
| EPS impact of special items (below) |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.22 |  |  |  | 0.44 |  |  |  | (0.03 | ) |  |  | 0.41 |  |
| Adjusted diluted EPS |  | $ | 1.16 |  |  | $ | 1.26 |  |  | $ | 2.42 |  |  | $ | 0.95 |  |  | $ | 1.15 |  |  | $ | 2.11 |  |
| Year-over-year adjusted EPS growth |  |  | 1 | % |  |  | 10 | % |  |  | 15 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-14-013652:8k_2_02:58]
| Special Items (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | 2.8 |  |  | $ | - |  |  | $ | 1.7 |  |  | $ | 1.7 |  |
| Restructuring |  |  | - |  |  |  | 2.0 |  |  |  | 2.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Acquisition expenses |  |  | - |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | - |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Adjustment to Operating income |  |  | 1.4 |  |  |  | 3.6 |  |  |  | 5.0 |  |  |  | - |  |  |  | 2.9 |  |  |  | 2.9 |  |
| Impairment charges |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10.7 |  |  |  | - |  |  |  | 10.7 |  |
| Foreign exchange (gain)/loss |  |  | (0.2 | ) |  |  | 2.4 |  |  |  | 2.2 |  |  |  | - |  |  |  | (3.7 | ) |  |  | (3.7 | ) |
| Adjustment to pre-tax income |  | $ | 1.2 |  |  | $ | 6.0 |  |  | $ | 7.2 |  |  | $ | 10.7 |  |  | $ | (0.8 | ) |  | $ | 9.9 |  |
| EPS impact of above special items |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.22 |  |  | $ | 0.29 |  |  | $ | (0.03 | ) |  | $ | 0.26 |  |
| EPS impact of Shocking tax adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.15 |  |  |  | - |  |  |  | 0.15 |  |
| Total EPS impact |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.22 |  |  | $ | 0.44 |  |  | $ | (0.03 | ) |  | $ | 0.41 |  |

[0001437749-14-013652:8k_2_02:59]
(1) Reflects $3.3 million of the Shocking tax adjustment recorded in Q1-13.

[0001437749-14-013652:8k_2_02:60]
| Operating margin reconciliation |  |  |  |  |  | Q2-14 |  |  | YTD-14 |  |  |  |  |  |  | Q2-13 |  |  | YTD-13 |  |
| Net sales |  |  |  |  |  | $ | 220.9 |  |  | $ | 427.8 |  |  |  |  |  |  | $ | 187.8 |  |  | $ | 358.7 |  |
| GAAP Operating income |  |  |  |  |  | $ | 33.7 |  |  | $ | 67.3 |  |  |  |  |  |  | $ | 31.3 |  |  | $ | 59.5 |  |
| Add back amortization |  |  |  |  |  |  | 3.1 |  |  |  | 6.3 |  |  |  |  |  |  |  | 1.9 |  |  |  | 3.5 |  |
| Add back special items |  |  |  |  |  |  | 3.6 |  |  |  | 5.0 |  |  |  |  |  |  |  | 2.9 |  |  |  | 2.9 |  |
| Operating income before amortization and special items |  |  |  |  |  | $ | 40.4 |  |  | $ | 78.6 |  |  |  |  |  |  | $ | 36.1 |  |  | $ | 65.9 |  |
| Operating margin before amortization and special items |  |  |  |  |  |  | 18.3 | % |  |  | 18.4 | % |  |  |  |  |  |  | 19.2 | % |  |  | 18.4 | % |

[0001437749-14-013652:8k_2_02:61]
-more-

[0001437749-14-013652:8k_2_02:62]
LITTELFUSE, INC.

[0001437749-14-013652:8k_2_02:63]
Condensed Consolidated Balance Sheets

[0001437749-14-013652:8k_2_02:64]
(In thousands of USD, except share amounts)

[0001437749-14-013652:8k_2_02:65]
|  |  | June 28, 2014 |  |  | December 28, 2013 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 346,406 |  |  | $ | 305,192 |  |
| Short-term investments |  |  | 6,849 |  |  |  | 6,886 |  |
| Accounts receivable, less allowances |  |  | 144,869 |  |  |  | 127,887 |  |
| Inventories |  |  | 96,674 |  |  |  | 92,591 |  |
| Deferred income taxes |  |  | 10,610 |  |  |  | 10,463 |  |
| Prepaid expenses and other current assets |  |  | 18,492 |  |  |  | 17,080 |  |
| Assets held for sale |  |  | 5,500 |  |  |  | 5,500 |  |
| Total current assets |  |  | 629,400 |  |  |  | 565,599 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 6,044 |  |  |  | 4,382 |  |
| Buildings |  |  | 71,154 |  |  |  | 59,699 |  |
| Equipment |  |  | 359,252 |  |  |  | 354,475 |  |
|  |  |  | 436,450 |  |  |  | 418,556 |  |
| Accumulated depreciation |  |  | (277,791 | ) |  |  | (268,383 | ) |
| Net property, plant and equipment |  |  | 158,659 |  |  |  | 150,173 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 25,638 |  |  |  | 25,166 |  |
| Distribution network |  |  | 40,992 |  |  |  | 42,685 |  |
| Customer lists, trademarks and tradenames |  |  | 44,750 |  |  |  | 30,506 |  |
| Goodwill |  |  | 201,769 |  |  |  | 186,464 |  |
|  |  |  | 313,149 |  |  |  | 284,821 |  |
| Investments |  |  | 15,787 |  |  |  | 12,286 |  |
| Deferred income taxes |  |  | 4,839 |  |  |  | 5,092 |  |
| Other assets |  |  | 7,065 |  |  |  | 6,402 |  |
| Total assets |  | $ | 1,128,899 |  |  | $ | 1,024,373 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 36,793 |  |  | $ | 33,872 |  |
| Accrued payroll |  |  | 22,149 |  |  |  | 29,437 |  |
| Accrued expenses |  |  | 13,972 |  |  |  | 13,087 |  |
| Accrued severance |  |  | 327 |  |  |  | 182 |  |
| Accrued income taxes |  |  | 6,422 |  |  |  | 5,931 |  |
| Deferred income taxes |  |  | 7 |  |  |  | 229 |  |
| Current portion of long-term debt |  |  | 204,000 |  |  |  | 126,000 |  |
| Total current liabilities |  |  | 283,670 |  |  |  | 208,738 |  |
| Long-term debt, less current portion |  |  | 91,250 |  |  |  | 93,750 |  |
| Deferred income taxes |  |  | 11,382 |  |  |  | 11,585 |  |
| Accrued post-retirement benefits |  |  | 182 |  |  |  | 8,528 |  |
| Other long-term liabilities |  |  | 14,922 |  |  |  | 14,856 |  |
| Total equity |  |  | 727,493 |  |  |  | 686,916 |  |
| Total liabilities and equity |  | $ | 1,128,899 |  |  | $ | 1,024,373 |  |

[0001437749-14-013652:8k_2_02:66]
Common shares issued and outstanding of 22,524,723 and 22,467,491 at June 28, 2014 and December 28, 2013, respectively.

[0001437749-14-013652:8k_2_02:67]
-more-

[0001437749-14-013652:8k_2_02:68]
LITTELFUSE, INC.

[0001437749-14-013652:8k_2_02:69]
Consolidated Statements of Comprehensive Income

[0001437749-14-013652:8k_2_02:70]
(In thousands of USD, except per share data, unaudited)

[0001437749-14-013652:8k_2_02:71]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| Net sales |  | $ | 220,908 |  |  | $ | 187,766 |  |  | $ | 427,767 |  |  | $ | 358,684 |  |
| Cost of sales |  |  | 137,913 |  |  |  | 114,209 |  |  |  | 266,278 |  |  |  | 220,521 |  |
| Gross profit |  |  | 82,995 |  |  |  | 73,557 |  |  |  | 161,489 |  |  |  | 138,163 |  |
| Selling, general and administrative |  |  | 38,328 |  |  |  | 34,452 |  |  |  | 72,499 |  |  |  | 63,654 |  |
| Research and development expenses |  |  | 7,810 |  |  |  | 5,793 |  |  |  | 15,384 |  |  |  | 11,508 |  |
| Amortization of intangibles |  |  | 3,138 |  |  |  | 1,930 |  |  |  | 6,297 |  |  |  | 3,502 |  |
|  |  |  | 49,276 |  |  |  | 42,175 |  |  |  | 94,180 |  |  |  | 78,664 |  |
| Operating income |  |  | 33,719 |  |  |  | 31,382 |  |  |  | 67,309 |  |  |  | 59,499 |  |
| Interest expense |  |  | 1,228 |  |  |  | 644 |  |  |  | 2,444 |  |  |  | 1,020 |  |
| Impairment and loan loss in unconsolidated affiliate |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10,678 |  |
| Foreign exchange loss (gain) |  |  | 2,375 |  |  |  | (3,724 | ) |  |  | 2,123 |  |  |  | (3,405 | ) |
| Other (income) expense, net |  |  | (1,446 | ) |  |  | (935 | ) |  |  | (2,632 | ) |  |  | (2,163 | ) |
| Income before income taxes |  |  | 31,562 |  |  |  | 35,397 |  |  |  | 65,374 |  |  |  | 53,369 |  |
| Income taxes |  |  | 6,984 |  |  |  | 8,749 |  |  |  | 15,407 |  |  |  | 15,233 |  |
| Net income |  | $ | 24,578 |  |  | $ | 26,648 |  |  | $ | 49,967 |  |  | $ | 38,136 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.09 |  |  | $ | 1.19 |  |  | $ | 2.22 |  |  | $ | 1.72 |  |
| Diluted |  | $ | 1.08 |  |  | $ | 1.18 |  |  | $ | 2.20 |  |  | $ | 1.70 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,579 |  |  |  | 22,296 |  |  |  | 22,536 |  |  |  | 22,197 |  |
| Diluted |  |  | 22,750 |  |  |  | 22,499 |  |  |  | 22,738 |  |  |  | 22,431 |  |
| Diluted Net Income Per Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 24,578 |  |  | $ | 26,648 |  |  | $ | 49,967 |  |  | $ | 38,136 |  |
| Less: income allocated to participating securities |  |  | - |  |  |  | (10 | ) |  |  | - |  |  |  | (32 | ) |
| Net income available to common shareholders |  | $ | 24,578 |  |  | $ | 26,638 |  |  | $ | 49,967 |  |  | $ | 38,104 |  |
| Weighted average shares adjusted for securities |  |  | 22,750 |  |  |  | 22,499 |  |  |  | 22,738 |  |  |  | 22,431 |  |
| Diluted net income per share |  | $ | 1.08 |  |  | $ | 1.18 |  |  | $ | 2.20 |  |  | $ | 1.70 |  |
| Comprehensive income |  | $ | 33,743 |  |  | $ | 17,956 |  |  | $ | 52,235 |  |  | $ | 28,924 |  |

[0001437749-14-013652:8k_2_02:72]
-more-

[0001437749-14-013652:8k_2_02:73]
LITTELFUSE, INC.

[0001437749-14-013652:8k_2_02:74]
Consolidated Statements of Cash Flows

[0001437749-14-013652:8k_2_02:75]
(In thousands of USD, unaudited)

[0001437749-14-013652:8k_2_02:76]
|  |  | For the Six Months Ended |  |
|  |  | June 28, 2014 |  |  | June 29, 2013 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 49,967 |  |  | $ | 38,136 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 14,459 |  |  |  | 12,748 |  |
| Amortization of intangibles |  |  | 6,297 |  |  |  | 3,502 |  |
| Impairment and loan loss in unconsolidated affiliate |  |  | - |  |  |  | 10,678 |  |
| Non-cash inventory charge (1) |  |  | 2,769 |  |  |  | 1,725 |  |
| Stock-based compensation |  |  | 5,229 |  |  |  | 4,562 |  |
| Excess tax benefit on stock-based compensation |  |  | (2,230 | ) |  |  | (3,494 | ) |
| Loss on sale of assets |  |  | 141 |  |  |  | 120 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (17,871 | ) |  |  | (20,246 | ) |
| Inventories |  |  | 410 |  |  |  | 3,354 |  |
| Accounts payable |  |  | 2,533 |  |  |  | 4,655 |  |
| Accrued expenses (including post retirement) |  |  | (7,578 | ) |  |  | (11,477 | ) |
| Accrued payroll and severance |  |  | (7,323 | ) |  |  | (1,725 | ) |
| Accrued taxes |  |  | (2,101 | ) |  |  | (4,257 | ) |
| Prepaid expenses and other |  |  | (2,189 | ) |  |  | 724 |  |
| Net cash provided by operating activities |  |  | 42,513 |  |  |  | 39,005 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (13,132 | ) |  |  | (14,445 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (52,768 | ) |  |  | (145,000 | ) |
| Purchase of short-term investments |  |  | - |  |  |  | (8,478 | ) |
| Proceeds from sale of assets |  |  | 37 |  |  |  | 56 |  |
| Net cash used in investing activities |  |  | (65,863 | ) |  |  | (167,867 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from term loan |  |  | - |  |  |  | 100,000 |  |
| Proceeds of revolving credit facility |  |  | 97,500 |  |  |  | 152,000 |  |
| Payments of term loan |  |  | (2,500 | ) |  |  | - |  |
| Payments of revolving credit facility |  |  | (19,500 | ) |  |  | (103,000 | ) |
| Debt issuance costs paid |  |  | (108 | ) |  |  | (808 | ) |
| Cash dividends paid |  |  | (9,921 | ) |  |  | (8,865 | ) |
| Purchase of common stock |  |  | (14,283 | ) |  |  | - |  |
| Proceeds from exercise of stock options |  |  | 11,101 |  |  |  | 15,401 |  |
| Excess tax benefit on stock-based compensation |  |  | 2,230 |  |  |  | 3,494 |  |
| Net cash provided by financing activities |  |  | 64,519 |  |  |  | 158,222 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 45 |  |  |  | (7,092 | ) |
| Increase in cash and cash equivalents |  |  | 41,214 |  |  |  | 22,268 |  |
| Cash and cash equivalents at beginning of period |  |  | 305,192 |  |  |  | 235,404 |  |
| Cash and cash equivalents at end of period |  | $ | 346,406 |  |  | $ | 257,672 |  |

[0001437749-14-013652:8k_2_02:77]
(1) Purchase accounting adjustment related to acquisitions.

[0001437749-14-013652:8k_2_02:78]
# # #
