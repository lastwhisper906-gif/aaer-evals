# LFUS MD&A — 0001437749-14-013895


## mdna

[0001437749-14-013895:mdna:1]
[same as prior period, unchanged from 0001437749-14-007780:mdna:1]

[0001437749-14-013895:mdna:2]
[same as prior period, unchanged from 0001437749-14-007780:mdna:2]

[0001437749-14-013895:mdna:3]
[same as prior period, unchanged from 0001437749-14-007780:mdna:3]

[0001437749-14-013895:mdna:4]
In addition to protecting and growing its core circuit protection business, Littelfuse has been investing in power control and sensing technologies. These newer platforms combined with the company’s strong balance sheet and operating cash flow, provide opportunities for increased organic and acquisition growth. The company has set a target to grow 15% per year, 5% organically and 10% through acquisitions.

[0001437749-14-013895:mdna:5]
[same as prior period, unchanged from 0001437749-14-007780:mdna:5]

[0001437749-14-013895:mdna:6]
[same as prior period, unchanged from 0001437749-14-007780:mdna:6]

[0001437749-14-013895:mdna:7]
[same as prior period, unchanged from 0001437749-14-007780:mdna:7]

[0001437749-14-013895:mdna:8]
[same as prior period, unchanged from 0001437749-14-007780:mdna:8]

[0001437749-14-013895:mdna:9]
[same as prior period, unchanged from 0001437749-14-007780:mdna:9]

[0001437749-14-013895:mdna:10]
[same as prior period, unchanged from 0001437749-14-007780:mdna:10]

[0001437749-14-013895:mdna:11]
[same as prior period, unchanged from 0001437749-14-007780:mdna:11]

[0001437749-14-013895:mdna:12]
[same as prior period, unchanged from 0001437749-14-007780:mdna:12]

[0001437749-14-013895:mdna:13]
The Electronics segment sells passive and semiconductor components and modules primarily into the global consumer electronics, general industrial and telecommunications markets. The core electronics markets are characterized by significant Asia competition and price erosion. As a result the company is focusing additional efforts on higher growth, less price sensitive niche markets and higher-power industrial applications. The Hamlin acquisition in 2013 expands the company’s product offering into reed switches which are used in a wide variety of electronic products and go through the same channels as the company’s core electronics products.

[0001437749-14-013895:mdna:14]
[same as prior period, unchanged from 0001437749-14-007780:mdna:14]

[0001437749-14-013895:mdna:15]
The Automotive segment is comprised of passenger vehicle circuit protection, commercial vehicle products and sensors. The primary growth drivers for these businesses are increasing global demand for passenger and commercial vehicles and increasing content per vehicle for both circuit protection and sensing products. The move away from internal combustion engines to hybrid and electric drive systems that require more circuit protection is expected to be an additional growth driver. The Hamlin acquisition in 2013 significantly expands the company’s position in automotive sensors.

[0001437749-14-013895:mdna:16]
[same as prior period, unchanged from 0001437749-14-007780:mdna:16]

[0001437749-14-013895:mdna:17]
[same as prior period, unchanged from 0001437749-14-007780:mdna:17]

[0001437749-14-013895:mdna:18]
[same as prior period, unchanged from 0001437749-14-007780:mdna:18]

[0001437749-14-013895:mdna:19]
[same as prior period, unchanged from 0001437749-14-007780:mdna:19]

[0001437749-14-013895:mdna:20]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 109,947 |  |  | $ | 91,450 |  |  |  | 20 | % |  | $ | 205,972 |  |  | $ | 170,865 |  |  |  | 21 | % |
| Automotive |  |  | 82,042 |  |  |  | 64,548 |  |  |  | 27 | % |  |  | 164,444 |  |  |  | 123,933 |  |  |  | 33 | % |
| Electrical |  |  | 28,919 |  |  |  | 31,768 |  |  |  | (9 | %) |  |  | 57,351 |  |  |  | 63,886 |  |  |  | (10 | %) |
| Total |  | $ | 220,908 |  |  | $ | 187,766 |  |  |  | 18 | % |  | $ | 427,767 |  |  | $ | 358,684 |  |  |  | 19 | % |

[0001437749-14-013895:mdna:21]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 95,874 |  |  | $ | 86,531 |  |  |  | 11 | % |  | $ | 185,025 |  |  | $ | 164,355 |  |  |  | 13 | % |
| Europe |  |  | 44,296 |  |  |  | 33,484 |  |  |  | 32 | % |  |  | 88,223 |  |  |  | 64,870 |  |  |  | 36 | % |
| Asia-Pacific |  |  | 80,738 |  |  |  | 67,751 |  |  |  | 19 | % |  |  | 154,519 |  |  |  | 129,459 |  |  |  | 19 | % |
| Total |  | $ | 220,908 |  |  | $ | 187,766 |  |  |  | 18 | % |  | $ | 427,767 |  |  | $ | 358,684 |  |  |  | 19 | % |

[0001437749-14-013895:mdna:22]
[same as prior period, unchanged from 0001437749-14-007780:mdna:22]

[0001437749-14-013895:mdna:23]
Results of Operations – Second Quarter, 2014 compared to 2013

[0001437749-14-013895:mdna:24]
The following table summarizes the company’s consolidated results of operations for the periods presented. The results include incremental activity from the company’s business acquisitions as described, where applicable, in the below analysis. There was an additional $1.4 million accounting adjustment (expense) during the second quarter of 2014 ($2.8 million year-to-date) for the write-off of stepped-up inventory valuation related to the SymCom acquisition as described in Note 2. The company also incurred $2.0 million of severance charges resulting from restructuring at the Hamlin-Mexico plant as well as $2.4 million ($2.1 million year-to-date) of foreign exchange losses during the second quarter of 2014 due primarily to balance sheet revaluation in the Philippines.

[0001437749-14-013895:mdna:25]
| (In thousands, unaudited) |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Sales |  | $ | 220,908 |  |  | $ | 187,766 |  |  |  | 18 | % |  | $ | 427,767 |  |  | $ | 358,684 |  |  |  | 19 | % |
| Gross Profit |  |  | 82,995 |  |  |  | 73,557 |  |  |  | 13 | % |  |  | 161,489 |  |  |  | 138,163 |  |  |  | 17 | % |
| Operating expense |  |  | 49,276 |  |  |  | 42,175 |  |  |  | 17 | % |  |  | 94,180 |  |  |  | 78,664 |  |  |  | 20 | % |
| Operating income |  |  | 33,719 |  |  |  | 31,382 |  |  |  | 7 | % |  |  | 67,309 |  |  |  | 59,499 |  |  |  | 13 | % |
| Other (income) expense, net |  |  | 929 |  |  |  | (4,659 | ) |  |  | (120 | %) |  |  | (509 | ) |  |  | (5,568 | ) |  |  | (91 | %) |
| Income before income taxes |  |  | 31,562 |  |  |  | 35,397 |  |  |  | (11 | %) |  |  | 65,374 |  |  |  | 53,369 |  |  |  | 22 | % |
| Net income |  | $ | 24,578 |  |  | $ | 26,648 |  |  |  | (8 | %) |  | $ | 49,967 |  |  | $ | 38,136 |  |  |  | 31 | % |

[0001437749-14-013895:mdna:26]
Net sales increased $33.1 million or 18% to $220.9 million in the second quarter of 2014 compared to $187.8 million in the second quarter of 2013 due primarily to an incremental $19.9 million from business acquisitions and strong organic growth in automotive and electronics, partially offset by lower electrical sales. The company also experienced $2.3 million in favorable foreign currency effects in the second quarter of 2014 as compared to the second quarter of 2013. Excluding incremental sales from acquisitions and currency effects, net sales increased $10.9 million or 6% year-over-year.

[0001437749-14-013895:mdna:27]
[same as prior period, unchanged from 0001437749-14-007780:mdna:39]

[0001437749-14-013895:mdna:28]
Electronics sales increased $18.5 million or 20% to $109.9 million in the second quarter of 2014 compared to $91.5 million in the second quarter of 2013 due primarily to strong growth for both semiconductor and passive components and an incremental $6.9 million from the addition of Hamlin. The electronics segment experienced $0.9 million in favorable currency effects in the second quarter of 2014 primarily from sales denominated in euro. Excluding the impact from incremental sales from acquisitions and currency effects, sales increased $10.7 million or 12% year-over-year.

[0001437749-14-013895:mdna:29]
Automotive sales increased $17.5 million or 27% to $82.0 million in the second quarter of 2014 compared to $64.5 million in the second quarter of 2013 due to strong organic growth for passenger car fuses, commercial vehicle products and Accel sensors and an incremental $7.7 million from the addition of Hamlin. The automotive segment experienced $1.6 million in favorable currency effects in the second quarter of 2014 primarily due to sales denominated in euros. Excluding incremental sales from acquisitions and currency effects, net sales increased $8.1 million or 13% year-over-year.

[0001437749-14-013895:mdna:30]
Electrical sales decreased $2.8 million or 9% to $28.9 million in the second quarter of 2014 compared to $31.8 million in the second quarter of 2013 primarily from declines in custom and relay sales into the mining market and power fuses into the industrial market. These declines more than offset incremental sales of $5.3 million from the SymCom acquisition. The electrical segment experienced $0.2 million in unfavorable currency effects in the second quarter of 2014 primarily from sales denominated in Canadian dollars. Excluding incremental sales from SymCom and currency effects, net sales decreased $8.0 million or 25% year-over-year.

[0001437749-14-013895:mdna:31]
On a geographic basis, sales in the Americas increased $9.3 million or 11% to $95.9 million in the second quarter of 2014 compared to $86.5 million in the second quarter of 2013 due to incremental sales of $11.9 million from business acquisitions offset by $0.3 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding incremental sales from acquisitions and currency effects, the Americas sales decreased $2.2 million or 3% due to the decline in electrical sales partially offset by increased automotive and electronics sales.

[0001437749-14-013895:mdna:32]
Europe sales increased $10.8 million or 32% to $44.3 million in the second quarter of 2014 compared to $33.5 million in the second quarter of 2013 mainly due to strong demand for automotive and electronic products, incremental sales of $3.7 million from Hamlin and $2.4 million in favorable currency effects. Excluding incremental sales from acquisitions and currency effects, Europe sales increased $4.7 million or 14% year-over-year primarily due to an increase in demand for automotive and electronics products.

[0001437749-14-013895:mdna:33]
Asia-Pacific sales increased $13.0 million or 19% to $80.7 million in the second quarter of 2014 compared to $67.8 million in the second quarter of 2013 primarily due to strong demand for electronics and electrical products and incremental sales from Hamlin of $4.3 million and $0.3 million in favorable currency effects primarily from sales denominated in Korean won. Excluding incremental sales from Hamlin and currency effects, net sales increased $8.3 million or 12% year-over-year.

[0001437749-14-013895:mdna:34]
Gross profit was $83.0 million or 38% of net sales for the second quarter of 2014 compared to $73.6 million or 39% of net sales in the same quarter last year. Gross profit for the second quarter of 2014 included a $1.4 million non-cash charge to cost of goods sold for inventory that was stepped up to fair value as a result of the SymCom acquisition and $2.0 million of severance charges resulting from restructuring at the Hamlin-Mexico plant. Gross profit for the second quarter of 2013 included a $1.7 million non-cash charge to cost of goods sold for inventory that was stepped-up to fair value as a result of the Hamlin acquisition. Excluding the impact of these charges, gross profit was 39% in the second quarter of 2014 as compared to 40% in the second quarter of 2013. The decline in gross margin is primarily attributable to lower sales in the Electrical market.

[0001437749-14-013895:mdna:35]
Total operating expense was $49.3 million or 22% of net sales for the second quarter of 2014 compared to $42.2 million or 22% of net sales for the same quarter in 2013. The increase in operating expenses primarily reflects incremental operating expenses of $3.1 million from business acquisitions and higher stock compensation expense.

[0001437749-14-013895:mdna:36]
Operating income for the second quarter of 2014 was approximately $33.7 million compared to operating income of $31.4 million for the same quarter in 2013 primarily due to higher sales partially offset by slightly higher operating expenses as described above.

[0001437749-14-013895:mdna:37]
Interest expense was $1.2 million in the second quarter of 2014 compared to $0.6 million in the second quarter of 2013.

[0001437749-14-013895:mdna:38]
Foreign exchange loss (gain), reflecting net gains and losses from balance sheet revaluation, was approximately $2.4 million of expense for the second quarter of 2014 and $3.7 million of income for the second quarter of 2013 and primarily reflects fluctuations in the Philippine peso against the U.S. dollar.

[0001437749-14-013895:mdna:39]
Other (income) expense, net, consisting of interest income, royalties and non-operating income and expense was approximately $1.5 million of income for the second quarter of 2014 compared to $0.9 million of income in the second quarter of 2013.

[0001437749-14-013895:mdna:40]
Income before income taxes was $31.6 million for the second quarter of 2014 compared to income before income taxes of $35.4 million for the second quarter of 2013. Income tax expense was $7.0 million with an effective tax rate of 22.1% for the second quarter of 2014 compared to income tax expense of $8.7 million with an effective tax rate of 24.7% in the second quarter of 2013. The effective tax rates for both the second quarter of 2014 and 2013 are lower than the U.S. statutory tax rate primarily due to income earned in countries with lower tax rates than the U.S.

[0001437749-14-013895:mdna:41]
Net income for the second quarter of 2014 was $24.6 million or $1.08 per diluted share compared to net income of $26.6 million or $1.18 per diluted share for the same quarter of 2013.

[0001437749-14-013895:mdna:42]
Results of Operations – Six Months, 2014 compared to 2013

[0001437749-14-013895:mdna:43]
Net sales increased $69.1 million or 19% to $427.8 million for the first six months of 2014 compared to $358.7 million in the first six months of 2013 due primarily to an incremental $46.3 million from business acquisitions. The company also experienced $3.6 million in favorable foreign currency effects in the first six months of 2014 as compared to 2013. The favorable foreign currency impact primarily resulted from sales denominated in euros. Excluding incremental sales from acquisitions and currency effects, net sales increased $19.1 million or 5% year-over-year.

[0001437749-14-013895:mdna:44]
Electronics sales increased $35.1 million or 21% to $206.0 million in the first six months of 2014 compared to $170.9 million in the first six months of 2013 due primarily to incremental sales of $16.3 million from the Hamlin acquisition. The electronics segment experienced $1.3 million in favorable currency effects in the first six months of 2014 primarily from sales denominated in euro. Excluding incremental sales from Hamlin and currency effects, net sales increased $17.6 million or 10% year-over-year.

[0001437749-14-013895:mdna:45]
Automotive sales increased $40.5 million or 33% to $164.4 million in the first six months of 2014 compared to $123.9 million in the first six months of 2013 due primarily to incremental sales of $20.2 million from Hamlin and strong growth in the passenger vehicle business. The automotive segment experienced $2.8 million in favorable currency effects in the first six months of 2014 primarily due to sales denominated in euros. Excluding incremental sales from acquisitions and currency effects, net sales increased $17.4 million or 14% year-over-year.

[0001437749-14-013895:mdna:46]
Electrical sales decreased $6.5 million or 10% to $57.4 million in the first six months of 2014 compared to $63.9 million in the first six months of 2013 due primarily to slowing demand for custom and relay products as a result of a slow-down in the mining industry. This more than offset incremental sales of $9.8 million from the SymCom acquisition. The electrical segment experienced $0.5 million in unfavorable currency effects in the first six months of 2014 primarily from sales denominated in Canadian dollars. Excluding incremental sales from SymCom and currency effects, net sales decreased $15.8 million or 25% year-over-year.

[0001437749-14-013895:mdna:47]
On a geographic basis, sales in the Americas increased $20.7 million or 13% to $185.0 million in the first six months of 2014 compared to $164.4 million in the first six months of 2013 due to incremental sales from business acquisitions of $26.5 million and increased sales of power fuses, offset by weaker custom and relay sales and $0.8 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding incremental sales from acquisitions and currency effects, net sales decreased $5.1 million or 3% year-over-year.

[0001437749-14-013895:mdna:48]
Europe sales increased $23.4 million or 36% to $88.2 million in the first six months of 2014 compared to $64.9 million in the first six months of 2013 mainly due to strong demand for both automotive and electronics products, incremental sales of $9.4 million from Hamlin and $4.1 million in favorable currency effects. Excluding incremental sales from acquisitions and currency effects, Europe sales increased 15% year-over-year.

[0001437749-14-013895:mdna:49]
17

[0001437749-14-013895:mdna:50]
Asia-Pacific sales increased $25.1 million or 19% to $154.5 million in the first six months of 2014 compared to $129.5 million in the first six months of 2013 primarily due to higher demand for automotive and electronics products, incremental sales from Hamlin of $10.4 million and $0.3 million in favorable currency effects primarily from sales denominated in Korean won. Excluding incremental sales from Hamlin and currency effects, net sales increased $14.3 million or 11% year-over-year.

[0001437749-14-013895:mdna:51]
Gross profit was $161.5 million or 38% of net sales for the first six months of 2014 compared to $138.2 million or 39% of net sales in the first six months of 2013. Gross profit for the first six months of 2014 included a $2.8 million non-cash charge to cost of goods sold for inventory that was stepped up to fair value as a result of the SymCom acquisition and $2.0 million of severance charges resulting from restructuring at the Hamlin-Mexico plant. Gross profit for the first six months of 2013 included a $1.7 million non-cash charge to cost of goods sold for inventory that was stepped-up to fair value as a result of the Hamlin acquisition. Excluding the impact of these charges, gross profit was 39% for both the first six months of 2014 and 2013.

[0001437749-14-013895:mdna:52]
Total operating expense was $94.2 million or 22% of net sales for the first six months of 2014 compared to $78.7 million or 22% of net sales for the first six months in 2013. The increase in operating expenses primarily reflects incremental operating expenses of $9.7 million from business acquisitions and higher stock compensation expense.

[0001437749-14-013895:mdna:53]
Operating income for the first six months of 2014 was $67.3 million compared to operating income of $59.5 million for the first six months in 2013 primarily due to higher sales partially offset by slightly higher operating expenses as described above.

[0001437749-14-013895:mdna:54]
Interest expense was $2.4 million for the first six months of 2014 and $1.0 million the first six months of 2013.

[0001437749-14-013895:mdna:55]
Foreign exchange loss (gain), reflecting balance sheet revaluation, was approximately $2.1 million of expense for the first six months of 2014 and $3.4 million of income for the first six months of 2013 and primarily reflects fluctuations in the Philippine peso against the U.S. dollar.

[0001437749-14-013895:mdna:56]
Other (income) expense, net, consisting of interest income, royalties and non-operating income and expense was approximately $2.6 million of income for the first six months of 2014 compared to $2.2 million of income in the first six months of 2013.

[0001437749-14-013895:mdna:57]
Income before income taxes was $65.4 million for the first six months of 2014 compared to income before income taxes of $53.4 million for the first six months of 2013. Income tax expense was $15.4 million with an effective tax rate of 23.6% for the first six months of 2014 compared to income tax expense of $15.2 million with an effective tax rate of 28.5% in the first six months of 2013. The effective tax rates for both the first six months of 2014 and 2013 are lower than the U.S. statutory tax rate primarily due to income earned in countries with lower tax rates than the U.S.

[0001437749-14-013895:mdna:58]
Net income for the first six months of 2014 was $50.0 million or $2.20 per diluted share compared to net income of $38.1 million or $1.70 per diluted share for the same six months of 2013.

[0001437749-14-013895:mdna:59]
[same as prior period, unchanged from 0001437749-14-007780:mdna:43]

[0001437749-14-013895:mdna:60]
As of June 28, 2014, $332.0 million of the $346.4 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $332.0 million held by foreign subsidiaries, approximately $16.1 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $16.1 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-14-013895:mdna:61]
[same as prior period, unchanged from 0001437749-14-007780:mdna:45]

[0001437749-14-013895:mdna:62]
18

[0001437749-14-013895:mdna:63]
[same as prior period, unchanged from 0001437749-14-007780:mdna:46]

[0001437749-14-013895:mdna:64]
On May 31, 2013, the company entered into a new credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consisted of a revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. At June 28, 2014, the company had available $75.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.250% (1.4% as of June 28, 2014). The credit agreement replaces the company’s previous credit agreement dated June 13, 2011 which was terminated on May 31, 2013.

[0001437749-14-013895:mdna:65]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 28, 2014, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-14-013895:mdna:66]
The company also had $0.8 million outstanding in letters of credit at June 28, 2014. No amounts were drawn under these letters of credit at June 28, 2014.

[0001437749-14-013895:mdna:67]
[same as prior period, unchanged from 0001437749-14-007780:mdna:50]

[0001437749-14-013895:mdna:68]
The company started 2014 with $305.2 million of cash and cash equivalents. Net cash provided by operating activities was approximately $42.5 million for the first six months of 2014 reflecting $50.0 million in net income and $26.7 million in non-cash adjustments (primarily $20.8 million in depreciation and amortization) offset by $34.2 million in net changes to various operating assets and liabilities.

[0001437749-14-013895:mdna:69]
Changes in operating assets and liabilities for the first six months of 2014 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivables ($17.9 million), prepaid and other assets ($2.2 million) and decreases in accrued payroll and severance ($7.3 million), accrued expenses (including post-retirement) ($7.6 million) and accrued and deferred taxes ($2.1 million). The increase in accounts receivables was due to increased sales in the first six months. The decrease in accrued payroll and severance was due primarily to payouts for the 2013 management incentive plan which occurred in the first quarter. The decrease in accrued expenses was due primarily to $9.9 million in pension contributions made during the first quarter. Other changes having a positive impact on cash flows were increases in accounts payable ($2.5 million) and accrued and inventories ($0.4 million).

[0001437749-14-013895:mdna:70]
Net cash used in investing activities was approximately $65.9 million and included $13.1 million in capital spending and $52.8 million for the acquisition of SymCom.

[0001437749-14-013895:mdna:71]
Net cash provided by financing activities was approximately $64.5 million and included $75.5 million in net proceeds from borrowing and $13.3 million from the exercise of stock options, including tax benefits, partially offset by debt issuance costs of $0.1 million, cash dividends paid of $9.9 million and the repurchase of common stock for $14.3 million. The effects of exchange rate changes increased cash and cash equivalents by less than $0.1 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $41.2 million increase in cash, which left the company with a cash and cash equivalents balance of $346.4 million at June 28, 2014.

[0001437749-14-013895:mdna:72]
The ratio of current assets to current liabilities was 2.2 at the end of the second quarter of 2014 compared to 2.7 at year-end 2013 and 2.4 at the end of the second quarter of 2013. Days sales outstanding in accounts receivable was approximately 60 days at the end of the second quarter of 2014 compared to 64 days at the end of the second quarter of 2013 and 59 days at year-end 2013. Days inventory outstanding was approximately 64 days at the end of the second quarter of 2014 compared to 67 days at end of the second quarter of 2013 and 70 days at the year-end 2013.

[0001437749-14-013895:mdna:73]
19

[0001437749-14-013895:mdna:74]
[same as prior period, unchanged from 0001437749-14-007780:mdna:56]

[0001437749-14-013895:mdna:75]
Sales for the third quarter are expected to be similar to sales for the second quarter of 2014. The electrical segment is expected to remain weak at least through the remainder of this year due primarily to continued softness in the mining market. The company issued the following guidance for the third quarter of 2014:

[0001437749-14-013895:mdna:76]
|  | ● | Sales for the third quarter are expected to be in the range of $215.0 million to $225.0 million which represents 9% year-over-year growth at the midpoint. |

[0001437749-14-013895:mdna:77]
|  | ● | Earnings for the third quarter are expected to be in the range of $1.29 to $1.43 per diluted share, excluding any special items. |

[0001437749-14-013895:mdna:78]
|  | ● | Capital expenditures are expected to be approximately $35.0 million for the year. |

[0001437749-14-013895:mdna:79]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-14-013895:mdna:80]
[same as prior period, unchanged from 0001437749-14-007780:mdna:61]
