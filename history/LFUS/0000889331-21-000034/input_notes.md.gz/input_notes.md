# LFUS notes — 0000889331-21-000034


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-21-000034:notes:1]
[same as prior period, unchanged from 0000889331-20-000054:notes:1]

[0000889331-21-000034:notes:2]
[same as prior period, unchanged from 0000889331-20-000054:notes:2]

[0000889331-21-000034:notes:3]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 12,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-21-000034:notes:4]
[same as prior period, unchanged from 0000889331-20-000054:notes:4]

[0000889331-21-000034:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 26, 2020 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-21-000034:notes:6]
[same as prior period, unchanged from 0000889331-20-000054:notes:6]

[0000889331-21-000034:notes:7]
[same as prior period, unchanged from 0000889331-20-000054:notes:7]

[0000889331-21-000034:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 27, 2021 and March 28, 2020:

[0000889331-21-000034:notes:9]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

[0000889331-21-000034:notes:10]
|  |  | Three Months Ended March 28, 2020 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |  |  |  |  |  |  |  |  |

[0000889331-21-000034:notes:11]
See Note 15, Segment Information for net sales by segment and countries.

[0000889331-21-000034:notes:12]
[same as prior period, unchanged from 0000889331-20-000054:notes:12]

[0000889331-21-000034:notes:13]
[same as prior period, unchanged from 0000889331-20-000054:notes:13]

[0000889331-21-000034:notes:14]
[same as prior period, unchanged from 0000889331-20-000054:notes:14]

[0000889331-21-000034:notes:15]
[same as prior period, unchanged from 0000889331-20-000054:notes:15]

[0000889331-21-000034:notes:16]
[same as prior period, unchanged from 0000889331-20-000054:notes:16]

[0000889331-21-000034:notes:17]
[same as prior period, unchanged from 0000889331-20-000054:notes:17]

[0000889331-21-000034:notes:18]
[same as prior period, unchanged from 0000889331-20-000054:notes:18]

[0000889331-21-000034:notes:19]
[same as prior period, unchanged from 0000889331-20-000054:notes:19]

[0000889331-21-000034:notes:20]
[same as prior period, unchanged from 0000889331-20-000054:notes:20]

[0000889331-21-000034:notes:21]
[same as prior period, unchanged from 0000889331-20-000054:notes:21]

[0000889331-21-000034:notes:22]
Cash, Cash Equivalents and Restricted Cash

[0000889331-21-000034:notes:23]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at March 27, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-21-000034:notes:24]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 572,771 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,462 |  |  | — |  |
| Restricted cash included in other assets |  | 1,064 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 577,297 |  |  | $ | 687,525 |  |

[0000889331-21-000034:notes:25]
Recently Adopted Accounting Standards

[0000889331-21-000034:notes:26]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-21-000034:notes:27]
Acquisitions

[0000889331-21-000034:notes:28]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0000889331-21-000034:notes:29]
Hartland Controls

[0000889331-21-000034:notes:30]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The purchase price for Hartland was approximately $112.3 million and the operations of Hartland are included in the Industrial segment.

[0000889331-21-000034:notes:31]
The total purchase consideration of $109.9 million, net of cash, cash equivalents, and restricted cash has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase consideration is subject to change for the final working capital adjustments. As of March 27, 2021, the Company had restricted cash of $1.7 million in an escrow account for general indemnification purposes. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary areas that are not yet finalized relate to the completion of the valuations of certain acquired income tax assets and liabilities. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-21-000034:notes:32]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the Hartland acquisition:

[0000889331-21-000034:notes:33]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired, and restricted cash | $ | 109,852 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 14,305 |  |
| Inventories | 36,306 |  |
| Other current assets | 2,384 |  |
| Property, plant, and equipment | 6,296 |  |
| Intangible assets | 39,660 |  |
| Goodwill | 38,929 |  |
| Other non-current assets | 3,542 |  |
| Current liabilities | (25,024) |  |
| Other non-current liabilities | (6,546) |  |
|  | $ | 109,852 |  |

[0000889331-21-000034:notes:34]
All Hartland goodwill, other assets and liabilities were recorded in the Industrial segment and are primarily reflected in the Americas and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Hartland’s products and technology with the Company’s existing industrial products portfolio. Goodwill resulting from the Hartland acquisition is not expected to be deductible for tax purposes.

[0000889331-21-000034:notes:35]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three months ended March 27, 2021 are net sales of approximately $16.7 million, and a loss before income taxes of $2.2 million, since the January 28, 2021 acquisition of Hartland.

[0000889331-21-000034:notes:36]
The Company recorded a $6.8 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up is being amortized as a non-cash charge to cost of goods sold during the first and second quarters of 2021, as the acquired inventory is sold, and reflected as other non-segment costs. During the three months ended March 27, 2021, the Company recognized a charge of $3.5 million for the amortization of this fair value inventory step-up.

[0000889331-21-000034:notes:37]
During the three months ended March 27, 2021, the Company incurred approximately $0.7 million of legal and professional fees related to this acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-21-000034:notes:38]
Pro Forma Results

[0000889331-21-000034:notes:39]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and Hartland as though the acquisition had occurred as of December 29, 2019. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Hartland acquisition occurred as of December 29, 2019 or of future consolidated operating results.

[0000889331-21-000034:notes:40]
|  |  | For the Three Months Ended |
| (in thousands, except per share amounts) |  | March 27,2021 |  | March 28, 2020 |
| Net sales |  | $ | 470,832 |  |  | $ | 363,617 |  |
| Income before income taxes |  | 77,288 |  |  | 31,431 |  |
| Net income |  | 61,317 |  |  | 21,438 |  |
| Net income per share — basic |  | 2.50 |  |  | 0.88 |  |
| Net income per share — diluted |  | 2.46 |  |  | 0.87 |  |

[0000889331-21-000034:notes:41]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-21-000034:notes:42]
|  |  | For the Three Months Ended |
| (in thousands) |  | March 27,2021 |  | March 28, 2020 |
| Amortization(a) |  | $ | (279) |  |  | $ | (834) |  |
| Depreciation |  | 7 |  |  | 48 |  |
| Transaction costs(b) |  | 707 |  |  | (707) |  |
| Amortization of inventory step-up(c) |  | 3,490 |  |  | (5,137) |  |
| Income tax (expense) benefit of above items |  | (831) |  |  | 1,398 |  |

[0000889331-21-000034:notes:43]
(a)The amortization adjustment for the three months ended March 28, 2020 primarily reflects incremental amortization resulting for the measurement of intangibles at their fair values.

[0000889331-21-000034:notes:44]
(b)The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the three months ended March 27, 2021 and recognition of those fees during the three months ended March 28, 2020.

[0000889331-21-000034:notes:45]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the three months ended March 27, 2021 and the recognition of a full quarter of the amortization during the three months ended March 28, 2020. The inventory step-up was amortized over four months as the inventory was sold.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-21-000034:notes:46]
[same as prior period, unchanged from 0000889331-20-000054:notes:27]

[0000889331-21-000034:notes:47]
The components of inventories at March 27, 2021 and December 26, 2020 are as follows:

[0000889331-21-000034:notes:48]
| (in thousands) |  | March 27, 2021 |  | December 26, 2020 |
| Raw materials |  | $ | 97,695 |  |  | $ | 85,394 |  |
| Work in process |  | 102,285 |  |  | 92,783 |  |
| Finished goods |  | 130,138 |  |  | 114,641 |  |
| Inventory Reserves |  | (35,061) |  |  | (34,816) |  |
| Total |  | $ | 295,057 |  |  | $ | 258,002 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-21-000034:notes:49]
[same as prior period, unchanged from 0000889331-20-000054:notes:30]

[0000889331-21-000034:notes:50]
The components of net property, plant, and equipment at March 27, 2021 and December 26, 2020 are as follows:

[0000889331-21-000034:notes:51]
| (in thousands) |  | March 27, 2021 |  | December 26, 2020 |
| Land |  | $ | 22,711 |  |  | $ | 22,851 |  |
| Building |  | 124,192 |  |  | 123,497 |  |
| Equipment |  | 687,563 |  |  | 678,220 |  |
| Accumulated depreciation and amortization |  | (489,552) |  |  | (480,390) |  |
| Total |  | $ | 344,914 |  |  | $ | 344,178 |  |

[0000889331-21-000034:notes:52]
The Company recorded depreciation expense of $13.7 million and $13.8 million for the three months ended March 27, 2021 and March 28, 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-21-000034:notes:53]
[same as prior period, unchanged from 0000889331-20-000054:notes:34]

[0000889331-21-000034:notes:54]
The amounts for goodwill and changes in the carrying value by segment for the three months ended March 27, 2021 are as follows:

[0000889331-21-000034:notes:55]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net book value of goodwill as of December 26, 2020 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 26, 2020 |  | $ | 676,325 |  |  | $ | 138,354 |  |  | $ | 47,551 |  |  | $ | 862,230 |  |
| Accumulated impairment losses as of December 26, 2020 |  | — |  |  | (36,423) |  |  | (8,995) |  |  | (45,418) |  |
| Total |  | 676,325 |  |  | 101,931 |  |  | 38,556 |  |  | 816,812 |  |
| Changes during 2021: |  |  |  |  |  |  |  |  |
| Additions(a) |  | — |  |  | — |  |  | 38,929 |  |  | 38,929 |  |
| Currency translation |  | (8,124) |  |  | (2,012) |  |  | (19) |  |  | (10,155) |  |
| Net book value of goodwill as of March 27, 2021 |  |  |  |  |  |  |  |  |
| Gross goodwill as of March 27, 2021 |  | 668,201 |  |  | 136,229 |  |  | 86,461 |  |  | 890,891 |  |
| Accumulated impairment losses as of March 27, 2021 |  | — |  |  | (36,310) |  |  | (8,995) |  |  | (45,305) |  |
| Total |  | $ | 668,201 |  |  | $ | 99,919 |  |  | $ | 77,466 |  |  | $ | 845,586 |  |

[0000889331-21-000034:notes:56]
(a) The additions resulted from the acquisition of Hartland.

[0000889331-21-000034:notes:57]
The components of other intangible assets as of March 27, 2021 and December 26, 2020 are as follows:

[0000889331-21-000034:notes:58]
|  |  |  | As of March 27, 2021 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 10,251 |  |  | $ | 2,051 |  |  | $ | 8,200 |  |
| Patents, licenses and software |  |  | 142,732 |  |  | 94,636 |  |  | 48,096 |  |
| Distribution network |  |  | 43,704 |  |  | 39,307 |  |  | 4,397 |  |
| Customer relationships, trademarks, and tradenames |  |  | 400,253 |  |  | 143,652 |  |  | 256,601 |  |
| Total |  |  | $ | 596,940 |  |  | $ | 279,646 |  |  | $ | 317,294 |  |

[0000889331-21-000034:notes:59]
|  | As of December 26, 2020 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 10,280 |  |  | $ | 2,007 |  |  | $ | 8,273 |  |
| Patents, licenses and software | 137,210 |  |  | 92,868 |  |  | 44,342 |  |
| Distribution network | 43,910 |  |  | 38,980 |  |  | 4,930 |  |
| Customer relationships, trademarks, and tradenames | 372,064 |  |  | 137,722 |  |  | 234,342 |  |
| Total | $ | 563,464 |  |  | $ | 271,577 |  |  | $ | 291,887 |  |

[0000889331-21-000034:notes:60]
During the three months ended March 27, 2021 and March 28, 2020, the Company recorded amortization expense of $10.5 million and $10.0 million, respectively.

[0000889331-21-000034:notes:61]
[same as prior period, unchanged from 0000889331-20-000054:notes:42]

[0000889331-21-000034:notes:62]
During the three months ended March 27, 2021, the Company recorded additions to intangible assets of $39.7 million, related to the Hartland acquisition, the components of which were as follows:

[0000889331-21-000034:notes:63]
| (in thousands) | Weighted Average Useful Life |  | Amount |
| Patents, licenses and software | 9.2 |  | $ | 7,559 |  |
| Customer relationships, trademarks, and tradenames | 13.7 |  | 32,101 |  |
| Total |  |  | $ | 39,660 |  |

[0000889331-21-000034:notes:64]
Estimated annual amortization expense related to intangible assets with definite lives as of March 27, 2021 is as follows:

[0000889331-21-000034:notes:65]
| (in thousands) | Amount |
| 2021 | $ | 41,545 |  |
| 2022 | 40,791 |  |
| 2023 | 36,491 |  |
| 2024 | 33,054 |  |
| 2025 | 32,603 |  |
| 2026 and thereafter | 143,331 |  |
| Total | $ | 327,815 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-21-000034:notes:66]
[same as prior period, unchanged from 0000889331-20-000054:notes:45]

[0000889331-21-000034:notes:67]
The components of accrued liabilities as of March 27, 2021 and December 26, 2020 are as follows:

[0000889331-21-000034:notes:68]
| (in thousands) |  | March 27, 2021 |  | December 26, 2020 |
| Employee-related liabilities |  | $ | 45,135 |  |  | $ | 50,689 |  |
| Operating lease liability |  | 7,177 |  |  | 6,811 |  |
| Interest |  | 2,636 |  |  | 4,517 |  |
| Restructuring liability |  | 2,588 |  |  | 4,195 |  |
| Customer liability |  | 794 |  |  | 3,858 |  |
| Professional services |  | 3,010 |  |  | 3,321 |  |
| Deferred revenue |  | 2,713 |  |  | 2,959 |  |
| Other non-income taxes |  | 1,903 |  |  | 2,126 |  |
| Other |  | 32,398 |  |  | 32,002 |  |
| Total |  | $ | 98,354 |  |  | $ | 110,478 |  |

[0000889331-21-000034:notes:69]
[same as prior period, unchanged from 0000889331-20-000054:notes:48]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-21-000034:notes:70]
Restructuring, Impairment and Other Charges
The Company recorded restructuring, impairment and other charges for the three months ended March 27, 2021 and March 28, 2020 as follows:

[0000889331-21-000034:notes:71]
|  | Three months ended March 27, 2021 |  |  |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 257 |  |  | $ | — |  |  | $ | 163 |  |  | $ | 420 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | — |  |  | 17 |  |  | — |  |  | 17 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 257 |  |  | 17 |  |  | 163 |  |  | 437 |  |  |  |  |  |  |  |  |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 257 |  |  | $ | 17 |  |  | $ | 163 |  |  | $ | 437 |  |  |  |  |  |  |  |  |  |

[0000889331-21-000034:notes:72]
|  | Three months ended March 28, 2020 |  |  |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 881 |  |  | $ | 399 |  |  | $ | 321 |  |  | $ | 1,601 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 1 |  |  | 120 |  |  | 3 |  |  | 124 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 882 |  |  | 519 |  |  | 324 |  |  | 1,725 |  |  |  |  |  |  |  |  |  |
| Impairment | — |  |  | — |  |  | 2,237 |  |  | 2,237 |  |  |  |  |  |  |  |  |  |
| Total | $ | 882 |  |  | $ | 519 |  |  | $ | 2,561 |  |  | $ | 3,962 |  |  |  |  |  |  |  |  |  |

[0000889331-21-000034:notes:73]
2021

[0000889331-21-000034:notes:74]
For the three months ended March 27, 2021, the Company recorded total restructuring charges of $0.4 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Electronics and Industrial segments.

[0000889331-21-000034:notes:75]
[same as prior period, unchanged from 0000889331-20-000054:notes:52]

[0000889331-21-000034:notes:76]
For the three months ended March 28, 2020, the Company recorded total restructuring charges of $1.7 million, for employee termination costs and other restructuring charges. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $2.2 million of impairment charges related to the land and building associated with the Company’s announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-21-000034:notes:77]
The restructuring liability as of March 27, 2021 and December 26, 2020 is $2.6 million and $4.2 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by the first quarter of 2022.


## us-gaap:DebtDisclosureTextBlock

[0000889331-21-000034:notes:78]
Debt

[0000889331-21-000034:notes:79]
The carrying amounts of debt at March 27, 2021 and December 26, 2020 are as follows:

[0000889331-21-000034:notes:80]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 138,039 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,876) |  |  | (4,114) |  |
| Total debt |  | 648,865 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 623,865 |  |  | $ | 687,034 |  |

[0000889331-21-000034:notes:81]
Revolving Credit Facility

[0000889331-21-000034:notes:82]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the three months ended March 27, 2021. The balance under the facility was $100.0 million as of March 27, 2021.

[0000889331-21-000034:notes:83]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.61% at March 27, 2021.

[0000889331-21-000034:notes:84]
As of March 27, 2021, the Company had no amount outstanding in letters of credit and had available $571.3 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 27, 2021, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-21-000034:notes:85]
Senior Notes

[0000889331-21-000034:notes:86]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-21-000034:notes:87]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”)

[0000889331-21-000034:notes:88]
(together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000034:notes:89]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-21-000034:notes:90]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-21-000034:notes:91]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 27, 2021, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-21-000034:notes:92]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-21-000034:notes:93]
Interest paid on all Company debt was $6.2 million and $7.4 million for the three months ended March 27, 2021 and March 28, 2020, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-21-000034:notes:94]
[same as prior period, unchanged from 0000889331-20-000054:notes:76]

[0000889331-21-000034:notes:95]
[same as prior period, unchanged from 0000889331-20-000054:notes:77]

[0000889331-21-000034:notes:96]
[same as prior period, unchanged from 0000889331-20-000054:notes:78]

[0000889331-21-000034:notes:97]
[same as prior period, unchanged from 0000889331-20-000054:notes:79]

[0000889331-21-000034:notes:98]
[same as prior period, unchanged from 0000889331-20-000054:notes:80]

[0000889331-21-000034:notes:99]
[same as prior period, unchanged from 0000889331-20-000054:notes:81]

[0000889331-21-000034:notes:100]
[same as prior period, unchanged from 0000889331-20-000054:notes:82]

[0000889331-21-000034:notes:101]
[same as prior period, unchanged from 0000889331-20-000054:notes:83]

[0000889331-21-000034:notes:102]
[same as prior period, unchanged from 0000889331-20-000054:notes:84]

[0000889331-21-000034:notes:103]
[same as prior period, unchanged from 0000889331-20-000054:notes:85]

[0000889331-21-000034:notes:104]
Other Investments

[0000889331-21-000034:notes:105]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. As of March 27, 2021 and December 26, 2020, the balances of these investments were both $0.5 million. The fair value of these investments are measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-21-000034:notes:106]
[same as prior period, unchanged from 0000889331-20-000054:notes:87]

[0000889331-21-000034:notes:107]
[same as prior period, unchanged from 0000889331-20-000054:notes:88]

[0000889331-21-000034:notes:108]
There were no changes during the quarter ended March 27, 2021 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of March 27, 2021 and December 26, 2020, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-21-000034:notes:109]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of March 27, 2021:

[0000889331-21-000034:notes:110]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 66,565 |  |  | $ | — |  |  | $ | — |  |  | $ | 66,565 |  |
| Investments in equity securities |  | 25,830 |  |  | — |  |  | — |  |  | 25,830 |  |
| Mutual funds |  | 13,397 |  |  | — |  |  | — |  |  | 13,397 |  |
| Total |  | $ | 105,792 |  |  | $ | — |  |  | $ | — |  |  | $ | 105,792 |  |

[0000889331-21-000034:notes:111]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 26, 2020:

[0000889331-21-000034:notes:112]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 73,461 |  |  | $ | — |  |  | $ | — |  |  | $ | 73,461 |  |
| Investments in equity securities |  | 19,186 |  |  | — |  |  | — |  |  | 19,186 |  |
| Mutual funds |  | 13,249 |  |  | — |  |  | — |  |  | 13,249 |  |
| Total |  | $ | 105,896 |  |  | $ | — |  |  | $ | — |  |  | $ | 105,896 |  |

[0000889331-21-000034:notes:113]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving credit facilities’ fair values approximate book value at March 27, 2021 and December 26, 2020, as the rates on these borrowings are variable in nature.

[0000889331-21-000034:notes:114]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of March 27, 2021 and December 26, 2020 were as follows:

[0000889331-21-000034:notes:115]
|  |  | March 27, 2021 |  | December 26, 2020 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 138,039 |  |  | $ | 140,084 |  |  | $ | 142,679 |  |  | $ | 144,323 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 117,703 |  |  | 115,850 |  |  | 123,588 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,375 |  |  | 25,000 |  |  | 25,437 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 106,174 |  |  | 100,000 |  |  | 109,552 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 52,817 |  |  | 50,000 |  |  | 53,474 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 130,764 |  |  | 125,000 |  |  | 138,036 |  |

[0000889331-21-000034:notes:116]
The Company recognized impairment charges of $1.9 million for the land and building and $0.3 million for a certain patent as a result of the Company’s announcement to consolidate a manufacturing facility within the Industrial segment during the first quarter of 2020. See Note 7, Restructuring, Impairment and Other Charges, for further discussion. The fair value of the land and building was valued using a real estate appraisal and classified as a Level 3 input under the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-21-000034:notes:117]
[same as prior period, unchanged from 0000889331-20-000054:notes:102]

[0000889331-21-000034:notes:118]
[same as prior period, unchanged from 0000889331-20-000054:notes:103]

[0000889331-21-000034:notes:119]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other (income) expense, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three months ended March 27, 2021 and March 28, 2020 were as follows:

[0000889331-21-000034:notes:120]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | March 27, 2021 |  | March 28, 2020 |  |  |  |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 702 |  |  | $ | 618 |  |  |  |  |  |
| Interest cost |  | 440 |  |  | 658 |  |  |  |  |  |
| Expected return on plan assets |  | (367) |  |  | (727) |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | 331 |  |  | 145 |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 1,106 |  |  | $ | 694 |  |  |  |  |  |

[0000889331-21-000034:notes:121]
The Company expects to make approximately $2.2 million of contributions to the plans and pay $3.8 million of benefits directly in 2021.

[0000889331-21-000034:notes:122]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.5 million for both the three months ended March 27, 2021 and March 28, 2020, respectively, in Cost of Sales and Other (income) expense, net within the Condensed Consolidated Statements of Net Income. For the three months ended March 27, 2021 and March 28, 2020, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were both $0.2 million.

[0000889331-21-000034:notes:123]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to directly pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $55 million, representing approximately 37% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge currently estimated between $18 million and $22 million in the fourth quarter of 2021, reflecting the accelerated recognition of unamortized actuarial losses 
in the plan. The actual amount and timing of the settlement charge could differ from this estimate due to final data and plan wind-up expenses. Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million (£10.9 million) to both the net pension liability and unamortized actuarial loss within other comprehensive income (loss) during the second quarter of 2020. Additionally, the Company made a cash contribution of $10.4 million (£8.4 million) under this agreement during the second quarter of 2020.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-21-000034:notes:124]
[same as prior period, unchanged from 0000889331-20-000054:notes:110]

[0000889331-21-000034:notes:125]
| (in thousands) |  | Three Months EndedMarch 27, 2021 |  | Three Months EndedMarch 28, 2020 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 506 |  |  | $ | 52 |  |  | $ | 454 |  |  | $ | 555 |  |  | $ | (6) |  |  | $ | 561 |  |
| Foreign currency translation adjustments |  | (5,325) |  |  | — |  |  | (5,325) |  |  | (15,540) |  |  | — |  |  | (15,540) |  |
| Total change in other comprehensive income (loss) |  | $ | (4,819) |  |  | $ | 52 |  |  | $ | (4,871) |  |  | $ | (14,985) |  |  | $ | (6) |  |  | $ | (14,979) |  |

[0000889331-21-000034:notes:126]
The following tables set forth the changes in accumulated other comprehensive (loss) by component for the three months ended March 27, 2021 and March 28, 2020:

[0000889331-21-000034:notes:127]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive (loss) |
| Balance at December 26, 2020 |  | $ | (34,141) |  |  |  |  | $ | (57,016) |  |  | $ | (91,157) |  |
| Activity in the period |  | 454 |  |  |  |  | (5,325) |  |  | (4,871) |  |
| Balance at March 27, 2021 |  | $ | (33,687) |  |  |  |  | $ | (62,341) |  |  | $ | (96,028) |  |

[0000889331-21-000034:notes:128]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currency translation adjustment |  | Accumulated other comprehensive (loss) |
| Balance at December 28, 2019 |  | $ | (18,046) |  |  |  |  | $ | (88,777) |  |  | $ | (106,823) |  |
| Activity in the period |  | 561 |  |  |  |  | (15,540) |  |  | (14,979) |  |
| Balance at March 28, 2020 |  | $ | (17,485) |  |  |  |  | $ | (104,317) |  |  | $ | (121,802) |  |

[0000889331-21-000034:notes:129]
Amounts reclassified from accumulated other comprehensive (loss) to earnings for the three months ended March 27, 2021 and March 28, 2020 were as follows:

[0000889331-21-000034:notes:130]
|  |  | Three Months Ended |  |  |  |  |
| (in thousands) |  | March 27, 2021 |  | March 28, 2020 |  |  |  |  |  |  |  |  |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 504 |  |  | $ | 345 |  |  |  |  |  |  |  |  |  |

[0000889331-21-000034:notes:131]
The Company recognizes the amortization of prior service costs in Other (income) expense, net within the Condensed Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-21-000034:notes:132]
[same as prior period, unchanged from 0000889331-20-000054:notes:120]

[0000889331-21-000034:notes:133]
The effective tax rate for the three months ended March 27, 2021 was 20.6%, compared to the effective tax rate for the three months ended March 28, 2020 of 30.6%. The effective tax rate for the 2021 period is lower than the effective tax rate for the comparable 2020 period primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 as compared to 2020. The effective tax rate for the 2021 period is approximately the same as the applicable U.S. statutory rate.


## us-gaap:EarningsPerShareTextBlock

[0000889331-21-000034:notes:134]
[same as prior period, unchanged from 0000889331-20-000054:notes:123]

[0000889331-21-000034:notes:135]
[same as prior period, unchanged from 0000889331-20-000054:notes:124]

[0000889331-21-000034:notes:136]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | March 27, 2021 |  | March 28, 2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 57,713 |  |  | $ | 24,644 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,532 |  |  | 24,393 |  |  |  |  |  |
| Effect of dilutive securities |  | 360 |  |  | 185 |  |  |  |  |  |
| Diluted |  | 24,892 |  |  | 24,578 |  |  |  |  |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.35 |  |  | $ | 1.01 |  |  |  |  |  |
| Diluted earnings per share |  | $ | 2.32 |  |  | $ | 1.00 |  |  |  |  |  |

[0000889331-21-000034:notes:137]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 15 and 153,836 for the three months ended March 27, 2021 and March 28, 2020,  respectively.

[0000889331-21-000034:notes:138]
[same as prior period, unchanged from 0000889331-20-000054:notes:127]

[0000889331-21-000034:notes:139]
On April 26, 2019, the Company's Board of Directors authorized a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program"). On April 29, 2020, the Company announced that the Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. On April, 28, 2021, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program. 
The Company did not repurchase any shares of its common stock for the three months ended March 27, 2021. During the three months ended March 28, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-21-000034:notes:140]
Related Party Transactions

[0000889331-21-000034:notes:141]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-21-000034:notes:142]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-21-000034:notes:143]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-21-000034:notes:144]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-21-000034:notes:145]
|  |  | For the Three Months Ended March 27, 2021 |  | For the Three Months Ended March 28, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.2 |  | $ | — |  | $ | 1.8 |  |
|  |  | March 27, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | $ | 0.2 |  | $ | — |  | $ | 0.3 |  |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |

[0000889331-21-000034:notes:146]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.5 million as of March 27, 2021 and December 26, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-21-000034:notes:147]
[same as prior period, unchanged from 0000889331-20-000054:notes:137]

[0000889331-21-000034:notes:148]
The Company and its subsidiaries design, manufacture and sell components and modules empowering a sustainable, connected, and safer world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-21-000034:notes:149]
[same as prior period, unchanged from 0000889331-20-000054:notes:139]

[0000889331-21-000034:notes:150]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, metal-oxide-semiconductor field effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related infrastructure, power supplies, data centers and telecommunications, medical devices, alternative energy, building and home automation, appliances, and mobile electronics.

[0000889331-21-000034:notes:151]
•Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle end markets. Passenger car fuse products for internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable

[0000889331-21-000034:notes:152]
protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules used in applications serving a number of end markets, including heavy truck, construction, agriculture and material handling. Automotive sensor products include a wide range of automotive and commercial vehicle products designed to monitor the passenger compartment occupant's safety and environment as well as the vehicle’s powertrain.

[0000889331-21-000034:notes:153]
•Industrial Segment: Consists of industrial circuit protection products (i.e. fuses, power distribution modules, switches) and industrial control products (i.e. relays, transformers, contactors, sensors). These products are used in a variety of applications and end-markets including: Renewable Energy, Energy Storage, HVAC, Electric Vehicle Infrastructure, Industrial Equipment, Industrial Automation, Construction, Mining, and Oil & Gas.

[0000889331-21-000034:notes:154]
[same as prior period, unchanged from 0000889331-20-000054:notes:144]

[0000889331-21-000034:notes:155]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 27, 2021 |  | March 28, 2020 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 286,535 |  |  | $ | 214,189 |  |  |  |  |  |
| Automotive |  | 128,529 |  |  | 104,770 |  |  |  |  |  |
| Industrial |  | 48,730 |  |  | 27,137 |  |  |  |  |  |
| Total net sales |  | $ | 463,794 |  |  | $ | 346,096 |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,381 |  |  | $ | 15,531 |  |  |  |  |  |
| Automotive |  | 7,073 |  |  | 7,187 |  |  |  |  |  |
| Industrial |  | 1,744 |  |  | 1,084 |  |  |  |  |  |
| Total depreciation and amortization |  | $ | 24,198 |  |  | $ | 23,802 |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 55,523 |  |  | $ | 32,272 |  |  |  |  |  |
| Automotive |  | 20,316 |  |  | 14,116 |  |  |  |  |  |
| Industrial |  | 3,506 |  |  | 3,534 |  |  |  |  |  |
| Other(a) |  | (2,864) |  |  | (5,172) |  |  |  |  |  |
| Total operating income |  | 76,481 |  |  | 44,750 |  |  |  |  |  |
| Interest expense |  | 4,673 |  |  | 5,418 |  |  |  |  |  |
| Foreign exchange loss |  | 6,837 |  |  | 2,584 |  |  |  |  |  |
| Other (income) expense, net |  | (7,737) |  |  | 1,249 |  |  |  |  |  |
| Income before income taxes |  | $ | 72,708 |  |  | $ | 35,499 |  |  |  |  |  |

[0000889331-21-000034:notes:156]
(a) Included in “Other” Operating income for the first quarter of 2021 was $3.5 million of purchase accounting inventory step-up charges, $0.8 million of legal and professional fees and other expenses related to Hartland and other contemplated acquisitions and $0.4 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment and Other Charges, for further discussion. In addition, there was a $1.9 million gain from the sale of a building within the Electronics segment.

[0000889331-21-000034:notes:157]
Included in "Other" Operating income for the first quarter of 2020 was $1.2 million of acquisition integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $4.0 million of restructuring, impairment and other charges, primarily related to impairment charges of $2.2 million associated with the announced consolidation of a manufacturing facility within the Industrial segment and $1.7 million of employee termination costs and other restructuring charges. See Note 7, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-21-000034:notes:158]
[same as prior period, unchanged from 0000889331-20-000054:notes:149]

[0000889331-21-000034:notes:159]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 27, 2021 |  | March 28, 2020 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,931 |  |  | $ | 102,910 |  |  |  |  |  |
| China |  | 139,158 |  |  | 86,015 |  |  |  |  |  |
| Other countries(a) |  | 193,705 |  |  | 157,171 |  |  |  |  |  |
| Total net sales |  | $ | 463,794 |  |  | $ | 346,096 |  |  |  |  |  |

[0000889331-21-000034:notes:160]
[same as prior period, unchanged from 0000889331-20-000054:notes:151]

[0000889331-21-000034:notes:161]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 48,908 |  |  | $ | 46,132 |  |
| China |  | 85,280 |  |  | 85,876 |  |
| Mexico |  | 72,499 |  |  | 70,125 |  |
| Germany |  | 36,227 |  |  | 37,976 |  |
| Philippines |  | 66,956 |  |  | 66,994 |  |
| Other countries(a) |  | 35,044 |  |  | 37,075 |  |
| Total long-lived assets |  | $ | 344,914 |  |  | $ | 344,178 |  |

[0000889331-21-000034:notes:162]
[same as prior period, unchanged from 0000889331-20-000054:notes:153]

[0000889331-21-000034:notes:163]
|  |  | Three Months Ended |
| (in thousands) |  | March 27, 2021 |  | March 28, 2020 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 683 |  |  | $ | 580 |  |
| China |  | 2,142 |  |  | 1,657 |  |
| Mexico |  | 6,121 |  |  | 2,592 |  |
| Germany |  | 593 |  |  | 753 |  |
| Philippines |  | 2,443 |  |  | 3,218 |  |
| Other countries(a) |  | 754 |  |  | 2,508 |  |
| Total additions to long-lived assets |  | $ | 12,736 |  |  | $ | 11,308 |  |

[0000889331-21-000034:notes:164]
[same as prior period, unchanged from 0000889331-20-000054:notes:155]
