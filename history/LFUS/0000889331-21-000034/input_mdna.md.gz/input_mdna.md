# LFUS MD&A — 0000889331-21-000034


## mdna

[0000889331-21-000034:mdna:1]
[same as prior period, unchanged from 0000889331-20-000054:mdna:1]

[0000889331-21-000034:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-21-000034:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 26, 2020.

[0000889331-21-000034:mdna:4]
[same as prior period, unchanged from 0000889331-20-000054:mdna:4]

[0000889331-21-000034:mdna:5]
[same as prior period, unchanged from 0000889331-20-000054:mdna:5]

[0000889331-21-000034:mdna:6]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 12,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-21-000034:mdna:7]
The Company maintains a network of global laboratories and engineering centers that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company conducts its business through three reportable segments: Electronics, Automotive, and Industrial. Within these segments, the Company designs, manufactures and sells components and modules empowering a sustainable, connected, and safer world. Our products protect against electrostatic discharge, power surges, short circuits, voltage spikes and other harmful occurrences, safely and efficiently control power and improve productivity and are used to identify and detect temperature, proximity, flow speed and fluid level in various applications.

[0000889331-21-000034:mdna:8]
[same as prior period, unchanged from 0000889331-20-000054:mdna:10]

[0000889331-21-000034:mdna:9]
For the first quarter of 2021, the Company recognized net sales of $463.8 million compared to $346.1 million in the first quarter of 2020 representing an increase of $117.7 million, or 34.0%. The increase was driven by higher volumes across all businesses in the Electronics and Automotive segments, $16.7 million or 3.6% of net sales from the Hartland acquisition within the Industrial segment and $12.4 million or 3.6% of favorable changes in foreign exchange rates. The Company recognized net income of $57.7 million, or $2.32 per diluted share, in the first quarter of 2021 compared to net income of $24.6 million, or $1.00 per diluted share in the first quarter of 2020. The increase in net income reflects higher operating income of $31.7 million driven by a $23.3 million and $6.2 million increase in operating income in the Electronics and Automotive segments, respectively, increases of $9.7 million of unrealized gains associated with our equity investments partially offset by higher foreign exchange losses of $4.3 million.

[0000889331-21-000034:mdna:10]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The purchase price for Hartland was approximately $112.3 million and the operations of Hartland are included in the Industrial segment.

[0000889331-21-000034:mdna:11]
Net cash provided by operating activities was $50.2 million for the three months ended March 27, 2021 as compared to $45.3 million for the three months ended March 28, 2020. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth.

[0000889331-21-000034:mdna:12]
[same as prior period, unchanged from 0000889331-20-000054:mdna:16]

[0000889331-21-000034:mdna:13]
The effects from COVID-19 continue to drive increased costs, though lower than 2020 levels. Ongoing costs include spending on personal protective equipment ("PPE"), additional personnel and employee transportation costs, and manufacturing inefficiencies, as well as an increase in freight costs due to the transportation capacity constraints across the world.

[0000889331-21-000034:mdna:14]
The Company anticipates that the global health crisis caused by COVID-19 may continue to negatively impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a resurgence in COVID-19 cases and its impact on our employees, customers, suppliers and vendors. The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business and operations, including the effects on our customers, employees, and prospects, or on our financial results for the fiscal year 2021.

[0000889331-21-000034:mdna:15]
[same as prior period, unchanged from 0000889331-20-000054:mdna:28]

[0000889331-21-000034:mdna:16]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The first quarter of 2021 includes $3.5 million of purchase accounting inventory step-up charges, $0.8 million of legal and professional fees and other expenses related to Hartland and other contemplated acquisitions and $0.4 million of

[0000889331-21-000034:mdna:17]
restructuring, impairment and other charges, primarily related to employee termination costs. In addition, there was a $1.9 million gain from the sale of a building within the Electronics segment.

[0000889331-21-000034:mdna:18]
The first quarter of 2020 includes $1.2 million of acquisition integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $4.0 million of restructuring, impairment and other charges, primarily related to impairment charges of $2.2 million associated with the announced consolidation of a manufacturing facility within the Industrial segment and $1.7 million of employee termination costs and other restructuring charges.

[0000889331-21-000034:mdna:19]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 463,794 |  |  | $ | 346,096 |  |  | $ | 117,698 |  |  | 34.0 | % |  |  |  |  |  |  |  |  |
| Cost of sales |  | 303,328 |  |  | 221,740 |  |  | 81,588 |  |  | 36.8 | % |  |  |  |  |  |  |  |  |
| Gross profit |  | 160,466 |  |  | 124,356 |  |  | 36,110 |  |  | 29.0 | % |  |  |  |  |  |  |  |  |
| Operating expenses |  | 83,985 |  |  | 79,606 |  |  | 4,379 |  |  | 5.5 | % |  |  |  |  |  |  |  |  |
| Operating income |  | 76,481 |  |  | 44,750 |  |  | 31,731 |  |  | 70.9 | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | 72,708 |  |  | 35,499 |  |  | 37,209 |  |  | 104.8 | % |  |  |  |  |  |  |  |  |
| Income taxes |  | 14,995 |  |  | 10,855 |  |  | 4,140 |  |  | 38.1 | % |  |  |  |  |  |  |  |  |
| Net income |  | $ | 57,713 |  |  | $ | 24,644 |  |  | $ | 33,069 |  |  | 134.2 | % |  |  |  |  |  |  |  |  |

[0000889331-21-000034:mdna:20]
[same as prior period, unchanged from 0000889331-20-000054:mdna:32]

[0000889331-21-000034:mdna:21]
Net sales increased $117.7 million or 34.0% including $12.4 million or 3.6% of favorable changes in foreign exchange rates for the first quarter of 2021 compared to the first quarter of 2020. The increase was primarily due to higher sales of $72.3 million and $23.8 million, respectively, in the Electronics and Automotive segments driven by higher volumes across all businesses within these segments. The volume increase within the Electronics segment was led by greater customer demand for products and devices for work-from-home and stay-at-home needs, and strong global automotive demand driving an increase for products used in automotive electronics and electric vehicles. The volume increase within the Automotive segment was due to stronger global auto and commercial vehicle market demand. The remaining increase in net sales was due to $16.7 million of net sales resulting from the Hartland acquisition included in the Industrial segment.

[0000889331-21-000034:mdna:22]
Cost of Sales

[0000889331-21-000034:mdna:23]
Cost of sales was $303.3 million, or 65.4% of net sales, in 2021, compared to $221.7 million, or 64.1% of net sales, in 2020. The increase in cost of sales was primarily due to greater volume in the Electronics and Automotive segments driven by the factors discussed above along with the acquisition of Hartland. As a percent of net sales, cost of sales increased 1.3% driven by higher freight costs of $7.3 million, or 0.9%, the Hartland purchase accounting inventory charges of $3.5 million or 0.8%, and higher commodity costs partially offset by cost reductions.

[0000889331-21-000034:mdna:24]
[same as prior period, unchanged from 0000889331-20-000054:mdna:36]

[0000889331-21-000034:mdna:25]
Gross profit was $160.5 million, or 34.6% of net sales, in the first quarter of 2021 compared to $124.4 million, or 35.9% of net sales, for the first quarter of 2020. The $36.1 million increase in gross profit was primarily due to higher volume in the Electronics and Automotive segments. The decrease in gross margin of 1.3% was primarily due to the higher freight costs of $7.3 million or 0.9%, the purchase accounting inventory charges of $3.5 million or 0.8%, higher commodity costs, and unfavorable price and foreign exchange partially offset by higher volumes within the Electronics and Automotive segments.

[0000889331-21-000034:mdna:26]
[same as prior period, unchanged from 0000889331-20-000054:mdna:39]

[0000889331-21-000034:mdna:27]
Total operating expenses were $84.0 million, or 18.1% of net sales, for the first quarter of 2021 compared to $79.6 million, or 23.0% of net sales, for the first quarter of 2020. The increase in operating expenses of $4.4 million was primarily due to higher selling, general and administrative expenses of $7.1 million largely due to higher accrued incentive compensation and the

[0000889331-21-000034:mdna:28]
Hartland acquisition partially offset by a $1.9 million gain from the sale of a building within the Electronics segment. The increase in operating expenses was also partially offset by lower restructuring, impairment and other charges of $3.5 million.

[0000889331-21-000034:mdna:29]
[same as prior period, unchanged from 0000889331-20-000054:mdna:42]

[0000889331-21-000034:mdna:30]
Operating income was $76.5 million, an increase of $31.7 million, or 70.9%, for the first quarter of 2021 compared to $44.8 million for the first quarter of 2020. The increase in operating income was primarily due to higher gross profit from the Electronics and Automotive segments. Operating margins increased from 12.9% in the first quarter of 2020 to 16.5% in the first quarter of 2021 driven by the factors mentioned above.

[0000889331-21-000034:mdna:31]
[same as prior period, unchanged from 0000889331-20-000054:mdna:45]

[0000889331-21-000034:mdna:32]
Income before income taxes was $72.7 million, or 15.7% of net sales, for the first quarter of 2021 compared to $35.5 million, or 10.3% of net sales, for the first quarter of 2020. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by increases of $9.7 million of unrealized gains associated with our equity investments partially offset by higher foreign exchange losses of $4.3 million.

[0000889331-21-000034:mdna:33]
[same as prior period, unchanged from 0000889331-20-000054:mdna:49]

[0000889331-21-000034:mdna:34]
Income tax expense for the first quarter of 2021 was $15.0 million, or an effective tax rate of 20.6%, compared to income tax expense of $10.9 million, or an effective tax rate of 30.6%, for the first quarter of 2020. The effective tax rate for the first quarter of 2021 is lower than the effective tax rate for the comparable 2020 period, primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 compared to 2020. The effective tax rate for the 2021 period is approximately the same as the applicable U.S. statutory rate.

[0000889331-21-000034:mdna:35]
[same as prior period, unchanged from 0000889331-20-000054:mdna:53]

[0000889331-21-000034:mdna:36]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 15, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-21-000034:mdna:37]
[same as prior period, unchanged from 0000889331-20-000054:mdna:55]

[0000889331-21-000034:mdna:38]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 286,535 |  |  | $ | 214,189 |  |  | $ | 72,346 |  |  | 33.8 | % |  |  |  |  |  |  |  |  |
| Automotive |  | 128,529 |  |  | 104,770 |  |  | 23,759 |  |  | 22.7 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 48,730 |  |  | 27,137 |  |  | 21,593 |  |  | 79.6 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 463,794 |  |  | $ | 346,096 |  |  | $ | 117,698 |  |  | 34.0 | % |  |  |  |  |  |  |  |  |

[0000889331-21-000034:mdna:39]
[same as prior period, unchanged from 0000889331-20-000054:mdna:57]

[0000889331-21-000034:mdna:40]
Net sales increased $72.3 million, or 33.8%, in the first quarter of 2021 compared to the first quarter of 2020 and included favorable changes in foreign exchange rates of $6.5 million. The sales increase was primarily due to increased volume for the electronics products and semiconductor businesses of $47.8 million and $24.5 million, respectively. The volume increases were led by greater customer demand for products and devices for work-from-home and stay-at-home needs, and strong global automotive demand driving an increase for products used in automotive electronics and electric vehicles. The first quarter of 2020 also included production disruptions due to the impact of COVID-19.

[0000889331-21-000034:mdna:41]
[same as prior period, unchanged from 0000889331-20-000054:mdna:61]

[0000889331-21-000034:mdna:42]
Net sales increased $23.8 million, or 22.7%, in the first quarter of 2021 compared to the first quarter of 2020 and included favorable changes in foreign exchange rates of $5.6 million. The sales increase was due to higher volume in passenger car products, commercial vehicle products, and the automotive sensors business of $15.3 million, $4.4 million, and $4.1 million,

[0000889331-21-000034:mdna:43]
respectively. These increases were due to stronger global auto and commercial vehicle market demand. Our Asia region experienced the most growth driven by an increase in global auto market demand as compared to the first quarter of 2020 that had production disruptions due to the impact of COVID-19. Sales also grew due to the launch of new products and higher content per vehicle.

[0000889331-21-000034:mdna:44]
[same as prior period, unchanged from 0000889331-20-000054:mdna:64]

[0000889331-21-000034:mdna:45]
Net sales increased by $21.6 million, or 79.6%, in the first quarter of 2021 compared to the first quarter of 2020, which included favorable changes in foreign exchange rates of $0.3 million. The increase in net sales was primarily due to incremental net sales of $16.7 million or 61.5% from the Hartland acquisition, higher volume of $4.5 million in the power fuse business, and the transfer of the temperature sensor product line totaling $1.9 million which was previously reported in the Electronics segment, partially offset by lower volume in the relay business.

[0000889331-21-000034:mdna:46]
[same as prior period, unchanged from 0000889331-20-000054:mdna:67]

[0000889331-21-000034:mdna:47]
[same as prior period, unchanged from 0000889331-20-000054:mdna:68]

[0000889331-21-000034:mdna:48]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | $ | 212,185 |  |  | $ | 140,873 |  |  | $ | 71,312 |  |  | 50.6 | % |  |  |  |  |  |  |  |  |
| Americas |  | 152,906 |  |  | 120,501 |  |  | 32,405 |  |  | 26.9 | % |  |  |  |  |  |  |  |  |
| Europe |  | 98,703 |  |  | 84,722 |  |  | 13,981 |  |  | 16.5 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 463,794 |  |  | $ | 346,096 |  |  | $ | 117,698 |  |  | 34.0 | % |  |  |  |  |  |  |  |  |

[0000889331-21-000034:mdna:49]
[same as prior period, unchanged from 0000889331-20-000054:mdna:70]

[0000889331-21-000034:mdna:50]
Net sales increased $71.3 million, or 50.6%, in the first quarter of 2021 compared to the first quarter of 2020 and included favorable changes in foreign exchange rates of $4.2 million. The increase in net sales was primarily due to higher volume across all businesses within the Electronics and Automotive segments, compared to the first quarter of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000034:mdna:51]
[same as prior period, unchanged from 0000889331-20-000054:mdna:73]

[0000889331-21-000034:mdna:52]
Net sales increased $32.4 million, or 26.9%, in the first quarter of 2021 compared to the first quarter of 2020 and included favorable changes in foreign exchange rates of $0.1 million. The increase in net sales was primarily due to incremental sales of $16.7 million from the Hartland acquisition, higher volume across all businesses within the Electronics segment, and higher volume in the passenger car products and commercial vehicle businesses within the Automotive segment.

[0000889331-21-000034:mdna:53]
[same as prior period, unchanged from 0000889331-20-000054:mdna:77]

[0000889331-21-000034:mdna:54]
Net sales increased $14.0 million, or 16.5%, in the first quarter of 2021 compared to the first quarter of 2020. The increase in net sales was primarily due to favorable changes in foreign exchange rates of $8.1 million and increased volume across all businesses within the Automotive segment and Electronics products business within the Electronics segment, partially offset by lower volume in the semiconductor business within the Electronics segment.

[0000889331-21-000034:mdna:55]
[same as prior period, unchanged from 0000889331-20-000054:mdna:80]

[0000889331-21-000034:mdna:56]
[same as prior period, unchanged from 0000889331-20-000054:mdna:81]

[0000889331-21-000034:mdna:57]
Cash and cash equivalents were $572.8 million as of March 27, 2021, a decrease of $114.8 million as compared to December 26, 2020. As of March 27, 2021, $306.6 million of the Company's $572.8 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-21-000034:mdna:58]
Revolving Credit Facility

[0000889331-21-000034:mdna:59]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the three months ended March 27, 2021. The balance under the facility was $100.0 million as of March 27, 2021.

[0000889331-21-000034:mdna:60]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.61% at March 27, 2021.

[0000889331-21-000034:mdna:61]
As of March 27, 2021, the Company had no amount outstanding in letters of credit and had available $571.3 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 27, 2021, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-21-000034:mdna:62]
[same as prior period, unchanged from 0000889331-20-000054:mdna:92]

[0000889331-21-000034:mdna:63]
[same as prior period, unchanged from 0000889331-20-000054:mdna:93]

[0000889331-21-000034:mdna:64]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000034:mdna:65]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-21-000034:mdna:66]
Debt Covenants

[0000889331-21-000034:mdna:67]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of March 27, 2021 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2021. As of March 27, 2021, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-21-000034:mdna:68]
Acquisitions

[0000889331-21-000034:mdna:69]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The purchase price for Hartland was approximately $112.3 million and the operations of Hartland Controls are included in the Industrial segment. The net cash payment of $109.9 million for this acquisition was funded by the Company's cash on hand.

[0000889331-21-000034:mdna:70]
[same as prior period, unchanged from 0000889331-20-000054:mdna:98]

[0000889331-21-000034:mdna:71]
During the first quarter of 2020 the Company paid quarterly dividends of $11.8 million to the shareholders. On April 28, 2021, the Board of Directors of the Company declared a quarterly cash dividend of $0.48 per share, payable on June 3, 2021 to stockholders of record as of May 20, 2021.

[0000889331-21-000034:mdna:72]
U.K. pension plan

[0000889331-21-000034:mdna:73]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to directly pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $55 million, representing approximately 37% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge currently estimated between $18 million and $22 million in the fourth quarter of 2021, reflecting the accelerated recognition of unamortized actuarial losses in the plan. The actual amount and timing of the settlement charge could differ from this estimate due to final data and plan wind-up expenses. Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million (£10.9 million) to both the net pension liability and unamortized actuarial loss within other comprehensive income (loss) during the second quarter of 2020. Additionally, the Company made a cash contribution of $10.4 million (£8.4 million) under this agreement during the second quarter of 2020.

[0000889331-21-000034:mdna:74]
[same as prior period, unchanged from 0000889331-20-000054:mdna:100]

[0000889331-21-000034:mdna:75]
|  |  | First three Months |
| (in thousands) |  | 2021 |  | 2020 |
| Net cash provided by operating activities |  | $ | 50,166 |  |  | $ | 45,279 |  |
| Net cash used in investing activities |  | (122,020) |  |  | (16,536) |  |
| Net cash (used in) provided by financing activities |  | (34,273) |  |  | 65,804 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (4,101) |  |  | (5,111) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (110,228) |  |  | 89,436 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 687,525 |  |  | 531,139 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 577,297 |  |  | $ | 620,575 |  |

[0000889331-21-000034:mdna:76]
[same as prior period, unchanged from 0000889331-20-000054:mdna:102]

[0000889331-21-000034:mdna:77]
[same as prior period, unchanged from 0000889331-20-000054:mdna:103]

[0000889331-21-000034:mdna:78]
Net cash provided by operating activities was $50.2 million for the three months ended March 27, 2021 as compared to $45.3 million for the three months ended March 28, 2020. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth.

[0000889331-21-000034:mdna:79]
[same as prior period, unchanged from 0000889331-20-000054:mdna:105]

[0000889331-21-000034:mdna:80]
Net cash used in investing activities was $122.0 million for the three months ended March 27, 2021 compared to $16.5 million during the three months ended March 28, 2020. Net cash paid for the Hartland acquisition was $109.9 million for the three

[0000889331-21-000034:mdna:81]
months ended March 27, 2021. Capital expenditures were $14.7 million, representing a decrease of $1.9 million compared to 2020. During the three months ended March 28, 2020, the Company received proceeds of $2.6 million from the sale of a property within the Electronics segment.

[0000889331-21-000034:mdna:82]
[same as prior period, unchanged from 0000889331-20-000054:mdna:107]

[0000889331-21-000034:mdna:83]
Net cash used in financing activities was $34.3 million for the three months ended March 27, 2021 compared to net cash provided by financing activities of $65.8 million for the three months ended March 28, 2020. The Company made payments of $30.0 million on the amended revolving credit facility during the first quarter of 2021. During the three months ended March 28, 2020, the Company made principal payments of $2.5 million on the term loan and borrowed $100.0 million from its revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. For the three months ended March 28, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million. Additionally, the Company paid dividends $11.8 million and $11.7 million in the three months ended March 27, 2021 and March 28, 2020, respectively.

[0000889331-21-000034:mdna:84]
[same as prior period, unchanged from 0000889331-20-000054:mdna:109]

[0000889331-21-000034:mdna:85]
On April 26, 2019, the Company's Board of Directors authorized a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program"). On April 29, 2020, the Company announced that the Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. On April, 28, 2021, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program.

[0000889331-21-000034:mdna:86]
The Company did not repurchase any shares of its common stock for the three months ended March 27, 2021. During the three months ended March 28, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.

[0000889331-21-000034:mdna:87]
[same as prior period, unchanged from 0000889331-20-000054:mdna:112]

[0000889331-21-000034:mdna:88]
As of March 27, 2021, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-21-000034:mdna:89]
[same as prior period, unchanged from 0000889331-20-000054:mdna:114]

[0000889331-21-000034:mdna:90]
[same as prior period, unchanged from 0000889331-20-000054:mdna:115]

[0000889331-21-000034:mdna:91]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 26, 2020. During the three months ended March 27, 2021, there were no significant changes in the application of critical accounting policies.
