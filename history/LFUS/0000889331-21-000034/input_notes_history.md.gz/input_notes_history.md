# LFUS note change history — 0000889331-20-000054 → 0000889331-21-000034


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-04-28):
[0000889331-21-000034:note_history:1]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 12,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

- changed (2021-04-28):
[0000889331-21-000034:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 27, 2021 and March 28, 2020:
  (was, 2020-10-28, similarity 0.8975):
[0000889331-20-000054:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 26, 2020 and September 28, 2019:

- changed (2021-04-28):
[0000889331-21-000034:note_history:3]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |
  (was, 2020-10-28, similarity 0.6703):
[0000889331-20-000054:note_history:3]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- changed (2021-04-28):
[0000889331-21-000034:note_history:4]
|  |  | Three Months Ended March 28, 2020 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |  |  |  |  |  |  |  |  |
  (was, 2020-10-28, similarity 0.6703):
[0000889331-20-000054:note_history:4]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- added (2021-04-28):
[0000889331-21-000034:note_history:5]
Cash, Cash Equivalents and Restricted Cash

- added (2021-04-28):
[0000889331-21-000034:note_history:6]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at March 27, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- added (2021-04-28):
[0000889331-21-000034:note_history:7]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 572,771 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,462 |  |  | — |  |
| Restricted cash included in other assets |  | 1,064 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 577,297 |  |  | $ | 687,525 |  |

- added (2021-04-28):
[0000889331-21-000034:note_history:8]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.

- removed (2021-04-28):
[0000889331-20-000054:note_history:9]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, the Company’s products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

- removed (2021-04-28):
[0000889331-20-000054:note_history:10]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments." The standard modifies the measurement approach for credit losses on financial instruments, including trade receivables, from an incurred loss method to a current expected credit loss method ("CECL").  The standard requires the measurement of expected credit losses to be based on relevant information, including historical experiences, current conditions and a forecast that is supportable.  The Company adopted the new standard on December 29, 2019.  The adoption of the standard did not have a material effect on our Condensed Consolidated Financial Statements.

- removed (2021-04-28):
[0000889331-20-000054:note_history:11]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement."  ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies other disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018-13 did not have a material impact on our Condensed Consolidated Financial Statements.

- removed (2021-04-28):
[0000889331-20-000054:note_history:12]
In August 2018, the FASB issued ASU No. 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic: 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force)." ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The Company adopted the new standard on December 29, 2019.  The adoption of ASU 2018-15 did not have a material impact on our Condensed Consolidated Financial Statements.

- removed (2021-04-28):
[0000889331-20-000054:note_history:13]
In March 2020, the FASB issued ASU 2020-04 Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting.” This ASU provides optional expedient and exceptions for applying generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by reference rate reform if certain criteria are met. The objective of this is to provide optional guidance for a limited period of time to ease the potential burden in accounting for (or recognizing the effects of) reference rate reform on financial reporting due to the cessation of the London Interbank Offered Rate (LIBOR). The amendments in this update are effective for all entities as of March 12, 2020 through December 31, 2022. The Company does not expect a material effect from the adoption of this guidance on its Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-28):
[0000889331-21-000034:note_history:14]
The carrying amounts of debt at March 27, 2021 and December 26, 2020 are as follows:
  (was, 2020-10-28, similarity 0.9342):
[0000889331-20-000054:note_history:14]
The carrying amounts of debt at September 26, 2020 and December 28, 2019 are as follows:

- changed (2021-04-28):
[0000889331-21-000034:note_history:15]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 138,039 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,876) |  |  | (4,114) |  |
| Total debt |  | 648,865 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 623,865 |  |  | $ | 687,034 |  |
  (was, 2020-10-28, similarity 0.9553):
[0000889331-20-000054:note_history:15]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 180,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,417 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,295) |  |  | (3,669) |  |
| Total debt |  | 725,507 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 725,507 |  |  | $ | 669,158 |  |

- changed (2021-04-28):
[0000889331-21-000034:note_history:16]
Revolving Credit Facility
  (was, 2020-10-28, similarity 0.8065):
[0000889331-20-000054:note_history:16]
Revolving Credit Facility / Term Loan

- changed (2021-04-28):
[0000889331-21-000034:note_history:17]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the three months ended March 27, 2021. The balance under the facility was $100.0 million as of March 27, 2021.
  (was, 2020-10-28, similarity 0.9687):
[0000889331-20-000054:note_history:17]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $60.0 million on the amended revolving credit facility during the three months ended September 26, 2020. The balance under the facility was $180.0 million as of September 26, 2020.

- changed (2021-04-28):
[0000889331-21-000034:note_history:18]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.61% at March 27, 2021.
  (was, 2020-10-28, similarity 0.9855):
[0000889331-20-000054:note_history:18]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.90% at September 26, 2020.

- changed (2021-04-28):
[0000889331-21-000034:note_history:19]
As of March 27, 2021, the Company had no amount outstanding in letters of credit and had available $571.3 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 27, 2021, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2020-10-28, similarity 0.9509):
[0000889331-20-000054:note_history:19]
As of September 26, 2020, the Company had no amount outstanding in letters of credit and had available $245.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 26, 2020, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2021-04-28):
[0000889331-21-000034:note_history:20]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”)
  (was, 2020-10-28, similarity 0.8349):
[0000889331-20-000054:note_history:20]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- added (2021-04-28):
[0000889331-21-000034:note_history:21]
(together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- changed (2021-04-28):
[0000889331-21-000034:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 27, 2021, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2020-10-28, similarity 0.9878):
[0000889331-20-000054:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 26, 2020, the Company was in compliance with all covenants under the Senior Notes.

- added (2021-04-28):
[0000889331-21-000034:note_history:23]
Interest paid on all Company debt was $6.2 million and $7.4 million for the three months ended March 27, 2021 and March 28, 2020, respectively.

- removed (2021-04-28):
[0000889331-20-000054:note_history:24]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

- removed (2021-04-28):
[0000889331-20-000054:note_history:25]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size

- removed (2021-04-28):
[0000889331-20-000054:note_history:26]
of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.

- removed (2021-04-28):
[0000889331-20-000054:note_history:27]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to coronavirus disease 2019 ("COVID-19").

- removed (2021-04-28):
[0000889331-20-000054:note_history:28]
Interest paid on all Company debt was $6.4 million for the three months ended September 26, 2020 and September 28, 2019, and $17.2 million and $17.9 million for the nine months ended September 26, 2020 and September 28, 2019, respectively.

- changed (2021-04-28):
[0000889331-21-000034:note_history:29]
The carrying amounts of debt at March 27, 2021 and December 26, 2020 are as follows:
  (was, 2020-10-28, similarity 0.9342):
[0000889331-20-000054:note_history:29]
The carrying amounts of debt at September 26, 2020 and December 28, 2019 are as follows:

- changed (2021-04-28):
[0000889331-21-000034:note_history:30]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 138,039 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,876) |  |  | (4,114) |  |
| Total debt |  | 648,865 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 623,865 |  |  | $ | 687,034 |  |
  (was, 2020-10-28, similarity 0.9553):
[0000889331-20-000054:note_history:30]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 180,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,417 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,295) |  |  | (3,669) |  |
| Total debt |  | 725,507 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 725,507 |  |  | $ | 669,158 |  |

- changed (2021-04-28):
[0000889331-21-000034:note_history:31]
Revolving Credit Facility
  (was, 2020-10-28, similarity 0.8065):
[0000889331-20-000054:note_history:31]
Revolving Credit Facility / Term Loan

- changed (2021-04-28):
[0000889331-21-000034:note_history:32]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the three months ended March 27, 2021. The balance under the facility was $100.0 million as of March 27, 2021.
  (was, 2020-10-28, similarity 0.9687):
[0000889331-20-000054:note_history:32]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $60.0 million on the amended revolving credit facility during the three months ended September 26, 2020. The balance under the facility was $180.0 million as of September 26, 2020.

- changed (2021-04-28):
[0000889331-21-000034:note_history:33]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.61% at March 27, 2021.
  (was, 2020-10-28, similarity 0.9855):
[0000889331-20-000054:note_history:33]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.90% at September 26, 2020.

- changed (2021-04-28):
[0000889331-21-000034:note_history:34]
As of March 27, 2021, the Company had no amount outstanding in letters of credit and had available $571.3 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 27, 2021, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2020-10-28, similarity 0.9509):
[0000889331-20-000054:note_history:34]
As of September 26, 2020, the Company had no amount outstanding in letters of credit and had available $245.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 26, 2020, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2021-04-28):
[0000889331-21-000034:note_history:35]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”)
  (was, 2020-10-28, similarity 0.8349):
[0000889331-20-000054:note_history:35]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- added (2021-04-28):
[0000889331-21-000034:note_history:36]
(together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- changed (2021-04-28):
[0000889331-21-000034:note_history:37]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 27, 2021, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2020-10-28, similarity 0.9878):
[0000889331-20-000054:note_history:37]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 26, 2020, the Company was in compliance with all covenants under the Senior Notes.

- added (2021-04-28):
[0000889331-21-000034:note_history:38]
Interest paid on all Company debt was $6.2 million and $7.4 million for the three months ended March 27, 2021 and March 28, 2020, respectively.

- removed (2021-04-28):
[0000889331-20-000054:note_history:39]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

- removed (2021-04-28):
[0000889331-20-000054:note_history:40]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size

- removed (2021-04-28):
[0000889331-20-000054:note_history:41]
of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $5.0 million of principal payments on the term loan before the Company amended the Credit Agreement on April 3, 2020 as discussed below.

- removed (2021-04-28):
[0000889331-20-000054:note_history:42]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to coronavirus disease 2019 ("COVID-19").

- removed (2021-04-28):
[0000889331-20-000054:note_history:43]
Interest paid on all Company debt was $6.4 million for the three months ended September 26, 2020 and September 28, 2019, and $17.2 million and $17.9 million for the nine months ended September 26, 2020 and September 28, 2019, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-28):
[0000889331-21-000034:note_history:44]
The carrying amounts of debt at March 27, 2021 and December 26, 2020 are as follows:
  (was, 2020-10-28, similarity 0.9342):
[0000889331-20-000054:note_history:44]
The carrying amounts of debt at September 26, 2020 and December 28, 2019 are as follows:

- changed (2021-04-28):
[0000889331-21-000034:note_history:45]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 138,039 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,876) |  |  | (4,114) |  |
| Total debt |  | 648,865 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 623,865 |  |  | $ | 687,034 |  |
  (was, 2020-10-28, similarity 0.9553):
[0000889331-20-000054:note_history:45]
| (in thousands) |  | September 26,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 180,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,417 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,766 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,295) |  |  | (3,669) |  |
| Total debt |  | 725,507 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 725,507 |  |  | $ | 669,158 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-04-28):
[0000889331-21-000034:note_history:46]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.
  (was, 2020-10-28, similarity 0.8):
[0000889331-20-000054:note_history:46]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

- added (2021-04-28):
[0000889331-21-000034:note_history:47]
|  |  | For the Three Months Ended March 27, 2021 |  | For the Three Months Ended March 28, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.2 |  | $ | — |  | $ | 1.8 |  |
|  |  | March 27, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | $ | 0.2 |  | $ | — |  | $ | 0.3 |  |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |

- changed (2021-04-28):
[0000889331-21-000034:note_history:48]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.5 million as of March 27, 2021 and December 26, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.
  (was, 2020-10-28, similarity 0.9455):
[0000889331-20-000054:note_history:48]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.5 million as of September 26, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

- removed (2021-04-28):
[0000889331-20-000054:note_history:49]
|  |  | For the Three Months Ended September 26, 2020 |  | For the Three Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 2.4 |  |  | 0.8 |  | 0.1 |  | 1.7 |  |
|  |  | For the Nine Months Ended September 26, 2020 |  | For the Nine Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.1 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | — |  | 5.8 |  |  | 2.4 |  | 0.3 |  | 5.5 |  |
|  |  | September 26, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |

- removed (2021-04-28):
[0000889331-20-000054:note_history:50]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income, net in the Condensed Consolidated Statements of Net Income. The operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2021-04-28):
[0000889331-21-000034:note_history:51]
|  |  | For the Three Months Ended March 27, 2021 |  | For the Three Months Ended March 28, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.2 |  | $ | — |  | $ | 1.8 |  |
|  |  | March 27, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | $ | 0.2 |  | $ | — |  | $ | 0.3 |  |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |

- removed (2021-04-28):
[0000889331-20-000054:note_history:52]
|  |  | For the Three Months Ended September 26, 2020 |  | For the Three Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 2.4 |  |  | 0.8 |  | 0.1 |  | 1.7 |  |
|  |  | For the Nine Months Ended September 26, 2020 |  | For the Nine Months Ended September 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.1 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | — |  | 5.8 |  |  | 2.4 |  | 0.3 |  | 5.5 |  |
|  |  | September 26, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-28):
[0000889331-21-000034:note_history:53]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 27, 2021 and March 28, 2020:
  (was, 2020-10-28, similarity 0.8975):
[0000889331-20-000054:note_history:53]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 26, 2020 and September 28, 2019:

- changed (2021-04-28):
[0000889331-21-000034:note_history:54]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |
  (was, 2020-10-28, similarity 0.6703):
[0000889331-20-000054:note_history:54]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- changed (2021-04-28):
[0000889331-21-000034:note_history:55]
|  |  | Three Months Ended March 28, 2020 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |  |  |  |  |  |  |  |  |
  (was, 2020-10-28, similarity 0.6703):
[0000889331-20-000054:note_history:55]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-28):
[0000889331-21-000034:note_history:56]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 27, 2021 and March 28, 2020:
  (was, 2020-10-28, similarity 0.8975):
[0000889331-20-000054:note_history:56]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 26, 2020 and September 28, 2019:

- changed (2021-04-28):
[0000889331-21-000034:note_history:57]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |
  (was, 2020-10-28, similarity 0.6703):
[0000889331-20-000054:note_history:57]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- changed (2021-04-28):
[0000889331-21-000034:note_history:58]
|  |  | Three Months Ended March 28, 2020 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |  |  |  |  |  |  |  |  |
  (was, 2020-10-28, similarity 0.6703):
[0000889331-20-000054:note_history:58]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |
