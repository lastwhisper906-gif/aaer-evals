# LFUS 8-K — 0000889331-21-000032 filed 2021-04-28

## item codes, every 8-K on or before 2021-04-28

- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2021-04-28

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-21-000032:8k_2_02:1]
EX-99.1
2
q12021earningsreleaseex991.htm
EX-99.1

[0000889331-21-000032:8k_2_02:2]
Document

[0000889331-21-000032:8k_2_02:3]
Exhibit 99.1

[0000889331-21-000032:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-21-000032:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2021

[0000889331-21-000032:8k_2_02:6]
Record sales driven by strong worldwide execution

[0000889331-21-000032:8k_2_02:7]
CHICAGO, April 28, 2021 - Littelfuse, Inc. (NASDAQ: LFUS), an industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the first quarter ended March 27, 2021:

[0000889331-21-000032:8k_2_02:8]
•Net sales of $463.8 million were up 34% versus the prior year period, and up 26% organically, due to strong demand across a number of electronics, automotive and industrial end markets

[0000889331-21-000032:8k_2_02:9]
•Growth by segment versus the prior year period:

[0000889331-21-000032:8k_2_02:10]
◦Electronics sales grew 34% (up 32% organically)

[0000889331-21-000032:8k_2_02:11]
◦Automotive sales grew 23% (up 17% organically)

[0000889331-21-000032:8k_2_02:12]
◦Industrial sales grew 80% (up 10% organically)

[0000889331-21-000032:8k_2_02:13]
•GAAP diluted EPS was $2.32; adjusted diluted EPS was $2.67, a growth of 107% and includes $0.54 of benefits related to a non-operating mark-to-market gain and lower effective tax rate compared to the prior year period

[0000889331-21-000032:8k_2_02:14]
•GAAP effective tax rate was 20.6% and the adjusted effective tax rate was 19.2%

[0000889331-21-000032:8k_2_02:15]
•Cash flow from operations was $50.2 million and free cash flow was $35.4 million

[0000889331-21-000032:8k_2_02:16]
“We are off to a strong start this year, delivering double-digit revenue and EPS growth well ahead of expectations,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Our agile teams around the world continue to navigate through this dynamic market environment while meeting commitments to our customers. Looking ahead, we are seeing healthy demand across a number of our end markets aligned to the strategic, structural growth themes of a sustainable, connected, and safer world. We remain confident we are well-positioned for long-term profitable growth.”

[0000889331-21-000032:8k_2_02:17]
Second Quarter of 2021*

[0000889331-21-000032:8k_2_02:18]
For the second quarter, the company expects net sales in the range of $463 to $477 million, adjusted diluted EPS in the range of $2.12 to $2.28 and an adjusted effective tax rate of approximately 17%.

[0000889331-21-000032:8k_2_02:19]
-more-

[0000889331-21-000032:8k_2_02:20]
Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-21-000032:8k_2_02:21]
Dividend and Share Repurchase Authorization

[0000889331-21-000032:8k_2_02:22]
•The company’s Board of Directors approved a new stock repurchase authorization to replace its previous 2020 program. The company may repurchase up to $300 million in the aggregate of shares of the company’s common stock for the period May 1, 2021 to April 30, 2024.

[0000889331-21-000032:8k_2_02:23]
•The company will pay a cash dividend on its common stock of $0.48 per share on June 3, 2021 to shareholders of record as of May 20, 2021

[0000889331-21-000032:8k_2_02:24]
Conference Call and Webcast Information

[0000889331-21-000032:8k_2_02:25]
Littelfuse will host a conference call today, Wednesday, April 28, 2021, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com. A slide presentation will be available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-21-000032:8k_2_02:26]
About Littelfuse

[0000889331-21-000032:8k_2_02:27]
Littelfuse (NASDAQ: LFUS) is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 12,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-21-000032:8k_2_02:28]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. These statements may involve risks and uncertainties, including, but not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings.

[0000889331-21-000032:8k_2_02:29]
-more-

[0000889331-21-000032:8k_2_02:30]
Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 26, 2020. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 26, 2020 and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-21-000032:8k_2_02:31]
Non-GAAP Financial Measures

[0000889331-21-000032:8k_2_02:32]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, consolidated total gross debt, consolidated EBITDA (as defined in the private placement senior notes), and ratio of consolidated total gross debt to consolidated EBITDA. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-21-000032:8k_2_02:33]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-21-000032:8k_2_02:34]
The company believes that organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that consolidated total gross debt, consolidated EBITDA, and ratio of consolidated total gross debt to consolidated EBITDA are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-21-000032:8k_2_02:35]
CONTACT: Trisha Tuntland

[0000889331-21-000032:8k_2_02:36]
Head of Investor Relations

[0000889331-21-000032:8k_2_02:37]
(773) 628-2163

[0000889331-21-000032:8k_2_02:38]
###

[0000889331-21-000032:8k_2_02:39]
LFUS-F

[0000889331-21-000032:8k_2_02:40]
LITTELFUSE, INC.

[0000889331-21-000032:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-21-000032:8k_2_02:42]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 572,771 |  |  | $ | 687,525 |  |
| Short-term investments |  | 53 |  |  | 54 |  |
| Trade receivables, less allowances of $42,624 and $45,237 at March 27, 2021 and December 26, 2020, respectively |  | 276,687 |  |  | 232,760 |  |
| Inventories |  | 295,057 |  |  | 258,002 |  |
| Prepaid income taxes and income taxes receivable |  | 4,146 |  |  | 3,029 |  |
| Prepaid expenses and other current assets |  | 43,698 |  |  | 35,939 |  |
| Total current assets |  | 1,192,412 |  |  | 1,217,309 |  |
| Net property, plant, and equipment |  | 344,914 |  |  | 344,178 |  |
| Intangible assets, net of amortization |  | 317,294 |  |  | 291,887 |  |
| Goodwill |  | 845,586 |  |  | 816,812 |  |
| Investments |  | 37,285 |  |  | 30,547 |  |
| Deferred income taxes |  | 9,854 |  |  | 11,224 |  |
| Right of use lease assets, net |  | 19,560 |  |  | 17,615 |  |
| Other assets |  | 19,965 |  |  | 18,021 |  |
| Total assets |  | $ | 2,786,870 |  |  | $ | 2,747,593 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 179,723 |  |  | $ | 145,984 |  |
| Accrued liabilities |  | 98,354 |  |  | 110,478 |  |
| Accrued income taxes |  | 23,468 |  |  | 19,186 |  |
| Current portion of long-term debt |  | 25,000 |  |  | — |  |
| Total current liabilities |  | 326,545 |  |  | 275,648 |  |
| Long-term debt, less current portion |  | 623,865 |  |  | 687,034 |  |
| Deferred income taxes |  | 51,229 |  |  | 50,134 |  |
| Accrued post-retirement benefits |  | 42,894 |  |  | 45,802 |  |
| Non-current operating lease liabilities |  | 14,190 |  |  | 12,950 |  |
| Other long-term liabilities |  | 67,410 |  |  | 67,252 |  |
| Total equity |  | 1,660,737 |  |  | 1,608,773 |  |
| Total liabilities and equity |  | $ | 2,786,870 |  |  | $ | 2,747,593 |  |

[0000889331-21-000032:8k_2_02:43]
LITTELFUSE, INC.

[0000889331-21-000032:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-21-000032:8k_2_02:45]
(Unaudited)

[0000889331-21-000032:8k_2_02:46]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share data) |  | March 27,2021 |  | March 28,2020 |  |  |  |  |
| Net sales |  | $ | 463,794 |  |  | $ | 346,096 |  |  |  |  |  |
| Cost of sales |  | 303,328 |  |  | 221,740 |  |  |  |  |  |
| Gross profit |  | 160,466 |  |  | 124,356 |  |  |  |  |  |
| Selling, general, and administrative expenses |  | 58,288 |  |  | 51,200 |  |  |  |  |  |
| Research and development expenses |  | 14,739 |  |  | 14,463 |  |  |  |  |  |
| Amortization of intangibles |  | 10,521 |  |  | 9,981 |  |  |  |  |  |
| Restructuring, impairment, and other charges |  | 437 |  |  | 3,962 |  |  |  |  |  |
| Total operating expenses |  | 83,985 |  |  | 79,606 |  |  |  |  |  |
| Operating income |  | 76,481 |  |  | 44,750 |  |  |  |  |  |
| Interest expense |  | 4,673 |  |  | 5,418 |  |  |  |  |  |
| Foreign exchange loss |  | 6,837 |  |  | 2,584 |  |  |  |  |  |
| Other (income) expense, net |  | (7,737) |  |  | 1,249 |  |  |  |  |  |
| Income before income taxes |  | 72,708 |  |  | 35,499 |  |  |  |  |  |
| Income taxes |  | 14,995 |  |  | 10,855 |  |  |  |  |  |
| Net income |  | $ | 57,713 |  |  | $ | 24,644 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.35 |  |  | $ | 1.01 |  |  |  |  |  |
| Diluted |  | $ | 2.32 |  |  | $ | 1.00 |  |  |  |  |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,532 |  |  | 24,393 |  |  |  |  |  |
| Diluted |  | 24,892 |  |  | 24,578 |  |  |  |  |  |
| Comprehensive income |  | $ | 52,842 |  |  | $ | 9,665 |  |  |  |  |  |

[0000889331-21-000032:8k_2_02:47]
LITTELFUSE, INC.

[0000889331-21-000032:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-21-000032:8k_2_02:49]
(Unaudited)

[0000889331-21-000032:8k_2_02:50]
|  |  | Three Months Ended |
| (in thousands) |  | March 27, 2021 |  | March 28, 2020 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 57,713 |  |  | $ | 24,644 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 32,165 |  |  | 35,626 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (32,973) |  |  | (9,457) |  |
| Inventories |  | (6,152) |  |  | 6,667 |  |
| Accounts payable |  | 17,070 |  |  | (3,964) |  |
| Accrued liabilities and income taxes |  | (15,427) |  |  | (7,012) |  |
| Prepaid expenses and other assets |  | (2,230) |  |  | (1,225) |  |
| Net cash provided by operating activities |  | 50,166 |  |  | 45,279 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (109,852) |  |  | — |  |
| Purchases of property, plant, and equipment |  | (14,721) |  |  | (16,586) |  |
| Net proceeds from sale of property, plant, and equipment |  | 2,553 |  |  | 50 |  |
| Net cash used in investing activities |  | (122,020) |  |  | (16,536) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net (payments) proceeds from credit facility |  | (30,000) |  |  | 97,500 |  |
| Purchases of common stock |  | — |  |  | (22,927) |  |
| Cash dividends paid |  | (11,782) |  |  | (11,725) |  |
| All other cash provided by financing activities |  | 7,509 |  |  | 2,956 |  |
| Net cash (used in) provided by financing activities |  | (34,273) |  |  | 65,804 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (4,101) |  |  | (5,111) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (110,228) |  |  | 89,436 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 687,525 |  |  | 531,139 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 577,297 |  |  | $ | 620,575 |  |

[0000889331-21-000032:8k_2_02:51]
LITTELFUSE, INC.

[0000889331-21-000032:8k_2_02:52]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-21-000032:8k_2_02:53]
(Unaudited)

[0000889331-21-000032:8k_2_02:54]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2021 |  | 2020 |  |  |  | %Growth /(Decline) |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 286,535 |  |  | $ | 214,189 |  |  |  |  | 33.8 | % |  |  |  |  |  |  |  |  |
| Automotive |  | 128,529 |  |  | 104,770 |  |  |  |  | 22.7 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 48,730 |  |  | 27,137 |  |  |  |  | 79.6 | % |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 463,794 |  |  | $ | 346,096 |  |  |  |  | 34.0 | % |  |  |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 55,523 |  |  | $ | 32,272 |  |  |  |  | 72.0 | % |  |  |  |  |  |  |  |  |
| Automotive |  | 20,316 |  |  | 14,116 |  |  |  |  | 43.9 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 3,506 |  |  | 3,534 |  |  |  |  | (0.8) | % |  |  |  |  |  |  |  |  |
| Other(a) |  | (2,864) |  |  | (5,172) |  |  |  |  | N.M. |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 76,481 |  |  | $ | 44,750 |  |  |  |  | 70.9 | % |  |  |  |  |  |  |  |  |
| Operating Margin |  | 16.5 | % |  | 12.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 4,673 |  |  | 5,418 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange loss |  | 6,837 |  |  | 2,584 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other (income) expense, net |  | (7,737) |  |  | 1,249 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 72,708 |  |  | $ | 35,499 |  |  |  |  | 104.8 | % |  |  |  |  |  |  |  |  |

[0000889331-21-000032:8k_2_02:55]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-21-000032:8k_2_02:56]
N.M. - Not meaningful

[0000889331-21-000032:8k_2_02:57]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2021 |  | 2020 |  | %Growth /(Decline) |  |  |  |  |  |  |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 19.4 | % |  | 15.1 | % |  | 4.3 | % |  |  |  |  |  |  |
| Automotive |  | 15.8 | % |  | 13.5 | % |  | 2.3 | % |  |  |  |  |  |  |
| Industrial |  | 7.2 | % |  | 13.0 | % |  | (5.8) | % |  |  |  |  |  |  |

[0000889331-21-000032:8k_2_02:58]
LITTELFUSE, INC.

[0000889331-21-000032:8k_2_02:59]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-21-000032:8k_2_02:60]
(In millions of USD except per share amounts - unaudited)

[0000889331-21-000032:8k_2_02:61]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-21 |  | Q1-20 |  |  |  |  |
| GAAP diluted EPS |  | $ | 2.32 |  |  | $ | 1.00 |  |  |  |  |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.35 |  |  | 0.29 |  |  |  |  |  |
| Adjusted diluted EPS |  | $ | 2.67 |  |  | $ | 1.29 |  |  |  |  |  |

[0000889331-21-000032:8k_2_02:62]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q1-21 |  | Q1-20 |  |  |  |  |
| Acquisition-related and integration costs (a) |  | $ | 0.8 |  |  | $ | 1.2 |  |  |  |  |  |
| Purchase accounting inventory adjustments (b) |  | 3.5 |  |  | — |  |  |  |  |  |
| Restructuring, impairment and other charges (c) |  | 0.4 |  |  | 4.0 |  |  |  |  |  |
| Gain on sale of fixed assets (d) |  | (1.9) |  |  | — |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 2.8 |  |  | 5.2 |  |  |  |  |  |
| Non-operating foreign exchange loss |  | 6.8 |  |  | 2.6 |  |  |  |  |  |
| Non-GAAP adjustments to income before income taxes |  | 9.6 |  |  | 7.8 |  |  |  |  |  |
| Income taxes (e) |  | 0.8 |  |  | 0.6 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | $ | 8.8 |  |  | $ | 7.2 |  |  |  |  |  |
| Total EPS impact |  | $ | 0.35 |  |  | $ | 0.29 |  |  |  |  |  |

[0000889331-21-000032:8k_2_02:63]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-21 |  | Q1-20 |  |  |  |  |
| Net sales |  | $ | 463.8 |  |  | $ | 346.1 |  |  |  |  |  |
| GAAP operating income |  | 76.5 |  |  | $ | 44.8 |  |  |  |  |  |
| Add back non-GAAP adjustments |  | 2.8 |  |  | 5.2 |  |  |  |  |  |
| Adjusted operating income |  | $ | 79.3 |  |  | $ | 50.0 |  |  |  |  |  |
| Adjusted operating margin |  | 17.1 | % |  | 14.4 | % |  |  |  |  |
| Add back amortization |  | 10.5 |  |  | 10.0 |  |  |  |  |  |
| Add back depreciation |  | 13.7 |  |  | 13.8 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 103.5 |  |  | $ | 73.8 |  |  |  |  |  |
| Adjusted EBITDA margin |  | 22.3 | % |  | 21.3 | % |  |  |  |  |

[0000889331-21-000032:8k_2_02:64]
| Net sales reconciliation |  | Q1-21 vs. Q1-20 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | 34 | % |  | 23 | % |  | 80 | % |  | 34 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — |  |  | — |  |  | 62 | % |  | 5 | % |
| Transfer a product line between segments |  | (1) | % |  | — | % |  | 7 | % |  | — | % |
| FX impact |  | 3 | % |  | 6 | % |  | 1 | % |  | 3 | % |
| Organic net sales growth |  | 32 | % |  | 17 | % |  | 10 | % |  | 26 | % |

[0000889331-21-000032:8k_2_02:65]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-21 |  | Q1-20 |  |  |  |  |
| Income taxes |  | $ | 15.0 |  |  | $ | 10.9 |  |  |  |  |  |
| Effective rate |  | 20.6 | % |  | 30.6 | % |  |  |  |  |
| Non-GAAP adjustments - income taxes |  | 0.8 |  |  | 0.6 |  |  |  |  |  |
| Adjusted income taxes |  | $ | 15.8 |  |  | $ | 11.5 |  |  |  |  |  |
| Adjusted effective rate |  | 19.2 | % |  | 26.5 | % |  |  |  |  |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-21 |  | Q1-20 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 50.2 |  |  | $ | 45.3 |  |  |  |  |  |
| Less: Purchases of property, plant and equipment |  | (14.7) |  |  | (16.6) |  |  |  |  |  |
| Free cash flow |  | $ | 35.4 |  |  | $ | 28.7 |  |  |  |  |  |

[0000889331-21-000032:8k_2_02:66]
| Consolidated Total Debt |  | As of March 27, 2021 |
| Consolidated total gross debt |  | $ | 652.8 |  |
| Unamortized debt issuance costs |  | (3.9) |  |
| Consolidated Total Debt |  | $ | 648.9 |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | Twelve Months Ended March 27, 2021 |
| Net Income |  | $ | 163.1 |  |
| Interest expense |  | 20.3 |  |
| Income taxes |  | 35.4 |  |
| Depreciation |  | 56.0 |  |
| Amortization |  | 40.6 |  |
| Non-cash additions (reductions): |  |  |
| Stock-based compensation expense |  | 18.5 |  |
| Purchase accounting inventory step-up charge |  | 3.5 |  |
| Unrealized gain on investments |  | (14.9) |  |
| Impairment charges |  | 33.8 |  |
| Other |  | (6.6) |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | $ | 349.7 |  |
| Ratio of Consolidated total gross debt to Consolidated EBITDA (as defined in Private Placement Senior Notes)* |  | 1.9x |

[0000889331-21-000032:8k_2_02:67]
* Our Private Placement Senior Notes, with maturities ranging from 2022 to 2030, contain a financial ratio covenant providing that if, as of the last day of each fiscal quarter, the ratio of Consolidated total gross debt at such time to Consolidated EBITDA for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Private Placement Senior Notes) is triggered

[0000889331-21-000032:8k_2_02:68]
(1) Represents Consolidated EBITDA as defined in our Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters

[0000889331-21-000032:8k_2_02:69]
Note: Total will not always foot due to rounding.

[0000889331-21-000032:8k_2_02:70]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-21-000032:8k_2_02:71]
(b) reflected in cost of sales.

[0000889331-21-000032:8k_2_02:72]
(c) For the fiscal year ended December 26, 2020, the Company presented restructuring, impairment and other charges as a separate caption in the Consolidated Statements of Net Income. Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements.

[0000889331-21-000032:8k_2_02:73]
(d) reflected in SG&A. 2021 quarter-to-date included a $1.9 million gain from the sale of a building in the Electronics segment.

[0000889331-21-000032:8k_2_02:74]
(e) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-21-000032:8k_2_02:75]
###
