# LFUS 8-K — 0001628280-25-046908 filed 2025-10-29

## item codes, every 8-K on or before 2025-10-29

- 2025-10-29 0001628280-25-046908 — 2.02, 7.01, 9.01
- 2025-10-28 0000889331-25-000186 — 1.01, 7.01, 9.01
- 2025-08-07 0000889331-25-000151 — 5.02, 7.01, 9.01
- 2025-07-30 0001628280-25-036551 — 2.02, 7.01, 9.01
- 2025-05-27 0000889331-25-000109 — 5.02, 7.01, 9.01
- 2025-04-29 0000889331-25-000095 — 2.02, 7.01, 9.01
- 2025-04-28 0000889331-25-000082 — 5.02, 5.07, 9.01
- 2025-04-09 0001140361-25-012942 — 5.02, 7.01, 9.01
- 2025-01-28 0000889331-25-000013 — 2.02, 7.01, 9.01
- 2025-01-13 0001140361-25-000873 — 5.02, 9.01
- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2025-10-29

- 2025-02-27 0001140361-25-006294 — NT 10-K, for the period ended 2024-12-28
- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-046908:8k_2_02:1]
EX-99.1
2
q32025earningsreleaseex991.htm
EX-99.1

[0001628280-25-046908:8k_2_02:2]
Document

[0001628280-25-046908:8k_2_02:3]
Exhibit 99.1

[0001628280-25-046908:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0001628280-25-046908:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS FOR 2025

[0001628280-25-046908:8k_2_02:6]
Third Quarter 2025 Highlights:

[0001628280-25-046908:8k_2_02:7]
(Year-over-year comparisons unless otherwise noted)

[0001628280-25-046908:8k_2_02:8]
•Net sales of $625 million, +10%; organic growth contributed +6.5%

[0001628280-25-046908:8k_2_02:9]
•GAAP diluted earnings per share of $2.77, +19%

[0001628280-25-046908:8k_2_02:10]
•Adjusted diluted earnings per share of $2.95, +9%

[0001628280-25-046908:8k_2_02:11]
•GAAP Operating margin of 15.6%, +10 bps; Adjusted EBITDA margin of 21.5%, (-20 bps)

[0001628280-25-046908:8k_2_02:12]
•YTD Cash flow from operations of $295 million and free cash flow of $246 million; YTD cash conversion of 145%

[0001628280-25-046908:8k_2_02:13]
CHICAGO, October 29, 2025  - Littelfuse, Inc. (NASDAQ: LFUS), a leader in developing smart solutions that enable safe and efficient electrical energy transfer, today reported financial results for  the third quarter ended September 27, 2025:

[0001628280-25-046908:8k_2_02:14]
“We are pleased with our third quarter performance as we delivered strong revenue growth versus the prior year while our adjusted diluted earnings exceeded the high end of our guidance range reflecting solid execution amid mixed end market conditions,” said Greg Henderson, Littelfuse President and Chief Executive Officer. “Across our segments, we are leveraging our leadership position in safe and efficient electrical energy transfer to accelerate our growth opportunities.”

[0001628280-25-046908:8k_2_02:15]
Acquisition of Basler Electric

[0001628280-25-046908:8k_2_02:16]
“We are also excited to announce the upcoming acquisition of Basler Electric, as disclosed yesterday (Link to Release), a leader in electrical control and protection solutions for industrial markets. Basler will expand our high growth market opportunities, enhance our high power technology capabilities, and broaden our industrial customer exposure. We look forward to welcoming the Basler team to Littelfuse and to leveraging our complementary technologies, engineering capabilities and manufacturing footprint to drive long-term growth, profitability enhancements, and shareholder value.”

[0001628280-25-046908:8k_2_02:17]
-more-

[0001628280-25-046908:8k_2_02:18]
Fourth Quarter of 2025*

[0001628280-25-046908:8k_2_02:19]
Looking ahead to the fourth quarter, we expect +10% revenue growth versus the prior year given our strong backlog and customer positioning. Although we expect typical fourth quarter seasonality and see continued mixed end market conditions, we remain focused on driving innovations with our customers while delivering operational enhancements. We will continue to execute on our strategic priorities as we aim to scale our company, with the goal of delivering long-term best-in-class performance and shareholder returns.

[0001628280-25-046908:8k_2_02:20]
Based on current market conditions, for the fourth quarter the company expects,

[0001628280-25-046908:8k_2_02:21]
•Net sales in the range of $570 - $590 million, adjusted diluted EPS in the range of $2.40 – $2.60 and an adjusted effective tax rate of 22%

[0001628280-25-046908:8k_2_02:22]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001628280-25-046908:8k_2_02:23]
Third Quarter 2025 Segment Performance Highlights

[0001628280-25-046908:8k_2_02:24]
Electronics Segment

[0001628280-25-046908:8k_2_02:25]
•Net sales for the third quarter 2025 increased +18%. Organic sales increased +12% driven by improved passive products (+19% organic) demand from OEM customers and distributors. Semiconductor product (+5% organic) sales also contributed to growth driven by improved protection semiconductor demand in-part offset by lower power semiconductor volumes. The Dortmund Fab acquisition also contributed +4% to growth.

[0001628280-25-046908:8k_2_02:26]
•Adjusted EBITDA margin for the third quarter 2025 increased to 24.0% (+140 bps) primarily due to strong passive products and protection volume leverage, which more than offset continued soft power semiconductor volumes and higher stock and variable compensation.

[0001628280-25-046908:8k_2_02:27]
Transportation Segment

[0001628280-25-046908:8k_2_02:28]
•Net sales for the third quarter 2025 were flat as favorable FX impact of +2% was offset by lower organic sales. Organic sales decreased -2% driven by lower commercial vehicle sales (-3% organic), reflecting softer on-highway, off-road and agriculture end market demand. Passenger car organic sales were flat reflecting stable passenger car product demand offset by sensor declines.

[0001628280-25-046908:8k_2_02:29]
•Adjusted EBITDA margin for the third quarter 2025 decreased to 16.8% (-220 bps) driven by lower volume, the impact of higher stock and variable compensation, and unfavorable tariff timing.

[0001628280-25-046908:8k_2_02:30]
-more-

[0001628280-25-046908:8k_2_02:31]
Industrial Segment

[0001628280-25-046908:8k_2_02:32]
•Net sales for the third quarter 2025 increased +4%. Organic sales increased +4% driven by improved energy storage, renewables and data center demand in-part offset by lower HVAC and continued soft construction demand.

[0001628280-25-046908:8k_2_02:33]
•Adjusted EBITDA margin for the third quarter 2025 decreased to 20.7% (-310 bps) driven by unfavorable mix and higher stock and variable compensation.

[0001628280-25-046908:8k_2_02:34]
Dividend

[0001628280-25-046908:8k_2_02:35]
•The company will pay a cash dividend on its common stock of $0.75 per share on December 4, 2025, to shareholders of record as of November 20, 2025.

[0001628280-25-046908:8k_2_02:36]
Conference Call and Webcast Information

[0001628280-25-046908:8k_2_02:37]
Littelfuse will host a conference call on Wednesday, October 29, 2025, at 8:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0001628280-25-046908:8k_2_02:38]
About Littelfuse

[0001628280-25-046908:8k_2_02:39]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0001628280-25-046908:8k_2_02:40]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks, uncertainties and other factors include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; changes in import and export duty and tariff rates; exchange rate fluctuations; commodity price fluctuations; the effect of the Company's accounting policies; labor disputes and shortages; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; integration of acquisitions may not be achieved in a timely manner, or at all; limited realization of the expected benefits from investment and strategic plans; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with

[0001628280-25-046908:8k_2_02:41]
information provided in the financial statements appearing in the company's Annual Report on Form 10-K for  the year ended  December 28, 2024.

[0001628280-25-046908:8k_2_02:42]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 28, 2024, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0001628280-25-046908:8k_2_02:43]
Non-GAAP Financial Measures

[0001628280-25-046908:8k_2_02:44]
The information included in this press release and other materials filed with the SEC may include the non-GAAP financial measures including organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001628280-25-046908:8k_2_02:45]
LFUS-F

[0001628280-25-046908:8k_2_02:46]
###

[0001628280-25-046908:8k_2_02:47]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-25-046908:8k_2_02:48]
LITTELFUSE, INC.

[0001628280-25-046908:8k_2_02:49]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-046908:8k_2_02:50]
|  |  | (Unaudited) |  |  |
| (in thousands, except share and per share data) |  | September 27,2025 |  | December 28,2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 814,733 |  |  | $ | 724,924 |  |
| Short-term investments |  | 290 |  |  | 976 |  |
| Trade receivables, less allowances of $78,392 and $69,990 at September 27, 2025 and December 28, 2024, respectively |  | 373,827 |  |  | 294,371 |  |
| Inventories |  | 396,871 |  |  | 416,273 |  |
| Prepaid income taxes and income taxes receivable |  | 11,253 |  |  | 11,749 |  |
| Prepaid expenses and other current assets |  | 77,509 |  |  | 103,716 |  |
| Total current assets |  | 1,674,483 |  |  | 1,552,009 |  |
| Net property, plant, and equipment |  | 513,965 |  |  | 477,068 |  |
| Intangible assets, net of amortization |  | 458,776 |  |  | 482,118 |  |
| Goodwill |  | 1,356,038 |  |  | 1,228,502 |  |
| Investments |  | 21,329 |  |  | 23,245 |  |
| Deferred income taxes |  | 5,712 |  |  | 4,899 |  |
| Right of use lease assets |  | 87,116 |  |  | 72,211 |  |
| Other long-term assets |  | 56,940 |  |  | 51,727 |  |
| Total assets |  | $ | 4,174,359 |  |  | $ | 3,891,779 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 204,016 |  |  | $ | 188,359 |  |
| Accrued liabilities |  | 173,786 |  |  | 148,276 |  |
| Accrued income taxes |  | 24,302 |  |  | 29,658 |  |
| Current portion of long-term debt |  | 16,955 |  |  | 67,612 |  |
| Total current liabilities |  | 419,059 |  |  | 433,905 |  |
| Long-term debt, less current portion |  | 788,821 |  |  | 788,502 |  |
| Deferred income taxes |  | 103,917 |  |  | 95,532 |  |
| Accrued post-retirement benefits |  | 33,658 |  |  | 29,836 |  |
| Non-current lease liabilities |  | 73,415 |  |  | 60,559 |  |
| Other long-term liabilities |  | 83,374 |  |  | 69,833 |  |
| Total equity |  | 2,672,115 |  |  | 2,413,612 |  |
| Total liabilities and equity |  | $ | 4,174,359 |  |  | $ | 3,891,779 |  |

[0001628280-25-046908:8k_2_02:51]
LITTELFUSE, INC.

[0001628280-25-046908:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0001628280-25-046908:8k_2_02:53]
(Unaudited)

[0001628280-25-046908:8k_2_02:54]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) |  | September 27,2025 |  | September 28,2024 |  | September 27,2025 |  | September 28,2024 |
| Net sales |  | $ | 624,640 |  |  | $ | 567,390 |  |  | $ | 1,792,360 |  |  | $ | 1,661,263 |  |
| Cost of sales |  | 383,652 |  |  | 351,498 |  |  | 1,112,062 |  |  | 1,050,559 |  |
| Gross profit |  | 240,988 |  |  | 215,892 |  |  | 680,298 |  |  | 610,704 |  |
| Selling, general, and administrative expenses |  | 99,570 |  |  | 83,897 |  |  | 282,795 |  |  | 263,395 |  |
| Research and development expenses |  | 27,332 |  |  | 26,470 |  |  | 79,781 |  |  | 81,283 |  |
| Amortization of intangibles |  | 15,037 |  |  | 15,864 |  |  | 44,220 |  |  | 47,418 |  |
| Restructuring, impairment, and other charges |  | 1,633 |  |  | 1,840 |  |  | 13,158 |  |  | 10,329 |  |
| Total operating expenses |  | 143,572 |  |  | 128,071 |  |  | 419,954 |  |  | 402,425 |  |
| Operating income |  | 97,416 |  |  | 87,821 |  |  | 260,344 |  |  | 208,279 |  |
| Interest expense |  | 8,578 |  |  | 9,772 |  |  | 26,021 |  |  | 29,358 |  |
| Foreign exchange loss |  | 175 |  |  | 9,630 |  |  | 15,466 |  |  | 4,273 |  |
| Other income, net |  | (6,053) |  |  | (9,297) |  |  | (14,020) |  |  | (19,916) |  |
| Income before income taxes |  | 94,716 |  |  | 77,716 |  |  | 232,877 |  |  | 194,564 |  |
| Income taxes |  | 25,194 |  |  | 19,658 |  |  | 62,442 |  |  | 42,588 |  |
| Net income |  | $ | 69,522 |  |  | $ | 58,058 |  |  | $ | 170,435 |  |  | $ | 151,976 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.80 |  |  | $ | 2.34 |  |  | $ | 6.88 |  |  | $ | 6.12 |  |
| Diluted |  | $ | 2.77 |  |  | $ | 2.32 |  |  | $ | 6.82 |  |  | $ | 6.07 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,837 |  |  | 24,796 |  |  | 24,786 |  |  | 24,822 |  |
| Diluted |  | 25,102 |  |  | 25,025 |  |  | 24,989 |  |  | 25,040 |  |
| Comprehensive income |  | $ | 65,985 |  |  | $ | 114,451 |  |  | $ | 302,408 |  |  | $ | 157,011 |  |

[0001628280-25-046908:8k_2_02:55]
LITTELFUSE, INC.

[0001628280-25-046908:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-25-046908:8k_2_02:57]
(Unaudited)

[0001628280-25-046908:8k_2_02:58]
|  |  | Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 170,435 |  |  | $ | 151,976 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 131,627 |  |  | 101,437 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (64,552) |  |  | (50,672) |  |
| Inventories |  | 33,567 |  |  | 19,865 |  |
| Accounts payable |  | 12,757 |  |  | 5,460 |  |
| Accrued liabilities and income taxes |  | 611 |  |  | (19,434) |  |
| Prepaid expenses and other assets |  | 10,654 |  |  | (1,633) |  |
| Net cash provided by operating activities |  | 295,099 |  |  | 206,999 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (57,417) |  |  | — |  |
| Purchases of property, plant, and equipment |  | (48,697) |  |  | (50,065) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 6,413 |  |  | 8,931 |  |
| Net cash used in investing activities |  | (99,701) |  |  | (41,134) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (61,250) |  |  | (3,750) |  |
| Repurchases of common stock |  | (27,553) |  |  | (40,862) |  |
| Cash dividends paid |  | (53,311) |  |  | (49,687) |  |
| All other cash provided by financing activities |  | 15,840 |  |  | 3,000 |  |
| Net cash used in financing activities |  | (126,274) |  |  | (91,299) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 20,868 |  |  | (396) |  |
| Increase in cash, cash equivalents, and restricted cash |  | 89,992 |  |  | 74,170 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 726,437 |  |  | 557,123 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 816,429 |  |  | $ | 631,293 |  |

[0001628280-25-046908:8k_2_02:59]
LITTELFUSE, INC.

[0001628280-25-046908:8k_2_02:60]
NET SALES AND OPERATING INCOME BY SEGMENT

[0001628280-25-046908:8k_2_02:61]
(Unaudited)

[0001628280-25-046908:8k_2_02:62]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2025 |  | 2024 |  |  |  | %Growth/(Decline) |  | 2025 |  | 2024 |  |  |  | %Growth |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 357,457 |  |  | $ | 304,188 |  |  |  |  | 17.5 | % |  | $ | 1,000,372 |  |  | $ | 900,932 |  |  |  |  | 11.0 | % |
| Transportation |  | 171,311 |  |  | 171,381 |  |  |  |  | — | % |  | 512,573 |  |  | 510,711 |  |  |  |  | 0.4 | % |
| Industrial |  | 95,872 |  |  | 91,821 |  |  |  |  | 4.4 | % |  | 279,415 |  |  | 249,620 |  |  |  |  | 11.9 | % |
| Total net sales |  | $ | 624,640 |  |  | $ | 567,390 |  |  |  |  | 10.1 | % |  | $ | 1,792,360 |  |  | $ | 1,661,263 |  |  |  |  | 7.9 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 63,640 |  |  | $ | 48,891 |  |  |  |  | 30.2 | % |  | $ | 160,267 |  |  | $ | 132,859 |  |  |  |  | 20.6 | % |
| Transportation |  | 20,187 |  |  | 23,485 |  |  |  |  | (14.0) | % |  | 67,178 |  |  | 54,925 |  |  |  |  | 22.3 | % |
| Industrial |  | 16,918 |  |  | 17,711 |  |  |  |  | (4.5) | % |  | 48,855 |  |  | 32,054 |  |  |  |  | 52.4 | % |
| Other (a) |  | (3,329) |  |  | (2,266) |  |  |  |  | N.M. |  | (15,956) |  |  | (11,559) |  |  |  |  | N.M. |
| Total operating income |  | $ | 97,416 |  |  | $ | 87,821 |  |  |  |  | 10.9 | % |  | $ | 260,344 |  |  | $ | 208,279 |  |  |  |  | 25.0 | % |
| Operating Margin |  | 15.6 | % |  | 15.5 | % |  |  |  |  |  | 14.5 | % |  | 12.5 | % |  |  |  |  |
| Interest expense |  | 8,578 |  |  | 9,772 |  |  |  |  |  |  | 26,021 |  |  | 29,358 |  |  |  |  |  |
| Foreign exchange loss |  | 175 |  |  | 9,630 |  |  |  |  |  |  | 15,466 |  |  | 4,273 |  |  |  |  |  |
| Other income, net |  | (6,053) |  |  | (9,297) |  |  |  |  |  |  | (14,020) |  |  | (19,916) |  |  |  |  |  |
| Income before income taxes |  | $ | 94,716 |  |  | $ | 77,716 |  |  |  |  | 21.9 | % |  | $ | 232,877 |  |  | $ | 194,564 |  |  |  |  | 19.7 | % |

[0001628280-25-046908:8k_2_02:63]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments, and restructuring and impairment charges. See Supplemental Financial Information for details.

[0001628280-25-046908:8k_2_02:64]
N.M. - Not meaningful

[0001628280-25-046908:8k_2_02:65]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2025 |  | 2024 |  | %Growth/(Decline) |  | 2025 |  | 2024 |  | %Growth |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 17.8 | % |  | 16.1 | % |  | 1.7 | % |  | 16.0 | % |  | 14.7 | % |  | 1.3 | % |
| Transportation |  | 11.8 | % |  | 13.7 | % |  | (1.9) | % |  | 13.1 | % |  | 10.8 | % |  | 2.3 | % |
| Industrial |  | 17.6 | % |  | 19.3 | % |  | (1.7) | % |  | 17.5 | % |  | 12.8 | % |  | 4.7 | % |

[0001628280-25-046908:8k_2_02:66]
LITTELFUSE, INC.

[0001628280-25-046908:8k_2_02:67]
SUPPLEMENTAL FINANCIAL INFORMATION

[0001628280-25-046908:8k_2_02:68]
(In millions of USD except per share amounts - unaudited)

[0001628280-25-046908:8k_2_02:69]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-25 |  | Q3-24 |  | YTD-25 |  | YTD-24 |
| GAAP diluted EPS |  | $ | 2.77 |  |  | $ | 2.32 |  |  | $ | 6.82 |  |  | $ | 6.07 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.18 |  |  | 0.39 |  |  | 1.17 |  |  | 0.37 |  |
| Adjusted diluted EPS |  | $ | 2.95 |  |  | $ | 2.71 |  |  | $ | 7.99 |  |  | $ | 6.44 |  |

[0001628280-25-046908:8k_2_02:70]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q3-25 |  | Q3-24 |  | YTD-25 |  | YTD-24 |
| Acquisition-related and integration costs (a) |  | $ | 1.4 |  |  | $ | 1.0 |  |  | $ | 3.0 |  |  | $ | 2.8 |  |
| Purchase accounting inventory adjustments (b) |  | — |  |  | — |  |  | (0.5) |  |  | — |  |
| Restructuring, impairment and other charges (c) |  | 1.6 |  |  | 1.8 |  |  | 13.2 |  |  | 10.3 |  |
| Gain on sale of fixed assets (d) |  | — |  |  | (0.5) |  |  | — |  |  | (1.5) |  |
| Loss on sale of the Marine business (e) |  | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |
| Non-GAAP adjustments to operating income |  | 3.3 |  |  | 2.3 |  |  | 16.0 |  |  | 11.6 |  |
| Other income, net (f) |  | — |  |  | — |  |  | — |  |  | (0.3) |  |
| Non-operating foreign exchange loss |  | 0.2 |  |  | 9.6 |  |  | 15.5 |  |  | 4.3 |  |
| Non-GAAP adjustments to income before income taxes |  | 3.5 |  |  | 11.9 |  |  | 31.5 |  |  | 15.6 |  |
| Income taxes (g) |  | (1.0) |  |  | 2.1 |  |  | 2.2 |  |  | 6.2 |  |
| Non-GAAP adjustments to net income |  | $ | 4.5 |  |  | $ | 9.8 |  |  | $ | 29.3 |  |  | $ | 9.4 |  |
| Total EPS impact |  | $ | 0.18 |  |  | $ | 0.39 |  |  | $ | 1.17 |  |  | $ | 0.37 |  |

[0001628280-25-046908:8k_2_02:71]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-25 |  | Q3-24 |  | YTD-25 |  | YTD-24 |
| Net income |  | $ | 69.5 |  |  | $ | 58.1 |  |  | $ | 170.4 |  |  | $ | 152.0 |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 25.2 |  |  | 19.7 |  |  | 62.4 |  |  | 42.6 |  |
| Interest expense |  | 8.6 |  |  | 9.8 |  |  | 26.0 |  |  | 29.4 |  |
| Foreign exchange loss |  | 0.2 |  |  | 9.6 |  |  | 15.5 |  |  | 4.3 |  |
| Other income, net |  | (6.1) |  |  | (9.3) |  |  | (14.0) |  |  | (19.9) |  |
| GAAP operating income |  | $ | 97.4 |  |  | $ | 87.8 |  |  | $ | 260.3 |  |  | $ | 208.3 |  |
| Non-GAAP adjustments to operating income |  | 3.3 |  |  | 2.3 |  |  | 16.0 |  |  | 11.6 |  |
| Adjusted operating income |  | $ | 100.7 |  |  | $ | 90.1 |  |  | $ | 276.3 |  |  | $ | 219.9 |  |
| Amortization of intangibles |  | 15.0 |  |  | 15.9 |  |  | 44.2 |  |  | 47.4 |  |
| Depreciation expense |  | 18.6 |  |  | 17.3 |  |  | 56.4 |  |  | 51.0 |  |
| Adjusted EBITDA |  | $ | 134.3 |  |  | $ | 123.3 |  |  | $ | 376.9 |  |  | $ | 318.3 |  |
| Net sales |  | $ | 624.6 |  |  | $ | 567.4 |  |  | $ | 1,792.4 |  |  | $ | 1,661.3 |  |
| Net income as a percentage of net sales |  | 11.1 | % |  | 10.2 | % |  | 9.5 | % |  | 9.1 | % |
| Operating margin |  | 15.6 | % |  | 15.5 | % |  | 14.5 | % |  | 12.5 | % |
| Adjusted operating margin |  | 16.1 | % |  | 15.9 | % |  | 15.4 | % |  | 13.2 | % |
| Adjusted EBITDA margin |  | 21.5 | % |  | 21.7 | % |  | 21.0 | % |  | 19.2 | % |

[0001628280-25-046908:8k_2_02:72]
| Adjusted EBITDA by Segment |  | Q3-25 |  | Q3-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 63.6 |  |  | $ | 20.2 |  |  | $ | 16.9 |  |  | $ | 48.9 |  |  | $ | 23.5 |  |  | $ | 17.7 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 10.2 |  |  | 3.4 |  |  | 1.4 |  |  | 9.9 |  |  | 3.4 |  |  | 2.6 |  |
| Add back depreciation |  | 12.0 |  |  | 5.1 |  |  | 1.5 |  |  | 10.1 |  |  | 5.7 |  |  | 1.5 |  |
| Adjusted EBITDA |  | $ | 85.8 |  |  | $ | 28.7 |  |  | $ | 19.8 |  |  | $ | 68.9 |  |  | $ | 32.6 |  |  | $ | 21.8 |  |
| Adjusted EBITDA Margin |  | 24.0 | % |  | 16.8 | % |  | 20.7 | % |  | 22.6 | % |  | 19.0 | % |  | 23.8 | % |

[0001628280-25-046908:8k_2_02:73]
| Adjusted EBITDA by Segment |  | YTD-25 |  | YTD-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 160.3 |  |  | $ | 67.2 |  |  | $ | 48.9 |  |  | $ | 132.9 |  |  | $ | 54.9 |  |  | $ | 32.1 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 30.1 |  |  | 10.2 |  |  | 3.9 |  |  | 29.6 |  |  | 10.1 |  |  | 7.7 |  |
| Add back depreciation |  | 35.9 |  |  | 15.9 |  |  | 4.6 |  |  | 30.1 |  |  | 16.7 |  |  | 4.2 |  |
| Adjusted EBITDA |  | $ | 226.3 |  |  | $ | 93.3 |  |  | $ | 57.3 |  |  | $ | 192.5 |  |  | $ | 81.8 |  |  | $ | 44.0 |  |
| Adjusted EBITDA Margin |  | 22.6 | % |  | 18.2 | % |  | 20.5 | % |  | 21.4 | % |  | 16.0 | % |  | 17.6 | % |

[0001628280-25-046908:8k_2_02:74]
| Net sales reconciliation |  | Q3-25 vs. Q3-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 18 | % |  | — | % |  | 4 | % |  | 10 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | — | % |  | — | % |  | 2 | % |
| FX impact |  | 2 | % |  | 2 | % |  | — | % |  | 1 | % |
| Organic net sales growth (decline) |  | 12 | % |  | (2) | % |  | 4 | % |  | 7 | % |

[0001628280-25-046908:8k_2_02:75]
| Electronics segment net sales reconciliation |  | Q3-25 vs. Q3-24 |
|  |  | Electronics - Semiconductor |  | Electronics - Passive Products and Sensors |  | Total Electronics |
| Net sales growth |  | 15 | % |  | 20 | % |  | 18 | % |
| Less: |  |  |  |  |  |  |
| Acquisitions |  | 9 | % |  | — | % |  | 4 | % |
| FX impact |  | 1 | % |  | 1 | % |  | 2 | % |
| Organic net sales growth |  | 5 | % |  | 19 | % |  | 12 | % |

[0001628280-25-046908:8k_2_02:76]
| Transportation segment net sales reconciliation |  | Q3-25 vs. Q3-24 |
|  |  | Commercial Vehicle Products |  | Passenger Car Products (1) |  | Auto Sensor Products (1) |  | Total Transportation |
| Net sales growth |  | (2) | % |  | 6 | % |  | (14) | % |  | — | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | 1 | % |  | 2 | % |  | 4 | % |  | 2 | % |
| Organic net sales (decline) growth |  | (3) | % |  | 4 | % |  | (18) | % |  | (2) | % |

[0001628280-25-046908:8k_2_02:77]
(1) Passenger vehicle business (PVB) includes passenger car and auto sensor products.

[0001628280-25-046908:8k_2_02:78]
| Net sales reconciliation |  | YTD-25 vs. YTD-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 11 | % |  | — | % |  | 12 | % |  | 8 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | — | % |  | — | % |  | 2 | % |
| FX impact |  | — | % |  | — | % |  | — | % |  | 1 | % |
| Organic net sales growth |  | 7 | % |  | — | % |  | 12 | % |  | 5 | % |

[0001628280-25-046908:8k_2_02:79]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-25 |  | Q3-24 |  | YTD-25 |  | YTD-24 |
| Income taxes |  | $ | 25.2 |  |  | $ | 19.7 |  |  | $ | 62.4 |  |  | $ | 42.6 |  |
| Effective rate |  | 26.6 | % |  | 25.3 | % |  | 26.8 | % |  | 21.9 | % |
| Non-GAAP adjustments - income taxes |  | (1.0) |  |  | 2.1 |  |  | 2.2 |  |  | 6.2 |  |
| Adjusted income taxes |  | $ | 24.2 |  |  | $ | 21.8 |  |  | $ | 64.6 |  |  | $ | 48.8 |  |
| Adjusted effective rate |  | 24.6 | % |  | 24.3 | % |  | 24.5 | % |  | 23.2 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-25 |  | Q3-24 |  | YTD-25 |  | YTD-24 |
| Net cash provided by operating activities |  | $ | 146.9 |  |  | $ | 80.4 |  |  | $ | 295.1 |  |  | $ | 207.0 |  |
| Less: Purchases of property, plant, and equipment |  | (15.7) |  |  | (15.4) |  |  | (48.7) |  |  | (50.1) |  |
| Free cash flow |  | $ | 131.2 |  |  | $ | 65.0 |  |  | $ | 246.4 |  |  | $ | 156.9 |  |

[0001628280-25-046908:8k_2_02:80]
| Consolidated Total Debt |  | As of September 27, 2025 |
| Consolidated Total Debt |  | $ | 805.8 |  |
| Unamortized debt issuance costs |  | 2.1 |  |
| Finance lease liability |  | 0.3 |  |
| Consolidated funded indebtedness |  | 808.2 |  |
| Cash held in U.S. (up to $400 million) |  | 345.0 |
| Net debt |  | $ | 463.2 |  |
| Consolidated EBITDA |  | Twelve Months Ended September 27, 2025 |
| Net Income |  | $ | 118.5 |  |
| Interest expense |  | 35.4 |  |
| Income taxes |  | 71.5 |  |
| Depreciation |  | 73.7 |  |
| Amortization |  | 58.9 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 26.3 |  |
| Unrealized loss on investments |  | 3.9 |  |
| Impairment charges |  | 92.7 |  |
| Other |  | 29.9 |  |
| Consolidated EBITDA (1) |  | $ | 510.8 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 0.9x |

[0001628280-25-046908:8k_2_02:81]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2025 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0001628280-25-046908:8k_2_02:82]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0001628280-25-046908:8k_2_02:83]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0001628280-25-046908:8k_2_02:84]
Note: Total will not always foot due to rounding.

[0001628280-25-046908:8k_2_02:85]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0001628280-25-046908:8k_2_02:86]
(b) reflected in cost of sales.

[0001628280-25-046908:8k_2_02:87]
(c) reflected in restructuring, impairment and other charges.

[0001628280-25-046908:8k_2_02:88]
(d) 2024 amount reflected a gain of $0.5 million ($1.5 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0001628280-25-046908:8k_2_02:89]
(e) Q3 2025 amount reflected $0.3 million loss related to the sale of the Marine business within the Transportation segment.

[0001628280-25-046908:8k_2_02:90]
(f) 2024 year-to-date included a reversal of $0.5 million for an asset retirement obligation charge related the disposal of a business in 2019 and $0.2 million increase in coal mining reserves.

[0001628280-25-046908:8k_2_02:91]
(g) reflected the tax impact associated with the non-GAAP adjustments.

[0001628280-25-046908:8k_2_02:92]
###
