# LFUS 10-Q controls and the auditor's report


## item_4_controls

[0001628280-25-047026:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001628280-25-047026:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001628280-25-047026:item_4_controls:3]
Disclosure controls and procedures (as defined in Rules 13a-15(b) and 15d-15(e) under the Exchange Act) are designed to ensure that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in the SEC rules and forms, and that such information is accumulated and communicated to management, including the Company's Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001628280-25-047026:item_4_controls:4]
In connection with the preparation of this report, management, under the supervision and with the participation of the Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of the Company's disclosure controls and procedures as of September 27, 2025. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer have concluded that, as of the quarter ended September 27, 2025, the Company's disclosure controls and procedures were not effective, because of the previously reported material weaknesses in internal control over financial reporting, as described below.

[0001628280-25-047026:item_4_controls:5]
Previously Reported Material Weaknesses in Internal Control over Financial Reporting

[0001628280-25-047026:item_4_controls:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Exchange Act Rule 13a-15(f) and 15d-15(f) based on the criteria established in Internal Control-Integrated Framework (2013)

[0001628280-25-047026:item_4_controls:7]
45

[0001628280-25-047026:item_4_controls:8]
issued by the Committee of Sponsoring Organizations of the Treadway Commission (“the COSO Framework). As reported in our Form 10-K for the fiscal year ended December 28, 2024, we did not maintain effective internal control over financial reporting as of December 28, 2024 as a result of material weaknesses in the control environment and control activities areas. A material weakness (as defined in Rule 12b-2 under the Exchange Act) is a deficiency, or combination of deficiencies, in internal control over financial reporting such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. Refer to our 2024 Form 10-K for a description of our material weaknesses.

[0001628280-25-047026:item_4_controls:9]
Ongoing Remediation Efforts to Address Material Weaknesses

[0001628280-25-047026:item_4_controls:10]
Our material weaknesses were not remediated as of September 27, 2025. Our management team is committed to maintaining a strong internal control environment. The Company, with oversight from our Audit Committee of the Board of Directors, is taking comprehensive actions to remediate the material weaknesses. The Company has developed and is in the process of implementing its remediation plan, which includes the following steps:

[0001628280-25-047026:item_4_controls:11]
Control Environment

[0001628280-25-047026:item_4_controls:12]
•recruiting of personnel with appropriate internal controls, and accounting knowledge and experience commensurate with our accounting and reporting requirements;

[0001628280-25-047026:item_4_controls:13]
•enhanced supervision of personnel at certain locations to ensure compliance with established Company policies; and

[0001628280-25-047026:item_4_controls:14]
•evaluating and updating (as appropriate) the sufficiency of policies and training provided to personnel to ensure the appropriate segregation of duties and adherence to the Code of Conduct.

[0001628280-25-047026:item_4_controls:15]
Control Activities

[0001628280-25-047026:item_4_controls:16]
•augmentation of training and clear instruction as to the process for recording of adjustments to inventories;

[0001628280-25-047026:item_4_controls:17]
•full physical inventory observations, facilitated by independent counters, until the cycle count and related inventory existence controls at certain of our non-U.S. manufacturing locations are operating effectively;

[0001628280-25-047026:item_4_controls:18]
•implementation of a management review control over inventory movements; and

[0001628280-25-047026:item_4_controls:19]
•examination and enhancement of the procedures to evaluate the completeness and accuracy of data and assumptions utilized in computing inventory reserves.

[0001628280-25-047026:item_4_controls:20]
The Company has made progress with a number of initiatives and actions to address the previously reported material weaknesses, which include the following:

[0001628280-25-047026:item_4_controls:21]
Control Environment

[0001628280-25-047026:item_4_controls:22]
•The Company has replaced certain key finance and operational roles at certain non-U.S. manufacturing locations, and continues to actively recruit the remaining open roles;

[0001628280-25-047026:item_4_controls:23]
•The Company is substantially complete with the redesign of the regional operations and finance organizational structures; and

[0001628280-25-047026:item_4_controls:24]
•New corporate policies and procedures have been adopted and disseminated along with training provided to strengthen the control environment and inventory management oversight.

[0001628280-25-047026:item_4_controls:25]
Control Activities

[0001628280-25-047026:item_4_controls:26]
•Key monitoring controls have been designed and implemented for cycle counts, full physical count, inventory storage locations, and excessive and obsolete inventory calculations; and

[0001628280-25-047026:item_4_controls:27]
•Full physical inventory observations, facilitated by independent counters, have been performed in certain non-U.S. locations in the second and third quarter of 2025 and will continue for the remainder of fiscal year 2025.

[0001628280-25-047026:item_4_controls:28]
We intend to remediate the material weaknesses as soon as possible; however, the material weaknesses will not be considered remediated until the applicable controls operate for a sufficient period of time and management has concluded, through testing, that the appropriate controls are operating effectively.

[0001628280-25-047026:item_4_controls:29]
Changes in Internal Control over Financial Reporting

[0001628280-25-047026:item_4_controls:30]
Other than the ongoing remediation efforts described above, there were no changes in the Company's internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15(f) and 15d-15(f) under the Exchange Act that occurred during the quarter ended September 27, 2025 that have materially affected, or are reasonably likely to materially affect, the Company's internal control over financial reporting.

[0001628280-25-047026:item_4_controls:31]
46
