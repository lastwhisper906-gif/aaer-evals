# LFUS notes — 0001628280-25-047026


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-25-047026:notes:1]
[same as prior period, unchanged from 0001628280-25-036650:notes:2]

[0001628280-25-047026:notes:2]
[same as prior period, unchanged from 0001628280-25-036650:notes:3]

[0001628280-25-047026:notes:3]
[same as prior period, unchanged from 0001628280-25-036650:notes:4]

[0001628280-25-047026:notes:4]
[same as prior period, unchanged from 0001628280-25-036650:notes:5]

[0001628280-25-047026:notes:5]
[same as prior period, unchanged from 0001628280-25-036650:notes:6]

[0001628280-25-047026:notes:6]
[same as prior period, unchanged from 0001628280-25-036650:notes:7]

[0001628280-25-047026:notes:7]
[same as prior period, unchanged from 0001628280-25-036650:notes:8]

[0001628280-25-047026:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 27, 2025 and September 28, 2024:

[0001628280-25-047026:notes:9]
|  |  | Three Months Ended September 27, 2025 |  | Nine Months Ended September 27, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 174,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 174,073 |  |  | $ | 499,329 |  |  | $ | — |  |  | $ | — |  |  | $ | 499,329 |  |
| Electronics – Passive Products and Sensors |  | 183,384 |  |  | — |  |  | — |  |  | 183,384 |  |  | 501,043 |  |  | — |  |  | — |  |  | 501,043 |  |
| Commercial Vehicle Products |  | — |  |  | 80,272 |  |  | — |  |  | 80,272 |  |  | — |  |  | 244,301 |  |  | — |  |  | 244,301 |  |
| Passenger Car Products |  | — |  |  | 75,636 |  |  | — |  |  | 75,636 |  |  | — |  |  | 220,822 |  |  | — |  |  | 220,822 |  |
| Automotive Sensors |  | — |  |  | 15,403 |  |  | — |  |  | 15,403 |  |  | — |  |  | 47,450 |  |  | — |  |  | 47,450 |  |
| Industrial Products |  | — |  |  | — |  |  | 95,872 |  |  | 95,872 |  |  | — |  |  | — |  |  | 279,415 |  |  | 279,415 |  |
| Total |  | $ | 357,457 |  |  | $ | 171,311 |  |  | $ | 95,872 |  |  | $ | 624,640 |  |  | $ | 1,000,372 |  |  | $ | 512,573 |  |  | $ | 279,415 |  |  | $ | 1,792,360 |  |

[0001628280-25-047026:notes:10]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

[0001628280-25-047026:notes:11]
[same as prior period, unchanged from 0001628280-25-036650:notes:12]

[0001628280-25-047026:notes:12]
[same as prior period, unchanged from 0001628280-25-036650:notes:13]

[0001628280-25-047026:notes:13]
[same as prior period, unchanged from 0001628280-25-036650:notes:14]

[0001628280-25-047026:notes:14]
[same as prior period, unchanged from 0001628280-25-036650:notes:15]

[0001628280-25-047026:notes:15]
[same as prior period, unchanged from 0001628280-25-036650:notes:16]

[0001628280-25-047026:notes:16]
[same as prior period, unchanged from 0001628280-25-036650:notes:17]

[0001628280-25-047026:notes:17]
[same as prior period, unchanged from 0001628280-25-036650:notes:18]

[0001628280-25-047026:notes:18]
[same as prior period, unchanged from 0001628280-25-036650:notes:19]

[0001628280-25-047026:notes:19]
[same as prior period, unchanged from 0001628280-25-036650:notes:20]

[0001628280-25-047026:notes:20]
[same as prior period, unchanged from 0001628280-25-036650:notes:21]

[0001628280-25-047026:notes:21]
[same as prior period, unchanged from 0001628280-25-036650:notes:22]

[0001628280-25-047026:notes:22]
[same as prior period, unchanged from 0001628280-25-036650:notes:23]

[0001628280-25-047026:notes:23]
[same as prior period, unchanged from 0001628280-25-036650:notes:24]

[0001628280-25-047026:notes:24]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at September 27, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0001628280-25-047026:notes:25]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 814,733 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,696 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 816,429 |  |  | $ | 726,437 |  |

[0001628280-25-047026:notes:26]
Recently Issued Accounting Standards

[0001628280-25-047026:notes:27]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software." The amendments in this update require the entity to start capitalizing software costs when both of the following criteria are met: (1) management has authorized and committed to funding the software project, and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the "probable-to-complete recognition threshold"). The amendments clarify that the intangibles disclosures are not required for capitalized internal-use software costs. Additionally, the amendments in this update supersede the website development costs guidance and incorporate the recognition requirements for website-specific development costs. The guidance is effective for fiscal years beginning after December 15, 2027 with early adoption permitted. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

[0001628280-25-047026:notes:28]
In September 2025, the FASB issued ASU No. 2025-05, "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets." The amendments in this update provide entities with a practical expedient when estimating expected credit losses for current accounts receivable and current contract assets arising from transactions accounted for under Topic 606. In developing reasonable and supportable forecasts as part of estimating expected credit losses, the practical expedient allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for fiscal years beginning after December 15, 2025 with early adoption permitted. The Company does not expect any material effect of the adoption of this guidance on the Company's Condensed Consolidated Financial Statements.

[0001628280-25-047026:notes:29]
In November 2024, the FASB issued ASU No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are

[0001628280-25-047026:notes:30]
not separately disaggregated quantitatively (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Condensed Consolidated Financial Statements.

[0001628280-25-047026:notes:31]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify disclosures in the Company's Condensed Consolidated Financial Statements.

[0001628280-25-047026:notes:32]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-25-047026:notes:33]
[same as prior period, unchanged from 0001628280-25-036650:notes:32]

[0001628280-25-047026:notes:34]
[same as prior period, unchanged from 0001628280-25-036650:notes:33]

[0001628280-25-047026:notes:35]
[same as prior period, unchanged from 0001628280-25-036650:notes:34]

[0001628280-25-047026:notes:36]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab was approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0001628280-25-047026:notes:37]
The acquisition was funded with cash on hand. The total purchase consideration of $95.9 million, net of cash acquired, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0001628280-25-047026:notes:38]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Dortmund Fab acquisition:

[0001628280-25-047026:notes:39]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 95,942 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables | 5,985 |  |
| Inventories | 6,600 |  |
| Other current assets | 8,278 |  |
| Property, plant, and equipment | 30,132 |  |
| Intangible assets | 1,800 |  |
| Goodwill | 57,321 |  |
| Other long-term assets | 8,579 |  |
| Current liabilities | (7,464) |  |
| Other long-term liabilities | (15,289) |  |
|  | $ | 95,942 |  |

[0001628280-25-047026:notes:40]
[same as prior period, unchanged from 0001628280-25-036650:notes:39]

[0001628280-25-047026:notes:41]
[same as prior period, unchanged from 0001628280-25-036650:notes:40]

[0001628280-25-047026:notes:42]
During the three months ended September 27, 2025, the Company recorded an additional measurement period adjustment to decrease other long-term liabilities and goodwill by $0.2 million accordingly.

[0001628280-25-047026:notes:43]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and nine months ended September 27, 2025 were net sales of $12.9 million and $36.4 million, respectively, and loss before income taxes was $1.5 million and $3.9 million, respectively, since the December 31, 2024 acquisition of Dortmund Fab.

[0001628280-25-047026:notes:44]
As required by purchase accounting guidance, the Company recorded a $0.5 million step-down of inventory to its fair value as of the acquisition date based on the valuation. The step-down was fully amortized as a non-cash credit to cost of sales during the first fiscal quarter of 2025 as the acquired inventory was sold and reflected as other non-segment costs.

[0001628280-25-047026:notes:45]
During the nine months ended September 28, 2024, the Company incurred approximately $0.2 million of legal and professional fees related to the Dortmund Fab acquisition recognized as Selling, general, and administrative expenses in the Condensed Consolidated Statements of Net Income. A total of $3.5 million of legal and professional fees related to the Dortmund Fab acquisition was recognized since 2023. These costs were reflected as other non-segment costs.

[0001628280-25-047026:notes:46]
[same as prior period, unchanged from 0001628280-25-036650:notes:44]

[0001628280-25-047026:notes:47]
[same as prior period, unchanged from 0001628280-25-036650:notes:45]

[0001628280-25-047026:notes:48]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands, except per share amounts) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net sales |  | $ | 624,640 |  |  | $ | 577,536 |  |  | $ | 1,792,360 |  |  | $ | 1,694,925 |  |
| Income before income taxes |  | 94,716 |  |  | 78,625 |  |  | 232,336 |  |  | 197,957 |  |
| Net income |  | 69,522 |  |  | 58,546 |  |  | 170,056 |  |  | 154,183 |  |
| Net income per share — basic |  | 2.80 |  | 2.36 |  |  | 6.86 |  |  | 6.21 |  |
| Net income per share — diluted |  | 2.77 |  | 2.34 |  |  | 6.81 |  |  | 6.16 |  |

[0001628280-25-047026:notes:49]
[same as prior period, unchanged from 0001628280-25-036650:notes:47]

[0001628280-25-047026:notes:50]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Amortization of unfavorable production contract (a) |  | $ | — |  |  | $ | 567 |  |  | $ | — |  |  | $ | 1,702 |  |
| Amortization of inventory step-down (b) |  | — |  |  | — |  |  | (504) |  |  | 510 |  |
| Depreciation |  | — |  |  | (296) |  |  | — |  |  | (845) |  |
| Amortization (c) |  | — |  |  | (95) |  |  | — |  |  | (283) |  |
| Transaction costs (d) |  | — |  |  | 66 |  |  | (37) |  |  | (314) |  |
| Income tax (expense) benefit of above items |  | — |  |  | (73) |  |  | 162 |  |  | (231) |  |

[0001628280-25-047026:notes:51]
(a) The amortization of the unfavorable production contract during the three and nine months ended September 28, 2024 results from the fair value assigned to the unfavorable production contract liability that is amortized over four years.

[0001628280-25-047026:notes:52]
(b) The amortization of the inventory step-down adjustment reflects the reversal of the amount recognized during the nine months ended September 27, 2025, and the recognition of the amortization during the nine months ended September 28, 2024. The inventory step-down was fully amortized over two months as the inventory was sold.

[0001628280-25-047026:notes:53]
(c) The amortization adjustment for the three and nine months ended September 28, 2024 primarily reflects amortization resulting from the measurement of intangibles at their fair values.

[0001628280-25-047026:notes:54]
(d) The transaction costs adjustment reflects certain legal and professional fees for the nine months ended September 27, 2025 and three and nine months ended September 28, 2024, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-25-047026:notes:55]
[same as prior period, unchanged from 0001628280-25-036650:notes:53]

[0001628280-25-047026:notes:56]
The components of inventories at September 27, 2025 and December 28, 2024 were as follows:

[0001628280-25-047026:notes:57]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Raw materials |  | $ | 185,918 |  |  | $ | 193,788 |  |
| Work in process |  | 126,090 |  |  | 115,497 |  |
| Finished goods |  | 170,030 |  |  | 173,513 |  |
| Inventory reserves |  | (85,167) |  |  | (66,525) |  |
| Total |  | $ | 396,871 |  |  | $ | 416,273 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-25-047026:notes:58]
[same as prior period, unchanged from 0001628280-25-036650:notes:56]

[0001628280-25-047026:notes:59]
The components of net property, plant, and equipment at September 27, 2025 and December 28, 2024 were as follows:

[0001628280-25-047026:notes:60]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Land and land improvements |  | $ | 18,839 |  |  | $ | 17,593 |  |
| Building and building improvements |  | 206,212 |  |  | 192,441 |  |
| Machinery and equipment |  | 972,980 |  |  | 892,940 |  |
| Accumulated depreciation and amortization |  | (684,066) |  |  | (625,906) |  |
| Total |  | $ | 513,965 |  |  | $ | 477,068 |  |

[0001628280-25-047026:notes:61]
The Company recorded depreciation expense of $18.6 million and $17.3 million for the three months ended September 27, 2025 and September 28, 2024, respectively, and $56.4 million and $51.0 million for the nine months ended September 27, 2025 and September 28, 2024, respectively, in Cost of sales, Selling, general, and administrative expenses, and Research and development expenses in the Condensed Consolidated Statements of Net Income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-047026:notes:62]
[same as prior period, unchanged from 0001628280-25-036650:notes:60]

[0001628280-25-047026:notes:63]
The amounts for goodwill and changes in the carrying value of goodwill by segment for the nine months ended September 27, 2025 were as follows:

[0001628280-25-047026:notes:64]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net goodwill as of December 28, 2024 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 28, 2024 |  | $ | 906,871 |  |  | $ | 233,286 |  |  | $ | 173,882 |  |  | $ | 1,314,039 |  |
| Accumulated impairment losses as of December 28, 2024 |  | — |  |  | (41,645) |  |  | (43,892) |  |  | (85,537) |  |
| Total |  | 906,871 |  |  | 191,641 |  |  | 129,990 |  |  | 1,228,502 |  |
| Changes during 2025: |  |  |  |  |  |  |  |  |
| Additions (a) |  | 57,321 |  |  | — |  |  | — |  |  | 57,321 |  |
| Foreign currency translation adjustments |  | 58,108 |  |  | 5,442 |  |  | 6,665 |  |  | 70,215 |  |
| Net goodwill as of September 27, 2025 |  |  |  |  |  |  |  |  |
| Gross goodwill as of September 27, 2025 |  | 1,022,300 |  |  | 241,368 |  |  | 185,157 |  |  | 1,448,825 |  |
| Accumulated impairment losses as of September 27, 2025 |  | — |  |  | (44,285) |  |  | (48,502) |  |  | (92,787) |  |
| Total |  | 1,022,300 |  |  | 197,083 |  |  | 136,655 |  |  | 1,356,038 |  |

[0001628280-25-047026:notes:65]
[same as prior period, unchanged from 0001628280-25-036650:notes:63]

[0001628280-25-047026:notes:66]
The components of intangible assets as of September 27, 2025 and December 28, 2024 were as follows:

[0001628280-25-047026:notes:67]
|  |  |  | As of September 27, 2025 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 16,410 |  |  | $ | 3,431 |  |  | $ | 12,979 |  |
| Patents, licenses, and software |  |  | 274,617 |  |  | 205,666 |  |  | 68,951 |  |
| Distribution network |  |  | 42,307 |  |  | 42,307 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 657,090 |  |  | 280,244 |  |  | 376,846 |  |
| Total |  |  | $ | 990,424 |  |  | $ | 531,648 |  |  | $ | 458,776 |  |

[0001628280-25-047026:notes:68]
[same as prior period, unchanged from 0001628280-25-036650:notes:66]

[0001628280-25-047026:notes:69]
During the three months ended September 27, 2025 and September 28, 2024, the Company recorded amortization expense of $15.0 million and $15.9 million, respectively. During the nine months ended September 27, 2025 and September 28, 2024, the Company recorded amortization expense of $44.2 million and $47.4 million, respectively.

[0001628280-25-047026:notes:70]
During the nine months ended September 27, 2025, the Company recorded additions to intangible assets of $1.8 million related to the Dortmund Fab acquisition, the components of which were as follows:

[0001628280-25-047026:notes:71]
[same as prior period, unchanged from 0001628280-25-036650:notes:69]

[0001628280-25-047026:notes:72]
Estimated annual amortization expense related to intangible assets with definite lives as of September 27, 2025 was as follows:

[0001628280-25-047026:notes:73]
| (in thousands) | Amount |
| Remainder of 2025 | $ | 14,953 |  |
| 2026 | 48,722 |  |
| 2027 | 46,551 |  |
| 2028 | 46,149 |  |
| 2029 | 45,738 |  |
| 2030 and thereafter | 256,663 |  |
| Total | $ | 458,776 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-25-047026:notes:74]
[same as prior period, unchanged from 0001628280-25-036650:notes:72]

[0001628280-25-047026:notes:75]
The components of accrued liabilities as of September 27, 2025 and December 28, 2024 were as follows:

[0001628280-25-047026:notes:76]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Employee-related liabilities |  | $ | 100,702 |  |  | $ | 67,639 |  |
| Current lease liability |  | 11,067 |  |  | 13,900 |  |
| Other non-income taxes |  | 8,356 |  |  | 7,022 |  |
| Professional services |  | 5,773 |  |  | 6,613 |  |
| Interest |  | 4,578 |  |  | 8,131 |  |
| Restructuring liability |  | 4,158 |  |  | 4,624 |  |
| Deferred revenue |  | 3,113 |  |  | 1,557 |  |
| Other customer reserves |  | 2,917 |  |  | 3,450 |  |
| Current benefit liability |  | 1,514 |  |  | 1,514 |  |
| Current hedge liability |  | — |  |  | 4,067 |  |
| Other |  | 31,608 |  |  | 29,759 |  |
| Total |  | $ | 173,786 |  |  | $ | 148,276 |  |

[0001628280-25-047026:notes:77]
[same as prior period, unchanged from 0001628280-25-036650:notes:75]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001628280-25-047026:notes:78]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three and nine months ended September 27, 2025 and September 28, 2024 as follows:

[0001628280-25-047026:notes:79]
|  | Three Months Ended September 27, 2025 |  | Nine Months Ended September 27, 2025 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 496 |  |  | $ | 1,097 |  |  | $ | — |  |  | $ | 1,593 |  |  | $ | 6,400 |  |  | $ | 5,579 |  |  | $ | 436 |  |  | $ | 12,415 |  |
| Other restructuring charges | 30 |  |  | 10 |  |  | — |  |  | 40 |  |  | 548 |  |  | 58 |  |  | 1 |  |  | 607 |  |
| Total restructuring charges | 526 |  |  | 1,107 |  |  | — |  |  | 1,633 |  |  | 6,948 |  |  | 5,637 |  |  | 437 |  |  | 13,022 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | 136 |  |  | — |  |  | — |  |  | 136 |  |
| Total | $ | 526 |  |  | $ | 1,107 |  |  | $ | — |  |  | $ | 1,633 |  |  | $ | 7,084 |  |  | $ | 5,637 |  |  | $ | 437 |  |  | $ | 13,158 |  |

[0001628280-25-047026:notes:80]
|  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,140 |  |  | $ | 404 |  |  | $ | 1 |  |  | $ | 1,545 |  |  | $ | 6,245 |  |  | $ | 1,995 |  |  | $ | 417 |  |  | $ | 8,657 |  |
| Other restructuring charges | 95 |  |  | 187 |  |  | 13 |  |  | 295 |  |  | 234 |  |  | 474 |  |  | 31 |  |  | 739 |  |
| Total restructuring charges | 1,235 |  |  | 591 |  |  | 14 |  |  | 1,840 |  |  | 6,479 |  |  | 2,469 |  |  | 448 |  |  | 9,396 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 933 |  |  | — |  |  | 933 |  |
| Total | $ | 1,235 |  |  | $ | 591 |  |  | $ | 14 |  |  | $ | 1,840 |  |  | $ | 6,479 |  |  | $ | 3,402 |  |  | $ | 448 |  |  | $ | 10,329 |  |

[0001628280-25-047026:notes:81]
[same as prior period, unchanged from 0001628280-25-036650:notes:79]

[0001628280-25-047026:notes:82]
For the three and nine months ended September 27, 2025, the Company recorded total restructuring charges of $1.6 million and $13.0 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and corporate support functions for the semiconductor business within the Electronics segment and across all businesses within the Transportation segment. In addition, during the first fiscal quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment.

[0001628280-25-047026:notes:83]
[same as prior period, unchanged from 0001628280-25-036650:notes:81]

[0001628280-25-047026:notes:84]
For the three and nine months ended September 28, 2024, the Company recorded total restructuring charges of $1.8 million and $9.4 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the semiconductor business in the Electronics segment and the reorganization of certain selling and administrative functions within the commercial vehicle business in the Transportation segment. In addition, during the first fiscal quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0001628280-25-047026:notes:85]
The restructuring reserves as of September 27, 2025 and December 28, 2024 were $4.2 million and $4.6 million, respectively. The restructuring liability as of September 27, 2025 was $4.2 million and is included within Accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed during fiscal year 2025.


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-047026:notes:86]
Debt

[0001628280-25-047026:notes:87]
The carrying amounts of debt at September 27, 2025 and December 28, 2024 were as follows:

[0001628280-25-047026:notes:88]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 270,000 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,889 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 1,955 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,068) |  |  | (2,766) |  |
| Total debt |  | 805,776 |  |  | 856,114 |  |
| Less: Current maturities |  | (16,955) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 788,821 |  |  | $ | 788,502 |  |

[0001628280-25-047026:notes:89]
Revolving Credit Facility and Term Loan

[0001628280-25-047026:notes:90]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-25-047026:notes:91]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-25-047026:notes:92]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 27, 2025, the Company made term loan payments of $3.8 million and $11.3 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $270.0 million, respectively, as of September 27, 2025.

[0001628280-25-047026:notes:93]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0001628280-25-047026:notes:94]
As of September 27, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.26%, and 4.13% on the hedged portion.

[0001628280-25-047026:notes:95]
As of September 27, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 27, 2025, the Company was in compliance with all covenants under the Credit Agreement.

[0001628280-25-047026:notes:96]
Senior Notes

[0001628280-25-047026:notes:97]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-25-047026:notes:98]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-25-047026:notes:99]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0001628280-25-047026:notes:100]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-25-047026:notes:101]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-25-047026:notes:102]
The Senior Notes have not been registered under the Securities Act of 1933 ("Securities Act"), or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001628280-25-047026:notes:103]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of September 27, 2025, the Company was in compliance with all covenants under the Senior Notes.

[0001628280-25-047026:notes:104]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001628280-25-047026:notes:105]
Interest paid on all Company debt was $11.1 million and $10.5 million for the three months ended September 27, 2025 and September 28, 2024, respectively, and $29.0 million and $30.1 million for the nine months ended September 27, 2025 and September 28, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-047026:notes:106]
[same as prior period, unchanged from 0001628280-25-036650:notes:104]

[0001628280-25-047026:notes:107]
[same as prior period, unchanged from 0001628280-25-036650:notes:105]

[0001628280-25-047026:notes:108]
[same as prior period, unchanged from 0001628280-25-036650:notes:106]

[0001628280-25-047026:notes:109]
[same as prior period, unchanged from 0001628280-25-036650:notes:107]

[0001628280-25-047026:notes:110]
[same as prior period, unchanged from 0001628280-25-036650:notes:108]

[0001628280-25-047026:notes:111]
[same as prior period, unchanged from 0001628280-25-036650:notes:109]

[0001628280-25-047026:notes:112]
[same as prior period, unchanged from 0001628280-25-036650:notes:110]

[0001628280-25-047026:notes:113]
[same as prior period, unchanged from 0001628280-25-036650:notes:111]

[0001628280-25-047026:notes:114]
[same as prior period, unchanged from 0001628280-25-036650:notes:112]

[0001628280-25-047026:notes:115]
[same as prior period, unchanged from 0001628280-25-036650:notes:113]

[0001628280-25-047026:notes:116]
[same as prior period, unchanged from 0001628280-25-036650:notes:114]

[0001628280-25-047026:notes:117]
[same as prior period, unchanged from 0001628280-25-036650:notes:115]

[0001628280-25-047026:notes:118]
[same as prior period, unchanged from 0001628280-25-036650:notes:116]

[0001628280-25-047026:notes:119]
[same as prior period, unchanged from 0001628280-25-036650:notes:117]

[0001628280-25-047026:notes:120]
[same as prior period, unchanged from 0001628280-25-036650:notes:118]

[0001628280-25-047026:notes:121]
| Trade Entry Date | Trade Maturity Date | Weighted-Average Floor | Weighted-Average Ceiling |
| July 3, 2024 | August 29, 2025 | 18.0000 | 19.4350 |
| August 5, 2024 | September 29, 2025 | 19.6550 | 21.0000 |
| September 3, 2024 | November 3, 2025 | 20.0820 | 21.7571 |
| September 30, 2024 | November 26, 2025 | 19.8700 | 21.3650 |
| November 4, 2024 | January 2, 2026 | 20.1200 | 21.6900 |
| December 3, 2024 | February 2, 2026 | 20.4250 | 22.0377 |
| January 2, 2025 | March 2, 2026 | 20.8000 | 21.9082 |
| February 6, 2025 | March 30, 2026 | 20.5300 | 22.0000 |
| April 9, 2025 | June 1, 2026 | 20.9700 | 22.2355 |
| May 1, 2025 | June 29, 2026 | 19.6940 | 20.9700 |
| June 4, 2025 | August 3, 2026 | 19.3100 | 20.3437 |
| July 2, 2025 | August 31, 2026 | 18.8500 | 19.8025 |
| August 5, 2025 | September 29, 2026 | 18.8500 | 19.8000 |
| September 2, 2025 | November 2, 2026 | 18.8100 | 19.8347 |

[0001628280-25-047026:notes:122]
The fair value of the collars was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three and nine months ended September 27, 2025, the Company recorded pre-tax unrealized gains on the collars of $1.3 million and $10.7 million, respectively. As of September 27, 2025, the Company estimates that approximately $7.1 million of pre-tax gain recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The amounts included in accumulated other comprehensive income will be reclassified to earnings should the hedge no longer be considered effective. No amount of ineffectiveness was included in net income for the three and nine months ended September 27, 2025. The Company will continue to assess the effectiveness of the hedge on an ongoing basis. The primary inputs into the valuation of the collars are interest yield curves, interest rate volatilities, foreign exchange rates, foreign exchange volatilities, credit risk, credit spreads and other market information. The collars are classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0001628280-25-047026:notes:123]
[same as prior period, unchanged from 0001628280-25-036650:notes:121]

[0001628280-25-047026:notes:124]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three and nine months ended September 27, 2025, the Company recorded a pre-tax unrealized loss on the

[0001628280-25-047026:notes:125]
interest rate swap of $0.6 million and $4.0 million, respectively. As of September 27, 2025, the Company estimates that approximately $1.7 million of pre-tax gain recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0001628280-25-047026:notes:126]
[same as prior period, unchanged from 0001628280-25-036650:notes:123]

[0001628280-25-047026:notes:127]
[same as prior period, unchanged from 0001628280-25-036650:notes:124]

[0001628280-25-047026:notes:128]
As of September 27, 2025 and December 28, 2024, the fair values of the Company's derivative financial instruments and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0001628280-25-047026:notes:129]
| (in thousands) | Condensed Consolidated Balance Sheets Classification |  | September 27, 2025 |  | December 28, 2024 |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 1,597 |  |  | $ | 2,482 |  |  |  |
|  | Other long-term assets |  | 591 |  |  | 3,716 |  |  |  |
| Zero cost collar agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 6,766 |  |  | $ | 22 |  |  |  |
|  | Other long-term assets |  | 1 |  |  | — |  |  |  |
|  | Accrued liabilities |  | — |  |  | 4,067 |  |  |  |
|  | Other long-term liabilities |  | — |  |  | 2 |  |  |  |

[0001628280-25-047026:notes:130]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Net Income for the three and nine months ended September 27, 2025 and September 28, 2024 were as follows:

[0001628280-25-047026:notes:131]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | Classification of (Gains) Losses Recognized in the Condensed Consolidated Statements of Net Income |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (786) |  |  | $ | (1,282) |  |  | $ | (2,357) |  |  | $ | (3,850) |  |
| Zero cost collar agreement |  | Cost of sales |  | (1,565) |  |  | 409 |  |  | (205) |  |  | 409 |  |
| Zero cost collar agreement |  | Selling, general, and administrative expenses |  | (119) |  |  | — |  |  | 2 |  |  | — |  |

[0001628280-25-047026:notes:132]
The pre-tax losses (gains) recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and nine months ended September 27, 2025 and September 28, 2024 were as follows:

[0001628280-25-047026:notes:133]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | 561 |  |  | $ | 5,857 |  |  | $ | 4,010 |  |  | $ | 3,346 |  |
| Zero cost collar agreement |  | (1,319) |  |  | 4,003 |  |  | (10,731) |  |  | 4,003 |  |

[0001628280-25-047026:notes:134]
[same as prior period, unchanged from 0001628280-25-036650:notes:131]

[0001628280-25-047026:notes:135]
[same as prior period, unchanged from 0001628280-25-036650:notes:132]

[0001628280-25-047026:notes:136]
There were no changes during the quarter ended September 27, 2025 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 27, 2025 and December 28, 2024, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001628280-25-047026:notes:137]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 27, 2025:

[0001628280-25-047026:notes:138]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 749,628 |  |  | $ | — |  |  | $ | — |  |  | $ | 749,628 |  |
| Investments in equity securities |  | 9,160 |  |  | — |  |  | — |  |  | 9,160 |  |
| Mutual funds |  | 25,440 |  |  | — |  |  | — |  |  | 25,440 |  |
| Total |  | $ | 784,228 |  |  | $ | — |  |  | $ | — |  |  | $ | 784,228 |  |

[0001628280-25-047026:notes:139]
[same as prior period, unchanged from 0001628280-25-036650:notes:136]

[0001628280-25-047026:notes:140]
[same as prior period, unchanged from 0001628280-25-036650:notes:137]

[0001628280-25-047026:notes:141]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at September 27, 2025 and December 28, 2024, as the rates on these borrowings are variable in nature. The purchase price of business acquisitions is primarily allocated to the tangible and identifiable intangible assets acquired and liabilities assumed based on their estimated fair values on the acquisition date, with the excess recorded as goodwill. The Company utilizes Level 3 inputs in the determination of the initial fair value for certain assets acquired and liabilities assumed in business acquisitions.

[0001628280-25-047026:notes:142]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series B and USD Senior Notes, Series A and Series B, as of September 27, 2025 and December 28, 2024 were as follows:

[0001628280-25-047026:notes:143]
|  |  | September 27, 2025 |  | December 28, 2024 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 |  | $ | 110,889 |  |  | $ | 104,638 |  |  | $ | 98,928 |  |  | $ | 91,741 |  |
| USD Senior Notes, Series A due 2025 |  | — |  |  | — |  |  | 50,000 |  |  | 49,919 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 98,784 |  |  | 100,000 |  |  | 96,623 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 119,292 |  |  | 125,000 |  |  | 114,786 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 95,072 |  |  | 100,000 |  |  | 91,175 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-25-047026:notes:144]
[same as prior period, unchanged from 0001628280-25-036650:notes:141]

[0001628280-25-047026:notes:145]
[same as prior period, unchanged from 0001628280-25-036650:notes:142]

[0001628280-25-047026:notes:146]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended September 27, 2025 and September 28, 2024 were as follows:

[0001628280-25-047026:notes:147]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 769 |  |  | $ | 753 |  |  | $ | 2,254 |  |  | $ | 2,318 |  |
| Interest cost |  | 1,028 |  |  | 961 |  |  | 2,985 |  |  | 2,931 |  |
| Expected return on plan assets |  | (483) |  |  | (527) |  |  | (1,423) |  |  | (1,555) |  |
| Amortization of prior service and net actuarial loss |  | 103 |  |  | 47 |  |  | 274 |  |  | 139 |  |
| Net periodic benefit cost |  | $ | 1,417 |  |  | $ | 1,234 |  |  | $ | 4,090 |  |  | $ | 3,833 |  |

[0001628280-25-047026:notes:148]
[same as prior period, unchanged from 0001628280-25-036650:notes:145]

[0001628280-25-047026:notes:149]
[same as prior period, unchanged from 0001628280-25-036650:notes:146]

[0001628280-25-047026:notes:150]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.8 million and $0.6 million for the three months ended September 27, 2025 and September 28, 2024, respectively, and $2.2 million and $2.0 million for the nine months ended September 27, 2025 and September 28, 2024, respectively, in Cost of sales and Other income, net within the Condensed Consolidated Statements of Net Income. The pre-tax losses amount recognized in other comprehensive income (loss) for these plans were $0.4 million and $0.3 million for the three months ended September 27, 2025 and September 28, 2024, respectively, and $1.1 million and $0.9 million for the nine months ended September 27, 2025 and September 28, 2024, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-047026:notes:151]
[same as prior period, unchanged from 0001628280-25-036650:notes:148]

[0001628280-25-047026:notes:152]
| (in thousands) |  | Three Months EndedSeptember 27, 2025 |  | Three Months EndedSeptember 28, 2024 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 662 |  |  | $ | 4 |  |  | $ | 666 |  |  | $ | 205 |  |  | $ | (14) |  |  | $ | 191 |  |
| Cash flow hedges |  | 758 |  |  | 88 |  |  | 846 |  |  | (9,860) |  |  | 1,563 |  |  | (8,297) |  |
| Foreign currency translation adjustments (a) |  | (5,297) |  |  | 248 |  |  | (5,049) |  |  | 66,331 |  |  | (1,832) |  |  | 64,499 |  |
| Total change in other comprehensive income (loss) |  | $ | (3,877) |  |  | $ | 340 |  |  | $ | (3,537) |  |  | $ | 56,676 |  |  | $ | (283) |  |  | $ | 56,393 |  |
| (in thousands) |  | Nine Months EndedSeptember 27, 2025 |  | Nine Months EndedSeptember 28, 2024 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 1,040 |  |  | $ | 29 |  |  | $ | 1,069 |  |  | $ | 901 |  |  | $ | (40) |  |  | $ | 861 |  |
| Cash flow hedges |  | 6,721 |  |  | 543 |  |  | 7,264 |  |  | (7,349) |  |  | 960 |  |  | (6,389) |  |
| Foreign currency translation adjustments (a) |  | 126,804 |  |  | (3,164) |  |  | 123,640 |  |  | 11,619 |  |  | (1,056) |  |  | 10,563 |  |
| Total change in other comprehensive income (loss) |  | $ | 134,565 |  |  | $ | (2,592) |  |  | $ | 131,973 |  |  | $ | 5,171 |  |  | $ | (136) |  |  | $ | 5,035 |  |

[0001628280-25-047026:notes:153]
[same as prior period, unchanged from 0001628280-25-036650:notes:150]

[0001628280-25-047026:notes:154]
The following tables set forth the changes in the components of accumulated other comprehensive income (loss) by component for the nine months ended September 27, 2025 and September 28, 2024:

[0001628280-25-047026:notes:155]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currencytranslation adjustments |  | Accumulated othercomprehensive (loss) income |
| Balance at December 28, 2024 |  | $ | (10,509) |  |  | $ | 1,301 |  |  | $ | (137,153) |  |  | $ | (146,361) |  |
| Activity in the period |  | 1,069 |  |  | 7,264 |  |  | 123,640 |  |  | 131,973 |  |
| Balance at September 27, 2025 |  | $ | (9,440) |  |  | $ | 8,565 |  |  | $ | (13,513) |  |  | $ | (14,388) |  |

[0001628280-25-047026:notes:156]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currency translation adjustments |  | Accumulated other comprehensive (loss) income |
| Balance at December 30, 2023 |  | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| Activity in the period |  | 861 |  |  | (6,389) |  |  | 10,563 |  |  | 5,035 |  |
| Balance at September 28, 2024 |  | $ | (6,752) |  |  | $ | (1,941) |  |  | $ | (42,089) |  |  | $ | (50,782) |  |

[0001628280-25-047026:notes:157]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for the three and nine months ended September 27, 2025 and September 28, 2024 were as follows:

[0001628280-25-047026:notes:158]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Pension and postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss, and other |  | $ | 490 |  |  | $ | 323 |  |  | $ | 1,381 |  |  | $ | 1,026 |  |

[0001628280-25-047026:notes:159]
[same as prior period, unchanged from 0001628280-25-036650:notes:156]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-047026:notes:160]
Income Taxes
The effective tax rate for the three and nine months ended September 27, 2025 was 26.6% and 26.8%, respectively, compared to the effective tax rate for the three and nine months ended September 28, 2024 of 25.3% and 21.9%, respectively. The effective tax rate for 2025 was higher than the effective tax rate for the comparable 2024 periods primarily due to increases in losses in non-U.S. jurisdictions with no related tax benefit, as compared to 2024. The 2024 periods also recognized more favorable tax rate benefits due to lapses in the statute of limitations for previously unrecognized tax benefits, as compared to the 2025 periods.

[0001628280-25-047026:notes:161]
The effective tax rate for three and nine months ended September 27, 2025 was higher than the statutory tax rate primarily due to foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit. The effective tax rate for the three and nine months ended September 28, 2024 was higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions, partially offset by the lapse in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter. 
On July 4, 2025, the United States enacted into law the legislation formally titled “An Act to provide for reconciliation pursuant to title II of H. Con. Res. 14,” and commonly referred to as the One Big Beautiful Bill Act (“OBBB”). The OBBB contains multiple business tax provisions, including the permanent extension of several expiring provisions of the Tax Cuts and Jobs Act and multiple modifications to the international tax framework. The legislation has multiple effective dates with certain provisions effective in 2025 and others to be implemented in future years, and the Company determined the impact for the three and nine months ended September 27, 2025 is not significant. The Company will continue to monitor future administrative guidance and regulations that clarify the legislative text of the OBBB and the bill’s potential effect on the Company’s income taxes.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-047026:notes:162]
[same as prior period, unchanged from 0001628280-25-036650:notes:160]

[0001628280-25-047026:notes:163]
[same as prior period, unchanged from 0001628280-25-036650:notes:161]

[0001628280-25-047026:notes:164]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 69,522 |  |  | $ | 58,058 |  |  | $ | 170,435 |  |  | $ | 151,976 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,837 |  |  | 24,796 |  |  | 24,786 |  |  | 24,822 |  |
| Effect of dilutive securities |  | 265 |  |  | 229 |  |  | 203 |  |  | 218 |  |
| Diluted |  | 25,102 |  |  | 25,025 |  |  | 24,989 |  |  | 25,040 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.80 |  |  | $ | 2.34 |  |  | $ | 6.88 |  |  | $ | 6.12 |  |
| Diluted earnings per share |  | $ | 2.77 |  |  | $ | 2.32 |  |  | $ | 6.82 |  |  | $ | 6.07 |  |

[0001628280-25-047026:notes:165]
Potential shares of common stock attributable to performance share units, stock options and restricted stock units excluded from the earnings per share calculation because their effect would be anti-dilutive were 101,354 and 124,197 for the three months ended September 27, 2025 and September 28, 2024, respectively, and 322,843 and 136,635 for the nine months ended September 27, 2025 and September 28, 2024, respectively.

[0001628280-25-047026:notes:166]
Share Repurchase Program

[0001628280-25-047026:notes:167]
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program") to replace its previous 2021 program. The Company did not repurchase any shares of its common stock for the three months ended 
September 27, 2025. During the nine months ended September 27, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. During the nine months ended September 28, 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-047026:notes:168]
[same as prior period, unchanged from 0001628280-25-036650:notes:165]

[0001628280-25-047026:notes:169]
[same as prior period, unchanged from 0001628280-25-036650:notes:166]

[0001628280-25-047026:notes:170]
[same as prior period, unchanged from 0001628280-25-036650:notes:167]

[0001628280-25-047026:notes:171]
[same as prior period, unchanged from 0001628280-25-036650:notes:168]

[0001628280-25-047026:notes:172]
[same as prior period, unchanged from 0001628280-25-036650:notes:169]

[0001628280-25-047026:notes:173]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), protective and monitoring relays (protection relays, residual current devices and monitors, ground fault circuit interrupters, solid state switches, and arc fault detection devices), and industrial controls and sensors (contactors, transformers, and temperature sensors) for use in various applications such as renewable energy and energy storage systems, industrial safety, factory automation, electric vehicle charging infrastructure, HVAC systems, non-residential construction, MRO, and mining.

[0001628280-25-047026:notes:174]
[same as prior period, unchanged from 0001628280-25-036650:notes:172]

[0001628280-25-047026:notes:175]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 357,457 |  |  | $ | 304,188 |  |  | $ | 1,000,372 |  |  | $ | 900,932 |  |
| Transportation |  | 171,311 |  |  | 171,381 |  |  | 512,573 |  |  | 510,711 |  |
| Industrial |  | 95,872 |  |  | 91,821 |  |  | 279,415 |  |  | 249,620 |  |
| Total net sales |  | $ | 624,640 |  |  | $ | 567,390 |  |  | $ | 1,792,360 |  |  | $ | 1,661,263 |  |
| Other segment expenses (b) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 293,817 |  |  | $ | 255,297 |  |  | $ | 840,105 |  |  | 768,073 |  |
| Transportation |  | 151,124 |  |  | 147,896 |  |  | 445,395 |  |  | 455,786 |  |
| Industrial |  | 78,954 |  |  | 74,110 |  |  | 230,560 |  |  | 217,566 |  |
| Total other segment expenses |  | $ | 523,895 |  |  | $ | 477,303 |  |  | $ | 1,516,060 |  |  | $ | 1,441,425 |  |
| Segment operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 63,640 |  |  | $ | 48,891 |  |  | $ | 160,267 |  |  | $ | 132,859 |  |
| Transportation |  | 20,187 |  |  | 23,485 |  |  | 67,178 |  |  | 54,925 |  |
| Industrial |  | 16,918 |  |  | 17,711 |  |  | 48,855 |  |  | 32,054 |  |
| Total segment operating income |  | 100,745 |  |  | 90,087 |  |  | 276,300 |  |  | 219,838 |  |
| Other (a) |  | (3,329) |  |  | (2,266) |  |  | (15,956) |  |  | (11,559) |  |
| Total operating income |  | 97,416 |  |  | 87,821 |  |  | 260,344 |  |  | 208,279 |  |
| Interest expense |  | 8,578 |  |  | 9,772 |  |  | 26,021 |  |  | 29,358 |  |
| Foreign exchange loss |  | 175 |  |  | 9,630 |  |  | 15,466 |  |  | 4,273 |  |
| Other income, net |  | (6,053) |  |  | (9,297) |  |  | (14,020) |  |  | (19,916) |  |
| Income before income taxes |  | $ | 94,716 |  |  | $ | 77,716 |  |  | $ | 232,877 |  |  | $ | 194,564 |  |

[0001628280-25-047026:notes:176]
(a) Included in "Other" Operating income for the third fiscal quarter of 2025 was $1.6 million ($13.1 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the third quarter of 2025, the Company recognized $1.4 million ($3.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and a $0.3 million loss related to the sale of the Marine business within the Transportation segment. During the first quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustments related to the Dortmund Fab acquisition.

[0001628280-25-047026:notes:177]
Included in "Other" Operating income for the third quarter of 2024 was $1.8 million ($9.4 million year-to-date) of restructuring charges primarily related to employee termination costs, and $1.0 million ($2.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the third quarter of 2024, the Company recorded a gain of $0.5 million related to the sale of a land use right within the Electronics segment. In addition, the Company recognized a gain of $1.0 million for the sale of two buildings within the Transportation segment during first half of 2024.

[0001628280-25-047026:notes:178]
(b) Other segment operating expenses include cost of sales, selling, general, and administration expenses, and research and development expenses. Other segment expenses are reconciled to the operating income of each segment. The CODM regularly assesses the performance of each operating segment focusing on each operating segment’s revenue and operating income. Other segment operating expenses for the three and nine months ended September 28, 2024 were included in order to adhere to the implementation of Accounting Standards Updates ("ASU") No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures."

[0001628280-25-047026:notes:179]
The Company’s depreciation and amortization expenses by segment for the three and nine months ended September 27, 2025 and September 28, 2024 were as follows:

[0001628280-25-047026:notes:180]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Depreciation |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 11,950 |  |  | $ | 10,143 |  |  | $ | 35,912 |  |  | $ | 30,089 |  |
| Transportation |  | 5,127 |  |  | 5,692 |  |  | 15,944 |  |  | 16,681 |  |
| Industrial |  | 1,497 |  |  | 1,471 |  |  | 4,523 |  |  | 4,255 |  |
| Total depreciation |  | $ | 18,574 |  |  | $ | 17,306 |  |  | $ | 56,379 |  |  | $ | 51,025 |  |
| Amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 10,249 |  |  | $ | 9,902 |  |  | $ | 30,124 |  |  | $ | 29,567 |  |
| Transportation |  | 3,431 |  |  | 3,392 |  |  | 10,186 |  |  | 10,146 |  |
| Industrial |  | 1,357 |  |  | 2,570 |  |  | 3,910 |  |  | 7,705 |  |
| Total amortization |  | $ | 15,037 |  |  | $ | 15,864 |  |  | $ | 44,220 |  |  | $ | 47,418 |  |

[0001628280-25-047026:notes:181]
[same as prior period, unchanged from 0001628280-25-036650:notes:179]

[0001628280-25-047026:notes:182]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |  | September 27, 2025 |  | September 28, 2024 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 218,532 |  |  | $ | 211,940 |  |  | $ | 636,390 |  |  | $ | 604,198 |  |
| China |  | 146,045 |  |  | 133,051 |  |  | 421,782 |  |  | 379,730 |  |
| Other countries (a) |  | 260,063 |  |  | 222,399 |  |  | 734,188 |  |  | 677,335 |  |
| Total net sales |  | $ | 624,640 |  |  | $ | 567,390 |  |  | $ | 1,792,360 |  |  | $ | 1,661,263 |  |

[0001628280-25-047026:notes:183]
[same as prior period, unchanged from 0001628280-25-036650:notes:181]

[0001628280-25-047026:notes:184]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 73,367 |  |  | $ | 74,698 |  |
| China |  | 128,559 |  |  | 132,504 |  |
| Mexico |  | 85,471 |  |  | 89,558 |  |
| Germany |  | 106,272 |  |  | 58,758 |  |
| Philippines |  | 61,929 |  |  | 66,174 |  |
| Other countries |  | 58,367 |  |  | 55,376 |  |
| Total long-lived assets |  | $ | 513,965 |  |  | $ | 477,068 |  |

[0001628280-25-047026:notes:185]
[same as prior period, unchanged from 0001628280-25-036650:notes:183]

[0001628280-25-047026:notes:186]
|  |  | Nine Months Ended |
| (in thousands) |  | September 27, 2025 |  | September 28, 2024 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 8,724 |  |  | $ | 9,591 |  |
| China |  | 8,385 |  |  | 10,681 |  |
| Mexico |  | 4,953 |  |  | 8,875 |  |
| Germany |  | 14,958 |  |  | 12,160 |  |
| Philippines |  | 3,266 |  |  | 3,025 |  |
| Other countries |  | 4,800 |  |  | 5,759 |  |
| Total additions to long-lived assets |  | $ | 45,086 |  |  | $ | 50,091 |  |

[0001628280-25-047026:notes:187]
[same as prior period, unchanged from 0001628280-25-036650:notes:185]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-25-047026:notes:188]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0001628280-25-047026:notes:189]
As of September 27, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-25-047026:notes:190]
Product Warranty Liabilities

[0001628280-25-047026:notes:191]
The Company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0001628280-25-047026:notes:192]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0001628280-25-047026:notes:193]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0001628280-25-047026:notes:194]
Environmental Remediation Liabilities

[0001628280-25-047026:notes:195]
The Company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0001628280-25-047026:notes:196]
Legal Proceedings

[0001628280-25-047026:notes:197]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

[0001628280-25-047026:notes:198]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss, the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.

[0001628280-25-047026:notes:199]
Pending Litigation and Claims

[0001628280-25-047026:notes:200]
There were no material pending litigation or claims outstanding as of September 27, 2025.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-25-047026:notes:201]
Related Party Transactions

[0001628280-25-047026:notes:202]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0001628280-25-047026:notes:203]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0001628280-25-047026:notes:204]
EB Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0001628280-25-047026:notes:205]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services.

[0001628280-25-047026:notes:206]
|  |  | Three Months Ended September 27, 2025 |  | Three Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.1 |  | 2.4 |  |  | 0.6 |  | 0.2 |  | 0.6 |  |
|  |  | Nine Months Ended September 27, 2025 |  | Nine Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.7 |  | 0.8 |  | 5.7 |  |  | 3.0 |  | 0.6 |  | 3.5 |  |
|  |  | September 27, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.3 |  | — |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-047026:notes:207]
Subsequent Events
On October 24, 2025, the Company entered into a Membership Interest Purchase Agreement with Basler Holdings, LLC, pursuant to which the Company has agreed to acquire all of the issued and outstanding membership interests of Basler Electric Company (“Basler”). The purchase price is approximately $350 million in cash, subject to certain adjustments after closing. The completion of the transaction is subject to certain customary closing conditions including regulatory approval.

[0001628280-25-047026:notes:208]
Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. With three manufacturing facilities in Highland, IL, Taylor, TX and Piedras Negras, Mexico, Basler’s technologies regulate and protect mission-critical equipment for a broad and expanding customer base. The business will be reported in the Company's Industrial segment. The Company financed the transaction with cash on hand.
