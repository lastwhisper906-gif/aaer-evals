# LFUS MD&A — 0001628280-25-047026


## mdna

[0001628280-25-047026:mdna:1]
[same as prior period, unchanged from 0001628280-25-036650:mdna:1]

[0001628280-25-047026:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001628280-25-047026:mdna:3]
[same as prior period, unchanged from 0001628280-25-036650:mdna:3]

[0001628280-25-047026:mdna:4]
[same as prior period, unchanged from 0001628280-25-036650:mdna:4]

[0001628280-25-047026:mdna:5]
[same as prior period, unchanged from 0001628280-25-036650:mdna:5]

[0001628280-25-047026:mdna:6]
[same as prior period, unchanged from 0001628280-25-036650:mdna:6]

[0001628280-25-047026:mdna:7]
[same as prior period, unchanged from 0001628280-25-036650:mdna:7]

[0001628280-25-047026:mdna:8]
[same as prior period, unchanged from 0001628280-25-036650:mdna:8]

[0001628280-25-047026:mdna:9]
For the third quarter of 2025, the Company recognized net sales of $624.6 million, an increase of $57.3 million, or 10.1% as compared to $567.4 million in the third quarter of 2024 including $12.9 million or 2.3% of incremental net sales, from the Dortmund Fab acquisition (defined below) in the semiconductor business within the Electronics segment and $7.4 million, or 1.3% of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume in the Electronics segment. The Company recognized net income of $69.5 million, or $2.77 per diluted share, in the third quarter of 2025 compared to $58.1 million, or $2.32 per diluted share, in the third quarter of 2024. The increase in net income was primarily due to higher operating income from the electronics products business within the Electronics segment driven by increases in net sales, volume leverage and lower foreign exchange losses of $9.5 million.

[0001628280-25-047026:mdna:10]
Net cash provided by operating activities was $295.1 million for the nine months ended September 27, 2025 compared to $207.0 million for the nine months ended September 28, 2024. The increase in net cash provided by operating activities of $88.1 million was primarily due to higher cash earnings and reductions in working capital.

[0001628280-25-047026:mdna:11]
On October 24, 2025, the Company entered into a Membership Interest Purchase Agreement with Basler Holdings, LLC, pursuant to which the Company has agreed to acquire all of the issued and outstanding membership interests of Basler Electric Company. The purchase price is approximately $350 million in cash, subject to certain adjustments after closing. The completion of the transaction is subject to certain customary closing conditions including regulatory approval. The business will be reported in the Company's Industrial segment. The Company financed the transaction with cash on hand.

[0001628280-25-047026:mdna:12]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab was approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0001628280-25-047026:mdna:13]
Risk Related to Market Conditions

[0001628280-25-047026:mdna:14]
The Company performs its goodwill impairment tests annually on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. As part of its interim review for indicators of impairment, management analyzed potential changes in value of individual reporting units with goodwill based on each reporting unit’s operating results for the nine months ended September 27, 2025 compared to expected results. In addition, management considered how other key assumptions, including discount rates and expected long-term growth rates, used in the last fiscal year’s impairment analysis could be impacted by changes in market conditions and economic events.

[0001628280-25-047026:mdna:15]
Management considered trends in these factors when performing its assessment of whether an interim impairment review was required for any reporting unit. Based on this interim assessment, management concluded that as of September 27, 2025, no events or changes in circumstances indicated that it was more likely than not that the fair value of any reporting unit had declined below its carrying value. Nevertheless, significant changes in global economic and market conditions could result in changes to expectations of future financial results and key valuation assumptions. Such changes could result in revisions of management’s estimates of the fair value of the Company’s reporting units and could result in a material impairment of goodwill as of September 28, 2025, the Company’s next annual measurement date.

[0001628280-25-047026:mdna:16]
In particular, the Electronics-Semiconductor reporting unit within the Electronics segment is at risk for future impairment if projected operating results are not met or other inputs into the fair value measurement change. The potential reduction in the estimated fair value of the reporting unit is due to lower expectations for future revenue, profitability and cash flows for the Electronics-Semiconductor reporting unit as compared to the expectations of the 2024 annual goodwill impairment test driven by lower-than-expected demand in the power semiconductor business. Continued negative trends could have a significant impact on the estimate fair value of this reporting unit and could result in future impairment charges. As of the  September 29, 2024 annual goodwill impairment test, the Electronics-Semiconductor reporting unit’s estimated fair value exceeded book value by approximately 82%. As of September 27, 2025, the Electronics-Semiconductor reporting unit had $539.2 million of goodwill.

[0001628280-25-047026:mdna:17]
[same as prior period, unchanged from 0001628280-25-036650:mdna:12]

[0001628280-25-047026:mdna:18]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies" that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0001628280-25-047026:mdna:19]
[same as prior period, unchanged from 0001628280-25-036650:mdna:14]

[0001628280-25-047026:mdna:20]
[same as prior period, unchanged from 0001628280-25-036650:mdna:15]

[0001628280-25-047026:mdna:21]
[same as prior period, unchanged from 0001628280-25-036650:mdna:16]

[0001628280-25-047026:mdna:22]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The third quarter of 2025 included $1.6 million ($13.1 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the third quarter of 2025, the Company recognized $1.4 million ($3.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and a $0.3 million loss related to the sale of the Marine business within the Transportation segment. During the first quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustments related to the Dortmund Fab acquisition.

[0001628280-25-047026:mdna:23]
The third quarter of 2024 included $1.8 million ($9.4 million year-to-date) of restructuring charges primarily related to employee termination costs, and $1.0 million ($2.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the third quarter of 2024, the Company recorded a gain of $0.5 million related to the sale of a land use right within the Electronics segment. In addition, the Company recognized a gain of $1.0 million for the sale of two buildings within the Transportation segment during the first half of 2024.

[0001628280-25-047026:mdna:24]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Net sales |  | $ | 624,640 |  |  | $ | 567,390 |  |  | $ | 57,250 |  |  | 10.1 | % |  | $ | 1,792,360 |  |  | $ | 1,661,263 |  |  | $ | 131,097 |  |  | 7.9 | % |
| Cost of sales |  | 383,652 |  |  | 351,498 |  |  | 32,154 |  |  | 9.1 | % |  | 1,112,062 |  |  | 1,050,559 |  |  | 61,503 |  |  | 5.9 | % |
| Gross profit |  | 240,988 |  |  | 215,892 |  |  | 25,096 |  |  | 11.6 | % |  | 680,298 |  |  | 610,704 |  |  | 69,594 |  |  | 11.4 | % |
| Operating expenses |  | 143,572 |  |  | 128,071 |  |  | 15,501 |  |  | 12.1 | % |  | 419,954 |  |  | 402,425 |  |  | 17,529 |  |  | 4.4 | % |
| Operating income |  | 97,416 |  |  | 87,821 |  |  | 9,595 |  |  | 10.9 | % |  | 260,344 |  |  | 208,279 |  |  | 52,065 |  |  | 25.0 | % |
| Income before income taxes |  | 94,716 |  |  | 77,716 |  |  | 17,000 |  |  | 21.9 | % |  | 232,877 |  |  | 194,564 |  |  | 38,313 |  |  | 19.7 | % |
| Income taxes |  | 25,194 |  |  | 19,658 |  |  | 5,536 |  |  | 28.2 | % |  | 62,442 |  |  | 42,588 |  |  | 19,854 |  |  | 46.6 | % |
| Net income |  | 69,522 |  |  | 58,058 |  |  | 11,464 |  |  | 19.7 | % |  | 170,435 |  |  | 151,976 |  |  | 18,459 |  |  | 12.1 | % |

[0001628280-25-047026:mdna:25]
[same as prior period, unchanged from 0001628280-25-036650:mdna:20]

[0001628280-25-047026:mdna:26]
Net sales increased $57.3 million, or 10.1%, for the third quarter of 2025 compared to the third quarter of 2024 including $12.9 million or 2.3% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and $7.4 million or 1.3% of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume of $31.2 million in the electronics products business within the Electronics segment.

[0001628280-25-047026:mdna:27]
Net sales increased $131.1 million, or 7.9%, for the first nine months of 2025 compared to the first nine months of 2024 including $36.4 million or 2.2% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and $7.8 million of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume of $69.5 million in the electronics products business within the Electronics segment and $29.8 million in the Industrial segment due to higher end market demand and favorable price, partially offset by lower volume from the remaining semiconductor business within the Electronics segment.

[0001628280-25-047026:mdna:28]
[same as prior period, unchanged from 0001628280-25-036650:mdna:23]

[0001628280-25-047026:mdna:29]
Cost of sales was $383.7 million, or 61.4% of net sales, in the third quarter of 2025 compared to $351.5 million, or 61.9% of net sales, in the third quarter of 2024. As a percent of net sales, cost of sales decreased 0.5% primarily due to improved margin from the electronics products business within the Electronics segment driven by volume leverage and favorable product mix, partially offset by lower gross margin from the semiconductor business within the Electronics segment.

[0001628280-25-047026:mdna:30]
Cost of sales was $1,112.1 million, or 62.0% of net sales, in the first nine months of 2025 compared to $1,050.6 million, or 63.2% of net sales, in the first nine months of 2024. As a percent of net sales, cost of sales decreased 1.2% primarily driven by higher volume in the electronics products business within the Electronics segment and across all businesses in the Industrial segment. Additionally, improved margin from the passenger car products and the commercial vehicle businesses within the Transportation segment driven by volume leverage, favorable price, and cost reduction initiatives favorably impacted the decrease in cost of net sales as a percentage of net sales that was partially offset by lower margin from the semiconductor business within the Electronics segment.

[0001628280-25-047026:mdna:31]
[same as prior period, unchanged from 0001628280-25-036650:mdna:26]

[0001628280-25-047026:mdna:32]
Gross profit was $241.0 million, or 38.6% of net sales, in the third quarter of 2025 compared to $215.9 million, or 38.1% of net sales, in the third quarter of 2024. The $25.1 million increase in gross profit was primarily due to higher volume and favorable product mix from the electronics products business within the Electronics segment.

[0001628280-25-047026:mdna:33]
Gross profit was $680.3 million, or 38.0% of net sales, in the first nine months of 2025 compared to $610.7 million, or 36.8% of net sales, in the first nine months of 2024. The $69.6 million increase in gross profit was primarily from higher net sales in the electronics products business within the Electronics segment, across all businesses within the Industrial segment, and the passenger car products and the commercial vehicle businesses within the Transportation driven by higher volume, favorable price, and product mix.

[0001628280-25-047026:mdna:34]
[same as prior period, unchanged from 0001628280-25-036650:mdna:29]

[0001628280-25-047026:mdna:35]
Operating expenses were $143.6 million, or 23.0% of net sales, for the third quarter of 2025 compared to $128.1 million, or 22.6% of net sales, for the third quarter of 2024. The increase in operating expenses of $15.5 million was primarily due to higher selling, general, and administrative expenses of $15.7 million driven by higher annual incentive and stock compensation expenses, and the Dortmund Fab acquisition.

[0001628280-25-047026:mdna:36]
Operating expenses were $420.0 million, or 23.4% of net sales, for the first nine months of 2025 compared to $402.4 million, or 24.2% of net sales, for the first nine months of 2024. The increase in operating expenses of $17.5 million was primarily due to higher selling, general, and administrative expenses of $19.4 million driven by higher annual incentive compensation expenses and the Dortmund Fab acquisition and higher restructuring, impairment, and other charges of $2.8 million related to company-wide cost control initiatives implemented in the first quarter of 2025, partially offset by lower amortization expense of $3.2 million.

[0001628280-25-047026:mdna:37]
[same as prior period, unchanged from 0001628280-25-036650:mdna:32]

[0001628280-25-047026:mdna:38]
Operating income was $97.4 million, representing an increase of $9.6 million, or 10.9%, for the third quarter of 2025 compared to $87.8 million for the third quarter of 2024. The increase in operating income was due to higher gross profit from the electronics products business within the Electronics segment, partially offset by higher operating expenses mainly driven by higher annual incentive compensation expenses and the Dortmund Fab acquisition noted above. Operating margins increased from 15.5% in the third quarter of 2024 to 15.6% in the third quarter of 2025 driven by improved gross margin from the electronics products business within the Electronics segment, which was mostly offset by lower gross margin from the semiconductor business within the Electronics segment and higher incentive compensation expenses.

[0001628280-25-047026:mdna:39]
Operating income was $260.3 million, representing an increase of $52.1 million, or 25.0%, for the first nine months of 2025 compared to $208.3 million for the first nine months of 2024. The increase in operating income was due to higher gross profit across all segments, partially offset by higher operating expenses mainly driven by higher selling, general, and administrative expenses and restructuring, impairment, and other charges due to company-wide cost control initiatives implemented in the first quarter of 2025. Operating margins increased from 12.5% in the first nine months of 2024 to 14.5% in the first nine months of 2025 driven by improved gross margin in the electronics products business within the Electronics segment and across the Industrial and Transportation segments.

[0001628280-25-047026:mdna:40]
[same as prior period, unchanged from 0001628280-25-036650:mdna:35]

[0001628280-25-047026:mdna:41]
Income before income taxes was $94.7 million, or 15.2% of net sales, for the third quarter of 2025 compared to $77.7 million, or 13.7% of net sales, for the third quarter of 2024. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by lower foreign exchange losses of $9.5 million in the third quarter of 2025 compared to the third quarter of 2024, partially offset by unrealized losses of $0.1 million in the third quarter of 2025 compared to unrealized gains of $3.1 million in the third quarter of 2024 related to the Company's equity investment.

[0001628280-25-047026:mdna:42]
Income before income taxes was $232.9 million, or 13.0% of net sales, for the first nine months of 2025 compared to $194.6 million, or 11.7% of net sales, for the first nine months of 2024. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by higher foreign exchange losses of $11.2 million in the first nine months of 2025 compared to the first nine months of 2024, and unrealized losses of $2.1 million during the first nine months of 2025 compared to unrealized gains of $1.9 million during the first nine months of 2024 related to the Company's equity investment.

[0001628280-25-047026:mdna:43]
[same as prior period, unchanged from 0001628280-25-036650:mdna:38]

[0001628280-25-047026:mdna:44]
The effective tax rate for the three and nine months ended September 27, 2025 was 26.6% and 26.8%, respectively, compared to the effective tax rate for the three and nine months ended September 28, 2024 of 25.3% and 21.9%, respectively. The effective tax rate for 2025 was higher than the effective tax rate for the comparable 2024 periods primarily due to increases in losses in non-U.S. jurisdictions with no related tax benefit, as compared to 2024. The 2024 periods also recognized more favorable tax rate benefits due to lapses in the statute of limitations for previously unrecognized tax benefits, as compared to the 2025 periods.

[0001628280-25-047026:mdna:45]
The effective tax rate for three and nine months ended September 27, 2025 was higher than the statutory tax rate primarily due to foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit. The effective tax rate for the three and nine months ended September 28, 2024 was higher than the statutory tax rate primarily due to the proportion of pre-tax

[0001628280-25-047026:mdna:46]
income that is earned in higher tax jurisdictions, partially offset by the lapse in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter.

[0001628280-25-047026:mdna:47]
[same as prior period, unchanged from 0001628280-25-036650:mdna:41]

[0001628280-25-047026:mdna:48]
[same as prior period, unchanged from 0001628280-25-036650:mdna:42]

[0001628280-25-047026:mdna:49]
[same as prior period, unchanged from 0001628280-25-036650:mdna:43]

[0001628280-25-047026:mdna:50]
| Net Sales |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Electronics |  | $ | 357,457 |  |  | $ | 304,188 |  |  | $ | 53,269 |  |  | 17.5 | % |  | $ | 1,000,372 |  |  | $ | 900,932 |  |  | $ | 99,440 |  |  | 11.0 | % |
| Transportation |  | 171,311 |  |  | 171,381 |  |  | (70) |  |  | — | % |  | 512,573 |  |  | 510,711 |  |  | 1,862 |  |  | 0.4 | % |
| Industrial |  | 95,872 |  |  | 91,821 |  |  | 4,051 |  |  | 4.4 | % |  | 279,415 |  |  | 249,620 |  |  | 29,795 |  |  | 11.9 | % |
| Total |  | $ | 624,640 |  |  | $ | 567,390 |  |  | $ | 57,250 |  |  | 10.1 | % |  | $ | 1,792,360 |  |  | $ | 1,661,263 |  |  | $ | 131,097 |  |  | 7.9 | % |

[0001628280-25-047026:mdna:51]
| Segment Operating Income |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Electronics |  | $ | 63,640 |  |  | $ | 48,891 |  |  | $ | 14,749 |  |  | 30.2 | % |  | $ | 160,267 |  |  | $ | 132,859 |  |  | $ | 27,408 |  |  | 20.6 | % |
| Transportation |  | 20,187 |  |  | 23,485 |  |  | (3,298) |  |  | (14.0) | % |  | 67,178 |  |  | 54,925 |  |  | 12,253 |  |  | 22.3 | % |
| Industrial |  | 16,918 |  |  | 17,711 |  |  | (793) |  |  | (4.5) | % |  | 48,855 |  |  | 32,054 |  |  | 16,801 |  |  | 52.4 | % |
| Total segment operating income |  | 100,745 |  |  | 90,087 |  |  | 10,658 |  |  |  |  | 276,300 |  |  | 219,838 |  |  | 56,462 |  |  |  |
| Other (a) |  | (3,329) |  |  | (2,266) |  |  | (1,063) |  |  |  |  | (15,956) |  |  | (11,559) |  |  | (4,397) |  |  |  |
| Total operating income |  | $ | 97,416 |  |  | $ | 87,821 |  |  | $ | 9,595 |  |  | 10.9 | % |  | $ | 260,344 |  |  | $ | 208,279 |  |  | $ | 52,065 |  |  | 25.0 | % |

[0001628280-25-047026:mdna:52]
(a) Included in “Other” Operating income for the third quarter of 2025 was $1.6 million ($13.1 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the third quarter of 2025, the Company recognized $1.4 million ($3.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and a $0.3 million loss related to the sale of the Marine business within the Transportation segment. During the first quarter of 2025, the Company recognized $0.5 million of the purchase accounting inventory step-down adjustments related to the Dortmund Fab acquisition.

[0001628280-25-047026:mdna:53]
Included in "Other" Operating income for the third quarter of 2024 was $1.8 million ($9.4 million year-to-date) of restructuring charges primarily related to employee termination costs, and $1.0 million ($2.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the third quarter of 2024, the Company recorded a gain of $0.5 million related to the sale of a land use right within the Electronics segment. In addition, the Company recognized a gain of $1.0 million for the sale of two buildings within the Transportation segment during first half of 2024.

[0001628280-25-047026:mdna:54]
[same as prior period, unchanged from 0001628280-25-036650:mdna:48]

[0001628280-25-047026:mdna:55]
[same as prior period, unchanged from 0001628280-25-036650:mdna:49]

[0001628280-25-047026:mdna:56]
Net sales increased $53.3 million, or 17.5%, in the third quarter of 2025 compared to the third quarter of 2024 and included favorable changes in foreign exchange rates of $4.2 million or 1.4%. The net sales increase was primarily due to higher volume of $31.2 million from the electronics products business driven by higher end market demand and $12.9 million of incremental net sales from the Dortmund Fab acquisition in the semiconductor business.

[0001628280-25-047026:mdna:57]
Net sales increased $99.4 million, or 11.0%, in the first nine months of 2025 compared to the first nine months of 2024 and included favorable changes in foreign exchange rates of $4.0 million or 0.4%. The net sales increase was primarily due to higher volume of $69.5 million from the electronics products business driven by higher end market demand and $36.4 million of incremental net sales from the Dortmund Fab acquisition in the semiconductor business, partially offset by lower volume from the remaining semiconductor business.

[0001628280-25-047026:mdna:58]
[same as prior period, unchanged from 0001628280-25-036650:mdna:52]

[0001628280-25-047026:mdna:59]
Operating income was $63.6 million, representing an increase of $14.7 million, or 30.2%, for the third quarter of 2025 compared to $48.9 million for the third quarter of 2024. The increase in operating income was primarily from the electronics products business due to volume leverage and favorable product mix. Operating margins increased from 16.1% in the third quarter of 2024 to 17.8% in the third quarter of 2025 primarily due to volume leverage from the electronics products business, partially offset by lower gross margin from the semiconductor business.

[0001628280-25-047026:mdna:60]
Operating income was $160.3 million, representing an increase of $27.4 million, or 20.6%, for the first nine months of 2025 compared to $132.9 million for the first nine months of 2024. The increase in operating income was primarily from the electronics products business due to volume leverage. Operating margins increased from 14.7% in the first nine months of 2024 to 16.0% in the first nine months of 2025 primarily due to volume leverage from the electronics products business, partially offset by lower gross margin from the semiconductor business.

[0001628280-25-047026:mdna:61]
[same as prior period, unchanged from 0001628280-25-036650:mdna:55]

[0001628280-25-047026:mdna:62]
[same as prior period, unchanged from 0001628280-25-036650:mdna:56]

[0001628280-25-047026:mdna:63]
Net sales decreased $0.1 million in the third quarter of 2025 compared to the third quarter of 2024 and included favorable changes in foreign exchange rates of $2.8 million or 1.7%. The net sales decrease was primarily due to lower net sales of $2.6 million and $1.8 million in the automotive sensor products and commercial vehicle products businesses respectively, offset by higher net sales of $4.3 million in the passenger car products driven by favorable price.

[0001628280-25-047026:mdna:64]
Net sales increased $1.9 million, or 0.4%, in the first nine months of 2025 compared to the first nine months of 2024 and included favorable changes in foreign exchange rates of $3.8 million or 0.7%. The net sales increase was primarily due to higher net sales of $10.2 million in the passenger car products business driven by favorable price and increased end market demand and favorable changes in foreign exchange rates, partially offset by lower automotive sensors business volume of $10.3 million driven by the strategic exit of certain lower margin products.

[0001628280-25-047026:mdna:65]
[same as prior period, unchanged from 0001628280-25-036650:mdna:59]

[0001628280-25-047026:mdna:66]
Operating income was $20.2 million, representing a decrease of $3.3 million, or 14.0%, for the third quarter of 2025 compared to $23.5 million for the third quarter of 2024. The decrease in operating income was primarily due to higher operating expenses and lower gross margin from the commercial vehicle and automotive sensor products businesses, partially offset by higher gross margin from the passenger car products business driven by favorable price. Operating margins decreased from 13.7% in the third quarter of 2024 to 11.8% in the third quarter of 2025.

[0001628280-25-047026:mdna:67]
Operating income was $67.2 million, representing an increase of $12.3 million, or 22.3%, for the first nine months of 2025 compared to $54.9 million for the first nine months of 2024. The increase in operating income was primarily from the commercial vehicle and passenger car products businesses due to favorable price, volume leverage, and cost reduction initiatives. Operating margins increased from 10.8% in the first nine months of 2024 to 13.1% in the first nine months of 2025 primarily driven by improved gross margin from the passenger car and commercial vehicle products businesses, partially offset by lower gross margin in the automotive sensors business.

[0001628280-25-047026:mdna:68]
[same as prior period, unchanged from 0001628280-25-036650:mdna:62]

[0001628280-25-047026:mdna:69]
[same as prior period, unchanged from 0001628280-25-036650:mdna:63]

[0001628280-25-047026:mdna:70]
Net sales increased $4.1 million, or 4.4%, in the third quarter of 2025 compared to the third quarter of 2024 and included favorable changes in foreign exchange rates of $0.4 million. The net sales increase was due to higher net sales from industrial circuit protection products driven by favorable price and higher volume.

[0001628280-25-047026:mdna:71]
Net sales increased $29.8 million, or 11.9%, in the first nine months of 2025 compared to the first nine months of 2024. The net sales increase was due to higher volume from industrial control and sensor and industrial circuit protection products driven by higher end market demand and favorable price.

[0001628280-25-047026:mdna:72]
[same as prior period, unchanged from 0001628280-25-036650:mdna:66]

[0001628280-25-047026:mdna:73]
Operating income was $16.9 million, representing a decrease of $0.8 million, or 4.5%, for the third quarter of 2025 compared to $17.7 million for the third quarter of 2024. The decrease in operating income was due to  higher operating expenses. Operating margins decreased from 19.3% in the third quarter of 2024 to 17.6% in the third quarter of 2025 due to higher operating expenses and lower gross margin in the industrial circuit protection products driven by unfavorable mix and cost inflation.

[0001628280-25-047026:mdna:74]
Operating income was $48.9 million, representing an increase of $16.8 million, or 52.4%, for the first nine months of 2025 compared to $32.1 million for the first nine months of 2024. The increase in operating income was driven by higher volume from industrial control and sensor and industrial circuit protection products driven by increased end market demand, favorable price and cost reductions. Operating margins increased from 12.8% in the first nine months of 2024 to 17.5% in the first nine months of 2025 due to higher volume, favorable price and cost reductions.

[0001628280-25-047026:mdna:75]
[same as prior period, unchanged from 0001628280-25-036650:mdna:69]

[0001628280-25-047026:mdna:76]
[same as prior period, unchanged from 0001628280-25-036650:mdna:70]

[0001628280-25-047026:mdna:77]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Americas |  | $ | 249,880 |  |  | $ | 237,951 |  |  | $ | 11,929 |  |  | 5.0 | % |  | $ | 724,010 |  |  | $ | 681,064 |  |  | $ | 42,946 |  |  | 6.3 | % |
| Asia-Pacific |  | 238,008 |  |  | 213,942 |  |  | 24,066 |  |  | 11.2 | % |  | 667,095 |  |  | 621,731 |  |  | 45,364 |  |  | 7.3 | % |
| Europe |  | 136,752 |  |  | 115,497 |  |  | 21,255 |  |  | 18.4 | % |  | 401,255 |  |  | 358,468 |  |  | 42,787 |  |  | 11.9 | % |
| Total |  | $ | 624,640 |  |  | $ | 567,390 |  |  | $ | 57,250 |  |  | 10.1 | % |  | $ | 1,792,360 |  |  | $ | 1,661,263 |  |  | $ | 131,097 |  |  | 7.9 | % |

[0001628280-25-047026:mdna:78]
[same as prior period, unchanged from 0001628280-25-036650:mdna:72]

[0001628280-25-047026:mdna:79]
Net sales increased $11.9 million, or 5.0%, in the third quarter of 2025 compared to the third quarter of 2024 and included favorable changes in foreign exchange rates of $0.2 million. The increase in net sales was primarily due to higher volume from the electronics products business within the Electronics segment, partially offset by lower volume from the commercial vehicle businesses within the Transportation segment and industrial circuit protection products within the Industrial segment.

[0001628280-25-047026:mdna:80]
Net sales increased $42.9 million, or 6.3%, in the first nine months of 2025 compared to the first nine months of 2024 and included unfavorable changes in foreign exchange rates of $0.4 million. The increase in net sales was due to higher volume from the electronics products business within the Electronics segment and the Industrial segment, partially offset by lower volume from the automotive sensor products and passenger car product businesses within the Transportation segment.

[0001628280-25-047026:mdna:81]
[same as prior period, unchanged from 0001628280-25-036650:mdna:75]

[0001628280-25-047026:mdna:82]
Net sales increased $24.1 million, or 11.2%, in the third quarter of 2025 compared to the third quarter of 2024 and included favorable changes in foreign exchange rates of $0.2 million. The increase in net sales was primarily due to higher volume from the Electronics segment and industrial circuit protection products within the Industrial segment.

[0001628280-25-047026:mdna:83]
Net sales increased $45.4 million, or 7.3%, in the first nine months of 2025 compared to the first nine months of 2024 and included unfavorable changes in foreign exchange rates of $1.6 million. The increase in net sales was primarily due to higher volume from the electronics products business within the Electronics segment, industrial circuit protection products within the Industrial segment and the passenger car products and the commercial vehicle businesses within the Transportation segment, partially offset by lower volume from the automotive sensor business within the Transportation segment.

[0001628280-25-047026:mdna:84]
[same as prior period, unchanged from 0001628280-25-036650:mdna:79]

[0001628280-25-047026:mdna:85]
Net sales increased $21.3 million, or 18.4%, in the third quarter of 2025 compared to the third quarter of 2024 and included favorable changes in foreign exchange rates of $7.0 million. The increase in net sales was primarily due to $12.9 million or 11.1% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment.

[0001628280-25-047026:mdna:86]
Net sales increased $42.8 million, or 11.9%, in the first nine months of 2025 compared to the first nine months of 2024 and included favorable changes in foreign exchange rates of $9.8 million. The increase in net sales was primarily due to $36.4 million or 10.2% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment.

[0001628280-25-047026:mdna:87]
[same as prior period, unchanged from 0001628280-25-036650:mdna:82]

[0001628280-25-047026:mdna:88]
[same as prior period, unchanged from 0001628280-25-036650:mdna:83]

[0001628280-25-047026:mdna:89]
Cash and cash equivalents were $814.7 million as of September 27, 2025, an increase of $89.8 million, as compared to December 28, 2024. As of September 27, 2025, $345.0 million of the Company's $814.7 million cash and cash equivalents was held by U.S. subsidiaries.

[0001628280-25-047026:mdna:90]
Revolving Credit Facility and Term Loan

[0001628280-25-047026:mdna:91]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-25-047026:mdna:92]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-25-047026:mdna:93]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 27, 2025, the Company made term loan payments of $3.8 million and $11.3 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $270.0 million, respectively, as of September 27, 2025.

[0001628280-25-047026:mdna:94]
[same as prior period, unchanged from 0001628280-25-036650:mdna:90]

[0001628280-25-047026:mdna:95]
As of September 27, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.26%, and 4.13% on the hedged portion.

[0001628280-25-047026:mdna:96]
As of September 27, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 27, 2025, the Company was in compliance with all covenants under the Credit Agreement.

[0001628280-25-047026:mdna:97]
[same as prior period, unchanged from 0001628280-25-036650:mdna:93]

[0001628280-25-047026:mdna:98]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-25-047026:mdna:99]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-25-047026:mdna:100]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0001628280-25-047026:mdna:101]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-25-047026:mdna:102]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-25-047026:mdna:103]
[same as prior period, unchanged from 0001628280-25-036650:mdna:99]

[0001628280-25-047026:mdna:104]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage.

[0001628280-25-047026:mdna:105]
[same as prior period, unchanged from 0001628280-25-036650:mdna:101]

[0001628280-25-047026:mdna:106]
Debt Covenants

[0001628280-25-047026:mdna:107]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of September 27, 2025 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2025. As of September 27, 2025, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0001628280-25-047026:mdna:108]
[same as prior period, unchanged from 0001628280-25-036650:mdna:104]

[0001628280-25-047026:mdna:109]
[same as prior period, unchanged from 0001628280-25-036650:mdna:105]

[0001628280-25-047026:mdna:110]
[same as prior period, unchanged from 0001628280-25-036650:mdna:106]

[0001628280-25-047026:mdna:111]
During the third quarter of 2025, the Company paid quarterly dividends of $18.6 million to its shareholders. On October 29, 2025, the Company announced the declaration of a quarterly cash dividend of $0.75 per share payable on December 4, 2025 to stockholders of record as of November 20, 2025.

[0001628280-25-047026:mdna:112]
[same as prior period, unchanged from 0001628280-25-036650:mdna:108]

[0001628280-25-047026:mdna:113]
|  |  | First Nine Months |
| (in thousands) |  | 2025 |  | 2024 |
| Net cash provided by operating activities |  | $ | 295,099 |  |  | $ | 206,999 |  |
| Net cash used in investing activities |  | (99,701) |  |  | (41,134) |  |
| Net cash used in financing activities |  | (126,274) |  |  | (91,299) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 20,868 |  |  | (396) |  |
| Increase in cash, cash equivalents, and restricted cash |  | 89,992 |  |  | 74,170 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 726,437 |  |  | 557,123 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 816,429 |  |  | $ | 631,293 |  |

[0001628280-25-047026:mdna:114]
[same as prior period, unchanged from 0001628280-25-036650:mdna:110]

[0001628280-25-047026:mdna:115]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes, and other operating activities.

[0001628280-25-047026:mdna:116]
Net cash provided by operating activities was $295.1 million for the nine months ended September 27, 2025 compared to $207.0 million for the nine months ended September 28, 2024. The increase in net cash provided by operating activities of $88.1 million was primarily due to higher cash earnings and reductions in working capital.

[0001628280-25-047026:mdna:117]
[same as prior period, unchanged from 0001628280-25-036650:mdna:113]

[0001628280-25-047026:mdna:118]
Net cash used in investing activities was $99.7 million for the nine months ended September 27, 2025 compared to $41.1 million during the nine months ended September 28, 2024. Net cash paid for the Dortmund Fab acquisition was $57.4 million during the nine months ended September 27, 2025. Capital expenditures were $48.7 million, representing a decrease of $1.4 million, compared to the nine months ended September 28, 2024. During the nine months ended September 27, 2025, the Company received proceeds of $5.6 million from the sale of the Marine business within the Transportation segment. During the nine months ended September 28, 2024, the Company received proceeds of $9.7 million from the sale of a land use right within the Electronics segment and two buildings within the Transportation segment.

[0001628280-25-047026:mdna:119]
[same as prior period, unchanged from 0001628280-25-036650:mdna:115]

[0001628280-25-047026:mdna:120]
Net cash used in financing activities was $126.3 million for the nine months ended September 27, 2025 compared to $91.3 million for the nine months ended September 28, 2024. During the nine months ended September 27, 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025 and made payments of $11.3 million on the term loan. During the nine months ended September 28, 2024, the Company made payments of $3.8 million on the term loan. The Company paid dividends of $53.3 million and $49.7 million in the nine months ended September 27, 2025 and September 28, 2024, respectively. In addition, during the nine months ended September 27, 2025 and September 28, 2024, the Company repurchased 120,689 shares of its common stock totaling $27.4 million and 179,311 shares of its common stock totaling $40.9 million, respectively. The Company paid a $0.2 million excise tax related to the share repurchases during the nine months ended September 27, 2025. In addition, the Company received $17.9 million cash from stock option exercise activities during  the nine months ended September 27, 2025 compared to $5.0 million for the nine months ended September 28, 2024.

[0001628280-25-047026:mdna:121]
[same as prior period, unchanged from 0001628280-25-036650:mdna:117]

[0001628280-25-047026:mdna:122]
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program") to replace its previous 2021 program. The Company did not repurchase shares of its common stock for the three months ended September 27, 2025. During the nine months ended September 27, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. During the nine months ended September 28, 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program.

[0001628280-25-047026:mdna:123]
[same as prior period, unchanged from 0001628280-25-036650:mdna:119]

[0001628280-25-047026:mdna:124]
As of September 27, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-25-047026:mdna:125]
[same as prior period, unchanged from 0001628280-25-036650:mdna:121]

[0001628280-25-047026:mdna:126]
[same as prior period, unchanged from 0001628280-25-036650:mdna:122]

[0001628280-25-047026:mdna:127]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 28, 2024. During the nine months ended September 27, 2025, there were no significant changes in the application of critical accounting policies and estimates.
