# LFUS note change history — 0001628280-25-036650 → 0001628280-25-047026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001628280-25-047026:note_history:1]
As of September 27, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.
  (was, 2025-07-30, similarity 0.9887):
[0001628280-25-036650:note_history:1]
As of June 28, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

- changed (2025-10-29):
[0001628280-25-047026:note_history:2]
There were no material pending litigation or claims outstanding as of September 27, 2025.
  (was, 2025-07-30, similarity 0.9317):
[0001628280-25-036650:note_history:2]
There were no material pending litigation or claims outstanding as of June 28, 2025.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001628280-25-047026:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 27, 2025 and September 28, 2024:
  (was, 2025-07-30, similarity 0.9066):
[0001628280-25-036650:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 28, 2025 and June 29, 2024:

- added (2025-10-29):
[0001628280-25-047026:note_history:4]
|  |  | Three Months Ended September 27, 2025 |  | Nine Months Ended September 27, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 174,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 174,073 |  |  | $ | 499,329 |  |  | $ | — |  |  | $ | — |  |  | $ | 499,329 |  |
| Electronics – Passive Products and Sensors |  | 183,384 |  |  | — |  |  | — |  |  | 183,384 |  |  | 501,043 |  |  | — |  |  | — |  |  | 501,043 |  |
| Commercial Vehicle Products |  | — |  |  | 80,272 |  |  | — |  |  | 80,272 |  |  | — |  |  | 244,301 |  |  | — |  |  | 244,301 |  |
| Passenger Car Products |  | — |  |  | 75,636 |  |  | — |  |  | 75,636 |  |  | — |  |  | 220,822 |  |  | — |  |  | 220,822 |  |
| Automotive Sensors |  | — |  |  | 15,403 |  |  | — |  |  | 15,403 |  |  | — |  |  | 47,450 |  |  | — |  |  | 47,450 |  |
| Industrial Products |  | — |  |  | — |  |  | 95,872 |  |  | 95,872 |  |  | — |  |  | — |  |  | 279,415 |  |  | 279,415 |  |
| Total |  | $ | 357,457 |  |  | $ | 171,311 |  |  | $ | 95,872 |  |  | $ | 624,640 |  |  | $ | 1,000,372 |  |  | $ | 512,573 |  |  | $ | 279,415 |  |  | $ | 1,792,360 |  |

- added (2025-10-29):
[0001628280-25-047026:note_history:5]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

- changed (2025-10-29):
[0001628280-25-047026:note_history:6]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at September 27, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2025-07-30, similarity 0.7599):
[0001628280-25-036650:note_history:6]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at June 28, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2025-10-29):
[0001628280-25-047026:note_history:7]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 814,733 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,696 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 816,429 |  |  | $ | 726,437 |  |
  (was, 2025-07-30, similarity 0.927):
[0001628280-25-036650:note_history:7]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 685,184 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,699 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 686,883 |  |  | $ | 726,437 |  |

- added (2025-10-29):
[0001628280-25-047026:note_history:8]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software." The amendments in this update require the entity to start capitalizing software costs when both of the following criteria are met: (1) management has authorized and committed to funding the software project, and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the "probable-to-complete recognition threshold"). The amendments clarify that the intangibles disclosures are not required for capitalized internal-use software costs. Additionally, the amendments in this update supersede the website development costs guidance and incorporate the recognition requirements for website-specific development costs. The guidance is effective for fiscal years beginning after December 15, 2027 with early adoption permitted. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

- added (2025-10-29):
[0001628280-25-047026:note_history:9]
In September 2025, the FASB issued ASU No. 2025-05, "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets." The amendments in this update provide entities with a practical expedient when estimating expected credit losses for current accounts receivable and current contract assets arising from transactions accounted for under Topic 606. In developing reasonable and supportable forecasts as part of estimating expected credit losses, the practical expedient allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for fiscal years beginning after December 15, 2025 with early adoption permitted. The Company does not expect any material effect of the adoption of this guidance on the Company's Condensed Consolidated Financial Statements.

- changed (2025-10-29):
[0001628280-25-047026:note_history:10]
In November 2024, the FASB issued ASU No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are
  (was, 2025-07-30, similarity 0.7656):
[0001628280-25-036650:note_history:10]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.

- added (2025-10-29):
[0001628280-25-047026:note_history:11]
not separately disaggregated quantitatively (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Condensed Consolidated Financial Statements.

- changed (2025-10-29):
[0001628280-25-047026:note_history:12]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify disclosures in the Company's Condensed Consolidated Financial Statements.
  (was, 2025-07-30, similarity 0.995):
[0001628280-25-036650:note_history:12]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify disclosures in the Company's Consolidated Financial Statements.

- changed (2025-10-29):
[0001628280-25-047026:note_history:13]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.
  (was, 2025-07-30, similarity 0.6253):
[0001628280-25-036650:note_history:13]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may

- removed (2025-10-29):
[0001628280-25-036650:note_history:14]
|  |  | Three Months Ended June 28, 2025 |  | Six Months Ended June 28, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 166,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 166,967 |  |  | $ | 325,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,256 |  |
| Electronics – Passive Products and Sensors |  | 168,699 |  |  | — |  |  | — |  |  | 168,699 |  |  | 317,659 |  |  | — |  |  | — |  |  | 317,659 |  |
| Commercial Vehicle Products |  | — |  |  | 86,260 |  |  | — |  |  | 86,260 |  |  | — |  |  | 164,029 |  |  | — |  |  | 164,029 |  |
| Passenger Car Products |  | — |  |  | 76,151 |  |  | — |  |  | 76,151 |  |  | — |  |  | 145,186 |  |  | — |  |  | 145,186 |  |
| Automotive Sensors |  | — |  |  | 16,989 |  |  | — |  |  | 16,989 |  |  | — |  |  | 32,047 |  |  | — |  |  | 32,047 |  |
| Industrial Products |  | — |  |  | — |  |  | 98,347 |  |  | 98,347 |  |  | — |  |  | — |  |  | 183,543 |  |  | 183,543 |  |
| Total |  | $ | 335,666 |  |  | $ | 179,400 |  |  | $ | 98,347 |  |  | $ | 613,413 |  |  | $ | 642,915 |  |  | $ | 341,262 |  |  | $ | 183,543 |  |  | $ | 1,167,720 |  |

- removed (2025-10-29):
[0001628280-25-036650:note_history:15]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  |  |  |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

- removed (2025-10-29):
[0001628280-25-036650:note_history:16]
be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001628280-25-047026:note_history:17]
The carrying amounts of debt at September 27, 2025 and December 28, 2024 were as follows:
  (was, 2025-07-30, similarity 0.9281):
[0001628280-25-036650:note_history:17]
The carrying amounts of debt at June 28, 2025 and December 28, 2024 were as follows:

- changed (2025-10-29):
[0001628280-25-047026:note_history:18]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 270,000 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,889 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 1,955 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,068) |  |  | (2,766) |  |
| Total debt |  | 805,776 |  |  | 856,114 |  |
| Less: Current maturities |  | (16,955) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 788,821 |  |  | $ | 788,502 |  |
  (was, 2025-07-30, similarity 0.9695):
[0001628280-25-036650:note_history:18]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 273,750 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,079 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 2,692 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,305) |  |  | (2,766) |  |
| Total debt |  | 810,216 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,692) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 792,524 |  |  | $ | 788,502 |  |

- changed (2025-10-29):
[0001628280-25-047026:note_history:19]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 27, 2025, the Company made term loan payments of $3.8 million and $11.3 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $270.0 million, respectively, as of September 27, 2025.
  (was, 2025-07-30, similarity 0.9731):
[0001628280-25-036650:note_history:19]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended June 28, 2025, the Company made term loan payments of $3.8 million and $7.5 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $273.8 million, respectively, as of June 28, 2025.

- changed (2025-10-29):
[0001628280-25-047026:note_history:20]
As of September 27, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.26%, and 4.13% on the hedged portion.
  (was, 2025-07-30, similarity 0.9662):
[0001628280-25-036650:note_history:20]
As of June 28, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.68%, and 4.13% on the hedged portion.

- added (2025-10-29):
[0001628280-25-047026:note_history:21]
As of September 27, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 27, 2025, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2025-10-29):
[0001628280-25-047026:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of September 27, 2025, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2025-07-30, similarity 0.9399):
[0001628280-25-036650:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of June 28, 2025, the Company was in compliance with all covenants under the Senior Notes.

- changed (2025-10-29):
[0001628280-25-047026:note_history:23]
Interest paid on all Company debt was $11.1 million and $10.5 million for the three months ended September 27, 2025 and September 28, 2024, respectively, and $29.0 million and $30.1 million for the nine months ended September 27, 2025 and September 28, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.
  (was, 2025-07-30, similarity 0.8051):
[0001628280-25-036650:note_history:23]
Interest paid on all Company debt was $5.6 million and $6.4 million for the three months ended June 28, 2025 and June 29, 2024, respectively, and $17.8 million and $19.6 million for the six months ended June 28, 2025 and June 29, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.

- removed (2025-10-29):
[0001628280-25-036650:note_history:24]
As of June 28, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of June 28, 2025, the Company was in compliance with all covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001628280-25-047026:note_history:25]
The carrying amounts of debt at September 27, 2025 and December 28, 2024 were as follows:
  (was, 2025-07-30, similarity 0.9281):
[0001628280-25-036650:note_history:25]
The carrying amounts of debt at June 28, 2025 and December 28, 2024 were as follows:

- changed (2025-10-29):
[0001628280-25-047026:note_history:26]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 270,000 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,889 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 1,955 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,068) |  |  | (2,766) |  |
| Total debt |  | 805,776 |  |  | 856,114 |  |
| Less: Current maturities |  | (16,955) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 788,821 |  |  | $ | 788,502 |  |
  (was, 2025-07-30, similarity 0.9695):
[0001628280-25-036650:note_history:26]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 273,750 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,079 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 2,692 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,305) |  |  | (2,766) |  |
| Total debt |  | 810,216 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,692) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 792,524 |  |  | $ | 788,502 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001628280-25-047026:note_history:27]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services.
  (was, 2025-07-30, similarity 0.8476):
[0001628280-25-036650:note_history:27]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One of the Company's executive officers serves on the Board of Directors of ATEC.

- changed (2025-10-29):
[0001628280-25-047026:note_history:28]
|  |  | Three Months Ended September 27, 2025 |  | Three Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.1 |  | 2.4 |  |  | 0.6 |  | 0.2 |  | 0.6 |  |
|  |  | Nine Months Ended September 27, 2025 |  | Nine Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.7 |  | 0.8 |  | 5.7 |  |  | 3.0 |  | 0.6 |  | 3.5 |  |
|  |  | September 27, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.3 |  | — |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |
  (was, 2025-07-30, similarity 0.8491):
[0001628280-25-036650:note_history:28]
|  |  | Three Months Ended June 28, 2025 |  | Three Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.5 |  | 1.4 |  |  | 1.2 |  | 0.2 |  | 0.8 |  |
|  |  | Six Months Ended June 28, 2025 |  | Six Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.6 |  | $ | — |  | $ | — |  |  | $ | 0.9 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.7 |  | 3.3 |  |  | 2.4 |  | 0.4 |  | 2.9 |  |
|  |  | June 28, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | — |  | 0.1 |  | 0.6 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001628280-25-047026:note_history:29]
|  |  | Three Months Ended September 27, 2025 |  | Three Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.1 |  | 2.4 |  |  | 0.6 |  | 0.2 |  | 0.6 |  |
|  |  | Nine Months Ended September 27, 2025 |  | Nine Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.7 |  | 0.8 |  | 5.7 |  |  | 3.0 |  | 0.6 |  | 3.5 |  |
|  |  | September 27, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.3 |  | — |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |
  (was, 2025-07-30, similarity 0.8491):
[0001628280-25-036650:note_history:29]
|  |  | Three Months Ended June 28, 2025 |  | Three Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.5 |  | 1.4 |  |  | 1.2 |  | 0.2 |  | 0.8 |  |
|  |  | Six Months Ended June 28, 2025 |  | Six Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.6 |  | $ | — |  | $ | — |  |  | $ | 0.9 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.7 |  | 3.3 |  |  | 2.4 |  | 0.4 |  | 2.9 |  |
|  |  | June 28, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | — |  | 0.1 |  | 0.6 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001628280-25-047026:note_history:30]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 27, 2025 and September 28, 2024:
  (was, 2025-07-30, similarity 0.9066):
[0001628280-25-036650:note_history:30]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 28, 2025 and June 29, 2024:

- added (2025-10-29):
[0001628280-25-047026:note_history:31]
|  |  | Three Months Ended September 27, 2025 |  | Nine Months Ended September 27, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 174,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 174,073 |  |  | $ | 499,329 |  |  | $ | — |  |  | $ | — |  |  | $ | 499,329 |  |
| Electronics – Passive Products and Sensors |  | 183,384 |  |  | — |  |  | — |  |  | 183,384 |  |  | 501,043 |  |  | — |  |  | — |  |  | 501,043 |  |
| Commercial Vehicle Products |  | — |  |  | 80,272 |  |  | — |  |  | 80,272 |  |  | — |  |  | 244,301 |  |  | — |  |  | 244,301 |  |
| Passenger Car Products |  | — |  |  | 75,636 |  |  | — |  |  | 75,636 |  |  | — |  |  | 220,822 |  |  | — |  |  | 220,822 |  |
| Automotive Sensors |  | — |  |  | 15,403 |  |  | — |  |  | 15,403 |  |  | — |  |  | 47,450 |  |  | — |  |  | 47,450 |  |
| Industrial Products |  | — |  |  | — |  |  | 95,872 |  |  | 95,872 |  |  | — |  |  | — |  |  | 279,415 |  |  | 279,415 |  |
| Total |  | $ | 357,457 |  |  | $ | 171,311 |  |  | $ | 95,872 |  |  | $ | 624,640 |  |  | $ | 1,000,372 |  |  | $ | 512,573 |  |  | $ | 279,415 |  |  | $ | 1,792,360 |  |

- added (2025-10-29):
[0001628280-25-047026:note_history:32]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

- removed (2025-10-29):
[0001628280-25-036650:note_history:33]
|  |  | Three Months Ended June 28, 2025 |  | Six Months Ended June 28, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 166,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 166,967 |  |  | $ | 325,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,256 |  |
| Electronics – Passive Products and Sensors |  | 168,699 |  |  | — |  |  | — |  |  | 168,699 |  |  | 317,659 |  |  | — |  |  | — |  |  | 317,659 |  |
| Commercial Vehicle Products |  | — |  |  | 86,260 |  |  | — |  |  | 86,260 |  |  | — |  |  | 164,029 |  |  | — |  |  | 164,029 |  |
| Passenger Car Products |  | — |  |  | 76,151 |  |  | — |  |  | 76,151 |  |  | — |  |  | 145,186 |  |  | — |  |  | 145,186 |  |
| Automotive Sensors |  | — |  |  | 16,989 |  |  | — |  |  | 16,989 |  |  | — |  |  | 32,047 |  |  | — |  |  | 32,047 |  |
| Industrial Products |  | — |  |  | — |  |  | 98,347 |  |  | 98,347 |  |  | — |  |  | — |  |  | 183,543 |  |  | 183,543 |  |
| Total |  | $ | 335,666 |  |  | $ | 179,400 |  |  | $ | 98,347 |  |  | $ | 613,413 |  |  | $ | 642,915 |  |  | $ | 341,262 |  |  | $ | 183,543 |  |  | $ | 1,167,720 |  |

- removed (2025-10-29):
[0001628280-25-036650:note_history:34]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  |  |  |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-10-29):
[0001628280-25-047026:note_history:35]
Subsequent Events
On October 24, 2025, the Company entered into a Membership Interest Purchase Agreement with Basler Holdings, LLC, pursuant to which the Company has agreed to acquire all of the issued and outstanding membership interests of Basler Electric Company (“Basler”). The purchase price is approximately $350 million in cash, subject to certain adjustments after closing. The completion of the transaction is subject to certain customary closing conditions including regulatory approval.

- added (2025-10-29):
[0001628280-25-047026:note_history:36]
Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. With three manufacturing facilities in Highland, IL, Taylor, TX and Piedras Negras, Mexico, Basler’s technologies regulate and protect mission-critical equipment for a broad and expanding customer base. The business will be reported in the Company's Industrial segment. The Company financed the transaction with cash on hand.

- removed (2025-10-29):
[0001628280-25-036650:note_history:37]
Subsequent Events
