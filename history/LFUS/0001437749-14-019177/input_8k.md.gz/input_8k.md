# LFUS 8-K — 0001437749-14-018971 filed 2014-10-29

## item codes, every 8-K on or before 2014-10-31

- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2014-10-31

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-14-018971:8k_2_02:1]
EX-99
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-14-018971:8k_2_02:2]
ex99-1.htm

[0001437749-14-018971:8k_2_02:3]
Exhibit 99.1

[0001437749-14-018971:8k_2_02:4]
| NEWS RELEASE |  |

[0001437749-14-018971:8k_2_02:5]
CONTACT: Phil Franklin,

[0001437749-14-018971:8k_2_02:6]
Senior Vice President and CFO (773) 628-0810

[0001437749-14-018971:8k_2_02:7]
LITTELFUSE REPORTS THIRD QUARTER RESULTS

[0001437749-14-018971:8k_2_02:8]
CHICAGO, October 29, 2014 – Littelfuse, Inc. (NASDAQ:LFUS) today reported sales and earnings for the third quarter of 2014.

[0001437749-14-018971:8k_2_02:9]
Third Quarter Highlights

[0001437749-14-018971:8k_2_02:10]
|  | ● | Sales for the third quarter of 2014 were $217.6 million, an 8% increase compared to the prior-year quarter as strong growth in automotive and electronics more than offset a decline in the electrical business. Excluding acquisitions, sales increased 6% compared to the prior year. |

[0001437749-14-018971:8k_2_02:11]
|  | ● | On a GAAP basis, third quarter 2014 earnings were $1.32 per diluted share. This included $1.0 million of special items (see Supplemental Financial Information on page 8). Excluding these special items, earnings for the third quarter of 2014 were $1.35 per diluted share. |

[0001437749-14-018971:8k_2_02:12]
|  | ● | Operating margin (excluding special items) for the third quarter of 2014 improved as expected to 19.0% from 16.9% in the second quarter of 2014. The sequential margin improvement was primarily due to improved operational performance and lower stock compensation expense. |

[0001437749-14-018971:8k_2_02:13]
|  | ● | The effective tax rate for the second quarter was approximately 200 basis points higher than expected due to more income earned in high-tax jurisdictions (particularly the U.S.) and $0.6 million of one-time tax items. |

[0001437749-14-018971:8k_2_02:14]
|  | ● | Sales trends by business unit for the third quarter were as follows: |

[0001437749-14-018971:8k_2_02:15]
|  | o | Electronics sales increased 7% year over year due to growth in all regions with particular strength in Europe. |

[0001437749-14-018971:8k_2_02:16]
|  | o | Automotive sales increased 15% year over year reflecting double-digit growth across all product categories, with particular strength in sensors and commercial vehicle products. All regions contributed to the strong year-over-year growth. |

[0001437749-14-018971:8k_2_02:17]
|  | o | Electrical sales declined 1% year over year as continued weakness in the mining segment more than offset the acquisition of SymCom. Industrial fuse sales increased 16% sequentially from the weak second quarter performance but were down 7% year over year. |

[0001437749-14-018971:8k_2_02:18]
-more-

[0001437749-14-018971:8k_2_02:19]
|  | ● | The electronics book-to-bill ratio for the third quarter of 2014 was .88, although this has increased to above 1.0 for the month of October. |

[0001437749-14-018971:8k_2_02:20]
|  | ● | Cash provided by operating activities was a record $61.3 million for the third quarter of 2014 compared to $46.8 million for the third quarter of 2013. Capital expenditures for the third quarter of 2014 were $6.3 million compared to $10.9 million for the third quarter of 2013. |

[0001437749-14-018971:8k_2_02:21]
|  | ● | In the fourth quarter of 2014, in conjunction with the post-merger integration of Hamlin, the company expects to return over $90 million of cash to the U.S. from various overseas subsidiaries. |

[0001437749-14-018971:8k_2_02:22]
“The third quarter played out about as expected with a slight sequential decline in sales but with improved margins and earnings compared to the second quarter,” said Gordon Hunter, Chief Executive Officer. “The positive top-line trends continue in our automotive business, and while the electronics business also had solid year-over-year growth, the order rate softened heading into the seasonally-weaker fourth quarter. The electrical business continues to be challenged by weakness in the mining sector, but we were encouraged to see a significant increase in quoting activity and orders for custom products.”

[0001437749-14-018971:8k_2_02:23]
“We were pleased to see margins bounce back in the third quarter after a sub-par second quarter,” said Phil Franklin, Chief Financial Officer. “As a result of the improved margins and excellent working capital management, we had record cash flow for the quarter. Our strong cash flow coupled with the expected return of over $90 million of cash to the U.S., puts us in a better position than ever to fund share repurchases and dividend increases alongside our ongoing acquisition program.”

[0001437749-14-018971:8k_2_02:24]
Outlook

[0001437749-14-018971:8k_2_02:25]
|  | ● | Sales for the fourth quarter of 2014 are expected to be in the range of $201 to $211 million which represents 4% year-over-year growth at the midpoint. |

[0001437749-14-018971:8k_2_02:26]
|  | ● | Earnings for the fourth quarter of 2014 are expected to be in the range of $1.05 to $1.19 per diluted share, assuming a tax rate of 26-27%. |

[0001437749-14-018971:8k_2_02:27]
|  | ● | Capital expenditures are expected to increase to approximately $11 million for the fourth quarter of 2014 due to spending on a new building at the company’s Philippines site and several large automotive equipment purchases. |

[0001437749-14-018971:8k_2_02:28]
Dividend

[0001437749-14-018971:8k_2_02:29]
The company will pay a cash dividend of $0.25 per common share on December 4, 2014 to shareholders of record at the close of business on November 20, 2014.

[0001437749-14-018971:8k_2_02:30]
-more-

[0001437749-14-018971:8k_2_02:31]
Conference Call and Webcast Information

[0001437749-14-018971:8k_2_02:32]
Littelfuse will host a conference call today, Wednesday, October 29, 2014, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the third quarter results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay through December 30, 2014 on the company’s website.

[0001437749-14-018971:8k_2_02:33]
About Littelfuse

[0001437749-14-018971:8k_2_02:34]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power

[0001437749-14-018971:8k_2_02:35]
control and sensing. The company serves customers in the electronics, automotive and industrial markets

[0001437749-14-018971:8k_2_02:36]
with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 8,000 employees in more than 35 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: littelfuse.com.

[0001437749-14-018971:8k_2_02:37]
| “Safe Harbor” Statement under the Private Securities Litigation Reform Act of 1995. The statements in this press release that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended December 28, 2013. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended December 28, 2013. |

[0001437749-14-018971:8k_2_02:38]
LFUS-F

[0001437749-14-018971:8k_2_02:39]
# # #

[0001437749-14-018971:8k_2_02:40]
LITTELFUSE, INC.

[0001437749-14-018971:8k_2_02:41]
Net Sales and Operating Income by Business Unit

[0001437749-14-018971:8k_2_02:42]
(In thousands of USD, unaudited)

[0001437749-14-018971:8k_2_02:43]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics (2) |  | $ | 107,754 |  |  | $ | 101,013 |  |  |  | 7 | % |  | $ | 313,726 |  |  | $ | 271,878 |  |  |  | 15 | % |
| Automotive (3) |  |  | 80,639 |  |  |  | 70,386 |  |  |  | 15 | % |  |  | 245,083 |  |  |  | 194,319 |  |  |  | 26 | % |
| Electrical (4) |  |  | 29,215 |  |  |  | 29,641 |  |  |  | (1 | %) |  |  | 86,566 |  |  |  | 93,527 |  |  |  | (7 | %) |
| Total net sales (1) |  | $ | 217,608 |  |  | $ | 201,040 |  |  |  | 8 | % |  | $ | 645,375 |  |  | $ | 559,724 |  |  |  | 15 | % |

[0001437749-14-018971:8k_2_02:44]
| (1) | Total net sales for 2014 include an incremental $5.5M for the quarter and $51.8M year-to-date from business acquisitions. |

[0001437749-14-018971:8k_2_02:45]
| (2) | Total Electronics net sales for 2014 include an incremental $16.3M year-to-date from the Hamlin acquisition. |

[0001437749-14-018971:8k_2_02:46]
| (3) | Total Automotive net sales for 2014 include an incremental $20.2M year-to-date from the Hamlin acquisition. |

[0001437749-14-018971:8k_2_02:47]
| (4) | Total Electrical net sales for 2014 include an incremental $5.5M for the quarter and $15.3M year-to-date from the SymCom acquisition. |

[0001437749-14-018971:8k_2_02:48]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 25,800 |  |  | $ | 20,362 |  |  |  | 27 | % |  | $ | 70,805 |  |  | $ | 52,284 |  |  |  | 35 | % |
| Automotive |  |  | 12,227 |  |  |  | 11,135 |  |  |  | 10 | % |  |  | 35,158 |  |  |  | 29,531 |  |  |  | 19 | % |
| Electrical |  |  | 3,224 |  |  |  | 6,687 |  |  |  | (52 | %) |  |  | 7,541 |  |  |  | 18,801 |  |  |  | (60 | %) |
| Other (5) |  |  | (1,121 | ) (6) |  |  | (625 | ) |  |  | 79 | % |  |  | (6,065 | ) |  |  | (3,558 | ) |  |  | 70 | % |
| Total operating income |  | $ | 40,130 |  |  | $ | 37,559 |  |  |  | 7 | % |  | $ | 107,439 |  |  | $ | 97,058 |  |  |  | 11 | % |
| Interest expense |  |  | 1,292 |  |  |  | 939 |  |  |  |  |  |  |  | 3,736 |  |  |  | 1,959 |  |  |  |  |  |
| Investment impairment |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |  |  | 10,678 | (7) |  |  |  |  |
| Foreign exchange (gain) loss |  |  | (101 | ) |  |  | 1,476 |  |  |  |  |  |  |  | 2,022 |  |  |  | (1,929 | ) |  |  |  |  |
| Other (income) expense, net |  |  | (2,261 | ) |  |  | (1,380 | ) |  |  |  |  |  |  | (4,893 | ) |  |  | (3,543 | ) |  |  |  |  |
| Income before taxes |  | $ | 41,200 |  |  | $ | 36,524 |  |  |  | 13 | % |  | $ | 106,574 |  |  | $ | 89,893 |  |  |  | 19 | % |

[0001437749-14-018971:8k_2_02:49]
| (5) | "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. |

[0001437749-14-018971:8k_2_02:50]
| (6) | Tax consulting and legal expenses to effect changes in the company's legal structure that will enable the up-streaming of cash to the U.S. in the fourth quarter of 2014. |

[0001437749-14-018971:8k_2_02:51]
| (7) | Impairment and loan losses from investment in Shocking Technologies. |

[0001437749-14-018971:8k_2_02:52]
-more-

[0001437749-14-018971:8k_2_02:53]
LITTELFUSE, INC.

[0001437749-14-018971:8k_2_02:54]
Condensed Consolidated Balance Sheets

[0001437749-14-018971:8k_2_02:55]
(In thousands of USD, except share amounts)

[0001437749-14-018971:8k_2_02:56]
|  |  | September 27,2014 |  |  | December 28,2013 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 378,276 |  |  | $ | 305,192 |  |
| Short-term investments |  |  | 38 |  |  |  | 6,886 |  |
| Accounts receivable, less allowances |  |  | 134,706 |  |  |  | 127,887 |  |
| Inventories |  |  | 99,822 |  |  |  | 92,591 |  |
| Deferred income taxes |  |  | 10,722 |  |  |  | 10,463 |  |
| Prepaid expenses and other current assets |  |  | 16,570 |  |  |  | 17,080 |  |
| Assets held for sale |  |  | 5,500 |  |  |  | 5,500 |  |
| Total current assets |  |  | 645,634 |  |  |  | 565,599 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 5,969 |  |  |  | 4,382 |  |
| Buildings |  |  | 66,780 |  |  |  | 59,699 |  |
| Equipment |  |  | 363,438 |  |  |  | 354,475 |  |
|  |  |  | 436,187 |  |  |  | 418,556 |  |
| Accumulated depreciation |  |  | (278,927 | ) |  |  | (268,383 | ) |
| Net property, plant and equipment |  |  | 157,260 |  |  |  | 150,173 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 24,514 |  |  |  | 25,166 |  |
| Distribution network |  |  | 39,604 |  |  |  | 42,685 |  |
| Customer lists, trademarks and tradenames |  |  | 42,911 |  |  |  | 30,506 |  |
| Goodwill |  |  | 198,702 |  |  |  | 186,464 |  |
|  |  |  | 305,731 |  |  |  | 284,821 |  |
| Investments |  |  | 13,115 |  |  |  | 12,286 |  |
| Deferred income taxes |  |  | 5,325 |  |  |  | 5,092 |  |
| Other assets |  |  | 6,750 |  |  |  | 6,402 |  |
| Total assets |  | $ | 1,133,815 |  |  | $ | 1,024,373 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 37,062 |  |  | $ | 33,872 |  |
| Accrued payroll |  |  | 28,022 |  |  |  | 29,437 |  |
| Accrued expenses |  |  | 13,342 |  |  |  | 13,087 |  |
| Accrued severance |  |  | 320 |  |  |  | 182 |  |
| Accrued income taxes |  |  | 15,059 |  |  |  | 5,931 |  |
| Deferred income taxes |  |  | 7 |  |  |  | 229 |  |
| Current portion of long-term debt |  |  | 186,500 |  |  |  | 126,000 |  |
| Total current liabilities |  |  | 280,312 |  |  |  | 208,738 |  |
| Long-term debt, less current portion |  |  | 90,000 |  |  |  | 93,750 |  |
| Deferred income taxes |  |  | 10,821 |  |  |  | 11,585 |  |
| Accrued post-retirement benefits |  |  | 225 |  |  |  | 8,528 |  |
| Other long-term liabilities |  |  | 14,558 |  |  |  | 14,856 |  |
| Total equity |  |  | 737,899 |  |  |  | 686,916 |  |
| Total liabilities and equity |  | $ | 1,133,815 |  |  | $ | 1,024,373 |  |

[0001437749-14-018971:8k_2_02:57]
Common shares issued and outstanding of

[0001437749-14-018971:8k_2_02:58]
22,541,918 and 22,467,491 at September 27, 2014 and

[0001437749-14-018971:8k_2_02:59]
December 28, 2013, respectively.

[0001437749-14-018971:8k_2_02:60]
-more-

[0001437749-14-018971:8k_2_02:61]
LITTELFUSE, INC.

[0001437749-14-018971:8k_2_02:62]
Consolidated Statements of Comprehensive Income

[0001437749-14-018971:8k_2_02:63]
(In thousands of USD, except per share data, unaudited)

[0001437749-14-018971:8k_2_02:64]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | September 27, 2014 |  |  | September 28, 2013 |  |  | September 27, 2014 |  |  | September 28, 2013 |  |
| Net sales |  | $ | 217,608 |  |  | $ | 201,040 |  |  | $ | 645,375 |  |  | $ | 559,724 |  |
| Cost of sales |  |  | 130,228 |  |  |  | 120,080 |  |  |  | 396,506 |  |  |  | 340,601 |  |
| Gross profit |  |  | 87,380 |  |  |  | 80,960 |  |  |  | 248,869 |  |  |  | 219,123 |  |
| Selling, general and administrative |  |  | 36,647 |  |  |  | 34,437 |  |  |  | 109,146 |  |  |  | 98,091 |  |
| Research and development expenses |  |  | 7,449 |  |  |  | 6,217 |  |  |  | 22,833 |  |  |  | 17,725 |  |
| Amortization of intangibles |  |  | 3,154 |  |  |  | 2,747 |  |  |  | 9,451 |  |  |  | 6,249 |  |
|  |  |  | 47,250 |  |  |  | 43,401 |  |  |  | 141,430 |  |  |  | 122,065 |  |
| Operating income |  |  | 40,130 |  |  |  | 37,559 |  |  |  | 107,439 |  |  |  | 97,058 |  |
| Interest expense |  |  | 1,292 |  |  |  | 939 |  |  |  | 3,736 |  |  |  | 1,959 |  |
| Impairment and loan loss in unconsolidated affiliate |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10,678 |  |
| Foreign currency revaluation (income) expense |  |  | (101 | ) |  |  | 1,476 |  |  |  | 2,022 |  |  |  | (1,929 | ) |
| Other (income) expense, net |  |  | (2,261 | ) |  |  | (1,380 | ) |  |  | (4,893 | ) |  |  | (3,543 | ) |
| Income before income taxes |  |  | 41,200 |  |  |  | 36,524 |  |  |  | 106,574 |  |  |  | 89,893 |  |
| Income taxes |  |  | 11,260 |  |  |  | 9,534 |  |  |  | 26,667 |  |  |  | 24,767 |  |
| Net income |  | $ | 29,940 |  |  | $ | 26,990 |  |  | $ | 79,907 |  |  | $ | 65,126 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.33 |  |  | $ | 1.20 |  |  | $ | 3.55 |  |  | $ | 2.92 |  |
| Diluted |  | $ | 1.32 |  |  | $ | 1.19 |  |  | $ | 3.52 |  |  | $ | 2.89 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 25,536 |  |  |  | 22,428 |  |  |  | 22,536 |  |  |  | 22,274 |  |
| Diluted |  |  | 22,689 |  |  |  | 22,625 |  |  |  | 22,722 |  |  |  | 22,497 |  |
| Diluted Net Income Per Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 29,940 |  |  | $ | 26,990 |  |  | $ | 79,907 |  |  | $ | 65,126 |  |
| Less: income allocated to participating securities |  |  | - |  |  |  | (3 | ) |  |  | - |  |  |  | (38 | ) |
| Net income available to common shareholders |  | $ | 29,940 |  |  | $ | 26,987 |  |  | $ | 79,907 |  |  | $ | 65,088 |  |
| Weighted average shares adjusted for securities |  |  | 22,689 |  |  |  | 22,625 |  |  |  | 22,722 |  |  |  | 22,497 |  |
| Diluted net income per share |  | $ | 1.32 |  |  | $ | 1.19 |  |  | $ | 3.52 |  |  | $ | 2.89 |  |
| Comprehensive income |  | $ | 13,209 |  |  | $ | 36,707 |  |  | $ | 66,444 |  |  | $ | 62,325 |  |

[0001437749-14-018971:8k_2_02:65]
-more-

[0001437749-14-018971:8k_2_02:66]
LITTELFUSE, INC.

[0001437749-14-018971:8k_2_02:67]
Consolidated Statements of Cash Flows

[0001437749-14-018971:8k_2_02:68]
(In thousands of USD, unaudited)

[0001437749-14-018971:8k_2_02:69]
|  |  | For the Nine Months Ended |  |
|  |  | September 27, 2014 |  |  | September 28, 2013 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 79,907 |  |  | $ | 65,126 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 21,736 |  |  |  | 19,603 |  |
| Amortization of intangibles |  |  | 9,451 |  |  |  | 6,249 |  |
| Impairment and loan loss in unconsolidated affiliate |  |  | - |  |  |  | 10,678 |  |
| Non-cash inventory charge (1) |  |  | 2,769 |  |  |  | 2,069 |  |
| Stock-based compensation |  |  | 7,168 |  |  |  | 7,030 |  |
| Excess tax benefit on stock-based compensation |  |  | (2,477 | ) |  |  | (3,763 | ) |
| Loss on sale of assets |  |  | 673 |  |  |  | 169 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (9,728 | ) |  |  | (16,348 | ) |
| Inventories |  |  | (4,118 | ) |  |  | (4,537 | ) |
| Accounts payable |  |  | 3,024 |  |  |  | 6,659 |  |
| Accrued expenses (including post retirement) |  |  | (7,080 | ) |  |  | (11,743 | ) |
| Accrued payroll and severance |  |  | (1,198 | ) |  |  | 5,492 |  |
| Accrued taxes |  |  | 5,756 |  |  |  | (2,167 | ) |
| Prepaid expenses and other |  |  | (2,052 | ) |  |  | 1,294 |  |
| Net cash provided by operating activities |  |  | 103,831 |  |  |  | 85,811 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (19,422 | ) |  |  | (25,328 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (52,768 | ) |  |  | (145,000 | ) |
| Purchase of short-term investments |  |  | - |  |  |  | (8,478 | ) |
| Proceeds from maturities of short-term investments |  |  | 6,770 |  |  |  | - |  |
| Proceeds from sale of assets |  |  | 72 |  |  |  | 158 |  |
| Net cash used in investing activities |  |  | (65,348 | ) |  |  | (178,648 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from term loan |  |  | - |  |  |  | 100,000 |  |
| Proceeds of revolving credit facility |  |  | 97,500 |  |  |  | 160,500 |  |
| Payments of term loan |  |  | (3,750 | ) |  |  | - |  |
| Payments of revolving credit facility |  |  | (37,000 | ) |  |  | (116,000 | ) |
| Debt issuance costs paid |  |  | (108 | ) |  |  | (809 | ) |
| Cash dividends paid |  |  | (15,543 | ) |  |  | (13,789 | ) |
| Purchase of common stock |  |  | (14,283 | ) |  |  | - |  |
| Proceeds from exercise of stock options |  |  | 12,170 |  |  |  | 19,335 |  |
| Excess tax benefit on stock-based compensation |  |  | 2,477 |  |  |  | 3,763 |  |
| Net cash provided by financing activities |  |  | 41,463 |  |  |  | 153,000 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (6,862 | ) |  |  | (2,631 | ) |
| Increase in cash and cash equivalents |  |  | 73,084 |  |  |  | 57,532 |  |
| Cash and cash equivalents at beginning of period |  |  | 305,192 |  |  |  | 235,404 |  |
| Cash and cash equivalents at end of period |  | $ | 378,276 |  |  | $ | 292,936 |  |

[0001437749-14-018971:8k_2_02:70]
| (1) | Purchase accounting adjustment related to acquisitions. |

[0001437749-14-018971:8k_2_02:71]
-more-

[0001437749-14-018971:8k_2_02:72]
LITTELFUSE, INC.

[0001437749-14-018971:8k_2_02:73]
Supplemental Financial Information

[0001437749-14-018971:8k_2_02:74]
(in millions of USD except share amounts)

[0001437749-14-018971:8k_2_02:75]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | YTD-14 |  |  | Q1-13 |  |  | Q2-13 |  |  | Q3-13 |  |  | YTD-13 |  |
| GAAP diluted EPS |  | $ | 1.12 |  |  | $ | 1.08 |  |  | $ | 1.32 |  |  | $ | 3.52 |  |  | $ | 0.51 |  |  | $ | 1.18 |  |  | $ | 1.19 |  |  | $ | 2.89 |  |
| EPS impact of special items (below) |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.03 |  |  |  | 0.25 |  |  |  | 0.44 |  |  |  | (0.03 | ) |  |  | 0.07 |  |  |  | 0.48 |  |
| Adjusted diluted EPS |  | $ | 1.16 |  |  | $ | 1.26 |  |  | $ | 1.35 |  |  | $ | 3.77 |  |  | $ | 0.95 |  |  | $ | 1.15 |  |  | $ | 1.26 |  |  | $ | 3.37 |  |
| Year-over-year adjusted EPS growth |  |  | 22 | % |  |  | 10 | % |  |  | 7 | % |  |  | 12 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-14-018971:8k_2_02:76]
| Special Items (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | - |  |  | $ | 2.8 |  |  | $ | - |  |  | $ | 1.7 |  |  | $ | 0.3 |  |  | $ | 2.1 |  |
| Restructuring |  |  | - |  |  |  | 2.0 |  |  |  | 1.1 |  |  |  | 3.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Acquisition expenses |  |  | - |  |  |  | 0.2 |  |  |  | - |  |  |  | 0.2 |  |  |  | - |  |  |  | 1.2 |  |  |  | 0.3 |  |  |  | 1.5 |  |
| Adjustment to Operating income |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 6.1 |  |  |  | - |  |  |  | 2.9 |  |  |  | 0.6 |  |  |  | 3.6 |  |
| Impairment charges |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10.7 |  |  |  | - |  |  |  | - |  |  |  | 10.7 |  |
| Foreign exchange (gain)/loss |  |  | (0.3 | ) |  |  | 2.4 |  |  |  | (0.1 | ) |  |  | 2.0 |  |  |  | - |  |  |  | (3.7 | ) |  |  | 1.5 |  |  |  | (2.2 | ) |
| Adjustment to pre-tax income |  | $ | 1.2 |  |  | $ | 5.9 |  |  | $ | 1.0 |  |  | $ | 8.1 |  |  | $ | 10.7 |  |  | $ | (0.8 | ) |  | $ | 2.1 |  |  | $ | 12.0 |  |
| EPS impact of above special items |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.03 |  |  | $ | 0.25 |  |  | $ | 0.29 |  |  | $ | (0.03 | ) |  | $ | 0.07 |  |  | $ | 0.33 |  |
| EPS impact of Shocking tax adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.15 |  |  |  | - |  |  |  | - |  |  |  | 0.15 |  |
| Total EPS impact |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.03 |  |  | $ | 0.25 |  |  | $ | 0.44 |  |  | $ | (0.03 | ) |  | $ | 0.07 |  |  | $ | 0.48 |  |

[0001437749-14-018971:8k_2_02:77]
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | YTD-14 |  |  | Q1-13 |  |  | Q2-13 |  |  | Q3-13 |  |  | YTD-13 |  |
| Net sales |  | $ | 206.9 |  |  | $ | 220.9 |  |  | $ | 217.6 |  |  | $ | 645.4 |  |  | $ | 170.9 |  |  | $ | 187.8 |  |  | $ | 201.0 |  |  | $ | 559.7 |  |
| GAAP operating income |  | $ | 33.6 |  |  | $ | 33.7 |  |  | $ | 40.1 |  |  | $ | 107.4 |  |  | $ | 28.1 |  |  | $ | 31.4 |  |  | $ | 37.6 |  |  | $ | 97.1 |  |
| Add back special operating items |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 6.1 |  |  |  | - |  |  |  | 2.9 |  |  |  | 0.6 |  |  |  | 3.6 |  |
| Adjusted operating income |  | $ | 35.0 |  |  | $ | 37.3 |  |  | $ | 41.3 |  |  | $ | 113.5 |  |  | $ | 28.1 |  |  | $ | 34.3 |  |  | $ | 38.2 |  |  | $ | 100.7 |  |
| Adjusted operating margin |  |  | 16.9 | % |  |  | 16.9 | % |  |  | 19.0 | % |  |  | 17.6 | % |  |  | 16.5 | % |  |  | 18.3 | % |  |  | 19.0 | % |  |  | 18.0 | % |
| Add back amortization |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 3.2 |  |  |  | 9.5 |  |  |  | 1.6 |  |  |  | 1.9 |  |  |  | 2.7 |  |  |  | 6.2 |  |
| Add back depreciation |  |  | 7.0 |  |  |  | 7.5 |  |  |  | 7.3 |  |  |  | 21.7 |  |  |  | 6.2 |  |  |  | 6.5 |  |  |  | 6.9 |  |  |  | 19.6 |  |
| Adjusted EBITDA |  | $ | 45.2 |  |  | $ | 47.8 |  |  | $ | 51.7 |  |  | $ | 144.7 |  |  | $ | 35.9 |  |  | $ | 42.8 |  |  | $ | 47.8 |  |  | $ | 126.5 |  |
| Adjusted EBITDA margin |  |  | 21.8 | % |  |  | 21.7 | % |  |  | 23.8 | % |  |  | 22.4 | % |  |  | 21.0 | % |  |  | 22.8 | % |  |  | 23.8 | % |  |  | 22.6 | % |
| Year-over-year adjusted EBITDA growth |  |  | 26 | % |  |  | 12 | % |  |  | 8 | % |  |  | 14 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-14-018971:8k_2_02:78]
Note: Totals will not always foot due to rounding

[0001437749-14-018971:8k_2_02:79]
# # #
