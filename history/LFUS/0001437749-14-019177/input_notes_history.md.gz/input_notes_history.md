# LFUS note change history — 0001437749-14-013895 → 0001437749-14-019177


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-10-31):
[0001437749-14-019177:note_history:1]
The carrying amounts of long-term debt at September 27, 2014 and December 28, 2013 are as follows (in thousands):
  (was, 2014-08-01, similarity 0.9453):
[0001437749-14-013895:note_history:1]
The carrying amounts of long-term debt at June 28, 2014 and December 28, 2013 are as follows (in thousands):

- changed (2014-10-31):
[0001437749-14-019177:note_history:2]
|  |  | September 27, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 95,000 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 181,500 |  |  |  | 121,000 |  |
| Total debt |  |  | 276,500 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 186,500 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 90,000 |  |  | $ | 93,750 |  |
  (was, 2014-08-01, similarity 0.975):
[0001437749-14-013895:note_history:2]
|  |  | June 28, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 96,250 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 199,000 |  |  |  | 121,000 |  |
| Total debt |  |  | 295,250 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 204,000 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 91,250 |  |  | $ | 93,750 |  |

- changed (2014-10-31):
[0001437749-14-019177:note_history:3]
On May 31, 2013, the company entered into a new credit agreement with J.P Morgan Securities LLC for up to $325.0 million which consisted of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of September 27, 2014, the company had available $92.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.50% (1.65% as of September 27, 2014). At September 27, 2014, the company was in compliance with all covenants under the revolving credit facility.
  (was, 2014-08-01, similarity 0.837):
[0001437749-14-013895:note_history:3]
On May 31, 2013, the company entered into a new credit agreement with J.P Morgan Securities LLC for up to $325.0 million which consisted of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of June 28, 2014, the company had available $75.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.250% (1.4% as of June 28, 2014). At June 28, 2014, the company was in compliance with all covenants under the revolving credit facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-10-31):
[0001437749-14-019177:note_history:4]
|  |  | September 27, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 95,000 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 181,500 |  |  |  | 121,000 |  |
| Total debt |  |  | 276,500 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 186,500 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 90,000 |  |  | $ | 93,750 |  |
  (was, 2014-08-01, similarity 0.975):
[0001437749-14-013895:note_history:4]
|  |  | June 28, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 96,250 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 199,000 |  |  |  | 121,000 |  |
| Total debt |  |  | 295,250 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 204,000 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 91,250 |  |  | $ | 93,750 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-10-31):
[0001437749-14-013895:note_history:5]
13. Subsequent Events

- removed (2014-10-31):
[0001437749-14-013895:note_history:6]
On July 31, 2014, the company terminated the Pension Plan. Distribution of plan assets resulting from the Pension Plan termination will not be made until the Internal Revenue Service and the Pension Benefit Guaranty Corporation determine that the termination satisfies applicable regulatory requirements. As a result of the termination of the Pension Plan, each participant will become fully vested in his or her benefits under the Pension Plan without regard to age and years of service. All participants will have a choice of receiving a lump sum payment or an annuity in full payment of their benefits accrued under the Pension Plan.
