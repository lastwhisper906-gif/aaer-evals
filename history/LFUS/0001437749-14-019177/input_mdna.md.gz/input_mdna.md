# LFUS MD&A — 0001437749-14-019177


## mdna

[0001437749-14-019177:mdna:1]
[same as prior period, unchanged from 0001437749-14-013895:mdna:1]

[0001437749-14-019177:mdna:2]
[same as prior period, unchanged from 0001437749-14-013895:mdna:2]

[0001437749-14-019177:mdna:3]
[same as prior period, unchanged from 0001437749-14-013895:mdna:3]

[0001437749-14-019177:mdna:4]
[same as prior period, unchanged from 0001437749-14-013895:mdna:4]

[0001437749-14-019177:mdna:5]
[same as prior period, unchanged from 0001437749-14-013895:mdna:5]

[0001437749-14-019177:mdna:6]
[same as prior period, unchanged from 0001437749-14-013895:mdna:6]

[0001437749-14-019177:mdna:7]
[same as prior period, unchanged from 0001437749-14-013895:mdna:7]

[0001437749-14-019177:mdna:8]
[same as prior period, unchanged from 0001437749-14-013895:mdna:8]

[0001437749-14-019177:mdna:9]
[same as prior period, unchanged from 0001437749-14-013895:mdna:9]

[0001437749-14-019177:mdna:10]
[same as prior period, unchanged from 0001437749-14-013895:mdna:10]

[0001437749-14-019177:mdna:11]
[same as prior period, unchanged from 0001437749-14-013895:mdna:11]

[0001437749-14-019177:mdna:12]
[same as prior period, unchanged from 0001437749-14-013895:mdna:12]

[0001437749-14-019177:mdna:13]
[same as prior period, unchanged from 0001437749-14-013895:mdna:13]

[0001437749-14-019177:mdna:14]
[same as prior period, unchanged from 0001437749-14-013895:mdna:14]

[0001437749-14-019177:mdna:15]
[same as prior period, unchanged from 0001437749-14-013895:mdna:15]

[0001437749-14-019177:mdna:16]
[same as prior period, unchanged from 0001437749-14-013895:mdna:16]

[0001437749-14-019177:mdna:17]
[same as prior period, unchanged from 0001437749-14-013895:mdna:17]

[0001437749-14-019177:mdna:18]
14

[0001437749-14-019177:mdna:19]
[same as prior period, unchanged from 0001437749-14-013895:mdna:18]

[0001437749-14-019177:mdna:20]
[same as prior period, unchanged from 0001437749-14-013895:mdna:19]

[0001437749-14-019177:mdna:21]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 107,754 |  |  | $ | 101,013 |  |  |  | 7 | % |  | $ | 313,726 |  |  | $ | 271,878 |  |  |  | 15 | % |
| Automotive |  |  | 80,639 |  |  |  | 70,386 |  |  |  | 15 | % |  |  | 245,083 |  |  |  | 194,319 |  |  |  | 26 | % |
| Electrical |  |  | 29,215 |  |  |  | 29,641 |  |  |  | (1 | %) |  |  | 86,566 |  |  |  | 93,527 |  |  |  | (7 | %) |
| Total |  | $ | 217,608 |  |  | $ | 201,040 |  |  |  | 8 | % |  | $ | 645,375 |  |  | $ | 559,724 |  |  |  | 15 | % |
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 97,903 |  |  | $ | 89,682 |  |  |  | 9 | % |  | $ | 282,928 |  |  | $ | 254,037 |  |  |  | 11 | % |
| Europe |  |  | 39,568 |  |  |  | 35,490 |  |  |  | 11 | % |  |  | 127,791 |  |  |  | 100,360 |  |  |  | 27 | % |
| Asia-Pacific |  |  | 80,137 |  |  |  | 75,868 |  |  |  | 6 | % |  |  | 234,656 |  |  |  | 205,327 |  |  |  | 14 | % |
| Total |  | $ | 217,608 |  |  | $ | 201,040 |  |  |  | 8 | % |  | $ | 645,375 |  |  | $ | 559,724 |  |  |  | 15 | % |

[0001437749-14-019177:mdna:22]
[same as prior period, unchanged from 0001437749-14-013895:mdna:22]

[0001437749-14-019177:mdna:23]
Results of Operations – Third Quarter, 2014 compared to 2013

[0001437749-14-019177:mdna:24]
The following table summarizes the company’s consolidated results of operations for the periods presented. The results include incremental activity from the company’s business acquisitions as described, where applicable, in the below analysis. There was an additional $2.8 million in 2014 year-to-date for the write-off of stepped-up inventory valuation related to the SymCom acquisition as described in Note 2. The company incurred $2.0 million of severance charges in 2014 year-to date resulting from restructuring at the Hamlin-Mexico plant. The company also incurred $1.1million of charges during the third quarter of 2014 related to its internal organization restructuring to optimize its ability to use cash. There was $0.1 million of foreign exchange gains during the third quarter of 2014 ($2.0 million of losses in 2014 year-to-date) due primarily to balance sheet remeasurement in the Philippines.

[0001437749-14-019177:mdna:25]
| (In thousands, unaudited) |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Sales |  | $ | 217,608 |  |  | $ | 201,040 |  |  |  | 8 | % |  | $ | 645,375 |  |  | $ | 559,724 |  |  |  | 15 | % |
| Gross Profit |  |  | 87,380 |  |  |  | 80,960 |  |  |  | 8 | % |  |  | 248,869 |  |  |  | 219,123 |  |  |  | 14 | % |
| Operating expense |  |  | 47,250 |  |  |  | 43,401 |  |  |  | 9 | % |  |  | 141,430 |  |  |  | 122,065 |  |  |  | 16 | % |
| Operating income |  |  | 40,130 |  |  |  | 37,559 |  |  |  | 7 | % |  |  | 107,439 |  |  |  | 97,058 |  |  |  | 11 | % |
| Other (income) expense, net |  |  | (1,070 | ) |  |  | 1,035 |  |  |  | (203 | %) |  |  | 865 |  |  |  | 7,165 |  |  |  | (88 | %) |
| Income before income taxes |  |  | 41,200 |  |  |  | 36,524 |  |  |  | 13 | % |  |  | 106,574 |  |  |  | 89,893 |  |  |  | 19 | % |
| Net income |  | $ | 29,940 |  |  | $ | 26,990 |  |  |  | 11 | % |  | $ | 79,907 |  |  | $ | 65,126 |  |  |  | 23 | % |

[0001437749-14-019177:mdna:26]
Net sales increased $16.6 million or 8% to $217.6 million in the third quarter of 2014 compared to $201.0 million in the third quarter of 2013 due primarily to strong organic growth in automotive and electronics and an incremental $5.5 million from the SymCom acquisition, partially offset by lower electrical sales. The company also experienced $0.3 million in favorable foreign currency effects in the third quarter of 2014 as compared to the third quarter of 2013. Excluding incremental sales from SymCom and currency effects, net sales increased $10.8 million or 5% year-over-year.

[0001437749-14-019177:mdna:27]
Electronics sales increased $6.7 million or 7% to $107.8 million in the third quarter of 2014 compared to $101.0 million in the third quarter of 2013 due primarily to strong growth for both semiconductor and passive components. The electronics segment experienced $0.2 million in favorable currency effects in the third quarter of 2014 primarily from sales denominated in Korean won. Excluding the impact of currency effects, sales increased $6.6 million or 6% year-over-year.

[0001437749-14-019177:mdna:28]
[same as prior period, unchanged from 0001437749-14-013895:mdna:27]

[0001437749-14-019177:mdna:29]
Automotive sales increased $10.3 million or 15% to $80.6 million in the third quarter of 2014 compared to $70.4 million in the third quarter of 2013 due to strong organic growth for passenger car fuses, commercial vehicle products and sensors. The automotive segment experienced $0.2 million in favorable currency effects in the third quarter of 2014 primarily due to sales denominated in Korean won. Excluding currency effects, net sales increased $10.1 million or 14% year-over-year.

[0001437749-14-019177:mdna:30]
Electrical sales decreased $0.4 million or 1% to $29.2 million in the third quarter of 2014 compared to $29.6 million in the third quarter of 2013 primarily from declines in custom and relay sales into the mining market and power fuses into the industrial market. These declines more than offset incremental sales of $5.5 million from the SymCom acquisition. The electrical segment experienced $0.1 million in unfavorable currency effects in the third quarter of 2014 primarily from sales denominated in Canadian dollars. Excluding incremental sales from SymCom and currency effects, net sales decreased $5.8 million or 20% year-over-year.

[0001437749-14-019177:mdna:31]
On a geographic basis, sales in the Americas increased $8.2 million or 9% to $97.9 million in the third quarter of 2014 compared to $89.7 million in the third quarter of 2013 due primarily to incremental sales of $5.5 million from SymCom offset by $0.1 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding incremental sales from acquisitions and currency effects, the Americas sales increased $2.9 million or 3% due to the increase in automotive and electronics sales partially offset by decreased electrical sales.

[0001437749-14-019177:mdna:32]
Europe sales increased $4.1 million or 11% to $39.6 million in the third quarter of 2014 compared to $35.5 million in the third quarter of 2013 mainly due to strong demand for electronics and automotive products and $0.2 million in favorable currency effects.

[0001437749-14-019177:mdna:33]
Asia-Pacific sales increased $4.3 million or 6% to $80.1 million in the third quarter of 2014 compared to $75.9 million in the third quarter of 2013 primarily due to strong demand for automotive and electronics products and $0.2 million in favorable currency effects primarily from sales denominated in Korean won. Excluding currency effects, net sales increased $4.1 million or 5% year-over-year.

[0001437749-14-019177:mdna:34]
Gross profit was $87.4 million or 40% of net sales for the third quarter of 2014 compared to $81.0 million or 40% of net sales in the same quarter last year. Gross profit for the third quarter of 2013 included a $0.4 million non-cash charge to cost of goods sold for inventory that was stepped-up to fair value as a result of the Hamlin acquisition.

[0001437749-14-019177:mdna:35]
Total operating expense was $47.3 million or 22% of net sales for the third quarter of 2014 compared to $43.4 million or 22% of net sales for the same quarter in 2013. The increase in operating expenses primarily reflects incremental operating expenses of $2.3 million from the SymCom acquisition and $1.1 million of expenses to effect changes in the company’s legal structure that will enable the up-streaming of cash to the U.S.

[0001437749-14-019177:mdna:36]
Operating income for the third quarter of 2014 was approximately $40.1 million compared to operating income of $37.6 million for the same quarter in 2013 primarily due to higher sales partially offset by higher operating expenses as described above.

[0001437749-14-019177:mdna:37]
Interest expense was $1.3 million in the third quarter of 2014 compared to $0.9 million in the third quarter of 2013 and is primarily related to the company’s revolving credit facility.

[0001437749-14-019177:mdna:38]
Foreign exchange loss (gain), reflecting net gains and losses from balance sheet revaluation, was approximately $0.1 million of income for the third quarter of 2014 and $1.5 million of expense for the third quarter of 2013 and primarily reflects fluctuations in the Philippine peso against the U.S. dollar.

[0001437749-14-019177:mdna:39]
Other (income) expense, net, consisting of interest income, royalties and non-operating income and expense was approximately $2.3 million of income for the third quarter of 2014 compared to $1.4 million of income in the third quarter of 2013.

[0001437749-14-019177:mdna:40]
Income before income taxes was $41.2 million for the third quarter of 2014 compared to income before income taxes of $36.5 million for the third quarter of 2013. Income tax expense was $11.3 million with an effective tax rate of 27.3% for the third quarter of 2014 compared to income tax expense of $9.5 million with an effective tax rate of 26.1% in the third quarter of 2013. The higher effective tax rate in the third quarter of 2014 was primarily due to more income earned in high tax jurisdictions.

[0001437749-14-019177:mdna:41]
16

[0001437749-14-019177:mdna:42]
Net income for the third quarter of 2014 was $29.9 million or $1.32 per diluted share compared to net income of $27.0 million or $1.19 per diluted share for the same quarter of 2013.

[0001437749-14-019177:mdna:43]
Results of Operations – Nine Months, 2014 compared to 2013

[0001437749-14-019177:mdna:44]
Net sales increased $85.7 million or 15% to $645.4 million in the first nine months of 2014 compared to $559.7 million in the first nine months of 2013 due primarily to an incremental $51.8 million from business acquisitions. The company also experienced $4.0 million in favorable foreign currency effects in the first nine months of 2014 as compared to 2013. The favorable foreign currency impact primarily resulted from sales denominated in euros. Excluding incremental sales from acquisitions and currency effects, net sales increased $29.9 million or 5% year-over-year.

[0001437749-14-019177:mdna:45]
Electronics sales increased $41.8 million or 15% to $313.7 million in the first nine months of 2014 compared to $271.9 million in the first nine months of 2013 due primarily to strong organic growth in fuse products and incremental sales of $16.3 million from the Hamlin acquisition. The electronics segment experienced $1.5 million in favorable currency effects in the first nine months of 2014 primarily from sales denominated in euros. Excluding incremental sales from Hamlin and currency effects, net sales increased $24.1 million or 9% year-over-year.

[0001437749-14-019177:mdna:46]
Automotive sales increased $50.8 million or 26% to $245.1 million in the first nine months of 2014 compared to $194.3 million in the first nine months of 2013 due primarily to incremental sales of $20.2 million from Hamlin and strong growth in all product categories. The automotive segment experienced $3.1 million in favorable currency effects in the first nine months of 2014 primarily due to sales denominated in euros. Excluding incremental sales from acquisitions and currency effects, net sales increased $27.5 million or 14% year-over-year.

[0001437749-14-019177:mdna:47]
Electrical sales decreased $7.0 million or 7% to $86.6 million in the first nine months of 2014 compared to $93.5 million in the first nine months of 2013 due primarily to slowing demand for custom and relay products as a result of a slow-down in the mining industry. This more than offset incremental sales of $15.3 million from the SymCom acquisition. The electrical segment experienced $0.6 million in unfavorable currency effects in the first nine months of 2014 primarily from sales denominated in Canadian dollars. Excluding incremental sales from SymCom and currency effects, net sales decreased $21.6 million or 23% year-over-year.

[0001437749-14-019177:mdna:48]
On a geographic basis, sales in the Americas increased $28.9 million or 11% to $282.9 million in the first nine months of 2014 compared to $254.0 million in the first nine months of 2013 due to incremental sales from business acquisitions of $32.0 million, offset by weaker custom and relay sales and $0.8 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding incremental sales from acquisitions and currency effects, net sales decreased $2.3 million or 1% year-over-year.

[0001437749-14-019177:mdna:49]
Europe sales increased $27.4 million or 27% to $127.8 million in the first nine months of 2014 compared to $100.4 million in the first nine months of 2013 mainly due to strong demand for both automotive and electronics products, incremental sales of $9.4 million from Hamlin and $4.3 million in favorable currency effects. Excluding incremental sales from acquisitions and currency effects, Europe sales increased $13.7 million or 14% year-over-year.

[0001437749-14-019177:mdna:50]
Asia-Pacific sales increased $29.3 million or 14% to $234.7 million in the first nine months of 2014 compared to $205.3 million in the first nine months of 2013 primarily due to higher demand for automotive and electronics products, incremental sales from Hamlin of $10.4 million and $0.5 million in favorable currency effects primarily from sales denominated in Korean won. Excluding incremental sales from Hamlin and currency effects, net sales increased $18.4 million or 9% year-over-year.

[0001437749-14-019177:mdna:51]
Gross profit was $248.9 million or 39% of net sales in the first nine months of 2014 compared to $219.1 million or 39% of net sales in the first nine months of 2013. Gross profit for the nine months of 2014 included a $2.8 million non-cash charge to cost of goods sold for inventory that was stepped up to fair value as a result of the SymCom acquisition and $2.0 million of severance charges resulting from restructuring at the Hamlin-Mexico plant. Gross profit for the first nine months of 2013 included a $2.1 million non-cash charge to cost of goods sold for inventory that was stepped-up to fair value as a result of the Hamlin acquisition. Excluding the impact of these charges, gross profit was 39% for the first nine months of 2014 and 40% for the first nine months of 2013. The decline in gross margin is primarily attributable to lower sales in the Electrical market.

[0001437749-14-019177:mdna:52]
Total operating expense was $141.4 million or 22% of net sales for the first nine months of 2014 compared to $122.1 million or 22% of net sales for the first nine months in 2013. The increase in operating expenses primarily reflects incremental operating expenses of $12.0 million from business acquisitions.

[0001437749-14-019177:mdna:53]
Operating income for the first nine months of 2014 was $107.4 million compared to operating income of $97.1 million for the first nine months in 2013 primarily due to higher sales partially offset by higher operating expenses as described above.

[0001437749-14-019177:mdna:54]
Interest expense was $3.7 million for the first nine months of 2014 and $2.0 million for the first nine months of 2013 and is primarily related to the company’s revolving credit facility.

[0001437749-14-019177:mdna:55]
Foreign exchange loss (gain), reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $2.0 million of expense for the first nine months of 2014 and $1.9 million of income for the first nine months of 2013 and primarily reflects fluctuations in the Philippine peso against the U.S. dollar.

[0001437749-14-019177:mdna:56]
Other (income) expense, net, consisting of interest income, royalties and non-operating income and expense was $4.9 million of income for the first nine months of 2014 compared to $3.5 million of income for the first nine months of 2013.

[0001437749-14-019177:mdna:57]
Income before income taxes was $106.6 million for the first nine months of 2014 compared to $89.9 million for the first nine months of 2013. Income tax expense was $26.7 million with an effective tax rate of 25.0% for the first nine months of 2014 compared to income tax expense of $24.8 million with an effective tax rate of 27.6% for the first nine months of 2013. The effective tax rates for both the first nine months of 2014 and 2013 are lower than the U.S. statutory tax rate primarily due to income earned in countries with lower tax rates than the U.S.

[0001437749-14-019177:mdna:58]
Net income for the first nine months of 2014 was $79.9 million or $3.52 per diluted share compared to net income of $65.1 million or $2.89 per diluted share for the same nine months of 2013.

[0001437749-14-019177:mdna:59]
[same as prior period, unchanged from 0001437749-14-013895:mdna:59]

[0001437749-14-019177:mdna:60]
As of September 27, 2014, $365.3 million of the $378.3 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $365.3 million held by foreign subsidiaries, approximately $17.7 million could be repatriated with minimal tax consequences as of September 27, 2014.

[0001437749-14-019177:mdna:61]
In the fourth quarter of 2014, in conjunction with the post-merger integration of Hamlin, the company expects to repatriate over $90.0 million of cash to the U.S. from various overseas subsidiaries. The company expects to maintain its foreign cash balances (other than the aforementioned $90.0 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S. in the foreseeable future. The company is also in the process of reviewing and revising its internal legal structure to optimize its ability to use cash.

[0001437749-14-019177:mdna:62]
[same as prior period, unchanged from 0001437749-14-013895:mdna:61]

[0001437749-14-019177:mdna:63]
[same as prior period, unchanged from 0001437749-14-013895:mdna:63]

[0001437749-14-019177:mdna:64]
On May 31, 2013, the company entered into a new credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consisted of a revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. At September 27, 2014, the company had available $92.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.50% (1.65% as of September 27, 2014). The credit agreement replaces the company’s previous credit agreement dated June 13, 2011 which was terminated on May 31, 2013.

[0001437749-14-019177:mdna:65]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 27, 2014, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-14-019177:mdna:66]
The company also had $0.8 million outstanding in letters of credit at September 27, 2014. No amounts were drawn under these letters of credit at September 27, 2014.

[0001437749-14-019177:mdna:67]
[same as prior period, unchanged from 0001437749-14-013895:mdna:67]

[0001437749-14-019177:mdna:68]
The company started 2014 with $305.2 million of cash and cash equivalents. Net cash provided by operating activities was approximately $103.8 million for the first nine months of 2014 reflecting $79.9 million in net income and $39.3 million in non-cash adjustments (primarily $31.2 million in depreciation and amortization) offset by $15.4 million in net changes to various operating assets and liabilities.

[0001437749-14-019177:mdna:69]
Changes in operating assets and liabilities for the first nine months of 2014 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivables ($9.7 million), inventory ($4.1 million) and prepaid and other assets ($2.1 million), decreases in accrued expenses (including post-retirement) ($7.1 million) and accrued payroll and severance ($1.2 million). The increase in accounts receivables was due to increased sales in the first nine months. The increase in inventory resulted from higher stock levels to meet increased demand. The decrease in accrued expenses was due primarily to $9.9 million in pension contributions made during the first quarter. Changes having a positive impact on cash flows were increases in accounts payable ($3.0 million) and accrued and deferred taxes ($5.8 million).

[0001437749-14-019177:mdna:70]
Net cash used in investing activities was approximately $65.3 million and included $19.4 million in capital spending and $52.8 million for the acquisition of SymCom offset by $6.8 million in proceeds from sales of short-term investments.

[0001437749-14-019177:mdna:71]
Net cash provided by financing activities was approximately $41.5 million and included $56.8 million in net proceeds from borrowing and $14.6 million from the exercise of stock options, including tax benefits, partially offset by debt issuance costs of $0.1 million, cash dividends paid of $15.5 million and the repurchase of common stock for $14.3 million. The effects of exchange rate changes decreased cash and cash equivalents by $6.9 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $73.1 million increase in cash, which left the company with a cash and cash equivalents balance of $378.3 million at September 27, 2014.

[0001437749-14-019177:mdna:72]
The ratio of current assets to current liabilities was 2.3 at the end of the third quarter of 2014 compared to 2.5 at the end of the third quarter of 2013 and 2.7 at year-end 2013. Days sales outstanding in accounts receivable was approximately 56 days at the end of the third quarter of 2014 compared to 58 days at the end of the third quarter of 2013 and 59 days at year-end 2013. Days inventory outstanding was approximately 70 days at the end of the third quarter of 2014 as well as at the end of the third quarter of 2013 and at year-end 2013.

[0001437749-14-019177:mdna:73]
[same as prior period, unchanged from 0001437749-14-013895:mdna:73]

[0001437749-14-019177:mdna:74]
[same as prior period, unchanged from 0001437749-14-013895:mdna:74]

[0001437749-14-019177:mdna:75]
Sales for the fourth quarter are expected to follow normal seasonal patterns which will call for slightly softer Automotive sales and a moderate decline in Electronics sales compared to the third quarter of 2014. The Electrical segment is expected to remain weak due primarily to continued softness in the mining market. The company issued the following guidance for the fourth quarter of 2014:

[0001437749-14-019177:mdna:76]
|  | ● | Sales for the fourth quarter are expected to be in the range of $201.0 million to $211.0 million which represents 4% year-over-year growth at the midpoint. |

[0001437749-14-019177:mdna:77]
|  | ● | Earnings for the fourth quarter are expected to be in the range of $1.05 to $1.19 per diluted share, excluding any special items. |

[0001437749-14-019177:mdna:78]
|  | ● | Capital expenditures are expected to increase to approximately $11.0 million for the fourth quarter of 2014 due to spending on a new building at the company’s Philippines site and several large equipment purchases. |

[0001437749-14-019177:mdna:79]
The company also made the following comments regarding 2015:

[0001437749-14-019177:mdna:80]
|  | ● | After a relatively strong first half of 2014, electronics market growth has slowed. We see a continuation of modest growth in 2015. |

[0001437749-14-019177:mdna:81]
|  | ● | Global car build rates have moderated after several years of above-trend growth. We see this slower growth environment continuing through 2015. However, our program wins for fuses and sensors give us confidence that we can continue to grow our automotive sales faster that the market. |

[0001437749-14-019177:mdna:82]
|  | ● | The overall electrical business is expected to have moderate growth in 2015 driven primarily by the beginnings of a recovery for custom products and the ramp up of new products at SymCom. |

[0001437749-14-019177:mdna:83]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-14-019177:mdna:84]
[same as prior period, unchanged from 0001437749-14-013895:mdna:80]
