# LFUS 10-Q controls and the auditor's report


## item_4_controls

[0001437749-14-019177:item_4_controls:1]
Item 4. Controls and Procedures.

[0001437749-14-019177:item_4_controls:2]
With the participation of our management, including the company’s principal executive officer and principal financial officer, the company has evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) and 15d-15(c) under the Securities Exchange Act of 1934 (the “Exchange Act”)) as of the end of the period covered by this Quarterly Report on Form 10-Q. Based upon that evaluation and the fact that the company is in the process of remediating the material weakness, which is expected to be completed by the fourth quarter of 2014, the company’s principal executive officer and principal financial officer concluded that the company’s disclosure controls and procedures were not effective as of the end of the period ended September 27, 2014.

[0001437749-14-019177:item_4_controls:3]
The errors resulted from the 2013 year-end treatment of tax deductions related to the company’s write-off of its investment in Shocking Technologies, Inc. The tax deductions were determined to be a capital loss for tax purposes, instead of an ordinary loss as the company had previously determined in consultation with a third party expert.

[0001437749-14-019177:item_4_controls:4]
Material Weakness and Related Remediation Initiatives

[0001437749-14-019177:item_4_controls:5]
On February 4, 2014, the company concluded there was a material weakness in internal control over financial reporting as defined in Rule 13a-15(f) under the Exchange Act as it relates to deferred tax valuation allowance accounting at March 30, 2013. A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the annual or interim financial statement will not be prevented or detected on a timely basis.

[0001437749-14-019177:item_4_controls:6]
The material weakness in internal control over financial reporting relates to the company’s evaluation of the income tax considerations, including deferred tax valuation allowances relating to the write-off of its investment in Shocking Technologies, Inc. during the first quarter of 2013. Management has commenced steps to remediate the material weakness associated with this misstatement and has begun the process of implementing an enhanced process to review and approve the income tax accounting treatment for any material items that are of an unusual or complex nature. In accordance with the company’s internal control over financial reporting compliance program, however, the material weakness designation cannot be remediated fully until the remediation processes have been operational for a period of time and successfully tested. Such remediation is anticipated to be completed in the fourth quarter of 2014.

[0001437749-14-019177:item_4_controls:7]
Changes in Internal Control Over Financial Reporting

[0001437749-14-019177:item_4_controls:8]
Except as has been described above, there has been no change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that occurred during the period ended September 27, 2014, that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0001437749-14-019177:item_4_controls:9]
Reference is made to Exhibits 31.1 and 31.2 for the Certification statements issued by the company’s Chief Executive Officer and Chief Financial Officer, regarding the company’s disclosure controls and procedures, and internal control over financial reporting, as of September 27, 2014.

[0001437749-14-019177:item_4_controls:10]
21
