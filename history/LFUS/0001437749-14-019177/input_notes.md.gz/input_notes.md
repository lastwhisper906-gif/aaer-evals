# LFUS notes — 0001437749-14-019177


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-14-019177:notes:1]
[same as prior period, unchanged from 0001437749-14-013895:notes:1]

[0001437749-14-019177:notes:2]
[same as prior period, unchanged from 0001437749-14-013895:notes:2]

[0001437749-14-019177:notes:3]
[same as prior period, unchanged from 0001437749-14-013895:notes:3]

[0001437749-14-019177:notes:4]
[same as prior period, unchanged from 0001437749-14-013895:notes:4]

[0001437749-14-019177:notes:5]
The following table sets forth the preliminary purchase price allocation for SymCom acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values.

[0001437749-14-019177:notes:6]
| SymCom preliminary purchase price allocation (in thousands): |  |
| Cash |  | $ | 325 |  |
| Current assets, net |  |  | 9,154 |  |
| Property, plant and equipment |  |  | 11,193 |  |
| Goodwill |  |  | 15,063 |  |
| Trademarks |  |  | 17,020 |  |
| Patents |  |  | 1,500 |  |
| Other non-current assets |  |  | 20 |  |
| Current liabilities |  |  | (1,182 | ) |
|  |  | $ | 53,093 |  |

[0001437749-14-019177:notes:7]
[same as prior period, unchanged from 0001437749-14-013895:notes:7]

[0001437749-14-019177:notes:8]
[same as prior period, unchanged from 0001437749-14-013895:notes:8]

[0001437749-14-019177:notes:9]
[same as prior period, unchanged from 0001437749-14-013895:notes:9]

[0001437749-14-019177:notes:10]
[same as prior period, unchanged from 0001437749-14-013895:notes:10]

[0001437749-14-019177:notes:11]
[same as prior period, unchanged from 0001437749-14-013895:notes:11]

[0001437749-14-019177:notes:12]
On May 31, 2013, the company acquired 100% of Hamlin, Inc. (“Hamlin”) from Key Safety Systems, for $144.4 million (net of cash acquired). Hamlin is a manufacturer of sensor technology providing standard products and custom solutions for leading global manufacturers in the automotive and electronic industries. The acquisition allows the company to expand its automotive and electronics product offerings in the global sensor market in both the Automotive and Electronics business segments. Hamlin has manufacturing, engineering and sales offices in the U.S., Mexico, Europe and Asia. Hamlin operations are being integrated into the Electronics and Automotive segments of Littelfuse. The company funded the acquisition with available cash raised from borrowings on the company’s new credit arrangement. (See Note 6).

[0001437749-14-019177:notes:13]
[same as prior period, unchanged from 0001437749-14-013895:notes:13]

[0001437749-14-019177:notes:14]
[same as prior period, unchanged from 0001437749-14-013895:notes:14]

[0001437749-14-019177:notes:15]
[same as prior period, unchanged from 0001437749-14-013895:notes:15]

[0001437749-14-019177:notes:16]
[same as prior period, unchanged from 0001437749-14-013895:notes:16]

[0001437749-14-019177:notes:17]
[same as prior period, unchanged from 0001437749-14-013895:notes:17]

[0001437749-14-019177:notes:18]
|  |  | (In thousands except for per share amounts) |  |
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (As restated) |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | (Unaudited) |  |
| Revenues |  | $ | 217,608 |  |  | $ | 201,040 |  |  | $ | 645,375 |  |  | $ | 591,095 |  |
| Net income |  | $ | 29,940 |  |  | $ | 26,990 |  |  | $ | 79,907 |  |  | $ | 65,425 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.33 |  |  | $ | 1.20 |  |  | $ | 3.55 |  |  | $ | 2.94 |  |
| Diluted |  | $ | 1.32 |  |  | $ | 1.19 |  |  | $ | 3.52 |  |  | $ | 2.91 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,536 |  |  |  | 22,428 |  |  |  | 22,536 |  |  |  | 22,274 |  |
| Diluted |  |  | 22,689 |  |  |  | 22,625 |  |  |  | 22,722 |  |  |  | 22,497 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001437749-14-019177:notes:19]
[same as prior period, unchanged from 0001437749-14-013895:notes:20]

[0001437749-14-019177:notes:20]
The components of inventories at September 27, 2014 and December 28, 2013 are as follows (in thousands):

[0001437749-14-019177:notes:21]
|  |  | September 27, 2014 |  |  | December 28, 2013 |  |
| Raw material |  | $ | 31,549 |  |  | $ | 28,228 |  |
| Work in process |  |  | 16,810 |  |  |  | 17,576 |  |
| Finished goods |  |  | 51,463 |  |  |  | 46,787 |  |
| Total inventories |  | $ | 99,822 |  |  | $ | 92,591 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-14-019177:notes:22]
[same as prior period, unchanged from 0001437749-14-013895:notes:23]

[0001437749-14-019177:notes:23]
The company’s other investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company. The Polytronics investment was acquired as part of the Heinrich Companies acquisition in 2004. The fair value of the Polytronics investment was €10.2 million (approximately $13.1 million) at September 27, 2014 and €9.0 million (approximately $12.3 million) at December 28, 2013. Included in 2014 other comprehensive income is an unrealized gain of $1.8 million, due to the increase in fair market value of the Polytronics investment. The remaining movement was due to the impact of changes in exchange rates.


## us-gaap:AssetImpairmentChargesTextBlock

[0001437749-14-019177:notes:24]
[same as prior period, unchanged from 0001437749-14-013895:notes:25]

[0001437749-14-019177:notes:25]
[same as prior period, unchanged from 0001437749-14-013895:notes:26]

[0001437749-14-019177:notes:26]
The loss was recorded as a component of impairment and equity loss of unconsolidated affiliate in the Consolidated Statements of Net Income for the nine months ended September 28, 2013.


## us-gaap:DebtDisclosureTextBlock

[0001437749-14-019177:notes:27]
6. Debt

[0001437749-14-019177:notes:28]
The carrying amounts of long-term debt at September 27, 2014 and December 28, 2013 are as follows (in thousands):

[0001437749-14-019177:notes:29]
|  |  | September 27, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 95,000 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 181,500 |  |  |  | 121,000 |  |
| Total debt |  |  | 276,500 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 186,500 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 90,000 |  |  | $ | 93,750 |  |

[0001437749-14-019177:notes:30]
On May 31, 2013, the company entered into a new credit agreement with J.P Morgan Securities LLC for up to $325.0 million which consisted of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of September 27, 2014, the company had available $92.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.50% (1.65% as of September 27, 2014). At September 27, 2014, the company was in compliance with all covenants under the revolving credit facility.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-14-019177:notes:31]
[same as prior period, unchanged from 0001437749-14-013895:notes:32]

[0001437749-14-019177:notes:32]
[same as prior period, unchanged from 0001437749-14-013895:notes:33]

[0001437749-14-019177:notes:33]
[same as prior period, unchanged from 0001437749-14-013895:notes:34]

[0001437749-14-019177:notes:34]
[same as prior period, unchanged from 0001437749-14-013895:notes:35]

[0001437749-14-019177:notes:35]
[same as prior period, unchanged from 0001437749-14-013895:notes:36]

[0001437749-14-019177:notes:36]
[same as prior period, unchanged from 0001437749-14-013895:notes:37]

[0001437749-14-019177:notes:37]
[same as prior period, unchanged from 0001437749-14-013895:notes:38]

[0001437749-14-019177:notes:38]
[same as prior period, unchanged from 0001437749-14-013895:notes:39]

[0001437749-14-019177:notes:39]
[same as prior period, unchanged from 0001437749-14-013895:notes:40]

[0001437749-14-019177:notes:40]
There were no changes during the nine months ended September 27, 2014 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 27, 2014 and December 28, 2013 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-14-019177:notes:41]
The following table presents assets and liabilities measured at fair value by classification within the fair value hierarchy as of September 27, 2014 (in thousands):

[0001437749-14-019177:notes:42]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 13,115 |  |  | $ | — |  |  | $ | — |  |  | $ | 13,115 |  |
| Total |  | $ | 13,115 |  |  | $ | — |  |  | $ | — |  |  | $ | 13,115 |  |

[0001437749-14-019177:notes:43]
[same as prior period, unchanged from 0001437749-14-013895:notes:44]

[0001437749-14-019177:notes:44]
[same as prior period, unchanged from 0001437749-14-013895:notes:45]

[0001437749-14-019177:notes:45]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt. The carrying amounts of cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt approximate their fair values. The company’s debt fair value approximates book value at September 27, 2014 and December 28, 2013, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:EarningsPerShareTextBlock

[0001437749-14-019177:notes:46]
[same as prior period, unchanged from 0001437749-14-013895:notes:47]

[0001437749-14-019177:notes:47]
[same as prior period, unchanged from 0001437749-14-013895:notes:48]

[0001437749-14-019177:notes:48]
[same as prior period, unchanged from 0001437749-14-013895:notes:49]

[0001437749-14-019177:notes:49]
The following table sets forth the computation of basic and diluted earnings per share under the treasury share method as of September 27, 2014 and the two-class method as of September 28, 2013.

[0001437749-14-019177:notes:50]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (in thousands except per share amounts) |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |
| Net income as reported |  | $ | 29,940 |  |  | $ | 26,990 |  |  | $ | 79,907 |  |  | $ | 65,126 |  |
| Less: Distributed earnings available to participating securities |  |  | — |  |  |  | (3 | ) |  |  | — |  |  |  | (21 | ) |
| Less: Undistributed earnings available to participating securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (16 | ) |
| Numerator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 29,940 |  |  | $ | 26,987 |  |  | $ | 79,907 |  |  | $ | 65,089 |  |
| Add: Undistributed earnings allocated to participating securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 16 |  |
| Less: Undistributed earnings reallocated to participating securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (16 | ) |
| Numerator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 29,940 |  |  | $ | 26,987 |  |  | $ | 79,907 |  |  | $ | 65,089 |  |
| Denominator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares |  |  | 22,536 |  |  |  | 22,428 |  |  |  | 22,536 |  |  |  | 22,274 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Common stock equivalents |  |  | 153 |  |  |  | 197 |  |  |  | 186 |  |  |  | 223 |  |
| Denominator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted for weighted-average shares & assumed conversions |  |  | 22,689 |  |  |  | 22,625 |  |  |  | 22,722 |  |  |  | 22,497 |  |
| Basic earnings per share |  | $ | 1.33 |  |  | $ | 1.20 |  |  | $ | 3.55 |  |  | $ | 2.92 |  |
| Diluted earnings per share |  | $ | 1.32 |  |  | $ | 1.19 |  |  | $ | 3.52 |  |  | $ | 2.89 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-14-019177:notes:51]
[same as prior period, unchanged from 0001437749-14-013895:notes:52]

[0001437749-14-019177:notes:52]
The effective tax rate for the third quarter of 2014 was 27.3% compared to an effective tax rate of 26.1% in the third quarter of 2013 reflecting more income earned in higher tax jurisdictions in the third quarter of 2014. The effective tax rate for the nine months ended September 27, 2014 was 25.0% as compared to an effective tax rate of 27.6% for the nine months ended September 28, 2013. The higher tax rate for the nine months ended September 28, 2013 was primarily the result of certain non-recurring tax items.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-14-019177:notes:53]
[same as prior period, unchanged from 0001437749-14-013895:notes:54]

[0001437749-14-019177:notes:54]
The components of net periodic benefit cost for the three and nine months ended September 27, 2014, compared with the three and nine months ended September 28, 2013, were (in thousands):

[0001437749-14-019177:notes:55]
|  |  | U.S. Pension Benefits |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |
| Service cost |  | $ | 150 |  |  | $ | 150 |  |  | $ | 450 |  |  | $ | 450 |  |  | $ | 311 |  |  | $ | 290 |  |  | $ | 933 |  |  | $ | 813 |  |
| Interest cost |  |  | 971 |  |  |  | 891 |  |  |  | 2,913 |  |  |  | 2,674 |  |  |  | 591 |  |  |  | 532 |  |  |  | 1,774 |  |  |  | 1,014 |  |
| Expected return on plan assetsassets |  |  | (1,412 | ) |  |  | (1,340 | ) |  |  | (4,234 | ) |  |  | (4,020 | ) |  |  | (572 | ) |  |  | (446 | ) |  |  | (1,718 | ) |  |  | (717 | ) |
| Amortization of net loss |  |  | 137 |  |  |  | 235 |  |  |  | 411 |  |  |  | 706 |  |  |  | 47 |  |  |  | 39 |  |  |  | 142 |  |  |  | 116 |  |
| Total (credit) cost of the plan |  |  | (154 | ) |  |  | (64 | ) |  |  | (460 | ) |  |  | (190 | ) |  |  | 377 |  |  |  | 415 |  |  |  | 1,131 |  |  |  | 1,226 |  |
| Expected plan participants’ contribution |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net periodic benefit (credit) cost |  | $ | (154 | ) |  | $ | (64 | ) |  | $ | (460 | ) |  | $ | (190 | ) |  | $ | 377 |  |  | $ | 415 |  |  | $ | 1,131 |  |  | $ | 1,226 |  |

[0001437749-14-019177:notes:56]
[same as prior period, unchanged from 0001437749-14-013895:notes:57]

[0001437749-14-019177:notes:57]
On July 31, 2014, the company terminated the Littelfuse, Inc. Retirement Plan (the “Pension Plan”), a plan that was previously offered to all full-time Company employees but frozen as to new participants and benefit accruals as of April 1, 2009. Distribution of plan assets resulting from the Pension Plan termination will not be made until the Internal Revenue Service and the Pension Benefit Guaranty Corporation determine that the termination satisfies applicable regulatory requirements. As a result of the termination of the Pension Plan, each participant will become fully vested in his or her benefits under the Pension Plan without regard to age and years of service. All participants will have a choice of receiving a lump sum payment or an annuity in full payment of their benefits accrued under the Pension
      Plan.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-14-019177:notes:58]
[same as prior period, unchanged from 0001437749-14-013895:notes:59]

[0001437749-14-019177:notes:59]
[same as prior period, unchanged from 0001437749-14-013895:notes:60]

[0001437749-14-019177:notes:60]
[same as prior period, unchanged from 0001437749-14-013895:notes:61]

[0001437749-14-019177:notes:61]
[same as prior period, unchanged from 0001437749-14-013895:notes:62]

[0001437749-14-019177:notes:62]
Business unit segment information for the three and nine months ended September 27, 2014 and September 28, 2013 are summarized as follows (in thousands):

[0001437749-14-019177:notes:63]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 107,754 |  |  | $ | 101,013 |  |  | $ | 313,726 |  |  | $ | 271,878 |  |
| Automotive |  |  | 80,639 |  |  |  | 70,386 |  |  |  | 245,083 |  |  |  | 194,319 |  |
| Electrical |  |  | 29,215 |  |  |  | 29,641 |  |  |  | 86,566 |  |  |  | 93,527 |  |
| Total net sales |  | $ | 217,608 |  |  | $ | 201,040 |  |  | $ | 645,375 |  |  | $ | 559,724 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 5,582 |  |  | $ | 5,784 |  |  | $ | 16,482 |  |  | $ | 15,776 |  |
| Automotive |  |  | 3,435 |  |  |  | 2,880 |  |  |  | 10,609 |  |  |  | 7,183 |  |
| Electrical |  |  | 1,414 |  |  |  | 937 |  |  |  | 4,096 |  |  |  | 2,893 |  |
| Total depreciation and amortization |  | $ | 10,431 |  |  | $ | 9,601 |  |  | $ | 31,187 |  |  | $ | 25,852 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 25,800 |  |  | $ | 20,362 |  |  | $ | 70,805 |  |  | $ | 52,284 |  |
| Automotive |  |  | 12,227 |  |  |  | 11,135 |  |  |  | 35,158 |  |  |  | 29,531 |  |
| Electrical |  |  | 3,224 |  |  |  | 6,687 |  |  |  | 7,541 |  |  |  | 18,801 |  |
| Other(1) |  |  | (1,121 | ) |  |  | (625 | ) |  |  | (6,065 | ) |  |  | (3,558 | ) |
| Total operating income |  |  | 40,130 |  |  |  | 37,559 |  |  |  | 107,439 |  |  |  | 97,058 |  |
| Interest expense |  |  | 1,292 |  |  |  | 939 |  |  |  | 3,736 |  |  |  | 1,959 |  |
| Impairment, loan loss and equity in net loss of unconsolidated affiliate (2) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 10,678 |  |
| Foreign exchange (gain) loss |  |  | (101 | ) |  |  | 1,476 |  |  |  | 2,022 |  |  |  | (1,929 | ) |
| Other (income) expense, net |  |  | (2,261 | ) |  |  | (1,380 | ) |  |  | (4,893 | ) |  |  | (3,543 | ) |
| Income before income taxes |  | $ | 41,200 |  |  | $ | 36,524 |  |  | $ | 106,574 |  |  | $ | 89,893 |  |

[0001437749-14-019177:notes:64]
(1) “Other” consists of acquisition related costs, severance charges and restructuring costs. (2) During the first quarter of 2013, the company recorded an impairment of its investment in Shocking Technologies. (See Note 5).

[0001437749-14-019177:notes:65]
The company’s significant net sales by country for the three and nine months ended September 27, 2014 and September 28, 2013 are summarized as follows (in thousands):

[0001437749-14-019177:notes:66]
|  |  | For the Three Months Ended(a) |  |  | For the Nine Months Ended(a) |  |
|  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |  | Sept. 27, 2014 |  |  | Sept. 28, 2013 |  |
| United States |  | $ | 85,326 |  |  | $ | 76,183 |  |  | $ | 243,979 |  |  | $ | 202,731 |  |
| China |  |  | 45,905 |  |  |  | 43,644 |  |  |  | 134,166 |  |  |  | 114,952 |  |
| Other countries |  |  | 86,377 |  |  |  | 81,213 |  |  |  | 267,230 |  |  |  | 242,041 |  |
| Total |  | $ | 217,608 |  |  | $ | 201,040 |  |  | $ | 645,375 |  |  | $ | 559,724 |  |

[0001437749-14-019177:notes:67]
[same as prior period, unchanged from 0001437749-14-013895:notes:68]

[0001437749-14-019177:notes:68]
The company’s significant long-lived assets by country as of September 27, 2014 and December 28, 2013 are summarized as follows (in thousands):

[0001437749-14-019177:notes:69]
|  |  | Long-lived assets(b) |  |
|  |  | September 27, 2014 |  |  | December 28, 2013 |  |
| United States |  | $ | 38,964 |  |  | $ | 27,294 |  |
| China |  |  | 40,015 |  |  |  | 45,843 |  |
| Canada |  |  | 13,621 |  |  |  | 14,429 |  |
| Other countries |  |  | 64,660 |  |  |  | 62,607 |  |
| Total |  | $ | 157,260 |  |  | $ | 150,173 |  |

[0001437749-14-019177:notes:70]
[same as prior period, unchanged from 0001437749-14-013895:notes:71]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-14-019177:notes:71]
[same as prior period, unchanged from 0001437749-14-013895:notes:72]

[0001437749-14-019177:notes:72]
[same as prior period, unchanged from 0001437749-14-013895:notes:73]

[0001437749-14-019177:notes:73]
| AOCI component |  | Balance at December 28, 2013 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Balance at September 27, 2014 |  |
| Pension liability adjustment(a) |  | $ | (17,140 | ) |  | $ | (243 | ) |  | $ | 242 |  |  | $ | (17,141 | ) |
| Unrealized gain on investments(b) |  |  | 9,393 |  |  |  | 1,811 |  |  |  | — |  |  |  | 11,204 |  |
| Foreign currency translation adjustment |  |  | 28,164 |  |  |  | (15,273 | ) |  |  | — |  |  |  | 12,891 |  |
| AOCI income (loss) |  | $ | 20,417 |  |  | $ | (13,705 | ) |  | $ | 242 |  |  | $ | 6,954 |  |

[0001437749-14-019177:notes:74]
(a) Balances are net of tax of $6,549 and $6,549 for 2014 and 2013, respectively.

[0001437749-14-019177:notes:75]
[same as prior period, unchanged from 0001437749-14-013895:notes:76]
