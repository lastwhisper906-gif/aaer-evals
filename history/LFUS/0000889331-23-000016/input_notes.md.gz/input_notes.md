# LFUS notes — 0000889331-23-000016


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000889331-23-000016:notes:1]
Portions of the Littelfuse, Inc. Proxy Statement for the 2022 Annual Meeting of Stockholders (the “Proxy Statement”) are incorporated by reference into Part III of this Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-23-000016:notes:2]
Summary of Significant Accounting Policies and Other Information

[0000889331-23-000016:notes:3]
Nature of Operations

[0000889331-23-000016:notes:4]
Littelfuse, Inc. and subsidiaries (the “Company”) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-23-000016:notes:5]
Fiscal Year

[0000889331-23-000016:notes:6]
References herein to “2022”, “fiscal 2022” or “fiscal year 2022” refer to the fiscal year ended December 31, 2022. References herein to “2021”, “fiscal 2021” or “fiscal year 2021” refer to the fiscal year ended January 1, 2022. References herein to “2020”, “fiscal 2020” or “fiscal year 2020” refer to the fiscal year ended December 26, 2020. The Company operates on a 52-53 week fiscal year (4-4-5 basis) ending on the Saturday closest to December 31. Therefore, the financial results of certain fiscal years and the associated 14 week quarters will not be exactly comparable to the prior 52 week fiscal years and the associated quarters having only 13 weeks. As a result of using this convention, the fiscal year 2021 contained 53 weeks while each of fiscal 2022 and fiscal 2020 contained 52 weeks.

[0000889331-23-000016:notes:7]
Basis of Presentation

[0000889331-23-000016:notes:8]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The Company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America ("U.S.") and include the assets, liabilities, sales and expenses of all wholly-owned subsidiaries and majority-owned subsidiaries over which the Company exercises control.

[0000889331-23-000016:notes:9]
Use of Estimates

[0000889331-23-000016:notes:10]
The process of preparing financial statements in conformity with generally accepted accounting principles in the U.S. requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The Company evaluates and updates its assumptions and estimates on an ongoing basis and may employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0000889331-23-000016:notes:11]
Cash, Cash Equivalents and Restricted Cash

[0000889331-23-000016:notes:12]
All highly liquid investments, with an original maturity of three months or less when purchased, are considered to be cash equivalents. The Company maintains several pools including multicurrency notional pools and physical pools internationally and a zero balance account ("ZBA") structure in the U.S. In the notional pools, actual cash balances are not physically converted and are not commingled between participating legal entities. The Company will classify any overdraft balances within accrued expenses and other current liabilities on the Consolidated Balance Sheets.

[0000889331-23-000016:notes:13]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at December 31, 2022 and January 1, 2022 reported within the Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Consolidated Statement of Cash Flows.

[0000889331-23-000016:notes:14]
| (in millions) |  | 2022 |  | 2021 |
| Cash and cash equivalents |  | $ | 562,588 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 802 |  |  | 2,718 |  |
| Restricted cash included in other assets |  | 1,549 |  |  | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 564,939 |  |  | $ | 482,836 |  |

[0000889331-23-000016:notes:15]
Short-Term and Long-Term Investments

[0000889331-23-000016:notes:16]
As of December 31, 2022, the Company has an investment in Polytronics Technology Corporation Ltd. (“Polytronics”). The Company’s Polytronics shares held at the end of fiscal 2022 and 2021 represent approximately 6.7% and 6.8% of total Polytronics shares outstanding, respectively. The Polytronics investment is carried at fair value. The fair value of the Polytronics investment was €10 million (approximately $10.7 million) at December 31, 2022 and €23 million (approximately $26.1 million) at January 1, 2022.

[0000889331-23-000016:notes:17]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The Company owns 45% of the outstanding equity of Powersem GmbH, a module manufacturer based in Germany, approximately 19% of the outstanding equity of EB Tech Ltd., a company with expertise in radiation technology based in South Korea, and approximately 24% of the outstanding common shares of Automated Technology, Inc., a supplier located in the Philippines that provides assembly and test services. The Company recognized gains of $1.3 million from its equity method investment for both the fiscal years ended December 31, 2022 and January 1, 2022. The balance of these equity method investments was $13.5 million and $12.4 million as of the fiscal years ended December 31, 2022 and January 1, 2022, respectively. See Note 17, Related Party Transactions, for further discussion.

[0000889331-23-000016:notes:18]
The Company has investments related to its non-qualified Supplemental Retirement and Savings Plan. The Company maintains accounts for participants through which participants make investment elections. The investment securities are subject to the claims of the Company’s creditors. The investment securities are all mutual funds. The investment securities are measured at net asset value. As of December 31, 2022 and January 1, 2022, the investment securities balance was $14.1 million and $15.0 million, respectively, related to the plan and are included in Other long-term assets on the Consolidated Balance Sheets.

[0000889331-23-000016:notes:19]
Trade Receivables

[0000889331-23-000016:notes:20]
The Company performs credit evaluations of customers’ financial condition and generally does not require collateral. Credit losses are provided for in the financial statements based upon specific knowledge of a customer’s inability to meet its financial obligations to the Company. Historically, credit losses have consistently been within management’s expectations and have not been a material amount. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0000889331-23-000016:notes:21]
The Company also maintains allowances against trade receivables for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.

[0000889331-23-000016:notes:22]
Inventories

[0000889331-23-000016:notes:23]
Inventories are stated at the lower of cost or net realizable value, which approximates current replacement cost. Cost is principally determined using the first-in, first-out method. The Company maintains excess and obsolete reserves against inventory to reduce the carrying value to the expected net realizable value. These reserves are based upon a combination of factors including historical sales volume, market conditions, lower of cost or net realizable value of the inventory.

[0000889331-23-000016:notes:24]
Property, Plant, and Equipment

[0000889331-23-000016:notes:25]
Land, buildings, and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of up to 35 years for buildings, three to 20 years for equipment, seven years for furniture and fixtures, five years for tooling and three years for computer equipment. Leasehold improvements are depreciated over the lesser of their useful life or the lease term. Maintenance and repair costs are charged to expense as incurred. Major overhauls that extend the useful lives of existing assets are capitalized.

[0000889331-23-000016:notes:26]
Goodwill

[0000889331-23-000016:notes:27]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.

[0000889331-23-000016:notes:28]
The Company compares each reporting unit’s fair value, estimated based on comparable company market valuations and expected future discounted cash flows to be generated by the reporting unit, to its carrying value. The results of the annual goodwill impairment test as of October 2, 2022 indicated that the estimated fair values for each of the seven reporting units exceeded their respective carrying values. As of the most recent annual test conducted on October 2, 2022, the Company noted that the excess of fair value over the carrying value, was 151%, 66%, 98%, 42%, 44%, 57%, and 191% for its reporting units; Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, Automotive Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test. See Note 5, Goodwill and Other Intangible Assets, for additional information.

[0000889331-23-000016:notes:29]
There were no impairment charges recorded during the fiscal years of 2022 and 2021. During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Transportation segment.

[0000889331-23-000016:notes:30]
The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments as of December 31, 2022, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value.

[0000889331-23-000016:notes:31]
Long-Lived Assets

[0000889331-23-000016:notes:32]
Customer relationships, trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of 3 to 20 years. Patents, licenses and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of 4 to 17 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of 4 to 10 years.  Land use rights are amortized using the straight-line method up to 50 years which is the term of the land use rights.

[0000889331-23-000016:notes:33]
The Company assesses potential impairments to its long-lived assets if events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. An impaired asset is written down to its estimated fair value based upon the most recent information available. Estimated fair market value is generally measured by discounting estimated future cash flows. Long-lived assets, other than goodwill and other intangible assets, that are held for sale are recorded at the lower of carrying value or the fair market value less the estimated cost to sell.

[0000889331-23-000016:notes:34]
Environmental Liabilities

[0000889331-23-000016:notes:35]
Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, the Company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0000889331-23-000016:notes:36]
Pension and Other Post-retirement Benefits

[0000889331-23-000016:notes:37]
The Company records annual income and expense amounts relating to its pension and post-retirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets, but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors.

[0000889331-23-000016:notes:38]
Revenue Recognition

[0000889331-23-000016:notes:39]
Revenue Disaggregation

[0000889331-23-000016:notes:40]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 31, 2022 and January 1, 2022:

[0000889331-23-000016:notes:41]
|  |  | Fiscal Year Ended December 31, 2022 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 802,281 |  |  | $ | — |  |  | $ | — |  |  | $ | 802,281 |  |
| Electronics – Passive Products and Sensors |  | 690,538 |  |  | — |  |  | — |  |  | 690,538 |  |
| Commercial Vehicle Products |  | — |  |  | 374,707 |  |  | — |  |  | 374,707 |  |
| Passenger Car Products |  | — |  |  | 249,470 |  |  | — |  |  | 249,470 |  |
| Automotive Sensors |  | — |  |  | 91,963 |  |  | — |  |  | 91,963 |  |
| Industrial Products |  | — |  |  | — |  |  | 304,938 |  |  | 304,938 |  |
| Total |  | $ | 1,492,819 |  |  | $ | 716,140 |  |  | $ | 304,938 |  |  | $ | 2,513,897 |  |

[0000889331-23-000016:notes:42]
|  |  | Fiscal Year Ended January 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 678,861 |  |  | $ | — |  |  | $ | — |  |  | $ | 678,861 |  |
| Electronics – Passive Products and Sensors |  | 621,883 |  |  | — |  |  | — |  |  | 621,883 |  |
| Passenger Car Products |  | — |  |  | 266,020 |  |  | — |  |  | 266,020 |  |
| Commercial Vehicle Products |  | — |  |  | 160,300 |  |  | — |  |  | 160,300 |  |
| Automotive Sensors |  | — |  |  | 101,738 |  |  | — |  |  | 101,738 |  |
| Industrial Products |  | — |  |  | — |  |  | 251,126 |  |  | 251,126 |  |
| Total |  | $ | 1,300,744 |  |  | $ | 528,058 |  |  | $ | 251,126 |  |  | $ | 2,079,928 |  |

[0000889331-23-000016:notes:43]
See Note 16, Segment Information, for net sales by segment and countries.

[0000889331-23-000016:notes:44]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-23-000016:notes:45]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-23-000016:notes:46]
Revenue and Billing

[0000889331-23-000016:notes:47]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0000889331-23-000016:notes:48]
Ship and Debit Program

[0000889331-23-000016:notes:49]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-23-000016:notes:50]
Return to Stock

[0000889331-23-000016:notes:51]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-23-000016:notes:52]
Volume Rebates

[0000889331-23-000016:notes:53]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-23-000016:notes:54]
Allowance for Credit Losses

[0000889331-23-000016:notes:55]
The Company currently measures the expected credit losses based on our historical credit loss experience. The Company has not experienced significant recent or historical credit losses and is not forecasting any significant credit losses which would require adjustments to our methodology. If current conditions and supportable forecasts indicate that our historical loss experience is not reasonable and no longer supportable, the Company may adjust its historical credit loss experience and to reflect these conditions and forecasts. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also analyzes all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and historical collection and loss experience. Historically, the allowance for credit losses has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-23-000016:notes:56]
As of December 31, 2022 and January 1, 2022, the Company’s allowance for credit losses was $1.6 million and $1.9 million, respectively. Additionally, the Company had $4.8 million and $2.1 million of trade receivables greater than 90 days past due as of December 31, 2022 and January 1, 2022, respectively.

[0000889331-23-000016:notes:57]
Advertising Costs

[0000889331-23-000016:notes:58]
The Company expenses advertising costs as incurred, which amounted to $3.8 million, $2.1 million, and $2.1 million in fiscal years 2022, 2021 and 2020, respectively, and are included as a component of selling, general, and administrative expenses.

[0000889331-23-000016:notes:59]
Shipping and Handling Fees and Costs

[0000889331-23-000016:notes:60]
Amounts billed to customers related to shipping and handling are classified as revenue. Costs incurred for shipping and handling of $13.9 million, $15.4 million, and $11.1 million in fiscal years 2022, 2021, and 2020, respectively, are classified in selling, general, and administrative expenses.

[0000889331-23-000016:notes:61]
Foreign Currency Translation / Remeasurement

[0000889331-23-000016:notes:62]
The Company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. Adjustments from the translation process are recognized in Shareholders’ equity as a component of Accumulated other comprehensive income (loss). The amount of foreign currency gain or loss recognized in the Consolidated Statements of Net Income was a loss of $24.4 million in fiscal year 2022, a loss of $17.2 million in fiscal year 2021, and a gain of $14.9 million in fiscal year 2020.

[0000889331-23-000016:notes:63]
Stock-Based Compensation

[0000889331-23-000016:notes:64]
The Company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as operating cash flows. See Note 12, Stock-Based Compensation, for additional information on stock-based compensation.

[0000889331-23-000016:notes:65]
Coal Mining Liability

[0000889331-23-000016:notes:66]
Included in other long-term liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €1.6 million ($1.7 million) and €1.9 million ($2.1 million) at December 31, 2022 and January 1, 2022, respectively. Management, in conjunction with an independent third-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time.

[0000889331-23-000016:notes:67]
Other Expense (Income), Net

[0000889331-23-000016:notes:68]
Other expense (income), net generally consists of interest income, royalties, change in fair value of available-for-sale securities, pension non-service costs and settlements and other non-operating expense (income).

[0000889331-23-000016:notes:69]
Income Taxes

[0000889331-23-000016:notes:70]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards, and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-23-000016:notes:71]
Deferred U.S. income taxes and non-U.S. taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-23-000016:notes:72]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-23-000016:notes:73]
The 2017 Tax Cuts and Jobs Act (the "Tax Act"), among other things, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and included base broadening provisions commonly referred to as the global intangible low-taxed income provisions ("GILTI").

[0000889331-23-000016:notes:74]
The Company elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The long-term portion of this Toll Charge which remains payable as of December 31, 2022, totaling $14.8 million, is recorded in Other long-term liabilities, and the anticipated 2023 annual installment payment of $5.0 million is included in Accrued income taxes, on the Consolidated Balance Sheet as of December 31, 2022.

[0000889331-23-000016:notes:75]
In accordance with guidance issued by the Financial Accounting Standards Board ("FASB") staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 31, 2022, January 1, 2022 and December 26, 2020, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-23-000016:notes:76]
Fair Value Measurements

[0000889331-23-000016:notes:77]
Certain assets and liabilities are required to be recorded at fair value on a recurring basis. Fair value is determined based on the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants. The Company records the fair value of its available-for-sale securities and pension plan assets on a recurring basis. Assets measured at fair value on a nonrecurring basis include long-lived assets held and used, long-lived assets held for sale, goodwill and other intangible assets. The fair value of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The three-tier value hierarchy, which prioritizes valuation methodologies based on the reliability of the inputs, is:

[0000889331-23-000016:notes:78]
Level 1 – Valuations based on quoted prices for identical assets and liabilities in active markets.

[0000889331-23-000016:notes:79]
Level 2 – Valuations based on observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data.

[0000889331-23-000016:notes:80]
Level 3 – Valuations based on unobservable inputs reflecting the Company’s own assumptions, consistent with reasonably available assumptions made by other market participants.

[0000889331-23-000016:notes:81]
Recently Adopted Accounting Standards

[0000889331-23-000016:notes:82]
In November 2021, the FASB issued ASU No. 2021-10, "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance". The standard, requires annual disclosures about transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy: 1) Information about the nature of the transactions and the related accounting policy used to account for the transactions; 2) The line items on the balance sheet and income statement that are affected by the transactions, and the amounts applicable to each financial statement line item; 3) Significant terms and conditions of the transactions, including commitments and contingencies. The guidance is effective for fiscal years beginning after December 15, 2021 with early adoption permitted. The adoption of ASU 2021-10 did not have a material impact on the Company's Consolidated Financial Statements.

[0000889331-23-000016:notes:83]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The adoption of ASU 2021-08 did not have a material impact on the Company's Consolidated Financial Statements.

[0000889331-23-000016:notes:84]
Recently Issued Accounting Standards

[0000889331-23-000016:notes:85]
In December 2022, the FASB issued ASU No. 2022-06, "Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848". the amendments in this Update defer the sunset date of Topic 848 from December 31, 2022, to December 31, 2024, after which entities will no longer be permitted to apply the relief in Topic 848. The amendments in this Update are effective for all entities upon issuance of this Update. On June 30, 2022, the Company amended and restated its Credit Agreement, replacing LIBOR-based interest benchmarks with Secured Overnight Financing Rate ("SOFR") based floating-rate loans. The Company's loans under the available credit facility are SOFR based floating-rate loans. The Company does not expect any effect from the adoption of this guidance on the Company's Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-23-000016:notes:86]
Acquisitions

[0000889331-23-000016:notes:87]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0000889331-23-000016:notes:88]
C&K Switches

[0000889331-23-000016:notes:89]
On July 19, 2022, the Company acquired C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, datacom, and aerospace. At the time the Company and C&K entered into a definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the electronics-passive products and sensors business within the Company's Electronics segment.

[0000889331-23-000016:notes:90]
The acquisition was funded through a combination of cash on hand and debt. The total purchase consideration of $523.0 million, net of cash acquired, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary area not yet finalized relates to the completion of the valuation of certain acquired income tax assets and liabilities. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-23-000016:notes:91]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the C&K acquisition:

[0000889331-23-000016:notes:92]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 523,014 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 20,967 |  |
| Inventories | 42,968 |  |
| Other current assets | 2,932 |  |
| Property, plant, and equipment | 32,791 |  |
| Intangible assets | 254,700 |  |
| Goodwill | 270,245 |  |
| Other non-current assets | 14,797 |  |
| Current liabilities | (47,734) |  |
| Long-term debt | (9,626) |  |
| Other non-current liabilities | (59,026) |  |
|  | $ | 523,014 |  |

[0000889331-23-000016:notes:93]
All C&K goodwill, other assets and liabilities were recorded in the Electronics segment and are reflected in the Americas, Europe and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining C&K’s products and technology with the Company’s existing Electronics products portfolio. Goodwill resulting from the C&K acquisition is not expected to be deductible for tax purposes.

[0000889331-23-000016:notes:94]
Included in the Company’s Consolidated Statements of Net Income for the fiscal year ended December 31, 2022 are net sales of $81.7 million, and a loss before income taxes of $4.2 million, since the July 19, 2022 acquisition of C&K.

[0000889331-23-000016:notes:95]
As required by purchase accounting rules, the Company recorded a $10.8 million step-up of inventory to its fair value as of the acquisition date. The step-up was amortized as a non-cash charge to cost of sales during the fiscal year ended December 31, 2022, as the acquired inventory was sold, and is reflected as other non-segment costs.

[0000889331-23-000016:notes:96]
For the fiscal year ended December 31, 2022, the Company incurred $9.1 million of legal and professional fees related to the C&K acquisition recognized as Selling, general, and administrative expenses and reflected as other non-segment costs.

[0000889331-23-000016:notes:97]
Embed

[0000889331-23-000016:notes:98]
On April 12, 2022, the Company acquired Embed Ltd. (“Embed”).  Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets, primarily including commercial vehicle electronification and eMobility. The business is included in the commercial vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand. The total purchase consideration was $9.2 million, net of cash.

[0000889331-23-000016:notes:99]
Carling Technologies

[0000889331-23-000016:notes:100]
On November 30, 2021, the Company acquired Carling Technologies, Inc. (“Carling”), pursuant to the Stock Purchase Agreement, dated as of October 19, 2021. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle electronification, communications infrastructure and marine markets. At the time of acquisition, Carling had annualized sales of approximately $170 million. The business is headquartered in Plainville, Connecticut, with offices and facilities located around the world and is reported as part of the commercial vehicle business within our Transportation segment. The purchase price for Carling Technologies was approximately $315 million subject to change for a working capital adjustment.

[0000889331-23-000016:notes:101]
The acquisition was funded with cash on hand. The total purchase consideration of $314.1 million, net of cash, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0000889331-23-000016:notes:102]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Carling acquisition:

[0000889331-23-000016:notes:103]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 314,094 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 26,232 |  |
| Inventories | 56,479 |  |
| Other current assets | 3,765 |  |
| Property, plant, and equipment | 56,128 |  |
| Intangible assets | 126,390 |  |
| Goodwill | 98,377 |  |
| Other non-current assets | 4,007 |  |
| Current liabilities | (21,790) |  |
| Other non-current liabilities | (35,494) |  |
|  | $ | 314,094 |  |

[0000889331-23-000016:notes:104]
All Carling goodwill, other assets and liabilities were recorded in the Transportation segment and are primarily reflected in the Americas, Europe and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Carling’s products and technology with the Company’s existing commercial vehicle products portfolio. Goodwill resulting from the Carling acquisition is not expected to be deductible for tax purposes.

[0000889331-23-000016:notes:105]
During the fiscal year ended December 31, 2022, the Company paid $0.5 million related to the final working capital adjustment and made measurement period adjustments to reduce the fair value of property, plant and equipment of $8.2 million, inventories of $1.0 million, and an increase in net accounts receivable of $0.7 million, intangible assets attributable to customer relationships of $0.5 million, other current assets of $0.3 million, other non-current liabilities of $0.3 million. As a result of these adjustments along with a corresponding reduction of deferred tax liabilities of $2.5 million, goodwill was increased by $6.0 million.

[0000889331-23-000016:notes:106]
As required by purchase accounting rules, the Company recorded a $6.4 million step-up of inventory to its fair value as of the acquisition date. The step-up was amortized as a non-cash charge to cost of goods sold during the fourth quarter of 2021 and first quarter of 2022, as the acquired inventory was sold, and is reflected as other non-segment costs. The Company recognized

[0000889331-23-000016:notes:107]
a non-cash charge of $4.8 million and $1.6 million to cost of goods sold during the fiscal years ended December 31, 2022 and January 1, 2022, respectively.

[0000889331-23-000016:notes:108]
For the fiscal year ended January 1, 2022, the Company incurred approximately $4.5 million of legal and professional fees related to the Carling acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-23-000016:notes:109]
Hartland Controls

[0000889331-23-000016:notes:110]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning ("HVAC") and other industrial and systems applications, and eMobility. At the time of acquisition, Hartland had annualized sales of approximately $70 million. The purchase price for Hartland was $111.0 million and the operations of Hartland are included in the Industrial segment.

[0000889331-23-000016:notes:111]
The total purchase consideration of $108.5 million, net of cash, cash equivalents, and restricted cash has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. As of December 31, 2022, the Company had restricted cash of $0.8 million in an escrow account for general indemnification purposes.

[0000889331-23-000016:notes:112]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Hartland acquisition:

[0000889331-23-000016:notes:113]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired, and restricted cash | $ | 108,516 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 12,915 |  |
| Inventories | 35,808 |  |
| Other current assets | 2,224 |  |
| Property, plant, and equipment | 6,296 |  |
| Intangible assets | 39,660 |  |
| Goodwill | 38,502 |  |
| Other non-current assets | 3,782 |  |
| Current liabilities | (24,861) |  |
| Other non-current liabilities | (5,810) |  |
|  | $ | 108,516 |  |

[0000889331-23-000016:notes:114]
All Hartland goodwill, other assets and liabilities were recorded in the Industrial segment and are primarily reflected in the Americas and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Hartland’s products and technology with the Company’s existing industrial products portfolio. Goodwill resulting from the Hartland acquisition is not expected to be deductible for tax purposes.

[0000889331-23-000016:notes:115]
The Company recorded a $6.8 million step-up of inventory to its fair value as of the acquisition date based on the valuation. The step-up was fully amortized as a $6.8 million non-cash charge to cost of goods sold during the first and second quarters of 2021, as the acquired inventory was sold, and is reflected as other non-segment costs.

[0000889331-23-000016:notes:116]
For the fiscal year ended January 1, 2022, the Company incurred approximately $0.8 million of legal and professional fees related to the Hartland acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-23-000016:notes:117]
Pro Forma Results

[0000889331-23-000016:notes:118]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company, C&K as though the acquisition had occurred as of December 27, 2020, and Hartland and Carling as though the acquisitions had occurred as of December 29, 2019. The Company has not included pro forma results of operations for Embed as its operations were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated

[0000889331-23-000016:notes:119]
results had the C&K acquisition occurred as of December 27, 2020 and had the Hartland and Carling acquisitions occurred as of December 29, 2019 or of future consolidated operating results.

[0000889331-23-000016:notes:120]
|  |  | For the Fiscal Year Ended |
| (in thousands, except per share amounts) |  | December 31,2022 |  | January 1, 2022 |  | December 26, 2020 |
| Net sales |  | $ | 2,639,132 |  |  | $ | 2,459,009 |  |  | $ | 1,662,896 |  |
| Income before income taxes |  | 483,013 |  |  | 337,894 |  |  | 141,491 |  |
| Net income |  | 399,606 |  |  | 274,763 |  |  | 115,078 |  |
| Net income per share — basic |  | 16.16 |  |  | 11.17 |  |  | 4.72 |  |
| Net income per share — diluted |  | 16.03 |  |  | 11.02 |  |  | 4.68 |  |

[0000889331-23-000016:notes:121]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-23-000016:notes:122]
|  |  | For the Fiscal Year Ended |
| (in thousands) |  | December 31,2022 |  | January 1, 2022 |  | December 26, 2020 |
| Amortization (a) |  | $ | (4,646) |  |  | $ | (18,410) |  |  | $ | (12,669) |  |
| Depreciation |  | 1,979 |  |  | 2,537 |  |  | 253 |  |
| Transaction costs (b) |  | 9,108 |  |  | (3,727) |  |  | (5,381) |  |
| Amortization of inventory step-up (c) |  | 15,593 |  |  | (2,426) |  |  | (13,156) |  |
| Interest expense (d) |  | 815 |  |  | 2,624 |  |  | — |  |
| Income tax (expense) benefit of above items |  | (5,569) |  |  | 5,065 |  |  | 6,706 |  |

[0000889331-23-000016:notes:123]
(a)The amortization adjustment for the twelve months ended December 31, 2022, January 1, 2022, and December 26, 2020, primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-23-000016:notes:124]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the twelve months ended December 31, 2022 and January 1, 2022, respectively, and recognition of those fees during the twelve months ended January 1, 2022 and December 26, 2020, respectively.

[0000889331-23-000016:notes:125]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the twelve months ended December 31, 2022 and January 1, 2022, respectively, and the recognition of the amortization during the twelve months ended January 1, 2022 and  December 26, 2020, respectively. The inventory step-up is amortized over four months for all acquisitions, as the inventory was sold.

[0000889331-23-000016:notes:126]
(d)The interest expense adjustment reflects lower interest expense associated with the financing of the C&K acquisition that replaced higher pre-acquisition debt.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-23-000016:notes:127]
The components of inventories at December 31, 2022 and January 1, 2022 are as follows:

[0000889331-23-000016:notes:128]
| (in thousands) | 2022 |  | 2021 |
| Raw materials | $ | 231,043 |  |  | $ | 168,409 |  |
| Work in process | 134,792 |  |  | 117,506 |  |
| Finished goods | 226,215 |  |  | 195,656 |  |
| Inventory reserves | (44,360) |  |  | (35,900) |  |
| Total | $ | 547,690 |  |  | $ | 445,671 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-23-000016:notes:129]
The components of net property, plant, and equipment at December 31, 2022 and January 1, 2022 are as follows:

[0000889331-23-000016:notes:130]
| (in thousands) | 2022 |  | 2021 |
| Land and land improvements | $ | 22,089 |  |  | $ | 23,470 |  |
| Building and building improvements | 191,733 |  |  | 151,297 |  |
| Machinery and equipment | 812,540 |  |  | 779,559 |  |
| Accumulated depreciation and amortization | (545,252) |  |  | (516,437) |  |
| Total | $ | 481,110 |  |  | $ | 437,889 |  |

[0000889331-23-000016:notes:131]
The Company recorded depreciation expense of $65.0 million, $55.9 million, and $56.1 million for the fiscal years ended December 31, 2022, January 1, 2022, and December 26, 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-23-000016:notes:132]
Goodwill and Other Intangible Assets

[0000889331-23-000016:notes:133]
The amounts for goodwill and changes in the carrying value by segment are as follows:

[0000889331-23-000016:notes:134]
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Gross goodwill as of December 26, 2020 | $ | 676,325 |  |  | $ | 138,354 |  |  | $ | 47,551 |  |  | $ | 862,230 |  |
| Accumulated impairment losses as of December 26, 2020 | — |  |  | (36,423) |  |  | (8,995) |  |  | (45,418) |  |
| Net goodwill as of December 26, 2020 | $ | 676,325 |  |  | $ | 101,931 |  |  | $ | 38,556 |  |  | $ | 816,812 |  |
| Changes during 2021: |  |  |  |  |  |  |  |
| Additions (a) | — |  |  | 96,307 |  |  | 38,502 |  |  | $ | 134,809 |  |
| Foreign currency translation adjustments | (16,080) |  |  | (6,106) |  |  | 179 |  |  | (22,007) |  |
| Gross goodwill as of January 1, 2022 | 660,245 |  |  | 228,555 |  |  | 86,232 |  |  | 975,032 |  |
| Accumulated impairment losses as of January 1, 2022 | — |  |  | (36,177) |  |  | (9,065) |  |  | (45,242) |  |
| Net goodwill as of January 1, 2022 | $ | 660,245 |  |  | $ | 192,378 |  |  | $ | 77,167 |  |  | $ | 929,790 |  |
| Changes during 2022: |  |  |  |  |  |  |  |
| Additions (b) | 270,245 |  |  | 14,886 |  |  | — |  |  | 285,131 |  |
| Foreign currency translation adjustments | (21,323) |  |  | (8,648) |  |  | (1,343) |  |  | (31,314) |  |
| Gross goodwill as of December 31, 2022 | 909,167 |  |  | 234,793 |  |  | 84,889 |  |  | 1,228,849 |  |
| Accumulated impairment losses as of December 31, 2022 |  |  | (33,401) |  |  | (8,526) |  |  | (41,927) |  |
| Net goodwill as of December 31, 2022 | $ | 909,167 |  |  | $ | 201,392 |  |  | $ | 76,363 |  |  | $ | 1,186,922 |  |

[0000889331-23-000016:notes:135]
(a) The additions resulted from the acquisitions of Carling and Hartland.

[0000889331-23-000016:notes:136]
(b) The additions resulted from the acquisitions of C&K, Embed and Carling.

[0000889331-23-000016:notes:137]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.

[0000889331-23-000016:notes:138]
During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Transportation segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition, during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling their existing program. The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data.

[0000889331-23-000016:notes:139]
The components of intangible assets at December 31, 2022 and January 1, 2022 are as follows:

[0000889331-23-000016:notes:140]
|  | As of December 31, 2022 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 17,938 |  |  | $ | 2,299 |  |  | $ | 15,639 |  |
| Patents, licenses and software | 259,603 |  |  | 140,208 |  |  | 119,395 |  |
| Distribution network | 41,733 |  |  | 40,955 |  |  | 778 |  |
| Customer relationships, trademarks, and tradenames | 623,721 |  |  | 165,563 |  |  | 458,158 |  |
| Total | $ | 942,995 |  |  | $ | 349,025 |  |  | $ | 593,970 |  |

[0000889331-23-000016:notes:141]
The Company reclassified $50.3 million and $31.1 million of gross carrying value and accumulated amortization, respectively, from customer relationships, trademarks and tradenames to patents, licenses and software as of December 31, 2022. This reclassification had no consolidated financial impact on net book value of intangible assets.

[0000889331-23-000016:notes:142]
|  | As of January 1, 2022 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 19,542 |  |  | $ | 1,906 |  |  | $ | 17,636 |  |
| Patents, licenses and software | 164,556 |  |  | 101,307 |  |  | 63,249 |  |
| Distribution network | 43,361 |  |  | 40,591 |  |  | 2,770 |  |
| Customer relationships, trademarks, and tradenames | 487,710 |  |  | 164,239 |  |  | 323,471 |  |
| Total | $ | 715,169 |  |  | $ | 308,043 |  |  | $ | 407,126 |  |

[0000889331-23-000016:notes:143]
During the year ended December 31, 2022, the Company recorded additions to other intangible assets of $254.7 million related to the C&K acquisition, the components of which were as follows:

[0000889331-23-000016:notes:144]
|  | 2022 |
| (in thousands, except weighted average useful life) | Weighted AverageUseful Life (Years) |  | Amount |
| Patents, developed technology | 12.0 |  | $ | 55,700 |  |
| Customer relationships, trademarks, and tradenames | 17.4 |  | 199,000 |  |
| Total |  |  | $ | 254,700 |  |

[0000889331-23-000016:notes:145]
For intangible assets with definite lives, the Company recorded amortization expense of $55.7 million, $42.7 million, and $40.0 million in 2022, 2021, and 2020, respectively.

[0000889331-23-000016:notes:146]
During the fourth quarter of 2022, the Company recorded a $2.9 million non-cash impairment charge for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment.

[0000889331-23-000016:notes:147]
Estimated annual amortization expense related to intangible assets with definite lives at December 31, 2022 is as follows:

[0000889331-23-000016:notes:148]
| (in thousands) | Amount |
| 2023 | $ | 60,274 |  |
| 2024 | 56,965 |  |
| 2025 | 56,602 |  |
| 2026 | 46,115 |  |
| 2027 | 44,209 |  |
| 2028 and thereafter | 329,805 |  |
| Total | $ | 593,970 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-23-000016:notes:149]
Accrued Liabilities

[0000889331-23-000016:notes:150]
The components of accrued liabilities at December 31, 2022 and January 1, 2022 are as follows:

[0000889331-23-000016:notes:151]
| (in thousands) | 2022 |  | 2021 |
| Employee-related liabilities | $ | 99,089 |  |  | $ | 92,018 |  |
| Current lease liability | 12,841 |  |  | 9,018 |  |
| Other non-income taxes | 10,594 |  |  | 4,280 |  |
| Professional services | 7,160 |  |  | 4,299 |  |
| Other customer reserves | 5,064 |  |  | 702 |  |
| Interest | 4,449 |  |  | 4,402 |  |
| Deferred revenue | 2,593 |  |  | 1,105 |  |
| Restructuring liability | 2,434 |  |  | 2,944 |  |
| Current benefit liability | 1,318 |  |  | 1,248 |  |
| Other | 41,515 |  |  | 39,673 |  |
| Total | $ | 187,057 |  |  | $ | 159,689 |  |

[0000889331-23-000016:notes:152]
Employee-related liabilities consist primarily of payroll, sales commission, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other client-related liabilities.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000889331-23-000016:notes:153]
Lease Commitments
Under ASC 842, a contract contains a lease if there is an identified asset and the Company has the right to control the asset. The Company determines whether a contract contains a lease at contract inception. The Company leases office and production space under various non-cancellable operating leases that expire no later than 2035. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The Company also has production equipment, office equipment and vehicles under operating leases and finance leases that were acquired through the C&K acquisition. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants. The Company has elected to use the available practical expedient to account for the lease and non-lease components of its leases as a single component. As the Company elected not to separate lease and non-lease components and instead to account for them as a single lease component, the variable lease cost primarily represents variable payments such as common area maintenance and utilities.

[0000889331-23-000016:notes:154]
The Company does not have a published credit rating because it has no publicly traded debt; therefore, the Company is generating its incremental borrowing rate ("IBR"), using a synthetic credit rating model that compares its credit quality to other rated companies based on certain financial metrics and ratios. The reference rate will be based on the yield curve of companies with similar credit quality based on the metrics and adjusted for currency in regions where we have significant operations.

[0000889331-23-000016:notes:155]
All leases with an initial term of 12 months or less that do not include an option to extend or purchase the underlying asset that the Company is reasonably certain to exercise (“short-term leases”) are not recorded on the Consolidated Balance Sheets. Short-term lease expenses are recognized on a straight-line basis over the lease term.

[0000889331-23-000016:notes:156]
The following table presents the classification of right of use assets and lease liabilities as of December 31, 2022 and January 1, 2022:

[0000889331-23-000016:notes:157]
|  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Balance Sheet Classification | December 31, 2022 |  | January 1, 2022 |
| Operating Leases |  |  |  |  |
| Right of use assets - operating lease | Right of use lease assets, net | $ | 54,901 |  |  | $ | 29,616 |  |
| Current operating lease liabilities | Accrued liabilities | 11,694 |  |  | 9,018 |  |
| Non-current operating lease liabilities | Non-current lease liabilities | 44,963 |  |  | 22,305 |  |
| Total operating lease liabilities |  | $ | 56,657 |  |  | $ | 31,323 |  |
| Finance Leases |  |  |  |  |
| Right of use assets - finance lease | Right of use lease assets, net | $ | 2,481 |  |  | $ | — |  |
| Current finance lease liabilities | Accrued liabilities | 1,147 |  |  | — |  |
| Non-current finance lease liabilities | Non-current lease liabilities | 698 |  |  | — |  |
| Total finance lease liabilities |  | $ | 1,845 |  |  | $ | — |  |

[0000889331-23-000016:notes:158]
The following table represents the lease costs for 2022, 2021, and 2020:

[0000889331-23-000016:notes:159]
|  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Statements of Net Income Classification | December 31, 2022 |  | January 1, 2022 |  | December 26, 2020 |
| Operating lease expenses | Cost of sales, SG&A expenses | $ | 14,071 |  |  | $ | 9,929 |  |  | $ | 8,591 |  |
| Finance lease: |  |  |  |  |  |  |
| Finance lease expenses | Cost of sales | 112 |  |  | — |  |  | — |  |
| Interest on lease liabilities | Other expenses | 13 |  |  | — |  |  | — |  |
| Short-term lease expenses | Cost of sales, SG&A expenses | 1,130 |  |  | 345 |  |  | 512 |  |
| Variable lease expenses | Cost of sales, SG&A expenses | 1,091 |  |  | 1,165 |  |  | 1,307 |  |
| Total lease costs | Cost of sales, SG&A expenses | $ | 16,417 |  |  | $ | 11,439 |  |  | $ | 10,410 |  |

[0000889331-23-000016:notes:160]
The Company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. The Company acquired through the C&K acquisition certain machinery and equipment under finance leases.

[0000889331-23-000016:notes:161]
Rent expense under these leases was $16.4 million, $11.4 million, and $10.4 million in 2022, 2021, and 2020, respectively.

[0000889331-23-000016:notes:162]
| Maturity of Lease Liabilities as of December 31, 2022(in thousands) | Operating leases |  | Finance Leases |
| 2023 | $ | 13,966 |  |  | $ | 1,166 |  |
| 2024 | 13,709 |  |  | 425 |  |
| 2025 | 8,099 |  |  | 283 |  |
| 2026 | 5,652 |  |  | 1 |  |
| 2027 | 4,447 |  |  | — |  |
| 2028 and thereafter | 21,217 |  |  | — |  |
| Total lease payments | $ | 67,090 |  |  | $ | 1,875 |  |
| Less: Imputed interest | (10,433) |  |  | (30) |  |
| Present value of lease liabilities | $ | 56,657 |  |  | $ | 1,845 |  |

[0000889331-23-000016:notes:163]
|  | Fiscal Year Ended |
|  | December 31, 2022 |  | January 1, 2022 |
| Weighted-average remaining lease term (years) |  |  |  |
| Operating leases | 6.84 |  | 4.79 |
| Finance leases | 1.90 |  | — |  |
| Weighted-average discount rate |  |  |  |
| Operating leases | 4.84 | % |  | 4.27 | % |
| Finance leases | 1.43 | % |  | — |  |

[0000889331-23-000016:notes:164]
|  | Fiscal Year Ended |
| (in thousands) | December 31, 2022 |  | January 1, 2022 |  | December 26, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flow - payments on operating leases | $ | (12,298) |  |  | $ | (10,150) |  |  | $ | (8,929) |  |
| Operating cash flow - interest payments on finance leases | (13) |  |  | — |  |  | — |  |
| Financing cash flow - payments on finance lease obligations | (719) |  |  | — |  |  | — |  |
| Leased assets obtained in exchange of new lease obligations, including leases acquired: |  |  |  |  |  |
| Operating leases | $ | 37,760 |  |  | $ | 20,217 |  |  | $ | 2,862 |  |
| Finance leases | 2,502 |  |  | — |  |  | — |  |

[0000889331-23-000016:notes:165]
There were no sale leaseback transactions for the fiscal years ended December 31, 2022, and December 26, 2020. The net gain recorded from a sale leaseback transaction was $4.1 million for the fiscal year ended January 1, 2022.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-23-000016:notes:166]
Restructuring, Impairment and Other Charges
The Company recorded restructuring, impairment and other charges for fiscal years 2022, 2021, and 2020 as follows:

[0000889331-23-000016:notes:167]
|  | Fiscal Year Ended December 31, 2022 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 2,792 |  |  | $ | 2,694 |  |  | $ | 283 |  |  | $ | 5,769 |  |
| Other restructuring charges | 276 |  |  | 1,076 |  |  | — |  |  | 1,352 |  |
| Total restructuring charges | 3,068 |  |  | 3,770 |  |  | 283 |  |  | 7,121 |  |
| Impairment | 2,856 |  |  | — |  |  | — |  |  | 2,856 |  |
| Total | $ | 5,924 |  |  | $ | 3,770 |  |  | $ | 283 |  |  | $ | 9,977 |  |

[0000889331-23-000016:notes:168]
|  | Fiscal Year Ended January 1, 2022 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,124 |  |  | $ | 404 |  |  | $ | 347 |  |  | $ | 1,875 |  |
| Other restructuring charges | — |  |  | 283 |  |  | — |  |  | 283 |  |
| Total restructuring charges | 1,124 |  |  | 687 |  |  | 347 |  |  | 2,158 |  |

[0000889331-23-000016:notes:169]
|  | Fiscal Year Ended December 26, 2020 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 2,540 |  |  | $ | 682 |  |  | $ | 2,231 |  |  | $ | 5,453 |  |
| Other restructuring charges | — |  |  | 175 |  |  | 10 |  |  | 185 |  |
| Total restructuring charges | 2,540 |  |  | 857 |  |  | 2,241 |  |  | 5,638 |  |
| Impairment | — |  |  | 33,841 |  |  | 2,237 |  |  | 36,078 |  |
| Total | $ | 2,540 |  |  | $ | 34,698 |  |  | $ | 4,478 |  |  | $ | 41,716 |  |

[0000889331-23-000016:notes:170]
2022

[0000889331-23-000016:notes:171]
For the year ended December 31, 2022, the Company recorded total restructuring charges of $7.1 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment's passenger car and automotive sensor businesses and the reorganization of selling and administrative functions within the Electronics segment due to the C&K acquisition. During the fourth quarter of 2022, the Company recorded a $2.9 million non-cash impairment charge for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the intangible asset impairment charge.

[0000889331-23-000016:notes:172]
2021

[0000889331-23-000016:notes:173]
For the year ended January 1, 2022, the Company recorded total restructuring charges of $2.2 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Electronics and Transportation segments.

[0000889331-23-000016:notes:174]
2020

[0000889331-23-000016:notes:175]
For the year ended December 26, 2020, the Company recorded total restructuring charges of $5.6 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the previously announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $36.1 million of impairment charges, which included a $33.8 million goodwill impairment charge associated with the automotive sensors reporting unit within the Transportation segment in the second quarter of 2020 and a $2.2 million impairment charge related to the land and building associated with the Company’s previously announced consolidation of a manufacturing facility within the Industrial segment in the first quarter of 2020. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the goodwill impairment charge.

[0000889331-23-000016:notes:176]
The restructuring reserves as of December 31, 2022 and January 1, 2022 are $2.4 million and $2.9 million, respectively. The restructuring reserves are included within accrued liabilities. Payments associated with employee terminations reflected in the above table were substantially completed by December 31, 2022. The Company anticipates that the remaining payments associated with employee terminations will be completed in fiscal 2023.


## us-gaap:DebtDisclosureTextBlock

[0000889331-23-000016:notes:177]
Debt

[0000889331-23-000016:notes:178]
The carrying amounts of debt at December 31, 2022 and January 1, 2022 are as follows:

[0000889331-23-000016:notes:179]
| (in thousands) | 2022 |  | 2021 |
| Revolving Credit Facility | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan | 296,250 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 | 124,716 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 | 101,265 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 | 100,000 |  |  | — |  |
| Other | 9,113 |  |  | — |  |
| Unamortized debt issuance costs | (4,847) |  |  | (3,087) |  |
| Total debt | 1,001,497 |  |  | 636,897 |  |
| Less: Current maturities | (134,874) |  |  | (25,000) |  |
| Total long-term debt | $ | 866,623 |  |  | $ | 611,897 |  |

[0000889331-23-000016:notes:180]
Interest paid on all Company debt was $25.4 million, $17.4 million, and $20.1 million in fiscal year 2022, 2021, and 2020, respectively.

[0000889331-23-000016:notes:181]
Revolving Credit Facility and Term Loan

[0000889331-23-000016:notes:182]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (as so amended and restated, the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000016:notes:183]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either SOFR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000016:notes:184]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the fiscal year ended December 31, 2022, the Company made term loan payments of $3.8 million. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $296.3 million, respectively, as of December 31, 2022.

[0000889331-23-000016:notes:185]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-23-000016:notes:186]
As of December 31, 2022, the effective interest rate on outstanding borrowings under the credit facility was 5.42%.

[0000889331-23-000016:notes:187]
As of December 31, 2022, the Company had no outstanding in letters of credit and had available $600.0 million of borrowing capacity under the revolving credit facility. At December 31, 2022, the Company was in compliance with all covenants under the credit agreement.

[0000889331-23-000016:notes:188]
Senior Notes

[0000889331-23-000016:notes:189]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-23-000016:notes:190]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the fiscal year ended December 31, 2022, the Company paid off $25.0 million of U.S. Senior Notes, Series A due 2022.

[0000889331-23-000016:notes:191]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000016:notes:192]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000016:notes:193]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2032.

[0000889331-23-000016:notes:194]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-23-000016:notes:195]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At December 31, 2022, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-23-000016:notes:196]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-23-000016:notes:197]
Debt Issuance Costs

[0000889331-23-000016:notes:198]
During fiscal year 2022, the Company paid debt issuance costs of $2.7 million in connection with the amended and restated Credit Agreement, dated June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility noted in below, are being amortized over the life of the amended and restated Credit Agreement.

[0000889331-23-000016:notes:199]
During fiscal year 2020, the Company paid debt issuance costs of $1.8 million in relation to the amended the Credit Agreement on April 3, 2020 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the amended Credit Agreement.

[0000889331-23-000016:notes:200]
Debt Maturities

[0000889331-23-000016:notes:201]
Scheduled maturities of the Company’s long-term debt for each of the five years succeeding December 31, 2022 and thereafter are summarized as follows:

[0000889331-23-000016:notes:202]
| (in thousands) | ScheduledMaturities |
| 2023 | $ | 134,874 |  |
| 2024 | 13,916 |  |
| 2025 | 67,674 |  |
| 2026 | 16,116 |  |
| 2027 | 447,500 |  |
| 2028 and thereafter | 326,264 |  |
|  | $ | 1,006,344 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-23-000016:notes:203]
Fair Value of Assets and Liabilities

[0000889331-23-000016:notes:204]
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a three-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows:

[0000889331-23-000016:notes:205]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0000889331-23-000016:notes:206]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable, and

[0000889331-23-000016:notes:207]
Level 3—Valuations based upon one or more significant unobservable inputs.

[0000889331-23-000016:notes:208]
There were no transfers in or out of Level 1, Level 2 and Level 3 during the year ended December 31, 2022.

[0000889331-23-000016:notes:209]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0000889331-23-000016:notes:210]
Cash Equivalents

[0000889331-23-000016:notes:211]
Cash equivalents primarily consist of money market funds, which are held with an institution with sound credit rating and are highly liquid. The Company classified cash equivalents as Level 1 and are valued at cost, which approximates fair value.

[0000889331-23-000016:notes:212]
Investments in Equity Securities

[0000889331-23-000016:notes:213]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 1 of the valuation hierarchy. Such securities are further detailed in Note 1, Summary of Significant Accounting Policies and Other Information.

[0000889331-23-000016:notes:214]
Other Investments

[0000889331-23-000016:notes:215]
The Company had certain convertible debt and convertible preferred stock investments that were accounted for under the cost method reflected in Investments and Other assets in the Consolidated Balance Sheets. During the fiscal year ended January 1, 2022, the Company impaired the remaining book value of these investments and recorded an impairment charge of $0.5 million in Other expense (income), net in the Consolidated Statements of Net Income. As of December 31, 2022 and January 1, 2022, the balances of these investments were zero.

[0000889331-23-000016:notes:216]
Derivatives Designated as Hedging Instruments

[0000889331-23-000016:notes:217]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive (loss) income until the underlying transactions are recognized in earnings. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by observable market data.

[0000889331-23-000016:notes:218]
The use of derivatives creates exposure to credit risk relating to potential losses that could be recognized in the event that the counterparties to these instruments fail to perform their obligations under the contracts. The Company seeks to minimize this risk by limiting our counterparties to major financial institutions with acceptable credit ratings and monitoring the total value of positions with individual counterparties. In the event of a default by one of our counterparties, the Company may not receive payments provided for under the terms of our derivatives.

[0000889331-23-000016:notes:219]
Derivatives Not Designated as Hedging Instruments

[0000889331-23-000016:notes:220]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at July 14, 2022 was €117.0 million and expires on December 7, 2023. The foreign currency contract was not designated as a hedge instrument and is marked to market on a monthly basis. As a result, changes in fair value are reported in Foreign exchange loss (gain) in the Consolidated Statements of Net Income. The fair value of the foreign currency forward contract was valued by a third party using market exchange rates and classified as a Level 2 input under the fair value hierarchy.

[0000889331-23-000016:notes:221]
As of December 31, 2022, the fair values of our derivative financial instrument and their classifications on the Consolidated Balance Sheets were as follows:

[0000889331-23-000016:notes:222]
| (in thousands) | Consolidated Balance Sheet Classification |  | Fiscal Year Ended December 31, 2022 |  |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 3,939 |  |  |  |
|  | Other long-term assets |  | $ | 4,740 |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |
| Foreign exchange forward contract | Prepaid expenses and other current assets |  | $ | 6,186 |  |  |  |

[0000889331-23-000016:notes:223]
The pre-tax gains recognized on derivative financial instruments in the Consolidated Statements of Operations for the fiscal year ended December 31, 2022 were as follows:

[0000889331-23-000016:notes:224]
| (in thousands) | Classification of Gain Recognized in the Consolidated Statements of Operations |  | Fiscal Year Ended December 31, 2022 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |
| Interest rate swap agreement | Interest expenses, net |  | $ | (100) |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |
| Foreign exchange forward contract | Foreign exchange loss (gain) |  | $ | (6,128) |  |  |  |

[0000889331-23-000016:notes:225]
The pre-tax gain recognized on derivative financial instruments in the Consolidated Statements of Comprehensive Income for the fiscal year ended December 31, 2022 was as follows:

[0000889331-23-000016:notes:226]
| (in thousands) |  |  |  | Fiscal Year Ended December 31, 2022 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |
| Interest rate swap agreement |  |  |  | $ | (8,679) |  |  |  |

[0000889331-23-000016:notes:227]
A pre-tax gain of $3.9 million from accumulated other comprehensive income (loss) to earnings is expected to be recognized during the next twelve months.

[0000889331-23-000016:notes:228]
Mutual Funds

[0000889331-23-000016:notes:229]
The Company has a non-qualified Supplemental Retirement and Savings Plan that provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains investment accounts for participants through which participants make investment elections. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value and recorded in Other long-term assets on the Consolidated Balance sheet.

[0000889331-23-000016:notes:230]
There were no changes during the fiscal year ended December 31, 2022 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of December 31, 2022 and January 1, 2022, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-23-000016:notes:231]
Defined Benefit Plan Assets / Non-qualified Supplemental Retirement and Savings Plan Investments

[0000889331-23-000016:notes:232]
See Note 11, Benefit Plans, for description of valuation methodologies and investment balances for defined benefit plan assets and investments related to the Company’s Non-Qualified Supplemental Retirement and Savings Plan.

[0000889331-23-000016:notes:233]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 31, 2022:

[0000889331-23-000016:notes:234]
|  | Fair Value Measurements Using |  |  |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash equivalents | $ | 304,101 |  |  | $ | — |  |  | $ | — |  |  | $ | 304,101 |  |
| Investments in equity securities | 10,653 |  |  | — |  |  | — |  |  | 10,653 |  |
| Mutual funds | 14,094 |  |  | — |  |  | — |  |  | 14,094 |  |
| Total: | $ | 328,848 |  |  | $ | — |  |  | $ | — |  |  | $ | 328,848 |  |

[0000889331-23-000016:notes:235]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of January 1, 2022:

[0000889331-23-000016:notes:236]
|  | Fair Value Measurements Using |  |  |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash equivalents | $ | 12,475 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,475 |  |
| Investments in equity securities | 26,070 |  |  | — |  |  | — |  |  | 26,070 |  |
| Mutual funds | 15,021 |  |  | — |  |  | — |  |  | 15,021 |  |
| Total: | $ | 53,566 |  |  | $ | — |  |  | $ | — |  |  | $ | 53,566 |  |

[0000889331-23-000016:notes:237]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, trade receivables and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and trade receivables approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at December 31, 2022 and January 1, 2022, as the rates on these borrowings are variable in nature.

[0000889331-23-000016:notes:238]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of December 31, 2022 and January 1, 2022 were as follows:

[0000889331-23-000016:notes:239]
|  | December 31, 2022 |  | January 1, 2022 |
| (in thousands) | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 | $ | 124,716 |  |  | $ | 122,270 |  |  | $ | 132,444 |  |  | $ | 134,119 |  |
| Euro Senior Notes, Series B due 2028 | 101,265 |  |  | 87,119 |  |  | 107,540 |  |  | 110,837 |  |
| USD Senior Notes, Series A due 2022 | — |  |  | — |  |  | 25,000 |  |  | 25,055 |  |
| USD Senior Notes, Series B due 2027 | 100,000 |  |  | 93,764 |  |  | 100,000 |  |  | 104,828 |  |
| USD Senior Notes, Series A due 2025 | 50,000 |  |  | 48,145 |  |  | 50,000 |  |  | 51,720 |  |
| USD Senior Notes, Series B due 2030 | 125,000 |  |  | 112,028 |  |  | 125,000 |  |  | 131,837 |  |
| USD Senior Notes, due 2032 | 100,000 |  |  | 90,131 |  |  | — |  |  | — |  |

[0000889331-23-000016:notes:240]
Impairments

[0000889331-23-000016:notes:241]
During the fourth quarter of 2022, the Company recorded a $2.9 million intangible asset impairment charge in Restructuring, impairment, and other charges in the Consolidated Statements of Net Income, for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment. See Note 5, Goodwill and Other Intangible Assets, for further discussion. Additionally, the Company recorded a non-cash impairment charge of $1.7 million for certain machinery and equipment within Electronics segment due to a decision to cease further production of a product line during the fourth quarter of 2022. The fair value of the patent, technology and machinery and equipment were measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-23-000016:notes:242]
Benefit Plans

[0000889331-23-000016:notes:243]
The Company has Company-sponsored and mandatory defined benefit pension plans covering employees in the United Kingdom ("U.K."), Germany, the Philippines, China, Japan, Mexico, Italy and France. The amount of the retirement benefits provided under the plans is generally based on years of service and final average pay.

[0000889331-23-000016:notes:244]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company is required to directly pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries. The Company completed the buy-out of this U.K. pension plan during the fourth quarter of 2021 and as a result recorded a non-cash pension settlement charge of $19.9 million (£14.9 million), inclusive of the accelerated recognition of prior service cost of $0.5 million (£0.4 million).

[0000889331-23-000016:notes:245]
Benefit plan related information is as follows for the years 2022 and 2021:

[0000889331-23-000016:notes:246]
| (in thousands) | 2022 |  | 2021 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 86,570 |  |  | $ | 148,992 |  |
| Service cost | 3,072 |  |  | 2,785 |  |
| Interest cost | 2,529 |  |  | 1,761 |  |
| Net actuarial gain | (19,327) |  |  | (11,016) |  |
| Benefits paid from the plan assets | (1,474) |  |  | (3,121) |  |
| Benefits paid directly by the Company | (1,853) |  |  | (2,692) |  |
| Settlements | (1,565) |  |  | (48,927) |  |
| Acquisitions | 3,812 |  |  | 1,797 |  |
| Effect of exchange rate movements | (5,839) |  |  | (3,218) |  |
| Plan amendment and other | (1,399) |  |  | 209 |  |
| Benefit obligation at end of year | $ | 64,526 |  |  | $ | 86,570 |  |
| Change in plan assets at fair value: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 48,325 |  |  | $ | 100,478 |  |
| Actual loss on plan assets | (9,217) |  |  | (2,824) |  |
| Employer contributions | 2,288 |  |  | 2,150 |  |
| Benefits paid from the plan assets | (1,474) |  |  | (3,121) |  |
| Settlements | — |  |  | (47,111) |  |
| Effect of exchange rate movements | (4,489) |  |  | (1,247) |  |
| Fair value of plan assets at end of year | 35,433 |  |  | 48,325 |  |
| Net amount unfunded status | $ | (29,093) |  |  | $ | (38,245) |  |

[0000889331-23-000016:notes:247]
Amounts recognized in the Consolidated Balance Sheets as of December 31, 2022 and January 1, 2022 consist of the following:

[0000889331-23-000016:notes:248]
| (in thousands) | 2022 |  | 2021 |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |
| Noncurrent assets | $ | 262 |  |  | $ | 40 |  |
| Current benefit liability | (1,318) |  |  | (1,248) |  |
| Noncurrent benefit liability | (28,037) |  |  | (37,037) |  |
| Net liability recognized | $ | (29,093) |  |  | $ | (38,245) |  |

[0000889331-23-000016:notes:249]
The amounts included in accumulated other comprehensive loss in the Consolidated Balance Sheets, excluding tax effects, that have not yet been recognized as components of net periodic benefit costs as of December 31, 2022 and January 1, 2022 were as follows:

[0000889331-23-000016:notes:250]
| (in thousands) | 2022 |  | 2021 |
| Net actuarial (gain) loss | $ | (631) |  |  | $ | 9,221 |  |
| Prior service cost | 1,496 |  |  | 3,340 |  |
| Total | $ | 865 |  |  | $ | 12,561 |  |

[0000889331-23-000016:notes:251]
The pre-tax amounts recognized in other comprehensive income (loss) in 2022 and 2021 were as follows:

[0000889331-23-000016:notes:252]
|  | 2022 |  | 2021 |
| (in thousands) |  |  |  |
| Amortization of: |  |  |  |
| Prior service cost | $ | 150 |  |  | $ | 179 |  |
| Net actuarial loss | 228 |  |  | 1,136 |  |
| Amount arising during the period: |  |  |  |
| Prior service cost (credit) | 1,399 |  |  | (209) |  |
| Net actuarial gain | 9,899 |  |  | 6,734 |  |
| Net settlement (gain) loss | (820) |  |  | 19,855 |  |
| Foreign currency adjustments | 840 |  |  | 966 |  |
| Total | $ | 11,696 |  |  | $ | 28,661 |  |

[0000889331-23-000016:notes:253]
In the fourth quarter of 2021, the Company recorded a non-cash pension settlement charge of $19.9 million (£14.9 million), inclusive of the accelerated recognition of prior service cost of $0.5 million (£0.4 million). In addition, the net actuarial gain and change in benefit obligation during 2022 as compared to 2021 were also impacted by higher discount rates in 2022 as compared to 2021.

[0000889331-23-000016:notes:254]
The components of net periodic benefit costs for the fiscal years 2022, 2021, and 2020 are as follows:

[0000889331-23-000016:notes:255]
| (in thousands) | 2022 |  | 2021 |  | 2020 |
| Components of net periodic benefit cost: |  |  |  |  |  |
| Service cost | $ | 3,072 |  |  | $ | 2,785 |  |  | $ | 2,462 |  |
| Interest cost | 2,529 |  |  | 1,761 |  |  | 2,173 |  |
| Expected return on plan assets | (1,507) |  |  | (1,458) |  |  | (1,972) |  |
| Amortization of prior service and net actuarial loss | 378 |  |  | 1,315 |  |  | 963 |  |
| Net periodic benefit cost | 4,472 |  |  | 4,403 |  |  | 3,626 |  |
| Net settlement (gain) loss | (820) |  |  | 19,855 |  |  | 236 |  |
| Total expense for the year | $ | 3,652 |  |  | $ | 24,258 |  |  | $ | 3,862 |  |

[0000889331-23-000016:notes:256]
Weighted average assumptions used to determine net periodic benefit cost for the fiscal years 2022, 2021, and 2020 are as follows:

[0000889331-23-000016:notes:257]
|  | 2022 |  | 2021 |  | 2020 |
| Discount rate | 3.1 | % |  | 1.2 | % |  | 2.3 | % |
| Expected return on plan assets | 3.3 | % |  | 1.4 | % |  | 3.7 | % |
| Compensation increase rate | 4.8 | % |  | 4.9 | % |  | 4.7 | % |

[0000889331-23-000016:notes:258]
The accumulated benefit obligation for the plans was $53.9 million and $75.7 million as of December 31, 2022 and January 1, 2022, respectively.

[0000889331-23-000016:notes:259]
The following table provides a summary of under-funded or unfunded pension benefit plans with projected benefit obligations in excess of plan assets as of December 31, 2022 and January 1, 2022:

[0000889331-23-000016:notes:260]
| (in thousands) | 2022 |  | 2021 |
| Projected benefit obligation | $ | 42,676 |  |  | $ | 86,228 |  |
| Fair value of plan assets | 13,650 |  |  | 47,942 |  |

[0000889331-23-000016:notes:261]
The following table provides a summary of under-funded or unfunded pension benefit plans with accumulated benefit obligations in excess of plan assets as of December 31, 2022 and January 1, 2022:

[0000889331-23-000016:notes:262]
| (in thousands) | 2022 |  | 2021 |
| Accumulated benefit obligation | $ | 26,540 |  |  | $ | 68,643 |  |
| Fair value of plan assets | 4,948 |  |  | 39,060 |  |

[0000889331-23-000016:notes:263]
Weighted average assumptions used to determine benefit obligations as of December 31, 2022, January 1, 2022 and December 26, 2020 are as follows:

[0000889331-23-000016:notes:264]
|  | 2022 |  | 2021 |  | 2020 |
| Discount rate | 5.8 | % |  | 3.1 | % |  | 1.2 | % |
| Compensation increase rate | 4.7 | % |  | 4.8 | % |  | 4.9 | % |

[0000889331-23-000016:notes:265]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows:

[0000889331-23-000016:notes:266]
| (in thousands) | Expected Benefit Payments |
| 2023 | $ | 4,155 |  |
| 2024 | 3,334 |  |
| 2025 | 3,869 |  |
| 2026 | 4,053 |  |
| 2027 | 4,286 |  |
| 2028-2032 and thereafter | 30,645 |  |

[0000889331-23-000016:notes:267]
The Company expects to make approximately $2.0 million of contributions to the plans and pay $1.9 million of benefits directly in 2023.

[0000889331-23-000016:notes:268]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. For the fiscal years ended December 31, 2022, January 1, 2022, and December 26, 2020, the Company recorded $1.9 million, $2.1 million, $2.0 million expense, respectively, in Cost of Sales and Other expense (income), net within the Consolidated Statements of Net Income.  As of December 31, 2022 and January 1, 2022, the Company reported benefit liabilities of $4.0 million and $4.1 million for these plans, of which $1.5 million and $1.5 million was recorded in Accrued liabilities and $2.5 million and $2.6 million was recorded in Other long-term liabilities on the Consolidated Balance Sheets, respectively. For the fiscal years ended December 31, 2022 and January 1, 2022, the pre-tax amounts recognized in other comprehensive income (loss) for these plans were $0.5 million and $0.3 million, respectively. For the fiscal year ended December 31, 2022, the expense reclassified from accumulated other comprehensive income (loss) to earnings was $1.7 million, including $1.3 million net settlement loss. For the fiscal year ended January 1, 2022, the expense reclassified from accumulated other comprehensive income (loss) to earnings was $0.7 million.

[0000889331-23-000016:notes:269]
Defined Benefit Plan Assets

[0000889331-23-000016:notes:270]
Based upon analysis of the target asset allocation and historical returns by type of investment, the Company has assumed that the expected long-term rate of return will be 5.2% on plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0000889331-23-000016:notes:271]
|  | Asset Allocation |
|  | 2022 |  | 2021 |
| Cash and cash equivalents, and other | 13 | % |  | 15 | % |
| Equity securities | 14 | % |  | 19 | % |
| Fixed income securities | 73 | % |  | 66 | % |
|  | 100 | % |  | 100 | % |

[0000889331-23-000016:notes:272]
The Company segregated its plan assets by the following major categories and level for determining their fair value as of December 31, 2022 and January 1, 2022. All plan assets that are valued using the net asset value per share (“NAV”) practical expedient have not been included within the fair value hierarchy but are separately disclosed.

[0000889331-23-000016:notes:273]
Cash and cash equivalents – Carrying value approximates fair value. As such, these assets were classified as Level 1. The Company also invests in certain short-term investments which are valued using the amortized cost method. Lastly, the Company has certain pooled pension funds that have short-term investments with third party mutual funds that are valued at unit value per share at measurement date. As such, these assets were classified as Level 2.

[0000889331-23-000016:notes:274]
Equity – The values of individual equity securities were based on quoted prices in active markets. As such, these assets are classified as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in certain equity securities that are not quoted on active markets; therefore, they were classified as Level 2.

[0000889331-23-000016:notes:275]
Fixed income – Fixed income securities are typically priced based on a last trade basis and are exchange-traded. Accordingly, the Company classified fixed income securities as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in fixed income securities and funds priced based on a valuation model rather than a last trade basis and are not exchange-traded.  As such, they were classified as Level 2. The Company also invests in certain fixed income funds which are valued at NAV.

[0000889331-23-000016:notes:276]
Insurance Contracts and other – This category includes pooled pension funds which have mutual funds with underlying investments in other assets and liabilities including alternatives priced based on a valuation model and are not exchange-traded. These were classified as Level 2. This category includes also insurance contracts that are valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market. Accordingly, insurance contracts were categorized as Level 3. Lastly, this category includes other assets and liabilities including futures or swaps.

[0000889331-23-000016:notes:277]
For any Level 2 and Level 3 plan assets, management reviews significant investments on a periodic basis including investigation of unusual fluctuations in price or returns and obtaining an understanding of the pricing methodology to assess the reliability of third-party pricing estimates.

[0000889331-23-000016:notes:278]
The valuation methodologies described above may generate a fair value calculation that may not be indicative of net realizable value or future fair values. While the Company believes the valuation methodologies used are appropriate, the use of different methodologies or assumptions in calculating fair value could result in different amounts. The Company invests in assets in which valuation is determined by NAV. The Company believes that the NAV is representative of fair value at the reporting date, as there are no significant restrictions on redemption of these investments or other reasons to indicate that the investment would be redeemed at an amount different than the NAV.

[0000889331-23-000016:notes:279]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 31, 2022:

[0000889331-23-000016:notes:280]
|  | Fair Value Measurements Using |  |  |  |  |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Insurance contracts and other | $ | — |  |  | $ | 1,153 |  |  | $ | 328 |  |  | $ | — |  |  | $ | 1,481 |  |
| Cash and cash equivalents | 594 |  |  | 2,475 |  |  | — |  |  | — |  |  | 3,069 |  |
| Equities | 2,425 |  |  | 2,435 |  |  | — |  |  | — |  |  | 4,860 |  |
| Fixed income | 5,930 |  |  | 14,940 |  |  | — |  |  | 5,153 |  |  | 26,023 |  |
| Total pension plan assets | $ | 8,949 |  |  | $ | 21,003 |  |  | $ | 328 |  |  | $ | 5,153 |  |  | $ | 35,433 |  |

[0000889331-23-000016:notes:281]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of January 1, 2022:

[0000889331-23-000016:notes:282]
|  | Fair Value Measurements Using |  |  |  |  |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Insurance contracts and other | $ | — |  |  | $ | 1,917 |  |  | $ | 343 |  |  | $ | — |  |  | $ | 2,260 |  |
| Cash and cash equivalents | 384 |  |  | 4,632 |  |  | — |  |  | — |  |  | 5,016 |  |
| Equities | 2,559 |  |  | 6,604 |  |  | — |  |  | — |  |  | 9,163 |  |
| Fixed income | 5,999 |  |  | 20,280 |  |  | — |  |  | 5,607 |  |  | 31,886 |  |
| Total pension plan assets | $ | 8,942 |  |  | $ | 33,433 |  |  | $ | 343 |  |  | $ | 5,607 |  |  | $ | 48,325 |  |

[0000889331-23-000016:notes:283]
The fair value measurement of plan assets using significant unobservable inputs (Level 3) changed during 2022 and 2021 due to the following:

[0000889331-23-000016:notes:284]
| (in thousands) | Level 3 |
| Balance at December 26, 2020 | $ | 53,778 |  |
| Level 3 assets transferred in from Level 1 and 2 assets valued at NAV: |  |
| Settlements | (47,111) |  |
| Actual loss on plan assets | (4,943) |  |
| Benefits paid from the plan assets | (1,238) |  |
| Foreign currency adjustments | (143) |  |
| Balance at January 1, 2022 | $ | 343 |  |
| Level 3 assets transferred in from Level 1 and 2 assets valued at NAV: |  |
| Employer contribution | 2 |  |
| Actual return on assets | 3 |  |
| Foreign currency adjustments | (20) |  |
| Balance at December 31, 2022 | $ | 328 |  |

[0000889331-23-000016:notes:285]
Defined Contribution Plan

[0000889331-23-000016:notes:286]
The Company also maintains a 401(k) savings plan covering substantially all U.S. employees. The Company matches 100% of the employee’s annual contributions for the first 4% of the employee’s eligible compensation. The Company may provide an additional discretionary match to participants and made discretionary matches of 2% of the employee’s eligible compensation for each of the fiscal year ended December 31, 2022, January 1, 2022 and December 26, 2020. Employees are immediately

[0000889331-23-000016:notes:287]
vested in their contributions plus actual earnings thereon, as well as the Company contributions. Company matching contributions amounted to $5.5 million, $5.0 million, and $4.6 million in 2022, 2021, and 2020, respectively.

[0000889331-23-000016:notes:288]
Non-qualified Supplemental Retirement and Savings Plan

[0000889331-23-000016:notes:289]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The investments are subject to the claims of the Company’s creditors and the Company is responsible for the payment of all benefits under the plan from its general assets. As of December 31, 2022, there was $14.1 million of marketable securities related to the plan included in Other assets and $14.1 million of accrued compensation benefits included in Other long-term liabilities. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value. The Company made matching contributions to the plan of $0.2 million, $0.2 million, and $0.5 million in 2022, 2021, and 2020, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000889331-23-000016:notes:290]
Equity Plans: The Company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, and other stock rights to employees and directors. As of December 31, 2022, there were 0.6 million shares available for issuance of future awards under the Company’s equity-based compensation plans.

[0000889331-23-000016:notes:291]
Stock options generally vest over a three-year period and are exercisable over either a seven or ten-year period commencing from the date of the grant. Restricted shares and share units granted by the Company generally vest over three years. Stock options and restricted share units may have accelerated vesting upon meeting certain qualified conditions.

[0000889331-23-000016:notes:292]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended December 31, 2022.

[0000889331-23-000016:notes:293]
|  | Shares UnderOption |  | WeightedAveragePrice |  | WeightedAverageRemainingContract Life(Years) |  | AggregateIntrinsicValue(000’s) |
| Outstanding January 1, 2022 | 563,226 |  |  | $ | 165.98 |  |  |  |  |  |
| Granted | 86,220 |  |  | 231.64 |  |  |  |  |  |
| Exercised | (29,353) |  |  | 132.31 |  |  |  |  |  |
| Forfeited | (2,237) |  |  | 153.14 |  |  |  |  |  |
| Outstanding December 31, 2022 | 617,856 |  |  | 176.79 |  |  | 4.2 |  | $ | 30,555 |  |
| Exercisable December 31, 2022 | 292,824 |  |  | 159.93 |  |  | 3.2 |  | 18,566 |  |

[0000889331-23-000016:notes:294]
The following table provides a reconciliation of non-vested restricted share and share unit awards ("RSU") for the fiscal year ended December 31, 2022.

[0000889331-23-000016:notes:295]
|  | Shares |  | Weighted Average Grant-Date Fair Value |
| Nonvested January 1, 2022 | 156,659 |  |  | $ | 192.44 |  |
| Granted | 90,970 |  |  | 228.78 |  |
| Vested | (71,822) |  |  | 185.06 |  |
| Forfeited | (7,521) |  |  | 227.96 |  |
| Nonvested December 31, 2022 | 168,286 |  |  | 213.65 |  |

[0000889331-23-000016:notes:296]
The total intrinsic value of options exercised during 2022, 2021, and 2020 was $3.7 million, $23.8 million, and $20.6 million, respectively. The total fair value of the vested RSU shares was $15.4 million, $18.9 million, and $9.5 million for 2022, 2021,

[0000889331-23-000016:notes:297]
and 2020, respectively. The total amount of share-based liabilities paid was $1.1 million, $1.3 million and $0.5 million for 2022, 2021, and 2020, respectively.

[0000889331-23-000016:notes:298]
The Company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At December 31, 2022, the unrecognized compensation cost for options and restricted shares was $21.1 million before tax, and will be recognized over a weighted average period of 1.8 years. Compensation cost included as a component of cost of sales, research and development and selling, general, and administrative expenses for all equity compensation plans discussed above was $24.6 million, $21.4 million, and $19.1 million for 2022, 2021, and 2020, respectively. The total related income tax benefit recognized in the Consolidated Statements of Net Income was $3.5 million, $3.3 million and $3.1 million for 2022, 2021, and 2020, respectively.

[0000889331-23-000016:notes:299]
The Company uses the Black-Scholes option valuation model to determine the fair value of stock option awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0000889331-23-000016:notes:300]
|  | 2022 |  | 2021 |  | 2020 |
| Weighted average fair value of options granted | $70.39 |  | $74.04 |  | $38.09 |
| Assumptions: |  |  |  |  |  |
| Risk-free interest rate | 2.83% |  | 0.66% |  | 0.30% |
| Expected dividend yield | 0.92% |  | 0.72% |  | 1.27% |
| Expected stock price volatility | 35.0% |  | 35.0% |  | 33.0% |
| Expected life of options (years) | 4.4 |  | 4.4 |  | 4.7 |

[0000889331-23-000016:notes:301]
Expected volatilities are based on the historical volatility of the Company’s stock price. The expected life of options is based on historical data for options granted by the Company. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption. Historical nonvested forfeiture information is the basis for the forfeiture rate assumptions.

[0000889331-23-000016:notes:302]
The fair value of RSU is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-23-000016:notes:303]
Preferred Stock: The Board of Directors may authorize the issuance of preferred stock from time to time in one or more series with such designations, preferences, qualifications, limitations, restrictions, and optional or other special rights as the Board may fix by resolution.

[0000889331-23-000016:notes:304]
Share Repurchase Program

[0000889331-23-000016:notes:305]
On April 29, 2020, the Company announced that the Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") . On April 28, 2021, the Company announced that the Board of Directors authorized a new three-year program to repurchase up to $300 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program. There are $300 million in the aggregate of shares available for purchase under the new program as of December 31, 2022.

[0000889331-23-000016:notes:306]
During the fiscal years 2022 and 2021, the Company did not repurchase any shares of its common stock. During the fiscal year 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-23-000016:notes:307]
Other Comprehensive Income (Loss)
Changes in other comprehensive income (loss) by component for fiscal years 2022, 2021, and 2020 were as follows:

[0000889331-23-000016:notes:308]
|  | Fiscal Year Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 26, 2020 |
| (in thousands) | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |
| Defined benefit pension plan and other adjustments | $ | 11,560 |  |  | $ | (1,825) |  |  | $ | 9,735 |  |  | $ | 27,481 |  |  | $ | (5,268) |  |  | $ | 22,213 |  |  | $ | (19,513) |  |  | $ | 3,418 |  |  | $ | (16,095) |  |
| Cash flow hedge | 8,679 |  |  | (2,083) |  |  | 6,596 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustments (1) | (39,619) |  |  | 987 |  |  | (38,632) |  |  | (6,967) |  |  | 2,448 |  |  | (4,519) |  |  | 34,707 |  |  | (2,946) |  |  | 31,761 |  |
| Total change in other comprehensive income (loss) | $ | (19,380) |  |  | $ | (2,921) |  |  | $ | (22,301) |  |  | $ | 20,514 |  |  | $ | (2,820) |  |  | $ | 17,694 |  |  | $ | 15,194 |  |  | $ | 472 |  |  | $ | 15,666 |  |

[0000889331-23-000016:notes:309]
(1) The tax shown above within the foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries which have been previously taxed in the U.S. and are not permanently reinvested.

[0000889331-23-000016:notes:310]
Accumulated Other Comprehensive Income (Loss) (“AOCI”): The following table sets forth the changes in the components of AOCI by component for fiscal years 2022, 2021, and 2020:

[0000889331-23-000016:notes:311]
| (in thousands) | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedge |  | Foreign currency translation adjustments |  | Accumulated other comprehensive income (loss) |
| Balance at December 28, 2019 | $ | (18,046) |  |  | $ | — |  |  | $ | (88,777) |  |  | $ | (106,823) |  |
| 2020 activity | (16,095) |  |  | — |  |  | 31,761 |  |  | 15,666 |  |
| Balance at December 26, 2020 | (34,141) |  |  | — |  |  | (57,016) |  |  | (91,157) |  |
| 2021 activity | 22,213 |  |  | — |  |  | (4,519) |  |  | 17,694 |  |
| Balance at January 1, 2022 | (11,928) |  |  | — |  |  | (61,535) |  |  | (73,463) |  |
| 2022 activity | 9,735 |  |  | 6,596 |  |  | (38,632) |  |  | (22,301) |  |
| Balance at December 31, 2022 | (2,193) |  |  | 6,596 |  |  | (100,167) |  |  | (95,764) |  |

[0000889331-23-000016:notes:312]
Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million to unamortized actuarial loss within other comprehensive income (loss). In the fourth quarter of 2021, the Company recorded a non-cash pension settlement charge of $19.9 million (£14.9 million), inclusive of the accelerated recognition of prior service cost of $0.5 million (£0.4 million). See Note 11, Benefits Plans for further discussion.

[0000889331-23-000016:notes:313]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for fiscal years 2022, 2021, and 2020 were as follows:

[0000889331-23-000016:notes:314]
|  |  | Fiscal Year Ended |
| (in thousands) |  | December 31, 2022 |  | January 1, 2022 |  | December 26, 2020 |
| Pension and postemployment and other plans: |  |  |  |  |  |  |
| Amortization of prior service, net actuarial loss, and other |  | $ | 785 |  |  | $ | 2,006 |  |  | $ | 1,694 |  |
| Net settlement loss and accelerated prior service costs |  | 477 |  |  | 19,855 |  |  | 236 |  |
| Total |  | $ | 1,262 |  |  | $ | 21,861 |  |  | $ | 1,930 |  |

[0000889331-23-000016:notes:315]
The Company recognizes the amortization of prior service costs and net settlement loss in other expense (income), net within the Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-23-000016:notes:316]
In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 31, 2022, January 1, 2022, and December 26, 2020, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-23-000016:notes:317]
Domestic and foreign income (loss) before income taxes is as follows:

[0000889331-23-000016:notes:318]
| (in thousands) | 2022 |  | 2021 |  | 2020 |
| Domestic | $ | 32,462 |  |  | $ | 13,746 |  |  | $ | (16,732) |  |
| Foreign | 410,582 |  |  | 327,279 |  |  | 177,985 |  |
| Income before income taxes | $ | 443,044 |  |  | $ | 341,025 |  |  | $ | 161,253 |  |

[0000889331-23-000016:notes:319]
Federal, state and foreign income tax expense (benefit) consists of the following:

[0000889331-23-000016:notes:320]
| (in thousands) | 2022 |  | 2021 |  | 2020 |
| Current: |  |  |  |  |  |
| Federal | $ | 12,423 |  |  | $ | 4,832 |  |  | $ | 437 |  |
| State | 2,183 |  |  | 1,401 |  |  | 203 |  |
| Foreign | 77,551 |  |  | 59,006 |  |  | 33,841 |  |
| Subtotal | 92,157 |  |  | 65,239 |  |  | 34,481 |  |
| Deferred: |  |  |  |  |  |
| Federal and State | (9,182) |  |  | (9,658) |  |  | (5,354) |  |
| Foreign | (13,237) |  |  | 1,638 |  |  | 2,140 |  |
| Subtotal | (22,419) |  |  | (8,020) |  |  | (3,214) |  |
| Provision for income taxes | $ | 69,738 |  |  | $ | 57,219 |  |  | $ | 31,267 |  |

[0000889331-23-000016:notes:321]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0000889331-23-000016:notes:322]
| (in thousands) | 2022 |  | 2021 |  | 2020 |
| Tax expense at statutory rate of 21% | $ | 93,039 |  |  | $ | 71,615 |  |  | $ | 33,863 |  |
| Non-U.S. income tax rate differential | (41,731) |  |  | (31,414) |  |  | (19,730) |  |
| One-time tax deductions for stock of subsidiaries | (11,495) |  |  | — |  |  | — |  |
| Tax on unremitted earnings | 10,870 |  |  | 7,585 |  |  | 3,955 |  |
| Non-U.S. losses and expenses with no tax benefit | 10,660 |  |  | 7,820 |  |  | 2,774 |  |
| Net impact associated with U.S. tax on Non-U.S. income, including GILTI | 2,546 |  |  | (238) |  |  | 3,731 |  |
| Certain changes in unrecognized tax benefits and related accrued interest | 1,839 |  |  | 4,263 |  |  | 2,160 |  |
| State and local taxes, net of federal tax benefit | 215 |  |  | (172) |  |  | (584) |  |
| Tax impact of non-deductible goodwill impairment charge | — |  |  | — |  |  | 5,642 |  |
| Other, net | 3,795 |  |  | (2,240) |  |  | (544) |  |
| Provision for income taxes | $ | 69,738 |  |  | $ | 57,219 |  |  | $ | 31,267 |  |

[0000889331-23-000016:notes:323]
For fiscal year ended December 31, 2022, the Company classified certain amounts in “Net impact associated with U.S. tax on Non-U.S. income, including GILTI,” that in prior years were classified in “Other, net”.

[0000889331-23-000016:notes:324]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the Company’s assets and liabilities. Significant components of the Company’s deferred tax assets and liabilities at December 31, 2022 and January 1, 2022, are as follows:

[0000889331-23-000016:notes:325]
| (in thousands) | 2022 |  | 2021 |
| Deferred tax assets: |  |  |  |
| Accrued expenses and reserves | $ | 49,138 |  |  | $ | 36,168 |  |
| Net operating loss carryforwards | 30,403 |  |  | 27,818 |  |
| Interest expense carryforwards | 33,507 |  |  | 16,089 |  |
| Capitalized expenses | 11,632 |  |  | 4,878 |  |
| U.S. foreign tax credit carryforwards | 3,385 |  |  | 980 |  |
| U.S. research and other general business tax credit carryforwards | 2,076 |  |  | 1,104 |  |
| Excess of tax basis over the book basis for intangible assets and goodwill | 404 |  |  | 5,636 |  |
| Other | — |  |  | 183 |  |
| Deferred tax assets | 130,545 |  |  | 92,856 |  |
| Less: Valuation allowance | (37,001) |  |  | (34,869) |  |
| Total deferred tax assets | 93,544 |  |  | 57,987 |  |
| Deferred tax liabilities: |  |  |  |
| Excess of book basis over the tax basis for intangible assets and goodwill | 143,542 |  |  | 98,046 |  |
| Excess of book basis over the tax basis for property, plant, and equipment | 18,489 |  |  | 12,563 |  |
| Tax on unremitted earnings | 16,282 |  |  | 15,467 |  |
| Unrealized foreign currency exchange gains | 1,094 |  |  | 73 |  |
| Total deferred tax liabilities | 179,407 |  |  | 126,149 |  |
| Net deferred tax liabilities | $ | 85,863 |  |  | $ | 68,162 |  |

[0000889331-23-000016:notes:326]
The deferred tax asset valuation allowance is mainly related to certain U.S. and non-U.S. net operating loss and non-U.S. interest expense carryforwards which are not expected to be realized. The remaining U.S. and non-U.S. net operating loss and interest expense carryforwards either have no expiration date or are expected to be utilized prior to expiration. No deferred tax asset nor valuation allowance has been recorded for certain U.S. and non-U.S. net operating loss carryforwards for which the possibility of usage has been determined to be remote.

[0000889331-23-000016:notes:327]
The Company paid income taxes of $96.8 million, $58.2 million, and $35.2 million in 2022, 2021, and 2020, respectively, and received income tax refunds of $3.2 million, $2.6 million, and $7.6 million in 2022, 2021, and 2020, respectively.

[0000889331-23-000016:notes:328]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those subsidiaries for which such excess is considered to be permanently reinvested in those operations. The Company believes the determination of the amount of such deferred income taxes is impractical as it would depend upon income tax laws and circumstances at the time of the hypothetical distributions or dispositions. As of December 31, 2022, unremitted earnings of the Company’s non-U.S. subsidiaries were approximately $1.2 billion. A distribution of such earnings will generally not be subject to U.S. federal income tax. The Company recognized deferred tax liabilities of $16.3 million ($16.1 million for non-U.S. taxes net of related U.S. foreign tax credits, and $0.2 million for U.S. state taxes) as of December 31, 2022 and $15.5 million ($15.3 million for non-U.S. taxes net of related U.S. foreign tax credits, and $0.2 million for U.S. state taxes) as of January 1, 2022, related to taxes on certain non-U.S. earnings which are not considered to be permanently reinvested.

[0000889331-23-000016:notes:329]
The Company has two subsidiaries in China which benefit from lower tax rates due to “tax holidays” which apply for three-year periods. The tax holiday for one of the subsidiaries expired at the end of 2022, and for the other subsidiary the tax holiday will expire at the end of 2023. The Company intends to seek an extension for the expired tax holiday. Together, the tax holidays contributed $10.1 million in tax benefits, or $0.40 per diluted share, during 2022. Future year tax benefits will depend upon the Company’s ability to obtain extensions, after the three-year periods expire. There can be no assurance that future extensions will be granted.

[0000889331-23-000016:notes:330]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of December 31, 2022, January 1, 2022, and December 26, 2020 is as follows:

[0000889331-23-000016:notes:331]
| (in thousands) | Unrecognized Tax Benefits |
| Balance at December 26, 2020 | $ | 17,437 |  |
| Additions for tax positions related to pre-acquisition periods of acquired subsidiaries | 3,260 |  |
| Additions for tax positions taken in the current year | 1,587 |  |
| Additions for tax positions taken in the prior year | 1,100 |  |
| Other | 61 |  |
| Balance at January 1, 2022 | 23,445 |  |
| Additions for tax positions related to pre-acquisition periods of acquired subsidiaries | 6,726 |  |
| Additions for tax positions taken in the current year | 2,153 |  |
| Decreases for tax positions taken in the prior year | (957) |  |
| Decreases for lapses in statute of limitations | (758) |  |
| Other | (235) |  |
| Balance at December 31, 2022 | $ | 30,374 |  |

[0000889331-23-000016:notes:332]
The December 31, 2022 total in the table above represents the net amount of tax benefits that, if recognized, would favorably affect the effective tax rate in future periods. Of this amount, approximately $1.3 million may be recognized in 2023 based upon the possible lapse in the statute of limitations. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility.

[0000889331-23-000016:notes:333]
The Company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense. The Company recognized such interest expense of $1.4 million (net of a $0.2 million decrease due to a lapse in the statute of limitations), $1.6 million (net of a $0.6 million decrease due to a lapse in the statute of limitations) and $1.6 million (net of a $0.6 million decrease due to a lapse in the statute of limitations) in 2022, 2021, and 2020, respectively. Accrued interest for such matters included in Other long-term liabilities within the Consolidated Balance Sheets was $11.8 million and $10.4 million as of December 31, 2022 and January 1, 2022, respectively.

[0000889331-23-000016:notes:334]
The U.S. federal statute of limitations remains open for the Company for the 2017 tax year (with respect to the Toll Charge) and later years. Non-U.S. and U.S. state statutes of limitations generally range from three to seven years, although certain jurisdictions do not have a statute expiration. Tax examinations occur from time to time, including examinations currently in process in Canada, Germany, the Netherlands, Singapore, the U.S., and certain U.S. states. The Company does not expect to recognize a significant amount of additional tax expense as a result of concluding these examinations.


## us-gaap:EarningsPerShareTextBlock

[0000889331-23-000016:notes:335]
Earnings Per Share

[0000889331-23-000016:notes:336]
The following table sets forth the computation of basic and diluted earnings per share:

[0000889331-23-000016:notes:337]
| (in thousands, except per share amounts) | 2022 |  | 2021 |  | 2020 |
| Numerator: |  |  |  |  |  |
| Net income as reported | $ | 373,306 |  |  | $ | 283,806 |  |  | $ | 129,986 |  |
| Denominator: |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |
| Basic | 24,734 |  |  | 24,603 |  |  | 24,371 |  |
| Effect of dilutive securities | 252 |  |  | 329 |  |  | 221 |  |
| Diluted | 24,986 |  |  | 24,932 |  |  | 24,592 |  |
| Earnings Per Share: |  |  |  |  |  |
| Basic earnings per share | $ | 15.09 |  |  | $ | 11.54 |  |  | $ | 5.33 |  |
| Diluted earnings per share | $ | 14.94 |  |  | $ | 11.38 |  |  | $ | 5.29 |  |

[0000889331-23-000016:notes:338]
Potential shares of common stock attributable to stock options and restricted shares excluded from the earnings per share calculation because their effect would be anti-dilutive were 87,425, 20,139, and 222,526 shares in 2022, 2021, and 2020, respectively.
During the fiscal year 2022 and 2021, the Company did not repurchase any shares of its common stock. During the fiscal year 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million. See Note 12 Stock-Based Compensation for further discussion.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-23-000016:notes:339]
Segment Information

[0000889331-23-000016:notes:340]
The Company and its subsidiaries design, manufacture and sell component, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company reports its operations by the following segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-23-000016:notes:341]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it.  Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-23-000016:notes:342]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related charging infrastructure, aerospace, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-23-000016:notes:343]
•Transportation Segment: Formerly known as Automotive segment. The term “Transportation” represents a more comprehensive description of the Company’s broad range of products, and the applications and end markets it serves. Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicle, heavy-duty truck, off-road vehicle, material handling, agricultural, construction and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck, construction, agriculture, material handling and marine.

[0000889331-23-000016:notes:344]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), industrial controls (protection relays, contactors, and transformers) and temperature sensors for use in various applications such as renewable energy and energy storage systems, electric vehicle infrastructure, HVAC systems, industrial safety, non-residential construction, MRO, mining and industrial automation.

[0000889331-23-000016:notes:345]
The Company has provided this segment information for all comparable prior periods. Segment information is summarized as follows:

[0000889331-23-000016:notes:346]
| (in thousands) | 2022 |  | 2021 |  | 2020 |
| Net sales |  |  |  |  |  |
| Electronics | $ | 1,492,819 |  |  | $ | 1,300,744 |  |  | $ | 937,762 |  |
| Transportation | 716,140 |  |  | 528,058 |  |  | 395,764 |  |
| Industrial | 304,938 |  |  | 251,126 |  |  | 112,169 |  |
| Total net sales | $ | 2,513,897 |  |  | $ | 2,079,928 |  |  | $ | 1,445,695 |  |
| Depreciation and amortization |  |  |  |  |  |
| Electronics | $ | 68,195 |  |  | $ | 61,512 |  |  | $ | 62,702 |  |
| Transportation | 43,756 |  |  | 29,015 |  |  | 28,995 |  |
| Industrial | 8,755 |  |  | 8,108 |  |  | 4,481 |  |
| Total depreciation and amortization | $ | 120,706 |  |  | $ | 98,635 |  |  | $ | 96,178 |  |
| Operating income (loss) |  |  |  |  |  |
| Electronics | $ | 431,616 |  |  | $ | 309,633 |  |  | $ | 152,695 |  |
| Transportation | 63,539 |  |  | 65,979 |  |  | 41,655 |  |
| Industrial | 48,853 |  |  | 22,621 |  |  | 11,996 |  |
| Other(a) | (43,182) |  |  | (12,591) |  |  | (43,974) |  |
| Total operating income | 500,826 |  |  | 385,642 |  |  | 162,372 |  |
| Interest expense | 26,216 |  |  | 18,527 |  |  | 21,077 |  |
| Foreign exchange loss (gain) | 24,359 |  |  | 17,158 |  |  | (14,875) |  |
| Other expense (income), net | 7,207 |  |  | 8,932 |  |  | (5,083) |  |
| Income before income taxes | $ | 443,044 |  |  | $ | 341,025 |  |  | $ | 161,253 |  |

[0000889331-23-000016:notes:347]
(a) Included in “Other” Operating income (loss) for 2022 was $17.6 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $15.6 million of purchase accounting inventory step-up charges, and $10.0 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $2.9 million non-cash impairment charge for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment in the fourth quarter of 2022. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-23-000016:notes:348]
Included in “Other” Operating income (loss) for 2021 was $8.4 million of purchase accounting inventory step-up charges, $7.0 million of legal and professional fees and other integration expenses related to Carling, Hartland and other contemplated acquisitions, and $2.2 million of restructuring, impairment and other charges, primarily related to employee termination costs.  See Note 8, Restructuring, Impairment and Other Charges, for further discussion. In addition, there was a gain of $5.0 million recorded for the sale of buildings within the Electronics segment.

[0000889331-23-000016:notes:349]
Included in “Other” Operating income (loss) for 2020 is $2.3 million of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $41.7 million of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Transportation segment, employee termination costs of $5.5 million, $2.2 million of impairment charges recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment and other restructuring charges of $0.2 million.

[0000889331-23-000016:notes:350]
The Company’s net sales, long-lived assets and additions to long-lived assets by country for the fiscal years ended 2022, 2021, and 2020 are as follows:

[0000889331-23-000016:notes:351]
| (in thousands) | 2022 |  | 2021 |  | 2020 |
| Net sales |  |  |  |  |  |
| U.S. | $ | 912,498 |  |  | $ | 639,381 |  |  | $ | 392,544 |  |
| China | 638,978 |  |  | 620,211 |  |  | 438,000 |  |
| Other countries(a) | 962,421 |  |  | 820,336 |  |  | 615,151 |  |
| Total net sales | $ | 2,513,897 |  |  | $ | 2,079,928 |  |  | $ | 1,445,695 |  |
| Long-lived assets |  |  |  |  |  |
| U.S. | $ | 76,325 |  |  | $ | 57,923 |  |  | $ | 46,132 |  |
| China | 129,094 |  |  | 122,867 |  |  | 85,876 |  |
| Mexico | 107,119 |  |  | 107,283 |  |  | 70,125 |  |
| Germany | 39,635 |  |  | 39,055 |  |  | 37,976 |  |
| Philippines | 77,240 |  |  | 74,918 |  |  | 66,994 |  |
| Other countries | 51,697 |  |  | 35,843 |  |  | 37,075 |  |
| Total long-lived assets | $ | 481,110 |  |  | $ | 437,889 |  |  | $ | 344,178 |  |
| Additions to long-lived assets |  |  |  |  |  |
| U.S. | $ | 14,603 |  |  | $ | 7,690 |  |  | $ | 4,170 |  |
| China | 35,297 |  |  | 26,396 |  |  | 10,074 |  |
| Mexico | 26,514 |  |  | 28,707 |  |  | 9,977 |  |
| Germany | 5,255 |  |  | 8,519 |  |  | 5,600 |  |
| Philippines | 14,847 |  |  | 19,342 |  |  | 19,612 |  |
| Other countries | 7,678 |  |  | 5,654 |  |  | 1,775 |  |
| Total additions to long-lived assets | $ | 104,194 |  |  | $ | 96,308 |  |  | $ | 51,208 |  |

[0000889331-23-000016:notes:352]
(a)Each country included in other countries are less than 10% of net sales.

[0000889331-23-000016:notes:353]
For the year ended December 31, 2022, approximately 64% of the Company’s net sales were to customers outside the U.S. (exports and foreign operations), including approximately 25% to China. For the year ended January 1, 2022, approximately 69% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 30% to China. For the year ended December 26, 2020, approximately 73% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 30% to China. Sales to Arrow Electronics, Inc., which were included in the Electronics, Transportation, and Industrial segments, were 11.5%, 10.7%, and 10.4% of consolidated net sales in 2022, 2021, and 2020 respectively. No other single customer accounted for more than 10% of net sales during the last three years.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-23-000016:notes:354]
Related Party Transactions

[0000889331-23-000016:notes:355]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-23-000016:notes:356]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-23-000016:notes:357]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB-Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-23-000016:notes:358]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-23-000016:notes:359]
|  | Fiscal Year Ended |
|  | December 31, 2022 |  | January 1, 2022 |
| (in millions) | Powersem |  | EB Tech |  | ATEC |  | Powersem |  | EB Tech |  | ATEC |
| Sales to related party | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |
| Purchase of material/services from related party | 0.3 |  |  | 0.4 |  |  | 11.5 |  |  | 3.0 |  |  | 0.4 |  |  | 12.6 |  |
| Accounts receivable balance | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Accounts payable balance | $ | — |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.8 |  |


## us-gaap:SubsequentEventsTextBlock

[0000889331-23-000016:notes:360]
Subsequent EventsOn February 3, 2023, the Company acquired Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. Western Automation has annualized sales of approximately $25 million and will be reported within the company’s Industrial segment. The company does not expect the acquisition to have a material impact to its 2023 financial results.The Company financed the transaction with cash on hand.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000889331-23-000016:notes:361]
SCHEDULE II

[0000889331-23-000016:notes:362]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0000889331-23-000016:notes:363]
| Description | Balance atBeginningof Year |  | Charged toCosts andExpenses (a) |  | Deductions (b) |  | Other (c) |  | Balance atEndof Year |
| (in thousands) |  |  |  |  |  |  |  |  |  |
| Fiscal year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 1,910 |  |  | $ | 166 |  |  | $ | (222) |  |  | $ | (279) |  |  | $ | 1,575 |  |
| Reserves for sales discounts and allowances | $ | 57,322 |  |  | $ | 184,201 |  |  | $ | (158,499) |  |  | $ | (1,037) |  |  | $ | 81,987 |  |
| Fiscal year ended January 1, 2022 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 1,400 |  |  | $ | 82 |  |  | $ | (362) |  |  | $ | 790 |  |  | $ | 1,910 |  |
| Reserves for sales discounts and allowances | $ | 43,837 |  |  | $ | 152,153 |  |  | $ | (137,920) |  |  | $ | (748) |  |  | $ | 57,322 |  |
| Fiscal year ended December 26, 2020 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 1,310 |  |  | $ | 1,170 |  |  | $ | (329) |  |  | $ | (751) |  |  | $ | 1,400 |  |
| Reserves for sales discounts and allowances | $ | 40,733 |  |  | $ | 113,709 |  |  | $ | (112,401) |  |  | $ | 1,796 |  |  | $ | 43,837 |  |

[0000889331-23-000016:notes:364]
(a)Includes provision for credit losses, sales returns and sales discounts granted to customers.

[0000889331-23-000016:notes:365]
(b)Represents uncollectible accounts written off, net of recoveries and credits issued to customers.

[0000889331-23-000016:notes:366]
(c)Represents business acquisitions and foreign currency translation adjustments.
