# LFUS 10-K controls and the auditor's report


## auditors_report

[0000889331-23-000016:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000889331-23-000016:auditors_report:2]
Board of Directors and Shareholders

[0000889331-23-000016:auditors_report:3]
Littelfuse, Inc.

[0000889331-23-000016:auditors_report:4]
Opinion on the financial statements

[0000889331-23-000016:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Littelfuse, Inc. (a Delaware corporation) and subsidiaries (the “Company”) as of December 31, 2022 and January 1, 2022, the related consolidated statements of net income, comprehensive income, equity, and cash flows for each of the three years in the period ended December 31, 2022, and the related notes and financial statement schedule included under Item 15(a) (collectively referred to as the “financial statements”). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2022 and January 1, 2022, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2022, in conformity with accounting principles generally accepted in the United States of America.

[0000889331-23-000016:auditors_report:6]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the Company’s internal control over financial reporting as of December 31, 2022, based on criteria established in the 2013 Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”), and our report dated February 16, 2023, expressed an unqualified opinion.

[0000889331-23-000016:auditors_report:7]
Basis for opinion

[0000889331-23-000016:auditors_report:8]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000889331-23-000016:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0000889331-23-000016:auditors_report:10]
Critical audit matter

[0000889331-23-000016:auditors_report:11]
The critical audit matter communicated below is a matter arising from the current period audit of the financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000889331-23-000016:auditors_report:12]
Business Acquisition – C&K Switches  – Valuation of acquired intangible assets

[0000889331-23-000016:auditors_report:13]
As discussed in Note 2, the Company acquired C&K Switches (“C&K”), on July 19, 2022 for a total purchase price of approximately $523 million, net of cash acquired. The Company allocated the purchase price, on a preliminary basis, to the assets acquired and liabilities assumed based on their respective fair values, including identified intangible assets of $254.7 million. We identified the valuation of acquired C&K intangible assets as a critical accounting matter.

[0000889331-23-000016:auditors_report:14]
The principal considerations for our determination that the valuation of acquired C&K intangible assets is a critical audit matter are (i) the significant judgment by management when determining assumptions used in the fair value measurement of acquired intangible assets (ii) the high degree of auditor judgment and subjectivity in performing procedures and evaluating management’s significant assumptions relating to the projected forecasted information including revenue growth rate, weighted average cost of capital (WACC), royalty rate, and customer attrition rate and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0000889331-23-000016:auditors_report:15]
Our audit procedures related to the valuation of the acquired intangible assets included the following, among others:

[0000889331-23-000016:auditors_report:16]
a.we tested the design and operating effectiveness of the controls over the Company’s acquisition and valuation process, including review of the valuation model, significant assumptions used, and the completeness and accuracy of the underlying data used

[0000889331-23-000016:auditors_report:17]
b.we tested the projected financial information including forecasted revenue growth rate by assessing the reasonableness of management’s forecasts compared to historical results and forecasted industry trends

[0000889331-23-000016:auditors_report:18]
c.with the assistance of our valuation specialists, we assessed the assumptions and methodologies used in developing the WACC, royalty rates, and customer attrition rates by developing a range of independent estimates and comparing those to the rates selected by management. We also involved our valuation specialists to evaluate the assumptions and methodologies used in valuing the intangible assets.

[0000889331-23-000016:auditors_report:19]
/s/ GRANT THORNTON LLP

[0000889331-23-000016:auditors_report:20]
We have served as the Company’s auditor since 2014.

[0000889331-23-000016:auditors_report:21]
Southfield, Michigan

[0000889331-23-000016:auditors_report:22]
February 16, 2023

[0000889331-23-000016:auditors_report:23]
Report of Independent Registered Public Accounting Firm

[0000889331-23-000016:auditors_report:24]
Board of Directors and Shareholders

[0000889331-23-000016:auditors_report:25]
Littelfuse, Inc.

[0000889331-23-000016:auditors_report:26]
Opinion on internal control over financial reporting

[0000889331-23-000016:auditors_report:27]
We have audited the internal control over financial reporting of Littelfuse, Inc. (a Delaware corporation) and subsidiaries (the “Company”) as of December 31, 2022, based on criteria established in the 2013 Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2022, based on criteria established in the 2013 Internal Control—Integrated Framework issued by COSO.

[0000889331-23-000016:auditors_report:28]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the consolidated financial statements of the Company as of and for the year ended December 31, 2022, and our report dated February 16, 2023 expressed an unqualified opinion on those financial statements.

[0000889331-23-000016:auditors_report:29]
Basis for opinion

[0000889331-23-000016:auditors_report:30]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting (“Management’s Report”). Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000889331-23-000016:auditors_report:31]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000889331-23-000016:auditors_report:32]
Our audit of, and opinion on, the Company’s internal control over financial reporting does not include the internal control over financial reporting of C&K Switches, a wholly-owned subsidiary, whose financial statements reflect total assets and revenues constituting 3% and 3%, respectively, of the related consolidated financial statement amounts as of and for the year ended December 31, 2022. As indicated in Management’s Report, C&K Switches, was acquired during 2022. Management’s assertion on the effectiveness of the Company’s internal control over financial reporting excluded internal control over financial reporting of C&K Switches.

[0000889331-23-000016:auditors_report:33]
Definition and limitations of internal control over financial reporting

[0000889331-23-000016:auditors_report:34]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0000889331-23-000016:auditors_report:35]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000889331-23-000016:auditors_report:36]
/s/ GRANT THORNTON LLP

[0000889331-23-000016:auditors_report:37]
Southfield, Michigan

[0000889331-23-000016:auditors_report:38]
February 16, 2023

[0000889331-23-000016:auditors_report:39]
LITTELFUSE, INC.


## item_9a

[0000889331-23-000016:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES.

[0000889331-23-000016:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000889331-23-000016:item_9a:3]
The Company maintains disclosure controls and procedures that are designed to ensure that information required to be disclosed in its reports filed under the Securities Exchange Act of 1934, as amended, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and that such information is accumulated and communicated to management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure. In designing and evaluating the disclosure controls and procedures, the Company recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives, and the Company is required to apply its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0000889331-23-000016:item_9a:4]
As required by SEC Rule 15d-15(b), the Company carried out an evaluation, under the supervision and with the participation of its management, including the Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of its disclosure controls and procedures pursuant to SEC Rule 13a-15 as of the end of the period covered by this report. Based on the foregoing, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of December 31, 2022.

[0000889331-23-000016:item_9a:5]
84

[0000889331-23-000016:item_9a:6]
Management’s Report on Internal Control over Financial Reporting

[0000889331-23-000016:item_9a:7]
Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in this Annual Report on Form 10-K a report on management’s assessment of the effectiveness of the Company’s internal control over financial reporting, as well as an attestation report from the Company’s independent registered public accounting firm on the effectiveness of the Company’s internal control over financial reporting. Management is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Exchange Act Rule 13a-15(f) and 15d-15(f). The Company’s internal control system was designed to provide reasonable assurance to its management and the Board of Directors regarding the preparation and fair presentation of published financial statements.

[0000889331-23-000016:item_9a:8]
All internal control systems, no matter how well designed, have inherent limitations. Therefore, even those systems determined effective can provide only reasonable assurance with respect to financial statement preparation and presentation. A material weakness is a deficiency, or a combination of deficiencies, in the internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the annual or interim financial statement will not be prevented or detected on a timely basis.

[0000889331-23-000016:item_9a:9]
The Company’s management, including its Principal Executive Officer and Principal Financial Officer, assessed the effectiveness of the Company’s internal control over financial reporting as of December 31, 2022, based upon the updated framework in Internal Control — Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in 1992 and updated in May 2013. Based on this assessment, the Company’s management concluded that, as of December 31, 2022, the Company’s internal control over financial reporting was effective.

[0000889331-23-000016:item_9a:10]
On July 19, 2022, the Company completed the acquisition of C&K Switches, as discussed in Note 2 – Acquisitions. Management has excluded C&K’s internal controls over financial reporting from its assessment of the effectiveness of internal controls over financial reporting as of December 31, 2022. C&K’s net sales and total assets (excluding goodwill and intangible assets, which were integrated into the Company’s control environment) represent approximately 3% and 3%, respectively, of the consolidated financial statement amounts as of, and for the fiscal year ended, December 31, 2022.

[0000889331-23-000016:item_9a:11]
Changes in Internal Control over Financial Reporting

[0000889331-23-000016:item_9a:12]
There has been no change in the Company’s internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that occurred during the 12 months or fiscal year ended December 31, 2022, that has materially affected, or is reasonably likely to materially affect, the Company’s internal control over financial reporting.
