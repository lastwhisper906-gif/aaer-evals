# LFUS MD&A — 0000889331-23-000016


## mdna

[0000889331-23-000016:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0000889331-23-000016:mdna:2]
The following discussion of the Company's financial condition and results of operations should be read together with the Consolidated Financial Statements and notes to those statements included in Item 8 of Part II of this Annual Report on Form 10-K.

[0000889331-23-000016:mdna:3]
BUSINESS

[0000889331-23-000016:mdna:4]
For a description of the Company’s business, segments and product offerings, see Item 1, Business.

[0000889331-23-000016:mdna:5]
2022 EXECUTIVE OVERVIEW

[0000889331-23-000016:mdna:6]
Net sales were $2,513.9 million, which increased by $434.0 million or 20.9% in 2022 compared to 2021. The increase was primarily driven by higher volume and price realization in the Electronics and Industrial segments, $202.8 million or 9.8% of incremental net sales from the Carling acquisition within the Transportation segment and $81.7 million or 3.9% of net sales from the C&K acquisition within the Electronics segment, partially offset by $65.3 million or 3.1% of unfavorable changes in foreign exchange rates. The Company recognized net income of $373.3 million, or $14.94 per diluted share, in 2022 compared to net income of $283.8 million, or $11.38 per diluted share in 2021. The increase in net income is primarily due to an increase in operating income of $122.0 million and $26.2 million in the Electronics and Industrial segments, respectively, partially offset by higher interest expense of $7.7 million and foreign exchange losses of $7.2 million.

[0000889331-23-000016:mdna:7]
Supply chain constraints, including material shortages and transportation capacity and costs impacted the Company, its suppliers and customers during the first half of 2022 and to a lesser extent during the second half of 2022. The Company expects to see continued improvement in supply chain availability during 2023.

[0000889331-23-000016:mdna:8]
Net cash provided by operating activities was $419.7 million for the fiscal year ended December 31, 2022 representing an increase of $46.4 million as compared to the fiscal year ended January 1, 2022. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth and larger annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-23-000016:mdna:9]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (as so amended and restated, the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000016:mdna:10]
On February 3, 2023, the Company acquired Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. Western Automation has annualized sales of approximately $25 million and will be reported within the company’s Industrial segment. The company does not expect the acquisition to have a material impact to its 2023 financial results.The Company financed the transaction with cash on hand.

[0000889331-23-000016:mdna:11]
On July 19, 2022, the Company acquired C&K for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, datacom, and aerospace. At the time the Company and C&K entered into a definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the electronics-passive products and sensors business within the Company's Electronics segment. The Company financed the transaction through a combination of cash on hand and debt.

[0000889331-23-000016:mdna:12]
Impact of COVID-19 on Business

[0000889331-23-000016:mdna:13]
The effects from COVID-19 continue to drive higher ongoing costs including spending on personal protective equipment ("PPE"), additional personnel and employee transportation costs, and manufacturing inefficiencies as well as an increase in material costs and transportation costs due to global supply chain and logistics constraints around the world.

[0000889331-23-000016:mdna:14]
Although COVID-19 had less of an effect on fiscal year 2022 as compared to fiscal year 2021, it is difficult to estimate the ongoing magnitude of future COVID-19 disruptions, and its potential impact on the Company's employees, customers, suppliers and vendors. The Company will continue to actively monitor the situation and may take further actions altering its business operations that the Company determines are in the best interests of its employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on the Company's business and operations, including the effects on its customers, employees, and prospects, or on the Company's financial results for the fiscal year 2023.

[0000889331-23-000016:mdna:15]
Risks Related to Market Conditions

[0000889331-23-000016:mdna:16]
The Company continues to operate in a more volatile macro environment, including events related to the war in Ukraine. Although the Company does not have any direct operations in Ukraine or Russia, it had a modest impact on the Company, including higher transportation costs due to the Company modifying its shipping logistics as well as suspending sales into and purchases from Russia. Additionally, the war impacted some of the Company's customers who had lower production levels during 2022 due to shut-downs and ongoing material shortages.

[0000889331-23-000016:mdna:17]
OUTLOOK

[0000889331-23-000016:mdna:18]
Vision and Strategy

[0000889331-23-000016:mdna:19]
The Company closely collaborates with strategic customers to design and manufacture innovative and reliable solutions to help empower a sustainable, connected, and safer world in virtually every market that uses electrical energy.

[0000889331-23-000016:mdna:20]
Within transportation end markets, the Company’s products are found in passenger vehicles and commercial vehicles, like material handling equipment, heavy-duty truck and bus, off-road and recreational vehicles, construction equipment, agricultural machinery, rail, marine and aerospace. The Company is also a key enabler of electrification, or eMobility, across these transportation applications, and EV charging infrastructure. The Company continues to advance its existing customer relationships with OEM, Tier One and channel partners while driving product content growth for advanced, high-growth applications.

[0000889331-23-000016:mdna:21]
Within industrial end markets, the Company’s products are found in renewable energy and energy storage applications, HVAC, factory automation and industrial safety, industrial motor drives and power conversion, and heavy and general industrial type applications. The Company utilizes its deep technical engineering capabilities and design support to drive product content growth across high-growth applications like renewables, energy storage, HVAC, and industrial automation and safety.

[0000889331-23-000016:mdna:22]
Within electronics end markets, the Company’s products are found in data center, cloud storage and telecom infrastructure applications, building technologies and automation, appliances, medical devices, gaming and entertainment applications and mobile electronics. The Company leverages its strategic distribution partnerships and deep OEM relationships, coupled with its comprehensive product offerings, to drive product content growth across a broad range of applications.

[0000889331-23-000016:mdna:23]
The Company expects the ever-increasing complexity of application architectures, driven by ongoing electronification and electrification across these end markets, to drive increasing product content opportunities. Built upon that framework, the Company has positioned itself around the structural growth themes of sustainability, connectivity, and safety, which will continue to drive increased demand for the Company’s innovative, reliable solutions across the transportation, industrial and electronics end markets that it serves.

[0000889331-23-000016:mdna:24]
The Company’s five-year strategic plan, built around these structural growth themes, is focused on delivering top-tier shareholder returns by driving double-digit sales growth, best-in-class profitability, earnings per share growth, strong cash flow generation, and deploying capital to drive value creation. The Company pursues the following major strategic objectives, which are summarized below, along with more specific areas of focus. The Company uses the financial measures below to gauge progress toward achieving these strategic objectives. These measures include organic sales growth, operating margins, cash flow from operations, and returns on invested capital.

[0000889331-23-000016:mdna:25]
| Strategic Objectives |  | Priorities |
| Double-digit sales growth |  | ● | Increase product content with existing and new customers, and expand market share |
| 5-7% average annual organic sales growth |  | ● | Expand presence (i.e. with portfolio and infrastructure) into new and underpenetrated, high-growth geographies and end markets |
| 5-7% average annual growth from strategic acquisitions |  | ● | Increase innovation capabilities and investments |
|  |  | ● | Leverage breadth of go-to-market strategies |
|  |  | ● | Target mergers and acquisitions that enhance and sustain organic growth |
| EPS growth |  | ● | Focus on higher profitability growth opportunities |
| Earnings per share growth greater than revenue growth |  | ● | Improve operating margins through operational and commercial excellence |
|  |  | ● | Disciplined approach to balancing costs with long-term strategic investments |
| Capital allocation and returns |  | ● | Disciplined management of working capital |
| Cash flow from operations less capital expenditures (free cash flow) is targeted to approximate or exceed net income |  | ● | Deployment of capital consistent with capital allocation priorities |
| Target 40% of free cash flow returned to shareholders |  | ● | Mergers and acquisitions that align with strategy and financial metrics |
| Remainder focused on strategic acquisitions |  | ● | Grow dividend in line with earnings |
| Return on invested capital percentage in the high-teens |  | ● | Opportunistic share repurchases |

[0000889331-23-000016:mdna:26]
The Company’s strategy is focused on accelerating organic growth by increasing its product content in applications and share gains, enhancing technology efforts to drive innovation, expanding its digital presence, capitalizing on cross segment opportunities, and gaining traction in underpenetrated, high-growth geographies and end markets. The Company also leverages strategic acquisitions to enhance and sustain its organic growth. The Company will continue to make targeted strategic acquisitions that align to its strategy and financial metrics to drive growth across its businesses, products, markets, and technologies while leveraging existing customers and targeting new customers.

[0000889331-23-000016:mdna:27]
Management believes that profitable growth through a combination of organic growth and strategic acquisitions is critical to the Company’s competitiveness, while enhancing the value the Company delivers to all of its stakeholders. In addition, the Company continues to implement initiatives across all businesses to enhance productivity, and its commercial and operational capabilities, while managing its cost structure to align with business conditions, and the markets it serves. Primary areas of focus include optimizing its global operations, successfully integrating strategic acquisitions, and streamlining administrative and support activities to drive improved operating margins.

[0000889331-23-000016:mdna:28]
The Company seeks to deploy its capital consistent with its capital allocation priorities. These priorities include investments to drive increased organic growth, targeted acquisitions that align to the Company’s strategic and financial metrics, and enhance and sustain its organic growth, and returning capital to shareholders through dividends and opportunistic share repurchases.

[0000889331-23-000016:mdna:29]
Critical Estimates and Significant Accounting Policies

[0000889331-23-000016:mdna:30]
The preparation of financial statements in conformity with generally accepted accounting principle ("GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The Company’s most critical accounting policies are those that are most important to the portrayal of its financial condition and results of operations, and which require the Company to make its most difficult and subjective judgments, often as a result of the need to make estimates of matters that are inherently uncertain. The Company has identified the following as its most critical accounting policies and judgments. Although management believes that its estimates and assumptions are reasonable, they are based upon information available when they are made, and therefore, actual results may

[0000889331-23-000016:mdna:31]
differ from these estimates under different assumptions or conditions. The Company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0000889331-23-000016:mdna:32]
Critical Accounting Estimates

[0000889331-23-000016:mdna:33]
Goodwill

[0000889331-23-000016:mdna:34]
The Company’s methodology for allocating the purchase price of acquisitions is based on established valuation techniques that reflect the consideration of a number of factors, including valuations performed by third-party appraisers when appropriate. Goodwill is measured as the excess of the cost of an acquired entity over the fair value assigned to identifiable assets acquired and liabilities assumed. Based on its current organization structure, the Company has seven reporting units for which cash flows are determinable and to which goodwill has been allocated.

[0000889331-23-000016:mdna:35]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events.

[0000889331-23-000016:mdna:36]
There were no impairment charges recorded during the fiscal years of 2022 and 2021. During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Transportation segment.

[0000889331-23-000016:mdna:37]
Quantitative Assessment for Impairment

[0000889331-23-000016:mdna:38]
For the seven reporting units with goodwill, the Company compares the estimated fair value of each reporting unit to its carrying value. If the carrying value of a reporting unit exceeds the estimated fair value, the difference between the estimated fair value and carrying value is recorded as the amount of the goodwill impairment charge. The results of the goodwill impairment test as of October 2, 2022 indicated that the estimated fair values for each of the seven reporting units exceeded their respective carrying values. Accordingly, there were no goodwill impairment charges recorded as part of the Company’s 2022 annual goodwill impairment test.

[0000889331-23-000016:mdna:39]
As part of its impairment test for these reporting units, the Company engaged a third-party appraisal firm to assist in the Company’s determination of the estimated fair values. This determination included estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping. The Company weighted both the income and market approach equally to estimate the concluded fair value of each reporting unit. The determination of fair value requires the Company to make significant estimates and assumptions, which primarily include, but are not limited to: the selection of appropriate peer group companies; control premiums appropriate for acquisitions in which the Company competes; the discount rate; terminal growth rates; and forecasts of revenue, operating income, depreciation and amortization and capital expenditures.

[0000889331-23-000016:mdna:40]
Goodwill Impairment Assumptions

[0000889331-23-000016:mdna:41]
Although the Company believes its estimates of fair value are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results or other underlying assumptions could have a significant impact on the fair value of the reporting units. Future declines in the overall market value of the Company’s equity may also result in a conclusion that the fair value of one or more reporting units has declined below its carrying value.

[0000889331-23-000016:mdna:42]
One measure of the sensitivity of the amount of goodwill impairment charges to key assumptions is the amount by which each reporting unit “passed” (fair value exceeds the carrying value) the goodwill impairment test. All seven of the reporting units passed the goodwill impairment test, with fair values that exceeded the carrying values between 42% and 191% of their respective estimated fair values. As of the most recent annual test conducted on October 2, 2022, the Company noted that the

[0000889331-23-000016:mdna:43]
excess of fair value over the carrying value was 151%, 66%, 98%, 42%, 44%, 57%, and 191% for its reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, Automotive Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test.

[0000889331-23-000016:mdna:44]
Generally, changes in estimates of expected future cash flows would have a similar effect on the estimated fair value of the reporting unit. That is, a 1.0% decrease in estimated annual future cash flows would decrease the estimated fair value of the reporting unit by approximately 1.0%. The estimated long-term net sales growth rate can have a significant impact on the estimated future cash flows, and therefore, the fair value of each reporting unit. A 1.0% decrease in the long-term net sales growth rate would have resulted in no reporting units failing the goodwill impairment test. Of the other key assumptions that impact the estimated fair values, most reporting units have the greatest sensitivity to changes in the estimated discount rate. The estimated discount rate was 13.4% for the Electronics-Passive Products and Sensors, the Passenger Car Products, and Commercial Vehicle Products reporting units, 14.3% for the Electronics-Semiconductor reporting unit, and 15.2% for each of the Automotive Sensors, Power Fuse and Relays reporting units. A 1.0% increase in the estimated discount rates would have resulted in no reporting units failing the annual goodwill impairment test. The Company believes that its estimates of future cash flows and discount rates are reasonable, but future changes in the underlying assumptions could differ due to the inherent uncertainty in making such estimates. Additionally, price deterioration or lower volume could have a significant impact on the fair values of the reporting units.

[0000889331-23-000016:mdna:45]
Income Taxes

[0000889331-23-000016:mdna:46]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-23-000016:mdna:47]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-23-000016:mdna:48]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-23-000016:mdna:49]
The 2017 Tax Cuts and Jobs Act (the "Tax Act"), among other things, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and included base broadening provisions commonly referred to as the global intangible low-taxed income provisions ("GILTI").

[0000889331-23-000016:mdna:50]
In accordance with guidance issued by the Financial Accounting Standards Board ("FASB") staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 31, 2022, January 1, 2022, and December 26, 2020, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-23-000016:mdna:51]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-23-000016:mdna:52]
Critical Accounting Policies

[0000889331-23-000016:mdna:53]
Revenue Recognition

[0000889331-23-000016:mdna:54]
Revenue Disaggregation

[0000889331-23-000016:mdna:55]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 31, 2022 and January 1, 2022:

[0000889331-23-000016:mdna:56]
|  |  | Fiscal Year Ended December 31, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 802,281 |  |  | $ | — |  |  | $ | — |  |  | $ | 802,281 |  |
| Electronics – Passive Products and Sensors |  | 690,538 |  |  | — |  |  | — |  |  | 690,538 |  |
| Commercial Vehicle Products |  | — |  |  | 374,707 |  |  | — |  |  | 374,707 |  |
| Passenger Car Products |  | — |  |  | 249,470 |  |  | — |  |  | 249,470 |  |
| Automotive Sensors |  | — |  |  | 91,963 |  |  | — |  |  | 91,963 |  |
| Industrial Products |  | — |  |  | — |  |  | 304,938 |  |  | 304,938 |  |
| Total |  | $ | 1,492,819 |  |  | $ | 716,140 |  |  | $ | 304,938 |  |  | $ | 2,513,897 |  |

[0000889331-23-000016:mdna:57]
|  |  | Fiscal Year Ended January 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 678,861 |  |  | $ | — |  |  | $ | — |  |  | $ | 678,861 |  |
| Electronics – Passive Products and Sensors |  | 621,883 |  |  | — |  |  | — |  |  | 621,883 |  |
| Passenger Car Products |  | — |  |  | 266,020 |  |  | — |  |  | 266,020 |  |
| Commercial Vehicle Products |  | — |  |  | 160,300 |  |  | — |  |  | 160,300 |  |
| Automotive Sensors |  | — |  |  | 101,738 |  |  | — |  |  | 101,738 |  |
| Industrial Products |  | — |  |  | — |  |  | 251,126 |  |  | 251,126 |  |
| Total |  | $ | 1,300,744 |  |  | $ | 528,058 |  |  | $ | 251,126 |  |  | $ | 2,079,928 |  |

[0000889331-23-000016:mdna:58]
See Note 16, Segment Information, for net sales by segment and countries.

[0000889331-23-000016:mdna:59]
Revenue Recognition

[0000889331-23-000016:mdna:60]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s sales channels are primarily through direct sales and independent third-party distributors.

[0000889331-23-000016:mdna:61]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-23-000016:mdna:62]
Revenue and Billing

[0000889331-23-000016:mdna:63]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment

[0000889331-23-000016:mdna:64]
activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0000889331-23-000016:mdna:65]
Ship and Debit Program

[0000889331-23-000016:mdna:66]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-23-000016:mdna:67]
Return to Stock

[0000889331-23-000016:mdna:68]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-23-000016:mdna:69]
Volume Rebates

[0000889331-23-000016:mdna:70]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-23-000016:mdna:71]
Allowance for Credit Losses

[0000889331-23-000016:mdna:72]
The Company currently measures the expected credit losses based on our historical credit loss experience. The Company has not experienced significant recent or historical credit losses and is not forecasting any significant credit losses which would require adjustments to our methodology. If current conditions and supportable forecasts indicate that our historical loss experience is not reasonable and no longer supportable, the Company may adjust its historical credit loss experience and to reflect these conditions and forecasts. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also analyzes all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and historical collection and loss experience. Historically, the allowance for credit losses has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-23-000016:mdna:73]
Inventory

[0000889331-23-000016:mdna:74]
The Company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life, and quality issues. Based on the analysis, the Company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable value.

[0000889331-23-000016:mdna:75]
Long-Lived Assets

[0000889331-23-000016:mdna:76]
The Company evaluates the recoverability of other long-lived assets, including property, plant and equipment and certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset group may not be recoverable. Factors which could trigger an impairment review include significant underperformance relative to historical or projected operating results, significant changes in the manner of use of the assets or the strategy for the overall business, a significant decrease in the market value of the assets or significant negative industry or economic trends. When the Company determines that the carrying value of long-lived assets may not be recoverable based upon the existence of one or more of the indicators, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition. If the carrying value of an asset exceeds its estimated future

[0000889331-23-000016:mdna:77]
undiscounted cash flows, an impairment loss is recorded for the excess of the asset’s carrying value over its fair value. For the fiscal year ended December 31, 2022, the Company recorded a $2.9 million non-cash impairment charge for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment. Additionally, the Company recorded a non-cash impairment charge of $1.7 million for certain machinery and equipment within the Electronics segment due to a decision to cease further production of a product line during the fourth quarter of 2022. For the fiscal year ended December 26, 2020, the Company recognized a $2.2 million impairment charge related to the land and building associated with the Company’s announced consolidation of a manufacturing facility within the Industrial segment.

[0000889331-23-000016:mdna:78]
Environmental Liabilities

[0000889331-23-000016:mdna:79]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The Company evaluates its reserve for coal mine remediation annually utilizing a third-party expert.

[0000889331-23-000016:mdna:80]
Pension Plans

[0000889331-23-000016:mdna:81]
The Company records annual income and expense amounts relating to its pension and postretirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive (loss) income. The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors. The Company maintains several pension plans in international locations. The expected returns on plan assets and discount rates are determined based on each plan’s investment approach, local interest rates and plan participant profiles. The weighted-average discount rates for the Company’s defined benefit plans primarily in Europe and the Asia-Pacific regions at December 31, 2022 and January 1, 2022 were 5.8% and 3.1%, respectively.

[0000889331-23-000016:mdna:82]
A 50 basis point change in the discount rates at December 31, 2022 would have the following effect on the projected benefit obligation:

[0000889331-23-000016:mdna:83]
| (in millions) | 0.5%Increase |  | 0.5%Decrease |
| Projected benefit obligation | $ | (3.4) |  |  | $ | 3.6 |  |

[0000889331-23-000016:mdna:84]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company is required to directly pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries. The Company completed the buy-out of this U.K. pension plan during the fourth quarter of 2021 and as a result recorded a non-cash pension settlement charge of $19.9 million (£14.9 million), inclusive of the accelerated recognition of prior service cost of $0.5 million (£0.4 million).

[0000889331-23-000016:mdna:85]
Equity-based Compensation

[0000889331-23-000016:mdna:86]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments for the foreseeable future. The fair value of restricted share units is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-23-000016:mdna:87]
Total equity-based compensation expense for all equity compensation plans was $24.6 million, $21.4 million, and $19.1 million in 2022, 2021, and 2020, respectively. Further information regarding this expense is provided in Note 12, Stock-Based Compensation, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-23-000016:mdna:88]
Off-Balance Sheet Arrangements

[0000889331-23-000016:mdna:89]
The Company does not have off-balance sheet arrangements as defined under SEC rules. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-23-000016:mdna:90]
In the financial review that follows, the Company discusses its consolidated results of operations, financial position, cash flows and certain other information. This discussion should be read in conjunction with the Company’s Consolidated Financial Statements and related notes.

[0000889331-23-000016:mdna:91]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 31, 2022 AS COMPARED TO THE YEAR ENDED JANUARY 01, 2022

[0000889331-23-000016:mdna:92]
Fiscal year 2022 included $43.2 million of non-segment charges, of which $17.6 million related to legal and professional fees and other integration expenses primarily associated with the C&K and Carling acquisitions and other contemplated acquisitions, $15.6 million of purchase accounting inventory step-up charges, and $10.0 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $2.9 million intangible asset impairment charge within the Electronics segment in the fourth quarter of 2022.  See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-23-000016:mdna:93]
Fiscal year 2021 included $12.6 million of non-segment charges, of which $8.4 million relates to purchase accounting inventory step-up charges, $7.0 million of acquisition-related and integration charges related to the Carling and Hartland acquisitions and other contemplated acquisitions, and $2.2 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Additionally, partially offsetting the above amounts was a gain of $5.0 million recorded for the sale of buildings within the Electronics segment.

[0000889331-23-000016:mdna:94]
Fiscal year 2022 also included approximately $24.4 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Philippine peso, Sterling, and Chinese renminbi against the U.S. dollar, while fiscal year 2021 included approximately $17.2 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Chinese renminbi, Mexican peso, and Philippine peso against the U.S. dollar.

[0000889331-23-000016:mdna:95]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2022 |  | 2021 |  | Change |  | % Change |
| Net sales | $ | 2,513,897 |  |  | $ | 2,079,928 |  |  | $ | 433,969 |  |  | 20.9 | % |
| Cost of sales | 1,506,984 |  |  | 1,308,002 |  |  | 198,982 |  |  | 15.2 | % |
| Gross profit | 1,006,913 |  |  | 771,926 |  |  | 234,987 |  |  | 30.4 | % |
| Operating expenses | 506,087 |  |  | 386,284 |  |  | 119,803 |  |  | 31.0 | % |
| Operating income | 500,826 |  |  | 385,642 |  |  | 115,184 |  |  | 29.9 | % |
| Other expense, net | 7,207 |  |  | 8,932 |  |  | (1,725) |  |  | (19.3) | % |
| Income before income taxes | 443,044 |  |  | 341,025 |  |  | 102,019 |  |  | 29.9 | % |
| Income taxes | 69,738 |  |  | 57,219 |  |  | 12,519 |  |  | 21.9 | % |
| Net income | 373,306 |  |  | 283,806 |  |  | 89,500 |  |  | 31.5 | % |

[0000889331-23-000016:mdna:96]
Net Sales

[0000889331-23-000016:mdna:97]
Net sales were $2,513.9 million, which increased $434.0 million, or 20.9% compared to 2021, including $202.8 million or 9.8% of incremental net sales within the Transportation segment from the Carling acquisition and $81.7 million or 3.9% of net sales within the Electronics segment from the C&K acquisition, partially offset by $65.3 million or 3.1% of unfavorable changes in foreign exchange rates for 2022 compared to 2021. The remaining increase of $110.3 million in the Electronics segment was due to higher volume and price realization across numerous end markets while the Industrial segment increased $53.8 million as a result of higher volume and price realization.

[0000889331-23-000016:mdna:98]
Cost of Sales

[0000889331-23-000016:mdna:99]
Cost of sales was $1,507.0 million, or 59.9% of net sales, in 2022, compared to $1,308.0 million, or 62.9% of net sales, in 2021. The increase in cost of sales was primarily due to greater volume across the Electronics and Industrial segments driven by the factors discussed above along with the acquisitions of Carling and C&K. As a percent of net sales, cost of sales decreased 3.0% driven by volume leverage, partially offset by higher purchase accounting inventory charges of $7.2 million or 0.2% compared to 2021.

[0000889331-23-000016:mdna:100]
Gross Profit

[0000889331-23-000016:mdna:101]
Gross profit was $1,006.9 million, or 40.1% of net sales, in 2022, compared to $771.9 million, or 37.1% of net sales, in 2021. The $235.0 million increase in gross profit was primarily due to higher volume and price realization in the Electronics and Industrial segments along with the acquisitions of Carling and C&K. The increase in gross margin of 3.0% was primarily driven by volume leverage and price realization, partially offset by higher purchase accounting inventory charges of $7.2 million or 0.2% compared to 2021.

[0000889331-23-000016:mdna:102]
Operating Expenses

[0000889331-23-000016:mdna:103]
Total operating expenses were $506.1 million, or 20.1% of net sales, for 2022 compared to $386.3 million, or 18.6% of net sales, for 2021. The increase in operating expenses of $119.8 million was primarily due to higher selling, general, and administrative expenses, which increased by $69.4 million, research and development expenses, which increased by $29.7 million and increased amortization expense of $13.0 million and acquisition-related expenses of $10.6 million largely due to the Carling and C&K acquisitions.

[0000889331-23-000016:mdna:104]
Operating Income

[0000889331-23-000016:mdna:105]
Operating income for 2022 was $500.8 million, an increase of $115.2 million or 29.9% compared to $385.6 million for 2021. The increase in operating income was primarily due to higher gross profit across from Electronics and Industrial segments, partially offset by higher operating expenses as discussed above. Operating margins increased from 18.5% in 2021 to 19.9% in 2022 primarily driven by higher operating income  in the Electronics segment of $122.0 million.

[0000889331-23-000016:mdna:106]
Income Before Income Taxes

[0000889331-23-000016:mdna:107]
Income before income taxes for 2022 was $443.0 million, or 17.6% of net sales compared to $341.0 million, or 16.4% of net sales, for 2021. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by $14.0 million of unrealized losses during 2022 compared to unrealized gains of $8.8 million during 2021 related to the Company's equity investment, higher interest expense of $7.7 million due to an increase in borrowings outstanding, and higher foreign exchange losses of $7.2 million compared to 2021, partially offset by a $19.9 million non-cash pension settlement charge recognized in 2021.

[0000889331-23-000016:mdna:108]
Income Taxes

[0000889331-23-000016:mdna:109]
Income tax expense for 2022 was $69.7 million, or an effective tax rate of 15.7%, compared to income tax expense of $57.2 million, or an effective tax rate of 16.8% for 2021. The Company’s tax rates are lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by the impact of taxes on unremitted earnings, the GILTI tax provisions, and non-U.S. losses and expenses with no tax benefit. The effective tax rate for 2022 is lower than the effective tax rate for 2021, primarily due to one-time tax benefits resulting from losses on investments in the stock of two of the Company's affiliates. Further information regarding these items is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-23-000016:mdna:110]
Segment Information

[0000889331-23-000016:mdna:111]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-23-000016:mdna:112]
The following table is a summary of the Company’s net sales by segment:

[0000889331-23-000016:mdna:113]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | % Change |
| Electronics | $ | 1,492.8 |  |  | $ | 1,300.7 |  |  | $ | 192.1 |  |  | 14.8 | % |
| Transportation | 716.2 |  |  | 528.1 |  |  | 188.1 |  |  | 35.6 | % |
| Industrial | 304.9 |  |  | 251.1 |  |  | 53.8 |  |  | 21.4 | % |
| Total | $ | 2,513.9 |  |  | $ | 2,079.9 |  |  | $ | 434.0 |  |  | 20.9 | % |

[0000889331-23-000016:mdna:114]
Electronics Segment

[0000889331-23-000016:mdna:115]
Net sales for the Electronics segment increased $192.1 million, or 14.8%, in 2022 compared to 2021 and included unfavorable changes in foreign exchange rates of $37.1 million or 2.9%. The sales increase was $123.4 million for the semiconductor products business and $68.7 million in the electronics products business, primarily driven by increased volume and price realization. The sales increase in electronics products business also included the incremental $81.7 million of sales from the acquisition of C&K. These volume increases were driven by continued broad-based demand across numerous end markets.

[0000889331-23-000016:mdna:116]
Transportation Segment

[0000889331-23-000016:mdna:117]
Net sales in the Transportation segment increased $188.1 million, or 35.6%, in 2022 compared to 2021 and included unfavorable changes in foreign exchange rates of $26.0 million or 4.9%. The sales increase was primarily due to the incremental sales of  $202.8 million from the Carling acquisition. Net sales in the commercial vehicle business increased by $214.4 million, largely due to the Carling acquisition noted previously and continued demand across a number of commercial vehicle end markets. The passenger car products and automotive sensors businesses had sales decreases of $16.6 million and $9.8 million, respectively. The decreases were primarily driven by unfavorable changes in foreign exchange rates, certain automotive customers rebalancing their inventory levels of the Company's products, and supply chain constraints, partially offset by greater content growth from vehicle mix and electric vehicles.

[0000889331-23-000016:mdna:118]
Industrial Segment

[0000889331-23-000016:mdna:119]
The Industrial segment net sales increased by $53.8 million, or 21.4%, in 2022 compared to 2021 and included unfavorable changes in foreign exchange rates of $2.2 million or 0.9%. The increase in net sales was primarily due to higher volume and demand across a number of end markets, price realization, and incremental one month net sales of $9.1 million or 3.6% from the Hartland acquisition.

[0000889331-23-000016:mdna:120]
Geographic Net Sales Information

[0000889331-23-000016:mdna:121]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-23-000016:mdna:122]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | % Change |
| Asia-Pacific | $ | 1,019.9 |  |  | $ | 955.7 |  |  | $ | 64.2 |  |  | 6.7 | % |
| Americas | 992.3 |  |  | 694.3 |  |  | 298.0 |  |  | 42.9 | % |
| Europe | 501.7 |  |  | 429.9 |  |  | 71.8 |  |  | 16.7 | % |
| Total | $ | 2,513.9 |  |  | $ | 2,079.9 |  |  | $ | 434.0 |  |  | 20.9 | % |

[0000889331-23-000016:mdna:123]
Asia-Pacific

[0000889331-23-000016:mdna:124]
Asia-Pacific net sales increased $64.2 million, or 6.7%, in 2022 compared to 2021 and included unfavorable changes in foreign exchange rates of $18.4 million. The increase in net sales was primarily due to incremental sales from the C&K acquisition and higher volume and price realization from the semiconductor products business within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business, partially offset by lower net sales from the electronics products and passenger car products businesses.

[0000889331-23-000016:mdna:125]
Americas

[0000889331-23-000016:mdna:126]
Net sales in the Americas increased $298.0 million, or 42.9%, in 2022 compared to 2021 and included unfavorable changes in foreign exchange rates of $1.4 million. The increase in net sales was primarily due to incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment, higher volume and price realization from all businesses within the Electronics segment including incremental sales from the C&K acquisition and higher volume and price realization from the Industrial segment compared to 2021.

[0000889331-23-000016:mdna:127]
Europe

[0000889331-23-000016:mdna:128]
European net sales increased $71.8 million, or 16.7%, in 2022 compared to 2021 and included unfavorable changes in foreign exchange rates of $45.5 million. The increase in net sales was primarily due to increased volume across all businesses within the Electronics segment including incremental sales from C&K acquisition, and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to 2021.

[0000889331-23-000016:mdna:129]
RESULTS OF OPERATIONS FOR THE YEAR ENDED JANUARY 01, 2022 AS COMPARED TO THE YEAR ENDED DECEMBER 26, 2020

[0000889331-23-000016:mdna:130]
Fiscal year 2021 included approximately $12.6 million of non-segment charges, of which $8.4 million relates to purchase accounting inventory step-up charges, $7.0 million of acquisition-related and integration charges related to the Carling and Hartland acquisitions and other contemplated acquisitions, and $2.2 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Additionally, partially offsetting the above amounts was a gain of $5.0 million recorded for the sale of buildings within the Electronics segment.

[0000889331-23-000016:mdna:131]
Fiscal year 2020 included approximately $44.0 million of non-segment charges, of which $2.3 million of charges are acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $41.7 million of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Transportation segment, employee termination costs of $5.5 million, $2.2 million of impairment charges recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment and other restructuring charges of $0.2 million.

[0000889331-23-000016:mdna:132]
Fiscal year 2021 also included approximately $17.2 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Chinese renminbi, Mexican peso, and Philippine peso against the U.S. dollar, while fiscal year 2020 included approximately $14.9 million in foreign currency exchange gains primarily attributable to changes in the value of the Euro, Philippine peso, and Chinese renminbi against the U.S. dollar.

[0000889331-23-000016:mdna:133]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2021 |  | 2020 |  | Change |  | % Change |
| Net sales | $ | 2,079,928 |  |  | $ | 1,445,695 |  |  | $ | 634,233 |  |  | 43.9 | % |
| Cost of sales | 1,308,002 |  |  | 944,523 |  |  | 363,479 |  |  | 38.5 | % |
| Gross profit | 771,926 |  |  | 501,172 |  |  | 270,754 |  |  | 54.0 | % |
| Operating expenses | 386,284 |  |  | 338,800 |  |  | 47,484 |  |  | 14.0 | % |
| Operating income | 385,642 |  |  | 162,372 |  |  | 223,270 |  |  | 137.5 | % |
| Other expense (income), net | 8,932 |  |  | (5,083) |  |  | 14,015 |  |  | (275.7) | % |
| Income before income taxes | 341,025 |  |  | 161,253 |  |  | 179,772 |  |  | 111.5 | % |
| Income taxes | 57,219 |  |  | 31,267 |  |  | 25,952 |  |  | 83.0 | % |
| Net income | 283,806 |  |  | 129,986 |  |  | 153,820 |  |  | 118.3 | % |

[0000889331-23-000016:mdna:134]
Net Sales

[0000889331-23-000016:mdna:135]
Net sales increased $634.2 million or 43.9% including $27.4 million or 1.9% of favorable changes in foreign exchange rates for 2021 compared to 2020. The increase was due to volume growth across all segments and businesses while 2020 had temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19. The increase was due to higher sales of $363.0 million, $138.9 million, and $132.3 million in the Electronics, Industrial, and Transportation segments, respectively, primarily driven by higher volumes across all businesses within these segments. The volume increase within the Electronics segment was led by broad-based demand across electronics, transportation and industrial end markets. The increase within the Industrial segment was primarily due to $100.5 million of net sales resulting from the Hartland acquisition and volume growth within the Industrial segment. The increase within the Transportation segment was due to volume growth driven by higher demand in the global auto and commercial vehicle markets, greater content growth across passenger vehicles due to vehicle mix, including growth in electric vehicles and some customers maintaining additional inventory of our products, and $15.3 million of net sales resulting from the Carling acquisition.

[0000889331-23-000016:mdna:136]
Cost of Sales

[0000889331-23-000016:mdna:137]
Cost of sales was $1,308.0 million, or 62.9% of net sales, in 2021, compared to $944.5 million, or 65.3% of net sales, in 2020. The increase in cost of sales was primarily due to greater volume across all segments driven by the factors discussed above along with the Hartland and Carling acquisitions. As a percent of net sales, cost of sales decreased 2.4% driven by volume leverage, partially offset by higher transportation, duty and tariff charges of 2.2%, the purchase accounting inventory charges of $8.4 million or 0.4% resulting from the Hartland and Carling acquisitions, and higher material costs.

[0000889331-23-000016:mdna:138]
Gross Profit

[0000889331-23-000016:mdna:139]
Gross profit was $771.9 million, or 37.1% of net sales, in 2021, compared to $501.2 million, or 34.7% of net sales, in 2020. The $270.8 million increase in gross profit was primarily due to higher volume across all segments while 2020 had additional costs associated with government-directed plant shutdowns and supply chain constraints. The increase in gross margin of 2.4% was primarily driven by volume leverage and favorable product mix within the Electronics segment, partially offset by higher transportation, duty and tariff charges as a percent of net sales of 2.2%, the purchase accounting inventory charges of $8.4 million or 0.4%, and higher material costs.

[0000889331-23-000016:mdna:140]
Operating Expenses

[0000889331-23-000016:mdna:141]
Total operating expenses were $386.3 million, or 18.6% of net sales, for 2021 compared to $338.8 million, or 23.4% of net sales, for 2020. The increase in operating expenses of $47.5 million is primarily due to higher selling, general, and administrative expenses of $71.0 million largely due to higher accrued incentive compensation, the Hartland and Carling acquisitions and higher acquisition-related and integration charges of $4.7 million, and higher research and development expenses of $13.4 million, partially offset by the 2020 goodwill impairment charge of $33.8 million, or 2.3% of net sales, in the automotive sensors reporting unit within the Transportation segment and impairment charges of $2.2 million related to the Company’s 2020 first quarter announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-23-000016:mdna:142]
Operating Income

[0000889331-23-000016:mdna:143]
Operating income for 2021 was $385.6 million, an increase of $223.3 million or 137.5% compared to $162.4 million for 2020. The increase in operating income was primarily due to higher gross margin across all segments, led by the Electronics segment partially offset by higher operating expenses noted above. Operating margins increased from 11.2% in 2020 to 18.5% in 2021 primarily driven by the factors mentioned above. The 2020 goodwill impairment charge of $33.8 million negatively impacted the 2020 operating margin by 2.3%.

[0000889331-23-000016:mdna:144]
Income Before Income Taxes

[0000889331-23-000016:mdna:145]
Income before income taxes for 2021 was $341.0 million, or 16.4% of net sales compared to $161.3 million, or 11.2% of net sales, for 2020. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by foreign exchange losses of $17.2 million during the fiscal year ended January 1, 2022 compared to foreign exchange gains of $14.9 million during the fiscal year ended December 26, 2020, and a $19.9 million non-cash pension settlement charge, partially offset by a $4.0 million increase in unrealized investment gains associated with our equity investment, and lower interest expense of $2.6 million due to lower outstanding borrowings under the credit facility along with a lower effective interest rate and a reduction in coal mining charges of $1.6 million compared to 2020.

[0000889331-23-000016:mdna:146]
Income Taxes

[0000889331-23-000016:mdna:147]
Income tax expense for 2021 was $57.2 million, or an effective tax rate of 16.8%, compared to income tax expense of $31.3 million, or an effective tax rate of 19.4% for 2020. The Company’s tax rates are lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by the impact of taxes on unremitted earnings, the GILTI tax provisions, and non-U.S. losses and expenses with no tax benefit. The effective tax rate for 2021 is lower than the effective tax rate for 2020, primarily due to an increase in the income earned in lower tax jurisdictions in 2021 as compared to 2020, as well as the impact of the goodwill impairment charge of $33.8 million recorded in 2020, the substantial majority of which did not result in a tax benefit.  Further information regarding these items is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-23-000016:mdna:148]
Segment Information

[0000889331-23-000016:mdna:149]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-23-000016:mdna:150]
The following table is a summary of the Company’s net sales by segment:

[0000889331-23-000016:mdna:151]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | % Change |
| Electronics | $ | 1,300.7 |  |  | $ | 937.7 |  |  | $ | 363.0 |  |  | 38.7 | % |
| Transportation | 528.1 |  |  | 395.8 |  |  | 132.3 |  |  | 33.4 | % |
| Industrial | 251.1 |  |  | 112.2 |  |  | 138.9 |  |  | 123.8 | % |
| Total | $ | 2,079.9 |  |  | $ | 1,445.7 |  |  | $ | 634.2 |  |  | 43.9 | % |

[0000889331-23-000016:mdna:152]
Electronics Segment

[0000889331-23-000016:mdna:153]
Net sales for the Electronics segment increased $363.0 million, or 38.7%, in 2021 compared to 2020 and included favorable changes in foreign exchange rates of $14.5 million or 1.5%. The sales increase was primarily due to increased volume for the electronics and semiconductor products businesses of $206.5 million and $156.5 million, respectively. The volume increases were driven by broad-based demand across electronics, transportation and industrial end markets while 2020 were negatively impacted by production disruptions and temporary plant shutdowns due to the impact of COVID-19.

[0000889331-23-000016:mdna:154]
Transportation Segment

[0000889331-23-000016:mdna:155]
Net sales in the Transportation segment increased $132.3 million, or 33.4%, in 2021 compared to 2020 and included favorable changes in foreign exchange rates of $12.0 million or 3.0%. The sales increase was due to higher volume in passenger car products, commercial vehicle products, and the automotive sensors businesses of $65.6 million, $59.0 million, and $7.8 million, respectively, including the incremental net sales of $15.3 million from the Carling acquisition within the commercial vehicle products business. These increases were due to volume growth driven by higher demand in the global auto and commercial vehicle markets, greater content growth across passenger vehicles due to vehicle mix, including growth in electric vehicles and some customers maintaining additional inventory of our products as compared to 2020, which had production disruptions and temporary plant shutdowns due to the impact of COVID-19.

[0000889331-23-000016:mdna:156]
Industrial Segment

[0000889331-23-000016:mdna:157]
The Industrial segment net sales increased by $138.9 million, or 123.8%, in 2021 compared to 2020 and included favorable changes in foreign exchange rates of $0.9 million or 0.8%. The increase in net sales was primarily due to the incremental net sales of $100.5 million or 90% from the Hartland acquisition, growth across all product lines, and the transfer of the temperature sensor product line totaling $4.7 million which was previously reported in the Electronics segment and moved to Industrial segment in the third quarter of 2020. Additionally, 2020 was negatively impacted by production disruptions and temporary plant shutdowns due to the impact of COVID-19.

[0000889331-23-000016:mdna:158]
Geographic Net Sales Information

[0000889331-23-000016:mdna:159]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-23-000016:mdna:160]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | % Change |
| Asia-Pacific | $ | 955.7 |  |  | $ | 670.5 |  |  | $ | 285.2 |  |  | 42.5 | % |
| Americas | 694.3 |  |  | 457.8 |  |  | 236.5 |  |  | 51.7 | % |
| Europe | 429.9 |  |  | 317.4 |  |  | 112.5 |  |  | 35.4 | % |
| Total | $ | 2,079.9 |  |  | $ | 1,445.7 |  |  | $ | 634.2 |  |  | 43.9 | % |

[0000889331-23-000016:mdna:161]
Asia-Pacific

[0000889331-23-000016:mdna:162]
Asia-Pacific net sales increased $285.2 million, or 42.5%, in 2021 compared to 2020 and included favorable changes in foreign exchange rates of $12.5 million. The increase in net sales was primarily due to higher volume across all segments and businesses compared to 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-23-000016:mdna:163]
Americas

[0000889331-23-000016:mdna:164]
Net sales in the Americas increased $236.5 million, or 51.7%, in 2021 compared to 2020 and included favorable changes in foreign exchange rates of $0.7 million. The increase in net sales was primarily due to incremental sales from the Hartland and Carling acquisitions, higher volume across all segments and businesses compared to 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-23-000016:mdna:165]
Europe

[0000889331-23-000016:mdna:166]
European net sales increased $112.5 million, or 35.4%, in 2021 compared to 2020 and included favorable changes in foreign exchange rates of $14.2 million. The increase in net sales was primarily due to higher volume across all businesses within the Electronics and Transportation segments compared to the 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-23-000016:mdna:167]
Liquidity and Capital Resources

[0000889331-23-000016:mdna:168]
Cash and cash equivalents were $562.6 million as of December 31, 2022, an increase of $84.1 million as compared to January 1, 2022.

[0000889331-23-000016:mdna:169]
As of December 31, 2022, $452.0 million of the Company's $562.6 million cash and cash equivalents was held by non-U.S. subsidiaries. Of the $452.0 million, at least $339.6 million can be repatriated with minimal tax consequences, although in certain cases a non-U.S. withholding tax would be payable but subsequently refunded. With respect to the remaining $112.4 million, the Company has recognized deferred tax liabilities on approximately $53.6 million as of December 31, 2022 because the amounts are not considered to be permanently reinvested, and the Company may access additional amounts through loans and other means. Repatriation of some non-U.S. cash balances is restricted by local laws. Management regularly evaluates whether foreign earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its foreign subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-23-000016:mdna:170]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0000889331-23-000016:mdna:171]
Revolving Credit Facility

[0000889331-23-000016:mdna:172]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (as so amended and restated, the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000016:mdna:173]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000016:mdna:174]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the fiscal year ended December 31, 2022, the Company made term loan payments of $3.8 million. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $296.3 million, respectively, as of December 31, 2022.

[0000889331-23-000016:mdna:175]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-23-000016:mdna:176]
As of December 31, 2022, the effective interest rate on outstanding borrowings under the credit facility was 5.42%.

[0000889331-23-000016:mdna:177]
As of December 31, 2022, the Company had no outstanding letters of credit and had available $600.0 million of borrowing capacity under the revolving credit facility. At December 31, 2022, the Company was in compliance with all covenants under the credit agreement.

[0000889331-23-000016:mdna:178]
Senior Notes

[0000889331-23-000016:mdna:179]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-23-000016:mdna:180]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the fiscal year ended December 31, 2022, the Company paid off $25.0 million of U.S. Senior Notes, Series A due 2022.

[0000889331-23-000016:mdna:181]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000016:mdna:182]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the amended and restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000016:mdna:183]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2032.

[0000889331-23-000016:mdna:184]
Debt Covenants

[0000889331-23-000016:mdna:185]
The Company was in compliance with its debt covenants as of December 31, 2022. As of December 31, 2022, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-23-000016:mdna:186]
Acquisitions

[0000889331-23-000016:mdna:187]
On February 3, 2023, the Company acquired Western Automation for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. Western Automation has annualized sales of approximately $25 million and will be reported within the company’s Industrial segment. The company does not expect the acquisition to have a material impact to its 2023 financial results.The Company financed the transaction with cash on hand.

[0000889331-23-000016:mdna:188]
On July 19, 2022, the Company acquired C&K Switches for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, datacom, and aerospace. At the time the Company and C&K entered into a definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the electronics-passive products and sensors business within the Company's Electronics segment. The net cash payment of $523.0 million was funded through a combination of cash on hand and debt.

[0000889331-23-000016:mdna:189]
On November 30, 2021, the Company acquired Carling, pursuant to the Stock Purchase Agreement, dated as of October 19, 2021. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle electronification, communications infrastructure and marine markets. At the time of acquisition, Carling had annualized sales of approximately $170 million. The operations of Carling are included in the commercial vehicle business within the Company's Transportation segment. The purchase price for Carling Technologies was approximately $315 million subject to a working capital adjustment. The net cash payment of $314.1 million was funded by the Company’s cash on hand.

[0000889331-23-000016:mdna:190]
On January 28, 2021, the Company acquired Hartland, a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning ("HVAC") and other industrial and systems applications, and eMobility. At the time of acquisition, Hartland had annualized sales of approximately $70 million. The purchase price for Hartland was $111.0 million and the operations of Hartland are included in the Industrial segment. The net cash payment of $108.5 million was funded by the Company’s cash on hand.

[0000889331-23-000016:mdna:191]
Cash Flow Overview

[0000889331-23-000016:mdna:192]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes and other operating activities.

[0000889331-23-000016:mdna:193]
The following describes the Company’s cash flows for the fiscal year ended December 31, 2022 and January 1, 2022:

[0000889331-23-000016:mdna:194]
|  | Fiscal Year |
| (in millions) | 2022 |  | 2021 |
| Net cash provided by operating activities | $ | 419.7 |  |  | $ | 373.3 |  |
| Net cash used in investing activities | (636.4) |  |  | (499.2) |  |
| Net cash provided by (used in) financing activities | 310.2 |  |  | (69.0) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (11.4) |  |  | (9.9) |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash | 82.1 |  |  | (204.7) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 482.8 |  |  | 687.5 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 564.9 |  |  | $ | 482.8 |  |

[0000889331-23-000016:mdna:195]
Cash Flow from Operating Activities

[0000889331-23-000016:mdna:196]
Net cash provided by operating activities was $419.7 million for the fiscal year 2022, an increase of $46.4 million, compared to $373.3 million during the fiscal year 2021. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth and larger annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-23-000016:mdna:197]
Cash Flow from Investing Activities

[0000889331-23-000016:mdna:198]
Net cash used in investing activities was $636.4 million for the fiscal year 2022, compared to $499.2 million during the fiscal year 2021. Capital expenditures were $104.3 million, representing an increase of $13.8 million compared to the fiscal year 2021. Net cash paid for acquisitions was $532.7 million during the fiscal year 2022 primarily for the C&K and Embed acquisitions versus net cash paid of $422.1 million for the Carling and Hartland acquisitions during the fiscal year 2021. The Company also received proceeds of $0.7 million primarily from the sale of a property within the Transportation segment during the fiscal year 2022 as compared to proceeds of $15.4 million from the sale of buildings within the Electronics segment during the fiscal year 2021.

[0000889331-23-000016:mdna:199]
Cash Flow from Financing Activities

[0000889331-23-000016:mdna:200]
Net cash provided by financing activities was $310.2 million for the fiscal year 2022 compared to $69.0 million used in financing activities for the fiscal year 2021. On July 18, 2022, the Company issued and funded $100 million in aggregate principal amount of 4.33% U.S. Senior Notes, due 2032. On June 30, 2022, the Company amended and restated its Credit Agreement and borrowed $300.0 million through a term loan. During the fiscal year 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022 and $3.8 million on the term loan. During the fiscal year 2021, the Company made payments of $30 million on the amended revolving credit facility. Additionally, dividends paid by the Company increased $6.2 million from $49.7 million for the fiscal year 2021 to $55.9 million for the fiscal year 2022.

[0000889331-23-000016:mdna:201]
The following describes the Company’s cash flows for the twelve months ended January 1, 2022 and December 26, 2020:

[0000889331-23-000016:mdna:202]
|  | Fiscal Year |
| (in millions) | 2021 |  | 2020 |
| Net cash provided by operating activities | $ | 373.3 |  |  | $ | 258.0 |  |
| Net cash used in investing activities | (499.2) |  |  | (51.4) |  |
| Net cash used in financing activities | (69.0) |  |  | (67.8) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (9.9) |  |  | 17.6 |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash | (204.7) |  |  | 156.4 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 687.5 |  |  | 531.1 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 482.8 |  |  | $ | 687.5 |  |

[0000889331-23-000016:mdna:203]
Cash Flow from Operating Activities

[0000889331-23-000016:mdna:204]
Net cash provided by operating activities was $373.3 million for the fiscal year 2021, an increase of $115.3 million, compared to $258.0 million during the fiscal year 2020. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth.

[0000889331-23-000016:mdna:205]
Cash Flow from Investing Activities

[0000889331-23-000016:mdna:206]
Net cash used in investing activities was $499.2 million for the fiscal year 2021, compared to $51.4 million during the fiscal year 2020. Capital expenditures were $90.6 million, representing a decrease of $34.4 million compared to the fiscal year 2020. Net cash paid for the Hartland and Carling acquisitions was $422.1 million during the fiscal year 2021. The Company also received proceeds of $15.4 million from the sale of buildings within the Electronics segment during the fiscal year 2021 as compared to proceeds of $4.8 million as a result of the sale of a property within the Industrial segment during the fiscal year 2020.

[0000889331-23-000016:mdna:207]
Cash Flow from Financing Activities

[0000889331-23-000016:mdna:208]
Net cash used in financing activities was $69.0 million for the fiscal year 2021 compared to $67.8 million for the fiscal year 2020. The Company made payments of $30.0 million on the amended revolving credit facility during the fiscal year 2021. On March 25, 2020, the Company borrowed $100.0 million from its revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19.  On April 3, 2020, the Company amended the Credit Agreement to eliminate the $200.0 million unsecured term loan credit facility, with the remaining outstanding balance of $140.0 million repaid in full on April 3, 2020 through a new borrowing of $140.0 million under the amended revolving credit facility. The Company also made principal payments of $5.0 million on the term loan during fiscal year 2020 before amended the Credit Agreement. During the fiscal year 2020, the Company made payments of $110.0 million on the amended revolving credit facility. During the fiscal year 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million. Additionally, dividends paid increased $2.9 million from $46.8 million for the fiscal year 2020 to $49.7 million for the fiscal year 2021.

[0000889331-23-000016:mdna:209]
Contractual Obligations and Commitments

[0000889331-23-000016:mdna:210]
The following table summarizes outstanding contractual obligations and commitments as of December 31, 2022:

[0000889331-23-000016:mdna:211]
|  | Payments Due By Period |
| (in thousands) | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | Greaterthan 5 Years |
| Long-term debt(a) | $ | 1,006,344 |  |  | $ | 134,874 |  |  | $ | 81,590 |  |  | $ | 463,616 |  |  | $ | 326,264 |  |
| Interest payments(b) | 202,327 |  |  | 39,411 |  |  | 73,283 |  |  | 56,482 |  |  | 33,151 |  |
| Operating and finance lease payments(c) | 68,965 |  |  | 15,132 |  |  | 22,516 |  |  | 10,100 |  |  | 21,217 |  |
| Income tax obligation(d) | 19,754 |  |  | 5,000 |  |  | 14,754 |  |  | — |  |  | — |  |
| Purchase obligations(e) | 15,155 |  |  | 12,571 |  |  | 1,151 |  |  | 964 |  |  | 469 |  |
| Total | $ | 1,312,545 |  |  | $ | 206,988 |  |  | $ | 193,294 |  |  | $ | 531,162 |  |  | $ | 381,101 |  |

[0000889331-23-000016:mdna:212]
(a)Excludes offsetting issuance costs of $4.8 million. Euro denominated debt amounts are converted based on the Euro to U.S. Dollar spot rate at year end. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-23-000016:mdna:213]
(b)Amounts represent estimated contractual interest payments on outstanding debt. Rates in effect as of December 31, 2022 are used for variable rate debt. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-23-000016:mdna:214]
(c)For more information see Note 7, Lease Commitments, of the Notes to Consolidated Financial Statements.

[0000889331-23-000016:mdna:215]
(d)The Income tax obligation represents the remaining amounts payable regarding the 2017 Littelfuse Toll Charge. The Company has elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. For more information see Note 14, Income Taxes, of the Notes to Consolidated Financial Statements.

[0000889331-23-000016:mdna:216]
(e)Purchase obligations include purchase commitments and commitments for capital expenditures not recognized in the Company’s Consolidated Balance Sheets.

[0000889331-23-000016:mdna:217]
In addition to the above contractual obligations and commitments, the Company had the following obligations at December 31, 2022:

[0000889331-23-000016:mdna:218]
The Company has Company-sponsored defined benefit pension plans covering employees at various non-U.S. subsidiaries including the U.K., Germany, the Philippines, China, Japan, Mexico, Italy and France. At December 31, 2022, the Company had a net unfunded status of $29.1 million. The Company expects to make approximately $2.0 million of contributions to the plans in 2023. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0000889331-23-000016:mdna:219]
Dividends

[0000889331-23-000016:mdna:220]
Cash dividends paid totaled $55.9 million, $49.7 million and $46.8 million for 2022, 2021 and 2020, respectively. On February 1, 2023, the Board of Directors of the Company declared a quarterly cash dividend of $0.60 per share, payable on March 9, 2023 to stockholders of record as of February 23, 2023.

[0000889331-23-000016:mdna:221]
Capital Resources

[0000889331-23-000016:mdna:222]
The Company expends capital to support its operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0000889331-23-000016:mdna:223]
Share Repurchase Program

[0000889331-23-000016:mdna:224]
On April 29, 2020, the Company announced that the Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program"). On April 28, 2021, the Company announced that the Board of Directors authorized a new three-year program to repurchase up to $300 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program. There are $300 million in the aggregate of shares available for purchase under the new program as of December 31, 2022.

[0000889331-23-000016:mdna:225]
During the fiscal years of 2022 and 2021, the Company did not repurchase any shares of its common stock. During the fiscal year 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.

[0000889331-23-000016:mdna:226]
Off-Balance Sheet Arrangements

[0000889331-23-000016:mdna:227]
As of December 31, 2022, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-23-000016:mdna:228]
Recent Accounting Pronouncements

[0000889331-23-000016:mdna:229]
Recently issued accounting standards and their estimated effect on the Company’s Consolidated Financial Statements are described in Note 1, Summary of Significant Accounting Policies and Other Information, of the Notes to Consolidated Financial Statements.
