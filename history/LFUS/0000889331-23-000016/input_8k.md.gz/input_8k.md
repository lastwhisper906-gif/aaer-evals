# LFUS 8-K — 0000889331-23-000003 filed 2023-02-01

## item codes, every 8-K on or before 2023-02-16

- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2023-02-16

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-23-000003:8k_2_02:1]
EX-99.1
2
q42022ex991.htm
EX-99.1

[0000889331-23-000003:8k_2_02:2]
Document

[0000889331-23-000003:8k_2_02:3]
Exhibit 99.1

[0000889331-23-000003:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-23-000003:8k_2_02:5]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS FOR 2022

[0000889331-23-000003:8k_2_02:6]
Record annual sales, earnings and cash generation driven by resilient business model and growth strategy

[0000889331-23-000003:8k_2_02:7]
CHICAGO, February 1, 2023 - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the fourth quarter and full year ended December 31, 2022:

[0000889331-23-000003:8k_2_02:8]
Fourth Quarter 2022 Results

[0000889331-23-000003:8k_2_02:9]
•Net sales of $613.3 million were up 11% versus the prior year period, and up 4% organically

[0000889331-23-000003:8k_2_02:10]
•GAAP diluted EPS was $3.74, an increase of 80% from the prior year period; adjusted diluted EPS was $3.34, up 6% versus the prior year period

[0000889331-23-000003:8k_2_02:11]
Full Year 2022 Results

[0000889331-23-000003:8k_2_02:12]
•Net sales of $2.5 billion were up 21% in total versus the prior year, and up 11% organically

[0000889331-23-000003:8k_2_02:13]
•GAAP diluted EPS was $14.94, up 31% versus the prior year; adjusted diluted EPS of $16.87 increased 28% versus the prior year

[0000889331-23-000003:8k_2_02:14]
•Cash flow from operations was $419.7 million and free cash flow was $315.4 million, both 12% higher than the prior year

[0000889331-23-000003:8k_2_02:15]
“In 2022 we achieved record levels of sales, earnings and cash generation, including double-digit sales growth in each of our business segments,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “We achieved these outstanding results by continuing to expand our leadership in high-growth markets with significant new business wins and adding over $200 million in sales from two acquisitions. I want to thank our global teams for their hard work and persistent commitment to serve our customers. Our demonstrated ability to drive double-digit growth over the past five-, ten-, and fifteen-year periods speaks to the resiliency of our business model and the strength of our growth strategy. Though we may see some near-term market challenges, I am confident our ongoing execution, investments and diversification position us to deliver continued, substantial value to all of our stakeholders.”

[0000889331-23-000003:8k_2_02:16]
First Quarter of 2023*

[0000889331-23-000003:8k_2_02:17]
Based on current market conditions, for the first quarter the company expects,

[0000889331-23-000003:8k_2_02:18]
•Net sales in the range of $575 to $605 million, adjusted diluted EPS in the range of $2.73 to $2.97 and an adjusted effective tax rate of approximately 19%

[0000889331-23-000003:8k_2_02:19]
-more-

[0000889331-23-000003:8k_2_02:20]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-23-000003:8k_2_02:21]
Dividend

[0000889331-23-000003:8k_2_02:22]
•The company will pay a cash dividend on its common stock of $0.60 per share on March 9, 2023, to shareholders of record as of February 23, 2023

[0000889331-23-000003:8k_2_02:23]
Conference Call and Webcast Information

[0000889331-23-000003:8k_2_02:24]
Littelfuse will host a conference call on Thursday, February 2, 2023, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-23-000003:8k_2_02:25]
About Littelfuse

[0000889331-23-000003:8k_2_02:26]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-23-000003:8k_2_02:27]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse's accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 1, 2022.

[0000889331-23-000003:8k_2_02:28]
-more-

[0000889331-23-000003:8k_2_02:29]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended January 1, 2022, its Quarterly Report on Form 10-Q for the quarter ended October 1, 2022, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-23-000003:8k_2_02:30]
Non-GAAP Financial Measures

[0000889331-23-000003:8k_2_02:31]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-23-000003:8k_2_02:32]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-23-000003:8k_2_02:33]
The company believes that organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-23-000003:8k_2_02:34]
CONTACT: Trisha Tuntland

[0000889331-23-000003:8k_2_02:35]
Head of Investor Relations

[0000889331-23-000003:8k_2_02:36]
(773) 628-2163

[0000889331-23-000003:8k_2_02:37]
LFUS-F

[0000889331-23-000003:8k_2_02:38]
###

[0000889331-23-000003:8k_2_02:39]
LITTELFUSE, INC.

[0000889331-23-000003:8k_2_02:40]
CONSOLIDATED BALANCE SHEETS

[0000889331-23-000003:8k_2_02:41]
| (in thousands) | December 31, 2022 |  | January 1, 2022 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 562,588 |  |  | $ | 478,473 |  |
| Short-term investments | 84 |  |  | 28 |  |
| Trade receivables, less allowances of $83,562 and $59,232, respectively | 306,578 |  |  | 275,192 |  |
| Inventories | 547,690 |  |  | 445,671 |  |
| Prepaid income taxes and income taxes receivable | 7,215 |  |  | 2,035 |  |
| Prepaid expenses and other current assets | 87,641 |  |  | 68,812 |  |
| Total current assets | 1,511,796 |  |  | 1,270,211 |  |
| Net property, plant, and equipment | 481,110 |  |  | 437,889 |  |
| Intangible assets, net of amortization | 593,970 |  |  | 407,126 |  |
| Goodwill | 1,186,922 |  |  | 929,790 |  |
| Investments | 24,121 |  |  | 39,211 |  |
| Deferred income taxes | 14,367 |  |  | 13,127 |  |
| Right of use lease assets, net | 57,382 |  |  | 29,616 |  |
| Other assets | 34,066 |  |  | 24,734 |  |
| Total assets | $ | 3,903,734 |  |  | $ | 3,151,704 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 208,571 |  |  | $ | 222,039 |  |
| Accrued liabilities | 187,057 |  |  | 159,689 |  |
| Accrued income taxes | 41,793 |  |  | 27,905 |  |
| Current portion of long-term debt | 134,874 |  |  | 25,000 |  |
| Total current liabilities | 572,295 |  |  | 434,633 |  |
| Long-term debt, less current portion | 866,623 |  |  | 611,897 |  |
| Deferred income taxes | 100,230 |  |  | 81,289 |  |
| Accrued post-retirement benefits | 28,037 |  |  | 37,037 |  |
| Non-current lease liabilities | 45,661 |  |  | 22,305 |  |
| Other long-term liabilities | 79,510 |  |  | 71,023 |  |
| Total equity | 2,211,378 |  |  | 1,893,520 |  |
| Total liabilities and equity | $ | 3,903,734 |  |  | $ | 3,151,704 |  |

[0000889331-23-000003:8k_2_02:42]
LITTELFUSE, INC.

[0000889331-23-000003:8k_2_02:43]
CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-23-000003:8k_2_02:44]
(Unaudited)

[0000889331-23-000003:8k_2_02:45]
|  |  | Three Months Ended |  | Fiscal Year Ended |
| (in thousands, except per share data) |  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Net sales |  | $ | 613,251 |  |  | $ | 553,065 |  |  | $ | 2,513,897 |  |  | $ | 2,079,928 |  |
| Cost of sales |  | 384,726 |  |  | 353,573 |  |  | 1,506,984 |  |  | 1,308,002 |  |
| Gross profit |  | 228,525 |  |  | 199,492 |  |  | 1,006,913 |  |  | 771,926 |  |
| Selling, general, and administrative expenses |  | 85,993 |  |  | 75,667 |  |  | 344,813 |  |  | 275,457 |  |
| Research and development expenses |  | 26,806 |  |  | 19,747 |  |  | 95,602 |  |  | 65,940 |  |
| Amortization of intangibles |  | 15,812 |  |  | 11,121 |  |  | 55,695 |  |  | 42,729 |  |
| Restructuring, impairment, and other charges |  | 5,712 |  |  | 160 |  |  | 9,977 |  |  | 2,158 |  |
| Total operating expenses |  | 134,323 |  |  | 106,695 |  |  | 506,087 |  |  | 386,284 |  |
| Operating income |  | 94,202 |  |  | 92,797 |  |  | 500,826 |  |  | 385,642 |  |
| Interest expense |  | 9,147 |  |  | 4,626 |  |  | 26,216 |  |  | 18,527 |  |
| Foreign exchange (gain) loss |  | (15,692) |  |  | 8,843 |  |  | 24,359 |  |  | 17,158 |  |
| Other (income) expense, net |  | (2,582) |  |  | 19,799 |  |  | 7,207 |  |  | 8,932 |  |
| Income before income taxes |  | 103,329 |  |  | 59,529 |  |  | 443,044 |  |  | 341,025 |  |
| Income taxes |  | 10,025 |  |  | 7,585 |  |  | 69,738 |  |  | 57,219 |  |
| Net income |  | $ | 93,304 |  |  | $ | 51,944 |  |  | $ | 373,306 |  |  | $ | 283,806 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.77 |  |  | $ | 2.11 |  |  | $ | 15.09 |  |  | $ | 11.54 |  |
| Diluted |  | $ | 3.74 |  |  | $ | 2.08 |  |  | $ | 14.94 |  |  | $ | 11.38 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,758 |  |  | 24,660 |  |  | 24,734 |  |  | 24,603 |  |
| Diluted |  | 24,978 |  |  | 25,001 |  |  | 24,986 |  |  | 24,932 |  |
| Comprehensive income |  | 139,811 |  |  | 74,009 |  |  | 351,005 |  |  | 301,500 |  |

[0000889331-23-000003:8k_2_02:46]
LITTELFUSE, INC.

[0000889331-23-000003:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-23-000003:8k_2_02:48]
|  | Year Ended |
| (in thousands) | December 31, 2022 |  | January 1, 2022 |
| OPERATING ACTIVITIES |  |  |  |
| Net income | $ | 373,306 |  |  | $ | 283,806 |  |
| Adjustments to reconcile net income to net cash provided by operating activities | 188,871 |  |  | 147,276 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Trade receivables | (19,334) |  |  | (10,234) |  |
| Inventories | (89,235) |  |  | (104,555) |  |
| Accounts payable | (22,403) |  |  | 40,481 |  |
| Accrued liabilities and income taxes | (9,756) |  |  | 30,793 |  |
| Prepaid expenses and other assets | (1,731) |  |  | (14,223) |  |
| Net cash provided by operating activities | 419,718 |  |  | 373,344 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisitions of businesses, net of cash acquired | (532,670) |  |  | (423,633) |  |
| Purchases of property, plant, and equipment | (104,341) |  |  | (90,562) |  |
| Net proceeds from sale of property, plant, and equipment, and other | 676 |  |  | 15,425 |  |
| Other | (62) |  |  | (390) |  |
| Net cash used in investing activities | (636,397) |  |  | (499,160) |  |
| FINANCING ACTIVITIES |  |  |  |
| Net proceeds (payments) of credit facility and senior notes | 371,250 |  |  | (32,619) |  |
| Cash dividends paid | (55,911) |  |  | (49,730) |  |
| All other cash (used in) provided by financing activities | (5,137) |  |  | 13,365 |  |
| Net cash provided by (used in) financing activities | 310,202 |  |  | (68,984) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (11,420) |  |  | (9,889) |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash | 82,103 |  |  | (204,689) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 482,836 |  |  | 687,525 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 564,939 |  |  | $ | 482,836 |  |

[0000889331-23-000003:8k_2_02:49]
LITTELFUSE, INC.

[0000889331-23-000003:8k_2_02:50]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-23-000003:8k_2_02:51]
(Unaudited)

[0000889331-23-000003:8k_2_02:52]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2022 |  | 2021 |  |  |  | %Growth /(Decline) |  | 2022 |  | 2021 |  |  |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 371,193 |  |  | $ | 341,622 |  |  |  |  | 8.7 | % |  | $ | 1,492,819 |  |  | $ | 1,300,744 |  |  |  |  | 14.8 | % |
| Transportation |  | 167,874 |  |  | 141,796 |  |  |  |  | 18.4 | % |  | 716,140 |  |  | 528,058 |  |  |  |  | 35.6 | % |
| Industrial |  | 74,184 |  |  | 69,647 |  |  |  |  | 6.5 | % |  | 304,938 |  |  | 251,126 |  |  |  |  | 21.4 | % |
| Total net sales |  | $ | 613,251 |  |  | $ | 553,065 |  |  |  |  | 10.9 | % |  | $ | 2,513,897 |  |  | $ | 2,079,928 |  |  |  |  | 20.9 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 91,941 |  |  | $ | 79,350 |  |  |  |  | 15.9 | % |  | $ | 431,616 |  |  | $ | 309,633 |  |  |  |  | 39.4 | % |
| Transportation |  | 5,935 |  |  | 10,599 |  |  |  |  | (44.0) | % |  | 63,539 |  |  | 65,979 |  |  |  |  | (3.7) | % |
| Industrial |  | 8,885 |  |  | 4,169 |  |  |  |  | 113.1 | % |  | 48,853 |  |  | 22,621 |  |  |  |  | 116.0 | % |
| Other (a) |  | (12,559) |  |  | (1,321) |  |  |  |  | N.M. |  | (43,182) |  |  | (12,591) |  |  |  |  | N.M. |
| Total operating income |  | $ | 94,202 |  |  | $ | 92,797 |  |  |  |  | 1.5 | % |  | $ | 500,826 |  |  | $ | 385,642 |  |  |  |  | 29.9 | % |
| Operating Margin |  | 15.4 | % |  | 16.8 | % |  |  |  |  |  | 19.9 | % |  | 18.5 | % |  |  |  |  |
| Interest expense |  | 9,147 |  |  | 4,626 |  |  |  |  |  |  | 26,216 |  |  | 18,527 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (15,692) |  |  | 8,843 |  |  |  |  |  |  | 24,359 |  |  | 17,158 |  |  |  |  |  |
| Other (income) expense, net |  | (2,582) |  |  | 19,799 |  |  |  |  |  |  | 7,207 |  |  | 8,932 |  |  |  |  |  |
| Income before income taxes |  | $ | 103,329 |  |  | $ | 59,529 |  |  |  |  | 73.6 | % |  | $ | 443,044 |  |  | $ | 341,025 |  |  |  |  | 29.9 | % |

[0000889331-23-000003:8k_2_02:53]
(a)"other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-23-000003:8k_2_02:54]
N.M. - Not meaningful

[0000889331-23-000003:8k_2_02:55]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2022 |  | 2021 |  |  |  | %Growth /(Decline) |  | 2022 |  | 2021 |  |  |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 24.8 | % |  | 23.2 | % |  |  |  | 1.6 | % |  | 28.9 | % |  | 23.8 | % |  |  |  | 5.1 | % |
| Transportation |  | 3.5 | % |  | 7.5 | % |  |  |  | (4.0) | % |  | 8.9 | % |  | 12.5 | % |  |  |  | (3.6) | % |
| Industrial |  | 12.0 | % |  | 6.0 | % |  |  |  | 6.0 | % |  | 16.0 | % |  | 9.0 | % |  |  |  | 7.0 | % |

[0000889331-23-000003:8k_2_02:56]
LITTELFUSE, INC.

[0000889331-23-000003:8k_2_02:57]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-23-000003:8k_2_02:58]
(In millions of USD except per share amounts - unaudited)

[0000889331-23-000003:8k_2_02:59]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-22 |  | Q4-21 |  | YTD-22 |  | YTD-21 |
| GAAP diluted EPS |  | $ | 3.74 |  |  | $ | 2.08 |  |  | $ | 14.94 |  |  | $ | 11.38 |  |
| EPS impact of Non-GAAP adjustments (below) |  | (0.40) |  |  | 1.08 |  |  | 1.93 |  |  | 1.81 |  |
| Adjusted diluted EPS |  | $ | 3.34 |  |  | $ | 3.16 |  |  | $ | 16.87 |  |  | $ | 13.19 |  |

[0000889331-23-000003:8k_2_02:60]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q4-22 |  | Q4-21 |  | YTD-22 |  | YTD-21 |
| Acquisition-related and integration costs (a) |  | $ | 2.8 |  |  | $ | 3.6 |  |  | $ | 17.6 |  |  | $ | 7.0 |  |
| Purchase accounting inventory adjustments (b) |  | 4.0 |  |  | 1.6 |  |  | 15.6 |  |  | 8.4 |  |
| Restructuring, impairment and other charges (c) |  | 5.7 |  |  | 0.2 |  |  | 10.0 |  |  | 2.2 |  |
| Gain on sale of fixed assets (d) |  | — |  |  | (4.1) |  |  | — |  |  | (5.0) |  |
| Non-GAAP adjustments to operating income |  | 12.5 |  |  | 1.3 |  |  | 43.2 |  |  | 12.6 |  |
| Other expense (income), net (e) |  | — |  |  | 20.8 |  |  | (0.5) |  |  | 21.4 |  |
| Non-operating foreign exchange (gain) loss |  | (15.7) |  |  | 8.9 |  |  | 24.4 |  |  | 17.2 |  |
| Non-GAAP adjustments to income before income taxes |  | (3.2) |  |  | 31.0 |  |  | 67.1 |  |  | 51.2 |  |
| Income taxes (f) |  | 6.8 |  |  | 3.9 |  |  | 19.0 |  |  | 6.0 |  |
| Non-GAAP adjustments to net income |  | $ | (10.0) |  |  | $ | 27.1 |  |  | $ | 48.1 |  |  | $ | 45.2 |  |
| Total EPS impact |  | $ | (0.40) |  |  | $ | 1.08 |  |  | $ | 1.93 |  |  | $ | 1.81 |  |

[0000889331-23-000003:8k_2_02:61]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-22 |  | Q4-21 |  | YTD-22 |  | YTD-21 |
| Net sales |  | $ | 613.3 |  |  | $ | 553.1 |  |  | $ | 2,513.9 |  |  | $ | 2,079.9 |  |
| GAAP operating income |  | $ | 94.2 |  |  | $ | 92.8 |  |  | $ | 500.8 |  |  | $ | 385.6 |  |
| Add back non-GAAP adjustments |  | 12.5 |  |  | 1.3 |  |  | 43.2 |  |  | 12.6 |  |
| Adjusted operating income |  | $ | 106.7 |  |  | $ | 94.1 |  |  | $ | 544.0 |  |  | $ | 398.2 |  |
| Adjusted operating margin |  | 17.4 | % |  | 17.0 | % |  | 21.6 | % |  | 19.1 | % |
| Add back amortization |  | 15.8 |  |  | 11.1 |  |  | 55.7 |  |  | 42.7 |  |
| Add back depreciation |  | 16.7 |  |  | 14.5 |  |  | 65.0 |  |  | 55.9 |  |
| Adjusted EBITDA |  | $ | 139.2 |  |  | $ | 119.7 |  |  | $ | 664.7 |  |  | $ | 496.8 |  |
| Adjusted EBITDA margin |  | 22.7 | % |  | 21.6 | % |  | 26.4 | % |  | 23.9 | % |

[0000889331-23-000003:8k_2_02:62]
| Adjusted EBITDA by Segment |  | Q4-22 |  | Q4-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 91.9 |  |  | $ | 5.9 |  |  | $ | 8.9 |  |  | $ | 79.4 |  |  | $ | 10.6 |  |  | $ | 4.2 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 10.2 |  |  | 4.4 |  |  | 1.2 |  |  | 6.9 |  |  | 3.0 |  |  | 1.2 |  |
| Add back depreciation |  | 9.0 |  |  | 6.7 |  |  | 1.0 |  |  | 8.6 |  |  | 4.9 |  |  | 1.0 |  |
| Adjusted EBITDA |  | $ | 111.1 |  |  | $ | 17.0 |  |  | $ | 11.1 |  |  | $ | 94.9 |  |  | $ | 18.5 |  |  | $ | 6.4 |  |
| Adjusted EBITDA Margin |  | 29.9 | % |  | 10.1 | % |  | 14.9 | % |  | 27.8 | % |  | 13.0 | % |  | 9.1 | % |

[0000889331-23-000003:8k_2_02:63]
| Adjusted EBITDA by Segment |  | YTD-22 |  | YTD-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 431.6 |  |  | $ | 63.5 |  |  | $ | 48.9 |  |  | $ | 309.6 |  |  | $ | 66.0 |  |  | $ | 22.6 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 32.7 |  |  | 18.1 |  |  | 4.9 |  |  | $ | 27.9 |  |  | $ | 10.1 |  |  | $ | 4.7 |  |
| Add back depreciation |  | 35.5 |  |  | 25.6 |  |  | 3.9 |  |  | $ | 33.6 |  |  | $ | 18.9 |  |  | $ | 3.4 |  |
| Adjusted EBITDA |  | $ | 499.8 |  |  | $ | 107.2 |  |  | $ | 57.7 |  |  | $ | 371.1 |  |  | $ | 95.0 |  |  | $ | 30.7 |  |
| Adjusted EBITDA Margin |  | 33.5 | % |  | 15.0 | % |  | 18.9 | % |  | 28.5 | % |  | 18.0 | % |  | 12.2 | % |

[0000889331-23-000003:8k_2_02:64]
| Net sales reconciliation |  | Q4-22 vs. Q4-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 9 | % |  | 18 | % |  | 7 | % |  | 11 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 13 | % |  | 22 | % |  | — | % |  | 14 | % |
| 53rd week of extra sales in fiscal year 2021 |  | (3) | % |  | (4) | % |  | (5) | % |  | (3) | % |
| FX impact |  | (3) | % |  | (6) | % |  | (1) | % |  | (4) | % |
| Organic net sales growth |  | 2 | % |  | 6 | % |  | 13 | % |  | 4 | % |

[0000889331-23-000003:8k_2_02:65]
| Net sales reconciliation |  | YTD-22 vs. YTD-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 15 | % |  | 36 | % |  | 21 | % |  | 21 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 7 | % |  | 40 | % |  | 4 | % |  | 14 | % |
| 53rd week of extra sales in fiscal year 2021 |  | (1) | % |  | (1) | % |  | (2) | % |  | (1) | % |
| FX impact |  | (3) | % |  | (5) | % |  | (1) | % |  | (3) | % |
| Organic net sales growth |  | 12 | % |  | 2 | % |  | 20 | % |  | 11 | % |

[0000889331-23-000003:8k_2_02:66]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-22 |  | Q4-21 |  | YTD-22 |  | YTD-21 |
| Income taxes |  | $ | 10.0 |  |  | $ | 7.6 |  |  | $ | 69.7 |  |  | $ | 57.2 |  |
| Effective rate |  | 9.7 | % |  | 12.7 | % |  | 15.7 | % |  | 16.8 | % |
| Non-GAAP adjustments - income taxes |  | 6.8 |  |  | 3.9 |  |  | 19.0 |  |  | 6.0 |  |
| Adjusted income taxes |  | $ | 16.8 |  |  | $ | 11.5 |  |  | $ | 88.7 |  |  | $ | 63.2 |  |
| Adjusted effective rate |  | 16.8 | % |  | 12.7 | % |  | 17.4 | % |  | 16.1 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-22 |  | Q4-21 |  | YTD-22 |  | YTD-21 |
| Net cash provided by operating activities |  | $ | 106.3 |  |  | $ | 132.6 |  |  | $ | 419.7 |  |  | $ | 373.3 |  |
| Less: Purchases of property, plant and equipment |  | (26.5) |  |  | (33.0) |  |  | (104.3) |  |  | (90.6) |  |
| Free cash flow |  | $ | 79.8 |  |  | $ | 99.6 |  |  | $ | 315.4 |  |  | $ | 282.7 |  |

[0000889331-23-000003:8k_2_02:67]
| Consolidated Total Debt |  | As of December 31, 2022 |
| Consolidated Total Debt |  | $ | 1,001.5 |  |
| Unamortized debt issuance costs |  | 4.8 |  |
| Finance lease liability |  | $ | 1.8 |  |
| Consolidated funded indebtedness |  | $ | 1,008.1 |  |
| Cash held in U.S. (up to $400 million) |  | $ | 110.6 |  |
| Net debt |  | $ | 897.5 |  |
| Consolidated EBITDA |  | Twelve Months EndedDecember 31, 2022 |
| Net Income |  | $ | 373.3 |  |
| Interest expense |  | 26.2 |  |
| Income taxes |  | 69.7 |  |
| Depreciation |  | 65.0 |  |
| Amortization |  | 55.7 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 23.6 |  |
| Purchase accounting inventory step-up charge |  | 15.6 |  |
| Unrealized loss on investments |  | 14.0 |  |
| Impairment charges |  | 4.5 |  |
| Other |  | 81.9 |  |
| Consolidated EBITDA (1) |  | $ | 729.5 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.2x |

[0000889331-23-000003:8k_2_02:68]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2023 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-23-000003:8k_2_02:69]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-23-000003:8k_2_02:70]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-23-000003:8k_2_02:71]
Note: Total will not always foot due to rounding.

[0000889331-23-000003:8k_2_02:72]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-23-000003:8k_2_02:73]
(b) reflected in cost of sales.

[0000889331-23-000003:8k_2_02:74]
(c) reflected in restructuring, impairment and other charges.

[0000889331-23-000003:8k_2_02:75]
(d) reflected a gain of $4.1 million recorded in SG&A during the fourth quarter of 2021 for a total year-to-date gain of $5.0 million from the sale of two buildings within the Electronics segment during 2021.

[0000889331-23-000003:8k_2_02:76]
(e) 2022 year-to-date amount included $0.5 million gain from the sale of a building within the Transportation segment. Q4 2021 included a $19.9 million non-cash pension settlement charge, a $0.7 million charge for an asset retirement obligation related to the disposal of a business in 2019 and a $0.2 million increase in coal mining reserves. 2021 year-to-date amount also included $0.5 million of impairment charges on certain other investments.

[0000889331-23-000003:8k_2_02:77]
(f) reflected the tax impact associated with the non-GAAP adjustments.
