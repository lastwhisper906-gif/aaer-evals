# LFUS MD&A — 0000889331-23-000131


## mdna

[0000889331-23-000131:mdna:1]
[same as prior period, unchanged from 0000889331-23-000095:mdna:1]

[0000889331-23-000131:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-23-000131:mdna:3]
[same as prior period, unchanged from 0000889331-23-000095:mdna:3]

[0000889331-23-000131:mdna:4]
[same as prior period, unchanged from 0000889331-23-000095:mdna:4]

[0000889331-23-000131:mdna:5]
[same as prior period, unchanged from 0000889331-23-000095:mdna:5]

[0000889331-23-000131:mdna:6]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-23-000131:mdna:7]
[same as prior period, unchanged from 0000889331-23-000095:mdna:7]

[0000889331-23-000131:mdna:8]
[same as prior period, unchanged from 0000889331-23-000095:mdna:8]

[0000889331-23-000131:mdna:9]
For the second quarter of 2023, the Company recognized net sales of $612.0 million, a decrease of $6.4 million, or 1.0% as compared to $618.4 million in the second quarter of 2022 including $0.5 million or 0.1% of unfavorable changes in foreign exchange rates. The decrease in net sales was due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment that more than offset $40.0 million or 6.5% and $4.8 million or 0.8% of incremental net sales from the C&K and Western Automation acquisitions, respectively, and higher volume in the Industrial segment. The Company recognized net income of $70.1 million, or $2.79 per diluted share, in the second quarter of 2023 compared to $87.0 million, or $3.48 per diluted share in the second quarter of 2022. The decrease in net income was primarily due to a decrease in operating income in the Electronics and Transportation segments driven by lower volume.

[0000889331-23-000131:mdna:10]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the fab is approximately 93 million Euro, of which approximately 37 million Euro will be paid after regulatory approvals and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2023 or 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-23-000131:mdna:11]
[same as prior period, unchanged from 0000889331-23-000095:mdna:10]

[0000889331-23-000131:mdna:12]
Net cash provided by operating activities was $151.6 million for the six months ended July 1, 2023 compared to $165.3 million for the six months ended July 2, 2022. The decrease in net cash provided by operating activities was primarily due to lower cash earnings, partially offset by reductions in working capital.

[0000889331-23-000131:mdna:13]
[same as prior period, unchanged from 0000889331-23-000095:mdna:12]

[0000889331-23-000131:mdna:14]
The Company continues to operate in a challenging macro environment, including but not limited to, supply chain disruptions, varying regional dynamics, and some pockets of end market softness. The ongoing war in Ukraine has had a modest impact on the Company, as the Company suspended sales into and purchases from Russia. The Company does not have any direct operations in Ukraine or Russia.

[0000889331-23-000131:mdna:15]
[same as prior period, unchanged from 0000889331-23-000095:mdna:14]

[0000889331-23-000131:mdna:16]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The second quarter of 2023 includes $3.9 million ($7.2 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $2.9 million ($4.8 million year-to-date) of restructuring charges, primarily related to employee termination costs. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000131:mdna:17]
The second quarter of 2022 includes $4.8 million ($8.6 million year-to-date) of legal and professional fees primarily related to the acquisition of C&K and other integration expenses related to completed and contemplated acquisitions, and $0.6 million ($0.8 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs, and $4.8 million year-to-date of purchase accounting inventory step-up charges. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000131:mdna:18]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  | 2023 |  | 2022 |  | Change |  | %Change |
| Net sales |  | $ | 611,997 |  |  | $ | 618,436 |  |  | $ | (6,439) |  |  | (1.0) | % |  | $ | 1,221,779 |  |  | $ | 1,241,766 |  |  | $ | (19,987) |  |  | (1.6) | % |
| Cost of sales |  | 377,165 |  |  | 355,465 |  |  | 21,700 |  |  | 6.1 | % |  | 741,990 |  |  | 720,199 |  |  | 21,791 |  |  | 3.0 | % |
| Gross profit |  | 234,832 |  |  | 262,971 |  |  | (28,139) |  |  | (10.7) | % |  | 479,789 |  |  | 521,567 |  |  | (41,778) |  |  | (8.0) | % |
| Operating expenses |  | 142,779 |  |  | 128,807 |  |  | 13,972 |  |  | 10.8 | % |  | 277,095 |  |  | 236,813 |  |  | 40,282 |  |  | 17.0 | % |
| Operating income |  | 92,053 |  |  | 134,164 |  |  | (42,111) |  |  | (31.4) | % |  | 202,694 |  |  | 284,754 |  |  | (82,060) |  |  | (28.8) | % |
| Income before income taxes |  | 85,451 |  |  | 109,612 |  |  | (24,161) |  |  | (22.0) | % |  | 194,354 |  |  | 243,737 |  |  | (49,383) |  |  | (20.3) | % |
| Income taxes |  | 15,380 |  |  | 22,596 |  |  | (7,216) |  |  | (31.9) | % |  | 35,538 |  |  | 39,203 |  |  | (3,665) |  |  | (9.3) | % |
| Net income |  | $ | 70,071 |  |  | $ | 87,016 |  |  | $ | (16,945) |  |  | (19.5) | % |  | $ | 158,816 |  |  | $ | 204,534 |  |  | $ | (45,718) |  |  | (22.4) | % |

[0000889331-23-000131:mdna:19]
[same as prior period, unchanged from 0000889331-23-000095:mdna:18]

[0000889331-23-000131:mdna:20]
Net sales decreased $6.4 million, or 1.0%, for the second quarter of 2023 compared to the second quarter of 2022 including $0.5 million or 0.1% of unfavorable changes in foreign exchange rates. The sales decrease was due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment that more than offset $40.0 million or 6.5% and $4.8 million or 0.8% of incremental net sales associated with the C&K and Western Automation acquisitions included in the Electronics and Industrial segments, respectively, and higher volume from the Industrial segment.

[0000889331-23-000131:mdna:21]
Net sales decreased $20.0 million, or 1.6%, for the first six months of 2023 compared to the first six months of 2022, including $10.4 million or 0.8% of unfavorable changes in foreign exchange rates. The sales decrease was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment that more than offset $82.5 million or 6.6% and $7.5 million or 0.6% incremental net sales associated with the C&K and Western Automation acquisitions included in the Electronics and Industrial segments, respectively, and higher volume from the Industrial segment.

[0000889331-23-000131:mdna:22]
[same as prior period, unchanged from 0000889331-23-000095:mdna:20]

[0000889331-23-000131:mdna:23]
Cost of sales was $377.2 million, or 61.6% of net sales, in the second quarter of 2023, compared to $355.5 million, or 57.5% of net sales, in the second quarter of 2022. As a percent of net sales, cost of sales increased 4.1% driven by lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment.

[0000889331-23-000131:mdna:24]
Cost of sales was $742.0 million, or 60.7% of net sales, in the first six months of 2023, compared to $720.2 million, or 58.0% of net sales, in the first six months of 2022. As a percent of net sales, cost of sales increased 2.7% driven by lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by volume leverage, and favorable product mix from the Industrial segment.

[0000889331-23-000131:mdna:25]
[same as prior period, unchanged from 0000889331-23-000095:mdna:22]

[0000889331-23-000131:mdna:26]
Gross profit was $234.8 million, or 38.4% of net sales, in the second quarter of 2023 compared to $263.0 million, or 42.5% of net sales, for the second quarter of 2022. The $28.1 million decrease in gross profit was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by the acquisition of C&K within Electronics segment.

[0000889331-23-000131:mdna:27]
Gross profit was $479.8 million, or 39.3% of net sales, in the first six months of 2023 compared to $521.6 million, or 42.0% of net sales, for the first six months of 2022. The $41.8 million decrease in gross profit was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by the acquisition of C&K within Electronics segment, and volume leverage and favorable product mix from the Industrial segment and $4.8 million or 0.4% of purchase accounting inventory charges recorded during the first six months of 2022.

[0000889331-23-000131:mdna:28]
[same as prior period, unchanged from 0000889331-23-000095:mdna:24]

[0000889331-23-000131:mdna:29]
Operating expenses were $142.8 million, or 23.3% of net sales, for the second quarter of 2023 compared to $128.8 million, or 20.8% of net sales, for the second quarter of 2022. The increase in operating expenses of $14.0 million was primarily due to higher restructuring, impairment, and other charges of $6.2 million, including a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment, and higher amortization, selling, general, and administrative, and research and development expenses of $5.3 million, $1.5 million, and $1.0 million, respectively  mainly due to the C&K and Western Automation acquisitions. This increase in operating expenses was partially offset by lower variable incentive compensation expense.

[0000889331-23-000131:mdna:30]
Operating expenses were $277.1 million, or 22.7% of net sales, for the first six months of 2023 compared to $236.8 million, or 19.1%of net sales, for the first six months of 2022. The increase in operating expenses of $40.3 million was primarily due to  higher selling, general, and administrative expenses of $14.3 million, higher amortization expense of $9.4 million and research and development expenses of $8.7 million mainly due to the C&K and Western Automation acquisitions, and higher restructuring, impairment, and other charges of $7.9 million, including a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. This increase in operating expenses was partially offset by lower variable incentive compensation expense.

[0000889331-23-000131:mdna:31]
[same as prior period, unchanged from 0000889331-23-000095:mdna:26]

[0000889331-23-000131:mdna:32]
Operating income was $92.1 million, representing a decrease of $42.1 million, or 31.4%, for the second quarter of 2023 compared to $134.2 million for the second quarter of 2022. The decrease in operating income was due to lower gross profit from the Electronics and Transportation segments and higher operating expenses as noted above. Operating margins decreased from 21.7% in the second quarter of 2022 to 15.0% in the second quarter of 2023 driven by lower volume in the Electronics and Transportation segments and the higher operating expenses mentioned above.

[0000889331-23-000131:mdna:33]
Operating income was $202.7 million, representing a decrease of $82.1 million, or 28.8%, for the first six months of 2023 compared to $284.8 million for the first six months of 2022. The decrease in operating income was due to lower gross profit from the Electronics and Transportation segments and higher operating expenses as noted above. Operating margins decreased from 22.9% in the first six months of 2022 to 16.6% in the first six months of 2023 driven by lower volume in the Electronics and Transportation segments and the higher operating expenses mentioned above.

[0000889331-23-000131:mdna:34]
[same as prior period, unchanged from 0000889331-23-000095:mdna:28]

[0000889331-23-000131:mdna:35]
Income before income taxes was $85.5 million, or 14.0% of net sales, for the second quarter of 2023 compared to $109.6 million, or 17.7% of net sales, for the second quarter of 2022. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange gains of $1.4 million in the second quarter of 2023 compared to foreign exchange losses of $14.1 million during the second quarter of 2022 and lower unrealized losses of $6.7 million compared to the second quarter of 2022 related to one of the Company's equity investments.

[0000889331-23-000131:mdna:36]
Income before income taxes was $194.4 million, or 15.9% of net sales, for the first six months of 2023 compared to $243.7 million, or 19.6% of net sales, for the first six months of 2022. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange gains of $3.1 million during the six months ended July 1, 2023 compared to foreign exchange losses of $21.9 million during the six months ended July 2, 2022, unrealized gains of $0.7 million during the six months ended July 1, 2023 compared to unrealized losses of $12.5 million during the six months ended July 2, 2022 related to one of  the Company's equity investments.

[0000889331-23-000131:mdna:37]
[same as prior period, unchanged from 0000889331-23-000095:mdna:31]

[0000889331-23-000131:mdna:38]
Income tax expense for the second quarter of 2023 was $15.4 million, or an effective tax rate of 18.0%, compared to $22.6 million, or an effective tax rate of 20.6%, for the second quarter of 2022. The effective tax rate for the second quarter of 2023 is lower than the effective tax rate for the comparable 2022 period, primarily due to the impact of foreign exchange losses with no related tax benefit in the 2022 period.

[0000889331-23-000131:mdna:39]
Income tax expense for the first six months of 2023 was $35.5 million, or an effective tax rate of 18.3%, compared to $39.2 million, or an effective tax rate of 16.1%, for the first six months of 2022. The effective tax rate for the first six months of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to the impact of a one-time deduction in the first quarter of 2022 that resulted in a net benefit of $7.2 million from the dissolution of one of the Company’s affiliates. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in

[0000889331-23-000131:mdna:40]
lower tax jurisdictions, while for the 2022 period, the effective tax rate was also lower due to the impact of the one-time deduction previously noted.

[0000889331-23-000131:mdna:41]
[same as prior period, unchanged from 0000889331-23-000095:mdna:33]

[0000889331-23-000131:mdna:42]
[same as prior period, unchanged from 0000889331-23-000095:mdna:34]

[0000889331-23-000131:mdna:43]
[same as prior period, unchanged from 0000889331-23-000095:mdna:35]

[0000889331-23-000131:mdna:44]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  | 2023 |  | 2022 |  | Change |  | %Change |
| Electronics |  | $ | 350,147 |  |  | $ | 358,176 |  |  | $ | (8,029) |  |  | (2.2) | % |  | $ | 708,740 |  |  | $ | 723,997 |  |  | $ | (15,257) |  |  | (2.1) | % |
| Transportation |  | 172,048 |  |  | 182,027 |  |  | (9,979) |  |  | (5.5) | % |  | 338,689 |  |  | 366,531 |  |  | (27,842) |  |  | (7.6) | % |
| Industrial |  | 89,802 |  |  | 78,233 |  |  | 11,569 |  |  | 14.8 | % |  | 174,350 |  |  | 151,238 |  |  | 23,112 |  |  | 15.3 | % |
| Total |  | $ | 611,997 |  |  | $ | 618,436 |  |  | $ | (6,439) |  |  | (1.0) | % |  | $ | 1,221,779 |  |  | $ | 1,241,766 |  |  | $ | (19,987) |  |  | (1.6) | % |

[0000889331-23-000131:mdna:45]
[same as prior period, unchanged from 0000889331-23-000095:mdna:37]

[0000889331-23-000131:mdna:46]
Net sales decreased $8.0 million, or 2.2%, in the second quarter of 2023 compared to the second quarter of 2022 and included unfavorable changes in foreign exchange rates of $0.1 million. The sales decrease was mainly due to lower volume from the Electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, and telecom, which more than offset the incremental net sales of $40.0 million from the C&K acquisition and $1.4 million of higher volume from the semiconductor business driven by increased demand predominantly in our industrial and medical end markets.

[0000889331-23-000131:mdna:47]
Net sales decreased $15.3 million, or 2.1%, in the first six months of 2023 compared to the first six months quarter of 2022 and included unfavorable changes in foreign exchange rates of $4.9 million. The sales decrease was mainly due to lower volume from the Electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, and telecom, which more than offset the incremental net sales of $82.5 million from the C&K acquisition and $15.5 million of higher volume from the semiconductor business driven by increased demand predominantly in our industrial and medical end markets.

[0000889331-23-000131:mdna:48]
[same as prior period, unchanged from 0000889331-23-000095:mdna:39]

[0000889331-23-000131:mdna:49]
Net sales decreased $10.0 million, or 5.5%, in the second quarter of 2023 compared to the second quarter of 2022 and included unfavorable changes in foreign exchange rates of $0.2 million. The sale decrease was mainly from the commercial vehicle business which had net sales decline of $15.7 million driven by reduced demand largely due to inventory rebalancing at certain distributors and customers, and some demand reduction in commercial vehicle end markets, partially offset by an increase of $6.1 million from the passenger car products business driven by global car build growth, as well as the ongoing electronification and electrification of vehicles.

[0000889331-23-000131:mdna:50]
Net sales decreased $27.8 million, or 7.6%, in the first six months of 2023 compared to the first six months of 2022 and included unfavorable changes in foreign exchange rates of $4.9 million. The commercial vehicle business net sales declined $25.4 million driven by reduced demand largely due to inventory rebalancing at certain distributors and customers, and some demand reduction in commercial vehicle end markets, partially offset by an increase of $3.3 million from the passenger car products business driven by the ongoing electronification and electrification of vehicles. The automotive sensors business had net sales declines of $5.7 million primarily due to lower demand in China.

[0000889331-23-000131:mdna:51]
[same as prior period, unchanged from 0000889331-23-000095:mdna:41]

[0000889331-23-000131:mdna:52]
Net sales increased by $11.6 million, or 14.8%, in the second quarter of 2023 compared to the second quarter of 2022, which included unfavorable changes in foreign exchange rates of $0.2 million. The sales increase was primarily due to higher growth across various markets including construction/MRO, renewables and industrial safety end markets, and the acquisition of Western Automation which contributed net sales of $4.8 million.

[0000889331-23-000131:mdna:53]
Net sales increased by $23.1 million, or 15.3%, in the first six months of 2023 compared to the first six months of 2022, which included unfavorable changes in foreign exchange rates of $0.6 million. The sales increase was primarily due to higher volume in the construction/MRO, renewables, and industrial safety end markets, and the acquisition of Western Automation which contributed net sales of $7.5 million.

[0000889331-23-000131:mdna:54]
[same as prior period, unchanged from 0000889331-23-000095:mdna:43]

[0000889331-23-000131:mdna:55]
[same as prior period, unchanged from 0000889331-23-000095:mdna:44]

[0000889331-23-000131:mdna:56]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  | 2023 |  | 2022 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 229,691 |  |  | $ | 252,809 |  |  | $ | (23,118) |  |  | (9.1) | % |  | $ | 457,703 |  |  | $ | 513,027 |  |  | $ | (55,324) |  |  | (10.8) | % |
| Americas |  | 227,896 |  |  | 247,591 |  |  | (19,695) |  |  | (8.0) | % |  | 461,750 |  |  | 484,821 |  |  | (23,071) |  |  | (4.8) | % |
| Europe |  | 154,410 |  |  | 118,036 |  |  | 36,374 |  |  | 30.8 | % |  | 302,326 |  |  | 243,918 |  |  | 58,408 |  |  | 23.9 | % |
| Total |  | $ | 611,997 |  |  | $ | 618,436 |  |  | $ | (6,439) |  |  | (1.0) | % |  | $ | 1,221,779 |  |  | $ | 1,241,766 |  |  | $ | (19,987) |  |  | (1.6) | % |

[0000889331-23-000131:mdna:57]
[same as prior period, unchanged from 0000889331-23-000095:mdna:46]

[0000889331-23-000131:mdna:58]
Net sales decreased $23.1 million, or 9.1%, in the second quarter of 2023 compared to the second quarter of 2022 and included unfavorable changes in foreign exchange rates of $2.7 million. The decrease in net sales was primarily due to lower net sales across all businesses within the Electronics segment and lower net sales from the commercial vehicle business within the Transportation segments, partially offset by incremental sales from the acquisition of C&K.

[0000889331-23-000131:mdna:59]
Net sales decreased $55.3 million, or 10.8%, in the first six months of 2023 compared to the first six months of 2022 and included unfavorable changes in foreign exchange rates of $6.6 million. The decrease in net sales was primarily due to lower net sales from electronics products business within the Electronics segment and lower net sales from the commercial vehicle and automotive sensors businesses within the Transportation segments, partially offset by incremental sales from the acquisition of C&K.

[0000889331-23-000131:mdna:60]
[same as prior period, unchanged from 0000889331-23-000095:mdna:48]

[0000889331-23-000131:mdna:61]
Net sales decreased $19.7 million, or 8.0%, in the second quarter of 2023 compared to the second quarter of 2022 and included unfavorable changes in foreign exchange rates of $0.1 million. The decrease in net sales was primarily due to lower volume from the Electronics products business within the Electronics segment and lower volume from the commercial vehicle business within the Transportation segment, partially offset by incremental sales from C&K acquisition within the Electronics segment, and higher sales within the Industrial segment compared to the second quarter of 2022.

[0000889331-23-000131:mdna:62]
Net sales decreased $23.1 million, or 4.8%, in the first six months of 2023 compared to the first six months of 2022 and included unfavorable changes in foreign exchange rates of $0.4 million. The decrease in net sales was primarily due to lower volume from the Electronics products business within the Electronics segment and lower sales across all businesses within the Transportation segment, partially offset by incremental sales from C&K acquisition within the Electronics segment and higher sales within the Industrial segment compared to the first six months of 2022.

[0000889331-23-000131:mdna:63]
[same as prior period, unchanged from 0000889331-23-000095:mdna:50]

[0000889331-23-000131:mdna:64]
Net sales increased $36.4 million, or 30.8%, in the second quarter of 2023 compared to the second quarter of 2022 and included favorable changes in foreign exchange rates of $2.3 million. The increase in net sales was primarily due to incremental sales from the acquisition of C&K, increased volume from the semiconductor business within the Electronics segment and the passenger car products business within the Transportation segment, and incremental sales from the Western Automation acquisition included within the Industrial segment compared to the second quarter of 2022.

[0000889331-23-000131:mdna:65]
Net sales increased $58.4 million, or 23.9%, in the first six months of 2023 compared to the first six months of 2022 and included unfavorable changes in foreign exchange rates of $3.4 million. The increase in net sales was primarily due to incremental sales from the acquisition of C&K, increased volume from the semiconductor business within the Electronics

[0000889331-23-000131:mdna:66]
segment, and incremental sales from the Western Automation acquisition included within the Industrial segment compared to the first six months of 2022, partially offset by lower net sales from the Electronics products business within the Electronics segment.

[0000889331-23-000131:mdna:67]
[same as prior period, unchanged from 0000889331-23-000095:mdna:52]

[0000889331-23-000131:mdna:68]
[same as prior period, unchanged from 0000889331-23-000095:mdna:53]

[0000889331-23-000131:mdna:69]
Cash and cash equivalents were $480.7 million as of July 1, 2023, a decrease of $81.8 million as compared to December 31, 2022. As of July 1, 2023, $127.4 million of the Company's $480.7 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-23-000131:mdna:70]
Revolving Credit Facility and Term Loan

[0000889331-23-000131:mdna:71]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000131:mdna:72]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000131:mdna:73]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended July 1, 2023, the Company made payments of $1.9 million and $3.8 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $292.5 million, respectively, as of July 1, 2023.

[0000889331-23-000131:mdna:74]
[same as prior period, unchanged from 0000889331-23-000095:mdna:59]

[0000889331-23-000131:mdna:75]
As of July 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.45%.

[0000889331-23-000131:mdna:76]
As of July 1, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of July 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-23-000131:mdna:77]
[same as prior period, unchanged from 0000889331-23-000095:mdna:62]

[0000889331-23-000131:mdna:78]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes

[0000889331-23-000131:mdna:79]
occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-23-000131:mdna:80]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-23-000131:mdna:81]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000131:mdna:82]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000131:mdna:83]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-23-000131:mdna:84]
Debt Covenants

[0000889331-23-000131:mdna:85]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of July 1, 2023 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2023. As of July 1, 2023, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-23-000131:mdna:86]
[same as prior period, unchanged from 0000889331-23-000095:mdna:70]

[0000889331-23-000131:mdna:87]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the fab is approximately 93 million Euro, of which approximately 37 million Euro will be paid after regulatory approvals and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2023 or 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-23-000131:mdna:88]
[same as prior period, unchanged from 0000889331-23-000095:mdna:71]

[0000889331-23-000131:mdna:89]
[same as prior period, unchanged from 0000889331-23-000095:mdna:72]

[0000889331-23-000131:mdna:90]
During the second quarter of 2023 the Company paid quarterly dividends of $14.9 million to the shareholders. On August 1, 2023, the Company announced the declaration of a quarterly cash dividend of $0.65 per share, a 8% increase from the first quarter, payable on September 7, 2023 to stockholders of record as of August 24, 2023.

[0000889331-23-000131:mdna:91]
[same as prior period, unchanged from 0000889331-23-000095:mdna:74]

[0000889331-23-000131:mdna:92]
|  |  | First Six Months |
| (in thousands) |  | 2023 |  | 2022 |
| Net cash provided by operating activities |  | $ | 151,633 |  |  | $ | 165,322 |  |
| Net cash used in investing activities |  | (199,020) |  |  | (65,367) |  |
| Net cash (used in) provided by financing activities |  | (32,686) |  |  | 245,017 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (1,772) |  |  | (15,511) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (81,845) |  |  | 329,461 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 564,939 |  |  | 482,836 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 483,094 |  |  | $ | 812,297 |  |

[0000889331-23-000131:mdna:93]
[same as prior period, unchanged from 0000889331-23-000095:mdna:76]

[0000889331-23-000131:mdna:94]
[same as prior period, unchanged from 0000889331-23-000095:mdna:77]

[0000889331-23-000131:mdna:95]
Net cash provided by operating activities was $151.6 million for the six months ended July 1, 2023 compared to $165.3 million for the six months ended July 2, 2022. The decrease in net cash provided by operating activities was primarily due to lower cash earnings, partially offset by reductions in working capital.

[0000889331-23-000131:mdna:96]
[same as prior period, unchanged from 0000889331-23-000095:mdna:79]

[0000889331-23-000131:mdna:97]
Net cash used in investing activities was $199.0 million for the six months ended July 1, 2023 compared to $65.4 million during the six months ended July 2, 2022. Net cash paid for acquisitions was $158.3 million and $9.8 million during the six months ended July 1, 2023 and July 2, 2022, respectively. Capital expenditures were $41.5 million, representing a decrease of $14.7 million compared to six months ended July 2, 2022. During the six months ended July 1, 2023 and July 2, 2022, the Company received proceeds of $0.7 million from the sale of a property within the Electronics segment, and $0.5 million from the sale of a property within the Transportation segment, respectively.

[0000889331-23-000131:mdna:98]
[same as prior period, unchanged from 0000889331-23-000095:mdna:81]

[0000889331-23-000131:mdna:99]
Net cash used in financing activities was $32.7 million for the six months ended July 1, 2023 compared to net cash provided by financing activities of $245.0 million for the six months ended July 2, 2022. On June 30, 2022, the Company amended its Credit Agreement and borrowed $300.0 million through a term loan. During the six months ended July 1, 2023, the Company made payments of $3.8 million on the term loan. During the six months ended July 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022. Additionally, the Company paid dividends of $29.8 million and $26.2 million in the six months ended July 1, 2023 and July 2, 2022, respectively.

[0000889331-23-000131:mdna:100]
[same as prior period, unchanged from 0000889331-23-000095:mdna:83]

[0000889331-23-000131:mdna:101]
[same as prior period, unchanged from 0000889331-23-000095:mdna:84]

[0000889331-23-000131:mdna:102]
The Company did not repurchase shares of its common stock for the three and six months ended July 1, 2023, and July 2, 2022.

[0000889331-23-000131:mdna:103]
[same as prior period, unchanged from 0000889331-23-000095:mdna:86]

[0000889331-23-000131:mdna:104]
As of July 1, 2023, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-23-000131:mdna:105]
[same as prior period, unchanged from 0000889331-23-000095:mdna:88]

[0000889331-23-000131:mdna:106]
[same as prior period, unchanged from 0000889331-23-000095:mdna:89]

[0000889331-23-000131:mdna:107]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 31, 2022. During the six months ended July 1, 2023, there were no significant changes in the application of critical accounting policies.
