# LFUS notes — 0000889331-23-000131


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-23-000131:notes:1]
[same as prior period, unchanged from 0000889331-23-000095:notes:1]

[0000889331-23-000131:notes:2]
[same as prior period, unchanged from 0000889331-23-000095:notes:2]

[0000889331-23-000131:notes:3]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-23-000131:notes:4]
[same as prior period, unchanged from 0000889331-23-000095:notes:4]

[0000889331-23-000131:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 31, 2022, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-23-000131:notes:6]
[same as prior period, unchanged from 0000889331-23-000095:notes:6]

[0000889331-23-000131:notes:7]
[same as prior period, unchanged from 0000889331-23-000095:notes:7]

[0000889331-23-000131:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 1, 2023 and July 2, 2022:

[0000889331-23-000131:notes:9]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,852 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,852 |  |  | $ | 301,450 |  |  | $ | — |  |  | $ | — |  |  | $ | 301,450 |  |
| Electronics – Semiconductor |  | 197,295 |  |  | — |  |  | — |  |  | 197,295 |  |  | 407,290 |  |  | — |  |  | — |  |  | 407,290 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  | — |  |  | — |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |

[0000889331-23-000131:notes:10]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  |  |  |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

[0000889331-23-000131:notes:11]
[same as prior period, unchanged from 0000889331-23-000095:notes:11]

[0000889331-23-000131:notes:12]
[same as prior period, unchanged from 0000889331-23-000095:notes:12]

[0000889331-23-000131:notes:13]
[same as prior period, unchanged from 0000889331-23-000095:notes:13]

[0000889331-23-000131:notes:14]
[same as prior period, unchanged from 0000889331-23-000095:notes:14]

[0000889331-23-000131:notes:15]
[same as prior period, unchanged from 0000889331-23-000095:notes:15]

[0000889331-23-000131:notes:16]
[same as prior period, unchanged from 0000889331-23-000095:notes:16]

[0000889331-23-000131:notes:17]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its

[0000889331-23-000131:notes:18]
price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-23-000131:notes:19]
[same as prior period, unchanged from 0000889331-23-000095:notes:18]

[0000889331-23-000131:notes:20]
[same as prior period, unchanged from 0000889331-23-000095:notes:19]

[0000889331-23-000131:notes:21]
[same as prior period, unchanged from 0000889331-23-000095:notes:20]

[0000889331-23-000131:notes:22]
[same as prior period, unchanged from 0000889331-23-000095:notes:21]

[0000889331-23-000131:notes:23]
Cash, Cash Equivalents, and Restricted Cash

[0000889331-23-000131:notes:24]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at July 1, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-23-000131:notes:25]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 480,743 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 771 |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,580 |  |  | 1,549 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 483,094 |  |  | $ | 564,939 |  |

[0000889331-23-000131:notes:26]
Recently Issued Accounting Standards

[0000889331-23-000131:notes:27]
In March 2023, the Financial Accounting Standards Board ("FASB") issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective on January 1, 2024. The Company does not expect any material effect on the Company's Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000889331-23-000131:notes:28]
[same as prior period, unchanged from 0000889331-23-000095:notes:27]

[0000889331-23-000131:notes:29]
[same as prior period, unchanged from 0000889331-23-000095:notes:28]

[0000889331-23-000131:notes:30]
[same as prior period, unchanged from 0000889331-23-000095:notes:29]

[0000889331-23-000131:notes:31]
On February 3, 2023, the Company completed the acquisition of Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets,

[0000889331-23-000131:notes:32]
including e-Mobility off-board charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The business is reported within the Company’s Industrial segment.

[0000889331-23-000131:notes:33]
[same as prior period, unchanged from 0000889331-23-000095:notes:31]

[0000889331-23-000131:notes:34]
[same as prior period, unchanged from 0000889331-23-000095:notes:32]

[0000889331-23-000131:notes:35]
[same as prior period, unchanged from 0000889331-23-000095:notes:33]

[0000889331-23-000131:notes:36]
[same as prior period, unchanged from 0000889331-23-000095:notes:34]

[0000889331-23-000131:notes:37]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and six months ended July 1, 2023 are net sales of approximately $4.8 million and $7.5 million respectively, and an income before income taxes of $0.3 million and $0.2 million,  respectively, since the February 3, 2023 acquisition of Western Automation.

[0000889331-23-000131:notes:38]
During the six months ended July 1, 2023, the Company incurred approximately $1.4 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-23-000131:notes:39]
[same as prior period, unchanged from 0000889331-23-000095:notes:37]

[0000889331-23-000131:notes:40]
[same as prior period, unchanged from 0000889331-23-000095:notes:38]

[0000889331-23-000131:notes:41]
The acquisition was funded through a combination of cash on hand and debt. The total purchase consideration of $523.0 million, net of cash acquired, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary area not

[0000889331-23-000131:notes:42]
yet finalized relates to the completion of the valuation of certain acquired income tax assets and liabilities. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-23-000131:notes:43]
[same as prior period, unchanged from 0000889331-23-000095:notes:40]

[0000889331-23-000131:notes:44]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 523,014 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 20,967 |  |
| Inventories | 42,968 |  |
| Other current assets | 2,932 |  |
| Property, plant, and equipment | 32,791 |  |
| Intangible assets | 254,700 |  |
| Goodwill | 274,124 |  |
| Other non-current assets | 14,797 |  |
| Current liabilities | (47,687) |  |
| Long-term debt | (9,626) |  |
| Other non-current liabilities | (62,952) |  |
|  | $ | 523,014 |  |

[0000889331-23-000131:notes:45]
[same as prior period, unchanged from 0000889331-23-000095:notes:42]

[0000889331-23-000131:notes:46]
During the three months ended July 1, 2023, the Company recorded measurement period adjustments to increase other non-current liabilities of $4.2 million associated with uncertain tax positions, income taxes payable of $0.2 million, and reduce accrued liabilities of $0.3 million and deferred tax liabilities of $0.2 million. As a result of these adjustments, goodwill was increased by $3.9 million.

[0000889331-23-000131:notes:47]
[same as prior period, unchanged from 0000889331-23-000095:notes:43]

[0000889331-23-000131:notes:48]
[same as prior period, unchanged from 0000889331-23-000095:notes:44]

[0000889331-23-000131:notes:49]
On April 12, 2022, the Company acquired Embed Ltd. (“Embed”). Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets, primarily including commercial vehicle electrification and eMobility. The business is included in the commercial vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand. The total purchase consideration was $9.2 million, net of cash.

[0000889331-23-000131:notes:50]
[same as prior period, unchanged from 0000889331-23-000095:notes:46]

[0000889331-23-000131:notes:51]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and Western Automation as though the acquisition had occurred as of January 2, 2022, and C&K as though the acquisition had occurred as of December 27, 2020, and Carling business acquired on November 30, 2021 as though the acquisition had occurred as of December 29, 2019. The Company has not included pro forma results of operations for Embed as its operations were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Western Automation acquisition occurred as of January 2, 2022, and had the C&K acquisition occurred as of December 27, 2020 and had Carling acquisition occurred as of December 29, 2019 or of future consolidated operating results.

[0000889331-23-000131:notes:52]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands, except per share amounts) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net sales |  | $ | 611,997 |  |  | $ | 684,835 |  |  | $ | 1,223,665 |  |  | $ | 1,376,586 |  |
| Income before income taxes |  | 85,481 |  |  | 121,995 |  |  | 196,094 |  |  | 271,474 |  |
| Net income |  | 70,098 |  |  | 93,818 |  |  | 160,339 |  |  | 222,514 |  |
| Net income per share — basic |  | 2.82 |  |  | 3.79 |  |  | 6.46 |  |  | 9.00 |  |
| Net income per share — diluted |  | 2.79 |  |  | 3.75 |  |  | 6.39 |  |  | 8.91 |  |

[0000889331-23-000131:notes:53]
[same as prior period, unchanged from 0000889331-23-000095:notes:49]

[0000889331-23-000131:notes:54]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Amortization (a) |  | $ | — |  |  | $ | (3,709) |  |  | $ | (479) |  |  | $ | (7,439) |  |
| Depreciation |  | — |  |  | 805 |  |  | — |  |  | 1,528 |  |
| Transaction costs (b) |  | 30 |  |  | 2,264 |  |  | 1,427 |  |  | 4,243 |  |
| Amortization of inventory step-up (c) |  | — |  |  | — |  |  | — |  |  | 4,769 |  |
| Interest expense (d) |  | — |  |  | 123 |  |  | — |  |  | 317 |  |
| Income tax expense of above items |  | (3) |  |  | (55) |  |  | (118) |  |  | (1,250) |  |

[0000889331-23-000131:notes:55]
(a) The amortization adjustment for the six months ended July 1, 2023 and three and six months ended July 2, 2022 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-23-000131:notes:56]
(b) The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three and six months ended July 1, 2023 and three and six months ended July 2, 2022, and recognition of those fees during the three and six months ended July 1, 2023.

[0000889331-23-000131:notes:57]
[same as prior period, unchanged from 0000889331-23-000095:notes:53]

[0000889331-23-000131:notes:58]
[same as prior period, unchanged from 0000889331-23-000095:notes:54]


## us-gaap:InventoryDisclosureTextBlock

[0000889331-23-000131:notes:59]
[same as prior period, unchanged from 0000889331-23-000095:notes:55]

[0000889331-23-000131:notes:60]
The components of inventories at July 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000131:notes:61]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Raw materials |  | $ | 229,813 |  |  | $ | 231,043 |  |
| Work in process |  | 142,420 |  |  | 134,792 |  |
| Finished goods |  | 209,520 |  |  | 226,215 |  |
| Inventory reserves |  | (54,602) |  |  | (44,360) |  |
| Total |  | $ | 527,151 |  |  | $ | 547,690 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-23-000131:notes:62]
[same as prior period, unchanged from 0000889331-23-000095:notes:58]

[0000889331-23-000131:notes:63]
The components of net property, plant, and equipment at July 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000131:notes:64]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Land and land improvements |  | $ | 21,970 |  |  | $ | 22,089 |  |
| Building and building improvements |  | 193,254 |  |  | 191,733 |  |
| Machinery and equipment |  | 838,909 |  |  | 812,540 |  |
| Accumulated depreciation |  | (572,566) |  |  | (545,252) |  |
| Total |  | $ | 481,567 |  |  | $ | 481,110 |  |

[0000889331-23-000131:notes:65]
The Company recorded depreciation expense of $18.0 million and $15.7 million for the three months ended July 1, 2023 and July 2, 2022, respectively, and $35.6 million and $31.3 million for the six months ended July 1, 2023 and July 2, 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-23-000131:notes:66]
[same as prior period, unchanged from 0000889331-23-000095:notes:62]

[0000889331-23-000131:notes:67]
Changes in the carrying value of goodwill by segment for the six months ended July 1, 2023 are as follows:

[0000889331-23-000131:notes:68]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net book value of goodwill as of December 31, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 31, 2022 |  | $ | 909,167 |  |  | $ | 234,793 |  |  | $ | 84,889 |  |  | $ | 1,228,849 |  |
| Accumulated impairment losses as of December 31, 2022 |  | — |  |  | (33,401) |  |  | (8,526) |  |  | (41,927) |  |
| Total |  | 909,167 |  |  | 201,392 |  |  | 76,363 |  |  | 1,186,922 |  |
| Changes during 2023: |  |  |  |  |  |  |  |  |
| Additions (a) |  | 3,879 |  |  | — |  |  | 94,823 |  |  | 98,702 |  |
| Currency translation |  | 3,384 |  |  | 365 |  |  | (185) |  |  | 3,564 |  |
| Net book value of goodwill as of July 1, 2023 |  |  |  |  |  |  |  |  |
| Gross goodwill as of July 1, 2023 |  | 916,430 |  |  | 235,281 |  |  | 179,719 |  |  | 1,331,430 |  |
| Accumulated impairment losses as of July 1, 2023 |  | — |  |  | (33,524) |  |  | $ | (8,718) |  |  | (42,242) |  |
| Total |  | $ | 916,430 |  |  | $ | 201,757 |  |  | $ | 171,001 |  |  | $ | 1,289,188 |  |

[0000889331-23-000131:notes:69]
(a) The additions resulted from the acquisitions of Western Automation and measurement period adjustment related to the C&K acquisition.

[0000889331-23-000131:notes:70]
The components of other intangible assets as of July 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000131:notes:71]
|  |  |  | As of July 1, 2023 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 17,275 |  |  | $ | 2,470 |  |  | $ | 14,805 |  |
| Patents, licenses, and software |  |  | 271,310 |  |  | 151,514 |  |  | 119,796 |  |
| Distribution network |  |  | 43,089 |  |  | 43,089 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 680,820 |  |  | 187,088 |  |  | 493,732 |  |
| Total |  |  | $ | 1,012,494 |  |  | $ | 384,161 |  |  | $ | 628,333 |  |

[0000889331-23-000131:notes:72]
|  | December 31, 2022 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 17,938 |  |  | $ | 2,299 |  |  | $ | 15,639 |  |
| Patents, licenses, and software | 259,603 |  |  | 140,208 |  |  | 119,395 |  |
| Distribution network | 41,733 |  |  | 40,955 |  |  | 778 |  |
| Customer relationships, trademarks, and tradenames | 623,721 |  |  | 165,563 |  |  | 458,158 |  |
| Total | $ | 942,995 |  |  | $ | 349,025 |  |  | $ | 593,970 |  |

[0000889331-23-000131:notes:73]
During the three months ended July 1, 2023 and July 2, 2022, the Company recorded amortization expense of $16.9 million and $11.6 million, respectively. During the six months ended July 1, 2023 and July 2, 2022, the Company recorded amortization expense of 33.8 million and $24.3 million, respectively.

[0000889331-23-000131:notes:74]
During the six months ended July 1, 2023, the Company recorded additions to intangible assets of $68.0 million, related to the Western Automation acquisition, the components of which were as follows:

[0000889331-23-000131:notes:75]
| (in thousands) | Weighted Average Useful Life |  | Amount |
| Patents, licenses, and software | 6.7 |  | $ | 11,500 |  |
| Customer relationships, trademarks, and tradenames | 14.7 |  | 56,500 |  |
| Total |  |  | $ | 68,000 |  |

[0000889331-23-000131:notes:76]
Estimated annual amortization expense related to intangible assets with definite lives as of July 1, 2023 is as follows:

[0000889331-23-000131:notes:77]
| (in thousands) | Amount |
| 2023 | $ | 65,730 |  |
| 2024 | 62,859 |  |
| 2025 | 62,536 |  |
| 2026 | 51,576 |  |
| 2027 | 49,529 |  |
| 2028 and thereafter | 369,854 |  |
| Total | $ | 662,084 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-23-000131:notes:78]
[same as prior period, unchanged from 0000889331-23-000095:notes:74]

[0000889331-23-000131:notes:79]
The components of accrued liabilities as of July 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000131:notes:80]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Employee-related liabilities |  | $ | 63,644 |  |  | $ | 99,089 |  |
| Current lease liability |  | 12,559 |  |  | 12,841 |  |
| Other non-income taxes |  | 8,373 |  |  | 10,594 |  |
| Professional services |  | 6,619 |  |  | 7,160 |  |
| Other customer reserves |  | 4,575 |  |  | 5,064 |  |
| Interest |  | 4,205 |  |  | 4,449 |  |
| Deferred revenue |  | 2,488 |  |  | 2,593 |  |
| Restructuring liability |  | 1,744 |  |  | 2,434 |  |
| Current benefit liability |  | 1,318 |  |  | 1,318 |  |
| Other |  | 38,318 |  |  | 41,515 |  |
| Total |  | $ | 143,843 |  |  | $ | 187,057 |  |

[0000889331-23-000131:notes:81]
[same as prior period, unchanged from 0000889331-23-000095:notes:77]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-23-000131:notes:82]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three and six months ended July 1, 2023 and July 2, 2022 as follows:

[0000889331-23-000131:notes:83]
|  | Three months ended July 1, 2023 |  | Six months ended July 1, 2023 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 987 |  |  | $ | 351 |  |  | $ | 277 |  |  | $ | 1,615 |  |  | $ | 1,659 |  |  | $ | 933 |  |  | $ | 594 |  |  | $ | 3,186 |  |
| Other restructuring charges | 250 |  |  | 412 |  |  | 654 |  |  | 1,316 |  |  | 257 |  |  | 684 |  |  | 654 |  |  | 1,595 |  |
| Total restructuring charges | 1,237 |  |  | 763 |  |  | 931 |  |  | 2,931 |  |  | 1,916 |  |  | 1,617 |  |  | 1,248 |  |  | 4,781 |  |
| Impairment | — |  |  | 3,870 |  |  | 54 |  |  | 3,924 |  |  | — |  |  | 3,870 |  |  | 54 |  |  | 3,924 |  |
| Total | $ | 1,237 |  |  | $ | 4,633 |  |  | $ | 985 |  |  | $ | 6,855 |  |  | $ | 1,916 |  |  | $ | 5,487 |  |  | $ | 1,302 |  |  | $ | 8,705 |  |

[0000889331-23-000131:notes:84]
|  | Three months ended July 2, 2022 |  | Six months ended July 2, 2022 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 201 |  |  | $ | 423 |  |  | $ | — |  |  | $ | 624 |  |  | $ | 406 |  |  | $ | 423 |  |  | $ | — |  |  | $ | 829 |  |
| Other restructuring charges | 3 |  |  | 7 |  |  | — |  |  | 10 |  |  | 3 |  |  | 20 |  |  | — |  |  | 23 |  |
| Total | $ | 204 |  |  | $ | 430 |  |  | $ | — |  |  | $ | 634 |  |  | $ | 409 |  |  | $ | 443 |  |  | $ | — |  |  | $ | 852 |  |

[0000889331-23-000131:notes:85]
[same as prior period, unchanged from 0000889331-23-000095:notes:81]

[0000889331-23-000131:notes:86]
For the three and six months ended July 1, 2023, the Company recorded total restructuring charges of $2.9 million and $4.8 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K acquisition and the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment’s commercial vehicle business. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate.

[0000889331-23-000131:notes:87]
[same as prior period, unchanged from 0000889331-23-000095:notes:83]

[0000889331-23-000131:notes:88]
For the three and six months ended July 2, 2022, the Company recorded total restructuring charges of $0.6 million and $0.9 million, respectively. primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling, and administrative functions within the Electronics segment.

[0000889331-23-000131:notes:89]
The restructuring liability as of July 1, 2023 and December 31, 2022 is $1.7 million and $2.4 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in fiscal year 2023.


## us-gaap:DebtDisclosureTextBlock

[0000889331-23-000131:notes:90]
Debt

[0000889331-23-000131:notes:91]
The carrying amounts of debt at July 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000131:notes:92]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 292,500 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,220 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,298 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,942 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,302) |  |  | (4,847) |  |
| Total debt |  | 1,001,658 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,435) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 864,223 |  |  | $ | 866,623 |  |

[0000889331-23-000131:notes:93]
Revolving Credit Facility and Term Loan

[0000889331-23-000131:notes:94]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000131:notes:95]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000131:notes:96]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended July 1, 2023, the Company made payments of $1.9 million and $3.8 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $292.5 million, respectively, as of July 1, 2023.

[0000889331-23-000131:notes:97]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-23-000131:notes:98]
As of July 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.45%.

[0000889331-23-000131:notes:99]
As of July 1, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of July 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-23-000131:notes:100]
Senior Notes

[0000889331-23-000131:notes:101]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-23-000131:notes:102]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-23-000131:notes:103]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000131:notes:104]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000131:notes:105]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-23-000131:notes:106]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-23-000131:notes:107]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At July 1, 2023, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-23-000131:notes:108]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-23-000131:notes:109]
Interest paid on all Company debt was $10.3 million and $2.3 million for the three months ended July 1, 2023 and July 2, 2022, respectively, and $21.3 million and $8.4 million for the six months ended July 1, 2023 and July 2, 2022, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-23-000131:notes:110]
[same as prior period, unchanged from 0000889331-23-000095:notes:106]

[0000889331-23-000131:notes:111]
[same as prior period, unchanged from 0000889331-23-000095:notes:107]

[0000889331-23-000131:notes:112]
[same as prior period, unchanged from 0000889331-23-000095:notes:108]

[0000889331-23-000131:notes:113]
[same as prior period, unchanged from 0000889331-23-000095:notes:109]

[0000889331-23-000131:notes:114]
[same as prior period, unchanged from 0000889331-23-000095:notes:110]

[0000889331-23-000131:notes:115]
[same as prior period, unchanged from 0000889331-23-000095:notes:111]

[0000889331-23-000131:notes:116]
[same as prior period, unchanged from 0000889331-23-000095:notes:112]

[0000889331-23-000131:notes:117]
[same as prior period, unchanged from 0000889331-23-000095:notes:113]

[0000889331-23-000131:notes:118]
[same as prior period, unchanged from 0000889331-23-000095:notes:114]

[0000889331-23-000131:notes:119]
[same as prior period, unchanged from 0000889331-23-000095:notes:115]

[0000889331-23-000131:notes:120]
[same as prior period, unchanged from 0000889331-23-000095:notes:116]

[0000889331-23-000131:notes:121]
[same as prior period, unchanged from 0000889331-23-000095:notes:117]

[0000889331-23-000131:notes:122]
[same as prior period, unchanged from 0000889331-23-000095:notes:118]

[0000889331-23-000131:notes:123]
[same as prior period, unchanged from 0000889331-23-000095:notes:119]

[0000889331-23-000131:notes:124]
The use of derivatives creates exposure to credit risk relating to potential losses that could be recognized in the event that the counterparties to these instruments fail to perform their obligations under the contracts. The Company seeks to minimize this risk by limiting our counterparties to major financial institutions with acceptable credit ratings and monitoring the total value of positions with individual counterparties. In the event of a default by one of our counterparties, the Company may not receive payments provided for under the terms of our derivatives.

[0000889331-23-000131:notes:125]
[same as prior period, unchanged from 0000889331-23-000095:notes:122]

[0000889331-23-000131:notes:126]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at July 1, 2023 was €117.0 million and expires on December 7, 2023. The foreign currency contract was not designated as a hedge instrument and is marked to market on a monthly basis. As a result, changes in fair value are reported in Foreign exchange (gain) loss in the Condensed Consolidated Statements of Operations. The fair value of the foreign currency forward contract was valued using market exchange rates by a third party and classified as a Level 2 input under the fair value hierarchy.

[0000889331-23-000131:notes:127]
As of July 1, 2023 and December 31, 2022, the fair values of our derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-23-000131:notes:128]
| (in thousands) | Consolidated Balance Sheet Classification |  | July 1, 2023 |  | December 31, 2022 |  |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 4,794 |  |  | $ | 3,939 |  |  |  |
|  | Other long-term assets |  | $ | 4,668 |  |  | $ | 4,740 |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |
| Foreign exchange forward contract | Prepaid expenses and other current assets |  | $ | 7,245 |  |  | $ | 6,186 |  |  |  |

[0000889331-23-000131:notes:129]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Operations for the three and six months ended July 1, 2023 and July 2, 2022 were as follows:

[0000889331-23-000131:notes:130]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | Classification of (Gain) Loss Recognized in theCondensed Consolidated Statements of Operations |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense, net |  | $ | (1,119) |  |  | $ | 21 |  |  | $ | (2,094) |  |  | $ | 21 |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  | Foreign exchange (gain) loss |  | $ | (264) |  |  | $ | — |  |  | $ | (1,083) |  |  | $ | — |  |

[0000889331-23-000131:notes:131]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and six months ended July 1, 2023 and July 2, 2022 was as follows:

[0000889331-23-000131:notes:132]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | (4,096) |  |  | $ | 712 |  |  | $ | (783) |  |  | $ | 712 |  |

[0000889331-23-000131:notes:133]
The pre-tax gain of $4.8 million from accumulated other comprehensive loss to earnings is expected to be recognized during the next twelve months.

[0000889331-23-000131:notes:134]
[same as prior period, unchanged from 0000889331-23-000095:notes:131]

[0000889331-23-000131:notes:135]
[same as prior period, unchanged from 0000889331-23-000095:notes:132]

[0000889331-23-000131:notes:136]
There were no changes during the quarter ended July 1, 2023 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of July 1, 2023 and December 31, 2022, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-23-000131:notes:137]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of July 1, 2023:

[0000889331-23-000131:notes:138]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 246,566 |  |  | $ | — |  |  | $ | — |  |  | $ | 246,566 |  |
| Investments in equity securities |  | 11,573 |  |  | — |  |  | — |  |  | 11,573 |  |
| Mutual funds |  | 18,513 |  |  | — |  |  | — |  |  | 18,513 |  |
| Total |  | $ | 276,652 |  |  | $ | — |  |  | $ | — |  |  | $ | 276,652 |  |

[0000889331-23-000131:notes:139]
[same as prior period, unchanged from 0000889331-23-000095:notes:136]

[0000889331-23-000131:notes:140]
[same as prior period, unchanged from 0000889331-23-000095:notes:137]

[0000889331-23-000131:notes:141]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at July 1, 2023 and December 31, 2022, as the rates on these borrowings are variable in nature.

[0000889331-23-000131:notes:142]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of July 1, 2023 and December 31, 2022 were as follows:

[0000889331-23-000131:notes:143]
|  |  | July 1, 2023 |  | December 31, 2022 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 127,220 |  |  | $ | 125,507 |  |  | $ | 124,716 |  |  | $ | 122,270 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,298 |  |  | 89,941 |  |  | 101,265 |  |  | 87,119 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 93,334 |  |  | 100,000 |  |  | 93,764 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 48,128 |  |  | 50,000 |  |  | 48,145 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 111,735 |  |  | 125,000 |  |  | 112,028 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 89,879 |  |  | 100,000 |  |  | 90,131 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-23-000131:notes:144]
[same as prior period, unchanged from 0000889331-23-000095:notes:141]

[0000889331-23-000131:notes:145]
[same as prior period, unchanged from 0000889331-23-000095:notes:142]

[0000889331-23-000131:notes:146]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other (income) expense, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and six months ended July 1, 2023 and July 2, 2022 were as follows:

[0000889331-23-000131:notes:147]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 695 |  |  | $ | 750 |  |  | $ | 1,387 |  |  | $ | 1,518 |  |
| Interest cost |  | 952 |  |  | 628 |  |  | 1,889 |  |  | 1,272 |  |
| Expected return on plan assets |  | (470) |  |  | (380) |  |  | (939) |  |  | (783) |  |
| Amortization of prior service and net actuarial loss |  | 11 |  |  | 96 |  |  | 22 |  |  | 197 |  |
| Net periodic benefit cost |  | $ | 1,188 |  |  | $ | 1,094 |  |  | $ | 2,359 |  |  | $ | 2,204 |  |

[0000889331-23-000131:notes:148]
[same as prior period, unchanged from 0000889331-23-000095:notes:145]

[0000889331-23-000131:notes:149]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.4 million and $0.5 million for the three months ended July 1, 2023 and July 2, 2022, respectively, and of $0.8 million and $0.5 million for the six months ended July 1, 2023 and July 2, 2022, respectively, in Cost of Sales and Other (income) expense, net within the Condensed Consolidated Statements of Net Income. The pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were nominal and $0.1 million for the three months ended July 1, 2023 and July 2, 2022, respectively, and nominal and $0.2 million for the six months ended July 1, 2023 and July 2, 2022, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-23-000131:notes:150]
Other Comprehensive (Loss) Income 
Changes in other comprehensive (loss) income by component were as follows:

[0000889331-23-000131:notes:151]
| (in thousands) |  | Three Months EndedJuly 1, 2023 |  | Three Months EndedJuly 2, 2022 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | (146) |  |  | $ | (13) |  |  | $ | (159) |  |  | $ | 722 |  |  | $ | (83) |  |  | $ | 639 |  |
| Cash flow hedge |  | 4,096 |  |  | (983) |  |  | 3,113 |  |  | (712) |  |  | 171 |  |  | (541) |  |
| Foreign currency translation adjustments (a) |  | (17,865) |  |  | — |  |  | (17,865) |  |  | (32,167) |  |  | 720 |  |  | (31,447) |  |
| Total change in other comprehensive (loss) income |  | $ | (13,915) |  |  | $ | (996) |  |  | $ | (14,911) |  |  | $ | (32,157) |  |  | $ | 808 |  |  | $ | (31,349) |  |
| (in thousands) |  | Six Months EndedJuly 1, 2023 |  | Six Months EndedJuly 2, 2022 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | (122) |  |  | $ | (31) |  |  | $ | (153) |  |  | 1,045 |  |  | (96) |  |  | $ | 949 |  |
| Cash flow hedge |  | 783 |  |  | (188) |  |  | 595 |  |  | (712) |  |  | 171 |  |  | (541) |  |
| Foreign currency translation adjustments (a) |  | (1,797) |  |  | (273) |  |  | (2,070) |  |  | $ | (35,382) |  |  | $ | 1,422 |  |  | $ | (33,960) |  |
| Total change in other comprehensive (loss) income |  | $ | (1,136) |  |  | $ | (492) |  |  | $ | (1,628) |  |  | $ | (35,049) |  |  | $ | 1,497 |  |  | $ | (33,552) |  |

[0000889331-23-000131:notes:152]
[same as prior period, unchanged from 0000889331-23-000095:notes:149]

[0000889331-23-000131:notes:153]
The following tables set forth the changes in accumulated other comprehensive loss by component for the six months ended July 1, 2023 and July 2, 2022:

[0000889331-23-000131:notes:154]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at December 31, 2022 |  | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| Activity in the period |  | (153) |  |  | 595 |  |  | (2,070) |  |  | (1,628) |  |
| Balance at July 1, 2023 |  | $ | (2,346) |  |  | $ | 7,191 |  |  | $ | (102,237) |  |  | $ | (97,392) |  |

[0000889331-23-000131:notes:155]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at January 1, 2022 |  | $ | (11,928) |  |  | $ | — |  |  | $ | (61,535) |  |  | $ | (73,463) |  |
| Activity in the period |  | 949 |  |  | (541) |  |  | (33,960) |  |  | (33,552) |  |
| Balance at July 2, 2022 |  | $ | (10,979) |  |  | $ | (541) |  |  | $ | (95,495) |  |  | $ | (107,015) |  |

[0000889331-23-000131:notes:156]
Amounts reclassified from accumulated other comprehensive loss to earnings for the three and six months ended July 1, 2023 and July 2, 2022 were as follows:

[0000889331-23-000131:notes:157]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial (gain) loss |  | $ | (11) |  |  | $ | 198 |  |  | $ | (22) |  |  | $ | 395 |  |

[0000889331-23-000131:notes:158]
[same as prior period, unchanged from 0000889331-23-000095:notes:155]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-23-000131:notes:159]
Income Taxes
The effective tax rate for the three and six months ended July 1, 2023 was 18.0% and 18.3%, respectively, compared to the effective tax rate for the three and six months ended July 2, 2022 of 20.6% and 16.1%, respectively. The effective tax rate for the second quarter of 2023 is lower than the effective tax rate for the comparable 2022 period, primarily due to the impact of foreign exchange losses with no related tax benefit in the 2022 period.

[0000889331-23-000131:notes:160]
The effective tax rate for the first six months of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to the impact of a one-time deduction in the first quarter of 2022 that resulted in a net benefit of $7.2 million from the dissolution of one of the Company’s affiliates. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, while for the 2022 period, the effective tax rate was also lower due to the impact of the one-time deduction previously noted.


## us-gaap:EarningsPerShareTextBlock

[0000889331-23-000131:notes:161]
[same as prior period, unchanged from 0000889331-23-000095:notes:157]

[0000889331-23-000131:notes:162]
[same as prior period, unchanged from 0000889331-23-000095:notes:158]

[0000889331-23-000131:notes:163]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share amounts) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 70,071 |  |  | $ | 87,016 |  |  | $ | 158,816 |  |  | $ | 204,534 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,839 |  |  | 24,734 |  |  | 24,810 |  |  | 24,712 |  |
| Effect of dilutive securities |  | 256 |  |  | 251 |  |  | 268 |  |  | 274 |  |
| Diluted |  | 25,095 |  |  | 24,985 |  |  | 25,078 |  |  | 24,986 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.82 |  |  | $ | 3.52 |  |  | $ | 6.40 |  |  | $ | 8.28 |  |
| Diluted earnings per share |  | $ | 2.79 |  |  | $ | 3.48 |  |  | $ | 6.33 |  |  | $ | 8.19 |  |

[0000889331-23-000131:notes:164]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 110,598 and 88,130 for the three months ended July 1, 2023 and July 2, 2022, respectively, and 102,283 and 72,970 for the six months ended July 1, 2023 and July 2, 2022, respectively.

[0000889331-23-000131:notes:165]
[same as prior period, unchanged from 0000889331-23-000095:notes:161]

[0000889331-23-000131:notes:166]
[same as prior period, unchanged from 0000889331-23-000095:notes:162]

[0000889331-23-000131:notes:167]
The Company did not repurchase shares of its common stock for the three and six months ended July 1, 2023, and July 2, 2022.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-23-000131:notes:168]
Related Party Transactions

[0000889331-23-000131:notes:169]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-23-000131:notes:170]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-23-000131:notes:171]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-23-000131:notes:172]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-23-000131:notes:173]
|  |  | Three Months Ended July 1, 2023 |  | Three Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.1 |  | 2.9 |  |  | 0.1 |  | 0.1 |  | 3.0 |  |
|  |  | Six Months Ended July 1, 2023 |  | Six Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.1 |  | 0.2 |  | 5.6 |  |  | 0.3 |  | 0.2 |  | 5.9 |  |
|  |  | July 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.7 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-23-000131:notes:174]
[same as prior period, unchanged from 0000889331-23-000095:notes:170]

[0000889331-23-000131:notes:175]
[same as prior period, unchanged from 0000889331-23-000095:notes:171]

[0000889331-23-000131:notes:176]
[same as prior period, unchanged from 0000889331-23-000095:notes:172]

[0000889331-23-000131:notes:177]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related charging infrastructure, aerospace, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-23-000131:notes:178]
•Transportation Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicle, heavy-duty truck and bus, off-road and recreational vehicles, material handling equipment, agricultural machinery, construction equipment and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck and bus, construction, agriculture, material handling and marine.

[0000889331-23-000131:notes:179]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), industrial controls (protection relays, contactors, transformers, residual current devices, ground fault circuit interrupters, residual current monitors, and arc fault detection devices) and temperature sensors for use in various applications such as renewable energy and energy storage systems, industrial safety, factory automation, electric vehicle infrastructure, HVAC systems, non-residential construction, MRO, and mining.

[0000889331-23-000131:notes:180]
[same as prior period, unchanged from 0000889331-23-000095:notes:177]

[0000889331-23-000131:notes:181]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 350,147 |  |  | $ | 358,176 |  |  | $ | 708,740 |  |  | $ | 723,997 |  |
| Transportation |  | 172,048 |  |  | 182,027 |  |  | 338,689 |  |  | 366,531 |  |
| Industrial |  | 89,802 |  |  | 78,233 |  |  | 174,350 |  |  | 151,238 |  |
| Total net sales |  | $ | 611,997 |  |  | $ | 618,436 |  |  | $ | 1,221,779 |  |  | $ | 1,241,766 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 19,808 |  |  | $ | 14,511 |  |  | $ | 39,596 |  |  | 29,904 |  |
| Transportation |  | 11,063 |  |  | 10,628 |  |  | 22,354 |  |  | 21,372 |  |
| Industrial |  | 4,021 |  |  | 2,181 |  |  | 7,424 |  |  | 4,342 |  |
| Total depreciation and amortization |  | $ | 34,892 |  |  | $ | 27,320 |  |  | $ | 69,374 |  |  | $ | 55,618 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 79,844 |  |  | $ | 105,958 |  |  | $ | 170,006 |  |  | $ | 226,535 |  |
| Transportation |  | 7,789 |  |  | 18,309 |  |  | 16,321 |  |  | 44,617 |  |
| Industrial |  | 15,108 |  |  | 15,285 |  |  | 32,249 |  |  | 27,790 |  |
| Other (a) |  | (10,688) |  |  | (5,388) |  |  | (15,882) |  |  | (14,188) |  |
| Total operating income |  | 92,053 |  |  | 134,164 |  |  | 202,694 |  |  | 284,754 |  |
| Interest expense |  | 10,056 |  |  | 4,368 |  |  | 19,702 |  |  | 8,670 |  |
| Foreign exchange (gain) loss |  | (1,404) |  |  | 14,124 |  |  | (3,079) |  |  | 21,860 |  |
| Other (income) expense, net |  | (2,050) |  |  | 6,060 |  |  | (8,283) |  |  | 10,487 |  |
| Income before income taxes |  | $ | 85,451 |  |  | $ | 109,612 |  |  | $ | 194,354 |  |  | $ | 243,737 |  |

[0000889331-23-000131:notes:182]
(a) Included in “Other” Operating income for the second quarter of 2023 was $3.9 million ($7.2 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $2.9 million ($4.8 million year-to-date) of restructuring charges, primarily related to employee termination costs. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000131:notes:183]
Included in “Other” Operating income for the second quarter of 2022 was $4.8 million ($8.6 million year-to-date) of legal and professional fees and other integration expenses related to the acquisition of C&K and other integration expenses related to completed and contemplated acquisitions, and $0.6 million ($0.8 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs, and $4.8 million year-to-date of purchase accounting inventory step-up charges. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000131:notes:184]
[same as prior period, unchanged from 0000889331-23-000095:notes:181]

[0000889331-23-000131:notes:185]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 205,793 |  |  | $ | 224,743 |  |  | $ | 417,988 |  |  | $ | 444,981 |  |
| China |  | 143,570 |  |  | 162,322 |  |  | 277,037 |  |  | 327,104 |  |
| Other countries (a) |  | 262,634 |  |  | 231,371 |  |  | 526,754 |  |  | 469,681 |  |
| Total net sales |  | $ | 611,997 |  |  | $ | 618,436 |  |  | $ | 1,221,779 |  |  | $ | 1,241,766 |  |

[0000889331-23-000131:notes:186]
[same as prior period, unchanged from 0000889331-23-000095:notes:183]

[0000889331-23-000131:notes:187]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 75,381 |  |  | $ | 76,325 |  |
| China |  | 130,154 |  |  | 129,094 |  |
| Mexico |  | 104,293 |  |  | 107,119 |  |
| Germany |  | 41,890 |  |  | 39,635 |  |
| Philippines |  | 75,216 |  |  | 77,240 |  |
| Other countries (a) |  | 54,633 |  |  | 51,697 |  |
| Total long-lived assets |  | $ | 481,567 |  |  | $ | 481,110 |  |

[0000889331-23-000131:notes:188]
[same as prior period, unchanged from 0000889331-23-000095:notes:185]

[0000889331-23-000131:notes:189]
|  |  | Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 5,482 |  |  | $ | 6,527 |  |
| China |  | 15,228 |  |  | 15,623 |  |
| Mexico |  | 7,176 |  |  | 14,244 |  |
| Germany |  | 3,269 |  |  | 2,432 |  |
| Philippines |  | 3,202 |  |  | 10,138 |  |
| Other countries (a) |  | 5,602 |  |  | 2,558 |  |
| Total additions to long-lived assets |  | $ | 39,959 |  |  | $ | 51,522 |  |

[0000889331-23-000131:notes:190]
[same as prior period, unchanged from 0000889331-23-000095:notes:187]
