# LFUS 8-K — 0000889331-23-000129 filed 2023-08-01

## item codes, every 8-K on or before 2023-08-02

- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2023-08-02

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-23-000129:8k_2_02:1]
EX-99.1
2
q22023earningsreleaseex991.htm
EX-99.1

[0000889331-23-000129:8k_2_02:2]
Document

[0000889331-23-000129:8k_2_02:3]
Exhibit 99.1

[0000889331-23-000129:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-23-000129:8k_2_02:5]
LITTELFUSE REPORTS SECOND QUARTER RESULTS FOR 2023

[0000889331-23-000129:8k_2_02:6]
Resilient business model continues to deliver strong year-to-date performance

[0000889331-23-000129:8k_2_02:7]
CHICAGO, August 1, 2023  - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the second quarter ended July 1, 2023:

[0000889331-23-000129:8k_2_02:8]
•Net sales of $612.0 million were down 1% versus the prior year period, and down 8% organically

[0000889331-23-000129:8k_2_02:9]
•GAAP diluted EPS was $2.79; adjusted diluted EPS was $3.12

[0000889331-23-000129:8k_2_02:10]
•Cash flow from operations was $98.2 million and free cash flow was $82.4 million

[0000889331-23-000129:8k_2_02:11]
•On June 28, the company entered into a purchase agreement to acquire a 200mm wafer fab from Elmos Semiconductor SE, enhancing its power semiconductor capabilities to support long-term business opportunities in high-growth industrial end markets

[0000889331-23-000129:8k_2_02:12]
•The company’s Board of Directors approved an 8% increase in the quarterly cash dividend from $0.60 to $0.65; this equates to an annualized dividend of $2.60 per share

[0000889331-23-000129:8k_2_02:13]
•On July 28, the company released its 2022 Sustainability Report on littelfuse.com/about-us/sustainability

[0000889331-23-000129:8k_2_02:14]
“We delivered solid results in the second quarter driven by our strong operating fundamentals, within an ongoing dynamic environment,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “During the quarter, we secured significant new business in sustainability, connectivity, and safety applications, and continued to advance our strategic investments in high-growth end markets. Our strong overall performance to date, in 2023, reflects the resiliency of our business model. Looking ahead, our diverse technologies and capabilities, and the strength of our execution, continue to position us to deliver on our long-term growth strategy.”

[0000889331-23-000129:8k_2_02:15]
Third Quarter of 2023*

[0000889331-23-000129:8k_2_02:16]
Based on current market conditions, for the third quarter the company expects,

[0000889331-23-000129:8k_2_02:17]
•Net sales in the range of $570 to $595 million, adjusted diluted EPS in the range of $2.48 to $2.72 and an adjusted effective tax rate of approximately 19.5%

[0000889331-23-000129:8k_2_02:18]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-23-000129:8k_2_02:19]
-more-

[0000889331-23-000129:8k_2_02:20]
Dividend

[0000889331-23-000129:8k_2_02:21]
•The company will pay a cash dividend on its common stock of $0.65 per share on September 7, 2023, to shareholders of record as of August 24, 2023

[0000889331-23-000129:8k_2_02:22]
Conference Call and Webcast Information

[0000889331-23-000129:8k_2_02:23]
Littelfuse will host a conference call on Wednesday, August 2, 2023, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-23-000129:8k_2_02:24]
About Littelfuse

[0000889331-23-000129:8k_2_02:25]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-23-000129:8k_2_02:26]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse's accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 31, 2022. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 31, 2022, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-23-000129:8k_2_02:27]
-more

[0000889331-23-000129:8k_2_02:28]
Non-GAAP Financial Measures

[0000889331-23-000129:8k_2_02:29]
The information included in this press release includes the non-GAAP financial measures of organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-23-000129:8k_2_02:30]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-23-000129:8k_2_02:31]
The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-23-000129:8k_2_02:32]
CONTACT: Trisha Tuntland

[0000889331-23-000129:8k_2_02:33]
Head of Investor Relations

[0000889331-23-000129:8k_2_02:34]
(773) 628-2163

[0000889331-23-000129:8k_2_02:35]
LFUS-F

[0000889331-23-000129:8k_2_02:36]
###

[0000889331-23-000129:8k_2_02:37]
LITTELFUSE, INC.

[0000889331-23-000129:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-23-000129:8k_2_02:39]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | July 1,2023 |  | December 31,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 480,743 |  |  | $ | 562,588 |  |
| Short-term investments |  | 84 |  |  | 84 |  |
| Trade receivables, less allowances of $86,968 and $83,562 at July 1, 2023 and December 31, 2022, respectively |  | 339,637 |  |  | 306,578 |  |
| Inventories |  | 527,151 |  |  | 547,690 |  |
| Prepaid income taxes and income taxes receivable |  | 3,407 |  |  | 7,215 |  |
| Prepaid expenses and other current assets |  | 90,324 |  |  | 87,641 |  |
| Total current assets |  | 1,441,346 |  |  | 1,511,796 |  |
| Net property, plant, and equipment |  | 481,567 |  |  | 481,110 |  |
| Intangible assets, net of amortization |  | 628,333 |  |  | 593,970 |  |
| Goodwill |  | 1,289,188 |  |  | 1,186,922 |  |
| Investments |  | 25,248 |  |  | 24,121 |  |
| Deferred income taxes |  | 13,394 |  |  | 14,367 |  |
| Right of use lease assets, net |  | 56,379 |  |  | 57,382 |  |
| Other long-term assets |  | 40,259 |  |  | 34,066 |  |
| Total assets |  | $ | 3,975,714 |  |  | $ | 3,903,734 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 173,353 |  |  | $ | 208,571 |  |
| Accrued liabilities |  | 143,843 |  |  | 187,057 |  |
| Accrued income taxes |  | 41,049 |  |  | 41,793 |  |
| Current portion of long-term debt |  | 137,435 |  |  | 134,874 |  |
| Total current liabilities |  | 495,680 |  |  | 572,295 |  |
| Long-term debt, less current portion |  | 864,223 |  |  | 866,623 |  |
| Deferred income taxes |  | 104,121 |  |  | 100,230 |  |
| Accrued post-retirement benefits |  | 30,038 |  |  | 28,037 |  |
| Non-current operating lease liabilities |  | 43,571 |  |  | 45,661 |  |
| Other long-term liabilities |  | 80,830 |  |  | 79,510 |  |
| Total equity |  | 2,357,251 |  |  | 2,211,378 |  |
| Total liabilities and equity |  | $ | 3,975,714 |  |  | $ | 3,903,734 |  |

[0000889331-23-000129:8k_2_02:40]
LITTELFUSE, INC.

[0000889331-23-000129:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-23-000129:8k_2_02:42]
(Unaudited)

[0000889331-23-000129:8k_2_02:43]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) |  | July 1,2023 |  | July 2,2022 |  | July 1,2023 |  | July 2,2022 |
| Net sales |  | $ | 611,997 |  |  | $ | 618,436 |  |  | $ | 1,221,779 |  |  | $ | 1,241,766 |  |
| Cost of sales |  | 377,165 |  |  | 355,465 |  |  | 741,990 |  |  | 720,199 |  |
| Gross profit |  | 234,832 |  |  | 262,971 |  |  | 479,789 |  |  | 521,567 |  |
| Selling, general, and administrative expenses |  | 94,543 |  |  | 93,093 |  |  | 182,853 |  |  | 168,601 |  |
| Research and development expenses |  | 24,496 |  |  | 23,488 |  |  | 51,786 |  |  | 43,044 |  |
| Amortization of intangibles |  | 16,885 |  |  | 11,592 |  |  | 33,751 |  |  | 24,316 |  |
| Restructuring, impairment, and other charges |  | 6,855 |  |  | 634 |  |  | 8,705 |  |  | 852 |  |
| Total operating expenses |  | 142,779 |  |  | 128,807 |  |  | 277,095 |  |  | 236,813 |  |
| Operating income |  | 92,053 |  |  | 134,164 |  |  | 202,694 |  |  | 284,754 |  |
| Interest expense |  | 10,056 |  |  | 4,368 |  |  | 19,702 |  |  | 8,670 |  |
| Foreign exchange (gain) loss |  | (1,404) |  |  | 14,124 |  |  | (3,079) |  |  | 21,860 |  |
| Other (income) expense, net |  | (2,050) |  |  | 6,060 |  |  | (8,283) |  |  | 10,487 |  |
| Income before income taxes |  | 85,451 |  |  | 109,612 |  |  | 194,354 |  |  | 243,737 |  |
| Income taxes |  | 15,380 |  |  | 22,596 |  |  | 35,538 |  |  | 39,203 |  |
| Net income |  | $ | 70,071 |  |  | $ | 87,016 |  |  | $ | 158,816 |  |  | $ | 204,534 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.82 |  |  | $ | 3.52 |  |  | $ | 6.40 |  |  | $ | 8.28 |  |
| Diluted |  | $ | 2.79 |  |  | $ | 3.48 |  |  | $ | 6.33 |  |  | $ | 8.19 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,839 |  |  | 24,734 |  |  | 24,810 |  |  | 24,712 |  |
| Diluted |  | 25,095 |  |  | 24,985 |  |  | 25,078 |  |  | 24,986 |  |
| Comprehensive income |  | $ | 55,160 |  |  | $ | 55,667 |  |  | $ | 157,188 |  |  | $ | 170,982 |  |

[0000889331-23-000129:8k_2_02:44]
LITTELFUSE, INC.

[0000889331-23-000129:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-23-000129:8k_2_02:46]
(Unaudited)

[0000889331-23-000129:8k_2_02:47]
|  |  | Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 2, 2022 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 158,816 |  |  | $ | 204,534 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 83,347 |  |  | 114,659 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (30,562) |  |  | (76,807) |  |
| Inventories |  | 26,638 |  |  | (70,285) |  |
| Accounts payable |  | (33,796) |  |  | 9,153 |  |
| Accrued liabilities and income taxes |  | (57,790) |  |  | (23,107) |  |
| Prepaid expenses and other assets |  | 4,980 |  |  | 7,175 |  |
| Net cash provided by operating activities |  | 151,633 |  |  | 165,322 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (158,260) |  |  | (9,758) |  |
| Purchases of property, plant, and equipment |  | (41,501) |  |  | (56,151) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 741 |  |  | 542 |  |
| Net cash used in investing activities |  | (199,020) |  |  | (65,367) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (3,750) |  |  | 275,000 |  |
| Cash dividends paid |  | (29,790) |  |  | (26,201) |  |
| All other cash provided by (used in) financing activities |  | 854 |  |  | (3,782) |  |
| Net cash (used in) provided by financing activities |  | (32,686) |  |  | 245,017 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (1,772) |  |  | (15,511) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (81,845) |  |  | 329,461 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 564,939 |  |  | 482,836 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 483,094 |  |  | $ | 812,297 |  |

[0000889331-23-000129:8k_2_02:48]
LITTELFUSE, INC.

[0000889331-23-000129:8k_2_02:49]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-23-000129:8k_2_02:50]
(Unaudited)

[0000889331-23-000129:8k_2_02:51]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2023 |  | 2022 |  |  |  | %Growth / (Decline) |  | 2023 |  | 2022 |  |  |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 350,147 |  |  | $ | 358,176 |  |  |  |  | (2.2) | % |  | $ | 708,740 |  |  | $ | 723,997 |  |  |  |  | (2.1) | % |
| Transportation |  | 172,048 |  |  | 182,027 |  |  |  |  | (5.5) | % |  | 338,689 |  |  | 366,531 |  |  |  |  | (7.6) | % |
| Industrial |  | 89,802 |  |  | 78,233 |  |  |  |  | 14.8 | % |  | 174,350 |  |  | 151,238 |  |  |  |  | 15.3 | % |
| Total net sales |  | $ | 611,997 |  |  | $ | 618,436 |  |  |  |  | (1.0) | % |  | $ | 1,221,779 |  |  | $ | 1,241,766 |  |  |  |  | (1.6) | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 79,844 |  |  | $ | 105,958 |  |  |  |  | (24.6) | % |  | $ | 170,006 |  |  | $ | 226,535 |  |  |  |  | (25.0) | % |
| Transportation |  | 7,789 |  |  | 18,309 |  |  |  |  | (57.5) | % |  | 16,321 |  |  | 44,617 |  |  |  |  | (63.4) | % |
| Industrial |  | 15,108 |  |  | 15,285 |  |  |  |  | (1.2) | % |  | 32,249 |  |  | 27,790 |  |  |  |  | 16.0 | % |
| Other(a) |  | (10,688) |  |  | (5,388) |  |  |  |  | N.M. |  | (15,882) |  |  | (14,188) |  |  |  |  | N.M. |
| Total operating income |  | $ | 92,053 |  |  | $ | 134,164 |  |  |  |  | (31.4) | % |  | $ | 202,694 |  |  | $ | 284,754 |  |  |  |  | (28.8) | % |
| Operating Margin |  | 15.0 | % |  | 21.7 | % |  |  |  |  |  | 16.6 | % |  | 22.9 | % |  |  |  |  |
| Interest expense |  | 10,056 |  |  | 4,368 |  |  |  |  |  |  | 19,702 |  |  | 8,670 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (1,404) |  |  | 14,124 |  |  |  |  |  |  | (3,079) |  |  | 21,860 |  |  |  |  |  |
| Other (income) expense, net |  | (2,050) |  |  | 6,060 |  |  |  |  |  |  | (8,283) |  |  | 10,487 |  |  |  |  |  |
| Income before income taxes |  | $ | 85,451 |  |  | $ | 109,612 |  |  |  |  | (22.0) | % |  | $ | 194,354 |  |  | $ | 243,737 |  |  |  |  | (20.3) | % |

[0000889331-23-000129:8k_2_02:52]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-23-000129:8k_2_02:53]
N.M. - Not meaningful

[0000889331-23-000129:8k_2_02:54]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2023 |  | 2022 |  | %(Decline) |  | 2023 |  | 2022 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 22.8 | % |  | 29.6 | % |  | (6.8) | % |  | 24.0 | % |  | 31.3 | % |  | (7.3) | % |
| Transportation |  | 4.5 | % |  | 10.1 | % |  | (5.6) | % |  | 4.8 | % |  | 12.2 | % |  | (7.4) | % |
| Industrial |  | 16.8 | % |  | 19.5 | % |  | (2.7) | % |  | 18.5 | % |  | 18.4 | % |  | 0.1 | % |

[0000889331-23-000129:8k_2_02:55]
LITTELFUSE, INC.

[0000889331-23-000129:8k_2_02:56]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-23-000129:8k_2_02:57]
(In millions of USD except per share amounts - unaudited)

[0000889331-23-000129:8k_2_02:58]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-23 |  | Q2-22 |  | YTD-23 |  | YTD-22 |
| GAAP diluted EPS |  | $ | 2.79 |  |  | $ | 3.48 |  |  | $ | 6.33 |  |  | $ | 8.19 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.33 |  |  | 0.78 |  |  | 0.42 |  |  | 1.06 |  |
| Adjusted diluted EPS |  | $ | 3.12 |  |  | $ | 4.26 |  |  | $ | 6.75 |  |  | $ | 9.25 |  |

[0000889331-23-000129:8k_2_02:59]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q2-23 |  | Q2-22 |  | YTD-23 |  | YTD-22 |
| Acquisition-related and integration costs (a) |  | $ | 3.8 |  |  | $ | 4.8 |  |  | $ | 7.2 |  |  | $ | 8.6 |  |
| Purchase accounting inventory adjustments (b) |  | — |  |  | — |  |  | — |  |  | 4.8 |  |
| Restructuring, impairment and other charges (c) |  | 6.9 |  |  | 0.6 |  |  | 8.7 |  |  | 0.8 |  |
| Non-GAAP adjustments to operating income |  | 10.7 |  |  | 5.4 |  |  | 15.9 |  |  | 14.2 |  |
| Other income, net (d) |  | — |  |  | (0.5) |  |  | (0.2) |  |  | (0.5) |  |
| Non-operating foreign exchange (gain) loss |  | (1.4) |  |  | 14.1 |  |  | (3.1) |  |  | 21.9 |  |
| Non-GAAP adjustments to income before income taxes |  | 9.3 |  |  | 19.0 |  |  | 12.6 |  |  | 35.6 |  |
| Income taxes (e) |  | 1.0 |  |  | (0.4) |  |  | 1.9 |  |  | 9.1 |  |
| Non-GAAP adjustments to net income |  | $ | 8.3 |  |  | $ | 19.4 |  |  | $ | 10.7 |  |  | $ | 26.5 |  |
| Total EPS impact |  | $ | 0.33 |  |  | $ | 0.78 |  |  | $ | 0.42 |  |  | $ | 1.06 |  |

[0000889331-23-000129:8k_2_02:60]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-23 |  | Q2-22 |  | YTD-23 |  | YTD-22 |
| Net sales |  | $ | 612.0 |  |  | $ | 618.4 |  |  | $ | 1,221.8 |  |  | $ | 1,241.8 |  |
| GAAP operating income |  | $ | 92.1 |  |  | $ | 134.2 |  |  | $ | 202.7 |  |  | $ | 284.8 |  |
| Add back non-GAAP adjustments |  | 10.7 |  |  | 5.4 |  |  | 15.9 |  |  | 14.2 |  |
| Adjusted operating income |  | $ | 102.8 |  |  | $ | 139.6 |  |  | $ | 218.6 |  |  | $ | 299.0 |  |
| Adjusted operating margin |  | 16.8 | % |  | 22.6 | % |  | 17.9 | % |  | 24.1 | % |
| Add back amortization |  | 16.9 |  |  | 11.6 |  |  | 33.8 |  |  | 24.3 |  |
| Add back depreciation |  | 18.0 |  |  | 15.7 |  |  | 35.6 |  |  | 31.3 |  |
| Adjusted EBITDA |  | $ | 137.7 |  |  | $ | 166.9 |  |  | $ | 288.0 |  |  | $ | 354.6 |  |
| Adjusted EBITDA margin |  | 22.5 | % |  | 27.0 | % |  | 23.6 | % |  | 28.6 | % |

[0000889331-23-000129:8k_2_02:61]
| Adjusted EBITDA by Segment |  | Q2-23 |  | Q2-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 79.8 |  |  | $ | 7.8 |  |  | $ | 15.1 |  |  | $ | 106.0 |  |  | $ | 18.3 |  |  | $ | 15.3 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 10.1 |  |  | 4.2 |  |  | 2.7 |  |  | 6.1 |  |  | 4.3 |  |  | 1.2 |  |
| Add back depreciation |  | 9.7 |  |  | 6.9 |  |  | 1.4 |  |  | 8.4 |  |  | 6.3 |  |  | 1.0 |  |
| Adjusted EBITDA |  | $ | 99.6 |  |  | $ | 18.9 |  |  | $ | 19.2 |  |  | $ | 120.5 |  |  | $ | 28.9 |  |  | $ | 17.5 |  |
| Adjusted EBITDA Margin |  | 28.5 | % |  | 11.0 | % |  | 21.4 | % |  | 33.6 | % |  | 15.9 | % |  | 22.3 | % |

[0000889331-23-000129:8k_2_02:62]
| Adjusted EBITDA by Segment |  | YTD-23 |  | YTD-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 170.0 |  |  | $ | 16.3 |  |  | $ | 32.2 |  |  | $ | 226.5 |  |  | $ | 44.6 |  |  | $ | 27.8 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 20.3 |  |  | 8.6 |  |  | 4.9 |  |  | 12.8 |  |  | 9.0 |  |  | 2.5 |  |
| Add back depreciation |  | 19.5 |  |  | 13.6 |  |  | 2.5 |  |  | 17.1 |  |  | 12.3 |  |  | 1.9 |  |
| Adjusted EBITDA |  | $ | 209.9 |  |  | $ | 38.5 |  |  | $ | 39.6 |  |  | $ | 256.4 |  |  | $ | 65.9 |  |  | $ | 32.2 |  |
| Adjusted EBITDA Margin |  | 29.6 | % |  | 11.4 | % |  | 22.8 | % |  | 35.4 | % |  | 18.0 | % |  | 21.3 | % |

[0000889331-23-000129:8k_2_02:63]
| Net sales reconciliation |  | Q2-23 vs. Q2-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (2) | % |  | (5) | % |  | 15 | % |  | (1) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 11 | % |  | 1 | % |  | 6 | % |  | 7 | % |
| FX impact |  | — | % |  | — | % |  | — | % |  | — | % |
| Organic net sales (decline) growth |  | (13) | % |  | (6) | % |  | 9 | % |  | (8) | % |

[0000889331-23-000129:8k_2_02:64]
| Net sales reconciliation |  | YTD-23 vs. YTD-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (2) | % |  | (8) | % |  | 15 | % |  | (2) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 12 | % |  | — | % |  | 5 | % |  | 7 | % |
| FX impact |  | (1) | % |  | (1) | % |  | (1) | % |  | (1) | % |
| Organic net sales (decline) growth |  | (13) | % |  | (7) | % |  | 11 | % |  | (8) | % |

[0000889331-23-000129:8k_2_02:65]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-23 |  | Q2-22 |  | YTD-23 |  | YTD-22 |
| Income taxes |  | $ | 15.4 |  |  | $ | 22.6 |  |  | $ | 35.5 |  |  | $ | 39.2 |  |
| Effective rate |  | 18.0 | % |  | 20.6 | % |  | 18.3 | % |  | 16.1 | % |
| Non-GAAP adjustments - income taxes |  | 1.0 |  |  | (0.4) |  |  | 1.9 |  |  | 9.1 |  |
| Adjusted income taxes |  | $ | 16.4 |  |  | $ | 22.2 |  |  | $ | 37.4 |  |  | $ | 48.3 |  |
| Adjusted effective rate |  | 17.4 | % |  | 17.3 | % |  | 18.1 | % |  | 17.3 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-23 |  | Q2-22 |  | YTD-23 |  | YTD-22 |
| Net cash provided by operating activities |  | $ | 98.2 |  |  | $ | 113.6 |  |  | $ | 151.6 |  |  | $ | 165.3 |  |
| Less: Purchases of property, plant and equipment |  | (15.8) |  |  | (26.4) |  |  | (41.5) |  |  | (56.2) |  |
| Free cash flow |  | $ | 82.4 |  |  | $ | 87.2 |  |  | $ | 110.1 |  |  | $ | 109.1 |  |

[0000889331-23-000129:8k_2_02:66]
| Consolidated Total Debt |  | As of July 1, 2023 |
| Consolidated Total Debt |  | $ | 1,001.7 |  |
| Unamortized debt issuance costs |  | 4.3 |  |
| Consolidated funded indebtedness |  | 1,006.0 |  |
| Cash held in U.S. (up to $400 million) |  | 127.4 |
| Net debt |  | $ | 878.6 |  |
| Consolidated EBITDA |  | Twelve Months Ended July 1, 2023 |
| Net Income |  | $ | 327.4 |  |
| Interest expense |  | 37.2 |  |
| Income taxes |  | 66.1 |  |
| Depreciation |  | 69.3 |  |
| Amortization |  | 65.1 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 24.6 |  |
| Purchase accounting inventory step-up charge |  | 10.8 |  |
| Unrealized loss on investments |  | 0.8 |  |
| Impairment charges |  | 8.5 |  |
| Other |  | 19.4 |  |
| Consolidated EBITDA (1) |  | $ | 629.2 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.4x |

[0000889331-23-000129:8k_2_02:67]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2023 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-23-000129:8k_2_02:68]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-23-000129:8k_2_02:69]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-23-000129:8k_2_02:70]
Note: Total will not always foot due to rounding.

[0000889331-23-000129:8k_2_02:71]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-23-000129:8k_2_02:72]
(b) reflected in cost of sales.

[0000889331-23-000129:8k_2_02:73]
(c) reflected in restructuring, impairment and other charges.

[0000889331-23-000129:8k_2_02:74]
(d) reflected YTD gain of $0.2 million from the sale of a building within the Electronics segment in the first quarter of 2023. 2022 amount included $0.5 million gain from the sale of a building within Transportation segment.

[0000889331-23-000129:8k_2_02:75]
(e) reflected the tax impact associated with the non-GAAP adjustments, and 2022 amount includes the one-time net benefit of $7.2 million that resulted from the dissolution of one of the Company’s affiliates.

[0000889331-23-000129:8k_2_02:76]
###
