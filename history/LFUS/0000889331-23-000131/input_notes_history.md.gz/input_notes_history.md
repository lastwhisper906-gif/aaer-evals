# LFUS note change history — 0000889331-23-000095 → 0000889331-23-000131


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000889331-23-000131:note_history:1]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.
  (was, 2023-05-03, similarity 0.9846):
[0000889331-23-000095:note_history:1]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

- changed (2023-08-02):
[0000889331-23-000131:note_history:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 31, 2022, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2023-05-03, similarity 0.9996):
[0000889331-23-000095:note_history:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 31, 2022, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

- changed (2023-08-02):
[0000889331-23-000131:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 1, 2023 and July 2, 2022:
  (was, 2023-05-03, similarity 0.9191):
[0000889331-23-000095:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 1, 2023 and April 2, 2022:

- added (2023-08-02):
[0000889331-23-000131:note_history:4]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,852 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,852 |  |  | $ | 301,450 |  |  | $ | — |  |  | $ | — |  |  | $ | 301,450 |  |
| Electronics – Semiconductor |  | 197,295 |  |  | — |  |  | — |  |  | 197,295 |  |  | 407,290 |  |  | — |  |  | — |  |  | 407,290 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  | — |  |  | — |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |

- added (2023-08-02):
[0000889331-23-000131:note_history:5]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  |  |  |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- changed (2023-08-02):
[0000889331-23-000131:note_history:6]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its
  (was, 2023-05-03, similarity 0.7646):
[0000889331-23-000095:note_history:6]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2023-08-02):
[0000889331-23-000131:note_history:7]
price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- changed (2023-08-02):
[0000889331-23-000131:note_history:8]
Cash, Cash Equivalents, and Restricted Cash
  (was, 2023-05-03, similarity 0.9882):
[0000889331-23-000095:note_history:8]
Cash, Cash Equivalents and Restricted Cash

- changed (2023-08-02):
[0000889331-23-000131:note_history:9]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at July 1, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2023-05-03, similarity 0.9843):
[0000889331-23-000095:note_history:9]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at April 1, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2023-08-02):
[0000889331-23-000131:note_history:10]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 480,743 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 771 |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,580 |  |  | 1,549 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 483,094 |  |  | $ | 564,939 |  |
  (was, 2023-05-03, similarity 0.9853):
[0000889331-23-000095:note_history:10]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 425,127 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 812 |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,586 |  |  | 1,549 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 427,525 |  |  | $ | 564,939 |  |

- removed (2023-08-02):
[0000889331-23-000095:note_history:11]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 148,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 148,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 209,995 |  |  | — |  |  | — |  |  | 209,995 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |

- removed (2023-08-02):
[0000889331-23-000095:note_history:12]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000889331-23-000131:note_history:13]
The carrying amounts of debt at July 1, 2023 and December 31, 2022 are as follows:
  (was, 2023-05-03, similarity 0.9524):
[0000889331-23-000095:note_history:13]
The carrying amounts of debt at April 1, 2023 and December 31, 2022 are as follows:

- changed (2023-08-02):
[0000889331-23-000131:note_history:14]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 292,500 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,220 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,298 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,942 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,302) |  |  | (4,847) |  |
| Total debt |  | 1,001,658 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,435) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 864,223 |  |  | $ | 866,623 |  |
  (was, 2023-05-03, similarity 0.9555):
[0000889331-23-000095:note_history:14]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 294,375 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,706 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,693 |  |  | 101,265 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | — |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 8,651 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,571) |  |  | (4,847) |  |
| Total debt |  | 1,004,854 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,929) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 866,925 |  |  | $ | 866,623 |  |

- changed (2023-08-02):
[0000889331-23-000131:note_history:15]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended July 1, 2023, the Company made payments of $1.9 million and $3.8 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $292.5 million, respectively, as of July 1, 2023.
  (was, 2023-05-03, similarity 0.8793):
[0000889331-23-000095:note_history:15]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended April 1, 2023, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $294.4 million, respectively, as of April 1, 2023.

- changed (2023-08-02):
[0000889331-23-000131:note_history:16]
As of July 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.45%.
  (was, 2023-05-03, similarity 0.9668):
[0000889331-23-000095:note_history:16]
As of April 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 5.91%.

- changed (2023-08-02):
[0000889331-23-000131:note_history:17]
As of July 1, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of July 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2023-05-03, similarity 0.6496):
[0000889331-23-000095:note_history:17]
As of April 1, 2023, the Company had no outstanding letters of credit under the Credit Facility and had $600.0 million of borrowing capacity available under the revolving Credit Facility. As of April 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2023-08-02):
[0000889331-23-000131:note_history:18]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At July 1, 2023, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2023-05-03, similarity 0.9921):
[0000889331-23-000095:note_history:18]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At April 1, 2023, the Company was in compliance with all covenants under the Senior Notes.

- changed (2023-08-02):
[0000889331-23-000131:note_history:19]
Interest paid on all Company debt was $10.3 million and $2.3 million for the three months ended July 1, 2023 and July 2, 2022, respectively, and $21.3 million and $8.4 million for the six months ended July 1, 2023 and July 2, 2022, respectively.
  (was, 2023-05-03, similarity 0.7072):
[0000889331-23-000095:note_history:19]
Interest paid on all Company debt was $11.0 million and $6.0 million for the three months ended April 1, 2023 and April 2, 2022, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000889331-23-000131:note_history:20]
The carrying amounts of debt at July 1, 2023 and December 31, 2022 are as follows:
  (was, 2023-05-03, similarity 0.9524):
[0000889331-23-000095:note_history:20]
The carrying amounts of debt at April 1, 2023 and December 31, 2022 are as follows:

- changed (2023-08-02):
[0000889331-23-000131:note_history:21]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 292,500 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,220 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,298 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,942 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,302) |  |  | (4,847) |  |
| Total debt |  | 1,001,658 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,435) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 864,223 |  |  | $ | 866,623 |  |
  (was, 2023-05-03, similarity 0.9555):
[0000889331-23-000095:note_history:21]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 294,375 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,706 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,693 |  |  | 101,265 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | — |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 8,651 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,571) |  |  | (4,847) |  |
| Total debt |  | 1,004,854 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,929) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 866,925 |  |  | $ | 866,623 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-08-02):
[0000889331-23-000131:note_history:22]
|  |  | Three Months Ended July 1, 2023 |  | Three Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.1 |  | 2.9 |  |  | 0.1 |  | 0.1 |  | 3.0 |  |
|  |  | Six Months Ended July 1, 2023 |  | Six Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.1 |  | 0.2 |  | 5.6 |  |  | 0.3 |  | 0.2 |  | 5.9 |  |
|  |  | July 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.7 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2023-08-02):
[0000889331-23-000095:note_history:23]
|  |  | Three Months Ended April 1, 2023 |  | Three Months Ended April 2, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.0 |  | $ | 0.1 |  | $ | 2.7 |  |  | $ | 0.2 |  | $ | 0.1 |  | $ | 2.9 |  |
|  |  | April 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.6 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-08-02):
[0000889331-23-000131:note_history:24]
|  |  | Three Months Ended July 1, 2023 |  | Three Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.1 |  | 2.9 |  |  | 0.1 |  | 0.1 |  | 3.0 |  |
|  |  | Six Months Ended July 1, 2023 |  | Six Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.1 |  | 0.2 |  | 5.6 |  |  | 0.3 |  | 0.2 |  | 5.9 |  |
|  |  | July 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.7 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2023-08-02):
[0000889331-23-000095:note_history:25]
|  |  | Three Months Ended April 1, 2023 |  | Three Months Ended April 2, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.0 |  | $ | 0.1 |  | $ | 2.7 |  |  | $ | 0.2 |  | $ | 0.1 |  | $ | 2.9 |  |
|  |  | April 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.6 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000889331-23-000131:note_history:26]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 1, 2023 and July 2, 2022:
  (was, 2023-05-03, similarity 0.9191):
[0000889331-23-000095:note_history:26]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 1, 2023 and April 2, 2022:

- added (2023-08-02):
[0000889331-23-000131:note_history:27]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,852 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,852 |  |  | $ | 301,450 |  |  | $ | — |  |  | $ | — |  |  | $ | 301,450 |  |
| Electronics – Semiconductor |  | 197,295 |  |  | — |  |  | — |  |  | 197,295 |  |  | 407,290 |  |  | — |  |  | — |  |  | 407,290 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  | — |  |  | — |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |

- added (2023-08-02):
[0000889331-23-000131:note_history:28]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  |  |  |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- removed (2023-08-02):
[0000889331-23-000095:note_history:29]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 148,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 148,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 209,995 |  |  | — |  |  | — |  |  | 209,995 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |

- removed (2023-08-02):
[0000889331-23-000095:note_history:30]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000889331-23-000131:note_history:31]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its
  (was, 2023-05-03, similarity 0.7646):
[0000889331-23-000095:note_history:31]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2023-08-02):
[0000889331-23-000131:note_history:32]
price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
