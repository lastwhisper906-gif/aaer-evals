# LFUS 8-K — 0000889331-19-000049 filed 2019-10-30

## item codes, every 8-K on or before 2019-10-30

- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2019-10-30

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-19-000049:8k_2_02:1]
EX-99.1
2
q32019earningsreleasee.htm
EXHIBIT 99.1

[0000889331-19-000049:8k_2_02:2]
Exhibit

[0000889331-19-000049:8k_2_02:3]
Exhibit 99.1

[0000889331-19-000049:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-19-000049:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS FOR 2019

[0000889331-19-000049:8k_2_02:6]
Company performance in line with expectations

[0000889331-19-000049:8k_2_02:7]
CHICAGO, October 30, 2019 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the third quarter ended September 28, 2019:

[0000889331-19-000049:8k_2_02:8]
| • | Net sales of $362.0 million were down 18% versus the prior year period, and down 16% organically, primarily due to ongoing global trade uncertainties, excess electronics channel inventories and declines in global auto production |

[0000889331-19-000049:8k_2_02:9]
| • | Segment performance versus the prior year period: |

[0000889331-19-000049:8k_2_02:10]
| • | Electronics sales decreased 23% (down 21% organically) |

[0000889331-19-000049:8k_2_02:11]
| • | Automotive sales decreased 9% (down 7% organically) |

[0000889331-19-000049:8k_2_02:12]
| • | Industrial sales increased 6% (up 7% organically) |

[0000889331-19-000049:8k_2_02:13]
| • | GAAP diluted EPS was $1.44; adjusted diluted EPS was $1.78 and includes $0.17 of benefits related to certain tax items and a non-operating mark-to-market gain that were not in the company's original guidance |

[0000889331-19-000049:8k_2_02:14]
| • | GAAP effective tax rate was 13.9% and the adjusted effective tax rate was 15.5% |

[0000889331-19-000049:8k_2_02:15]
| • | During the quarter, the company repurchased approximately $49.5 million of common stock |

[0000889331-19-000049:8k_2_02:16]
| • | Year-to-date, cash flow from operations was $160.9 million and free cash flow was $122.5 million, representing a 105% conversion from net income |

[0000889331-19-000049:8k_2_02:17]
“Our performance this quarter reflects the successful execution by our global teams to actively manage costs as we continue to work through the challenging macro environment,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “While navigating the soft demand, we achieved an adjusted EBITDA margin of 21% to deliver adjusted EPS above guidance. Beyond the current back-drop, we remain well-positioned to deliver ongoing superior value for our stakeholders.”

[0000889331-19-000049:8k_2_02:18]
-more-

[0000889331-19-000049:8k_2_02:19]
For the fourth quarter of 2019*, the company expects:

[0000889331-19-000049:8k_2_02:20]
| • | Net sales in the range of $333 to $345 million |

[0000889331-19-000049:8k_2_02:21]
| • | Adjusted diluted EPS in the range of $1.06 to $1.20 |

[0000889331-19-000049:8k_2_02:22]
| • | Adjusted effective tax rate in the range of 19% - 20% |

[0000889331-19-000049:8k_2_02:23]
For the full year of 2019*, the company expects:

[0000889331-19-000049:8k_2_02:24]
| • | Adjusted effective tax rate of approximately 18% |

[0000889331-19-000049:8k_2_02:25]
| • | Free cash flow to exceed 100% of net income |

[0000889331-19-000049:8k_2_02:26]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-19-000049:8k_2_02:27]
Dividend

[0000889331-19-000049:8k_2_02:28]
| • | The company will pay a cash dividend on its common stock of $0.48 per share on December 5, 2019 to shareholders of record as November 21, 2019 |

[0000889331-19-000049:8k_2_02:29]
Conference Call and Webcast Information

[0000889331-19-000049:8k_2_02:30]
Littelfuse will host a conference call today, Wednesday, October 30, 2019, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-19-000049:8k_2_02:31]
About Littelfuse

[0000889331-19-000049:8k_2_02:32]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Our 11,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-19-000049:8k_2_02:33]
-more-

[0000889331-19-000049:8k_2_02:34]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 29, 2018. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 29, 2018.

[0000889331-19-000049:8k_2_02:35]
Non-GAAP Financial Measures

[0000889331-19-000049:8k_2_02:36]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate, free cash flow, net debt, adjusted gross leverage, and adjusted net leverage. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-19-000049:8k_2_02:37]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, adjusted gross leverage and adjusted net leverage are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-19-000049:8k_2_02:38]
CONTACT: Trisha Tuntland

[0000889331-19-000049:8k_2_02:39]
Head of Investor Relations

[0000889331-19-000049:8k_2_02:40]
(773) 628-2163

[0000889331-19-000049:8k_2_02:41]
###

[0000889331-19-000049:8k_2_02:42]
LFUS-F

[0000889331-19-000049:8k_2_02:43]
LITTELFUSE, INC.

[0000889331-19-000049:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-19-000049:8k_2_02:45]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 476,057 |  |  | $ | 489,733 |  |
| Short-term investments |  | 33 |  |  | 34 |  |
| Trade receivables, less allowances of $39,874 and $36,038 at September 28, 2019 and December 29, 2018, respectively |  | 226,352 |  |  | 232,892 |  |
| Inventories |  | 240,059 |  |  | 258,228 |  |
| Prepaid income taxes and income taxes receivable |  | 2,730 |  |  | 2,339 |  |
| Prepaid expenses and other current assets |  | 62,361 |  |  | 49,291 |  |
| Total current assets |  | 1,007,592 |  |  | 1,032,517 |  |
| Net property, plant, and equipment |  | 329,792 |  |  | 339,894 |  |
| Intangible assets, net of amortization |  | 326,417 |  |  | 361,474 |  |
| Goodwill |  | 813,653 |  |  | 826,715 |  |
| Investments |  | 26,662 |  |  | 25,405 |  |
| Deferred income taxes |  | 7,485 |  |  | 7,330 |  |
| Right of use lease assets, net |  | 21,598 |  |  | — |  |
| Other assets |  | 18,162 |  |  | 20,971 |  |
| Total assets |  | $ | 2,551,361 |  |  | $ | 2,614,306 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 107,211 |  |  | $ | 126,323 |  |
| Accrued liabilities |  | 114,549 |  |  | 138,405 |  |
| Accrued income taxes |  | 16,989 |  |  | 20,547 |  |
| Current portion of long-term debt |  | 10,000 |  |  | 10,000 |  |
| Total current liabilities |  | 248,749 |  |  | 295,275 |  |
| Long-term debt, less current portion |  | 668,160 |  |  | 684,730 |  |
| Deferred income taxes |  | 51,776 |  |  | 51,853 |  |
| Accrued post-retirement benefits |  | 28,725 |  |  | 31,874 |  |
| Non-current operating lease liabilities |  | 17,237 |  |  | — |  |
| Other long-term liabilities |  | 64,502 |  |  | 72,232 |  |
| Total equity |  | 1,472,212 |  |  | 1,478,342 |  |
| Total liabilities and equity |  | $ | 2,551,361 |  |  | $ | 2,614,306 |  |

[0000889331-19-000049:8k_2_02:46]
LITTELFUSE, INC.

[0000889331-19-000049:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-19-000049:8k_2_02:48]
(Unaudited)

[0000889331-19-000049:8k_2_02:49]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Net sales |  | $ | 361,971 |  |  | $ | 439,191 |  |  | $ | 1,165,350 |  |  | $ | 1,316,187 |  |
| Cost of sales |  | 231,025 |  |  | 259,597 |  |  | 737,368 |  |  | 817,983 |  |
| Gross profit |  | 130,946 |  |  | 179,594 |  |  | 427,982 |  |  | 498,204 |  |
| Selling, general, and administrative expenses |  | 54,224 |  |  | 69,782 |  |  | 174,845 |  |  | 220,540 |  |
| Research and development expenses |  | 19,728 |  |  | 20,454 |  |  | 62,595 |  |  | 65,742 |  |
| Amortization of intangibles |  | 9,827 |  |  | 13,130 |  |  | 30,068 |  |  | 38,501 |  |
| Total operating expenses |  | 83,779 |  |  | 103,366 |  |  | 267,508 |  |  | 324,783 |  |
| Operating income |  | 47,167 |  |  | 76,228 |  |  | 160,474 |  |  | 173,421 |  |
| Interest expense |  | 5,559 |  |  | 5,775 |  |  | 16,834 |  |  | 16,980 |  |
| Foreign exchange loss (gain) |  | 4,968 |  |  | 982 |  |  | 5,636 |  |  | (6,372 | ) |
| Other (income) expense, net |  | (4,764 | ) |  | 1,259 |  |  | (3,406 | ) |  | (2,362 | ) |
| Income before income taxes |  | 41,404 |  |  | 68,212 |  |  | 141,410 |  |  | 165,175 |  |
| Income taxes |  | 5,757 |  |  | 14,666 |  |  | 24,982 |  |  | 33,275 |  |
| Net income |  | $ | 35,647 |  |  | $ | 53,546 |  |  | $ | 116,428 |  |  | $ | 131,900 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.46 |  |  | $ | 2.13 |  |  | $ | 4.72 |  |  | $ | 5.31 |  |
| Diluted |  | $ | 1.44 |  |  | $ | 2.10 |  |  | $ | 4.68 |  |  | $ | 5.23 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,482 |  |  | 25,109 |  |  | 24,646 |  |  | 24,817 |  |
| Diluted |  | 24,684 |  |  | 25,471 |  |  | 24,894 |  |  | 25,212 |  |
| Comprehensive income |  | $ | 18,621 |  |  | $ | 45,599 |  |  | $ | 101,744 |  |  | $ | 107,732 |  |

[0000889331-19-000049:8k_2_02:50]
LITTELFUSE, INC.

[0000889331-19-000049:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-19-000049:8k_2_02:52]
(Unaudited)

[0000889331-19-000049:8k_2_02:53]
|  |  | Nine Months Ended |
| (in thousands) |  | September 28, 2019 |  | September 29, 2018 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 116,428 |  |  | $ | 131,900 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 93,511 |  |  | 130,495 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | 2,781 |  |  | (20,588 | ) |
| Inventories |  | 18,102 |  |  | (17,624 | ) |
| Accounts payable |  | (29,453 | ) |  | 17,033 |  |
| Accrued liabilities and income taxes |  | (44,241 | ) |  | 20,736 |  |
| Prepaid expenses and other assets |  | 3,735 |  |  | (9,836 | ) |
| Net cash provided by operating activities |  | 160,863 |  |  | 252,116 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (775 | ) |  | (313,475 | ) |
| Purchases of property, plant, and equipment |  | (38,397 | ) |  | (55,946 | ) |
| Proceeds from sale of property, plant, and equipment |  | 6,212 |  |  | 858 |  |
| Net cash used in investing activities |  | (32,960 | ) |  | (368,563 | ) |
| FINANCING ACTIVITIES |  |  |  |  |
| Net (payments) proceeds from credit facility and senior notes |  | (7,500 | ) |  | 207,475 |  |
| Purchases of common stock |  | (99,387 | ) |  | — |  |
| Cash dividends paid |  | (32,990 | ) |  | (29,258 | ) |
| All other cash provided by financing activities |  | 4,412 |  |  | 17,042 |  |
| Net cash (used in) provided by financing activities |  | (135,465 | ) |  | 195,259 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (6,114 | ) |  | (10,273 | ) |
| (Decrease) increase in cash and cash equivalents |  | (13,676 | ) |  | 68,539 |  |
| Cash and cash equivalents at beginning of period |  | 489,733 |  |  | 429,676 |  |
| Cash and cash equivalents at end of period |  | $ | 476,057 |  |  | $ | 498,215 |  |

[0000889331-19-000049:8k_2_02:54]
LITTELFUSE, INC.

[0000889331-19-000049:8k_2_02:55]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-19-000049:8k_2_02:56]
(Unaudited)

[0000889331-19-000049:8k_2_02:57]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Growth /(Decline) |  | 2019 |  | 2018 |  | Change |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 227,252 |  |  | $ | 296,472 |  |  | $ | (69,220 | ) |  | (23.3 | )% |  | $ | 752,199 |  |  | $ | 860,240 |  |  | $ | (108,041 | ) |  | (12.6 | )% |
| Automotive |  | 104,681 |  |  | 114,416 |  |  | (9,735 | ) |  | (8.5 | )% |  | 326,814 |  |  | 367,718 |  |  | (40,904 | ) |  | (11.1 | )% |
| Industrial |  | 30,038 |  |  | 28,303 |  |  | 1,735 |  |  | 6.1 | % |  | 86,337 |  |  | 88,229 |  |  | (1,892 | ) |  | (2.1 | )% |
| Total net sales |  | $ | 361,971 |  |  | $ | 439,191 |  |  | $ | (77,220 | ) |  | (17.6 | )% |  | $ | 1,165,350 |  |  | $ | 1,316,187 |  |  | $ | (150,837 | ) |  | (11.5 | )% |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 34,567 |  |  | $ | 72,464 |  |  | $ | (37,897 | ) |  | (52.3 | )% |  | $ | 127,233 |  |  | $ | 193,739 |  |  | $ | (66,506 | ) |  | (34.3 | )% |
| Automotive |  | 11,437 |  |  | 10,863 |  |  | 574 |  |  | 5.3 | % |  | 34,987 |  |  | 44,965 |  |  | (9,978 | ) |  | (22.2 | )% |
| Industrial |  | 6,822 |  |  | 4,134 |  |  | 2,688 |  |  | 65.0 | % |  | 16,158 |  |  | 14,123 |  |  | 2,035 |  |  | 14.4 | % |
| Other(a) |  | (5,659 | ) |  | (11,233 | ) |  |  |  | N.M. |  |  | (17,904 | ) |  | (79,406 | ) |  |  |  |  | N.M. |  |
| Total operating income |  | $ | 47,167 |  |  | $ | 76,228 |  |  | $ | (29,061 | ) |  | (38.1 | )% |  | $ | 160,474 |  |  | $ | 173,421 |  |  | $ | (12,947 | ) |  | (7.5 | )% |
| Operating Margin |  | 13.0 | % |  | 17.4 | % |  |  |  |  |  | 13.8 | % |  | 13.2 | % |  |  |  |  |
| Interest expense |  | 5,559 |  |  | 5,775 |  |  |  |  |  |  | 16,834 |  |  | 16,980 |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 4,968 |  |  | 982 |  |  |  |  |  |  | 5,636 |  |  | (6,372 | ) |  |  |  |  |
| Other (income) expense, net |  | (4,764 | ) |  | 1,259 |  |  |  |  |  |  | (3,406 | ) |  | (2,362 | ) |  |  |  |  |
| Income before income taxes |  | $ | 41,404 |  |  | $ | 68,212 |  |  | $ | (26,808 | ) |  | (39.3 | )% |  | $ | 141,410 |  |  | $ | 165,175 |  |  | $ | (23,765 | ) |  | (14.4 | )% |

[0000889331-19-000049:8k_2_02:58]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and other charges, and restructuring charges. (See Supplemental Financial Information for details.)

[0000889331-19-000049:8k_2_02:59]
N.M. - Not meaningful

[0000889331-19-000049:8k_2_02:60]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2019 |  | 2018 |  | %Growth /(Decline) |  | 2019 |  | 2018 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 15.2 | % |  | 24.4 | % |  | (9.2 | )% |  | 16.9 | % |  | 22.5 | % |  | (5.6 | )% |
| Automotive |  | 10.9 | % |  | 9.5 | % |  | 1.4 | % |  | 10.7 | % |  | 12.2 | % |  | (1.5 | )% |
| Industrial |  | 22.7 | % |  | 14.6 | % |  | 8.1 | % |  | 18.7 | % |  | 16.0 | % |  | 2.7 | % |

[0000889331-19-000049:8k_2_02:61]
LITTELFUSE, INC.

[0000889331-19-000049:8k_2_02:62]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-19-000049:8k_2_02:63]
(In millions of USD except per share amounts unaudited)

[0000889331-19-000049:8k_2_02:64]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-19 |  | Q3-18 |  | YTD-19 |  | YTD-18 |
| GAAP diluted EPS |  | $ | 1.44 |  |  | $ | 2.10 |  |  | $ | 4.68 |  |  | $ | 5.23 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.34 |  | 0.39 |  | 0.97 |  |  | 2.34 |  |
| Adjusted diluted EPS |  | $ | 1.78 |  |  | $ | 2.49 |  |  | $ | 5.65 |  |  | $ | 7.57 |  |

[0000889331-19-000049:8k_2_02:65]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q3-19 |  | Q3-18 |  | YTD-19 |  | YTD-18 |
| Acquisition related and integration costs (a) |  | $ | 3.2 |  |  | $ | 2.9 |  |  | $ | 6.9 |  |  | $ | 17.0 |  |
| Restructuring, impairment and other charges (b) |  | 2.5 |  |  | 5.2 |  |  | 11.0 |  |  | 10.2 |  |
| Amortization backlog - IXYS (c) |  | — |  |  | 3.1 |  |  | — |  |  | 8.7 |  |
| Change in control - IXYS (d) |  | — |  |  | — |  |  | — |  |  | 2.1 |  |
| Acquisition related stock-based compensation charge (e) |  | — |  |  | — |  |  | — |  |  | 4.5 |  |
| Purchase accounting inventory adjustments (f) |  | — |  |  | — |  |  | — |  |  | 36.9 |  |
| Non-GAAP adjustments to operating income |  | 5.7 |  |  | 11.2 |  |  | 17.9 |  |  | 79.4 |  |
| Other expense, net (g) |  | — |  |  | — |  |  | 5.8 |  |  | — |  |
| Non-operating foreign exchange loss (gain) |  | 5.0 |  |  | 1.0 |  |  | 5.6 |  |  | (6.4 | ) |
| Non-GAAP adjustments to income before income taxes |  | 10.7 |  |  | 12.2 |  |  | 29.3 |  |  | 73.0 |  |
| Income taxes (h) |  | 2.3 |  |  | 2.2 |  |  | 5.1 |  |  | 14.1 |  |
| Non-GAAP adjustments to net income |  | $ | 8.4 |  |  | $ | 10.0 |  |  | $ | 24.2 |  |  | $ | 58.9 |  |
| Total EPS impact |  | $ | 0.34 |  |  | $ | 0.39 |  |  | $ | 0.97 |  |  | $ | 2.34 |  |

[0000889331-19-000049:8k_2_02:66]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-19 |  | Q3-18 |  | YTD-19 |  | YTD-18 |
| Net sales |  | $ | 362.0 |  |  | $ | 439.2 |  |  | $ | 1,165.4 |  |  | $ | 1,316.2 |  |
| GAAP operating income |  | $ | 47.2 |  |  | $ | 76.2 |  |  | $ | 160.5 |  |  | $ | 173.4 |  |
| Add back non-GAAP adjustments |  | 5.7 |  |  | 11.2 |  |  | 17.9 |  |  | 79.4 |  |
| Adjusted operating income |  | $ | 52.9 |  |  | $ | 87.4 |  |  | $ | 178.4 |  |  | $ | 252.8 |  |
| Adjusted operating margin |  | 14.6 | % |  | 19.9 | % |  | 15.3 | % |  | 19.2 | % |
| Add back amortization |  | 9.8 |  |  | 10.0 |  |  | 30.1 |  |  | 29.8 |  |
| Add back depreciation |  | 13.3 |  |  | 13.1 |  |  | 39.0 |  |  | 37.6 |  |
| Adjusted EBITDA |  | $ | 76.0 |  |  | $ | 110.5 |  |  | $ | 247.5 |  |  | $ | 320.2 |  |
| Adjusted EBITDA margin |  | 21.0 | % |  | 25.2 | % |  | 21.2 | % |  | 24.3 | % |

[0000889331-19-000049:8k_2_02:67]
| Net sales reconciliation |  | Q3-19 vs. Q3-18 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | (23 | )% |  | (9 | )% |  | 6 | % |  | (18 | )% |
| Less: |  |  |  |  |  |  |  |  |
| Divestitures |  | (1 | )% |  | — |  |  | — | % |  | (1 | )% |
| FX impact |  | (1 | )% |  | (2 | )% |  | (1 | )% |  | (1 | )% |
| Organic net sales growth |  | (21 | )% |  | (7 | )% |  | 7 | % |  | (16 | )% |

[0000889331-19-000049:8k_2_02:68]
| Net sales reconciliation |  | 2019 YTD vs. 2018 YTD |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | (13 | )% |  | (11 | )% |  | (2 | )% |  | (12 | )% |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 1 | % |  | — |  |  | — |  |  | 1 | % |
| Divestitures |  | — | % |  | — | % |  | (5 | )% |  | (1 | )% |
| FX impact |  | (2 | )% |  | (3 | )% |  | (1 | )% |  | (2 | )% |
| Organic net sales growth |  | (12 | )% |  | (8 | )% |  | 4 | % |  | (10 | )% |

[0000889331-19-000049:8k_2_02:69]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-19 |  | Q3-18 |  | YTD-19 |  | YTD-18 |
| Income taxes |  | $ | 5.8 |  |  | $ | 14.7 |  |  | $ | 25.0 |  |  | $ | 33.3 |  |
| Effective rate |  | 13.9 | % |  | 21.5 | % |  | 17.7 | % |  | 20.1 | % |
| Non-GAAP adjustments - income taxes |  | 2.3 |  |  | 2.2 |  |  | 5.1 |  |  | 14.1 |  |
| Adjusted income taxes |  | $ | 8.1 |  |  | $ | 16.9 |  |  | $ | 30.1 |  |  | $ | 47.4 |  |
| Adjusted effective rate |  | 15.5 | % |  | 21.0 | % |  | 17.6 | % |  | 19.9 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-19 |  | Q3-18 |  | YTD-19 |  | YTD-18 |
| Net cash provided by operating activities |  | $ | 80.8 |  |  | $ | 111.2 |  |  | $ | 160.9 |  |  | $ | 252.1 |  |
| Less: Purchases of property, plant and equipment |  | (13.1 | ) |  | (15.6 | ) |  | (38.4 | ) |  | (55.9 | ) |
| Free cash flow |  | $ | 67.7 |  |  | $ | 95.6 |  |  | $ | 122.5 |  |  | $ | 196.2 |  |

[0000889331-19-000049:8k_2_02:70]
|  |  | Q4-18 |  | Q1-19 |  | Q2-19 |  | Q3-19 |  | For the Twelve Months Ended September 28, 2019 |
| Adjusted EBITDA |  | $ | 84.3 |  |  | $ | 89.1 |  |  | $ | 82.5 |  |  | $ | 76.0 |  |  | $ | 331.9 |  |
|  |  |  |  |  |  |  |  |  |  | September 28, 2019 |
| Current portion of long-term debt |  |  |  |  |  |  |  |  |  | $ | 10.0 |  |
| Long-term debt, less current portion |  |  |  |  |  |  |  |  |  | 668.2 |  |
| Total debt |  |  |  |  |  |  |  |  |  | $ | 678.2 |  |
| Less: Cash and cash equivalents |  |  |  |  |  |  |  |  |  | 476.1 |  |
| Net debt |  |  |  |  |  |  |  |  |  | $ | 202.1 |  |
| Adjusted Gross Leverage (defined as total debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 2.0 |
| Adjusted Net Leverage (defined as net debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 0.6 |

[0000889331-19-000049:8k_2_02:71]
Note: Total will not always foot due to rounding.

[0000889331-19-000049:8k_2_02:72]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-19-000049:8k_2_02:73]
(b) $1.8 million and $0.7 million and $0.1 million and $5.1 million reflected in cost of sales and SG&A, respectively for the three months ended September 28, 2019 and September 29, 2018, and $4.6 million and $6.4 million and $1.0 million and $9.2 million reflected in cost of sales and SG&A, respectively for the nine months ended September 28, 2019 and September 29, 2018.

[0000889331-19-000049:8k_2_02:74]
(c) reflected in amortization of intangibles.

[0000889331-19-000049:8k_2_02:75]
(d) reflected in SG&A.

[0000889331-19-000049:8k_2_02:76]
(e) $2.4 million, $1.6 million and $0.5 million reflected in SG&A, research and development expenses and cost of sales, respectively.

[0000889331-19-000049:8k_2_02:77]
(f) reflected in cost of sales.

[0000889331-19-000049:8k_2_02:78]
(g) year-to-date amounts included $2.8 million impairment charges to certain other investments, $2.6 million loss on the disposal of a business, and $0.4 million gain primarily related to the final payments for the acquisition of Monolith.

[0000889331-19-000049:8k_2_02:79]
(h) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-19-000049:8k_2_02:80]
###
