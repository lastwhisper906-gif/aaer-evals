# LFUS notes — 0000889331-19-000052


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-19-000052:notes:1]
[same as prior period, unchanged from 0000889331-19-000042:notes:1]

[0000889331-19-000052:notes:2]
[same as prior period, unchanged from 0000889331-19-000042:notes:2]

[0000889331-19-000052:notes:3]
[same as prior period, unchanged from 0000889331-19-000042:notes:3]

[0000889331-19-000052:notes:4]
[same as prior period, unchanged from 0000889331-19-000042:notes:4]

[0000889331-19-000052:notes:5]
[same as prior period, unchanged from 0000889331-19-000042:notes:5]

[0000889331-19-000052:notes:6]
[same as prior period, unchanged from 0000889331-19-000042:notes:6]

[0000889331-19-000052:notes:7]
[same as prior period, unchanged from 0000889331-19-000042:notes:7]

[0000889331-19-000052:notes:8]
[same as prior period, unchanged from 0000889331-19-000042:notes:8]

[0000889331-19-000052:notes:9]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2019 and September 29, 2018:

[0000889331-19-000052:notes:10]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

[0000889331-19-000052:notes:11]
|  |  | Three Months Ended September 29, 2018 |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

[0000889331-19-000052:notes:12]
[same as prior period, unchanged from 0000889331-19-000042:notes:12]

[0000889331-19-000052:notes:13]
[same as prior period, unchanged from 0000889331-19-000042:notes:13]

[0000889331-19-000052:notes:14]
[same as prior period, unchanged from 0000889331-19-000042:notes:14]

[0000889331-19-000052:notes:15]
[same as prior period, unchanged from 0000889331-19-000042:notes:15]

[0000889331-19-000052:notes:16]
[same as prior period, unchanged from 0000889331-19-000042:notes:16]

[0000889331-19-000052:notes:17]
[same as prior period, unchanged from 0000889331-19-000042:notes:17]

[0000889331-19-000052:notes:18]
[same as prior period, unchanged from 0000889331-19-000042:notes:18]

[0000889331-19-000052:notes:19]
[same as prior period, unchanged from 0000889331-19-000042:notes:19]

[0000889331-19-000052:notes:20]
[same as prior period, unchanged from 0000889331-19-000042:notes:20]

[0000889331-19-000052:notes:21]
[same as prior period, unchanged from 0000889331-19-000042:notes:21]

[0000889331-19-000052:notes:22]
[same as prior period, unchanged from 0000889331-19-000042:notes:22]

[0000889331-19-000052:notes:23]
Recently Adopted Accounting Standards

[0000889331-19-000052:notes:24]
In February 2016,  the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, "Leases" (Topic 842), ("ASC 842"). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption requires using a modified retrospective transition with either 1) periods prior to the adoption date being recast or 2) a cumulative-effect adjustment recognized to the opening balance of retained earnings on the adoption date with prior periods not recast.

[0000889331-19-000052:notes:25]
The Company adopted the standard on December 30, 2018 using alternative modified retrospective transition method provided in ASU No. 2018-11, "Leases (Topic 842): Target Improvements." Under this method, the Company recorded a cumulative-effect adjustment as of December 30, 2018 and did not record any retrospective adjustments to comparative periods to reflect the adoption of ASC 842. The new standard provides a number of optional practical expedients in transition. The Company has elected the ‘package of practical expedients’ which permits us not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct costs. The Company has not elected the use-of-hindsight. Adoption of  ASC 842 resulted in the recognition of operating lease right-of-use assets ("ROU") net of deferred rent of $26.1 million and lease liabilities of $29.4 million, as of December 30, 2018 for operating leases on its Condensed Consolidated Balance Sheets, with no  impact to its Condensed Consolidated Statements of Net Income and no impact on Condensed Consolidated Statements of Cash Flow. See Note 6, Lease Commitments, for further discussion.

[0000889331-19-000052:notes:26]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. The Company adopted the new standard on December 30, 2018. The adoption of this guidance did not have a material effect on our Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-19-000052:notes:27]
[same as prior period, unchanged from 0000889331-19-000042:notes:27]

[0000889331-19-000052:notes:28]
[same as prior period, unchanged from 0000889331-19-000042:notes:28]

[0000889331-19-000052:notes:29]
[same as prior period, unchanged from 0000889331-19-000042:notes:29]

[0000889331-19-000052:notes:30]
[same as prior period, unchanged from 0000889331-19-000042:notes:30]

[0000889331-19-000052:notes:31]
[same as prior period, unchanged from 0000889331-19-000042:notes:31]

[0000889331-19-000052:notes:32]
[same as prior period, unchanged from 0000889331-19-000042:notes:32]

[0000889331-19-000052:notes:33]
[same as prior period, unchanged from 0000889331-19-000042:notes:33]

[0000889331-19-000052:notes:34]
[same as prior period, unchanged from 0000889331-19-000042:notes:34]

[0000889331-19-000052:notes:35]
[same as prior period, unchanged from 0000889331-19-000042:notes:35]

[0000889331-19-000052:notes:36]
[same as prior period, unchanged from 0000889331-19-000042:notes:36]

[0000889331-19-000052:notes:37]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and nine months ended September 29, 2018 are net sales of approximately $99.7 million and $286.2 million, respectively, and an income (loss) before income taxes of $6.2 million and $(25.5) million, respectively, since the January 17, 2018 acquisition of IXYS. The Company recognized

[0000889331-19-000052:notes:38]
approximately $4.3 million and $11.8 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the three and nine months ended September 29, 2018, of which $4.5 million was recognized immediately as it related to prior services periods.

[0000889331-19-000052:notes:39]
As required by purchase accounting rules, the Company recorded a $36.9 million step-up of inventory to its fair value as of the acquisition date based on the valuation. The step-up was fully amortized as a non-cash charge to cost of goods sold during the first and second quarters of 2018, as the acquired inventory was sold, and reflected as other non-segment costs.

[0000889331-19-000052:notes:40]
During the nine months ended September 29, 2018, the Company incurred approximately $11.0 million of legal and professional fees related to this acquisition which were primarily recognized as selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-19-000052:notes:41]
[same as prior period, unchanged from 0000889331-19-000042:notes:40]

[0000889331-19-000052:notes:42]
[same as prior period, unchanged from 0000889331-19-000042:notes:41]

[0000889331-19-000052:notes:43]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 29, 2018 |  | September 29, 2018 |
| Net sales |  | $ | 439,191 |  |  | $ | 1,332,900 |  |
| Income before income taxes |  | 71,737 |  |  | 228,503 |  |
| Net income |  | 56,060 |  |  | 179,264 |  |
| Net income per share — basic |  | 2.23 |  |  | 7.17 |  |
| Net income per share — diluted |  | 2.18 |  |  | 7.16 |  |

[0000889331-19-000052:notes:44]
[same as prior period, unchanged from 0000889331-19-000042:notes:43]

[0000889331-19-000052:notes:45]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 29, 2018 |  | September 29, 2018 |
| Amortization(a) |  | $ | 3,104 |  |  | $ | 8,289 |  |
| Transaction costs(b) |  | — |  |  | 9,976 |  |
| Amortization of inventory step-up(c) |  | — |  |  | 36,927 |  |
| Stock compensation(d) |  | 421 |  |  | 5,110 |  |
| Income tax impact of above items |  | (1,011 | ) |  | (14,290 | ) |

[0000889331-19-000052:notes:46]
| (a) | The amortization adjustment for the three and nine months ended September 29, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and was fully amortized in the fiscal 2017 pro forma results. |

[0000889331-19-000052:notes:47]
| (b) | The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the nine months ended September 29, 2018 and recognition of those fees during the nine months ended September 30, 2017. |

[0000889331-19-000052:notes:48]
| (c) | The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the three and nine months ended September 29, 2018 and recognition of those costs during the three and nine months ended September 30, 2017. The inventory step-up was amortized over five months as the inventory was sold. |

[0000889331-19-000052:notes:49]
(d)
The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the nine months ended September 29, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-19-000052:notes:50]
[same as prior period, unchanged from 0000889331-19-000042:notes:49]

[0000889331-19-000052:notes:51]
The components of inventories at September 28, 2019 and December 29, 2018 are as follows:

[0000889331-19-000052:notes:52]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Raw materials |  | $ | 71,327 |  |  | $ | 69,883 |  |
| Work in process |  | 78,022 |  |  | 88,505 |  |
| Finished goods |  | 90,710 |  |  | 99,840 |  |
| Total |  | $ | 240,059 |  |  | $ | 258,228 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-19-000052:notes:53]
[same as prior period, unchanged from 0000889331-19-000042:notes:52]

[0000889331-19-000052:notes:54]
The components of net property, plant, and equipment at September 28, 2019 and December 29, 2018 are as follows:

[0000889331-19-000052:notes:55]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Land |  | $ | 24,699 |  |  | $ | 25,630 |  |
| Building |  | 106,062 |  |  | 114,636 |  |
| Equipment |  | 605,965 |  |  | 583,043 |  |
| Accumulated depreciation and amortization |  | (406,934 | ) |  | (383,415 | ) |
| Total |  | $ | 329,792 |  |  | $ | 339,894 |  |

[0000889331-19-000052:notes:56]
The Company recorded depreciation expense of $13.3 million and $13.1 million for the three months ended September 28, 2019 and September 29, 2018, respectively, and $39.0 million and $37.6 million for the nine months ended September 28, 2019 and September 29, 2018, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-19-000052:notes:57]
[same as prior period, unchanged from 0000889331-19-000042:notes:56]

[0000889331-19-000052:notes:58]
The amounts for goodwill and changes in the carrying value by segment for the nine months ended September 28, 2019 are as follows:

[0000889331-19-000052:notes:59]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 29, 2018 |  | $ | 656,039 |  |  | $ | 132,332 |  |  | $ | 38,344 |  |  | $ | 826,715 |  |
| Currency translation |  | (10,627 | ) |  | (2,530 | ) |  | 95 |  |  | (13,062 | ) |
| As of September 28, 2019 |  | $ | 645,412 |  |  | $ | 129,802 |  |  | $ | 38,439 |  |  | $ | 813,653 |  |

[0000889331-19-000052:notes:60]
The components of other intangible assets at September 28, 2019 are as follows:

[0000889331-19-000052:notes:61]
| (in thousands) |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Patents, licenses and software |  | $ | 136,565 |  |  | $ | 76,797 |  |  | $ | 59,768 |  |
| Distribution network |  | 43,638 |  |  | 36,014 |  |  | 7,624 |  |
| Customer relationships, trademarks, and tradenames |  | 372,627 |  |  | 113,602 |  |  | 259,025 |  |
| Total |  | $ | 552,830 |  |  | $ | 226,413 |  |  | $ | 326,417 |  |

[0000889331-19-000052:notes:62]
During the three months ended September 28, 2019 and September 29, 2018, the Company recorded amortization expense of $9.8 million and $13.1 million, respectively. During the nine months ended September 28, 2019 and September 29, 2018, the Company recorded amortization expense of $30.1 million and $38.5 million, respectively.

[0000889331-19-000052:notes:63]
Estimated annual amortization expense related to intangible assets with definite lives as of September 28, 2019 is as follows:

[0000889331-19-000052:notes:64]
| (in thousands) | Amount |
| 2019 | $ | 41,376 |  |
| 2020 | 39,206 |  |
| 2021 | 37,606 |  |
| 2022 | 36,532 |  |
| 2023 | 32,150 |  |
| 2024 and thereafter | 169,616 |  |
| Total | $ | 356,486 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000889331-19-000052:notes:65]
[same as prior period, unchanged from 0000889331-19-000042:notes:64]

[0000889331-19-000052:notes:66]
The Company leases office and production space under various non-cancelable operating leases that expire no later than 2025. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The Company also has production equipment, office equipment and vehicles under operating leases. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants.

[0000889331-19-000052:notes:67]
[same as prior period, unchanged from 0000889331-19-000042:notes:66]

[0000889331-19-000052:notes:68]
[same as prior period, unchanged from 0000889331-19-000042:notes:67]

[0000889331-19-000052:notes:69]
The following table presents the classification of ROU assets and lease liabilities as of September 28, 2019:

[0000889331-19-000052:notes:70]
| Leases(in thousands) | Condensed Consolidated Balance Sheet Classification | September 28, 2019 |
| Assets |  |  |
| Operating ROU assets | Right of use lease assets, net | $ | 21,598 |  |
| Liabilities |  |  |
| Current operating lease liabilities | Accrued liabilities | $ | 6,926 |  |
| Non-current operating lease liabilities | Non-current operating lease liabilities | 17,237 |  |
| Total lease liabilities |  | $ | 24,163 |  |

[0000889331-19-000052:notes:71]
The following table represents the lease costs for the three and nine months ended ended September 28, 2019:

[0000889331-19-000052:notes:72]
| Leases cost(in thousands) | Condensed Consolidated Statements of Net Income Classification | Three Months Ended September 28, 2019 | Nine Months EndedSeptember 28, 2019 |
| Short-term lease expenses | Cost of sales, SG&A expenses | $ | 86 |  | $ | 387 |  |
| Variable lease expenses | Cost of sales, SG&A expenses | 239 |  | 621 |  |
| Operating lease rent expenses | Cost of sales, SG&A expenses | 2,131 |  | 6,539 |  |
| Total operating lease costs | Cost of sales, SG&A expenses | $ | 2,456 |  | $ | 7,547 |  |

[0000889331-19-000052:notes:73]
| Maturity of Lease Liabilities as of September 28, 2019(in thousands) | Operating leases |
| 2019 (excluding the nine months ended September 28, 2019) | $ | 2,155 |  |
| 2020 | 7,571 |  |
| 2021 | 5,878 |  |
| 2022 | 4,873 |  |
| 2023 | 3,252 |  |
| 2024 and thereafter | 3,253 |  |
| Total lease payments | $ | 26,982 |  |
| Present value of lease liabilities | $ | 24,163 |  |

[0000889331-19-000052:notes:74]
| Operating Lease Term and Discount Rate | September 28, 2019 |
| Weighted-average remaining lease term (years) | 4.19 |  |
| Weighted-average discount rate | 5.18 | % |

[0000889331-19-000052:notes:75]
| Other Information(in thousands) | Nine Months EndedSeptember 28, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flow payments for operating leases | $ | (6,762 | ) |
| Leased assets obtained in exchange for operating lease liabilities | 2,051 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-19-000052:notes:76]
[same as prior period, unchanged from 0000889331-19-000042:notes:75]

[0000889331-19-000052:notes:77]
The components of accrued liabilities at September 28, 2019 and December 29, 2018 are as follows:

[0000889331-19-000052:notes:78]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Employee-related liabilities |  | $ | 42,076 |  |  | $ | 60,640 |  |
| Other non-income taxes |  | 32,453 |  |  | 21,523 |  |
| Operating lease liability |  | 6,926 |  |  | — |  |
| Professional services |  | 4,117 |  |  | 6,169 |  |
| Interest |  | 3,239 |  |  | 5,137 |  |
| Accrued share repurchases |  | — |  |  | 4,349 |  |
| Restructuring liability |  | 2,302 |  |  | 3,887 |  |
| Other |  | 23,436 |  |  | 36,700 |  |
| Total |  | $ | 114,549 |  |  | $ | 138,405 |  |

[0000889331-19-000052:notes:79]
Employee-related liabilities consist primarily of payroll, sales commissions, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other client-related liabilities.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-19-000052:notes:80]
[same as prior period, unchanged from 0000889331-19-000042:notes:79]

[0000889331-19-000052:notes:81]
The Company recorded restructuring, impairment and other charges for the three and nine months ended September 28, 2019 and September 29, 2018 as follows:

[0000889331-19-000052:notes:82]
|  | Three months ended September 28, 2019 |  | Nine months ended September 28, 2019 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 655 |  |  | $ | 109 |  |  | $ | 49 |  |  | $ | 813 |  |  | $ | 4,153 |  |  | $ | 3,955 |  |  | $ | 770 |  |  | $ | 8,878 |  |
| Other restructuring charges | 128 |  |  | 1,150 |  |  | 124 |  |  | 1,402 |  |  | 141 |  |  | 1,240 |  |  | 374 |  |  | 1,755 |  |
| Total restructuring charges | 783 |  |  | 1,259 |  |  | 173 |  |  | 2,215 |  |  | 4,294 |  |  | 5,195 |  |  | 1,144 |  |  | 10,633 |  |
| Impairment | — |  |  | 322 |  |  | — |  |  | 322 |  |  | — |  |  | 322 |  |  | — |  |  | 322 |  |
| Total | $ | 783 |  |  | $ | 1,581 |  |  | $ | 173 |  |  | $ | 2,537 |  |  | $ | 4,294 |  |  | $ | 5,517 |  |  | $ | 1,144 |  |  | $ | 10,955 |  |

[0000889331-19-000052:notes:83]
|  | Three months ended September 29, 2018 |  | Nine months ended September 29, 2018 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 4,614 |  |  | $ | 202 |  |  | $ | — |  |  | $ | 4,816 |  |  | $ | 7,693 |  |  | $ | 301 |  |  | $ | 65 |  |  | $ | 8,059 |  |
| Other restructuring charges | — |  |  | 166 |  |  | — |  |  | 166 |  |  | 670 |  |  | 166 |  |  | — |  |  | 836 |  |
| Total restructuring charges | 4,614 |  |  | 368 |  |  | — |  |  | 4,982 |  |  | 8,363 |  |  | 467 |  |  | 65 |  |  | 8,895 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 88 |  |  | 1,037 |  |  | 1,125 |  |
| Total | $ | 4,614 |  |  | $ | 368 |  |  | $ | — |  |  | $ | 4,982 |  |  | $ | 8,363 |  |  | $ | 555 |  |  | $ | 1,102 |  |  | $ | 10,020 |  |

[0000889331-19-000052:notes:84]
[same as prior period, unchanged from 0000889331-19-000042:notes:83]

[0000889331-19-000052:notes:85]
For the three and nine months ended September 28, 2019, the Company recorded total restructuring charges of $2.2 million and $10.6 million, respectively, for employee termination costs and other restructuring charges. These charges primarily related to the reorganization of operations and selling, general and administrative functions as well as the integration of IXYS within the Electronics segment and the reorganization of operations in the automotive sensors and commercial vehicle products businesses within the Automotive segment.

[0000889331-19-000052:notes:86]
In April 2019, we announced the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment. The Company recorded $1.7 million of employee termination costs and $1.1 million of other restructuring and impairment charges  associated with this plant closure.

[0000889331-19-000052:notes:87]
[same as prior period, unchanged from 0000889331-19-000042:notes:86]

[0000889331-19-000052:notes:88]
For three and nine months ended September 29, 2018, the Company recorded total restructuring charges of $5.0 million and $8.9 million, respectively, for employee termination costs and other restructuring charges related to lease termination and facility closure. These charges primarily related to the integration of IXYS and the reorganization of the IXYS Radio Pulse business within the Electronics segment. For the nine months ended September 29, 2018, the Company recorded impairment charges of $1.1 million primarily related to the impairment of a building and a trade name associated with the exit of the Custom business within the Industrial segment.

[0000889331-19-000052:notes:89]
The restructuring reserves as of September 28, 2019 and December 29, 2018 are $2.3 million and $3.9 million, respectively. The restructuring reserves are included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by December 2019.


## us-gaap:DebtDisclosureTextBlock

[0000889331-19-000052:notes:90]
Debt

[0000889331-19-000052:notes:91]
The carrying amounts of debt at September 28, 2019 and December 29, 2018 are as follows:

[0000889331-19-000052:notes:92]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,002 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,932 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,893 | ) |  | (4,636 | ) |
| Total debt |  | 678,160 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 668,160 |  |  | $ | 684,730 |  |

[0000889331-19-000052:notes:93]
Revolving Credit Facility / Term Loan

[0000889331-19-000052:notes:94]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-19-000052:notes:95]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $7.5 million on the term loan during the nine months ended September 28, 2019.

[0000889331-19-000052:notes:96]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.54% at September 28, 2019.

[0000889331-19-000052:notes:97]
As of September 28, 2019, the Company had less than $0.1 million outstanding in letters of credit and had available $416.5 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 28, 2019, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-19-000052:notes:98]
Senior Notes

[0000889331-19-000052:notes:99]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023

[0000889331-19-000052:notes:100]
(“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-19-000052:notes:101]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-19-000052:notes:102]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-19-000052:notes:103]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-19-000052:notes:104]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 28, 2019, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-19-000052:notes:105]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-19-000052:notes:106]
Interest paid on all Company debt was $6.4 million and $8.1 million for the three months ended September 28, 2019 and September 29, 2018, respectively, and $17.9 million and $15.8 million for the nine months ended September 28, 2019 and September 29, 2018, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-19-000052:notes:107]
[same as prior period, unchanged from 0000889331-19-000042:notes:106]

[0000889331-19-000052:notes:108]
[same as prior period, unchanged from 0000889331-19-000042:notes:107]

[0000889331-19-000052:notes:109]
[same as prior period, unchanged from 0000889331-19-000042:notes:108]

[0000889331-19-000052:notes:110]
[same as prior period, unchanged from 0000889331-19-000042:notes:109]

[0000889331-19-000052:notes:111]
[same as prior period, unchanged from 0000889331-19-000042:notes:110]

[0000889331-19-000052:notes:112]
[same as prior period, unchanged from 0000889331-19-000042:notes:111]

[0000889331-19-000052:notes:113]
[same as prior period, unchanged from 0000889331-19-000042:notes:112]

[0000889331-19-000052:notes:114]
[same as prior period, unchanged from 0000889331-19-000042:notes:113]

[0000889331-19-000052:notes:115]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the nine months ended September 28, 2019, the Company recorded impairment charges of $2.8 million in Other expense (income), net in the Condensed Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value of $1.2 million. The fair value of these investments are measured on a nonrecurring basis and determined to be Level 3 under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-19-000052:notes:116]
[same as prior period, unchanged from 0000889331-19-000042:notes:115]

[0000889331-19-000052:notes:117]
[same as prior period, unchanged from 0000889331-19-000042:notes:116]

[0000889331-19-000052:notes:118]
There were no changes during the quarter ended September 28, 2019 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 28, 2019 and December 29, 2018, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-19-000052:notes:119]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 28, 2019:

[0000889331-19-000052:notes:120]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Investments in equity securities |  | $ | 12,648 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,648 |  |
| Mutual funds |  | 9,717 |  |  | — |  |  | — |  |  | 9,717 |  |

[0000889331-19-000052:notes:121]
[same as prior period, unchanged from 0000889331-19-000042:notes:120]

[0000889331-19-000052:notes:122]
[same as prior period, unchanged from 0000889331-19-000042:notes:121]

[0000889331-19-000052:notes:123]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at September 28, 2019 and December 29, 2018, as the rates on these borrowings are variable in nature.

[0000889331-19-000052:notes:124]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of September 28, 2019 and December 29, 2018 were as follows:

[0000889331-19-000052:notes:125]
|  |  | September 28, 2019 |  | December 29, 2018 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 128,002 |  |  | $ | 129,793 |  |  | $ | 133,417 |  |  | $ | 130,888 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,933 |  |  | 109,767 |  |  | 108,330 |  |  | 103,774 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,010 |  |  | 25,000 |  |  | 24,115 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 103,179 |  |  | 100,000 |  |  | 94,458 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,918 |  |  | 50,000 |  |  | 47,434 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 128,681 |  |  | 125,000 |  |  | 114,731 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-19-000052:notes:126]
[same as prior period, unchanged from 0000889331-19-000042:notes:125]

[0000889331-19-000052:notes:127]
[same as prior period, unchanged from 0000889331-19-000042:notes:126]

[0000889331-19-000052:notes:128]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended September 28, 2019 and September 29, 2018 were as follows:

[0000889331-19-000052:notes:129]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 509 |  |  | $ | 533 |  |  | $ | 1,523 |  |  | $ | 1,599 |  |
| Interest cost |  | 777 |  |  | 501 |  |  | 2,374 |  |  | 1,503 |  |
| Expected return on plan assets |  | (773 | ) |  | (540 | ) |  | (2,384 | ) |  | (1,620 | ) |
| Amortization of prior service |  | 60 |  |  | 74 |  |  | 184 |  |  | 222 |  |
| Net periodic benefit cost |  | $ | 573 |  |  | $ | 568 |  |  | $ | 1,697 |  |  | $ | 1,704 |  |

[0000889331-19-000052:notes:130]
[same as prior period, unchanged from 0000889331-19-000042:notes:129]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-19-000052:notes:131]
[same as prior period, unchanged from 0000889331-19-000042:notes:130]

[0000889331-19-000052:notes:132]
[same as prior period, unchanged from 0000889331-19-000042:notes:131]

[0000889331-19-000052:notes:133]
| (in thousands) |  | Three Months EndedSeptember 28, 2019 |  | Three Months EndedSeptember 29, 2018 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 155 |  |  | $ | 18 |  |  | $ | 137 |  |  | $ | (115 | ) |  | $ | — |  |  | $ | (115 | ) |
| Foreign currency translation adjustments |  | (17,163 | ) |  | — |  |  | (17,163 | ) |  | (7,832 | ) |  | — |  |  | (7,832 | ) |
| Total change in other comprehensive income (loss) |  | $ | (17,008 | ) |  | $ | 18 |  |  | $ | (17,026 | ) |  | $ | (7,947 | ) |  | $ | — |  |  | $ | (7,947 | ) |

[0000889331-19-000052:notes:134]
| (in thousands) |  | Nine Months Ended September 28, 2019 |  | Nine Months Ended September 29, 2018 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 278 |  |  | $ | 29 |  |  | $ | 249 |  |  | $ | 630 |  |  | $ | (18 | ) |  | $ | 648 |  |
| Foreign currency translation adjustments |  | (14,933 | ) |  | — |  |  | (14,933 | ) |  | (24,816 | ) |  | — |  |  | (24,816 | ) |
| Total change in other comprehensive income (loss) |  | $ | (14,655 | ) |  | $ | 29 |  |  | $ | (14,684 | ) |  | $ | (24,186 | ) |  | $ | (18 | ) |  | $ | (24,168 | ) |

[0000889331-19-000052:notes:135]
The following tables set forth the changes in accumulated other comprehensive (loss) income by component for the nine months ended September 28, 2019 and September 29, 2018:

[0000889331-19-000052:notes:136]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 29, 2018 |  | $ | (9,959 | ) |  | $ | (87,965 | ) |  | $ | (97,924 | ) |
| Activity in the period |  | 249 |  |  | (14,933 | ) |  | (14,684 | ) |
| Balance at September 28, 2019 |  | $ | (9,710 | ) |  | $ | (102,898 | ) |  | $ | (112,608 | ) |

[0000889331-19-000052:notes:137]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Unrealizedgain (loss) oninvestments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 30, 2017 |  | $ | (10,836 | ) |  | $ | 9,795 |  |  | $ | (62,627 | ) |  | $ | (63,668 | ) |
| Cumulative effect adjustment (a) |  | — |  |  | (9,795 | ) |  | — |  |  | (9,795 | ) |
| Activity in the period |  | 648 |  |  | — |  |  | (24,816 | ) |  | (24,168 | ) |
| Balance at September 29, 2018 |  | $ | (10,188 | ) |  | $ | — |  |  | $ | (87,443 | ) |  | $ | (97,631 | ) |

[0000889331-19-000052:notes:138]
(a)The Company adopted ASU 2016-01 on December 31, 2017 on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings.

[0000889331-19-000052:notes:139]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three and nine months ended September 28, 2019 and September 29, 2018 were as follows:

[0000889331-19-000052:notes:140]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service |  | $ | 60 |  |  | $ | 74 |  |  | $ | 184 |  |  | $ | 222 |  |

[0000889331-19-000052:notes:141]
[same as prior period, unchanged from 0000889331-19-000042:notes:140]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-19-000052:notes:142]
[same as prior period, unchanged from 0000889331-19-000042:notes:141]

[0000889331-19-000052:notes:143]
The effective tax rate for the three and nine months ended September 28, 2019 was 13.9% and 17.7% respectively, compared to the effective tax rate for the three and nine months ended September 29, 2018 of 21.5% and 20.1% respectively. The effective tax rates for the 2019 periods are lower than the effective tax rates for the 2018 periods primarily due to lower taxes in certain non-US jurisdictions, including the impact of a tax holiday in China which was applicable in the 2019 periods but not in the 2018 periods. The effective tax rates for the 2019 periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-19-000052:notes:144]
[same as prior period, unchanged from 0000889331-19-000042:notes:143]

[0000889331-19-000052:notes:145]
[same as prior period, unchanged from 0000889331-19-000042:notes:144]

[0000889331-19-000052:notes:146]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 35,647 |  |  | $ | 53,546 |  |  | $ | 116,428 |  |  | $ | 131,900 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,482 |  |  | 25,109 |  |  | 24,646 |  |  | 24,817 |  |
| Effect of dilutive securities |  | 202 |  |  | 362 |  |  | 248 |  |  | 395 |  |
| Diluted |  | 24,684 |  |  | 25,471 |  |  | 24,894 |  |  | 25,212 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.46 |  |  | $ | 2.13 |  |  | $ | 4.72 |  |  | $ | 5.31 |  |
| Diluted earnings per share |  | $ | 1.44 |  |  | $ | 2.10 |  |  | $ | 4.68 |  |  | $ | 5.23 |  |

[0000889331-19-000052:notes:147]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 205,516 and 38,082 for the three months ended September 28, 2019 and September 29, 2018, respectively, and 147,090 and 39,446 for the nine months ended September 28, 2019 and September 29, 2018, respectively.

[0000889331-19-000052:notes:148]
[same as prior period, unchanged from 0000889331-19-000042:notes:147]

[0000889331-19-000052:notes:149]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to

[0000889331-19-000052:notes:150]
April 30, 2020 ("2019 program"). During the three and nine months ended September 28, 2019, the Company repurchased 311,786 and 579,916 shares of its common stock totaling $49.5 million and $95.0 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-19-000052:notes:151]
Related Party Transactions

[0000889331-19-000052:notes:152]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method and recorded in investments in the Condensed Consolidated Balance Sheets. The following is a description of the investments and related party transactions.

[0000889331-19-000052:notes:153]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For both the three months ended September 28, 2019 and September 29, 2018, the Company recorded revenues of $0.2 million from sales of products to Powersem for use as components in their products. For the nine months ended September 28, 2019 and September 29, 2018, the Company recorded revenues of $0.4 million and $0.6 million from sales of products to Powersem for use as components in their products, respectively. During the three months ended September 28, 2019 and September 29, 2018, the Company purchased $0.8 million and $1.3 million of products from Powersem, respectively. During the nine months ended September 28, 2019 and September 29, 2018, the Company purchased $2.4 million and $3.4 million of products from Powersem, respectively. As of September 28, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

[0000889331-19-000052:notes:154]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During both the three months ended September 28, 2019 and September 29, 2018, EB Tech rendered processing services for the Company totaling less than $0.1 million. During both the  nine months ended September 28, 2019 and September 29, 2018, EB Tech rendered processing services for the Company totaling approximately $0.3 million. As of September 28, 2019 the Company's accounts payable balance to EB Tech was less than $0.1 million. As of December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

[0000889331-19-000052:notes:155]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended September 28, 2019 and September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $1.7 million and $2.5 million, respectively. During the nine months ended September 28, 2019 and September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $5.5 million and $7.7 million, respectively. As of September 28, 2019 the Company's accounts payable balance to ATEC was $0.2 million. As of December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.

[0000889331-19-000052:notes:156]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $1.2 million as of September 28, 2019 where one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

[0000889331-19-000052:notes:157]
On March 25, 2019, the Company entered into a definitive agreement to sell the assets and liabilities of Microwave Technology, Inc. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net Income. The operations of Microwave Technology, Inc. were included in the Electronics segment. One member of the Company’s  Board of Directors is the co-owner of a company that agreed to purchase MWT. This transaction closed on April 26, 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-19-000052:notes:158]
[same as prior period, unchanged from 0000889331-19-000042:notes:156]

[0000889331-19-000052:notes:159]
[same as prior period, unchanged from 0000889331-19-000042:notes:157]

[0000889331-19-000052:notes:160]
[same as prior period, unchanged from 0000889331-19-000042:notes:158]

[0000889331-19-000052:notes:161]
[same as prior period, unchanged from 0000889331-19-000042:notes:159]

[0000889331-19-000052:notes:162]
[same as prior period, unchanged from 0000889331-19-000042:notes:160]

[0000889331-19-000052:notes:163]
[same as prior period, unchanged from 0000889331-19-000042:notes:161]

[0000889331-19-000052:notes:164]
[same as prior period, unchanged from 0000889331-19-000042:notes:162]

[0000889331-19-000052:notes:165]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 227,252 |  |  | $ | 296,472 |  |  | $ | 752,199 |  |  | $ | 860,240 |  |
| Automotive |  | 104,681 |  |  | 114,416 |  |  | 326,814 |  |  | 367,718 |  |
| Industrial |  | 30,038 |  |  | 28,303 |  |  | 86,337 |  |  | 88,229 |  |
| Total net sales |  | $ | 361,971 |  |  | $ | 439,191 |  |  | $ | 1,165,350 |  |  | $ | 1,316,187 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 14,960 |  |  | $ | 15,898 |  |  | $ | 45,031 |  |  | 45,227 |  |
| Automotive |  | 7,067 |  |  | 5,891 |  |  | 20,848 |  |  | 17,830 |  |
| Industrial |  | 1,061 |  |  | 1,364 |  |  | 3,177 |  |  | 4,291 |  |
| Other |  | — |  |  | 3,105 |  |  | — |  |  | 8,712 |  |
| Total depreciation and amortization |  | $ | 23,088 |  |  | $ | 26,258 |  |  | $ | 69,056 |  |  | $ | 76,060 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 34,567 |  |  | $ | 72,464 |  |  | $ | 127,233 |  |  | $ | 193,739 |  |
| Automotive |  | 11,437 |  |  | 10,863 |  |  | 34,987 |  |  | 44,965 |  |
| Industrial |  | 6,822 |  |  | 4,134 |  |  | 16,158 |  |  | 14,123 |  |
| Other(a) |  | (5,659 | ) |  | (11,233 | ) |  | (17,904 | ) |  | (79,406 | ) |
| Total operating income |  | 47,167 |  |  | 76,228 |  |  | 160,474 |  |  | 173,421 |  |
| Interest expense |  | 5,559 |  |  | 5,775 |  |  | 16,834 |  |  | 16,980 |  |
| Foreign exchange loss (gain) |  | 4,968 |  |  | 982 |  |  | 5,636 |  |  | (6,372 | ) |
| Other (income) expense, net |  | (4,764 | ) |  | 1,259 |  |  | (3,406 | ) |  | (2,362 | ) |
| Income before income taxes |  | $ | 41,404 |  |  | $ | 68,212 |  |  | $ | 141,410 |  |  | $ | 165,175 |  |

[0000889331-19-000052:notes:166]
(a) Included in “Other” Operating income (loss) for the 2019 third quarter is $3.2 million ($6.9 million year-to-date) of acquisition related and integration charges primarily related to the IXYS acquisition. In addition, there were $2.5 million ($11.0 million year-to-date) of restructuring charges primarily related to employee termination costs. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-19-000052:notes:167]
Included in "Other" Operating income (loss) for the third quarter of  2018 is includes approximately  $10.1 million ($75.6 million year-to-date) of charges related to the IXYS acquisition, which include $36.9 million year-to-date of purchase accounting inventory step-up charges previously recorded during the first and second quarters of 2018, $2.4 million ($16.1 million year-to-date) in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $3.1 million ($8.7 million year-to-date) in backlog amortization costs,  $4.6 million ($7.3 million year-to-date) of employee termination costs and other restructuring charges, and $4.5 million year-to-date stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million year-to-date change in control expense related to IXYS. In addition, there were $0.4 million ($1.6 million year-to-date) of employee termination costs, other restructuring, impairment charges of $1.1 million associated with the exit of the Custom business in the second quarter, and $0.7 million ($1.1 million year-to-date) of acquisition-related expenses for other contemplated acquisitions.

[0000889331-19-000052:notes:168]
[same as prior period, unchanged from 0000889331-19-000042:notes:166]

[0000889331-19-000052:notes:169]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 28, 2019 |  | September 29, 2018 |  | September 28, 2019 |  | September 29, 2018 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 105,292 |  |  | $ | 125,867 |  |  | $ | 340,811 |  |  | $ | 386,980 |  |
| China |  | 101,960 |  |  | 117,813 |  |  | 316,553 |  |  | 352,097 |  |
| Other countries(a) |  | 154,719 |  |  | 195,511 |  |  | 507,986 |  |  | 577,110 |  |
| Total net sales |  | $ | 361,971 |  |  | $ | 439,191 |  |  | $ | 1,165,350 |  |  | $ | 1,316,187 |  |

[0000889331-19-000052:notes:170]
[same as prior period, unchanged from 0000889331-19-000042:notes:168]

[0000889331-19-000052:notes:171]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 56,790 |  |  | $ | 58,691 |  |
| China |  | 88,386 |  |  | 95,806 |  |
| Mexico |  | 73,350 |  |  | 70,495 |  |
| Germany |  | 35,817 |  |  | 36,548 |  |
| Philippines |  | 37,775 |  |  | 32,459 |  |
| Other countries(a) |  | 37,674 |  |  | 45,895 |  |
| Total long-lived assets |  | $ | 329,792 |  |  | $ | 339,894 |  |

[0000889331-19-000052:notes:172]
[same as prior period, unchanged from 0000889331-19-000042:notes:170]

[0000889331-19-000052:notes:173]
|  |  | Nine Months Ended |
| (in thousands) |  | September 28, 2019 |  | September 29, 2018 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 4,972 |  |  | $ | 5,636 |  |
| China |  | 12,418 |  |  | 19,043 |  |
| Mexico |  | 12,650 |  |  | 14,089 |  |
| Germany |  | 4,335 |  |  | 5,917 |  |
| Philippines |  | 9,546 |  |  | 6,133 |  |
| Other countries(a) |  | 3,454 |  |  | 5,128 |  |
| Total additions to long-lived assets |  | $ | 47,375 |  |  | $ | 55,946 |  |

[0000889331-19-000052:notes:174]
[same as prior period, unchanged from 0000889331-19-000042:notes:172]

[0000889331-19-000052:notes:175]
[same as prior period, unchanged from 0000889331-19-000042:notes:173]
