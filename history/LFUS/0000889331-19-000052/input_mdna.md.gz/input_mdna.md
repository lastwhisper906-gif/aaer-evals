# LFUS MD&A — 0000889331-19-000052


## mdna

[0000889331-19-000052:mdna:1]
[same as prior period, unchanged from 0000889331-19-000042:mdna:1]

[0000889331-19-000052:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-19-000052:mdna:3]
[same as prior period, unchanged from 0000889331-19-000042:mdna:3]

[0000889331-19-000052:mdna:4]
[same as prior period, unchanged from 0000889331-19-000042:mdna:4]

[0000889331-19-000052:mdna:5]
[same as prior period, unchanged from 0000889331-19-000042:mdna:5]

[0000889331-19-000052:mdna:6]
[same as prior period, unchanged from 0000889331-19-000042:mdna:6]

[0000889331-19-000052:mdna:7]
[same as prior period, unchanged from 0000889331-19-000042:mdna:7]

[0000889331-19-000052:mdna:8]
[same as prior period, unchanged from 0000889331-19-000042:mdna:8]

[0000889331-19-000052:mdna:9]
For the third quarter of 2019, the Company recognized net sales of $362.0 million compared to $439.2 million in the third quarter of 2018 representing a decrease of $77.2 million, or 17.6%. The decrease was primarily driven by lower volume in the Electronics and Automotive segments and $4.4 million or 1.0% of unfavorable changes in foreign exchange rates, partially offset by higher volume in the Industrial segment. The Company recognized net income of $35.6 million, or $1.44 per diluted share, in the third quarter of 2019 compared to net income of $53.5 million, or $2.10 per diluted share in the third quarter of 2018. The decrease in net income reflects lower operating income in the Electronics segment and foreign exchange losses, partially offset by lower non-segment charges compared to prior year primarily due to the IXYS acquisition.

[0000889331-19-000052:mdna:10]
The Company continues to take actions to improve its cost structure and drive the synergies from the integration of IXYS. The Company expects to realize cost savings from the restructuring activities taken during 2019 including the reorganization of certain manufacturing, selling and administrative functions across all segments and the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment.

[0000889331-19-000052:mdna:11]
Net cash provided by operating activities was $160.9 million for the nine months ended September 28, 2019 as compared to $252.1 million for the nine months ended September 29, 2018. The decrease in net cash provided by operating activities reflected lower earnings and higher working capital levels primarily due to the timing of supplier payments.

[0000889331-19-000052:mdna:12]
During the three and nine months ended September 28, 2019, the Company repurchased 311,786 and 579,916 shares of its common stock totaling $49.5 million and $95.0 million, respectively. Since September 30, 2018, the Company has repurchased 971,888 shares of its common stock at an average price of $167.65 totaling $162.9 million.

[0000889331-19-000052:mdna:13]
[same as prior period, unchanged from 0000889331-19-000042:mdna:13]

[0000889331-19-000052:mdna:14]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The third quarter of 2019 includes $5.7 million ($17.9 million year-to-date) of non-segment charges, of which $2.5 million ($11.0 million year-to-date) of restructuring charges are primarily related to employee termination costs and other restructuring charges and $3.2 million ($6.9 million year-to-date) of acquisition-related and integration charges are primarily related to the IXYS acquisition and other contemplated acquisitions.

[0000889331-19-000052:mdna:15]
The third quarter of 2018 includes approximately $10.1 million ($75.6 million year-to-date) of charges related to the IXYS acquisition, which include $36.9 million year-to-date of purchase accounting inventory step-up charges previously recorded during the first and second quarters of 2018, $2.4 million ($16.1 million year-to-date) in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $3.1 million ($8.7 million year-to-date) in backlog amortization costs, $4.6 million ($7.3 million year-to-date) of employee termination costs and other restructuring charges, and $4.5 million year-to-date stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million year-to-date change in control expense related to IXYS. In addition, there were $0.4 million ($1.6 million year-to-date) of employee termination costs, other restructuring, impairment charges of $1.1 million associated with the exit of the Custom business in the second quarter, and $0.7 million ($1.1 million year-to-date) of acquisition-related expenses for other contemplated acquisitions.

[0000889331-19-000052:mdna:16]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |  | 2019 |  | 2018 |  | Change |  | %Change |
| Net sales |  | $ | 361,971 |  |  | $ | 439,191 |  |  | $ | (77,220 | ) |  | (17.6 | )% |  | $ | 1,165,350 |  |  | $ | 1,316,187 |  |  | $ | (150,837 | ) |  | (11.5 | )% |
| Gross profit |  | 130,946 |  |  | 179,594 |  |  | (48,648 | ) |  | (27.1 | )% |  | 427,982 |  |  | 498,204 |  |  | (70,222 | ) |  | (14.1 | )% |
| Operating expenses |  | 83,779 |  |  | 103,366 |  |  | (19,587 | ) |  | (18.9 | )% |  | 267,508 |  |  | 324,783 |  |  | (57,275 | ) |  | (17.6 | )% |
| Operating income |  | 47,167 |  |  | 76,228 |  |  | (29,061 | ) |  | (38.1 | )% |  | 160,474 |  |  | 173,421 |  |  | (12,947 | ) |  | (7.5 | )% |
| Income before income taxes |  | 41,404 |  |  | 68,212 |  |  | (26,808 | ) |  | (39.3 | )% |  | 141,410 |  |  | 165,175 |  |  | (23,765 | ) |  | (14.4 | )% |
| Income taxes |  | 5,757 |  |  | 14,666 |  |  | (8,909 | ) |  | (60.7 | )% |  | 24,982 |  |  | 33,275 |  |  | (8,293 | ) |  | (24.9 | )% |
| Net income |  | $ | 35,647 |  |  | $ | 53,546 |  |  | $ | (17,899 | ) |  | (33.4 | )% |  | $ | 116,428 |  |  | $ | 131,900 |  |  | $ | (15,472 | ) |  | (11.7 | )% |

[0000889331-19-000052:mdna:17]
[same as prior period, unchanged from 0000889331-19-000042:mdna:17]

[0000889331-19-000052:mdna:18]
Net sales decreased $77.2 million or 17.6% for the third quarter of 2019 compared to the third quarter of 2018 primarily due to lower volume across the Electronics and Automotive segments from electronics distribution partners reducing excess channel inventories and a decline in global auto production, and $4.4 million or 1.0% of unfavorable changes in foreign exchange rates, partially offset by higher volume in Industrial segment.

[0000889331-19-000052:mdna:19]
Net sales decreased $150.8 million or 11.5% for the first nine months of 2019 compared to the first nine months of 2018 primarily due to lower volume across the Electronics and Automotive segments and $22.3 million or 1.7% of unfavorable changes in foreign exchange rates.

[0000889331-19-000052:mdna:20]
[same as prior period, unchanged from 0000889331-19-000042:mdna:20]

[0000889331-19-000052:mdna:21]
Gross profit was $130.9 million, or 36.2% of net sales, in the third quarter of 2019 compared to $179.6 million, or 40.9% of net sales, in the third quarter of 2018. The decrease in gross profit is primarily due to lower volumes across the Electronics and Automotive segments from electronics distribution partners reducing excess channel inventories, a decline in global auto production, unfavorable price and product mix, and costs related to restructuring activities taken during 2019.

[0000889331-19-000052:mdna:22]
Gross profit was $428.0 million, or 36.7% of net sales, in the first nine months of 2019 compared to $498.2 million, or 37.9% of net sales, in the first nine months of 2018. The decrease in gross profit reflected lower volume across all segments. In 2018 the IXYS purchase accounting inventory step-up charge of $36.9 million negatively impacted the 2018 gross margin by 2.8%.

[0000889331-19-000052:mdna:23]
[same as prior period, unchanged from 0000889331-19-000042:mdna:23]

[0000889331-19-000052:mdna:24]
Total operating expenses were $83.8 million, or 23.1% of net sales, for the third quarter of 2019 compared to $103.4 million, or 23.5% of net sales, for the third quarter of 2018. The decrease in operating expenses of $19.6 million is primarily due to lower annual incentive compensation expenses, global cost saving initiatives, and reduced backlog amortization expense of $3.1 million related to the IXYS acquisition in 2018.

[0000889331-19-000052:mdna:25]
Total operating expenses were $267.5 million, or 23.0% of net sales, for the first nine months of 2019 compared to $324.8 million, or 24.7% of net sales, for the first nine months of 2018. The decrease in operating expenses of $57.3 million is primarily due to lower annual incentive compensation expenses, lower acquisition and integration related costs of $10.3 million, global cost saving initiatives, reduced backlog amortization expense of $8.7 million and $4.5 million stock compensation expense and $2.1 million of change in control expense related to the IXYS acquisition in 2018.

[0000889331-19-000052:mdna:26]
[same as prior period, unchanged from 0000889331-19-000042:mdna:26]

[0000889331-19-000052:mdna:27]
Operating income was $47.2 million, a decrease of $29.1 million, or 38.1%, for the third quarter of 2019 compared to $76.2 million for the third quarter of 2018. The decrease in operating income is due to lower gross margin across the Electronics and Automotive segments, partially offset by the lower operating expenses noted above. Operating margins decreased from 17.4% in the third quarter of 2018 to 13.0% in the third quarter of 2019 driven by the factors mentioned above.

[0000889331-19-000052:mdna:28]
Operating income was $160.5 million, a decrease of $12.9 million, or 7.5%, for the first nine months of 2019 compared to $173.4 million for the first nine months of 2018. The decrease in operating income is primarily due to lower gross profit across all segments,

[0000889331-19-000052:mdna:29]
partially offset by lower operating expenses noted above and the $36.9 million purchase accounting inventory step-up charges in 2018. Operating margins increased from 13.2% in the first nine months of 2018 to 13.8% in the first nine months of 2019 driven by lower operating expenses discussed above.

[0000889331-19-000052:mdna:30]
[same as prior period, unchanged from 0000889331-19-000042:mdna:29]

[0000889331-19-000052:mdna:31]
Income before income taxes was $41.4 million, or 11.4% of net sales, for the third quarter of 2019 compared to $68.2 million, or 15.5% of net sales, for the third quarter of 2018. In addition to the factors impacting comparative results for operating income discussed above, income before taxes was primarily impacted by increased foreign exchange losses of $4.0 million during the three months ended September 28, 2019 compared to the three months ended September 29, 2018, unrealized investment gains of $2.0 million associated with our equity investments during the three months ended September 28, 2019 compared to unrealized losses of $2.6 million during the three months ended September 29, 2018, and increased interest income of $1.0 million  during  three months ended September 28, 2019 compared to the three months ended September 29, 2018.

[0000889331-19-000052:mdna:32]
Income before income taxes was $141.4 million, or 12.1% of net sales, for the first nine months of 2019 compared to $165.2 million, or 12.5% of net sales, for the first nine months of 2018. In addition to the factors impacting comparative results for operating income discussed above, income before taxes was impacted by foreign exchange losses of $5.6 million during the nine months ended September 28, 2019 compared to foreign exchange gains of $6.4 million during the nine months ended September 29, 2018, and increases of $1.0 million in other income primarily due to unrealized investment gains associated with our equity investments and interest income, partially offset by impairment charges of $3.1 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment during the first nine months of 2019 compared to the first nine months of 2018.

[0000889331-19-000052:mdna:33]
[same as prior period, unchanged from 0000889331-19-000042:mdna:32]

[0000889331-19-000052:mdna:34]
Income tax expense was $5.8 million, or an effective tax rate of 13.9%, for the third quarter of 2019 compared to income tax expense of $14.7 million, or an effective tax rate of 21.5%, for the third quarter of 2018. The effective tax rate for the 2019 period is lower than the effective tax rate for the 2018 period primarily due to lower taxes in certain non-US jurisdictions , including the impact of a tax holiday in China which was applicable in the 2019 period but not the 2018 period. The effective tax rate for the 2019 period was lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-19-000052:mdna:35]
Income tax expense was $25.0 million, or an effective tax rate of 17.7%, for the first nine months of 2019 compared to income tax expense of $33.3 million, or an effective tax rate of 20.1%, for the first nine months of 2018. The effective tax rate for the 2019 period is lower than the effective tax rate for the 2018 period primarily due to lower taxes in certain non-US jurisdictions, including the impact of a tax holiday in China which was applicable in the 2019 period but not the 2018 period. The effective tax rate for the 2019 period was lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-19-000052:mdna:36]
[same as prior period, unchanged from 0000889331-19-000042:mdna:35]

[0000889331-19-000052:mdna:37]
[same as prior period, unchanged from 0000889331-19-000042:mdna:36]

[0000889331-19-000052:mdna:38]
[same as prior period, unchanged from 0000889331-19-000042:mdna:37]

[0000889331-19-000052:mdna:39]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |  | 2019 |  | 2018 |  | Change |  | %Change |
| Electronics |  | $ | 227,252 |  |  | $ | 296,472 |  |  | $ | (69,220 | ) |  | (23.3 | )% |  | $ | 752,199 |  |  | $ | 860,240 |  |  | $ | (108,041 | ) |  | (12.6 | )% |
| Automotive |  | 104,681 |  |  | 114,416 |  |  | (9,735 | ) |  | (8.5 | )% |  | 326,814 |  |  | 367,718 |  |  | (40,904 | ) |  | (11.1 | )% |
| Industrial |  | 30,038 |  |  | 28,303 |  |  | 1,735 |  |  | 6.1 | % |  | 86,337 |  |  | 88,229 |  |  | (1,892 | ) |  | (2.1 | )% |
| Total |  | $ | 361,971 |  |  | $ | 439,191 |  |  | $ | (77,220 | ) |  | (17.6 | )% |  | $ | 1,165,350 |  |  | $ | 1,316,187 |  |  | $ | (150,837 | ) |  | (11.5 | )% |

[0000889331-19-000052:mdna:40]
[same as prior period, unchanged from 0000889331-19-000042:mdna:39]

[0000889331-19-000052:mdna:41]
Net sales decreased $69.2 million, or 23.3%, in the third quarter of 2019 compared to the third quarter of 2018 primarily due to lower volume across all businesses due to electronics distribution partners reducing excess channel inventories and unfavorable changes in foreign exchange rates of $2.4 million.

[0000889331-19-000052:mdna:42]
Net sales decreased $108.0 million, or 12.6%, in the first nine months of 2019 compared to the first nine months of 2018 primarily due to lower volume in the electronics products and semiconductor businesses due to electronics distribution partners reducing excess channel inventories and unfavorable changes in foreign exchange rates of $12.1 million.

[0000889331-19-000052:mdna:43]
[same as prior period, unchanged from 0000889331-19-000042:mdna:42]

[0000889331-19-000052:mdna:44]
Net sales decreased $9.7 million, or 8.5%, in the third quarter of 2019 compared to the third quarter of 2018 due to decreased volume primarily in the passenger car and automotive sensor businesses from a decline in global auto production and unfavorable changes in foreign exchange rates of $1.9 million.

[0000889331-19-000052:mdna:45]
Net sales decreased $40.9 million, or 11.1%, in the first nine months of 2019 compared to the first nine months of 2018 due to decreased volume primarily in the passenger car and automotive sensor businesses from a decline in global auto production and unfavorable changes in foreign exchange rates of $9.6 million.

[0000889331-19-000052:mdna:46]
[same as prior period, unchanged from 0000889331-19-000042:mdna:45]

[0000889331-19-000052:mdna:47]
Net sales increased by $1.7 million, or 6.1%, in the third quarter of 2019 compared to the third quarter of 2018 primarily due to higher volume across all businesses, partially offset by unfavorable changes in foreign exchange rates of $0.1 million.

[0000889331-19-000052:mdna:48]
Net sales decreased slightly by $1.9 million, or 2.1%, in the first nine months of 2019 compared to the first nine months of 2018 primarily due to the exit of the Custom business during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.6 million, partially offset by higher volume in the power fuse and relay businesses.

[0000889331-19-000052:mdna:49]
[same as prior period, unchanged from 0000889331-19-000042:mdna:48]

[0000889331-19-000052:mdna:50]
[same as prior period, unchanged from 0000889331-19-000042:mdna:49]

[0000889331-19-000052:mdna:51]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |  | 2019 |  | 2018 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 158,778 |  |  | $ | 193,249 |  |  | $ | (34,471 | ) |  | (17.8 | )% |  | $ | 504,453 |  |  | $ | 576,103 |  |  | $ | (71,650 | ) |  | (12.4 | )% |
| Americas |  | 122,754 |  |  | 156,852 |  |  | (34,098 | ) |  | (21.7 | )% |  | 396,683 |  |  | 442,200 |  |  | (45,517 | ) |  | (10.3 | )% |
| Europe |  | 80,439 |  |  | 89,090 |  |  | (8,651 | ) |  | (9.7 | )% |  | 264,214 |  |  | 297,884 |  |  | (33,670 | ) |  | (11.3 | )% |
| Total |  | $ | 361,971 |  |  | $ | 439,191 |  |  | $ | (77,220 | ) |  | (17.6 | )% |  | $ | 1,165,350 |  |  | $ | 1,316,187 |  |  | $ | (150,837 | ) |  | (11.5 | )% |

[0000889331-19-000052:mdna:52]
[same as prior period, unchanged from 0000889331-19-000042:mdna:51]

[0000889331-19-000052:mdna:53]
Net sales decreased $34.5 million, or 17.8%, in the third quarter of 2019 compared to the third quarter of 2018. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment and the Automotive segment and unfavorable changes in foreign exchange rates of $1.0 million.

[0000889331-19-000052:mdna:54]
Net sales decreased $71.7 million, or 12.4%, in the first nine months of 2019 compared to the first nine months of 2018. The decrease in net sales was primarily due to lower volume in semiconductor business and electronics products within the Electronics segment and lower volume across all businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $6.2 million.

[0000889331-19-000052:mdna:55]
[same as prior period, unchanged from 0000889331-19-000042:mdna:54]

[0000889331-19-000052:mdna:56]
Net sales decreased $34.1 million, or 21.7%, in the third quarter of 2019 compared to the third quarter of 2018 primarily due to lower volume across all businesses within the Electronics segment, lower volume in automotive sensor and commercial vehicle businesses in the Automotive segment, and unfavorable changes in foreign exchange rates of $0.1 million.

[0000889331-19-000052:mdna:57]
Net sales decreased $45.5 million, or 10.3%, in the first nine months of 2019 compared to the first nine months of 2018 primarily due to lower volume in electronics products and semiconductor businesses within the Electronics segment, lower volume in automotive sensor and commercial vehicle businesses in the Automotive segment, the exit of the Custom business within Industrial segment during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.7 million.

[0000889331-19-000052:mdna:58]
[same as prior period, unchanged from 0000889331-19-000042:mdna:57]

[0000889331-19-000052:mdna:59]
Net sales decreased $8.7 million, or 9.7%, in the third quarter of 2019 compared to the third quarter of 2018. The decrease in net sales was primarily due to lower volume in semiconductor business within the Electronics segment, lower volume in passenger car products and commercial vehicle businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $3.2 million, partially offset by higher volume in electronics products within the Electronics segment and higher volume across all businesses within Industrial segments.

[0000889331-19-000052:mdna:60]
Net sales decreased $33.7 million, or 11.3%, in the first nine months of 2019 compared to the first nine months of 2018. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment and lower volume in passenger car products and commercial vehicle businesses within the Automotive segment, and unfavorable changes in foreign exchange rates of $15.4 million, partially offset by higher volume in the power fuse business within Industrial segments.

[0000889331-19-000052:mdna:61]
[same as prior period, unchanged from 0000889331-19-000042:mdna:60]

[0000889331-19-000052:mdna:62]
[same as prior period, unchanged from 0000889331-19-000042:mdna:61]

[0000889331-19-000052:mdna:63]
Revolving Credit Facility/Term Loan

[0000889331-19-000052:mdna:64]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-19-000052:mdna:65]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principle payments $7.5 million on the term loan during the nine months ended September 28, 2019.

[0000889331-19-000052:mdna:66]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.54% at September 28, 2019.

[0000889331-19-000052:mdna:67]
As of September 28, 2019, the Company had $0.1 million outstanding in letters of credit and had available $416.5 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 28, 2019, the Company was in compliance with all covenants under the Credit Agreement. Further information regarding the Company’s credit agreement is provided in Note 9, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-19-000052:mdna:68]
[same as prior period, unchanged from 0000889331-19-000042:mdna:67]

[0000889331-19-000052:mdna:69]
[same as prior period, unchanged from 0000889331-19-000042:mdna:68]

[0000889331-19-000052:mdna:70]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-19-000052:mdna:71]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 9, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-19-000052:mdna:72]
[same as prior period, unchanged from 0000889331-19-000042:mdna:71]

[0000889331-19-000052:mdna:73]
During the third quarter of 2019, the Company paid quarterly dividends of $11.7 million to the shareholders totaling $33.0 million year to date as of September 28, 2019. On October 25, 2019, the Board of Directors of the Company declared a quarterly dividend of $0.48 per share, payable on December 5, 2019 to stockholders of record as of November 21, 2019.

[0000889331-19-000052:mdna:74]
[same as prior period, unchanged from 0000889331-19-000042:mdna:73]

[0000889331-19-000052:mdna:75]
|  |  | First Nine Months |
| (in thousands) |  | 2019 |  | 2018 |
| Net cash provided by operating activities |  | $ | 160,863 |  |  | $ | 252,116 |  |
| Net cash used in investing activities |  | (32,960 | ) |  | (368,563 | ) |
| Net cash (used in) provided by financing activities |  | (135,465 | ) |  | 195,259 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (6,114 | ) |  | (10,273 | ) |
| (Decrease) increase in cash and cash equivalents |  | (13,676 | ) |  | 68,539 |  |
| Cash and cash equivalents at beginning of period |  | 489,733 |  |  | 429,676 |  |
| Cash and cash equivalents at end of period |  | $ | 476,057 |  |  | $ | 498,215 |  |

[0000889331-19-000052:mdna:76]
[same as prior period, unchanged from 0000889331-19-000042:mdna:75]

[0000889331-19-000052:mdna:77]
[same as prior period, unchanged from 0000889331-19-000042:mdna:76]

[0000889331-19-000052:mdna:78]
Net cash provided by operating activities was $160.9 million for the nine months ended September 28, 2019, compared to $252.1 million during the nine months ended September 29, 2018. The decrease in net cash provided by operating activities reflected lower earnings and higher working capital levels primarily due to the timing of supplier payments.

[0000889331-19-000052:mdna:79]
[same as prior period, unchanged from 0000889331-19-000042:mdna:78]

[0000889331-19-000052:mdna:80]
Net cash used in investing activities was $33.0 million for the nine months ended September 28, 2019 compared to $368.6 million during the nine months ended September 29, 2018. Net cash used for the acquisition of IXYS was $306.5 million for the nine months ended September 29, 2018. Capital expenditures were $38.4 million, representing a decrease of $17.5 million compared to 2018. Additionally, the Company received proceeds of $6.4 million from the sale of a property within the Industrial segment.

[0000889331-19-000052:mdna:81]
[same as prior period, unchanged from 0000889331-19-000042:mdna:80]

[0000889331-19-000052:mdna:82]
Net cash used in financing activities was $135.5 million for the nine months ended September 28, 2019 compared to net cash provided by financing activities of $195.3 million for the nine months ended September 29, 2018. The Company repurchased 579,916 shares of its common stock during the nine months ended September 28, 2019 totaling $95.0 million, but made payments of $99.4 million related to settled share repurchases. The Company made payments of $7.5 million on the term loan during the nine months ended September 28, 2019 as compared to $310.0 million of proceeds from the credit facility and senior notes payable and $102.5 million of payments on the credit facility and term loan during the nine months ended September 29, 2018. Additionally, dividends paid increased $3.7 million from $29.3 million in 2018 to $33.0 million for the nine months ended September 28, 2019.

[0000889331-19-000052:mdna:83]
[same as prior period, unchanged from 0000889331-19-000042:mdna:82]

[0000889331-19-000052:mdna:84]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 (“2018 Program”). The Share Repurchase Program expired on April 30, 2019 with 471,888 shares repurchased. On April 26, 2019, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020. During the three and nine months ended September 28, 2019, the Company repurchased 311,786 and 579,916 shares of its common stock totaling $49.5 million and $95.0 million, respectively.

[0000889331-19-000052:mdna:85]
[same as prior period, unchanged from 0000889331-19-000042:mdna:84]

[0000889331-19-000052:mdna:86]
As of September 28, 2019, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-19-000052:mdna:87]
[same as prior period, unchanged from 0000889331-19-000042:mdna:86]

[0000889331-19-000052:mdna:88]
[same as prior period, unchanged from 0000889331-19-000042:mdna:87]

[0000889331-19-000052:mdna:89]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 29, 2018. During the nine months ended September 28, 2019, there were no significant changes in the application of critical accounting policies.
