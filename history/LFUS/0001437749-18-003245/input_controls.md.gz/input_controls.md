# LFUS 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 4 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001437749-18-003245:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES.

[0001437749-18-003245:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-18-003245:item_9a:3]
The Company maintains disclosure controls and procedures that are designed to ensure that information required to be disclosed in its reports filed under the Securities Exchange Act of 1934, as amended, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and that such information is accumulated and communicated to management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure. In designing and evaluating the disclosure controls and procedures, the Company recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives, and the Company is required to apply its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001437749-18-003245:item_9a:4]
As required by SEC Rule 15d-15(b), the Company carried out an evaluation, under the supervision and with the participation of its management, including the Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of its disclosure controls and procedures pursuant to SEC Rule 13a-15 as of the end of the period covered by this report. Based on the foregoing, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of December 30, 2017.

[0001437749-18-003245:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001437749-18-003245:item_9a:6]
Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in this Annual Report on Form 10-K a report on management’s assessment of the effectiveness of the Company’s internal control over financial reporting, as well as an attestation report from the Company’s independent registered public accounting firm on the effectiveness of the Company’s internal control over financial reporting. Management is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Exchange Act Rule 13a-15(f) and 15d-15(f). The Company’s internal control system was designed to provide reasonable assurance to its management and the Board of Directors regarding the preparation and fair presentation of published financial statements.

[0001437749-18-003245:item_9a:7]
All internal control systems, no matter how well designed, have inherent limitations. Therefore, even those systems determined effective can provide only reasonable assurance with respect to financial statement preparation and presentation. A material weakness is a deficiency, or a combination of deficiencies, in the internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the annual or interim financial statement will not be prevented or detected on a timely basis.

[0001437749-18-003245:item_9a:8]
The Company’s management, including the its Principal Executive Officer and Principal Financial Officer, assessed the effectiveness of the Company’s internal control over financial reporting as of December 30, 2017, based upon the updated framework in Internal Control — Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in 1992 and updated in May 2013. Based on this assessment, the Company’s management concluded that, as of December 30, 2017, the Company’s internal control over financial reporting was effective.

[0001437749-18-003245:item_9a:9]
Changes in Internal Control over Financial Reporting

[0001437749-18-003245:item_9a:10]
There has been no change in the Company’s internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that occurred during the 12 months or fiscal quarter ended December 30, 2017, that has materially affected, or is reasonably likely to materially affect, the Company’s internal control over financial reporting.
