# LFUS notes — 0001437749-18-003245


## lfus:CoalMiningLiabilityPolicyTextBlock

[0001437749-18-003245:notes:1]
Coal Mining Liability

[0001437749-18-003245:notes:2]
Included in other long-term liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €

[0001437749-18-003245:notes:3]
0.9
 million (
$1.1
 million) and 
€1.4
 million (
$1.5
 million) at 
 December 30, 2017 
and 
 December 31, 2016, 
respectively.  Management, in conjunction with an independent 
third
-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time. The accrual is 
not
 discounted as management cannot reasonably estimate when such remediation efforts will take place.


## lfus:OtherIncomeExpensePolicyTextBlock

[0001437749-18-003245:notes:4]
Other Expense (Income), Net

[0001437749-18-003245:notes:5]
Other expense (income), net generally consists of interest income, royalties
, and non-operating income.


## lfus:PensionPlanAssetsMeasuredAtFairValueTableTextBlock

[0001437749-18-003245:notes:6]
|  |  | Fair Value Measurements Using |  |  |  |  |  |  |  |  |  |
| (in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | NAV |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Equity 50:50 Index Fund |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,898 |  |  | $ | 7,898 |  |
| Global Equity 50:50 GBP Hedged Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8,134 |  |  |  | 8,134 |  |
| Philippine Stock |  |  | 1,031 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,031 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment Grade Corporate Bond Funds |  |  | 6,003 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6,003 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,684 |  |  |  | 3,684 |  |
| Active Corp Bond – Over 10 Yr Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6,835 |  |  |  | 6,835 |  |
| Over 5y Index-Linked Gilts Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 12,049 |  |  |  | 12,049 |  |
| Philippine Long Government Securities |  |  | 1,362 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,362 |  |
| Philippine Long Corporate Bonds |  |  | 723 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 723 |  |
| Cash and equivalents |  |  | 173 |  |  |  | — |  |  |  | — |  |  |  | 231 |  |  |  | 404 |  |
| Total pension plan assets |  | $ | 9,292 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,831 |  |  | $ | 48,123 |  |

[0001437749-18-003245:notes:7]
|  |  | Fair Value Measurements Using |  |  |  |  |  |  |  |  |  |
| (in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | NAV |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Equity 50:50 Index Fund |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6,321 |  |  | $ | 6,321 |  |
| Global Equity 50:50 GBP Hedged Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6,406 |  |  |  | 6,406 |  |
| Philippine Stock |  |  | 906 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 906 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment Grade Corporate Bond Funds |  |  | 5,372 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5,372 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,265 |  |  |  | 3,265 |  |
| Active Corp Bond – Over 10 Yr Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5,902 |  |  |  | 5,902 |  |
| Over 5y Index-Linked Gilts Fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 10,724 |  |  |  | 10,724 |  |
| Philippine Long Government Securities |  |  | 1,133 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,133 |  |
| Philippine Long Corporate Bonds |  |  | 751 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 751 |  |
| Cash and equivalents |  |  | 476 |  |  |  | — |  |  |  | — |  |  |  | 952 |  |  |  | 1,428 |  |
| Total pension plan assets |  | $ | 8,638 |  |  | $ | — |  |  | $ | — |  |  | $ | 33,570 |  |  | $ | 42,208 |  |


## lfus:RevenueRecognitionAndBillingPolicyTextBlock

[0001437749-18-003245:notes:8]
Revenue and Billing

[0001437749-18-003245:notes:9]
The 
Company generally accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement.


## lfus:RevenueRecognitionReturnToStockPolicyTextBlock

[0001437749-18-003245:notes:10]
Return to Stock

[0001437749-18-003245:notes:11]
The 
Company has a return to stock policy whereby a customer with prior authorization from Littelfuse management can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001437749-18-003245:notes:12]
Advertising Costs

[0001437749-18-003245:notes:13]
The 
Company expenses advertising costs as incurred, which amounted to

[0001437749-18-003245:notes:14]
$2.9

[0001437749-18-003245:notes:15]
million in both 
2017
 and 
2016
 and 
$2.3
 million in 
2015,
 respectively, and are included as a component of selling, general, and administrative expenses.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-18-003245:notes:16]
Basis of Presentation

[0001437749-18-003245:notes:17]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The company
’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America and include the assets, liabilities, sales and expenses of all wholly-owned subsidiaries and majority-owned subsidiaries over which the Company exercises control.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-18-003245:notes:18]
|  |  | For the Year Ended |  |
| (in thousands, except per share amounts) |  | 2016 |  |  | 2015 |  |
| Net sales |  | $ | 1,130,645 |  |  | $ | 1,104,838 |  |
| Income before income taxes |  |  | 143,110 |  |  |  | 120,370 |  |
| Net income |  |  | 124,388 |  |  |  | 92,983 |  |
| Net income per share — basic |  |  | 5.51 |  |  |  | 4.12 |  |
| Net income per share — diluted |  |  | 5.47 |  |  |  | 4.09 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001437749-18-003245:notes:19]
Cash Equivalents

[0001437749-18-003245:notes:20]
All highly liquid investments, with an original maturity of 
three
 months or less when purchased, are considered to be cash equivalents.


## us-gaap:CommitmentsDisclosureTextBlock

[0001437749-18-003245:notes:21]
5.
 Lease Commitments

[0001437749-18-003245:notes:22]
The 
Company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was 
$11.6
 million, 
$12.6
 million, and 
$11.1
 million in 
2017,

[0001437749-18-003245:notes:23]
2016,
 and 
2015,
 respectively.

[0001437749-18-003245:notes:24]
Rent expense is recognized on a straight-line basis over the term of the leases. The difference between straight-line basis rent and the amount paid has been recorded as accrued lease obligations. The 
Company also has leases that have lease renewal provisions. As of 
 December 30, 2017, 
all operating leases outstanding were with 
third
 parties. The Company did 
not
 have any capital leases as of 
 December 30, 2017

[0001437749-18-003245:notes:25]
.

[0001437749-18-003245:notes:26]
Future minimum payments for all non-cancellable operating leases with initial terms of 
one
 year or more at D
ecember 
30,

[0001437749-18-003245:notes:27]
2017
 are as follows:

[0001437749-18-003245:notes:28]
| (in thousands) |  | Future Minimum Payments |  |
| 2018 |  | $ | 10,842 |  |
| 2019 |  |  | 6,194 |  |
| 2020 |  |  | 5,425 |  |
| 2021 |  |  | 4,632 |  |
| 2022 |  |  | 3,464 |  |
| 2023 and thereafter |  |  | 5,021 |  |
|  |  | $ | 35,578 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-18-003245:notes:29]
6

[0001437749-18-003245:notes:30]
. Debt

[0001437749-18-003245:notes:31]
The carrying amounts of debt at 
 December 3

[0001437749-18-003245:notes:32]
0,

[0001437749-18-003245:notes:33]
2017
 and 
 December 31, 2016 
are as follows:

[0001437749-18-003245:notes:34]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Revolving Credit Facility |  | $ | — |  |  | $ | 112,500 |  |
| Term Loan |  |  | 122,500 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | — |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 139,623 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 113,369 |  |  |  | 99,314 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (4,881 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 495,611 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 489,361 |  |  | $ | 447,892 |  |

[0001437749-18-003245:notes:35]
Revolving Credit Facility / Term Loan

[0001437749-18-003245:notes:36]
On 
 March 4, 2016, 
the Company entered into a 
five
-year credit agreement (“Credit Agreement”) with a group of lenders for up to 
$700.0
 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of 
$575.0
 million and an unsecured term loan credit facility (“Term Loan”) of up to 
$125.0
 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the Term Loan, the Company was required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.

[0001437749-18-003245:notes:37]
On 
 October 13, 2017, 
the Company amended 
the Credit Agreement to increase the Revolving Credit Facility from 
$575.0
 million to 
$700.0
 million and increase the Term Loan from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans 
 may 
be made in up to 
two
 advances. The 
first
 advance of 
$125.0
 million occurred on 
 October 13, 2017 
and the 
second
 advance of 
$75.0
 million occurred on 
 January 16, 2018. 
For the Term Loan, the Company is required to make quarterly principal payments of 
1.25%
 of the original term loan (
$1.6
 million as of 
 December 30, 2017 
increasing to 
$2.5
 million with the 
second
 advance on 
 January 16, 2018) 
through maturity, with the remaining balance due on 
 October 13, 2022.

[0001437749-18-003245:notes:38]
Outstanding borrowings under the 
Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
-month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.25%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
3.07%
 at 
 December 30, 2017.

[0001437749-18-003245:notes:39]
As of 
 December 3

[0001437749-18-003245:notes:40]
2017,
 the Company had 
$0.1
 million outstanding in letters of credit and had available 
$699.9
 million of borrowing capacity under the Revolving Credit Facility. At 
 December 30, 2017, 
the Company was in compliance with all covenants under the Credit Agreement.

[0001437749-18-003245:notes:41]
Senior Notes

[0001437749-18-003245:notes:42]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023 (
“Euro Senior Notes, Series A due 
2023”
)

[0001437749-18-003245:notes:43]
, and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
“Euro Senior Notes, Series B due 
2028”
)

[0001437749-18-003245:notes:44]
(together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.

[0001437749-18-003245:notes:45]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February 15, 2017,

[0001437749-18-003245:notes:46]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022 (
“U.S. Senior Notes, Series A due 
2022”
)

[0001437749-18-003245:notes:47]
, and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
“U.S. Senior Notes, Series B due 
2027”
)

[0001437749-18-003245:notes:48]
(together, the “U.S. Senior Notes due 
2022
 and 
2027”
) were funded. Interest on the U.S. Senior Notes due 
2022
 and 
2027
 is payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

[0001437749-18-003245:notes:49]
On 
 November 15, 2017, 
the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold 
$175
 million in aggregate principal amount of senior notes in 
two
 series. On 
 January 16, 2018,

[0001437749-18-003245:notes:50]
$50
 million aggregate principal amount of 
3.48%
 Senior Notes, Series A, due 
 February 15, 2025

[0001437749-18-003245:notes:51]
(“U.S. Senior Notes, Series A due 
2025”
)

[0001437749-18-003245:notes:52]
and 
$125
 million in aggregate principal amount of 
3.78%
 Senior Notes, Series B, due 
 February 15, 2030 (
“U.S. Senior Notes, Series A due 
2030”
)

[0001437749-18-003245:notes:53]
(together the “U.S. Senior Notes due 
2025
 and 
2030”
 and with the Euro Senior Notes and the U.S. Senior Notes 
2022
 and 
2027,
 the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 
2025
 and 
2030
 will be payable on 
 February 15 
and 
 August 15, 
commencing on 
 August 15, 2018.

[0001437749-18-003245:notes:54]
The Senior Notes have 
not
 been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the 
Company.

[0001437749-18-003245:notes:55]
The Senior Notes are subject to certain customary covenants, including limitations on the 
Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 December 30, 2017, 
the Company was in compliance with all covenants under the Senior Notes.

[0001437749-18-003245:notes:56]
The 
Company 
 may 
redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001437749-18-003245:notes:57]
Debt Issuance Costs

[0001437749-18-003245:notes:58]
The 
Company incurred debt issuance costs of 
$1.6
 million in relation to the Credit Agreement which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the Credit Agreement. The Company additionally incurred aggregate debt issuance costs of 
$2.6
 million in relation to the Senior Notes which are being amortized over the respective lives of the Series A and B notes.

[0001437749-18-003245:notes:59]
Entrusted Loan

[0001437749-18-003245:notes:60]
During 
2014,
 the 
Company entered into an entrusted loan arrangement (“Entrusted Loan”) of

[0001437749-18-003245:notes:61]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
-party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the Company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with 
no
 net impact on the Company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in 
 November 2019. 
The balance of the Entrusted Loan was paid off as of 
 September 30, 2017.

[0001437749-18-003245:notes:62]
Interest paid on all 
Company debt was approximately 
$13.4
 million, 
$8.6
 million, and 
$4.1
 million in 
2017,

[0001437749-18-003245:notes:63]
Debt Maturities

[0001437749-18-003245:notes:64]
Scheduled maturities of the 
Company’s long-term debt for each of the 
five
 years succeeding 
 December 30, 2017 
and thereafter are summarized as follows:

[0001437749-18-003245:notes:65]
| (in thousands) |  | Scheduled Maturities |  |
| 2018 |  | $ | 6,250 |  |
| 2019 |  |  | 6,250 |  |
| 2020 |  |  | 6,250 |  |
| 2021 |  |  | 6,250 |  |
| 2022 |  |  | 122,500 |  |
| 2023 and thereafter |  |  | 352,992 |  |
|  |  | $ | 500,492 |  |


## us-gaap:DetailsOfImpairmentOfLongLivedAssetsHeldAndUsedByAssetTextBlock

[0001437749-18-003245:notes:66]
|  |  | Year Ended December 31, 2016 |  |  | As of December 31, 2016 |  |
| (in thousands) |  | Impairment Charge |  |  | Fair Value Measurement (Level 3) |  |  | Net Book Value |  |
| Goodwill |  | $ | 8,794 |  |  | $ | — |  |  | $ | — |  |
| Other intangible assets |  |  | 6,015 |  |  |  | 680 |  |  |  | 660 |  |
| Total |  | $ | 14,809 |  |  | $ | 680 |  |  | $ | 660 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-18-003245:notes:67]
11

[0001437749-18-003245:notes:68]
. Earnings Per Share

[0001437749-18-003245:notes:69]
The following table sets forth the computation of basic and diluted earnings per share:

[0001437749-18-003245:notes:70]
| (in thousands, except per share amounts) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 119,519 |  |  | $ | 104,488 |  |  | $ | 80,866 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,687 |  |  |  | 22,559 |  |  |  | 22,565 |  |
| Effect of dilutive securities |  |  | 244 |  |  |  | 168 |  |  |  | 154 |  |
| Diluted |  |  | 22,931 |  |  |  | 22,727 |  |  |  | 22,719 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 5.27 |  |  | $ | 4.63 |  |  | $ | 3.58 |  |
| Diluted earnings per share |  | $ | 5.21 |  |  | $ | 4.60 |  |  | $ | 3.56 |  |

[0001437749-18-003245:notes:71]
Potential shares of common stock attributable to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were

[0001437749-18-003245:notes:72]
37,443
 shares, 
53,448
 shares, and 
113,130
 shares in 
2017,

[0001437749-18-003245:notes:73]
On 
 January 17, 2018, 
the Company acquired IXYS through a combination of cash, Littelfuse common stock, and the value of converted, or cash settled IXYS equity awards. The Company issued approximately 
2.1
 million shares of Littelfuse common stock and conve
rted IXYS equity awards into approximately 
0.5
 million Littelfuse equity awards.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisValuationTechniquesTableTextBlock

[0001437749-18-003245:notes:74]
| (in thousands, except rates data) |  | Fair Value |  | Valuation Technique |  | Unobservable Inputs |  | Rates |  |
| Tradename |  | $ | 680 |  | Relief from royalty |  | Discount rate: |  |  | 18% |  |
|  |  |  |  |  |  |  | Royalty rate: |  |  | 1% |  |
| Customer relationships |  | $ | — |  | Excess earnings |  | Discount rate: |  |  | 18% |  |
|  |  |  |  |  |  |  | Attrition rate: |  |  | 5% |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-18-003245:notes:75]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,993 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,993 |  |

[0001437749-18-003245:notes:76]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,435 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001437749-18-003245:notes:77]
|  |  | 2017 |  |  | 2016 |  |
| (in thousands) |  | Carrying Value |  |  | Estimated Fair Value |  |  | Carrying Value |  |  | Estimated Fair Value |  |
| Euro Senior Notes, Series A due 2023 |  | $ | 139,623 |  |  | $ | 138,294 |  |  | $ | 122,313 |  |  | $ | 122,586 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 113,369 |  |  |  | 111,579 |  |  |  | 95,314 |  |  |  | 99,230 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 24,737 |  |  |  | 25,000 |  |  |  | 24,746 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 99,992 |  |  |  | 100,000 |  |  |  | 98,660 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-18-003245:notes:78]
7

[0001437749-18-003245:notes:79]
. Fair Value of Assets and Liabilities

[0001437749-18-003245:notes:80]
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a 
three
-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect 
the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows

[0001437749-18-003245:notes:81]
:

[0001437749-18-003245:notes:82]
Level 
1

[0001437749-18-003245:notes:83]
—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0001437749-18-003245:notes:84]
Level 
2

[0001437749-18-003245:notes:85]
—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are 
not
 active, or model-derived valuations, all of whose significant inputs are observable, and

[0001437749-18-003245:notes:86]
Level 
3

[0001437749-18-003245:notes:87]
—

[0001437749-18-003245:notes:88]
Valuations

[0001437749-18-003245:notes:89]
based upon 
one
 or more significant unobservable inputs.

[0001437749-18-003245:notes:90]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0001437749-18-003245:notes:91]
Investments

[0001437749-18-003245:notes:92]
Investments in equity securities listed on a national market or exchange are valued at the last sales price
 and classified within Level 
1
 of the valuation hierarchy. Such securities are further detailed in Note 
1,

[0001437749-18-003245:notes:93]
Summary of Significant Accounting Policies and Other Information
.

[0001437749-18-003245:notes:94]
Defined Benefit Plan Assets / Non-qualified Supplemental Retirement and Savings Plan

[0001437749-18-003245:notes:95]
See
 Note 
8,

[0001437749-18-003245:notes:96]
Benefit Plans
 for description of valuation methodologies and investment balances for defined benefit plan assets and investments related to the Company’s Non-Qualified Supplemental Retirement and Savings Plan.

[0001437749-18-003245:notes:97]
The following table presents assets measured at fair value by classification within the fair value hierarchy
 as of 
 December 30, 2017:

[0001437749-18-003245:notes:98]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of

[0001437749-18-003245:notes:99]
December 31, 2016:

[0001437749-18-003245:notes:100]
Ther
e were 
no
 changes during 
2017
 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of 
 December 30, 2017 
and 
 December 31, 2016, 
the Company held

[0001437749-18-003245:notes:101]
no

[0001437749-18-003245:notes:102]
non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-18-003245:notes:103]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are 
not
 marked to market on a recurring basis. The 
Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at 
 December 30, 2017 
and 
 December 31, 2016, 
as the rates on these borrowings are variable in nature.

[0001437749-18-003245:notes:104]
The carrying value and estimated fair values of the 
Company’s Euro Senior Notes, Series A and Series B and U.S. Senior Notes, Series A and Series B, as of 
 December 30, 2017 
and 
 December 31, 2016 
were as follows:

[0001437749-18-003245:notes:105]
The fair value as of the measurement date, net book value as of the end of the year and related impairment charge for assets measured at fair value on a nonrecurring basis subsequent to initial recognition during the years ended 
 December 31, 2016 
were as follows:

[0001437749-18-003245:notes:106]
During the 
year ended 
 December 31, 2016, 
the goodwill related to the Custom Products reporting unit was written down to its implied fair value of 
zero
. In addition, the company recorded a 
$6.0
 million impairment charge, including 
$3.8
 million related to the Custom Products trade name and 
$2.2
 million for the customer relationship intangible assets. After recording the impairment charges, there was 
no
 remaining value related to the customer relationship intangible assets while 
$0.7
 million remaining net book value related to the tradename.

[0001437749-18-003245:notes:107]
The company
’s accounting and finance management determines the valuation policies and procedures for Level 
3
 fair value measurements and is responsible for the development and determination of unobservable inputs. The following table presents the fair value, valuation techniques and related unobservable inputs for these Level 
3
 measurements for the year ended 
 December 31, 2016:


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001437749-18-003245:notes:108]
Fair Value Measurements

[0001437749-18-003245:notes:109]
Certain assets and liabilities are required to be recorded at fair value on a recurring basis. Fair value is determined based on the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants. The Company records the fair value of its available-for-sale securities and pension plan assets on a recurring basis. Assets measured at fair value on a nonrecurring basis include long-lived assets held and used, long-lived assets held for sale, goodwill and other intangible assets. The fair value of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The 
three
-tier value hierarchy, which prioritizes valuation methodologies based on the reliability of the inputs, is:

[0001437749-18-003245:notes:110]
– Valuations based on quoted prices for identical assets and liabilities in active markets.

[0001437749-18-003245:notes:111]
– Valuations based on observable inputs other than quoted prices included in Level 
1,
 such as quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are 
not
 active, or other inputs that are observable or can be corroborated by observable market data.

[0001437749-18-003245:notes:112]
– Valuations based on unobservable inputs reflecting the Company’s own assumptions, consistent with reasonably available assumptions made by other market participants.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001437749-18-003245:notes:113]
Foreign Currency Translation

[0001437749-18-003245:notes:114]
/

[0001437749-18-003245:notes:115]
Remeasurement

[0001437749-18-003245:notes:116]
The 
Company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. The amount of foreign currency gain or loss from remeasurement recognized in the income statement was a loss of 
$2.4
 million in 
2017,
 a loss of 
$0.5
 million in 
2016,
 and a gain of 
$1.5
 million in 
2015.
 Adjustments from the translation process are recognized in “Shareholders’ equity” as a component of “Accumulated other comprehensive income.”


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-18-003245:notes:117]
4.
 Goodwill and Other Intangible Assets

[0001437749-18-003245:notes:118]
The amounts for goodwill and changes in the carrying value by segment are as follows:

[0001437749-18-003245:notes:119]
| (in thousands) |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| As of January 2, 2016 |  | $ | 58,246 |  |  | $ | 80,262 |  |  | $ | 51,259 |  |  | $ | 189,767 |  |
| Additions(a) |  |  | 162,172 |  |  |  | 70,762 |  |  |  | — |  |  |  | 232,934 |  |
| Impairments(b) |  |  | — |  |  |  | — |  |  |  | (8,794 | ) |  |  | (8,794 | ) |
| Adjustments(c) |  |  | (4,653 | ) |  |  | (6,439 | ) |  |  | 729 |  |  |  | (10,363 | ) |
| As of December 31, 2016 |  | $ | 215,765 |  |  | $ | 144,585 |  |  | $ | 43,194 |  |  | $ | 403,544 |  |
| Additions(d) |  |  | 36,716 |  |  |  | — |  |  |  | — |  |  |  | 36,716 |  |
| Adjustments(e) |  |  | 26,478 |  |  |  | (8,756 | ) |  |  | (4,568 | ) |  |  | 13,154 |  |
| As of December 30, 2017 |  | $ | 278,959 |  |  | $ | 135,829 |  |  | $ | 38,626 |  |  | $ | 453,414 |  |

[0001437749-18-003245:notes:120]
|  | (a) | The 2016 additions resulted primarily from the acquisitions of PolySwitch, ON and Menber’s. |

[0001437749-18-003245:notes:121]
|  | (b) | The 2016 impairments in the Industrial segment was due to the $8.8 million impairment of Custom Products reporting unit goodwill. |

[0001437749-18-003245:notes:122]
|  | (c) | Adjustments in 2016 reflect the impact of changes in foreign exchange rates. |

[0001437749-18-003245:notes:123]
|  | (d) | The 2017 additions resulted from the acquisitions of U.S. Sensor and Monolith. |
|  | (e) | Adjustments in 2017 reflect adjustments to reclass goodwill by segment as well as the impact of changes in foreign exchange rates. The impact of the reclassification was an increase in goodwill to the Electronics segment of $21.6 million and a decrease of goodwill of $16.8 million and $4.8 million to the Automotive segment and the Industrial segment, respectively. |

[0001437749-18-003245:notes:124]
Due to negative events in the potash market in 
2016,
 management revisited its long-term projections and conducted a step 
one
 goodwill impairment analysis for its 
Custom Products reporting unit in the 
third
 quarter of 
2016.
 The reporting unit failed the step 
one
 test and management conducted a step 
two
 analysis. The fair value of the unit was estimated using the expected present value of future cash flows over a 
seven
-year forecast period and appraisal of certain assets. As a result, the Company recognized a charge for goodwill impairment of 
$8.8
 million as it wrote off the entire goodwill balance.

[0001437749-18-003245:notes:125]
The 
components of other intangible assets at 
 December 30, 2017 
and 
 December 31, 2016 
are as follows:

[0001437749-18-003245:notes:126]
|  |  | As of December 30, 2017 |  |
| (in thousands) |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Patents, licenses and software |  | 11.4 |  |  | $ | 141,520 |  |  | $ | 59,609 |  |  | $ | 81,911 |  |
| Distribution network |  | 12.1 |  |  |  | 46,233 |  |  |  | 33,361 |  |  |  | 12,872 |  |
| Customer relationships, trademarks and tradenames |  | 15.6 |  |  |  | 162,679 |  |  |  | 53,612 |  |  |  | 109,067 |  |
| Total |  |  |  |  | $ | 350,432 |  |  | $ | 146,582 |  |  | $ | 203,850 |  |

[0001437749-18-003245:notes:127]
|  |  | As of December 31, 2016 |  |
| (in thousands) |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Patents, licenses and software |  | 11.4 |  |  | $ | 131,611 |  |  | $ | 48,004 |  |  | $ | 83,607 |  |
| Distribution network |  | 12.1 |  |  |  | 49,150 |  |  |  | 30,155 |  |  |  | 18,995 |  |
| Customer relationships, trademarks and tradenames |  | 14.4 |  |  |  | 150,887 |  |  |  | 40,463 |  |  |  | 110,424 |  |
| Total |  |  |  |  | $ | 331,648 |  |  | $ | 118,622 |  |  | $ | 213,026 |  |

[0001437749-18-003245:notes:128]
During the year ended 
 December 31, 2016, 
the Company recognized non-cash impairment charges totaling 
$6.0
 million, of which 
$2.2
 million related to the impairment of certain customer relationship intangib
le assets in the Custom Products reporting unit within the Industrial segment and 
$3.8
 million related to the impairment of the Custom Products tradename. The impairment of the customer relationship intangible assets resulted from lower expectations of future revenue to be derived from those relationships while the tradename impairment resulted from lower expectations of future cash flows of the Custom Products reporting unit.

[0001437749-18-003245:notes:129]
During the years ended 
 December 30, 2017 
and 
 December 31, 2016, 
the Company recorded additions to other intangible assets of 
$11.0
 million and 
$144.4
 million, respectively, for acquisitions during those years, the components of which were as follows:

[0001437749-18-003245:notes:130]
|  |  | 2017 |  |  | 2016 |  |
| (in thousands) |  | Weighted Average Useful Life |  |  | Amount |  |  | Weighted Average Useful Life |  |  | Amount |  |
| Patents, licenses and software |  | 9.6 |  |  | $ | 7,810 |  |  | 9.6 |  |  | $ | 65,449 |  |
| Customer relationships, trademarks and tradenames |  | 9.0 |  |  |  | 3,220 |  |  | 13.5 |  |  |  | 78,919 |  |
| Total |  |  |  |  | $ | 11,030 |  |  |  |  |  | $ | 144,368 |  |

[0001437749-18-003245:notes:131]
For intangible assets with definite lives, the Company recorded amortization expense of 
$24.7
 million, 
$19.3
 million, and 
$11.9
 million in 
2017,

[0001437749-18-003245:notes:132]
Estimated amortization expense related to intangible assets with definite lives at 
 December 30, 2017 
is as follows:

[0001437749-18-003245:notes:133]
| (in thousands) |  | Amount |  |
| 2018 |  | $ | 25,689 |  |
| 2019 |  |  | 25,528 |  |
| 2020 |  |  | 24,879 |  |
| 2021 |  |  | 23,093 |  |
| 2022 |  |  | 22,058 |  |
| 2023 and thereafter |  |  | 82,603 |  |
|  |  | $ | 203,850 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-18-003245:notes:134]
10.

[0001437749-18-003245:notes:135]
Income

[0001437749-18-003245:notes:136]
Taxes

[0001437749-18-003245:notes:137]
On 
 December 22, 2017, 
the U.S. enacted legislation commonly referred to as t
he Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduces the U.S. corporate federal income tax rate from 
35%
 to 
21%,
 adds base broadening provisions which limit deductions and address excessive international tax planning, imposes a 
one
-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enables repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. Other than the Toll Charge (which is applicable to the Company for 
2017
), the provisions will generally be applicable to the Company in 
2018
 and beyond.

[0001437749-18-003245:notes:138]
In accordance with the guidance provided in SEC Staff Accounting Bulletin (“SAB”) 
No.

[0001437749-18-003245:notes:139]
118,
 in the 
fourth
 quarter of 
2017
 the Company recorded a charge of 
$47
 million as a provisional reasonable estimate of the impact of the Tax Act, including 
$49
 million for the Toll Charge net of 
$2
 million for other net tax benefits. The Company is continuing to analyze the Tax Act and plans to finalize the estimate within the measurement period outlined in SAB 
No.

[0001437749-18-003245:notes:140]
118.
 The final charge 
 may 
differ from the provisional reasonable estimate if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining the estimate, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors. Aside from these interpretation issues, the final charge 
 may 
differ from the provisional reasonable estimate due to refinements of accumulated non-U.S. earnings and tax pool data.

[0001437749-18-003245:notes:141]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has 
not
 adopted an accounting policy for GILTI. Thus, the U.S. balance sheet tax accounts, notably deferred taxes, were computed without consideration of the possible future impact of the GILTI provisions. The Company intends to adopt an accounting policy for GILTI within the measurement period outlined in SAB 
118.

[0001437749-18-003245:notes:142]
Domestic and foreign income (loss) before income taxes is as follows:

[0001437749-18-003245:notes:143]
| (in thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | (20,496 | ) |  | $ | (9,563 | ) |  | $ | 1,313 |  |
| Foreign |  |  | 224,533 |  |  |  | 132,837 |  |  |  | 105,635 |  |
| Income before income taxes |  | $ | 204,037 |  |  | $ | 123,274 |  |  | $ | 106,948 |  |

[0001437749-18-003245:notes:144]
Federal, state and foreign income tax expense (benefit) consists of the following:

[0001437749-18-003245:notes:145]
| (in thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 34,060 |  |  | $ | (3,992 | ) |  | $ | (6,686 | ) |
| State |  |  | 450 |  |  |  | (648 | ) |  |  | 2,078 |  |
| Foreign |  |  | 32,945 |  |  |  | 28,695 |  |  |  | 19,211 |  |
| Subtotal |  |  | 67,455 |  |  |  | 24,055 |  |  |  | 14,603 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal and State |  |  | 16,562 |  |  |  | (1,594 | ) |  |  | 11,330 |  |
| Foreign |  |  | 501 |  |  |  | (3,675 | ) |  |  | 149 |  |
| Subtotal |  |  | 17,063 |  |  |  | (5,269 | ) |  |  | 11,479 |  |
| Provision for income taxes |  | $ | 84,518 |  |  | $ | 18,786 |  |  | $ | 26,082 |  |

[0001437749-18-003245:notes:146]
The current federal and state income tax expense for 
2017
 includes the preliminary estimate of 
$49
 million 
for the Toll Charge as discussed above, partially offset by 
$13
 million of foreign tax credits. The Company will elect to pay the 
2017
 current federal income tax over the 
eight
-year period prescribed by the Tax Act. The long-term portion of the 
2017
 current federal income tax (approximately 
$32
 million) is recorded in the 
O

[0001437749-18-003245:notes:147]
ther long-term liabilit

[0001437749-18-003245:notes:148]
ies
 on the Consolidated Balance Sheets as of 
 December 30, 2017.

[0001437749-18-003245:notes:149]
The current federal tax benefit for 
2016
 includes an estimated 
$3
 million benefit as a result of the carry-back of the 
2016
 U.S. federal net operating loss to the 
2014
 tax year.

[0001437749-18-003245:notes:150]
The current federal tax benefit for 
2015
 includes an 
$11.7
 million benefit reclassified from accumulated other comprehensive income as a result of the company
’s termination of the U.S. defined benefit pension plan as described in Note 
8,

[0001437749-18-003245:notes:151]
Benefit Plans
.

[0001437749-18-003245:notes:152]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0001437749-18-003245:notes:153]
| (in thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Tax expense at statutory rate of 35% |  | $ | 71,413 |  |  | $ | 43,146 |  |  | $ | 37,432 |  |
| Provisional amount of the Toll charge |  |  | 49,000 |  |  |  | — |  |  |  | — |  |
| Provisional Tax Act impact other than the Toll charge |  |  | (1,962 | ) |  |  | — |  |  |  | — |  |
| State and local taxes, net of federal tax benefit |  |  | 292 |  |  |  | (415 | ) |  |  | 1,907 |  |
| Non-U.S. income tax rate differential |  |  | (47,077 | ) |  |  | (25,471 | ) |  |  | (18,253 | ) |
| Impairment of goodwill without tax benefit |  |  | — |  |  |  | 3,088 |  |  |  | — |  |
| Tax on unremitted earnings |  |  | 12,202 |  |  |  | 2,747 |  |  |  | — |  |
| Mexico manufacturing operations restructuring |  |  | — |  |  |  | — |  |  |  | 4,841 |  |
| Nondeductible professional fees |  |  | 1,240 |  |  |  | 313 |  |  |  | 1,011 |  |
| Tax deduction for stock of foreign subsidiary |  |  | — |  |  |  | (3,896 | ) |  |  | — |  |
| Other, net |  |  | (590 | ) |  |  | (726 | ) |  |  | (856 | ) |
| Provision for income taxes |  | $ | 84,518 |  |  | $ | 18,786 |  |  | $ | 26,082 |  |

[0001437749-18-003245:notes:154]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the company
’s assets and liabilities. Significant components of the company’s deferred tax assets and liabilities at 
 December 30, 2017 
and 
 December 31, 2016, 
are as follows:

[0001437749-18-003245:notes:155]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 24,094 |  |  | $ | 31,770 |  |
| Foreign tax credit carryforwards |  |  | 1,053 |  |  |  | 6,472 |  |
| Accrued restructuring |  |  | 156 |  |  |  | 456 |  |
| Capital losses |  |  | 3,165 |  |  |  | 4,557 |  |
| Domestic and foreign net operating loss carryforwards |  |  | 5,778 |  |  |  | 2,223 |  |
| Gross deferred tax assets |  |  | 34,246 |  |  |  | 45,478 |  |
| Less: Valuation allowance |  |  | (6,203 | ) |  |  | (6,738 | ) |
| Total deferred tax assets |  |  | 28,043 |  |  |  | 38,740 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Tax depreciation and amortization in excess of book |  |  | 21,254 |  |  |  | 23,471 |  |
| Tax on unremitted earnings |  |  | 12,000 |  |  |  | 1,750 |  |
| Total deferred tax liabilities |  |  | 33,254 |  |  |  | 25,221 |  |
| Net deferred tax (liabilities) assets |  | $ | (5,211 | ) |  | $ | 13,519 |  |

[0001437749-18-003245:notes:156]
The deferred tax asset valuation allowance is related to a U.S. capital loss carryover (which expire in 
2018
) and tax attributes of certain non-US subsidiaries which are 
not
 expected to be realized. The remaining net operating losses either have 
no
 expira
tion date or are expected to be utilized prior to expiration (which begin expiring in 
2021
). The Company paid income taxes of 
$31.8
 million, 
$35.6
 million, and 
$23.3
 million in 
2017,

[0001437749-18-003245:notes:157]
2016,
 and 
2015,
 respectively, and received income tax refunds of 
$13.7
 million in 
2017.

[0001437749-18-003245:notes:158]
Deferred income taxes are 
not
 provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. As of 
 December 30, 2017, 
unremitted earnings of the Company
’s non-U.S. subsidiaries was approximately 
$680
 million. The Company recognized deferred tax liabilities of 
$12.0
 million (
$11.8
 million for non-U.S. taxes and 
$0.2
 million for U.S. state taxes) as of 
 December 30, 2017 
and 
$1.8
 million as of 
 December 31, 2016, 
related to taxes on certain non-U.S. earnings which are 
not
 considered to be permanently reinvested. Some of these taxes 
 may 
provide a U.S. federal income tax benefit as a foreign tax credit. However, due to uncertainty in regard to the Tax Act’s provisions, 
no
 such tax benefit was recorded. The Company will reconsider this provisional conclusion when it finalizes its preliminary reasonable estimate of the impact of the Tax Act, based upon interpretations and administrative guidance as of that time.

[0001437749-18-003245:notes:159]
The 
Company has 
three
 subsidiaries in China which benefit from lowered income tax rates due to “tax holidays” which apply for 
three
-year periods, subject to extension. One such tax holiday expires in 
2018,
 and the Company expects to be granted an extension. Such tax holidays contributed 
$5.7
 million in tax benefits, or 
$0.25
 per diluted share, during 
2017,
 with similar amounts expected in future years while such tax holidays are in effect.

[0001437749-18-003245:notes:160]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of 
 December 30, 2017,

[0001437749-18-003245:notes:161]
December 31, 2016, 
and 
 January 2, 2016 
is as follows:

[0001437749-18-003245:notes:162]
| (in thousands, except per share amounts) |  | Unrecognized Tax Benefits |  |
| Balance at January 2, 2016 |  | $ | 3,532 |  |
| Additions for tax positions taken in the current year |  |  | 2,696 |  |
| Additions for tax positions taken in the pre-acquisition periods of acquired subsidiaries |  |  | 2,491 |  |
| Settlements |  |  | (102 | ) |
| Balance at December 31, 2016 |  | $ | 8,617 |  |
| Additions for tax positions taken in the current year |  |  | 370 |  |
| Other |  |  | (1,327 | ) |
| Balance at December 30, 2017 |  | $ | 7,660 |  |

[0001437749-18-003245:notes:163]
The company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense. The company recognized interest expense of 
$0.9
 million, 
$0.9
 million, and 
$0.2
 million in 
2017,

[0001437749-18-003245:notes:164]
2016,
 and 
2015,
 respectively. Accrued interest was 
$3.3
 million, 
$2.4
 million, and 
$1.5
 million as of 
 December 30, 2017,

[0001437749-18-003245:notes:165]
December 31, 2016, 
and 
 January 2, 2016, 
respectively.

[0001437749-18-003245:notes:166]
The amount of unrecognized tax benefits at 
 December 30, 2017 
was $

[0001437749-18-003245:notes:167]
7.7
 million. This total represents the net amount of tax benefits that, if recognized, would favorably affect the effective income tax rate in future periods. The company does 
not
 expect any material decrease in unrecognized tax benefits in the next 
12
 months. 
None
 of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility.

[0001437749-18-003245:notes:168]
The U.S. federal statute of limitations remains open for 
201

[0001437749-18-003245:notes:169]
4
 onward although the company has been audited for 
2014
 (during 
2016
) and the audit concluded with 
no
 additional tax due. In late 
2017,
 the U.S. Internal Revenue Service began an examination of the Company’s federal income tax returns for 
2015
 and 
2016
 (with certain aspects of 
2014
 also subject to review as a consequence of a carryback of tax attributes from 
2016
). Foreign and U.S. state statute of limitations generally range from 
three
 to 
seven
 years. The German tax authority is currently conducting its examination for tax years 
2011
 through 
2014.
 Other non-U.S. tax examinations occur from time to time, including 
one
 which is currently in process in Italy. The company does 
not
 expect to recognize a significant amount of additional tax expense as a result of concluding any of these examinations.


## us-gaap:IncomeTaxPolicyTextBlock

[0001437749-18-003245:notes:170]
Income Taxes

[0001437749-18-003245:notes:171]
The 
Company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than 
not
 that some portion, or all, of the deferred tax assets will 
not
 be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0001437749-18-003245:notes:172]
Deferred U.S. income taxes and non-U.S. taxes are 
not
 provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested 
in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company’s foreign subsidiaries.  Changes in economic and business conditions, non-U.S. or U.S. tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0001437749-18-003245:notes:173]
The 
Company recognizes the tax benefit from an uncertain tax position only if it is more likely than 
not
 that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 
50%
 likelihood of being realized upon ultimate settlement.

[0001437749-18-003245:notes:174]
118,
 in the 
fourth
 quarter of 
2017
 the Company recorded a charge of 
$47
 million as a provisional reasonable estimate of the impact of the Tax Act, including 
$49
 million for the Toll Charge net of 
$2
 million for other net tax benefits. The Company is continuing to analyze the Tax Act and plans to finalize the estimate within the measurement period outlined in SAB 
No.118.

[0001437749-18-003245:notes:175]
The final charge 
 may 
differ from the provisional reasonable estimate if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining the estimate, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors. Aside from these interpretation issues, the final charge 
 may 
differ from the provisional reasonable estimate due to refinements of accumulated non-U.S. earnings and tax pool data.

[0001437749-18-003245:notes:176]
One of the base broadening provisions of the Tax Act is commonly referred to as the global intangible low-taxed income “
GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has 
not
 adopted an accounting policy for GILTI. Thus, the U.S. balance sheet tax accounts, notably deferred taxes, were computed without consideration of the possible future impact of the GILTI provisions. The Company intends to adopt an accounting policy for GILTI within the measurement period outlined in SAB 
118.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-18-003245:notes:177]
3

[0001437749-18-003245:notes:178]
. Inventories

[0001437749-18-003245:notes:179]
The components of inventories at 
 December 3

[0001437749-18-003245:notes:180]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Raw materials |  | $ | 39,030 |  |  | $ | 32,231 |  |
| Work in process |  |  | 27,454 |  |  |  | 23,354 |  |
| Finished goods |  |  | 74,305 |  |  |  | 58,478 |  |
| Total |  | $ | 140,789 |  |  | $ | 114,063 |  |

[0001437749-18-003245:notes:181]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS


## us-gaap:InventoryPolicyTextBlock

[0001437749-18-003245:notes:182]
Inventories

[0001437749-18-003245:notes:183]
Inventories are stated at the lower of cost or 
net realizable value, which approximates current replacement cost. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.


## us-gaap:InvestmentPolicyTextBlock

[0001437749-18-003245:notes:184]
Short-Term and Long-Term Investments

[0001437749-18-003245:notes:185]
2017,
 the Company had an investment in Polytronics Technology Corporation Ltd. (“Polytronics”). The Company’s Polytronics shares held at the end of fiscal 
2017
 and 
2016
 represent approximately

[0001437749-18-003245:notes:186]
7.2%

[0001437749-18-003245:notes:187]
of total Polytronics shares outstanding. The Polytronics investment is classified as available-for-sale and is carried at fair value with the unrealized gains and losses reported as a component of “Accumulated Other Comprehensive Income (Loss).” The fair value of the Polytronics investment was 
€9.2
 million (approximately 
$11.0
 million) at 
 December 30, 2017 
and 
€10.0
 million (approximately 
$10.4
 million) at 
 December 31, 2016. 
Included in 
2017
 and 
2016,
 other comprehensive income are unrealized losses of 
$1.0
 million and 
$0.8
 million, respectively, due to changes in fair market value of the Polytronics investment. The remaining movement year over year was due to the impact of changes in exchange rates.

[0001437749-18-003245:notes:188]
The 
Company has certain investment securities that are classified as available-for-sale. Available-for-sale securities are carried at fair value with the unrealized gains and losses reported as a component of “Accumulated Other Comprehensive Income (Loss).” Realized gains and losses and declines in unrealized value judged to be other-than-temporary on available-for-sale securities are included in other expense (income), net. The cost of securities sold is based on the specific identification method. Interest and dividends on securities classified as available-for-sale are included in interest income. Short-term investments, which are primarily certificates of deposits, are carried at cost which approximates fair value.

[0001437749-18-003245:notes:189]
The C
ompany has investments related to its non-qualified Supplemental Retirement and Savings Plan. The Company maintains accounts for participants through which participants make investment elections. The investment securities are subject to the claims of the Company’s creditors. The investment securities are all mutual funds with readily determinable fair values and are classified as trading securities. The investment securities are measured at fair value with unrealized gains and losses recognized in earnings. As of 
 December 30, 2017, 
there was 
$8.0
 million of marketable securities related to the plan included in 
Other assets
 on the Consolidated Balance Sheets.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-18-003245:notes:190]
2

[0001437749-18-003245:notes:191]
. Acquisitions and Dispositions

[0001437749-18-003245:notes:192]
The 
Company accounts for acquisitions using the acquisition method in accordance with ASC 
805,
 “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0001437749-18-003245:notes:193]
Subsequent Event

[0001437749-18-003245:notes:194]
IXYS Corporation

[0001437749-18-003245:notes:195]
On 
 January 17, 2018, 
the 
Company acquired IXYS Corporation (“IXYS”), a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 
3,500
 customers through its direct sales force and global distribution partners. The acquisition of IXYS is expected to accelerate the Company’s growth across the power control market driven by IXYS’s extensive power semiconductor portfolio and technology expertise. With IXYS, the Company will be able to diversify and expand its presence within industrial electronics markets, leveraging the strong IXYS industrial OEM customer base. The Company also expects to increase long-term penetration of its power semiconductor portfolio in automotive markets, expanding its global content per vehicle.

[0001437749-18-003245:notes:196]
The Company has commenced the determination of the purchase price allocation. 
Upon completion of the acquisition, at IXYS stockholders’ election and subject to proration, each share of IXYS common stock, par value 
$0.01
 per share, owned immediately prior to the effective time were cancelled and extinguished and automatically converted into the right to receive: (i) 
$23.00
 in cash (subject to applicable withholding tax), without interest (referred to as the cash consideration), or (ii) 
0.1265
 of a share of common stock, par value 
$0.01
 per share, of Littelfuse (referred to as the stock consideration and together with the cash consideration, the merger consideration). IXYS stockholders received cash in lieu of any fractional shares of Littelfuse common stock that the IXYS stockholders would otherwise have been entitled to receive. Additionally, each outstanding option to purchase shares of IXYS common stock granted under an IXYS equity plan were assumed by Littelfuse and converted into an option to acquire (i) a number of shares of Littelfuse common stock equal to the number of shares of IXYS common stock subject to such option immediately prior to the effective time multiplied by 
0.1265,
 rounded down to the nearest whole share, with (ii) an exercise price per share of Littelfuse common stock equal to the exercise price of such IXYS stock option immediately prior to the effective time divided by 
0.1265,
 rounded up to the nearest whole cent.

[0001437749-18-003245:notes:197]
Based on the

[0001437749-18-003245:notes:198]
$207.5
 per share opening price of Littelfuse common stock on 
 January 17, 2018, 
the consideration IXYS stockholders received in exchange of their IXYS common stock in the acquisition had a value of approximately 
$814.8
 million comprised of 
$380.5
 million of cash and 
$434.2
 million of Littelfuse stock. In addition to the consideration transferred related to IXYS common stock, the value of consideration transferred, and included in the purchase price, related to IXYS stock options that were converted to Littelfuse stock options, or cash settled, had a value of approximately 
$41.7
 million. As a result, total consideration is valued at approximately 
$856.5
 million. The Company is in the process of estimating the purchase price allocation.

[0001437749-18-003245:notes:199]
2017
 Acquisitions

[0001437749-18-003245:notes:200]
U.S. Sensor

[0001437749-18-003245:notes:201]
O
n 
 July 7, 2017, 
the Company acquired the assets of U.S. Sensor Corporation (“U.S. Sensor”). The acquisition purchase price of 
$24.3
 million, net of the finalization of an income tax gross up which was settled in the 
fourth
 quarter of 
2017,
 was funded with available cash

[0001437749-18-003245:notes:202]
. The acquired business

[0001437749-18-003245:notes:203]
expands the Company’s existing sensor portfolio in several key electronics and industrial end markets. U.S. Sensor manufactures a variety of high quality negative temperature coefficient thermistors as well as thermistor probes and assemblies. Product lines also include thin film platinum resistance temperature detectors (“RTDs”) and RTD assemblies.

[0001437749-18-003245:notes:204]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the U.S. Sensor acquisition:

[0001437749-18-003245:notes:205]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 24,340 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 4,635 |  |
| Patented and unpatented technologies |  |  | 1,090 |  |
| Trademarks and tradenames |  |  | 200 |  |
| Non-compete agreement |  |  | 50 |  |
| Customer relationships |  |  | 2,830 |  |
| Goodwill |  |  | 16,075 |  |
| Current liabilities |  |  | (540 | ) |
|  |  | $ | 24,340 |  |

[0001437749-18-003245:notes:206]
Included in U.S. Sensor
’s current assets, net was approximately 
$1.5
 million of receivables. All U.S. Sensor goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining U.S. Sensor’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-18-003245:notes:207]
As required by purchase accounting rules, the 
Company recorded a 
$1.6
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the 
third
 quarter of 
2017,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-18-003245:notes:208]
Monolith

[0001437749-18-003245:notes:209]
In 
 December 2015, 
the Company invested 
$3.5
 million in the preferred stock of Monolith Semiconductor Inc. (
“Monolith”), a U.S. start-up Company developing silicon carbide technology, which represented approximately 
12%
 of the common stock of Monolith on an as-converted basis. The Company accounted for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was 
$3.5
 million at 
 December 31, 2016.

[0001437749-18-003245:notes:210]
On 
 February 28, 2017, 
pursuant to a Securities Purchase Agreement between the Company and the stockholders of Monolith and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired approximately 
62%
 of the outstanding common stock of Monolith for 
$15
 million. The Securities Purchase Agreement includes provisions whereby the Company will acquire the remaining outstanding stock of Monolith (“non-controlling interest”) at a time or times based on Monolith meeting certain technical and sales targets. Consideration for the additional investment(s) will range from 
$1.0
 million to 
$10
 million and will be paid 
no
 later than 
 June 30, 2019.

[0001437749-18-003245:notes:211]
The additional investment resulted in the Company gaining control of Monolith and was accounted for as a step-acquisition with the fair value of the original investment immediately before the acquisition estimated to be approximately 
$3.5
 million. As the 
fair value of the investment immediately prior to the transaction equaled the carrying value, there was 
no
 impact on the Company’s Consolidated Statements of Net Income. As the Securities Purchase Agreement includes an obligation of the Company to mandatorily redeem the non-controlling interest for cash, the fair value of the non-controlling interest was recognized as a liability on the Company’s Consolidated Balance Sheets. Changes in the fair value of the non-controlling interest are recognized in the Company’s Consolidated Statements of Net Income.

[0001437749-18-003245:notes:212]
Commencing 
 March 1, 2017, 
Monolith was reflected as a consolidated subsidiary within the Company
’s Consolidated Financial Statements. Had the acquisition occurred as of 
 January

[0001437749-18-003245:notes:213]
1,

[0001437749-18-003245:notes:214]
2017,
 the impact on the Company’s consolidated results of operations would 
not
 have been material.

[0001437749-18-003245:notes:215]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the Monolith acquisition:

[0001437749-18-003245:notes:216]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Original investment |  | $ | 3,500 |  |
| Cash, net of cash acquired |  |  | 14,172 |  |
| Fair value of commitment to purchase non-controlling interest |  |  | 9,000 |  |
| Total purchase consideration |  | $ | 26,672 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 891 |  |
| Property, plant, and equipment |  |  | 789 |  |
| Patented and unpatented technologies |  |  | 6,720 |  |
| Non-compete agreement |  |  | 140 |  |
| Goodwill |  |  | 20,641 |  |
| Current liabilities |  |  | (639 | ) |
| Other non-current liabilities |  |  | (1,870 | ) |
|  |  | $ | 26,672 |  |

[0001437749-18-003245:notes:217]
Included in Monolith
’s current assets, net was approximately 
$0.7
 million of receivables. All Monolith goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Monolith’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-18-003245:notes:218]
2016
 Acquisitions

[0001437749-18-003245:notes:219]
ON Portfolio

[0001437749-18-003245:notes:220]
On 
 August 29, 2016, 
the 
Company acquired certain assets of select businesses (the “ON Portfolio”) of ON Semiconductor Corporation for 
$104.0
 million. The Company funded the acquisition with available cash and proceeds from its credit facility

[0001437749-18-003245:notes:221]
. The acquired business, which is included in the Electronics segment,

[0001437749-18-003245:notes:222]
consists of a product portfolio that includes transient voltage suppression (“TVS”) diodes, switching thyristors and insulated gate bipolar transistors (“IGBTs”) for automotive ignition applications. The acquisition expands the Company’s offerings in power semiconductor applications as well as increases its presence in the automotive electronics market. The ON Portfolio products have strong synergies with the Company’s existing circuit protection business and will strengthen its channel partnerships and customer engagement.

[0001437749-18-003245:notes:223]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the 
ON Portfolio acquisition:

[0001437749-18-003245:notes:224]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 104,000 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 4,816 |  |
| Customer relationships |  |  | 31,800 |  |
| Patented and unpatented technologies |  |  | 8,800 |  |
| Non-compete agreement |  |  | 2,500 |  |
| Goodwill |  |  | 56,084 |  |
|  |  | $ | 104,000 |  |

[0001437749-18-003245:notes:225]
All the ON Portfolio business goodwill and other assets were recorded in the Electronics segment and are reflected in the Americas and Europe geographic areas. The customer relationships are being amortized over 
13.5
 years. The patented and unpatented technologies are being amortized over 
6
-
8.5
 years. The non-compete agreement is being amortized over 
4
 years. The goodwill resulting from this acquisition consists largely of the 
Company’s expected future product sales and synergies from combining the ON Portfolio products with the Company’s existing

[0001437749-18-003245:notes:226]
power semiconductor product portfolio. 
$7.3
 million of goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-18-003245:notes:227]
As required by purchase accounting rules, the 
Company recorded a 
$0.7
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. All of the step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-18-003245:notes:228]
Included in the 
Company’s Consolidated Statements of Net Income for the year ended 
 December 31, 2016 
are net sales of approximately 
$21.8
 million since the 
 August 29, 2016 
acquisition of the ON Portfolio business.

[0001437749-18-003245:notes:229]
Menber
’s

[0001437749-18-003245:notes:230]
On 
 April 4, 2016, 
the 
Company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy for 
$19.2
 million, net of acquired cash and after settlement of a working capital adjustment. The Company funded the acquisition with cash on hand and borrowings under the Company’s revolving credit facility. The acquired business is part of the Company's commercial vehicle product business within the Automotive segment and specializes in the design, manufacturing, and selling of manual and electrical high current switches and trailer connectors for commercial vehicles. The acquisition expands the Company’s commercial vehicle products business globally.

[0001437749-18-003245:notes:231]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the
 Menber’s acquisition:

[0001437749-18-003245:notes:232]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash, net of acquired cash |  | $ | 19,162 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 12,919 |  |
| Property, plant, and equipment |  |  | 1,693 |  |
| Customer relationships |  |  | 3,050 |  |
| Patented and unpatented technologies |  |  | 224 |  |
| Trademarks and tradenames |  |  | 1,849 |  |
| Goodwill |  |  | 8,091 |  |
| Current liabilities |  |  | (7,220 | ) |
| Other non-current liabilities |  |  | (1,444 | ) |
|  |  | $ | 19,162 |  |

[0001437749-18-003245:notes:233]
All Menber
’s goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The customer relationships are being amortized over 
10
 years. The patented and unpatented technologies are being amortized over 
5
 years. The trademarks and tradenames are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Menber’s products with the Company’s existing automotive product portfolio. Goodwill for the above acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-18-003245:notes:234]
As required by purchase accounting rules, the 
Company recorded a 
$0.2
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, with the charge reflected as other non-segment costs.

[0001437749-18-003245:notes:235]
Included in the 
Company’s Consolidated Statements of Net Income for the year ended 
 December 31, 2016 
are net sales of approximately 
$17.3
 million since the 
 April 4, 2016 
acquisition of Menber’s.

[0001437749-18-003245:notes:236]
PolySwitch

[0001437749-18-003245:notes:237]
On 
 March 25, 2016, 
the 
Company acquired 
100%
 of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for 
$348.3
 million, net of acquired cash and after settlement of certain post-closing adjustments. The Company funded the acquisition with available cash on hand and borrowings under the Company’s revolving credit facility. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-18-003245:notes:238]
has a leading position in polymer based resettable circuit protection devices, with a strong global presence in the automotive, battery, industrial, communications and mobile computing markets. PolySwitch has manufacturing facilities in Shanghai and Kunshan, China and Tsukuba, Japan. The acquisition allows the Company to strengthen its global circuit protection product portfolio, as well as strengthen its presence in the automotive electronics and battery end markets. The acquisition also significantly increases the Company’s presence in Japan.

[0001437749-18-003245:notes:239]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the
 PolySwitch acquisition:

[0001437749-18-003245:notes:240]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Original consideration |  | $ | 350,000 |  |
| Post closing consideration adjustment received |  |  | (1,708 | ) |
| Acquired cash |  |  | (3,810 | ) |
| Acquired cash to be returned to seller |  |  | 3,810 |  |
| Total purchase consideration |  | $ | 348,292 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 60,228 |  |
| Property, plant, and equipment |  |  | 51,613 |  |
| Land lease |  |  | 4,290 |  |
| Patented and unpatented technologies |  |  | 56,425 |  |
| Customer relationships |  |  | 39,720 |  |
| Goodwill |  |  | 165,088 |  |
| Other long-term assets |  |  | 11,228 |  |
| Current liabilities |  |  | (35,280 | ) |
| Other non-current liabilities |  |  | (5,020 | ) |
|  |  | $ | 348,292 |  |

[0001437749-18-003245:notes:241]
All PolySwitch goodwill and other assets and liabilities were recorded in the Electronics 
and Automotive segments and reflected in all geographic areas. The customer relationships are being amortized over 
15
 years. The patented and unpatented technologies are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining PolySwitch products with the Company’s existing automotive and electronics product portfolio. 
$103.8
 million and 
$61.3
 million of the goodwill for the above acquisition has been assigned to the Electronics and Automotive segments, respectively, with 
$64.9
 million expected to be deductible for tax purposes.

[0001437749-18-003245:notes:242]
As required by purchase accounting rules, the 
Company recorded a 
$6.9
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the 
second
 quarter of 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-18-003245:notes:243]
Included in the 
Company’s Consolidated Statements of Net Income for the year ended 
 December 31, 2016 
are net sales of approximately 
$126.5
 million since the 
 March 25, 2016 
acquisition of PolySwitch.

[0001437749-18-003245:notes:244]
2016
 Dispositions

[0001437749-18-003245:notes:245]
During the 
first
 quarter of 
2016,
 the 
Company sold its tangible and intangible assets relating to a marine product line that it acquired as part of its acquisition of Selco A/S in 
2011.
 In connection with this sale, the Company recorded a loss on sale of the product line of 
$1.4
 million reflected within selling, general, and administrative expenses for the year ended 
 December 31, 2016. 
This loss was recognized as an “other” charge for segment reporting purposes.

[0001437749-18-003245:notes:246]
2015
 Acquisitions

[0001437749-18-003245:notes:247]
Sigmar S.r.l

[0001437749-18-003245:notes:248]
On 
 October 1, 2015, 
the 
Company acquired 
100%
 of Sigmar S.r.l. (“Sigmar”). The total purchase price for Sigmar was 
$6.5
 million, net of cash acquired and including estimated additional net payments of up to 
$0.9
 million, a portion of which is subject to the achievement of certain milestones.

[0001437749-18-003245:notes:249]
Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel sensors and also manufactures selective catalytic reduction (
“SCR”) quality sensors and diesel fuel heaters for automotive and commercial vehicle applications. The acquisition further expanded the Company’s automotive sensor product line offerings within its Automotive segment. The Company funded the acquisition with available cash.

[0001437749-18-003245:notes:250]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the Sigmar acquisition:

[0001437749-18-003245:notes:251]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash, net of acquired cash |  | $ | 5,558 |  |
| Estimated additional consideration payable |  |  | 901 |  |
| Total purchase consideration |  | $ | 6,459 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 2,519 |  |
| Property, plant, and equipment |  |  | 1,097 |  |
| Goodwill |  |  | 4,084 |  |
| Patents |  |  | 2,845 |  |
| Current liabilities |  |  | (1,518 | ) |
| Other non-current liabilities |  |  | (2,568 | ) |
|  |  | $ | 6,459 |  |

[0001437749-18-003245:notes:252]
All Sigmar goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The patents are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the 
Company’s expected future product sales and synergies from combining Sigmar’s products with the Company’s existing automotive product offerings. Goodwill for the above acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-18-003245:notes:253]
Pro Forma Results

[0001437749-18-003245:notes:254]
The following table summarizes, on a pro forma basis, the combined results of operations of the 
Company and the acquired PolySwitch and the ON Portfolio businesses as though the acquisitions had occurred as of 
 December 28, 2014. 
The Company has 
not
 included pro forma results of operations for Menber’s or Sigmar as these results were 
not
 material to the Company. The pro forma amounts presented are 
not
 necessarily indicative of either the actual consolidated results had the PolySwitch or ON Portfolio acquisitions occurred as of 
 December 28, 2014 
or of future consolidated operating results.

[0001437749-18-003245:notes:255]
Pro forma results presented above primarily reflect: (
i) incremental depreciation relating to fair value adjustments to property, plant, and equipment; (ii) amortization adjustments relating to fair value estimates of intangible assets; (iii) incremental interest expense on assumed indebtedness; and (iv) additional cost of goods sold relating to the capitalization of gross profit as part of purchase accounting recognized for purposes of the pro forma as if it was recognized during the Company’s 
first
 quarter of 
2015.
 Pro forma adjustments described above have been tax affected using the Company's effective rate during the respective periods.

[0001437749-18-003245:notes:256]
The historical PolySwitch and ON Portfolio business results for the years ended 
 December 31, 2016 
and 
 January 2, 2016 
do 
not
 include a provision for income taxes. Income tax expense for the historical PolySwitch business was only provided at the end of the business
’s fiscal year ended 
 September 25, 2015. 
Income tax expense for the historical ON Portfolio business was 
not
 provided on a standalone basis.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-18-003245:notes:257]
Recently Issued Accounting Standards

[0001437749-18-003245:notes:258]
In 
 October 2016, 
the FASB issued ASU 
No.

[0001437749-18-003245:notes:259]
2016
-
16,
 "Income Taxes
” (Topic 
740
). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted. Adoption will require a modified retrospective transition
, and is 
not
 expected to have a material impact.

[0001437749-18-003245:notes:260]
In 
 March 2016, 
the FASB issued ASU 
No.

[0001437749-18-003245:notes:261]
2016
-
09

[0001437749-18-003245:notes:262]
– “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
As a result of the adoption, on a prospective basis, the Company recognized 
$2.0
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the year ended 
 December 30, 2017. 
Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Consolidated Statements of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Consolidated Statements of Cash Flows. The Company elected 
not
 to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had 
no
 impact on the results of operations.

[0001437749-18-003245:notes:263]
In 
 January 2016, 
the FASB issued ASU 
No.

[0001437749-18-003245:notes:264]
2016
-
01,
 “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU will require the Company to recognize any changes in the fair value of certain equity investments in net income. These changes are currently recognized in other comprehensive income ("OCI"). This guidance is effective for interim and fiscal years beginning after

[0001437749-18-003245:notes:265]
December 15, 2017.

[0001437749-18-003245:notes:266]
In 
 February 2016, 
the FASB issued ASU 
No.

[0001437749-18-003245:notes:267]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition, 
and the Company plans to adopt the standard in the 
first
 quarter of 
2019.
 The Company is currently evaluating the impact of ASU 
2016
-
02.

[0001437749-18-003245:notes:268]
In 
 May 2014, 
the FASB issued ASU 
No.

[0001437749-18-003245:notes:269]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August, 2015, 
the FASB issued ASU 
No.

[0001437749-18-003245:notes:270]
2015
-
14,
 which postponed the effective date of ASU 
No.

[0001437749-18-003245:notes:271]
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted on the original effective date of fiscal years beginning after 
 December 15, 2016.

[0001437749-18-003245:notes:272]
The Company is in the process of finalizing its assessment and the documentation of its evaluation of the new standard. 
The majority of the Company’s revenue arrangements generally consist of a single performance obligation to transfer promised finished goods. Based on the Company’s evaluation process completed and review of its contracts with customers, the timing and amount of revenue recognized based on ASU 
2015
-
14
 is consistent with its revenue recognition policy under previous guidance. The Company adopted the new standard effective 
 December 31, 2017, 
using the modified retrospective approach, and will expand its consolidated financial statement disclosures in order to comply with the ASU. The Company has determined the adoption of ASU 
2015
-
14
 will 
not
 have a material impact on its results of operations, cash flows, or financial position.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-18-003245:notes:273]
8

[0001437749-18-003245:notes:274]
. Benefit Plans

[0001437749-18-003245:notes:275]
The 
Company has Company-sponsored defined benefit pension plans covering employees in the U.K., Germany, the Philippines, China, Japan, Mexico, Italy and France. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0001437749-18-003245:notes:276]
PolySwitch Acquisition

[0001437749-18-003245:notes:277]
During 
2016,
 as a result of the PolySwitch acquisition, past service l
iabilities were assumed by the Company in mainland China, France, Germany, Japan, Mexico, and Taiwan (China), together with a small amount of plan assets in Taiwan (China).

[0001437749-18-003245:notes:278]
Littelfuse Inc. Retirement Plan Termination

[0001437749-18-003245:notes:279]
The company received approval from the IRS on 
 April 14, 2015 
on its Application for Determination for Terminating Plan to terminate the U.S. defined benefit pension plan, the Littelfuse Inc. Retirement Plan, effective 
 July 30, 2014. 
All plan liabilities were settled (either via lump sum payout or purchase of a group annuity contract) in the 
third
 quarter of 
2015.
 A cash contribution of 
$9.1
 million was made to the U.S. defined benefit plan
’s trust in the 
third
 quarter of 
2015
 to fully fund the plan on a buyout basis, and the eventual settlement of the plan’s liabilities triggered a settlement charge of 
$30.2
 million in the 
third
 quarter of 
2015.
 In the 
fourth
 quarter of 
2015
 there was an adjustment to the price of the annuity contract which resulted in a refund of premium to the company of 
$0.3
 million. This refund of premium, effectively a re-measurement gain, was recognized in the 
fourth
 quarter of 
2015
 as a dollar-for-dollar adjustment to the 
$30.2
 million earnings charge recognized in the 
third
 quarter of 
2015,
 resulting in a final settlement loss of 
$29.9
 million for the fiscal year ended 
 January 2, 2016.

[0001437749-18-003245:notes:280]
During 
2016,
 there were 
two
 further adjustments to the price of the annuity contract. Their combined effect resulted in a further refund of premium to the company of 
$0.3
 million. This refund of premium was considered additional actual return on the assets during 
2016,
 followed by a negative employer contribution of that same amount in the asset reconciliation table below.

[0001437749-18-003245:notes:281]
Benefit plan related information is as follows
 for the years 
2017
 and 
2016:

[0001437749-18-003245:notes:282]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year |  | $ | 55,606 |  |  | $ | 50,282 |  |
| Service cost |  |  | 2,037 |  |  |  | 1,509 |  |
| Interest cost |  |  | 1,887 |  |  |  | 1,662 |  |
| Net actuarial loss (gain) |  |  | (433 | ) |  |  | 10,190 |  |
| Benefits paid from the trust |  |  | (1,405 | ) |  |  | (2,329 | ) |
| Benefits paid directly by the Company |  |  | (1,098 | ) |  |  | 250 |  |
| Curtailments and settlements |  |  | (31 | ) |  |  | (427 | ) |
| Acquisitions |  |  | — |  |  |  | 2,023 |  |
| Effect of exchange rate movements |  |  | 5,477 |  |  |  | (7,554 | ) |
| Other |  |  | 5,228 |  |  |  | — |  |
| Benefit obligation at end of year |  | $ | 67,268 |  |  | $ | 55,606 |  |
| Change in plan assets at fair value: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year |  | $ | 42,208 |  |  | $ | 44,629 |  |
| Actual return on plan assets |  |  | 2,962 |  |  |  | 6,929 |  |
| Employer contributions |  |  | 264 |  |  |  | (126 | ) |
| Benefits paid |  |  | (1,405 | ) |  |  | (2,329 | ) |
| Acquisitions |  |  | — |  |  |  | 24 |  |
| Effect of exchange rate movements |  |  | 4,094 |  |  |  | (6,919 | ) |
| Fair value of plan assets at end of year |  |  | 48,123 |  |  |  | 42,208 |  |
| Net amount recognized/(unfunded status) |  | $ | (19,145 | ) |  | $ | (13,398 | ) |

[0001437749-18-003245:notes:283]
Amounts recognized in the Consolidated Balance Sheet
s as of 
 December 30, 2017 
and 
 December 31, 2016 
consist of the following:

[0001437749-18-003245:notes:284]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |  |  |  |  |  |
| Noncurrent assets |  | $ | 78 |  |  | $ | — |  |
| Current benefit liability |  |  | (481 | ) |  |  | — |  |
| Noncurrent benefit liability |  |  | (18,742 | ) |  |  | (13,398 | ) |
| Net liability recognized |  | $ | (19,145 | ) |  | $ | (13,398 | ) |

[0001437749-18-003245:notes:285]
Amounts recognized in accumulated other comprehensive income (loss), pre-tax 
as of 
 December 30, 2017 
and 
 December 31, 2016

[0001437749-18-003245:notes:286]
consist of:

[0001437749-18-003245:notes:287]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Net actuarial loss |  | $ | 12,261 |  |  | $ | 13,107 |  |
| Prior service (cost) |  |  | — |  |  |  | — |  |
| Net amount recognized, pre-tax |  | $ | 12,261 |  |  | $ | 13,107 |  |

[0001437749-18-003245:notes:288]
The estimated net actuarial loss (gain) which will be amortized from accumulated other comprehensive income 
(loss) into benefit cost in 
2018
 is

[0001437749-18-003245:notes:289]
approximately 
$0.3
 million.

[0001437749-18-003245:notes:290]
The components of pension exp
ense for the years 
2017,

[0001437749-18-003245:notes:291]
2016,
 and 
2015
 are as follows:

[0001437749-18-003245:notes:292]
|  |  |  |  |  |  |  |  |  |  | 2015 |  |
| (in thousands) |  | 2017 |  |  | 2016 |  |  | U.S. |  |  | Foreign |  |  | Total |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 2,037 |  |  | $ | 1,509 |  |  | $ | 750 |  |  | $ | 824 |  |  | $ | 1,574 |  |
| Interest cost |  |  | 1,887 |  |  |  | 1,662 |  |  |  | 3,093 |  |  |  | 1,735 |  |  |  | 4,828 |  |
| Expected return on plan assets |  |  | (1,990 | ) |  |  | (1,935 | ) |  |  | (2,749 | ) |  |  | (2,346 | ) |  |  | (5,095 | ) |
| Amortization of losses |  |  | 337 |  |  |  | 306 |  |  |  | 870 |  |  |  | 221 |  |  |  | 1,091 |  |
| Net periodic benefit cost |  |  | 2,271 |  |  |  | 1,542 |  |  |  | 1,964 |  |  |  | 434 |  |  |  | 2,398 |  |
| Curtailment/Settlement loss (gain) |  |  | (25 | ) |  |  | (36 | ) |  |  | 29,928 |  |  |  | — |  |  |  | 29,928 |  |
| Total expense (income) for the year |  | $ | 2,246 |  |  | $ | 1,506 |  |  | $ | 31,892 |  |  | $ | 434 |  |  | $ | 32,326 |  |

[0001437749-18-003245:notes:293]
Weighted average assumptions used to determine net periodic
 benefit cost for the years 
2017,

[0001437749-18-003245:notes:294]
|  |  |  |  |  |  |  |  |  |  | 2015 |  |
|  |  | 2017 |  |  | 2016 |  |  | U.S. |  |  | Foreign |  |
| Discount rate |  |  | 3.0 | % |  |  | 3.7 | % |  |  | 3.9 | % |  |  | 3.7 | % |
| Expected return on plan assets |  |  | 4.5 | % |  |  | 4.9 | % |  |  | 6.8 | % |  |  | 5.1 | % |
| Compensation increase rate |  |  | 4.5 | % |  |  | 5.3 | % |  |  | — |  |  |  | 5.3 | % |
| Measurement dates |  | 12/31/16 |  |  | 1/2/16 |  |  | 12/27/14 |  |  | 12/27/14 |  |

[0001437749-18-003245:notes:295]
The accumulated benefit obligation for the foreign plans 
was 
$60.5
 million and 
$51.3
 million at 
 December 30, 2017 
and 
 December 31, 2016, 
respectively.

[0001437749-18-003245:notes:296]
The following table provides a summary of under-funded or unfunded pension benefit plans with projected benefit obligations in excess of plan assets as of 
 December 30, 2017 
and 
 December 31, 2016:

[0001437749-18-003245:notes:297]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Projected benefit obligation |  | $ | 28,515 |  |  | $ | 48,985 |  |
| Fair value of plan assets |  |  | 9,292 |  |  |  | 42,179 |  |

[0001437749-18-003245:notes:298]
The following table provides a summary of under-funded or unfunded pension benefit plans with accumulated benefit obligations in excess of plan assets as of 
 December 30, 2017 
and 
 December 31, 2016:

[0001437749-18-003245:notes:299]
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Accumulated benefit obligation |  | $ | 18,990 |  |  | $ | 51,306 |  |
| Fair value of plan assets |  |  | 6,003 |  |  |  | 38,912 |  |

[0001437749-18-003245:notes:300]
Weighted average assumptions used to determine benefit obligations 
as of 
 December 30, 2017,

[0001437749-18-003245:notes:301]
December 31, 2016 
and 
 January 2, 2016 
are as follows:

[0001437749-18-003245:notes:302]
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Discount rate |  |  | 3.1 | % |  |  | 2.6 | % |  |  | 3.8 | % |
| Compensation increase rate |  |  | 5.0 | % |  |  | 4.5 | % |  |  | 6.2 | % |
| Measurement dates |  | 12/30/17 |  |  | 12/31/16 |  |  | 1/2/16 |  |

[0001437749-18-003245:notes:303]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows:

[0001437749-18-003245:notes:304]
| (in thousands) |  | Expected Benefit Payments |  |
| 2018 |  | $ | 2,467 |  |
| 2019 |  |  | 2,474 |  |
| 2020 |  |  | 2,473 |  |
| 2021 |  |  | 2,802 |  |
| 2022 |  |  | 2,776 |  |
| 2023-2027 |  |  | 16,777 |  |

[0001437749-18-003245:notes:305]
The Company expects to make approximately 
$1.4
 million of contributions to the plans in 
2018.

[0001437749-18-003245:notes:306]
Defined Benefit Plan Assets

[0001437749-18-003245:notes:307]
Based upon analysis of the target asset allocation and historical retu
rns by type of investment, the Company has assumed that the expected long-term rate of return will be 
4.5%
 on plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were 
not
 materially different from the target asset allocation:

[0001437749-18-003245:notes:308]
|  |  | Asset Allocation |  |
|  |  | 2017 |  |  | 2016 |  |
| Equity securities |  |  | 35 | % |  |  | 32 | % |
| Debt securities |  |  | 64 | % |  |  | 65 | % |
| Cash and equivalents |  |  | 1 | % |  |  | 3 | % |
|  |  |  | 100 | % |  |  | 100 | % |

[0001437749-18-003245:notes:309]
The Company segregated its plan assets by the following major categories and level for determining their fair value as of 
 December 30, 2017 
and 
 December 31, 2016. 
All plan assets that are valued using the net asset value per share (“NAV”) practical expedient have 
not
 been included within the fair value hierarchy but are separately disclosed.

[0001437749-18-003245:notes:310]
Cash and cash equivalents 
–

[0001437749-18-003245:notes:311]
Carrying value approximates fair value. As such these assets were classified as Level 
1.
 The Company also invests in certain short-term investments which are valued using the amortized cost method and at NAV.

[0001437749-18-003245:notes:312]
Equity 
–

[0001437749-18-003245:notes:313]
The values of individual equity securities were based on quoted prices in active markets. As such, these assets are classified as Level 
1.
 Additionally, the Company invests in certain equity funds that are valued at calculated NAV.

[0001437749-18-003245:notes:314]
Fixed income

[0001437749-18-003245:notes:315]
– Fixed income securities are typically priced based on a last trade basis and are exchange-traded. Accordingly, the Company classified fixed income securities as Level 
1.
 The Company also invests in certain fixed income funds which are valued at NAV.

[0001437749-18-003245:notes:316]
For any Level 
2
 plan assets, management reviews significant investments on a periodic basis including investigation of unusual fluctuations in price or returns and obtaining an understanding of the pricing methodology to assess the reliability of 
third
-party pricing estimates.

[0001437749-18-003245:notes:317]
The valuation methodologies described above 
 may 
generate a fair value calculation that 
 may

[0001437749-18-003245:notes:318]
not
 be indicative of net realizable value or future fair values. While the Company believes the valuation methodologies used are appropriate, the use of different methodologies or assumptions in calculating fair value could result in different amounts. The Company invests in various assets in which valuation is determined by NAV. The Company believes that the NAV is representative of fair value at the reporting date, as there are 
no
 significant restrictions on redemption of these investments or other reasons to indicate that the investment would be redeemed at an amount different than the NAV.

[0001437749-18-003245:notes:319]
Th
e following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of 
 December 30, 2017:

[0001437749-18-003245:notes:320]
Th
e following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of 
 December 31, 2016:

[0001437749-18-003245:notes:321]
Defined Contribution Plan

[0001437749-18-003245:notes:322]
The 
Company also maintains a 
401
(k) savings plan covering substantially all U.S. employees. The Company matches 
100%
 of the employee’s annual contributions for the 
first

[0001437749-18-003245:notes:323]
4%
 of the employee’s eligible compensation. The Company 
 may 
provide an additional discretionary match to participants and made discretionary matches of 
2%
 of the employee’s eligible compensation for each of the years ended 
 December 30, 2017,

[0001437749-18-003245:notes:324]
December 31, 2016 
and 
 January 2, 2016. 
Employees are immediately vested in their contributions plus actual earnings thereon, as well as the Company contributions. Company matching contributions amounted to 
$3.5
 million, 
$3.2
 million, and 
$2.8
 million in 
2017,

[0001437749-18-003245:notes:325]
Non-qualified Supplemental Retirement and Savings Plan

[0001437749-18-003245:notes:326]
The C
ompany has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The investments are subject to the claims of the Company’s creditors and the Company is responsible for the payment of all benefits under the plan from its general assets. As of 
 December 30, 2017, 
there was 
$8.0
 million of marketable securities related to the plan included in 
Other assets
 and 
$8.0
 million of accrued compensation included in 
Other long-term liabilities
. The marketable securities are classified as Level 
1
 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value. The Company made matching contributions to the plan of 
$0.3
 million in 
2017.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001437749-18-003245:notes:327]
Property, Plant

[0001437749-18-003245:notes:328]
,

[0001437749-18-003245:notes:329]
and Equipment

[0001437749-18-003245:notes:330]
Land, buildings
, and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of 
21
 years for buildings, 
seven
 to 
nine
 years for equipment, 
seven
 years for furniture and fixtures, 
five
 years for tooling and 
three
 years for computer equipment. Leasehold improvements are depreciated over the lesser of their useful life or the lease term. Maintenance and repair costs are charged to expense as incurred. Major overhauls that extend the useful lives of existing assets are capitalized.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-18-003245:notes:331]
1

[0001437749-18-003245:notes:332]
. Selected Quarterly Financial Data (Unaudited)

[0001437749-18-003245:notes:333]
The quarterly periods for 
201

[0001437749-18-003245:notes:334]
7
 are for the 
13
-weeks ended 
 December 30, 2017,

[0001437749-18-003245:notes:335]
September 30, 2017,

[0001437749-18-003245:notes:336]
July 1, 2017, 
and 
 April 1, 2017, 
respectively. The quarterly periods for 
2016
 are for the 
13
-weeks ended 
 December 31, 2016,

[0001437749-18-003245:notes:337]
October 1, 2016,

[0001437749-18-003245:notes:338]
July 2, 2016, 
and 
 April 2, 2016, 
respectively.

[0001437749-18-003245:notes:339]
| (in thousands, except per share data) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | 4Q(a) |  |  | 3Q(b) |  |  | 2Q(c) |  |  | 1Q(d) |  |  | 4Q(e) |  |  | 3Q(f) |  |  | 2Q(g) |  |  | 1Q(h) |  |
| Net sales |  | $ | 304,849 |  |  | $ | 317,889 |  |  | $ | 313,355 |  |  | $ | 285,441 |  |  | $ | 284,518 |  |  | $ | 280,331 |  |  | $ | 271,912 |  |  | $ | 219,398 |  |
| Gross profit |  |  | 126,624 |  |  |  | 133,651 |  |  |  | 132,608 |  |  |  | 113,650 |  |  |  | 114,337 |  |  |  | 113,759 |  |  |  | 97,866 |  |  |  | 87,155 |  |
| Operating income |  |  | 50,780 |  |  |  | 58,609 |  |  |  | 60,270 |  |  |  | 48,852 |  |  |  | 40,988 |  |  |  | 27,526 |  |  |  | 29,702 |  |  |  | 32,428 |  |
| Net income/(loss) |  |  | (10,819 | ) |  |  | 42,808 |  |  |  | 48,638 |  |  |  | 38,891 |  |  |  | 27,245 |  |  |  | 30,802 |  |  |  | 27,152 |  |  |  | 19,289 |  |
| Net income/(loss per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.48 | ) |  | $ | 1.88 |  |  | $ | 2.13 |  |  | $ | 1.71 |  |  | $ | 1.20 |  |  | $ | 1.36 |  |  | $ | 1.21 |  |  | $ | 0.86 |  |
| Diluted |  | $ | (0.48 | ) |  | $ | 1.87 |  |  | $ | 2.11 |  |  | $ | 1.69 |  |  | $ | 1.19 |  |  | $ | 1.35 |  |  | $ | 1.20 |  |  | $ | 0.85 |  |

[0001437749-18-003245:notes:340]
| (a) | In the fourth quarter of 2017, the Company recorded an estimated one-time tax charge of $49 million for the enactment of the Tax Cuts and Jobs Act for deemed repatriation of unremitted earnings of foreign subsidiaries, $1.4 million in acquisition and integration costs and $0.7 million in restructuring and production costs related to the transfer of Asian operations. |
| (b) | In the third quarter of 2017, the Company recorded $4.8 million in acquisition and integration costs and $1.5 million in restructuring and production costs related to the transfer of Asian operations. |
| (c) | In the second quarter of 2017, the Company recorded $0.3 million in acquisition and integration costs. |
| (d) | In the first quarter of 2017, the Company $1.5 million in acquisition and integration costs |
| (e) | In the fourth quarter of 2016, the Company recorded ($0.1) million gain related to the Company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, $1.2 million of restructuring costs, $3.2 million in acquisition and integration costs and $0.3 million in non-cash inventory charges related to the 2016 acquisitions. |
| (f) | In the third quarter of 2016, the Company recorded $0.9 million of restructuring costs, $5.9 million in acquisition and integration costs, $14.8 million of charges related to the impairment of the Custom Products reporting unit and $0.5 million in non-cash inventory charges as noted above. |
| (g) | In the second quarter of 2016, the Company recorded $0.7 million related to the reed sensor manufacturing transfer as noted above, $0.1 million of restructuring costs, $6.1 million in acquisition and integration costs, $0.3 million in charges related to the closure of the manufacturing facility in Denmark and $6.9 million in non-cash inventory charges as noted above. |
| (h) | In the first quarter of 2016, the Company recorded $1.0 million related to the reed sensor manufacturing transfer as noted above, $0.4 million of restructuring costs, $6.2 million in acquisition and integration costs, and $1.6 million in charges related to the closure of the manufacturing facility in Denmark. |


## us-gaap:ReceivablesPolicyTextBlock

[0001437749-18-003245:notes:341]
Trade Receivables

[0001437749-18-003245:notes:342]
The 
Company performs credit evaluations of customers’ financial condition and generally does 
not
 require collateral. Credit losses are provided for in the financial statements based upon specific knowledge of a customer’s inability to meet its financial obligations to the Company. Historically, credit losses have consistently been within management’s expectations and have 
not
 been a material amount. A receivable is considered past due if payments have 
not
 been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0001437749-18-003245:notes:343]
The 
Company also maintains allowances against accounts receivable for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-18-003245:notes:344]
Revenue Recognition

[0001437749-18-003245:notes:345]
The 
Company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured, and the pricing is fixed and determinable.

[0001437749-18-003245:notes:346]
At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do 
not
 transfer until the product has been received by the customer, the 
Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The Company’s distribution channels are primarily through direct sales and independent 
third
-party distributors.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001437749-18-003245:notes:347]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments (a) |  |  | Gain (Loss) on investments |  |  | Foreign currency translation adjustments |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 27, 2014 |  | $ | (29,615 | ) |  | $ | 10,791 |  |  | $ | (2,302 | ) |  | $ | (21,126 | ) |
| 2015 activity |  |  | 20,893 |  |  |  | 793 |  |  |  | (46,231 | ) |  |  | (24,545 | ) |
| Balance at January 2, 2016 |  |  | (8,722 | ) |  |  | 11,584 |  |  |  | (48,533 | ) |  |  | (45,671 | ) |
| 2016 activity |  |  | (3,261 | ) |  |  | (815 | ) |  |  | (24,832 | ) |  |  | (28,908 | ) |
| Balance at December 31, 2016 |  |  | (11,983 | ) |  |  | 10,769 |  |  |  | (73,365 | ) |  |  | (74,579 | ) |
| 2017 activity |  |  | 1,147 |  |  |  | (974 | ) |  |  | 10,738 |  |  |  | 10,911 |  |
| Balance at December 30, 2017 |  | $ | (10,836 | ) |  | $ | 9,795 |  |  | $ | (62,627 | ) |  | $ | (63,668 | ) |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-18-003245:notes:348]
| (in thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 383,025 |  |  | $ | 356,674 |  |  | $ | 344,305 |  |
| China |  |  | 321,111 |  |  |  | 263,701 |  |  |  | 193,792 |  |
| Other countries |  |  | 517,398 |  |  |  | 435,784 |  |  |  | 329,767 |  |
| Total net sales |  | $ | 1,221,534 |  |  | $ | 1,056,159 |  |  | $ | 867,864 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 23,490 |  |  | $ | 23,731 |  |  | $ | 23,965 |  |
| China |  |  | 86,310 |  |  |  | 65,345 |  |  |  | 37,241 |  |
| Mexico |  |  | 62,510 |  |  |  | 52,262 |  |  |  | 47,130 |  |
| Philippines |  |  | 31,129 |  |  |  | 33,345 |  |  |  | 33,525 |  |
| Other countries |  |  | 47,138 |  |  |  | 42,492 |  |  |  | 20,707 |  |
| Total long-lived assets |  | $ | 250,577 |  |  | $ | 217,175 |  |  | $ | 162,568 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 3,518 |  |  | $ | 4,694 |  |  | $ | 8,609 |  |
| China |  |  | 32,775 |  |  |  | 13,181 |  |  |  | 9,710 |  |
| Mexico |  |  | 19,395 |  |  |  | 15,667 |  |  |  | 9,193 |  |
| Philippines |  |  | 2,979 |  |  |  | 5,096 |  |  |  | 12,620 |  |
| Other countries |  |  | 7,258 |  |  |  | 7,590 |  |  |  | 3,887 |  |
| Total additions to long-lived assets |  | $ | 65,925 |  |  | $ | 46,228 |  |  | $ | 44,019 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001437749-18-003245:notes:349]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
| Nonvested December 31, 2016 |  |  | 207,330 |  |  | $ | 106.92 |  |
| Granted |  |  | 95,621 |  |  |  | 151.91 |  |
| Vested |  |  | (95,520 | ) |  |  | 102.49 |  |
| Forfeited |  |  | (7,738 | ) |  |  | 111.56 |  |
| Nonvested December 30, 2017 |  |  | 199,693 |  |  |  | 130.40 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-18-003245:notes:350]
| (in thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 661,928 |  |  | $ | 535,191 |  |  | $ | 405,497 |  |
| Automotive |  |  | 453,227 |  |  |  | 415,200 |  |  |  | 339,957 |  |
| Industrial |  |  | 106,379 |  |  |  | 105,768 |  |  |  | 122,410 |  |
| Total net sales |  | $ | 1,221,534 |  |  | $ | 1,056,159 |  |  | $ | 867,864 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 35,215 |  |  | $ | 29,141 |  |  | $ | 22,936 |  |
| Automotive |  |  | 22,459 |  |  |  | 18,107 |  |  |  | 13,437 |  |
| Industrial |  |  | 5,337 |  |  |  | 5,889 |  |  |  | 5,268 |  |
| Total depreciation and amortization |  | $ | 63,011 |  |  | $ | 53,137 |  |  | $ | 41,641 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 155,880 |  |  | $ | 117,088 |  |  | $ | 78,194 |  |
| Automotive |  |  | 62,571 |  |  |  | 59,905 |  |  |  | 53,086 |  |
| Industrial |  |  | 10,334 |  |  |  | 3,615 |  |  |  | 18,094 |  |
| Other(a) |  |  | (10,274 | ) |  |  | (49,964 | ) |  |  | (45,217 | ) |
| Total operating income |  |  | 218,511 |  |  |  | 130,644 |  |  |  | 104,157 |  |
| Interest expense |  |  | 13,380 |  |  |  | 8,628 |  |  |  | 4,091 |  |
| Foreign exchange loss (gain) |  |  | 2,376 |  |  |  | 472 |  |  |  | (1,465 | ) |
| Other (income) expense, net |  |  | (1,282 | ) |  |  | (1,730 | ) |  |  | (5,417 | ) |
| Income before income taxes |  | $ | 204,037 |  |  | $ | 123,274 |  |  | $ | 106,948 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001437749-18-003245:notes:351]
|  |  | Shares Under Option |  |  | Weighted Average Price |  |  | Weighted Average Remaining Contract Life (Years) |  |  | Aggregate Intrinsic Value (000’s) |  |
| Outstanding December 31, 2016 |  |  | 356,184 |  |  | $ | 98.65 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 76,082 |  |  |  | 154.15 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (27,965 | ) |  |  | 84.93 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | — |  |  | NA |  |  |  |  |  |  |  |  |  |
| Outstanding December 30, 2017 |  |  | 404,301 |  |  |  | 110.04 |  |  |  | 4.5 |  |  | $ | 35,488 |  |
| Exercisable December 30, 2017 |  |  | 203,745 |  |  |  | 92.36 |  |  |  | 3.6 |  |  |  | 21,486 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001437749-18-003245:notes:352]
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Weighted average fair value of options granted |  |  | $30.77 |  |  |  | $26.06 |  |  |  | $21.99 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 1.79% |  |  |  | 1.37% |  |  |  | 1.25% |  |
| Expected dividend yield |  |  | 0.86% |  |  |  | 0.97% |  |  |  | 1.04% |  |
| Expected stock price volatility |  |  | 23.0% |  |  |  | 26.0% |  |  |  | 28.0% |  |
| Expected life of options (years) |  |  | 4.4 |  |  |  | 4.6 |  |  |  | 4.6 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-18-003245:notes:353]
SCHEDULE II

[0001437749-18-003245:notes:354]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001437749-18-003245:notes:355]
| Description |  | Balance at Beginning of Year |  |  | Charged to Costs and Expenses (a) |  |  | Deductions (b) |  |  | Other (c) |  |  | Balance at End of Year |  |
| (in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year ended December 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 2,079 |  |  | $ | 3,068 |  |  | $ | (4,070 | ) |  | $ | 95 |  |  | $ | 1,172 |  |
| Reserves for sales discounts and allowances |  | $ | 23,825 |  |  | $ | 106,781 |  |  | $ | (104,941 | ) |  | $ | 679 |  |  | $ | 26,344 |  |
| Deferred tax valuation allowance |  | $ | 6,738 |  |  | $ | — |  |  | $ | — |  |  | $ | (535 | ) |  | $ | 6,203 |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 319 |  |  | $ | 1,769 |  |  | $ | (42 | ) |  | $ | 33 |  |  | $ | 2,079 |  |
| Reserves for sales discounts and allowances |  | $ | 17,168 |  |  | $ | 91,632 |  |  | $ | (90,837 | ) |  | $ | 5,862 |  |  | $ | 23,825 |  |
| Deferred tax valuation allowance |  | $ | 4,557 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,181 |  |  | $ | 6,738 |  |
| Year ended January 2, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 278 |  |  | $ | 164 |  |  | $ | 150 |  |  | $ | 27 |  |  | $ | 319 |  |
| Reserves for sales discounts and allowances |  | $ | 19,140 |  |  | $ | 81,335 |  |  | $ | 82,997 |  |  | $ | (310 | ) |  | $ | 17,168 |  |
| Deferred tax valuation allowance |  | $ | 4,557 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,557 |  |

[0001437749-18-003245:notes:356]
|  | (a) | Includes provision for doubtful accounts, sales returns and sales discounts granted to customers. |

[0001437749-18-003245:notes:357]
|  | (b) | Represents uncollectible accounts written off, net of recoveries and credits issued to customers and the write-off of certain deferred tax assets that previously had full valuation allowances. |

[0001437749-18-003245:notes:358]
|  | (c) | Represents business acquisitions, U.S. and non-U.S. subsidiary tax attributes and foreign currency translation adjustments. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-18-003245:notes:359]
12

[0001437749-18-003245:notes:360]
. Segment Information

[0001437749-18-003245:notes:361]
The 
Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it 
 may 
earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”).  The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does 
not
 evaluate the operating segments using discrete balance sheet information.

[0001437749-18-003245:notes:362]
Sales, marketing
, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the 
three
 operating segments.  The Company does 
not
 report inter-segment revenue because the operating segments do 
not
 record it.  Certain expenses, determined by the CODM to be strategic in nature and 
not
 directly related to segments current results, are 
not
 allocated but identified as “Other”.  Additionally, the Company does 
not
 allocate interest and other income, interest expense, or taxes to operating segments.  These costs are 
not
 allocated to the segments, as management excludes such costs when assessing the performance of the segments.  Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in 
one
 segment 
 may 
benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001437749-18-003245:notes:363]
|  | ● | Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, gas discharge tubes; semiconductor and power semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon carbide, metal-oxide-semiconductor field-effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including consumer electronics, automotive electronics, IT and telecommunications equipment, medical devices, lighting products, and white goods. |

[0001437749-18-003245:notes:364]
|  | ● | Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in the automotive, commercial vehicle, and agricultural and construction equipment industries. Passenger car fuse products include fuses and fuse accessories, including blade fuses, battery cable protectors, varistors, high-current fuses, and high-voltage fuses for hybrid and electric vehicles. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle sensors designed to monitor the passenger compartment occupants and environment as well as the vehicle’s powertrain, emissions, speed and suspension. |

[0001437749-18-003245:notes:365]
|  | ● | Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in heavy industrial applications such as mining, oil and gas, energy storage, construction, HVAC systems, elevator and other industrial equipment. |

[0001437749-18-003245:notes:366]
The 
Company has provided this segment information for all comparable prior periods.

[0001437749-18-003245:notes:367]
Segment information is summarized as follows:

[0001437749-18-003245:notes:368]
(a) 
Included in “Other” Operating income (loss) for 
2017
 are costs related to the acquisition and integration costs associated with the Company’s completed and pending acquisitions (
$8.0
 million in 
Cost of sales
 (“COS”) and 
Selling, general, and administrative expenses 
(“SG&A”) and charges related to restructuring and production transfers in the Company’s Asia operations (
$2.2
 million in SG&A).

[0001437749-18-003245:notes:369]
Included in “Other” Operating income (loss) for 
2016
 are costs related to the impairment of the 
Custom Products reporting unit (
$14.8
 million), acquisition and integration costs associated with the Company’s 
2016
 acquisitions (
$29.2
 million in COS and SG&A), transfer of the Company’s reed switch manufacturing operations from its Lake Mills, Wisconsin and Suzhou, China locations to the Philippines (
$1.6
 million in COS), impairment and severance costs related to the closure of the Company’s manufacturing facility in Denmark (
$1.9
 million in SG&A), and restructuring costs (
$2.5
 million in SG&A and 
Research and development expenses
).

[0001437749-18-003245:notes:370]
Included in “Other” Operating income (loss) for 
2015
 are costs related to the transfer of the 
Company’s reed switch manufacturing operations from its Lake Mills, Wisconsin and Suzhou, China locations to the Philippines (
$5.2
 million in COS), acquisition related fees (
$4.6
 million included in SG&A), pension settlement and other costs (
$31.9
 million in SG&A), and restructuring costs (
$3.6
 million in SG&A).

[0001437749-18-003245:notes:371]
The 
Company’s significant net sales, long-lived assets and additions to long-lived assets by country for the fiscal years ended 
2017,

[0001437749-18-003245:notes:372]
For the year ended

[0001437749-18-003245:notes:373]
December 30, 2017, 
approximately 
69%
 of the Company’s net sales were to customers outside the United States (exports and foreign operations) including 
26%
 to China (including Hong Kong). Sales to Arrow Electronics, Inc., which were included in the Electronics, Automotive, and Industrial segments, were 
10.6%
 of consolidated net sales in 
2017
 but less than 
10%
 for 
2016
 and 
2015.

[0001437749-18-003245:notes:374]
No
 other single customer accounted for more than 
10%
 of net sales during the last 
three
 years.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001437749-18-003245:notes:375]
Shipping and Handling Fees and Costs

[0001437749-18-003245:notes:376]
Amounts billed to customers related to shipping and handling is classified as revenue. Costs incurred for shipping and handling of

[0001437749-18-003245:notes:377]
$10.9
 million 
$9.1
 million, and 
$7.0
 million in 
2017,

[0001437749-18-003245:notes:378]
2016,
 and 
2015,
 respectively, are classified in selling, general, and administrative expenses.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-18-003245:notes:379]
1.
 Summary of Significant Accounting Policies and Other Information

[0001437749-18-003245:notes:380]
Nature of Operations

[0001437749-18-003245:notes:381]
Littelfuse, Inc. and subsidiaries (the “
Company”) is a global leader in circuit protection products with advancing platforms in power control and sensor technologies, serving customers in the electronics, automotive, and industrial markets. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy, ranging across consumer electronics, IT and telecommunication applications, industrial electronics, automobiles and other transportation, and heavy industrial applications. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance.

[0001437749-18-003245:notes:382]
Fiscal Year

[0001437749-18-003245:notes:383]
References herein to 
“201

[0001437749-18-003245:notes:384]
7”,
 “fiscal 
2017”
 or “fiscal year 
2017”
 refer to the fiscal year ended 
 December 30, 2017. 
References herein to 
“2016”,
 “fiscal 
2016”
 or “fiscal year 
2016”
 refer to the fiscal year ended 
 December 31, 2016. 
References herein to 
“2015”,
 “fiscal 
2015”
 or “fiscal year 
2015”
 refer to the fiscal year ended 
 January 2, 2016. 
The Company operates on a 
52
-
53
 week fiscal year (
4
-
4
-
5
 basis) ending on the Saturday closest to 
 December 31. 
Therefore, the financial results of certain fiscal years and the associated 
14
 week quarters will 
not
 be exactly comparable to the prior and subsequent 
52
 week fiscal years and the associated quarters having only 
13
 weeks. As a result of using this convention, each of fiscal 
2017
 and fiscal 
2016
 contained 
52
 weeks whereas fiscal 
2015
 contained 
53
 weeks.

[0001437749-18-003245:notes:385]
Use of Estimates

[0001437749-18-003245:notes:386]
The process of preparing financial statements in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The 
Company evaluates and updates its assumptions and estimates on an ongoing basis and 
 may 
employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0001437749-18-003245:notes:387]
Goodwill

[0001437749-18-003245:notes:388]
The 
Company annually tests goodwill for impairment on the 
first
 day of its fiscal 
fourth
 quarter, or more frequently if an event occurs or circumstances change that would more likely than 
not
 reduce the fair value of a reporting unit below its carrying value.

[0001437749-18-003245:notes:389]
The Company compares each reporting unit
’s fair value, estimated based on comparable company market valuations and expected future discounted cash flows to be generated by the reporting unit, to its carrying value. For the 
seven
 reporting units with goodwill, the Company compared the estimated fair value of each reporting unit to its carrying value. The results of the goodwill impairment test as of 
 October 1, 2017 
indicated that the estimated fair values for each of the 
seven
 reporting units exceeded their respective carrying values. As of the most recent annual test conducted on 
 October 1, 2017, 
the Company noted that the excess of fair value over the carrying value, was 
161%,

[0001437749-18-003245:notes:390]
314%,

[0001437749-18-003245:notes:391]
247%,

[0001437749-18-003245:notes:392]
218%,

[0001437749-18-003245:notes:393]
100%,

[0001437749-18-003245:notes:394]
25%,
 and 
248%
 for its reporting units; Electronics (non-silicon), Electronics (silicon), Passenger Car, Commercial Vehicle Products, Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would 
not
 have resulted in any reporting units failing the goodwill impairment test. See Note 
4,

[0001437749-18-003245:notes:395]
and Other Intangible Assets,
 for additional information.

[0001437749-18-003245:notes:396]
The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit
’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments as of 
 December 30, 2017, 
management concluded that 
no
 events or changes in circumstances indicated that it was more likely than 
not
 that the fair value for any reporting unit had declined below its carrying value.

[0001437749-18-003245:notes:397]
Long-Lived Assets

[0001437749-18-003245:notes:398]
Customer relationships, t
rademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of 
five
 to 
20
 years. Patents, licenses and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of 
five
 to 
17
 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of 
three
 to 
20
 years.

[0001437749-18-003245:notes:399]
The Company assesses potential impairments to its long-lived assets if events or changes in circumstances indicate that the carrying amount of an asset 
 may

[0001437749-18-003245:notes:400]
not
 be recoverable. An impaired asset is written down to its estimated fair value based upon the most recent information available. Estimated fair market value is generally measured by discounting estimated future cash flows. Long-lived assets, other than goodwill and other intangible assets, that are held for sale are recorded at the lower of carrying value or the fair market value less the estimated cost to sell.

[0001437749-18-003245:notes:401]
During the year ended 
 December 31, 2016, 
the Company recognized non-cash impairment charges totaling 
$6.0
 million, of which 
$2.2
 million related to the impairment of certain customer relationship intangible assets in the customs reporting unit within the Industrial segment and 
$3.8
 million related to the impairment of the 
Custom Products tradename. The impairment of the customer relationship intangible assets resulted from lower expectations of future revenue to be derived from those relationships while the tradename impairment resulted from lower expectations of future cash flows of the customs reporting unit.

[0001437749-18-003245:notes:402]
Environmental Liabilities

[0001437749-18-003245:notes:403]
Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the 
Company’s recorded liability for such claims, the Company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0001437749-18-003245:notes:404]
Pension and Other Post-retirement Benefits

[0001437749-18-003245:notes:405]
The Company records annual income and expense amounts relating to its pension and post-retirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets, but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors.

[0001437749-18-003245:notes:406]
Returns and Credits

[0001437749-18-003245:notes:407]
Some of the terms of the 
Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-18-003245:notes:408]
Volume Rebates

[0001437749-18-003245:notes:409]
The 
Company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The Company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-18-003245:notes:410]
Allowance for Doubtful Accounts

[0001437749-18-003245:notes:411]
The 
Company evaluates the collectability of its trade receivables based on a combination of factors. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a specific customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Accounts receivable balances that are deemed to be uncollectible, are written off against the reserve on a case-by-case basis. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted. However, due to the Company’s diverse customer base and lack of credit concentration, the Company does 
not
 believe its estimates would be materially impacted by changes in its assumptions.

[0001437749-18-003245:notes:412]
Stock-based Compensation

[0001437749-18-003245:notes:413]
The 
Company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as operating cash flows. See Note 
9,

[0001437749-18-003245:notes:414]
Shareholders’ Equity
, for additional information on stock-based compensation.

[0001437749-18-003245:notes:415]
Reclassifications

[0001437749-18-003245:notes:416]
Certain reclassifications of prior year amounts for

[0001437749-18-003245:notes:417]
Trade receivables, net
 and 
Prepaid expenses and other current assets
 were made to conform to the 
2017
 presentation.

[0001437749-18-003245:notes:418]
Recently

[0001437749-18-003245:notes:419]
Adopted

[0001437749-18-003245:notes:420]
Accounting Standards

[0001437749-18-003245:notes:421]
In 
 July 2015, 
the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 
No.

[0001437749-18-003245:notes:422]
2015
-
11

[0001437749-18-003245:notes:423]
– “Inventory (Topic 
330
): Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
The adoption of the update did 
not
 have a material impact on the Company’s consolidated financial position and results of operations. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

[0001437749-18-003245:notes:424]
In 
 January 2017, 
the FASB issued ASU 
No.

[0001437749-18-003245:notes:425]
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350
). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity 
no
 longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December 15, 2020, 
with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January 1, 2017. 
The 
ASU did 
not
 impact the Company in 
2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-18-003245:notes:426]
9

[0001437749-18-003245:notes:427]
. Shareholders’ Equity

[0001437749-18-003245:notes:428]
Equity Plans

[0001437749-18-003245:notes:429]
: The Company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, performance shares and other stock rights to employees and directors. As of 
 December 30, 2017, 
there were 
1.3
 million shares available for issuance of future awards under the Company’s equity-based compensation plans.

[0001437749-18-003245:notes:430]
Stock options vest over a three, 
four
 or 
five
-year period and are exercisable over either a 
seven
 or 
ten
-year period commencing from the date of the grant. Restricted shares and share units granted by the 
Company generally vest over 
three
 to 
four
 years.

[0001437749-18-003245:notes:431]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended 
 December 3

[0001437749-18-003245:notes:432]
2017.

[0001437749-18-003245:notes:433]
The following table provides a reconciliation of non-vested restricted share and share unit awards for the fiscal year ended 
 December 3

[0001437749-18-003245:notes:434]
The total intrinsic value of options exercised during 
201

[0001437749-18-003245:notes:435]
7,

[0001437749-18-003245:notes:436]
2016,
 and 
2015
 was 
$2.2
 million, 
$13.3
 million, and 
$5.0
 million, respectively. The total fair value of shares vested was 
$15.0
 million, 
$10.7
 million, and 
$8.1
 million for 
2017,

[0001437749-18-003245:notes:437]
2016,
 and 
2015,
 respectively. The total amount of share-based liabilities paid was 
$0.9
 million, 
$0.6
 million and 
$0.4
 million for 
2017,

[0001437749-18-003245:notes:438]
The 
Company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At 
 December 30, 2017, 
the unrecognized compensation cost for options, restricted shares and performance shares was 
$15.9
 million before tax, and will be recognized over a weighted-average period of 
1.9
 years. Compensation cost included as a component of selling, general, and administrative expense for all equity compensation plans discussed above was 
$17.3
 million, 
$12.8
 million, and 
$10.7
 million for 
2017,

[0001437749-18-003245:notes:439]
2016,
 and 
2015

[0001437749-18-003245:notes:440]
, respectively. The total income tax benefit recognized in the Consolidated Statements of Net Income was 
$6.0
 million, 
$4.4
 million and 
$3.7
 million for 
2017,

[0001437749-18-003245:notes:441]
, respectively.

[0001437749-18-003245:notes:442]
The 
Company uses the Black-Scholes option valuation model to determine the fair value of awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0001437749-18-003245:notes:443]
Expected volatilities are based on the historical volatility of the 
Company’s stock price. The expected life of options is based on historical data for options granted by the Company. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption.

[0001437749-18-003245:notes:444]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)

[0001437749-18-003245:notes:445]
The following table sets forth the changes in the components of AOCI by component for fiscal years 
2017,

[0001437749-18-003245:notes:446]
2016,
 and 
2015:

[0001437749-18-003245:notes:447]
(a) Net of tax of $

[0001437749-18-003245:notes:448]
1.4
 million, 
$1.1
 million, and 
$0.7
 million 
at 
 December 30, 2017;

[0001437749-18-003245:notes:449]
December 31, 2016; 
and 
 January 2, 2016, 
respectively.

[0001437749-18-003245:notes:450]
Preferred Stock

[0001437749-18-003245:notes:451]
: The Board of Directors 
 may 
authorize the issuance of preferred stock from time to time in 
one
 or more series with such designations, preferences, qualifications, limitations, restrictions, and optional or other special rights as the Board 
 may 
fix by resolution.

[0001437749-18-003245:notes:452]
The 
Company’s Board of Directors authorized the repurchase of up to 
1,000,000
 shares of the Company’s common stock under a program for the period 
 May 1, 2017 
to 
 April 30, 2018. 
The Company did 
not
 repurchase any shares of its common stock during fiscal 
2017
 under the stock repurchase program.
