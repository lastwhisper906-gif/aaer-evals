# LFUS 8-K — 0001437749-18-001357 filed 2018-01-31

## item codes, every 8-K on or before 2018-02-23

- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2018-02-23

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-001357:8k_2_02:1]
EX-99.1
2
ex_103941.htm
EXHIBIT 99.1

[0001437749-18-001357:8k_2_02:2]
ex_103941.htm

[0001437749-18-001357:8k_2_02:3]
Exhibit 99.1

[0001437749-18-001357:8k_2_02:4]
NEWS RELEASE

[0001437749-18-001357:8k_2_02:5]
LITTELFUSE REPORTS FOURTH QUARTER and FULL YEAR RESULTS

[0001437749-18-001357:8k_2_02:6]
Company delivers record sales, adjusted earnings per share and cash flow for 2017

[0001437749-18-001357:8k_2_02:7]
CHICAGO, January 31, 2018 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the fourth quarter and full year ended December 30, 2017:

[0001437749-18-001357:8k_2_02:8]
Fourth Quarter 2017 Highlights

[0001437749-18-001357:8k_2_02:9]
| ● | Net sales were $304.8 million, up 7% versus the prior year period. Organic revenue growth was 4%, excluding revenue from acquisitions closed in the past 12 months, divestitures and foreign currency effects. |

[0001437749-18-001357:8k_2_02:10]
| ● | Growth by segment versus the prior year period: |

[0001437749-18-001357:8k_2_02:11]
|  | o | Electronics sales increased 4% (up 1% organically) |

[0001437749-18-001357:8k_2_02:12]
|  | o | Automotive sales increased 9% (up 6% organically) |

[0001437749-18-001357:8k_2_02:13]
|  | o | Industrial sales increased 19% (up 21% organically) |

[0001437749-18-001357:8k_2_02:14]
| ● | GAAP diluted loss per share was ($0.48); This includes $52.5 million of charges primarily due to an estimated one-time tax charge of $49 million for the enactment of the Tax Cuts and Jobs Act for deemed repatriation of unremitted earnings of foreign subsidiaries, and charges related to the acquisition of IXYS Corporation |

[0001437749-18-001357:8k_2_02:15]
| ● | Adjusted diluted EPS of $1.81 increased 15% over last year |

[0001437749-18-001357:8k_2_02:16]
| ● | GAAP effective tax rate was 124.7%, including the impact of the estimated one-time tax charge noted above; Adjusted effective tax rate was 16.2% |

[0001437749-18-001357:8k_2_02:17]
| ● | The electronics segment book-to-bill ratio for the fourth quarter was 1.11 |

[0001437749-18-001357:8k_2_02:18]
| ● | During January, the company completed a private placement of $175 million of senior notes |

[0001437749-18-001357:8k_2_02:19]
| ● | On January 17th, the company completed its acquisition of IXYS Corporation |

[0001437749-18-001357:8k_2_02:20]
Full Year 2017 Highlights

[0001437749-18-001357:8k_2_02:21]
| ● | Net sales were $1.222 billion, up 16% versus the prior year period, and 7% organically |

[0001437749-18-001357:8k_2_02:22]
| ● | GAAP diluted EPS was $5.21, which includes the estimated one-time $49 million tax charge noted above; Adjusted diluted EPS of $7.74 increased 24% over last year |

[0001437749-18-001357:8k_2_02:23]
-more-

[0001437749-18-001357:8k_2_02:24]
| ● | GAAP effective tax rate was 41.4% and adjusted effective tax rate was 18.1% |

[0001437749-18-001357:8k_2_02:25]
| ● | Cash flow from operations was $269 million and free cash flow was $203 million, both records for the company |

[0001437749-18-001357:8k_2_02:26]
"The fourth quarter capped off a tremendous year for us, as we finished 2017 with record sales, earnings and cash flow,” said Dave Heinzmann, Littelfuse Chief Executive Officer. “While our 2017 organic sales growth of 7% was led by strength across our Electronics segment, all of our businesses had a strong finish for the year. We delivered 160 basis points in full year adjusted operating margin expansion, which included returning our industrial segment back to double digit operating margin profitability. We made significant progress in our strategy with two acquisitions that will add more than $350 million in annualized revenue, while expanding our sensor and power control portfolios.”

[0001437749-18-001357:8k_2_02:27]
First Quarter 2018 Outlook

[0001437749-18-001357:8k_2_02:28]
All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, foreign exchange adjustments and unusual gains and losses. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-18-001357:8k_2_02:29]
"We enter 2018 with good momentum, a track record of strong operational performance and a diversified portfolio that capitalizes on the key trends of a safe, green and connected world," continued Heinzmann. “We’re well positioned to deliver on our strategy, which we expect will drive double digit revenue and earnings growth”.

[0001437749-18-001357:8k_2_02:30]
The outlook includes IXYS results, with the first quarter including approximately two and a half months of IXYS financial results.

[0001437749-18-001357:8k_2_02:31]
For the first quarter of 2018:

[0001437749-18-001357:8k_2_02:32]
| ● | Net sales are expected to be in the range of $384 to $396 million, up 37% on an as reported basis and up 6% organically, at the midpoint versus the prior year quarter |

[0001437749-18-001357:8k_2_02:33]
| ● | Adjusted diluted earnings per share are expected to be in the range of $1.73 to $1.87 |

[0001437749-18-001357:8k_2_02:34]
| ● | Adjusted effective tax rate is expected to be in the range of 22.5% to 23.5% |

[0001437749-18-001357:8k_2_02:35]
For the 2018 full year:

[0001437749-18-001357:8k_2_02:36]
| ● | Adjusted effective tax rate is expected to be in the range of 18% – 21% |

[0001437749-18-001357:8k_2_02:37]
-more-

[0001437749-18-001357:8k_2_02:38]
| ● | Capital expenditures are expected to be in the range of $80 - $85 million, including expenditures for IXYS’ operations. |

[0001437749-18-001357:8k_2_02:39]
Dividend

[0001437749-18-001357:8k_2_02:40]
The company will pay a cash dividend on its common stock of $0.37 per share on March 8, 2018 to shareholders of record as of February 22, 2018.

[0001437749-18-001357:8k_2_02:41]
Conference Call and Webcast Information

[0001437749-18-001357:8k_2_02:42]
Littelfuse will host a conference call today, Wednesday, January 31, 2018, at 9:00 a.m. Central / 10:00 a.m. Eastern time to discuss the results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. The call will be available for replay on the company’s website.

[0001437749-18-001357:8k_2_02:43]
About Littelfuse

[0001437749-18-001357:8k_2_02:44]
Founded in 1927, Littelfuse is the global leader in circuit protection with advancing platforms in power control and sensor technologies. The company serves customers in the electronics, automotive and industrial markets with products that include fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has more than 11,000 employees in more than 50 locations worldwide. For more information, please visit Littelfuse.com.

[0001437749-18-001357:8k_2_02:45]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; the integration of the recently acquired business of IXYS Corporation ("IXYS") and the risk that expected benefits, synergies and growth prospects of the acquisition of IXYS may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 31, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-18-001357:8k_2_02:46]
Non-GAAP Financial Measures

[0001437749-18-001357:8k_2_02:47]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted

[0001437749-18-001357:8k_2_02:48]
-more-

[0001437749-18-001357:8k_2_02:49]
EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0001437749-18-001357:8k_2_02:50]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-18-001357:8k_2_02:51]
CONTACT: Meenal Sethna

[0001437749-18-001357:8k_2_02:52]
Executive Vice President and CFO

[0001437749-18-001357:8k_2_02:53]
(773) 628-0616

[0001437749-18-001357:8k_2_02:54]
###

[0001437749-18-001357:8k_2_02:55]
| LITTELFUSE, INC. |
| Net Sales and Operating Income by Segment |
| (In thousands of USD, unaudited) |

[0001437749-18-001357:8k_2_02:56]
|  |  | Fourth Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 162,875 |  |  | $ | 156,495 |  |  |  | 4% |  |  | $ | 661,928 |  |  | $ | 535,191 |  |  |  | 24% |  |
| Automotive |  |  | 115,134 |  |  |  | 105,556 |  |  |  | 9% |  |  |  | 453,227 |  |  |  | 415,200 |  |  |  | 9% |  |
| Industrial |  |  | 26,840 |  |  |  | 22,467 |  |  |  | 19% |  |  |  | 106,379 |  |  |  | 105,768 |  |  |  | 1% |  |
| Total net sales |  | $ | 304,849 |  |  | $ | 284,518 |  |  |  | 7% |  |  | $ | 1,221,534 |  |  | $ | 1,056,159 |  |  |  | 16% |  |

[0001437749-18-001357:8k_2_02:57]
|  |  | Fourth Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 33,362 |  |  | $ | 34,842 |  |  |  | (4%) |  |  | $ | 155,880 |  |  | $ | 117,088 |  |  |  | 33% |  |
| Automotive |  |  | 14,972 |  |  |  | 10,908 |  |  |  | 37% |  |  |  | 62,571 |  |  |  | 59,905 |  |  |  | 4% |  |
| Industrial |  |  | 4,565 |  |  |  | (143 | ) |  |  | 3,292% |  |  |  | 10,334 |  |  |  | 3,615 |  |  |  | 186% |  |
| Other (1) |  |  | (2,119 | ) |  |  | (4,619 | ) |  |  | 54% |  |  |  | (10,274 | ) |  |  | (49,964 | ) |  |  | 79% |  |
| Total operating income |  | $ | 50,780 |  |  | $ | 40,988 |  |  |  | 24% |  |  | $ | 218,511 |  |  | $ | 130,644 |  |  |  | 67% |  |
| Operating margin |  |  | 16.7 | % |  |  | 14.4 | % |  |  |  |  |  |  | 17.9 | % |  |  | 12.4 | % |  |  |  |  |
| Interest expense |  |  | 3,512 |  |  |  | 2,342 |  |  |  |  |  |  |  | 13,380 |  |  |  | 8,628 |  |  |  |  |  |
| Foreign exchange loss |  |  | 3,859 |  |  |  | 7,586 |  |  |  |  |  |  |  | 2,376 |  |  |  | 472 |  |  |  |  |  |
| Other income, net |  |  | (320 | ) |  |  | (690 | ) |  |  |  |  |  |  | (1,282 | ) |  |  | (1,730 | ) |  |  |  |  |
| Income before taxes |  | $ | 43,729 |  |  | $ | 31,750 |  |  |  | 38% |  |  | $ | 204,037 |  |  | $ | 123,274 |  |  |  | 66% |  |

[0001437749-18-001357:8k_2_02:58]
| (1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details.) |

[0001437749-18-001357:8k_2_02:59]
|  |  | Fourth Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | Growth / (Decline) |  |
| Operating Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  |  | 20.5 | % |  |  | 22.3 | % |  |  | (1.8 | %) |  |  | 23.5 | % |  |  | 21.9 | % |  |  | 1.6 | % |
| Automotive |  |  | 13.0 | % |  |  | 10.3 | % |  |  | 2.7 | % |  |  | 13.8 | % |  |  | 14.4 | % |  |  | (0.6 | %) |
| Industrial |  |  | 17.0 | % |  |  | (0.6 | %) |  |  | 17.6 | % |  |  | 9.7 | % |  |  | 3.4 | % |  |  | 6.3 | % |

[0001437749-18-001357:8k_2_02:60]
-more-

[0001437749-18-001357:8k_2_02:61]
| LITTELFUSE, INC. |
| Condensed Consolidated Balance Sheets |
| (In thousands of USD) |

[0001437749-18-001357:8k_2_02:62]
|  |  | December 30, 2017 |  |  | December 31, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 429,676 |  |  | $ | 275,124 |  |
| Short-term investments |  |  | 35 |  |  |  | 3,690 |  |
| Accounts receivable, less allowances |  |  | 182,699 |  |  |  | 176,032 |  |
| Inventories |  |  | 140,789 |  |  |  | 114,063 |  |
| Prepaid income taxes and income taxes receivable |  |  | 1,689 |  |  |  | 11,671 |  |
| Prepaid expenses and other current assets |  |  | 37,452 |  |  |  | 31,501 |  |
| Total current assets |  |  | 792,340 |  |  |  | 612,081 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 9,547 |  |  |  | 9,268 |  |
| Buildings |  |  | 86,599 |  |  |  | 80,553 |  |
| Equipment |  |  | 505,838 |  |  |  | 439,542 |  |
|  |  |  | 601,984 |  |  |  | 529,363 |  |
| Accumulated depreciation |  |  | (351,407 | ) |  |  | (312,188 | ) |
| Net property, plant and equipment |  |  | 250,577 |  |  |  | 217,175 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 81,911 |  |  |  | 83,607 |  |
| Distribution network |  |  | 19,505 |  |  |  | 18,995 |  |
| Customer lists, trademarks and tradenames |  |  | 102,434 |  |  |  | 110,425 |  |
| Goodwill |  |  | 453,414 |  |  |  | 403,544 |  |
|  |  |  | 657,264 |  |  |  | 616,571 |  |
| Investments |  |  | 10,993 |  |  |  | 13,933 |  |
| Deferred income taxes |  |  | 11,858 |  |  |  | 20,585 |  |
| Other assets |  |  | 17,070 |  |  |  | 10,849 |  |
| Total assets |  | $ | 1,740,102 |  |  | $ | 1,491,194 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 101,844 |  |  | $ | 90,712 |  |
| Accrued payroll |  |  | 49,962 |  |  |  | 42,810 |  |
| Accrued expenses |  |  | 48,994 |  |  |  | 36,138 |  |
| Accrued severance |  |  | 1,459 |  |  |  | 2,785 |  |
| Accrued income taxes |  |  | 16,285 |  |  |  | 8,846 |  |
| Current portion of long-term debt |  |  | 6,250 |  |  |  | 6,250 |  |
| Total current liabilities |  |  | 224,794 |  |  |  | 187,541 |  |
| Long-term debt, less current portion |  |  | 489,361 |  |  |  | 447,892 |  |
| Deferred income taxes |  |  | 17,069 |  |  |  | 7,066 |  |
| Accrued post-retirement benefits |  |  | 18,742 |  |  |  | 13,398 |  |
| Other long-term liabilities |  |  | 62,580 |  |  |  | 20,366 |  |
| Total equity |  |  | 927,556 |  |  |  | 814,931 |  |
| Total liabilities and equity |  | $ | 1,740,102 |  |  | $ | 1,491,194 |  |

[0001437749-18-001357:8k_2_02:63]
-more-

[0001437749-18-001357:8k_2_02:64]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Comprehensive Income |
| (In thousands of USD, except per share data, unaudited) |

[0001437749-18-001357:8k_2_02:65]
|  |  | For the Three Months Ended |  |  | For the Twelve Months Ended |  |
|  |  | December 30, 2017 |  |  | December 31, 2016 |  |  | December 30, 2017 |  |  | December 31, 2016 |  |
| Net sales |  | $ | 304,849 |  |  | $ | 284,518 |  |  | $ | 1,221,534 |  |  | $ | 1,056,159 |  |
| Cost of sales |  |  | 178,225 |  |  |  | 170,181 |  |  |  | 715,001 |  |  |  | 643,042 |  |
| Gross profit |  |  | 126,624 |  |  |  | 114,337 |  |  |  | 506,533 |  |  |  | 413,117 |  |
| Selling, general and administrative expenses |  |  | 55,934 |  |  |  | 56,082 |  |  |  | 212,833 |  |  |  | 206,129 |  |
| Research and development expenses |  |  | 13,617 |  |  |  | 11,314 |  |  |  | 50,489 |  |  |  | 42,198 |  |
| Amortization of intangibles |  |  | 6,293 |  |  |  | 5,953 |  |  |  | 24,700 |  |  |  | 19,337 |  |
| Impairment of goodwill and intangible assets |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14,809 |  |
|  |  |  | 75,844 |  |  |  | 73,349 |  |  |  | 288,022 |  |  |  | 282,473 |  |
| Operating income |  |  | 50,780 |  |  |  | 40,988 |  |  |  | 218,511 |  |  |  | 130,644 |  |
| Interest expense |  |  | 3,512 |  |  |  | 2,342 |  |  |  | 13,380 |  |  |  | 8,628 |  |
| Foreign exchange loss |  |  | 3,859 |  |  |  | 7,586 |  |  |  | 2,376 |  |  |  | 472 |  |
| Other income, net |  |  | (320 | ) |  |  | (690 | ) |  |  | (1,282 | ) |  |  | (1,730 | ) |
| Income before income taxes |  |  | 43,729 |  |  |  | 31,750 |  |  |  | 204,037 |  |  |  | 123,274 |  |
| Income taxes |  |  | 54,548 |  |  |  | 4,505 |  |  |  | 84,518 |  |  |  | 18,786 |  |
| Net income (loss) |  | $ | (10,819 | ) |  | $ | 27,245 |  |  | $ | 119,519 |  |  | $ | 104,488 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.48 | ) |  | $ | 1.20 |  |  | $ | 5.27 |  |  | $ | 4.63 |  |
| Diluted |  | $ | (0.48 | ) |  | $ | 1.19 |  |  | $ | 5.21 |  |  | $ | 4.60 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,714 |  |  |  | 22,692 |  |  |  | 22,687 |  |  |  | 22,559 |  |
| Diluted |  |  | 22,714 |  |  |  | 22,863 |  |  |  | 22,931 |  |  |  | 22,727 |  |
| Comprehensive income (loss) |  | $ | (1,143 | ) |  | $ | 7,818 |  |  | $ | 130,431 |  |  | $ | 75,580 |  |

[0001437749-18-001357:8k_2_02:66]
-more-

[0001437749-18-001357:8k_2_02:67]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Cash Flows |
| (In thousands of USD, unaudited) |

[0001437749-18-001357:8k_2_02:68]
|  |  | For the Twelve Months Ended |  |
|  |  | December 30, 2017 |  |  | December 31, 2016 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 119,519 |  |  | $ | 104,488 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 38,311 |  |  |  | 33,800 |  |
| Amortization of intangibles |  |  | 24,700 |  |  |  | 19,337 |  |
| Impairment of goodwill and intangible assets |  |  | - |  |  |  | 14,809 |  |
| Provision for bad debts |  |  | 2,414 |  |  |  | 1,769 |  |
| Loss on sale of product line |  |  | - |  |  |  | 1,391 |  |
| Stock-based compensation |  |  | 16,315 |  |  |  | 11,987 |  |
| Non-cash inventory charges |  |  | 1,607 |  |  |  | 7,834 |  |
| Excess tax benefit on stock-based compensation |  |  | - |  |  |  | (3,421 | ) |
| Loss on sale of assets |  |  | 3,634 |  |  |  | 813 |  |
| Deferred income taxes |  |  | 17,063 |  |  |  | (5,269 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (11,087 | ) |  |  | (22,779 | ) |
| Inventories |  |  | (20,180 | ) |  |  | 8,539 |  |
| Accounts payable |  |  | 6,494 |  |  |  | 19,190 |  |
| Accrued expenses (including post-retirement) |  |  | 7,641 |  |  |  | 2,287 |  |
| Accrued payroll and severance |  |  | 3,709 |  |  |  | 6,131 |  |
| Accrued income taxes |  |  | 39,276 |  |  |  | (18,062 | ) |
| Prepaid expenses and other assets |  |  | 19,754 |  |  |  | (2,711 | ) |
| Net cash provided by operating activities |  |  | 269,170 |  |  |  | 180,133 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (65,925 | ) |  |  | (46,228 | ) |
| Acquisition of business, net of cash acquired |  |  | (38,512 | ) |  |  | (471,118 | ) |
| Proceeds from maturities of short-term investments |  |  | 3,739 |  |  |  | 345 |  |
| Decrease in entrusted loan receivable |  |  | 3,599 |  |  |  | 5,510 |  |
| Proceeds from sale of property, plant and equipment |  |  | 962 |  |  |  | 248 |  |
| Net cash used in investing activities |  |  | (96,137 | ) |  |  | (511,243 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 15,000 |  |  |  | 367,000 |  |
| Proceeds of term loan |  |  | 9,375 |  |  |  | 125,000 |  |
| Payments of revolving credit facility |  |  | (127,500 | ) |  |  | (331,500 | ) |
| Payments of term loan |  |  | (7,188 | ) |  |  | (89,688 | ) |
| Net proceeds from senior notes payable |  |  | 125,000 |  |  |  | 226,428 |  |
| Payments of entrusted loan |  |  | (3,599 | ) |  |  | (5,510 | ) |
| Debt issuance costs paid |  |  | (1,626 | ) |  |  | (3,583 | ) |
| Cash dividends paid |  |  | (31,670 | ) |  |  | (27,866 | ) |
| Net (payments) proceeds related to stock-based award activities |  |  | (2,373 | ) |  |  | 20,494 |  |
| Excess tax benefit on share-based compensation |  |  | - |  |  |  | 3,421 |  |
| Net cash (used in) provided by financing activities |  |  | (24,581 | ) |  |  | 284,196 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 6,100 |  |  |  | (6,748 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 154,552 |  |  |  | (53,662 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275,124 |  |  |  | 328,786 |  |
| Cash and cash equivalents at end of period |  | $ | 429,676 |  |  | $ | 275,124 |  |

[0001437749-18-001357:8k_2_02:69]
-more-

[0001437749-18-001357:8k_2_02:70]
| LITTELFUSE, INC. |
| Supplemental Financial Information |
| (in millions of USD except per share amounts, unaudited) |

[0001437749-18-001357:8k_2_02:71]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4-17 |  |  | Q4-16 |  |  | YTD-17 |  |  | YTD-16 |  |
| GAAP diluted EPS |  | $ | (0.48 | ) |  | $ | 1.19 |  |  | $ | 5.21 |  |  | $ | 4.60 |  |
| EPS impact of Non-GAAP adjustments (below) |  |  | 2.30 |  |  |  | 0.38 |  |  |  | 2.53 |  |  |  | 1.66 |  |
| Adjusted diluted EPS |  | $ | 1.81 |  |  | $ | 1.57 |  |  | $ | 7.74 |  |  | $ | 6.26 |  |
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4-17 |  |  | Q4-16 |  |  | YTD-17 |  |  | YTD-16 |  |
| Reed switch manufacturing transfer costs |  | $ | - |  |  | $ | (0.1 | ) |  | $ | - |  |  | $ | 1.6 |  |
| Restructuring |  |  | 0.7 |  |  |  | 1.2 |  |  |  | 2.2 |  |  |  | 2.5 |  |
| Acquisition-related and integration costs |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 8.1 |  |  |  | 31.1 |  |
| Impairment of goodwill and intangible assets |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.8 |  |
| Non-gaap adjustments to operating income |  |  | 2.1 |  |  |  | 4.6 |  |  |  | 10.3 |  |  |  | 50.0 |  |
| Non-operating foreign exchange loss |  |  | 3.9 |  |  |  | 7.6 |  |  |  | 2.4 |  |  |  | 0.5 |  |
| Non-gaap adjustments to income before income taxes |  |  | 6.0 |  |  |  | 12.2 |  |  |  | 12.7 |  |  |  | 50.5 |  |
| Income taxes |  |  | (46.5 | ) |  |  | 3.5 |  |  |  | (45.3 | ) |  |  | 12.6 |  |
| Non-gaap adjustments to net income |  | $ | 52.5 |  |  | $ | 8.7 |  |  | $ | 58.0 |  |  | $ | 37.9 |  |
| Total EPS impact |  | $ | 2.30 |  |  | $ | 0.38 |  |  | $ | 2.53 |  |  | $ | 1.66 |  |
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4-17 |  |  | Q4-16 |  |  | YTD-17 |  |  | YTD-16 |  |
| Net sales |  | $ | 304.8 |  |  | $ | 284.5 |  |  | $ | 1,221.5 |  |  | $ | 1,056.2 |  |
| GAAP operating income |  | $ | 50.8 |  |  | $ | 41.0 |  |  | $ | 218.5 |  |  | $ | 130.6 |  |
| Add back non-gaap adjustments |  |  | 2.1 |  |  |  | 4.6 |  |  |  | 10.3 |  |  |  | 49.9 |  |
| Adjusted operating income |  | $ | 52.9 |  |  | $ | 45.6 |  |  | $ | 228.8 |  |  | $ | 180.5 |  |
| Adjusted operating margin |  |  | 17.4 | % |  |  | 16.0 | % |  |  | 18.7 | % |  |  | 17.1 | % |
| Add back amortization |  |  | 6.3 |  |  |  | 6.0 |  |  |  | 24.7 |  |  |  | 19.4 |  |
| Add back depreciation |  |  | 10.1 |  |  |  | 9.0 |  |  |  | 38.3 |  |  |  | 33.8 |  |
| Adjusted EBITDA |  | $ | 69.3 |  |  | $ | 60.6 |  |  | $ | 291.8 |  |  | $ | 233.7 |  |
| Adjusted EBITDA margin |  |  | 22.7 | % |  |  | 21.3 | % |  |  | 23.9 | % |  |  | 22.1 | % |
| Net sales reconciliation |  | Q4-17 vs. Q4-16 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales growth |  |  | 4 | % |  |  | 9 | % |  |  | 19 | % |  |  | 7 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 2 | % |  |  | - |  |  |  | - |  |  |  | 1 | % |
| Divestitures |  |  | - |  |  |  | - |  |  |  | (2 | %) |  |  | - |  |
| FX impact |  |  | 1 | % |  |  | 3 | % |  |  | - |  |  |  | 2 | % |
| Organic net sales growth |  |  | 1 | % |  |  | 6 | % |  |  | 21 | % |  |  | 4 | % |
|  |  | 2017 YTD vs. 2016 YTD |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales growth |  |  | 24 | % |  |  | 9 | % |  |  | 1 | % |  |  | 16 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 14 | % |  |  | 5 | % |  |  | - |  |  |  | 9 | % |
| Divestitures |  |  | - |  |  |  | - |  |  |  | (7 | %) |  |  | (1 | %) |
| FX impact |  |  | - |  |  |  | - |  |  |  | 1 | % |  |  | 1 | % |
| Organic net sales growth |  |  | 10 | % |  |  | 4 | % |  |  | 7 | % |  |  | 7 | % |
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4-17 |  |  | Q4-16 |  |  | YTD-17 |  |  | YTD-16 |  |
| Income taxes |  | $ | 54.5 |  |  | $ | 4.5 |  |  | $ | 84.5 |  |  | $ | 18.8 |  |
| Effective rate |  |  | 124.7 | % |  |  | 14.2 | % |  |  | 41.4 | % |  |  | 15.2 | % |
| Non-GAAP adjustments - income taxes |  |  | (46.5 | ) |  |  | 3.5 |  |  |  | (45.3 | ) |  |  | 12.6 |  |
| Adjusted income taxes |  | $ | 8.0 |  |  | $ | 8.0 |  |  | $ | 39.2 |  |  | $ | 31.4 |  |
| Adjusted effective rate |  |  | 16.2 | % |  |  | 18.3 | % |  |  | 18.1 | % |  |  | 18.1 | % |
| Free cash flow reconcilation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4-17 |  |  | Q4-16 |  |  | YTD-17 |  |  | YTD-16 |  |
| Net cash provided by operating activities |  | $ | 87.9 |  |  | $ | 80.1 |  |  | $ | 269.2 |  |  | $ | 180.1 |  |
| Less: Purchases of property, plant and equipment |  |  | (17.5 | ) |  |  | (11.7 | ) |  |  | (65.9 | ) |  |  | (46.2 | ) |
| Free cash flow |  | $ | 70.4 |  |  | $ | 68.4 |  |  | $ | 203.3 |  |  | $ | 133.9 |  |

[0001437749-18-001357:8k_2_02:72]
| Note: Totals will not always foot due to rounding |

[0001437749-18-001357:8k_2_02:73]
# # #
