# LFUS MD&A — 0001437749-18-003245


## mdna

[0001437749-18-003245:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001437749-18-003245:mdna:2]
The following discussion of Littelfuse’s financial condition and results of operations should be read together with the Consolidated Financial Statements and notes to those statements included in Item 8 of Part II of this Annual Report on Form 10-K.

[0001437749-18-003245:mdna:3]
Business

[0001437749-18-003245:mdna:4]
For a description of the Company’s business, segments and product offerings, see Item 1, Business.

[0001437749-18-003245:mdna:5]
2017 EXECUTIVE OVERVIEW

[0001437749-18-003245:mdna:6]
Net sales increased by $165.4 million, or 15.7%, in 2017 compared to 2016. The increase in net sales was primarily driven by the acquisitions of ON Portfolio, PolySwitch, and U.S. Sensor, higher volume and growth across each of the Electronics segment reporting units and volume growth in the Automotive segment driven by increases in passenger car and commercial vehicle businesses.

[0001437749-18-003245:mdna:7]
For the year ended December 30, 2017, the Company recognized net income of $119.5 million, or $5.21 per diluted share compared to net income of $104.5 million, or $4.60 per diluted share for the year ended December 31, 2016. Net income increased due to the impacts of the acquisitions and volume increases, higher gross profit largely driven by a favorable mix within the Electronics segment, a $14.8 million impairment to goodwill and other intangible assets impairment charge recorded in the Custom Products reporting unit in 2016 partially offset by higher income tax expense primarily driven by the enactment of the Tax Cuts and Jobs Act in December 2017.

[0001437749-18-003245:mdna:8]
Net cash provided by operating activities was $269.2 million for the year ended December 30, 2017 as compared to $180.1 million for the year ended December 31, 2016. The increase in net cash provided by operating activities reflected higher earnings, lower cash taxes, lower acquisition-related and integration payments and the impact of working capital changes largely driven by collections efficiency and lower vendor prepayments.

[0001437749-18-003245:mdna:9]
On January 17, 2018, the Company acquired IXYS Corporation “IXYS”, a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 3,500 customers through its direct sales force and global distribution partners. The purchase price for IXYS was approximately $856.5 million, which included consideration of cash, Littelfuse common stock, and the value of converted or cash settled IXYS equity awards. For the twelve months ended December 30, 2017, IXYS generated net sales of approximately $340 million. IXYS’ operations will be included in the Electronics segment.

[0001437749-18-003245:mdna:10]
On July 7, 2017, the Company acquired the assets of U.S. Sensor for $24.3 million. The acquired business, which is included in the Electronics segment expands the Company’s existing sensor portfolio in several key electronics and industrial end markets. U.S. Sensor manufactures a variety of high quality negative temperature coefficient thermistors as well as thermistor probes and assemblies. Product lines also include thin film platinum resistance temperature detectors (“RTDs”) and RTD assemblies.

[0001437749-18-003245:mdna:11]
On February 28, 2017, pursuant to a Securities Purchase Agreement between the Company and the stockholders of Monolith, a U.S. start-up Company developing silicon carbide technology, and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired approximately 62% of the outstanding common stock of Monolith for $15 million. This was in addition to the Company’s initial investment of $3.5 million in the preferred stock of Monolith Semiconductor in December 2015. Monolith operations are included in the Electronics segment.

[0001437749-18-003245:mdna:12]
On October 13, 2017, the Company amended its existing credit agreement to increase the unsecured revolving credit facility from $575.0 million to $700.0 million, increase the unsecured term loan credit facility from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The credit agreement also includes the option for the Company to increase the size of the revolving credit facility and the term loan facility by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the credit agreement. Additionally, on November 15, 2017, the Company entered into a note purchase agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes. On January 16, 2018, $50 million in aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 were funded.

[0001437749-18-003245:mdna:13]
OUTLOOK

[0001437749-18-003245:mdna:14]
Vision and Strategy

[0001437749-18-003245:mdna:15]
The Company works with its customers to design and develop technologies that help them build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy, ranging across consumer electronics, IT and telecommunication applications, industrial electronics, automobiles and other transportation, and heavy industrial applications. Built upon that framework, the Company’s strategy is centered on growing its core circuit protection business, accelerating its growth in power control, and doubling its sensor platform.

[0001437749-18-003245:mdna:16]
The Company’s strategic plan is focused on maximizing shareholder value by driving profitable sales growth, earnings per share growth, strong cash flow generation, and maintaining a balanced approach to capital allocation. The Company pursues the following major strategic initiatives, which are summarized below, along with more specific areas of focus.

[0001437749-18-003245:mdna:17]
| Strategic Objective |  | 2018 and Future Priorities |
| Double digit sales growth |  | ● | Grow through increased product content with existing customers and increased market share |
|  |  | ● | Expand portfolio into new and underpenetrated geographies and end markets |
|  |  | ● | Increase innovation capabilities and investments |
|  |  | ● | Expand presence in products and applications that are converging across business segments |
|  |  | ● | Targeted mergers and acquisitions |
| EPS growth |  | ● | Focus on higher profitability growth opportunities |
|  |  | ● | Grow operating margins through operational excellence |
|  |  | ● | Disciplined approach to managing costs |
| Cash flow and liquidity |  | ● | Disciplined management of working capital |
|  |  | ● | Prudent deployment of capital |
|  |  | ● | Disciplined approach to mergers and acquisitions |
|  |  | ● | Grow dividend in line with earnings |
|  |  | ● | Periodic share repurchases |

[0001437749-18-003245:mdna:18]
The Company’s strategy is to generate profitable sales growth. In order to accomplish this, The Company is focusing on accelerating organic growth by increasing its content and share gains, enhancing technology efforts to drive innovation, capitalizing on cross segment opportunities, and gaining traction in underpenetrated geographies and markets. The Company will continue to make targeted strategic acquisitions that align to its strategy and financial targets to support new business, products, markets, and technologies while leveraging existing customers.

[0001437749-18-003245:mdna:19]
Management believes that sustaining profitability through a combination of profitable organic growth and acquisitions is critical to the Company’s competitiveness, while enhancing value the Company delivers to its customers. In addition, the Company continues to implement initiatives across all platforms to enhance productivity while managing its cost structure, including integration of operations and streamlining administrative and support activities to drive operating margins.

[0001437749-18-003245:mdna:20]
The Company seeks to deploy its capital using a balanced approach. Priorities for capital deployment, over time, include investments to drive increased organic growth, targeted acquisitions that align to the Company’s strategic and financial metrics and returning capital to shareholders through dividends and periodic share repurchases.

[0001437749-18-003245:mdna:21]
The Company uses several key indicators to gauge progress toward achieving these objectives. These indicators include organic sales growth, operating margins, cash flow from operations and capital expenditures. The Company targets long-term sales double digit sales growth, split between 5-7% annual organic sales growth and 5-7% annual growth from strategic acquisitions, while targeting operating margins between 17% and 19% and double-digit earnings per share growth. Cash flow from operations less capital expenditures is targeted to approximate net income but in any given year can be significantly impacted by the timing of non-recurring or infrequent expenditures.

[0001437749-18-003245:mdna:22]
Significant Accounting Policies and Critical Estimates

[0001437749-18-003245:mdna:23]
Critical Accounting Policies and Estimates

[0001437749-18-003245:mdna:24]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The Company’s most critical accounting policies are those that are most important to the portrayal of its financial condition and results of operations, and which require the Company to make its most difficult and subjective judgments, often as a result of the need to make estimates of matters that are inherently uncertain. The Company has identified the following as its most critical accounting policies and judgments. Although management believes that its estimates and assumptions are reasonable, they are based upon information available when they are made, and therefore, actual results may differ from these estimates under different assumptions or conditions. The Company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001437749-18-003245:mdna:25]
Net Sales

[0001437749-18-003245:mdna:26]
Revenue Recognition: The Company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured and the pricing is fixed and determinable. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts sales and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0001437749-18-003245:mdna:27]
Revenue and Billing: The Company accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement.

[0001437749-18-003245:mdna:28]
Returns and Credits: Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-18-003245:mdna:29]
Return to Stock: The Company has a return to stock policy whereby a customer, with previous authorization from management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0001437749-18-003245:mdna:30]
Volume Rebates: The Company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The Company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-18-003245:mdna:31]
Allowance for Doubtful Accounts: The Company evaluates the collectability of its trade receivables based on a combination of factors. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a specific customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0001437749-18-003245:mdna:32]
Inventory

[0001437749-18-003245:mdna:33]
The Company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life, and quality issues. Based on the analysis, the Company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable values. During 2017, the Company was required to step up the value of inventory acquired in business combinations to its selling prices less the cost to sell under business combination accounting. This step-up was approximately $1.6 million for the U.S. Sensor acquisition in 2017.

[0001437749-18-003245:mdna:34]
Goodwill

[0001437749-18-003245:mdna:35]
The Company’s methodology for allocating the purchase price of acquisitions is based on established valuation techniques that reflect the consideration of a number of factors, including valuations performed by third-party appraisers when appropriate. Goodwill is measured as the excess of the cost of an acquired entity over the fair value assigned to identifiable assets acquired and liabilities assumed. Based on its current organization structure, the Company has seven reporting units for which cash flows are determinable and to which goodwill has be allocated. Goodwill is either assigned to a specific reporting unit or allocated between reporting units based on the relative excess fair value of each reporting unit.

[0001437749-18-003245:mdna:36]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value

[0001437749-18-003245:mdna:37]
Quantitative Assessment for Impairment

[0001437749-18-003245:mdna:38]
For the seven reporting units with goodwill, the Company compared the estimated fair value of each reporting unit to its carrying value. If the carrying value of a reporting unit exceeded the estimated fair value, the difference between the estimated fair value and carrying value is recorded as the amount of the goodwill impairment charge. The results of the goodwill impairment test as of October 1, 2017 indicated that the estimated fair values for each of the seven reporting units with goodwill exceeded their respective carrying values. Accordingly, there were no goodwill impairment charges recorded as part of the Company’s 2017 annual goodwill impairment test.

[0001437749-18-003245:mdna:39]
As part of its impairment test for these reporting units, the Company engaged a third-party appraisal firm to assist in the Company’s determination of the estimated fair values. This determination included estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping. The Company weighted both the income and market approach equally to estimate the concluded fair value of each reporting unit. The determination of fair value requires the Company to make significant estimates and assumptions, which primarily include, but are not limited to: the selection of appropriate peer group companies; control premiums appropriate for acquisitions in which the Company competes; the discount rate; terminal growth rates; and forecasts of revenue, operating income, depreciation and amortization and capital expenditures.

[0001437749-18-003245:mdna:40]
Goodwill Impairment Assumptions

[0001437749-18-003245:mdna:41]
Although the Company believes its estimates of fair value are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results or other underlying assumptions could have a significant impact on the fair value of the reporting units. Future declines in the overall market value of the Company’s equity may also result in a conclusion that the fair value of one or more reporting units has declined below its carrying value.

[0001437749-18-003245:mdna:42]
One measure of the sensitivity of the amount of goodwill impairment charges to key assumptions is the amount by which each reporting unit “passed” (fair value exceeds the carrying value”) the goodwill impairment test. All seven of the reporting units passed the goodwill impairment test, with fair values that exceeded the carrying values by between 25% and 314% of their respective estimated fair values. As of the most recent annual test conducted on October 1, 2017, the Company noted that the excess of fair value over the carrying value, was 161%, 314%, 247%, 218%, 100%, 25%, and 248% for its reporting units: Electronics (non-silicon), Electronics (silicon), Passenger Car, Commercial Vehicle Products, Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test.

[0001437749-18-003245:mdna:43]
Generally, changes in estimates of expected future cash flows would have a similar effect on the estimated fair value of the reporting unit. That is, a 1.0% decrease in estimated annual future cash flows would decrease the estimated fair value of the reporting unit by approximately 1.0%. The estimated long-term net sales growth rate can have a significant impact on the estimated future cash flows, and therefore, the fair value of each reporting unit. A 1.0% decrease in the long-term net sales growth rate would have resulted in no reporting units failing the goodwill impairment test. Of the other key assumptions that impact the estimated fair values, most reporting units have the greatest sensitivity to changes in the estimated discount rate. The estimated discount rate was 9.6% for all reporting units except for Relays which had a discount rate of 10.1%. A 1.0% increase in the estimated discount rates would have resulted in no reporting units failing the annual goodwill impairment test. The Company believes that its estimates of future cash flows and discount rates are reasonable, but future changes in the underlying assumptions could differ due to the inherent uncertainty in making such estimates. Additionally, price deterioration or lower volume could have a significant impact on the fair values of the reporting units.

[0001437749-18-003245:mdna:44]
Long-Lived Assets

[0001437749-18-003245:mdna:45]
The Company evaluates the recoverability of other long-lived assets, including property, plant and equipment and certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset group may not be recoverable. Factors which could trigger an impairment review include significant underperformance relative to historical or projected operating results, significant changes in the manner of use of the assets or the strategy for the overall business, a significant decrease in the market value of the assets or significant negative industry or economic trends. When the Company determines that the carrying value of long-lived assets may not be recoverable based upon the existence of one or more of the indicators, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition. If the carrying value of an asset exceeds its estimated future undiscounted cash flows, an impairment loss is recorded for the excess of the asset’s carrying value over its fair value. During the year ended December 30, 2017, the Company recognized non-cash impairment charges of $2.9 million related to certain machinery and equipment in the Electronics and Automotive segments due to changes in the expected use of these certain assets. During the year ended December 31, 2016, the Company recognized non-cash impairment charges totaling $6.0 million, of which $2.2 million related to the impairment of certain customer relationship intangible assets in the Custom Products reporting unit within the Industrial segment and $3.8 million related to the impairment of the Custom Products tradename. The impairment of the customer relationship intangible assets resulted from lower expectations of future revenue to be derived from those relationships while the tradename impairment resulted from lower expectations of future cash flows of the Custom Products reporting unit.

[0001437749-18-003245:mdna:46]
Environmental Liabilities

[0001437749-18-003245:mdna:47]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The Company evaluates its reserve for coal mine remediation annually utilizing a third party expert.

[0001437749-18-003245:mdna:48]
Pension and Supplemental Executive Retirement Plan

[0001437749-18-003245:mdna:49]
The Company records annual income and expense amounts relating to its pension and postretirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets, but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors. The Company maintains several pension plans in international locations. The expected returns on plan assets and discount rates are determined based on each plan’s investment approach, local interest rates and plan participant profiles. The discount rates for the Company’s defined benefit plans primarily in Europe and the Asia-Pacific regions at December 30, 2017 and December 31, 2016 were 3.1% and 2.6%, respectively. During 2015, the Company settled its U.S. defined benefit pension plan as described in Note 8, Benefit Plans, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-18-003245:mdna:50]
A 50 basis point change in the discount rates at December 30, 2017 would have the following effect on the projected benefit obligation:

[0001437749-18-003245:mdna:51]
| (in millions) |  | 0.5% Increase |  |  | 0.5% Decrease |  |
| Projected benefit obligation |  | $ | (5.6 | ) |  | $ | 6.2 |  |

[0001437749-18-003245:mdna:52]
Equity-based Compensation

[0001437749-18-003245:mdna:53]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments in the foreseeable future.

[0001437749-18-003245:mdna:54]
Total equity-based compensation expense for all equity compensation plans was $17.3 million, $12.8 million, and $10.7 million in 2017, 2016, and 2015, respectively. Further information regarding this expense is provided in Note 9, Shareholders’ Equity, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-18-003245:mdna:55]
Income Taxes

[0001437749-18-003245:mdna:56]
The Company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of foreign income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity).

[0001437749-18-003245:mdna:57]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. The Company recognized deferred tax liabilities of $12.0 million ($11.8 million for non-U.S. taxes and $0.2 million for U.S. state taxes) as of December 30, 2017 related to taxes on certain non-U.S. earnings which are not considered to be permanently reinvested. Management regularly evaluates whether foreign earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company’s non-U.S. subsidiaries. Changes in economic and business conditions, foreign or U.S. tax laws (such as the Tax Act), or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0001437749-18-003245:mdna:58]
In accordance with the guidance provided in SEC SAB No. 118, in the fourth quarter of 2017 the Company recorded a charge of $47 million as a provisional reasonable estimate of the impact of the Tax Act, including $49 million for the Toll Charge net of $2 million for other net tax benefits. The Company is continuing to analyze the Tax Act and plans to finalize the estimate within the measurement period outlined in SAB No.118. The final charge may differ from the provisional reasonable estimate if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining the estimate, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors. Aside from these interpretation issues, the final charge may differ from the provisional reasonable estimate due to refinements of accumulated non-U.S. earnings and tax pool data.

[0001437749-18-003245:mdna:59]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001437749-18-003245:mdna:60]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 10, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-18-003245:mdna:61]
Off-Balance Sheet Arrangements

[0001437749-18-003245:mdna:62]
Other than non-cancellable operating lease commitments, the Company does not have off-balance sheet arrangements, financings or special purpose entities.

[0001437749-18-003245:mdna:63]
Financial Review

[0001437749-18-003245:mdna:64]
In the financial review that follows, the Company discusses its consolidated results of operations, financial position, cash flows and certain other information. This discussion should be read in conjunction with the Company’s Consolidated Financial Statements and related notes that begin on page F-1.

[0001437749-18-003245:mdna:65]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 30, 2017 AS COMPARED TO THE YEAR ENDED DECEMBER 31, 2016

[0001437749-18-003245:mdna:66]
The following table summarizes the Company’s consolidated results of operations for periods presented. The fiscal year 2017 includes approximately $10.3 million of non-segment charges.  These included acquisition-related and integration costs related to legal, accounting and other expenses associated with completed or pending acquisitions of approximately $8.0 million, including $1.6 million of purchase accounting inventory charges related to the Company’s 2017 acquisition of U.S. Sensor as described in Note 2, Acquisitions and Dispositions, of the Notes to the Consolidated Financial Statements included in this Annual Report, and $2.2 million of charges related to restructuring and production transfers in the Company’s Asia operations.

[0001437749-18-003245:mdna:67]
The fiscal year 2016 includes approximately $50.0 million of non-segment charges.  These included $14.8 million of charges related to the impairment of the Custom Products reporting unit, $21.4 million of acquisition and integration costs associated with the Company’s 2016 acquisitions, primarily PolySwitch, $7.8 million of non-cash fair value step-up inventory charges relating to the Company’s 2016 acquisitions, primarily PolySwitch, as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report, $1.9 million in charges related to the closure of the Company’s manufacturing facility in Denmark, $1.6 million related to the Company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, and $2.5 million related to restructuring costs.

[0001437749-18-003245:mdna:68]
Fiscal year 2017 also included approximately $2.4 million in foreign currency expenses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar, while fiscal year 2016 also included approximately $0.5 million in foreign currency expenses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar.

[0001437749-18-003245:mdna:69]
|  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |
| (in thousands, except % change) |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Sales |  | $ | 1,221,534 |  |  | $ | 1,056,159 |  |  | $ | 165,375 |  |  | 15.7 | % |  |
| Gross profit |  |  | 506,533 |  |  |  | 413,117 |  |  |  | 93,416 |  |  | 22.6 | % |  |
| Operating expenses |  |  | 288,022 |  |  |  | 282,473 |  |  |  | 5,549 |  |  | 2.0 | % |  |
| Operating income |  |  | 218,511 |  |  |  | 130,644 |  |  |  | 87,867 |  |  | 67.3 | % |  |
| Other expense (income), net |  |  | (1,282 | ) |  |  | (1,730 | ) |  |  | (448 | ) |  | (25.9 | %) |  |
| Income before income taxes |  |  | 204,037 |  |  |  | 123,274 |  |  |  | 80,763 |  |  | 65.5 | % |  |
| Income taxes |  |  | 84,518 |  |  |  | 18,786 |  |  |  | 65,732 |  |  | 349.9 | % |  |
| Net income |  |  | 119,519 |  |  |  | 104,488 |  |  |  | 15,031 |  |  | 14.4 | % |  |

[0001437749-18-003245:mdna:70]
Sales

[0001437749-18-003245:mdna:71]
Net sales for 2017 of $1,221.5 million increased $165.4 million, or 15.7%, compared to the prior year, resulting from the prior year acquisitions of PolySwitch, ON Portfolio, and Menber’s and $5.4 million from the current year U.S. Sensor acquisition. The remaining increase in net sales was primarily due to higher volume across all product lines in the Electronics segment and passenger car and commercial vehicle businesses within the Automotive segment partially offset by the divestitures of two non-core product lines within the Industrial segment in 2016.

[0001437749-18-003245:mdna:72]
Gross Profit

[0001437749-18-003245:mdna:73]
Gross profit was $506.5 million, or 41.5% of sales, in 2017, compared to $413.1 million, or 39.1% of sales, in 2016. The increase in gross profit and gross margin reflects the incremental net sales and improved leverage in expenses and profits related to the prior year acquisitions, primarily in the Electronics segment.

[0001437749-18-003245:mdna:74]
Operating Expenses

[0001437749-18-003245:mdna:75]
Total operating expenses were $288.0 million, or 23.6% of net sales, for 2017 compared to $282.5 million, or 26.7% of net sales, for 2016. The increase in operating expenses of $5.5 million was primarily due to acquisitions, higher selling costs, higher research and development costs of $8.3 million and an increase of $5.4 million in amortization expense of intangible assets due to the acquisitions, partially offset by the $14.8 million of goodwill and other intangible asset impairment charges recognized in 2016 and lower acquisition-related expenses and integration costs of $13.4 million. Selling, general and administrative expenses increased by $6.7 million to $212.8 million, but decreased from 19.5% to 17.4% as a percentage of net sales for 2017 compared to 2016 primarily as a result of lower acquisition-related expenses and integration costs of $13.4 million and cost control initiatives partially offset by the acquisitions.

[0001437749-18-003245:mdna:76]
Operating Income

[0001437749-18-003245:mdna:77]
Operating income for 2017 was $218.5 million, an increase of $87.9 million or 67.3% compared to $130.6 million for 2016. The increase in operating income was the result of acquisitions and higher volume in the Electronics segment. Operating margins increased from 12.4% to 17.9% for 2017 due to the acquisitions, improvement in gross margins primarily driven by the Electronics segment, lower acquisition and integration related costs, the prior year goodwill and other intangible asset impairment charge and operational efficiencies. Also, the prior year goodwill and other intangible asset impairment charge reduced the operating margin by 1.4% in 2016.

[0001437749-18-003245:mdna:78]
Income Before Income Taxes

[0001437749-18-003245:mdna:79]
Income before income taxes for 2017 was $204.0 million, or 16.7% of net sales compared to $123.3 million, or 11.7% of net sales, for 2016. Income before income taxes was impacted by an increase in operating income described above, partially offset by higher interest expense of $4.8 million reflecting increased borrowings and unfavorable changes in foreign exchange rates of $1.9 million primarily as a result of fluctuations in the Chinese renminbi and Philippine peso against the U.S. dollar partially offset by fluctuations in the Euro against U.S. dollar.

[0001437749-18-003245:mdna:80]
Income Taxes

[0001437749-18-003245:mdna:81]
Income tax expense for 2017 was $84.5 million, or an effective tax rate of 41.4% compared to income tax expense of $18.8 million, or an effective tax rate of 15.2%, for 2016. The increase in 2017 reflects a fourth quarter charge of $47 million as a provisional reasonable estimate of the impact of the Tax Act, including $49 million for the Toll Charge net of $2 million for other net tax benefits. The Company is continuing to analyze the Tax Act and plans to finalize the estimate within the measurement period outlined in SAB No.118. The final charge may differ from the provisional reasonable estimate if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company in determining the estimate, whether through issuance of administrative guidance, or through further review of the Tax Act by the Company and its advisors. Aside from these interpretation issues, the final charge may differ from the provisional reasonable estimate due to refinements of accumulated non-U.S. earnings and tax pool data. Excluding the impact of the Tax Act, the effective tax rates for 2017 and 2016 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions partially offset by the impact of taxes on unremitted earnings, and, with respect to 2016, a one-time deduction with respect to the stock of one of the Company’s affiliates, partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded.

[0001437749-18-003245:mdna:82]
Segment Information

[0001437749-18-003245:mdna:83]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 12, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-18-003245:mdna:84]
The following table is a summary of the Company’s net sales by segment:

[0001437749-18-003245:mdna:85]
|  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |
| (in millions) |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Electronics |  | $ | 661.9 |  |  | $ | 535.2 |  |  | $ | 126.7 |  |  |  | 23.7 | % |
| Automotive |  |  | 453.2 |  |  |  | 415.2 |  |  |  | 38.0 |  |  |  | 9.2 | % |
| Industrial |  |  | 106.4 |  |  |  | 105.8 |  |  |  | 0.6 |  |  |  | 0.6 | % |
| Total |  | $ | 1,221.5 |  |  | $ | 1,056.2 |  |  | $ | 165.3 |  |  |  | 15.7 | % |

[0001437749-18-003245:mdna:86]
Electronics Segment

[0001437749-18-003245:mdna:87]
The Electronics segment net sales increased $126.7 million, or 23.7%, in 2017 compared to 2016 primarily due to the PolySwitch, and ON Portfolio acquisitions in 2016, and the U.S Sensor acquisition in 2017 along with higher volume across the passives, sensors and semiconductor product lines.

[0001437749-18-003245:mdna:88]
Automotive Segment

[0001437749-18-003245:mdna:89]
Net sales in the Automotive segment increased $38.0 million, or 9.2%, in 2017 compared to 2016 primarily due to the incremental net sales associated with the PolySwitch and Menber’s acquisitions in 2016, higher volume in passenger car and commercial vehicle products and favorable foreign exchange impacts of $1.9 million, partially offset by lower volume in automotive sensor products.

[0001437749-18-003245:mdna:90]
Industrial Segment

[0001437749-18-003245:mdna:91]
The Industrial segment net sales increased $0.6 million, or 0.6%, in 2017 compared to 2016 primarily due higher volume across all product lines, partially offset by the divestiture of two non-core product lines, one in the fourth quarter of 2016 and the other in the first quarter of 2016.

[0001437749-18-003245:mdna:92]
Geographic Sales Information

[0001437749-18-003245:mdna:93]
Sales by geography represent sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0001437749-18-003245:mdna:94]
|  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |
| (in millions) |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Americas |  | $ | 436.5 |  |  | $ | 411.1 |  |  | $ | 25.4 |  |  |  | 6.2 | % |
| Europe |  |  | 243.9 |  |  |  | 200.3 |  |  |  | 43.6 |  |  |  | 21.8 | % |
| Asia-Pacific |  |  | 541.1 |  |  |  | 444.8 |  |  |  | 96.3 |  |  |  | 21.7 | % |
| Total |  | $ | 1,221.5 |  |  | $ | 1,056.2 |  |  | $ | 165.3 |  |  |  | 15.7 | % |

[0001437749-18-003245:mdna:95]
Americas

[0001437749-18-003245:mdna:96]
Net sales in the Americas increased $25.4 million, or 6.2%, in 2017 compared to 2016 resulting from acquisitions and higher volume in the passive and semiconductor product lines in the Electronics segment and the passenger car and commercial vehicle businesses in the Automotive segment that were partially offset by lower volume in sensor products in the Automotive segment and the divestiture of a non-core product line in the Industrial segment.

[0001437749-18-003245:mdna:97]
Europe

[0001437749-18-003245:mdna:98]
European net sales increased $43.6 million, or 21.8%, in 2017 compared to 2016. The increase in net sales was primarily due to acquisitions and increased net sales across all product lines in the Electronics segment and the passenger car and commercial vehicle products businesses in the Automotive segment.

[0001437749-18-003245:mdna:99]
Asia-Pacific

[0001437749-18-003245:mdna:100]
Asia-Pacific net sales increased $96.3 million, or 21.7%, in 2017 compared to 2016, primarily due to incremental net sales from prior year acquisitions and increased volume across all product lines in the Electronics segment.

[0001437749-18-003245:mdna:101]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 31, 2016 AS COMPARED TO THE YEAR ENDED JANUARY 2, 2016

[0001437749-18-003245:mdna:102]
The following table summarizes the Company’s consolidated results of operations for periods presented. The fiscal year 2016 includes approximately $50.0 million of non-segment charges.  These included $14.8 million of charges related to the impairment of the Custom Products reporting unit, $21.4 million of acquisition and integration costs associated with the Company’s 2016 acquisitions, primarily PolySwitch, $7.8 million of non-cash fair value step-up inventory charges relating to the Company’s 2016 acquisitions, primarily PolySwitch, as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report, $1.9 million in charges related to the closure of the Company’s manufacturing facility in Denmark, $1.6 million related to the Company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, and $2.5 million related to restructuring costs.

[0001437749-18-003245:mdna:103]
Fiscal year 2015 includes approximately $45.2 million of other non-segment charges.  These included $5.2 million related to the Company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, $3.6 million related to restructuring, $4.6 million related to acquisition costs and $31.9 million of expense related to the planned termination of the U.S. pension as described in Note 8, Benefit Plans, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-18-003245:mdna:104]
Fiscal year 2016 also included approximately $0.5 million in foreign currency expenses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar, while fiscal year 2015 also included $1.5 million in foreign currency gains primarily attributable to changes in the value of both the euro and Philippine peso against the U.S. dollar.

[0001437749-18-003245:mdna:105]
|  |  | Fiscal Year |  |  |  |  |  |  |  |  |  |
| (in thousands, except % change) |  | 2016 |  |  | 2015 |  |  | Change |  |  | % Change |  |
| Sales |  | $ | 1,056,159 |  |  | $ | 867,864 |  |  | $ | 188,295 |  |  |  | 21.7 | % |
| Gross profit |  |  | 413,117 |  |  |  | 330,499 |  |  |  | 82,618 |  |  |  | 25.0 | % |
| Operating expenses |  |  | 282,473 |  |  |  | 226,342 |  |  |  | 56,131 |  |  |  | 24.8 | % |
| Operating income |  |  | 130,644 |  |  |  | 104,157 |  |  |  | 26,487 |  |  |  | 25.4 | % |
| Other expense (income), net |  |  | (1,730 | ) |  |  | (5,417 | ) |  |  | 3,687 |  |  |  | (68.1 | %) |
| Income before income taxes |  |  | 123,274 |  |  |  | 106,948 |  |  |  | 16,326 |  |  |  | 15.3 | % |
| Income taxes |  |  | 18,786 |  |  |  | 26,082 |  |  |  | (7,296 | ) |  |  | (28.0 | %) |
| Net income |  |  | 104,488 |  |  |  | 80,866 |  |  |  | 23,622 |  |  |  | 29.2 | % |

[0001437749-18-003245:mdna:106]
Sales

[0001437749-18-003245:mdna:107]
Net sales for 2016 of $1,056.2 million increased $188.3 million, or 21.7%, compared to the prior year, reflecting $170.2 million of incremental revenues from businesses acquired over the previous two years as well as organic growth in the Electronics and Automotive segments, partially offset by lower sales from the Industrial segment due to weaker end markets. The Company also experienced $7.3 million in unfavorable foreign currency effects in 2016 compared to 2015 primarily resulting from sales denominated in Chinese renminbi.

[0001437749-18-003245:mdna:108]
The increase in sales in 2016 reflects a $75.2 million, or 22%, increase in Automotive segment sales and a $129.7 million, or 32%, increase in Electronics segment sales, partially offset by a $16.6 million, or 14%, decrease in Industrial segment sales.

[0001437749-18-003245:mdna:109]
Gross Profit

[0001437749-18-003245:mdna:110]
Gross profit was $413.1 million, or 39.1% of sales, in 2016, compared to $330.5 million, or 38.1% of sales, in 2015. Gross profit for 2016 was negatively impacted by $10.8 million of charges primarily related to the inventory step-up from the acquisition of PolySwitch and to a lesser extent the ON Portfolio and Menber’s acquisitions. Gross profit for 2015 was negatively impacted by $5.2 million of charges related to the transfer of the Company’s reed switch production from the U.S. and China to the Philippines.

[0001437749-18-003245:mdna:111]
Operating Expenses

[0001437749-18-003245:mdna:112]
Total operating expense was $282.5 million, or 26.7% of net sales, for 2016 compared to $226.3 million, or 26.1% of net sales, for 2015. Operating expense in 2016 included $39.1 million of charges primarily consisting of acquisition and integration costs of $21.4 million and $14.8 million of charges related to the impairment of the Custom Products reporting unit. Operating expense in 2015 included $39.9 million of charges, primarily related to the U.S. pension settlement of $31.9 million and restructuring and acquisition costs of $8.0 million.

[0001437749-18-003245:mdna:113]
Operating Income

[0001437749-18-003245:mdna:114]
Operating income was $130.6 million, or 12.4% of net sales, in 2016 compared to $104.2 million, or 12.0% of net sales, in the prior year. The increase in operating income in the current year was due primarily to higher revenue as well as the factors affecting operating expenses discussed above.

[0001437749-18-003245:mdna:115]
Interest expense was $8.6 million in 2016 compared to $4.1 million in 2015 and is primarily related to the Company’s increased borrowing to fund acquisitions.

[0001437749-18-003245:mdna:116]
Foreign exchange (gain) loss was $0.5 million of loss in 2016 compared to $1.5 million of gain in 2015. The fluctuation in foreign exchange was primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar in 2016 and 2015.

[0001437749-18-003245:mdna:117]
Other Expense (Income), Net

[0001437749-18-003245:mdna:118]
Other expense (income), net, consisting of interest income, royalties and non-operating income was $1.7 million of income in 2016 compared to $5.4 million of income in 2015. The year-over-year decrease in income primarily reflects lower interest income in 2016.

[0001437749-18-003245:mdna:119]
Income Taxes

[0001437749-18-003245:mdna:120]
Income tax expense was $18.8 million with an effective tax rate of 15.2% in 2016 compared to income tax expense of $26.1 million with an effective tax rate of 24.4% in 2015. The effective tax rates for these periods are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions and, with respect to the 2016 period, a one-time deduction with respect to the stock of one of the Company’s affiliates partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded and taxes on unremitted earnings, and, with respect to the 2015 period, the impact of a pension settlement partially offset by the impact from the restructuring of the legal ownership of the Company’s Mexican manufacturing operations.

[0001437749-18-003245:mdna:121]
Segment Information

[0001437749-18-003245:mdna:122]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 12, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-18-003245:mdna:123]
The following table is a summary of the Company’s net sales by segment:

[0001437749-18-003245:mdna:124]
|  |  | Fiscal Year |  |  |  |  |  |
| (in millions) |  | 2016 |  |  | 2015 |  |  | Change |  |
| Electronics |  | $ | 535.2 |  |  | $ | 405.5 |  |  | $ | 129.7 |  |
| Automotive |  |  | 415.2 |  |  |  | 340.0 |  |  |  | 75.2 |  |
| Industrial |  |  | 105.8 |  |  |  | 122.4 |  |  |  | (16.6 | ) |
| Total |  | $ | 1,056.2 |  |  | $ | 867.9 |  |  | $ | 188.3 |  |

[0001437749-18-003245:mdna:125]
Electronics Segment

[0001437749-18-003245:mdna:126]
The Electronics segment, which accounted for approximately 51% of total sales in 2016, has produced modest organic revenue growth over the last few years. In 2016, sales increased $129.7 million, or 32%, compared to the prior year, reflecting $110.0 million of sales from businesses acquired in 2016 as well as organic growth in sensor products and to a lesser extent passive and semiconductor products. Operating margins also improved in 2016 compared to 2015 due to better leverage from the higher sales, as well as favorable product and regional mix.

[0001437749-18-003245:mdna:127]
Fourth quarter 2016 sales were unseasonably strong due to higher demand in some markets, along with an earlier than usual Chinese New Year. The book-to-bill ratio of 1.05 at the end of the fourth quarter is primarily due to stronger than normal seasonal trends.

[0001437749-18-003245:mdna:128]
Automotive Segment

[0001437749-18-003245:mdna:129]
The Automotive segment, which accounted for approximately 39% of total sales in 2016, has been the Company’s fastest growing business over the last few years. In 2016, sales increased $75.2 million, or 22%, compared to the prior year, reflecting $60.2 million of incremental sales from businesses acquired in 2016 and the fourth quarter of 2015 as well as organic growth related to sensor and passenger car products. These increases in sales were partially offset by lower sales of legacy commercial vehicle products, reflecting weakness in the North American heavy truck, construction, and agricultural end markets.

[0001437749-18-003245:mdna:130]
The segment realized growth in fuse content which was driven by more sophisticated electronics in vehicles and sales of high-current products, especially the Masterfuse® line. Also contributing to segment performance was the automotive sensor business which experienced strong growth in sales and a significant improvement in margins. Sales in China were strong due to the Chinese government’s tax incentives for smaller cars driving higher growth in the China car industry.

[0001437749-18-003245:mdna:131]
Industrial Segment

[0001437749-18-003245:mdna:132]
The Industrial segment, which accounted for approximately 10% of total sales in 2016, experienced a sales decrease of 14% over the prior year with declines across all businesses. The Company also divested certain non-core product lines during 2016. See Note 2, Acquisitions and Dispositions of the Notes to the Consolidated Financial Statements included in this Annual Report, for additional information. The Company’s power fuse business has benefited from a strong U.S. solar market in recent years; however, this market slowed in the second half of 2016. Sales in the protection relay business continued to be impacted by weakness in the heavy industrial and oil and gas markets, as those customers have restricted their capital spending. In the custom products business, the Company continued to see a decline in the potash market, which has resulted in the aforementioned impairment charge in the third quarter of 2016. It is possible that the Company could recognize impairment charges for the Relays reporting unit if there are declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment.

[0001437749-18-003245:mdna:133]
Geographic Sales Information

[0001437749-18-003245:mdna:134]
Sales by geography represent sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0001437749-18-003245:mdna:135]
|  |  | Fiscal Year |  |  |  |  |  |
| (in millions) |  | 2016 |  |  | 2015 |  |  | Change |  |
| Americas |  | $ | 411.1 |  |  | $ | 401.2 |  |  | $ | 9.9 |  |
| Europe |  |  | 200.3 |  |  |  | 152.7 |  |  |  | 47.6 |  |
| Asia-Pacific |  |  | 444.8 |  |  |  | 314.0 |  |  |  | 130.8 |  |
| Total |  | $ | 1,056.2 |  |  | $ | 867.9 |  |  | $ | 188.3 |  |

[0001437749-18-003245:mdna:136]
Americas

[0001437749-18-003245:mdna:137]
Sales in the Americas increased $9.9 million, or 2%, in 2016 compared to 2015, primarily due to acquisitions and increased demand for Electronics products, partially offset by lower Industrial sales. Electronics sales increased $23.3 million, or 20%, primarily due to acquisitions as well as increased sales for passive and sensor products. Industrial sales decreased $14.0 million, or 13%, resulting from decreases in demand for power fuses, custom products, and relay products.

[0001437749-18-003245:mdna:138]
Europe

[0001437749-18-003245:mdna:139]
European sales increased $47.6 million, or 31%, in 2016 compared to 2015 primarily due to acquisitions and increased demand for Automotive and Electronics products, partially offset by lower Industrial sales. Automotive sales increased $26.8 million, or 27%, in 2016 primarily due to acquisitions and increased sales for sensor products. Electronics sales increased $22.4 million, or 46%, primarily due to acquisitions as well as increased sales for the passive and sensor products. Industrial sales decreased $1.5 million, or 24%, in 2016 primarily from lower sales of fuse and relay products.

[0001437749-18-003245:mdna:140]
Asia-Pacific

[0001437749-18-003245:mdna:141]
Asia-Pacific sales increased $130.8 million, or 42%, in 2016 compared to 2015, primarily due to acquisitions and increased demand for Automotive and Electronics products offset by lower Industrial sales and changes in foreign exchange rates of $5.4 million. Electronics sales increased $84.0 million, or 35%, primarily due to acquisitions as well as increased sales for passive and sensor products partially offset by $2.3 million due to changes in foreign exchange rates. Automotive sales increased $47.8 million, or 72%, primarily due to acquisitions as well as increased sales for passenger car and sensor products, partially offset by $3.3 million of changes in foreign exchange rates. Industrial sales decreased $1.2 million, or 13%.

[0001437749-18-003245:mdna:142]
Liquidity and Capital Resources

[0001437749-18-003245:mdna:143]
Cash and cash equivalents were $429.7 million as of December 30, 2017, an increase of $154.6 million as compared to December 31, 2016.

[0001437749-18-003245:mdna:144]
As of December 30, 2017, $309.5 million of the $429.7 million of the Company’s cash and cash equivalents was held by non-U.S. subsidiaries. Of the $309.5 million, at least $160 million can be repatriated with minimal tax consequences. With respect to the remaining $149.5 million, the Company has recognized deferred tax liabilities of $12.0 million as of December 30, 2017 (including $11.8 million for non-U.S. taxes and $0.2 million for U.S. state taxes) on approximately $118 million of the non-U.S. cash balance because the amounts are not considered to be permanently reinvested. In addition, repatriation of some non-U.S. cash balances is further restricted by local laws. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0001437749-18-003245:mdna:145]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0001437749-18-003245:mdna:146]
Revolving Credit Facility/Term Loan

[0001437749-18-003245:mdna:147]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders. For the Term Loan, the Company was required to make quarterly principal payments of $1.6 million through March 31, 2018 and $3.1 million from June 30, 2018 through December 31, 2020 with the remaining balance due on March 4, 2021.

[0001437749-18-003245:mdna:148]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($1.6 million as of December 30, 2017 increasing to $2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022

[0001437749-18-003245:mdna:149]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.07% at December 30, 2017.

[0001437749-18-003245:mdna:150]
Senior Notes

[0001437749-18-003245:mdna:151]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001437749-18-003245:mdna:152]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001437749-18-003245:mdna:153]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series A due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 will be payable on February 15 and August 15, commencing on August 15, 2018.

[0001437749-18-003245:mdna:154]
The Company was in compliance with its debt covenants as of December 30, 2017, and expects to remain in compliance based on management’s estimates of operating and financial results for 2017 and the foreseeable future. As of December 30, 2017, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0001437749-18-003245:mdna:155]
Acquisitions

[0001437749-18-003245:mdna:156]
During the year ended December 30, 2017, the Company paid $38.5 million, net of cash acquired, for the acquisitions of U.S Sensor and Monolith. The Company financed the cash portion of the acquisition with a combination of cash on hand and borrowings under the credit facility.

[0001437749-18-003245:mdna:157]
During the year ended December 31, 2016, the Company paid $417.1 million of total purchase prices, net of cash acquired, for the acquisitions of the ON Portfolio, Menber’s and PolySwitch. The Company financed the cash portion of these acquisitions with a combination of cash on hand and borrowings under the credit facility.

[0001437749-18-003245:mdna:158]
During the year ended January 2, 2016, the Company paid $4.6 million, net of cash acquired, substantially all for the acquisition of Sigmar. The Company financed the cash portion of the acquisition with cash on hand.

[0001437749-18-003245:mdna:159]
Cash Flow Overview

[0001437749-18-003245:mdna:160]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes and other operating activities.

[0001437749-18-003245:mdna:161]
The following describes the Company’s cash flows for the twelve months ended December 30, 2017 and December 31, 2016

[0001437749-18-003245:mdna:162]
|  |  | Fiscal Year |  |
| (in millions) |  | 2017 |  |  | 2016 |  |
| Net cash provided by operating activities |  | $ | 269.2 |  |  | $ | 180.1 |  |
| Net cash provided used in investing activities |  |  | (96.1 | ) |  |  | (511.2 | ) |
| Net cash (used in) provided by financing activities |  |  | (24.7 | ) |  |  | 284.2 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 6.2 |  |  |  | (6.8 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 154.6 |  |  |  | (53.7 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275.1 |  |  |  | 328.8 |  |
| Cash and cash equivalents at end of period |  | $ | 429.7 |  |  | $ | 275.1 |  |

[0001437749-18-003245:mdna:163]
Cash flows from Operating Activities

[0001437749-18-003245:mdna:164]
Net cash provided by operating activities was $269.2 million for 2017, compared to $180.1 million during 2016. The increase in net cash provided by operating activities was primarily driven by higher earnings, lower cash taxes, reduced acquisition and integration payments and the timing of supplier and customer payments.

[0001437749-18-003245:mdna:165]
Cash flows from Investing Activities

[0001437749-18-003245:mdna:166]
Net cash used in investing activities was $96.1 million for 2017, compared to $511.2 million during 2016. Net cash used for acquisitions of $38.5 million in 2017 related to the acquisition of a majority stake in Monolith for $14.2 million and the acquisition of U.S. Sensor for $24.3 million. Net cash used for acquisitions of $471.1 million for 2016 primarily related to the acquisitions of PolySwitch for $344.5 million, the ON Portfolio for $104.0 million and Menber’s for $19.2 million. Capital expenditures were $65.9 million, representing an increase of $19.7 million compared to 2016.

[0001437749-18-003245:mdna:167]
Cash flows from Financing Activities

[0001437749-18-003245:mdna:168]
Net cash used in financing activities was $24.6 million for 2017 compared to net cash provided by financing activities of $284.2 million for 2016. The Company had $149.4 million of proceeds from the credit facility and senior notes payable and $134.7 million of payments on the term loan and credit facility in 2017 as compared to $718.4 million of proceeds from the credit facility and term loan and $421.2 million of payments on the term loan and credit facility. Additionally, dividends paid increased $3.8 million from $27.9 million in 2016 to $31.7 million for 2017.

[0001437749-18-003245:mdna:169]
The following describes the Company’s cash flows for the twelve months ended December 31, 2016 and January 2, 2016

[0001437749-18-003245:mdna:170]
|  |  | Fiscal Year |  |
| (in millions) |  | 2016 |  |  | 2015 |  |
| Net cash provided by operating activities |  | $ | 180.1 |  |  | $ | 165.8 |  |
| Net cash used in investing activities |  |  | (511.2 | ) |  |  | (44.2 | ) |
| Net cash used in financing activities |  |  | 284.2 |  |  |  | (67.6 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (6.8 | ) |  |  | (22.8 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | (53.7 | ) |  |  | 31.2 |  |
| Cash and cash equivalents at beginning of period |  |  | 328.8 |  |  |  | 297.6 |  |
| Cash and cash equivalents at end of period |  | $ | 275.1 |  |  | $ | 328.8 |  |

[0001437749-18-003245:mdna:171]
Cash flows from Operating Activities

[0001437749-18-003245:mdna:172]
Net cash provided by operating activities increased $14.3 million in 2016 compared to 2015. Cash provided by operating activities in 2016 included $104.5 million in net income, $83.0 million in non-cash adjustments (primarily $53.1 million in depreciation and amortization) and $7.4 million of unfavorable changes in operating assets and liabilities.

[0001437749-18-003245:mdna:173]
Changes in operating assets and liabilities (including short-term and long-term items) that negatively impacted cash flows in 2016 consisted of changes in accounts receivable ($25.2 million), accrued taxes ($18.1 million) and prepaid expenses and other ($0.3 million). The increase in accounts receivable reflects increased sales in 2016 compared to the prior year. Positively impacting cash flows were changes in inventory ($8.5 million), accrued expenses including post-retirement ($2.3 million), accounts payable ($19.2 million) and accrued payroll and severance ($6.1 million).

[0001437749-18-003245:mdna:174]
Cash flows from Investing Activities

[0001437749-18-003245:mdna:175]
Net cash used in investing activities increased $467.1 million in 2016 compared to 2015 primarily due to the acquisitions of PolySwitch ($344.5 million, net of cash acquired), the ON portfolio business ($104.0 million), and Menber’s ($19.2 million).

[0001437749-18-003245:mdna:176]
Cash flows from Financing Activities

[0001437749-18-003245:mdna:177]
Net cash provided by financing activities increased $351.9 million in 2016 compared to 2015. The increase was primarily due to an increase in net proceeds from debt of $314.8 million in 2016 compared to 2015. In March the company replaced its credit agreement with a new agreement and in December the company received proceeds from the issuance of senior notes. Also contributing to the increase in comparative periods was the use of cash for the share repurchase in 2015 of $31.3 million. Information regarding the company’s debt is provided in Note 6, Debt, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001437749-18-003245:mdna:178]
Capital Resources

[0001437749-18-003245:mdna:179]
The Company expends capital to support its operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0001437749-18-003245:mdna:180]
Share Repurchase Program

[0001437749-18-003245:mdna:181]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2017 to April 30, 2018. The Company did not repurchase any shares of its common stock during fiscal 2017 and the full 1,000,000 shares may yet be purchased under the program as of December 30, 2017.

[0001437749-18-003245:mdna:182]
Contractual Obligations and Commitments

[0001437749-18-003245:mdna:183]
The following table summarizes outstanding contractual obligations and commitments as of December 30, 2017:

[0001437749-18-003245:mdna:184]
| (in thousands) |  | Total |  |  | Less than 1 Year |  |  | 1 to 3 Years |  |  | 3 to 5 Years |  |  | Greater than 5 Years |  |
| Long-term debt(a) |  | $ | 500,492 |  |  | $ | 6,250 |  |  | $ | 12,500 |  |  | $ | 128,750 |  |  | $ | 352,992 |  |
| Interest payments(b) |  |  | 85,973 |  |  |  | 11,809 |  |  |  | 22,697 |  |  |  | 20,597 |  |  |  | 30,870 |  |
| Operating lease payments(c) |  |  | 34,578 |  |  |  | 10,842 |  |  |  | 11,619 |  |  |  | 8,096 |  |  |  | 5,021 |  |
| Income Tax Obligation(d) |  |  | 35,400 |  |  |  | 3,400 |  |  |  | 6,000 |  |  |  | 6,000 |  |  |  | 20,000 |  |
| Purchase obligations(e) |  |  | 27,600 |  |  |  | 27,600 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 685,043 |  |  | $ | 59,901 |  |  | $ | 52,816 |  |  | $ | 163,443 |  |  | $ | 408,883 |  |

[0001437749-18-003245:mdna:185]
|  | (a) | Excludes offsetting issuance costs of $4.9 million. Euro denominated debt amounts are converted based on the Euro to U.S. Dollar spot rate at year end. Excludes funding of $50 million and $125 million from the U.S Senior Notes, Series A due 2025 and U.S. Senior Notes, Series A due 2030, respectively, as these occurred subsequent to December 30, 2017. For more information see Note 6, Debt, of the Notes to the Consolidated Financial Statements. |

[0001437749-18-003245:mdna:186]
|  | (b) | Amounts represent estimated contractual interest payments on outstanding debt. Rates in effect as of December 30, 2017 are used for variable rate debt. For more information see Note 6, Debt, of the Notes to the Consolidated Financial Statements. |

[0001437749-18-003245:mdna:187]
|  | (c) | For more information see Note 5, Lease Commitments, of the Notes to the Consolidated Financial Statements. |

[0001437749-18-003245:mdna:188]
|  | (d) | The Income Tax Obligation represents the current federal and state income tax expense for 2017 including the preliminary estimate of $49 million for the Toll Charge, partially offset by $13 million of foreign tax credits. The Company will elect to pay the 2017 current federal income tax over the eight-year period as prescribed by the Tax Act. For more information see Note 10, Income Taxes, of the Notes to the Consolidated Financial Statements. |

[0001437749-18-003245:mdna:189]
|  | (e) | Purchase obligations include commitments for capital expenditures not recognized in the Company’s Consolidated Balance Sheets. |

[0001437749-18-003245:mdna:190]
In addition to the above contractual obligations and commitments, the Company had the following obligations at December 30, 2017:

[0001437749-18-003245:mdna:191]
The Company has Company-sponsored defined benefit pension plans covering employees at various non-U.S. subsidiaries including the U.K., Germany, the Philippines, China, Japan, Mexico, Italy and France. At December 30, 2017, the Company had a net unfunded status of $19.1 million. The Company expects to make approximately $1.4 million of contributions to the plans in 2018. For additional information, see Note 8, Benefit Plans, of the Notes to the Consolidated Financial Statements.

[0001437749-18-003245:mdna:192]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. As of December 30, 2017, there was $8.0 million of accrued compensation benefits included in Other long-term liabilities. For additional information, see Note 8, Benefit Plans, of the Notes to the Consolidated Financial Statements.

[0001437749-18-003245:mdna:193]
As of December 30, 2017, the Company recognized various accruals related to employee compensation including its annual incentive program that are expected to be paid in 2018.

[0001437749-18-003245:mdna:194]
Due to the uncertainty with respect to the cash outflows, the preceding table excludes unrecognized tax benefits of $7.7 million. The Company does not expect to make significant payments of these liabilities within the next year. For additional information, see Note 10, Income Taxes, of the Notes to the Consolidated Financial Statements.

[0001437749-18-003245:mdna:195]
Off-Balance Sheet Arrangements

[0001437749-18-003245:mdna:196]
As of December 30, 2017, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-18-003245:mdna:197]
Recent Accounting Pronouncements

[0001437749-18-003245:mdna:198]
Recently issued accounting standards and their estimated effect on the Company’s Consolidated Financial Statements are described in Note 1, Summary of Significant Accounting Policies and Other Information, of the Notes to the Consolidated Financial Statements.
