# LFUS note change history — 0001437749-17-013580 → 0001437749-17-018040


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-11-01):
[0001437749-17-018040:note_history:1]
Littelfuse, Inc. and subsidiaries (the “
Company”) is 
one
 of the world’s leading designer, manufacturer and supplier of circuit protection products, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s products protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.

- changed (2017-11-01):
[0001437749-17-018040:note_history:2]
The 
Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December
  (was, 2017-08-02, similarity 0.9938):
[0001437749-17-013580:note_history:2]
The 
Company’s accompanying unaudited Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

- changed (2017-11-01):
[0001437749-17-018040:note_history:3]
Factors the 
Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does 
not
 believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the Relays reporting unit if there are declines in profitability or projected future operating results and cash flows due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October 2, 2016, 
the Company concluded the fair value of the Relays reporting unit exceeded its carrying value of invested capital and therefore, 
no
 potential goodwill impairment existed. As of the 
2016
 annual test date, the Relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 September 30, 2017, 
there were 
no
 events or circumstances that indicate the Relays intangible assets were impaired.
  (was, 2017-08-02, similarity 0.923):
[0001437749-17-013580:note_history:3]
Factors the 
Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does 
not
 believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the Relays reporting unit if there are declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October 2, 2016, 
the Company concluded the fair value of the Relays reporting unit exceeded its carrying value of invested capital and therefore, 
no
 potential goodwill impairment existed. As of the 
2016
 annual test date, the Relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 July 1, 2017, 
there were 
no
 events or circumstances that indicate the Relays intangible assets were impaired.

- added (2017-11-01):
[0001437749-17-018040:note_history:4]
In the 
third
 quarter of 
2016,
 due to continued declines in the potash market the Company conducted a goodwill impairment analysis of the Custom Products reporting unit and concluded that the 
reporting unit was impaired. The fair value of the unit was estimated using the expected present value of future cash flows over a 
seven
 year forecast period and appraisal of certain assets. This analysis required a write down of the reporting unit’s carrying value of 
$14.8
 million. A goodwill impairment loss of 
$8.8
 million and intangible assets impairments aggregating 
$6.0
 million were recognized during the 
third
 quarter, including a 
$3.8
 million reduction of the custom products trade names to a 
$0.7
 million remaining value and a 
$2.2
 million reduction of the reporting unit’s customer relationships to 
zero
 value.

- changed (2017-11-01):
[0001437749-17-018040:note_history:5]
Recently Adopted Accounting Standards
  (was, 2017-08-02, similarity 0.7018):
[0001437749-17-013580:note_history:5]
Accounting Standards

- changed (2017-11-01):
[0001437749-17-018040:note_history:6]
2015
-
11
 – “Inventory (Topic 
330
): Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
The adoption of the update did 
not
 have a material impact on the Company’s consolidated financial position and results of operations. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.
  (was, 2017-08-02, similarity 0.9798):
[0001437749-17-013580:note_history:6]
2015
-
11
 – “Inventory (Topic 
330
): Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
The adoption of the update did 
not
 have a material impact on the Company’s consolidated financial statements. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

- changed (2017-11-01):
[0001437749-17-018040:note_history:7]
– “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Condensed Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
As a result of the adoption, on a prospective basis, the Company recognized 
$0.1
 million and 
$1.9
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 and 
nine
 months ended 
 September 30, 2017, 
respectively. Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Condensed Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Condensed Consolidated Statement of Cash Flows. The Company elected 
not
 to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had 
no
 impact on the results of operations.
  (was, 2017-08-02, similarity 0.9733):
[0001437749-17-013580:note_history:7]
– “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
As a result of the adoption, on a prospective basis, the Company recognized 
$1.4
 million and 
$1.9
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 and 
six
 months ended 
 July 1, 2017, 
respectively. Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Consolidated Statement of Cash Flows. The Company elected 
not
 to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had 
no
 impact on the results of operations.

- added (2017-11-01):
[0001437749-17-018040:note_history:8]
In 
 March 2017, 
the FASB issued ASU

- added (2017-11-01):
[0001437749-17-018040:note_history:9]
No.

- added (2017-11-01):
[0001437749-17-018040:note_history:10]
2017
-
07
 “Compensation-Retirement Benefits (Topic 
715
): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changes the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the current guidance, net benefit cost is reported as an employee cost within operating income. The amendment requires the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU 
No.

- added (2017-11-01):
[0001437749-17-018040:note_history:11]
2017
-
07
 will be effective for the 
first
 quarter of 
2018
 and is required to be retrospectively adopted. Had this guidance been adopted as of 
 January 1, 2017, 
operating income within the Condensed Consolidated Statements of Income for the 
three
 months and 
nine
 months ended 
 September 30, 2017 
would have 
not
 changed by a material amount.

- added (2017-11-01):
[0001437749-17-018040:note_history:12]
In 
 January 2016, 
the FASB issued ASU 
No.

- added (2017-11-01):
[0001437749-17-018040:note_history:13]
2016
-
01,
 “
Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU will require the Company to recognize any changes in the fair value of certain equity investments in net income. These changes are currently recognized in other comprehensive income ("OCI"). This guidance is effective for interim and fiscal years beginning after 
 December 15, 2017.

- changed (2017-11-01):
[0001437749-17-018040:note_history:14]
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted on the original effective date of fiscal years beginning after 
 December 15, 2016. 
The Company is in the process of performing its assessment of the potential impact on its consolidated financial statements, and anticipates adopting this standard using the modified retrospective method. While the Company is currently assessing the impact of the new standard, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does 
not
 expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may 
be affected. The Company has 
not
 yet quantified this potential impact.
  (was, 2017-08-02, similarity 0.9569):
[0001437749-17-013580:note_history:14]
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted on the original effective date of fiscal years beginning after 
 December 15, 2016. 
The Company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements, and currently anticipates adopting this standard using the modified retrospective method. While the Company is currently assessing the impact of the new standards, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does 
not
 expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may 
be affected. The Company has 
not
 yet quantified this potential impact.

- changed (2017-11-01):
[0001437749-17-018040:note_history:15]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition, however the Company plans to adopt the standard in the 
first
 quarter of 
2019.
 The Company is currently evaluating the impact of ASU 
2016
-
02.
  (was, 2017-08-02, similarity 0.7958):
[0001437749-17-013580:note_history:15]
2016
-
02,
 "Leases" (Topic 
842
). This
 ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company is currently evaluating the impact of this ASU on its consolidated financial statements.

- removed (2017-11-01):
[0001437749-17-013580:note_history:16]
Littelfuse, Inc. and subsidiaries (the “
Company”) design, manufacture, and sell circuit protection devices for use in the automotive, electronics, and industrial markets throughout the world. The Company is 
one
 of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.

- removed (2017-11-01):
[0001437749-17-013580:note_history:17]
Recently

- removed (2017-11-01):
[0001437749-17-013580:note_history:18]
Adopted


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-01):
[0001437749-17-018040:note_history:19]
September 30, 2017 
and 
 December 31, 2016 
were as follows:
  (was, 2017-08-02, similarity 0.8182):
[0001437749-17-013580:note_history:19]
July 1, 2017 
and 
 December 31, 2016 
are as follows:

- changed (2017-11-01):
[0001437749-17-018040:note_history:20]
| (in thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | 15,000 |  |  | $ | 112,500 |  |
| Term loan |  |  | 115,625 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | — |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 137,670 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 111,784 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,432 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 501,647 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (9,375 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 492,272 |  |  | $ | 447,892 |  |
  (was, 2017-08-02, similarity 0.7902):
[0001437749-17-013580:note_history:20]
| (in thousands) |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 117,188 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 1,179 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 133,497 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 108,395 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,567 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 481,692 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (7,813 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 473,879 |  |  | $ | 447,892 |  |

- added (2017-11-01):
[0001437749-17-018040:note_history:21]
On 
 October 13, 2017, 
the Company amended its existing 
Credit Agreement to increase the unsecured revolving credit facility from 
$575.0
 million to 
$700.0
 million and increase the unsecured term loan credit facility from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term loans 
 may 
be made in up to 
two
 advances, the 
first
 advance occurring on 
 October 13, 2017 
and the 
second
 advance, in the aggregate amount 
not
 to exceed 
$75.0
 million, to occur in the 
first
 quarter of 
2018.

- changed (2017-11-01):
[0001437749-17-018040:note_history:22]
Outstanding borrowings under the credit agreement bear interest, at the 
Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.73%
 at 
 September 30, 2017.
  (was, 2017-08-02, similarity 0.9855):
[0001437749-17-013580:note_history:22]
Outstanding borrowings under the credit agreement bear interest, at the 
Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.72%
 at 
 July 1, 2017.

- added (2017-11-01):
[0001437749-17-018040:note_history:23]
September 30, 2017, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$559.9
 million of borrowing capacity under the revolving credit facility. At 
 September 30, 2017, 
the Company was in compliance with all covenants under the credit agreement and expects to remain in compliance based on management’s estimates of operating and financial results for 
2017
 and the foreseeable future.

- changed (2017-11-01):
[0001437749-17-018040:note_history:24]
The Senior Notes are subject to certain customary covenants, including limitations on the 
Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 September 30, 2017, 
the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.
  (was, 2017-08-02, similarity 0.943):
[0001437749-17-013580:note_history:24]
The Senior Notes are subject to certain customary covenants, including limitations on the 
Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 July 1, 2017, 
the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.

- changed (2017-11-01):
[0001437749-17-018040:note_history:25]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan was reflected as both a long-term asset and long-term debt on the Company’s Condensed Consolidated Balance Sheets and was reflected in the investing and financing activities in its Condensed Consolidated Statements of Cash Flows. Interest expense and interest income are recorded between the lender and borrower with 
no
 net impact on the Company’s Condensed Consolidated Statements of Income since the amounts were offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan was used to finance the operation and working capital needs of the borrower and was scheduled to mature in 
 November 2019. 
The balance of the Entrusted Loan was paid off as of 
 September 30, 2017.
  (was, 2017-08-02, similarity 0.8829):
[0001437749-17-013580:note_history:25]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the Company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with 
no
 net impact on the Company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in 
 November 2019. 
The balance of the Entrusted Loan was

- removed (2017-11-01):
[0001437749-17-013580:note_history:26]
July 1, 2017, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$574.9
 million of borrowing capacity under the revolving credit facility. At 
 July 1, 2017, 
the Company was in compliance with all covenants under the credit agreement.

- removed (2017-11-01):
[0001437749-17-013580:note_history:27]
Chinese renminbi 
8.0
 million (approximately U.S. 
$1.2
 million) at 
 July 1, 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-01):
[0001437749-17-018040:note_history:28]
| (in thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | 15,000 |  |  | $ | 112,500 |  |
| Term loan |  |  | 115,625 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | — |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 137,670 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 111,784 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,432 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 501,647 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (9,375 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 492,272 |  |  | $ | 447,892 |  |
  (was, 2017-08-02, similarity 0.7902):
[0001437749-17-013580:note_history:28]
| (in thousands) |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 117,188 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 1,179 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 133,497 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 108,395 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,567 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 481,692 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (7,813 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 473,879 |  |  | $ | 447,892 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-11-01):
[0001437749-17-013580:note_history:29]
11

- removed (2017-11-01):
[0001437749-17-013580:note_history:30]
) Subsequent Event

- removed (2017-11-01):
[0001437749-17-013580:note_history:31]
On

- removed (2017-11-01):
[0001437749-17-013580:note_history:32]
July 6, 2017, 
the company completed the acquisition of U.S. Sensor Corp. headquartered in California. The purchase price of 
$24.0
 million is subject to a working capital adjustment and was financed primarily by cash on hand. The acquired business, which will be part of the company's Electronics segment, will contribute to the expansion of the Company’s existing sensor platform portfolio with a range of high-quality temperature sensor products.
