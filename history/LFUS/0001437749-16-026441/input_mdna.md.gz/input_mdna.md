# LFUS MD&A — 0001437749-16-026441


## mdna

[0001437749-16-026441:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS. |

[0001437749-16-026441:mdna:2]
Littelfuse Overview

[0001437749-16-026441:mdna:3]
Introduction

[0001437749-16-026441:mdna:4]
Littelfuse, Inc. and its subsidiaries (the “company” or “Littelfuse” or “we” or “our”) is the worldwide leader in circuit protection offering the industry's broadest and deepest portfolio of circuit protection products and solutions. The company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment. The company conducts its business through three reportable segments, which are defined by markets and consist of Electronics, Automotive, and Industrial (formerly Electrical). The company’s customer base includes original equipment manufacturers, tier one automotive suppliers and distributors.

[0001437749-16-026441:mdna:5]
In addition to protecting and growing its core circuit protection business, Littelfuse has been investing in power control and sensing technologies. These newer platforms, combined with the company’s strong balance sheet and operating cash flow, provide opportunities for increased organic and acquisition growth. In 2012, the company set a five-year strategic target plan to grow annual sales at 15% per year; 5% organically and 10% through acquisitions. As of January 2, 2016, three years into the five-year plan, the company has achieved an annual sales growth of 9%; 4% organically and 5% through acquisitions.

[0001437749-16-026441:mdna:6]
In November, 2015, the company announced its planned acquisition of TE Connectivity’s circuit protection devices business (“CPD”) which is expected to close by the end of the first quarter of 2016. The company believes that the pending acquisition of the CPD business in 2016 puts the company on track with the five-year growth targets set in 2012 as described above.

[0001437749-16-026441:mdna:7]
The company remains focused on only those acquisitions that will add shareholder value. Overall, the company believes its strategy is sound, the fundamentals of its business have not changed, and its long-term goals are achievable.

[0001437749-16-026441:mdna:8]
To maximize shareholder value, the company’s primary strategic goals are to:

[0001437749-16-026441:mdna:9]
|  | ● | Grow organically faster than its markets; |

[0001437749-16-026441:mdna:10]
|  | ● | Continue the pace of acquisitions; |

[0001437749-16-026441:mdna:11]
|  | ● | Sustain operating margins in the high teens; |

[0001437749-16-026441:mdna:12]
|  | ● | Improve return on investment; and |

[0001437749-16-026441:mdna:13]
|  | ● | Return excess cash to shareholders. |

[0001437749-16-026441:mdna:14]
The company serves markets that are directly impacted by global economic trends with significant exposures to the consumer electronics, automotive, industrial and mining end markets. The company’s results will be impacted positively or negatively by changes in these end markets.

[0001437749-16-026441:mdna:15]
Electronics Segment Overview

[0001437749-16-026441:mdna:16]
The Electronics segment, which accounted for approximately 47% of total sales in 2015, has produced modest revenue growth and strong operating margins over the last few years. In 2015, sales decreased 1% (a 2% increase excluding currency effects) and operating margins were 19.0% for 2015 as compared to 21.2% in 2014. Strong sales in both Europe and China helped to offset continued adjustments in channel inventory and capacity constraints for electronic sensor products as the company continues to transfer production to the Philippines. The company believes the revenue growth is the result of a stable electronics market combined with ongoing design wins and market share gains for Littelfuse.

[0001437749-16-026441:mdna:17]
The electronics business is affected by seasonality. Sales are typically weaker in the first and fourth quarters and stronger in the second quarter and third quarters. This reflects the production ramp-up for consumer electronics in advance of the year-end holidays and other factors.

[0001437749-16-026441:mdna:18]
Fourth quarter 2015 sales for Electronics were consistent with normal seasonality as channel inventories remain at appropriate levels. The book-to-bill ratio of 1.00 at the end of the fourth quarter is also consistent with normal seasonal trends.

[0001437749-16-026441:mdna:19]
Automotive Segment Overview

[0001437749-16-026441:mdna:20]
The Automotive segment, which accounted for approximately 39% of sales in 2015, has been the company’s fastest growing business over the last few years. In 2015, Automotive sales increased 4% (11% excluding currency effects) primarily resulting from a strong performance in automotive sensor sales which increased 20% over the prior year.

[0001437749-16-026441:mdna:21]
Passenger car fuse sales continue to outperform global car production due primarily to the success of the company’s new high current fuses which are driving increases in content per vehicle. Automotive sensors also had its third consecutive year of double-digit sales growth primarily reflecting ramp-up of new solar sensor and speed and position sensor platforms. The company continues to make good progress on its objective to improve sensor margins by growing the business and replacing low margin legacy business with more profitable design wins.

[0001437749-16-026441:mdna:22]
In summary, 2015 was a record year for the Automotive segment. Growth in fuse content was driven by more sophisticated electronics in vehicles and sales of our high-current products, especially the MasterfuseTM line. Our automotive sensor business had an excellent year, with strong growth in sales and a significant improvement in margins. For the CVP business, the main contributor to sales was the North American heavy duty truck market.

[0001437749-16-026441:mdna:23]
Industrial Segment Overview

[0001437749-16-026441:mdna:24]
The Industrial segment, which accounted for approximately 14% of total sales in 2015, experienced an improved performance in 2015 with sales increasing 5% (9% excluding currency effects) over the prior year with strong sales in power fuses and continued improvement in the custom business more than offsetting a decline in relay sales. The increase in fuse sales was due to continuing strength in the solar market, as well as distributors increasing purchases after working down inventories in response to the weak end markets. Within the custom business, the company has diversified its portfolio beyond the potash market and into e-houses used in the heavy industrial and utility markets.

[0001437749-16-026441:mdna:25]
In summary, 2015 was a good year for the Industrial segment overall. The business saw a rebound in electrical fuse sales and margins, with fuse sales into the solar market almost doubling. It also made progress in diversifying the custom products and relay businesses beyond potash mining.

[0001437749-16-026441:mdna:26]
Business Acquisitions

[0001437749-16-026441:mdna:27]
On October 1, 2015, the company acquired 100% of Sigmar S.r.l. (“Sigmar”) for $5.4 million (net of cash acquired). Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel and selective catalytic reduction (SCR) quality sensors, as well as diesel fuel heaters, solenoid valves and rotating oil filters for automotive and commercial vehicle applications. The acquisition further expands the company’s automotive sensor product line offerings within its Automotive business segment.

[0001437749-16-026441:mdna:28]
On January 3, 2014, the company acquired 100% of SymCom, Inc. (“SymCom”) for $52.8 million (net of cash acquired). Located in Rapid City, South Dakota, SymCom provides overload relays and pump controllers primarily to the industrial market. The acquisition allows the company to strengthen its position in the relay products market by adding new products and new customers within its Industrial business segment.

[0001437749-16-026441:mdna:29]
Business Segment Information

[0001437749-16-026441:mdna:30]
U.S. Generally Accepted Accounting Principles (“GAAP”) dictates annual and interim reporting standards for an enterprise's operating segments and related disclosures about its products, services, geographic areas and major customers. Within U.S. GAAP, an operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer.

[0001437749-16-026441:mdna:31]
The following table is a summary of the company’s business unit segments’ net sales by business unit and geography (in millions):

[0001437749-16-026441:mdna:32]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics(b) |  | $ | 405.5 |  |  | $ | 410.1 |  |  | $ | 367.1 |  |
| Automotive(c) |  |  | 340.0 |  |  |  | 325.4 |  |  |  | 267.2 |  |
| Industrial(g) |  |  | 122.4 |  |  |  | 116.5 |  |  |  | 123.6 |  |
| Total |  | $ | 867.9 |  |  | $ | 852.0 |  |  | $ | 757.9 |  |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas(d)(g) |  | $ | 401.2 |  |  | $ | 377.7 |  |  | $ | 342.4 |  |
| Europe(e) |  |  | 152.7 |  |  |  | 163.9 |  |  |  | 136.8 |  |
| Asia-Pacific(f) |  |  | 314.0 |  |  |  | 310.4 |  |  |  | 278.7 |  |
| Total |  | $ | 867.9 |  |  | $ | 852.0 |  |  | $ | 757.9 |  |

[0001437749-16-026441:mdna:33]
|  | (a) | Sales by geography represent sales to customer or distributor locations. |

[0001437749-16-026441:mdna:34]
|  | (b) | 2014 includes incremental Hamlin net sales of $36.5 million. |

[0001437749-16-026441:mdna:35]
|  | (c) | 2014 includes incremental Hamlin net sales of $20.2 million. |

[0001437749-16-026441:mdna:36]
|  | (d) | 2014 includes incremental Hamlin net sales of $16.7 million. |

[0001437749-16-026441:mdna:37]
|  | (e) | 2014 includes incremental Hamlin net sales of $9.3 million. |

[0001437749-16-026441:mdna:38]
|  | (f) | 2014 includes incremental Hamlin net sales of $10.4 million. |

[0001437749-16-026441:mdna:39]
|  | (g) | 2014 includes incremental SymCom net sales of $19.6 million. |

[0001437749-16-026441:mdna:40]
Business segment information is described more fully in Note 15 of the Notes to Consolidated Financial Statements. The following discussion provides an analysis of the information contained in the Consolidated Financial Statements and accompanying Notes to Consolidated Financial Statements at January 2, 2016 and December 27, 2014, and for the three fiscal years ended January 2, 2016, December 27, 2014 and December 28, 2013.

[0001437749-16-026441:mdna:41]
Results of Operations — 2015 compared with 2014

[0001437749-16-026441:mdna:42]
The following table summarizes the company’s consolidated results of operations for the periods presented. There were additional charges incurred during 2015. These included $4.6 million in acquisition-related costs primarily related to the transaction and integration planning costs for the pending acquisition of TE Connectivity’s circuit protection device business, $5.2 million in charges related to the transfer of the company’s reed switch manufacturing operations from its Lake Mills, Wisconsin and Suzhou, China locations to the Philippines, $3.6 million in internal restructuring costs that will improve the company’s worldwide legal structure and $31.9 million in pension settlement and wind-up costs.

[0001437749-16-026441:mdna:43]
Fiscal year 2015 also included $1.5 million in foreign currency gains primarily attributable to changes in the value of both the euro and Philippine peso against the U.S. dollar while fiscal year 2014 included $3.9 million in foreign currency losses primarily related to the value of the Philippine peso against the dollar.

[0001437749-16-026441:mdna:44]
|  |  | Fiscal Year |  |  |  |  |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Sales |  | $ | 867,864 |  |  | $ | 851,995 |  |  |  | 2% |  |
| Gross profit |  |  | 330,499 |  |  |  | 324,428 |  |  |  | 2% |  |
| Operating expenses |  |  | 226,342 |  |  |  | 190,598 |  |  |  | 19% |  |
| Operating income |  |  | 104,157 |  |  |  | 133,830 |  |  |  | (22%) |  |
| Other expense (income), net |  |  | (5,417 | ) |  |  | (6,644 | ) |  |  | (18%) |  |
| Income before income taxes |  |  | 106,948 |  |  |  | 131,646 |  |  |  | (19%) |  |
| Net income |  | $ | 82,466 |  |  | $ | 99,418 |  |  |  | (17%) |  |

[0001437749-16-026441:mdna:45]
26

[0001437749-16-026441:mdna:46]
Net sales increased $15.9 million or 2% to $867.9 million for fiscal year 2015 compared to $852.0 million in fiscal year 2014 due primarily to strong growth in automotive products and improvement in the Industrial business segment partially offset by lower Electronics sales. The company also experienced $38.9 million in unfavorable foreign currency effects in 2015 as compared to 2014 primarily resulting from sales denominated in the euro. Excluding currency effects, net sales increased $54.7 million or 6% year-over-year. The Automotive business segment sales increased $14.5 million or 4% to $340.0 million. The Electronics business segment sales decreased $4.6 million or 1% to $405.5 million, and the Industrial business segment sales increased $5.9 million or 5% to $122.4 million. Sales levels in 2015, excluding currency effects, were positively impacted by increased demand for the company’s automotive and industrial products partially offset by lower demand for the company’s electronics products.

[0001437749-16-026441:mdna:47]
The increase in Automotive sales was primarily due to strong growth for automotive sensor products. Sales in the commercial vehicle market were up slightly year-over-year as continued strength in the heavy truck market was offset by general market weakness in construction, agriculture and the global mining industry. Automotive sales were negatively impacted by net unfavorable currency effects of $22.4 million in 2015 as compared to 2014 primarily resulting from sales denominated in the euro. Excluding currency effects, Automotive sales increased $37.0 million or 11% year-over-year.

[0001437749-16-026441:mdna:48]
The decrease in Electronics sales primarily resulted from net unfavorable currency effects of $11.7 million for the full year 2015. Excluding currency effects, Electronics sales increased $7.2 million or 2% year-over-year reflecting solid growth for passive components offset by lower sensor sales. Strong sales of electronic products in Europe and China helped to offset continued adjustments in channel inventory and capacity constraints for our electronic sensor products as the company continues to transfer production from the U.S. and China to the Philippines.

[0001437749-16-026441:mdna:49]
The increase in Industrial sales was primarily from higher custom and power fuse sales which were offset by lower relay sales. The Industrial segment experienced net unfavorable currency effects of $4.7 million primarily from sales denominated in Canadian dollars and the euro. Excluding currency effects, Industrial sales increased $10.6 million or 9% year over year. The increase in fuse sales is primarily due to continuing strength in the solar market, while higher custom product sales benefited from some recovery in the potash mining end market.

[0001437749-16-026441:mdna:50]
On a geographic basis, sales in the Americas increased $23.5 million or 6% in 2015 as compared to 2014 due primarily to growth in all business segments offset by $3.6 million in unfavorable currency effects resulting from sales denominated in Canadian dollars. Excluding currency effects, Americas’ sales increased $27.1 million or 7%. Automotive sales increased $15.1 million or 9% primarily reflecting strong growth in the automotive sensor and passenger vehicle markets. Electronics sales increased $3.2 million or 3% primarily reflecting higher demand for passive products. Industrial sales increased $5.2 million or 5% resulting from increases in demand for power fuses and custom products.

[0001437749-16-026441:mdna:51]
European sales decreased $11.3 million or 7% in 2015 compared to 2014 primarily due to net unfavorable currency effects of $32.8 million primarily from sales denominated in the euro. Excluding currency effects, European sales increased $21.5 million or 13% reflecting strong demand across all business segments. Automotive sales decreased $6.9 million or 7% in 2015 reflecting net unfavorable currency effects. Excluding currency effects, Automotive sales increased $14.2 million or 13% reflecting strong demand for automotive sensor products. Electronics sales decreased $3.7 million or 7% reflecting the impact of net unfavorable currency effects. Excluding currency effects, Electronics sales increased $6.6 million or 13% reflecting strong demand for semiconductor products. Industrial sales decreased $0.7 million or 10% in 2015 primarily from the impact of net unfavorable currency effects. Excluding currency effects, Industrial sales increased $0.7 million or 10%.

[0001437749-16-026441:mdna:52]
Asia-Pacific sales increased $3.6 million or 1% in 2015 compared to 2014 primarily due to increased demand for Automotive and Industrial products offset by lower Electronics sales. Net unfavorable currency effects amounted to $2.5 million. Excluding currency effects, Asia-Pacific sales increased $6.1 million or 2%. Electronics sales decreased $4.1 million or 2% reflecting weakness in the Taiwan, Japan and Korea markets. Automotive sales increased $6.4 million or 11% reflecting continued increased demand for passenger vehicles in China as well as gains in market share. Industrial sales increased $1.4 million or 19%.

[0001437749-16-026441:mdna:53]
Gross profit was $330.5 million or 38.1% of sales in 2015, compared to $324.4 million or 38.1% of sales in 2014. Gross profit for 2015 was negatively impacted by $5.3 million of charges related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines. Gross profit for 2014 was negatively impacted by $2.8 million for accounting adjustments related to the SymCom inventory which had been stepped up to fair value at the acquisition date as required by purchase accounting rules. Additionally, 2014 gross profit was negatively impacted by $2.7 million in severance charges. These severance charges primarily related to post-Hamlin acquisition reorganization changes. Excluding the impact of these charges, gross profit was $335.8 million or 38.7% of sales in 2015 as compared to $329.9 million or 38.7% of sales in 2014.

[0001437749-16-026441:mdna:54]
Total operating expense was $226.3 million or 26.1% of net sales for 2015 compared to $190.6 million or 22.4% of net sales for 2014. Operating expense in 2015 included $39.9 million of charges primarily related to pension settlement and wind-up costs of $31.9 million and restructuring and acquisition costs of $8.0 million. Operating expense in 2014 included $3.5 million in restructuring, acquisition and impairment costs, $2.2 million of which was to effect changes in the company’s legal structure to allow tax-efficient repatriation of cash. Excluding these charges, total operating expense was $186.4 million or 21.5% of net sales for 2015 compared to $187.1 million or 22.0% of net sales in 2014.

[0001437749-16-026441:mdna:55]
Operating income was $104.2 million or 12.0% of net sales in 2015 compared to $133.8 million or 15.7% of net sales in the prior year. The decrease in operating income in the current year was due primarily to the factors affecting operating expenses discussed above.

[0001437749-16-026441:mdna:56]
Interest expense was $4.1 million in 2015 as compared to $4.9 million in 2014 and is primarily related to the company’s increased borrowing to fund acquisitions. The lower interest expense in 2015 resulted from lower average debt balances as compared to the prior year.

[0001437749-16-026441:mdna:57]
Foreign exchange (gain) loss was $1.5 million of gain in 2015 compared to $3.9 million of loss in 2014. The fluctuation in foreign exchange was primarily attributable to changes in the value of both the euro and the Philippine peso against the U.S. dollar in 2015 and 2014.

[0001437749-16-026441:mdna:58]
Other expense (income), net, consisting of interest income, royalties and non-operating income was $5.4 million of income in 2015 compared to $6.6 million of income in 2014. The year-over-year decrease in income primarily reflects lower interest income in 2015.

[0001437749-16-026441:mdna:59]
Income before income taxes was $106.9 million in 2015 compared to $131.6 million in 2014. Income tax expense was $24.5 million in 2015 compared to $32.2 million in 2014. The 2015 effective income tax rate was 22.9% compared to 24.5% in 2014. The lower effective tax rate in 2015 is primarily related to more income earned in low-tax jurisdictions in 2015 as compared to 2014. The effective tax rates are lower than the U.S. statutory tax rate primarily as a result of income earned in low-tax jurisdictions.

[0001437749-16-026441:mdna:60]
Results of Operations — 2014 compared with 2013

[0001437749-16-026441:mdna:61]
The following table summarizes the company’s consolidated results of operations for the periods presented. The results include incremental activity from the company’s business acquisitions as described, where applicable, in the below analysis. There were also additional charges and accounting adjustments during 2014. These include a $2.8 million inventory adjustment in 2014 related to the SymCom acquisition as described in Note 2, $0.4 million in acquisition-related costs, $3.2 million in severance charges related to the Lake Mills, Wisconsin and Matamoros, Mexico locations, $2.2 million in internal legal restructuring costs that will improve the company’s worldwide legal structure and $0.3 million in asset impairments.

[0001437749-16-026441:mdna:62]
Fiscal year 2014 also included $3.9 million in foreign currency losses primarily attributable to changes in the value of both the euro and Philippine peso against the U.S. dollar while fiscal year 2013 included $3.3 million in foreign currency gains primarily related to the value of the Philippine peso against the U.S. dollar.

[0001437749-16-026441:mdna:63]
|  |  | Fiscal Year |  |  |  |  |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Sales |  | $ | 851,995 |  |  | $ | 757,853 |  |  |  | 12 | % |
| Gross profit |  |  | 324,428 |  |  |  | 296,232 |  |  |  | 10 | % |
| Operating expenses |  |  | 190,598 |  |  |  | 166,351 |  |  |  | 15 | % |
| Operating income |  |  | 133,830 |  |  |  | 129,881 |  |  |  | 3 | % |
| Other expense (income), net |  |  | (6,644 | ) |  |  | (4,646 | ) |  |  | 43 | % |
| Income before income taxes |  |  | 131,646 |  |  |  | 124,235 |  |  |  | 6 | % |
| Net income |  | $ | 99,418 |  |  | $ | 88,784 |  |  |  | 12 | % |

[0001437749-16-026441:mdna:64]
Net sales increased $94.1 million or 12% to $852.0 million for fiscal year 2014 compared to $757.9 million in fiscal year 2013 due primarily to an incremental $56.1 million from business acquisitions and growth in electronic and automotive products, offset by lower Industrial sales. The company also experienced $0.4 million in unfavorable foreign currency effects in 2014 as compared to 2013 primarily resulting from sales denominated in Canadian dollars and Japanese yen. During the fourth quarter of 2014, sales were negatively impacted by the steep decline in the euro. Excluding acquisitions and currency effects, net sales increased $38.5 million or 5% year over year. The Automotive business segment sales increased $58.2 million or 22% to $325.4 million. The Electronics business segment sales increased $43.0 million or 12% to $410.1 million, and the Industrial business segment sales decreased $7.1 million or 6% to $116.5 million. Sales levels in 2014, excluding acquisitions and currency effects, were positively impacted by increased demand for the company’s automotive and electronic products partially offset by slowing demand for the company’s industrial products.

[0001437749-16-026441:mdna:65]
The increase in Automotive sales was primarily due to strong organic growth in all product categories and an incremental $20.2 million in sales from Hamlin. Currency effects increased sales by $0.6 million for the full year 2014 compared to 2013. Excluding incremental sales from Hamlin and currency effects, Automotive sales increased $37.3 million or 14% year over year due primarily to increases in content per vehicle and strength in the heavy truck market.

[0001437749-16-026441:mdna:66]
The increase in Electronics sales reflected solid growth for both semiconductor and passive components and incremental sales from Hamlin of $16.3 million. In addition, sales were positively impacted by net favorable currency effects of $0.2 million for the full year 2014. Excluding acquisitions and currency effects, Electronics sales increased $26.5 million or 7% year over year.

[0001437749-16-026441:mdna:67]
29

[0001437749-16-026441:mdna:68]
The decrease in Industrial sales was primarily from declines in custom and relay sales into the mining market and power fuses into the solar market. These declines more than offset incremental sales of $19.6 million from the SymCom acquisition in 2014. The Industrial segment experienced net unfavorable currency effects of $1.3 million primarily from sales denominated in Canadian dollars. Excluding incremental sales and currency effects, Industrial sales decreased $25.4 million or 21% year over year.

[0001437749-16-026441:mdna:69]
On a geographic basis, sales in the Americas increased $35.3 million or 10% in 2014 as compared to 2013 due primarily to incremental sales from business acquisitions of $36.3 million offset by $1.4 million in unfavorable currency effects resulting from sales denominated in Canadian dollars. Excluding acquisitions and currency effects, Americas’ sales increased $0.4 million or less than 1%. Increases in the company’s Automotive and Electronics sales were mostly offset by a decline in Industrial sales. Automotive sales increased $33.4 million or 26% primarily reflecting incremental sales from acquisitions of $12.5 million, strong growth in the passenger vehicle market and growth in the commercial vehicle market. Electronics sales increased $9.6 million or 9% primarily reflecting higher demand and incremental sales from Hamlin of $4.3 million. Industrial sales decreased $7.7 million or 7% resulting from decreases in demand for protection relays and custom products due to continued weakness in the mining segment. This decrease more than offset $19.6 million in incremental sales from SymCom in 2014.

[0001437749-16-026441:mdna:70]
European sales increased $27.1 million or 20% in 2014 compared to 2013 primarily due to strong demand for electronics and automotive products, incremental sales from Hamlin of $9.4 million and $1.0 million in favorable currency effects from sales denominated in euros. Excluding acquisitions and currency effects, European sales increased $16.8 million or 12%. This resulted from increases in the company’s Electronics and Automotive sales partially offset by a decrease in Industrial sales. Automotive sales increased $18.2 million or 21% in 2014 primarily reflecting incremental sales from Hamlin sensors of $6.2 million and higher sales in the passenger vehicle markets driven primarily by increased content. Excluding the impact of incremental sales from Hamlin and favorable currency effects, Automotive sales increased $11.5 million or 13%. Electronics sales increased $9.2 million or 22% reflecting incremental sales from Hamlin of $3.2 million and higher demand in 2014. Industrial sales decreased $0.3 million or 4% in 2014 primarily from decreased demand in the marine market for relays.

[0001437749-16-026441:mdna:71]
Asia-Pacific sales increased $31.7 million or 11% in 2014 compared to 2013 primarily due to increased demand across all product categories and incremental sales from Hamlin of $10.4 million. Currency effects amounted to less than $0.1 million. Excluding acquisitions and currency effects, Asia-Pacific sales increased $21.3 million or 8%. Electronics sales increased $24.2 million or 11% reflecting incremental sales from Hamlin of $8.9 million and increased sales in China offset by weakness in the Taiwan, Japan and Korea markets. Automotive sales increased $6.6 million or 12% reflecting incremental sales from acquisitions of $1.5 million and continued increased demand for passenger vehicles in China as well as gains in market share.

[0001437749-16-026441:mdna:72]
Gross profit was $324.4 million or 38.1% of sales in 2014, compared to $296.2 million or 39.1% of sales in 2013. Gross profit in both 2014 and 2013 were negatively impacted by purchase accounting adjustments in cost of sales of $2.8 million and $1.5 million, respectively. These charges were the additional cost of goods sold for SymCom and Hamlin inventories which had been stepped up to fair value at the acquisition dates as required by purchase accounting rules. Additionally, 2014 gross profit was negatively impacted by $2.7 million in severance charges. These severance charges primarily related to post-Hamlin acquisition reorganization changes. Excluding the impact of these charges, gross profit was $329.9 million or 38.7% of sales as compared to $297.8 million or 39.3% of sales in 2013. The decrease in gross margin was primarily attributable to higher sales of sensors in 2014 which carry lower margins than the company’s core products.

[0001437749-16-026441:mdna:73]
Total operating expense was $190.6 million or 22.4% of net sales for 2014 compared to $166.4 million or 22.0% of net sales for 2013. The increase in operating expenses primarily reflects incremental operating expenses of $14.2 million from business acquisitions and $3.5 million in restructuring, acquisition and impairment costs, $2.2 million of which was to effect changes in the company’s legal structure to allow tax-efficient repatriation of approximately $90.0 million of cash in the fourth quarter of 2014.

[0001437749-16-026441:mdna:74]
Operating income was $133.8 million or 15.7% of net sales in 2014 compared to $129.9 million or 17.1% of net sales in the prior year. The increase in operating income and decrease in operating margin in the current year was due primarily to the factors affecting gross profit and operating expenses discussed above.

[0001437749-16-026441:mdna:75]
Interest expense was $4.9 million in 2014 as compared to $2.9 million in 2013 and is primarily related to the company’s increased borrowing to fund acquisitions.

[0001437749-16-026441:mdna:76]
Impairment and equity in net loss of unconsolidated affiliate was $10.7 million in 2013. During the first quarter of 2013, the company fully impaired its investment in and loan receivable from Shocking Technologies, Inc. (“Shocking”) as described in Note 6 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:mdna:77]
Foreign exchange (gain) loss was $3.9 million of loss in 2014 compared to $3.3 million of gain in 2013. The fluctuation in foreign exchange was primarily attributable to changes in the value of both the euro and the Philippine peso against the U.S. dollar in 2014 and the Philippine peso against the dollar in 2013.

[0001437749-16-026441:mdna:78]
Other expense (income), net, consisting of interest income, royalties and non-operating income was $6.6 million of income in 2014 compared to $4.6 million of income in 2013. The year-over-year increase in income primarily reflects higher interest income in 2014.

[0001437749-16-026441:mdna:79]
Income before income taxes was $131.6 million in 2014 compared to $124.2 million in 2013. Income tax expense was $32.2 million in 2014 compared to $35.5 million in 2013. The 2014 effective income tax rate was 24.5% compared to 28.5% in 2013. The lower effective tax rate in 2014 is primarily related to the $6.1 million Shocking tax adjustment booked in 2013. The 2014 and 2013 effective tax rates are lower than the U.S. statutory tax rate primarily the result of income earned in low-tax jurisdictions.

[0001437749-16-026441:mdna:80]
Liquidity and Capital Resources

[0001437749-16-026441:mdna:81]
As of January 2, 2016, $318.5 million of the $328.8 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $318.5 million held by foreign subsidiaries, approximately $24.6 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $24.6 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-16-026441:mdna:82]
The company historically has financed capital expenditures through cash flows from operations. Management expects that cash flows from operations and available lines of credit will be sufficient to support both the company’s operations and its debt obligations for the foreseeable future.

[0001437749-16-026441:mdna:83]
31

[0001437749-16-026441:mdna:84]
Term Loan and Revolving Credit Facilities

[0001437749-16-026441:mdna:85]
On May 31, 2013, the company entered into a new credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consists of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. At January 2, 2016, the company had available $197.9 million of borrowing capacity under the credit agreement at an interest rate of LIBOR plus 1.25%, or a total interest rate of 1.68% as of January 2, 2016.

[0001437749-16-026441:mdna:86]
The credit agreement replaced the company’s previous credit agreement dated June 13, 2011, which was terminated on May 31, 2013.

[0001437749-16-026441:mdna:87]
On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million.

[0001437749-16-026441:mdna:88]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At January 2, 2016, the company was in compliance with all covenants under the credit agreement.

[0001437749-16-026441:mdna:89]
Entrusted Loan

[0001437749-16-026441:mdna:90]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.5 million) at January 2, 2016.

[0001437749-16-026441:mdna:91]
Other Obligations

[0001437749-16-026441:mdna:92]
For the fiscal year ended January 2, 2016, the company had $0.1 million available in letters of credit. No amounts were drawn under these letters of credit at January 2, 2016.

[0001437749-16-026441:mdna:93]
Cash Flows and Working Capital

[0001437749-16-026441:mdna:94]
The company started 2015 with $297.6 million of cash. Net cash provided by operating activities in 2015 was approximately $165.8 million and included $82.5 million in net income, $82.1 million in non-cash adjustments (primarily $41.6 million in depreciation and amortization) and $1.2 million of favorable changes in operating assets and liabilities.

[0001437749-16-026441:mdna:95]
Changes in operating assets and liabilities (including short-term and long-term items) that negatively impacted cash flows in 2015 consisted of changes in accounts receivable ($14.4 million), inventory ($3.6 million) and accrued taxes ($1.0 million). Increases in accounts receivable and inventory resulted from higher sales volumes in 2015. Positively impacting cash flows were changes in accrued expenses including post-retirement ($6.5 million), accounts payable ($2.6 million), accrued payroll and severance ($5.9 million) and prepaid expenses and other ($5.2 million).

[0001437749-16-026441:mdna:96]
Net cash used in investing activities in 2015 was approximately $44.2 million and included $44.0 million in purchases of property, plant and equipment (primarily production equipment and facilities for capacity expansion and new products at the company’s locations in Piedras Negras, Mexico, Wuxi, China and the Philippines), $3.5 million for the purchase of an investment and $4.6 million for a business acquisition. Offsetting the cash used in investing activities was a $7.8 million decrease in the Entrusted Loan receivable (see Note 7 of the Notes to Consolidated Financial Statements included in this report) and $0.1 million in proceeds from sales of property, plant and equipment.

[0001437749-16-026441:mdna:97]
Net cash used in financing activities in 2015 was approximately $67.7 million, which included $23.1 million in net payments of debt, $1.9 million in excess tax benefits on share-based compensation and $9.2 million in cash proceeds from the exercise of stock options. The company also repurchased $31.3 million of its own stock in 2015. Additionally the company paid cash dividends of $24.3 million during the year. Information regarding the company’s debt is provided in Note 7 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:mdna:98]
The effect of exchange rate changes decreased cash by $22.8 million in 2015. The net cash provided by operating activities less net cash used in financing and provided by investing activities plus the effect of exchange rate changes, resulted in a $31.2 million increase in cash and cash equivalents in 2015. This left the company with a cash balance of $328.8 million at January 2, 2016.

[0001437749-16-026441:mdna:99]
Days sales outstanding (DSO) in accounts receivable was 59 days at year-end 2015 compared to 60 days at year-end 2014 and 59 days at year-end 2013. Days inventory outstanding was 65 days at year-end 2015, compared to 68 days at year-end 2014 and 70 days at year-end 2013.

[0001437749-16-026441:mdna:100]
The ratio of current assets to current liabilities was 2.8 to 1 at year-end 2015, compared to 2.7 to 1 at year-end 2014 and 2.7 to 1 at year-end 2013. The change in the current ratio at the end of 2015 compared to the prior year reflected increased current assets in 2015, primarily related to higher cash balances. The carrying amounts of total debt decreased $23.1 million in 2015, compared to a decrease of $24.6 million in 2014 and an increase of $135.8 million in 2013. The decrease in 2015 was due to higher net payments under the revolving credit facility in 2015. The ratio of long-term debt to equity was 0.11 to 1 at year-end 2015 compared to 0.15 to 1 at year-end 2014 and 0.14 to 1 at year-end 2013. Further information regarding the company’s debt is provided in Note 7 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:mdna:101]
The company started 2014 with $305.2 million of cash. Net cash provided by operating activities in 2014 was approximately $153.1 million and included $99.4 million in net income and $47.8 million in non-cash adjustments (primarily $41.9 million in depreciation and amortization), and $5.9 million of favorable changes in operating assets and liabilities.

[0001437749-16-026441:mdna:102]
Changes in operating assets and liabilities (including short-term and long-term items) that negatively impacted cash flows in 2014 consisted of changes in accounts receivable ($13.1 million), inventory ($2.3 million), accrued expenses including post-retirement ($1.6 million) and accrued taxes ($0.5 million). Increases in accounts receivable and inventory resulted from higher sales volumes in 2014. Accrued expenses including post-retirement included pension contributions of $9.9 million in 2014 and $5.0 million in 2013. Positively impacting cash flows were changes in accounts payable ($17.3 million), accrued payroll and severance ($2.4 million) and prepaid expenses and other ($3.7 million). The increase in accounts payable primarily resulted from large capital purchases in December 2014 and the lengthening of vendor payment terms.

[0001437749-16-026441:mdna:103]
The company’s capital expenditures were $44.0 million in 2015, $32.3 million in 2014 and $35.0 million in 2013.

[0001437749-16-026441:mdna:104]
The company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2015 to April 30, 2016. The company repurchased 350,000 shares of its common stock during 2015 under this program and 650,000 shares may yet be purchased under the program as of January 2, 2016. The company withheld 28,286 shares of stock in lieu of withholding taxes on behalf of employees who became vested in restricted stock option grants during 2015.

[0001437749-16-026441:mdna:105]
Contractual Obligations and Commitments

[0001437749-16-026441:mdna:106]
The following table summarizes contractual obligations and commitments as of January 2, 2016:

[0001437749-16-026441:mdna:107]
| (In thousands ) |  | Total |  |  | < 1 Year |  |  | > 1 - < 3 Years |  |  | > 3 - < 5 Years |  |  | > 5 Years |  |
| Term loan |  | $ | 85,000 |  |  | $ | 10,000 |  |  | $ | 75,000 |  |  | $ | — |  |  | $ | — |  |
| Revolving credit facility |  |  | 77,000 |  |  |  | 77,000 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Entrusted loan |  |  | 9,474 |  |  |  | — |  |  |  | — |  |  |  | 9,474 |  |  |  | — |  |
| Interest payments |  |  | 3,098 |  |  |  | 1,365 |  |  |  | 1,733 |  |  |  | — |  |  |  | — |  |
| Supplemental Executive |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Retirement Plan |  |  | 2,461 |  |  |  | 31 |  |  |  | 1,880 |  |  |  | 63 |  |  |  | 487 |  |
| Operating lease payments |  |  | 34,639 |  |  |  | 8,886 |  |  |  | 9,211 |  |  |  | 6,521 |  |  |  | 10,021 |  |
| Purchase obligations |  |  | 51,658 |  |  |  | 51,658 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 263,330 |  |  | $ | 148,940 |  |  | $ | 87,824 |  |  | $ | 16,058 |  |  | $ | 10,508 |  |

[0001437749-16-026441:mdna:108]
Off-Balance Sheet Arrangements

[0001437749-16-026441:mdna:109]
As of January 2, 2016, the company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the company was not liable for guarantees of indebtedness owed by third parties, the company was not directly liable for the debt of any unconsolidated entity and the company did not have any retained or contingent interest in assets. The company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-16-026441:mdna:110]
Recent Accounting Pronouncements

[0001437749-16-026441:mdna:111]
In November 2015, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2015-17 – Income taxes (Topic 740): Balance Sheet Classification of Deferred Taxes which amends the presentation of deferred income tax liabilities and assets to be classified as noncurrent in a classified statement of financial position. The amendments in the ASU are effective for financial statements issued for annual periods beginning after December 15, 2016. The company has adopted the new standard on January 2, 2016 and has restated the presentation of deferred income taxes on its comparative Consolidated Balance Sheets as of December 27, 2014 to reflect the change.

[0001437749-16-026441:mdna:112]
In May 2014, the FASB amended prior authoritative guidance for revenue recognition which provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The standard is effective for public entities for annual and interim periods beginning after December 15, 2016. Early adoption is not permitted. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The company is currently evaluating the impact of the adoption of this accounting standard on its consolidated financial statements.

[0001437749-16-026441:mdna:113]
Critical Accounting Policies and Estimates

[0001437749-16-026441:mdna:114]
Certain of the accounting policies as discussed below require the application of significant judgment by management in selecting the appropriate estimates and assumptions for calculating amounts to record in the financial statements. Actual results could differ from those estimates and assumptions, impacting the reported results of operations and financial position. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report. Certain accounting policies, however, are considered to be critical in that they are most important to the depiction of the company’s financial condition and results of operations and their application requires management’s subjective judgment in making estimates about the effect of matters that are inherently uncertain. The company believes the following accounting policies are the most critical to aid in fully understanding and evaluating its reported financial results, as they require management’s most difficult, subjective or complex judgments, resulting from the need to make estimates about the effect of matters that are inherently uncertain. The company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors.

[0001437749-16-026441:mdna:115]
Net Sales

[0001437749-16-026441:mdna:116]
Revenue Recognition: The company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured and the pricing is fixed and determinable. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The company’s distribution channels are primarily through direct sales and independent third party distributors.

[0001437749-16-026441:mdna:117]
Revenue and Billing: The company accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the company’s published price lists. The customer is invoiced when the company’s products are shipped to them in accordance with the terms of the sales agreement.

[0001437749-16-026441:mdna:118]
Returns and Credits: Some of the terms of the company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-16-026441:mdna:119]
Return to Stock: The company has a return to stock policy whereby a customer with previous authorization from Littelfuse management can return previously purchased goods for full or partial credit. The company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0001437749-16-026441:mdna:120]
Volume Rebates: The company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-16-026441:mdna:121]
Allowance for Doubtful Accounts: The company evaluates the collectability of its trade receivables based on a combination of factors. The company regularly analyzes its significant customer accounts and, when the company becomes aware of a specific customer’s inability to meet its financial obligations, the company records a specific reserve for bad debt to reduce the related receivable to the amount the company reasonably believes is collectible. The company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0001437749-16-026441:mdna:122]
Inventory

[0001437749-16-026441:mdna:123]
The company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life and quality issues. Based on the analysis, the company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable values. During 2014, the company was required to step up the value of inventory acquired in business combinations to its selling prices less the cost to sell under business combination accounting. This step-up was approximately $2.8 million for SymCom in 2014.

[0001437749-16-026441:mdna:124]
Goodwill and Other Intangible Assets

[0001437749-16-026441:mdna:125]
The company annually tests goodwill for impairment on the first day of its fiscal fourth quarter or at an interim date if there is an event or change in circumstances that indicates the asset may be impaired. The company has eight reporting units for goodwill testing purposes. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted five-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after five years) to estimate market value. In addition, the company compares its derived enterprise value on a consolidated basis to the company’s market capitalization as of its test date to ensure its derived value approximates the market value of the company when taken as a whole.

[0001437749-16-026441:mdna:126]
As of the most recent annual test conducted on September 27, 2015, the company concluded the fair value of each of the reporting units exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. Specifically, the company noted that its headroom, defined as the excess of fair value over the carrying value of invested capital, was 148%, 95%, 188%, 218%, 76%, 26%, 12% and 198% for its reporting units; electronics (non-silicon), electronics (silicon), passenger car, commercial vehicle products, sensors, relays, custom products and power fuse, respectively, at September 27, 2015.

[0001437749-16-026441:mdna:127]
Certain key assumptions used in the annual test included a discount rate of 11.7% and a long-term growth rate of 3.0% which were used for all reporting units except for automotive sensor and relay which had a discount rate of 13.7% as a result of a 2.0% premium factor and custom products which had a discount rate of 14.7% as a result of a 3.0% premium factor.

[0001437749-16-026441:mdna:128]
In addition, the company performed a sensitivity test at September 27, 2015 that showed either a 100 basis point increase in its discount rate or a 100 basis point decrease in the long-term growth rate for each reporting unit would not have changed the company’s conclusion that no potential goodwill impairment existed at September 27, 2015.

[0001437749-16-026441:mdna:129]
The company will continue to perform a goodwill impairment test as required on an annual basis and on an interim basis, if certain conditions exist. Factors the company considers important, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the company does not believe its future operating results will vary significantly relative to its historical and projected future operating results.

[0001437749-16-026441:mdna:130]
Long-Lived Assets

[0001437749-16-026441:mdna:131]
The company evaluates long-lived asset groups on an ongoing basis. Long-lived asset groups are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the related asset may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of the asset to future undiscounted cash flows expected to be generated by the asset group. If it is determined to be impaired, the impairment recognized is measured by the amount by which the carrying value of the asset exceeds its fair value. The company’s estimates of future cash flows from such assets could be impacted if it underperforms relative to historical or projected future operating results. The company recorded asset impairment charges of $0.0 million, $0.3 million and $0.0 million for the fiscal years ended 2015, 2014 and 2013, respectively. Further information regarding asset impairments is provided in Note 11 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:mdna:132]
Environmental Liabilities

[0001437749-16-026441:mdna:133]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The company evaluates its reserve for coal mine remediation annually utilizing a third party expert.

[0001437749-16-026441:mdna:134]
Pension and Supplemental Executive Retirement Plan

[0001437749-16-026441:mdna:135]
Littelfuse has a number of company-sponsored defined benefit plans primarily in Europe and the Asia-Pacific region. The company recognizes the full unfunded status of these plans on the balance sheet. Actuarial gains and losses and prior service costs and credits are recognized as a component of accumulated other comprehensive income. Accounting for pensions requires estimating the future benefit cost and recognizing the cost over the employee’s expected period of employment with the company. Certain assumptions are required in the calculation of pension costs and obligations. These assumptions include the discount rate, salary scales and the expected long-term rate of return on plan assets. The discount rate is intended to represent the rate at which pension benefit obligations could be settled by purchase of an annuity contract. These assumptions are subject to change based on stock and bond market returns and other economic factors. Actual results that differ from the company’s assumptions are accumulated and amortized over future periods and, therefore, generally affect its recognized expense and accrued liability in such future periods. While the company believes that its assumptions are appropriate given current economic conditions and its actual experience, significant differences in results or significant changes in the company’s assumptions may materially affect its pension obligations and related future expense. During 2015, the company settled its U.S. defined benefit pension plan as described in Note 12 of the Notes to Consolidated Financial Statements included in this report. Further information regarding these plans is also provided in Note 12 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:mdna:136]
Equity-based Compensation

[0001437749-16-026441:mdna:137]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments in the foreseeable future.

[0001437749-16-026441:mdna:138]
Total equity-based compensation expense for all equity compensation plans was $10.7 million, $9.4 million, and $8.9 million in 2015, 2014, and 2013, respectively. Further information regarding this expense is provided in Note 13 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:mdna:139]
Income Taxes

[0001437749-16-026441:mdna:140]
The company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. Federal and state income taxes are provided on the portion of foreign income that is expected to be remitted to the U.S. and be taxable.

[0001437749-16-026441:mdna:141]
The company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001437749-16-026441:mdna:142]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:mdna:143]
Outlook

[0001437749-16-026441:mdna:144]
Sales for the first quarter of 2016 are expected to be in the range of $213.0 to $223.0 million which represents 4% revenue growth over the prior quarter at the midpoint of the range (approximately 6% growth excluding currency effects). Despite concerns about the global economy and weakness in some of its end markets, the company believes it can grow revenue in the low to mid single digits in 2016. Assuming modest top-line growth, the company believes it can expand its operating margin by approximately 150 basis points compared to 2015 as it benefits from completion of its footprint consolidation projects, further progress on automotive sensor profitability initiatives and continued gains in manufacturing performance.

[0001437749-16-026441:mdna:145]
The company expects capital expenditures in 2016 to be in the range of $40 to $45 million, primarily for capacity to support volume increases, new product introductions and restructuring activities. The company expects to fund 2016 capital expenditures from operating cash flows.
