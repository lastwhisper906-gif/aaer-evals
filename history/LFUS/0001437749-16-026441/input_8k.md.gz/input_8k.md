# LFUS 8-K — 0001437749-16-024462 filed 2016-02-02

## item codes, every 8-K on or before 2016-03-01

- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2016-03-01

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-024462:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-024462:8k_2_02:2]
ex99-1.htm

[0001437749-16-024462:8k_2_02:3]
Exhibit 99.1

[0001437749-16-024462:8k_2_02:4]
| NEWS RELEASE |  |

[0001437749-16-024462:8k_2_02:5]
CONTACT: Phil Franklin,

[0001437749-16-024462:8k_2_02:6]
Executive Vice President and CFO (773) 628-0810

[0001437749-16-024462:8k_2_02:7]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS

[0001437749-16-024462:8k_2_02:8]
Fourth Quarter Sales and Earnings at the High End of Guidance

[0001437749-16-024462:8k_2_02:9]
CHICAGO, February 2, 2016 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the fourth quarter and full year ended January 2, 2016.

[0001437749-16-024462:8k_2_02:10]
Fourth Quarter Highlights

[0001437749-16-024462:8k_2_02:11]
|  | ● | Sales for the fourth quarter of 2015 were $220.0 million, which was 6% growth over the prior-year quarter. Excluding currency effects, sales increased 10% compared to the prior-year quarter due to continued strong growth in the automotive segment and continued improvement in the electrical segment. |
|  | ● | GAAP earnings for the fourth quarter of 2015 were $1.00 per diluted share. This included $5.7 million of special charges primarily related to transaction and integration planning costs for the pending acquisition of TE Connectivity’s circuit protection devices (“CPD”) business and the transfer of reed switch production to the Philippines. Excluding these special items, adjusted earnings for the fourth quarter of 2015 were $1.21 per diluted share, representing a 19% increase over the prior-year quarter. |
|  | ● | The fourth quarter of 2015 included an extra week (14 weeks rather than 13). The impact of the extra week was approximately $9 million in revenue and $0.02 cents per diluted share, which was consistent with the fourth quarter guidance. |
|  | ● | Highlights by segment included: |

[0001437749-16-024462:8k_2_02:12]
|  | o | Electronics sales grew 2% year over year (4% excluding currency effects) as growth in passive and semiconductor products was partially offset by lower sensor sales due to capacity constraints related to the Philippines transfer. |
|  | o | Automotive sales increased 10% year over year (16% excluding currency effects) reflecting strong growth across all three geographies. |
|  | o | Electrical sales increased 12% year over year (17% excluding currency effects) due to strong growth in the core fuse business and continued recovery in custom products. |

[0001437749-16-024462:8k_2_02:13]
-more-

[0001437749-16-024462:8k_2_02:14]
|  | ● | The electronics book-to-bill ratio for the fourth quarter of 2015 was 1.00. |
|  | ● | As announced in November, the company signed a definitive agreement to acquire the CPD business of TE Connectivity and is on track to close the acquisition by the end of the first quarter of 2016. |

[0001437749-16-024462:8k_2_02:15]
|  | Full Year 2015 Highlights |
|  | ● | Sales for full year of 2015 were $867.9 million, which was 2% growth over the prior year and a 6% increase excluding currency effects. |
|  | ● | GAAP earnings for the full year 2015 were $3.63 per diluted share. Adjusted earnings per diluted share were $5.05, which was 6% growth over the prior year. |
|  | ● | Cash provided by operating activities was $166 million for the full year 2015 compared to $153 million in the prior year. Capital expenditures were $44 million for the year compared to $32 million in 2014. The increased capital spending in 2015 was primarily due to capacity expansion for new automotive programs and the Philippines manufacturing transfer. |

[0001437749-16-024462:8k_2_02:16]
“This was without question a challenging year, with substantial macroeconomic headwinds and volatility in currency and commodity markets,” said Gordon Hunter, chief executive officer. "Despite these challenges, our teams executed well across many fronts and delivered record performance for sales, adjusted earnings and cash flow. This strong 2015 performance, coupled with the pending acquisition of the CPD business, puts us on track with the five-year growth target we set at the end of 2012.”

[0001437749-16-024462:8k_2_02:17]
Outlook

[0001437749-16-024462:8k_2_02:18]
All comments below relate to the company’s existing businesses and do not include any effects from the pending CPD acquisition.

[0001437749-16-024462:8k_2_02:19]
“We head into 2016 with good momentum and the groundwork laid for substantial margin improvement,” said Phil Franklin, chief financial officer. “Despite concerns about the global economy and weakness in some of our end markets, we believe we can grow revenue in the low to mid single digits in 2016. Assuming modest top-line growth, we believe we can expand our operating margin by approximately 150 basis points compared to 2015 as we benefit from completion of our footprint consolidation projects, further progress on automotive sensor profitability initiatives and continued gains in manufacturing performance.”

[0001437749-16-024462:8k_2_02:20]
|  | ● | Sales for the first quarter of 2016 are expected to be in the range of $213 to $223 million, which represents 4% revenue growth over the prior quarter at the midpoint (6% growth excluding currency effects). |

[0001437749-16-024462:8k_2_02:21]
-more-

[0001437749-16-024462:8k_2_02:22]
|  | ● | Earnings for the first quarter of 2016 are expected to be in the range of $1.21 to $1.35 per diluted share, excluding special items. |
|  | ● | The 2016 full year tax rate is expected to be approximately 22%. |
|  | ● | Capital expenditures for the full year 2016 are expected to be in the range of $40 to $45 million. |

[0001437749-16-024462:8k_2_02:23]
Dividend

[0001437749-16-024462:8k_2_02:24]
The company will pay a cash dividend of $0.29 per common share on March 10, 2016 to shareholders of record at the close of business on February 25, 2016.

[0001437749-16-024462:8k_2_02:25]
Conference Call and Webcast Information

[0001437749-16-024462:8k_2_02:26]
Littelfuse will host a conference call today, Tuesday, February 2, 2016, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the fourth quarter and full year 2015 results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay through March 31, 2016 on the company’s website.

[0001437749-16-024462:8k_2_02:27]
About Littelfuse

[0001437749-16-024462:8k_2_02:28]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 8,000 employees in more than 35 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: www.littelfuse.com.

[0001437749-16-024462:8k_2_02:29]
| “Safe Harbor” Statement under the Private Securities Litigation Reform Act of 1995. The statements in this press release that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended December 27, 2014. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended December 27, 2014. |

[0001437749-16-024462:8k_2_02:30]
###

[0001437749-16-024462:8k_2_02:31]
LITTELFUSE, INC.

[0001437749-16-024462:8k_2_02:32]
Net Sales and Operating Income by Business Segment

[0001437749-16-024462:8k_2_02:33]
(In thousands of USD, unaudited)

[0001437749-16-024462:8k_2_02:34]
|  |  | Fourth Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 97,948 |  |  | $ | 96,339 |  |  |  | 2 | % |  | $ | 405,497 |  |  | $ | 410,065 |  |  |  | (1% | ) |
| Automotive |  |  | 88,493 |  |  |  | 80,332 |  |  |  | 10 | % |  |  | 339,957 |  |  |  | 325,415 |  |  |  | 4 | % |
| Industrial |  |  | 33,579 |  |  |  | 29,949 |  |  |  | 12 | % |  |  | 122,410 |  |  |  | 116,515 |  |  |  | 5 | % |
| Total net sales |  | $ | 220,020 |  |  | $ | 206,620 |  |  |  | 6 | % |  | $ | 867,864 |  |  | $ | 851,995 |  |  |  | 2 | % |

[0001437749-16-024462:8k_2_02:35]
|  |  | Fourth Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 16,439 |  |  | $ | 16,176 |  |  |  | 2 | % |  | $ | 78,194 |  |  | $ | 86,981 |  |  |  | (10% | ) |
| Automotive |  |  | 13,963 |  |  |  | 9,928 |  |  |  | 41 | % |  |  | 53,086 |  |  |  | 45,086 |  |  |  | 18 | % |
| Industrial |  |  | 4,874 |  |  |  | 3,133 |  |  |  | 56 | % |  |  | 18,094 |  |  |  | 10,674 |  |  |  | 70 | % |
| Other (1) |  |  | (5,422 | ) |  |  | (2,846 | ) |  |  | 91 | % |  |  | (45,217 | ) |  |  | (8,911 | ) |  |  | 407 | % |
| Total operating income |  | $ | 29,854 |  |  | $ | 26,391 |  |  |  | 13 | % |  | $ | 104,157 |  |  | $ | 133,830 |  |  |  | (22% | ) |
| Interest expense |  |  | 1,070 |  |  |  | 1,167 |  |  |  |  |  |  |  | 4,091 |  |  |  | 4,903 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | 259 |  |  |  | 1,903 |  |  |  |  |  |  |  | (1,465 | ) |  |  | 3,925 |  |  |  |  |  |
| Other (income) expense, net |  |  | (1,659 | ) |  |  | (1,751 | ) |  |  |  |  |  |  | (5,417 | ) |  |  | (6,644 | ) |  |  |  |  |
| Income before taxes |  | $ | 30,184 |  |  | $ | 25,072 |  |  |  | 20 | % |  | $ | 106,948 |  |  | $ | 131,646 |  |  |  | (19% | ) |

[0001437749-16-024462:8k_2_02:36]
(1) "Other" includes special items such as acquisition-related costs, restructuring costs, gains and losses on asset sales and the U.S. Pension wind-up. (See Supplemental Financial Information for details on page 8.)

[0001437749-16-024462:8k_2_02:37]
LITTELFUSE, INC.

[0001437749-16-024462:8k_2_02:38]
Condensed Consolidated Balance Sheets

[0001437749-16-024462:8k_2_02:39]
(In thousands of USD, except share amounts)

[0001437749-16-024462:8k_2_02:40]
|  |  | January 2, 2016 |  |  | December 27, 2014 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 328,786 |  |  | $ | 297,571 |  |
| Short-term investments |  |  | 4,179 |  |  |  | 4,302 |  |
| Accounts receivable, less allowances |  |  | 142,882 |  |  |  | 135,356 |  |
| Inventories |  |  | 98,629 |  |  |  | 97,391 |  |
| Prepaid expenses and other current assets |  |  | 8,959 |  |  |  | 13,904 |  |
| Assets held for sale |  |  | - |  |  |  | 5,500 |  |
| Total current assets |  |  | 583,435 |  |  |  | 554,024 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 5,236 |  |  |  | 5,697 |  |
| Buildings |  |  | 71,383 |  |  |  | 64,609 |  |
| Equipment |  |  | 382,429 |  |  |  | 370,179 |  |
|  |  |  | 459,048 |  |  |  | 440,485 |  |
| Accumulated depreciation |  |  | (296,480 | ) |  |  | (281,845 | ) |
| Net property, plant and equipment |  |  | 162,568 |  |  |  | 158,640 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 20,221 |  |  |  | 23,640 |  |
| Distribution network |  |  | 16,490 |  |  |  | 19,428 |  |
| Customer lists, trademarks and tradenames |  |  | 54,912 |  |  |  | 60,605 |  |
| Goodwill |  |  | 189,767 |  |  |  | 196,256 |  |
|  |  |  | 281,390 |  |  |  | 299,929 |  |
| Investments |  |  | 15,197 |  |  |  | 12,056 |  |
| Deferred income taxes |  |  | 8,333 |  |  |  | 22,874 |  |
| Other assets |  |  | 14,058 |  |  |  | 23,303 |  |
| Total assets |  | $ | 1,064,981 |  |  | $ | 1,070,826 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 51,658 |  |  | $ | 50,793 |  |
| Accrued payroll |  |  | 32,611 |  |  |  | 30,511 |  |
| Accrued expenses |  |  | 24,145 |  |  |  | 13,059 |  |
| Accrued severance |  |  | 3,798 |  |  |  | 790 |  |
| Accrued income taxes |  |  | 10,621 |  |  |  | 9,045 |  |
| Current portion of accrued post-retirement benefits |  |  | - |  |  |  | 11,768 |  |
| Current portion of long-term debt |  |  | 87,000 |  |  |  | 88,500 |  |
| Total current liabilities |  |  | 209,833 |  |  |  | 204,466 |  |
| Long-term debt, less current portion |  |  | 84,474 |  |  |  | 106,658 |  |
| Deferred income taxes |  |  | 8,014 |  |  |  | 11,076 |  |
| Accrued post-retirement benefits |  |  | 5,653 |  |  |  | 5,147 |  |
| Other long-term liabilities |  |  | 12,809 |  |  |  | 15,814 |  |
| Total equity |  |  | 744,198 |  |  |  | 727,665 |  |
| Total liabilities and equity |  | $ | 1,064,981 |  |  | $ | 1,070,826 |  |

[0001437749-16-024462:8k_2_02:41]
| Common shares issued and outstanding of 22,420,785 and 22,585,529 at January 2, 2016 and December 27, 2014, respectively. |  |  |  |  |  |  |  |  |

[0001437749-16-024462:8k_2_02:42]
LITTELFUSE, INC.

[0001437749-16-024462:8k_2_02:43]
Consolidated Statements of Comprehensive Income

[0001437749-16-024462:8k_2_02:44]
(In thousands of USD, except per share data)

[0001437749-16-024462:8k_2_02:45]
|  |  | For the Three Months Ended |  |  | For the Twelve Months Ended |  |
|  |  | January 2, 2016 |  |  | December 27, 2014 |  |  | January 2, 2016 |  |  | December 27, 2014 |  |
|  |  | (Unaudited) |  |  |  |  |  |  | (Unaudited) |  |  |  |  |  |
| Net sales |  | $ | 220,020 |  |  | $ | 206,620 |  |  | $ | 867,864 |  |  | $ | 851,995 |  |
| Cost of sales |  |  | 137,314 |  |  |  | 131,061 |  |  |  | 537,365 |  |  |  | 527,567 |  |
| Gross profit |  |  | 82,706 |  |  |  | 75,559 |  |  |  | 330,499 |  |  |  | 324,428 |  |
| Selling, general and administrative expenses |  |  | 41,595 |  |  |  | 37,829 |  |  |  | 153,714 |  |  |  | 146,975 |  |
| Research and development expenses |  |  | 8,578 |  |  |  | 8,289 |  |  |  | 30,802 |  |  |  | 31,122 |  |
| Pension settlement (income) expense |  |  | (266 | ) |  |  | - |  |  |  | 29,928 |  |  |  | - |  |
| Amortization of intangibles |  |  | 2,945 |  |  |  | 3,050 |  |  |  | 11,898 |  |  |  | 12,501 |  |
|  |  |  | 52,852 |  |  |  | 49,168 |  |  |  | 226,342 |  |  |  | 190,598 |  |
| Operating income |  |  | 29,854 |  |  |  | 26,391 |  |  |  | 104,157 |  |  |  | 133,830 |  |
| Interest expense |  |  | 1,070 |  |  |  | 1,167 |  |  |  | 4,091 |  |  |  | 4,903 |  |
| Foreign exchange loss (gain) |  |  | 259 |  |  |  | 1,903 |  |  |  | (1,465 | ) |  |  | 3,925 |  |
| Other (income) expense, net |  |  | (1,659 | ) |  |  | (1,751 | ) |  |  | (5,417 | ) |  |  | (6,644 | ) |
| Income before income taxes |  |  | 30,184 |  |  |  | 25,072 |  |  |  | 106,948 |  |  |  | 131,646 |  |
| Income taxes |  |  | 7,721 |  |  |  | 5,561 |  |  |  | 24,482 |  |  |  | 32,228 |  |
| Net income |  | $ | 22,463 |  |  | $ | 19,511 |  |  | $ | 82,466 |  |  | $ | 99,418 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.00 |  |  | $ | 0.86 |  |  | $ | 3.65 |  |  | $ | 4.41 |  |
| Diluted |  | $ | 1.00 |  |  | $ | 0.86 |  |  | $ | 3.63 |  |  | $ | 4.37 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,403 |  |  |  | 22,563 |  |  |  | 22,565 |  |  |  | 22,543 |  |
| Diluted |  |  | 22,564 |  |  |  | 22,729 |  |  |  | 22,719 |  |  |  | 22,727 |  |
| Comprehensive income |  | $ | 12,025 |  |  | $ | 19,511 |  |  | $ | 57,921 |  |  | $ | 57,875 |  |

[0001437749-16-024462:8k_2_02:46]
LITTELFUSE, INC.

[0001437749-16-024462:8k_2_02:47]
Consolidated Statements of Cash Flows

[0001437749-16-024462:8k_2_02:48]
(In thousands of USD)

[0001437749-16-024462:8k_2_02:49]
|  |  | For the Twelve Months Ended |  |
|  |  | January 2, 2016 |  |  | December 27, 2014 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 82,466 |  |  | $ | 99,418 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 29,701 |  |  |  | 29,374 |  |
| Amortization of intangibles |  |  | 11,977 |  |  |  | 12,501 |  |
| Impairment of assets |  |  | - |  |  |  | 293 |  |
| Provision for bad debts |  |  | 164 |  |  |  | 130 |  |
| Non-cash inventory charge (1) |  |  | - |  |  |  | 2,769 |  |
| Stock-based compensation |  |  | 10,266 |  |  |  | 9,069 |  |
| Excess tax benefit on stock-based compensation |  |  | (1,891 | ) |  |  | (2,843 | ) |
| Net loss on pension settlement, net of tax |  |  | 19,308 |  |  |  | - |  |
| Loss on sale of assets |  |  | 1,253 |  |  |  | 1,042 |  |
| Deferred income taxes |  |  | 11,479 |  |  |  | (4,488 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (14,377 | ) |  |  | (13,062 | ) |
| Inventories |  |  | (3,577 | ) |  |  | (2,258 | ) |
| Accounts payable |  |  | 2,573 |  |  |  | 17,281 |  |
| Accrued expenses (including post retirement) |  |  | 6,482 |  |  |  | (1,577 | ) |
| Accrued payroll and severance |  |  | 5,883 |  |  |  | 2,360 |  |
| Accrued taxes |  |  | (1,043 | ) |  |  | (549 | ) |
| Prepaid expenses and other |  |  | 5,162 |  |  |  | 3,681 |  |
| Net cash provided by operating activities |  |  | 165,826 |  |  |  | 153,141 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (4,558 | ) |  |  | (56,368 | ) |
| Purchase of short-term investments |  |  | - |  |  |  | (4,331 | ) |
| Purchase of investments |  |  | (3,500 | ) |  |  | - |  |
| Proceeds from maturities of short-term investments |  |  | - |  |  |  | 6,770 |  |
| Decrease (increase) in entrusted loan receivable |  |  | 7,811 |  |  |  | (17,908 | ) |
| Purchases of property, plant and equipment |  |  | (44,019 | ) |  |  | (32,281 | ) |
| Proceeds from sale of assets |  |  | 102 |  |  |  | 125 |  |
| Net cash used in investing activities |  |  | (44,164 | ) |  |  | (103,993 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from debt |  |  | 49,000 |  |  |  | 97,500 |  |
| Payments of term debt |  |  | (8,750 | ) |  |  | (5,000 | ) |
| Payments of revolving credit facility |  |  | (55,500 | ) |  |  | (135,000 | ) |
| Proceeds from entrusted loan |  |  | - |  |  |  | 17,908 |  |
| Payments of entrusted loan |  |  | (7,811 | ) |  |  | - |  |
| Proceeds from exercise of stock options |  |  | 9,150 |  |  |  | 14,061 |  |
| Debt issuance costs paid |  |  | (42 | ) |  |  | (107 | ) |
| Cash dividends paid |  |  | (24,341 | ) |  |  | (21,175 | ) |
| Purchases of common stock |  |  | (31,252 | ) |  |  | (14,283 | ) |
| Excess tax benefit on share-based compensation |  |  | 1,891 |  |  |  | 2,843 |  |
| Net cash used in financing activities |  |  | (67,655 | ) |  |  | (43,253 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (22,792 | ) |  |  | (13,516 | ) |
| Increase (decrease) in cash and cash equivalents |  |  | 31,215 |  |  |  | (7,621 | ) |
| Cash and cash equivalents at beginning of period |  |  | 297,571 |  |  |  | 305,192 |  |
| Cash and cash equivalents at end of period |  | $ | 328,786 |  |  | $ | 297,571 |  |

[0001437749-16-024462:8k_2_02:50]
(1) Purchase accounting adjustment related to acquisitions.

[0001437749-16-024462:8k_2_02:51]
LITTELFUSE, INC.

[0001437749-16-024462:8k_2_02:52]
Supplemental Financial Information

[0001437749-16-024462:8k_2_02:53]
(in millions of USD except per share amounts)

[0001437749-16-024462:8k_2_02:54]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-15 |  |  | Q2-15 |  |  | Q3-15 |  |  | Q4-15 |  |  | YTD-15 |  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | Q4-14 |  |  | YTD-14 |  |
| GAAP diluted EPS |  | $ | 0.88 |  |  | $ | 1.26 |  |  | $ | 0.50 |  |  | $ | 1.00 |  |  | $ | 3.63 |  |  | $ | 1.12 |  |  | $ | 1.08 |  |  | $ | 1.32 |  |  | $ | 0.86 |  |  | $ | 4.37 |  |
| EPS impact of special items (below) |  |  | 0.20 |  |  |  | 0.07 |  |  |  | 0.93 |  |  |  | 0.21 |  |  |  | 1.42 |  |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.03 |  |  |  | 0.16 |  |  |  | 0.41 |  |
| Adjusted diluted EPS |  | $ | 1.08 |  |  | $ | 1.33 |  |  | $ | 1.43 |  |  | $ | 1.21 |  |  | $ | 5.05 |  |  | $ | 1.16 |  |  | $ | 1.26 |  |  | $ | 1.35 |  |  | $ | 1.02 |  |  | $ | 4.78 |  |
| Year-over-year adjusted EPS growth |  |  | (7% | ) |  |  | 6 | % |  |  | 6 | % |  |  | 19 | % |  |  | 6 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special Items (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.2 |  |  | $ | 2.1 |  |  | $ | 5.2 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Restructuring |  |  | 1.2 |  |  |  | 1.7 |  |  |  | 0.9 |  |  |  | (0.1 | ) |  |  | 3.6 |  |  |  | - |  |  |  | 2.0 |  |  |  | 1.1 |  |  |  | 2.2 |  |  |  | 5.3 |  |
| Impairment charges |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Acquisition expenses |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 4.0 |  |  |  | 4.6 |  |  |  | - |  |  |  | 0.2 |  |  |  | - |  |  |  | 0.3 |  |  |  | 0.5 |  |
| U.S. pension wind-up and settlement costs |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 30.8 |  |  |  | (0.3 | ) |  |  | 31.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Purchase accounting adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.4 |  |  |  | 1.4 |  |  |  | - |  |  |  | - |  |  |  | 2.8 |  |
| Other |  |  | - |  |  |  | - |  |  |  | 0.1 |  |  |  | (0.3 | ) |  |  | (0.2 | ) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Adjustment to operating income |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 33.4 |  |  |  | 5.4 |  |  |  | 45.2 |  |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 2.8 |  |  |  | 8.9 |  |
| Foreign exchange loss/(gain) |  |  | 3.1 |  |  |  | (1.3 | ) |  |  | (3.5 | ) |  |  | 0.3 |  |  |  | (1.5 | ) |  |  | (0.3 | ) |  |  | 2.4 |  |  |  | (0.1 | ) |  |  | 1.9 |  |  |  | 3.9 |  |
| Adjustment to pre-tax income |  | $ | 6.1 |  |  | $ | 2.1 |  |  | $ | 29.8 |  |  | $ | 5.7 |  |  | $ | 43.8 |  |  | $ | 1.2 |  |  | $ | 6.0 |  |  | $ | 1.0 |  |  | $ | 4.7 |  |  | $ | 12.8 |  |
| Total EPS impact |  | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 0.93 |  |  | $ | 0.21 |  |  | $ | 1.42 |  |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.03 |  |  | $ | 0.16 |  |  | $ | 0.41 |  |

[0001437749-16-024462:8k_2_02:55]
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-15 |  |  | Q2-15 |  |  | Q3-15 |  |  | Q4-14 |  |  | YTD-15 |  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | Q4-14 |  |  | YTD-14 |  |
| Net sales |  | $ | 210.3 |  |  | $ | 222.0 |  |  | $ | 215.5 |  |  | $ | 220.0 |  |  | $ | 867.9 |  |  | $ | 206.9 |  |  | $ | 220.9 |  |  | $ | 217.6 |  |  | $ | 206.6 |  |  | $ | 852.0 |  |
| GAAP operating income |  | $ | 29.5 |  |  | $ | 36.2 |  |  | $ | 8.6 |  |  | $ | 29.9 |  |  | $ | 104.2 |  |  | $ | 33.6 |  |  | $ | 33.7 |  |  | $ | 40.1 |  |  | $ | 26.4 |  |  | $ | 133.8 |  |
| GAAP operating margin |  |  | 14.0 | % |  |  | 16.3 | % |  |  | 4.0 | % |  |  | 13.6 | % |  |  | 12.0 | % |  |  | 16.2 | % |  |  | 15.3 | % |  |  | 18.4 | % |  |  | 12.8 | % |  |  | 15.7 | % |
| Add back special operating items |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 33.4 |  |  |  | 5.4 |  |  |  | 45.2 |  |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 2.8 |  |  |  | 8.9 |  |
| Adjusted operating income |  | $ | 32.5 |  |  | $ | 39.6 |  |  | $ | 42.0 |  |  | $ | 35.3 |  |  | $ | 149.4 |  |  | $ | 35.0 |  |  | $ | 37.2 |  |  | $ | 41.3 |  |  | $ | 29.2 |  |  | $ | 142.7 |  |
| Adjusted operating margin |  |  | 15.5 | % |  |  | 17.8 | % |  |  | 19.5 | % |  |  | 16.0 | % |  |  | 17.2 | % |  |  | 16.9 | % |  |  | 16.8 | % |  |  | 19.0 | % |  |  | 14.1 | % |  |  | 16.7 | % |
| Add back amortization |  |  | 3.1 |  |  |  | 2.9 |  |  |  | 3.0 |  |  |  | 3.0 |  |  |  | 11.9 |  |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 12.6 |  |
| Add back depreciation |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 7.5 |  |  |  | 29.7 |  |  |  | 7.0 |  |  |  | 7.5 |  |  |  | 7.3 |  |  |  | 7.6 |  |  |  | 29.3 |  |
| Adjusted EBITDA |  | $ | 43.0 |  |  | $ | 49.9 |  |  | $ | 52.4 |  |  | $ | 45.8 |  |  | $ | 191.0 |  |  | $ | 45.2 |  |  | $ | 47.8 |  |  | $ | 51.8 |  |  | $ | 39.9 |  |  | $ | 184.6 |  |
| Adjusted EBITDA margin |  |  | 20.4 | % |  |  | 22.5 | % |  |  | 24.3 | % |  |  | 20.8 | % |  |  | 22.0 | % |  |  | 21.8 | % |  |  | 21.6 | % |  |  | 23.8 | % |  |  | 19.3 | % |  |  | 21.7 | % |
| Year-over-year adjusted EBITDA growth |  |  | (5% | ) |  |  | 4 | % |  |  | 1 | % |  |  | 15 | % |  |  | 3 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-16-024462:8k_2_02:56]
Note: Totals will not always foot due to rounding
