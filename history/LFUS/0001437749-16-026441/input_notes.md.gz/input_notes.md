# LFUS notes — 0001437749-16-026441


## lfus:OtherIncomeExpensePolicyTextBlock

[0001437749-16-026441:notes:1]
Other

[0001437749-16-026441:notes:2]
E

[0001437749-16-026441:notes:3]
xpense (

[0001437749-16-026441:notes:4]
I

[0001437749-16-026441:notes:5]
ncome),

[0001437749-16-026441:notes:6]
N

[0001437749-16-026441:notes:7]
et

[0001437749-16-026441:notes:8]
:
 Other expense (income), net consisting of interest income, royalties and non-operating income

[0001437749-16-026441:notes:9]
, was ($5.4 million), ($6.6 million) and ($4.6 million) of income in 2015, 2014, and 2013, respectively.


## lfus:PensionPlanAssetsMeasuredAtFairValueTableTextBlock

[0001437749-16-026441:notes:10]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Equity 50:50 Index Fund |  | $ | — |  |  | $ | 12,801 |  |  | $ | — |  |  | $ | 12,801 |  |
| Philippine Stock |  |  | 836 |  |  |  | — |  |  |  | — |  |  |  | 836 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investment grade corporate bond funds |  |  | 6,807 |  |  |  | — |  |  |  | — |  |  |  | 6,807 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | 3,428 |  |  |  | — |  |  |  | 3,428 |  |
| Active Corp Bond – Over 10 Yr Fund |  |  | — |  |  |  | 6,440 |  |  |  | — |  |  |  | 6,440 |  |
| Over 5y Index-Linked Gilts Fund |  |  | — |  |  |  | 10,248 |  |  |  | — |  |  |  | 10,248 |  |
| Philippine Long Govt Securities |  |  | 1,227 |  |  |  | — |  |  |  | — |  |  |  | 1,227 |  |
| Philippine Long Corporate Bonds |  |  | 781 |  |  |  | — |  |  |  | — |  |  |  | 781 |  |
| Cash and equivalents |  |  | 2,061 |  |  |  | — |  |  |  | — |  |  |  | 2,061 |  |
| Total pension plan assets |  | $ | 11,712 |  |  | $ | 32,917 |  |  | $ | — |  |  | $ | 44,629 |  |

[0001437749-16-026441:notes:11]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Equity 50:50 Index Fund |  | $ | — |  |  | $ | 13,168 |  |  | $ | — |  |  | $ | 13,168 |  |
| Philippine Stock |  |  | 1,069 |  |  |  | — |  |  |  | — |  |  |  | 1,069 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long U.S. Credit Corp Index Fund |  |  | — |  |  |  | 42,911 |  |  |  | — |  |  |  | 42,911 |  |
| Long U.S. Govt Bond Index Fund |  |  | — |  |  |  | 24,116 |  |  |  | — |  |  |  | 24,116 |  |
| Intermediate U.S. Govt Bond Index Fund |  |  | — |  |  |  | 18,884 |  |  |  | — |  |  |  | 18,884 |  |
| Investment grade corporate bond funds |  |  | 8,118 |  |  |  | — |  |  |  | — |  |  |  | 8,118 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | 3,814 |  |  |  | — |  |  |  | 3,814 |  |
| Active Corp Bond – Over 10 Yr Fund |  |  | — |  |  |  | 7,065 |  |  |  | — |  |  |  | 7,065 |  |
| Over 5y Index-Linked Gilts Fund |  |  | — |  |  |  | 11,352 |  |  |  | — |  |  |  | 11,352 |  |
| Philippine Long Govt Securities |  |  | 1,059 |  |  |  | — |  |  |  | — |  |  |  | 1,059 |  |
| Philippine Long Corporate Bonds |  |  | 781 |  |  |  | — |  |  |  | — |  |  |  | 781 |  |
| Cash and equivalents |  |  | 9,247 |  |  |  | — |  |  |  | — |  |  |  | 9,247 |  |
| Total pension plan assets |  | $ | 20,274 |  |  | $ | 121,310 |  |  | $ | — |  |  | $ | 141,584 |  |


## lfus:RevenueRecognitionAndBillingPolicyTextBlock

[0001437749-16-026441:notes:12]
Revenue

[0001437749-16-026441:notes:13]
and

[0001437749-16-026441:notes:14]
Billing
: The company accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the company’s published price lists. The customer is invoiced when the company’s products are shipped to them in accordance with the terms of the sales agreement.


## lfus:RevenueRecognitionReturnToStockPolicyTextBlock

[0001437749-16-026441:notes:15]
Return to Stock:
 The company has a return to stock policy whereby a customer with prior authorization from Littelfuse management can return previously purchased goods for full or partial credit. The company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001437749-16-026441:notes:16]
Advertising Costs
: The company expenses advertising costs as incurred, which amounted to $2.3 million in 2015, $2.8 million in 2014 and $1.6 million in 2013, and are included as a component of selling, general and administrative expenses.


## us-gaap:AssetImpairmentChargesTextBlock

[0001437749-16-026441:notes:17]
11. Asset Impairments

[0001437749-16-026441:notes:18]
The company recorded no impairments of assets during the year ended January 2, 2016.

[0001437749-16-026441:notes:19]
For the year ended December 27, 2014, the company recorded an asset impairment charge of approximately $0.3 million within selling, general and administrative expenses. This charge reflects the write-down of assets from project cancellations. The charge was recognized as an “other” charge for segment reporting purposes. The carrying values of the company’s assets held for sale were $0.0 million and $5.5 million for the previously closed manufacturing facility in Des Plaines, Illinois as of January 2, 2016 and December 27, 2014, respectively.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-16-026441:notes:20]
Basis of Presentation
:

[0001437749-16-026441:notes:21]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America and include the assets, liabilities, revenues and expenses of all wholly-owned subsidiaries and majority-owned subsidiaries over which the company exercises control.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001437749-16-026441:notes:22]
Cash Equivalents
: All highly liquid investments, with an original maturity of three months or less when purchased, are considered to be cash equivalents.


## us-gaap:CommitmentsDisclosureTextBlock

[0001437749-16-026441:notes:23]
16. Lease Commitments

[0001437749-16-026441:notes:24]
The company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was approximately $11.1 million in 2015, $8.9 million in 2014 and $8.9 million in 2013.

[0001437749-16-026441:notes:25]
Rent expense is recognized on a straight-line basis over the term of the leases. The difference between straight-line basis rent and the amount paid has been recorded as accrued lease obligations. The company also has leases that have lease renewal provisions. As of January 2, 2016, all operating leases outstanding were with third parties. The company did not have any capital leases as of January 2, 2016

[0001437749-16-026441:notes:26]
.

[0001437749-16-026441:notes:27]
Future minimum payments for all non-cancellable operating leases with initial terms of one year or more at January 2, 2016 are as follows (in thousands):

[0001437749-16-026441:notes:28]
| 2016 |  | $ | 8,886 |  |
| 2017 |  |  | 5,227 |  |
| 2018 |  |  | 3,984 |  |
| 2019 |  |  | 3,358 |  |
| 2020 |  |  | 3,163 |  |
| 2021 and thereafter |  |  | 10,021 |  |
|  |  | $ | 34,639 |  |


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0001437749-16-026441:notes:29]
5.

[0001437749-16-026441:notes:30]
Other I

[0001437749-16-026441:notes:31]
nvestment

[0001437749-16-026441:notes:32]
s

[0001437749-16-026441:notes:33]
The company’s other investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company and shares of Monolith Semiconductor, Inc. (“Monolith”), a Texas-based startup company.

[0001437749-16-026441:notes:34]
Polytronics

[0001437749-16-026441:notes:35]
The Polytronics investment was acquired as part of the Littelfuse GmbH acquisition. The company’s Polytronics shares held at the end of fiscal 2015 and 2014 represent approximately 7.2% of total Polytronics shares outstanding. The fair value of the Polytronics investment was €10.7

[0001437749-16-026441:notes:36]
million (approximately $11.7 million) at January 2, 2016 and €9.9

[0001437749-16-026441:notes:37]
million (approximately $12.1 million) at December 27, 2014. Included in 2015 other comprehensive income is an unrealized gain of $0.9 million, due to the increase in fair market value of the Polytronics investment. The remaining movement year over year was due to the impact of changes in exchange rates.

[0001437749-16-026441:notes:38]
Monolith

[0001437749-16-026441:notes:39]
In December 2015, the company invested $3.5 million in the preferred stock of Monolith, a U.S. start-up company developing silicon carbide (SiC) technology, which represents approximately 12% of the common stock of Monolith on an as-converted basis. The company accounts for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was $3.5 million at January 2, 2016.


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-026441:notes:40]
7

[0001437749-16-026441:notes:41]
. Debt

[0001437749-16-026441:notes:42]
The carrying amounts of debt at January 2, 2016 and December 27, 2014 are as follows (in thousands):

[0001437749-16-026441:notes:43]
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 85,000 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 77,000 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 9,474 |  |  |  | 17,908 |  |
| Total debt |  |  | 171,474 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 87,000 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 84,474 |  |  | $ | 106,658 |  |

[0001437749-16-026441:notes:44]
Term Loan

[0001437749-16-026441:notes:45]
and Revolving Credit Facilities

[0001437749-16-026441:notes:46]
On May 31, 2013, the company entered into a new credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consists of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The credit agreement is for a five year period. At January 2, 2016, the company had available $197.9 million of borrowing capacity under the credit agreement at an interest rate of LIBOR plus 1.25%, or a total interest rate of 1.68% as of January 2, 2016.

[0001437749-16-026441:notes:47]
The credit agreement replaced the company’s previous credit agreement dated June 13, 2011, which was terminated on May 31, 2013.

[0001437749-16-026441:notes:48]
The company incurred debt issuance costs of $0.8 million which will be amortized over the life of the new credit agreement.

[0001437749-16-026441:notes:49]
On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013 by $50.0 million, thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement.

[0001437749-16-026441:notes:50]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At January 2, 2016, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-16-026441:notes:51]
The company assumed three credit lines with the acquisition of Hamlin totaling RMB 41.0 million (approximately $6.6 million) as of June 29, 2013 with expiration dates from August 23, 2013 through April 22, 2014. Two of these credit lines expired during the third quarter of 2013 and the remaining credit line expired during the second  quarter of 2014.

[0001437749-16-026441:notes:52]
For the fiscal years ended January 2, 2016, December 27, 2014 and December 28, 2013, the company had $0.1, $0.8 and $0.8 million outstanding in letters of credit, respectively. No amounts were drawn under these lines of credit at January 2, 2016.

[0001437749-16-026441:notes:53]
Entrust

[0001437749-16-026441:notes:54]
ed

[0001437749-16-026441:notes:55]
Loan

[0001437749-16-026441:notes:56]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.5 million) at January 2, 2016.

[0001437749-16-026441:notes:57]
Interest paid on all company debt was approximately $4.1 million in 2015, $4.9 million in 2014 and $2.9 million in 2013.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-16-026441:notes:58]
8

[0001437749-16-026441:notes:59]
Financial Instruments and Risk Management

[0001437749-16-026441:notes:60]
Occasionally, the company uses financial instruments to manage its exposures to movements in commodity prices, foreign exchange and interest rates. The use of these financial instruments modifies the company’s exposure to these risks with the goal of reducing the risk or cost to the company. The company does not use derivatives for trading purposes and is not a party to leveraged derivative contracts.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-026441:notes:61]
17. Earnings P

[0001437749-16-026441:notes:62]
er Share

[0001437749-16-026441:notes:63]
As of January 2014, the company no longer had “participating securities” as defined under ASC 260. As such, the company now calculates its earnings per share using the treasury method. All of the previous participating securities that resulted in the company using the two-class method have become fully vested or have otherwise expired.

[0001437749-16-026441:notes:64]
In 2013, the company calculated its earnings per share using the two-class method which included an earnings allocation formula that determined earnings per share for each class of common stock according to dividends declared and undistributed earnings for the period. Previously, the company’s reported net earnings were reduced by the amount allocated to participating securities to arrive at the earnings 
allocated to common stock shareholders for purposes of calculating earnings per share under the two-class method.

[0001437749-16-026441:notes:65]
Under the previous two-class method calculation, the dilutive effect of participating securities was calculated using the more dilutive of the treasury stock or the two-class method. The company previously determined the two-class method to be the more dilutive. As such, the earnings allocated to common stock shareholders in the basic earnings per share calculation was adjusted for the reallocation of undistributed earnings to participating securities to arrive at the earnings allocated to common stock shareholders for calculating the diluted earnings per share.

[0001437749-16-026441:notes:66]
The following table sets forth the computation of basic and diluted earnings per share under the two-class method:

[0001437749-16-026441:notes:67]
| (In thousands, except per share amounts) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net income as reported |  | $ | 82,466 |  |  | $ | 99,418 |  |  | $ | 88,784 |  |
| Less: Distributed earnings available to participating securities |  |  | — |  |  |  | — |  |  |  | (35 | ) |
| Less: Undistributed earnings available to participating securities |  |  | — |  |  |  | — |  |  |  | (16 | ) |
| Numerator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 82,466 |  |  | $ | 99,418 |  |  | $ | 88,733 |  |
| Add: Undistributed earnings allocated to participating securities |  |  | — |  |  |  | — |  |  |  | 16 |  |
| Less: Undistributed earnings reallocated to participating securities |  |  | — |  |  |  | — |  |  |  | (16 | ) |
| Numerator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 82,466 |  |  | $ | 99,418 |  |  | $ | 88,733 |  |
| Denominator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares |  |  | 22,565 |  |  |  | 22,543 |  |  |  | 22,315 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Common stock equivalents |  |  | 154 |  |  |  | 184 |  |  |  | 222 |  |
| Denominator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted for weighted-average shares & assumed conversions |  |  | 22,719 |  |  |  | 22,727 |  |  |  | 22,537 |  |
| Basic earnings per share |  | $ | 3.65 |  |  | $ | 4.41 |  |  | $ | 3.98 |  |
| Diluted earnings per share |  | $ | 3.63 |  |  | $ | 4.37 |  |  | $ | 3.94 |  |

[0001437749-16-026441:notes:68]
The following potential shares of common stock attributable to stock options were excluded from the earnings per share calculation because their effect would be anti-dilutive: 113,130 in 2015; 43,693 in 2014; and 96,401 in 2013.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-16-026441:notes:69]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 11,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,697 |  |
| Total |  | $ | 11,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,697 |  |

[0001437749-16-026441:notes:70]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |
| Total |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-16-026441:notes:71]
9

[0001437749-16-026441:notes:72]
. Fair Value of Assets and Liabilities

[0001437749-16-026441:notes:73]
Applicable accounting literature establishes a hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Applicable accounting literature defines levels within the hierarchy based on the reliability of inputs as follows:

[0001437749-16-026441:notes:74]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0001437749-16-026441:notes:75]
Level 2—Valuations based on quoted prices for similar assets or liabilities or identical assets or liabilities in less active markets, such as dealer or broker markets; and

[0001437749-16-026441:notes:76]
Level 3—Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable, such as pricing models, discounted cash flow models and similar techniques not based on market, exchange, dealer or broker-traded transactions.

[0001437749-16-026441:notes:77]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0001437749-16-026441:notes:78]
Investment

[0001437749-16-026441:notes:79]
Investments in equity securities listed on a national market or exchange are valued at the last sales price. Such securities are further detailed in Note 5 and classified within Level 1 of the valuation hierarchy.

[0001437749-16-026441:notes:80]
The company has an investment in Monolith as described in Note 5 to the Notes to Consolidated Financial Statements for which the value of $3.5 million represents the cost of the investment.

[0001437749-16-026441:notes:81]
There were no changes during the year ended January 2, 2016 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of January 2, 2016 and December 27, 2014, the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-16-026441:notes:82]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of January 2, 2016 (in thousands):

[0001437749-16-026441:notes:83]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 27, 2014 (in thousands):

[0001437749-16-026441:notes:84]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The company’s long-term debt fair value approximates book value at January 2, 2016 and December 27, 2014.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001437749-16-026441:notes:85]
Foreign Currency Translation

[0001437749-16-026441:notes:86]
/Remeasurement
: The company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. The amount of foreign currency gain or loss from remeasurement recognized in the income statement was a loss of $7.9 million in 2015, a loss of $4.6 million in 2014 and a gain of $5.2 million in 2013. Adjustments from the translation process are recognized in “Shareholders’ equity” as a component of “Accumulated other comprehensive income.”


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-16-026441:notes:87]
4.

[0001437749-16-026441:notes:88]
Goodwill and Other

[0001437749-16-026441:notes:89]
Intangible Assets

[0001437749-16-026441:notes:90]
The amounts for goodwill and changes in the carrying value by business unit segment are as follows at January 2, 2016 and December 27, 2014 (in thousands):

[0001437749-16-026441:notes:91]
|  |  | 2015 |  |  | Additions (Reductions)(a) |  |  | Adjustments(c) |  |  | 2014 |  |  | Additions (Reductions)(b) |  |  | Adjustments(c) |  |  | 2013 |  |
| Electronics |  | $ | 58,246 |  |  | $ | (524 | ) |  | $ | (1,740 | ) |  | $ | 60,510 |  |  | $ | 1,654 |  |  | $ | (1,590 | ) |  | $ | 60,446 |  |
| Automotive |  |  | 80,262 |  |  |  | 1,994 |  |  |  | (3,449 | ) |  |  | 81,717 |  |  |  | — |  |  |  | (3,264 | ) |  |  | 84,981 |  |
| Industrial |  |  | 51,259 |  |  |  | — |  |  |  | (2,770 | ) |  |  | 54,029 |  |  |  | 14,920 |  |  |  | (1,928 | ) |  |  | 41,037 |  |
| Total |  | $ | 189,767 |  |  | $ | 1,470 |  |  | $ | (7,959 | ) |  | $ | 196,256 |  |  | $ | 16,574 |  |  | $ | (6,782 | ) |  | $ | 186,464 |  |

[0001437749-16-026441:notes:92]
| (a) | Electronics reduction resulted from reclassification of goodwill to customer lists. Automotive addition of $2.0 million resulted from business acquisitions. |

[0001437749-16-026441:notes:93]
| (b) | Electronics addition of $1.7 million and Industrial addition of $14.9 million in 2014 resulted from business acquisitions. |

[0001437749-16-026441:notes:94]
| (c) | Adjustments reflect the impact of changes in foreign exchange rates. |

[0001437749-16-026441:notes:95]
There were no accumulated goodwill impairment losses at January 2, 2016, December 27, 2014 or December 28, 2013.

[0001437749-16-026441:notes:96]
The company recorded amortization expense of $11.9 million in 2015, $12.5 million in 2014 and $9.3 million in 2013. The details of other intangible assets and related future amortization expense of existing intangible assets at January 2, 2016 and December 27, 2014 are as follows:

[0001437749-16-026441:notes:97]
|  |  | 2015 |  |  | 2014 |  |
| (in thousands) |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |
| Patents, licenses and software(a) |  |  | 11.6 |  |  | $ | 61,297 |  |  | $ | 41,076 |  |  |  | 11.7 |  |  | $ | 62,378 |  |  | $ | 38,738 |  |
| Distribution network(a) |  |  | 12.4 |  |  |  | 45,564 |  |  |  | 29,074 |  |  |  | 12.4 |  |  |  | 46,850 |  |  |  | 27,422 |  |
| Customer lists, trademarks and tradenames(a) |  |  | 13.0 |  |  |  | 81,233 |  |  |  | 30,534 |  |  |  | 13.2 |  |  |  | 80,821 |  |  |  | 25,246 |  |
| Tradenames(b) |  |  | — |  |  |  | 4,213 |  |  |  | — |  |  |  | — |  |  |  | 5,030 |  |  |  | — |  |
| Total |  |  | 12.4 |  |  | $ | 192,307 |  |  | $ | 100,684 |  |  |  | 12.5 |  |  | $ | 195,079 |  |  | $ | 91,406 |  |

[0001437749-16-026441:notes:98]
| (a) | Decrease to gross carrying value in 2015 primarily due to the impact of foreign currency translation adjustments partially offset by the preliminary Sigmar acquisition purchase price allocation discussed in Note 2. |

[0001437749-16-026441:notes:99]
| (b) | Tradenames with indefinite lives. |

[0001437749-16-026441:notes:100]
Estimated amortization expense related to intangible assets with definite lives at January 2, 2016 is as follows (in thousands):

[0001437749-16-026441:notes:101]
| 2016 |  | $ | 11,162 |  |
| 2017 |  |  | 10,745 |  |
| 2018 |  |  | 10,628 |  |
| 2019 |  |  | 10,582 |  |
| 2020 |  |  | 10,582 |  |
| 2021 and thereafter |  |  | 33,711 |  |
|  |  | $ | 87,410 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-026441:notes:102]
14

[0001437749-16-026441:notes:103]
. Income Taxes

[0001437749-16-026441:notes:104]
Domestic and foreign income (loss) before income taxes is as follows (in thousands):

[0001437749-16-026441:notes:105]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Domestic |  | $ | 1,313 |  |  | $ | 35,264 |  |  | $ | 20,254 |  |
| Foreign |  |  | 105,635 |  |  |  | 96,382 |  |  |  | 103,982 |  |
| Income before income taxes |  | $ | 106,948 |  |  | $ | 131,646 |  |  | $ | 124,236 |  |

[0001437749-16-026441:notes:106]
Federal, state and foreign income tax (benefit) expense consists of the following (in thousands):

[0001437749-16-026441:notes:107]
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (6,686 | ) |  | $ | 8,003 |  |  | $ | 8,265 |  |
| State |  |  | 2,078 |  |  |  | 1,275 |  |  |  | 2,084 |  |
| Foreign |  |  | 17,611 |  |  |  | 27,438 |  |  |  | 18,462 |  |
| Subtotal |  |  | 13,003 |  |  |  | 36,716 |  |  |  | 28,811 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal and State |  |  | 11,330 |  |  |  | (1,513 | ) |  |  | 3,251 |  |
| Foreign |  |  | 149 |  |  |  | (2,975 | ) |  |  | 3,389 |  |
| Subtotal |  |  | 11,479 |  |  |  | (4,488 | ) |  |  | 6,640 |  |
| Provision for income taxes |  | $ | 24,482 |  |  | $ | 32,228 |  |  | $ | 35,451 |  |

[0001437749-16-026441:notes:108]
The current federal tax benefit for 2015 includes an $11.7 million benefit reclassified from AOCI as a result of the company’s termination of the U.S. defined benefit pension plan as described in Note 12 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-16-026441:notes:109]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below (in thousands):

[0001437749-16-026441:notes:110]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Tax expense at statutory rate of 35% |  | $ | 37,432 |  |  | $ | 46,076 |  |  | $ | 43,481 |  |
| State and local taxes, net of federal tax benefit |  |  | 1,907 |  |  |  | 1,186 |  |  |  | 1,076 |  |
| Foreign income tax rate differential |  |  | (19,853 | ) |  |  | (14,981 | ) |  |  | (15,497 | ) |
| Capital loss valuation allowance |  |  | — |  |  |  | — |  |  |  | 6,085 |  |
| Tax on unremitted earnings |  |  | — |  |  |  | — |  |  |  | (349 | ) |
| Mexico manufacturing operations restructuring |  |  | 4,841 |  |  |  | — |  |  |  | — |  |
| Nondeductible professional fees |  |  | 1,011 |  |  |  | — |  |  |  | — |  |
| Other, net |  |  | (856 | ) |  |  | (53 | ) |  |  | 655 |  |
| Provision for income taxes |  | $ | 24,482 |  |  | $ | 32,228 |  |  | $ | 35,451 |  |

[0001437749-16-026441:notes:111]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the company’s assets and liabilities. Significant components of the company’s deferred tax assets and liabilities at January 2, 2016 and December 27, 2014, are as follows (in thousands):

[0001437749-16-026441:notes:112]
|  |  | 2015 |  |  | 2014 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 19,738 |  |  | $ | 27,088 |  |
| Foreign tax credit carryforwards |  |  | 1,529 |  |  |  | 5,299 |  |
| AMT credit carryforwards |  |  | — |  |  |  | 167 |  |
| Accrued restructuring |  |  | 1,115 |  |  |  | 124 |  |
| Capital losses |  |  | 4,557 |  |  |  | 4,557 |  |
| Domestic and foreign net operating loss carryforwards |  |  | 684 |  |  |  | 525 |  |
| Gross deferred tax assets |  |  | 27,623 |  |  |  | 37,760 |  |
| Less: Valuation allowance |  |  | (4,557 | ) |  |  | (4,557 | ) |
| Total deferred tax assets |  |  | 23,066 |  |  |  | 33,203 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Tax depreciation and amortization in excess of book |  |  | 22,747 |  |  |  | 21,405 |  |
| Total deferred tax liabilities |  |  | 22,747 |  |  |  | 21,405 |  |
| Net deferred tax assets |  | $ | 319 |  |  | $ | 11,798 |  |

[0001437749-16-026441:notes:113]
The deferred tax asset valuation allowance is related to a U.S. capital loss carryover which is not expected to be realized. The remaining domestic and foreign net operating losses either have no expiration date or are expected to be utilized prior to expiration. The foreign tax credit carryforwards begin to expire in 2019. The company paid income taxes of approximately $23.3 million, $26.6 million and $30.4 million in 2015, 2014 and 2013, respectively.

[0001437749-16-026441:notes:114]
U.S. income taxes were not provided on a cumulative total of approximately $367.9 million of undistributed earnings for certain non-U.S. subsidiaries as of January 2, 2016, and accordingly, no deferred tax liability has been established relative to these earnings. The determination of the deferred tax liability associated with the distribution of these earnings is not practicable. The company has three subsidiaries in China on “tax holidays.” The tax holidays begin to expire in 2017. The company expects to be granted extensions. Such tax holidays contributed approximately $2.6 million in tax benefits ($0.11 per diluted share) during 2015 with similar amounts expected in future years while tax holidays are in effect.

[0001437749-16-026441:notes:115]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of January 2, 2016, December 27, 2014 and December 28, 2013 is as follows (in thousands):

[0001437749-16-026441:notes:116]
| Balance at December 28, 2013 |  | $ | 112 |  |
| Balance at December 27, 2014 |  |  | 112 |  |
| Increases/decreases for tax positions taken in the current year |  |  | — |  |
| Additions for tax positions taken in prior years |  |  | — |  |
| Settlements |  |  | — |  |
| Lapses of statute of limitations |  |  | — |  |
| Other |  |  | (10 | ) |
| Balance at January 2, 2016 |  | $ | 102 |  |

[0001437749-16-026441:notes:117]
The amount of unrecognized tax benefits at January 2, 2016 was approximately $0.1 million. Of this total, approximately $0.1 million represents the amount of tax benefits that, if recognized, would favorably affect the effective income tax rate in future periods. The company expects a decrease in unrecognized tax benefits in the next 12 months of $0.1 million upon concluding a German tax examination. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility. The U.S. federal statute of limitations remains open for 2012 onward. Foreign and U.S. state statute of limitations generally range from three to seven years. During 2015, the company received an examination notice from the Illinois state taxing authority for the 2012 and 2013 tax years as well as the Ohio state taxing authority for the 2012 to 2014 tax years. In February 2016, the company received an examination notice from the Internal Revenue Service for the 2014 tax year. The company is currently under examination in Germany for tax years 2008 through 2010. The company does not expect to recognize a significant amount of additional tax expense as a result of concluding the state, U.S. federal or German tax examinations.

[0001437749-16-026441:notes:118]
The company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense.


## us-gaap:IncomeTaxPolicyTextBlock

[0001437749-16-026441:notes:119]
Income Taxes: 
The company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. Federal and state income taxes are provided on the portion of foreign income that is expected to be remitted to the U.S. and be taxable.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-16-026441:notes:120]
3. Inventories

[0001437749-16-026441:notes:121]
The components of inventories at January 2, 2016 and December 27, 2014 are as follows (in thousands):

[0001437749-16-026441:notes:122]
|  |  | 2015 |  |  | 2014 |  |
| Raw materials |  | $ | 33,599 |  |  | $ | 29,756 |  |
| Work in process |  |  | 16,479 |  |  |  | 15,164 |  |
| Finished goods |  |  | 48,551 |  |  |  | 52,471 |  |
| Total |  | $ | 98,629 |  |  | $ | 97,391 |  |


## us-gaap:InventoryPolicyTextBlock

[0001437749-16-026441:notes:123]
Inventories
: Inventories are stated at the lower of cost or market (first in, first out method), which approximates current replacement cost. The company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.


## us-gaap:InvestmentPolicyTextBlock

[0001437749-16-026441:notes:124]
Short-Term and Long-Term Investments
: The company has determined that certain of its investment securities are to be classified as available-for-sale. Available-for-sale securities are carried at fair value with the unrealized gains and losses reported as a component of “Accumulated Other Comprehensive Income (Loss).” Realized gains and losses and declines in unrealized value judged to be other-than-temporary on available-for-sale securities are included in other expense (income), net. The cost of securities sold is based on the specific identification method. Interest and dividends on securities classified as available-for-sale are included in interest income. Short-term investments, which are primarily certificates of deposits, are carried at cost which approximates fair value.


## us-gaap:InvestmentsInAndAdvancesToAffiliatesScheduleOfInvestmentsTextBlock

[0001437749-16-026441:notes:125]
6. Investment in Unconsolidated Affiliate

[0001437749-16-026441:notes:126]
Investments in unconsolidated entities over which the company has significant influence over the investees’ operating and financing activities are accounted for under the equity method of accounting. Investments in affiliates in which the company does not have such ability are accounted for under the cost method of accounting.

[0001437749-16-026441:notes:127]
In April 2012, the company invested an additional $10.0 million in certain common and preferred stock of Shocking Technologies, Inc. (“Shocking”) increasing its previous investment interest in Shocking to $16.0 million or approximately 18.4%. In addition, in late-November 2012, the company provided an 
additional $2.0 million short-term secured loan to Shocking and determined that the company then had the ability to exert significant influence. As a result, the company began accounting for the investment in Shocking using the equity method. In accordance with ASC 323, the company retroactively recorded its proportional share of Shocking's operating losses, which amounted to approximately $4.0 million in 2012.

[0001437749-16-026441:notes:128]
Impairment

[0001437749-16-026441:notes:129]
During the first quarter of 2013, the company fully impaired its investment in a loan receivable from Shocking owing to their filing for Chapter 7 bankruptcy on March 12, 2013. The impairment charge of approximately $10.7 million consisted of the remaining equity method investment of $8.7 million and a $2.0 million loan receivable, and reduced the carrying value of both the investment and loan receivable to zero at March 30, 2013.

[0001437749-16-026441:notes:130]
During the fourth quarter of 2013, the company incurred a $6.1 million charge to income tax expense related to the company’s investment in Shocking which had been fully impaired and written off as described above. $3.3 million of this charge was pushed back to the first quarter of 2013 with the remaining $2.8 million (which related to the fourth quarter of 2012) recorded in the fourth quarter of 2013 as the correction of an immaterial error under ASC 250. This charge was determined to be a capital loss for tax purposes, instead of an ordinary loss as the company had previously determined in consultation with a third party expert.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-16-026441:notes:131]
2. Acquisition of Business

[0001437749-16-026441:notes:132]
es

[0001437749-16-026441:notes:133]
The company accounts for acquisitions using the purchase method in accordance with ASC 805, “Business Combinations.” The results of operations of each acquisition have been included in the accompanying consolidated financial statements as of the dates of the acquisition. Acquisition-related costs associated with acquisition activity were $4.6 million, $0.5 million and $1.7 million for fiscal years 2015, 2014, and 2013, respectively and were recorded in Selling, general and administrative expenses.

[0001437749-16-026441:notes:134]
Sigmar S.r.l

[0001437749-16-026441:notes:135]
On October 1, 2015, the company acquired 100% of Sigmar S.r.l. (“Sigmar”). The total purchase price for Sigmar is $5.4 million, net of cash acquired, subject to post-closing adjustments. The purchase also includes an earn-out clause of an additional payment of up to $0.6 million, subject to the achievement of certain milestones.

[0001437749-16-026441:notes:136]
Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel and selective catalytic reduction (SCR) quality sensors, as well as diesel fuel heaters, solenoid valves and rotating oil filters for automotive and commercial vehicle applications. The acquisition further expands the company’s automotive sensor product line offerings within its Automotive business segment. The company funded the acquisition with available cash.

[0001437749-16-026441:notes:137]
The following table sets forth the preliminary purchase price allocation for Sigmar acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values.

[0001437749-16-026441:notes:138]
| Sigmar preliminary purchase price allocation (in thousands): |  |
| Cash |  | $ | 230 |  |
| Current assets, net |  |  | 4,011 |  |
| Property, plant and equipment |  |  | 1,097 |  |
| Goodwill |  |  | 2,060 |  |
| Patents |  |  | 2,845 |  |
| Current liabilities |  |  | (1,704 | ) |
| Other non-current liabilities |  |  | (2,906 | ) |
|  |  | $ | 5,633 |  |

[0001437749-16-026441:notes:139]
All Sigmar goodwill and other assets and liabilities were recorded in the Automotive business unit segment and reflected in the Europe geographical area. The patents are being amortized over 10 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining Sigmar’s products with the company’s existing automotive product offerings. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-16-026441:notes:140]
Sym

[0001437749-16-026441:notes:141]
C

[0001437749-16-026441:notes:142]
om

[0001437749-16-026441:notes:143]
On January 3, 2014, the company acquired 100% of SymCom, Inc. (“SymCom”) for $52.8 million net of cash acquired. Located in Rapid City, South Dakota, SymCom provides overload relays and pump controllers primarily to the industrial market. The acquisition allows the company to strengthen its position in the relay products market by adding new products and new customers within its Industrial business unit segment. The company funded the acquisition with available cash and proceeds from credit facilities

[0001437749-16-026441:notes:144]
The following table sets forth the final purchase price allocation for SymCom acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values.

[0001437749-16-026441:notes:145]
| SymCom final purchase price allocation (in thousands): |  |
| Cash |  | $ | 325 |  |
| Current assets, net |  |  | 9,154 |  |
| Property, plant and equipment |  |  | 11,193 |  |
| Goodwill |  |  | 15,018 |  |
| Trademarks |  |  | 17,020 |  |
| Patents |  |  | 1,500 |  |
| Other non-current assets |  |  | 20 |  |
| Current liabilities |  |  | (1,137 | ) |
|  |  | $ | 53,093 |  |

[0001437749-16-026441:notes:146]
All SymCom goodwill and other assets and liabilities were recorded in the Industrial business segment and reflected in the Americas geographical area. The trademarks are being amortized over 15 to 20 years. The patents are being amortized over 16 to 17 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining SymCom’s products with the company’s existing electrical product offerings. Goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-16-026441:notes:147]
As required by purchase accounting rules, the company initially recorded a $2.6 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. During the first quarter of 2014, as a portion of this inventory was sold, cost of goods sold included a $1.4 million non-cash charge for this step-up.

[0001437749-16-026441:notes:148]
During the second quarter of 2014, the inventory step-up valuation was finalized at $2.8 million which resulted in an additional $1.4 million non-cash charge to cost of goods sold for the second quarter of 2014. Pro forma financial information is not presented for the above acquisitions due to amounts not being materially different than actual results.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-16-026441:notes:149]
Accounting Pronouncements
: In November 2015, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (“ASU”) No. 2015-17 – Income taxes (Topic 740): Balance Sheet Classification of Deferred Taxes, which simplifies the balance sheet classification of deferred taxes. The 
new guidance requires that all deferred taxes be presented as noncurrent. The company has adopted the new guidance for the year ended January 2, 2016 with all prior periods presented retrospectively adjusted to conform to the new ASU.

[0001437749-16-026441:notes:150]
In May 2014, the FASB amended prior authoritative guidance for revenue recognition which provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The standard is effective for public entities for annual and interim periods beginning after December 15, 2016. Early adoption is not permitted. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The company is currently evaluating the impact of the adoption of this accounting standard on its consolidated financial statements.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001437749-16-026441:notes:151]
10.

[0001437749-16-026441:notes:152]
Coal Min

[0001437749-16-026441:notes:153]
ing

[0001437749-16-026441:notes:154]
Liability

[0001437749-16-026441:notes:155]
Included in other long-term liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €1.8 million ($2.0 million) and €1.9 million ($2.4 million) at January 2, 2016 and December 27, 2014, respectively.  Management, in conjunction with an independent third-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time. The accrual is not discounted as management cannot reasonably estimate when such remediation efforts will take place.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-16-026441:notes:156]
12

[0001437749-16-026441:notes:157]
. Benefit Plans

[0001437749-16-026441:notes:158]
The company previously had a company-sponsored defined benefit pension plan, the Littelfuse Inc. Retirement Plan, which covered certain of its North American employees. The amount of the retirement benefit was based on years of service and final average pay. The plan also provided a temporary supplemental retirement income benefit to help retirees pay the cost of post-retirement medical coverage if the retiree has reached age 62 and has provided at least ten years of service prior to retirement. Such benefits generally cease once the retiree attains age 65. The plan was frozen in 2009 and terminated in 2015 as described below.

[0001437749-16-026441:notes:159]
The company also has company-sponsored defined benefit pension plans covering employees in the U.K., Germany, Japan, Singapore and the Philippines. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0001437749-16-026441:notes:160]
Littelfuse Inc. Retirement Plan Termination

[0001437749-16-026441:notes:161]
The company received approval from the IRS on April 14, 2015 on its Application for Determination for Terminating Plan to terminate the U.S. defined benefit pension plan, the Littelfuse Inc. Retirement Plan, effective July 30, 2014. All plan liabilities were settled (either via lump sum payout or purchase of a group annuity contract) in the third quarter of 2015. A cash contribution of $9.1 million was made to the U.S. defined benefit plan’s trust in the third quarter of 2015 to fully fund the plan on a buyout basis, and the eventual settlement of the plan’s liabilities triggered a settlement charge of $30.2 million in the third quarter of 2015. In the fourth quarter of 2015 there was an adjustment to the price of the annuity contract which resulted in a refund of premium to the company of $0.3 million. This refund of premium, effectively a re-measurement gain, was recognized in the fourth quarter of 2015 as a dollar-for-dollar adjustment to the $30.2 million earnings charge recognized in the third quarter of 2015, resulting in a final settlement loss of $29.9 million for the fiscal year ended January 2, 2016.

[0001437749-16-026441:notes:162]
Total pension expense was $32.4 million, $0.3 million and $0.8 million in 2015, 2014 and 2013, respectively. The increase in pension expense in 2015 primarily resulted from the termination and settlement of the U.S. plan. The decrease in pension expense in 2014 resulted from returns on assets exceeding interest and service costs.

[0001437749-16-026441:notes:163]
Benefit plan related information is as follows:

[0001437749-16-026441:notes:164]
|  |  | 2015 |  |  | 2014 |  |
| (In thousands) |  | U.S. |  |  | Foreign |  |  | Total |  |  | U.S. |  |  | Foreign |  |  | Total |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year |  | $ | 105,759 |  |  | $ | 52,740 |  |  | $ | 158,499 |  |  | $ | 84,422 |  |  | $ | 50,331 |  |  | $ | 134,753 |  |
| Service cost |  |  | 750 |  |  |  | 824 |  |  |  | 1,574 |  |  |  | 600 |  |  |  | 925 |  |  |  | 1,525 |  |
| Interest cost |  |  | 3,093 |  |  |  | 1,735 |  |  |  | 4,828 |  |  |  | 3,884 |  |  |  | 2,060 |  |  |  | 5,944 |  |
| Net actuarial loss (gain) |  |  | (9,127 | ) |  |  | 648 |  |  |  | (8,479 | ) |  |  | 22,025 |  |  |  | 5,652 |  |  |  | 27,677 |  |
| Benefits paid from the trust |  |  | (100,475 | ) |  |  | (1,732 | ) |  |  | (102,207 | ) |  |  | (5,172 | ) |  |  | (2,525 | ) |  |  | (7,697 | ) |
| Benefits paid directly by company |  |  | — |  |  |  | (410 | ) |  |  | (410 | ) |  |  | — |  |  |  | (155 | ) |  |  | (155 | ) |
| Curtailments and settlements |  |  | — |  |  |  | (294 | ) |  |  | (294 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Effect of exchange rate movements |  |  | — |  |  |  | (3,229 | ) |  |  | (3,229 | ) |  |  | — |  |  |  | (3,548 | ) |  |  | (3,548 | ) |
| Benefit obligation at end of year |  | $ | — |  |  | $ | 50,282 |  |  | $ | 50,282 |  |  | $ | 105,759 |  |  | $ | 52,740 |  |  | $ | 158,499 |  |
| Change in plan assets at fair value: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year |  | $ | 93,991 |  |  | $ | 47,593 |  |  | $ | 141,584 |  |  | $ | 83,748 |  |  | $ | 42,477 |  |  | $ | 126,225 |  |
| Actual return on plan assets |  |  | (2,375 | ) |  |  | 389 |  |  |  | (1,986 | ) |  |  | 10,416 |  |  |  | 5,141 |  |  |  | 15,557 |  |
| Employer contributions |  |  | 8,859 |  |  |  | 1,072 |  |  |  | 9,931 |  |  |  | 5,000 |  |  |  | 5,596 |  |  |  | 10,596 |  |
| Benefits paid |  |  | (100,475 | ) |  |  | (1,732 | ) |  |  | (102,207 | ) |  |  | (5,173 | ) |  |  | (2,525 | ) |  |  | (7,698 | ) |
| Effect of exchange rate movements |  |  | — |  |  |  | (2,693 | ) |  |  | (2,693 | ) |  |  | — |  |  |  | (3,096 | ) |  |  | (3,096 | ) |
| Fair value of plan assets at end of year |  |  | — |  |  |  | 44,629 |  |  |  | 44,629 |  |  |  | 93,991 |  |  |  | 47,593 |  |  |  | 141,584 |  |
| Net amount recognized/(unfunded status) |  | $ | — |  |  | $ | (5,653 | ) |  | $ | (5,653 | ) |  | $ | (11,768 | ) |  | $ | (5,147 | ) |  | $ | (16,915 | ) |
| Amounts recognized in the Consolidated Balance Sheet consist of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of accrued benefit liability |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (11,768 | ) |  | $ | — |  |  | $ | (11,768 | ) |
| Accrued benefit liability |  |  | — |  |  |  | (5,653 | ) |  |  | (5,653 | ) |  |  | — |  |  |  | (5,147 | ) |  |  | (5,147 | ) |
| Total liability recognized |  | $ | — |  |  | $ | (5,653 | ) |  | $ | (5,653 | ) |  | $ | (11,768 | ) |  | $ | (5,147 | ) |  | $ | (16,915 | ) |
| Accumulated other comprehensive loss |  | $ | — |  |  | $ | 9,383 |  |  | $ | 9,383 |  |  | $ | 34,801 |  |  | $ | 7,671 |  |  | $ | 42,472 |  |

[0001437749-16-026441:notes:165]
Amounts recognized in accumulated other comprehensive income (loss), pre-tax consist of:

[0001437749-16-026441:notes:166]
|  |  | 2015 |  |  | 2014 |  |
| (In thousands) |  | U.S. |  |  | Foreign |  |  | Total |  |  | U.S. |  |  | Foreign |  |  | Total |  |
| Net actuarial loss |  | $ | — |  |  | $ | 9,383 |  |  | $ | 9,383 |  |  | $ | 34,801 |  |  | $ | 7,671 |  |  | $ | 42,472 |  |
| Prior service (cost) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net amount recognized /occurring, pre-tax |  | $ | — |  |  | $ | 9,383 |  |  | $ | 9,383 |  |  | $ | 34,801 |  |  | $ | 7,671 |  |  | $ | 42,472 |  |

[0001437749-16-026441:notes:167]
The estimated net actuarial loss (gain) which will be amortized from accumulated other comprehensive income (loss) into benefit cost in 2016 is approximately $0.3 million.

[0001437749-16-026441:notes:168]
|  |  | U.S. |  |  | Foreign |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 750 |  |  | $ | 600 |  |  | $ | 600 |  |  | $ | 824 |  |  | $ | 925 |  |  | $ | 744 |  |
| Interest cost |  |  | 3,093 |  |  |  | 3,884 |  |  |  | 3,565 |  |  |  | 1,735 |  |  |  | 2,060 |  |  |  | 1,376 |  |
| Expected return on plan assets |  |  | (2,749 | ) |  |  | (5,646 | ) |  |  | (5,360 | ) |  |  | (2,346 | ) |  |  | (2,292 | ) |  |  | (1,207 | ) |
| Amortization of prior service (credit) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Amortization of losses |  |  | 870 |  |  |  | 549 |  |  |  | 942 |  |  |  | 221 |  |  |  | 216 |  |  |  | 130 |  |
| Total cost (credit) of the plan for the year |  |  | 1,964 |  |  |  | (613 | ) |  |  | (253 | ) |  |  | 434 |  |  |  | 909 |  |  |  | 1,043 |  |
| Expected plan participants’ contributions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net periodic benefit cost (credit) |  |  | 1,964 |  |  |  | (613 | ) |  |  | (253 | ) |  |  | 434 |  |  |  | 909 |  |  |  | 1,043 |  |
| Settlement loss |  |  | 29,928 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total expense (income) for the year |  | $ | 31,892 |  |  | $ | (613 | ) |  | $ | (253 | ) |  | $ | 434 |  |  | $ | 909 |  |  | $ | 1,043 |  |

[0001437749-16-026441:notes:169]
Weighted average assumptions used to determine net periodic benefit cost for the years 2015, 2014 and 2013 are as follows:

[0001437749-16-026441:notes:170]
|  |  | U.S. |  |  | Foreign |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Discount rate |  |  | 3.9 | % |  |  | 4.8 | % |  |  | 3.9 | % |  |  | 3.7 | % |  |  | 3.7 | % |  |  | 4.5 | % |
| Expected return on plan assets |  |  | 6.8 | % |  |  | 6.8 | % |  |  | 6.8 | % |  |  | 5.1 | % |  |  | 4.9 | % |  |  | 4.8 | % |
| Compensation increase rate |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.3 | % |  |  | 3.8 | % |  |  | 3.6 | % |
| Measurement dates |  | 9/30/15 |  |  | 12/31/14 |  |  | 12/31/13 |  |  | 12/31/15 |  |  | 12/31/14 |  |  | 12/31/13 |  |

[0001437749-16-026441:notes:171]
The accumulated benefit obligation for the U.S. defined benefit plan was $0.0 million and $105.8 million at January 2, 2016 and December 27, 2014, respectively. The accumulated benefit obligation for the foreign plans was $46.2 million and $48.9 million at January 2, 2016 and December 27, 2014, respectively.

[0001437749-16-026441:notes:172]
Weighted average assumptions used to determine benefit obligations at year-end 2015, 2014 and 2013 are as follows:

[0001437749-16-026441:notes:173]
|  |  | U.S. |  |  | Foreign |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Discount rate |  |  | 3.9 | % |  |  | 3.9 | % |  |  | 4.8 | % |  |  | 3.8 | % |  |  | 3.7 | % |  |  | 4.5 | % |
| Compensation increase rate |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6.2 | % |  |  | 5.3 | % |  |  | 3.8 | % |
| Measurement dates |  | 12/31/15 |  |  | 12/31/14 |  |  | 12/31/13 |  |  | 12/31/15 |  |  | 12/31/14 |  |  | 12/31/13 |  |

[0001437749-16-026441:notes:174]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows (in thousands):

[0001437749-16-026441:notes:175]
|  |  | Expected |  |
|  |  | Benefit |  |
|  |  | Payments |  |
| Year |  | (Foreign) |  |
| 2016 |  | 1,964 |  |  |
| 2017 |  | 2,012 |  |  |
| 2018 |  | 2,032 |  |  |
| 2019 |  | 2,065 |  |  |
| 2020 |  | 2,101 |  |  |
| 2021-2025 |  | 11,831 |  |  |

[0001437749-16-026441:notes:176]
Defined Benefit Plan Assets

[0001437749-16-026441:notes:177]
Based upon analysis of the target asset allocation and historical returns by type of investment, the company has assumed that the expected long-term rate of return will be 5.1% on foreign plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0001437749-16-026441:notes:178]
|  |  | U.S. Asset Allocation |  |  | Foreign Asset Allocation |  |
|  |  |  | 2015* |  |  |  | 2014 |  |  |  | 2015 |  |  |  | 2014 |  |
| Equity securities |  |  | 0 | % |  |  | 0 | % |  |  | 30 | % |  |  | 30 | % |
| Debt securities |  |  | 0 | % |  |  | 91 | % |  |  | 65 | % |  |  | 68 | % |
| Cash |  |  | 0 | % |  |  | 9 | % |  |  | 5 | % |  |  | 2 | % |
|  |  |  | 0 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001437749-16-026441:notes:179]
* The U.S. pension plan was terminated during the third quarter of 2015 as described above.

[0001437749-16-026441:notes:180]
The following table presents the company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of January 2, 2016 (in thousands):

[0001437749-16-026441:notes:181]
The following table presents the company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 27, 2014 (in thousands):

[0001437749-16-026441:notes:182]
Defined Contribution Plans

[0001437749-16-026441:notes:183]
The company also maintains a 401(k) savings plan covering substantially all U.S. employees. The company matches 100% of the employee’s annual contributions for the first 4% of the employee’s eligible compensation. Employees are immediately vested in their contributions plus actual earnings thereon, as well as the company contributions. Company matching contributions amounted to $2.8 million, $2.1 million and $1.7 million in each of the years 2015, 2014 and 2013, respectively.

[0001437749-16-026441:notes:184]
The company has a non-qualified Supplemental Retirement and Savings Plan. The company will provide additional retirement benefits for certain management employees and named executive officers by allowing participants to contribute up to 90% of their annual compensation with matching contributions of 4% and 5% of the participant’s annual compensation in excess of the IRS compensation limits.

[0001437749-16-026441:notes:185]
The company previously provided additional retirement benefits for certain key executives through its unfunded defined contribution Supplemental Executive Retirement Plan (“SERP”). The company amended the SERP during 2009 to freeze contributions and set the annual interest rate credited to the accounts until distributed at the five-year Treasury constant maturity rate. The charge to expense for the SERP plan amounted to $0.1 million in 2015 and less than $0.1 million in each of 2014 and 2013.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001437749-16-026441:notes:186]
Property, Plant and Equipment
: Land, buildings and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of 21 years for buildings, seven to nine years for equipment, seven years for furniture and fixtures, five years for tooling and three years for computer equipment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-16-026441:notes:187]
18.

[0001437749-16-026441:notes:188]
S

[0001437749-16-026441:notes:189]
elected

[0001437749-16-026441:notes:190]
Quarterly Financial Data (Unaudited)

[0001437749-16-026441:notes:191]
The quarterly periods listed in the table below for 2015 are for the 14-weeks ended January 2, 2016 and the 13-weeks ended September 26, 2015, June 27, 2015 and March 28, 2015, respectively. The quarterly periods for 2014 are for the 13-weeks ended December 27, 2014, September 27, 2014, June 28, 2014 and March 29, 2014, respectively.

[0001437749-16-026441:notes:192]
(In thousands, except per share data)

[0001437749-16-026441:notes:193]
|  |  | 2015 |  |  | 2014 |  |
|  |  | 4Qa |  |  | 3Qb |  |  | 2Qc |  |  | 1Qd |  |  | 4Qe |  |  | 3Qf |  |  | 2Qg |  |  | 1Qh |  |
| Net sales |  | $ | 220,020 |  |  | $ | 215,510 |  |  | $ | 222,021 |  |  | $ | 210,313 |  |  | $ | 206,620 |  |  | $ | 217,608 |  |  | $ | 220,908 |  |  | $ | 206,859 |  |
| Gross profit |  |  | 82,706 |  |  |  | 86,182 |  |  |  | 85,281 |  |  |  | 76,330 |  |  |  | 75,559 |  |  |  | 87,380 |  |  |  | 82,995 |  |  |  | 78,494 |  |
| Operating income |  |  | 29,854 |  |  |  | 8,584 |  |  |  | 36,171 |  |  |  | 29,548 |  |  |  | 26,391 |  |  |  | 40,130 |  |  |  | 33,719 |  |  |  | 33,590 |  |
| Net income |  |  | 22,463 |  |  |  | 11,324 |  |  |  | 28,684 |  |  |  | 19,995 |  |  |  | 19,511 |  |  |  | 29,940 |  |  |  | 24,578 |  |  |  | 25,389 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.00 |  |  | $ | 0.50 |  |  | $ | 1.26 |  |  | $ | 0.88 |  |  | $ | 0.86 |  |  | $ | 1.33 |  |  | $ | 1.09 |  |  | $ | 1.13 |  |
| Diluted |  | $ | 1.00 |  |  | $ | 0.50 |  |  | $ | 1.26 |  |  | $ | 0.88 |  |  | $ | 0.86 |  |  | $ | 1.32 |  |  | $ | 1.08 |  |  | $ | 1.12 |  |

[0001437749-16-026441:notes:194]
| a – | In the fourth quarter of 2015, the company recorded $2.1 million related to the company’s transfer of its reed switch manufacturing operations from the U.S. and China to the Philippines, ($0.1) million related to the reorganization of its internal legal structure, $4.0 million in acquisition costs, ($0.3) million in pension settlement refunds (See Note 12) and ($0.3) million in other. |

[0001437749-16-026441:notes:195]
| b – | In the third quarter of 2015, the company recorded $1.2 million related to the reed switch manufacturing transfer as noted above, $0.9 million related to the company’s reorganization of its internal legal structure as noted above, $0.3 million in acquisition costs, $30.8 million in pension settlement and wind-up costs (See Note 12) and $0.1 million in other. |

[0001437749-16-026441:notes:196]
| c – | In the second quarter of 2015, the company recorded $0.9 million related to the reed switch manufacturing transfer as noted above, $1.7 million related to the company’s reorganization of its internal legal structure as noted above, $0.2 million in acquisition costs, and $0.7 million in pension wind-up costs. |

[0001437749-16-026441:notes:197]
| d – | In the first quarter of 2015, the company recorded $1.0 million related to the reed switch manufacturing transfer as noted above, $1.2 million in charges related to the reorganization of its internal legal structure as noted above, $0.2 million in acquisition costs, and $0.7 million in pension wind-up costs. |

[0001437749-16-026441:notes:198]
| e – | In the fourth quarter of 2014, the company recorded $2.2 million in charges related to severance and to the company’s reorganization of its internal legal structure as noted above. The company also recorded $0.3 million in acquisition costs and $0.3 million in impairment costs. |

[0001437749-16-026441:notes:199]
| f – | In the third quarter of 2014, the company recorded $1.1 million in charges related to the company’s reorganization of its internal legal structure, as noted above. |

[0001437749-16-026441:notes:200]
| g – | In the second quarter of 2014, the company recorded a $1.4 million non-cash charge related to the step-up of inventory from the SymCom acquisition (See Note 2), $2.0 million in severance charges and $0.2 million in acquisition costs. |

[0001437749-16-026441:notes:201]
| h – | In the first quarter of 2014, the company recorded a $1.4 million non-cash charge related to the step-up of inventory from the SymCom acquisition (See Note 2). |


## us-gaap:ReceivablesPolicyTextBlock

[0001437749-16-026441:notes:202]
Accounts Receivable
:

[0001437749-16-026441:notes:203]
The company performs credit evaluations of customers’ financial condition and generally does not require collateral. Credit losses are provided for in the financial statements based upon specific knowledge of a customer’s inability to meet its financial obligations to the company. Historically, credit losses have consistently been within management’s expectations and have not been a material amount. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0001437749-16-026441:notes:204]
The company also maintains allowances against accounts receivable for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-16-026441:notes:205]
Revenue Recognition
: The company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured and the pricing is fixed and determinable.

[0001437749-16-026441:notes:206]
At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The company’s distribution channels are primarily through direct sales and independent third party distributors.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001437749-16-026441:notes:207]
|  |  | Pension liability adjustments (a) |  |  | Gain on investments (b) |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 28, 2013 |  | $ | (17,140 | ) |  | $ | 9,393 |  |  | $ | 28,164 |  |  | $ | 20,417 |  |
| 2014 activity |  |  | (12,475 | ) |  |  | 1,398 |  |  |  | (30,466 | ) |  |  | (41,543 | ) |
| Balance at December 27, 2014 |  |  | (29,615 | ) |  |  | 10,791 |  |  |  | (2,302 | ) |  |  | (21,126 | ) |
| 2015 activity |  |  | 20,893 |  |  |  | 793 |  |  |  | (46,231 | ) |  |  | (24,545 | ) |
| Balance at January 2, 2016 |  | $ | (8,722 | ) |  | $ | 11,584 |  |  | $ | (48,533 | ) |  | $ | (45,671 | ) |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-16-026441:notes:208]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 344,305 |  |  | $ | 313,762 |  |  | $ | 274,666 |  |
| China |  |  | 193,792 |  |  |  | 189,191 |  |  |  | 158,494 |  |
| Other countries |  |  | 329,767 |  |  |  | 349,042 |  |  |  | 324,693 |  |
| Total net sales |  | $ | 867,864 |  |  | $ | 851,995 |  |  | $ | 757,853 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 23,965 |  |  | $ | 34,179 |  |  | $ | 27,294 |  |
| China |  |  | 37,241 |  |  |  | 40,981 |  |  |  | 45,843 |  |
| Canada |  |  | 10,488 |  |  |  | 12,899 |  |  |  | 14,429 |  |
| Other countries |  |  | 90,874 |  |  |  | 70,581 |  |  |  | 62,607 |  |
| Total long-lived assets |  | $ | 162,568 |  |  | $ | 158,640 |  |  | $ | 150,173 |  |

[0001437749-16-026441:notes:209]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 8,609 |  |  | $ | 9,134 |  |  | $ | 4,644 |  |
| China |  |  | 9,710 |  |  |  | 7,265 |  |  |  | 7,864 |  |
| Canada |  |  | 506 |  |  |  | 555 |  |  |  | 2,280 |  |
| Other countries |  |  | 25,194 |  |  |  | 15,327 |  |  |  | 20,165 |  |
| Total additions to long-lived assets |  | $ | 44,019 |  |  | $ | 32,281 |  |  | $ | 34,953 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001437749-16-026441:notes:210]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
| Nonvested December 27, 2014 |  |  | 188,998 |  |  | $ | 78.91 |  |
| Granted |  |  | 103,002 |  |  |  | 94.10 |  |
| Vested |  |  | (88,901 | ) |  |  | 73.59 |  |
| Forfeited |  |  | (8,638 | ) |  |  | 80.40 |  |
| Nonvested January 2, 2016 |  |  | 194,461 |  |  |  | 89.32 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-16-026441:notes:211]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 405,497 |  |  | $ | 410,065 |  |  | $ | 367,052 |  |
| Automotive |  |  | 339,957 |  |  |  | 325,415 |  |  |  | 267,207 |  |
| Industrial |  |  | 122,410 |  |  |  | 116,515 |  |  |  | 123,594 |  |
| Total net sales |  | $ | 867,864 |  |  | $ | 851,995 |  |  | $ | 757,853 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 22,936 |  |  | $ | 22,177 |  |  | $ | 20,735 |  |
| Automotive |  |  | 13,437 |  |  |  | 14,204 |  |  |  | 9,928 |  |
| Industrial |  |  | 5,268 |  |  |  | 5,494 |  |  |  | 3,817 |  |
| Total depreciation and amortization |  | $ | 41,641 |  |  | $ | 41,875 |  |  | $ | 34,480 |  |

[0001437749-16-026441:notes:212]
| (Table continued from prior page.) |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 78,194 |  |  | $ | 86,981 |  |  | $ | 69,559 |  |
| Automotive |  |  | 53,086 |  |  |  | 45,086 |  |  |  | 39,170 |  |
| Industrial |  |  | 18,094 |  |  |  | 10,674 |  |  |  | 24,363 |  |
| Other (1) |  |  | (45,217 | ) |  |  | (8,911 | ) |  |  | (3,211 | ) |
| Total operating income |  |  | 104,157 |  |  |  | 133,830 |  |  |  | 129,881 |  |
| Interest expense |  |  | 4,091 |  |  |  | 4,903 |  |  |  | 2,917 |  |
| Impairment and equity in net loss of unconsolidated affiliate (2) |  |  | — |  |  |  | — |  |  |  | 10,678 |  |
| Foreign exchange loss (gain) |  |  | (1,465 | ) |  |  | 3,925 |  |  |  | (3,303 | ) |
| Other expense (income), net |  |  | (5,417 | ) |  |  | (6,644 | ) |  |  | (4,646 | ) |
| Income before income taxes |  | $ | 106,948 |  |  | $ | 131,646 |  |  | $ | 124,235 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001437749-16-026441:notes:213]
|  |  | Shares Under Option |  |  | Weighted Average Price |  |  | Weighted Average Remaining Contract Life (Years) |  |  | Aggregate Intrinsic Value (000’s) |  |
| Outstanding December 27, 2014 |  |  | 421,862 |  |  | $ | 67.88 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 145,140 |  |  |  | 96.18 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (95,548 | ) |  |  | 48.74 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (550 | ) |  |  | 29.68 |  |  |  |  |  |  |  |  |  |
| Outstanding January 2, 2016 |  |  | 470,904 |  |  |  | 80.53 |  |  |  | 4.8 |  |  | $ | 12,470 |  |
| Exercisable January 2, 2016 |  |  | 199,472 |  |  |  | 66.23 |  |  |  | 3.6 |  |  |  | 8,135 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001437749-16-026441:notes:214]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Weighted average fair value of options granted |  | $ | 21.99 |  |  | $ | 26.25 |  |  | $ | 23.90 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 1.25 | % |  |  | 1.67 | % |  |  | 0.70 | % |
| Expected dividend yield |  |  | 1.04 | % |  |  | 0.93 | % |  |  | 1.20 | % |
| Expected stock price volatility |  |  | 28.0 | % |  |  | 33.0 | % |  |  | 45.0 | % |
| Expected life of options (years) |  |  | 4.6 |  |  |  | 4.6 |  |  |  | 5.1 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-16-026441:notes:215]
SCHEDULE II

[0001437749-16-026441:notes:216]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001437749-16-026441:notes:217]
(In thousands of USD)

[0001437749-16-026441:notes:218]
| Description |  | Balance at Beginning of Year |  |  | Charged to Costs and Expenses (1) |  |  | Deductions (2) |  |  | Other (3) |  |  | Balance at End of Year |  |
| Year ended January 2, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 278 |  |  | $ | 164 |  |  | $ | 150 |  |  | $ | 27 |  |  | $ | 319 |  |
| Reserves for sales discounts and allowances |  | $ | 19,140 |  |  | $ | 81,335 |  |  | $ | 82,997 |  |  | $ | (310 | ) |  | $ | 17,168 |  |
| Deferred tax valuation allowance |  | $ | 4,557 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,557 |  |
| Year ended December 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 790 |  |  | $ | 130 |  |  | $ | 656 |  |  | $ | 14 |  |  | $ | 278 |  |
| Reserves for sales discounts and allowances |  | $ | 16,117 |  |  | $ | 85,825 |  |  | $ | 82,568 |  |  | $ | (234 | ) |  | $ | 19,140 |  |
| Deferred tax valuation allowance |  | $ | 6,250 |  |  | $ | — |  |  | $ | 1,693 |  |  | $ | — |  |  | $ | 4,557 |  |
| Year ended December 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 705 |  |  | $ | 2,289 |  |  | $ | 2,316 |  |  | $ | 112 |  |  | $ | 790 |  |
| Reserves for sales discounts and allowances |  | $ | 12,803 |  |  | $ | 77,659 |  |  | $ | 74,432 |  |  | $ | 87 |  |  | $ | 16,117 |  |
| Deferred tax valuation allowance |  | $ | 784 |  |  | $ | 6,085 |  |  | $ | 619 |  |  | $ | — |  |  | $ | 6,250 |  |

[0001437749-16-026441:notes:219]
|  | (1) | Includes provision for doubtful accounts, sales returns and sales discounts granted to customers. |

[0001437749-16-026441:notes:220]
|  | (2) | Represents uncollectible accounts written off, net of recoveries and credits issued to customers and the write-off of certain deferred tax assets that previously had full valuation allowances. |

[0001437749-16-026441:notes:221]
|  | (3) | Represents business acquisitions and foreign currency translation adjustments. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-026441:notes:222]
15

[0001437749-16-026441:notes:223]
. Business Unit Segment Information

[0001437749-16-026441:notes:224]
An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer (“CEO”).

[0001437749-16-026441:notes:225]
The company reports its operations by the following business unit segments: Electronics, Automotive and Industrial.

[0001437749-16-026441:notes:226]
|  | ● | Electronics. Provides circuit protection components and expertise to leading global manufacturers of a wide range of electronic products including mobile phones, computers, LCD TVs, telecommunications equipment, medical devices, lighting products and white goods. The Electronics business segment has the broadest product offering in the industry including fuses and protectors, positive temperature coefficient (“PTC”) resettable fuses, varistors, polymer electrostatic discharge (“ESD”) suppressors, discrete transient voltage suppression (“TVS”) diodes, TVS diode arrays and protection thyristors, gas discharge tubes, power switching components and fuseholders, blocks and related accessories. |

[0001437749-16-026441:notes:227]
|  | ● | Automotive. Provides circuit protection products to the worldwide automotive original equipment manufacturers (“OEM”) and parts distributors of passenger automobiles, trucks, buses and off-road equipment. The company also sells its fuses in the automotive replacement parts market. Products include blade fuses, high current fuses, battery cable protectors and varistors. |

[0001437749-16-026441:notes:228]
|  | ● | Industrial (formerly Electrical). Provides circuit protection products for industrial and commercial customers. Products include power fuses and other circuit protection devices that are used in commercial and industrial buildings and large equipment such as HVAC systems, elevators and machine tools. |

[0001437749-16-026441:notes:229]
Each of the operating segments is directly responsible for sales, marketing and research and development. Manufacturing, purchasing, logistics, customer service, finance, information technology and human resources are shared functions that are allocated back to the three operating segments. The CEO allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss), but does not evaluate the operating segments using discrete balance sheet information.

[0001437749-16-026441:notes:230]
Sales, marketing and research and development expenses are charged directly into each operating segment. All other functions are shared by the operating segments and expenses for these shared functions are allocated to the operating segments and included in the operating results reported below. The company does not report inter-segment revenue because the operating segments do not record it. The company does not allocate interest and other income, interest expense, equity in loss of unconsolidated affiliate, or taxes to operating segments. Although the CEO uses operating income to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the company as a whole.

[0001437749-16-026441:notes:231]
The company has provided this business unit segment information for all comparable prior periods.

[0001437749-16-026441:notes:232]
Segment information is summarized as follows (in thousands):

[0001437749-16-026441:notes:233]
| (1) | Included in “Other” Operating income (loss) for 2015 are costs related to the transfer of the company’s reed switch manufacturing operations from its Lake Mills, Wisconsin and Suzhou, China locations to the Philippines ($5.2 million in Cost of sales (“COS”)), acquisition related fees ($4.6 million included in Selling, general and administrative expenses (“SG&A”)), pension settlement and other costs ($31.9 million in SG&A), internal legal restructuring costs ($3.6 million in SG&A) and (($0.2 million) of other in SG&A). |

[0001437749-16-026441:notes:234]
|  | Included in “Other” Operating income (loss) for 2014 are acquisition related fees ($0.4 million included in SG&A), non-cash charges for the sale of inventory that had been stepped-up to fair value at the acquisition date of SymCom ($2.8 million included in COS (See Note 2)), severance charges ($2.7 million in COS and $0.5 million in SG&A), internal legal restructuring costs ($2.2 million in SG&A) and asset impairments ($0.2 million in Research and development and $0.1 million in SG&A). |

[0001437749-16-026441:notes:235]
|  | Included in “Other” Operating income (loss) for 2013 are acquisition related fees ($1.7 million included in SG&A) and non-cash charges for the sale of inventory that had been stepped-up to fair value at the acquisition date of Hamlin ($1.5 million included in COS). |

[0001437749-16-026441:notes:236]
| (2) | During the first quarter of 2013, the company recorded approximately $10.7 million related to the impairment of Shocking Technologies. (See Note 6). |

[0001437749-16-026441:notes:237]
The company’s significant net sales, long-lived assets and additions to long-lived assets by country for the fiscal years ended 2015, 2014 and 2013 are as follows (in thousands):

[0001437749-16-026441:notes:238]
For the year ended January 2, 2016, approximately 60% of the company’s net sales were to customers outside the United States (exports and foreign operations) including 22% to China. No single customer accounted for more than 10% of net sales during the last three years.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001437749-16-026441:notes:239]
Shipping and Handling Fees and Costs
: Amounts billed to customers related to shipping and handling is classified as revenue. Costs incurred for shipping and handling of $7.0 million, $6.7 million and $6.5 million in 2015, 2014 and 2013, respectively, are classified in selling, general and administrative expenses.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-16-026441:notes:240]
1. Summary of Significant Accounting Policies and Other Information

[0001437749-16-026441:notes:241]
Nature of Operations
: Littelfuse, Inc. and subsidiaries (the “company”) design, manufacture and sell circuit protection devices for use in the automotive, electronics and industrial markets throughout the world. In addition to the broadest and deepest portfolio of circuit protection products and solutions, the company offers a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles and sensors for automobile safety systems, as well as protection relays and power distribution centers for the safe control and distribution of electricity.

[0001437749-16-026441:notes:242]
Fiscal Year
: The company’s fiscal years ended on January 2, 2016, December 27, 2014 and December 28, 2013. Fiscal year 2015 contained 53 weeks while fiscal years 2014 and 2013 each contained 52 weeks.

[0001437749-16-026441:notes:243]
Use of Estimates
: The process of preparing financial statements in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The company evaluates and updates its assumptions and estimates on an ongoing basis and may employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0001437749-16-026441:notes:244]
Fair Value of Financial Instruments
: The company’s financial instruments include cash and cash equivalents, accounts receivable, investments and long-term debt. The carrying values of such financial instruments approximate their estimated fair values.

[0001437749-16-026441:notes:245]
Investment in Unconsolidated Affiliate

[0001437749-16-026441:notes:246]
:

[0001437749-16-026441:notes:247]
Investments in unconsolidated affiliates over which the company has significant influence over the investees’ operating and financing activities are accounted for under the equity method of accounting. Investments in affiliates over which the company does not have the ability to exert significant influence over the investees’ operating and financing activities are accounted for under the cost method.

[0001437749-16-026441:notes:248]
Goodwill and Indefinite-Lived Intangible Assets:

[0001437749-16-026441:notes:249]
The company annually tests goodwill and indefinite-lived intangible assets for impairment on the first day of its fiscal fourth quarter or at other dates if there is an event or change in circumstances that indicates the asset may be impaired. The company has eight reporting units for testing purposes. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted five-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after five years) to estimate market value. In addition, the company compares its derived enterprise value on a consolidated basis to the company’s market capitalization as of its test date to ensure its derived value approximates the market value of the company when taken as a whole.

[0001437749-16-026441:notes:250]
As of the most recent annual test conducted on September 27, 2015, the company concluded the fair value of each of the reporting units exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. Specifically, the company noted that its headroom, defined as the excess of fair value over the carrying value of invested capital, was 148%, 95%, 188%, 218%, 76%, 26%, 12% and 198% for its electronics (non-silicon), electronics (silicon), passenger car products, commercial vehicle products, automotive sensor products, relay, custom and power fuse reporting units, respectively, at September 27, 2015. Certain key assumptions used in the annual test included a discount rate of 11.7% and a long-term growth rate of 3.0% which were used for all reporting units except for automotive sensor and relay which had a discount rate of 13.7% as a result of a 2.0% premium factor and custom products which had a discount rate of 14.7% as a result of a 3.0% premium factor.

[0001437749-16-026441:notes:251]
In addition, the company performed a sensitivity test at September 27, 2015 that showed a 100 basis point increase in its discount rate or a 100 basis point decrease in the long-term growth rate for each reporting unit would not have changed the company’s conclusion that no potential goodwill impairment existed at September 27, 2015.

[0001437749-16-026441:notes:252]
The company will continue to perform a goodwill and indefinite-lived intangible asset impairment test as required on an annual basis and on an interim basis, if certain impairment conditions exist. Factors the company considers important, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the company does not believe its future operating results will vary significantly relative to its historical and projected future operating results.

[0001437749-16-026441:notes:253]
Intangible Assets
: Trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of five to 20 years. Patents, licenses and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of seven to 17 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of three to 20 years. Other intangible assets are also tested for impairment when there is a significant event that may cause the asset to be impaired.

[0001437749-16-026441:notes:254]
Environmental Liabilities
: Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the company’s recorded liability for such claims, the company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0001437749-16-026441:notes:255]
Pension and Other Post-retirement Benefits
: Accounting for pensions requires estimating the future benefit cost and recognizing the cost over the employee’s expected period of employment with the company. Certain assumptions are required in the calculation of pension costs and obligations. These assumptions include the discount rate, salary scales and the expected long-term rate of return on plan assets. The discount rate is intended to represent the rate at which pension benefit obligations could be settled by purchase of an annuity contract. These assumptions are subject to change based on stock and bond market returns and other economic factors. Actual results that differ from the company’s assumptions are accumulated and amortized over future periods and therefore generally affect its recognized expense and accrued liability in such future periods. While the company believes that its assumptions are appropriate given current economic conditions and its actual experience, significant differences in results or significant changes in the company’s assumptions may materially affect its pension obligations and related future expense. During 2015, the company terminated the U.S. defined benefit pension plan which resulted in a settlement of the plan’s liabilities resulting in a pre-tax charge of $29.9 million. See Note 12 for additional information.

[0001437749-16-026441:notes:256]
Reclassifications:
 Certain amounts presented in the 2014 financial statements have been reclassified to conform to the 2015 presentation - specifically a reclassification was made to the company’s current deferred tax assets from short-term to long-term. This reclassification resulted from the company’s early adoption of ASU 2015-17 “Balance Sheet Classification of Deferred Taxes (ASC 740, income taxes)” which requires all deferred taxes to be presented as long-term. The amount of current deferred tax assets that were reclassified to long-term deferred tax assets for the fiscal year 2014 was $17.5 million at December 27, 2014. This reclassification had no impact on net income, cash flows or shareholders’ equity.

[0001437749-16-026441:notes:257]
Returns

[0001437749-16-026441:notes:258]
Credits
: Some of the terms of the company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-16-026441:notes:259]
Volume Rebates

[0001437749-16-026441:notes:260]
The company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-16-026441:notes:261]
Allowance for Doubtful Accounts:
 The company evaluates the collectability of its trade receivables based on a combination of factors. The company regularly analyzes its significant customer accounts and, when the company becomes aware of a specific customer’s inability to meet its financial obligations, the company records a specific reserve for bad debt to reduce the related receivable to the amount the 
company reasonably believes is collectible. The company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Accounts receivable balances that are deemed to be uncollectible, are written off against the reserve on a case-by-case basis. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted. However, due to the company’s diverse customer base and lack of credit concentration, the company does not believe its estimates would be materially impacted by changes in its assumptions.

[0001437749-16-026441:notes:262]
Stock-based Compensation
: The company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as both operating and financing cash flows. See Note 13 for additional information on stock-based compensation.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-16-026441:notes:263]
13. Shareholders’ Equity

[0001437749-16-026441:notes:264]
Equity Plans
: The company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, performance shares and other stock rights of employees and directors. As of January 2, 2016, there were approximately 0.6 million shares available for issuance of future awards under the company’s equity-based compensation plans.

[0001437749-16-026441:notes:265]
Stock options granted prior to 2002 vested over a five-year period and are exercisable over a ten-year period commencing from the date of vesting. The stock options granted in 2002 through February 2005 vested over a five-year period and are exercisable over a ten-year period commencing from the date of the grant. Stock options granted after February 2005 vest over a three, four or five-year period and are exercisable over either a seven or ten-year period commencing from the date of the grant. Restricted shares and share units granted by the company vest over three to four years.

[0001437749-16-026441:notes:266]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended January 2, 2016.

[0001437749-16-026441:notes:267]
The following table provides a reconciliation of non-vested restricted share and share unit awards for the fiscal year ended January 2, 2016.

[0001437749-16-026441:notes:268]
The total intrinsic value of options exercised during 2015, 2014 and 2013 was $5.0 million, $9.6 million, and $15.3 million, respectively. The total fair value of shares vested was $8.1 million, $7.6 million, and $6.5 million for 2015, 2014 and 2013, respectively. The total amount of share-based liabilities paid was $0.4 million, $0.3 million and $0.1 million for 2015, 2014 and 2013, respectively.

[0001437749-16-026441:notes:269]
The company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At January 2, 2016, the unrecognized compensation cost for options, restricted shares and performance shares was $13.2 million before tax, and will be recognized over a weighted-average period of 1.9 years. Compensation cost included as a component of selling, general and administrative expense for all equity compensation plans discussed above was $10.7 million, $9.4 million and $8.9 million for 2015, 2014 and 2013, respectively. The total income tax benefit recognized in the Consolidated Statements of Net Income was $3.7 million, $3.3 million and $3.2 million for 2015, 2014 and 2013, respectively.

[0001437749-16-026441:notes:270]
The company uses the Black-Scholes option valuation model to determine the fair value of awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0001437749-16-026441:notes:271]
Expected volatilities are based on the historical volatility of the company’s stock price. The expected life of options is based on historical data for options granted by the company

[0001437749-16-026441:notes:272]
The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption.

[0001437749-16-026441:notes:273]
Accumulated Other Comprehensive Income (Loss)

[0001437749-16-026441:notes:274]
(AOCI)
: The following table sets forth the changes in the components of AOCI by component for fiscal years 2015, 2014 and 2013 (in thousands):

[0001437749-16-026441:notes:275]
| (a) | Net of tax of $661, $12,587, and $6,549 for 2015, 2014 and 2013, respectively. |

[0001437749-16-026441:notes:276]
| (b) | Net of tax of $0, $0 and $0 for 2015, 2014 and 2013, respectively. |

[0001437749-16-026441:notes:277]
Preferred Stock
: The Board of Directors may authorize the issuance of preferred stock from time to time in one or more series with such designations, preferences, qualifications, limitations, restrictions and optional or other special rights as the Board may fix by resolution.

[0001437749-16-026441:notes:278]
The Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2015 to April 30, 2016. The company repurchased 350,000 of its shares in fiscal 2015 and 650,000 shares remain available for purchase under the initial program as of January 2, 2016.


## us-gaap:SubsequentEventsTextBlock

[0001437749-16-026441:notes:279]
19. Subsequent Event

[0001437749-16-026441:notes:280]
On November 7, 2015, the company and TE Connectivity Ltd., a Swiss corporation, entered into a

[0001437749-16-026441:notes:281]
stock and asset purchase agreement for $350.0 million, pursuant to which the company has agreed to acquire TE’s circuit protection business. The company expects to close the acquisition by the end of the first quarter of 2016. The company will fund the acquisition with available cash and proceeds from credit facilities.
