# LFUS note change history — 0000889331-23-000131 → 0000889331-23-000157


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0000889331-23-000157:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 30, 2023 and October 1, 2022:
  (was, 2023-08-02, similarity 0.899):
[0000889331-23-000131:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 1, 2023 and July 2, 2022:

- added (2023-11-01):
[0000889331-23-000157:note_history:2]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,410 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,410 |  |  | $ | 453,860 |  |  | $ | — |  |  | $ | — |  |  | $ | 453,860 |  |
| Electronics – Semiconductor |  | 191,523 |  |  | — |  |  | — |  |  | 191,523 |  |  | 598,813 |  |  | — |  |  | — |  |  | 598,813 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  | — |  |  | — |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- changed (2023-11-01):
[0000889331-23-000157:note_history:3]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  |  |  |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |
  (was, 2023-08-02, similarity 0.9752):
[0000889331-23-000131:note_history:3]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  |  |  |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- changed (2023-11-01):
[0000889331-23-000157:note_history:4]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at September 30, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2023-08-02, similarity 0.7591):
[0000889331-23-000131:note_history:4]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at July 1, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2023-11-01):
[0000889331-23-000157:note_history:5]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 560,056 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | — |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,535 |  |  | 1,549 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 561,591 |  |  | $ | 564,939 |  |
  (was, 2023-08-02, similarity 0.9432):
[0000889331-23-000131:note_history:5]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 480,743 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 771 |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,580 |  |  | 1,549 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 483,094 |  |  | $ | 564,939 |  |

- added (2023-11-01):
[0000889331-23-000157:note_history:6]
In October 2023, the Financial Accounting Standards Board ("FASB") issued ASU No. 2023-06, "Disclosure Improvements". The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and  will not be effective until June 30, 2027. The company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

- changed (2023-11-01):
[0000889331-23-000157:note_history:7]
In March 2023, the FASB issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective on January 1, 2024. The Company does not expect any material effect on the Company's Condensed Consolidated Financial Statements.
  (was, 2023-08-02, similarity 0.9811):
[0000889331-23-000131:note_history:7]
In March 2023, the Financial Accounting Standards Board ("FASB") issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective on January 1, 2024. The Company does not expect any material effect on the Company's Condensed Consolidated Financial Statements.

- removed (2023-11-01):
[0000889331-23-000131:note_history:8]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,852 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,852 |  |  | $ | 301,450 |  |  | $ | — |  |  | $ | — |  |  | $ | 301,450 |  |
| Electronics – Semiconductor |  | 197,295 |  |  | — |  |  | — |  |  | 197,295 |  |  | 407,290 |  |  | — |  |  | — |  |  | 407,290 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  | — |  |  | — |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0000889331-23-000157:note_history:9]
The carrying amounts of debt at September 30, 2023 and December 31, 2022 are as follows:
  (was, 2023-08-02, similarity 0.9139):
[0000889331-23-000131:note_history:9]
The carrying amounts of debt at July 1, 2023 and December 31, 2022 are as follows:

- changed (2023-11-01):
[0000889331-23-000157:note_history:10]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 290,625 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 123,605 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 100,363 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,056 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,024) |  |  | (4,847) |  |
| Total debt |  | 992,625 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (135,619) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 857,006 |  |  | $ | 866,623 |  |
  (was, 2023-08-02, similarity 0.972):
[0000889331-23-000131:note_history:10]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 292,500 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,220 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,298 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,942 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,302) |  |  | (4,847) |  |
| Total debt |  | 1,001,658 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,435) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 864,223 |  |  | $ | 866,623 |  |

- changed (2023-11-01):
[0000889331-23-000157:note_history:11]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to
  (was, 2023-08-02, similarity 0.8408):
[0000889331-23-000131:note_history:11]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

- added (2023-11-01):
[0000889331-23-000157:note_history:12]
0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

- changed (2023-11-01):
[0000889331-23-000157:note_history:13]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 30, 2023, the Company made payments of $1.9 million and $5.6 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $290.6 million, respectively, as of September 30, 2023.
  (was, 2023-08-02, similarity 0.9732):
[0000889331-23-000131:note_history:13]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended July 1, 2023, the Company made payments of $1.9 million and $3.8 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $292.5 million, respectively, as of July 1, 2023.

- changed (2023-11-01):
[0000889331-23-000157:note_history:14]
As of September 30, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.67%.
  (was, 2023-08-02, similarity 0.9395):
[0000889331-23-000131:note_history:14]
As of July 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.45%.

- added (2023-11-01):
[0000889331-23-000157:note_history:15]
As of September 30, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of September 30, 2023, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2023-11-01):
[0000889331-23-000157:note_history:16]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 30, 2023, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2023-08-02, similarity 0.9396):
[0000889331-23-000131:note_history:16]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At July 1, 2023, the Company was in compliance with all covenants under the Senior Notes.

- added (2023-11-01):
[0000889331-23-000157:note_history:17]
Interest paid on all Company debt was $11.9 million and $8.5 million for the three months ended September 30, 2023 and October 1, 2022, respectively, and $33.2 million and $16.9 million for the nine months ended September 30, 2023 and October 1, 2022, respectively.

- removed (2023-11-01):
[0000889331-23-000131:note_history:18]
As of July 1, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of July 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.

- removed (2023-11-01):
[0000889331-23-000131:note_history:19]
Interest paid on all Company debt was $10.3 million and $2.3 million for the three months ended July 1, 2023 and July 2, 2022, respectively, and $21.3 million and $8.4 million for the six months ended July 1, 2023 and July 2, 2022, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0000889331-23-000157:note_history:20]
The carrying amounts of debt at September 30, 2023 and December 31, 2022 are as follows:
  (was, 2023-08-02, similarity 0.9139):
[0000889331-23-000131:note_history:20]
The carrying amounts of debt at July 1, 2023 and December 31, 2022 are as follows:

- changed (2023-11-01):
[0000889331-23-000157:note_history:21]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 290,625 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 123,605 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 100,363 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,056 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,024) |  |  | (4,847) |  |
| Total debt |  | 992,625 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (135,619) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 857,006 |  |  | $ | 866,623 |  |
  (was, 2023-08-02, similarity 0.972):
[0000889331-23-000131:note_history:21]
| (in thousands) |  | July 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 292,500 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,220 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,298 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,942 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,302) |  |  | (4,847) |  |
| Total debt |  | 1,001,658 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,435) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 864,223 |  |  | $ | 866,623 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0000889331-23-000157:note_history:22]
|  |  | Three Months Ended September 30, 2023 |  | Three Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.1 |  | 2.0 |  |  | — |  | 0.1 |  | 2.9 |  |
|  |  | Nine Months Ended September 30, 2023 |  | Nine Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.3 |  | 0.3 |  | 7.6 |  |  | 0.3 |  | 0.3 |  | 8.8 |  |
|  |  | September 30, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.8 |  | $ | — |  | $ | 1.6 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |
  (was, 2023-08-02, similarity 0.6891):
[0000889331-23-000131:note_history:22]
|  |  | Three Months Ended July 1, 2023 |  | Three Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.1 |  | 2.9 |  |  | 0.1 |  | 0.1 |  | 3.0 |  |
|  |  | Six Months Ended July 1, 2023 |  | Six Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.1 |  | 0.2 |  | 5.6 |  |  | 0.3 |  | 0.2 |  | 5.9 |  |
|  |  | July 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.7 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0000889331-23-000157:note_history:23]
|  |  | Three Months Ended September 30, 2023 |  | Three Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.1 |  | 2.0 |  |  | — |  | 0.1 |  | 2.9 |  |
|  |  | Nine Months Ended September 30, 2023 |  | Nine Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.3 |  | 0.3 |  | 7.6 |  |  | 0.3 |  | 0.3 |  | 8.8 |  |
|  |  | September 30, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.8 |  | $ | — |  | $ | 1.6 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |
  (was, 2023-08-02, similarity 0.6891):
[0000889331-23-000131:note_history:23]
|  |  | Three Months Ended July 1, 2023 |  | Three Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.1 |  | 2.9 |  |  | 0.1 |  | 0.1 |  | 3.0 |  |
|  |  | Six Months Ended July 1, 2023 |  | Six Months Ended July 2, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.1 |  | 0.2 |  | 5.6 |  |  | 0.3 |  | 0.2 |  | 5.9 |  |
|  |  | July 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.7 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-01):
[0000889331-23-000157:note_history:24]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 30, 2023 and October 1, 2022:
  (was, 2023-08-02, similarity 0.899):
[0000889331-23-000131:note_history:24]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 1, 2023 and July 2, 2022:

- added (2023-11-01):
[0000889331-23-000157:note_history:25]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,410 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,410 |  |  | $ | 453,860 |  |  | $ | — |  |  | $ | — |  |  | $ | 453,860 |  |
| Electronics – Semiconductor |  | 191,523 |  |  | — |  |  | — |  |  | 191,523 |  |  | 598,813 |  |  | — |  |  | — |  |  | 598,813 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  | — |  |  | — |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- changed (2023-11-01):
[0000889331-23-000157:note_history:26]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  |  |  |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |
  (was, 2023-08-02, similarity 0.9752):
[0000889331-23-000131:note_history:26]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  |  |  |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- removed (2023-11-01):
[0000889331-23-000131:note_history:27]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,852 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,852 |  |  | $ | 301,450 |  |  | $ | — |  |  | $ | — |  |  | $ | 301,450 |  |
| Electronics – Semiconductor |  | 197,295 |  |  | — |  |  | — |  |  | 197,295 |  |  | 407,290 |  |  | — |  |  | — |  |  | 407,290 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  | — |  |  | — |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |
