# LFUS notes — 0000889331-23-000157


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-23-000157:notes:1]
[same as prior period, unchanged from 0000889331-23-000131:notes:1]

[0000889331-23-000157:notes:2]
[same as prior period, unchanged from 0000889331-23-000131:notes:2]

[0000889331-23-000157:notes:3]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-23-000157:notes:4]
[same as prior period, unchanged from 0000889331-23-000131:notes:4]

[0000889331-23-000157:notes:5]
[same as prior period, unchanged from 0000889331-23-000131:notes:5]

[0000889331-23-000157:notes:6]
[same as prior period, unchanged from 0000889331-23-000131:notes:6]

[0000889331-23-000157:notes:7]
[same as prior period, unchanged from 0000889331-23-000131:notes:7]

[0000889331-23-000157:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 30, 2023 and October 1, 2022:

[0000889331-23-000157:notes:9]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,410 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,410 |  |  | $ | 453,860 |  |  | $ | — |  |  | $ | — |  |  | $ | 453,860 |  |
| Electronics – Semiconductor |  | 191,523 |  |  | — |  |  | — |  |  | 191,523 |  |  | 598,813 |  |  | — |  |  | — |  |  | 598,813 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  | — |  |  | — |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

[0000889331-23-000157:notes:10]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  |  |  |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |

[0000889331-23-000157:notes:11]
[same as prior period, unchanged from 0000889331-23-000131:notes:11]

[0000889331-23-000157:notes:12]
[same as prior period, unchanged from 0000889331-23-000131:notes:12]

[0000889331-23-000157:notes:13]
[same as prior period, unchanged from 0000889331-23-000131:notes:13]

[0000889331-23-000157:notes:14]
[same as prior period, unchanged from 0000889331-23-000131:notes:14]

[0000889331-23-000157:notes:15]
[same as prior period, unchanged from 0000889331-23-000131:notes:15]

[0000889331-23-000157:notes:16]
[same as prior period, unchanged from 0000889331-23-000131:notes:16]

[0000889331-23-000157:notes:17]
[same as prior period, unchanged from 0000889331-23-000131:notes:17]

[0000889331-23-000157:notes:18]
[same as prior period, unchanged from 0000889331-23-000131:notes:18]

[0000889331-23-000157:notes:19]
[same as prior period, unchanged from 0000889331-23-000131:notes:19]

[0000889331-23-000157:notes:20]
[same as prior period, unchanged from 0000889331-23-000131:notes:20]

[0000889331-23-000157:notes:21]
[same as prior period, unchanged from 0000889331-23-000131:notes:21]

[0000889331-23-000157:notes:22]
[same as prior period, unchanged from 0000889331-23-000131:notes:22]

[0000889331-23-000157:notes:23]
[same as prior period, unchanged from 0000889331-23-000131:notes:23]

[0000889331-23-000157:notes:24]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at September 30, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-23-000157:notes:25]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 560,056 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | — |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,535 |  |  | 1,549 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 561,591 |  |  | $ | 564,939 |  |

[0000889331-23-000157:notes:26]
Recently Issued Accounting Standards

[0000889331-23-000157:notes:27]
In October 2023, the Financial Accounting Standards Board ("FASB") issued ASU No. 2023-06, "Disclosure Improvements". The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and  will not be effective until June 30, 2027. The company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

[0000889331-23-000157:notes:28]
In March 2023, the FASB issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective on January 1, 2024. The Company does not expect any material effect on the Company's Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000889331-23-000157:notes:29]
[same as prior period, unchanged from 0000889331-23-000131:notes:28]

[0000889331-23-000157:notes:30]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of

[0000889331-23-000157:notes:31]
the acquired business are included in the Company’s Condensed Consolidated Financial Statements from the date of the acquisition.

[0000889331-23-000157:notes:32]
Dortmund Fab

[0000889331-23-000157:notes:33]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the fab is approximately 93 million Euro, of which 37.2 million Euro down payment (approximately $40.5 million) recorded in Other long-term assets in the Condensed Consolidated Balance Sheets was paid in the third quarter after regulatory approvals and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2023 or 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-23-000157:notes:34]
[same as prior period, unchanged from 0000889331-23-000131:notes:30]

[0000889331-23-000157:notes:35]
On February 3, 2023, the Company completed the acquisition of Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The business is reported within the Company’s Industrial segment.

[0000889331-23-000157:notes:36]
[same as prior period, unchanged from 0000889331-23-000131:notes:33]

[0000889331-23-000157:notes:37]
[same as prior period, unchanged from 0000889331-23-000131:notes:34]

[0000889331-23-000157:notes:38]
[same as prior period, unchanged from 0000889331-23-000131:notes:35]

[0000889331-23-000157:notes:39]
[same as prior period, unchanged from 0000889331-23-000131:notes:36]

[0000889331-23-000157:notes:40]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and nine months ended September 30, 2023 are net sales of $2.7 million and $10.2 million respectively, and a loss before income taxes of $1.0 million and $0.8 million, respectively, since the February 3, 2023 acquisition of Western Automation.

[0000889331-23-000157:notes:41]
During the nine months ended September 30, 2023, the Company incurred approximately $1.2 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-23-000157:notes:42]
[same as prior period, unchanged from 0000889331-23-000131:notes:39]

[0000889331-23-000157:notes:43]
[same as prior period, unchanged from 0000889331-23-000131:notes:40]

[0000889331-23-000157:notes:44]
The acquisition was funded through a combination of cash on hand and debt. The total purchase consideration of $523.0 million, net of cash acquired, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0000889331-23-000157:notes:45]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the C&K acquisition:

[0000889331-23-000157:notes:46]
[same as prior period, unchanged from 0000889331-23-000131:notes:44]

[0000889331-23-000157:notes:47]
[same as prior period, unchanged from 0000889331-23-000131:notes:45]

[0000889331-23-000157:notes:48]
During the nine months ended September 30, 2023, the Company recorded measurement period adjustments to increase other non-current liabilities of $4.2 million associated with uncertain tax positions, income taxes payable of $0.2 million, and reduce accrued liabilities of $0.3 million and deferred tax liabilities of $0.2 million. As a result of these adjustments, goodwill was increased by $3.9 million.

[0000889331-23-000157:notes:49]
[same as prior period, unchanged from 0000889331-23-000131:notes:47]

[0000889331-23-000157:notes:50]
[same as prior period, unchanged from 0000889331-23-000131:notes:48]

[0000889331-23-000157:notes:51]
[same as prior period, unchanged from 0000889331-23-000131:notes:49]

[0000889331-23-000157:notes:52]
[same as prior period, unchanged from 0000889331-23-000131:notes:50]

[0000889331-23-000157:notes:53]
[same as prior period, unchanged from 0000889331-23-000131:notes:51]

[0000889331-23-000157:notes:54]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands, except per share amounts) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Net sales |  | $ | 607,071 |  |  | $ | 669,956 |  |  | $ | 1,830,736 |  |  | $ | 1,376,586 |  |
| Income before income taxes |  | 75,071 |  |  | 107,585 |  |  | 271,165 |  |  | 271,474 |  |
| Net income |  | 57,591 |  |  | 83,713 |  |  | 217,930 |  |  | 222,514 |  |
| Net income per share — basic |  | 2.31 |  |  | 3.38 |  |  | 8.77 |  |  | 12.38 |  |
| Net income per share — diluted |  | 2.29 |  |  | 3.35 |  |  | 8.68 |  |  | 12.26 |  |

[0000889331-23-000157:notes:55]
[same as prior period, unchanged from 0000889331-23-000131:notes:53]

[0000889331-23-000157:notes:56]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Amortization (a) |  | $ | — |  |  | $ | (1,512) |  |  | $ | (479) |  |  | $ | (8,951) |  |
| Depreciation |  | — |  |  | 451 |  |  | — |  |  | 1,979 |  |
| Transaction costs (b) |  | (224) |  |  | 3,772 |  |  | 1,203 |  |  | 8,015 |  |
| Amortization of inventory step-up (c) |  | — |  |  | 6,765 |  |  | — |  |  | 11,534 |  |
| Interest expense (d) |  | — |  |  | 497 |  |  | — |  |  | 815 |  |
| Income tax benefit (expense) of above items |  | 28 |  |  | (2,644) |  |  | (91) |  |  | (3,893) |  |

[0000889331-23-000157:notes:57]
(a) The amortization adjustment for the nine months ended September 30, 2023 and three and nine months ended October 1, 2022 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-23-000157:notes:58]
(b) The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three and nine months ended September 30, 2023 and three and nine months ended October 1, 2022, and recognition of those fees during the three and nine months ended September 30, 2023.

[0000889331-23-000157:notes:59]
[same as prior period, unchanged from 0000889331-23-000131:notes:57]

[0000889331-23-000157:notes:60]
[same as prior period, unchanged from 0000889331-23-000131:notes:58]


## us-gaap:InventoryDisclosureTextBlock

[0000889331-23-000157:notes:61]
[same as prior period, unchanged from 0000889331-23-000131:notes:59]

[0000889331-23-000157:notes:62]
The components of inventories at September 30, 2023 and December 31, 2022 are as follows:

[0000889331-23-000157:notes:63]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Raw materials |  | $ | 214,588 |  |  | $ | 231,043 |  |
| Work in process |  | 134,657 |  |  | 134,792 |  |
| Finished goods |  | 192,365 |  |  | 226,215 |  |
| Inventory reserves |  | (58,535) |  |  | (44,360) |  |
| Total |  | $ | 483,075 |  |  | $ | 547,690 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-23-000157:notes:64]
[same as prior period, unchanged from 0000889331-23-000131:notes:62]

[0000889331-23-000157:notes:65]
The components of net property, plant, and equipment at September 30, 2023 and December 31, 2022 are as follows:

[0000889331-23-000157:notes:66]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Land and land improvements |  | $ | 21,579 |  |  | $ | 22,089 |  |
| Building and building improvements |  | 194,322 |  |  | 191,733 |  |
| Machinery and equipment |  | 846,065 |  |  | 812,540 |  |
| Accumulated depreciation |  | (583,060) |  |  | (545,252) |  |
| Total |  | $ | 478,906 |  |  | $ | 481,110 |  |

[0000889331-23-000157:notes:67]
The Company recorded depreciation expense of $17.9 million and $17.0 million for the three months ended September 30, 2023 and October 1, 2022, respectively, and $53.5 million and $48.3 million for the nine months ended September 30, 2023 and October 1, 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-23-000157:notes:68]
[same as prior period, unchanged from 0000889331-23-000131:notes:66]

[0000889331-23-000157:notes:69]
Changes in the carrying value of goodwill by segment for the nine months ended September 30, 2023 are as follows:

[0000889331-23-000157:notes:70]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net book value of goodwill as of December 31, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 31, 2022 |  | $ | 909,167 |  |  | $ | 234,793 |  |  | $ | 84,889 |  |  | $ | 1,228,849 |  |
| Accumulated impairment losses as of December 31, 2022 |  | — |  |  | (33,401) |  |  | (8,526) |  |  | (41,927) |  |
| Total |  | 909,167 |  |  | 201,392 |  |  | 76,363 |  |  | 1,186,922 |  |
| Changes during 2023: |  |  |  |  |  |  |  |  |
| Additions (a) |  | 3,879 |  |  | — |  |  | 94,823 |  |  | 98,702 |  |
| Currency translation |  | 676 |  |  | (1,616) |  |  | (341) |  |  | (1,281) |  |
| Net book value of goodwill as of September 30, 2023 |  |  |  |  |  |  |  |  |
| Gross goodwill as of September 30, 2023 |  | 913,722 |  |  | 232,668 |  |  | 179,401 |  |  | 1,325,791 |  |
| Accumulated impairment losses as of September 30, 2023 |  | — |  |  | (32,892) |  |  | $ | (8,556) |  |  | (41,448) |  |
| Total |  | $ | 913,722 |  |  | $ | 199,776 |  |  | $ | 170,845 |  |  | $ | 1,284,343 |  |

[0000889331-23-000157:notes:71]
[same as prior period, unchanged from 0000889331-23-000131:notes:69]

[0000889331-23-000157:notes:72]
The components of other intangible assets as of September 30, 2023 and December 31, 2022 are as follows:

[0000889331-23-000157:notes:73]
|  |  |  | As of September 30, 2023 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 17,133 |  |  | $ | 2,579 |  |  | $ | 14,554 |  |
| Patents, licenses, and software |  |  | 269,219 |  |  | 154,983 |  |  | 114,236 |  |
| Distribution network |  |  | 42,888 |  |  | 42,888 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 679,246 |  |  | 195,670 |  |  | 483,576 |  |
| Total |  |  | $ | 1,008,486 |  |  | $ | 396,120 |  |  | $ | 612,366 |  |

[0000889331-23-000157:notes:74]
[same as prior period, unchanged from 0000889331-23-000131:notes:72]

[0000889331-23-000157:notes:75]
During the three months ended September 30, 2023 and October 1, 2022, the Company recorded amortization expense of $16.0 million and $15.6 million, respectively. During the nine months ended September 30, 2023 and October 1, 2022, the Company recorded amortization expense of $49.8 million and $39.9 million, respectively.

[0000889331-23-000157:notes:76]
During the nine months ended September 30, 2023, the Company recorded additions to intangible assets of $68.0 million, related to the Western Automation acquisition, the components of which were as follows:

[0000889331-23-000157:notes:77]
[same as prior period, unchanged from 0000889331-23-000131:notes:75]

[0000889331-23-000157:notes:78]
Estimated annual amortization expense related to intangible assets with definite lives as of September 30, 2023 is as follows:

[0000889331-23-000157:notes:79]
| (in thousands) | Amount |
| 2023 | $ | 65,693 |  |
| 2024 | 62,578 |  |
| 2025 | 62,258 |  |
| 2026 | 51,475 |  |
| 2027 | 49,470 |  |
| 2028 and thereafter | 370,665 |  |
| Total | $ | 662,139 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-23-000157:notes:80]
[same as prior period, unchanged from 0000889331-23-000131:notes:78]

[0000889331-23-000157:notes:81]
The components of accrued liabilities as of September 30, 2023 and December 31, 2022 are as follows:

[0000889331-23-000157:notes:82]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Employee-related liabilities |  | $ | 68,367 |  |  | $ | 99,089 |  |
| Current lease liability |  | 11,839 |  |  | 12,841 |  |
| Other non-income taxes |  | 8,639 |  |  | 10,594 |  |
| Professional services |  | 6,159 |  |  | 7,160 |  |
| Other customer reserves |  | 4,804 |  |  | 5,064 |  |
| Interest |  | 3,687 |  |  | 4,449 |  |
| Deferred revenue |  | 2,126 |  |  | 2,593 |  |
| Restructuring liability |  | 2,075 |  |  | 2,434 |  |
| Current benefit liability |  | 1,318 |  |  | 1,318 |  |
| Other |  | 34,526 |  |  | 41,515 |  |
| Total |  | $ | 143,540 |  |  | $ | 187,057 |  |

[0000889331-23-000157:notes:83]
[same as prior period, unchanged from 0000889331-23-000131:notes:81]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-23-000157:notes:84]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three and nine months ended September 30, 2023 and October 1, 2022 as follows:

[0000889331-23-000157:notes:85]
|  | Three months ended September 30, 2023 |  | Nine months ended September 30, 2023 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,174 |  |  | $ | 1,665 |  |  | $ | 293 |  |  | $ | 3,132 |  |  | $ | 2,833 |  |  | $ | 2,598 |  |  | $ | 887 |  |  | $ | 6,318 |  |
| Other restructuring charges | 64 |  |  | 138 |  |  | 364 |  |  | 566 |  |  | 321 |  |  | 822 |  |  | 1,018 |  |  | 2,161 |  |
| Total restructuring charges | 1,238 |  |  | 1,803 |  |  | 657 |  |  | 3,698 |  |  | 3,154 |  |  | 3,420 |  |  | 1,905 |  |  | 8,479 |  |
| Impairment | — |  |  | — |  |  | 818 |  |  | 818 |  |  | — |  |  | 3,870 |  |  | 872 |  |  | 4,742 |  |
| Total | $ | 1,238 |  |  | $ | 1,803 |  |  | $ | 1,475 |  |  | $ | 4,516 |  |  | $ | 3,154 |  |  | $ | 7,290 |  |  | $ | 2,777 |  |  | $ | 13,221 |  |

[0000889331-23-000157:notes:86]
|  | Three months ended October 1, 2022 |  | Nine months ended October 1, 2022 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,401 |  |  | $ | 1,574 |  |  | $ | — |  |  | $ | 2,975 |  |  | $ | 1,807 |  |  | $ | 1,997 |  |  | $ | — |  |  | $ | 3,804 |  |
| Other restructuring charges | 73 |  |  | 365 |  |  | — |  |  | 438 |  |  | 76 |  |  | 385 |  |  | — |  |  | 461 |  |
| Total | $ | 1,474 |  |  | $ | 1,939 |  |  | $ | — |  |  | $ | 3,413 |  |  | $ | 1,883 |  |  | $ | 2,382 |  |  | $ | — |  |  | $ | 4,265 |  |

[0000889331-23-000157:notes:87]
[same as prior period, unchanged from 0000889331-23-000131:notes:85]

[0000889331-23-000157:notes:88]
For the three and nine months ended September 30, 2023, the Company recorded total restructuring charges of $3.7 million and $8.5 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment’s commercial vehicle business, and the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K acquisition. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate.

[0000889331-23-000157:notes:89]
[same as prior period, unchanged from 0000889331-23-000131:notes:87]

[0000889331-23-000157:notes:90]
For the three and nine months ended October 1, 2022, the Company recorded total restructuring charges of $3.4 million and $4.3 million, respectively. primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions within the passenger vehicle and automotive sensor businesses in the Transportation segment and the reorganization of selling and administrative functions due to the C&K acquisition within the Electronics segment.

[0000889331-23-000157:notes:91]
The restructuring liability as of September 30, 2023 and December 31, 2022 is $2.1 million and $2.4 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in the third quarter fiscal year 2024.


## us-gaap:DebtDisclosureTextBlock

[0000889331-23-000157:notes:92]
Debt

[0000889331-23-000157:notes:93]
The carrying amounts of debt at September 30, 2023 and December 31, 2022 are as follows:

[0000889331-23-000157:notes:94]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 290,625 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 123,605 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 100,363 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,056 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,024) |  |  | (4,847) |  |
| Total debt |  | 992,625 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (135,619) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 857,006 |  |  | $ | 866,623 |  |

[0000889331-23-000157:notes:95]
Revolving Credit Facility and Term Loan

[0000889331-23-000157:notes:96]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000157:notes:97]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to

[0000889331-23-000157:notes:98]
0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000157:notes:99]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 30, 2023, the Company made payments of $1.9 million and $5.6 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $290.6 million, respectively, as of September 30, 2023.

[0000889331-23-000157:notes:100]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-23-000157:notes:101]
As of September 30, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.67%.

[0000889331-23-000157:notes:102]
As of September 30, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of September 30, 2023, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-23-000157:notes:103]
Senior Notes

[0000889331-23-000157:notes:104]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-23-000157:notes:105]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-23-000157:notes:106]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000157:notes:107]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000157:notes:108]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-23-000157:notes:109]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-23-000157:notes:110]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 30, 2023, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-23-000157:notes:111]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-23-000157:notes:112]
Interest paid on all Company debt was $11.9 million and $8.5 million for the three months ended September 30, 2023 and October 1, 2022, respectively, and $33.2 million and $16.9 million for the nine months ended September 30, 2023 and October 1, 2022, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-23-000157:notes:113]
[same as prior period, unchanged from 0000889331-23-000131:notes:110]

[0000889331-23-000157:notes:114]
[same as prior period, unchanged from 0000889331-23-000131:notes:111]

[0000889331-23-000157:notes:115]
[same as prior period, unchanged from 0000889331-23-000131:notes:112]

[0000889331-23-000157:notes:116]
[same as prior period, unchanged from 0000889331-23-000131:notes:113]

[0000889331-23-000157:notes:117]
[same as prior period, unchanged from 0000889331-23-000131:notes:114]

[0000889331-23-000157:notes:118]
[same as prior period, unchanged from 0000889331-23-000131:notes:115]

[0000889331-23-000157:notes:119]
[same as prior period, unchanged from 0000889331-23-000131:notes:116]

[0000889331-23-000157:notes:120]
[same as prior period, unchanged from 0000889331-23-000131:notes:117]

[0000889331-23-000157:notes:121]
[same as prior period, unchanged from 0000889331-23-000131:notes:118]

[0000889331-23-000157:notes:122]
Cash equivalents primarily consist of money market funds, certificates of deposit, and short-term time deposits, which are held with institutions with sound credit ratings and are highly liquid. The Company classified cash equivalents as Level 1 and are valued at cost which approximates fair value.

[0000889331-23-000157:notes:123]
[same as prior period, unchanged from 0000889331-23-000131:notes:120]

[0000889331-23-000157:notes:124]
[same as prior period, unchanged from 0000889331-23-000131:notes:121]

[0000889331-23-000157:notes:125]
[same as prior period, unchanged from 0000889331-23-000131:notes:122]

[0000889331-23-000157:notes:126]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in

[0000889331-23-000157:notes:127]
earnings. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by market observable data.

[0000889331-23-000157:notes:128]
[same as prior period, unchanged from 0000889331-23-000131:notes:124]

[0000889331-23-000157:notes:129]
[same as prior period, unchanged from 0000889331-23-000131:notes:125]

[0000889331-23-000157:notes:130]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at July 14, 2022 was €117.0 million and expires on December 7, 2023. The foreign currency contract was not designated as a hedge instrument and is marked to market on a monthly basis. As a result, changes in fair value are reported in Foreign exchange loss in the Condensed Consolidated Statements of Operations. The fair value of the foreign currency forward contract was valued using market exchange rates by a third party and classified as a Level 2 input under the fair value hierarchy.

[0000889331-23-000157:notes:131]
As of September 30, 2023 and December 31, 2022, the fair values of our derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-23-000157:notes:132]
| (in thousands) | Consolidated Balance Sheet Classification |  | September 30, 2023 |  | December 31, 2022 |  |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 4,963 |  |  | $ | 3,939 |  |  |  |
|  | Other long-term assets |  | $ | 6,533 |  |  | $ | 4,740 |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |
| Foreign exchange forward contract | Prepaid expenses and other current assets |  | $ | 2,862 |  |  | $ | 6,186 |  |  |  |

[0000889331-23-000157:notes:133]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2023 and October 1, 2022 were as follows:

[0000889331-23-000157:notes:134]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | Classification of (Gain) Loss Recognized in theCondensed Consolidated Statements of Operations |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense, net |  | $ | (1,252) |  |  | $ | 314 |  |  | $ | (3,246) |  |  | $ | 335 |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  | Foreign exchange loss |  | $ | 4,310 |  |  | $ | 3,209 |  |  | $ | 3,226 |  |  | $ | 3,209 |  |

[0000889331-23-000157:notes:135]
The pre-tax gains recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and nine months ended September 30, 2023 and October 1, 2022 was as follows:

[0000889331-23-000157:notes:136]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | (2,034) |  |  | $ | (10,012) |  |  | $ | (2,817) |  |  | $ | (9,300) |  |

[0000889331-23-000157:notes:137]
The pre-tax gain of $5.0 million from accumulated other comprehensive loss to earnings is expected to be recognized during the next twelve months.

[0000889331-23-000157:notes:138]
[same as prior period, unchanged from 0000889331-23-000131:notes:134]

[0000889331-23-000157:notes:139]
[same as prior period, unchanged from 0000889331-23-000131:notes:135]

[0000889331-23-000157:notes:140]
There were no changes during the quarter ended September 30, 2023 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 30, 2023 and December 31, 2022, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-23-000157:notes:141]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 30, 2023:

[0000889331-23-000157:notes:142]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 427,671 |  |  | $ | — |  |  | $ | — |  |  | $ | 427,671 |  |
| Investments in equity securities |  | 9,703 |  |  | — |  |  | — |  |  | 9,703 |  |
| Mutual funds |  | 18,192 |  |  | — |  |  | — |  |  | 18,192 |  |
| Total |  | $ | 455,566 |  |  | $ | — |  |  | $ | — |  |  | $ | 455,566 |  |

[0000889331-23-000157:notes:143]
[same as prior period, unchanged from 0000889331-23-000131:notes:139]

[0000889331-23-000157:notes:144]
[same as prior period, unchanged from 0000889331-23-000131:notes:140]

[0000889331-23-000157:notes:145]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term

[0000889331-23-000157:notes:146]
loan debt facilities' fair values approximate book value at September 30, 2023 and December 31, 2022, as the rates on these borrowings are variable in nature.

[0000889331-23-000157:notes:147]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of September 30, 2023 and December 31, 2022 were as follows:

[0000889331-23-000157:notes:148]
|  |  | September 30, 2023 |  | December 31, 2022 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 123,605 |  |  | $ | 122,830 |  |  | $ | 124,716 |  |  | $ | 122,270 |  |
| Euro Senior Notes, Series B due 2028 |  | 100,363 |  |  | 87,722 |  |  | 101,265 |  |  | 87,119 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 92,866 |  |  | 100,000 |  |  | 93,764 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 48,338 |  |  | 50,000 |  |  | 48,145 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 109,188 |  |  | 125,000 |  |  | 112,028 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 86,977 |  |  | 100,000 |  |  | 90,131 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-23-000157:notes:149]
[same as prior period, unchanged from 0000889331-23-000131:notes:144]

[0000889331-23-000157:notes:150]
[same as prior period, unchanged from 0000889331-23-000131:notes:145]

[0000889331-23-000157:notes:151]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other (income) expense, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended September 30, 2023 and October 1, 2022 were as follows:

[0000889331-23-000157:notes:152]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 700 |  |  | $ | 725 |  |  | $ | 2,087 |  |  | $ | 2,243 |  |
| Interest cost |  | 961 |  |  | 607 |  |  | 2,850 |  |  | 1,879 |  |
| Expected return on plan assets |  | (470) |  |  | (361) |  |  | (1,409) |  |  | (1,144) |  |
| Amortization of prior service and net actuarial loss |  | 12 |  |  | 92 |  |  | 34 |  |  | 289 |  |
| Net periodic benefit cost |  | $ | 1,203 |  |  | $ | 1,063 |  |  | $ | 3,562 |  |  | $ | 3,267 |  |

[0000889331-23-000157:notes:153]
[same as prior period, unchanged from 0000889331-23-000131:notes:148]

[0000889331-23-000157:notes:154]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.4 million and $0.5 million for the three months ended September 30, 2023 and October 1, 2022, respectively, and $1.1 million and $1.5 million for the nine months ended September 30, 2023 and October 1, 2022, respectively, in Cost of Sales and Other (income) expense, net within the Condensed Consolidated Statements of Net Income. The pre-tax (gains) losses amount recognized in other comprehensive (loss) income as components of net periodic benefit costs for these plans were nominal and $0.1 million for the three months ended September 30, 2023 and October 1, 2022, respectively, and $(0.1) million and $0.3 million for the nine months ended September 30, 2023 and October 1, 2022, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-23-000157:notes:155]
[same as prior period, unchanged from 0000889331-23-000131:notes:150]

[0000889331-23-000157:notes:156]
| (in thousands) |  | Three Months EndedSeptember 30, 2023 |  | Three Months EndedOctober 1, 2022 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | (3) |  |  | $ | — |  |  | $ | (3) |  |  | $ | 673 |  |  | $ | (74) |  |  | $ | 599 |  |
| Cash flow hedge |  | 2,034 |  |  | (488) |  |  | 1,546 |  |  | 10,012 |  |  | (2,403) |  |  | 7,609 |  |
| Foreign currency translation adjustments (a) |  | (4,301) |  |  | 624 |  |  | (3,677) |  |  | (37,289) |  |  | 893 |  |  | (36,396) |  |
| Total change in other comprehensive (loss) income |  | $ | (2,270) |  |  | $ | 136 |  |  | $ | (2,134) |  |  | $ | (26,604) |  |  | $ | (1,584) |  |  | $ | (28,188) |  |
| (in thousands) |  | Nine Months EndedSeptember 30, 2023 |  | Nine Months EndedOctober 1, 2022 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | (125) |  |  | $ | (31) |  |  | $ | (156) |  |  | $ | 1,718 |  |  | $ | (170) |  |  | $ | 1,548 |  |
| Cash flow hedge |  | 2,817 |  |  | (676) |  |  | 2,141 |  |  | 9,300 |  |  | (2,232) |  |  | 7,068 |  |
| Foreign currency translation adjustments (a) |  | (6,098) |  |  | 351 |  |  | (5,747) |  |  | (72,671) |  |  | 2,315 |  |  | (70,356) |  |
| Total change in other comprehensive loss |  | $ | (3,406) |  |  | $ | (356) |  |  | $ | (3,762) |  |  | $ | (61,653) |  |  | $ | (87) |  |  | $ | (61,740) |  |

[0000889331-23-000157:notes:157]
[same as prior period, unchanged from 0000889331-23-000131:notes:152]

[0000889331-23-000157:notes:158]
The following tables set forth the changes in accumulated other comprehensive loss by component for the nine months ended September 30, 2023 and October 1, 2022:

[0000889331-23-000157:notes:159]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at December 31, 2022 |  | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| Activity in the period |  | (156) |  |  | 2,141 |  |  | (5,747) |  |  | (3,762) |  |
| Balance at September 30, 2023 |  | $ | (2,349) |  |  | $ | 8,737 |  |  | $ | (105,914) |  |  | $ | (99,526) |  |

[0000889331-23-000157:notes:160]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at January 1, 2022 |  | $ | (11,928) |  |  | $ | — |  |  | $ | (61,535) |  |  | $ | (73,463) |  |
| Activity in the period |  | 1,548 |  |  | 7,068 |  |  | (70,356) |  |  | (61,740) |  |
| Balance at October 1, 2022 |  | $ | (10,380) |  |  | $ | 7,068 |  |  | $ | (131,891) |  |  | $ | (135,203) |  |

[0000889331-23-000157:notes:161]
Amounts reclassified from accumulated other comprehensive loss to earnings for the three and nine months ended September 30, 2023 and October 1, 2022 were as follows:

[0000889331-23-000157:notes:162]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial (gain) loss |  | $ | (11) |  |  | $ | 193 |  |  | $ | (33) |  |  | $ | 588 |  |

[0000889331-23-000157:notes:163]
[same as prior period, unchanged from 0000889331-23-000131:notes:158]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-23-000157:notes:164]
Income Taxes
The effective tax rate for the three and nine months ended September 30, 2023 was 23.3% and 19.7%, respectively, compared to the effective tax rate for the three and nine months ended October 1, 2022 of 21.4% and 17.6%, respectively. The effective tax rate for the third quarter of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to less income earned in lower tax jurisdictions in the 2023 period, as compared to the 2022 period. The effective tax rates for both periods are higher than the statutory tax rate due to the impact of foreign exchange losses with no related tax benefit.

[0000889331-23-000157:notes:165]
The effective tax rate for the first nine months of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to the impact of a one-time deduction in the first quarter of 2022 that resulted in a net benefit of $7.2 million from the dissolution of one of the Company’s affiliates. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, while for the 2022 period, the effective tax rate was also lower due to the impact of the one-time deduction previously noted.


## us-gaap:EarningsPerShareTextBlock

[0000889331-23-000157:notes:166]
[same as prior period, unchanged from 0000889331-23-000131:notes:161]

[0000889331-23-000157:notes:167]
[same as prior period, unchanged from 0000889331-23-000131:notes:162]

[0000889331-23-000157:notes:168]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 57,788 |  |  | $ | 75,468 |  |  | $ | 216,604 |  |  | $ | 280,002 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,893 |  |  | 24,755 |  |  | 24,838 |  |  | 24,726 |  |
| Effect of dilutive securities |  | 250 |  |  | 233 |  |  | 262 |  |  | 260 |  |
| Diluted |  | 25,143 |  |  | 24,988 |  |  | 25,100 |  |  | 24,986 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.32 |  |  | $ | 3.05 |  |  | $ | 8.72 |  |  | $ | 11.32 |  |
| Diluted earnings per share |  | $ | 2.30 |  |  | $ | 3.02 |  |  | $ | 8.63 |  |  | $ | 11.21 |  |

[0000889331-23-000157:notes:169]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 80,828 and 92,052 for the three months ended September 30, 2023 and October 1, 2022, respectively, and 106,156 and 84,027 for the nine months ended September 30, 2023 and October 1, 2022, respectively.

[0000889331-23-000157:notes:170]
[same as prior period, unchanged from 0000889331-23-000131:notes:165]

[0000889331-23-000157:notes:171]
[same as prior period, unchanged from 0000889331-23-000131:notes:166]

[0000889331-23-000157:notes:172]
The Company did not repurchase shares of its common stock for the three and nine months ended September 30, 2023, and October 1, 2022.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-23-000157:notes:173]
Related Party Transactions

[0000889331-23-000157:notes:174]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-23-000157:notes:175]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-23-000157:notes:176]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-23-000157:notes:177]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-23-000157:notes:178]
|  |  | Three Months Ended September 30, 2023 |  | Three Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.1 |  | 2.0 |  |  | — |  | 0.1 |  | 2.9 |  |
|  |  | Nine Months Ended September 30, 2023 |  | Nine Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.3 |  | 0.3 |  | 7.6 |  |  | 0.3 |  | 0.3 |  | 8.8 |  |
|  |  | September 30, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.8 |  | $ | — |  | $ | 1.6 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-23-000157:notes:179]
[same as prior period, unchanged from 0000889331-23-000131:notes:174]

[0000889331-23-000157:notes:180]
[same as prior period, unchanged from 0000889331-23-000131:notes:175]

[0000889331-23-000157:notes:181]
[same as prior period, unchanged from 0000889331-23-000131:notes:176]

[0000889331-23-000157:notes:182]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related charging infrastructure, aerospace, power supplies, data centers and telecommunications,

[0000889331-23-000157:notes:183]
medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-23-000157:notes:184]
[same as prior period, unchanged from 0000889331-23-000131:notes:178]

[0000889331-23-000157:notes:185]
[same as prior period, unchanged from 0000889331-23-000131:notes:179]

[0000889331-23-000157:notes:186]
[same as prior period, unchanged from 0000889331-23-000131:notes:180]

[0000889331-23-000157:notes:187]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 343,933 |  |  | $ | 397,629 |  |  | $ | 1,052,673 |  |  | $ | 1,121,626 |  |
| Transportation |  | 177,019 |  |  | 181,735 |  |  | 515,708 |  |  | 548,266 |  |
| Industrial |  | 86,119 |  |  | 79,516 |  |  | 260,469 |  |  | 230,754 |  |
| Total net sales |  | $ | 607,071 |  |  | $ | 658,880 |  |  | $ | 1,828,850 |  |  | $ | 1,900,646 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 19,623 |  |  | $ | 19,080 |  |  | $ | 59,219 |  |  | 48,984 |  |
| Transportation |  | 10,193 |  |  | 11,331 |  |  | 32,547 |  |  | 32,703 |  |
| Industrial |  | 4,093 |  |  | 2,180 |  |  | 11,517 |  |  | 6,522 |  |
| Total depreciation and amortization |  | $ | 33,909 |  |  | $ | 32,591 |  |  | $ | 103,283 |  |  | $ | 88,209 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 77,022 |  |  | $ | 113,140 |  |  | $ | 247,028 |  |  | $ | 339,675 |  |
| Transportation |  | 9,694 |  |  | 12,987 |  |  | 26,015 |  |  | 57,604 |  |
| Industrial |  | 13,201 |  |  | 12,178 |  |  | 45,450 |  |  | 39,968 |  |
| Other (a) |  | (6,272) |  |  | (16,435) |  |  | (22,154) |  |  | (30,623) |  |
| Total operating income |  | 93,645 |  |  | 121,870 |  |  | 296,339 |  |  | 406,624 |  |
| Interest expense |  | 10,101 |  |  | 8,399 |  |  | 29,803 |  |  | 17,069 |  |
| Foreign exchange loss |  | 11,776 |  |  | 18,191 |  |  | 8,697 |  |  | 40,051 |  |
| Other (income) expense, net |  | (3,527) |  |  | (698) |  |  | (11,810) |  |  | 9,789 |  |
| Income before income taxes |  | $ | 75,295 |  |  | $ | 95,978 |  |  | $ | 269,649 |  |  | $ | 339,715 |  |

[0000889331-23-000157:notes:188]
(a) Included in “Other” Operating income for the third quarter of 2023 was $3.7 million ($8.5 million year-to-date) of restructuring charges, primarily related to employee termination costs, and $1.8 million ($9.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000157:notes:189]
Included in “Other” Operating income for the third quarter of 2022 was $6.8 million ($11.6 million year-to-date) of purchase accounting inventory step-up charges, $6.2 million ($14.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $3.4 million ($4.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000157:notes:190]
[same as prior period, unchanged from 0000889331-23-000131:notes:184]

[0000889331-23-000157:notes:191]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |  | September 30, 2023 |  | October 1, 2022 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 217,904 |  |  | $ | 244,907 |  |  | $ | 635,892 |  |  | $ | 689,888 |  |
| China |  | 138,393 |  |  | 165,091 |  |  | 415,430 |  |  | 492,195 |  |
| Other countries (a) |  | 250,774 |  |  | 248,882 |  |  | 777,528 |  |  | 718,563 |  |
| Total net sales |  | $ | 607,071 |  |  | $ | 658,880 |  |  | $ | 1,828,850 |  |  | $ | 1,900,646 |  |

[0000889331-23-000157:notes:192]
[same as prior period, unchanged from 0000889331-23-000131:notes:186]

[0000889331-23-000157:notes:193]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 73,902 |  |  | $ | 76,325 |  |
| China |  | 131,438 |  |  | 129,094 |  |
| Mexico |  | 102,896 |  |  | 107,119 |  |
| Germany |  | 42,712 |  |  | 39,635 |  |
| Philippines |  | 74,004 |  |  | 77,240 |  |
| Other countries |  | 53,954 |  |  | 51,697 |  |
| Total long-lived assets |  | $ | 478,906 |  |  | $ | 481,110 |  |

[0000889331-23-000157:notes:194]
[same as prior period, unchanged from 0000889331-23-000131:notes:188]

[0000889331-23-000157:notes:195]
|  |  | Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 7,407 |  |  | $ | 9,761 |  |
| China |  | 22,558 |  |  | 23,449 |  |
| Mexico |  | 11,339 |  |  | 21,169 |  |
| Germany |  | 6,534 |  |  | 3,246 |  |
| Philippines |  | 5,245 |  |  | 13,118 |  |
| Other countries |  | 8,138 |  |  | 4,269 |  |
| Total additions to long-lived assets |  | $ | 61,221 |  |  | $ | 75,012 |  |

[0000889331-23-000157:notes:196]
[same as prior period, unchanged from 0000889331-23-000131:notes:190]
