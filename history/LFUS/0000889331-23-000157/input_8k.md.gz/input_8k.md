# LFUS 8-K — 0000889331-23-000154 filed 2023-10-31

## item codes, every 8-K on or before 2023-11-01

- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2023-11-01

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-23-000154:8k_2_02:1]
EX-99.1
2
q32023earningsreleaseex991.htm
EX-99.1

[0000889331-23-000154:8k_2_02:2]
Document

[0000889331-23-000154:8k_2_02:3]
Exhibit 99.1

[0000889331-23-000154:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0000889331-23-000154:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS FOR 2023

[0000889331-23-000154:8k_2_02:6]
Strong Execution Drives Performance Above Guidance

[0000889331-23-000154:8k_2_02:7]
CHICAGO, October 31, 2023  - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the third quarter ended September 30, 2023:

[0000889331-23-000154:8k_2_02:8]
•Net sales of $607.1 million were down 8% versus the prior year period, and down 11% organically

[0000889331-23-000154:8k_2_02:9]
•GAAP diluted EPS was $2.30; adjusted diluted EPS was $2.97

[0000889331-23-000154:8k_2_02:10]
•Cash flow from operations was $161.5 million and free cash flow was $139.8 million

[0000889331-23-000154:8k_2_02:11]
“In the third quarter, sales and earnings exceeded our expectations, despite pockets of end market softness and ongoing inventory destocking” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Our year-to-date performance underscores the resilience of our business model, strong cash generation, and consistent execution. Looking ahead, while dynamic macro conditions likely persist, our improved cost structure, healthy balance sheet, and ability to optimize cash flow should position us well into 2024. Our experienced team will continue to leverage our competitive advantages across our evolving and diversified end markets.”

[0000889331-23-000154:8k_2_02:12]
Fourth Quarter of 2023*

[0000889331-23-000154:8k_2_02:13]
Based on current market conditions, for the fourth quarter the company expects,

[0000889331-23-000154:8k_2_02:14]
•Net sales in the range of $520 to $550 million, adjusted diluted EPS in the range of $1.90 to $2.10 and an adjusted effective tax rate of approximately 18%

[0000889331-23-000154:8k_2_02:15]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-23-000154:8k_2_02:16]
-more-

[0000889331-23-000154:8k_2_02:17]
Dividend

[0000889331-23-000154:8k_2_02:18]
•The company will pay a cash dividend on its common stock of $0.65 per share on December 7, 2023, to shareholders of record as of November 23, 2023.

[0000889331-23-000154:8k_2_02:19]
Conference Call and Webcast Information

[0000889331-23-000154:8k_2_02:20]
Littelfuse will host a conference call on Wednesday, November 1, 2023, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-23-000154:8k_2_02:21]
About Littelfuse

[0000889331-23-000154:8k_2_02:22]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-23-000154:8k_2_02:23]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 31, 2022. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 31, 2022, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-23-000154:8k_2_02:24]
-more

[0000889331-23-000154:8k_2_02:25]
Non-GAAP Financial Measures

[0000889331-23-000154:8k_2_02:26]
The information included in this press release includes the non-GAAP financial measures of organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-23-000154:8k_2_02:27]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-23-000154:8k_2_02:28]
The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-23-000154:8k_2_02:29]
LFUS-F

[0000889331-23-000154:8k_2_02:30]
###

[0000889331-23-000154:8k_2_02:31]
|  | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000www.littelfuse.com |

[0000889331-23-000154:8k_2_02:32]
LITTELFUSE, INC.

[0000889331-23-000154:8k_2_02:33]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-23-000154:8k_2_02:34]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | September 30,2023 |  | December 31,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 560,056 |  |  | $ | 562,588 |  |
| Short-term investments |  | 229 |  |  | 84 |  |
| Trade receivables, less allowances of $88,440 and $83,562 at September 30, 2023 and December 31, 2022, respectively |  | 327,500 |  |  | 306,578 |  |
| Inventories |  | 483,075 |  |  | 547,690 |  |
| Prepaid income taxes and income taxes receivable |  | 3,776 |  |  | 7,215 |  |
| Prepaid expenses and other current assets |  | 83,684 |  |  | 87,641 |  |
| Total current assets |  | 1,458,320 |  |  | 1,511,796 |  |
| Net property, plant, and equipment |  | 478,906 |  |  | 481,110 |  |
| Intangible assets, net of amortization |  | 612,366 |  |  | 593,970 |  |
| Goodwill |  | 1,284,343 |  |  | 1,186,922 |  |
| Investments |  | 23,371 |  |  | 24,121 |  |
| Deferred income taxes |  | 13,598 |  |  | 14,367 |  |
| Right of use lease assets, net |  | 51,755 |  |  | 57,382 |  |
| Other long-term assets |  | 80,267 |  |  | 34,066 |  |
| Total assets |  | $ | 4,002,926 |  |  | $ | 3,903,734 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 166,725 |  |  | $ | 208,571 |  |
| Accrued liabilities |  | 143,540 |  |  | 187,057 |  |
| Accrued income taxes |  | 35,762 |  |  | 41,793 |  |
| Current portion of long-term debt |  | 135,619 |  |  | 134,874 |  |
| Total current liabilities |  | 481,646 |  |  | 572,295 |  |
| Long-term debt, less current portion |  | 857,006 |  |  | 866,623 |  |
| Deferred income taxes |  | 106,656 |  |  | 100,230 |  |
| Accrued post-retirement benefits |  | 29,445 |  |  | 28,037 |  |
| Non-current operating lease liabilities |  | 39,818 |  |  | 45,661 |  |
| Other long-term liabilities |  | 83,496 |  |  | 79,510 |  |
| Total equity |  | 2,404,859 |  |  | 2,211,378 |  |
| Total liabilities and equity |  | $ | 4,002,926 |  |  | $ | 3,903,734 |  |

[0000889331-23-000154:8k_2_02:35]
LITTELFUSE, INC.

[0000889331-23-000154:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-23-000154:8k_2_02:37]
(Unaudited)

[0000889331-23-000154:8k_2_02:38]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) |  | September 30,2023 |  | October 1,2022 |  | September 30,2023 |  | October 1,2022 |
| Net sales |  | $ | 607,071 |  |  | $ | 658,880 |  |  | $ | 1,828,850 |  |  | $ | 1,900,646 |  |
| Cost of sales |  | 380,200 |  |  | 402,059 |  |  | 1,122,190 |  |  | 1,122,258 |  |
| Gross profit |  | 226,871 |  |  | 256,821 |  |  | 706,660 |  |  | 778,388 |  |
| Selling, general, and administrative expenses |  | 87,204 |  |  | 90,219 |  |  | 270,057 |  |  | 258,820 |  |
| Research and development expenses |  | 25,484 |  |  | 25,752 |  |  | 77,270 |  |  | 68,796 |  |
| Amortization of intangibles |  | 16,022 |  |  | 15,567 |  |  | 49,773 |  |  | 39,883 |  |
| Restructuring, impairment, and other charges |  | 4,516 |  |  | 3,413 |  |  | 13,221 |  |  | 4,265 |  |
| Total operating expenses |  | 133,226 |  |  | 134,951 |  |  | 410,321 |  |  | 371,764 |  |
| Operating income |  | 93,645 |  |  | 121,870 |  |  | 296,339 |  |  | 406,624 |  |
| Interest expense |  | 10,101 |  |  | 8,399 |  |  | 29,803 |  |  | 17,069 |  |
| Foreign exchange loss |  | 11,776 |  |  | 18,191 |  |  | 8,697 |  |  | 40,051 |  |
| Other (income) expense, net |  | (3,527) |  |  | (698) |  |  | (11,810) |  |  | 9,789 |  |
| Income before income taxes |  | 75,295 |  |  | 95,978 |  |  | 269,649 |  |  | 339,715 |  |
| Income taxes |  | 17,507 |  |  | 20,510 |  |  | 53,045 |  |  | 59,713 |  |
| Net income |  | $ | 57,788 |  |  | $ | 75,468 |  |  | $ | 216,604 |  |  | $ | 280,002 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.32 |  |  | $ | 3.05 |  |  | $ | 8.72 |  |  | $ | 11.32 |  |
| Diluted |  | $ | 2.30 |  |  | $ | 3.02 |  |  | $ | 8.63 |  |  | $ | 11.21 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,893 |  |  | 24,755 |  |  | 24,838 |  |  | 24,726 |  |
| Diluted |  | 25,143 |  |  | 24,988 |  |  | 25,100 |  |  | 24,986 |  |
| Comprehensive income |  | $ | 55,654 |  |  | $ | 47,280 |  |  | $ | 212,842 |  |  | $ | 218,262 |  |

[0000889331-23-000154:8k_2_02:39]
LITTELFUSE, INC.

[0000889331-23-000154:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-23-000154:8k_2_02:41]
(Unaudited)

[0000889331-23-000154:8k_2_02:42]
|  |  | Nine Months Ended |
| (in thousands) |  | September 30, 2023 |  | October 1, 2022 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 216,604 |  |  | $ | 280,002 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 137,988 |  |  | 183,942 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (21,752) |  |  | (56,431) |  |
| Inventories |  | 66,456 |  |  | (83,803) |  |
| Accounts payable |  | (38,475) |  |  | (3,838) |  |
| Accrued liabilities and income taxes |  | (61,359) |  |  | (4,399) |  |
| Prepaid expenses and other assets |  | 13,678 |  |  | (2,034) |  |
| Net cash provided by operating activities |  | 313,140 |  |  | 313,439 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (198,810) |  |  | (532,772) |  |
| Purchases of property, plant, and equipment |  | (63,166) |  |  | (77,773) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 597 |  |  | 565 |  |
| Net cash used in investing activities |  | (261,379) |  |  | (609,980) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (5,625) |  |  | 373,125 |  |
| Cash dividends paid |  | (45,973) |  |  | (41,055) |  |
| All other cash provided by (used in) financing activities |  | 4,454 |  |  | (10,147) |  |
| Net cash (used in) provided by financing activities |  | (47,144) |  |  | 321,923 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (7,965) |  |  | (31,963) |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (3,348) |  |  | (6,581) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 564,939 |  |  | 482,836 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 561,591 |  |  | $ | 476,255 |  |

[0000889331-23-000154:8k_2_02:43]
LITTELFUSE, INC.

[0000889331-23-000154:8k_2_02:44]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-23-000154:8k_2_02:45]
(Unaudited)

[0000889331-23-000154:8k_2_02:46]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2023 |  | 2022 |  |  |  | %Growth / (Decline) |  | 2023 |  | 2022 |  |  |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 343,933 |  |  | $ | 397,629 |  |  |  |  | (13.5) | % |  | $ | 1,052,673 |  |  | $ | 1,121,626 |  |  |  |  | (6.1) | % |
| Transportation |  | 177,019 |  |  | 181,735 |  |  |  |  | (2.6) | % |  | 515,708 |  |  | 548,266 |  |  |  |  | (5.9) | % |
| Industrial |  | 86,119 |  |  | 79,516 |  |  |  |  | 8.3 | % |  | 260,469 |  |  | 230,754 |  |  |  |  | 12.9 | % |
| Total net sales |  | $ | 607,071 |  |  | $ | 658,880 |  |  |  |  | (7.9) | % |  | $ | 1,828,850 |  |  | $ | 1,900,646 |  |  |  |  | (3.8) | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 77,022 |  |  | $ | 113,140 |  |  |  |  | (31.9) | % |  | $ | 247,028 |  |  | $ | 339,675 |  |  |  |  | (27.3) | % |
| Transportation |  | 9,694 |  |  | 12,987 |  |  |  |  | (25.4) | % |  | 26,015 |  |  | 57,604 |  |  |  |  | (54.8) | % |
| Industrial |  | 13,201 |  |  | 12,178 |  |  |  |  | 8.4 | % |  | 45,450 |  |  | 39,968 |  |  |  |  | 13.7 | % |
| Other(a) |  | (6,272) |  |  | (16,435) |  |  |  |  | N.M. |  | (22,154) |  |  | (30,623) |  |  |  |  | N.M. |
| Total operating income |  | $ | 93,645 |  |  | $ | 121,870 |  |  |  |  | (23.2) | % |  | $ | 296,339 |  |  | $ | 406,624 |  |  |  |  | (27.1) | % |
| Operating Margin |  | 15.4 | % |  | 18.5 | % |  |  |  |  |  | 16.2 | % |  | 21.4 | % |  |  |  |  |
| Interest expense |  | 10,101 |  |  | 8,399 |  |  |  |  |  |  | 29,803 |  |  | 17,069 |  |  |  |  |  |
| Foreign exchange loss |  | 11,776 |  |  | 18,191 |  |  |  |  |  |  | 8,697 |  |  | 40,051 |  |  |  |  |  |
| Other (income) expense, net |  | (3,527) |  |  | (698) |  |  |  |  |  |  | (11,810) |  |  | 9,789 |  |  |  |  |  |
| Income before income taxes |  | $ | 75,295 |  |  | $ | 95,978 |  |  |  |  | (21.5) | % |  | $ | 269,649 |  |  | $ | 339,715 |  |  |  |  | (20.6) | % |

[0000889331-23-000154:8k_2_02:47]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-23-000154:8k_2_02:48]
N.M. - Not meaningful

[0000889331-23-000154:8k_2_02:49]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2023 |  | 2022 |  | %(Decline) |  | 2023 |  | 2022 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 22.4 | % |  | 28.5 | % |  | (6.1) | % |  | 23.5 | % |  | 30.3 | % |  | (6.8) | % |
| Transportation |  | 5.5 | % |  | 7.1 | % |  | (1.6) | % |  | 5.0 | % |  | 10.5 | % |  | (5.5) | % |
| Industrial |  | 15.3 | % |  | 15.3 | % |  | — | % |  | 17.4 | % |  | 17.3 | % |  | 0.1 | % |

[0000889331-23-000154:8k_2_02:50]
LITTELFUSE, INC.

[0000889331-23-000154:8k_2_02:51]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-23-000154:8k_2_02:52]
(In millions of USD except per share amounts - unaudited)

[0000889331-23-000154:8k_2_02:53]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-23 |  | Q3-22 |  | YTD-23 |  | YTD-22 |
| GAAP diluted EPS |  | $ | 2.30 |  |  | $ | 3.02 |  |  | $ | 8.63 |  |  | $ | 11.21 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.67 |  |  | 1.26 |  |  | 1.09 |  |  | 2.32 |  |
| Adjusted diluted EPS |  | $ | 2.97 |  |  | $ | 4.28 |  |  | $ | 9.72 |  |  | $ | 13.53 |  |

[0000889331-23-000154:8k_2_02:54]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q3-23 |  | Q3-22 |  | YTD-23 |  | YTD-22 |
| Acquisition-related and integration costs (a) |  | $ | 1.8 |  |  | $ | 6.2 |  |  | $ | 9.0 |  |  | $ | 14.8 |  |
| Purchase accounting inventory adjustments (b) |  | — |  |  | 6.8 |  |  | — |  |  | 11.6 |  |
| Restructuring, impairment and other charges (c) |  | 4.5 |  |  | 3.4 |  |  | 13.2 |  |  | 4.3 |  |
| Non-GAAP adjustments to operating income |  | 6.3 |  |  | 16.4 |  |  | 22.2 |  |  | 30.7 |  |
| Other income, net (d) |  | — |  |  | — |  |  | (0.2) |  |  | (0.5) |  |
| Non-operating foreign exchange loss |  | 11.8 |  |  | 18.2 |  |  | 8.7 |  |  | 40.1 |  |
| Non-GAAP adjustments to income before income taxes |  | 18.1 |  |  | 34.6 |  |  | 30.7 |  |  | 70.3 |  |
| Income taxes (e) |  | 1.2 |  |  | 3.0 |  |  | 3.2 |  |  | 12.2 |  |
| Non-GAAP adjustments to net income |  | $ | 16.9 |  |  | $ | 31.6 |  |  | $ | 27.5 |  |  | $ | 58.1 |  |
| Total EPS impact |  | $ | 0.67 |  |  | $ | 1.26 |  |  | $ | 1.09 |  |  | $ | 2.32 |  |

[0000889331-23-000154:8k_2_02:55]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-23 |  | Q3-22 |  | YTD-23 |  | YTD-22 |
| Net income |  | $ | 57.8 |  |  | $ | 75.5 |  |  | $ | 216.6 |  |  | $ | 280.0 |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 17.5 |  |  | 20.5 |  |  | 53.0 |  |  | 59.7 |  |
| Interest expense |  | 10.1 |  |  | 8.4 |  |  | 29.8 |  |  | 17.1 |  |
| Foreign exchange loss |  | 11.8 |  |  | 18.2 |  |  | 8.7 |  |  | 40.1 |  |
| Other (income) expense, net |  | (3.5) |  |  | (0.7) |  |  | (11.8) |  |  | 9.8 |  |
| GAAP operating income |  | $ | 93.6 |  |  | $ | 121.9 |  |  | $ | 296.3 |  |  | $ | 406.6 |  |
| Non-GAAP adjustments to operating income |  | 6.3 |  |  | 16.4 |  |  | 22.2 |  |  | 30.7 |  |
| Adjusted operating income |  | $ | 99.9 |  |  | $ | 138.3 |  |  | $ | 318.5 |  |  | $ | 437.3 |  |
| Amortization of intangibles |  | 16.0 |  |  | 15.6 |  |  | 49.8 |  |  | 39.9 |  |
| Depreciation expenses |  | 17.9 |  |  | 17.0 |  |  | 53.5 |  |  | 48.3 |  |
| Adjusted EBITDA |  | $ | 133.8 |  |  | $ | 170.9 |  |  | $ | 421.8 |  |  | $ | 525.5 |  |
| Net sales |  | $ | 607.1 |  |  | $ | 658.9 |  |  | $ | 1,828.9 |  |  | $ | 1,900.6 |  |
| Net income as a percentage of net sales |  | 9.5 | % |  | 11.5 | % |  | 11.8 | % |  | 14.7 | % |
| Operating margin |  | 15.4 | % |  | 18.5 | % |  | 16.2 | % |  | 21.4 | % |
| Adjusted operating margin |  | 16.5 | % |  | 21.0 | % |  | 17.4 | % |  | 23.0 | % |
| Adjusted EBITDA margin |  | 22.0 | % |  | 25.9 | % |  | 23.1 | % |  | 27.6 | % |

[0000889331-23-000154:8k_2_02:56]
| Adjusted EBITDA by Segment |  | Q3-23 |  | Q3-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 77.0 |  |  | $ | 9.7 |  |  | $ | 13.2 |  |  | $ | 113.1 |  |  | $ | 13.0 |  |  | $ | 12.2 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 9.8 |  |  | 3.6 |  |  | 2.6 |  |  | 9.7 |  |  | 4.7 |  |  | 1.2 |  |
| Add back depreciation |  | 9.8 |  |  | 6.6 |  |  | 1.5 |  |  | 9.4 |  |  | 6.7 |  |  | 1.0 |  |
| Adjusted EBITDA |  | $ | 96.6 |  |  | $ | 19.9 |  |  | $ | 17.3 |  |  | $ | 132.2 |  |  | $ | 24.4 |  |  | $ | 14.4 |  |
| Adjusted EBITDA Margin |  | 28.1 | % |  | 11.2 | % |  | 20.1 | % |  | 33.3 | % |  | 13.4 | % |  | 18.1 | % |

[0000889331-23-000154:8k_2_02:57]
| Adjusted EBITDA by Segment |  | YTD-23 |  | YTD-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 247.0 |  |  | $ | 26.0 |  |  | $ | 45.5 |  |  | $ | 339.7 |  |  | $ | 57.6 |  |  | $ | 40.0 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 30.1 |  |  | 12.2 |  |  | 7.5 |  |  | 22.5 |  |  | 13.7 |  |  | 3.7 |  |
| Add back depreciation |  | 29.1 |  |  | 20.4 |  |  | 4.0 |  |  | 26.5 |  |  | 19.0 |  |  | 2.9 |  |
| Adjusted EBITDA |  | $ | 306.2 |  |  | $ | 58.6 |  |  | $ | 57.0 |  |  | $ | 388.7 |  |  | $ | 90.3 |  |  | $ | 46.5 |  |
| Adjusted EBITDA Margin |  | 29.1 | % |  | 11.4 | % |  | 21.9 | % |  | 34.7 | % |  | 16.5 | % |  | 20.1 | % |

[0000889331-23-000154:8k_2_02:58]
| Net sales reconciliation |  | Q3-23 vs. Q3-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (14) | % |  | (3) | % |  | 8 | % |  | (8) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 2 | % |  | — | % |  | 3 | % |  | 2 | % |
| FX impact |  | 1 | % |  | 1 | % |  | — | % |  | 1 | % |
| Organic net sales (decline) growth |  | (17) | % |  | (4) | % |  | 5 | % |  | (11) | % |

[0000889331-23-000154:8k_2_02:59]
| Net sales reconciliation |  | YTD-23 vs. YTD-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (6) | % |  | (6) | % |  | 13 | % |  | (4) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 8 | % |  | — | % |  | 4 | % |  | 5 | % |
| FX impact |  | — | % |  | — | % |  | — | % |  | — | % |
| Organic net sales (decline) growth |  | (14) | % |  | (6) | % |  | 9 | % |  | (9) | % |

[0000889331-23-000154:8k_2_02:60]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-23 |  | Q3-22 |  | YTD-23 |  | YTD-22 |
| Income taxes |  | $ | 17.5 |  |  | $ | 20.5 |  |  | $ | 53.0 |  |  | $ | 59.7 |  |
| Effective rate |  | 23.3 | % |  | 21.4 | % |  | 19.7 | % |  | 17.6 | % |
| Non-GAAP adjustments - income taxes |  | 1.2 |  |  | 3.0 |  |  | 3.2 |  |  | 12.2 |  |
| Adjusted income taxes |  | $ | 18.7 |  |  | $ | 23.4 |  |  | $ | 56.2 |  |  | $ | 71.9 |  |
| Adjusted effective rate |  | 20.0 | % |  | 18.0 | % |  | 18.7 | % |  | 17.5 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-23 |  | Q3-22 |  | YTD-23 |  | YTD-22 |
| Net cash provided by operating activities |  | $ | 161.5 |  |  | $ | 148.1 |  |  | $ | 313.1 |  |  | $ | 313.4 |  |
| Less: Purchases of property, plant and equipment |  | (21.7) |  |  | (21.7) |  |  | (63.2) |  |  | (77.8) |  |
| Free cash flow |  | $ | 139.8 |  |  | $ | 126.5 |  |  | $ | 250.0 |  |  | $ | 235.7 |  |

[0000889331-23-000154:8k_2_02:61]
| Consolidated Total Debt |  | As of September 30, 2023 |
| Consolidated Total Debt |  | $ | 992.6 |  |
| Unamortized debt issuance costs |  | 4.0 |  |
| Consolidated funded indebtedness |  | 996.6 |  |
| Cash held in U.S. (up to $400 million) |  | 155.6 |
| Net debt |  | $ | 841.0 |  |
| Consolidated EBITDA |  | Twelve Months Ended September 30, 2023 |
| Net Income |  | $ | 309.7 |  |
| Interest expense |  | 38.9 |  |
| Income taxes |  | 63.1 |  |
| Depreciation |  | 70.2 |  |
| Amortization |  | 65.6 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 24.0 |  |
| Purchase accounting inventory step-up charge |  | 4.1 |  |
| Unrealized loss on investments |  | 1.2 |  |
| Impairment charges |  | 9.2 |  |
| Other |  | (3.7) |  |
| Consolidated EBITDA (1) |  | $ | 582.3 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.4x |

[0000889331-23-000154:8k_2_02:62]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2023 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-23-000154:8k_2_02:63]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-23-000154:8k_2_02:64]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-23-000154:8k_2_02:65]
Note: Total will not always foot due to rounding.

[0000889331-23-000154:8k_2_02:66]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-23-000154:8k_2_02:67]
(b) reflected in cost of sales.

[0000889331-23-000154:8k_2_02:68]
(c) reflected in restructuring, impairment and other charges.

[0000889331-23-000154:8k_2_02:69]
(d) reflected YTD gain of $0.2 million from the sale of a building within the Electronics segment in the first quarter of 2023. 2022 amount included $0.5 million gain from the sale of a building within Transportation segment.

[0000889331-23-000154:8k_2_02:70]
(e) reflected the tax impact associated with the non-GAAP adjustments, and 2022 year-to-date amount includes the one-time net benefit of $7.2 million that resulted from the dissolution of one of the Company’s affiliates.

[0000889331-23-000154:8k_2_02:71]
###
