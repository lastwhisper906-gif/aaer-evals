# LFUS MD&A — 0000889331-23-000157


## mdna

[0000889331-23-000157:mdna:1]
[same as prior period, unchanged from 0000889331-23-000131:mdna:1]

[0000889331-23-000157:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-23-000157:mdna:3]
[same as prior period, unchanged from 0000889331-23-000131:mdna:3]

[0000889331-23-000157:mdna:4]
[same as prior period, unchanged from 0000889331-23-000131:mdna:4]

[0000889331-23-000157:mdna:5]
[same as prior period, unchanged from 0000889331-23-000131:mdna:5]

[0000889331-23-000157:mdna:6]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-23-000157:mdna:7]
[same as prior period, unchanged from 0000889331-23-000131:mdna:7]

[0000889331-23-000157:mdna:8]
[same as prior period, unchanged from 0000889331-23-000131:mdna:8]

[0000889331-23-000157:mdna:9]
For the third quarter of 2023, the Company recognized net sales of $607.1 million, a decrease of $51.8 million, or 7.9% as compared to $658.9 million in the third quarter of 2022 including $7.3 million or 1.1% of favorable changes in foreign exchange rates. The decrease in net sales was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment that more than offset higher volume in the passenger car products business within the Transportation segment, and higher volume in the Industrial segment. The Company recognized net income of $57.8 million, or $2.30 per diluted share, in the third quarter of 2023 compared to $75.5 million, or $3.02 per diluted share in the third quarter of 2022. The decrease in net income was primarily due to lower operating income of $36.1 million in the Electronics segment driven by a reduction in volume.

[0000889331-23-000157:mdna:10]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the fab is approximately 93 million Euro, of which 37.2 million Euro down payment (approximately $40.5 million) recorded in Other long-term assets in the Condensed Consolidated Balance Sheets was paid in the third quarter after regulatory approvals and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2023 or 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-23-000157:mdna:11]
On February 3, 2023, the Company acquired Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million and will be reported within the company’s Industrial segment. The Company financed the transaction with cash on hand.

[0000889331-23-000157:mdna:12]
Net cash provided by operating activities was $313.1 million for the nine months ended September 30, 2023 compared to $313.4 million for the nine months ended October 1, 2022 as lower cash earnings were offset by reductions in working capital.

[0000889331-23-000157:mdna:13]
[same as prior period, unchanged from 0000889331-23-000131:mdna:13]

[0000889331-23-000157:mdna:14]
[same as prior period, unchanged from 0000889331-23-000131:mdna:14]

[0000889331-23-000157:mdna:15]
[same as prior period, unchanged from 0000889331-23-000131:mdna:15]

[0000889331-23-000157:mdna:16]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The third quarter of 2023 includes $3.7 million ($8.5 million year-to-date) of restructuring charges, primarily related to employee termination costs, and $1.8 million ($9.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000157:mdna:17]
The third quarter of 2022 includes $6.8 million ($11.6 million year-to-date) of purchase accounting inventory step-up charges, $6.2 million ($14.8 million year-to-date) of legal and professional fees primarily related to completed and contemplated acquisitions, and $3.4 million ($4.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000157:mdna:18]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  | 2023 |  | 2022 |  | Change |  | %Change |
| Net sales |  | $ | 607,071 |  |  | $ | 658,880 |  |  | $ | (51,809) |  |  | (7.9) | % |  | $ | 1,828,850 |  |  | $ | 1,900,646 |  |  | $ | (71,796) |  |  | (3.8) | % |
| Cost of sales |  | 380,200 |  |  | 402,059 |  |  | (21,859) |  |  | (5.4) | % |  | 1,122,190 |  |  | 1,122,258 |  |  | (68) |  |  | — | % |
| Gross profit |  | 226,871 |  |  | 256,821 |  |  | (29,950) |  |  | (11.7) | % |  | 706,660 |  |  | 778,388 |  |  | (71,728) |  |  | (9.2) | % |
| Operating expenses |  | 133,226 |  |  | 134,951 |  |  | (1,725) |  |  | (1.3) | % |  | 410,321 |  |  | 371,764 |  |  | 38,557 |  |  | 10.4 | % |
| Operating income |  | 93,645 |  |  | 121,870 |  |  | (28,225) |  |  | (23.2) | % |  | 296,339 |  |  | 406,624 |  |  | (110,285) |  |  | (27.1) | % |
| Income before income taxes |  | 75,295 |  |  | 95,978 |  |  | (20,683) |  |  | (21.5) | % |  | 269,649 |  |  | 339,715 |  |  | (70,066) |  |  | (20.6) | % |
| Income taxes |  | 17,507 |  |  | 20,510 |  |  | (3,003) |  |  | (14.6) | % |  | 53,045 |  |  | 59,713 |  |  | (6,668) |  |  | (11.2) | % |
| Net income |  | $ | 57,788 |  |  | $ | 75,468 |  |  | $ | (17,680) |  |  | (23.4) | % |  | $ | 216,604 |  |  | $ | 280,002 |  |  | $ | (63,398) |  |  | (22.6) | % |

[0000889331-23-000157:mdna:19]
[same as prior period, unchanged from 0000889331-23-000131:mdna:19]

[0000889331-23-000157:mdna:20]
Net sales decreased $51.8 million, or 7.9%, for the third quarter of 2023 compared to the third quarter of 2022 including $7.3 million or 1.1% of favorable changes in foreign exchange rates. The decrease in net sales was due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment that more than offset higher volume in passenger car products business within the Transportation segment, and higher volume in the Industrial segment.

[0000889331-23-000157:mdna:21]
Net sales decreased $71.8 million, or 3.8%, for the first nine months of 2023 compared to the first nine months of 2022, including $3.1 million or 0.2% of unfavorable changes in foreign exchange rates. The sales decrease was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment that more than offset $102.0 million or 5.4% incremental net sales associated with the C&K and Western Automation acquisitions and higher volume from the Industrial segment.

[0000889331-23-000157:mdna:22]
[same as prior period, unchanged from 0000889331-23-000131:mdna:22]

[0000889331-23-000157:mdna:23]
Cost of sales was $380.2 million, or 62.6% of net sales, in the third quarter of 2023, compared to $402.1 million, or 61.0% of net sales, in the third quarter of 2022. As a percent of net sales, cost of sales increased 1.6% driven by lower volume in the Electronics segment.

[0000889331-23-000157:mdna:24]
Cost of sales was $1,122.2 million, or 61.4% of net sales, in the first nine months of 2023, compared to $1,122.3 million, or 59.0% of net sales, in the first nine months of 2022. As a percent of net sales, cost of sales increased 2.3% driven by lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by volume leverage, and favorable product mix from the Industrial segment.

[0000889331-23-000157:mdna:25]
[same as prior period, unchanged from 0000889331-23-000131:mdna:25]

[0000889331-23-000157:mdna:26]
Gross profit was $226.9 million, or 37.4% of net sales, in the third quarter of 2023 compared to $256.8 million, or 39.0% of net sales, for the third quarter of 2022. The $30.0 million decrease in gross profit was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by higher volume in passenger car products business within the Transportation segment, and higher volume in the Industrial segment.

[0000889331-23-000157:mdna:27]
Gross profit was $706.7 million, or 38.6% of net sales, in the first nine months of 2023 compared to $778.4 million, or 41.0% of net sales, for the first nine months of 2022. The $71.7 million decrease in gross profit was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by the acquisition of C&K within the Electronics segment, and volume leverage and favorable product mix from the Industrial segment and $11.5 million or 0.6% of purchase accounting inventory charges recorded during the first nine months of 2022.

[0000889331-23-000157:mdna:28]
[same as prior period, unchanged from 0000889331-23-000131:mdna:28]

[0000889331-23-000157:mdna:29]
Operating expenses were $133.2 million, or 21.9% of net sales, for the third quarter of 2023 compared to $135.0 million, or 20.5% of net sales, for the third quarter of 2022. The decrease in operating expenses of $1.7 million was primarily due to lower selling, general, and administrative expenses of $3.0 million, partially offset by higher restructuring, impairment, and other charges of $1.1 million, including a $0.8 million impairment charge related to related to certain patents in a business within the Industrial segment.

[0000889331-23-000157:mdna:30]
Operating expenses were $410.3 million, or 22.4% of net sales, for the first nine months of 2023 compared to $371.8 million, or 19.6%of net sales, for the first nine months of 2022. The increase in operating expenses of $38.6 million was primarily due to higher selling, general, and administrative expenses of $11.2 million, higher amortization expense of $9.9 million and research and development expenses of $8.5 million mainly due to the C&K and Western Automation acquisitions. Additionally, the Company incurred an increase in restructuring, impairment, and other charges of $9.0 million, including a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment and $0.8 million impairment charge related to related to certain patents in a business within the Industrial segment. This increase in operating expenses was partially offset by lower variable incentive compensation expense.

[0000889331-23-000157:mdna:31]
[same as prior period, unchanged from 0000889331-23-000131:mdna:31]

[0000889331-23-000157:mdna:32]
Operating income was $93.6 million, representing a decrease of $28.3 million, or 23.2%, for the third quarter of 2023 compared to $121.9 million for the third quarter of 2022. The decrease in operating income was due to lower gross profit from the Electronics segment. Operating margins decreased from 18.5% in the third quarter of 2022 to 15.4% in the third quarter of 2023 driven by lower volume in the Electronics segment.

[0000889331-23-000157:mdna:33]
Operating income was $296.3 million, representing a decrease of $110.3 million, or 27.1%, for the first nine months of 2023 compared to $406.6 million for the first nine months of 2022. The decrease in operating income was due to lower gross profit from the Electronics and Transportation segments and higher operating expenses as noted above. Operating margins decreased from 21.4% in the first nine months of 2022 to 16.2% in the first nine months of 2023 driven by lower volume in the Electronics and Transportation segments and the higher operating expenses mentioned above.

[0000889331-23-000157:mdna:34]
[same as prior period, unchanged from 0000889331-23-000131:mdna:34]

[0000889331-23-000157:mdna:35]
Income before income taxes was $75.3 million, or 12.4% of net sales, for the third quarter of 2023 compared to $96.0 million, or 14.6% of net sales, for the third quarter of 2022. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily favorably impacted by lower foreign exchange losses of $6.4 million in the third quarter of 2023 compared to the third quarter of 2022.

[0000889331-23-000157:mdna:36]
Income before income taxes was $269.6 million, or 14.7% of net sales, for the first nine months of 2023 compared to $339.7 million, or 17.9% of net sales, for the first nine months of 2022. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by lower foreign exchange losses of $31.4 million and lower unrealized losses of $12.8 million related to one of the Company's equity investments during the nine months ended September 30, 2023 compared to the nine months ended October 1, 2022.

[0000889331-23-000157:mdna:37]
[same as prior period, unchanged from 0000889331-23-000131:mdna:37]

[0000889331-23-000157:mdna:38]
Income tax expense for the third quarter of 2023 was $17.5 million, or an effective tax rate of 23.3%, compared to $20.5 million, or an effective tax rate of 21.4%, for the third quarter of 2022. The effective tax rate for the third quarter of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to less income earned in lower tax jurisdictions in the 2023 period, as compared to the 2022 period. The effective tax rates for both periods are higher than the statutory tax rate due to the impact of foreign exchange losses with no related tax benefit.

[0000889331-23-000157:mdna:39]
Income tax expense for the first nine months of 2023 was $53.0 million, or an effective tax rate of 19.7%, compared to $59.7 million, or an effective tax rate of 17.6%, for the first nine months of 2022. The effective tax rate for the first nine months of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to the impact of a one-time deduction in the first quarter of 2022 that resulted in a net benefit of $7.2 million from the dissolution of one of the Company’s affiliates. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, while for the 2022 period, the effective tax rate was also lower due to the impact of the one-time deduction previously noted.

[0000889331-23-000157:mdna:40]
[same as prior period, unchanged from 0000889331-23-000131:mdna:41]

[0000889331-23-000157:mdna:41]
[same as prior period, unchanged from 0000889331-23-000131:mdna:42]

[0000889331-23-000157:mdna:42]
The following table is a summary of the Company’s net sales and operating income by segment:

[0000889331-23-000157:mdna:43]
| Net Sales |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  | 2023 |  | 2022 |  | Change |  | %Change |
| Electronics |  | $ | 343,933 |  |  | $ | 397,629 |  |  | $ | (53,696) |  |  | (13.5) | % |  | $ | 1,052,673 |  |  | $ | 1,121,626 |  |  | $ | (68,953) |  |  | (6.1) | % |
| Transportation |  | 177,019 |  |  | 181,735 |  |  | (4,716) |  |  | (2.6) | % |  | 515,708 |  |  | 548,266 |  |  | (32,558) |  |  | (5.9) | % |
| Industrial |  | 86,119 |  |  | 79,516 |  |  | 6,603 |  |  | 8.3 | % |  | 260,469 |  |  | 230,754 |  |  | 29,715 |  |  | 12.9 | % |
| Total |  | $ | 607,071 |  |  | $ | 658,880 |  |  | $ | (51,809) |  |  | (7.9) | % |  | $ | 1,828,850 |  |  | $ | 1,900,646 |  |  | $ | (71,796) |  |  | (3.8) | % |

[0000889331-23-000157:mdna:44]
| Operating income |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  | 2023 |  | 2022 |  | Change |  | %Change |
| Electronics |  | $ | 77,022 |  |  | $ | 113,140 |  |  | $ | (36,118) |  |  | (31.9) | % |  | $ | 247,028 |  |  | $ | 339,675 |  |  | $ | (92,647) |  |  | (27.3) | % |
| Transportation |  | 9,694 |  |  | 12,987 |  |  | (3,293) |  |  | (25.4) | % |  | 26,015 |  |  | 57,604 |  |  | (31,589) |  |  | (54.8) | % |
| Industrial |  | 13,201 |  |  | 12,178 |  |  | 1,023 |  |  | 8.4 | % |  | 45,450 |  |  | 39,968 |  |  | 5,482 |  |  | 13.7 | % |
| Other (a) |  | (6,272) |  |  | (16,435) |  |  | 10,163 |  |  |  |  | (22,154) |  |  | (30,623) |  |  | 8,469 |  |  |  |
| Total |  | $ | 93,645 |  |  | $ | 121,870 |  |  | $ | (28,225) |  |  | (23.2) | % |  | $ | 296,339 |  |  | $ | 406,624 |  |  | $ | (110,285) |  |  | (27.1) | % |

[0000889331-23-000157:mdna:45]
(a) Included in “Other” Operating income for the third quarter of 2023 was $3.7 million ($8.5 million year-to-date) of restructuring charges, primarily related to employee termination costs, and $1.8 million ($9.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment.

[0000889331-23-000157:mdna:46]
Included in “Other” Operating income for the third quarter of 2022 was $6.8 million ($11.6 million year-to-date) of purchase accounting inventory step-up charges, $6.2 million ($14.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $3.4 million ($4.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000157:mdna:47]
[same as prior period, unchanged from 0000889331-23-000131:mdna:45]

[0000889331-23-000157:mdna:48]
Net Sales

[0000889331-23-000157:mdna:49]
Net sales decreased $53.7 million, or 13.5%, in the third quarter of 2023 compared to the third quarter of 2022 and included favorable changes in foreign exchange rates of $4.4 million. The sales decrease was mainly due to lower volume across all businesses driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics.

[0000889331-23-000157:mdna:50]
Net sales decreased $69.0 million, or 6.1%, in the first nine months of 2023 compared to the first nine months quarter of 2022 and included unfavorable changes in foreign exchange rates of $0.4 million. The sales decrease was mainly due to lower volume from the Electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, and telecom, which more than offset the incremental net sales of $91.9 million from the C&K acquisition.

[0000889331-23-000157:mdna:51]
Operating Income

[0000889331-23-000157:mdna:52]
Operating income was $77.0 million, representing a decrease of $36.1 million, or 31.9%, for the third quarter of 2023 compared to $113.1 million for the third quarter of 2022. The decrease in operating income was primarily due to lower volume leverage from the Electronics products businesses and unfavorable mix that were partially offset by cost control initiatives. Operating margins decreased from 28.5% in the third quarter of 2022 to 22.4% in the third quarter of 2023 primarily due to the lower volume.

[0000889331-23-000157:mdna:53]
Operating income was $247.0 million, representing a decrease of $92.6 million, or 27.3%, for the first nine months of 2023 compared to $339.7 million for the first nine months of 2022. The decrease in operating income was primarily due to lower volume mainly driven from the Electronics products business, which more than offset the incremental volume from the C&K acquisition. Operating margins decreased from 30.3% in the first nine months of 2022 to 23.5% in the first nine months of 2023 primarily due to the lower volume.

[0000889331-23-000157:mdna:54]
[same as prior period, unchanged from 0000889331-23-000131:mdna:48]

[0000889331-23-000157:mdna:55]
Net Sales

[0000889331-23-000157:mdna:56]
Net sales decreased $4.7 million, or 2.6%, in the third quarter of 2023 compared to the third quarter of 2022 and included favorable changes in foreign exchange rates of $2.8 million. The sales decrease was mainly from the commercial vehicle business which had a net sales decline of $15.2 million driven by reduced demand largely due to inventory rebalancing at certain distributors and customers, and demand reduction in Asia end markets, partially offset by an increase of $10.2 million from the passenger car products business driven by global car build growth, new vehicle launches, as well as the ongoing electronification and electrification of vehicles.

[0000889331-23-000157:mdna:57]
Net sales decreased $32.6 million, or 5.9%, in the first nine months of 2023 compared to the first nine months of 2022 and included unfavorable changes in foreign exchange rates of $2.2 million. The commercial vehicle business net sales declined $40.6 million driven by reduced demand largely due to inventory rebalancing at certain distributors and customers, and some demand reduction in commercial vehicle end markets, partially offset by an increase of $13.6 million from the passenger car products business driven by the ongoing electronification and electrification of vehicles. The automotive sensors business had net sales declines of $5.5 million primarily due to lower demand in the United States and China.

[0000889331-23-000157:mdna:58]
Operating Income

[0000889331-23-000157:mdna:59]
Operating income was $9.7 million, representing a decrease of $3.3 million, or 25.4%, for the third quarter of 2023 compared to $13.0 million for the third quarter of 2022. The decrease in operating income was primarily due to lower volume driven by the decrease from the commercial vehicle business partially offset by higher volume and price realization in the passenger car business. Operating margins decreased from 7.1% in the third quarter of 2022 to 5.5% in the third quarter of 2023 primarily driven by lower commercial vehicle volume.

[0000889331-23-000157:mdna:60]
Operating income was $26.0 million, representing a decrease of $31.6 million, or 54.8%, for the first nine months of 2023 compared to $57.6 million for the first nine months of 2022. Operating margins declined from 10.5% to 5.0% primarily due to lower volume from the commercial vehicle business.

[0000889331-23-000157:mdna:61]
[same as prior period, unchanged from 0000889331-23-000131:mdna:51]

[0000889331-23-000157:mdna:62]
Net Sales

[0000889331-23-000157:mdna:63]
Net sales increased by $6.6 million, or 8.3%, in the third quarter of 2023 compared to the third quarter of 2022, which included favorable changes in foreign exchange rates of $0.1 million. The sales increase was primarily due to continued growth in construction/MRO, price realization and the acquisition of Western Automation.

[0000889331-23-000157:mdna:64]
Net sales increased by $29.7 million, or 12.9%, in the first nine months of 2023 compared to the first nine months of 2022, which included unfavorable changes in foreign exchange rates of $0.5 million. The sales increase was primarily due to higher volume in the construction/MRO, renewables, and industrial OEM end markets, and the acquisition of Western Automation.

[0000889331-23-000157:mdna:65]
Operating Income

[0000889331-23-000157:mdna:66]
Operating income was $13.2 million, representing an increase of $1.0 million, or 8.4%, for the third quarter of 2023 compared to $12.2 million for the third quarter of 2022. The increase in operating income was driven by price realization and higher volume, partially offset by higher amortization expense from the acquisition of Western Automation. Operating margin was 15.3% for both the third quarter of 2023 and 2022.

[0000889331-23-000157:mdna:67]
Operating income was $45.5 million, representing an increase of $5.5 million, or 13.7%, for the first nine months of 2023 compared to $40.0 million for the first nine months of 2022. The increase in operating income was due to price realization and

[0000889331-23-000157:mdna:68]
higher volume, partially offset by higher amortization expenses from the acquisition of Western Automation. Operating margins were 17.4% in the first nine months of 2023 compared to 17.3% in the first nine months of 2022.

[0000889331-23-000157:mdna:69]
[same as prior period, unchanged from 0000889331-23-000131:mdna:54]

[0000889331-23-000157:mdna:70]
[same as prior period, unchanged from 0000889331-23-000131:mdna:55]

[0000889331-23-000157:mdna:71]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  | 2023 |  | 2022 |  | Change |  | %Change |
| Americas |  | $ | 236,706 |  |  | $ | 264,894 |  |  | $ | (28,188) |  |  | (10.6) | % |  | $ | 698,456 |  |  | $ | 749,715 |  |  | $ | (51,259) |  |  | (6.8) | % |
| Asia-Pacific |  | 235,908 |  |  | 263,963 |  |  | (28,055) |  |  | (10.6) | % |  | 693,611 |  |  | 776,990 |  |  | (83,379) |  |  | (10.7) | % |
| Europe |  | 134,457 |  |  | 130,023 |  |  | 4,434 |  |  | 3.4 | % |  | 436,783 |  |  | 373,941 |  |  | 62,842 |  |  | 16.8 | % |
| Total |  | $ | 607,071 |  |  | $ | 658,880 |  |  | $ | (51,809) |  |  | (7.9) | % |  | $ | 1,828,850 |  |  | $ | 1,900,646 |  |  | $ | (71,796) |  |  | (3.8) | % |

[0000889331-23-000157:mdna:72]
[same as prior period, unchanged from 0000889331-23-000131:mdna:60]

[0000889331-23-000157:mdna:73]
Net sales decreased $28.2 million, or 10.6%, in the third quarter of 2023 compared to the third quarter of 2022 and included favorable changes in foreign exchange rates of $0.1 million. The decrease in net sales was primarily due to lower volume from the Electronics segment and lower sales from the commercial vehicle business within the Transportation segment, partially offset by higher sales from the passenger car products business within the Transportation segment and growth across various markets in the Industrial segment compared to the third quarter of 2022.

[0000889331-23-000157:mdna:74]
Net sales decreased $51.3 million, or 6.8%, in the first nine months of 2023 compared to the first nine months of 2022 and included unfavorable changes in foreign exchange rates of $0.3 million. The decrease in net sales was primarily due to lower volume from the electronics products business within the Electronics segment and lower sales from the commercial vehicle business within the Transportation segment, partially offset by incremental sales from C&K acquisition within the Electronics segment and higher sales within the Industrial segment compared to the first nine months of 2022.

[0000889331-23-000157:mdna:75]
[same as prior period, unchanged from 0000889331-23-000131:mdna:57]

[0000889331-23-000157:mdna:76]
Net sales decreased $28.1 million, or 10.6%, in the third quarter of 2023 compared to the third quarter of 2022 and included unfavorable changes in foreign exchange rates of $1.8 million. The decrease in net sales was primarily due to lower net sales from the Electronics segment and lower net sales from the commercial vehicle business within the Transportation segment, partially offset by higher net sales from passenger car products business within the Transportation segment compared to the third quarter of 2022.

[0000889331-23-000157:mdna:77]
Net sales decreased $83.4 million, or 10.7%, in the first nine months of 2023 compared to the first nine months of 2022 and included unfavorable changes in foreign exchange rates of $8.4 million. The decrease in net sales was primarily due to lower net sales from electronics products business within the Electronics segment and lower net sales from the commercial vehicle and automotive sensors businesses within the Transportation segment, partially offset by incremental sales from the acquisition of C&K.

[0000889331-23-000157:mdna:78]
[same as prior period, unchanged from 0000889331-23-000131:mdna:63]

[0000889331-23-000157:mdna:79]
Net sales increased $4.4 million, or 3.4%, in the third quarter of 2023 compared to the third quarter of 2022 and included favorable changes in foreign exchange rates of $9.0 million. The increase in net sales was primarily due to favorable changes in foreign exchange rates, increased volume across all businesses within the Transportation segment, and incremental sales from the Western Automation acquisition included within the Industrial segment, partially offset by lower net sales from the Electronics segment.

[0000889331-23-000157:mdna:80]
Net sales increased $62.8 million, or 16.8%, in the first nine months of 2023 compared to the first nine months of 2022 and included favorable changes in foreign exchange rates of $5.6 million. The increase in net sales was primarily due to the incremental sales from the acquisition of C&K, increased volume from the semiconductor business within the Electronics segment, and the incremental sales from the Western Automation acquisition included within the Industrial segment, partially offset by lower net sales from the electronics products business within the Electronics segment.

[0000889331-23-000157:mdna:81]
36

[0000889331-23-000157:mdna:82]
[same as prior period, unchanged from 0000889331-23-000131:mdna:67]

[0000889331-23-000157:mdna:83]
[same as prior period, unchanged from 0000889331-23-000131:mdna:68]

[0000889331-23-000157:mdna:84]
Cash and cash equivalents were $560.1 million as of September 30, 2023, a decrease of $2.5 million as compared to December 31, 2022. As of September 30, 2023, $155.6 million of the Company's $560.1 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-23-000157:mdna:85]
Revolving Credit Facility and Term Loan

[0000889331-23-000157:mdna:86]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000157:mdna:87]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000157:mdna:88]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 30, 2023, the Company made payments of $1.9 million and $5.6 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $290.6 million, respectively, as of September 30, 2023.

[0000889331-23-000157:mdna:89]
[same as prior period, unchanged from 0000889331-23-000131:mdna:74]

[0000889331-23-000157:mdna:90]
As of September 30, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.67%.

[0000889331-23-000157:mdna:91]
As of September 30, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of September 30, 2023, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-23-000157:mdna:92]
[same as prior period, unchanged from 0000889331-23-000131:mdna:77]

[0000889331-23-000157:mdna:93]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December

[0000889331-23-000157:mdna:94]
8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-23-000157:mdna:95]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-23-000157:mdna:96]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000157:mdna:97]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000157:mdna:98]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-23-000157:mdna:99]
Debt Covenants

[0000889331-23-000157:mdna:100]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of September 30, 2023 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2023. As of September 30, 2023, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-23-000157:mdna:101]
[same as prior period, unchanged from 0000889331-23-000131:mdna:86]

[0000889331-23-000157:mdna:102]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the fab is approximately 93 million Euro, of which 37.2 million Euro down payment (approximately $40.5 million) recorded in Other long-term assets in the Condensed Consolidated Balance Sheets was paid in the third quarter after regulatory approvals and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2023 or 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-23-000157:mdna:103]
[same as prior period, unchanged from 0000889331-23-000131:mdna:88]

[0000889331-23-000157:mdna:104]
[same as prior period, unchanged from 0000889331-23-000131:mdna:89]

[0000889331-23-000157:mdna:105]
During the third quarter of 2023 the Company paid quarterly dividends of $16.2 million to the shareholders. On October 31, 2023, the Company announced the declaration of a quarterly cash dividend of $0.65 per share payable on December 7, 2023 to stockholders of record as of November 23, 2023.

[0000889331-23-000157:mdna:106]
[same as prior period, unchanged from 0000889331-23-000131:mdna:91]

[0000889331-23-000157:mdna:107]
|  |  | First Nine Months |
| (in thousands) |  | 2023 |  | 2022 |
| Net cash provided by operating activities |  | $ | 313,140 |  |  | $ | 313,439 |  |
| Net cash used in investing activities |  | (261,379) |  |  | (609,980) |  |
| Net cash (used in) provided by financing activities |  | (47,144) |  |  | 321,923 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (7,965) |  |  | (31,963) |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (3,348) |  |  | (6,581) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 564,939 |  |  | 482,836 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 561,591 |  |  | $ | 476,255 |  |

[0000889331-23-000157:mdna:108]
[same as prior period, unchanged from 0000889331-23-000131:mdna:93]

[0000889331-23-000157:mdna:109]
[same as prior period, unchanged from 0000889331-23-000131:mdna:94]

[0000889331-23-000157:mdna:110]
Net cash provided by operating activities was $313.1 million for the nine months ended September 30, 2023 compared to $313.4 million for the nine months ended October 1, 2022 as lower cash earnings were offset by reductions in working capital.

[0000889331-23-000157:mdna:111]
[same as prior period, unchanged from 0000889331-23-000131:mdna:96]

[0000889331-23-000157:mdna:112]
Net cash used in investing activities was $261.4 million for the nine months ended September 30, 2023 compared to $610.0 million during the nine months ended October 1, 2022. Net cash paid for acquisitions was $198.8 million and $532.8 million during the nine months ended September 30, 2023 and October 1, 2022, respectively. Capital expenditures were $63.2 million, representing a decrease of $14.6 million compared to nine months ended October 1, 2022. During the nine months ended September 30, 2023 and October 1, 2022, the Company received proceeds of $0.7 million from the sale of a property within the Electronics segment and $0.6 million from the sale of a property within the Transportation segment, respectively.

[0000889331-23-000157:mdna:113]
[same as prior period, unchanged from 0000889331-23-000131:mdna:98]

[0000889331-23-000157:mdna:114]
Net cash used in financing activities was $47.1 million for the nine months ended September 30, 2023 compared to net cash provided by financing activities of $321.9 million for the nine months ended October 1, 2022. On June 30, 2022, the Company amended its Credit Agreement and borrowed $300.0 million through a term loan. During the nine months ended September 30, 2023, the Company made payments of $5.6 million on the term loan. During the nine months ended October 1, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022 and $1.9 million on the term loan. Additionally, the Company paid dividends of $46.0 million and $41.1 million in the nine months ended September 30, 2023 and October 1, 2022, respectively.

[0000889331-23-000157:mdna:115]
[same as prior period, unchanged from 0000889331-23-000131:mdna:100]

[0000889331-23-000157:mdna:116]
[same as prior period, unchanged from 0000889331-23-000131:mdna:101]

[0000889331-23-000157:mdna:117]
The Company did not repurchase shares of its common stock for the three and nine months ended September 30, 2023, and October 1, 2022.

[0000889331-23-000157:mdna:118]
[same as prior period, unchanged from 0000889331-23-000131:mdna:103]

[0000889331-23-000157:mdna:119]
As of September 30, 2023, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-23-000157:mdna:120]
[same as prior period, unchanged from 0000889331-23-000131:mdna:105]

[0000889331-23-000157:mdna:121]
[same as prior period, unchanged from 0000889331-23-000131:mdna:106]

[0000889331-23-000157:mdna:122]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 31, 2022. During the nine months ended September 30, 2023, there were no significant changes in the application of critical accounting policies.
