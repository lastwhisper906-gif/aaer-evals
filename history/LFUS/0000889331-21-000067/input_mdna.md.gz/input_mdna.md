# LFUS MD&A — 0000889331-21-000067


## mdna

[0000889331-21-000067:mdna:1]
[same as prior period, unchanged from 0000889331-21-000047:mdna:1]

[0000889331-21-000067:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-21-000067:mdna:3]
[same as prior period, unchanged from 0000889331-21-000047:mdna:3]

[0000889331-21-000067:mdna:4]
[same as prior period, unchanged from 0000889331-21-000047:mdna:4]

[0000889331-21-000067:mdna:5]
[same as prior period, unchanged from 0000889331-21-000047:mdna:5]

[0000889331-21-000067:mdna:6]
[same as prior period, unchanged from 0000889331-21-000047:mdna:6]

[0000889331-21-000067:mdna:7]
[same as prior period, unchanged from 0000889331-21-000047:mdna:7]

[0000889331-21-000067:mdna:8]
[same as prior period, unchanged from 0000889331-21-000047:mdna:8]

[0000889331-21-000067:mdna:9]
For the third quarter of 2021, the Company recognized net sales of $539.6 million, an increase of $148.0 million, or 37.8% as compared to $391.6 million in the third quarter of 2020. The increase was primarily driven by higher volumes across each of the segments, $29.3 million or 5.4% of net sales from the Hartland acquisition within the Industrial segment and $4.2 million or 1.1% of favorable changes in foreign exchange rates. The Company recognized net income of $92.1 million, or $3.69 per diluted share, in the third quarter of 2021 compared to $55.4 million, or $2.25 per diluted share in the third quarter of 2020. The increase in net income reflects higher operating income of $55.5 million driven by a $54.7 million increase in operating income in the Electronics segment partially offset by higher foreign exchange losses and acquisition-related and integration charges.

[0000889331-21-000067:mdna:10]
Supply chain constraints, including transportation capacity shortages have and are expected to continue to impact the Company, our suppliers and our customers.  This has resulted in higher transportation and input costs incurred by the Company and supply chain shortages have impacted our suppliers and customers across the markets that we serve.

[0000889331-21-000067:mdna:11]
Net cash provided by operating activities was $240.7 million for the nine months ended September 25, 2021 as compared to $164.3 million for the nine months ended September 26, 2020. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth.

[0000889331-21-000067:mdna:12]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The purchase price for Hartland was $112.3 million and the operations of Hartland are included in the Industrial segment.

[0000889331-21-000067:mdna:13]
On October 20, 2021, the Company announced that it had entered in a definitive agreement to acquire Carling Technologies, Inc. (“Carling”) for $315 million in cash, subject to a working capital adjustment. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle, marine and datacom/telecom infrastructure markets. The business is headquartered in Plainville, Connecticut, with offices and facilities located around the world and will be reported as part of the commercial vehicle business within our Automotive segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close in the fourth quarter of 2021.

[0000889331-21-000067:mdna:14]
[same as prior period, unchanged from 0000889331-21-000047:mdna:12]

[0000889331-21-000067:mdna:15]
The effects from COVID-19 continue to drive increased costs, though lower than 2020 levels. Ongoing costs include spending on personal protective equipment ("PPE"), additional personnel and employee transportation costs, and manufacturing inefficiencies. as well as an increase in transportation costs and raw material due to the transportation capacity constraints across the world. The company has also been experiencing higher raw material costs, as well as transportation costs due to global transportation capacity constraints

[0000889331-21-000067:mdna:16]
The Company anticipates that the disruptions caused by COVID-19 may continue to impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a resurgence in COVID-19 cases and its impact on our employees, customers, suppliers and vendors. The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our

[0000889331-21-000067:mdna:17]
business and operations, including the effects on our customers, employees, and prospects, or on our financial results for the fiscal year 2021.

[0000889331-21-000067:mdna:18]
[same as prior period, unchanged from 0000889331-21-000047:mdna:15]

[0000889331-21-000067:mdna:19]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The third quarter of 2021 includes $6.8 million year-to-date of purchase accounting inventory step-up charges, $2.0 million ($3.4 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.8 million ($2.0 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a year-to-date gain of $0.9 million recorded for the sale of a building within the Electronics segment.

[0000889331-21-000067:mdna:20]
The third quarter of 2020 includes $0.3 million ($1.6 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there was $1.3 million ($40.9 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs of $1.2 million ($4.6 million year-to-date), and other restructuring charges of $0.1 million ($0.2 million year-to-date), the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, impairment charges of $2.2 million recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment.

[0000889331-21-000067:mdna:21]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  | 2021 |  | 2020 |  | Change |  | %Change |
| Net sales |  | $ | 539,581 |  |  | $ | 391,566 |  |  | $ | 148,015 |  |  | 37.8 | % |  | $ | 1,526,863 |  |  | $ | 1,044,999 |  |  | $ | 481,864 |  |  | 46.1 | % |
| Cost of sales |  | 325,009 |  |  | 252,735 |  |  | 72,274 |  |  | 28.6 | % |  | 954,429 |  |  | 681,910 |  |  | 272,519 |  |  | 40.0 | % |
| Gross profit |  | 214,572 |  |  | 138,831 |  |  | 75,741 |  |  | 54.6 | % |  | 572,434 |  |  | 363,089 |  |  | 209,345 |  |  | 57.7 | % |
| Operating expenses |  | 94,465 |  |  | 74,273 |  |  | 20,192 |  |  | 27.2 | % |  | 279,589 |  |  | 265,731 |  |  | 13,858 |  |  | 5.2 | % |
| Operating income |  | 120,107 |  |  | 64,558 |  |  | 55,549 |  |  | 86.0 | % |  | 292,845 |  |  | 97,358 |  |  | 195,487 |  |  | 200.8 | % |
| Income before income taxes |  | 113,591 |  |  | 67,426 |  |  | 46,165 |  |  | 68.5 | % |  | 281,496 |  |  | 92,340 |  |  | 189,156 |  |  | 204.8 | % |
| Income taxes |  | 21,537 |  |  | 12,070 |  |  | 9,467 |  |  | 78.4 | % |  | 49,634 |  |  | 21,331 |  |  | 28,303 |  |  | 132.7 | % |
| Net income |  | $ | 92,054 |  |  | $ | 55,356 |  |  | $ | 36,698 |  |  | 66.3 | % |  | $ | 231,862 |  |  | $ | 71,009 |  |  | $ | 160,853 |  |  | 226.5 | % |

[0000889331-21-000067:mdna:22]
[same as prior period, unchanged from 0000889331-21-000047:mdna:20]

[0000889331-21-000067:mdna:23]
Net sales increased $148.0 million or 37.8% including $4.2 million or 1.1% of favorable changes in foreign exchange rates for the third quarter of 2021 compared to the third quarter of 2020. The increase was driven by growth across each of our segments with the most significant sales growth within the Electronics and Automotive segments, which had sales increases of $91.9 million and $19.7 million, respectively. The increase within the Electronics segment was led by continued broad-based demand across electronics, transportation and industrial end markets. The increase within the Automotive segment was across both the passenger car and commercial vehicle businesses. While global car build declined compared to the same quarter last year largely due to market shortages of semiconductor chips, the automotive growth was due to greater content growth across passenger vehicles from vehicle mix, including growth in electric vehicles, as well as some customers maintaining additional inventory of our products. The growth in the commercial vehicle business was driven largely by continued demand across a number of commercial vehicle end markets. The remaining increase in net sales was primarily due to $29.3 million of net sales resulting from the Hartland acquisition included in the Industrial segment and volume growth across all businesses within the Industrial segment.

[0000889331-21-000067:mdna:24]
Net sales increased $481.9 million or 46.1% including $30.1 million or 2.9% of favorable changes in foreign exchange rates for the first nine months of 2021 compared to 2020. The increase was due to volume growth across all segments and businesses while the first nine months of 2020 had temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19. The increase was primarily due to higher sales of $266.3 million and $114.8 million in the

[0000889331-21-000067:mdna:25]
Electronics and Automotive segments, respectively, driven by higher volumes across all businesses within these segments. The volume increase within the Electronics segment was led by broad-based demand across electronics, transportation and industrial end markets. The volume increase within the Automotive segment was led by growth in global auto and commercial vehicle market demand, greater content growth across passenger vehicles due to vehicle mix, including growth in electric vehicles and some customers maintaining additional inventory of our products. The remaining increase in net sales was primarily due to $72.3 million of net sales resulting from the Hartland acquisition included in the Industrial segment and volume growth across all businesses within the Industrial segment.

[0000889331-21-000067:mdna:26]
[same as prior period, unchanged from 0000889331-21-000047:mdna:24]

[0000889331-21-000067:mdna:27]
Cost of sales was $325.0 million, or 60.2% of net sales, in 2021, compared to $252.7 million, or 64.5% of net sales, in 2020. The increase in cost of sales was primarily due to greater volume across all segments driven by the factors discussed above along with the acquisition of Hartland. As a percent of net sales, cost of sales decreased 4.3% driven by volume leverage and favorable product mix, partially offset by higher transportation, duty and tariff charges of 1.9%, and higher commodity costs.

[0000889331-21-000067:mdna:28]
Cost of sales was $954.4 million, or 62.5% of net sales for the first nine months of 2021, compared to $681.9 million, or 65.3% of net sales for the first nine months of 2020. The increase in cost of sales was primarily due to greater volume across all segments driven by the factors discussed above along with the acquisition of Hartland. As a percent of net sales, cost of sales decreased 2.7% driven by volume leverage, partially offset by higher transportation, duty and tariff charges of 0.8%, the Hartland purchase accounting inventory charges of $6.8 million or 0.4%, and higher commodity costs.

[0000889331-21-000067:mdna:29]
[same as prior period, unchanged from 0000889331-21-000047:mdna:27]

[0000889331-21-000067:mdna:30]
Gross profit was $214.6 million, or 39.8% of net sales, in the third quarter of 2021 compared to $138.8 million, or 35.5% of net sales, for the third quarter of 2020. The $75.7 million increase in gross profit was primarily due to higher volume in the Electronics segment. The increase in gross margin of 4.3% was primarily driven by volume leverage and favorable product mix within the Electronics segment, higher prices, partially offset by higher transportation, duty and tariff charges as a percent of net sales of 1.9%, and higher commodity costs.

[0000889331-21-000067:mdna:31]
Gross profit was $572.4 million, or 37.5% of net sales, in the first nine months of 2021 compared to $363.1 million, or 34.7% of net sales, for the first nine months of 2020. The $209.3 million increase in gross profit was primarily due to higher volume across all segments while the first nine months of 2020 had additional costs associated with government-directed plant shutdowns and supply chain constraints. The increase in gross margin of 2.7% was primarily driven by volume leverage and favorable product mix within the Electronics segment, partially offset by higher transportation, duty and tariff charges as a percent of net sales of 0.8%, the purchase accounting inventory charges of $6.8 million or 0.4%, and higher commodity costs.

[0000889331-21-000067:mdna:32]
[same as prior period, unchanged from 0000889331-21-000047:mdna:30]

[0000889331-21-000067:mdna:33]
Total operating expenses were $94.5 million, or 17.5% of net sales, for the third quarter of 2021 compared to $74.3 million, or 19.0% of net sales, for the third quarter of 2020. The increase in operating expenses of $20.2 million was primarily due to the higher selling, general and administrative expenses of $17.5 million largely due to higher accrued incentive compensation and the Hartland acquisition, and higher research and development expenses of $2.8 million.

[0000889331-21-000067:mdna:34]
Total operating expenses were $279.6 million, or 18.3% of net sales, for the first nine months of 2021 compared to $265.7 million, or 25.4% of net sales, for the first nine months of 2020. The increase in operating expenses of $13.9 million is primarily due to higher selling, general, and administrative expenses of $44.7 million largely due to higher accrued incentive compensation and the Hartland acquisition, and higher research and development expenses of $6.3 million, partially offset by the 2020 goodwill impairment charge of $33.8 million, or 3.2% of net sales, in the automotive sensors reporting unit within the Automotive segment and impairment charges of $2.2 million related to the Company’s 2020 first quarter announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-21-000067:mdna:35]
Operating Income

[0000889331-21-000067:mdna:36]
Operating income was $120.1 million, an increase of $55.5 million, or 86.0%, for the third quarter of 2021 compared to $64.6 million for the third quarter of 2020. The increase in operating income was due to higher gross profit from all segments, particularly in the Electronics segment, partially offset by higher operating expenses as noted above. Operating margins increased from 16.5% in the third quarter of 2020 to 22.3% in the third quarter of 2021 driven by the factors mentioned above.

[0000889331-21-000067:mdna:37]
Operating income was $292.8 million, an increase of $195.5 million, or 200.8%, for the first nine months of 2021 compared to $97.4 million for the first nine months of 2020. The increase in operating income was primarily due to higher gross margin

[0000889331-21-000067:mdna:38]
across all segments partially offset by higher operating expenses noted above. Operating margins increased from 9.3% in the first nine months of 2020 to 19.2% in the first nine months of 2021 driven by the factors mentioned above. The goodwill impairment charge of $33.8 million negatively impacted the operating margin by 3.2% for the first nine months of 2020.

[0000889331-21-000067:mdna:39]
Income Before Income Taxes

[0000889331-21-000067:mdna:40]
Income before income taxes was $113.6 million, or 21.1% of net sales, for the third quarter of 2021 compared to $67.4 million, or 17.2% of net sales, for the third quarter of 2020. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange losses of $3.2 million in the third quarter of 2021 compared to foreign exchange gains of $6.2 million in the third quarter of 2020.

[0000889331-21-000067:mdna:41]
Income before income taxes was $281.5 million, or 18.4% of net sales, for the first nine months of 2021 compared to $92.3 million, or 8.8% of net sales, for the first nine months of 2020. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by foreign exchange losses of $8.3 million during the nine months ended September 25, 2021 compared to foreign exchange gains of $9.6 million during nine months ended September 26, 2020, partially offset by a $7.7 million increase in unrealized investment gains associated with our equity investment and lower interest expense of $2.4 million due to lower outstanding borrowings under the credit facility along with a lower effective interest rate, and coal mining charges of $1.8 million incurred during the nine months ended September 26, 2020.

[0000889331-21-000067:mdna:42]
[same as prior period, unchanged from 0000889331-21-000047:mdna:40]

[0000889331-21-000067:mdna:43]
Income tax expense for the third quarter of 2021 was $21.5 million, or an effective tax rate of 19.0%, compared to $12.1 million, or an effective tax rate of 17.9%, for the third quarter of 2020. The effective tax rate for the third quarter of 2021 is higher than the effective tax rate for the comparable 2020 period, primarily due to a reduction during the third quarter of 2020 in the estimated 2020 annual effective tax rate, the impact of which was recorded during the third quarter of 2020.

[0000889331-21-000067:mdna:44]
Income tax expense for the first nine months of 2021 was $49.6 million, or an effective tax rate of 17.6%, compared to $21.3 million, or an effective tax rate of 23.1%, for the first nine months of 2020. The effective tax rate for the first nine months of 2021 is lower than the effective tax rate for the comparable 2020 period primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 compared to 2020, and the impact of the goodwill impairment charge of $33.8 million recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit. The effective tax rate for the 2021 period is lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-21-000067:mdna:45]
[same as prior period, unchanged from 0000889331-21-000047:mdna:44]

[0000889331-21-000067:mdna:46]
[same as prior period, unchanged from 0000889331-21-000047:mdna:45]

[0000889331-21-000067:mdna:47]
[same as prior period, unchanged from 0000889331-21-000047:mdna:46]

[0000889331-21-000067:mdna:48]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  | 2021 |  | 2020 |  | Change |  | %Change |
| Electronics |  | $ | 347,240 |  |  | $ | 255,349 |  |  | $ | 91,891 |  |  | 36.0 | % |  | $ | 959,122 |  |  | $ | 692,809 |  |  | $ | 266,313 |  |  | 38.4 | % |
| Automotive |  | 124,415 |  |  | 104,724 |  |  | 19,691 |  |  | 18.8 | % |  | 386,262 |  |  | 271,493 |  |  | 114,769 |  |  | 42.3 | % |
| Industrial |  | 67,926 |  |  | 31,493 |  |  | 36,433 |  |  | 115.7 | % |  | 181,479 |  |  | 80,697 |  |  | 100,782 |  |  | 124.9 | % |
| Total |  | $ | 539,581 |  |  | $ | 391,566 |  |  | $ | 148,015 |  |  | 37.8 | % |  | $ | 1,526,863 |  |  | $ | 1,044,999 |  |  | $ | 481,864 |  |  | 46.1 | % |

[0000889331-21-000067:mdna:49]
[same as prior period, unchanged from 0000889331-21-000047:mdna:48]

[0000889331-21-000067:mdna:50]
Net sales increased $91.9 million, or 36.0%, in the third quarter of 2021 compared to the third quarter of 2020 and included favorable changes in foreign exchange rates of $2.3 million. The sales increase was primarily due to increased volume for the electronics products and semiconductor businesses of $63.0 million and $28.8 million, respectively. The volume increase

[0000889331-21-000067:mdna:51]
within the Electronics segment was led by continued broad-based demand across electronics, transportation and industrial end markets.

[0000889331-21-000067:mdna:52]
Net sales increased $266.3 million, or 38.4%, in the first nine months of 2021 compared to the first nine months of 2020 and included favorable changes in foreign exchange rates of $16.2 million. The sales increase was primarily due to increased volume for the electronics products and semiconductor businesses of $173.3 million and $93.0 million, respectively. The volume increases were driven by broad-based demand across electronics, transportation and industrial end markets while the first nine months of 2020 were negatively impacted by production disruptions due to the impact of COVID-19.

[0000889331-21-000067:mdna:53]
[same as prior period, unchanged from 0000889331-21-000047:mdna:51]

[0000889331-21-000067:mdna:54]
Net sales increased $19.7 million, or 18.8%, in the third quarter of 2021 compared to the third quarter of 2020 and included favorable changes in foreign exchange rates of $1.7 million. The sales increase was due to higher volume in passenger car products and commercial vehicle products businesses of $11.9 million and $9.7 million, respectively, partially offset by lower volume in automotive sensors business of $2.0 million. The increase within the Automotive segment was across both the passenger car and commercial vehicle businesses. While global car build declined compared to the same quarter last year largely due to market shortages of semiconductor chips, the automotive growth was due to greater content growth across passenger vehicles from vehicle mix, including growth in electric vehicles, as well as some customers maintaining additional inventory of our products. The growth in the commercial vehicle business was driven largely by continued demand across a number of commercial vehicle end markets. This growth was across all regions, particularly in Asia-Pacific where volumes and demand increased, but constrained in Europe and North America where supply chain shortages have had a detrimental impact on vehicle output.

[0000889331-21-000067:mdna:55]
Net sales increased $114.8 million, or 42.3%, in the first nine months of 2021 compared to the first nine months of 2020 and included favorable changes in foreign exchange rates of $13.0 million. These sales increases were due to higher volume in passenger car products, commercial vehicle products, and the automotive sensors businesses of $64.9 million, $34.9 million, and $14.9 million, respectively. These increases were due to stronger global auto and commercial vehicle market demand. Each of our regions experienced growth driven by an increase in global auto market demand as compared to the first nine months of 2020, which had production disruptions due to the impact of COVID-19. Sales also grew due to the launch of new products and higher content per vehicle due to automotive vehicle mix.

[0000889331-21-000067:mdna:56]
[same as prior period, unchanged from 0000889331-21-000047:mdna:54]

[0000889331-21-000067:mdna:57]
Net sales increased by $36.4 million, or 115.7%, in the third quarter of 2021 compared to the third quarter of 2020, which included favorable changes in foreign exchange rates of $0.2 million. The increase in net sales was primarily due to incremental net sales of $29.3 million or 92.9% from the Hartland acquisition and higher volume across all product lines.

[0000889331-21-000067:mdna:58]
Net sales increased by $100.8 million, or 124.9%, in the first nine months of 2021 compared to the first nine months of 2020, which included favorable changes in foreign exchange rates of $0.9 million. The increase in net sales was primarily due to incremental net sales of $72.3 million or 89.6% from the Hartland acquisition, growth across all product lines, and the transfer of the temperature sensor product line totaling $4.7 million which was previously reported in the Electronics segment and moved to Industrial segment in the third quarter of 2020. Additionally, the first nine months of 2020 was negatively impacted by production disruptions and temporary plant shutdown due to the impact of COVID-19.

[0000889331-21-000067:mdna:59]
[same as prior period, unchanged from 0000889331-21-000047:mdna:57]

[0000889331-21-000067:mdna:60]
[same as prior period, unchanged from 0000889331-21-000047:mdna:58]

[0000889331-21-000067:mdna:61]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  | 2021 |  | 2020 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 250,880 |  |  | $ | 186,956 |  |  | $ | 63,924 |  |  | 34.2 | % |  | $ | 702,542 |  |  | $ | 483,566 |  |  | $ | 218,976 |  |  | 45.3 | % |
| Americas |  | 167,314 |  |  | 123,739 |  |  | 43,575 |  |  | 35.2 | % |  | 500,555 |  |  | 333,891 |  |  | 166,664 |  |  | 49.9 | % |
| Europe |  | 121,387 |  |  | 80,871 |  |  | 40,516 |  |  | 50.1 | % |  | 323,766 |  |  | 227,542 |  |  | 96,224 |  |  | 42.3 | % |
| Total |  | $ | 539,581 |  |  | $ | 391,566 |  |  | $ | 148,015 |  |  | 37.8 | % |  | $ | 1,526,863 |  |  | $ | 1,044,999 |  |  | $ | 481,864 |  |  | 46.1 | % |

[0000889331-21-000067:mdna:62]
[same as prior period, unchanged from 0000889331-21-000047:mdna:60]

[0000889331-21-000067:mdna:63]
Net sales increased $63.9 million, or 34.2%, in the third quarter of 2021 compared to the third quarter of 2020 and included favorable changes in foreign exchange rates of $2.9 million. The increase in net sales was primarily due to higher volume across all businesses within the Electronics, Automotive, and Industrial segments compared to the third quarter of 2020.

[0000889331-21-000067:mdna:64]
Net sales increased $219.0 million, or 45.3%, in the first nine months of 2021 compared to the first nine months of 2020 and included favorable changes in foreign exchange rates of $12.0 million. The increase in net sales was primarily due to higher volume across all businesses across all segments compared to the first nine months of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000067:mdna:65]
[same as prior period, unchanged from 0000889331-21-000047:mdna:63]

[0000889331-21-000067:mdna:66]
Net sales increased $43.6 million, or 35.2%, in the third quarter of 2021 compared to the third quarter of 2020 and included favorable changes in foreign exchange rates of $0.2 million. The increase in net sales was primarily due to incremental sales from the Hartland acquisition included in the Industrial segment, higher volume from the electronics products business within the Electronics segment and commercial vehicle products business within the Automotive segment, and higher volume across all businesses within the Industrial segment compared to the third quarter of 2020.

[0000889331-21-000067:mdna:67]
Net sales increased $166.7 million, or 49.9%, in the first nine months of 2021 compared to first nine months of 2020 and included favorable changes in foreign exchange rates of $0.6 million. The increase in net sales was primarily due to incremental sales from the Hartland acquisition, higher volume across all businesses within the Electronics and Automotive segments compared to the first nine months of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000067:mdna:68]
[same as prior period, unchanged from 0000889331-21-000047:mdna:66]

[0000889331-21-000067:mdna:69]
Net sales increased $40.5 million, or 50.1%, in the third quarter of 2021 compared to the third quarter of 2020 and included favorable changes in foreign exchange rates of $1.1 million. The increase in net sales was primarily due to increased volume across all businesses within the Electronics segment and commercial vehicle products business within the Automotive segment, and higher volume cross all businesses within the Industrial segment compared to the third quarter of 2020.

[0000889331-21-000067:mdna:70]
Net sales increased $96.2 million, or 42.3%, in the first nine months of 2021 compared to the first nine months of 2020 and included favorable changes in foreign exchange rates of $17.5 million. The increase in net sales was primarily due to higher volume across all businesses within the Electronics and Automotive segments compared to the first nine months of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000067:mdna:71]
[same as prior period, unchanged from 0000889331-21-000047:mdna:69]

[0000889331-21-000067:mdna:72]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0000889331-21-000067:mdna:73]
Cash and cash equivalents were $690.7 million as of September 25, 2021, a decrease of $3.2 million as compared to December 26, 2020. As of September 25, 2021, $337.2 million of the Company's $690.7 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-21-000067:mdna:74]
Revolving Credit Facility

[0000889331-21-000067:mdna:75]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit

[0000889331-21-000067:mdna:76]
facility during the nine months ended September 25, 2021. The balance under the facility was $100.0 million as of September 25, 2021.

[0000889331-21-000067:mdna:77]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.33% at September 25, 2021.

[0000889331-21-000067:mdna:78]
As of September 25, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At September 25, 2021, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-21-000067:mdna:79]
[same as prior period, unchanged from 0000889331-21-000047:mdna:77]

[0000889331-21-000067:mdna:80]
[same as prior period, unchanged from 0000889331-21-000047:mdna:78]

[0000889331-21-000067:mdna:81]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000067:mdna:82]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-21-000067:mdna:83]
Debt Covenants

[0000889331-21-000067:mdna:84]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of September 25, 2021 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2021. As of September 25, 2021, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-21-000067:mdna:85]
[same as prior period, unchanged from 0000889331-21-000047:mdna:83]

[0000889331-21-000067:mdna:86]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The purchase price for Hartland was $112.3 million and the operations of Hartland Controls are included in the Industrial segment. The net cash payment of $109.9 million for this acquisition was funded by the Company's cash on hand.

[0000889331-21-000067:mdna:87]
[same as prior period, unchanged from 0000889331-21-000047:mdna:85]

[0000889331-21-000067:mdna:88]
During the third quarter of 2021 the Company paid quarterly dividends of $13.1 million to the shareholders. On October 26, 2021, the Board of Directors of the Company declared a quarterly cash dividend of $0.53 per share, payable on December 2nd, 2021 to stockholders of record as of November 18, 2021.

[0000889331-21-000067:mdna:89]
[same as prior period, unchanged from 0000889331-21-000047:mdna:87]

[0000889331-21-000067:mdna:90]
[same as prior period, unchanged from 0000889331-21-000047:mdna:88]

[0000889331-21-000067:mdna:91]
[same as prior period, unchanged from 0000889331-21-000047:mdna:89]

[0000889331-21-000067:mdna:92]
|  |  | First Nine Months |
| (in thousands) |  | 2021 |  | 2020 |
| Net cash provided by operating activities |  | $ | 240,664 |  |  | $ | 164,256 |  |
| Net cash used in investing activities |  | (165,611) |  |  | (41,388) |  |
| Net cash used in financing activities |  | (60,877) |  |  | (18,376) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (5,832) |  |  | 6,259 |  |
| Increase in cash, cash equivalents, and restricted cash |  | 8,344 |  |  | 110,751 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 687,525 |  |  | 531,139 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 695,869 |  |  | $ | 641,890 |  |

[0000889331-21-000067:mdna:93]
[same as prior period, unchanged from 0000889331-21-000047:mdna:91]

[0000889331-21-000067:mdna:94]
[same as prior period, unchanged from 0000889331-21-000047:mdna:92]

[0000889331-21-000067:mdna:95]
Net cash provided by operating activities was $240.7 million for the nine months ended September 25, 2021 as compared to $164.3 million for the nine months ended September 26, 2020. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth.

[0000889331-21-000067:mdna:96]
[same as prior period, unchanged from 0000889331-21-000047:mdna:94]

[0000889331-21-000067:mdna:97]
Net cash used in investing activities was $165.6 million for the nine months ended September 25, 2021 compared to $41.4 million during the nine months ended September 26, 2020. Net cash paid for acquisitions was $110.6 million for the nine months ended September 25, 2021. Capital expenditures were $57.5 million, representing an increase of $16.0 million compared to 2020. During the nine months ended September 25, 2021, the Company received proceeds of $2.6 million from the sale of a property within the Electronics segment.

[0000889331-21-000067:mdna:98]
[same as prior period, unchanged from 0000889331-21-000047:mdna:96]

[0000889331-21-000067:mdna:99]
Net cash used in financing activities was $60.9 million for the nine months ended September 25, 2021 compared to $18.4 million for the nine months ended September 26, 2020. The Company made payments of $30.0 million on the amended revolving credit facility during the nine months ended September 25, 2021. On April 3, 2020, the Company amended the Credit Agreement to eliminate the $200.0 million unsecured term loan credit facility, with the remaining outstanding balance of $140.0 million repaid in full on April 3, 2020 through a new borrowing of $140.0 million under the amended revolving credit facility. During the nine months ended September 26, 2020, the Company borrowed $100.0 million from its revolving credit

[0000889331-21-000067:mdna:100]
facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. The Company also made principal payments of $5.0 million on the term loan during the nine months ended September 26, 2020. For the nine months ended September 26, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million. Additionally, the Company paid dividends $36.6 million and $35.1 million in the nine months ended September 25, 2021 and September 26, 2020, respectively.

[0000889331-21-000067:mdna:101]
[same as prior period, unchanged from 0000889331-21-000047:mdna:98]

[0000889331-21-000067:mdna:102]
On April 26, 2019, the Company's Board of Directors authorized a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program"). On April 29, 2020, the Company announced that the Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. On April 28, 2021, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program.

[0000889331-21-000067:mdna:103]
The Company did not repurchase any shares of its common stock for the nine months ended September 25, 2021. During the nine months ended September 26, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.

[0000889331-21-000067:mdna:104]
[same as prior period, unchanged from 0000889331-21-000047:mdna:101]

[0000889331-21-000067:mdna:105]
As of September 25, 2021, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-21-000067:mdna:106]
[same as prior period, unchanged from 0000889331-21-000047:mdna:103]

[0000889331-21-000067:mdna:107]
[same as prior period, unchanged from 0000889331-21-000047:mdna:104]

[0000889331-21-000067:mdna:108]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 26, 2020. During the nine months ended September 25, 2021, there were no significant changes in the application of critical accounting policies.
