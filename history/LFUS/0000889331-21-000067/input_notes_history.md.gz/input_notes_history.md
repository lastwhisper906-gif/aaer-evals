# LFUS note change history — 0000889331-21-000047 → 0000889331-21-000067


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-10-27):
[0000889331-21-000067:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 25, 2021 and September 26, 2020:
  (was, 2021-07-28, similarity 0.9066):
[0000889331-21-000047:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 26, 2021 and June 27, 2020:

- added (2021-10-27):
[0000889331-21-000067:note_history:2]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  | — |  |  | — |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- added (2021-10-27):
[0000889331-21-000067:note_history:3]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- changed (2021-10-27):
[0000889331-21-000067:note_history:4]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at September 25, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2021-07-28, similarity 0.7591):
[0000889331-21-000047:note_history:4]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at June 26, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2021-10-27):
[0000889331-21-000067:note_history:5]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 690,682 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,483 |  |  | — |  |
| Restricted cash included in other assets |  | 1,704 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 695,869 |  |  | $ | 687,525 |  |
  (was, 2021-07-28, similarity 0.9504):
[0000889331-21-000047:note_history:5]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 616,330 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,790 |  |  | — |  |
| Restricted cash included in other assets |  | 1,734 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 621,854 |  |  | $ | 687,525 |  |

- changed (2021-10-27):
[0000889331-21-000067:note_history:6]
In December 2019, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update ("ASU") No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.
  (was, 2021-07-28, similarity 0.9989):
[0000889331-21-000047:note_history:6]
In December 2019, the Financial Accounting Standards Board (FASB) issued Accounting Standard Update ("ASU") No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.

- removed (2021-10-27):
[0000889331-21-000047:note_history:7]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  | — |  |  | — |  |  | 64,823 |  |  | 64,823 |  |  | — |  |  | — |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- removed (2021-10-27):
[0000889331-21-000047:note_history:8]
|  |  | Three Months Ended June 27, 2020 |  | Six Months Ended June 27, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-27):
[0000889331-21-000067:note_history:9]
The carrying amounts of debt at September 25, 2021 and December 26, 2020 are as follows:
  (was, 2021-07-28, similarity 0.9272):
[0000889331-21-000047:note_history:9]
The carrying amounts of debt at June 26, 2021 and December 26, 2020 are as follows:

- changed (2021-10-27):
[0000889331-21-000067:note_history:10]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 137,173 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,441) |  |  | (4,114) |  |
| Total debt |  | 647,731 |  |  | 687,034 |  |
| Less: Current maturities |  | (27,619) |  |  | — |  |
| Total long-term debt |  | $ | 620,112 |  |  | $ | 687,034 |  |
  (was, 2021-07-28, similarity 0.974):
[0000889331-21-000047:note_history:10]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 139,610 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,671) |  |  | (4,114) |  |
| Total debt |  | 651,917 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 626,917 |  |  | $ | 687,034 |  |

- changed (2021-10-27):
[0000889331-21-000067:note_history:11]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the nine months ended September 25, 2021. The balance under the facility was $100.0 million as of September 25, 2021.
  (was, 2021-07-28, similarity 0.9544):
[0000889331-21-000047:note_history:11]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the six months ended June 26, 2021. The balance under the facility was $100.0 million as of June 26, 2021.

- changed (2021-10-27):
[0000889331-21-000067:note_history:12]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.33% on September 25, 2021.
  (was, 2021-07-28, similarity 0.9822):
[0000889331-21-000047:note_history:12]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.59% at June 26, 2021.

- added (2021-10-27):
[0000889331-21-000067:note_history:13]
As of September 25, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of of September 25, 2021, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2021-10-27):
[0000889331-21-000067:note_history:14]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in
  (was, 2021-07-28, similarity 0.8596):
[0000889331-21-000047:note_history:14]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”)

- changed (2021-10-27):
[0000889331-21-000067:note_history:15]
aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.
  (was, 2021-07-28, similarity 0.7617):
[0000889331-21-000047:note_history:15]
(together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- changed (2021-10-27):
[0000889331-21-000067:note_history:16]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 25, 2021, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2021-07-28, similarity 0.9396):
[0000889331-21-000047:note_history:16]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 26, 2021, the Company was in compliance with all covenants under the Senior Notes.

- changed (2021-10-27):
[0000889331-21-000067:note_history:17]
Interest paid on all Company debt was $6.1 million and $6.4 million for the three months ended September 25, 2021 and September 26, 2020, respectively, and $14.8 million and $17.2 million for the nine months ended September 25, 2021 and September 26, 2020, respectively.
  (was, 2021-07-28, similarity 0.7297):
[0000889331-21-000047:note_history:17]
Interest paid on all Company debt was $2.5 million and $3.4 million for the three months ended June 26, 2021 and June 27, 2020, respectively, and $8.7 million and $10.8 million for the six months ended June 26, 2021 and June 27, 2020, respectively.

- removed (2021-10-27):
[0000889331-21-000047:note_history:18]
As of June 26, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At June 26, 2021, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2021-10-27):
[0000889331-21-000067:note_history:19]
The carrying amounts of debt at September 25, 2021 and December 26, 2020 are as follows:
  (was, 2021-07-28, similarity 0.9272):
[0000889331-21-000047:note_history:19]
The carrying amounts of debt at June 26, 2021 and December 26, 2020 are as follows:

- changed (2021-10-27):
[0000889331-21-000067:note_history:20]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 137,173 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,441) |  |  | (4,114) |  |
| Total debt |  | 647,731 |  |  | 687,034 |  |
| Less: Current maturities |  | (27,619) |  |  | — |  |
| Total long-term debt |  | $ | 620,112 |  |  | $ | 687,034 |  |
  (was, 2021-07-28, similarity 0.974):
[0000889331-21-000047:note_history:20]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 139,610 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,671) |  |  | (4,114) |  |
| Total debt |  | 651,917 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 626,917 |  |  | $ | 687,034 |  |

- changed (2021-10-27):
[0000889331-21-000067:note_history:21]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the nine months ended September 25, 2021. The balance under the facility was $100.0 million as of September 25, 2021.
  (was, 2021-07-28, similarity 0.9544):
[0000889331-21-000047:note_history:21]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the six months ended June 26, 2021. The balance under the facility was $100.0 million as of June 26, 2021.

- changed (2021-10-27):
[0000889331-21-000067:note_history:22]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.33% on September 25, 2021.
  (was, 2021-07-28, similarity 0.9822):
[0000889331-21-000047:note_history:22]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.59% at June 26, 2021.

- added (2021-10-27):
[0000889331-21-000067:note_history:23]
As of September 25, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of of September 25, 2021, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2021-10-27):
[0000889331-21-000067:note_history:24]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in
  (was, 2021-07-28, similarity 0.8596):
[0000889331-21-000047:note_history:24]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”)

- changed (2021-10-27):
[0000889331-21-000067:note_history:25]
aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.
  (was, 2021-07-28, similarity 0.7617):
[0000889331-21-000047:note_history:25]
(together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- changed (2021-10-27):
[0000889331-21-000067:note_history:26]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 25, 2021, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2021-07-28, similarity 0.9396):
[0000889331-21-000047:note_history:26]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 26, 2021, the Company was in compliance with all covenants under the Senior Notes.

- changed (2021-10-27):
[0000889331-21-000067:note_history:27]
Interest paid on all Company debt was $6.1 million and $6.4 million for the three months ended September 25, 2021 and September 26, 2020, respectively, and $14.8 million and $17.2 million for the nine months ended September 25, 2021 and September 26, 2020, respectively.
  (was, 2021-07-28, similarity 0.7297):
[0000889331-21-000047:note_history:27]
Interest paid on all Company debt was $2.5 million and $3.4 million for the three months ended June 26, 2021 and June 27, 2020, respectively, and $8.7 million and $10.8 million for the six months ended June 26, 2021 and June 27, 2020, respectively.

- removed (2021-10-27):
[0000889331-21-000047:note_history:28]
As of June 26, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At June 26, 2021, the Company was in compliance with all covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-27):
[0000889331-21-000067:note_history:29]
The carrying amounts of debt at September 25, 2021 and December 26, 2020 are as follows:
  (was, 2021-07-28, similarity 0.9272):
[0000889331-21-000047:note_history:29]
The carrying amounts of debt at June 26, 2021 and December 26, 2020 are as follows:

- changed (2021-10-27):
[0000889331-21-000067:note_history:30]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 137,173 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,441) |  |  | (4,114) |  |
| Total debt |  | 647,731 |  |  | 687,034 |  |
| Less: Current maturities |  | (27,619) |  |  | — |  |
| Total long-term debt |  | $ | 620,112 |  |  | $ | 687,034 |  |
  (was, 2021-07-28, similarity 0.974):
[0000889331-21-000047:note_history:30]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 139,610 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,671) |  |  | (4,114) |  |
| Total debt |  | 651,917 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 626,917 |  |  | $ | 687,034 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-10-27):
[0000889331-21-000067:note_history:31]
|  |  | For the Three Months Ended September 25, 2021 |  | For the Three Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | 0.1 |  | 3.1 |  |  | 0.8 |  | — |  | 2.4 |  |
|  |  | For the Nine Months Ended September 25, 2021 |  | For the Nine Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 1.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.6 |  | 0.3 |  | 8.9 |  |  | 1.8 |  | — |  | 5.8 |  |
|  |  | September 25, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 2.1 |  |  | 0.1 |  | — |  | 0.2 |  |
  (was, 2021-07-28, similarity 0.9304):
[0000889331-21-000047:note_history:31]
|  |  | For the Three Months Ended June 26, 2021 |  | For the Three Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.7 |  | 0.1 |  | 2.8 |  |  | 0.8 |  | — |  | 1.6 |  |
|  |  | For the Six Months Ended June 26, 2021 |  | For the Six Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | 0.2 |  | 5.8 |  |  | 1.0 |  | — |  | 3.4 |  |
|  |  | June 26, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 1.8 |  |  | 0.1 |  | — |  | 0.2 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-10-27):
[0000889331-21-000067:note_history:32]
|  |  | For the Three Months Ended September 25, 2021 |  | For the Three Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | 0.1 |  | 3.1 |  |  | 0.8 |  | — |  | 2.4 |  |
|  |  | For the Nine Months Ended September 25, 2021 |  | For the Nine Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 1.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.6 |  | 0.3 |  | 8.9 |  |  | 1.8 |  | — |  | 5.8 |  |
|  |  | September 25, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 2.1 |  |  | 0.1 |  | — |  | 0.2 |  |
  (was, 2021-07-28, similarity 0.9304):
[0000889331-21-000047:note_history:32]
|  |  | For the Three Months Ended June 26, 2021 |  | For the Three Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.7 |  | 0.1 |  | 2.8 |  |  | 0.8 |  | — |  | 1.6 |  |
|  |  | For the Six Months Ended June 26, 2021 |  | For the Six Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | 0.2 |  | 5.8 |  |  | 1.0 |  | — |  | 3.4 |  |
|  |  | June 26, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 1.8 |  |  | 0.1 |  | — |  | 0.2 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-10-27):
[0000889331-21-000067:note_history:33]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 25, 2021 and September 26, 2020:
  (was, 2021-07-28, similarity 0.9066):
[0000889331-21-000047:note_history:33]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 26, 2021 and June 27, 2020:

- added (2021-10-27):
[0000889331-21-000067:note_history:34]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  | — |  |  | — |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- added (2021-10-27):
[0000889331-21-000067:note_history:35]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- removed (2021-10-27):
[0000889331-21-000047:note_history:36]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  | — |  |  | — |  |  | 64,823 |  |  | 64,823 |  |  | — |  |  | — |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- removed (2021-10-27):
[0000889331-21-000047:note_history:37]
|  |  | Three Months Ended June 27, 2020 |  | Six Months Ended June 27, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- removed (2021-10-27):
[0000889331-21-000047:note_history:38]
Revenue Disaggregation

- removed (2021-10-27):
[0000889331-21-000047:note_history:39]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 26, 2021 and June 27, 2020:

- removed (2021-10-27):
[0000889331-21-000047:note_history:40]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  | — |  |  | — |  |  | 64,823 |  |  | 64,823 |  |  | — |  |  | — |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- removed (2021-10-27):
[0000889331-21-000047:note_history:41]
|  |  | Three Months Ended June 27, 2020 |  | Six Months Ended June 27, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

- removed (2021-10-27):
[0000889331-21-000047:note_history:42]
See Note 15, Segment Information for net sales by segment and countries.

- removed (2021-10-27):
[0000889331-21-000047:note_history:43]
Revenue Recognition


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-10-27):
[0000889331-21-000067:note_history:44]
Subsequent eventOn October 20, 2021, the Company announced that it had entered into a definitive agreement to acquire Carling Technologies, Inc. (“Carling”) for $315 million in cash, subject to a working capital adjustment. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle, marine and datacom/telecom infrastructure markets. The business is headquartered in Plainville, Connecticut, with offices and facilities located around the world and will be reported as part of the commercial vehicle business within our Automotive segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close in the fourth quarter of 2021.
