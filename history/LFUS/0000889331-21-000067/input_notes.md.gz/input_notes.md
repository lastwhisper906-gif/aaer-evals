# LFUS notes — 0000889331-21-000067


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-21-000067:notes:1]
[same as prior period, unchanged from 0000889331-21-000047:notes:1]

[0000889331-21-000067:notes:2]
[same as prior period, unchanged from 0000889331-21-000047:notes:2]

[0000889331-21-000067:notes:3]
[same as prior period, unchanged from 0000889331-21-000047:notes:3]

[0000889331-21-000067:notes:4]
[same as prior period, unchanged from 0000889331-21-000047:notes:4]

[0000889331-21-000067:notes:5]
[same as prior period, unchanged from 0000889331-21-000047:notes:5]

[0000889331-21-000067:notes:6]
[same as prior period, unchanged from 0000889331-21-000047:notes:6]

[0000889331-21-000067:notes:7]
[same as prior period, unchanged from 0000889331-21-000047:notes:7]

[0000889331-21-000067:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 25, 2021 and September 26, 2020:

[0000889331-21-000067:notes:9]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  | — |  |  | — |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

[0000889331-21-000067:notes:10]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

[0000889331-21-000067:notes:11]
[same as prior period, unchanged from 0000889331-21-000047:notes:11]

[0000889331-21-000067:notes:12]
[same as prior period, unchanged from 0000889331-21-000047:notes:12]

[0000889331-21-000067:notes:13]
[same as prior period, unchanged from 0000889331-21-000047:notes:13]

[0000889331-21-000067:notes:14]
[same as prior period, unchanged from 0000889331-21-000047:notes:14]

[0000889331-21-000067:notes:15]
[same as prior period, unchanged from 0000889331-21-000047:notes:15]

[0000889331-21-000067:notes:16]
[same as prior period, unchanged from 0000889331-21-000047:notes:16]

[0000889331-21-000067:notes:17]
[same as prior period, unchanged from 0000889331-21-000047:notes:17]

[0000889331-21-000067:notes:18]
[same as prior period, unchanged from 0000889331-21-000047:notes:18]

[0000889331-21-000067:notes:19]
[same as prior period, unchanged from 0000889331-21-000047:notes:19]

[0000889331-21-000067:notes:20]
[same as prior period, unchanged from 0000889331-21-000047:notes:20]

[0000889331-21-000067:notes:21]
[same as prior period, unchanged from 0000889331-21-000047:notes:21]

[0000889331-21-000067:notes:22]
[same as prior period, unchanged from 0000889331-21-000047:notes:22]

[0000889331-21-000067:notes:23]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at September 25, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-21-000067:notes:24]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 690,682 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,483 |  |  | — |  |
| Restricted cash included in other assets |  | 1,704 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 695,869 |  |  | $ | 687,525 |  |

[0000889331-21-000067:notes:25]
Recently Adopted Accounting Standards

[0000889331-21-000067:notes:26]
In December 2019, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update ("ASU") No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-21-000067:notes:27]
[same as prior period, unchanged from 0000889331-21-000047:notes:27]

[0000889331-21-000067:notes:28]
[same as prior period, unchanged from 0000889331-21-000047:notes:28]

[0000889331-21-000067:notes:29]
[same as prior period, unchanged from 0000889331-21-000047:notes:29]

[0000889331-21-000067:notes:30]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The purchase price for Hartland was $112.3 million and the operations of Hartland are included in the Industrial segment.

[0000889331-21-000067:notes:31]
The total purchase consideration of $109.9 million, net of cash, cash equivalents, and restricted cash has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase consideration is subject to change for the final working capital adjustments. As of September 25, 2021, the Company had restricted cash of $1.7 million in an escrow account for general indemnification purposes.

[0000889331-21-000067:notes:32]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Hartland acquisition:

[0000889331-21-000067:notes:33]
[same as prior period, unchanged from 0000889331-21-000047:notes:33]

[0000889331-21-000067:notes:34]
[same as prior period, unchanged from 0000889331-21-000047:notes:35]

[0000889331-21-000067:notes:35]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and nine months ended September 25, 2021 are net sales of $29.3 million and $72.3 million respectively, and an income (loss) before income taxes of $1.2 million and $(1.3) million, respectively since the January 28, 2021 acquisition of Hartland.

[0000889331-21-000067:notes:36]
The Company recorded a $6.8 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the first and second quarters of 2021, as the acquired inventory was sold, and is reflected as other non-segment costs. During the nine months ended September 25, 2021, the Company recognized a charge of $6.8 million for the amortization of this fair value inventory step-up.

[0000889331-21-000067:notes:37]
During the nine months ended September 25, 2021, the Company incurred approximately $0.8 million of legal and professional fees related to this acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-21-000067:notes:38]
[same as prior period, unchanged from 0000889331-21-000047:notes:39]

[0000889331-21-000067:notes:39]
[same as prior period, unchanged from 0000889331-21-000047:notes:40]

[0000889331-21-000067:notes:40]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands, except per share amounts) |  | September 25,2021 |  | September 26, 2020 |  | September 25,2021 |  | September 26, 2020 |
| Net sales |  | $ | 539,581 |  |  | $ | 414,100 |  |  | $ | 1,533,901 |  |  | $ | 1,101,430 |  |
| Income before income taxes |  | 113,591 |  |  | 69,478 |  |  | 289,530 |  |  | 90,516 |  |
| Net income |  | 92,054 |  |  | 56,961 |  |  | 238,197 |  |  | 69,526 |  |
| Net income per share — basic |  | 3.74 |  |  | 2.34 |  |  | 9.69 |  |  | 2.85 |  |
| Net income per share — diluted |  | 3.69 |  |  | 2.32 |  |  | 9.56 |  |  | 2.83 |  |

[0000889331-21-000067:notes:41]
[same as prior period, unchanged from 0000889331-21-000047:notes:42]

[0000889331-21-000067:notes:42]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 25,2021 |  | September 26, 2020 |  | September 25, 2021 |  | September 26, 2020 |
| Amortization(a) |  | $ | — |  |  | $ | (838) |  |  | $ | (280) |  |  | $ | (2,514) |  |
| Depreciation |  | — |  |  | 44 |  |  | 7 |  |  | 139 |  |
| Transaction costs(b) |  | — |  |  | — |  |  | 835 |  |  | (835) |  |
| Amortization of inventory step-up(c) |  | — |  |  | — |  |  | 6,808 |  |  | (6,796) |  |
| Income tax (expense) benefit of above items |  | — |  |  | 167 |  |  | (1,555) |  |  | 2,107 |  |

[0000889331-21-000067:notes:43]
(a)The amortization adjustment for the three and nine months ended September 26, 2020 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-21-000067:notes:44]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the  nine months ended September 25, 2021 and recognition of those fees during the nine months ended September 26, 2020.

[0000889331-21-000067:notes:45]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the nine months ended September 25, 2021 and the recognition of the amortization during the nine months ended September 26, 2020. The inventory step-up was amortized over four months as the inventory was sold.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-21-000067:notes:46]
[same as prior period, unchanged from 0000889331-21-000047:notes:47]

[0000889331-21-000067:notes:47]
The components of inventories at September 25, 2021 and December 26, 2020 are as follows:

[0000889331-21-000067:notes:48]
| (in thousands) |  | September 25, 2021 |  | December 26, 2020 |
| Raw materials |  | $ | 121,282 |  |  | $ | 85,394 |  |
| Work in process |  | 109,347 |  |  | 92,783 |  |
| Finished goods |  | 161,567 |  |  | 114,641 |  |
| Inventory Reserves |  | (35,172) |  |  | (34,816) |  |
| Total |  | $ | 357,024 |  |  | $ | 258,002 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-21-000067:notes:49]
Property, Plant, and Equipment

[0000889331-21-000067:notes:50]
The components of net property, plant, and equipment at September 25, 2021 and December 26, 2020 are as follows:

[0000889331-21-000067:notes:51]
| (in thousands) |  | September 25, 2021 |  | December 26, 2020 |
| Land |  | $ | 22,887 |  |  | $ | 22,851 |  |
| Building |  | 129,135 |  |  | 123,497 |  |
| Equipment |  | 725,971 |  |  | 678,220 |  |
| Accumulated depreciation and amortization |  | (513,664) |  |  | (480,390) |  |
| Total |  | $ | 364,329 |  |  | $ | 344,178 |  |

[0000889331-21-000067:notes:52]
The Company recorded depreciation expense of $14.2 million for both the three months ended September 25, 2021 and September 26, 2020, and $41.4 million and $42.0 million for the nine months ended September 25, 2021 and September 26, 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-21-000067:notes:53]
[same as prior period, unchanged from 0000889331-21-000047:notes:53]

[0000889331-21-000067:notes:54]
The amounts for goodwill and changes in the carrying value by segment for the nine months ended September 25, 2021 are as follows:

[0000889331-21-000067:notes:55]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net book value of goodwill as of December 26, 2020 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 26, 2020 |  | $ | 676,325 |  |  | $ | 138,354 |  |  | $ | 47,551 |  |  | $ | 862,230 |  |
| Accumulated impairment losses as of December 26, 2020 |  | — |  |  | (36,423) |  |  | (8,995) |  |  | (45,418) |  |
| Total |  | 676,325 |  |  | 101,931 |  |  | 38,556 |  |  | 816,812 |  |
| Changes during 2021: |  |  |  |  |  |  |  |  |
| Additions(a) |  | — |  |  | 1,614 |  |  | 40,442 |  |  | 42,056 |  |
| Currency translation |  | (9,530) |  |  | (2,165) |  |  | 32 |  |  | (11,663) |  |
| Net book value of goodwill as of September 25, 2021 |  |  |  |  |  |  |  |  |
| Gross goodwill as of September 25, 2021 |  | 666,795 |  |  | 137,783 |  |  | 88,133 |  |  | 892,711 |  |
| Accumulated impairment losses as of September 25, 2021 |  | — |  |  | (36,403) |  |  | (9,103) |  |  | (45,506) |  |
| Total |  | $ | 666,795 |  |  | $ | 101,380 |  |  | $ | 79,030 |  |  | $ | 847,205 |  |

[0000889331-21-000067:notes:56]
(a) The additions primarily resulted from the acquisition of Hartland.

[0000889331-21-000067:notes:57]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of September 25, 2021, the automotive sensors reporting unit had $9.5 million of remaining goodwill.

[0000889331-21-000067:notes:58]
The components of other intangible assets as of September 25, 2021 and December 26, 2020 are as follows:

[0000889331-21-000067:notes:59]
|  |  |  | As of September 25, 2021 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 10,354 |  |  | $ | 2,230 |  |  | $ | 8,124 |  |
| Patents, licenses and software |  |  | 142,606 |  |  | 99,834 |  |  | 42,772 |  |
| Distribution network |  |  | 43,601 |  |  | 40,306 |  |  | 3,295 |  |
| Customer relationships, trademarks, and tradenames |  |  | 399,655 |  |  | 158,080 |  |  | 241,575 |  |
| Total |  |  | $ | 596,216 |  |  | $ | 300,450 |  |  | $ | 295,766 |  |

[0000889331-21-000067:notes:60]
[same as prior period, unchanged from 0000889331-21-000047:notes:60]

[0000889331-21-000067:notes:61]
During the three months ended September 25, 2021 and September 26, 2020, the Company recorded amortization expense of $10.4 million and $10.1 million, respectively. During the nine months ended September 25, 2021 and September 26, 2020, the Company recorded amortization expense of $31.6 million and $29.9 million, respectively.

[0000889331-21-000067:notes:62]
[same as prior period, unchanged from 0000889331-21-000047:notes:62]

[0000889331-21-000067:notes:63]
During the nine months ended September 25, 2021, the Company recorded additions to intangible assets of $39.7 million, related to the Hartland acquisition, the components of which were as follows:

[0000889331-21-000067:notes:64]
[same as prior period, unchanged from 0000889331-21-000047:notes:64]

[0000889331-21-000067:notes:65]
Estimated annual amortization expense related to intangible assets with definite lives as of September 25, 2021 is as follows:

[0000889331-21-000067:notes:66]
| (in thousands) | Amount |
| 2021 | $ | 41,922 |  |
| 2022 | 40,761 |  |
| 2023 | 36,461 |  |
| 2024 | 33,038 |  |
| 2025 | 33,019 |  |
| 2026 and thereafter | 142,173 |  |
| Total | $ | 327,374 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-21-000067:notes:67]
[same as prior period, unchanged from 0000889331-21-000047:notes:67]

[0000889331-21-000067:notes:68]
The components of accrued liabilities as of September 25, 2021 and December 26, 2020 are as follows:

[0000889331-21-000067:notes:69]
| (in thousands) |  | September 25, 2021 |  | December 26, 2020 |
| Employee-related liabilities |  | $ | 80,034 |  |  | $ | 50,689 |  |
| Operating lease liability |  | 8,649 |  |  | 6,811 |  |
| Other non-income taxes |  | 5,352 |  |  | 2,126 |  |
| Professional services |  | 3,375 |  |  | 3,321 |  |
| Restructuring liability |  | 3,075 |  |  | 4,195 |  |
| Interest |  | 2,598 |  |  | 4,517 |  |
| Deferred revenue |  | 867 |  |  | 2,959 |  |
| Customer liability |  | 740 |  |  | 3,858 |  |
| Other |  | 34,980 |  |  | 32,002 |  |
| Total |  | $ | 139,670 |  |  | $ | 110,478 |  |

[0000889331-21-000067:notes:70]
[same as prior period, unchanged from 0000889331-21-000047:notes:70]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-21-000067:notes:71]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment and other charges for the three and nine months ended September 25, 2021 and September 26, 2020 as follows:

[0000889331-21-000067:notes:72]
|  | Three months ended September 25, 2021 |  | Nine months ended September 25, 2021 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 542 |  |  | $ | — |  |  | $ | 133 |  |  | $ | 675 |  |  | $ | 1,094 |  |  | $ | 416 |  |  | $ | 302 |  |  | $ | 1,812 |  |
| Other restructuring charges | — |  |  | 97 |  |  | — |  |  | 97 |  |  | — |  |  | 186 |  |  | — |  |  | 186 |  |
| Total restructuring charges | 542 |  |  | 97 |  |  | 133 |  |  | 772 |  |  | 1,094 |  |  | 602 |  |  | 302 |  |  | 1,998 |  |
| Total | $ | 542 |  |  | $ | 97 |  |  | $ | 133 |  |  | $ | 772 |  |  | $ | 1,094 |  |  | $ | 602 |  |  | $ | 302 |  |  | $ | 1,998 |  |

[0000889331-21-000067:notes:73]
|  | Three months ended September 26, 2020 |  | Nine months ended September 26, 2020 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 388 |  |  | $ | 162 |  |  | $ | 648 |  |  | $ | 1,198 |  |  | $ | 2,125 |  |  | $ | 770 |  |  | $ | 1,719 |  |  | $ | 4,614 |  |
| Other restructuring charges | — |  |  | — |  |  | 79 |  |  | 79 |  |  | — |  |  | 108 |  |  | 104 |  |  | 212 |  |
| Total restructuring charges | 388 |  |  | 162 |  |  | 727 |  |  | 1,277 |  |  | 2,125 |  |  | 878 |  |  | 1,823 |  |  | 4,826 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33,841 |  |  | 2,237 |  |  | 36,078 |  |
| Total | $ | 388 |  |  | $ | 162 |  |  | $ | 727 |  |  | $ | 1,277 |  |  | $ | 2,125 |  |  | $ | 34,719 |  |  | $ | 4,060 |  |  | $ | 40,904 |  |

[0000889331-21-000067:notes:74]
[same as prior period, unchanged from 0000889331-21-000047:notes:74]

[0000889331-21-000067:notes:75]
For the three and nine months ended September 25, 2021, the Company recorded total restructuring charges of $0.8 million and $2.0 million, primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Electronics and Automotive segments.

[0000889331-21-000067:notes:76]
[same as prior period, unchanged from 0000889331-21-000047:notes:76]

[0000889331-21-000067:notes:77]
For the three and nine months ended September 26, 2020, the Company recorded total restructuring charges of $1.3 million and $4.8 million, respectively, for employee termination costs and other restructuring charges. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $36.1 million of impairment charges for the nine months ended September 26, 2020, respectively, which included a $33.8 million goodwill impairment charge associated with the automotive sensors reporting unit within the Automotive segment in the second quarter of 2020 and $2.2 million related to the land and building associated with the Company’s previously announced consolidation of a manufacturing facility within the Industrial segment in the first quarter of 2020. The impairment charges of the land and building were included in selling, general, and administrative expenses. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the goodwill impairment charge.

[0000889331-21-000067:notes:78]
The restructuring liability as of September 25, 2021 and December 26, 2020 is $3.1 million and $4.2 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by the third quarter of 2022.


## us-gaap:DebtDisclosureTextBlock

[0000889331-21-000067:notes:79]
Debt

[0000889331-21-000067:notes:80]
The carrying amounts of debt at September 25, 2021 and December 26, 2020 are as follows:

[0000889331-21-000067:notes:81]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 137,173 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,441) |  |  | (4,114) |  |
| Total debt |  | 647,731 |  |  | 687,034 |  |
| Less: Current maturities |  | (27,619) |  |  | — |  |
| Total long-term debt |  | $ | 620,112 |  |  | $ | 687,034 |  |

[0000889331-21-000067:notes:82]
Revolving Credit Facility

[0000889331-21-000067:notes:83]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the nine months ended September 25, 2021. The balance under the facility was $100.0 million as of September 25, 2021.

[0000889331-21-000067:notes:84]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.33% on September 25, 2021.

[0000889331-21-000067:notes:85]
As of September 25, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of of September 25, 2021, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-21-000067:notes:86]
Senior Notes

[0000889331-21-000067:notes:87]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-21-000067:notes:88]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in

[0000889331-21-000067:notes:89]
aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000067:notes:90]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-21-000067:notes:91]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-21-000067:notes:92]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 25, 2021, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-21-000067:notes:93]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-21-000067:notes:94]
Interest paid on all Company debt was $6.1 million and $6.4 million for the three months ended September 25, 2021 and September 26, 2020, respectively, and $14.8 million and $17.2 million for the nine months ended September 25, 2021 and September 26, 2020, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-21-000067:notes:95]
[same as prior period, unchanged from 0000889331-21-000047:notes:95]

[0000889331-21-000067:notes:96]
[same as prior period, unchanged from 0000889331-21-000047:notes:96]

[0000889331-21-000067:notes:97]
[same as prior period, unchanged from 0000889331-21-000047:notes:97]

[0000889331-21-000067:notes:98]
[same as prior period, unchanged from 0000889331-21-000047:notes:98]

[0000889331-21-000067:notes:99]
[same as prior period, unchanged from 0000889331-21-000047:notes:99]

[0000889331-21-000067:notes:100]
[same as prior period, unchanged from 0000889331-21-000047:notes:100]

[0000889331-21-000067:notes:101]
[same as prior period, unchanged from 0000889331-21-000047:notes:101]

[0000889331-21-000067:notes:102]
[same as prior period, unchanged from 0000889331-21-000047:notes:102]

[0000889331-21-000067:notes:103]
[same as prior period, unchanged from 0000889331-21-000047:notes:103]

[0000889331-21-000067:notes:104]
[same as prior period, unchanged from 0000889331-21-000047:notes:104]

[0000889331-21-000067:notes:105]
[same as prior period, unchanged from 0000889331-21-000047:notes:105]

[0000889331-21-000067:notes:106]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the nine months ended September 25, 2021, the Company impaired the remaining book value of these investments and recorded an impairment charge of $0.5 million and during the three and nine months ended September 26, 2020, the Company recorded impairment charges of $0.1 million in Other income, net in the Condensed Consolidated Statements of Net Income. As of December 26, 2020, the balance of these investments was $0.5 million. The fair value of these investments is measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy.

[0000889331-21-000067:notes:107]
[same as prior period, unchanged from 0000889331-21-000047:notes:107]

[0000889331-21-000067:notes:108]
[same as prior period, unchanged from 0000889331-21-000047:notes:108]

[0000889331-21-000067:notes:109]
There were no changes during the quarter ended September 25, 2021 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 25, 2021 and December 26, 2020, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-21-000067:notes:110]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 25, 2021:

[0000889331-21-000067:notes:111]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 15,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,970 |  |
| Investments in equity securities |  | 27,358 |  |  | — |  |  | — |  |  | 27,358 |  |
| Mutual funds |  | 14,711 |  |  | — |  |  | — |  |  | 14,711 |  |
| Total |  | $ | 58,039 |  |  | $ | — |  |  | $ | — |  |  | $ | 58,039 |  |

[0000889331-21-000067:notes:112]
[same as prior period, unchanged from 0000889331-21-000047:notes:112]

[0000889331-21-000067:notes:113]
[same as prior period, unchanged from 0000889331-21-000047:notes:113]

[0000889331-21-000067:notes:114]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving credit facilities’ fair values approximate book value at September 25, 2021 and December 26, 2020, as the rates on these borrowings are variable in nature.

[0000889331-21-000067:notes:115]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of September 25, 2021 and December 26, 2020 were as follows:

[0000889331-21-000067:notes:116]
|  |  | September 25, 2021 |  | December 26, 2020 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 137,173 |  |  | $ | 138,825 |  |  | $ | 142,679 |  |  | $ | 144,323 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 116,425 |  |  | 115,850 |  |  | 123,588 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,167 |  |  | 25,000 |  |  | 25,437 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 106,585 |  |  | 100,000 |  |  | 109,552 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 52,567 |  |  | 50,000 |  |  | 53,474 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 133,376 |  |  | 125,000 |  |  | 138,036 |  |

[0000889331-21-000067:notes:117]
[same as prior period, unchanged from 0000889331-21-000047:notes:117]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-21-000067:notes:118]
[same as prior period, unchanged from 0000889331-21-000047:notes:118]

[0000889331-21-000067:notes:119]
[same as prior period, unchanged from 0000889331-21-000047:notes:119]

[0000889331-21-000067:notes:120]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended September 25, 2021 and September 26, 2020 were as follows:

[0000889331-21-000067:notes:121]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 25, 2021 |  | September 26, 2020 |  | September 25, 2021 |  | September 26, 2020 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 684 |  |  | $ | 615 |  |  | $ | 2,086 |  |  | $ | 1,825 |  |
| Interest cost |  | 434 |  |  | 511 |  |  | 1,317 |  |  | 1,655 |  |
| Expected return on plan assets |  | (361) |  |  | (422) |  |  | (1,099) |  |  | (1,551) |  |
| Amortization of prior service and net actuarial loss |  | 327 |  |  | 279 |  |  | 992 |  |  | 688 |  |
| Net periodic benefit cost |  | $ | 1,084 |  |  | $ | 983 |  |  | $ | 3,296 |  |  | $ | 2,617 |  |

[0000889331-21-000067:notes:122]
[same as prior period, unchanged from 0000889331-21-000047:notes:122]

[0000889331-21-000067:notes:123]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.6 million and $0.5 million for the three months ended September 25, 2021 and September 26, 2020, respectively, and $1.6 million and $1.5 million expense for the nine months ended September 25, 2021 and September 26, 2020, respectively, in Cost of Sales and Other income, net within the Condensed Consolidated Statements of Net Income. For the three and nine months ended September 25, 2021, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.2 million and $0.5 million, respectively. For the three and nine months ended September 26, 2020, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.2 million and $0.5 million, respectively.
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to directly pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $55 million, representing approximately 37% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge currently estimated between $18 million and $22 million in the fourth quarter of 2021, reflecting the accelerated recognition of unamortized actuarial losses in the plan. The actual amount and timing of the settlement charge could differ from this estimate due to final data and plan wind-up expenses. Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million (£10.9 million) to both the net pension liability and unamortized actuarial loss within other comprehensive income (loss) during the second quarter of 2020. Additionally, the Company made a cash contribution of $10.4 million (£8.4 million) under this agreement during the second quarter of 2020.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-21-000067:notes:124]
Other Comprehensive (Loss) Income
Changes in other comprehensive income (loss) by component were as follows:

[0000889331-21-000067:notes:125]
| (in thousands) |  | Three Months EndedSeptember 25, 2021 |  | Three Months EndedSeptember 26, 2020 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 601 |  |  | $ | 114 |  |  | $ | 487 |  |  | $ | 273 |  |  | $ | (290) |  |  | $ | 563 |  |
| Foreign currency translation adjustments |  | (5,441) |  |  | — |  |  | (5,441) |  |  | 16,418 |  |  | — |  |  | 16,418 |  |
| Total change in other comprehensive (loss) income |  | $ | (4,840) |  |  | $ | 114 |  |  | $ | (4,954) |  |  | $ | 16,691 |  |  | $ | (290) |  |  | $ | 16,981 |  |
| (in thousands) |  | Nine Months EndedSeptember 25, 2021 |  | Nine Months EndedSeptember 26, 2020 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 1,479 |  |  | $ | 209 |  |  | $ | 1,270 |  |  | (12,270) |  |  | (2,555) |  |  | $ | (9,715) |  |
| Foreign currency translation adjustments |  | (5,641) |  |  | — |  |  | (5,641) |  |  | $ | 9,300 |  |  | $ | — |  |  | $ | 9,300 |  |
| Total change in other comprehensive (loss) income |  | $ | (4,162) |  |  | $ | 209 |  |  | $ | (4,371) |  |  | $ | (2,970) |  |  | $ | (2,555) |  |  | $ | (415) |  |

[0000889331-21-000067:notes:126]
Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million to unamortized actuarial loss within other comprehensive income (loss). See Note 10, Benefit Plans for further discussion.

[0000889331-21-000067:notes:127]
The following tables set forth the changes in accumulated other comprehensive (loss) by component for the nine months ended September 25, 2021 and September 26, 2020:

[0000889331-21-000067:notes:128]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive (loss) |
| Balance at December 26, 2020 |  | $ | (34,141) |  |  |  |  | $ | (57,016) |  |  | $ | (91,157) |  |
| Activity in the period |  | 1,270 |  |  |  |  | (5,641) |  |  | (4,371) |  |
| Balance at September 25, 2021 |  | $ | (32,871) |  |  |  |  | $ | (62,657) |  |  | $ | (95,528) |  |

[0000889331-21-000067:notes:129]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currency translation adjustment |  | Accumulated other comprehensive (loss) |
| Balance at December 28, 2019 |  | $ | (18,046) |  |  |  |  | $ | (88,777) |  |  | $ | (106,823) |  |
| Activity in the period |  | (9,715) |  |  |  |  | 9,300 |  |  | (415) |  |
| Balance at September 26, 2020 |  | $ | (27,761) |  |  |  |  | $ | (79,477) |  |  | $ | (107,238) |  |

[0000889331-21-000067:notes:130]
Amounts reclassified from accumulated other comprehensive (loss) to earnings for the three and nine months ended September 25, 2021 and September 26, 2020 were as follows:

[0000889331-21-000067:notes:131]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 25, 2021 |  | September 26, 2020 |  | September 25, 2021 |  | September 26, 2020 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 501 |  |  | $ | 452 |  |  | $ | 1,514 |  |  | $ | 1,226 |  |

[0000889331-21-000067:notes:132]
The Company recognizes the amortization of prior service costs in Other income, net within the Condensed Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-21-000067:notes:133]
Income Taxes
The effective tax rate for the three and nine months ended September 25, 2021 was 19.0% and 17.6%, respectively, compared to the effective tax rate for the three and nine months ended September 26, 2020 of 17.9% and 23.1%, respectively. The effective tax rate for the third quarter of 2021 is higher than the effective tax rate for the comparable 2020 period, primarily due to a reduction during the third quarter of 2020 in the estimated 2020 annual effective tax rate, the impact of which was recorded during the third quarter of  2020.

[0000889331-21-000067:notes:134]
The effective tax rate for the first nine months of 2021 is lower than the effective tax rate for the comparable 2020 period, primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 as compared to 2020, as well as the impact of the goodwill impairment charge of $33.8 million recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit in the annual estimated effective tax rate. The effective tax rate for the 2021 period is lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-21-000067:notes:135]
Earnings Per Share

[0000889331-21-000067:notes:136]
[same as prior period, unchanged from 0000889331-21-000047:notes:137]

[0000889331-21-000067:notes:137]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 25, 2021 |  | September 26, 2020 |  | September 25, 2021 |  | September 26, 2020 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 92,054 |  |  | $ | 55,356 |  |  | $ | 231,862 |  |  | $ | 71,009 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,622 |  |  | 24,357 |  |  | 24,582 |  |  | 24,354 |  |
| Effect of dilutive securities |  | 304 |  |  | 216 |  |  | 322 |  |  | 181 |  |
| Diluted |  | 24,926 |  |  | 24,573 |  |  | 24,904 |  |  | 24,535 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 3.74 |  |  | $ | 2.27 |  |  | $ | 9.43 |  |  | $ | 2.92 |  |
| Diluted earnings per share |  | $ | 3.69 |  |  | $ | 2.25 |  |  | $ | 9.31 |  |  | $ | 2.89 |  |

[0000889331-21-000067:notes:138]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 57,936 and 290,262 for the three months ended September 25, 2021 and September 26, 2020, respectively, and 32,773 and 194,857 for the nine months ended September 25, 2021 and September 26, 2020, respectively.

[0000889331-21-000067:notes:139]
[same as prior period, unchanged from 0000889331-21-000047:notes:140]

[0000889331-21-000067:notes:140]
On April 26, 2019, the Company's Board of Directors authorized a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program"). On April 29, 2020, the Company announced that the Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. On April 28, 2021, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program. 
The Company did not repurchase any shares of its common stock for the three and nine months ended September 25, 2021. During the nine months ended September 26, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-21-000067:notes:141]
Related Party Transactions

[0000889331-21-000067:notes:142]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-21-000067:notes:143]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-21-000067:notes:144]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-21-000067:notes:145]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-21-000067:notes:146]
|  |  | For the Three Months Ended September 25, 2021 |  | For the Three Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | 0.1 |  | 3.1 |  |  | 0.8 |  | — |  | 2.4 |  |
|  |  | For the Nine Months Ended September 25, 2021 |  | For the Nine Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 1.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.6 |  | 0.3 |  | 8.9 |  |  | 1.8 |  | — |  | 5.8 |  |
|  |  | September 25, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 2.1 |  |  | 0.1 |  | — |  | 0.2 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-21-000067:notes:147]
[same as prior period, unchanged from 0000889331-21-000047:notes:148]

[0000889331-21-000067:notes:148]
The Company and its subsidiaries design, manufacture and sell components and modules empowering a sustainable, connected, and safer world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-21-000067:notes:149]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments' current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-21-000067:notes:150]
[same as prior period, unchanged from 0000889331-21-000047:notes:151]

[0000889331-21-000067:notes:151]
•Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle end markets. Passenger car fuse products for internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules used in applications serving a number of end markets, including heavy truck, construction, agriculture and material handling. Automotive sensor products include a wide range of

[0000889331-21-000067:notes:152]
automotive and commercial vehicle products designed to monitor the passenger compartment occupant's safety and environment as well as the vehicle’s powertrain.

[0000889331-21-000067:notes:153]
•Industrial Segment: Consists of industrial circuit protection products (i.e. fuses, power distribution modules, switches) and industrial control products (i.e. relays, transformers, contactors, sensors). These products are used in a variety of applications and end-markets including: renewable energy, energy storage, HVAC, electric vehicle infrastructure, industrial equipment, industrial automation, construction, mining, and oil & gas.

[0000889331-21-000067:notes:154]
[same as prior period, unchanged from 0000889331-21-000047:notes:155]

[0000889331-21-000067:notes:155]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 25, 2021 |  | September 26, 2020 |  | September 25, 2021 |  | September 26, 2020 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 347,240 |  |  | $ | 255,349 |  |  | $ | 959,122 |  |  | $ | 692,809 |  |
| Automotive |  | 124,415 |  |  | 104,724 |  |  | 386,262 |  |  | 271,493 |  |
| Industrial |  | 67,926 |  |  | 31,493 |  |  | 181,479 |  |  | 80,697 |  |
| Total net sales |  | $ | 539,581 |  |  | $ | 391,566 |  |  | $ | 1,526,863 |  |  | $ | 1,044,999 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,503 |  |  | $ | 15,819 |  |  | $ | 45,998 |  |  | 46,967 |  |
| Automotive |  | 7,075 |  |  | 7,370 |  |  | 21,094 |  |  | 21,628 |  |
| Industrial |  | 2,058 |  |  | 1,140 |  |  | 5,957 |  |  | 3,270 |  |
| Total depreciation and amortization |  | $ | 24,636 |  |  | $ | 24,329 |  |  | $ | 73,049 |  |  | $ | 71,865 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 100,524 |  |  | $ | 45,860 |  |  | $ | 230,283 |  |  | $ | 110,783 |  |
| Automotive |  | 15,806 |  |  | 15,383 |  |  | 55,380 |  |  | 20,642 |  |
| Industrial |  | 6,571 |  |  | 4,898 |  |  | 18,452 |  |  | 8,409 |  |
| Other(a) |  | (2,794) |  |  | (1,583) |  |  | (11,270) |  |  | (42,476) |  |
| Total operating income |  | 120,107 |  |  | 64,558 |  |  | 292,845 |  |  | 97,358 |  |
| Interest expense |  | 4,602 |  |  | 4,988 |  |  | 13,901 |  |  | 16,261 |  |
| Foreign exchange loss (gain) |  | 3,154 |  |  | (6,174) |  |  | 8,315 |  |  | (9,600) |  |
| Other income, net |  | (1,240) |  |  | (1,682) |  |  | (10,867) |  |  | (1,643) |  |
| Income before income taxes |  | $ | 113,591 |  |  | $ | 67,426 |  |  | $ | 281,496 |  |  | $ | 92,340 |  |

[0000889331-21-000067:notes:156]
(a) Included in “Other” Operating income for the third quarter of 2021 was $6.8 million year-to-date of purchase accounting inventory step-up charges, $2.0 million ($3.4 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.8 million ($2.0 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a year-to-date gain of $0.9 million recorded for the sale of a building within the Electronics segment.

[0000889331-21-000067:notes:157]
Included in “Other” Operating income for the 2020 third quarter was $0.3 million ($1.6 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there was $1.3 million ($40.9 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs of $1.2 million ($4.6 million year-to-date), and other restructuring charges of $0.1 million ($0.2 million year-to-date), the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, impairment charges of $2.2 million recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment. See Note 5, Goodwill and Other Intangible Assets and Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-21-000067:notes:158]
[same as prior period, unchanged from 0000889331-21-000047:notes:159]

[0000889331-21-000067:notes:159]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 25, 2021 |  | September 26, 2020 |  | September 25, 2021 |  | September 26, 2020 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,995 |  |  | $ | 106,121 |  |  | $ | 458,723 |  |  | $ | 285,901 |  |
| China |  | 160,628 |  |  | 126,506 |  |  | 455,872 |  |  | 314,547 |  |
| Other countries(a) |  | 205,958 |  |  | 158,939 |  |  | 612,268 |  |  | 444,551 |  |
| Total net sales |  | $ | 539,581 |  |  | $ | 391,566 |  |  | $ | 1,526,863 |  |  | $ | 1,044,999 |  |

[0000889331-21-000067:notes:160]
[same as prior period, unchanged from 0000889331-21-000047:notes:161]

[0000889331-21-000067:notes:161]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 47,533 |  |  | $ | 46,132 |  |
| China |  | 90,984 |  |  | 85,876 |  |
| Mexico |  | 82,882 |  |  | 70,125 |  |
| Germany |  | 40,115 |  |  | 37,976 |  |
| Philippines |  | 68,594 |  |  | 66,994 |  |
| Other countries(a) |  | 34,221 |  |  | 37,075 |  |
| Total long-lived assets |  | $ | 364,329 |  |  | $ | 344,178 |  |

[0000889331-21-000067:notes:162]
[same as prior period, unchanged from 0000889331-21-000047:notes:163]

[0000889331-21-000067:notes:163]
|  |  | Nine Months Ended |
| (in thousands) |  | September 25, 2021 |  | September 26, 2020 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 3,696 |  |  | $ | 2,712 |  |
| China |  | 13,790 |  |  | 6,414 |  |
| Mexico |  | 22,518 |  |  | 7,291 |  |
| Germany |  | 6,994 |  |  | 3,793 |  |
| Philippines |  | 10,109 |  |  | 15,331 |  |
| Other countries(a) |  | 3,527 |  |  | 1,152 |  |
| Total additions to long-lived assets |  | $ | 60,634 |  |  | $ | 36,693 |  |

[0000889331-21-000067:notes:164]
[same as prior period, unchanged from 0000889331-21-000047:notes:165]


## us-gaap:SubsequentEventsTextBlock

[0000889331-21-000067:notes:165]
Subsequent eventOn October 20, 2021, the Company announced that it had entered into a definitive agreement to acquire Carling Technologies, Inc. (“Carling”) for $315 million in cash, subject to a working capital adjustment. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle, marine and datacom/telecom infrastructure markets. The business is headquartered in Plainville, Connecticut, with offices and facilities located around the world and will be reported as part of the commercial vehicle business within our Automotive segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close in the fourth quarter of 2021.
