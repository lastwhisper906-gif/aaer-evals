# LFUS notes — 0000889331-25-000099


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-25-000099:notes:1]
[same as prior period, unchanged from 0000889331-24-000191:notes:1]

[0000889331-25-000099:notes:2]
[same as prior period, unchanged from 0000889331-24-000191:notes:2]

[0000889331-25-000099:notes:3]
[same as prior period, unchanged from 0000889331-24-000191:notes:3]

[0000889331-25-000099:notes:4]
[same as prior period, unchanged from 0000889331-24-000191:notes:4]

[0000889331-25-000099:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2024, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-25-000099:notes:6]
[same as prior period, unchanged from 0000889331-24-000191:notes:6]

[0000889331-25-000099:notes:7]
[same as prior period, unchanged from 0000889331-24-000191:notes:7]

[0000889331-25-000099:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 29, 2025 and March 30, 2024:

[0000889331-25-000099:notes:9]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |

[0000889331-25-000099:notes:10]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |

[0000889331-25-000099:notes:11]
[same as prior period, unchanged from 0000889331-24-000191:notes:11]

[0000889331-25-000099:notes:12]
[same as prior period, unchanged from 0000889331-24-000191:notes:12]

[0000889331-25-000099:notes:13]
[same as prior period, unchanged from 0000889331-24-000191:notes:13]

[0000889331-25-000099:notes:14]
[same as prior period, unchanged from 0000889331-24-000191:notes:14]

[0000889331-25-000099:notes:15]
[same as prior period, unchanged from 0000889331-24-000191:notes:15]

[0000889331-25-000099:notes:16]
[same as prior period, unchanged from 0000889331-24-000191:notes:16]

[0000889331-25-000099:notes:17]
[same as prior period, unchanged from 0000889331-24-000191:notes:17]

[0000889331-25-000099:notes:18]
[same as prior period, unchanged from 0000889331-24-000191:notes:18]

[0000889331-25-000099:notes:19]
[same as prior period, unchanged from 0000889331-24-000191:notes:19]

[0000889331-25-000099:notes:20]
[same as prior period, unchanged from 0000889331-24-000191:notes:20]

[0000889331-25-000099:notes:21]
[same as prior period, unchanged from 0000889331-24-000191:notes:21]

[0000889331-25-000099:notes:22]
[same as prior period, unchanged from 0000889331-24-000191:notes:22]

[0000889331-25-000099:notes:23]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 29, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-25-000099:notes:24]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 618,687 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,569 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 620,256 |  |  | $ | 726,437 |  |

[0000889331-25-000099:notes:25]
Recently Issued Accounting Standards

[0000889331-25-000099:notes:26]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements; (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively; (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.

[0000889331-25-000099:notes:27]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify disclosures in the Company's Consolidated Financial Statements.

[0000889331-25-000099:notes:28]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000889331-25-000099:notes:29]
[same as prior period, unchanged from 0000889331-24-000191:notes:32]

[0000889331-25-000099:notes:30]
[same as prior period, unchanged from 0000889331-24-000191:notes:33]

[0000889331-25-000099:notes:31]
[same as prior period, unchanged from 0000889331-24-000191:notes:34]

[0000889331-25-000099:notes:32]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab is approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-25-000099:notes:33]
The acquisition was funded with cash on hand. The total purchase consideration of $95.9 million, net of cash acquired, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. The purchase consideration is subject to change for the final working capital adjustments. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary areas not yet finalized relate to the completion of the valuation of certain acquired income tax assets and liabilities and personal property. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-25-000099:notes:34]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Dortmund Fab acquisition:

[0000889331-25-000099:notes:35]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 95,942 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables | 5,985 |  |
| Inventories | 6,600 |  |
| Other current assets | 8,479 |  |
| Property, plant, and equipment | 30,132 |  |
| Intangible assets | 1,800 |  |
| Goodwill | 57,439 |  |
| Other long-term assets | 8,579 |  |
| Current liabilities | (8,248) |  |
| Other long-term liabilities | (14,824) |  |
|  | $ | 95,942 |  |

[0000889331-25-000099:notes:36]
All Dortmund assets and liabilities were recorded in the Electronics segment and are primarily reflected in the Europe geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Dortmund Fab’s products and technology with the Company’s existing semiconductor products portfolio. Goodwill resulting from the Dortmund acquisition is expected to be deductible for tax purposes.

[0000889331-25-000099:notes:37]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three months ended March 29, 2025 were net sales of $10.2 million and income before income taxes was nil since the December 31, 2024 acquisition of Dortmund Fab.

[0000889331-25-000099:notes:38]
As required by purchase accounting rules, the Company recorded a $0.5 million step-down of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-down was fully amortized as a non-cash credit to cost of sales during the first fiscal quarter of 2025 as the acquired inventory was sold and reflected as other non-segment costs.

[0000889331-25-000099:notes:39]
During the three months ended March 30, 2024, the Company incurred approximately $0.1 million of legal and professional fees related to the Dortmund Fab acquisition recognized as Selling, general, and administrative expenses in the Condensed Consolidated Statements of Net Income. Total of $3.5 million of legal and professional fees related to the Dortmund Fab acquisition was recognized since 2023. These costs were reflected as other non-segment costs.

[0000889331-25-000099:notes:40]
[same as prior period, unchanged from 0000889331-24-000191:notes:43]

[0000889331-25-000099:notes:41]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and Dortmund Fab as though the acquisition had occurred as of December 31, 2023. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Dortmund Fab acquisition occurred as of December 31, 2023, or of future consolidated operating results.

[0000889331-25-000099:notes:42]
| (in thousands, except per share amounts) |  | Three Months Ended March 29, 2025 |  | Three Months Ended March 30, 2024 |
| Net sales |  | $ | 554,307 |  |  | $ | 546,901 |  |
| Income before income taxes |  | 59,406 |  |  | 57,125 |  |
| Net income |  | 43,192 |  |  | 49,446 |  |
| Net income per share — basic |  | 1.74 |  |  | 1.98 |  |
| Net income per share — diluted |  | 1.73 |  |  | 1.97 |  |

[0000889331-25-000099:notes:43]
[same as prior period, unchanged from 0000889331-24-000191:notes:46]

[0000889331-25-000099:notes:44]
| (in thousands) |  | Three Months Ended March 29, 2025 |  | Three Months Ended March 30, 2024 |
| Amortization of unfavorable production contract (a) |  | $ | — |  |  | $ | 756 |  |
| Amortization of inventory step-down (b) |  | (504) |  |  | 510 |  |
| Depreciation |  |  |  | (276) |  |
| Amortization (c) |  |  |  | (94) |  |
| Transaction costs (d) |  | (37) |  |  | (469) |  |
| Income tax benefit (expense) of above items |  | 162 |  |  | (128) |  |

[0000889331-25-000099:notes:45]
(a) The amortization of the unfavorable production contract during the three months ended March 30, 2024 results from the fair value assigned to the unfavorable production contract liability that is amortized over three years.

[0000889331-25-000099:notes:46]
(b) The amortization of the inventory step-down adjustment reflects the reversal of the amount recognized during the three months ended March 29, 2025, and the recognition of the amortization during the three months ended March 30, 2024. The inventory step-down was fully amortized over two months as the inventory was sold.

[0000889331-25-000099:notes:47]
(c) The amortization adjustment for the three months ended March 30, 2024 primarily reflects amortization resulting from the measurement of intangibles at their fair values.

[0000889331-25-000099:notes:48]
(d) The transaction costs adjustment reflects certain legal and professional fees for the three months ended  March 29, 2025 and three months ended March 30, 2024, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-25-000099:notes:49]
[same as prior period, unchanged from 0000889331-24-000191:notes:50]

[0000889331-25-000099:notes:50]
The components of inventories at March 29, 2025 and December 28, 2024 were as follows:

[0000889331-25-000099:notes:51]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Raw materials |  | $ | 192,382 |  |  | $ | 193,788 |  |
| Work in process |  | 128,051 |  |  | 115,497 |  |
| Finished goods |  | 168,923 |  |  | 173,513 |  |
| Inventory reserves |  | (72,254) |  |  | (66,525) |  |
| Total |  | $ | 417,102 |  |  | $ | 416,273 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-25-000099:notes:52]
Property, Plant, and Equipment, net

[0000889331-25-000099:notes:53]
The components of net property, plant, and equipment at March 29, 2025 and December 28, 2024 were as follows:

[0000889331-25-000099:notes:54]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Land and land improvements |  | $ | 18,012 |  |  | $ | 17,593 |  |
| Building and building improvements |  | 199,492 |  |  | 192,441 |  |
| Machinery and equipment |  | 935,644 |  |  | 892,940 |  |
| Accumulated depreciation and amortization |  | (642,812) |  |  | (625,906) |  |
| Total |  | $ | 510,336 |  |  | $ | 477,068 |  |

[0000889331-25-000099:notes:55]
The Company recorded depreciation expense of $18.4 million and $16.7 million for the three months ended March 29, 2025 and March 30, 2024, respectively, in Cost of sales, Selling, general, and administrative expenses, and Research and development expenses in the Condensed Consolidated Statements of Net Income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-25-000099:notes:56]
[same as prior period, unchanged from 0000889331-24-000191:notes:57]

[0000889331-25-000099:notes:57]
The amounts for goodwill and changes in the carrying value of goodwill by segment for the three months ended March 29, 2025 were as follows:

[0000889331-25-000099:notes:58]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net goodwill as of December 28, 2024 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 28, 2024 |  | $ | 906,871 |  |  | $ | 233,286 |  |  | $ | 173,882 |  |  | $ | 1,314,039 |  |
| Accumulated impairment losses as of December 28, 2024 |  | — |  |  | (41,645) |  |  | (43,892) |  |  | (85,537) |  |
| Total |  | 906,871 |  |  | 191,641 |  |  | 129,990 |  |  | 1,228,502 |  |
| Changes during 2025: |  |  |  |  |  |  |  |  |
| Additions (a) |  | 57,439 |  |  | — |  |  | — |  |  | 57,439 |  |
| Foreign currency translation adjustments |  | 18,252 |  |  | 1,740 |  |  | 2,008 |  |  | 22,000 |  |
| Net goodwill as of March 29, 2025 |  |  |  |  |  |  |  |  |
| Gross goodwill as of March 29, 2025 |  | 982,562 |  |  | 235,960 |  |  | 177,263 |  |  | 1,395,785 |  |
| Accumulated impairment losses as of March 29, 2025 |  | — |  |  | (42,579) |  |  | (45,265) |  |  | (87,844) |  |
| Total |  | $ | 982,562 |  |  | $ | 193,381 |  |  | $ | 131,998 |  |  | $ | 1,307,941 |  |

[0000889331-25-000099:notes:59]
(a) The additions resulted from the acquisition of Dortmund Fab.

[0000889331-25-000099:notes:60]
The components of intangible assets as of March 29, 2025 and December 28, 2024 were as follows:

[0000889331-25-000099:notes:61]
|  |  |  | As of March 29, 2025 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 16,164 |  |  | $ | 3,132 |  |  | $ | 13,032 |  |
| Patents, licenses, and software |  |  | 264,596 |  |  | 188,579 |  |  | 76,017 |  |
| Distribution network |  |  | 41,857 |  |  | 41,857 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 641,597 |  |  | 255,001 |  |  | 386,596 |  |
| Total |  |  | $ | 964,214 |  |  | $ | 488,569 |  |  | $ | 475,645 |  |

[0000889331-25-000099:notes:62]
|  | As of December 28, 2024 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 16,079 |  |  | $ | 2,994 |  |  | $ | 13,085 |  |
| Patents, licenses, and software | 260,096 |  |  | 180,674 |  |  | 79,422 |  |
| Distribution network | 41,667 |  |  | 41,667 |  |  | — |  |
| Customer relationships, trademarks, and tradenames | 632,572 |  |  | 242,961 |  |  | 389,611 |  |
| Total | $ | 950,414 |  |  | $ | 468,296 |  |  | $ | 482,118 |  |

[0000889331-25-000099:notes:63]
During the three months ended March 29, 2025 and March 30, 2024, the Company recorded amortization expense of $14.3 million and $15.8 million, respectively.

[0000889331-25-000099:notes:64]
During the three months ended March 29, 2025, the Company recorded additions to intangible assets of $1.8 million related to the Dortmund Fab acquisition, the components of which were as follows:

[0000889331-25-000099:notes:65]
| (in thousands) | Weighted Average Useful Life |  | Amount |
| Customer relationships, trademarks, and tradenames | 5 |  | $ | 1,800 |  |
| Total |  |  | $ | 1,800 |  |

[0000889331-25-000099:notes:66]
Estimated annual amortization expense related to intangible assets with definite lives as of March 29, 2025 was as follows:

[0000889331-25-000099:notes:67]
| (in thousands) | Amount |
| Remainder of 2025 | $ | 43,680 |  |
| 2026 | 47,456 |  |
| 2027 | 45,389 |  |
| 2028 | 44,991 |  |
| 2029 | 44,580 |  |
| 2030 and thereafter | 249,549 |  |
| Total | $ | 475,645 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-25-000099:notes:68]
[same as prior period, unchanged from 0000889331-24-000191:notes:66]

[0000889331-25-000099:notes:69]
The components of accrued liabilities as of March 29, 2025 and December 28, 2024 were as follows:

[0000889331-25-000099:notes:70]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Employee-related liabilities |  | $ | 57,350 |  |  | $ | 67,639 |  |
| Current lease liability |  | 10,592 |  |  | 13,900 |  |
| Other non-income taxes |  | 8,152 |  |  | 7,022 |  |
| Restructuring liability |  | 7,044 |  |  | 4,624 |  |
| Professional services |  | 5,924 |  |  | 6,613 |  |
| Interest |  | 4,628 |  |  | 8,131 |  |
| Other customer reserves |  | 3,388 |  |  | 3,450 |  |
| Deferred revenue |  | 2,575 |  |  | 1,557 |  |
| Current hedge liability |  | 1,848 |  |  | 4,067 |  |
| Current benefit liability |  | 1,514 |  |  | 1,514 |  |
| Other |  | 36,800 |  |  | 29,759 |  |
| Total |  | $ | 139,815 |  |  | $ | 148,276 |  |

[0000889331-25-000099:notes:71]
[same as prior period, unchanged from 0000889331-24-000191:notes:69]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-25-000099:notes:72]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three months ended March 29, 2025 and March 30, 2024 as follows:

[0000889331-25-000099:notes:73]
|  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 4,804 |  |  | $ | 3,132 |  |  | $ | 412 |  |  | $ | 8,348 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 511 |  |  | 23 |  |  | 1 |  |  | 535 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 5,315 |  |  | 3,155 |  |  | 413 |  |  | 8,883 |  |  |  |  |  |  |  |  |  |
| Impairment | 136 |  |  | — |  |  | — |  |  | 136 |  |  |  |  |  |  |  |  |  |
| Total | $ | 5,451 |  |  | $ | 3,155 |  |  | $ | 413 |  |  | $ | 9,019 |  |  |  |  |  |  |  |  |  |

[0000889331-25-000099:notes:74]
|  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 544 |  |  | $ | 1,190 |  |  | $ | 435 |  |  | $ | 2,169 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 52 |  |  | 78 |  |  | 5 |  |  | 135 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 596 |  |  | 1,268 |  |  | 440 |  |  | 2,304 |  |  |  |  |  |  |  |  |  |
| Impairment | — |  |  | 933 |  |  | — |  |  | 933 |  |  |  |  |  |  |  |  |  |
| Total | $ | 596 |  |  | $ | 2,201 |  |  | $ | 440 |  |  | $ | 3,237 |  |  |  |  |  |  |  |  |  |

[0000889331-25-000099:notes:75]
2025

[0000889331-25-000099:notes:76]
For the three months ended March 29, 2025, the Company recorded total restructuring charges of $8.9 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and corporate support functions for the semiconductor business within the Electronics segment, and across all businesses within the Transportation segment. In addition, during the first fiscal quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment.

[0000889331-25-000099:notes:77]
[same as prior period, unchanged from 0000889331-24-000191:notes:73]

[0000889331-25-000099:notes:78]
For the three months ended March 30, 2024, the Company recorded total restructuring charges of $2.3 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and

[0000889331-25-000099:notes:79]
administrative functions within the Transportation segment’s commercial vehicle business, and the reorganization of certain selling and administrative functions within the Electronics and Industrial segments. In addition, during the first fiscal quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-25-000099:notes:80]
The restructuring reserves as of March 29, 2025 and December 28, 2024 were $7.0 million and $4.6 million, respectively. The restructuring liability is included within Accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed during fiscal year 2025.


## us-gaap:DebtDisclosureTextBlock

[0000889331-25-000099:notes:81]
Debt

[0000889331-25-000099:notes:82]
The carrying amounts of debt at March 29, 2025 and December 28, 2024 were as follows:

[0000889331-25-000099:notes:83]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 277,500 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,557 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 3,163 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,530) |  |  | (2,766) |  |
| Total debt |  | 805,690 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,710) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 787,980 |  |  | $ | 788,502 |  |

[0000889331-25-000099:notes:84]
Revolving Credit Facility and Term Loan

[0000889331-25-000099:notes:85]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-25-000099:notes:86]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-25-000099:notes:87]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 29, 2025, the Company made term loan payments of $3.8 million. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $277.5 million, respectively, as of March 29, 2025.

[0000889331-25-000099:notes:88]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-25-000099:notes:89]
As of March 29, 2025, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 5.42%, and 4.13% on the hedged portion.

[0000889331-25-000099:notes:90]
As of March 29, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of March 29, 2025, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-25-000099:notes:91]
Senior Notes

[0000889331-25-000099:notes:92]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-25-000099:notes:93]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-25-000099:notes:94]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-25-000099:notes:95]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-25-000099:notes:96]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-25-000099:notes:97]
The Senior Notes have not been registered under the Securities Act of 1933 ("Securities Act"), or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-25-000099:notes:98]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of March 29, 2025, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-25-000099:notes:99]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-25-000099:notes:100]
Interest paid on all Company debt was $12.2 million and $13.2 million for the three months ended March 29, 2025 and March 30, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-25-000099:notes:101]
[same as prior period, unchanged from 0000889331-24-000191:notes:98]

[0000889331-25-000099:notes:102]
[same as prior period, unchanged from 0000889331-24-000191:notes:99]

[0000889331-25-000099:notes:103]
[same as prior period, unchanged from 0000889331-24-000191:notes:100]

[0000889331-25-000099:notes:104]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable; and

[0000889331-25-000099:notes:105]
Level 3—Valuations based upon one or more significant unobservable inputs.

[0000889331-25-000099:notes:106]
There were no transfers in or out of Level 1, Level 2 or Level 3 during the period.

[0000889331-25-000099:notes:107]
[same as prior period, unchanged from 0000889331-24-000191:notes:104]

[0000889331-25-000099:notes:108]
[same as prior period, unchanged from 0000889331-24-000191:notes:105]

[0000889331-25-000099:notes:109]
Cash equivalents primarily consist of money market funds, certificates of deposit, and short-term time deposits, which are held with institutions with sound credit ratings and are highly liquid. The Company classified cash equivalents as Level 1 and were valued at cost which approximates fair value.

[0000889331-25-000099:notes:110]
[same as prior period, unchanged from 0000889331-24-000191:notes:107]

[0000889331-25-000099:notes:111]
[same as prior period, unchanged from 0000889331-24-000191:notes:108]

[0000889331-25-000099:notes:112]
[same as prior period, unchanged from 0000889331-24-000191:notes:109]

[0000889331-25-000099:notes:113]
[same as prior period, unchanged from 0000889331-24-000191:notes:110]

[0000889331-25-000099:notes:114]
[same as prior period, unchanged from 0000889331-24-000191:notes:111]

[0000889331-25-000099:notes:115]
In July 2024, the Company implemented a hedging program to manage foreign currency risk exposure related to fluctuations between the U.S. dollar and Mexican peso. These foreign currency zero cost collars are designated as cash flow hedges for a portion of our Mexican peso-denominated manufacturing expenses, predominantly salary expenses, vendor payments, and utility expenses. If the spot rate is between the weighted-average ceiling and floor rates on the date of maturity, then the Company would not owe or receive any payments under these collars. The Company plans to continue executing zero cost collars with 14-month rolling maturities as an ongoing strategy to hedge peso-denominated manufacturing expenses. The trade entry date, maturity date, weighted-average floor, and weighted-average ceiling for each collar trade was as follows:

[0000889331-25-000099:notes:116]
| Trade Entry Date | Trade Maturity Date | Weighted-Average Floor | Weighted-Average Ceiling |
| July 3, 2024 | August 29, 2025 | 18.0000 | 19.4350 |
| August 5, 2024 | September 29, 2025 | 19.6550 | 21.0000 |
| September 3, 2024 | November 3, 2025 | 20.0820 | 21.7571 |
| September 30, 2024 | November 26, 2025 | 19.8700 | 21.3650 |
| November 4, 2024 | January 2, 2026 | 20.1200 | 21.6900 |
| December 3, 2024 | February 2, 2026 | 20.4250 | 22.0377 |
| January 2, 2025 | March 2, 2026 | 20.8000 | 21.9082 |
| February 6, 2025 | March 30, 2026 | 20.5300 | 22.0000 |

[0000889331-25-000099:notes:117]
The fair value of the collars was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three months ended March 29, 2025, the Company recorded a pre-tax unrealized gain on the collars of $2.4 million. As of March 29, 2025, the Company estimates that approximately $1.1 million of pre-tax losses  recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The amounts included in accumulated other comprehensive income will be reclassified to earnings should the hedge no longer be considered effective. No amount of ineffectiveness was included in net income for the three months ended March 29, 2025. The Company will continue to assess the effectiveness of the hedge on an ongoing basis. The primary inputs into the valuation of the collars are interest yield curves, interest rate volatilities, foreign exchange rates, foreign exchange volatilities, credit risk, credit spreads and other market information. The collars are classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0000889331-25-000099:notes:118]
[same as prior period, unchanged from 0000889331-24-000191:notes:114]

[0000889331-25-000099:notes:119]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three months ended March 29, 2025, the Company recorded a pre-tax unrealized loss on the interest rate swap of $2.3 million. As of March 29, 2025, the Company estimates that approximately $2.3 million of pre-tax gain recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0000889331-25-000099:notes:120]
[same as prior period, unchanged from 0000889331-24-000191:notes:116]

[0000889331-25-000099:notes:121]
[same as prior period, unchanged from 0000889331-24-000191:notes:119]

[0000889331-25-000099:notes:122]
As of March 29, 2025 and December 28, 2024, the fair values of the Company's derivative financial instruments and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-25-000099:notes:123]
| (in thousands) | Condensed Consolidated Balance Sheets Classification |  | March 29, 2025 |  | December 28, 2024 |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 2,131 |  |  | $ | 2,482 |  |  |  |
|  | Other long-term assets |  | 1,749 |  |  | 3,716 |  |  |  |
| Zero cost collar agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 173 |  |  | $ | 22 |  |  |  |
|  | Accrued liabilities |  | 1,848 |  |  | 4,067 |  |  |  |
|  | Other long-term liabilities |  | — |  |  | 2 |  |  |  |

[0000889331-25-000099:notes:124]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Net Income for the three months ended March 29, 2025 and March 30, 2024 were as follows:

[0000889331-25-000099:notes:125]
|  |  |  |  | Three Months Ended |  |  |
| (in thousands) |  | Classification of (Gains) Losses Recognized in the Condensed Consolidated Statements of Net Income |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (788) |  |  | $ | (1,280) |  |  |  |  |  |
| Zero cost collar agreement |  | Cost of sales |  | 1,480 |  |  | — |  |  |  |  |  |
| Zero cost collar agreement |  | Selling, general, and administrative expenses |  | $ | 121 |  |  | — |  |  |  |  |  |

[0000889331-25-000099:notes:126]
The pre-tax losses (gains) recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three months ended March 29, 2025 and March 30, 2024 were as follows:

[0000889331-25-000099:notes:127]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | 2,318 |  |  | $ | (2,534) |  |  |  |  |  |
| Zero cost collar agreement |  | $ | (2,442) |  |  | $ | — |  |  |  |  |  |

[0000889331-25-000099:notes:128]
[same as prior period, unchanged from 0000889331-24-000191:notes:126]

[0000889331-25-000099:notes:129]
[same as prior period, unchanged from 0000889331-24-000191:notes:127]

[0000889331-25-000099:notes:130]
There were no changes during the quarter ended March 29, 2025 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of March 29, 2025 and December 28, 2024, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-25-000099:notes:131]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of March 29, 2025:

[0000889331-25-000099:notes:132]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 542,185 |  |  | $ | — |  |  | $ | — |  |  | $ | 542,185 |  |
| Investments in equity securities |  | 8,926 |  |  | — |  |  | — |  |  | 8,926 |  |
| Mutual funds |  | 22,351 |  |  | — |  |  | — |  |  | 22,351 |  |
| Total |  | $ | 573,462 |  |  | $ | — |  |  | $ | — |  |  | $ | 573,462 |  |

[0000889331-25-000099:notes:133]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 28, 2024:

[0000889331-25-000099:notes:134]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 658,491 |  |  | $ | — |  |  | $ | — |  |  | $ | 658,491 |  |
| Investments in equity securities |  | 10,182 |  |  | — |  |  | — |  |  | 10,182 |  |
| Mutual funds |  | 23,268 |  |  | — |  |  | — |  |  | 23,268 |  |
| Total |  | $ | 691,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 691,941 |  |

[0000889331-25-000099:notes:135]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at March 29, 2025 and December 28, 2024, as the rates on these borrowings are variable in nature. The purchase price of business acquisitions is primarily allocated to the tangible and identifiable intangible assets acquired and liabilities assumed based on their estimated fair values on the acquisition date, with the excess recorded as goodwill. The Company utilizes Level 3 inputs in the determination of the initial fair value.

[0000889331-25-000099:notes:136]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series B and USD Senior Notes, Series A and Series B, as of March 29, 2025 and December 28, 2024 were as follows:

[0000889331-25-000099:notes:137]
|  |  | March 29, 2025 |  | December 28, 2024 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 |  | $ | 102,557 |  |  | $ | 95,548 |  |  | $ | 98,928 |  |  | $ | 91,741 |  |
| USD Senior Notes, Series A due 2025 |  | — |  |  | — |  |  | 50,000 |  |  | 49,919 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 97,511 |  |  | 100,000 |  |  | 96,623 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 116,960 |  |  | 125,000 |  |  | 114,786 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 92,877 |  |  | 100,000 |  |  | 91,175 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-25-000099:notes:138]
[same as prior period, unchanged from 0000889331-24-000191:notes:136]

[0000889331-25-000099:notes:139]
[same as prior period, unchanged from 0000889331-24-000191:notes:137]

[0000889331-25-000099:notes:140]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three months ended March 29, 2025 and March 30, 2024 were as follows:

[0000889331-25-000099:notes:141]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 727 |  |  | $ | 795 |  |  |  |  |  |
| Interest cost |  | 954 |  |  | 995 |  |  |  |  |  |
| Expected return on plan assets |  | (459) |  |  | (518) |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | 69 |  |  | 46 |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 1,291 |  |  | $ | 1,318 |  |  |  |  |  |

[0000889331-25-000099:notes:142]
The Company expects to make approximately $1.2 million of contributions to the plans and pay $2.1 million of benefits directly in 2025.

[0000889331-25-000099:notes:143]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company is required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $23 million, representing approximately 33% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-25-000099:notes:144]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.7 million for both of the three months ended March 29, 2025 and March 30, 2024, respectively, in Cost of sales and Other income, net within the Condensed Consolidated Statements of Net Income. The pre-tax losses amount recognized in other comprehensive income (loss) for these plans were $0.4 million and $0.3 million for the three months ended March 29, 2025 and March 30, 2024, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-25-000099:notes:145]
[same as prior period, unchanged from 0000889331-24-000191:notes:143]

[0000889331-25-000099:notes:146]
| (in thousands) |  | Three Months EndedMarch 29, 2025 |  | Three Months EndedMarch 30, 2024 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 227 |  |  | $ | (8) |  |  | $ | 219 |  |  | $ | 360 |  |  | $ | (16) |  |  | $ | 344 |  |
| Cash flow hedges |  | 124 |  |  | 464 |  |  | 588 |  |  | 2,534 |  |  | (608) |  |  | 1,926 |  |
| Foreign currency translation adjustments (a) |  | 37,668 |  |  | (878) |  |  | 36,790 |  |  | (33,170) |  |  | 609 |  |  | (32,561) |  |
| Total change in other comprehensive income (loss) |  | $ | 38,019 |  |  | $ | (422) |  |  | $ | 37,597 |  |  | $ | (30,276) |  |  | $ | (15) |  |  | $ | (30,291) |  |

[0000889331-25-000099:notes:147]
[same as prior period, unchanged from 0000889331-24-000191:notes:145]

[0000889331-25-000099:notes:148]
The following tables set forth the changes in the components of accumulated other comprehensive income (loss) by component for the three months ended March 29, 2025 and March 30, 2024:

[0000889331-25-000099:notes:149]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currencytranslation adjustments |  | Accumulated othercomprehensive loss |
| Balance at December 28, 2024 |  | $ | (10,509) |  |  | $ | 1,301 |  |  | $ | (137,153) |  |  | $ | (146,361) |  |
| Activity in the period |  | 219 |  |  | 588 |  |  | 36,790 |  |  | 37,597 |  |
| Balance at March 29, 2025 |  | $ | (10,290) |  |  | $ | 1,889 |  |  | $ | (100,363) |  |  | $ | (108,764) |  |

[0000889331-25-000099:notes:150]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currency translation adjustments |  | Accumulated other comprehensive loss |
| Balance at December 30, 2023 |  | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| Activity in the period |  | 344 |  |  | 1,926 |  |  | (32,561) |  |  | (30,291) |  |
| Balance at March 30, 2024 |  | $ | (7,269) |  |  | $ | 6,374 |  |  | $ | (85,213) |  |  | $ | (86,108) |  |

[0000889331-25-000099:notes:151]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for the three months ended March 29, 2025 and March 30, 2024 were as follows:

[0000889331-25-000099:notes:152]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Pension and postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss, and other |  | $ | 421 |  |  | $ | 356 |  |  |  |  |  |

[0000889331-25-000099:notes:153]
[same as prior period, unchanged from 0000889331-24-000191:notes:151]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-25-000099:notes:154]
Income Taxes
The effective tax rate for the three months ended March 29, 2025 was 27.3%, compared to the effective tax rate for the three months ended March 30, 2024 of 13.0%. The effective tax rate for 2025 is higher than the effective tax rate for the comparable 2024 period primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits in the first fiscal quarter of 2024 which favorably impacted the 2024 effective tax rate by 10.6%.

[0000889331-25-000099:notes:155]
The effective tax rate for 2025 is higher than the statutory tax rate primarily due to losses in non-US jurisdictions with no related tax benefit, and the effective tax rate for 2024 is lower than the statutory tax rate primarily due to the lapse in statute of limitations for previously unrecognized tax benefits.

[0000889331-25-000099:notes:156]
.


## us-gaap:EarningsPerShareTextBlock

[0000889331-25-000099:notes:157]
[same as prior period, unchanged from 0000889331-24-000191:notes:153]

[0000889331-25-000099:notes:158]
[same as prior period, unchanged from 0000889331-24-000191:notes:154]

[0000889331-25-000099:notes:159]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 43,571 |  |  | $ | 48,452 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,767 |  |  | 24,911 |  |  |  |  |  |
| Effect of dilutive securities |  | 196 |  |  | 213 |  |  |  |  |  |
| Diluted |  | 24,963 |  |  | 25,124 |  |  |  |  |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.76 |  |  | $ | 1.95 |  |  |  |  |  |
| Diluted earnings per share |  | $ | 1.75 |  |  | $ | 1.93 |  |  |  |  |  |

[0000889331-25-000099:notes:160]
Potential shares of common stock attributable to stock options and restricted stock units excluded from the earnings per share calculation because their effect would be anti-dilutive were 340,710 and 175,411 for the three months ended March 29, 2025 and March 30, 2024, respectively.

[0000889331-25-000099:notes:161]
[same as prior period, unchanged from 0000889331-24-000191:notes:157]

[0000889331-25-000099:notes:162]
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program") to replace its previous 2021 program. During the three months ended March 29, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. During the three months ended March 30, 2024, the Company repurchased 70,280 shares of its common stock totaling $16.1 million pursuant to the 2021 program.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-25-000099:notes:163]
[same as prior period, unchanged from 0000889331-24-000191:notes:159]

[0000889331-25-000099:notes:164]
The Company and its subsidiaries design, manufacture and sell component, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company aggregated its operating segments into the reportable segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information and as such, segment asset information is not disclosed. The CODM’s key decisions involve the allocation of resources, such as acquisitions, divestitures, investments, capital expenditures, significant customer contracts, and other key management resources, and assessment of performance, such as executive officer hiring, promotion, and compensation. The CODM uses operating income as the key metric when establishing targets in the annual budget and in evaluating the allocation of resources to each segment. The CODM regularly reviews each segment's operating income against the forecast, budget and previous quarterly results to assess performance and make decisions about the allocation of operating and capital resources to each segment.

[0000889331-25-000099:notes:165]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Finance, information technology, and human resources are shared functions that are allocated back to the operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined

[0000889331-25-000099:notes:166]
by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other.” Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-25-000099:notes:167]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes, and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related charging infrastructure, aerospace, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-25-000099:notes:168]
•Transportation Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicles, heavy-duty truck and bus, off-road and recreational vehicles, material handling equipment, agricultural machinery, construction equipment and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engines, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck and bus, construction, agriculture, material handling and marine.

[0000889331-25-000099:notes:169]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), protective and monitoring relays (protection relays, residual current devices and monitors, ground fault circuit interrupters, solid state switches, and arc fault detection devices), and industrial controls and sensors (contactors, transformers, and temperature sensors) for use in various applications such as renewable energy and energy storage systems, industrial safety, factory automation, electric vehicle charging infrastructure, HVAC systems, non-residential construction, MRO, and mining.

[0000889331-25-000099:notes:170]
The Company has provided this segment information for comparable prior periods. Segment information is summarized as follows:

[0000889331-25-000099:notes:171]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 307,249 |  |  | $ | 291,105 |  |  |  |  |  |
| Transportation |  | 161,862 |  |  | 170,367 |  |  |  |  |  |
| Industrial |  | 85,196 |  |  | 73,913 |  |  |  |  |  |
| Total net sales |  | $ | 554,307 |  |  | $ | 535,385 |  |  |  |  |  |
| Other segment expenses (b) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 260,483 |  |  | $ | 253,302 |  |  |  |  |  |
| Transportation |  | 142,945 |  |  | 154,161 |  |  |  |  |  |
| Industrial |  | 72,122 |  |  | 69,117 |  |  |  |  |  |
| Total other segment expenses |  | $ | 475,550 |  |  | $ | 476,580 |  |  |  |  |  |
| Segment operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 46,766 |  |  | $ | 37,803 |  |  |  |  |  |
| Transportation |  | 18,917 |  |  | 16,206 |  |  |  |  |  |
| Industrial |  | 13,074 |  |  | 4,796 |  |  |  |  |  |
| Total segment operating income |  | 78,757 |  |  | 58,805 |  |  |  |  |  |
| Other (a) |  | (8,607) |  |  | (3,853) |  |  |  |  |  |
| Total operating income |  | 70,150 |  |  | 54,952 |  |  |  |  |  |
| Interest expense |  | 8,875 |  |  | 9,611 |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 4,843 |  |  | (5,042) |  |  |  |  |  |
| Other income, net |  | (3,515) |  |  | (5,321) |  |  |  |  |  |
| Income before income taxes |  | $ | 59,947 |  |  | $ | 55,704 |  |  |  |  |  |

[0000889331-25-000099:notes:172]
(a) Included in "Other" Operating income for the first fiscal quarter of 2025 was $8.9 million of restructuring charges primarily related to employee termination costs, and $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the first fiscal quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustment, and $0.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisition.

[0000889331-25-000099:notes:173]
Included in "Other" Operating income for the first fiscal quarter of 2024 was $2.3 million of restructuring charges primarily related to employee termination costs and a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first fiscal quarter of 2024, the Company recognized a $0.9 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.3 million recorded for the sale of a building in the commercial vehicle business within the Transportation segment.

[0000889331-25-000099:notes:174]
(b) Other segment operating expenses include cost of sales, selling, general, and administration expenses, and research and development expenses. Other segment expenses are reconciled to the operating income of each segment. The CODM regularly assesses the performance of each operating segment focusing on each operating segment’s revenue and operating income. Other segment operating expenses for the first fiscal quarter of 2024 were included in order to adhere to the implementation of Accounting Standards Updates ("ASU") No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures."

[0000889331-25-000099:notes:175]
The Company’s depreciation and amortization expenses by segment for the three months ended March 29, 2025 and March 30, 2024 were as follows:

[0000889331-25-000099:notes:176]
|  |  | Three Months Ended |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |
| Depreciation |  |  |  |  |
| Electronics |  | $ | 11,410 |  |  | $ | 9,985 |  |
| Transportation |  | 5,499 |  |  | 5,247 |  |
| Industrial |  | 1,521 |  |  | 1,436 |  |
| Total depreciation |  | $ | 18,430 |  |  | $ | 16,668 |  |
| Amortization |  |  |  |  |
| Electronics |  | $ | 9,777 |  |  | $ | 9,856 |  |
| Transportation |  | 3,349 |  |  | 3,384 |  |
| Industrial |  | 1,205 |  |  | 2,585 |  |
| Total amortization |  | $ | 14,331 |  |  | $ | 15,825 |  |

[0000889331-25-000099:notes:177]
[same as prior period, unchanged from 0000889331-24-000191:notes:169]

[0000889331-25-000099:notes:178]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 198,378 |  |  | $ | 190,433 |  |  |  |  |  |
| China |  | 129,394 |  |  | 115,169 |  |  |  |  |  |
| Other countries (a) |  | 226,535 |  |  | 229,783 |  |  |  |  |  |
| Total net sales |  | $ | 554,307 |  |  | $ | 535,385 |  |  |  |  |  |

[0000889331-25-000099:notes:179]
The Company’s long-lived assets represent net property, plant, and equipment, and are classified according to the country where the asset is located. The Company's long-lived assets were as follows:

[0000889331-25-000099:notes:180]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 75,148 |  |  | $ | 74,698 |  |
| China |  | 129,401 |  |  | 132,504 |  |
| Mexico |  | 86,711 |  |  | 89,558 |  |
| Germany |  | 97,739 |  |  | 58,758 |  |
| Philippines |  | 64,761 |  |  | 66,174 |  |
| Other countries |  | 56,576 |  |  | 55,376 |  |
| Total long-lived assets |  | $ | 510,336 |  |  | $ | 477,068 |  |

[0000889331-25-000099:notes:181]
The Company’s additions to net property, plant, and equipment by country were as follows:

[0000889331-25-000099:notes:182]
|  |  | Three Months Ended |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 3,493 |  |  | $ | 4,806 |  |
| China |  | 1,483 |  |  | 2,408 |  |
| Mexico |  | 1,484 |  |  | 2,330 |  |
| Germany |  | 7,620 |  |  | 3,230 |  |
| Philippines |  | 637 |  |  | 1,338 |  |
| Other countries |  | 1,610 |  |  | 2,212 |  |
| Total additions to long-lived assets |  | $ | 16,327 |  |  | $ | 16,324 |  |

[0000889331-25-000099:notes:183]
(a)Each country included in other countries was less than 10% of net sales.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000889331-25-000099:notes:184]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0000889331-25-000099:notes:185]
As of March 29, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-25-000099:notes:186]
Product Warranty Liabilities

[0000889331-25-000099:notes:187]
The Company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0000889331-25-000099:notes:188]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0000889331-25-000099:notes:189]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-25-000099:notes:190]
Environmental Remediation Liabilities

[0000889331-25-000099:notes:191]
The Company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0000889331-25-000099:notes:192]
Legal Proceedings

[0000889331-25-000099:notes:193]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

[0000889331-25-000099:notes:194]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss, the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.

[0000889331-25-000099:notes:195]
Pending Litigation and Claims

[0000889331-25-000099:notes:196]
There were no material pending litigation or claims outstanding as of March 29, 2025.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-25-000099:notes:197]
Related Party Transactions

[0000889331-25-000099:notes:198]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-25-000099:notes:199]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-25-000099:notes:200]
EB-Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-25-000099:notes:201]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's executive officers serves on the Board of Directors of ATEC.

[0000889331-25-000099:notes:202]
|  |  | Three Months Ended March 29, 2025 |  | Three Months Ended March 30, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.5 |  | 0.2 |  | 1.9 |  |  | 1.2 |  | 0.2 |  | 2.1 |  |
|  |  | March 29, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |
