# LFUS MD&A — 0000889331-25-000099


## mdna

[0000889331-25-000099:mdna:1]
[same as prior period, unchanged from 0000889331-24-000191:mdna:1]

[0000889331-25-000099:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-25-000099:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 28, 2024.

[0000889331-25-000099:mdna:4]
[same as prior period, unchanged from 0000889331-24-000191:mdna:4]

[0000889331-25-000099:mdna:5]
[same as prior period, unchanged from 0000889331-24-000191:mdna:5]

[0000889331-25-000099:mdna:6]
[same as prior period, unchanged from 0000889331-24-000191:mdna:6]

[0000889331-25-000099:mdna:7]
[same as prior period, unchanged from 0000889331-24-000191:mdna:7]

[0000889331-25-000099:mdna:8]
[same as prior period, unchanged from 0000889331-24-000191:mdna:8]

[0000889331-25-000099:mdna:9]
For the first quarter of 2025, the Company recognized net sales of $554.3 million, an increase of $18.9 million, or 3.5% as compared to $535.4 million in the first quarter of 2024 including $10.2 million or 1.9% of incremental net sales from the Dortmund Fab acquisition (defined below) in the semiconductor business within the Electronics segment and $6.6 million or 1.2% of unfavorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume in the Industrial and Electronics segments. The Company recognized net income of $43.6 million, or $1.75 per diluted share, in the first quarter of 2025 compared to $48.5 million, or $1.93 per diluted share, in the first quarter of 2024. The decrease in net income was primarily due to the higher effective tax rate and foreign exchange losses, which were partially offset by the higher operating income in the Electronics and Industrial segments driven by increases in net sales.

[0000889331-25-000099:mdna:10]
Net cash provided by operating activities was $65.8 million for the three months ended March 29, 2025 compared to $57.2 million for the three months ended March 30, 2024. The increase in net cash provided by operating activities was primarily due to reductions in working capital and higher cash earnings.

[0000889331-25-000099:mdna:11]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab is approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-25-000099:mdna:12]
[same as prior period, unchanged from 0000889331-24-000191:mdna:16]

[0000889331-25-000099:mdna:13]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies" that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-25-000099:mdna:14]
Recently, the U.S. government has imposed extensive tariffs on goods imported from several countries, including, without limitation, China, Mexico and Canada, as well as certain broad, product-specific tariffs on foreign goods and products. Tariffs may increase the cost of materials in our supply chain, incur reciprocal levies on components and finished products exported to or imported from affected countries, and have an adverse impact on our cost of goods sold in the U.S. and abroad. These factors in turn could require us to materially increase prices to our customers which may reduce demand, or, if we do not or are unable to increase prices, could result in lower margins on products sold.

[0000889331-25-000099:mdna:15]
Tariffs have resulted in China and other countries imposing reciprocal tariffs on U.S. goods and ceasing sales of certain products to the U.S. and could result in more U.S. trading partners adopting responsive trade policies, including making it more difficult or costly for us to export our products to those countries. Sales to customers outside of the U.S., and to China in particular, comprise a significant portion of our net sales, and reciprocal tariffs may impact our business in China.  Further, tariffs and trade policies may continue to change quickly and without warning, and we may not be able to accurately anticipate and mitigate the impacts.

[0000889331-25-000099:mdna:16]
[same as prior period, unchanged from 0000889331-24-000191:mdna:18]

[0000889331-25-000099:mdna:17]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The first quarter of 2025 included $8.9 million of restructuring charges primarily related to employee termination costs, and $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the first quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustment, and $0.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions.

[0000889331-25-000099:mdna:18]
The first quarter of 2024 included $2.3 million of restructuring charges primarily related to employee termination costs and a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first quarter of 2024, the Company recognized $0.9 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.3 million recorded for the sale of a building in the commercial vehicle business within the Transportation segment.

[0000889331-25-000099:mdna:19]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 554,307 |  |  | $ | 535,385 |  |  | $ | 18,922 |  |  | 3.5 | % |  |  |  |  |  |  |  |  |
| Cost of sales |  | 347,051 |  |  | 347,577 |  |  | (526) |  |  | (0.2) | % |  |  |  |  |  |  |  |  |
| Gross profit |  | 207,256 |  |  | 187,808 |  |  | 19,448 |  |  | 10.4 | % |  |  |  |  |  |  |  |  |
| Operating expenses |  | 137,106 |  |  | 132,856 |  |  | 4,250 |  |  | 3.2 | % |  |  |  |  |  |  |  |  |
| Operating income |  | 70,150 |  |  | 54,952 |  |  | 15,198 |  |  | 27.7 | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | 59,947 |  |  | 55,704 |  |  | 4,243 |  |  | 7.6 | % |  |  |  |  |  |  |  |  |
| Income taxes |  | 16,376 |  |  | 7,252 |  |  | 9,124 |  |  | 125.8 | % |  |  |  |  |  |  |  |  |
| Net income |  | 43,571 |  |  | 48,452 |  |  | (4,881) |  |  | (10.1) | % |  |  |  |  |  |  |  |  |

[0000889331-25-000099:mdna:20]
[same as prior period, unchanged from 0000889331-24-000191:mdna:22]

[0000889331-25-000099:mdna:21]
Net sales increased $18.9 million, or 3.5%, for the first quarter of 2025 compared to the first quarter of 2024 including $10.2 million or 1.9% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and $6.6 million or 1.2% of unfavorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume of $15.7 million in the electronics products business within the Electronics segment and $11.3 million in the Industrial segment due to higher end market demand, partially offset by the lower volume from the remaining semiconductor business within the Electronics segment.

[0000889331-25-000099:mdna:22]
[same as prior period, unchanged from 0000889331-24-000191:mdna:25]

[0000889331-25-000099:mdna:23]
Cost of sales was $347.1 million, or 62.6% of net sales, in the first quarter of 2025, compared to $347.6 million, or 64.9% of net sales, in the first quarter of 2024. As a percent of net sales, cost of sales decreased 2.3% primarily driven by improved margins from the electronics products business within the Electronics segment and the industrial circuit protection business within the Industrial segment driven by volume leverage, favorable price, product mix and cost reduction initiatives.

[0000889331-25-000099:mdna:24]
[same as prior period, unchanged from 0000889331-24-000191:mdna:28]

[0000889331-25-000099:mdna:25]
Gross profit was $207.3 million, or 37.4% of net sales, in the first quarter of 2025 compared to $187.8 million, or 35.1% of net sales, for the first quarter of 2024. The $19.4 million increase in gross profit was primarily due to higher volume and favorable price from the electronics products business within the Electronics segment and across all businesses within the Industrial segment.

[0000889331-25-000099:mdna:26]
[same as prior period, unchanged from 0000889331-24-000191:mdna:31]

[0000889331-25-000099:mdna:27]
Operating expenses were $137.1 million, or 24.7% of net sales, for the first quarter of 2025 compared to $132.9 million, or 24.8% of net sales, for the first quarter of 2024. The increase in operating expenses of $4.3 million was primarily due to higher restructuring, impairment, and other charges of $5.8 million related to company-wide cost control initiatives.

[0000889331-25-000099:mdna:28]
[same as prior period, unchanged from 0000889331-24-000191:mdna:34]

[0000889331-25-000099:mdna:29]
Operating income was $70.2 million, representing an increase of $15.2 million, or 27.7%, for the first quarter of 2025 compared to $55.0 million for the first quarter of 2024. The increase in operating income was due to higher gross profit from the Electronics and Industrial segments, partially offset by higher operating expenses mainly driven by higher restructuring, impairment, and other charges. Operating margins increased from 10.3% in the first quarter of 2024 to 12.7% in the first quarter of 2025 driven by improved gross margin in the Electronics and Industrial segments.

[0000889331-25-000099:mdna:30]
[same as prior period, unchanged from 0000889331-24-000191:mdna:37]

[0000889331-25-000099:mdna:31]
Income before income taxes was $59.9 million, or 10.8% of net sales, for the first quarter of 2025 compared to $55.7 million, or 10.4% of net sales, for the first fiscal quarter of 2024. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange losses of $4.8 million in the first quarter of 2025 compared to foreign exchange gains of $5.0 million in the first quarter of 2024, and higher unrealized losses of $1.3 million related to the Company's equity investment.

[0000889331-25-000099:mdna:32]
[same as prior period, unchanged from 0000889331-24-000191:mdna:40]

[0000889331-25-000099:mdna:33]
The effective tax rate for the three months ended March 29, 2025 was 27.3%, compared to the effective tax rate for the three months ended March 30, 2024 of 13.0%. The effective tax rate for 2025 was higher than the effective tax rate for the comparable 2024 period primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits in the first quarter of 2024 which favorably impacted the 2024 effective tax rate by 10.6%.

[0000889331-25-000099:mdna:34]
The effective tax rate for 2025 is higher than the statutory tax rate primarily due to losses in non-US jurisdictions with no related tax benefit, and the effective tax rate for 2024 was lower than the statutory tax rate primarily due to the lapse in statute of limitations for previously unrecognized tax benefits.

[0000889331-25-000099:mdna:35]
[same as prior period, unchanged from 0000889331-24-000191:mdna:43]

[0000889331-25-000099:mdna:36]
[same as prior period, unchanged from 0000889331-24-000191:mdna:44]

[0000889331-25-000099:mdna:37]
[same as prior period, unchanged from 0000889331-24-000191:mdna:45]

[0000889331-25-000099:mdna:38]
| Net Sales |  | First Quarter |  |  |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 307,249 |  |  | $ | 291,105 |  |  | $ | 16,144 |  |  | 5.5 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 161,862 |  |  | 170,367 |  |  | (8,505) |  |  | (5.0) | % |  |  |  |  |  |  |  |  |
| Industrial |  | 85,196 |  |  | 73,913 |  |  | 11,283 |  |  | 15.3 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 554,307 |  |  | $ | 535,385 |  |  | $ | 18,922 |  |  | 3.5 | % |  |  |  |  |  |  |  |  |

[0000889331-25-000099:mdna:39]
| Segment Operating Income |  | First Quarter |  |  |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 46,766 |  |  | $ | 37,803 |  |  | $ | 8,963 |  |  | 23.7 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 18,917 |  |  | 16,206 |  |  | 2,711 |  |  | 16.7 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 13,074 |  |  | 4,796 |  |  | 8,278 |  |  | 172.6 | % |  |  |  |  |  |  |  |  |
| Total segment operating income |  | 78,757 |  |  | 58,805 |  |  | 19,952 |  |  |  |  |  |  |  |  |  |  |  |
| Other (a) |  | (8,607) |  |  | (3,853) |  |  | (4,754) |  |  |  |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 70,150 |  |  | $ | 54,952 |  |  | $ | 15,198 |  |  | 27.7 | % |  |  |  |  |  |  |  |  |

[0000889331-25-000099:mdna:40]
(a) Included in “Other” Operating income for the first quarter of 2025 was $8.9 million of restructuring charges primarily related to employee termination costs, and $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the first quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustment, and $0.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisition.

[0000889331-25-000099:mdna:41]
Included in “Other” Operating income for the first quarter of 2024 was $2.3 million of restructuring charges primarily related to employee termination costs and a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first quarter of 2024, the Company recognized $0.9 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.3 million recorded for the sale of a building in the commercial vehicle business within the Transportation segment.

[0000889331-25-000099:mdna:42]
[same as prior period, unchanged from 0000889331-24-000191:mdna:50]

[0000889331-25-000099:mdna:43]
[same as prior period, unchanged from 0000889331-24-000191:mdna:51]

[0000889331-25-000099:mdna:44]
Net sales increased $16.1 million, or 5.5%, in the first quarter of 2025 compared to the first quarter of 2024 and included unfavorable changes in foreign exchange rates of $3.8 million. The sales increase was primarily due to higher volume of $15.7 million from the electronics products business driven by higher end market demand and $10.2 million of incremental net sales from the Dortmund Fab acquisition in the semiconductor business, partially offset by the lower volume from the remaining semiconductor business.

[0000889331-25-000099:mdna:45]
[same as prior period, unchanged from 0000889331-24-000191:mdna:54]

[0000889331-25-000099:mdna:46]
Operating income was $46.8 million, representing an increase of $9.0 million, or 23.7%, for the first quarter of 2025 compared to $37.8 million for the first quarter of 2024. The increase in operating income was primarily from the electronics products business due to volume leverage. Operating margins increased from 13.0% in the first quarter of 2024 to 15.2% in the first quarter of 2025 primarily due to the volume leverage from the electronics products business.

[0000889331-25-000099:mdna:47]
[same as prior period, unchanged from 0000889331-24-000191:mdna:57]

[0000889331-25-000099:mdna:48]
[same as prior period, unchanged from 0000889331-24-000191:mdna:58]

[0000889331-25-000099:mdna:49]
Net sales decreased $8.5 million, or 5.0%, in the first quarter of 2025 compared to the first quarter of 2024 and included unfavorable changes in foreign exchange rates of $2.2 million. The remaining sales decline was primarily due to lower automotive sensors business volume of $5.5 million driven by the strategic exit of certain lower margin products.

[0000889331-25-000099:mdna:50]
[same as prior period, unchanged from 0000889331-24-000191:mdna:61]

[0000889331-25-000099:mdna:51]
Operating income was $18.9 million, representing an increase of $2.7 million, or 16.7%, for the first quarter of 2025 compared to $16.2 million for the first quarter of 2024. The increase in operating income was primarily from the commercial vehicle business due to favorable price and cost reduction initiatives. Operating margins increased from 9.5% in the first quarter of 2024 to 11.7% in the first quarter of 2025 primarily driven by favorable price, cost reduction initiatives and product mix from the commercial vehicle business.

[0000889331-25-000099:mdna:52]
[same as prior period, unchanged from 0000889331-24-000191:mdna:64]

[0000889331-25-000099:mdna:53]
[same as prior period, unchanged from 0000889331-24-000191:mdna:65]

[0000889331-25-000099:mdna:54]
Net sales increased by $11.3 million, or 15.3%, in the first quarter of 2025 compared to the first quarter of 2024, which included unfavorable changes in foreign exchange rates of $0.6 million. The sales increase was due to higher volume from industrial circuit protection and industrial control and sensor products driven by higher end market demand and favorable price.

[0000889331-25-000099:mdna:55]
[same as prior period, unchanged from 0000889331-24-000191:mdna:68]

[0000889331-25-000099:mdna:56]
Operating income was $13.1 million, representing an increase of $8.3 million, or 172.6%, for the first quarter of 2025 compared to $4.8 million for the first quarter of 2024. The increase in operating income was driven by higher volume from industrial circuit protection and industrial control and sensor products driven by increased end market demand and favorable price and product mix. Operating margins increased from 6.5% in the first quarter of 2024 to 15.3% in the first fiscal quarter of 2025 due to higher volume and favorable price.

[0000889331-25-000099:mdna:57]
[same as prior period, unchanged from 0000889331-24-000191:mdna:71]

[0000889331-25-000099:mdna:58]
[same as prior period, unchanged from 0000889331-24-000191:mdna:72]

[0000889331-25-000099:mdna:59]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Americas |  | $ | 224,690 |  |  | $ | 214,784 |  |  | $ | 9,906 |  |  | 4.6 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 205,284 |  |  | 193,689 |  |  | 11,595 |  |  | 6.0 | % |  |  |  |  |  |  |  |  |
| Europe |  | 124,333 |  |  | 126,912 |  |  | (2,579) |  |  | (2.0) | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 554,307 |  |  | $ | 535,385 |  |  | $ | 18,922 |  |  | 3.5 | % |  |  |  |  |  |  |  |  |

[0000889331-25-000099:mdna:60]
[same as prior period, unchanged from 0000889331-24-000191:mdna:74]

[0000889331-25-000099:mdna:61]
Net sales increased $9.9 million, or 4.6%, in the first quarter of 2025 compared to the first quarter of 2024 and included unfavorable changes in foreign exchange rates of $0.6 million. The net sales increase was due to higher volume from the Industrial and Electronics segments, partially offset by lower volume from the passenger car product business within the Transportation segment.

[0000889331-25-000099:mdna:62]
[same as prior period, unchanged from 0000889331-24-000191:mdna:77]

[0000889331-25-000099:mdna:63]
Net sales increased $11.6 million, or 6.0%, in the first quarter of 2025 compared to the first quarter of 2024 and included unfavorable changes in foreign exchange rates of $2.6 million. The increase in net sales was primarily due to higher net sales from the electronics products business within the Electronics segment and higher net sales from passenger car products and the commercial vehicle businesses within the Transportation segment, partially offset by lower volume from the semiconductor business within the Electronics segment and the automotive sensor business within the Transportation segment.

[0000889331-25-000099:mdna:64]
[same as prior period, unchanged from 0000889331-24-000191:mdna:80]

[0000889331-25-000099:mdna:65]
Net sales decreased $2.6 million, or 2.0%, in the first quarter of 2025 compared to the first quarter of 2024 and included  unfavorable changes in foreign exchange rates of $3.4 million. The decrease in net sales was primarily due to unfavorable foreign exchange rate impact and lower net sales from the Transportation segment, partially offset by $10.2 million or 1.9% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment.

[0000889331-25-000099:mdna:66]
[same as prior period, unchanged from 0000889331-24-000191:mdna:83]

[0000889331-25-000099:mdna:67]
[same as prior period, unchanged from 0000889331-24-000191:mdna:84]

[0000889331-25-000099:mdna:68]
Cash and cash equivalents were $618.7 million as of March 29, 2025, a decrease of $106.2 million, as compared to December 28, 2024. As of March 29, 2025, $174.0 million of the Company's $618.7 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-25-000099:mdna:69]
Revolving Credit Facility and Term Loan

[0000889331-25-000099:mdna:70]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-25-000099:mdna:71]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-

[0000889331-25-000099:mdna:72]
month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-25-000099:mdna:73]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 29, 2025, the Company made term loan payments of $3.8 million. The revolving loan and term loan balance under the Credit Facility were $100.0 million and $277.5 million, respectively, as of March 29, 2025.

[0000889331-25-000099:mdna:74]
[same as prior period, unchanged from 0000889331-24-000191:mdna:90]

[0000889331-25-000099:mdna:75]
As of March 29, 2025, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 5.42%, and 4.13% on the hedged portion.

[0000889331-25-000099:mdna:76]
As of March 29, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of March 29, 2025, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-25-000099:mdna:77]
[same as prior period, unchanged from 0000889331-24-000191:mdna:93]

[0000889331-25-000099:mdna:78]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-25-000099:mdna:79]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-25-000099:mdna:80]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-25-000099:mdna:81]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-25-000099:mdna:82]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-25-000099:mdna:83]
The Senior Notes have not been registered under the Securities Act of 1933 ("Securities Act"), or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-25-000099:mdna:84]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage.

[0000889331-25-000099:mdna:85]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-25-000099:mdna:86]
Debt Covenants

[0000889331-25-000099:mdna:87]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of March 29, 2025 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2024. As of March 29, 2025, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-25-000099:mdna:88]
[same as prior period, unchanged from 0000889331-24-000191:mdna:101]

[0000889331-25-000099:mdna:89]
On December 31, 2024, the Company completed the acquisition of Dortmund Fab from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab was approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-25-000099:mdna:90]
[same as prior period, unchanged from 0000889331-24-000191:mdna:103]

[0000889331-25-000099:mdna:91]
During the first quarter of 2025, the Company paid quarterly dividends of $17.3 million to its shareholders. On April 30, 2025, the Company announced the declaration of a quarterly cash dividend of $0.70 per share payable on June 5, 2025 to stockholders of record as of May 22, 2025.

[0000889331-25-000099:mdna:92]
[same as prior period, unchanged from 0000889331-24-000191:mdna:105]

[0000889331-25-000099:mdna:93]
|  |  | First Three Months |
| (in thousands) |  | 2025 |  | 2024 |
| Net cash provided by operating activities |  | $ | 65,758 |  |  | $ | 57,150 |  |
| Net cash used in investing activities |  | (80,508) |  |  | (8,483) |  |
| Net cash used in financing activities |  | (97,034) |  |  | (33,520) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 5,603 |  |  | (8,550) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (106,181) |  |  | 6,597 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 726,437 |  |  | 557,123 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 620,256 |  |  | $ | 563,720 |  |

[0000889331-25-000099:mdna:94]
[same as prior period, unchanged from 0000889331-24-000191:mdna:107]

[0000889331-25-000099:mdna:95]
[same as prior period, unchanged from 0000889331-24-000191:mdna:108]

[0000889331-25-000099:mdna:96]
Net cash provided by operating activities was $65.8 million for the three months ended March 29, 2025 compared to $57.2 million for the three months ended March 30, 2024. The increase in net cash provided by operating activities was primarily due to reductions in working capital and higher cash earnings.

[0000889331-25-000099:mdna:97]
[same as prior period, unchanged from 0000889331-24-000191:mdna:110]

[0000889331-25-000099:mdna:98]
Net cash used in investing activities was $80.5 million for the three months ended March 29, 2025 compared to $8.5 million during the three months ended March 30, 2024. Net cash paid for the Dortmund Fab acquisition was $57.4 million during the three months ended March 29, 2025. Capital expenditures were $23.1 million, representing an increase of $7.6 million compared to the three months ended March 30, 2024. During the three months ended March 30, 2024, the Company received proceeds of $7.1 million from the sale of a building from the commercial vehicle business within the Transportation segment.

[0000889331-25-000099:mdna:99]
[same as prior period, unchanged from 0000889331-24-000191:mdna:112]

[0000889331-25-000099:mdna:100]
Net cash used in financing activities was $97.0 million for the three months ended March 29, 2025 compared to $33.5 million during the three months ended March 30, 2024. During the three months ended March 29, 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025 and made payments of $3.8 million on the term loan. During the three months ended March 30, 2024, the Company made payments of $1.9 million on the term loan. The Company paid dividends of $17.3 million and $16.2 million in the three months ended March 29, 2025 and March 30, 2024, respectively. Additionally, during the three months ended March 29, 2025 and March 30, 2024, the Company repurchased 120,689 shares of its common stock totaling $27.4 million and 70,280 shares of its common stock totaling $16.1 million, respectively.

[0000889331-25-000099:mdna:101]
[same as prior period, unchanged from 0000889331-24-000191:mdna:114]

[0000889331-25-000099:mdna:102]
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program") to replace its previous 2021 program. During the three months ended March 29, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. During the three months ended March 30, 2024, the Company repurchased 70,280 shares of its common stock totaling $16.1 million pursuant to the 2021 program.

[0000889331-25-000099:mdna:103]
[same as prior period, unchanged from 0000889331-24-000191:mdna:116]

[0000889331-25-000099:mdna:104]
As of March 29, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-25-000099:mdna:105]
[same as prior period, unchanged from 0000889331-24-000191:mdna:118]

[0000889331-25-000099:mdna:106]
[same as prior period, unchanged from 0000889331-24-000191:mdna:119]

[0000889331-25-000099:mdna:107]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 28, 2024. During the three months ended March 29, 2025, there were no significant changes in the application of critical accounting policies and estimates.
