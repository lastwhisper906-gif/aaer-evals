# LFUS 10-Q controls and the auditor's report


## item_4_controls

[0000889331-25-000099:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000889331-25-000099:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000889331-25-000099:item_4_controls:3]
Disclosure controls and procedures (as defined in Rules 13a-15(b) and 15d-15(e) under the Exchange Act) are designed to ensure that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in the SEC rules and forms, and that such information is accumulated and communicated to management, including the Company's Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0000889331-25-000099:item_4_controls:4]
In connection with the preparation of this report, management, under the supervision and with the participation of the Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of the Company's disclosure controls and procedures as of March 29, 2025. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer have concluded that, as of the quarter ended March 29, 2025, the Company's disclosure controls and procedures were not effective, because of the previously reported material weaknesses in internal control over financial reporting, as described below.

[0000889331-25-000099:item_4_controls:5]
Previously Reported Material Weaknesses in Internal Control over Financial Reporting

[0000889331-25-000099:item_4_controls:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Exchange Act Rule 13a-15(f) and 15d-15(f) based on the criteria established in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“the COSO Framework). As reported in our Form 10-K for the fiscal year ended December 28, 2024, we did not maintain effective internal control over financial reporting as of December 28, 2024 as a result of material weaknesses in the control environment and control activities areas. A material weakness (as defined in Rule 12b-2 under the Exchange Act) is a deficiency, or combination of deficiencies, in internal control over financial reporting such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. Refer to our 2024 Form 10-K for a description of our material weaknesses.

[0000889331-25-000099:item_4_controls:7]
Ongoing Remediation Efforts to Address Material Weaknesses

[0000889331-25-000099:item_4_controls:8]
Our material weaknesses were not remediated as of March 29, 2025. Our management team is committed to maintaining a strong internal control environment. The Company, with oversight from our Audit Committee of the Board of Directors, is taking comprehensive actions to remediate the material weaknesses. The Company has developed and is in the process of implementing its remediation plan, which will include the following steps:

[0000889331-25-000099:item_4_controls:9]
Control environment

[0000889331-25-000099:item_4_controls:10]
•recruiting of personnel with appropriate internal controls, and accounting knowledge and experience commensurate with our accounting and reporting requirements;

[0000889331-25-000099:item_4_controls:11]
•enhanced supervision of personnel at certain locations to ensure compliance with established Company policies; and

[0000889331-25-000099:item_4_controls:12]
•evaluating and updating (as appropriate) the sufficiency of policies and training provided to personnel to ensure the appropriate segregation of duties and adherence to the Code of Conduct.

[0000889331-25-000099:item_4_controls:13]
Control activities

[0000889331-25-000099:item_4_controls:14]
•augmentation of training and clear instruction as to the process for recording of adjustments to inventories;

[0000889331-25-000099:item_4_controls:15]
•full physical inventory observations, facilitated by independent counters, until the cycle count and related inventory existence controls at certain of our non-U.S. manufacturing locations are operating effectively;

[0000889331-25-000099:item_4_controls:16]
•implementation of a management review control over inventory movements;

[0000889331-25-000099:item_4_controls:17]
•examination and enhancement of the procedures to evaluate the completeness and accuracy of data and assumptions utilized in computing inventory reserves.

[0000889331-25-000099:item_4_controls:18]
We intend to remediate the material weaknesses as soon as possible; however, the material weaknesses will not be considered remediated until the applicable controls operate for a sufficient period of time and management has concluded, through testing, that the appropriate controls are operating effectively.

[0000889331-25-000099:item_4_controls:19]
Changes in Internal Control over Financial Reporting

[0000889331-25-000099:item_4_controls:20]
Other than the ongoing remediation efforts described above, there were no changes in the Company's internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15(f) and 15d-15(f) under the Exchange

[0000889331-25-000099:item_4_controls:21]
39

[0000889331-25-000099:item_4_controls:22]
Act that occurred during the quarter ended March 29, 2025 that have materially affected, or are reasonably likely to materially affect, the Company's internal control over financial reporting.
