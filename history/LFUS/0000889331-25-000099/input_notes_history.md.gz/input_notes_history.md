# LFUS note change history — 0000889331-24-000191 → 0000889331-25-000099


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-04-30):
[0000889331-25-000099:note_history:1]
As of March 29, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.
  (was, 2024-10-30, similarity 0.9878):
[0000889331-24-000191:note_history:1]
As of September 28, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

- changed (2025-04-30):
[0000889331-25-000099:note_history:2]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.
  (was, 2024-10-30, similarity 0.999):
[0000889331-24-000191:note_history:2]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

- changed (2025-04-30):
[0000889331-25-000099:note_history:3]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss, the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.
  (was, 2024-10-30, similarity 0.6315):
[0000889331-24-000191:note_history:3]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss and therefore the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.

- changed (2025-04-30):
[0000889331-25-000099:note_history:4]
There were no material pending litigation or claims outstanding as of March 29, 2025.
  (was, 2024-10-30, similarity 0.9193):
[0000889331-24-000191:note_history:4]
There are no material pending litigation or claims outstanding as of September 28, 2024.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-04-30):
[0000889331-25-000099:note_history:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2024, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2024-10-30, similarity 0.9949):
[0000889331-24-000191:note_history:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 30, 2023, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

- changed (2025-04-30):
[0000889331-25-000099:note_history:6]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 29, 2025 and March 30, 2024:
  (was, 2024-10-30, similarity 0.8975):
[0000889331-24-000191:note_history:6]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2024 and September 30, 2023:

- changed (2025-04-30):
[0000889331-25-000099:note_history:7]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |
  (was, 2024-10-30, similarity 0.683):
[0000889331-24-000191:note_history:7]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 191,523 |  |  | $ | — |  |  | $ | — |  |  | $ | 191,523 |  |  | $ | 598,813 |  |  | $ | — |  |  | $ | — |  |  | $ | 598,813 |  |
| Electronics – Passive Products and Sensors |  | 152,410 |  |  | — |  |  | — |  |  | 152,410 |  |  | 453,860 |  |  | — |  |  | — |  |  | 453,860 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  |  |  |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- changed (2025-04-30):
[0000889331-25-000099:note_history:8]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |
  (was, 2024-10-30, similarity 0.6702):
[0000889331-24-000191:note_history:8]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

- changed (2025-04-30):
[0000889331-25-000099:note_history:9]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 29, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2024-10-30, similarity 0.8966):
[0000889331-24-000191:note_history:9]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at September 28, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2025-04-30):
[0000889331-25-000099:note_history:10]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 618,687 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,569 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 620,256 |  |  | $ | 726,437 |  |
  (was, 2024-10-30, similarity 0.9252):
[0000889331-24-000191:note_history:10]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 629,670 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,623 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 631,293 |  |  | $ | 557,123 |  |

- added (2025-04-30):
[0000889331-25-000099:note_history:11]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements; (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively; (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.

- changed (2025-04-30):
[0000889331-25-000099:note_history:12]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify disclosures in the Company's Consolidated Financial Statements.
  (was, 2024-10-30, similarity 0.978):
[0000889331-24-000191:note_history:12]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

- changed (2025-04-30):
[0000889331-25-000099:note_history:13]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.
  (was, 2024-10-30, similarity 0.9901):
[0000889331-24-000191:note_history:13]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

- removed (2025-04-30):
[0000889331-24-000191:note_history:14]
Recently Adopted Accounting Standards

- removed (2025-04-30):
[0000889331-24-000191:note_history:15]
In March 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements." The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

- removed (2025-04-30):
[0000889331-24-000191:note_history:16]
In March 2024, the Securities and Exchange Commission ("SEC") issued a final rule that requires registrants to provide climate disclosures in annual reports and registration statements. The climate-related final rule requires disclosures in the footnotes to the financial statements, including: 1) specified financial statement effects of severe weather events and other natural conditions, 2) certain carbon offsets and renewable energy credits or certificates if used as a material component of a registrant's plans to achieve its disclosed climate-related targets or goals, 3) material impacts on financial estimates and assumptions in the financial statements if they would materially impacted by risks and uncertainties associated with severe weather events and other natural conditions, previously disclosed climate-related targets, and transition plans. The financial statement disclosure requirements are effective beginning with annual reports for the fiscal year beginning in calendar year 2025 for the Company as a large accelerated filer. These disclosures will be subject to existing audit requirement for financial statements. On April 4, 2024, the SEC chose to stay its climate disclosure rules pending judicial review. The adoption of this rule will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating and is in the process of performing its initial assessment of the potential impact on its Condensed Consolidated Financial Statements.

- removed (2025-04-30):
[0000889331-24-000191:note_history:17]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures." The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of the Chief Operating Decision Maker (“CODM”) on an annual basis as well as an explanation of how the CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-04-30):
[0000889331-25-000099:note_history:18]
The carrying amounts of debt at March 29, 2025 and December 28, 2024 were as follows:
  (was, 2024-10-30, similarity 0.915):
[0000889331-24-000191:note_history:18]
The carrying amounts of debt at September 28, 2024 and December 30, 2023 are as follows:

- changed (2025-04-30):
[0000889331-25-000099:note_history:19]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 277,500 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,557 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 3,163 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,530) |  |  | (2,766) |  |
| Total debt |  | 805,690 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,710) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 787,980 |  |  | $ | 788,502 |  |
  (was, 2024-10-30, similarity 0.9671):
[0000889331-24-000191:note_history:19]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,106 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 4,670 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,028) |  |  | (3,770) |  |
| Total debt |  | 867,748 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,799) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 799,949 |  |  | $ | 857,915 |  |

- changed (2025-04-30):
[0000889331-25-000099:note_history:20]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 29, 2025, the Company made term loan payments of $3.8 million. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $277.5 million, respectively, as of March 29, 2025.
  (was, 2024-10-30, similarity 0.9407):
[0000889331-24-000191:note_history:20]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the nine months ended September 28, 2024, the Company made payments of $3.8 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of September 28, 2024.

- changed (2025-04-30):
[0000889331-25-000099:note_history:21]
As of March 29, 2025, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 5.42%, and 4.13% on the hedged portion.
  (was, 2024-10-30, similarity 0.9686):
[0000889331-24-000191:note_history:21]
As of September 28, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.60%, and 4.13% on the hedged portion.

- changed (2025-04-30):
[0000889331-25-000099:note_history:22]
As of March 29, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of March 29, 2025, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2024-10-30, similarity 0.9):
[0000889331-24-000191:note_history:22]
As of September 28, 2024, the Company had $0.1 million outstanding letters of credit under the Credit Facility and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 28, 2024, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2025-04-30):
[0000889331-25-000099:note_history:23]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.
  (was, 2024-10-30, similarity 0.7818):
[0000889331-24-000191:note_history:23]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

- changed (2025-04-30):
[0000889331-25-000099:note_history:24]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.
  (was, 2024-10-30, similarity 0.9714):
[0000889331-24-000191:note_history:24]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- changed (2025-04-30):
[0000889331-25-000099:note_history:25]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.
  (was, 2024-10-30, similarity 0.7557):
[0000889331-24-000191:note_history:25]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

- changed (2025-04-30):
[0000889331-25-000099:note_history:26]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.
  (was, 2024-10-30, similarity 0.999):
[0000889331-24-000191:note_history:26]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

- changed (2025-04-30):
[0000889331-25-000099:note_history:27]
The Senior Notes have not been registered under the Securities Act of 1933 ("Securities Act"), or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.
  (was, 2024-10-30, similarity 0.9589):
[0000889331-24-000191:note_history:27]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

- changed (2025-04-30):
[0000889331-25-000099:note_history:28]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of March 29, 2025, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2024-10-30, similarity 0.9878):
[0000889331-24-000191:note_history:28]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of September 28, 2024, the Company was in compliance with all covenants under the Senior Notes.

- changed (2025-04-30):
[0000889331-25-000099:note_history:29]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
  (was, 2024-10-30, similarity 0.9903):
[0000889331-24-000191:note_history:29]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

- added (2025-04-30):
[0000889331-25-000099:note_history:30]
Interest paid on all Company debt was $12.2 million and $13.2 million for the three months ended March 29, 2025 and March 30, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.

- removed (2025-04-30):
[0000889331-24-000191:note_history:31]
Interest paid on all Company debt was $10.5 million and $11.9 million for the three months ended September 28, 2024 and September 30, 2023, respectively, and $30.1 million and $33.2 million for the nine months ended September 28, 2024 and September 30, 2023, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-04-30):
[0000889331-25-000099:note_history:32]
The carrying amounts of debt at March 29, 2025 and December 28, 2024 were as follows:
  (was, 2024-10-30, similarity 0.915):
[0000889331-24-000191:note_history:32]
The carrying amounts of debt at September 28, 2024 and December 30, 2023 are as follows:

- changed (2025-04-30):
[0000889331-25-000099:note_history:33]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 277,500 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,557 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 3,163 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,530) |  |  | (2,766) |  |
| Total debt |  | 805,690 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,710) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 787,980 |  |  | $ | 788,502 |  |
  (was, 2024-10-30, similarity 0.9671):
[0000889331-24-000191:note_history:33]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,106 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 4,670 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,028) |  |  | (3,770) |  |
| Total debt |  | 867,748 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,799) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 799,949 |  |  | $ | 857,915 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2025-04-30):
[0000889331-25-000099:note_history:34]
|  |  | Three Months Ended March 29, 2025 |  | Three Months Ended March 30, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.5 |  | 0.2 |  | 1.9 |  |  | 1.2 |  | 0.2 |  | 2.1 |  |
|  |  | March 29, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |

- removed (2025-04-30):
[0000889331-24-000191:note_history:35]
|  |  | Three Months Ended September 28, 2024 |  | Three Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.2 |  | 0.6 |  |  | 1.2 |  | 0.1 |  | 2.0 |  |
|  |  | Nine Months Ended September 28, 2024 |  | Nine Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | 1.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.0 |  | 0.6 |  | 3.5 |  |  | 3.3 |  | 0.3 |  | 7.6 |  |
|  |  | September 28, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.5 |  | $ | — |  | $ | 0.1 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2025-04-30):
[0000889331-25-000099:note_history:36]
|  |  | Three Months Ended March 29, 2025 |  | Three Months Ended March 30, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.5 |  | 0.2 |  | 1.9 |  |  | 1.2 |  | 0.2 |  | 2.1 |  |
|  |  | March 29, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |

- removed (2025-04-30):
[0000889331-24-000191:note_history:37]
|  |  | Three Months Ended September 28, 2024 |  | Three Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.2 |  | 0.6 |  |  | 1.2 |  | 0.1 |  | 2.0 |  |
|  |  | Nine Months Ended September 28, 2024 |  | Nine Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | 1.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.0 |  | 0.6 |  | 3.5 |  |  | 3.3 |  | 0.3 |  | 7.6 |  |
|  |  | September 28, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.5 |  | $ | — |  | $ | 0.1 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-04-30):
[0000889331-25-000099:note_history:38]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 29, 2025 and March 30, 2024:
  (was, 2024-10-30, similarity 0.8975):
[0000889331-24-000191:note_history:38]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2024 and September 30, 2023:

- changed (2025-04-30):
[0000889331-25-000099:note_history:39]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |
  (was, 2024-10-30, similarity 0.683):
[0000889331-24-000191:note_history:39]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 191,523 |  |  | $ | — |  |  | $ | — |  |  | $ | 191,523 |  |  | $ | 598,813 |  |  | $ | — |  |  | $ | — |  |  | $ | 598,813 |  |
| Electronics – Passive Products and Sensors |  | 152,410 |  |  | — |  |  | — |  |  | 152,410 |  |  | 453,860 |  |  | — |  |  | — |  |  | 453,860 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  |  |  |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- changed (2025-04-30):
[0000889331-25-000099:note_history:40]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |
  (was, 2024-10-30, similarity 0.6702):
[0000889331-24-000191:note_history:40]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |
