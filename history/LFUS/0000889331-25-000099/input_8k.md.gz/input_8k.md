# LFUS 8-K — 0000889331-25-000095 filed 2025-04-29

## item codes, every 8-K on or before 2025-04-30

- 2025-04-29 0000889331-25-000095 — 2.02, 7.01, 9.01
- 2025-04-28 0000889331-25-000082 — 5.02, 5.07, 9.01
- 2025-04-09 0001140361-25-012942 — 5.02, 7.01, 9.01
- 2025-01-28 0000889331-25-000013 — 2.02, 7.01, 9.01
- 2025-01-13 0001140361-25-000873 — 5.02, 9.01
- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2025-04-30

- 2025-02-27 0001140361-25-006294 — NT 10-K, for the period ended 2024-12-28
- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-25-000095:8k_2_02:1]
EX-99.1
2
q12025earningsreleaseex991.htm
EX-99.1

[0000889331-25-000095:8k_2_02:2]
Document

[0000889331-25-000095:8k_2_02:3]
Exhibit 99.1

[0000889331-25-000095:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0000889331-25-000095:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2025

[0000889331-25-000095:8k_2_02:6]
First Quarter 2025 Highlights:

[0000889331-25-000095:8k_2_02:7]
(Year-over-year comparisons unless otherwise noted)

[0000889331-25-000095:8k_2_02:8]
•Net sales of $554 million, +3.5%; organic growth contributed +2.9%

[0000889331-25-000095:8k_2_02:9]
•GAAP diluted earnings per share of $1.75

[0000889331-25-000095:8k_2_02:10]
•Adjusted diluted EPS of $2.19, +24%

[0000889331-25-000095:8k_2_02:11]
•Free cash flow of $43 million, +3%; Cash conversion of 98%

[0000889331-25-000095:8k_2_02:12]
•Returned $45m to shareholders via dividend and share repurchases

[0000889331-25-000095:8k_2_02:13]
CHICAGO, April 29, 2025  - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the first quarter ended March 29, 2025:

[0000889331-25-000095:8k_2_02:14]
“In the first quarter, we delivered results that exceeded our expectations, driven by solid Electronics Segment demand recovery and robust growth in our Industrial Segment,” said Greg Henderson, Littelfuse President and Chief Executive Officer. “Across our businesses, we drove improved bookings in the first quarter while our teams delivered strong operational performance, reflected in our expanded operating margin.  Into the second quarter, we are prepared to navigate an uncertain environment, supported by our flexible operating model, strong balance sheet, diversified end market and customer exposures, and seasoned global teams.”

[0000889331-25-000095:8k_2_02:15]
“While we are focused on executing through the current uncertain trade and economic landscape, we are not losing sight of our meaningful long-term opportunities. We have a history of strong and resilient profitability and cash flow that provide a solid foundation for future success. We are a leader in developing solutions that enable safe and efficient electrical energy transfer for our customers while our diverse end market exposures are aligned with secular growth trends. I am confident we are well positioned to deliver compelling long-term returns for our shareholders.”

[0000889331-25-000095:8k_2_02:16]
-more-

[0000889331-25-000095:8k_2_02:17]
Second Quarter of 2025*

[0000889331-25-000095:8k_2_02:18]
Based on current market conditions, for the second quarter the company expects,

[0000889331-25-000095:8k_2_02:19]
•Net sales in the range of $565 - $595 million, adjusted diluted EPS in the range of $2.10 – $2.40 and an adjusted effective tax rate of 23% - 25%

[0000889331-25-000095:8k_2_02:20]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-25-000095:8k_2_02:21]
Dividend

[0000889331-25-000095:8k_2_02:22]
•The company will pay a cash dividend on its common stock of $0.70 per share on June 5, 2025, to shareholders of record as of May 22, 2025

[0000889331-25-000095:8k_2_02:23]
Conference Call and Webcast Information

[0000889331-25-000095:8k_2_02:24]
Littelfuse will host a conference call on Wednesday, April 30, 2025, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-25-000095:8k_2_02:25]
About Littelfuse

[0000889331-25-000095:8k_2_02:26]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-25-000095:8k_2_02:27]
-more

[0000889331-25-000095:8k_2_02:28]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks, uncertainties and other factors include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of the Company's accounting policies; labor disputes and shortages; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; integration of acquisitions may not be achieved in a timely manner, or at all; limited realization of the expected benefits from investment and strategic plans; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended  December 28, 2024.

[0000889331-25-000095:8k_2_02:29]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 28, 2024, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-25-000095:8k_2_02:30]
-more

[0000889331-25-000095:8k_2_02:31]
Non-GAAP Financial Measures

[0000889331-25-000095:8k_2_02:32]
The information included in this press release includes the non-GAAP financial measures of organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-25-000095:8k_2_02:33]
LFUS-F

[0000889331-25-000095:8k_2_02:34]
###

[0000889331-25-000095:8k_2_02:35]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0000889331-25-000095:8k_2_02:36]
LITTELFUSE, INC.

[0000889331-25-000095:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-25-000095:8k_2_02:38]
|  |  | (Unaudited) |  |  |
| (in thousands, except share and per share data) |  | March 29,2025 |  | December 28,2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 618,687 |  |  | $ | 724,924 |  |
| Short-term investments |  | 984 |  |  | 976 |  |
| Trade receivables, less allowances of $69,244 and $69,990 at March 29, 2025 and December 28, 2024, respectively |  | 317,828 |  |  | 294,371 |  |
| Inventories |  | 417,102 |  |  | 416,273 |  |
| Prepaid income taxes and income taxes receivable |  | 8,245 |  |  | 11,749 |  |
| Prepaid expenses and other current assets |  | 70,238 |  |  | 103,716 |  |
| Total current assets |  | 1,433,084 |  |  | 1,552,009 |  |
| Net property, plant, and equipment |  | 510,336 |  |  | 477,068 |  |
| Intangible assets, net of amortization |  | 475,645 |  |  | 482,118 |  |
| Goodwill |  | 1,307,941 |  |  | 1,228,502 |  |
| Investments |  | 21,821 |  |  | 23,245 |  |
| Deferred income taxes |  | 5,581 |  |  | 4,899 |  |
| Right of use lease assets |  | 85,028 |  |  | 72,211 |  |
| Other long-term assets |  | 48,799 |  |  | 51,727 |  |
| Total assets |  | $ | 3,888,235 |  |  | $ | 3,891,779 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 176,450 |  |  | $ | 188,359 |  |
| Accrued liabilities |  | 139,815 |  |  | 148,276 |  |
| Accrued income taxes |  | 35,592 |  |  | 29,658 |  |
| Current portion of long-term debt |  | 17,710 |  |  | 67,612 |  |
| Total current liabilities |  | 369,567 |  |  | 433,905 |  |
| Long-term debt, less current portion |  | 787,980 |  |  | 788,502 |  |
| Deferred income taxes |  | 95,416 |  |  | 95,532 |  |
| Accrued post-retirement benefits |  | 30,751 |  |  | 29,836 |  |
| Non-current lease liabilities |  | 72,243 |  |  | 60,559 |  |
| Other long-term liabilities |  | 75,523 |  |  | 69,833 |  |
| Total equity |  | 2,456,755 |  |  | 2,413,612 |  |
| Total liabilities and equity |  | $ | 3,888,235 |  |  | $ | 3,891,779 |  |

[0000889331-25-000095:8k_2_02:39]
LITTELFUSE, INC.

[0000889331-25-000095:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-25-000095:8k_2_02:41]
(Unaudited)

[0000889331-25-000095:8k_2_02:42]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share data) |  | March 29,2025 |  | March 30,2024 |  |  |  |  |
| Net sales |  | $ | 554,307 |  |  | $ | 535,385 |  |  |  |  |  |
| Cost of sales |  | 347,051 |  |  | 347,577 |  |  |  |  |  |
| Gross profit |  | 207,256 |  |  | 187,808 |  |  |  |  |  |
| Selling, general, and administrative expenses |  | 87,708 |  |  | 86,127 |  |  |  |  |  |
| Research and development expenses |  | 26,048 |  |  | 27,667 |  |  |  |  |  |
| Amortization of intangibles |  | 14,331 |  |  | 15,825 |  |  |  |  |  |
| Restructuring, impairment, and other charges |  | 9,019 |  |  | 3,237 |  |  |  |  |  |
| Total operating expenses |  | 137,106 |  |  | 132,856 |  |  |  |  |  |
| Operating income |  | 70,150 |  |  | 54,952 |  |  |  |  |  |
| Interest expense |  | 8,875 |  |  | 9,611 |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 4,843 |  |  | (5,042) |  |  |  |  |  |
| Other income, net |  | (3,515) |  |  | (5,321) |  |  |  |  |  |
| Income before income taxes |  | 59,947 |  |  | 55,704 |  |  |  |  |  |
| Income taxes |  | 16,376 |  |  | 7,252 |  |  |  |  |  |
| Net income |  | $ | 43,571 |  |  | $ | 48,452 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.76 |  |  | $ | 1.95 |  |  |  |  |  |
| Diluted |  | $ | 1.75 |  |  | $ | 1.93 |  |  |  |  |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,767 |  |  | 24,911 |  |  |  |  |  |
| Diluted |  | 24,963 |  |  | 25,124 |  |  |  |  |  |
| Comprehensive income |  | $ | 81,168 |  |  | $ | 18,161 |  |  |  |  |  |

[0000889331-25-000095:8k_2_02:43]
LITTELFUSE, INC.

[0000889331-25-000095:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-25-000095:8k_2_02:45]
(Unaudited)

[0000889331-25-000095:8k_2_02:46]
|  |  | Three Months Ended |
| (in thousands) |  | March 29, 2025 |  | March 30, 2024 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 43,571 |  |  | $ | 48,452 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 37,658 |  |  | 28,729 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (14,745) |  |  | (12,723) |  |
| Inventories |  | 8,699 |  |  | 16,179 |  |
| Accounts payable |  | (8,772) |  |  | 345 |  |
| Accrued liabilities and income taxes |  | (8,044) |  |  | (28,042) |  |
| Prepaid expenses and other assets |  | 7,391 |  |  | 4,210 |  |
| Net cash provided by operating activities |  | 65,758 |  |  | 57,150 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (57,417) |  |  | — |  |
| Purchases of property, plant, and equipment |  | (23,102) |  |  | (15,547) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 11 |  |  | 7,064 |  |
| Net cash used in investing activities |  | (80,508) |  |  | (8,483) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (53,750) |  |  | (1,875) |  |
| Repurchases of common stock |  | (27,374) |  |  | (16,131) |  |
| Cash dividends paid |  | (17,335) |  |  | (16,200) |  |
| All other cash provided by financing activities |  | 1,425 |  |  | 686 |  |
| Net cash used in financing activities |  | (97,034) |  |  | (33,520) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 5,603 |  |  | (8,550) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (106,181) |  |  | 6,597 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 726,437 |  |  | 557,123 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 620,256 |  |  | $ | 563,720 |  |

[0000889331-25-000095:8k_2_02:47]
LITTELFUSE, INC.

[0000889331-25-000095:8k_2_02:48]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-25-000095:8k_2_02:49]
(Unaudited)

[0000889331-25-000095:8k_2_02:50]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2025 |  | 2024 |  |  |  | %(Decline) /Growth |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 307,249 |  |  | $ | 291,105 |  |  |  |  | 5.5 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 161,862 |  |  | 170,367 |  |  |  |  | (5.0) | % |  |  |  |  |  |  |  |  |
| Industrial |  | 85,196 |  |  | 73,913 |  |  |  |  | 15.3 | % |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 554,307 |  |  | $ | 535,385 |  |  |  |  | 3.5 | % |  |  |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 46,766 |  |  | $ | 37,803 |  |  |  |  | 23.7 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 18,917 |  |  | 16,206 |  |  |  |  | 16.7 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 13,074 |  |  | 4,796 |  |  |  |  | 172.6 | % |  |  |  |  |  |  |  |  |
| Other(a) |  | (8,607) |  |  | (3,853) |  |  |  |  | N.M. |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 70,150 |  |  | $ | 54,952 |  |  |  |  | 27.7 | % |  |  |  |  |  |  |  |  |
| Operating Margin |  | 12.7 | % |  | 10.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 8,875 |  |  | 9,611 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 4,843 |  |  | (5,042) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net |  | (3,515) |  |  | (5,321) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 59,947 |  |  | $ | 55,704 |  |  |  |  | 7.6 | % |  |  |  |  |  |  |  |  |

[0000889331-25-000095:8k_2_02:51]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-25-000095:8k_2_02:52]
N.M. - Not meaningful

[0000889331-25-000095:8k_2_02:53]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2025 |  | 2024 |  | %Growth |  |  |  |  |  |  |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 15.2 | % |  | 13.0 | % |  | 2.2 | % |  |  |  |  |  |  |
| Transportation |  | 11.7 | % |  | 9.5 | % |  | 2.2 | % |  |  |  |  |  |  |
| Industrial |  | 15.3 | % |  | 6.5 | % |  | 8.8 | % |  |  |  |  |  |  |

[0000889331-25-000095:8k_2_02:54]
LITTELFUSE, INC.

[0000889331-25-000095:8k_2_02:55]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-25-000095:8k_2_02:56]
(In millions of USD except per share amounts - unaudited)

[0000889331-25-000095:8k_2_02:57]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-25 |  | Q1-24 |  |  |  |  |
| GAAP diluted EPS |  | $ | 1.75 |  |  | $ | 1.93 |  |  |  |  |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.44 |  |  | (0.17) |  |  |  |  |  |
| Adjusted diluted EPS |  | $ | 2.19 |  |  | $ | 1.76 |  |  |  |  |  |

[0000889331-25-000095:8k_2_02:58]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q1-25 |  | Q1-24 |  |  |  |  |
| Acquisition-related and integration costs (a) |  | $ | 0.1 |  |  | $ | 0.9 |  |  |  |  |  |
| Purchase accounting inventory adjustments (b) |  | (0.5) |  |  | — |  |  |  |  |  |
| Restructuring, impairment and other charges (c) |  | 9.0 |  |  | 3.2 |  |  |  |  |  |
| Gain on sale of fixed assets (d) |  | — |  |  | (0.3) |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 8.6 |  |  | 3.8 |  |  |  |  |  |
| Other income, net (e) |  | — |  |  | 0.2 |  |  |  |  |  |
| Non-operating foreign exchange loss (gain) |  | 4.8 |  |  | (5.0) |  |  |  |  |  |
| Non-GAAP adjustments to income before income taxes |  | 13.4 |  |  | (1.0) |  |  |  |  |  |
| Income taxes (f) |  | 2.3 |  |  | 3.3 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | $ | 11.1 |  |  | $ | (4.3) |  |  |  |  |  |
| Total EPS impact |  | $ | 0.44 |  |  | $ | (0.17) |  |  |  |  |  |

[0000889331-25-000095:8k_2_02:59]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-25 |  | Q1-24 |  |  |  |  |
| Net income |  | $ | 43.6 |  |  | $ | 48.5 |  |  |  |  |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 16.4 |  |  | 7.3 |  |  |  |  |  |
| Interest expense |  | 8.9 |  |  | 9.6 |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 4.8 |  |  | (5.0) |  |  |  |  |  |
| Other income, net |  | (3.5) |  |  | (5.3) |  |  |  |  |  |
| GAAP operating income |  | $ | 70.2 |  |  | $ | 55.0 |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 8.6 |  |  | 3.8 |  |  |  |  |  |
| Adjusted operating income |  | $ | 78.8 |  |  | $ | 58.8 |  |  |  |  |  |
| Amortization of intangibles |  | 14.3 |  |  | 15.8 |  |  |  |  |  |
| Depreciation expense |  | 18.4 |  |  | 16.7 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 111.5 |  |  | $ | 91.3 |  |  |  |  |  |
| Net sales |  | $ | 554.3 |  |  | $ | 535.4 |  |  |  |  |  |
| Net income as a percentage of net sales |  | 7.9 | % |  | 9.1 | % |  |  |  |  |
| Operating margin |  | 12.7 | % |  | 10.3 | % |  |  |  |  |
| Adjusted operating margin |  | 14.2 | % |  | 11.0 | % |  |  |  |  |
| Adjusted EBITDA margin |  | 20.1 | % |  | 17.1 | % |  |  |  |  |

[0000889331-25-000095:8k_2_02:60]
| Adjusted EBITDA by Segment |  | Q1-25 |  | Q1-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 46.8 |  |  | $ | 18.9 |  |  | $ | 13.1 |  |  | $ | 37.8 |  |  | $ | 16.2 |  |  | $ | 4.8 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 9.8 |  |  | 3.3 |  |  | 1.2 |  |  | 9.8 |  |  | 3.4 |  |  | 2.6 |  |
| Add back depreciation |  | 11.4 |  |  | 5.5 |  |  | 1.5 |  |  | 10.0 |  |  | 5.3 |  |  | 1.4 |  |
| Adjusted EBITDA |  | $ | 68.0 |  |  | $ | 27.7 |  |  | $ | 15.8 |  |  | $ | 57.6 |  |  | $ | 24.9 |  |  | $ | 8.8 |  |
| Adjusted EBITDA Margin |  | 22.1 | % |  | 17.1 | % |  | 18.5 | % |  | 19.8 | % |  | 14.6 | % |  | 11.9 | % |

[0000889331-25-000095:8k_2_02:61]
| Net sales reconciliation |  | Q1-25 vs. Q1-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth (decline) |  | 6 | % |  | (5) | % |  | 15 | % |  | 4 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | — | % |  | — | % |  | 2 | % |
| FX impact |  | (1) | % |  | (1) | % |  | (1) | % |  | (1) | % |
| Organic net sales growth (decline) |  | 3 | % |  | (4) | % |  | 16 | % |  | 3 | % |

[0000889331-25-000095:8k_2_02:62]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-25 |  | Q1-24 |  |  |  |  |
| Income taxes |  | $ | 16.4 |  |  | $ | 7.3 |  |  |  |  |  |
| Effective rate |  | 27.3 | % |  | 13.0 | % |  |  |  |  |
| Non-GAAP adjustments - income taxes |  | 2.3 |  |  | 3.3 |  |  |  |  |  |
| Adjusted income taxes |  | $ | 18.7 |  |  | $ | 10.6 |  |  |  |  |  |
| Adjusted effective rate |  | 25.5 | % |  | 19.3 | % |  |  |  |  |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-25 |  | Q1-24 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 65.8 |  |  | $ | 57.1 |  |  |  |  |  |
| Less: Purchases of property, plant and equipment |  | (23.1) |  |  | (15.5) |  |  |  |  |  |
| Free cash flow |  | $ | 42.7 |  |  | $ | 41.6 |  |  |  |  |  |

[0000889331-25-000095:8k_2_02:63]
| Consolidated Total Debt |  | As of March 29, 2025 |
| Consolidated Total Debt |  | $ | 805.7 |  |
| Unamortized debt issuance costs |  | 2.5 |  |
| Finance lease liability |  | 0.2 |  |
| Consolidated funded indebtedness |  | 808.4 |  |
| Cash held in U.S. (up to $400 million) |  | 174.0 |
| Net debt |  | $ | 634.4 |  |
| Consolidated EBITDA |  | Twelve Months Ended March 29, 2025 |
| Net Income |  | $ | 95.1 |  |
| Interest expense |  | 38.0 |  |
| Income taxes |  | 60.8 |  |
| Depreciation |  | 70.1 |  |
| Amortization |  | 60.6 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 27.2 |  |
| Unrealized loss on investments |  | 1.1 |  |
| Impairment charges |  | 92.7 |  |
| Other |  | 24.8 |  |
| Consolidated EBITDA (1) |  | $ | 470.4 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.3x |

[0000889331-25-000095:8k_2_02:64]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2024 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-25-000095:8k_2_02:65]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-25-000095:8k_2_02:66]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-25-000095:8k_2_02:67]
Note: Total will not always foot due to rounding.

[0000889331-25-000095:8k_2_02:68]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-25-000095:8k_2_02:69]
(b) reflected in cost of sales.

[0000889331-25-000095:8k_2_02:70]
(c) reflected in restructuring, impairment and other charges.

[0000889331-25-000095:8k_2_02:71]
(d) 2024 amount reflected a gain of $0.3 million gain from the sale of a building within the Transportation segment.

[0000889331-25-000095:8k_2_02:72]
(e) 2024 amount reflected $0.2 million increase in coal mining reserves.

[0000889331-25-000095:8k_2_02:73]
(f) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-25-000095:8k_2_02:74]
###
