# LFUS 8-K — 0000889331-22-000020 filed 2022-05-03

## item codes, every 8-K on or before 2022-05-04

- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2022-05-04

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-22-000020:8k_2_02:1]
EX-99.1
2
q12022earningsreleaseex991.htm
EX-99.1

[0000889331-22-000020:8k_2_02:2]
Document

[0000889331-22-000020:8k_2_02:3]
Exhibit 99.1

[0000889331-22-000020:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-22-000020:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2022

[0000889331-22-000020:8k_2_02:6]
Record sales and earnings driven by strong worldwide execution and robust market demand

[0000889331-22-000020:8k_2_02:7]
CHICAGO, May 3, 2022  - Littelfuse, Inc. (NASDAQ: LFUS), an industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the first quarter ended April 2, 2022:

[0000889331-22-000020:8k_2_02:8]
•Net sales of $623.3 million were up 34% versus the prior year period, and up 22% organically

[0000889331-22-000020:8k_2_02:9]
•GAAP operating margin was 24.2%; adjusted operating margin was 25.6%

[0000889331-22-000020:8k_2_02:10]
•GAAP diluted EPS was $4.70; adjusted diluted EPS was $4.99, up 87% versus the prior year period

[0000889331-22-000020:8k_2_02:11]
•GAAP effective tax rate was 12.4% and the adjusted effective tax rate was 17.3%

[0000889331-22-000020:8k_2_02:12]
•Cash flow from operations was $51.7 million and free cash flow was $21.9 million

[0000889331-22-000020:8k_2_02:13]
•On April 8, the company announced it has entered into a definitive agreement to acquire C&K Switches, a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions, with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom; the company has annualized sales of over $200 million

[0000889331-22-000020:8k_2_02:14]
•On April 12, the company completed the acquisition of Embed, Ltd., a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets

[0000889331-22-000020:8k_2_02:15]
“We are off to a tremendous start this year, achieving strong revenue and EPS growth substantially above our expectations while continuing to outperform the markets we serve,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Our organic growth trajectory combined with our strategy-led acquisitions continue to strengthen and diversify our business. As a result of our persistent execution, we remain extremely well positioned to further capitalize on current and future growth opportunities within the global structural themes of sustainability, connectivity, and safety. We continue focusing on what we can control to drive our performance within a volatile market, which is reflected in our second quarter outlook of continued double-digit year-over-year growth.”

[0000889331-22-000020:8k_2_02:16]
-more-

[0000889331-22-000020:8k_2_02:17]
Second Quarter of 2022*

[0000889331-22-000020:8k_2_02:18]
Based on current market conditions, for the second quarter the company expects,

[0000889331-22-000020:8k_2_02:19]
•Net sales in the range of $594 to $608 million, the midpoint of which represents 15% growth over the prior year and 7% organic growth

[0000889331-22-000020:8k_2_02:20]
•Adjusted diluted EPS in the range of $3.95 to $4.11, the midpoint of which represents 18% growth over the prior year

[0000889331-22-000020:8k_2_02:21]
•An adjusted effective tax rate of approximately 16.5%

[0000889331-22-000020:8k_2_02:22]
•The company’s forecast includes an approximately 300 basis point year-over-year sales headwind from COVID-related lockdowns in China, as well as costs to support its operations and employees

[0000889331-22-000020:8k_2_02:23]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-22-000020:8k_2_02:24]
Dividend

[0000889331-22-000020:8k_2_02:25]
•The company will pay a cash dividend on its common stock of $0.53 per share on June 9, 2022, to shareholders of record as of May 26, 2022

[0000889331-22-000020:8k_2_02:26]
Conference Call and Webcast Information

[0000889331-22-000020:8k_2_02:27]
Littelfuse will host a conference call on Wednesday, May 4, 2022, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at  Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-22-000020:8k_2_02:28]
About Littelfuse

[0000889331-22-000020:8k_2_02:29]
Littelfuse (NASDAQ: LFUS) is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-22-000020:8k_2_02:30]
-more-

[0000889331-22-000020:8k_2_02:31]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse’s current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 1, 2022. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended January 1, 2022, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-22-000020:8k_2_02:32]
Non-GAAP Financial Measures

[0000889331-22-000020:8k_2_02:33]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, consolidated total gross debt, consolidated EBITDA (as defined in the private placement senior notes), and ratio of consolidated total gross debt to consolidated EBITDA. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-22-000020:8k_2_02:34]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules

[0000889331-22-000020:8k_2_02:35]
-more-

[0000889331-22-000020:8k_2_02:36]
The company believes that organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that consolidated total gross debt, consolidated EBITDA, and ratio of consolidated total gross debt to consolidated EBITDA are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-22-000020:8k_2_02:37]
CONTACT: Trisha Tuntland

[0000889331-22-000020:8k_2_02:38]
Head of Investor Relations

[0000889331-22-000020:8k_2_02:39]
(773) 628-2163

[0000889331-22-000020:8k_2_02:40]
LFUS-F

[0000889331-22-000020:8k_2_02:41]
###

[0000889331-22-000020:8k_2_02:42]
LITTELFUSE, INC.

[0000889331-22-000020:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-22-000020:8k_2_02:44]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 461,617 |  |  | $ | 478,473 |  |
| Short-term investments |  | 27 |  |  | 28 |  |
| Trade receivables, less allowances of $62,170 and $59,232 at April 2, 2022 and January 1, 2022, respectively |  | 319,457 |  |  | 275,192 |  |
| Inventories |  | 470,552 |  |  | 445,671 |  |
| Prepaid income taxes and income taxes receivable |  | 1,570 |  |  | 2,035 |  |
| Prepaid expenses and other current assets |  | 64,987 |  |  | 68,812 |  |
| Total current assets |  | 1,318,210 |  |  | 1,270,211 |  |
| Net property, plant, and equipment |  | 442,022 |  |  | 437,889 |  |
| Intangible assets, net of amortization |  | 391,855 |  |  | 407,126 |  |
| Goodwill |  | 926,732 |  |  | 929,790 |  |
| Investments |  | 34,372 |  |  | 39,211 |  |
| Deferred income taxes |  | 17,119 |  |  | 13,127 |  |
| Right of use lease assets, net |  | 37,579 |  |  | 29,616 |  |
| Other long-term assets |  | 25,279 |  |  | 24,734 |  |
| Total assets |  | $ | 3,193,168 |  |  | $ | 3,151,704 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 212,644 |  |  | $ | 222,039 |  |
| Accrued liabilities |  | 127,011 |  |  | 159,689 |  |
| Accrued income taxes |  | 25,689 |  |  | 27,905 |  |
| Current portion of long-term debt |  | — |  |  | 25,000 |  |
| Total current liabilities |  | 365,344 |  |  | 434,633 |  |
| Long-term debt, less current portion |  | 606,741 |  |  | 611,897 |  |
| Deferred income taxes |  | 80,686 |  |  | 81,289 |  |
| Accrued post-retirement benefits |  | 36,884 |  |  | 37,037 |  |
| Non-current operating lease liabilities |  | 29,511 |  |  | 22,305 |  |
| Other long-term liabilities |  | 73,350 |  |  | 71,023 |  |
| Total equity |  | 2,000,652 |  |  | 1,893,520 |  |
| Total liabilities and equity |  | $ | 3,193,168 |  |  | $ | 3,151,704 |  |

[0000889331-22-000020:8k_2_02:45]
LITTELFUSE, INC.

[0000889331-22-000020:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-22-000020:8k_2_02:47]
(Unaudited)

[0000889331-22-000020:8k_2_02:48]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share data) |  | April 2,2022 |  | March 27,2021 |  |  |  |  |
| Net sales |  | $ | 623,330 |  |  | $ | 463,794 |  |  |  |  |  |
| Cost of sales |  | 364,734 |  |  | 303,328 |  |  |  |  |  |
| Gross profit |  | 258,596 |  |  | 160,466 |  |  |  |  |  |
| Selling, general, and administrative expenses |  | 75,508 |  |  | 58,288 |  |  |  |  |  |
| Research and development expenses |  | 19,556 |  |  | 14,739 |  |  |  |  |  |
| Amortization of intangibles |  | 12,724 |  |  | 10,521 |  |  |  |  |  |
| Restructuring, impairment, and other charges |  | 218 |  |  | 437 |  |  |  |  |  |
| Total operating expenses |  | 108,006 |  |  | 83,985 |  |  |  |  |  |
| Operating income |  | 150,590 |  |  | 76,481 |  |  |  |  |  |
| Interest expense |  | 4,302 |  |  | 4,673 |  |  |  |  |  |
| Foreign exchange loss |  | 7,736 |  |  | 6,837 |  |  |  |  |  |
| Other expense (income), net |  | 4,427 |  |  | (7,737) |  |  |  |  |  |
| Income before income taxes |  | 134,125 |  |  | 72,708 |  |  |  |  |  |
| Income taxes |  | 16,607 |  |  | 14,995 |  |  |  |  |  |
| Net income |  | $ | 117,518 |  |  | $ | 57,713 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 4.76 |  |  | $ | 2.35 |  |  |  |  |  |
| Diluted |  | $ | 4.70 |  |  | $ | 2.32 |  |  |  |  |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,689 |  |  | 24,532 |  |  |  |  |  |
| Diluted |  | 24,981 |  |  | 24,892 |  |  |  |  |  |
| Comprehensive income |  | $ | 115,315 |  |  | $ | 52,842 |  |  |  |  |  |

[0000889331-22-000020:8k_2_02:49]
LITTELFUSE, INC.

[0000889331-22-000020:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-22-000020:8k_2_02:51]
(Unaudited)

[0000889331-22-000020:8k_2_02:52]
|  |  | Three Months Ended |
| (in thousands) |  | April 2, 2022 |  | March 27, 2021 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 117,518 |  |  | $ | 57,713 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 47,966 |  |  | 32,165 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (45,945) |  |  | (32,973) |  |
| Inventories |  | (30,879) |  |  | (6,152) |  |
| Accounts payable |  | (6,611) |  |  | 17,070 |  |
| Accrued liabilities and income taxes |  | (36,287) |  |  | (15,427) |  |
| Prepaid expenses and other assets |  | 5,969 |  |  | (2,230) |  |
| Net cash provided by operating activities |  | 51,731 |  |  | 50,166 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (109,852) |  |
| Purchases of property, plant, and equipment |  | (29,809) |  |  | (14,721) |  |
| Net proceeds from sale of property, plant, and equipment, and other |  | 21 |  |  | 2,553 |  |
| Net cash used in investing activities |  | (29,788) |  |  | (122,020) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments from credit facility |  | (25,000) |  |  | (30,000) |  |
| Cash dividends paid |  | (13,086) |  |  | (11,782) |  |
| All other cash provided by financing activities |  | 1,016 |  |  | 7,509 |  |
| Net cash used in financing activities |  | (37,070) |  |  | (34,273) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (2,738) |  |  | (4,101) |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (17,865) |  |  | (110,228) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 482,836 |  |  | 687,525 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 464,971 |  |  | $ | 577,297 |  |

[0000889331-22-000020:8k_2_02:53]
LITTELFUSE, INC.

[0000889331-22-000020:8k_2_02:54]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-22-000020:8k_2_02:55]
(Unaudited)

[0000889331-22-000020:8k_2_02:56]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2022 |  | 2021 |  |  |  | %Growth /(Decline) |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 365,821 |  |  | $ | 286,535 |  |  |  |  | 27.7 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 184,504 |  |  | 128,529 |  |  |  |  | 43.6 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 73,005 |  |  | 48,730 |  |  |  |  | 49.8 | % |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 623,330 |  |  | $ | 463,794 |  |  |  |  | 34.4 | % |  |  |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 120,577 |  |  | $ | 55,523 |  |  |  |  | 117.2 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 26,308 |  |  | 20,316 |  |  |  |  | 29.5 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 12,505 |  |  | 3,506 |  |  |  |  | 256.7 | % |  |  |  |  |  |  |  |  |
| Other(a) |  | (8,800) |  |  | (2,864) |  |  |  |  | N.M. |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 150,590 |  |  | $ | 76,481 |  |  |  |  | 96.9 | % |  |  |  |  |  |  |  |  |
| Operating Margin |  | 24.2 | % |  | 16.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 4,302 |  |  | 4,673 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange loss |  | 7,736 |  |  | 6,837 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expense (income), net |  | 4,427 |  |  | (7,737) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 134,125 |  |  | $ | 72,708 |  |  |  |  | 84.5 | % |  |  |  |  |  |  |  |  |

[0000889331-22-000020:8k_2_02:57]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-22-000020:8k_2_02:58]
N.M. - Not meaningful

[0000889331-22-000020:8k_2_02:59]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2022 |  | 2021 |  | %Growth /(Decline) |  |  |  |  |  |  |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 33.0 | % |  | 19.4 | % |  | 13.6 | % |  |  |  |  |  |  |
| Transportation |  | 14.3 | % |  | 15.8 | % |  | (1.5) | % |  |  |  |  |  |  |
| Industrial |  | 17.1 | % |  | 7.2 | % |  | 9.9 | % |  |  |  |  |  |  |

[0000889331-22-000020:8k_2_02:60]
LITTELFUSE, INC.

[0000889331-22-000020:8k_2_02:61]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-22-000020:8k_2_02:62]
(In millions of USD except per share amounts - unaudited)

[0000889331-22-000020:8k_2_02:63]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-22 |  | Q1-21 |  |  |  |  |
| GAAP diluted EPS |  | $ | 4.70 |  |  | $ | 2.32 |  |  |  |  |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.29 |  |  | 0.35 |  |  |  |  |  |
| Adjusted diluted EPS |  | $ | 4.99 |  |  | $ | 2.67 |  |  |  |  |  |

[0000889331-22-000020:8k_2_02:64]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q1-22 |  | Q1-21 |  |  |  |  |
| Acquisition-related and integration costs (a) |  | $ | 3.8 |  |  | $ | 0.8 |  |  |  |  |  |
| Purchase accounting inventory adjustments (b) |  | 4.8 |  |  | 3.5 |  |  |  |  |  |
| Restructuring, impairment and other charges (c) |  | 0.2 |  |  | 0.4 |  |  |  |  |  |
| Gain on sale of fixed assets (d) |  | — |  |  | (1.9) |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 8.8 |  |  | 2.8 |  |  |  |  |  |
| Non-operating foreign exchange loss |  | 7.7 |  |  | 6.8 |  |  |  |  |  |
| Non-GAAP adjustments to income before income taxes |  | 16.5 |  |  | 9.6 |  |  |  |  |  |
| Income taxes (e) |  | 9.5 |  |  | 0.8 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | $ | 7.0 |  |  | $ | 8.8 |  |  |  |  |  |
| Total EPS impact |  | $ | 0.29 |  |  | $ | 0.35 |  |  |  |  |  |

[0000889331-22-000020:8k_2_02:65]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-22 |  | Q1-21 |  |  |  |  |
| Net sales |  | $ | 623.3 |  |  | $ | 463.8 |  |  |  |  |  |
| GAAP operating income |  | 150.6 |  |  | $ | 76.5 |  |  |  |  |  |
| Add back non-GAAP adjustments |  | 8.8 |  |  | 2.8 |  |  |  |  |  |
| Adjusted operating income |  | $ | 159.4 |  |  | $ | 79.3 |  |  |  |  |  |
| Adjusted operating margin |  | 25.6 | % |  | 17.1 | % |  |  |  |  |
| Add back amortization |  | 12.7 |  |  | 10.5 |  |  |  |  |  |
| Add back depreciation |  | 15.6 |  |  | 13.7 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 187.7 |  |  | $ | 103.5 |  |  |  |  |  |
| Adjusted EBITDA margin |  | 30.1 | % |  | 22.3 | % |  |  |  |  |

[0000889331-22-000020:8k_2_02:66]
| Net sales reconciliation |  | Q1-22 vs. Q1-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 28 | % |  | 44 | % |  | 50 | % |  | 34 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | 44 | % |  | 19 | % |  | 14 | % |
| FX impact |  | (1) | % |  | (3) | % |  | (1) | % |  | (2) | % |
| Organic net sales growth |  | 29 | % |  | 3 | % |  | 32 | % |  | 22 | % |

[0000889331-22-000020:8k_2_02:67]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-22 |  | Q1-21 |  |  |  |  |
| Income taxes |  | $ | 16.6 |  |  | $ | 15.0 |  |  |  |  |  |
| Effective rate |  | 12.4 | % |  | 20.6 | % |  |  |  |  |
| Non-GAAP adjustments - income taxes |  | 9.5 |  |  | 0.8 |  |  |  |  |  |
| Adjusted income taxes |  | $ | 26.1 |  |  | $ | 15.8 |  |  |  |  |  |
| Adjusted effective rate |  | 17.3 | % |  | 19.2 | % |  |  |  |  |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-22 |  | Q1-21 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 51.7 |  |  | $ | 50.2 |  |  |  |  |  |
| Less: Purchases of property, plant and equipment |  | (29.8) |  |  | (14.7) |  |  |  |  |  |
| Free cash flow |  | $ | 21.9 |  |  | $ | 35.4 |  |  |  |  |  |

[0000889331-22-000020:8k_2_02:68]
| Consolidated Total Debt |  | As of April 2, 2022 |
| Consolidated total gross debt |  | $ | 609.6 |  |
| Unamortized debt issuance costs |  | (2.9) |  |
| Consolidated Total Debt |  | $ | 606.7 |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | Twelve Months Ended April 2, 2022 |
| Net Income |  | $ | 343.6 |  |
| Interest expense |  | 18.2 |  |
| Income taxes |  | 58.8 |  |
| Depreciation |  | 57.8 |  |
| Amortization |  | 44.9 |  |
| Non-cash additions (reductions): |  |  |
| Stock-based compensation expense |  | 20.1 |  |
| Non-cash pension settlement charge |  | 19.9 |  |
| Purchase accounting inventory step-up charge |  | 9.7 |  |
| Unrealized gain on investments |  | 3.5 |  |
| Impairment charges |  | — |  |
| Other |  | 21.0 |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (1) |  | $ | 597.5 |  |
| Ratio of Consolidated total gross debt to Consolidated EBITDA (as defined in Private Placement Senior Notes)* |  | 1.0x |

[0000889331-22-000020:8k_2_02:69]
* Our Private Placement Senior Notes, with maturities ranging from 2022 to 2030, contain a financial ratio covenant providing that if, as of the last day of each fiscal quarter, the ratio of Consolidated total gross debt at such time to Consolidated EBITDA for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Private Placement Senior Notes) is triggered.

[0000889331-22-000020:8k_2_02:70]
(1) Represents Consolidated EBITDA as defined in our Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-22-000020:8k_2_02:71]
Note: Total will not always foot due to rounding.

[0000889331-22-000020:8k_2_02:72]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-22-000020:8k_2_02:73]
(b) reflected in cost of sales.

[0000889331-22-000020:8k_2_02:74]
(c) reflected in restructuring, impairment and other charges.

[0000889331-22-000020:8k_2_02:75]
(d) reflected in SG&A. 2021 quarter-to-date included a $1.9 million gain from the sale of a building in the Electronics segment.

[0000889331-22-000020:8k_2_02:76]
(e) reflected the tax impact associated with the non-GAAP adjustments and the one-time net benefit of $7.2 million that resulted from the dissolution of one of the Company’s affiliates.

[0000889331-22-000020:8k_2_02:77]
###
