# LFUS 10-Q controls and the auditor's report


## item_4_controls

[0000889331-22-000022:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000889331-22-000022:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0000889331-22-000022:item_4_controls:3]
Disclosure controls and procedures (as defined in Rules 13a-15(b) and 15d-15(e) under the Exchange Act) are designed to ensure that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in the SEC rules and forms, and that such information is accumulated and communicated to management, including the Company's Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0000889331-22-000022:item_4_controls:4]
In connection with the preparation of this report, management, under the supervision and with the participation of the Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of the

[0000889331-22-000022:item_4_controls:5]
34

[0000889331-22-000022:item_4_controls:6]
Company's disclosure controls and procedures as of April 2, 2022. Based on that evaluation, the Company's Chief Executive Officer and Chief Financial Officer have concluded that, as of the quarter ended April 2, 2022, the Company's disclosure controls and procedures were effective.

[0000889331-22-000022:item_4_controls:7]
(b) Changes in Internal Control over Financial Reporting

[0000889331-22-000022:item_4_controls:8]
During the first quarter of 2022, the Company implemented a new consolidation and financial reporting software package to enhance the Company’s worldwide consolidation function. In connection with this implementation, the Company has modified the design, operation and documentation of its internal control processes impacted by the new software. Except as noted previously, there were no other changes in the Company's internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15(f) and 15d-15(f) under the Exchange Act that occurred during the quarter ended April 2, 2022 that have materially affected, or are reasonably likely to materially affect, the Company's internal control over financial reporting.
