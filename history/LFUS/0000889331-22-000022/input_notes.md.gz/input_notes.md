# LFUS notes — 0000889331-22-000022


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-22-000022:notes:1]
[same as prior period, unchanged from 0000889331-21-000067:notes:1]

[0000889331-22-000022:notes:2]
[same as prior period, unchanged from 0000889331-21-000067:notes:2]

[0000889331-22-000022:notes:3]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 17,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-22-000022:notes:4]
[same as prior period, unchanged from 0000889331-21-000067:notes:4]

[0000889331-22-000022:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended January 1, 2022 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-22-000022:notes:6]
[same as prior period, unchanged from 0000889331-21-000067:notes:6]

[0000889331-22-000022:notes:7]
[same as prior period, unchanged from 0000889331-21-000067:notes:7]

[0000889331-22-000022:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 2, 2022 and March 27, 2021:

[0000889331-22-000022:notes:9]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

[0000889331-22-000022:notes:10]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  |  |  |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

[0000889331-22-000022:notes:11]
[same as prior period, unchanged from 0000889331-21-000067:notes:11]

[0000889331-22-000022:notes:12]
[same as prior period, unchanged from 0000889331-21-000067:notes:12]

[0000889331-22-000022:notes:13]
[same as prior period, unchanged from 0000889331-21-000067:notes:13]

[0000889331-22-000022:notes:14]
[same as prior period, unchanged from 0000889331-21-000067:notes:14]

[0000889331-22-000022:notes:15]
[same as prior period, unchanged from 0000889331-21-000067:notes:15]

[0000889331-22-000022:notes:16]
[same as prior period, unchanged from 0000889331-21-000067:notes:16]

[0000889331-22-000022:notes:17]
[same as prior period, unchanged from 0000889331-21-000067:notes:17]

[0000889331-22-000022:notes:18]
[same as prior period, unchanged from 0000889331-21-000067:notes:18]

[0000889331-22-000022:notes:19]
[same as prior period, unchanged from 0000889331-21-000067:notes:19]

[0000889331-22-000022:notes:20]
[same as prior period, unchanged from 0000889331-21-000067:notes:20]

[0000889331-22-000022:notes:21]
[same as prior period, unchanged from 0000889331-21-000067:notes:21]

[0000889331-22-000022:notes:22]
[same as prior period, unchanged from 0000889331-21-000067:notes:22]

[0000889331-22-000022:notes:23]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at April 2, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-22-000022:notes:24]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Cash and cash equivalents |  | $ | 461,617 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 1,745 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,609 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 464,971 |  |  | $ | 482,836 |  |

[0000889331-22-000022:notes:25]
Recently Adopted Accounting Standards

[0000889331-22-000022:notes:26]
In November 2021, the Financial Accounting Standards Board ("FASB") issued ASU No. 2021-10, "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance". The standard, requires annual disclosures about transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy: 1) Information about the nature of the transactions and the related accounting policy used to account for the transactions; 2) The line items on the balance sheet and income statement that are affected by the transactions, and the amounts applicable to each financial statement line item; 3) Significant terms and conditions of the transactions, including commitments and contingencies. The guidance is effective for fiscal years beginning after December 15, 2021 with early adoption permitted. The adoption of ASU 2021-10 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

[0000889331-22-000022:notes:27]
Recently Issued Accounting Standards

[0000889331-22-000022:notes:28]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The Company does not expect a material impact from the adoption of this guidance on the Company's Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-22-000022:notes:29]
[same as prior period, unchanged from 0000889331-21-000067:notes:27]

[0000889331-22-000022:notes:30]
[same as prior period, unchanged from 0000889331-21-000067:notes:28]

[0000889331-22-000022:notes:31]
Carling Technologies

[0000889331-22-000022:notes:32]
On November 30, 2021, the Company completed the previously announced acquisition of Carling Technologies, Inc. (“Carling”), pursuant to the Stock Purchase Agreement, dated as of October 19, 2021. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle, marine and datacom/telecom infrastructure markets. At the time of acquisition, Carling had annualized sales of approximately $170 million. The business is headquartered in Plainville, Connecticut, with offices and facilities located around the world and is reported as

[0000889331-22-000022:notes:33]
part of the commercial vehicle business within the Company's Transportation segment. The purchase price for Carling Technologies was approximately $315.5 million subject to a working capital adjustment.

[0000889331-22-000022:notes:34]
The acquisition was funded with cash on hand. The total purchase consideration of $313.6 million, net of cash, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase consideration will be adjusted for an additional $0.5 million associated with the final working capital adjustment, which will be settled in the second quarter of 2022. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary areas that are not yet finalized relate to the completion of the valuations of certain property, plant and equipment and acquired income tax assets and liabilities. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-22-000022:notes:35]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Carling acquisition:

[0000889331-22-000022:notes:36]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 313,583 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 26,129 |  |
| Inventories | 56,657 |  |
| Other current assets | 3,454 |  |
| Property, plant, and equipment | 58,315 |  |
| Intangible assets | 125,890 |  |
| Goodwill | 97,553 |  |
| Other non-current assets | 4,007 |  |
| Current liabilities | (22,288) |  |
| Other non-current liabilities | (36,134) |  |
|  | $ | 313,583 |  |

[0000889331-22-000022:notes:37]
All Carling goodwill, other assets and liabilities were recorded in the Transportation segment and are reflected in the Americas, Europe and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Carling’s products and technology with the Company’s existing commercial vehicle products portfolio. Goodwill resulting from the Carling acquisition is not expected to be deductible for tax purposes.

[0000889331-22-000022:notes:38]
During the three months ended April 2, 2022, the Company made adjustments to reduce the fair value of fixed assets of $6.0 million, inventories of $0.8 million, net accounts receivable of $0.6 million and increase in accrued liabilities of $0.5 million. As a result of these adjustments along with a corresponding reduction of deferred tax liabilities of $1.6 million, goodwill was increased by $5.2 million.

[0000889331-22-000022:notes:39]
As required by purchase accounting rules, the Company recorded a $6.4 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of sales during the fourth quarter of 2021 and first quarter of 2022, as the acquired inventory was sold, and reflected as other non-segment costs. The Company recognized a non-cash charge of $4.8 million to cost of sales during the three months ended April 2, 2022.

[0000889331-22-000022:notes:40]
[same as prior period, unchanged from 0000889331-21-000067:notes:29]

[0000889331-22-000022:notes:41]
On January 28, 2021, the Company acquired Hartland Controls ("Hartland"), a manufacturer and leading supplier of electrical components used primarily in heating, ventilation, air conditioning (HVAC) and other industrial and control systems applications with annualized sales of approximately $70 million. The purchase price for Hartland was $111.0 million and the operations of Hartland are included in the Industrial segment.

[0000889331-22-000022:notes:42]
The total purchase consideration of $108.5 million, net of cash, cash equivalents, and restricted cash has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. The purchase consideration is subject to change for the final working capital adjustments. As of April 2, 2022, the Company had restricted cash of $1.7 million in an escrow account for general indemnification purposes.

[0000889331-22-000022:notes:43]
[same as prior period, unchanged from 0000889331-21-000067:notes:32]

[0000889331-22-000022:notes:44]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired, and restricted cash | $ | 108,516 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 12,915 |  |
| Inventories | 35,808 |  |
| Other current assets | 2,224 |  |
| Property, plant, and equipment | 6,296 |  |
| Intangible assets | 39,660 |  |
| Goodwill | 38,502 |  |
| Other non-current assets | 3,782 |  |
| Current liabilities | (24,861) |  |
| Other non-current liabilities | (5,810) |  |
|  | $ | 108,516 |  |

[0000889331-22-000022:notes:45]
[same as prior period, unchanged from 0000889331-21-000067:notes:34]

[0000889331-22-000022:notes:46]
The Company recorded a $6.8 million step-up of inventory to its fair value as of the acquisition date. The step-up was amortized as a non-cash charge to cost of sales during the first and second quarters of 2021, as the acquired inventory was sold, and is reflected as other non-segment costs. During the three months ended March 27, 2021, the Company recognized a charge of $3.5 million for the amortization of this fair value inventory step-up.

[0000889331-22-000022:notes:47]
During the three months ended March 27, 2021, the Company incurred approximately $0.7 million of legal and professional fees related to this acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-22-000022:notes:48]
[same as prior period, unchanged from 0000889331-21-000067:notes:38]

[0000889331-22-000022:notes:49]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company, Hartland and Carling as though the acquisitions had occurred as of December 29, 2019. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Hartland and Carling acquisitions occurred as of December 29, 2019 or of future consolidated operating results.

[0000889331-22-000022:notes:50]
|  |  | For the Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | April 2, 2022 |  | March 27, 2021 |  |  |  |  |
| Net sales |  | $ | 623,330 |  |  | $ | 517,399 |  |  |  |  |  |
| Income before income taxes |  | 138,894 |  |  | 78,595 |  |  |  |  |  |
| Net income |  | 121,238 |  |  | 62,573 |  |  |  |  |  |
| Net income per share — basic |  | 4.91 |  |  | 2.57 |  |  |  |  |  |
| Net income per share — diluted |  | 4.85 |  |  | 2.55 |  |  |  |  |  |

[0000889331-22-000022:notes:51]
[same as prior period, unchanged from 0000889331-21-000067:notes:41]

[0000889331-22-000022:notes:52]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | April 2, 2022 |  | March 27, 2021 |  |  |  |  |
| Amortization(a) |  | $ | — |  |  | $ | (2,601) |  |  |  |  |  |
| Depreciation |  | — |  |  | (43) |  |  |  |  |  |
| Transaction costs(b) |  | — |  |  | 707 |  |  |  |  |  |
| Amortization of inventory step-up(c) |  | 4,769 |  |  | 3,490 |  |  |  |  |  |
| Income tax expense of above items |  | (1,049) |  |  | (309) |  |  |  |  |  |

[0000889331-22-000022:notes:53]
(a)The amortization adjustment for the three months ended March 27, 2021 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-22-000022:notes:54]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three months ended March 27, 2021.

[0000889331-22-000022:notes:55]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during three months ended April 2, 2022 and the recognition of the amortization during  2020. The inventory step-up was amortized over four months as the inventory was sold.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-22-000022:notes:56]
[same as prior period, unchanged from 0000889331-21-000067:notes:46]

[0000889331-22-000022:notes:57]
The components of inventories at April 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000022:notes:58]
| (in thousands) |  | April 2, 2022 |  | January 1, 2022 |
| Raw materials |  | $ | 197,628 |  |  | $ | 168,409 |  |
| Work in process |  | 122,324 |  |  | 117,506 |  |
| Finished goods |  | 187,477 |  |  | 195,656 |  |
| Inventory reserves |  | (36,877) |  |  | (35,900) |  |
| Total |  | $ | 470,552 |  |  | $ | 445,671 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-22-000022:notes:59]
[same as prior period, unchanged from 0000889331-21-000067:notes:49]

[0000889331-22-000022:notes:60]
The components of net property, plant, and equipment at April 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000022:notes:61]
| (in thousands) |  | April 2, 2022 |  | January 1, 2022 |
| Land and land improvements |  | $ | 23,153 |  |  | $ | 23,470 |  |
| Building and building improvements |  | 177,453 |  |  | 151,297 |  |
| Machinery and equipment |  | 770,642 |  |  | 779,559 |  |
| Accumulated depreciation |  | (529,226) |  |  | (516,437) |  |
| Total |  | $ | 442,022 |  |  | $ | 437,889 |  |

[0000889331-22-000022:notes:62]
The Company recorded depreciation expense of $15.6 million and $13.7 million for the three months ended April 2, 2022 and March 27, 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-22-000022:notes:63]
[same as prior period, unchanged from 0000889331-21-000067:notes:53]

[0000889331-22-000022:notes:64]
Changes in the carrying value of goodwill by segment for the three months ended April 2, 2022 are as follows:

[0000889331-22-000022:notes:65]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net book value of goodwill as of January 1, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of January 1, 2022 |  | $ | 660,245 |  |  | $ | 228,555 |  |  | $ | 86,232 |  |  | $ | 975,032 |  |
| Accumulated impairment losses as of January 1, 2022 |  | — |  |  | (36,177) |  |  | (9,065) |  |  | (45,242) |  |
| Total |  | 660,245 |  |  | 192,378 |  |  | 77,167 |  |  | 929,790 |  |
| Changes during 2022: |  |  |  |  |  |  |  |  |
| Additions(a) |  | — |  |  | 5,187 |  |  | — |  |  | 5,187 |  |
| Currency translation |  | (6,746) |  |  | (1,610) |  |  | 111 |  |  | (8,245) |  |
| Net book value of goodwill as of April 2, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of April 2, 2022 |  | 653,499 |  |  | 231,733 |  |  | 86,517 |  |  | 971,749 |  |
| Accumulated impairment losses as of April 2, 2022 |  | — |  |  | (35,778) |  |  | $ | (9,239) |  |  | (45,017) |  |
| Total |  | $ | 653,499 |  |  | $ | 195,955 |  |  | $ | 77,278 |  |  | $ | 926,732 |  |

[0000889331-22-000022:notes:66]
(a) The additions resulted from the acquisition of Carling.

[0000889331-22-000022:notes:67]
The components of other intangible assets as of April 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000022:notes:68]
|  |  |  | As of April 2, 2022 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 19,562 |  |  | $ | 2,019 |  |  | $ | 17,543 |  |
| Patents, licenses and software |  |  | 163,214 |  |  | 103,649 |  |  | 59,565 |  |
| Distribution network |  |  | 43,239 |  |  | 40,991 |  |  | 2,248 |  |
| Customer relationships, trademarks, and tradenames |  |  | 483,872 |  |  | 171,373 |  |  | 312,499 |  |
| Total |  |  | $ | 709,887 |  |  | $ | 318,032 |  |  | $ | 391,855 |  |

[0000889331-22-000022:notes:69]
|  | As of January 1, 2022 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 19,542 |  |  | $ | 1,906 |  |  | $ | 17,636 |  |
| Patents, licenses and software | 164,556 |  |  | 101,307 |  |  | 63,249 |  |
| Distribution network | 43,361 |  |  | 40,591 |  |  | 2,770 |  |
| Customer relationships, trademarks, and tradenames | 487,710 |  |  | 164,239 |  |  | 323,471 |  |
| Total | $ | 715,169 |  |  | $ | 308,043 |  |  | $ | 407,126 |  |

[0000889331-22-000022:notes:70]
During the three months ended April 2, 2022 and March 27, 2021, the Company recorded amortization expense of $12.7 million and $10.5 million, respectively.

[0000889331-22-000022:notes:71]
Estimated annual amortization expense related to intangible assets with definite lives as of April 2, 2022 is as follows:

[0000889331-22-000022:notes:72]
| (in thousands) | Amount |
| 2022 | $ | 49,911 |  |
| 2023 | 45,302 |  |
| 2024 | 41,899 |  |
| 2025 | 41,426 |  |
| 2026 | 32,955 |  |
| 2027 and thereafter | 193,086 |  |
| Total | $ | 404,579 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-22-000022:notes:73]
[same as prior period, unchanged from 0000889331-21-000067:notes:67]

[0000889331-22-000022:notes:74]
The components of accrued liabilities as of April 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000022:notes:75]
| (in thousands) |  | April 2, 2022 |  | January 1, 2022 |
| Employee-related liabilities |  | $ | 55,410 |  |  | $ | 92,018 |  |
| Operating lease liability |  | 9,748 |  |  | 9,018 |  |
| Other non-income taxes |  | 6,252 |  |  | 4,280 |  |
| Professional services |  | 5,840 |  |  | 4,299 |  |
| Restructuring liability |  | 2,882 |  |  | 2,944 |  |
| Interest |  | 2,594 |  |  | 4,402 |  |
| Deferred revenue |  | 1,216 |  |  | 1,105 |  |
| Other |  | 43,069 |  |  | 41,623 |  |
| Total |  | $ | 127,011 |  |  | $ | 159,689 |  |

[0000889331-22-000022:notes:76]
[same as prior period, unchanged from 0000889331-21-000067:notes:70]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-22-000022:notes:77]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment and other charges for the three months ended April 2, 2022 and March 27, 2021 as follows:

[0000889331-22-000022:notes:78]
|  | Three months ended April 2, 2022 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 205 |  |  | $ | — |  |  | $ | — |  |  | $ | 205 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | — |  |  | 13 |  |  | — |  |  | 13 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 205 |  |  | 13 |  |  | — |  |  | 218 |  |  |  |  |  |  |  |  |  |
| Total | $ | 205 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 218 |  |  |  |  |  |  |  |  |  |

[0000889331-22-000022:notes:79]
|  | Three months ended March 27, 2021 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 257 |  |  | $ | — |  |  | $ | 163 |  |  | $ | 420 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | — |  |  | 17 |  |  | — |  |  | 17 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 257 |  |  | 17 |  |  | 163 |  |  | 437 |  |  |  |  |  |  |  |  |  |
| Total | $ | 257 |  |  | $ | 17 |  |  | $ | 163 |  |  | $ | 437 |  |  |  |  |  |  |  |  |  |

[0000889331-22-000022:notes:80]
2022

[0000889331-22-000022:notes:81]
For the three months ended April 2, 2022, the Company recorded total restructuring charges of $0.2 million, primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Electronics segment.

[0000889331-22-000022:notes:82]
[same as prior period, unchanged from 0000889331-21-000067:notes:74]

[0000889331-22-000022:notes:83]
For the three months ended March 27, 2021, the Company recorded total restructuring charges of $0.4 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Electronics and Industrial segments.

[0000889331-22-000022:notes:84]
The restructuring liability as of both April 2, 2022 and January 1, 2022 is $2.9 million. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in fiscal year 2022.


## us-gaap:DebtDisclosureTextBlock

[0000889331-22-000022:notes:85]
Debt

[0000889331-22-000022:notes:86]
The carrying amounts of debt at April 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000022:notes:87]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 129,478 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 105,132 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | — |  |  | — |  |
| Unamortized debt issuance costs |  | (2,869) |  |  | (3,087) |  |
| Total debt |  | 606,741 |  |  | 636,897 |  |
| Less: Current maturities |  | — |  |  | (25,000) |  |
| Total long-term debt |  | $ | 606,741 |  |  | $ | 611,897 |  |

[0000889331-22-000022:notes:88]
Revolving Credit Facility

[0000889331-22-000022:notes:89]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The balance under the facility was $100.0 million as of April 2, 2022.

[0000889331-22-000022:notes:90]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.71% on April 2, 2022.

[0000889331-22-000022:notes:91]
As of April 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of April 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-22-000022:notes:92]
Senior Notes

[0000889331-22-000022:notes:93]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-22-000022:notes:94]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is

[0000889331-22-000022:notes:95]
payable semiannually on February 15 and August 15, commencing August 15, 2017. During the three months ended April 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

[0000889331-22-000022:notes:96]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-22-000022:notes:97]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-22-000022:notes:98]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At April 2, 2022, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-22-000022:notes:99]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-22-000022:notes:100]
Interest paid on all Company debt was $6.0 million and $6.2 million for the three months ended April 2, 2022 and March 27, 2021, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-22-000022:notes:101]
[same as prior period, unchanged from 0000889331-21-000067:notes:95]

[0000889331-22-000022:notes:102]
[same as prior period, unchanged from 0000889331-21-000067:notes:96]

[0000889331-22-000022:notes:103]
[same as prior period, unchanged from 0000889331-21-000067:notes:97]

[0000889331-22-000022:notes:104]
[same as prior period, unchanged from 0000889331-21-000067:notes:98]

[0000889331-22-000022:notes:105]
[same as prior period, unchanged from 0000889331-21-000067:notes:99]

[0000889331-22-000022:notes:106]
[same as prior period, unchanged from 0000889331-21-000067:notes:100]

[0000889331-22-000022:notes:107]
[same as prior period, unchanged from 0000889331-21-000067:notes:101]

[0000889331-22-000022:notes:108]
[same as prior period, unchanged from 0000889331-21-000067:notes:102]

[0000889331-22-000022:notes:109]
[same as prior period, unchanged from 0000889331-21-000067:notes:103]

[0000889331-22-000022:notes:110]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 1 of the valuation hierarchy and recorded in Investments and Other long-term assets.

[0000889331-22-000022:notes:111]
[same as prior period, unchanged from 0000889331-21-000067:notes:107]

[0000889331-22-000022:notes:112]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value and recorded in Other long-term assets.

[0000889331-22-000022:notes:113]
There were no changes during the quarter ended April 2, 2022 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of April 2, 2022 and January 1, 2022, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-22-000022:notes:114]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of April 2, 2022:

[0000889331-22-000022:notes:115]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 12,476 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,476 |  |
| Investments in equity securities |  | 20,864 |  |  | — |  |  | — |  |  | 20,864 |  |
| Mutual funds |  | 15,546 |  |  | — |  |  | — |  |  | 15,546 |  |
| Total |  | $ | 48,886 |  |  | $ | — |  |  | $ | — |  |  | $ | 48,886 |  |

[0000889331-22-000022:notes:116]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of January 1, 2022:

[0000889331-22-000022:notes:117]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 12,475 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,475 |  |
| Investments in equity securities |  | 26,070 |  |  | — |  |  | — |  |  | 26,070 |  |
| Mutual funds |  | 15,021 |  |  | — |  |  | — |  |  | 15,021 |  |
| Total |  | $ | 53,566 |  |  | $ | — |  |  | $ | — |  |  | $ | 53,566 |  |

[0000889331-22-000022:notes:118]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving credit facilities’ fair values approximate book value at April 2, 2022 and January 1, 2022, as the rates on these borrowings are variable in nature.

[0000889331-22-000022:notes:119]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of April 2, 2022 and January 1, 2022 were as follows:

[0000889331-22-000022:notes:120]
|  |  | April 2, 2022 |  | January 1, 2022 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 129,478 |  |  | $ | 129,149 |  |  | $ | 132,444 |  |  | $ | 134,119 |  |
| Euro Senior Notes, Series B due 2028 |  | 105,132 |  |  | 101,072 |  |  | 107,540 |  |  | 110,837 |  |
| USD Senior Notes, Series A due 2022 |  | — |  |  | — |  |  | 25,000 |  |  | 25,055 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 98,501 |  |  | 100,000 |  |  | 104,828 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 49,284 |  |  | 50,000 |  |  | 51,720 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 122,010 |  |  | 125,000 |  |  | 131,837 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-22-000022:notes:121]
[same as prior period, unchanged from 0000889331-21-000067:notes:118]

[0000889331-22-000022:notes:122]
[same as prior period, unchanged from 0000889331-21-000067:notes:119]

[0000889331-22-000022:notes:123]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three months ended April 2, 2022 and March 27, 2021 were as follows:

[0000889331-22-000022:notes:124]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | April 2, 2022 |  | March 27, 2021 |  |  |  |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 768 |  |  | $ | 702 |  |  |  |  |  |
| Interest cost |  | 644 |  |  | 440 |  |  |  |  |  |
| Expected return on plan assets |  | (403) |  |  | (367) |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | 101 |  |  | 331 |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 1,110 |  |  | $ | 1,106 |  |  |  |  |  |

[0000889331-22-000022:notes:125]
The Company expects to make approximately $2.6 million of contributions to the plans and pay $1.8 million of benefits directly in 2022.
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.5 million for both the three months ended April 2, 2022 and March 27, 2021, respectively, in Cost of Sales and Other expense (income), net within the Condensed Consolidated Statements of Net Income. For the three months ended April 2, 2022 and March 27, 2021, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.1 million and $0.2 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-22-000022:notes:126]
Other Comprehensive (Loss) IncomeChanges in other comprehensive income (loss) by component were as follows:

[0000889331-22-000022:notes:127]
| (in thousands) |  | Three Months EndedApril 2, 2022 |  | Three Months EndedMarch 27, 2021 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 323 |  |  | $ | 13 |  |  | $ | 310 |  |  | $ | 506 |  |  | $ | 52 |  |  | $ | 454 |  |
| Foreign currency translation adjustments (1) |  | (3,215) |  |  | (702) |  |  | (2,513) |  |  | (5,325) |  |  | — |  |  | (5,325) |  |
| Total change in other comprehensive (loss) income |  | $ | (2,892) |  |  | $ | (689) |  |  | $ | (2,203) |  |  | $ | (4,819) |  |  | $ | 52 |  |  | $ | (4,871) |  |

[0000889331-22-000022:notes:128]
(1) The tax shown above within the foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries which have been previously taxed in the U.S. and are not permanently reinvested.

[0000889331-22-000022:notes:129]
The following tables set forth the changes in accumulated other comprehensive (loss) by component for the three months ended April 2, 2022 and March 27, 2021:

[0000889331-22-000022:notes:130]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive (loss) |
| Balance at January 1, 2022 |  | $ | (11,928) |  |  |  |  | $ | (61,535) |  |  | $ | (73,463) |  |
| Activity in the period |  | 310 |  |  |  |  | (2,513) |  |  | (2,203) |  |
| Balance at April 2, 2022 |  | $ | (11,618) |  |  |  |  | $ | (64,048) |  |  | $ | (75,666) |  |

[0000889331-22-000022:notes:131]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currency translation adjustment |  | Accumulated other comprehensive (loss) |
| Balance at December 26, 2020 |  | $ | (34,141) |  |  |  |  | $ | (57,016) |  |  | $ | (91,157) |  |
| Activity in the period |  | 454 |  |  |  |  | (5,325) |  |  | (4,871) |  |
| Balance at March 27, 2021 |  | $ | (33,687) |  |  |  |  | $ | (62,341) |  |  | $ | (96,028) |  |

[0000889331-22-000022:notes:132]
Amounts reclassified from accumulated other comprehensive (loss) to earnings for the three months ended April 2, 2022 and March 27, 2021 were as follows:

[0000889331-22-000022:notes:133]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | April 2, 2022 |  | March 27, 2021 |  |  |  |  |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 197 |  |  | $ | 504 |  |  |  |  |  |

[0000889331-22-000022:notes:134]
The Company recognizes the amortization of prior service costs in Other expense (income), net within the Condensed Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-22-000022:notes:135]
Income TaxesThe effective tax rate for the three months ended April 2, 2022 was 12.4%, compared to the effective tax rate for the three months ended March 27, 2021 of 20.6%. The effective tax rate for the first quarter of 2022 is lower than the effective tax rate for the comparable 2021 period, primarily due to a one-time deduction that resulted from the dissolution of one of the Company’s affiliates, which resulted in a net benefit of $7.2 million. The effective tax rate for the 2022 period is lower than the applicable U.S. statutory tax rate due to a one-time deduction that resulted from the dissolution of one of the Company’s affiliates, as well as the forecasted impact of income earned in lower tax jurisdictions. The effective tax rate for the comparable 2021 period is approximately the same as the applicable U.S. statutory tax rate.


## us-gaap:EarningsPerShareTextBlock

[0000889331-22-000022:notes:136]
[same as prior period, unchanged from 0000889331-21-000067:notes:135]

[0000889331-22-000022:notes:137]
[same as prior period, unchanged from 0000889331-21-000067:notes:136]

[0000889331-22-000022:notes:138]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | April 2, 2022 |  | March 27, 2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 117,518 |  |  | $ | 57,713 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,689 |  |  | 24,532 |  |  |  |  |  |
| Effect of dilutive securities |  | 292 |  |  | 360 |  |  |  |  |  |
| Diluted |  | 24,981 |  |  | 24,892 |  |  |  |  |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 4.76 |  |  | $ | 2.35 |  |  |  |  |  |
| Diluted earnings per share |  | $ | 4.70 |  |  | $ | 2.32 |  |  |  |  |  |

[0000889331-22-000022:notes:139]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 57,928 and 15 for the three months ended April 2, 2022 and March 27, 2021, respectively.

[0000889331-22-000022:notes:140]
[same as prior period, unchanged from 0000889331-21-000067:notes:139]

[0000889331-22-000022:notes:141]
On April 28, 2021, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program.

[0000889331-22-000022:notes:142]
The Company did not repurchase any shares of its common stock for the three months ended April 2, 2022, and March 27, 2021.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-22-000022:notes:143]
Related Party Transactions

[0000889331-22-000022:notes:144]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-22-000022:notes:145]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-22-000022:notes:146]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-22-000022:notes:147]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-22-000022:notes:148]
|  |  | Three Months Ended April 2, 2022 |  | Three Months Ended March 27, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.2 |  | 0.1 |  | 2.9 |  |  | 1.1 |  | 0.1 |  | 3.0 |  |
|  |  | April 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | — |  | — |  | 2.0 |  |  | — |  | — |  | 1.8 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-22-000022:notes:149]
[same as prior period, unchanged from 0000889331-21-000067:notes:147]

[0000889331-22-000022:notes:150]
The Company and its subsidiaries design, manufacture and sell component, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company reports its operations by the following segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-22-000022:notes:151]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it.  Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-22-000022:notes:152]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related infrastructure, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-22-000022:notes:153]
•Transportation Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicle, heavy-duty truck, off-road vehicle, material handling, agricultural, construction and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck, construction, agriculture, material handling and marine.

[0000889331-22-000022:notes:154]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), industrial controls (protection relays, contactors, and transformers) and temperature sensors for use in various applications such as renewable energy and energy storage systems, electric vehicle infrastructure, HVAC systems, industrial safety, non-residential construction, MRO, mining and industrial automation.

[0000889331-22-000022:notes:155]
[same as prior period, unchanged from 0000889331-21-000067:notes:154]

[0000889331-22-000022:notes:156]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | April 2, 2022 |  | March 27, 2021 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 365,821 |  |  | $ | 286,535 |  |  |  |  |  |
| Transportation |  | 184,504 |  |  | 128,529 |  |  |  |  |  |
| Industrial |  | 73,005 |  |  | 48,730 |  |  |  |  |  |
| Total net sales |  | $ | 623,330 |  |  | $ | 463,794 |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,393 |  |  | $ | 15,381 |  |  |  |  |  |
| Transportation |  | 10,744 |  |  | 7,073 |  |  |  |  |  |
| Industrial |  | 2,161 |  |  | 1,744 |  |  |  |  |  |
| Total depreciation and amortization |  | $ | 28,298 |  |  | $ | 24,198 |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 120,577 |  |  | $ | 55,523 |  |  |  |  |  |
| Transportation |  | 26,308 |  |  | 20,316 |  |  |  |  |  |
| Industrial |  | 12,505 |  |  | 3,506 |  |  |  |  |  |
| Other(a) |  | (8,800) |  |  | (2,864) |  |  |  |  |  |
| Total operating income |  | 150,590 |  |  | 76,481 |  |  |  |  |  |
| Interest expense |  | 4,302 |  |  | 4,673 |  |  |  |  |  |
| Foreign exchange loss |  | 7,736 |  |  | 6,837 |  |  |  |  |  |
| Other expense (income), net |  | 4,427 |  |  | (7,737) |  |  |  |  |  |
| Income before income taxes |  | $ | 134,125 |  |  | $ | 72,708 |  |  |  |  |  |

[0000889331-22-000022:notes:157]
(a) Included in “Other” Operating income for the first quarter of 2022 was $4.8 million of  purchase accounting inventory step-up charges, $3.8 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $0.2 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-22-000022:notes:158]
Included in “Other” Operating income for the 2021 first quarter was $3.5 million of purchase accounting inventory step-up charges, $0.8 million of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.4 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a gain of $1.9 million from the sale of a building within the Electronics segment.

[0000889331-22-000022:notes:159]
[same as prior period, unchanged from 0000889331-21-000067:notes:158]

[0000889331-22-000022:notes:160]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | April 2, 2022 |  | March 27, 2021 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 220,238 |  |  | $ | 130,931 |  |  |  |  |  |
| China |  | 164,782 |  |  | 139,158 |  |  |  |  |  |
| Other countries(a) |  | 238,310 |  |  | 193,705 |  |  |  |  |  |
| Total net sales |  | $ | 623,330 |  |  | $ | 463,794 |  |  |  |  |  |

[0000889331-22-000022:notes:161]
[same as prior period, unchanged from 0000889331-21-000067:notes:160]

[0000889331-22-000022:notes:162]
| (in thousands) |  | April 2, 2022 |  | January 1, 2022 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 65,163 |  |  | $ | 57,923 |  |
| China |  | 117,403 |  |  | 122,867 |  |
| Mexico |  | 107,120 |  |  | 107,283 |  |
| Germany |  | 38,044 |  |  | 39,055 |  |
| Philippines |  | 78,918 |  |  | 74,918 |  |
| Other countries(a) |  | 35,374 |  |  | 35,843 |  |
| Total long-lived assets |  | $ | 442,022 |  |  | $ | 437,889 |  |

[0000889331-22-000022:notes:163]
[same as prior period, unchanged from 0000889331-21-000067:notes:162]

[0000889331-22-000022:notes:164]
|  |  | Three Months Ended |
| (in thousands) |  | April 2, 2022 |  | March 27, 2021 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 3,174 |  |  | $ | 683 |  |
| China |  | 6,949 |  |  | 2,142 |  |
| Mexico |  | 7,918 |  |  | 6,121 |  |
| Germany |  | 918 |  |  | 593 |  |
| Philippines |  | 6,970 |  |  | 2,443 |  |
| Other countries(a) |  | 1,561 |  |  | 754 |  |
| Total additions to long-lived assets |  | $ | 27,490 |  |  | $ | 12,736 |  |

[0000889331-22-000022:notes:165]
[same as prior period, unchanged from 0000889331-21-000067:notes:164]


## us-gaap:SubsequentEventsTextBlock

[0000889331-22-000022:notes:166]
Subsequent eventsOn April 8, 2022, the Company announced that it had entered into a definitive agreement to acquire C&K Switches (“C&K”) for $540 million in cash, subject to a working capital adjustment. Founded in 1928, C&K Switches is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is headquartered in Waltham, Massachusetts, with facilities located around the world and will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close during the second quarter of 2022. The Company expects to finance the transaction through a combination of cash on hand and debt.On April 12, 2022, the Company acquired Embed Ltd. (“Embed”).  Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets. The business is headquartered in Coventry, United Kingdom, and will be included in the Commercial Vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand.
