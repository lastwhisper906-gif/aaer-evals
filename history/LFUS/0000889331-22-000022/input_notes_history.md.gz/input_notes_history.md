# LFUS note change history — 0000889331-21-000067 → 0000889331-22-000022


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-05-04):
[0000889331-22-000022:note_history:1]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 17,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

- changed (2022-05-04):
[0000889331-22-000022:note_history:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended January 1, 2022 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2021-10-27, similarity 0.7346):
[0000889331-21-000067:note_history:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 26, 2020 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

- changed (2022-05-04):
[0000889331-22-000022:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 2, 2022 and March 27, 2021:
  (was, 2021-10-27, similarity 0.8975):
[0000889331-21-000067:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 25, 2021 and September 26, 2020:

- added (2022-05-04):
[0000889331-22-000022:note_history:4]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

- added (2022-05-04):
[0000889331-22-000022:note_history:5]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  |  |  |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

- changed (2022-05-04):
[0000889331-22-000022:note_history:6]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at April 2, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2021-10-27, similarity 0.922):
[0000889331-21-000067:note_history:6]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at September 25, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2022-05-04):
[0000889331-22-000022:note_history:7]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Cash and cash equivalents |  | $ | 461,617 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 1,745 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,609 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 464,971 |  |  | $ | 482,836 |  |
  (was, 2021-10-27, similarity 0.8267):
[0000889331-21-000067:note_history:7]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 690,682 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,483 |  |  | — |  |
| Restricted cash included in other assets |  | 1,704 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 695,869 |  |  | $ | 687,525 |  |

- added (2022-05-04):
[0000889331-22-000022:note_history:8]
In November 2021, the Financial Accounting Standards Board ("FASB") issued ASU No. 2021-10, "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance". The standard, requires annual disclosures about transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy: 1) Information about the nature of the transactions and the related accounting policy used to account for the transactions; 2) The line items on the balance sheet and income statement that are affected by the transactions, and the amounts applicable to each financial statement line item; 3) Significant terms and conditions of the transactions, including commitments and contingencies. The guidance is effective for fiscal years beginning after December 15, 2021 with early adoption permitted. The adoption of ASU 2021-10 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

- added (2022-05-04):
[0000889331-22-000022:note_history:9]
Recently Issued Accounting Standards

- added (2022-05-04):
[0000889331-22-000022:note_history:10]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The Company does not expect a material impact from the adoption of this guidance on the Company's Condensed Consolidated Financial Statements.

- removed (2022-05-04):
[0000889331-21-000067:note_history:11]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 12,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

- removed (2022-05-04):
[0000889331-21-000067:note_history:12]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  | — |  |  | — |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:13]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:14]
In December 2019, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update ("ASU") No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000889331-22-000022:note_history:15]
The carrying amounts of debt at April 2, 2022 and January 1, 2022 are as follows:
  (was, 2021-10-27, similarity 0.8477):
[0000889331-21-000067:note_history:15]
The carrying amounts of debt at September 25, 2021 and December 26, 2020 are as follows:

- added (2022-05-04):
[0000889331-22-000022:note_history:16]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 129,478 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 105,132 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | — |  |  | — |  |
| Unamortized debt issuance costs |  | (2,869) |  |  | (3,087) |  |
| Total debt |  | 606,741 |  |  | 636,897 |  |
| Less: Current maturities |  | — |  |  | (25,000) |  |
| Total long-term debt |  | $ | 606,741 |  |  | $ | 611,897 |  |

- changed (2022-05-04):
[0000889331-22-000022:note_history:17]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The balance under the facility was $100.0 million as of April 2, 2022.
  (was, 2021-10-27, similarity 0.9185):
[0000889331-21-000067:note_history:17]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the nine months ended September 25, 2021. The balance under the facility was $100.0 million as of September 25, 2021.

- changed (2022-05-04):
[0000889331-22-000022:note_history:18]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.71% on April 2, 2022.
  (was, 2021-10-27, similarity 0.9855):
[0000889331-21-000067:note_history:18]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.33% on September 25, 2021.

- changed (2022-05-04):
[0000889331-22-000022:note_history:19]
As of April 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of April 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2021-10-27, similarity 0.9405):
[0000889331-21-000067:note_history:19]
As of September 25, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of of September 25, 2021, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2022-05-04):
[0000889331-22-000022:note_history:20]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is
  (was, 2021-10-27, similarity 0.7555):
[0000889331-21-000067:note_history:20]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in

- added (2022-05-04):
[0000889331-22-000022:note_history:21]
payable semiannually on February 15 and August 15, commencing August 15, 2017. During the three months ended April 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

- changed (2022-05-04):
[0000889331-22-000022:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At April 2, 2022, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2021-10-27, similarity 0.9878):
[0000889331-21-000067:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 25, 2021, the Company was in compliance with all covenants under the Senior Notes.

- changed (2022-05-04):
[0000889331-22-000022:note_history:23]
Interest paid on all Company debt was $6.0 million and $6.2 million for the three months ended April 2, 2022 and March 27, 2021, respectively.
  (was, 2021-10-27, similarity 0.6011):
[0000889331-21-000067:note_history:23]
Interest paid on all Company debt was $6.1 million and $6.4 million for the three months ended September 25, 2021 and September 26, 2020, respectively, and $14.8 million and $17.2 million for the nine months ended September 25, 2021 and September 26, 2020, respectively.

- removed (2022-05-04):
[0000889331-21-000067:note_history:24]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 137,173 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,441) |  |  | (4,114) |  |
| Total debt |  | 647,731 |  |  | 687,034 |  |
| Less: Current maturities |  | (27,619) |  |  | — |  |
| Total long-term debt |  | $ | 620,112 |  |  | $ | 687,034 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:25]
aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- removed (2022-05-04):
[0000889331-21-000067:note_history:26]
Debt

- removed (2022-05-04):
[0000889331-21-000067:note_history:27]
The carrying amounts of debt at September 25, 2021 and December 26, 2020 are as follows:

- removed (2022-05-04):
[0000889331-21-000067:note_history:28]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 137,173 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,441) |  |  | (4,114) |  |
| Total debt |  | 647,731 |  |  | 687,034 |  |
| Less: Current maturities |  | (27,619) |  |  | — |  |
| Total long-term debt |  | $ | 620,112 |  |  | $ | 687,034 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:29]
Revolving Credit Facility

- removed (2022-05-04):
[0000889331-21-000067:note_history:30]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the nine months ended September 25, 2021. The balance under the facility was $100.0 million as of September 25, 2021.

- removed (2022-05-04):
[0000889331-21-000067:note_history:31]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.33% on September 25, 2021.

- removed (2022-05-04):
[0000889331-21-000067:note_history:32]
As of September 25, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of of September 25, 2021, the Company was in compliance with all covenants under the Credit Agreement.

- removed (2022-05-04):
[0000889331-21-000067:note_history:33]
Senior Notes

- removed (2022-05-04):
[0000889331-21-000067:note_history:34]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

- removed (2022-05-04):
[0000889331-21-000067:note_history:35]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in

- removed (2022-05-04):
[0000889331-21-000067:note_history:36]
aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- removed (2022-05-04):
[0000889331-21-000067:note_history:37]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

- removed (2022-05-04):
[0000889331-21-000067:note_history:38]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

- removed (2022-05-04):
[0000889331-21-000067:note_history:39]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 25, 2021, the Company was in compliance with all covenants under the Senior Notes.

- removed (2022-05-04):
[0000889331-21-000067:note_history:40]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

- removed (2022-05-04):
[0000889331-21-000067:note_history:41]
Interest paid on all Company debt was $6.1 million and $6.4 million for the three months ended September 25, 2021 and September 26, 2020, respectively, and $14.8 million and $17.2 million for the nine months ended September 25, 2021 and September 26, 2020, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000889331-22-000022:note_history:42]
The carrying amounts of debt at April 2, 2022 and January 1, 2022 are as follows:
  (was, 2021-10-27, similarity 0.8477):
[0000889331-21-000067:note_history:42]
The carrying amounts of debt at September 25, 2021 and December 26, 2020 are as follows:

- added (2022-05-04):
[0000889331-22-000022:note_history:43]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 129,478 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 105,132 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | — |  |  | — |  |
| Unamortized debt issuance costs |  | (2,869) |  |  | (3,087) |  |
| Total debt |  | 606,741 |  |  | 636,897 |  |
| Less: Current maturities |  | — |  |  | (25,000) |  |
| Total long-term debt |  | $ | 606,741 |  |  | $ | 611,897 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:44]
| (in thousands) |  | September 25,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 137,173 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,380 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,441) |  |  | (4,114) |  |
| Total debt |  | 647,731 |  |  | 687,034 |  |
| Less: Current maturities |  | (27,619) |  |  | — |  |
| Total long-term debt |  | $ | 620,112 |  |  | $ | 687,034 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-05-04):
[0000889331-22-000022:note_history:45]
|  |  | Three Months Ended April 2, 2022 |  | Three Months Ended March 27, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.2 |  | 0.1 |  | 2.9 |  |  | 1.1 |  | 0.1 |  | 3.0 |  |
|  |  | April 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | — |  | — |  | 2.0 |  |  | — |  | — |  | 1.8 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:46]
|  |  | For the Three Months Ended September 25, 2021 |  | For the Three Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | 0.1 |  | 3.1 |  |  | 0.8 |  | — |  | 2.4 |  |
|  |  | For the Nine Months Ended September 25, 2021 |  | For the Nine Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 1.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.6 |  | 0.3 |  | 8.9 |  |  | 1.8 |  | — |  | 5.8 |  |
|  |  | September 25, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 2.1 |  |  | 0.1 |  | — |  | 0.2 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-05-04):
[0000889331-22-000022:note_history:47]
|  |  | Three Months Ended April 2, 2022 |  | Three Months Ended March 27, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.2 |  | 0.1 |  | 2.9 |  |  | 1.1 |  | 0.1 |  | 3.0 |  |
|  |  | April 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | — |  | — |  | 2.0 |  |  | — |  | — |  | 1.8 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:48]
|  |  | For the Three Months Ended September 25, 2021 |  | For the Three Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | 0.1 |  | 3.1 |  |  | 0.8 |  | — |  | 2.4 |  |
|  |  | For the Nine Months Ended September 25, 2021 |  | For the Nine Months Ended September 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 1.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.6 |  | 0.3 |  | 8.9 |  |  | 1.8 |  | — |  | 5.8 |  |
|  |  | September 25, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 2.1 |  |  | 0.1 |  | — |  | 0.2 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000889331-22-000022:note_history:49]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 2, 2022 and March 27, 2021:
  (was, 2021-10-27, similarity 0.8975):
[0000889331-21-000067:note_history:49]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 25, 2021 and September 26, 2020:

- added (2022-05-04):
[0000889331-22-000022:note_history:50]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

- added (2022-05-04):
[0000889331-22-000022:note_history:51]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  |  |  |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:52]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  | — |  |  | — |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- removed (2022-05-04):
[0000889331-21-000067:note_history:53]
|  |  | Three Months Ended September 26, 2020 |  | Nine Months Ended September 26, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,253 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,253 |  |  | $ | 285,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 285,697 |  |
| Electronics – Semiconductor |  | 147,096 |  |  | — |  |  | — |  |  | 147,096 |  |  | 407,112 |  |  | — |  |  | — |  |  | 407,112 |  |
| Passenger Car Products |  | — |  |  | 52,691 |  |  | — |  |  | 52,691 |  |  | — |  |  | 135,645 |  |  | — |  |  | 135,645 |  |
| Automotive Sensors |  | — |  |  | 26,093 |  |  | — |  |  | 26,093 |  |  | — |  |  | 64,166 |  |  | — |  |  | 64,166 |  |
| Commercial Vehicle Products |  | — |  |  | 25,940 |  |  | — |  |  | 25,940 |  |  | — |  |  | 71,682 |  |  | — |  |  | 71,682 |  |
| Industrial Products |  | — |  |  | — |  |  | 31,493 |  |  | 31,493 |  |  | — |  |  | — |  |  | 80,697 |  |  | 80,697 |  |
| Total |  | $ | 255,349 |  |  | $ | 104,724 |  |  | $ | 31,493 |  |  | $ | 391,566 |  |  | $ | 692,809 |  |  | $ | 271,493 |  |  | $ | 80,697 |  |  | $ | 1,044,999 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-05-04):
[0000889331-22-000022:note_history:54]
Subsequent eventsOn April 8, 2022, the Company announced that it had entered into a definitive agreement to acquire C&K Switches (“C&K”) for $540 million in cash, subject to a working capital adjustment. Founded in 1928, C&K Switches is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is headquartered in Waltham, Massachusetts, with facilities located around the world and will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close during the second quarter of 2022. The Company expects to finance the transaction through a combination of cash on hand and debt.On April 12, 2022, the Company acquired Embed Ltd. (“Embed”).  Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets. The business is headquartered in Coventry, United Kingdom, and will be included in the Commercial Vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand.

- removed (2022-05-04):
[0000889331-21-000067:note_history:55]
Subsequent eventOn October 20, 2021, the Company announced that it had entered into a definitive agreement to acquire Carling Technologies, Inc. (“Carling”) for $315 million in cash, subject to a working capital adjustment. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle, marine and datacom/telecom infrastructure markets. The business is headquartered in Plainville, Connecticut, with offices and facilities located around the world and will be reported as part of the commercial vehicle business within our Automotive segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close in the fourth quarter of 2021.
