# LFUS MD&A — 0000889331-22-000022


## mdna

[0000889331-22-000022:mdna:1]
[same as prior period, unchanged from 0000889331-21-000067:mdna:1]

[0000889331-22-000022:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-22-000022:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended January 1, 2022.

[0000889331-22-000022:mdna:4]
Management’s Discussion and Analysis of Financial Condition and Results of Operations ("MD&A") is designed to provide information that is supplemental to, and should be read together with, the consolidated financial statements and the accompanying notes. Information in MD&A is intended to assist the reader in obtaining an understanding of (i) the consolidated financial statements, (ii) the changes in certain key items within those financial statements from year-to-year, (iii) the primary factors that contributed to those changes, and (iv) any changes in known trends or uncertainties that the Company is aware of and that may have a material effect on future performance. In addition, MD&A provides information about the Company’s segments and how the results of those segments impact the results of operations and financial condition as a whole.

[0000889331-22-000022:mdna:5]
[same as prior period, unchanged from 0000889331-21-000067:mdna:5]

[0000889331-22-000022:mdna:6]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-22-000022:mdna:7]
The Company maintains a network of global laboratories and engineering centers that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company conducts its business through three reportable segments: Electronics, Transportation, and Industrial. Within these segments, the Company designs, manufactures and sells components and modules empowering a sustainable, connected, and safer world. Our products protect against electrostatic discharge, power surges, short circuits, voltage spikes and other harmful occurrences, safely and efficiently control power and improve productivity and are used to identify and detect temperature, proximity, flow speed and fluid level in various applications.

[0000889331-22-000022:mdna:8]
[same as prior period, unchanged from 0000889331-21-000067:mdna:8]

[0000889331-22-000022:mdna:9]
For the first quarter of 2022, the Company recognized net sales of $623.3 million, an increase of $159.5 million, or 34.4% as compared to $463.8 million in the first quarter of 2021. The increase was primarily driven by higher volumes in the Electronics and Industrial segments and $55.8 million or 12.0% of net sales from the Carling acquisition within the Transportation segment. The Company recognized net income of $117.5 million, or $4.70 per diluted share, in the first quarter of 2022 compared to $57.7 million, or $2.32 per diluted share in the first quarter of 2021. The increase in net income reflects higher operating income of $74.1 million primarily due to an increase in operating income of $65.1 million in the Electronics segment.

[0000889331-22-000022:mdna:10]
Supply chain constraints, including transportation capacity shortages have and are expected to continue to impact the Company, its  suppliers and its customers. This has resulted in higher transportation and input costs incurred by the Company.

[0000889331-22-000022:mdna:11]
Net cash provided by operating activities was $51.7 million for the three months ended April 2, 2022 as compared to $50.2 million for the three months ended March 27, 2021. The slight increase in net cash provided by operating activities was primarily due to higher cash earnings, largely offset by increases in working capital resulting from higher sales growth and higher annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-22-000022:mdna:12]
On April 8, 2022, the Company announced that it had entered into a definitive agreement to acquire C&K Switches (“C&K”) for $540 million in cash, subject to a working capital adjustment. Founded in 1928, C&K Switches is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom.At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is headquartered in Waltham, Massachusetts, with facilities located around the world and will be reported as part of the Electronics-Passive Products and Sensors within the Company's Electronics Segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close during the second quarter of 2022. The Company expects to finance the transaction through a combination of cash on hand and debt.

[0000889331-22-000022:mdna:13]
[same as prior period, unchanged from 0000889331-21-000067:mdna:14]

[0000889331-22-000022:mdna:14]
The effects from COVID-19 continue to drive higher ongoing costs including spending on personal protective equipment ("PPE"), additional personnel and employee transportation costs, and manufacturing inefficiencies as well as an increase in material costs and transportation costs due to global supply chain and logistics constraints around the world.

[0000889331-22-000022:mdna:15]
During the first quarter of 2022, the Company's manufacturing facilities were operational and were generally running at normal capacity levels.  However, the recent outbreak of COVID-19 in China in late March has resulted in the temporary shut-down of certain of the Company's China manufacturing facilities throughout April. The Company is focused on the safety and well-being of its employees and actively monitoring the current situation. The Company is not currently able to determine the duration of the temporary shut-down, the impact on its customers, suppliers and transportation in and out of China or the potential financial impact on the Company's 2022 financial results.

[0000889331-22-000022:mdna:16]
The Company anticipates that the disruptions caused by COVID-19 may continue to impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a resurgence in COVID-19 cases and its impact on the Company's employees, customers, suppliers and vendors. The Company will continue to actively monitor the situation and may take further actions altering its business operations that the Company determines are in the best interests of its employees, customers, partners, suppliers, and other stakeholders, or as

[0000889331-22-000022:mdna:17]
required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on the Company's business and operations, including the effects on its customers, employees, and prospects, or on the Company's financial results for the fiscal year 2022.

[0000889331-22-000022:mdna:18]
Risks Related to Market Conditions

[0000889331-22-000022:mdna:19]
The Company continues to operate in a more volatile macro environment given events related to the war in Ukraine.  The company does not have any direct operations in Ukraine or Russia. The war has had a modest impact on the Company, including higher transportation costs due to the Company modifying its shipping logistics as well as suspending sales into and purchases from Russia. Additionally, the war has impacted certain OEM customers who have had lower production levels due to shut-downs and ongoing material shortages.

[0000889331-22-000022:mdna:20]
[same as prior period, unchanged from 0000889331-21-000067:mdna:18]

[0000889331-22-000022:mdna:21]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The first quarter of 2022 includes $4.8 million of  purchase accounting inventory step-up charges, $3.8 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $0.2 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-22-000022:mdna:22]
The first quarter of 2021 includes $3.5 million of purchase accounting inventory step-up charges, $0.8 million of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions and $0.4 million of restructuring, impairment and other charges, primarily related to employee termination costs. In addition, there was a gain of $1.9 million from the sale of a building within the Electronics segment.

[0000889331-22-000022:mdna:23]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 623,330 |  |  | $ | 463,794 |  |  | $ | 159,536 |  |  | 34.4 | % |  |  |  |  |  |  |  |  |
| Cost of sales |  | 364,734 |  |  | 303,328 |  |  | 61,406 |  |  | 20.2 | % |  |  |  |  |  |  |  |  |
| Gross profit |  | 258,596 |  |  | 160,466 |  |  | 98,130 |  |  | 61.2 | % |  |  |  |  |  |  |  |  |
| Operating expenses |  | 108,006 |  |  | 83,985 |  |  | 24,021 |  |  | 28.6 | % |  |  |  |  |  |  |  |  |
| Operating income |  | 150,590 |  |  | 76,481 |  |  | 74,109 |  |  | 96.9 | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | 134,125 |  |  | 72,708 |  |  | 61,417 |  |  | 84.5 | % |  |  |  |  |  |  |  |  |
| Income taxes |  | 16,607 |  |  | 14,995 |  |  | 1,612 |  |  | 10.8 | % |  |  |  |  |  |  |  |  |
| Net income |  | $ | 117,518 |  |  | $ | 57,713 |  |  | $ | 59,805 |  |  | 103.6 | % |  |  |  |  |  |  |  |  |

[0000889331-22-000022:mdna:24]
[same as prior period, unchanged from 0000889331-21-000067:mdna:22]

[0000889331-22-000022:mdna:25]
Net sales increased $159.5 million, or 34.4%, including $55.8 million or 12.0% from the Carling acquisition within the Transportation segment and $8.6 million or 1.9% of unfavorable changes in foreign exchange rates for the first quarter of 2022 compared to the first quarter of 2021. The remaining increase was primarily driven by growth across the Company's Electronics and Industrial segments, which had sales increases of $79.3 million and $24.3 million, respectively. The increase within the Electronics segment was led by continued broad-based demand across electronics, transportation and industrial end markets.  The increase in the Industrial segment  was driven across all businesses within the segment.

[0000889331-22-000022:mdna:26]
[same as prior period, unchanged from 0000889331-21-000067:mdna:26]

[0000889331-22-000022:mdna:27]
Cost of sales was $364.7 million, or 58.5% of net sales, in 2022, compared to $303.3 million, or 65.4% of net sales, in 2021. The increase in cost of sales was primarily due to greater volume across the Electronics and Industrial segments driven by the factors discussed above along with the acquisition of Carling. As a percent of net sales, cost of sales decreased 6.9% driven by volume leverage and favorable product mix predominantly in the Electronics segment, partially offset by higher transportation, duty and tariff charges of 0.9%, and higher commodity costs.

[0000889331-22-000022:mdna:28]
[same as prior period, unchanged from 0000889331-21-000067:mdna:29]

[0000889331-22-000022:mdna:29]
Gross profit was $258.6 million, or 41.5% of net sales, in the first quarter of 2022 compared to $160.5 million, or 34.6% of net sales, for the first quarter of 2021. The $98.1 million increase in gross profit was primarily due to higher volume in the Electronics segment. The increase in gross margin of 6.9% was primarily driven by volume leverage and favorable product mix within the Electronics segment and higher prices, partially offset by higher transportation, duty and tariff charges as a percent of net sales of 0.9%, and higher commodity costs.

[0000889331-22-000022:mdna:30]
[same as prior period, unchanged from 0000889331-21-000067:mdna:32]

[0000889331-22-000022:mdna:31]
Total operating expenses were $108.0 million, or 17.3% of net sales, for the first quarter of 2022 compared to $84.0 million, or 18.1% of net sales, for the first quarter of 2021. The increase in operating expenses of $24.0 million was primarily due to the higher selling, general, and administrative expenses of $17.2 million largely due to the Carling acquisition and increased acquisition-related expenses of $3.0 million, higher research and development expenses of $4.8 million, and higher amortization expense of $2.2 million due to the Carling acquisition.

[0000889331-22-000022:mdna:32]
[same as prior period, unchanged from 0000889331-21-000067:mdna:35]

[0000889331-22-000022:mdna:33]
Operating income was $150.6 million, an increase of $74.1 million, or 96.9%, for the first quarter of 2022 compared to $76.5 million for the first quarter of 2021. The increase in operating income was due to higher gross profit from all segments, particularly in the Electronics segment, partially offset by higher operating expenses as noted above. Operating margins increased from 16.5% in the first quarter of 2021 to 24.2% in the first quarter of 2022 driven by the factors mentioned above.

[0000889331-22-000022:mdna:34]
[same as prior period, unchanged from 0000889331-21-000067:mdna:39]

[0000889331-22-000022:mdna:35]
Income before income taxes was $134.1 million, or 21.5% of net sales, for the first quarter of 2022 compared to $72.7 million, or 15.7% of net sales, for the first quarter of 2021. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by $4.7 million of unrealized losses associated with the Company's equity investment in the first quarter of 2022 compared to unrealized gains of $7.5 million from the Company's equity investment in the first quarter of 2021, and higher foreign exchange losses of $0.9 million.

[0000889331-22-000022:mdna:36]
[same as prior period, unchanged from 0000889331-21-000067:mdna:42]

[0000889331-22-000022:mdna:37]
Income tax expense for the first quarter of 2022 was $16.6 million, or an effective tax rate of 12.4%, compared to $15.0 million, or an effective tax rate of 20.6%, for the first quarter of 2021. The effective tax rate for the first quarter of 2022 is lower than the effective tax rate for the comparable 2021 period, primarily due to a one-time deduction that resulted from the dissolution of one of the Company’s affiliates, which resulted in a net benefit of $7.2 million for the first quarter of 2022. The effective tax rate for the 2022 period is lower than the applicable U.S. statutory tax rate due to the one-time deduction that resulted from the dissolution of one of the Company’s affiliates that is referred to in the preceding sentence, as well as the forecasted impact of income earned in lower tax jurisdictions. The effective tax rate for the comparable 2021 period is approximately the same as the applicable U.S. statutory tax rate.

[0000889331-22-000022:mdna:38]
[same as prior period, unchanged from 0000889331-21-000067:mdna:45]

[0000889331-22-000022:mdna:39]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 15, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-22-000022:mdna:40]
[same as prior period, unchanged from 0000889331-21-000067:mdna:47]

[0000889331-22-000022:mdna:41]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 365,821 |  |  | $ | 286,535 |  |  | $ | 79,286 |  |  | 27.7 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 184,504 |  |  | 128,529 |  |  | 55,975 |  |  | 43.6 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 73,005 |  |  | 48,730 |  |  | 24,275 |  |  | 49.8 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 623,330 |  |  | $ | 463,794 |  |  | $ | 159,536 |  |  | 34.4 | % |  |  |  |  |  |  |  |  |

[0000889331-22-000022:mdna:42]
[same as prior period, unchanged from 0000889331-21-000067:mdna:49]

[0000889331-22-000022:mdna:43]
Net sales increased $79.3 million, or 27.7%, in the first quarter of 2022 compared to the first quarter of 2021 and included unfavorable changes in foreign exchange rates of $4.8 million. The sales increase was primarily due to increased volume for the semiconductor and electronics products businesses of $41.8 million and $37.5 million, respectively, led by continued broad-based demand across electronics, transportation and industrial end markets.

[0000889331-22-000022:mdna:44]
Transportation Segment

[0000889331-22-000022:mdna:45]
Net sales increased $56.0 million, or 43.6%, in the first quarter of 2022 compared to the first quarter of 2021 and included unfavorable changes in foreign exchange rates of $3.6 million. The sales increase was primarily due to the acquisition of Carling which contributed net sales of $55.8 million. Net sales in the commercial vehicle business increased by $61.5 million, largely due to the Carling acquisition noted previously and continued demand across a number of commercial vehicle end markets. The passenger car products and automotive sensors businesses had sales decreases of $3.4 million and $2.1 million, respectively, driven by a decline in global car build compared to the same quarter last year largely due to supply chain constraints and OEM shut downs caused by market shortages of semiconductor chips as well as a reduction of demand in Europe due to Ukraine/Russia conflict partially offset by greater content growth from vehicle mix and electric vehicles.

[0000889331-22-000022:mdna:46]
[same as prior period, unchanged from 0000889331-21-000067:mdna:56]

[0000889331-22-000022:mdna:47]
Net sales increased by $24.3 million, or 49.8%, in the first quarter of 2022 compared to the first quarter of 2021, which included unfavorable changes in foreign exchange rates of $0.2 million. The increase in net sales was primarily due to higher volume and demand across product lines in industrial safety, HVAC, renewables, nonresidential construction, and industrial maintenance, repair, and operations end markets and incremental net sales of $9.1 million or 18.6% from the Hartland acquisition.

[0000889331-22-000022:mdna:48]
[same as prior period, unchanged from 0000889331-21-000067:mdna:59]

[0000889331-22-000022:mdna:49]
[same as prior period, unchanged from 0000889331-21-000067:mdna:60]

[0000889331-22-000022:mdna:50]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | $ | 260,218 |  |  | $ | 212,185 |  |  | $ | 48,033 |  |  | 22.6 | % |  |  |  |  |  |  |  |  |
| Americas |  | 237,230 |  |  | 152,906 |  |  | 84,324 |  |  | 55.1 | % |  |  |  |  |  |  |  |  |
| Europe |  | 125,882 |  |  | 98,703 |  |  | 27,179 |  |  | 27.5 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 623,330 |  |  | $ | 463,794 |  |  | $ | 159,536 |  |  | 34.4 | % |  |  |  |  |  |  |  |  |

[0000889331-22-000022:mdna:51]
[same as prior period, unchanged from 0000889331-21-000067:mdna:62]

[0000889331-22-000022:mdna:52]
Net sales increased  $48.0 million, or 22.6%, in the first quarter of 2022 compared to the first quarter of 2021 and included unfavorable changes in foreign exchange rates of $1.1 million. The increase in net sales was primarily due to higher volume across all businesses within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the first quarter of 2021.

[0000889331-22-000022:mdna:53]
[same as prior period, unchanged from 0000889331-21-000067:mdna:65]

[0000889331-22-000022:mdna:54]
Net sales increased $84.3 million, or 55.1%, in the first quarter of 2022 compared to the first quarter of 2021 and included unfavorable changes in foreign exchange rates of $0.1 million. The increase in net sales was primarily due to incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment and higher volume from all businesses within the Electronics and Industrial segments compared to the first quarter of  2021.

[0000889331-22-000022:mdna:55]
[same as prior period, unchanged from 0000889331-21-000067:mdna:68]

[0000889331-22-000022:mdna:56]
Net sales increased $27.2 million, or 27.5%, in the first quarter of 2022 compared to the first quarter of 2021 and included unfavorable changes in foreign exchange rates of $7.4 million. The increase in net sales was primarily due to increased volume across all businesses within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the first quarter of 2021.

[0000889331-22-000022:mdna:57]
[same as prior period, unchanged from 0000889331-21-000067:mdna:71]

[0000889331-22-000022:mdna:58]
[same as prior period, unchanged from 0000889331-21-000067:mdna:72]

[0000889331-22-000022:mdna:59]
Cash and cash equivalents were $461.6 million as of April 2, 2022, a decrease of $16.9 million as compared to January 1, 2022. As of April 2, 2022, $145.3 million of the Company's $461.6 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-22-000022:mdna:60]
Revolving Credit Facility

[0000889331-22-000022:mdna:61]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The balance under the facility was $100.0 million as of April 2, 2022.

[0000889331-22-000022:mdna:62]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.71% at April 2, 2022.

[0000889331-22-000022:mdna:63]
As of April 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At April 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-22-000022:mdna:64]
[same as prior period, unchanged from 0000889331-21-000067:mdna:79]

[0000889331-22-000022:mdna:65]
[same as prior period, unchanged from 0000889331-21-000067:mdna:80]

[0000889331-22-000022:mdna:66]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the three months ended April 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

[0000889331-22-000022:mdna:67]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”)

[0000889331-22-000022:mdna:68]
(together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-22-000022:mdna:69]
Debt Covenants

[0000889331-22-000022:mdna:70]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of April 2, 2022 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2022. As of April 2, 2022, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-22-000022:mdna:71]
[same as prior period, unchanged from 0000889331-21-000067:mdna:85]

[0000889331-22-000022:mdna:72]
On April 8, 2022, the Company announced that it had entered into a definitive agreement to acquire C&K Switches for $540 million in cash, subject to a working capital adjustment. Founded in 1928, C&K Switches is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is headquartered in Waltham, Massachusetts, with facilities located around the world and will be reported as part of the Electronics-Passive Products and Sensors within the Company's Electronics Segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close during the second quarter of 2022. The Company expects to finance the transaction through a combination of cash on hand and debt.

[0000889331-22-000022:mdna:73]
[same as prior period, unchanged from 0000889331-21-000067:mdna:87]

[0000889331-22-000022:mdna:74]
During the first quarter of 2022 the Company paid quarterly dividends of $13.1 million to the shareholders. On April 28, 2022, the Board of Directors of the Company declared a quarterly cash dividend of $0.53 per share, payable on June 9, 2022 to stockholders of record as of May 26, 2022.

[0000889331-22-000022:mdna:75]
[same as prior period, unchanged from 0000889331-21-000067:mdna:91]

[0000889331-22-000022:mdna:76]
|  |  | First three Months |
| (in thousands) |  | 2022 |  | 2021 |
| Net cash provided by operating activities |  | $ | 51,731 |  |  | $ | 50,166 |  |
| Net cash used in investing activities |  | (29,788) |  |  | (122,020) |  |
| Net cash used in financing activities |  | (37,070) |  |  | (34,273) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (2,738) |  |  | (4,101) |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (17,865) |  |  | (110,228) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 482,836 |  |  | 687,525 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 464,971 |  |  | $ | 577,297 |  |

[0000889331-22-000022:mdna:77]
[same as prior period, unchanged from 0000889331-21-000067:mdna:93]

[0000889331-22-000022:mdna:78]
[same as prior period, unchanged from 0000889331-21-000067:mdna:94]

[0000889331-22-000022:mdna:79]
Net cash provided by operating activities was $51.7 million for the three months ended April 2, 2022 as compared to $50.2 million for the three months ended March 27, 2021. The slight increase in net cash provided by operating activities was primarily due to higher cash earnings, largely offset by increases in working capital resulting from higher sales growth and higher annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-22-000022:mdna:80]
[same as prior period, unchanged from 0000889331-21-000067:mdna:96]

[0000889331-22-000022:mdna:81]
Net cash used in investing activities was $29.8 million for the three months ended April 2, 2022 compared to $122.0 million during the three months ended March 27, 2021. Net cash paid for acquisitions was $109.9 million for the three months ended March 27, 2021. Capital expenditures were $29.8 million, representing an increase of $15.1 million compared to 2021. During the three months ended March 27, 2021, the Company received proceeds of $2.6 million from the sale of a property within the Electronics segment.

[0000889331-22-000022:mdna:82]
[same as prior period, unchanged from 0000889331-21-000067:mdna:98]

[0000889331-22-000022:mdna:83]
Net cash used in financing activities was $37.1 million for the three months ended April 2, 2022 compared to $34.3 million for the three months ended March 27, 2021. During the three months ended April 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022. During the three months ended March 27, 2021, the Company made payments of $30.0 million on the amended revolving credit facility. Additionally, the Company paid dividends $13.1 million and $11.8 million in the three months ended April 2, 2022 and March 27, 2021, respectively.

[0000889331-22-000022:mdna:84]
[same as prior period, unchanged from 0000889331-21-000067:mdna:101]

[0000889331-22-000022:mdna:85]
On April 28, 2021, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program.

[0000889331-22-000022:mdna:86]
The Company did not repurchase any shares of its common stock for the three months ended April 2, 2022, and March 27, 2021.

[0000889331-22-000022:mdna:87]
[same as prior period, unchanged from 0000889331-21-000067:mdna:104]

[0000889331-22-000022:mdna:88]
As of April 2, 2022, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-22-000022:mdna:89]
[same as prior period, unchanged from 0000889331-21-000067:mdna:106]

[0000889331-22-000022:mdna:90]
[same as prior period, unchanged from 0000889331-21-000067:mdna:107]

[0000889331-22-000022:mdna:91]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended January 1, 2022. During the three months ended April 2, 2022, there were no significant changes in the application of critical accounting policies.
