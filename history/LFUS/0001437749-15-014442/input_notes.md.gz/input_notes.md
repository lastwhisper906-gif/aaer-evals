# LFUS notes — 0001437749-15-014442


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-15-014442:notes:1]
[same as prior period, unchanged from 0001437749-15-008576:notes:61]

[0001437749-15-014442:notes:2]
[same as prior period, unchanged from 0001437749-15-008576:notes:62]

[0001437749-15-014442:notes:3]
| AOCI component |  | Balance at December 27, 2014 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Balance at June 27, 2015 |  |
| Pension liability adjustment(a) |  | $ | (29,615 | ) |  | $ | (124 | ) |  | $ | 1,971 |  |  | $ | (27,768 | ) |
| Unrealized gain on investments(b) |  |  | 10,791 |  |  |  | 3,336 |  |  |  | — |  |  |  | 14,127 |  |
| Foreign currency translation adjustment |  |  | (2,302 | ) |  |  | (10,153 | ) |  |  | — |  |  |  | (12,455 | ) |
| AOCI (loss) income |  | $ | (21,126 | ) |  | $ | (6,941 | ) |  | $ | 1,971 |  |  | $ | (26,096 | ) |

[0001437749-15-014442:notes:4]
(a) Balances are net of tax of $12,055 and $12,857 for 2015 and 2014, respectively.

[0001437749-15-014442:notes:5]
[same as prior period, unchanged from 0001437749-15-008576:notes:65]


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0001437749-15-014442:notes:6]
4

[0001437749-15-014442:notes:7]
.

[0001437749-15-014442:notes:8]
Other

[0001437749-15-014442:notes:9]
Investments

[0001437749-15-014442:notes:10]
The company’s other investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company. The Polytronics investment was acquired as part of the Heinrich Companies acquisition in 2004. The fair value of the Polytronics investment was €12.9million (approximately $14.5 million) at June 27, 2015 and €9.9 million (approximately $12.1 million) at December 27, 2014. Included in 2015 other comprehensive income is an unrealized gain of $3.4 million, due to the increase in fair market value of the Polytronics investment. The remaining movement was due to the impact of changes in exchange rates.


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-014442:notes:11]
5. Debt

[0001437749-15-014442:notes:12]
The carrying amounts of debt at June 27, 2015 and December 27, 2014 are as follows (in thousands):

[0001437749-15-014442:notes:13]
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 91,250 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 73,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 14,493 |  |  |  | 17,908 |  |
| Total debt |  |  | 179,243 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 82,250 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 96,993 |  |  | $ | 106,658 |  |

[0001437749-15-014442:notes:14]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of June 27, 2015, the company had available $200.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of June 27, 2015). At June 27, 2015, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-15-014442:notes:15]
Entrusted Loan

[0001437749-15-014442:notes:16]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-014442:notes:17]
7

[0001437749-15-014442:notes:18]
Earnings per Share

[0001437749-15-014442:notes:19]
The following table sets forth the computation of basic and diluted earnings per share for the periods ended June 27, 2015 and June 28, 2014 (in thousands except per share amounts).

[0001437749-15-014442:notes:20]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Net income |  | $ | 28.684 |  |  | $ | 24,578 |  |  | $ | 48,679 |  |  | $ | 49,967 |  |
| Average shares outstanding - Basic |  |  | 22,691 |  |  |  | 22,579 |  |  |  | 22,645 |  |  |  | 22,536 |  |
| Net effect of dilutive stock options and restricted share units |  |  | 144 |  |  |  | 171 |  |  |  | 165 |  |  |  | 202 |  |
| Average shares - Diluted |  |  | 22,835 |  |  |  | 22,750 |  |  |  | 22,810 |  |  |  | 22,738 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.26 |  |  | $ | 1.09 |  |  | $ | 2.15 |  |  | $ | 2.22 |  |
| Diluted |  | $ | 1.26 |  |  | $ | 1.08 |  |  | $ | 2.13 |  |  | $ | 2.20 |  |

[0001437749-15-014442:notes:21]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were113,878 and 46,190 for the three months ended June 27, 2015 and June 28, 2014 and 90,875 and 22,708 for the six months ended June 27

[0001437749-15-014442:notes:22]
, 2015

[0001437749-15-014442:notes:23]
and June 28

[0001437749-15-014442:notes:24]
, 2014

[0001437749-15-014442:notes:25]
, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-15-014442:notes:26]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |
| Total |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |

[0001437749-15-014442:notes:27]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 14,503 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,503 |  |
| Total |  | $ | 14,503 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,503 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-014442:notes:28]
6

[0001437749-15-014442:notes:29]
. Fair Value of Assets and Liabilities

[0001437749-15-014442:notes:30]
[same as prior period, unchanged from 0001437749-15-008576:notes:21]

[0001437749-15-014442:notes:31]
[same as prior period, unchanged from 0001437749-15-008576:notes:22]

[0001437749-15-014442:notes:32]
[same as prior period, unchanged from 0001437749-15-008576:notes:23]

[0001437749-15-014442:notes:33]
[same as prior period, unchanged from 0001437749-15-008576:notes:24]

[0001437749-15-014442:notes:34]
[same as prior period, unchanged from 0001437749-15-008576:notes:25]

[0001437749-15-014442:notes:35]
[same as prior period, unchanged from 0001437749-15-008576:notes:26]

[0001437749-15-014442:notes:36]
[same as prior period, unchanged from 0001437749-15-008576:notes:27]

[0001437749-15-014442:notes:37]
[same as prior period, unchanged from 0001437749-15-008576:notes:28]

[0001437749-15-014442:notes:38]
There were no changes during the six months ended June 27, 2015 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of June 27, 2015 and December 27, 2014 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-15-014442:notes:39]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of June 27, 2015 (in thousands):

[0001437749-15-014442:notes:40]
[same as prior period, unchanged from 0001437749-15-008576:notes:32]

[0001437749-15-014442:notes:41]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt. The carrying amounts of cash and cash equivalents

[0001437749-15-014442:notes:42]
, short-term investments, accounts receivable, accounts payable and debt approximate their fair values. The company’s debt fair value approximates book value at June 27, 2015 and December 27, 2014, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-014442:notes:43]
8

[0001437749-15-014442:notes:44]
. Income

[0001437749-15-014442:notes:45]
Taxes

[0001437749-15-014442:notes:46]
The effective tax rate for the second quarter of 2015 was 23.9% compared to an effective tax rate of 22.1% in the second quarter of 2014

[0001437749-15-014442:notes:47]
. The effective tax rate for the six months ended June 27, 2015 was 24.1% as compared to an effective tax rate of 23.6% for the six months ended June 28, 2014. The effective tax rates for both the second quarter and six month periods of 2015 and 2014 are lower than the U.S. statutory tax rate primarily due to the result of more income earned in low tax jurisdictions.

[0001437749-15-014442:notes:48]
The company has restructured the legal ownership of its Mexican manufacturing operations as of June 28, 2015. Although the transaction was completed in the third quarter, the company considered the impact on the effective tax rate for the second quarter and determined such impact was not material.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-15-014442:notes:49]
[same as prior period, unchanged from 0001437749-15-008576:notes:9]

[0001437749-15-014442:notes:50]
The components of inventories at June 27, 2015 and December 27, 2014 are as follows (in thousands):

[0001437749-15-014442:notes:51]
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
| Raw material |  | $ | 33,193 |  |  | $ | 29,756 |  |
| Work in process |  |  | 16,404 |  |  |  | 15,164 |  |
| Finished goods |  |  | 48,138 |  |  |  | 52,471 |  |
| Total inventories |  | $ | 97,735 |  |  | $ | 97,391 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-15-014442:notes:52]
2

[0001437749-15-014442:notes:53]
. Acquisition of Business

[0001437749-15-014442:notes:54]
[same as prior period, unchanged from 0001437749-15-008576:notes:2]

[0001437749-15-014442:notes:55]
On January 3, 2014, the company acquired 100% of SymCom, Inc. (“SymCom”) for $52.8 million net of cash acquired. Located in Rapid City, South Dakota, SymCom provides overload relays and pump controllers primarily to the industrial market. The acquisition allows the company to strengthen its position in the relay products market by adding new products and new customers within its Electrical business unit segment. The company funded the acquisition with available cash and proceeds from credit facilities

[0001437749-15-014442:notes:56]
[same as prior period, unchanged from 0001437749-15-008576:notes:4]

[0001437749-15-014442:notes:57]
[same as prior period, unchanged from 0001437749-15-008576:notes:5]

[0001437749-15-014442:notes:58]
[same as prior period, unchanged from 0001437749-15-008576:notes:6]

[0001437749-15-014442:notes:59]
[same as prior period, unchanged from 0001437749-15-008576:notes:7]

[0001437749-15-014442:notes:60]
[same as prior period, unchanged from 0001437749-15-008576:notes:8]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-15-014442:notes:61]
[same as prior period, unchanged from 0001437749-15-008576:notes:41]

[0001437749-15-014442:notes:62]
The components of net periodic benefit cost for the three and six months ended June 27, 2015, compared with the three and six months ended June 28, 2014, were (in thousands):

[0001437749-15-014442:notes:63]
|  |  | U.S. Pension Benefits |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Service cost |  | $ | 250 |  |  | $ | 150 |  |  | $ | 500 |  |  | $ | 300 |  |  | $ | 315 |  |  | $ | 311 |  |  | $ | 630 |  |  | $ | 622 |  |
| Interest cost |  |  | 1,031 |  |  |  | 971 |  |  |  | 2,062 |  |  |  | 1,942 |  |  |  | 513 |  |  |  | 592 |  |  |  | 1,026 |  |  |  | 1,183 |  |
| Expected return on plan assets |  |  | (916 | ) |  |  | (1,411 | ) |  |  | (1,832 | ) |  |  | (2,822 | ) |  |  | (601 | ) |  |  | (573 | ) |  |  | (1,201 | ) |  |  | (1,146 | ) |
| Amortization of net loss |  |  | 290 |  |  |  | 137 |  |  |  | 580 |  |  |  | 274 |  |  |  | 62 |  |  |  | 47 |  |  |  | 123 |  |  |  | 95 |  |
| Total cost (credit) of the plan |  |  | 655 |  |  |  | (153 | ) |  |  | 1,310 |  |  |  | (306 | ) |  |  | 289 |  |  |  | 377 |  |  |  | 578 |  |  |  | 754 |  |
| Expected plan participants’ contribution |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net periodic benefit cost (credit) |  | $ | 655 |  |  | $ | (153 | ) |  | $ | 1,310 |  |  | $ | (306 | ) |  | $ | 289 |  |  | $ | 377 |  |  | $ | 578 |  |  | $ | 754 |  |

[0001437749-15-014442:notes:64]
[same as prior period, unchanged from 0001437749-15-008576:notes:44]

[0001437749-15-014442:notes:65]
[same as prior period, unchanged from 0001437749-15-008576:notes:45]

[0001437749-15-014442:notes:66]
The company received approval from the IRS on April 14, 2015 on its Application for Determination for Terminating Plan to terminate the U.S. defined benefit pension plan, the Littelfuse Inc. Retirement Plan, effective July 30, 2014. The current liability balance of $11.8 million at June 27, 2015, represents the projected cost to settle the plan’s liability in conjunction with the upcoming plan termination. Settlement is expected to occur during the third quarter of 2015.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-15-014442:notes:67]
|  |  | Additions to long-lived assets |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| United States |  | $ | 6,615 |  |  | $ | 3,309 |  |
| Mexico |  |  | 4,190 |  |  |  | 4,694 |  |
| China |  |  | 4,080 |  |  |  | 2,506 |  |
| Other countries |  |  | 11,503 |  |  |  | 2,623 |  |
| Total |  | $ | 26,388 |  |  | $ | 13,132 |  |

[0001437749-15-014442:notes:68]
|  |  | For the Three Months Ended(a) |  |  | For the Six Months Ended(a) |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| United States |  | $ | 89,608 |  |  | $ | 80,492 |  |  | $ | 172,981 |  |  | $ | 152,366 |  |
| China |  |  | 49,920 |  |  |  | 39,987 |  |  |  | 94,349 |  |  |  | 77,200 |  |
| Other countries |  |  | 82,493 |  |  |  | 100,429 |  |  |  | 165,004 |  |  |  | 198,201 |  |
| Total |  | $ | 222,021 |  |  | $ | 220,908 |  |  | $ | 432,334 |  |  | $ | 427,767 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001437749-15-014442:notes:69]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 105,553 |  |  | $ | 109,947 |  |  | $ | 204,933 |  |  | $ | 205,972 |  |
| Automotive |  |  | 85,918 |  |  |  | 82,042 |  |  |  | 169,989 |  |  |  | 164,444 |  |
| Electrical |  |  | 30,550 |  |  |  | 28,919 |  |  |  | 57,412 |  |  |  | 57,351 |  |
| Total net sales |  | $ | 222,021 |  |  | $ | 220,908 |  |  | $ | 432,334 |  |  | $ | 427,767 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 5,775 |  |  | $ | 5,530 |  |  | $ | 11,573 |  |  | $ | 10,900 |  |
| Automotive |  |  | 3,303 |  |  |  | 3,646 |  |  |  | 6,639 |  |  |  | 7,174 |  |
| Electrical |  |  | 1,295 |  |  |  | 1,414 |  |  |  | 2,579 |  |  |  | 2,682 |  |
| Total depreciation and amortization |  | $ | 10,373 |  |  | $ | 10,590 |  |  | $ | 20,791 |  |  | $ | 20,756 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 22,167 |  |  | $ | 25,634 |  |  | $ | 40,832 |  |  | $ | 45,005 |  |
| Automotive |  |  | 12,699 |  |  |  | 11,049 |  |  |  | 23,870 |  |  |  | 22,931 |  |
| Electrical |  |  | 4,709 |  |  |  | 571 |  |  |  | 7,439 |  |  |  | 4,317 |  |
| Other(1) |  |  | (3,404 | ) |  |  | (3,535 | ) |  |  | (6,422 | ) |  |  | (4,944 | ) |
| Total operating income |  |  | 36,171 |  |  |  | 33,719 |  |  |  | 65,719 |  |  |  | 67,309 |  |
| Interest expense |  |  | 948 |  |  |  | 1,228 |  |  |  | 2,099 |  |  |  | 2,444 |  |
| Foreign exchange (gain) loss |  |  | (1,292 | ) |  |  | 2,375 |  |  |  | 1,825 |  |  |  | 2,123 |  |
| Other (income) expense, net |  |  | (1,202 | ) |  |  | (1,446 | ) |  |  | (2,328 | ) |  |  | (2,632 | ) |
| Income before income taxes |  | $ | 37,717 |  |  | $ | 31,562 |  |  | $ | 64,123 |  |  | $ | 65,374 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-15-014442:notes:70]
|  |  | Long-lived assets(b) |  |
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
| United States |  | $ | 34,129 |  |  | $ | 34,179 |  |
| Mexico |  |  | 46,052 |  |  |  | 47,936 |  |
| China |  |  | 40,416 |  |  |  | 40,981 |  |
| Other countries |  |  | 45,782 |  |  |  | 35,544 |  |
| Total |  | $ | 166,379 |  |  | $ | 158,640 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-014442:notes:71]
10

[0001437749-15-014442:notes:72]
Business Unit Segment Information

[0001437749-15-014442:notes:73]
[same as prior period, unchanged from 0001437749-15-008576:notes:48]

[0001437749-15-014442:notes:74]
[same as prior period, unchanged from 0001437749-15-008576:notes:49]

[0001437749-15-014442:notes:75]
An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer (“CEO”)

[0001437749-15-014442:notes:76]
Business unit segment information for the three and six months ended June 27, 2015 and June 28, 2014 are summarized as follows (in thousands):

[0001437749-15-014442:notes:77]
(1) For the three months ended June 27, 2015, “Other” consists of restructuring costs ($2.5 million), acquisition expenses ($0.2 million) and pension wind-up costs ($0.7 million). For the six months ended June 27, 2015, “Other” consist of restructuring costs ($4.8 million), acquisition expenses ($0.3 million) and pension wind-up costs ($1.3 million).

[0001437749-15-014442:notes:78]
The company’s significant net sales by country for the three and six months ended June 27, 2015 and June 28, 2014 are summarized as follows (in thousands):

[0001437749-15-014442:notes:79]
[same as prior period, unchanged from 0001437749-15-008576:notes:56]

[0001437749-15-014442:notes:80]
The company’s significant long-lived assets and additions to long-lived assets by country as of June 27, 2015 and December 27, 2014 are summarized as follows (in thousands):

[0001437749-15-014442:notes:81]
(b) Long-lived assets consists of net property, plant and equipment

[0001437749-15-014442:notes:82]
The company’s additions to long-lived assets for the six months ended June 27, 2015 and June 28, 2014 are summarized as follows (in thousands):
