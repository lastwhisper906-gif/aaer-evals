# LFUS note change history — 0001437749-15-008576 → 0001437749-15-014442


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-31):
[0001437749-15-014442:note_history:1]
The carrying amounts of debt at June 27, 2015 and December 27, 2014 are as follows (in thousands):
  (was, 2015-05-01, similarity 0.9492):
[0001437749-15-008576:note_history:1]
The carrying amounts of debt at March 28, 2015 and December 27, 2014 are as follows (in thousands):

- changed (2015-07-31):
[0001437749-15-014442:note_history:2]
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 91,250 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 73,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 14,493 |  |  |  | 17,908 |  |
| Total debt |  |  | 179,243 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 82,250 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 96,993 |  |  | $ | 106,658 |  |
  (was, 2015-05-01, similarity 0.9849):
[0001437749-15-008576:note_history:2]
|  |  | March 28, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 92,500 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 79,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 17,969 |  |  |  | 17,908 |  |
| Total debt |  |  | 189,969 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 87,000 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 102,969 |  |  | $ | 106,658 |  |

- changed (2015-07-31):
[0001437749-15-014442:note_history:3]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of June 27, 2015, the company had available $200.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of June 27, 2015). At June 27, 2015, the company was in compliance with all covenants under the revolving credit facility.
  (was, 2015-05-01, similarity 0.9799):
[0001437749-15-008576:note_history:3]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of March 28, 2015, the company had available $194.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.18% as of March 28, 2015). At March 28, 2015, the company was in compliance with all covenants under the revolving credit facility.

- changed (2015-07-31):
[0001437749-15-014442:note_history:4]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.
  (was, 2015-05-01, similarity 0.9862):
[0001437749-15-008576:note_history:4]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income
      will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-31):
[0001437749-15-014442:note_history:5]
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 91,250 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 73,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 14,493 |  |  |  | 17,908 |  |
| Total debt |  |  | 179,243 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 82,250 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 96,993 |  |  | $ | 106,658 |  |
  (was, 2015-05-01, similarity 0.9849):
[0001437749-15-008576:note_history:5]
|  |  | March 28, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 92,500 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 79,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 17,969 |  |  |  | 17,908 |  |
| Total debt |  |  | 189,969 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 87,000 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 102,969 |  |  | $ | 106,658 |  |
