# LFUS 8-K — 0001437749-15-014196 filed 2015-07-29

## item codes, every 8-K on or before 2015-07-31

- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2015-07-31

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-15-014196:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-15-014196:8k_2_02:2]
ex99-1.htm

[0001437749-15-014196:8k_2_02:3]
Exhibit 99.1

[0001437749-15-014196:8k_2_02:4]
NEWS RELEASE

[0001437749-15-014196:8k_2_02:5]
CONTACT: Phil Franklin,

[0001437749-15-014196:8k_2_02:6]
Executive Vice President and CFO (773) 628-0810

[0001437749-15-014196:8k_2_02:7]
LITTELFUSE REPORTS SECOND QUARTER RESULTS

[0001437749-15-014196:8k_2_02:8]
CHICAGO, July 29, 2015 – Littelfuse, Inc. (NASDAQ:LFUS) today reported sales and earnings for the second quarter ended June 27, 2015 and announced a 16% increase in the quarterly cash dividend.

[0001437749-15-014196:8k_2_02:9]
Second Quarter Highlights

[0001437749-15-014196:8k_2_02:10]
|  | ● | Sales for the second quarter of 2015 were $222.0 million, a 1% increase (6% excluding currency effects) compared to the prior-year quarter due to continued growth in automotive and improvement in the electrical business. |

[0001437749-15-014196:8k_2_02:11]
|  | ● | On a GAAP basis, second quarter 2015 earnings were $1.26 per diluted share. This included $2.1 million of special items comprised primarily of restructuring and pension wind-up charges partially offset by non-operating foreign exchange gains (see Supplemental Financial Information on page 8). Excluding these special items, earnings for the second quarter of 2015 were $1.33 per diluted share. |

[0001437749-15-014196:8k_2_02:12]
|  | ● | Sales trends by business unit for the second quarter were as follows: |

[0001437749-15-014196:8k_2_02:13]
|  | o | Electronics sales declined 4% year over year (1% excluding currency effects) due to a slower seasonal ramp-up for core products and capacity constraints for sensor products as they are being transferred to the Philippines. |

[0001437749-15-014196:8k_2_02:14]
|  | o | Automotive sales increased 5% year over year (13% excluding currency effects) as all three regions had double-digit growth on a constant-currency basis. |

[0001437749-15-014196:8k_2_02:15]
|  | o | Electrical sales increased 6% year over year (9% excluding currency effects) as improvements in fuse and custom products sales were partially offset by weaker relay sales. |

[0001437749-15-014196:8k_2_02:16]
|  | ● | The electronics book-to-bill ratio for the second quarter of 2015 was 0.94. |

[0001437749-15-014196:8k_2_02:17]
|  | ● | Cash provided by operating activities was $38.7 million for the second quarter of 2015 compared to $31.0 million for the second quarter of 2014. Capital expenditures for the second quarter of 2015 increased to $14.1 million compared to $6.7 million for the second quarter of 2014 primarily related to capacity addition for new automotive programs and the manufacturing transfer to the Philippines. |

[0001437749-15-014196:8k_2_02:18]
-more-

[0001437749-15-014196:8k_2_02:19]
“Execution was excellent across our businesses in the second quarter,” said Gordon Hunter, chief executive officer. “This enabled us to outperform our earnings guidance despite the continuing negative effects of the weak euro and some sluggishness in our electronics markets. Improved manufacturing performance at our Piedras Negras, Mexico site was particularly encouraging.”

[0001437749-15-014196:8k_2_02:20]
Outlook

[0001437749-15-014196:8k_2_02:21]
“There are mixed signals regarding the near term outlook,” said Hunter. “The .94 book to bill indicates less- than-normal seasonal strength for electronics, although we did see this increase some in July. On the other hand, the electrical business continues to improve and automotive trends remain solid despite slowing growth in global car production.”

[0001437749-15-014196:8k_2_02:22]
|  | ● | Sales for the third quarter of 2015 are expected to be in the range of $211 to $221 million. At the midpoint, this is flat with the prior year quarter or approximately 4% growth on a constant currency basis. |

[0001437749-15-014196:8k_2_02:23]
|  | ● | The full year effective tax rate is expected to be approximately 23.5%, although this assumes that Congress approves the R&D credit and the “look-through” provision for 2015 as it did in 2014. Until such time, the rate is expected to be about 50 basis points higher. |

[0001437749-15-014196:8k_2_02:24]
|  | ● | Earnings for the third quarter of 2015 are expected to be in the range of $1.24 to $1.36 per diluted share. This includes negative currency effects of approximately $0.10 compared to the prior year. |

[0001437749-15-014196:8k_2_02:25]
|  | ● | Although capital expenditures through the first six months of the year are $26.4 million, it is expected that spending will slow down in the second half resulting in full year capital expenditures of approximately $40 to $45 million. |

[0001437749-15-014196:8k_2_02:26]
Dividend

[0001437749-15-014196:8k_2_02:27]
The Board has approved a 16% increase in the quarterly cash dividend from $0.25 to $0.29 per share. This dividend is payable on September 3, 2015 to shareholders of record at the close of business on August 20, 2015.

[0001437749-15-014196:8k_2_02:28]
“Since the dividend was initiated in 2010, we have increased it at a compound annual growth rate of 15%,” said Phil Franklin, chief financial officer. “As previously indicated, we will be revisiting our capital allocation targets in the coming months and, if M&A activity does not pick up, will increase the percentage of free cash returned to shareholders.”

[0001437749-15-014196:8k_2_02:29]
-more-

[0001437749-15-014196:8k_2_02:30]
Conference Call and Webcast Information

[0001437749-15-014196:8k_2_02:31]
Littelfuse will host a conference call today, Wednesday, July 29, 2015, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the second quarter results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay through September 30, 2015 on the company’s website.

[0001437749-15-014196:8k_2_02:32]
About Littelfuse

[0001437749-15-014196:8k_2_02:33]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 8,000 employees in more than 35 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: littelfuse.com.

[0001437749-15-014196:8k_2_02:34]
The statements in this press release that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended December 27, 2014. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended December 27, 2014.

[0001437749-15-014196:8k_2_02:35]
LFUS-F

[0001437749-15-014196:8k_2_02:36]
# # #

[0001437749-15-014196:8k_2_02:37]
LITTELFUSE, INC.

[0001437749-15-014196:8k_2_02:38]
Net Sales and Operating Income by Business Unit

[0001437749-15-014196:8k_2_02:39]
(In thousands of USD, unaudited)

[0001437749-15-014196:8k_2_02:40]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 105,553 |  |  | $ | 109,947 |  |  |  | (4 | %) |  | $ | 204,933 |  |  | $ | 205,972 |  |  |  | (1 | %) |
| Automotive |  |  | 85,918 |  |  |  | 82,042 |  |  |  | 5 | % |  |  | 169,989 |  |  |  | 164,444 |  |  |  | 3 | % |
| Electrical |  |  | 30,550 |  |  |  | 28,919 |  |  |  | 6 | % |  |  | 57,412 |  |  |  | 57,351 |  |  |  | 0 | % |
| Total net sales |  | $ | 222,021 |  |  | $ | 220,908 |  |  |  | 1 | % |  | $ | 432,334 |  |  | $ | 427,767 |  |  |  | 1 | % |

[0001437749-15-014196:8k_2_02:41]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 22,167 |  |  | $ | 25,634 |  |  |  | (14 | %) |  | $ | 40,832 |  |  | $ | 45,005 |  |  |  | (9 | %) |
| Automotive |  |  | 12,699 |  |  |  | 11,049 |  |  |  | 15 | % |  |  | 23,870 |  |  |  | 22,931 |  |  |  | 4 | % |
| Electrical |  |  | 4,709 |  |  |  | 571 |  |  |  | 725 | % |  |  | 7,439 |  |  |  | 4,317 |  |  |  | 72 | % |
| Other (1) |  |  | (3,404 | ) |  |  | (3,535 | ) |  |  | (4 | %) |  |  | (6,422 | ) |  |  | (4,944 | ) |  |  | 30 | % |
| Total operating income |  | $ | 36,171 |  |  | $ | 33,719 |  |  |  | 7 | % |  | $ | 65,719 |  |  | $ | 67,309 |  |  |  | (2 | %) |
| Interest expense |  |  | 948 |  |  |  | 1,228 |  |  |  |  |  |  |  | 2,099 |  |  |  | 2,444 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | (1,292 | ) |  |  | 2,375 |  |  |  |  |  |  |  | 1,825 |  |  |  | 2,123 |  |  |  |  |  |
| Other (income) expense, net |  |  | (1,202 | ) |  |  | (1,446 | ) |  |  |  |  |  |  | (2,328 | ) |  |  | (2,632 | ) |  |  |  |  |
| Income before taxes |  | $ | 37,717 |  |  | $ | 31,562 |  |  |  | 20 | % |  | $ | 64,123 |  |  | $ | 65,374 |  |  |  | (2 | %) |

[0001437749-15-014196:8k_2_02:42]
(1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details on page 8.)

[0001437749-15-014196:8k_2_02:43]
-more-

[0001437749-15-014196:8k_2_02:44]
LITTELFUSE, INC.

[0001437749-15-014196:8k_2_02:45]
Condensed Consolidated Balance Sheets

[0001437749-15-014196:8k_2_02:46]
(In thousands of USD, except share amounts)

[0001437749-15-014196:8k_2_02:47]
|  |  | June 27, 2015 |  |  | December 27, 2014 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 311,915 |  |  | $ | 297,571 |  |
| Short-term investments |  |  | 3,954 |  |  |  | 4,302 |  |
| Accounts receivable, less allowances |  |  | 151,283 |  |  |  | 135,356 |  |
| Inventories |  |  | 97,735 |  |  |  | 97,391 |  |
| Deferred income taxes |  |  | 17,378 |  |  |  | 17,481 |  |
| Prepaid expenses and other current assets |  |  | 15,357 |  |  |  | 13,904 |  |
| Assets held for sale |  |  | 5,500 |  |  |  | 5,500 |  |
| Total current assets |  |  | 603,122 |  |  |  | 571,505 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 5,542 |  |  |  | 5,697 |  |
| Buildings |  |  | 63,546 |  |  |  | 64,609 |  |
| Equipment |  |  | 389,026 |  |  |  | 370,179 |  |
|  |  |  | 458,114 |  |  |  | 440,485 |  |
| Accumulated depreciation |  |  | (291,735 | ) |  |  | (281,845 | ) |
| Net property, plant and equipment |  |  | 166,379 |  |  |  | 158,640 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 21,449 |  |  |  | 23,640 |  |
| Distribution network |  |  | 17,813 |  |  |  | 19,428 |  |
| Customer lists, trademarks and tradenames |  |  | 58,018 |  |  |  | 60,605 |  |
| Goodwill |  |  | 192,947 |  |  |  | 196,256 |  |
|  |  |  | 290,227 |  |  |  | 299,929 |  |
| Investments |  |  | 14,503 |  |  |  | 12,056 |  |
| Deferred income taxes |  |  | 5,604 |  |  |  | 5,393 |  |
| Other assets |  |  | 19,456 |  |  |  | 23,303 |  |
| Total assets |  | $ | 1,099,291 |  |  | $ | 1,070,826 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 53,919 |  |  | $ | 50,793 |  |
| Accrued payroll |  |  | 25,501 |  |  |  | 30,511 |  |
| Accrued expenses |  |  | 19,668 |  |  |  | 13,059 |  |
| Accrued severance |  |  | 2,033 |  |  |  | 790 |  |
| Accrued income taxes |  |  | 8,547 |  |  |  | 9,045 |  |
| Current portion of accrued post-retirement benefits |  |  | 11,768 |  |  |  | 11,768 |  |
| Current portion of long-term debt |  |  | 82,250 |  |  |  | 88,500 |  |
| Total current liabilities |  |  | 203,686 |  |  |  | 204,466 |  |
| Long-term debt, less current portion |  |  | 96,993 |  |  |  | 106,658 |  |
| Deferred income taxes |  |  | 11,173 |  |  |  | 11,076 |  |
| Accrued post-retirement benefits |  |  | 5,247 |  |  |  | 5,147 |  |
| Other long-term liabilities |  |  | 14,900 |  |  |  | 15,814 |  |
| Total equity |  |  | 767,292 |  |  |  | 727,665 |  |
| Total liabilities and equity |  | $ | 1,099,291 |  |  | $ | 1,070,826 |  |
| Common shares issued and outstanding of 22,725,882 and 22,585,529 at June 27, 2015 and December 27, 2014, respectively. |  |  |  |  |  |  |  |  |

[0001437749-15-014196:8k_2_02:48]
-more-

[0001437749-15-014196:8k_2_02:49]
LITTELFUSE, INC.

[0001437749-15-014196:8k_2_02:50]
Consolidated Statements of Comprehensive Income

[0001437749-15-014196:8k_2_02:51]
(In thousands of USD, except per share data, unaudited)

[0001437749-15-014196:8k_2_02:52]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| Net sales |  | $ | 222,021 |  |  | $ | 220,908 |  |  | $ | 432,334 |  |  | $ | 427,767 |  |
| Cost of sales |  |  | 136,740 |  |  |  | 137,913 |  |  |  | 270,723 |  |  |  | 266,278 |  |
| Gross profit |  |  | 85,281 |  |  |  | 82,995 |  |  |  | 161,611 |  |  |  | 161,489 |  |
| Selling, general and administrative expenses |  |  | 38,772 |  |  |  | 38,328 |  |  |  | 75,117 |  |  |  | 72,499 |  |
| Research and development expenses |  |  | 7,361 |  |  |  | 7,810 |  |  |  | 14,745 |  |  |  | 15,384 |  |
| Amortization of intangibles |  |  | 2,977 |  |  |  | 3,138 |  |  |  | 6,030 |  |  |  | 6,297 |  |
|  |  |  | 49,110 |  |  |  | 49,276 |  |  |  | 95,892 |  |  |  | 94,180 |  |
| Operating income |  |  | 36,171 |  |  |  | 33,719 |  |  |  | 65,719 |  |  |  | 67,309 |  |
| Interest expense |  |  | 948 |  |  |  | 1,228 |  |  |  | 2,099 |  |  |  | 2,444 |  |
| Foreign exchange (gain) loss |  |  | (1,292 | ) |  |  | 2,375 |  |  |  | 1,825 |  |  |  | 2,123 |  |
| Other (income) expense, net |  |  | (1,202 | ) |  |  | (1,446 | ) |  |  | (2,328 | ) |  |  | (2,632 | ) |
| Income before income taxes |  |  | 37,717 |  |  |  | 31,562 |  |  |  | 64,123 |  |  |  | 65,374 |  |
| Income taxes |  |  | 9,033 |  |  |  | 6,984 |  |  |  | 15,444 |  |  |  | 15,407 |  |
| Net income |  | $ | 28,684 |  |  | $ | 24,578 |  |  | $ | 48,679 |  |  | $ | 49,967 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.26 |  |  | $ | 1.09 |  |  | $ | 2.15 |  |  | $ | 2.22 |  |
| Diluted |  | $ | 1.26 |  |  | $ | 1.08 |  |  | $ | 2.13 |  |  | $ | 2.20 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,691 |  |  |  | 22,579 |  |  |  | 22,645 |  |  |  | 22,536 |  |
| Diluted |  |  | 22,835 |  |  |  | 22,750 |  |  |  | 22,810 |  |  |  | 22,738 |  |
| Comprehensive income |  | $ | 34,672 |  |  | $ | 33,743 |  |  | $ | 43,709 |  |  | $ | 52,235 |  |

[0001437749-15-014196:8k_2_02:53]
-more-

[0001437749-15-014196:8k_2_02:54]
LITTELFUSE, INC.

[0001437749-15-014196:8k_2_02:55]
Consolidated Statements of Cash Flows

[0001437749-15-014196:8k_2_02:56]
(In thousands of USD, unaudited)

[0001437749-15-014196:8k_2_02:57]
|  |  | For the Six Months Ended |  |
|  |  | June 27, 2015 |  |  | June 28, 2014 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 48,679 |  |  | $ | 49,967 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 14,761 |  |  |  | 14,459 |  |
| Amortization of intangibles |  |  | 6,030 |  |  |  | 6,297 |  |
| Non-cash inventory charge (1) |  |  | - |  |  |  | 2,769 |  |
| Stock-based compensation |  |  | 5,764 |  |  |  | 5,229 |  |
| Excess tax benefit on stock-based compensation |  |  | (1,470 | ) |  |  | (2,230 | ) |
| Loss on sale of assets |  |  | 329 |  |  |  | 141 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (21,266 | ) |  |  | (17,871 | ) |
| Inventories |  |  | (1,199 | ) |  |  | 410 |  |
| Accounts payable |  |  | 3,440 |  |  |  | 2,533 |  |
| Accrued expenses (including post retirement) |  |  | 11,129 |  |  |  | (7,578 | ) |
| Accrued payroll and severance |  |  | (3,652 | ) |  |  | (7,323 | ) |
| Accrued taxes |  |  | (3,003 | ) |  |  | (2,101 | ) |
| Prepaid expenses and other |  |  | 2,422 |  |  |  | (2,189 | ) |
| Net cash provided by operating activities |  |  | 61,964 |  |  |  | 42,513 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (26,388 | ) |  |  | (13,132 | ) |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (52,768 | ) |
| Decrease in entrusted loan receivable |  |  | 3,519 |  |  |  | - |  |
| Proceeds from sale of assets |  |  | 48 |  |  |  | 37 |  |
| Net cash used in investing activities |  |  | (22,821 | ) |  |  | (65,863 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 11,000 |  |  |  | 97,500 |  |
| Payments of revolving credit facility |  |  | (21,000 | ) |  |  | (19,500 | ) |
| Payments of term loan |  |  | (2,500 | ) |  |  | (2,500 | ) |
| Payments of entrusted loan |  |  | (3,519 | ) |  |  | - |  |
| Debt issuance costs paid |  |  | (42 | ) |  |  | (108 | ) |
| Cash dividends paid |  |  | (11,296 | ) |  |  | (9,921 | ) |
| Purchases of common stock |  |  | - |  |  |  | (14,283 | ) |
| Proceeds from exercise of stock options |  |  | 6,278 |  |  |  | 11,101 |  |
| Excess tax benefit on share-based compensation |  |  | 1,470 |  |  |  | 2,230 |  |
| Net cash (used in) provided by financing activities |  |  | (19,609 | ) |  |  | 64,519 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (5,192 | ) |  |  | 45 |  |
| Increase in cash and cash equivalents |  |  | 14,344 |  |  |  | 41,214 |  |
| Cash and cash equivalents at beginning of period |  |  | 297,571 |  |  |  | 305,192 |  |
| Cash and cash equivalents at end of period |  | $ | 311,915 |  |  | $ | 346,406 |  |

[0001437749-15-014196:8k_2_02:58]
(1) Purchase accounting adjustment related to acquisitions.

[0001437749-15-014196:8k_2_02:59]
-more-

[0001437749-15-014196:8k_2_02:60]
LITTELFUSE, INC.

[0001437749-15-014196:8k_2_02:61]
Supplemental Financial Information

[0001437749-15-014196:8k_2_02:62]
(in millions of USD except share amounts)

[0001437749-15-014196:8k_2_02:63]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-15 |  |  | Q2-15 |  |  | YTD-15 |  |  | Q1-14 |  |  | Q2-14 |  |  | YTD-14 |  |
| GAAP diluted EPS |  | $ | 0.88 |  |  | $ | 1.26 |  |  | $ | 2.13 |  |  | $ | 1.12 |  |  | $ | 1.08 |  |  | $ | 2.20 |  |
| EPS impact of special items (below) |  |  | 0.20 |  |  |  | 0.07 |  |  |  | 0.27 |  |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.22 |  |
| Adjusted diluted EPS |  | $ | 1.08 |  |  | $ | 1.33 |  |  | $ | 2.40 |  |  | $ | 1.16 |  |  | $ | 1.26 |  |  | $ | 2.42 |  |
| Year-over-year adjusted EPS growth |  |  | -7 | % |  |  | 6 | % |  |  | -1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Special Items (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.9 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Restructuring |  |  | 1.2 |  |  |  | 1.7 |  |  |  | 2.9 |  |  |  | - |  |  |  | 2.0 |  |  |  | 2.0 |  |
| Acquisition expenses |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | - |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Pension wind-up |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 1.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Purchase accounting adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.4 |  |  |  | 1.4 |  |  |  | 2.8 |  |
| Adjustment to Operating income |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 6.4 |  |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 5.0 |  |
| Foreign exchange loss/(gain) |  |  | 3.1 |  |  |  | (1.3 | ) |  |  | 1.8 |  |  |  | (0.3 | ) |  |  | 2.4 |  |  |  | 2.1 |  |
| Adjustment to pre-tax income |  | $ | 6.1 |  |  | $ | 2.1 |  |  | $ | 8.2 |  |  | $ | 1.2 |  |  | $ | 6.0 |  |  | $ | 7.2 |  |
| Total EPS impact |  | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 0.27 |  |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.22 |  |

[0001437749-15-014196:8k_2_02:64]
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-15 |  |  | Q2-15 |  |  | YTD-15 |  |  | Q1-14 |  |  | Q2-14 |  |  | YTD-14 |  |
| Net sales |  | $ | 210.3 |  |  | $ | 222.0 |  |  | $ | 432.3 |  |  | $ | 206.9 |  |  | $ | 220.9 |  |  | $ | 427.8 |  |
| GAAP operating income |  | $ | 29.5 |  |  | $ | 36.2 |  |  | $ | 65.7 |  |  | $ | 33.6 |  |  | $ | 33.7 |  |  | $ | 67.3 |  |
| Add back special operating items |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 6.4 |  |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 5.0 |  |
| Adjusted operating income |  | $ | 32.5 |  |  | $ | 39.6 |  |  | $ | 72.1 |  |  | $ | 35.0 |  |  | $ | 37.2 |  |  | $ | 72.3 |  |
| Adjusted operating margin |  |  | 15.5 | % |  |  | 17.8 | % |  |  | 16.7 | % |  |  | 16.9 | % |  |  | 16.8 | % |  |  | 16.9 | % |
| Add back amortization |  |  | 3.1 |  |  |  | 2.9 |  |  |  | 6.0 |  |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 6.3 |  |
| Add back depreciation |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 14.8 |  |  |  | 7.0 |  |  |  | 7.5 |  |  |  | 14.5 |  |
| Adjusted EBITDA |  | $ | 43.0 |  |  | $ | 49.9 |  |  | $ | 92.9 |  |  | $ | 45.2 |  |  | $ | 47.8 |  |  | $ | 93.0 |  |
| Adjusted EBITDA margin |  |  | 20.4 | % |  |  | 22.5 | % |  |  | 21.5 | % |  |  | 21.8 | % |  |  | 21.6 | % |  |  | 21.7 | % |
| Year-over-year adjusted EBITDA growth |  |  | -5 | % |  |  | 4 | % |  |  | 0 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-15-014196:8k_2_02:65]
Note: Totals will not always foot due to rounding

[0001437749-15-014196:8k_2_02:66]
# # #
