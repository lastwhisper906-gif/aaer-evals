# LFUS 10-Q controls and the auditor's report


## item_4_controls

[0001437749-15-014442:item_4_controls:1]
Item 4. Controls and Procedures.

[0001437749-15-014442:item_4_controls:2]
As of June 27, 2015, the Chief Executive Officer and Chief Financial Officer of the company evaluated the effectiveness of the disclosure controls and procedures of the company and concluded that these disclosure controls and procedures are effective to ensure that material information relating to the company and its consolidated subsidiaries has been made known to them by the employees of the company and its consolidated subsidiaries during the period preceding the filing of this Quarterly Report on Form 10-Q and that such information is accurately recorded, processed, summarized and reported within the time periods specified in SEC rules. There were no significant changes in the company’s internal controls during the period covered by this Report that could materially affect these controls or could reasonably be expected to materially affect the company’s internal control reporting, disclosures and procedures subsequent to the last day they were evaluated by the company’s Chief Executive Officer and Chief Financial Officer.

[0001437749-15-014442:item_4_controls:3]
19
