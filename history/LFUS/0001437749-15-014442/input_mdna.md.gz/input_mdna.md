# LFUS MD&A — 0001437749-15-014442


## mdna

[0001437749-15-014442:mdna:1]
[same as prior period, unchanged from 0001437749-15-008576:mdna:1]

[0001437749-15-014442:mdna:2]
[same as prior period, unchanged from 0001437749-15-008576:mdna:2]

[0001437749-15-014442:mdna:3]
[same as prior period, unchanged from 0001437749-15-008576:mdna:3]

[0001437749-15-014442:mdna:4]
[same as prior period, unchanged from 0001437749-15-008576:mdna:4]

[0001437749-15-014442:mdna:5]
[same as prior period, unchanged from 0001437749-15-008576:mdna:5]

[0001437749-15-014442:mdna:6]
[same as prior period, unchanged from 0001437749-15-008576:mdna:6]

[0001437749-15-014442:mdna:7]
[same as prior period, unchanged from 0001437749-15-008576:mdna:7]

[0001437749-15-014442:mdna:8]
[same as prior period, unchanged from 0001437749-15-008576:mdna:8]

[0001437749-15-014442:mdna:9]
[same as prior period, unchanged from 0001437749-15-008576:mdna:9]

[0001437749-15-014442:mdna:10]
[same as prior period, unchanged from 0001437749-15-008576:mdna:10]

[0001437749-15-014442:mdna:11]
[same as prior period, unchanged from 0001437749-15-008576:mdna:11]

[0001437749-15-014442:mdna:12]
[same as prior period, unchanged from 0001437749-15-008576:mdna:12]

[0001437749-15-014442:mdna:13]
The Electronics segment sells passive and semiconductor components and modules as well as sensors primarily into the global consumer electronics, general industrial and telecommunications markets. The core electronics markets are characterized by significant Asia competition and price erosion. As a result, the company is focusing additional efforts on higher growth, less price sensitive niche markets (such as LED lighting) and higher-power industrial applications.

[0001437749-15-014442:mdna:14]
[same as prior period, unchanged from 0001437749-15-008576:mdna:14]

[0001437749-15-014442:mdna:15]
The Automotive segment is comprised of passenger vehicle circuit protection, commercial vehicle products and sensors for vehicle applications. The primary growth drivers for these businesses are increasing global demand for passenger and commercial vehicles and increasing content per vehicle for both circuit protection and sensing products. The move away from internal combustion engines to hybrid and electric drive systems that require more circuit protection is expected to be an additional growth driver.

[0001437749-15-014442:mdna:16]
[same as prior period, unchanged from 0001437749-15-008576:mdna:16]

[0001437749-15-014442:mdna:17]
The Electrical segment derives its revenues from power fuses, protection relays and custom products selling primarily into the industrial, mining, solar and oil and gas markets. Custom products sales, after several years of strong growth, have declined due to the completion of several large Canadian potash mining projects. The company has expanded this business by moving into new markets such as non-potash mining and oil and gas. Protection relay sales have also slowed due to the general slowdown in the global mining market.

[0001437749-15-014442:mdna:18]
[same as prior period, unchanged from 0001437749-15-008576:mdna:18]

[0001437749-15-014442:mdna:19]
[same as prior period, unchanged from 0001437749-15-008576:mdna:19]

[0001437749-15-014442:mdna:20]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  |  | $ | 105,553 |  |  | $ | 109,947 |  |  |  | (4 | %) |  | $ | 204,933 |  |  | $ | 205,972 |  |  |  | (1 | %) |
| Automotive |  |  |  | 85,918 |  |  |  | 82,042 |  |  |  | 5 | % |  |  | 169,989 |  |  |  | 164,444 |  |  |  | 3 | % |
| Electrical |  |  |  | 30,550 |  |  |  | 28,919 |  |  |  | 6 | % |  |  | 57,412 |  |  |  | 57,351 |  |  |  | 0 | % |
| Total |  |  | $ | 222,021 |  |  | $ | 220,908 |  |  |  | 1 | % |  | $ | 432,334 |  |  | $ | 427,767 |  |  |  | 1 | % |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | $ | 103,033 |  |  | $ | 95,874 |  |  |  | 7 | % |  | $ | 200,087 |  |  | $ | 185,025 |  |  |  | 8 | % |
| Europe |  |  |  | 39,125 |  |  |  | 44,296 |  |  |  | (12 | %) |  |  | 78,093 |  |  |  | 88,223 |  |  |  | (11 | %) |
| Asia-Pacific |  |  |  | 79,863 |  |  |  | 80,738 |  |  |  | (1 | %) |  |  | 154,154 |  |  |  | 154,519 |  |  |  | (0 | %) |
| Total |  |  | $ | 222,021 |  |  | $ | 220,908 |  |  |  | 1 | % |  | $ | 432,334 |  |  | $ | 427,767 |  |  |  | 1 | % |

[0001437749-15-014442:mdna:21]
[same as prior period, unchanged from 0001437749-15-008576:mdna:22]

[0001437749-15-014442:mdna:22]
Results of Operations – Second Quarter, 2015 compared to 2014

[0001437749-15-014442:mdna:23]
The following table summarizes the company’s consolidated results of operations for the periods presented. During the second quarter of 2015, there was approximately $3.4 million of special charges ($6.4 million year-to-date) consisting of $0.9 million ($1.9 million year-to-date) related to the company’s transfer of its reed sensor manufacturing from the U.S. to the Philippines, $1.7 million ($2.9 million year-to-date) related to internal legal restructuring, $0.2 million ($0.3 million year-to-date) related to acquisition costs and $0.7 million ($1.3 million year-to-date) of expense related to the planned termination of the U.S. pension as described in Note 9.

[0001437749-15-014442:mdna:24]
| (In thousands, unaudited) |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Sales |  | $ | 222,021 |  |  | $ | 220,908 |  |  |  | 1 | % |  | $ | 432,334 |  |  | $ | 427,767 |  |  |  | 1 | % |
| Gross Profit |  |  | 85,281 |  |  |  | 82,995 |  |  |  | 3 | % |  |  | 161,611 |  |  |  | 161,489 |  |  |  | 0 | % |
| Operating expense |  |  | 49,110 |  |  |  | 49,276 |  |  |  | (0 | %) |  |  | 95,892 |  |  |  | 94,180 |  |  |  | 2 | % |
| Operating income |  |  | 36,171 |  |  |  | 33,719 |  |  |  | 7 | % |  |  | 65,719 |  |  |  | 67,309 |  |  |  | (2 | %) |
| Other (income) expense, net |  |  | (1,202 | ) |  |  | (1,446 | ) |  |  | (17 | %) |  |  | (2,328 | ) |  |  | (2,632 | ) |  |  | (12 | %) |
| Income before income taxes |  |  | 37,717 |  |  |  | 31,562 |  |  |  | 20 | % |  |  | 64,123 |  |  |  | 65,374 |  |  |  | (2 | %) |
| Net income |  | $ | 28,684 |  |  | $ | 24,578 |  |  |  | 17 | % |  | $ | 48,679 |  |  | $ | 49,967 |  |  |  | (3 | %) |

[0001437749-15-014442:mdna:25]
Net sales increased $1.1 million or 1% to $222.0 million in the second quarter of 2015 compared to $220.9 million in the second quarter of 2014 due primarily to growth in automotive and electrical sales, offset by lower electronics sales. The company also experienced $11.3 million in unfavorable foreign currency effects in the second quarter of 2015 as compared to the second quarter of 2014. The unfavorable foreign currency impact primarily resulted from sales denominated in the euro. Excluding currency effects, net sales increased $12.4 million or 6% year-over-year.

[0001437749-15-014442:mdna:26]
Electronics sales decreased $4.4 million or 4% to $105.6 million in the second quarter of 2015 compared to $109.9 million in the second quarter of 2014 due primarily to lower sales of semiconductor and sensor products. The electronics segment experienced $3.6 million in unfavorable currency effects in the second quarter of 2015 primarily from sales denominated in euros. Excluding currency effects, net sales decreased $0.8 million or 1% year-over-year.

[0001437749-15-014442:mdna:27]
Automotive sales increased $3.9 million or 5% to $85.9 million in the second quarter of 2015 compared to $82.0 million in the second quarter of 2014 due to strong growth for sensors and commercial vehicle products partially offset by lower fuse sales. The automotive segment experienced $6.6 million in unfavorable currency effects in the second quarter of 2015 primarily due to sales denominated in euros. Excluding currency effects, net sales increased $10.5 million or 13% year-over-year.

[0001437749-15-014442:mdna:28]
Electrical sales increased $1.6 million or 6% to $30.6 million in the second quarter of 2015 compared to $28.9 million in the second quarter of 2014 as higher fuse and custom sales were offset by weaker relay sales. The electrical segment experienced $1.0 million in unfavorable currency effects in the second quarter of 2015 primarily from sales denominated in Canadian dollars and the euro. Excluding currency effects, net sales increased $2.6 million or 9% year-over-year.

[0001437749-15-014442:mdna:29]
On a geographic basis, sales in the Americas increased $7.2 million or 7% to $103.0 million in the second quarter of 2015 compared to $95.9 million in the second quarter of 2014 due primarily to strong growth in auto and electrical sales offset by $0.6 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding currency effects, the Americas sales increased $7.8 million or 8%.

[0001437749-15-014442:mdna:30]
Europe sales decreased $5.2 million or 12% to $39.1 million in the second quarter of 2015 compared to $44.3 million in the second quarter of 2014 mainly due to $10.3 million in unfavorable currency effects reflecting a decline in the euro during the current year quarter. Excluding currency effects, Europe sales increased $5.2 million or 12% reflecting strong demand for automotive products.

[0001437749-15-014442:mdna:31]
Asia-Pacific sales decreased $0.9 million or 1% to $79.9 million in the second quarter of 2015 compared to $80.7 million in the second quarter of 2014 due to a decline in electronics and electrical products and $0.3 million in unfavorable currency effects offset by strong demand for automotive products. Excluding currency effects, Asia-Pacific sales increased $0.6 million or 1% year-over-year.

[0001437749-15-014442:mdna:32]
Gross profit was $85.3 million or 38% of net sales for the second quarter of 2015 compared to $83.0 million or 38% of net sales in the same quarter last year. Gross profit for the second quarter of 2015 included $0.9 million of charges related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines. Gross profit for the second quarter of 2014 included a $1.4 million non-cash charge to cost of goods sold for inventory that was stepped up to fair value as a result of the SymCom acquisition and $2.0 million in severance charges resulting from restructuring at the Hamlin-Mexico plant. Excluding the impact of these charges, gross profit was 39% of net sales for both the second quarter of 2015 and 2014.

[0001437749-15-014442:mdna:33]
Total operating expense was $49.1 million or 22% of net sales for the second quarter of 2015 compared to $49.3 million or 22% of net sales for the same quarter in 2014. The slight decrease in operating expenses primarily reflects lower research and development costs offset by higher internal legal restructuring costs and costs related to the wind-up of the U.S. pension plan.

[0001437749-15-014442:mdna:34]
Operating income for the second quarter of 2015 was approximately $36.2 million compared to operating income of $33.7 million for the same quarter in 2014 primarily as a result of higher sales and slightly lower operating expenses as described above.

[0001437749-15-014442:mdna:35]
Interest expense was $0.9 million in the second quarter of 2015 and $1.2 million in the second quarter of 2014 and reflects interest incurred for borrowing on the company’s credit agreement.

[0001437749-15-014442:mdna:36]
Foreign exchange loss (gain), reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $1.3 million of income for the second quarter of 2015 as compared to $2.4 million of expense for the second quarter of 2014 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar.

[0001437749-15-014442:mdna:37]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $1.2 million of income for second quarter of 2015 and $1.5 million of income for the second quarter of 2014.

[0001437749-15-014442:mdna:38]
Income before income taxes was $37.7 million for the second quarter of 2015 compared to $31.6 million for the second quarter of 2014. Income tax expense was $9.0 million with an effective tax rate of 23.9% for the second quarter of 2015 compared to income tax expense of $7.0 million with an effective tax rate of 22.1% in the second quarter of 2014. The effective tax rates for both the second quarter of 2015 and 2014 are lower than the U.S. statutory tax rate primarily due to more income earned in low tax jurisdictions.

[0001437749-15-014442:mdna:39]
Net income for the second quarter of 2015 was $28.7 million or $1.26 per diluted share compared to net income of $24.6 million or $1.08 per diluted share for the same quarter of 2014.

[0001437749-15-014442:mdna:40]
Results of Operations – Six months, 2015 compared to 2014

[0001437749-15-014442:mdna:41]
Net sales increased $4.6 million or 1% to $432.3 million for the first six months of 2015 compared to $427.8 million in the first six months of 2014 due primarily to strong growth in automotive products, partially offset by lower electronics sales. The company also experienced $21.2 million in unfavorable foreign currency effects in the first six months of 2015 as compared to 2014 primarily resulting from sales denominated in the euro. Excluding currency effects, net sales increased $25.7 million or 6% year-over-year.

[0001437749-15-014442:mdna:42]
Electronics sales decreased $1.0 million or 1% to $204.9 million for the first six months of 2015 compared to $206.0 million in the first six months of 2014 due primarily to negative currency effects offset by strong growth for fuse products. The electronics segment experienced $6.6 million in unfavorable currency effects in the first six months of 2015 primarily from sales denominated in euro. Excluding currency effects, net sales increased $5.5 million or 3% year-over-year.

[0001437749-15-014442:mdna:43]
Automotive sales increased $5.5 million or 3% to $170.0 million in the first six months of 2015 compared to $164.4 million in the first six months of 2014 due to strong growth for sensors and commercial vehicle products offset by lower fuse sales. The automotive segment experienced $12.5 million in unfavorable currency effects in the first six months of 2015 primarily due to sales denominated in euros. Excluding currency effects, net sales increased $18.1 million or 11% year-over-year.

[0001437749-15-014442:mdna:44]
Electrical sales, before currency effects, were flat year-over year at $57.4 million in the first six months of 2015 compared to $57.4 million in the first six months of 2014 as higher custom and fuse sales were offset by weaker relay sales. The electrical segment experienced $2.1 million in unfavorable currency effects in the first six months of 2015 primarily from sales denominated in Canadian dollars and the euro. Excluding currency effects, net sales increased $2.1 million or 4% year-over-year.

[0001437749-15-014442:mdna:45]
On a geographic basis, sales in the Americas increased $15.1 million or 8% to $200.1 million in the first six months of 2015 compared to $185.0 million in the first six months of 2014 due primarily to strong growth in auto and electronics sales offset by $1.3 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding currency effects, the Americas sales increased $16.4 million or 9%.

[0001437749-15-014442:mdna:46]
Europe sales decreased $10.1 million or 11% to $78.1 million in the first six months of 2015 compared to $88.2 million in the first six months of 2014 mainly due to $19.2 million in unfavorable currency effects reflecting a decline in the euro during the first six months. Excluding currency effects, Europe sales increased $9.1 million or 10% reflecting strong demand for automotive products.

[0001437749-15-014442:mdna:47]
Asia-Pacific sales decreased $0.4 million or less than 1% to $154.2 million in the first six months of 2015 compared to $154.5 million in the first six months of 2014 due primarily to strong demand for automotive products offset by lower electronics sales and unfavorable currency effects of $0.6 million. Excluding currency effects, Asia-Pacific sales increased $0.3 million or less than 1% year-over-year.

[0001437749-15-014442:mdna:48]
Gross profit was $161.6 million or 37% of net sales for the first six months of 2015 compared to $161.5 million or 38% of net sales for the first six months of 2014. Gross profit for the first six months of 2015 included $1.9 million of charges related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines. Gross profit for the first six months of 2014 included a $2.8 million non-cash charge to cost of goods sold for inventory that was stepped up to fair value as a result of the SymCom acquisition and $2.0 million in severance charges resulting from restructuring at the Hamlin-Mexico plant. Excluding the impact of these charges, gross profit was 38% of net sales for the first six months of 2015 as compared to 39% for the first six months of 2014. The decrease in gross profit margin compared to the prior year was primarily attributable to foreign exchange losses primarily due to the decline in the euro.

[0001437749-15-014442:mdna:49]
Total operating expense was $95.9 million or 22% of net sales for the first six months of 2015 compared to $94.2 million or 22% of net sales for the first six months of 2014. The increase in operating expenses primarily reflects higher wage and benefit costs, internal legal restructuring costs and costs related to the wind-up of the U.S. pension plan offset by lower amortization of intangibles and research and development costs

[0001437749-15-014442:mdna:50]
Operating income for the first six months of 2015 was approximately $65.7 million compared to operating income of $67.3 million for the first six months of 2014, primarily as a result of the negative impact of foreign exchange on sales and gross profit as discussed above.

[0001437749-15-014442:mdna:51]
Interest expense was $2.1 million for the first six months of 2015 compared to $2.4 million for the first six months of 2014 and reflects interest for borrowing on the company’s credit agreement.

[0001437749-15-014442:mdna:52]
Foreign exchange loss (gain), reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $1.8 million of expense for the first six months of 2015 compared to $2.1 million of expense for the first six months of 2014 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar.

[0001437749-15-014442:mdna:53]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $2.3 million of income for the first six months of 2015 compared to $2.6 million of income for the first six months of 2014.

[0001437749-15-014442:mdna:54]
Income before income taxes was $64.1 million for the second quarter of 2015 compared to $65.4 million for the first six months of 2014. Income tax expense was $15.4 million with an effective tax rate of 24.1% for the first six months of 2015 compared to income tax expense of $15.4 million with an effective tax rate of 23.6% in the first six months of 2014. The effective tax rates for both 2015 and 2014 are lower than the U.S. statutory tax rate primarily due to more income earned in low tax jurisdictions.

[0001437749-15-014442:mdna:55]
Net income for the first six months of 2015 was $48.7 million or $2.13 per diluted share compared to net income of $50.0 million or $2.20 per diluted share for the same period of 2014.

[0001437749-15-014442:mdna:56]
[same as prior period, unchanged from 0001437749-15-008576:mdna:41]

[0001437749-15-014442:mdna:57]
As of June 27, 2015, $302.1 million of the $311.9 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $302.1 million held by foreign subsidiaries, approximately $17.7 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $17.7 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-15-014442:mdna:58]
[same as prior period, unchanged from 0001437749-15-008576:mdna:43]

[0001437749-15-014442:mdna:59]
[same as prior period, unchanged from 0001437749-15-008576:mdna:44]

[0001437749-15-014442:mdna:60]
In 2013, the company entered into a credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consists of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The credit agreement is for a five year period.

[0001437749-15-014442:mdna:61]
On January 30, 2014, the company increased the unsecured revolving credit facility by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. At June 27, 2015, the company had available $200.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of June 27, 2015).

[0001437749-15-014442:mdna:62]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 27, 2015, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-15-014442:mdna:63]
The company also had $0.6 million outstanding in letters of credit at June 27, 2015. No amounts were drawn under these letters of credit at June 27, 2015.

[0001437749-15-014442:mdna:64]
[same as prior period, unchanged from 0001437749-15-008576:mdna:49]

[0001437749-15-014442:mdna:65]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Net Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 88.5 million (approximately $14.5 million) at June 27, 2015.

[0001437749-15-014442:mdna:66]
[same as prior period, unchanged from 0001437749-15-008576:mdna:51]

[0001437749-15-014442:mdna:67]
The company started 2015 with $297.6 million of cash and cash equivalents. Net cash provided by operating activities was approximately $62.0 million for the first six months of 2015 reflecting $48.7 million in net income and $25.4 million in non-cash adjustments (primarily $20.8 million in depreciation and amortization) offset by $12.1 million in net changes to various operating assets and liabilities.

[0001437749-15-014442:mdna:68]
Changes in operating assets and liabilities for the first six months of 2015 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivable ($21.3 million) and inventory ($1.2 million), and decreases in accrued payroll and severance ($3.7 million) and accrued and deferred taxes ($3.0 million). The increase in accounts receivable was due to increased sales in the first six months of 2015. The decrease in accrued payroll and severance was due primarily to payouts for the 2014 management incentive plan which occurred in the first quarter. Other changes having a positive impact on cash flows were increases in prepaid and other assets ($2.4 million), accounts payable ($3.4 million) and accrued expenses ($11.1 million).

[0001437749-15-014442:mdna:69]
Net cash used in investing activities was approximately $22.8 million for the first six months of 2015 and represented capital spending ($26.4 million) offset by a reduction in the entrusted loan receivable ($3.5 million) (see Note 5) .

[0001437749-15-014442:mdna:70]
Net cash used in financing activities was approximately $19.6 million and included $12.5 million in net payments on borrowings from the company’s credit agreement, $3.5 million in payments on the entrusted loan (see Note 5) and dividends paid of $11.3 million offset by $7.7 million from the exercise of stock options including tax benefits. The effects of exchange rate changes decreased cash and cash equivalents by approximately $5.2 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $14.3 million increase in cash, which left the company with a cash and cash equivalents balance of $311.9 million at June 27, 2015.

[0001437749-15-014442:mdna:71]
The ratio of current assets to current liabilities was 3.0 at the end of the second quarter of 2015 compared to 2.8 at year-end 2014 and 2.2 at the end of the second quarter of 2014. Days sales outstanding in accounts receivable was approximately 62 days at the end of the second quarter of 2015 compared to 60 days at the end of the second quarter of 2014 and 60 days at year-end 2014. Days inventory outstanding was approximately 65 days at the end of the second quarter of 2015 compared to 68 days at the year-end 2014 and 64 days at end of the second quarter of 2014.

[0001437749-15-014442:mdna:72]
17

[0001437749-15-014442:mdna:73]
[same as prior period, unchanged from 0001437749-15-008576:mdna:57]

[0001437749-15-014442:mdna:74]
Sales are expected to be flat sequentially in the third quarter of 2015 due to expected less-than-normal seasonal strength for electronics while the electrical business continues to improve and automotive trends remain solid despite slowing growth in global car production. The mining sector is expected to remain weak at least through the remainder of this year. Foreign currency effects are expected to remain volatile. The company issued the following guidance for the third quarter of 2015:

[0001437749-15-014442:mdna:75]
|  | ● | Sales for the third quarter of 2015 are expected to be in the range of $211 to $221 million. At the midpoint, this is flat with the prior year quarter or approximately 4% growth on a constant currency basis. |

[0001437749-15-014442:mdna:76]
|  | ● | The full year effective tax rate is expected to be approximately 23.5%, although this assumes that Congress approves the R&D credit and the “look-through” provision for 2015 as it did in 2014. Until such time, the rate is expected to be about 50 basis points higher. |

[0001437749-15-014442:mdna:77]
|  | ● | Earnings for the third quarter of 2015 are expected to be in the range of $1.24 to $1.36 per diluted share. This includes negative currency effects of approximately $0.10 compared to the prior year. |

[0001437749-15-014442:mdna:78]
|  | ● | Although capital expenditures through the first six months of the year are $26.4 million, it is expected that spending will slow down in the second half resulting in full year capital expenditures of approximately $40 to $45 million. |

[0001437749-15-014442:mdna:79]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-15-014442:mdna:80]
[same as prior period, unchanged from 0001437749-15-008576:mdna:64]
