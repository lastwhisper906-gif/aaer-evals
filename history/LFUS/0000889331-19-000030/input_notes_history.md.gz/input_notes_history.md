# LFUS note change history — 0000889331-18-000004 → 0000889331-19-000030


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-05-01):
[0000889331-19-000030:note_history:1]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The company's  products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

- changed (2019-05-01):
[0000889331-19-000030:note_history:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 29, 2018  which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2018-10-31, similarity 0.9717):
[0000889331-18-000004:note_history:2]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the year ended December 30, 2017, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

- changed (2019-05-01):
[0000889331-19-000030:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2019 and March 31, 2018 :
  (was, 2018-10-31, similarity 0.8647):
[0000889331-18-000004:note_history:3]
The following table disaggregates the Company’s revenue by primary business units for the three and nine months ended September 29, 2018:

- added (2019-05-01):
[0000889331-19-000030:note_history:4]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  |  |  |  |  |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

- added (2019-05-01):
[0000889331-19-000030:note_history:5]
|  |  | Three Months Ended March 31, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics – Semiconductor |  | 149,916 |  |  | — |  |  | — |  |  | 149,916 |  |
| Passenger Car Products |  | — |  |  | 63,580 |  |  | — |  |  | 63,580 |  |
| Automotive Sensors |  | — |  |  | 31,323 |  |  | — |  |  | 31,323 |  |
| Commercial Vehicle Products |  | — |  |  | 31,228 |  |  | — |  |  | 31,228 |  |
| Industrial Products |  | — |  |  |  |  |  | 27,271 |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |

- changed (2019-05-01):
[0000889331-19-000030:note_history:6]
The Company elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.
  (was, 2018-10-31, similarity 0.9922):
[0000889331-18-000004:note_history:6]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- changed (2019-05-01):
[0000889331-19-000030:note_history:7]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.
  (was, 2018-10-31, similarity 0.9982):
[0000889331-18-000004:note_history:7]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

- added (2019-05-01):
[0000889331-19-000030:note_history:8]
In February 2016,  the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, "Leases" (Topic 842), ("ASC 842"). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption requires using a modified retrospective transition with either 1) periods prior to the adoption date being recast or 2) a cumulative-effect adjustment recognized to the opening balance of retained earnings on the adoption date with prior periods not recast.

- added (2019-05-01):
[0000889331-19-000030:note_history:9]
The Company adopted the standard on December 30, 2018 using alternative modified retrospective transition method provided in ASU No. 2018-11, "Leases (Topic 842): Target Improvements." Under this method, the Company recorded a cumulative-effect adjustment as of December 30, 2018 and did not record any retrospective adjustments to comparative periods to reflect the adoption of ASC 842. The new standard provides a number of optional practical expedients in transition. The Company has elected the ‘package of practical expedients’ which permits us not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct costs. The Company has not elected the use-of-hindsight. Adoption of  ASC 842 resulted in the recognition of operating lease right-of-use assets ("ROU") net of deferred rent of $26.1 million and lease liabilities of $29.4 million, as of December 30, 2018 for operating leases on its Condensed Consolidated Balance Sheets, with no  impact to its Condensed Consolidated Statements of Net Income and no impact on Condensed Consolidated Statements of Cash Flow. See Note 6, Lease Commitments, for further discussion.

- changed (2019-05-01):
[0000889331-19-000030:note_history:10]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. The Company adopted the new standard on December 30, 2018. The adoption of this guidance did not have a material effect on our Condensed Consolidated Financial Statements.
  (was, 2018-10-31, similarity 0.8411):
[0000889331-18-000004:note_history:10]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 2018-02 will be effective in the first quarter of 2019; however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 2018-02 on the Consolidated Financial Statements.

- removed (2019-05-01):
[0000889331-18-000004:note_history:11]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The Company has products in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance.

- removed (2019-05-01):
[0000889331-18-000004:note_history:12]
Adoption

- removed (2019-05-01):
[0000889331-18-000004:note_history:13]
|  |  | Three Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |

- removed (2019-05-01):
[0000889331-18-000004:note_history:14]
|  |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- removed (2019-05-01):
[0000889331-18-000004:note_history:15]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-07 “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the previous guidance, net benefit cost was reported as an employee cost within operating income. The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU No. 2017-07 was effective for the first quarter of 2018 with the Company adopting the new standard on December 31, 2017.

- removed (2019-05-01):
[0000889331-18-000004:note_history:16]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on December 31, 2017, on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings. As a result of the adoption of the new standard and change in fair value of our equity investments, for the nine months ended September 29, 2018, the Company recognized an unrealized loss of $0.3 million in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.

- removed (2019-05-01):
[0000889331-18-000004:note_history:17]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers” (Topic 606) which supersedes the revenue recognition requirements in ASC 605, “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on December 31, 2017 using the modified retrospective method, however, no adjustment to retained earnings was needed. The new guidance did not have a material effect on the Company’s Condensed Consolidated Statements of Net Income. See the Revenue Recognition section above for further discussion.

- removed (2019-05-01):
[0000889331-18-000004:note_history:18]
In October 2016, the FASB issued ASU No. 2016-16, "Income Taxes” (Topic 740). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on December 31, 2017 and it did not have a material impact.

- removed (2019-05-01):
[0000889331-18-000004:note_history:19]
Recently Issued Accounting Standards

- removed (2019-05-01):
[0000889331-18-000004:note_history:20]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the first quarter of 2019. The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has not yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.

- removed (2019-05-01):
[0000889331-18-000004:note_history:21]
In January 2018, the FASB released guidance on the accounting for tax on the global intangible low-taxed income ("GILTI") provisions of the 2017 U.S. Tax Cuts and Jobs Act (the “Tax Act”). The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has not yet completed its assessment and therefore has not yet elected an accounting policy.

- removed (2019-05-01):
[0000889331-18-000004:note_history:22]
In August 2018, the FASB issued ASU No. 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurement."  ASU 2018-13 modified the disclosure requirements in Topic 820, "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted.  The company is currently evaluating the potential effects of this guidance on its Consolidated Financial Statements.

- removed (2019-05-01):
[0000889331-18-000004:note_history:23]
In August 2018, the FASB issued ASU No. 2018-14 "Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans, which amends ASC 715-20, Compensation - Retirement Benefits - Defined Benefit Plans - General. The amended guidance modifies the disclosure requirements for employers that sponsor defined benefit pension or other post-retirement plans by removing and adding certain disclosures for these plans. The eliminated disclosures include (a) the amounts in  OCI expected to be recognized in net periodic benefit costs over the next fiscal year, and (b) the effects of a one percentage point change in assumed health care cost trend rates on the net periodic benefit costs and the benefit obligation for post-retirement health care benefits. Additional disclosures include descriptions of significant gains and losses affecting the benefit obligation for the period. The adoption of this guidance will modify our disclosures but will not have a material effect on our Consolidated Financial Statements.

- removed (2019-05-01):
[0000889331-18-000004:note_history:24]
In August 2018, the FASB issued ASU No. 2018-15, “Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force).” ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted. The Company is currently evaluating this guidance on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-01):
[0000889331-19-000030:note_history:25]
The carrying amounts of debt at March 30, 2019 and December 29, 2018 are as follows:
  (was, 2018-10-31, similarity 0.9342):
[0000889331-18-000004:note_history:25]
The carrying amounts of debt at September 29, 2018 and December 30, 2017 are as follows:

- added (2019-05-01):
[0000889331-19-000030:note_history:26]
| (in thousands) |  | March 30, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 150,000 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,499 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,772 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,380 | ) |  | (4,636 | ) |
| Total debt |  | 686,510 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,510 |  |  | $ | 684,730 |  |

- changed (2019-05-01):
[0000889331-19-000030:note_history:27]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $5.0 million on the term loan during the three months ended March 30, 2019.
  (was, 2018-10-31, similarity 0.9073):
[0000889331-18-000004:note_history:27]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. In addition to the quarterly principal payments, the Company paid an additional $35.0 million of principal on the term loan during the nine months ended September 29, 2018.

- changed (2019-05-01):
[0000889331-19-000030:note_history:28]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.75% at March 30, 2019.
  (was, 2018-10-31, similarity 0.9852):
[0000889331-18-000004:note_history:28]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.49% at September 29, 2018.

- changed (2019-05-01):
[0000889331-19-000030:note_history:29]
As of March 30, 2019, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At March 30, 2019, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2018-10-31, similarity 0.9455):
[0000889331-18-000004:note_history:29]
As of September 29, 2018, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At September 29, 2018, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2019-05-01):
[0000889331-19-000030:note_history:30]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 30, 2019, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2018-10-31, similarity 0.9878):
[0000889331-18-000004:note_history:30]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 29, 2018, the Company was in compliance with all covenants under the Senior Notes.

- added (2019-05-01):
[0000889331-19-000030:note_history:31]
Interest paid on all Company debt was $8.0 million and $4.0 million in the three months ended March 30, 2019 and March 31, 2018, respectively.

- removed (2019-05-01):
[0000889331-18-000004:note_history:32]
| (in thousands) |  | September 29, 2018 |  | December 30, 2017 |
| Term Loan |  | $ | 155,000 |  |  | $ | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,819 |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,092 |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | — |  |
| Other |  | 2,694 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,892 | ) |  | (4,881 | ) |
| Total debt |  | 700,713 |  |  | 495,611 |  |
| Less: Current maturities |  | (10,076 | ) |  | (6,250 | ) |
| Total long-term debt |  | $ | 690,637 |  |  | $ | 489,361 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-01):
[0000889331-19-000030:note_history:33]
The carrying amounts of debt at March 30, 2019 and December 29, 2018 are as follows:
  (was, 2018-10-31, similarity 0.9342):
[0000889331-18-000004:note_history:33]
The carrying amounts of debt at September 29, 2018 and December 30, 2017 are as follows:

- added (2019-05-01):
[0000889331-19-000030:note_history:34]
| (in thousands) |  | March 30, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 150,000 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,499 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,772 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,380 | ) |  | (4,636 | ) |
| Total debt |  | 686,510 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,510 |  |  | $ | 684,730 |  |

- removed (2019-05-01):
[0000889331-18-000004:note_history:35]
| (in thousands) |  | September 29, 2018 |  | December 30, 2017 |
| Term Loan |  | $ | 155,000 |  |  | $ | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,819 |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,092 |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | — |  |
| Other |  | 2,694 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,892 | ) |  | (4,881 | ) |
| Total debt |  | 700,713 |  |  | 495,611 |  |
| Less: Current maturities |  | (10,076 | ) |  | (6,250 | ) |
| Total long-term debt |  | $ | 690,637 |  |  | $ | 489,361 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-05-01):
[0000889331-19-000030:note_history:36]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method and recorded in investments in the Condensed Consolidated Balance Sheets. The following is a description of the investments and related party transactions.
  (was, 2018-10-31, similarity 0.614):
[0000889331-18-000004:note_history:36]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

- changed (2019-05-01):
[0000889331-19-000030:note_history:37]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For both the three months ended March 30, 2019 and March 31, 2018, the Company recorded revenues of $0.1 million from sales of products to Powersem for use as components in their products. During the three months ended March 30, 2019 and March 31, 2018, the Company purchased $0.8 million and $1.1 million of products from Powersem, respectively. As of March 30, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.
  (was, 2018-10-31, similarity 0.7):
[0000889331-18-000004:note_history:37]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the three and nine months ended September 29, 2018, the Company recorded revenues of $0.2 million and $0.6 million, respectively from sales of products to Powersem for use as components in their products. During the three and nine months ended September 29, 2018, the Company purchased $1.3 million and $3.4 million, respectively of products from Powersem. At September 29, 2018, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

- changed (2019-05-01):
[0000889331-19-000030:note_history:38]
EB Tech Ltd.: The Company owns approximately 20% of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. EB Tech rendered processing services for the Company totaling approximately $0.1 million for both three months ended March 30, 2019 and March 31, 2018. As of March 30, 2019 and December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.
  (was, 2018-10-31, similarity 0.7452):
[0000889331-18-000004:note_history:38]
EB Tech Ltd.: The Company owns approximately 20% of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the three and nine months ended September 29, 2018 EB Tech rendered processing services for the Company totaling approximately $0.1 million and $0.3 million, respectively. As of September 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

- changed (2019-05-01):
[0000889331-19-000030:note_history:39]
Automated Technology, Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended March 30, 2019 and March 31, 2018, ATEC rendered assembly and test services to the Company totaling approximately $1.5 million and $2.4 million, respectively. As of March 30, 2019, the Company’s accounts payable balance to ATEC was $0.4 million. As of December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.
  (was, 2018-10-31, similarity 0.8437):
[0000889331-18-000004:note_history:39]
Automated Technology, Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three and nine months ended September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $2.5 million and $7.7 million, respectively. As of September 29, 2018, the Company’s accounts payable balance to ATEC was $0.6 million.

- added (2019-05-01):
[0000889331-19-000030:note_history:40]
On March 25, 2019, the Company entered into a definitive agreement to sell the assets and liabilities of Microwave Technology, Inc. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net Income. The operations of Microwave Technology, Inc. were included in the Electronics segment. One member of the Company’s  Board of Directors is the co-owner of a company that agreed to purchase MWT. This transaction closed on April 26, 2019.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-01):
[0000889331-19-000030:note_history:41]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2019 and March 31, 2018 :
  (was, 2018-10-31, similarity 0.8647):
[0000889331-18-000004:note_history:41]
The following table disaggregates the Company’s revenue by primary business units for the three and nine months ended September 29, 2018:

- added (2019-05-01):
[0000889331-19-000030:note_history:42]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  |  |  |  |  |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

- added (2019-05-01):
[0000889331-19-000030:note_history:43]
|  |  | Three Months Ended March 31, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics – Semiconductor |  | 149,916 |  |  | — |  |  | — |  |  | 149,916 |  |
| Passenger Car Products |  | — |  |  | 63,580 |  |  | — |  |  | 63,580 |  |
| Automotive Sensors |  | — |  |  | 31,323 |  |  | — |  |  | 31,323 |  |
| Commercial Vehicle Products |  | — |  |  | 31,228 |  |  | — |  |  | 31,228 |  |
| Industrial Products |  | — |  |  |  |  |  | 27,271 |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |

- removed (2019-05-01):
[0000889331-18-000004:note_history:44]
|  |  | Three Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |

- removed (2019-05-01):
[0000889331-18-000004:note_history:45]
|  |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-01):
[0000889331-19-000030:note_history:46]
Revenue Disaggregation

- added (2019-05-01):
[0000889331-19-000030:note_history:47]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2019 and March 31, 2018 :

- added (2019-05-01):
[0000889331-19-000030:note_history:48]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  |  |  |  |  |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

- added (2019-05-01):
[0000889331-19-000030:note_history:49]
|  |  | Three Months Ended March 31, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics – Semiconductor |  | 149,916 |  |  | — |  |  | — |  |  | 149,916 |  |
| Passenger Car Products |  | — |  |  | 63,580 |  |  | — |  |  | 63,580 |  |
| Automotive Sensors |  | — |  |  | 31,323 |  |  | — |  |  | 31,323 |  |
| Commercial Vehicle Products |  | — |  |  | 31,228 |  |  | — |  |  | 31,228 |  |
| Industrial Products |  | — |  |  |  |  |  | 27,271 |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |

- added (2019-05-01):
[0000889331-19-000030:note_history:50]
See Note 16, Segment Information for net sales by segment and countries.

- changed (2019-05-01):
[0000889331-19-000030:note_history:51]
The Company elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.
  (was, 2018-10-31, similarity 0.9922):
[0000889331-18-000004:note_history:51]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- changed (2019-05-01):
[0000889331-19-000030:note_history:52]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.
  (was, 2018-10-31, similarity 0.9982):
[0000889331-18-000004:note_history:52]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

- removed (2019-05-01):
[0000889331-18-000004:note_history:53]
Adoption
