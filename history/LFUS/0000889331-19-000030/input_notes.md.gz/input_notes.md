# LFUS notes — 0000889331-19-000030


## lfus:AssetsAndLiabilitiesLesseeTableTextBlock

[0000889331-19-000030:notes:1]
The following table presents the classification of ROU assets and lease liabilities as of March 30, 2019:

[0000889331-19-000030:notes:2]
| Leases(in thousands) | Condensed Consolidated Balance Sheet Classification | March 30, 2019 |
| Assets |  |  |
| Operating ROU assets | Right of use lease assets, net | $ | 24,725 |  |
| Liabilities |  |  |
| Current operating lease liabilities | Accrued liabilities | $ | 7,447 |  |
| Non-current operating lease liabilities | Non-current operating lease liabilities | 19,950 |  |
| Total lease liabilities |  | $ | 27,397 |  |


## lfus:OperatingLeaseTermandDiscountRateTableTextBlock

[0000889331-19-000030:notes:3]
| Operating Lease Term and Discount Rate | March 30, 2019 |
| Weighted-average remaining lease term (years) | 4.40 |  |
| Weighted-average discount rate | 5.17 | % |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-19-000030:notes:4]
Accrued Liabilities

[0000889331-19-000030:notes:5]
The components of accrued liabilities at March 30, 2019 and December 29, 2018 are as follows:

[0000889331-19-000030:notes:6]
| (in thousands) | March 30, 2019 |  | December 29, 2018 |
| Employee-related liabilities | $ | 38,479 |  |  | $ | 60,640 |  |
| Other non-income taxes | 25,379 |  |  | 21,523 |  |
| Operating lease liability | 7,447 |  |  | — |  |
| Professional services | 5,395 |  |  | 6,169 |  |
| Interest | 2,487 |  |  | 5,137 |  |
| Accrued share repurchases | — |  |  | 4,349 |  |
| Restructuring liability | 2,144 |  |  | 3,887 |  |
| Other | 25,883 |  |  | 36,700 |  |
| Total | $ | 107,214 |  |  | $ | 138,405 |  |

[0000889331-19-000030:notes:7]
Employee-related liabilities consist primarily of payroll, sales commission, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other client-related liabilities.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000889331-19-000030:notes:8]
[same as prior period, unchanged from 0000889331-18-000004:notes:1]

[0000889331-19-000030:notes:9]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 29, 2018  which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.


## us-gaap:BusinessAcquisitionProFormaInformationNonrecurringAdjustmentsTableTextBlock

[0000889331-19-000030:notes:10]
[same as prior period, unchanged from 0000889331-18-000004:notes:3]

[0000889331-19-000030:notes:11]
|  |  | Three Months Ended |
| (in thousands) |  | March 31, 2018 |
| Amortization(a) |  | $ | 1,902 |  |
| Transaction costs(b) |  | 9,976 |  |
| Amortization of inventory step-up(c) |  | 17,896 |  |
| Stock compensation(d) |  | 4,479 |  |
| Income tax impact of above items |  | (7,701 | ) |

[0000889331-19-000030:notes:12]
| (a) | The amortization adjustment for the three months ended March 31, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and was fully amortized in the fiscal 2017 pro forma results. |

[0000889331-19-000030:notes:13]
| (b) | The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the three months ended March 31, 2018 and recognition of those fees during the three months ended April 1, 2017. |

[0000889331-19-000030:notes:14]
| (c) | The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the three months ended March 31, 2018 and recognition of those fees during the three months ended April 1, 2017. The inventory step-up was amortized over five months as the inventory was sold. |

[0000889331-19-000030:notes:15]
| (d) | The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the three months ended March 31, 2018. |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000889331-19-000030:notes:16]
[same as prior period, unchanged from 0000889331-18-000004:notes:10]

[0000889331-19-000030:notes:17]
|  |  | Three Months Ended |
| (in thousands, except per share amounts) |  | March 31, 2018 |
| Net sales |  | $ | 434,526 |  |
| Income before income taxes |  | 81,924 |  |
| Net income |  | 63,933 |  |
| Net income per share — basic |  | 2.57 |  |
| Net income per share — diluted |  | 2.53 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-19-000030:notes:18]
Other Comprehensive Income (Loss)

[0000889331-19-000030:notes:19]
[same as prior period, unchanged from 0000889331-18-000004:notes:14]

[0000889331-19-000030:notes:20]
| (in thousands) |  | Three Months Ended March 30, 2019 |  | Three Months Ended March 31, 2018 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | (78 | ) |  | $ | (29 | ) |  | $ | (49 | ) |  | $ | (68 | ) |  | $ | (65 | ) |  | $ | (3 | ) |
| Foreign currency translation adjustments |  | 8,122 |  |  | — |  |  | 8,122 |  |  | (276 | ) |  | — |  |  | (276 | ) |
| Total change in other comprehensive income (loss) |  | $ | 8,044 |  |  | $ | (29 | ) |  | $ | 8,073 |  |  | $ | (344 | ) |  | $ | (65 | ) |  | $ | (279 | ) |

[0000889331-19-000030:notes:21]
The following tables set forth the changes in accumulated other comprehensive (loss) income by component for the three months ended March 30, 2019 and March 31, 2018:

[0000889331-19-000030:notes:22]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 29, 2018 |  | $ | (9,959 | ) |  | $ | (87,965 | ) |  | $ | (97,924 | ) |
| Activity in the period |  | (49 | ) |  | 8,122 |  |  | 8,073 |  |
| Balance at March 30, 2019 |  | $ | (10,008 | ) |  | $ | (79,843 | ) |  | $ | (89,851 | ) |

[0000889331-19-000030:notes:23]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Unrealizedgain (loss) oninvestments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 30, 2017 |  | $ | (10,836 | ) |  | $ | 9,795 |  |  | $ | (62,627 | ) |  | $ | (63,668 | ) |
| Cumulative effect adjustment (a) |  | — |  |  | (9,795 | ) |  | — |  |  | (9,795 | ) |
| Activity in the period |  | (3 | ) |  | — |  |  | (276 | ) |  | (279 | ) |
| Balance at March 31, 2018 |  | $ | (10,839 | ) |  | $ | — |  |  | $ | (62,903 | ) |  | $ | (73,742 | ) |

[0000889331-19-000030:notes:24]
(a)The Company adopted ASU 2016-01 on December 31, 2017 on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings.

[0000889331-19-000030:notes:25]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three months ended March 30, 2019 and March 31, 2018 were as follows:

[0000889331-19-000030:notes:26]
|  |  | Three Months Ended |
| (in thousands) |  | March 30, 2019 |  | March 31, 2018 |
| Pension and Postemployment plans: |  |  |  |  |
| Amortization of prior service |  | $ | 62 |  |  | $ | 74 |  |

[0000889331-19-000030:notes:27]
The Company recognizes the amortization of prior service costs in Other (expense) income, net within the Condensed Consolidated Statements of Net Income.


## us-gaap:DebtDisclosureTextBlock

[0000889331-19-000030:notes:28]
Debt

[0000889331-19-000030:notes:29]
The carrying amounts of debt at March 30, 2019 and December 29, 2018 are as follows:

[0000889331-19-000030:notes:30]
| (in thousands) |  | March 30, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 150,000 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,499 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,772 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,380 | ) |  | (4,636 | ) |
| Total debt |  | 686,510 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,510 |  |  | $ | 684,730 |  |

[0000889331-19-000030:notes:31]
Revolving Credit Facility / Term Loan

[0000889331-19-000030:notes:32]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-19-000030:notes:33]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $5.0 million on the term loan during the three months ended March 30, 2019.

[0000889331-19-000030:notes:34]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.75% at March 30, 2019.

[0000889331-19-000030:notes:35]
As of March 30, 2019, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At March 30, 2019, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-19-000030:notes:36]
Senior Notes

[0000889331-19-000030:notes:37]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-19-000030:notes:38]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-19-000030:notes:39]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-19-000030:notes:40]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-19-000030:notes:41]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 30, 2019, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-19-000030:notes:42]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-19-000030:notes:43]
Interest paid on all Company debt was $8.0 million and $4.0 million in the three months ended March 30, 2019 and March 31, 2018, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000889331-19-000030:notes:44]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2019 and March 31, 2018 :

[0000889331-19-000030:notes:45]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  |  |  |  |  |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

[0000889331-19-000030:notes:46]
|  |  | Three Months Ended March 31, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics – Semiconductor |  | 149,916 |  |  | — |  |  | — |  |  | 149,916 |  |
| Passenger Car Products |  | — |  |  | 63,580 |  |  | — |  |  | 63,580 |  |
| Automotive Sensors |  | — |  |  | 31,323 |  |  | — |  |  | 31,323 |  |
| Commercial Vehicle Products |  | — |  |  | 31,228 |  |  | — |  |  | 31,228 |  |
| Industrial Products |  | — |  |  |  |  |  | 27,271 |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |


## us-gaap:EarningsPerShareTextBlock

[0000889331-19-000030:notes:47]
[same as prior period, unchanged from 0000889331-18-000004:notes:41]

[0000889331-19-000030:notes:48]
[same as prior period, unchanged from 0000889331-18-000004:notes:42]

[0000889331-19-000030:notes:49]
|  |  | Three Months Ended |
| (in thousands, except per share amounts) |  | March 30, 2019 |  | March 31, 2018 |
| Numerator: |  |  |  |  |
| Net income as reported |  | $ | 36,989 |  |  | $ | 36,029 |  |
| Denominator: |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |
| Basic |  | 24,717 |  |  | 24,339 |  |
| Effect of dilutive securities |  | 292 |  |  | 436 |  |
| Diluted |  | 25,009 |  |  | 24,775 |  |
| Earnings Per Share: |  |  |  |  |
| Basic earnings per share |  | $ | 1.50 |  |  | $ | 1.48 |  |
| Diluted earnings per share |  | $ | 1.48 |  |  | $ | 1.45 |  |

[0000889331-19-000030:notes:50]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 77,047  for the  three months ended March 30, 2019. No potential shares of common stock attributable to stock options were excluded from the diluted earnings per share calculation for the three months ended March 31, 2018.

[0000889331-19-000030:notes:51]
Share Repurchase Program

[0000889331-19-000030:notes:52]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019. On April 26, 2019, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020. During the  three months ended March 30, 2019, the Company repurchased 79,916 shares of its common stock totaling $13.6 million.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000889331-19-000030:notes:53]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 29, 2018:

[0000889331-19-000030:notes:54]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Investments in equity securities |  | $ | 10,312 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,312 |  |
| Mutual funds |  | 9,112 |  |  | — |  |  | — |  |  | 9,112 |  |

[0000889331-19-000030:notes:55]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of March 30, 2019:

[0000889331-19-000030:notes:56]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Investments in equity securities |  | $ | 10,551 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,551 |  |
| Mutual funds |  | 9,806 |  |  | — |  |  | — |  |  | 9,806 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000889331-19-000030:notes:57]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of March 30, 2019 and December 29, 2018 were as follows:

[0000889331-19-000030:notes:58]
|  |  | March 30, 2019 |  | December 29, 2018 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 131,499 |  |  | $ | 129,800 |  |  | $ | 133,417 |  |  | $ | 130,888 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,772 |  |  | 105,700 |  |  | 108,330 |  |  | 103,774 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 24,374 |  |  | 25,000 |  |  | 24,115 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 96,673 |  |  | 100,000 |  |  | 94,458 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 48,349 |  |  | 50,000 |  |  | 47,434 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 118,090 |  |  | 125,000 |  |  | 114,731 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-19-000030:notes:59]
[same as prior period, unchanged from 0000889331-18-000004:notes:51]

[0000889331-19-000030:notes:60]
[same as prior period, unchanged from 0000889331-18-000004:notes:52]

[0000889331-19-000030:notes:61]
[same as prior period, unchanged from 0000889331-18-000004:notes:53]

[0000889331-19-000030:notes:62]
[same as prior period, unchanged from 0000889331-18-000004:notes:54]

[0000889331-19-000030:notes:63]
[same as prior period, unchanged from 0000889331-18-000004:notes:55]

[0000889331-19-000030:notes:64]
[same as prior period, unchanged from 0000889331-18-000004:notes:56]

[0000889331-19-000030:notes:65]
[same as prior period, unchanged from 0000889331-18-000004:notes:57]

[0000889331-19-000030:notes:66]
[same as prior period, unchanged from 0000889331-18-000004:notes:58]

[0000889331-19-000030:notes:67]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the three months ended March 30, 2019, the Company recorded impairment charges of $2.8 million in Other expense (income), net in the Condensed Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value of $1.2 million. The fair value of these investments are measured on a nonrecurring basis and determined to be Level 3 under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-19-000030:notes:68]
[same as prior period, unchanged from 0000889331-18-000004:notes:59]

[0000889331-19-000030:notes:69]
[same as prior period, unchanged from 0000889331-18-000004:notes:60]

[0000889331-19-000030:notes:70]
There were no changes during the quarter ended March 30, 2019 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of March 30, 2019 and December 29, 2018, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-19-000030:notes:71]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at March 30, 2019 and December 29, 2018, as the rates on these borrowings are variable in nature.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-19-000030:notes:72]
[same as prior period, unchanged from 0000889331-18-000004:notes:63]

[0000889331-19-000030:notes:73]
The amounts for goodwill and changes in the carrying value by segment for the three months ended March 30, 2019 are as follows:

[0000889331-19-000030:notes:74]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 29, 2018 |  | $ | 656,039 |  |  | $ | 132,332 |  |  | $ | 38,344 |  |  | $ | 826,715 |  |
| Currency translation |  | (1,400 | ) |  | 102 |  |  | 50 |  |  | (1,248 | ) |
| As of March 30, 2019 |  | $ | 654,639 |  |  | $ | 132,434 |  |  | $ | 38,394 |  |  | $ | 825,467 |  |

[0000889331-19-000030:notes:75]
The components of other intangible assets at March 30, 2019 are as follows:

[0000889331-19-000030:notes:76]
| (in thousands, except weighted average useful life) |  | WeightedAverageUseful Life (Years) |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Patents, licenses and software |  | 11.1 |  | $ | 138,951 |  |  | $ | 72,219 |  |  | $ | 66,732 |  |
| Distribution network |  | 12.3 |  | 43,797 |  |  | 35,049 |  |  | 8,748 |  |
| Customer relationships, trademarks, and tradenames |  | 17.2 |  | 374,204 |  |  | 99,263 |  |  | 274,941 |  |
| Total |  |  |  | $ | 556,952 |  |  | $ | 206,531 |  |  | $ | 350,421 |  |

[0000889331-19-000030:notes:77]
During the three months ended March 30, 2019 and March 31, 2018, the Company recorded amortization expense of $10.2 million and $12.0 million, respectively, for intangible assets with definite lives.

[0000889331-19-000030:notes:78]
Estimated annual amortization expense related to intangible assets with definite lives as of March 30, 2019 is as follows:

[0000889331-19-000030:notes:79]
| (in thousands) | Amount |
| 2019 | $ | 49,524 |  |
| 2020 | 38,776 |  |
| 2021 | 36,930 |  |
| 2022 | 35,884 |  |
| 2023 | 30,423 |  |
| 2024 and thereafter | 169,075 |  |
| Total | $ | 360,612 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-19-000030:notes:80]
[same as prior period, unchanged from 0000889331-18-000004:notes:74]

[0000889331-19-000030:notes:81]
The effective tax rate for the three months ended March 30, 2019 was 20.3%, compared to an effective tax rate for the three months ended March 31, 2018 of 19.3%. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-19-000030:notes:82]
[same as prior period, unchanged from 0000889331-18-000004:notes:83]

[0000889331-19-000030:notes:83]
The components of inventories at March 30, 2019 and December 29, 2018 are as follows:

[0000889331-19-000030:notes:84]
| (in thousands) |  | March 30 2019 |  | December 29 2018 |
| Raw materials |  | $ | 75,949 |  |  | $ | 69,883 |  |
| Work in process |  | 90,538 |  |  | 88,505 |  |
| Finished goods |  | 95,172 |  |  | 99,840 |  |
| Total |  | $ | 261,659 |  |  | $ | 258,228 |  |


## us-gaap:LeaseCostTableTextBlock

[0000889331-19-000030:notes:85]
| Other Information(in thousands) | Three Months EndedMarch 30, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flow payments for operating leases | $ | (2,253 | ) |
| Leased assets obtained in exchange for operating lease liabilities | 859 |  |

[0000889331-19-000030:notes:86]
The following table represents the lease costs for the three months ended March 30, 2019:

[0000889331-19-000030:notes:87]
| Leases cost(in thousands) | Condensed Consolidated Statements of Net Income Classification | March 30, 2019 |
| Short-term lease expenses | Cost of sales, SG&A expenses | $ | 153 |  |
| Variable lease expenses | Cost of sales, SG&A expenses | 194 |  |
| Operating lease rent expenses | Cost of sales, SG&A expenses | 2,193 |  |
| Total operating lease costs | Cost of sales, SG&A expenses | $ | 2,540 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0000889331-19-000030:notes:88]
| Maturity of Lease Liabilities as of March 30, 2019(in thousands) | Operating leases |
| 2019 (excluding the three months ended March 30, 2019) | $ | 6,574 |  |
| 2020 | 7,551 |  |
| 2021 | 5,779 |  |
| 2022 | 4,665 |  |
| 2023 | 3,062 |  |
| 2024 and thereafter | 3,064 |  |
| Total lease payments | $ | 30,695 |  |
| Present value of lease Liabilities | $ | 27,397 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000889331-19-000030:notes:89]
Lease Commitments

[0000889331-19-000030:notes:90]
The Company leases office and production space under various non-cancelable operating leases that expire no later than 2025. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option.The Company also has production equipment, office equipment and vehicles under operating leases. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants.

[0000889331-19-000030:notes:91]
The Company does not have a published credit rating because it has no publicly traded debt; therefore, the Company is generating its incremental borrowing rate (IBR), using a synthetic credit rating model that compares its credit quality to other rated companies based on certain financial metrics and ratios. The reference rate will be based on the yield curve of companies with similar credit quality based on the metrics and adjusted for currency in regions where we have significant operations.

[0000889331-19-000030:notes:92]
All leases with an initial term of 12 months or less that do not include an option to extend or purchase the underlying asset that the Company is reasonably certain to exercise (“short-term leases”) are not recorded on the Condensed Consolidated Balance Sheet. Short-term lease expenses are recognized on a straight-line basis over the lease term.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-19-000030:notes:93]
[same as prior period, unchanged from 0000889331-18-000004:notes:86]

[0000889331-19-000030:notes:94]
[same as prior period, unchanged from 0000889331-18-000004:notes:87]

[0000889331-19-000030:notes:95]
[same as prior period, unchanged from 0000889331-18-000004:notes:88]

[0000889331-19-000030:notes:96]
[same as prior period, unchanged from 0000889331-18-000004:notes:89]

[0000889331-19-000030:notes:97]
[same as prior period, unchanged from 0000889331-18-000004:notes:90]

[0000889331-19-000030:notes:98]
[same as prior period, unchanged from 0000889331-18-000004:notes:91]

[0000889331-19-000030:notes:99]
The total purchase price of $856.5 million has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the IXYS acquisition:

[0000889331-19-000030:notes:100]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 302,865 |  |
| Cash settled stock options | 3,622 |  |
| Littelfuse stock | 434,192 |  |
| Converted stock options | 38,109 |  |
| Total purchase consideration | $ | 778,788 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | $ | 155,930 |  |
| Property, plant, and equipment | 77,442 |  |
| Intangible assets | 212,720 |  |
| Goodwill | 382,360 |  |
| Other non-current assets | 28,706 |  |
| Other non-current liabilities | (78,370 | ) |
|  | $ | 778,788 |  |

[0000889331-19-000030:notes:101]
Approximately $49.1 million of net receivables was included in IXYS’s current assets. All IXYS goodwill, other assets and liabilities were recorded in the Electronics segment and primarily reflected in the Americas and European geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining IXYS’s products and technology with the Company’s existing electronics product portfolio. Goodwill resulting from the IXYS acquisition is not expected to be deductible for tax purposes.

[0000889331-19-000030:notes:102]
During the three months ended March 31, 2018, the Company recognized a charge of $17.9 million for the amortization of the fair value inventory step-up. The step-up was a non-cash charge to cost of goods and reflected as other non-segment costs. The Company recognized approximately $5.9 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the three months ended March 31, 2018 of which $4.5 million was recognized immediately as it related to prior services periods.

[0000889331-19-000030:notes:103]
During the three months ended March 31, 2018, the Company incurred approximately $10.2 million of legal and professional fees related to this acquisition which were primarily recognized as selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-19-000030:notes:104]
[same as prior period, unchanged from 0000889331-18-000004:notes:114]

[0000889331-19-000030:notes:105]
The following table summarizes, on a pro forma basis, the combined results of operations of the Company and IXYS as though the acquisition had occurred as of January 1, 2017. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the IXYS acquisition occurred as of January 1, 2017 or of future consolidated operating results.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000889331-19-000030:notes:106]
Recently Adopted Accounting Standards

[0000889331-19-000030:notes:107]
In February 2016,  the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, "Leases" (Topic 842), ("ASC 842"). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption requires using a modified retrospective transition with either 1) periods prior to the adoption date being recast or 2) a cumulative-effect adjustment recognized to the opening balance of retained earnings on the adoption date with prior periods not recast.

[0000889331-19-000030:notes:108]
The Company adopted the standard on December 30, 2018 using alternative modified retrospective transition method provided in ASU No. 2018-11, "Leases (Topic 842): Target Improvements." Under this method, the Company recorded a cumulative-effect adjustment as of December 30, 2018 and did not record any retrospective adjustments to comparative periods to reflect the adoption of ASC 842. The new standard provides a number of optional practical expedients in transition. The Company has elected the ‘package of practical expedients’ which permits us not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct costs. The Company has not elected the use-of-hindsight. Adoption of  ASC 842 resulted in the recognition of operating lease right-of-use assets ("ROU") net of deferred rent of $26.1 million and lease liabilities of $29.4 million, as of December 30, 2018 for operating leases on its Condensed Consolidated Balance Sheets, with no  impact to its Condensed Consolidated Statements of Net Income and no impact on Condensed Consolidated Statements of Cash Flow.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-19-000030:notes:109]
[same as prior period, unchanged from 0000889331-18-000004:notes:125]

[0000889331-19-000030:notes:110]
The Company has company-sponsored defined benefit pension plans covering employees in the U.K., Germany, the Philippines, China, Japan, Mexico, Italy and France. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0000889331-19-000030:notes:111]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three months ended March 30, 2019 and March 31, 2018 were as follows:

[0000889331-19-000030:notes:112]
|  |  | For the Three Months Ended |
| (in thousands) |  | March 30, 2019 |  | March 31, 2018 |
| Components of net periodic benefit cost: |  |  |  |  |
| Service cost |  | $ | 500 |  |  | $ | 533 |  |
| Interest cost |  | 784 |  |  | 501 |  |
| Expected return on plan assets |  | (790 | ) |  | (540 | ) |
| Amortization of prior service |  | 62 |  |  | 74 |  |
| Net periodic benefit cost |  | $ | 556 |  |  | $ | 568 |  |

[0000889331-19-000030:notes:113]
The Company expects to make approximately $2.3 million of cash contributions to its pension plans in 2019.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-19-000030:notes:114]
Property, Plant, and Equipment

[0000889331-19-000030:notes:115]
The components of net property, plant, and equipment at March 30, 2019 and December 29, 2018 are as follows:

[0000889331-19-000030:notes:116]
| (in thousands) | March 30 2019 |  | December 29 2018 |
| Land | $ | 25,607 |  |  | $ | 25,630 |  |
| Building | 114,506 |  |  | 114,636 |  |
| Equipment | 599,254 |  |  | 583,043 |  |
| Accumulated depreciation and amortization | (397,033 | ) |  | (383,415 | ) |
| Total | $ | 342,334 |  |  | $ | 339,894 |  |

[0000889331-19-000030:notes:117]
The Company recorded depreciation expense of $13.1 million and $11.6 million for the three months ended March 30, 2019 and March 31, 2018, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-19-000030:notes:118]
Related Party Transactions

[0000889331-19-000030:notes:119]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method and recorded in investments in the Condensed Consolidated Balance Sheets. The following is a description of the investments and related party transactions.

[0000889331-19-000030:notes:120]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For both the three months ended March 30, 2019 and March 31, 2018, the Company recorded revenues of $0.1 million from sales of products to Powersem for use as components in their products. During the three months ended March 30, 2019 and March 31, 2018, the Company purchased $0.8 million and $1.1 million of products from Powersem, respectively. As of March 30, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

[0000889331-19-000030:notes:121]
EB Tech Ltd.: The Company owns approximately 20% of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. EB Tech rendered processing services for the Company totaling approximately $0.1 million for both three months ended March 30, 2019 and March 31, 2018. As of March 30, 2019 and December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

[0000889331-19-000030:notes:122]
Automated Technology, Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended March 30, 2019 and March 31, 2018, ATEC rendered assembly and test services to the Company totaling approximately $1.5 million and $2.4 million, respectively. As of March 30, 2019, the Company’s accounts payable balance to ATEC was $0.4 million. As of December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.

[0000889331-19-000030:notes:123]
On March 25, 2019, the Company entered into a definitive agreement to sell the assets and liabilities of Microwave Technology, Inc. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net Income. The operations of Microwave Technology, Inc. were included in the Electronics segment. One member of the Company’s  Board of Directors is the co-owner of a company that agreed to purchase MWT. This transaction closed on April 26, 2019.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-19-000030:notes:124]
Restructuring, Impairment and Other Charges

[0000889331-19-000030:notes:125]
The Company recorded restructuring, impairment and other charges-net for three months ended March 30, 2019 and March 31, 2018 as follows:

[0000889331-19-000030:notes:126]
|  | Three months ended March 30, 2019 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 1,800 |  |  | $ | 605 |  |  | $ | 47 |  |  | $ | 2,452 |  |
| Other restructuring charges | 13 |  |  | 20 |  |  | 250 |  |  | 283 |  |
| Total restructuring charges | $ | 1,813 |  |  | $ | 625 |  |  | $ | 297 |  |  | $ | 2,735 |  |

[0000889331-19-000030:notes:127]
|  | Three months ended March 31, 2018 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 677 |  |  | $ | 99 |  |  | $ | 3 |  |  | $ | 779 |  |
| Total restructuring charges | $ | 677 |  |  | $ | 99 |  |  | $ | 3 |  |  | $ | 779 |  |

[0000889331-19-000030:notes:128]
2019

[0000889331-19-000030:notes:129]
For the three months ended March 30, 2019, the Company recorded total restructuring charges of $2.7 million, of which $2.5 million was for employee termination costs and $0.3 million for other restructuring charges. These charges primarily related to reorganization of operations and selling, general and administrative functions as well as integration of IXYS within the Electronics segment and the reorganization of operations in the commercial vehicle products and automotive sensors businesses within the Automotive segment.

[0000889331-19-000030:notes:130]
In April 2019, we announced the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment. The Company estimates the restructuring costs associated with this plant closure to be approximately $5.0 million to $7.0 million.

[0000889331-19-000030:notes:131]
2018

[0000889331-19-000030:notes:132]
For the three months ended March 31, 2018, the Company recorded total restructuring charges of $0.8 million for employee termination costs mainly related to the Electronics segment.

[0000889331-19-000030:notes:133]
The restructuring reserves as of March 30, 2019 and December 29, 2018 are $2.1 million and $3.9 million, respectively. The restructuring reserves are included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will be completed in the second quarter of fiscal year 2019.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000889331-19-000030:notes:134]
[same as prior period, unchanged from 0000889331-18-000004:notes:135]

[0000889331-19-000030:notes:135]
[same as prior period, unchanged from 0000889331-18-000004:notes:137]

[0000889331-19-000030:notes:136]
Revenue Disaggregation

[0000889331-19-000030:notes:137]
See Note 16, Segment Information for net sales by segment and countries.

[0000889331-19-000030:notes:138]
[same as prior period, unchanged from 0000889331-18-000004:notes:138]

[0000889331-19-000030:notes:139]
The Company elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-19-000030:notes:140]
[same as prior period, unchanged from 0000889331-18-000004:notes:140]

[0000889331-19-000030:notes:141]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

[0000889331-19-000030:notes:142]
[same as prior period, unchanged from 0000889331-18-000004:notes:142]

[0000889331-19-000030:notes:143]
[same as prior period, unchanged from 0000889331-18-000004:notes:143]

[0000889331-19-000030:notes:144]
[same as prior period, unchanged from 0000889331-18-000004:notes:144]

[0000889331-19-000030:notes:145]
[same as prior period, unchanged from 0000889331-18-000004:notes:145]

[0000889331-19-000030:notes:146]
[same as prior period, unchanged from 0000889331-18-000004:notes:146]

[0000889331-19-000030:notes:147]
[same as prior period, unchanged from 0000889331-18-000004:notes:147]


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0000889331-19-000030:notes:148]
The Company’s net sales by country were as follows:

[0000889331-19-000030:notes:149]
|  |  | Three Months Ended |
| (in thousands) |  | March 30, 2019 |  | March 31, 2018 |
| Net sales |  |  |  |  |
| United States |  | $ | 119,528 |  |  | $ | 123,877 |  |
| China |  | 57,334 |  |  | 106,508 |  |
| Other countries(a) |  | 228,638 |  |  | 187,428 |  |
| Total net sales |  | $ | 405,500 |  |  | $ | 417,813 |  |

[0000889331-19-000030:notes:150]
The Company’s long-lived assets by country were as follows:

[0000889331-19-000030:notes:151]
| (in thousands) |  | March 30, 2019 |  | December 29, 2018 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 57,527 |  |  | $ | 58,691 |  |
| China |  | 94,807 |  |  | 95,806 |  |
| Mexico |  | 73,694 |  |  | 70,495 |  |
| Germany |  | 35,536 |  |  | 36,548 |  |
| Philippines |  | 36,223 |  |  | 32,459 |  |
| Other countries(a) |  | 44,547 |  |  | 45,895 |  |
| Total long-lived assets |  | $ | 342,334 |  |  | $ | 339,894 |  |

[0000889331-19-000030:notes:152]
[same as prior period, unchanged from 0000889331-18-000004:notes:151]

[0000889331-19-000030:notes:153]
|  |  | Three Months Ended |
| (in thousands) |  | March 30, 2019 |  | March 31, 2018 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 905 |  |  | $ | 2,909 |  |
| China |  | 1,225 |  |  | 5,144 |  |
| Mexico |  | 5,484 |  |  | 3,310 |  |
| Germany |  | 598 |  |  | 3,038 |  |
| Philippines |  | 5,229 |  |  | 2,162 |  |
| Other countries(a) |  | 635 |  |  | 1,346 |  |
| Total additions to long-lived assets |  | $ | 14,076 |  |  | $ | 17,909 |  |

[0000889331-19-000030:notes:154]
| (a) | Each country included in other countries are less than 10% of net sales. |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000889331-19-000030:notes:155]
[same as prior period, unchanged from 0000889331-18-000004:notes:156]

[0000889331-19-000030:notes:156]
|  |  | Three Months Ended |
| (in thousands) |  | March 30, 2019 |  | March 31, 2018 |
| Net sales |  |  |  |  |
| Electronics |  | $ | 265,394 |  |  | $ | 264,411 |  |
| Automotive |  | 113,483 |  |  | 126,131 |  |
| Industrial |  | 26,623 |  |  | 27,271 |  |
| Total net sales |  | $ | 405,500 |  |  | $ | 417,813 |  |
| Depreciation and amortization |  |  |  |  |
| Electronics |  | $ | 15,342 |  |  | $ | 13,678 |  |
| Automotive |  | 6,877 |  |  | 5,970 |  |
| Industrial |  | 1,060 |  |  | 1,460 |  |
| Other |  | — |  |  | 2,504 |  |
| Total depreciation and amortization |  | $ | 23,279 |  |  | $ | 23,612 |  |
| Operating income (loss) |  |  |  |  |
| Electronics |  | $ | 49,037 |  |  | $ | 53,964 |  |
| Automotive |  | 13,200 |  |  | 18,390 |  |
| Industrial |  | 3,505 |  |  | 4,709 |  |
| Other(a) |  | (5,069 | ) |  | (39,492 | ) |
| Total operating income |  | 60,673 |  |  | 37,571 |  |
| Interest expense |  | 5,686 |  |  | 5,423 |  |
| Foreign exchange loss (gain) |  | 4,243 |  |  | (10,555 | ) |
| Other expense (income), net |  | 4,305 |  |  | (1,943 | ) |
| Income before income taxes |  | $ | 46,439 |  |  | $ | 44,646 |  |

[0000889331-19-000030:notes:157]
(a) Included in “Other” Operating income (loss) for the 2019 first quarter is $2.4 million of acquisition integration charges primarily related to the IXYS acquisition. In addition, there were $2.7 million of restructuring charges primarily related to employee termination costs.

[0000889331-19-000030:notes:158]
The first quarter of  2018 includes approximately  $38.6 million of charges primarily related to the IXYS acquisition, which include $17.9 million of purchase accounting inventory step-up charges, $11.6 million in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $2.5 million in backlog amortization costs,  and $4.5 million in stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million change in control expense related to IXYS. In addition, there were $0.8 million of employee termination costs and $0.1 million of acquisition-related expenses for other contemplated acquisitions.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-19-000030:notes:159]
[same as prior period, unchanged from 0000889331-18-000004:notes:162]

[0000889331-19-000030:notes:160]
[same as prior period, unchanged from 0000889331-18-000004:notes:163]

[0000889331-19-000030:notes:161]
[same as prior period, unchanged from 0000889331-18-000004:notes:164]

[0000889331-19-000030:notes:162]
| • | Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor and power semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon carbide, metal-oxide-semiconductor field-effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial and automotive electronics, electric vehicle infrastructure, data and telecommunications, medical devices, LED lighting, consumer electronics and appliances |

[0000889331-19-000030:notes:163]
| • | Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle industries. Passenger car fuse products include fuses and fuse accessories for internal combustion engine vehicles and hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle products designed to monitor the passenger compartment occupants, safety and environment as well as the vehicle’s powertrain, emissions, speed and suspension. |

[0000889331-19-000030:notes:164]
| • | Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in various industrial applications such as oil, gas, mining, alternative energy - solar and wind, electric vehicle infrastructure, construction, HVAC systems, elevator and other industrial equipment. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-19-000030:notes:165]
[same as prior period, unchanged from 0000889331-18-000004:notes:169]

[0000889331-19-000030:notes:166]
[same as prior period, unchanged from 0000889331-18-000004:notes:170]

[0000889331-19-000030:notes:167]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The company's  products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

[0000889331-19-000030:notes:168]
The Company adopted the standard on December 30, 2018 using alternative modified retrospective transition method provided in ASU No. 2018-11, "Leases (Topic 842): Target Improvements." Under this method, the Company recorded a cumulative-effect adjustment as of December 30, 2018 and did not record any retrospective adjustments to comparative periods to reflect the adoption of ASC 842. The new standard provides a number of optional practical expedients in transition. The Company has elected the ‘package of practical expedients’ which permits us not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct costs. The Company has not elected the use-of-hindsight. Adoption of  ASC 842 resulted in the recognition of operating lease right-of-use assets ("ROU") net of deferred rent of $26.1 million and lease liabilities of $29.4 million, as of December 30, 2018 for operating leases on its Condensed Consolidated Balance Sheets, with no  impact to its Condensed Consolidated Statements of Net Income and no impact on Condensed Consolidated Statements of Cash Flow. See Note 6, Lease Commitments, for further discussion.

[0000889331-19-000030:notes:169]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. The Company adopted the new standard on December 30, 2018. The adoption of this guidance did not have a material effect on our Condensed Consolidated Financial Statements.
