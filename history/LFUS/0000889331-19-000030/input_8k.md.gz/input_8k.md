# LFUS 8-K — 0000889331-19-000028 filed 2019-05-01

## item codes, every 8-K on or before 2019-05-01

- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2019-05-01

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-19-000028:8k_2_02:1]
EX-99.1
2
q12019earningsreleaseex991.htm
EXHIBIT 99.1

[0000889331-19-000028:8k_2_02:2]
Exhibit

[0000889331-19-000028:8k_2_02:3]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-19-000028:8k_2_02:4]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2019

[0000889331-19-000028:8k_2_02:5]
Company performance in line with guidance

[0000889331-19-000028:8k_2_02:6]
CHICAGO, May 1, 2019 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the first quarter ended March 30, 2019:

[0000889331-19-000028:8k_2_02:7]
| • | Net sales of $405.5 million were in line with guidance, down 3% versus the prior year period, and down 4% organically |

[0000889331-19-000028:8k_2_02:8]
| • | Growth by segment versus the prior year period: |

[0000889331-19-000028:8k_2_02:9]
| • | Electronics sales were flat (down 4% organically) |

[0000889331-19-000028:8k_2_02:10]
| • | Automotive sales decreased 10% (down 7% organically) |

[0000889331-19-000028:8k_2_02:11]
| • | Industrial sales decreased 2% (up 4% organically) |

[0000889331-19-000028:8k_2_02:12]
| • | GAAP diluted EPS was $1.48 |

[0000889331-19-000028:8k_2_02:13]
| • | Adjusted diluted EPS of $1.96 was above the midpoint of guidance. As expected, EPS was unfavorably impacted by currency headwinds as well as lower volumes and associated leverage versus the prior year |

[0000889331-19-000028:8k_2_02:14]
| • | GAAP effective tax rate was 20.3% and the adjusted effective tax rate was 19.7% |

[0000889331-19-000028:8k_2_02:15]
| • | Cash flow from operations was $30.9 million and free cash flow was $16.8 million |

[0000889331-19-000028:8k_2_02:16]
| • | During the first quarter, the company repurchased 79,916 shares of common stock under its share repurchase authorization |

[0000889331-19-000028:8k_2_02:17]
“We delivered a solid first quarter in line with our sales and adjusted EPS guidance,” said Dave Heinzmann, Littelfuse Chief Executive Officer. “Our teams remain focused on executing our long-term strategy while containing costs within this current environment. We continue to see good design win activity driven by the strong fundamentals of our business, and the content opportunities driven by a safer, greener and increasingly connected world. During the quarter, we initiated additional footprint and product line rationalizations. While we anticipate soft demand to persist, we continue to expect improving conditions in the second half of the year. We remain confident we will deliver exceptional value for our shareholders by executing on our five-year growth strategy.”

[0000889331-19-000028:8k_2_02:18]
-more-

[0000889331-19-000028:8k_2_02:19]
For the second quarter of 2019*:

[0000889331-19-000028:8k_2_02:20]
| • | Net sales are expected to be in the range of $409 to $421 million |

[0000889331-19-000028:8k_2_02:21]
| • | Adjusted diluted EPS is expected to be in the range of $2.00 to $2.14. This includes an estimated 25 cent decline versus the prior year, due to unfavorable foreign exchange impacts and mark-to-market comparisons, as well as timing of stock compensation expense |

[0000889331-19-000028:8k_2_02:22]
| • | Adjusted effective tax rate is expected to be in the range of 18% - 19% |

[0000889331-19-000028:8k_2_02:23]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-19-000028:8k_2_02:24]
Dividend and Share Repurchase Authorization

[0000889331-19-000028:8k_2_02:25]
| • | The company will pay a cash dividend on its common stock of $0.43 per share on June 6, 2019 to shareholders of record as of May 23, 2019 |

[0000889331-19-000028:8k_2_02:26]
| • | The company’s previous share repurchase authorization expired on April 30, 2019 and has been replaced with a new one million share repurchase authorization effective through April 30, 2020 |

[0000889331-19-000028:8k_2_02:27]
Conference Call and Webcast Information

[0000889331-19-000028:8k_2_02:28]
Littelfuse will host a conference call today, Wednesday, May 1, 2019, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-19-000028:8k_2_02:29]
About Littelfuse

[0000889331-19-000028:8k_2_02:30]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Sold in over 150 countries, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Our 12,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-19-000028:8k_2_02:31]
-more-

[0000889331-19-000028:8k_2_02:32]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 29, 2018. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 29, 2018.

[0000889331-19-000028:8k_2_02:33]
Non-GAAP Financial Measures

[0000889331-19-000028:8k_2_02:34]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate, free cash flow, and adjusted leverage. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-19-000028:8k_2_02:35]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-19-000028:8k_2_02:36]
CONTACT: Trisha Tuntland

[0000889331-19-000028:8k_2_02:37]
Head of Investor Relations

[0000889331-19-000028:8k_2_02:38]
(773) 628-2163

[0000889331-19-000028:8k_2_02:39]
###

[0000889331-19-000028:8k_2_02:40]
LFUS-F

[0000889331-19-000028:8k_2_02:41]
LITTELFUSE, INC.

[0000889331-19-000028:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-19-000028:8k_2_02:43]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | March 30, 2019 |  | December 29, 2018 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 476,614 |  |  | $ | 489,733 |  |
| Short-term investments |  | 33 |  |  | 34 |  |
| Trade receivables, less allowances of $33,140 and $36,038 at March 30, 2019 and December 29, 2018, respectively |  | 237,878 |  |  | 232,892 |  |
| Inventories |  | 261,659 |  |  | 258,228 |  |
| Prepaid income taxes and income taxes receivable |  | 758 |  |  | 2,339 |  |
| Prepaid expenses and other current assets |  | 53,203 |  |  | 49,291 |  |
| Total current assets |  | 1,030,145 |  |  | 1,032,517 |  |
| Net property, plant, and equipment |  | 342,334 |  |  | 339,894 |  |
| Intangible assets, net of amortization |  | 350,421 |  |  | 361,474 |  |
| Goodwill |  | 825,467 |  |  | 826,715 |  |
| Investments |  | 24,640 |  |  | 25,405 |  |
| Deferred income taxes |  | 8,461 |  |  | 7,330 |  |
| Right of use lease assets, net |  | 24,725 |  |  | — |  |
| Other assets |  | 18,825 |  |  | 20,971 |  |
| Total assets |  | $ | 2,625,018 |  |  | $ | 2,614,306 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 129,092 |  |  | $ | 126,323 |  |
| Accrued liabilities |  | 107,214 |  |  | 138,405 |  |
| Accrued income taxes |  | 23,244 |  |  | 20,547 |  |
| Current portion of long-term debt |  | 10,000 |  |  | 10,000 |  |
| Total current liabilities |  | 269,550 |  |  | 295,275 |  |
| Long-term debt, less current portion |  | 676,510 |  |  | 684,730 |  |
| Deferred income taxes |  | 52,658 |  |  | 51,853 |  |
| Accrued post-retirement benefits |  | 31,548 |  |  | 31,874 |  |
| Non-current operating lease liabilities |  | 19,950 |  |  | — |  |
| Other long-term liabilities |  | 69,414 |  |  | 72,232 |  |
| Total equity |  | 1,505,388 |  |  | 1,478,342 |  |
| Total liabilities and equity |  | $ | 2,625,018 |  |  | $ | 2,614,306 |  |

[0000889331-19-000028:8k_2_02:44]
LITTELFUSE, INC.

[0000889331-19-000028:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-19-000028:8k_2_02:46]
(Unaudited)

[0000889331-19-000028:8k_2_02:47]
|  |  | Three Months Ended |
| (in thousands, except per share data) |  | March 30, 2019 |  | March 31, 2018 |
| Net sales |  | $ | 405,500 |  |  | $ | 417,813 |  |
| Cost of sales |  | 250,272 |  |  | 268,190 |  |
| Gross profit |  | 155,228 |  |  | 149,623 |  |
| Selling, general, and administrative expenses |  | 62,955 |  |  | 77,514 |  |
| Research and development expenses |  | 21,409 |  |  | 22,540 |  |
| Amortization of intangibles |  | 10,191 |  |  | 11,998 |  |
| Total operating expenses |  | 94,555 |  |  | 112,052 |  |
| Operating income |  | 60,673 |  |  | 37,571 |  |
| Interest expense |  | 5,686 |  |  | 5,423 |  |
| Foreign exchange loss (gain) |  | 4,243 |  |  | (10,555 | ) |
| Other expense (income), net |  | 4,305 |  |  | (1,943 | ) |
| Income before income taxes |  | 46,439 |  |  | 44,646 |  |
| Income taxes |  | 9,450 |  |  | 8,617 |  |
| Net income |  | $ | 36,989 |  |  | $ | 36,029 |  |
| Income per share: |  |  |  |  |
| Basic |  | $ | 1.50 |  |  | $ | 1.48 |  |
| Diluted |  | $ | 1.48 |  |  | $ | 1.45 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |
| Basic |  | 24,717 |  |  | 24,339 |  |
| Diluted |  | 25,009 |  |  | 24,775 |  |
| Comprehensive income |  | $ | 45,062 |  |  | $ | 35,750 |  |

[0000889331-19-000028:8k_2_02:48]
LITTELFUSE, INC.

[0000889331-19-000028:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-19-000028:8k_2_02:50]
(Unaudited)

[0000889331-19-000028:8k_2_02:51]
|  |  | Three Months Ended |
| (in thousands) |  | March 30, 2019 |  | March 31, 2018 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 36,989 |  |  | $ | 36,029 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 35,376 |  |  | 49,286 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (5,800 | ) |  | (8,417 | ) |
| Inventories |  | (3,250 | ) |  | (269 | ) |
| Accounts payable |  | (8,499 | ) |  | 2,990 |  |
| Accrued liabilities and income taxes |  | (27,170 | ) |  | (7,208 | ) |
| Prepaid expenses and other assets |  | 3,273 |  |  | (3,143 | ) |
| Net cash provided by operating activities |  | 30,919 |  |  | 69,268 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (775 | ) |  | (306,487 | ) |
| Purchases of property, plant, and equipment |  | (14,076 | ) |  | (17,909 | ) |
| Proceeds from sale of property, plant, and equipment |  | 607 |  |  | 19 |  |
| Net cash used in investing activities |  | (14,244 | ) |  | (324,377 | ) |
| FINANCING ACTIVITIES |  |  |  |  |
| Net (payments) proceeds from credit facility and senior notes |  | (5,000 | ) |  | 250,500 |  |
| Purchases of common stock |  | (17,906 | ) |  | — |  |
| Cash dividends paid |  | (10,625 | ) |  | (9,198 | ) |
| All other cash provided by (used in) financing activities |  | 2,198 |  |  | (994 | ) |
| Net cash (used in) provided by financing activities |  | (31,333 | ) |  | 240,308 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,539 |  |  | (2,417 | ) |
| Decrease in cash and cash equivalents |  | (13,119 | ) |  | (17,218 | ) |
| Cash and cash equivalents at beginning of period |  | 489,733 |  |  | 429,676 |  |
| Cash and cash equivalents at end of period |  | $ | 476,614 |  |  | $ | 412,458 |  |

[0000889331-19-000028:8k_2_02:52]
LITTELFUSE, INC.

[0000889331-19-000028:8k_2_02:53]
NET SALES AND OPERTATING INCOME BY SEGMENT

[0000889331-19-000028:8k_2_02:54]
(Unaudited)

[0000889331-19-000028:8k_2_02:55]
|  |  | First Quarter |
| (in thousands) |  | 2019 |  | 2018 |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |
| Electronics |  | $ | 265,394 |  |  | $ | 264,411 |  |  | 0.4 | % |
| Automotive |  | 113,483 |  |  | 126,131 |  |  | (10.0 | )% |
| Industrial |  | 26,623 |  |  | 27,271 |  |  | (2.4 | )% |
| Total net sales |  | $ | 405,500 |  |  | $ | 417,813 |  |  | (2.9 | )% |
| Operating income (loss) |  |  |  |  |  |  |
| Electronics |  | $ | 49,037 |  |  | $ | 53,964 |  |  | (9.1 | )% |
| Automotive |  | 13,200 |  |  | 18,390 |  |  | (28.2 | )% |
| Industrial |  | 3,505 |  |  | 4,709 |  |  | (25.6 | )% |
| Other(a) |  | (5,069 | ) |  | (39,492 | ) |  | N.M. |  |
| Total operating income |  | $ | 60,673 |  |  | $ | 37,571 |  |  | 61.5 | % |
| Operating Margin |  | 15.0 | % |  | 9.0 | % |  |  |
| Interest expense |  | 5,686 |  |  | 5,423 |  |  |  |
| Foreign exchange loss (gain) |  | 4,243 |  |  | (10,555 | ) |  |  |
| Other expense (income), net |  | 4,305 |  |  | (1,943 | ) |  |  |
| Income before income taxes |  | $ | 46,439 |  |  | $ | 44,646 |  |  | 4.0 | % |

[0000889331-19-000028:8k_2_02:56]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and other charges, and restructuring charges. (See Supplemental Financial Information for details.)

[0000889331-19-000028:8k_2_02:57]
N.M. - Not meaningful

[0000889331-19-000028:8k_2_02:58]
|  |  | First Quarter |
| (in thousands) |  | 2019 |  | 2018 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |
| Electronics |  | 18.5 | % |  | 20.4 | % |  | (1.9 | )% |
| Automotive |  | 11.6 | % |  | 14.6 | % |  | (2.9 | )% |
| Industrial |  | 13.2 | % |  | 17.3 | % |  | (4.1 | )% |

[0000889331-19-000028:8k_2_02:59]
LITTELFUSE, INC.

[0000889331-19-000028:8k_2_02:60]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-19-000028:8k_2_02:61]
(In millions of USD except per share amounts unaudited)

[0000889331-19-000028:8k_2_02:62]
| Non-GAAP EPS reconciliation |  |  |  |  |
|  |  | Q1-19 |  | Q1-18 |
| GAAP diluted EPS |  | $ | 1.48 |  |  | $ | 1.45 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.48 |  | 0.94 |
| Adjusted diluted EPS |  | $ | 1.96 |  |  | $ | 2.39 |  |

[0000889331-19-000028:8k_2_02:63]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |
|  |  | Q1-19 |  | Q1-18 |
| Acquisition related and integration costs (a) |  | $ | 2.4 |  |  | $ | 11.7 |  |
| Restructuring, impairment and other charges (b) |  | 2.7 |  |  | 0.8 |  |
| Amortization backlog - IXYS (c) |  | — |  |  | 2.5 |  |
| Change in control - IXYS (d) |  | — |  |  | 2.1 |  |
| Acquisition related stock-based compensation charge (e) |  | — |  |  | 4.5 |  |
| Purchase accounting inventory adjustments (f) |  | — |  |  | 17.9 |  |
| Non-GAAP adjustments to operating income |  | 5.1 |  |  | 39.5 |  |
| Other expense, net (g) |  | 5.2 |  |  | — |  |
| Non-operating foreign exchange loss (gain) |  | 4.2 |  |  | (10.6 | ) |
| Non-GAAP adjustments to income before income taxes |  | 14.5 |  |  | 28.9 |  |
| Income taxes (h) |  | 2.5 |  |  | 5.8 |  |
| Non-GAAP adjustments to net income |  | $ | 12.0 |  |  | $ | 23.1 |  |
| Total EPS impact |  | $ | 0.48 |  |  | $ | 0.94 |  |

[0000889331-19-000028:8k_2_02:64]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |
|  |  | Q1-19 |  | Q1-18 |
| Net sales |  | $ | 405.5 |  |  | $ | 417.8 |  |
| GAAP operating income |  | $ | 60.7 |  |  | $ | 37.6 |  |
| Add back non-GAAP adjustments |  | 5.1 |  |  | 39.5 |  |
| Adjusted operating income |  | $ | 65.8 |  |  | $ | 77.1 |  |
| Adjusted operating margin |  | 16.2 | % |  | 18.5 | % |
| Add back amortization |  | 10.2 |  |  | 12.0 |  |
| Add back depreciation |  | 13.1 |  |  | 11.6 |  |
| Adjusted EBITDA |  | $ | 89.1 |  |  | $ | 100.7 |  |
| Adjusted EBITDA margin |  | 22.0 | % |  | 24.1 | % |

[0000889331-19-000028:8k_2_02:65]
| Net sales reconciliation |  | Q1-19 vs. Q1-18 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | — | % |  | (10 | )% |  | (2 | )% |  | (3 | )% |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 6 | % |  | — |  |  | — |  |  | 3 | % |
| Divestitures |  | — |  |  | — |  |  | (5 | )% |  | — | % |
| FX impact |  | (2 | )% |  | (3 | )% |  | (1 | )% |  | (2 | )% |
| Organic net sales growth |  | (4 | )% |  | (7 | )% |  | 4 | % |  | (4 | )% |

[0000889331-19-000028:8k_2_02:66]
| Income tax reconciliation |  |  |  |  |
|  |  | Q1-19 |  | Q1-18 |
| Income taxes |  | $ | 9.5 |  |  | $ | 8.6 |  |
| Effective rate |  | 20.3 | % |  | 19.3 | % |
| Non-GAAP adjustments - income taxes |  | 2.5 |  |  | 5.8 |  |
| Adjusted income taxes |  | $ | 12.0 |  |  | $ | 14.4 |  |
| Adjusted effective rate |  | 19.7 | % |  | 19.6 | % |
| Free cash flow reconciliation |  |  |  |  |
|  |  | Q1-19 |  | Q1-18 |
| Net cash provided by operating activities |  | $ | 30.9 |  |  | $ | 69.3 |  |
| Less: Purchases of property, plant and equipment |  | (14.1 | ) |  | (17.9 | ) |
| Free cash flow |  | $ | 16.8 |  |  | $ | 51.4 |  |

[0000889331-19-000028:8k_2_02:67]
|  |  | Q2-18 |  | Q3-18 |  | Q4-18 |  | Q1-19 |  | For the Twelve Months Ended March 30, 2019 |
| Adjusted EBITDA |  | $ | 111.4 |  |  | $ | 110.5 |  |  | $ | 84.3 |  |  | $ | 89.1 |  |  | $ | 395.3 |  |
|  |  |  |  |  |  |  |  |  |  | March 30, 2019 |
| Current portion of long-term debt |  |  |  |  |  |  |  |  |  | $ | 10.0 |  |
| Long-term debt, less current portion |  |  |  |  |  |  |  |  |  | 676.5 |  |
| Total debt |  |  |  |  |  |  |  |  |  | $ | 686.5 |  |
| Less: Cash |  |  |  |  |  |  |  |  |  | 476.6 |  |
| Net debt |  |  |  |  |  |  |  |  |  | $ | 209.9 |  |
| Adjusted Gross Leverage (defined as total debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 1.7 |
| Adjusted Net Leverage (defined as net debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 0.5 |

[0000889331-19-000028:8k_2_02:68]
Note: Total will not always foot due to rounding.

[0000889331-19-000028:8k_2_02:69]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-19-000028:8k_2_02:70]
(b) $2.1 million and $0.6 million reflected in SG&A and cost of sales, respectively for the three months ended March 30, 2019 and $0.5 million and $0.3 million reflected in SG&A and cost of sales, respectively for the three months ended March 31, 2018.

[0000889331-19-000028:8k_2_02:71]
(c) reflected in amortization of intangibles.

[0000889331-19-000028:8k_2_02:72]
(d) reflected in SG&A.

[0000889331-19-000028:8k_2_02:73]
(e) $2.4 million, $1.6 million and $0.5 million reflected in SG&A, research and development expenses and cost of sales, respectively.

[0000889331-19-000028:8k_2_02:74]
(f) reflected in cost of sales.

[0000889331-19-000028:8k_2_02:75]
(g) included $2.8 million impairment charges to certain other investments, $2.6 million loss on the disposal of a business, and $0.3 million gain primarily related to the final payments for the acquisition of Monolith.

[0000889331-19-000028:8k_2_02:76]
(h) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-19-000028:8k_2_02:77]
###
