# LFUS MD&A — 0000889331-19-000030


## mdna

[0000889331-19-000030:mdna:1]
[same as prior period, unchanged from 0000889331-18-000004:mdna:1]

[0000889331-19-000030:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-19-000030:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 29, 2018.

[0000889331-19-000030:mdna:4]
[same as prior period, unchanged from 0000889331-18-000004:mdna:4]

[0000889331-19-000030:mdna:5]
[same as prior period, unchanged from 0000889331-18-000004:mdna:5]

[0000889331-19-000030:mdna:6]
Founded in 1927, Littelfuse is a global manufacturer of leading technologies in circuit protection, power control and sensing. Sold in over 150 countries, the Company’s products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

[0000889331-19-000030:mdna:7]
The Company maintains a network of global laboratories and engineering centers that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company conducts its business through three reportable segments: Electronics, Automotive, and Industrial. Within these segments, the Company designs, manufactures and sells components and modules for circuit protection, power control and sensing  products throughout the world. The circuit protection products protect against electrostatic discharge, power surges, short circuits, voltage spikes and other harmful occurrences; our power control products safely and efficiently control power to mitigate equipment damage, minimize electrical hazards and improve productivity and our sensor products are used to identify and detect temperature, proximity, flow speed and fluid level in various applications.

[0000889331-19-000030:mdna:8]
[same as prior period, unchanged from 0000889331-18-000004:mdna:8]

[0000889331-19-000030:mdna:9]
For the first quarter of 2019, the Company recognized net sales of  $405.5 million compared to $417.8 million in the first quarter of 2018 representing a decrease of $12.3 million, or 2.9%. The decrease was primarily driven by $9.9 million or 2.4% of unfavorable changes in foreign exchange rates and decreased volume in the passenger car and automotive sensors businesses within the Automotive segment, partially offset by higher volumes in the semiconductor business in the Electronics segment as result of the IXYS acquisition completed on January 17, 2018. The Company recognized net income of $37.0 million, or $1.48 per diluted share, in the first quarter of 2019 compared to net income of $36.0 million, or $1.45 per diluted share in the first quarter of 2018. The increase in net income reflects lower non-segment charges compared to prior year primarily due to the IXYS acquisition, partially offset by lower operating income across all segments and foreign exchange losses.

[0000889331-19-000030:mdna:10]
The Company continues to take actions to improve its cost structure and drive the synergies from the integration of IXYS. The Company expects to realize cost savings from the restructuring activities taken during the first quarter of 2019 including the reorganization of certain  manufacturing, selling and administrative functions within the Electronics and Automotive segments. In April 2019, we announced the closure of a European manufacturing facility in the automotive sensor business within the Automotive segment.  The Company estimates the restructuring costs associated with this plant closure to be approximately  $5.0 million to $7.0 million.

[0000889331-19-000030:mdna:11]
Net cash provided by operating activities was $30.9 million for the three months ended March 30, 2019 as compared to $69.3 million for the three months ended March 31, 2018. The decrease in net cash provided by operating activities reflected lower earnings and higher working capital levels primarily due to the timing of supplier and customer payments.

[0000889331-19-000030:mdna:12]
During the three months ended March 30, 2019, the Company repurchased 79,916 shares of its common stock totaling $13.6 million. Since September 30, 2018, the Company has repurchased 471,888 shares of its common stock at an average price of $172.62 totaling $81.5 million.

[0000889331-19-000030:mdna:13]
[same as prior period, unchanged from 0000889331-18-000004:mdna:13]

[0000889331-19-000030:mdna:14]
The following table summarizes the Company’s condensed consolidated results of operations for the periods presented. The first quarter of 2019 includes $5.1 million of non-segment charges, of which $2.7 million of restructuring charges are primarily related to employee termination costs and $2.4 million of acquisition integration charges are primarily related to the IXYS acquisition.

[0000889331-19-000030:mdna:15]
The first quarter of  2018 includes approximately  $38.6 million of charges primarily related to the IXYS acquisition, which include $17.9 million of purchase accounting inventory step-up charges, $11.6 million  in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $2.5 million in backlog amortization costs, and $4.5 million in stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million change in control expense related to IXYS. In addition, there were $0.8 million of employee termination costs and $0.1 million of acquisition-related expenses for other contemplated acquisitions.

[0000889331-19-000030:mdna:16]
|  |  | First Quarter |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |
| Net sales |  | $ | 405,500 |  |  | $ | 417,813 |  |  | $ | (12,313 | ) |  | (2.9 | )% |
| Gross profit |  | 155,228 |  |  | 149,623 |  |  | 5,605 |  |  | 3.7 | % |
| Operating expenses |  | 94,555 |  |  | 112,052 |  |  | (17,497 | ) |  | (15.6 | )% |
| Operating income |  | 60,673 |  |  | 37,571 |  |  | 23,102 |  |  | 61.5 | % |
| Income before income taxes |  | 46,439 |  |  | 44,646 |  |  | 1,793 |  |  | 4.0 | % |
| Income taxes |  | 9,450 |  |  | 8,617 |  |  | 833 |  |  | 9.7 | % |
| Net income |  | $ | 36,989 |  |  | $ | 36,029 |  |  | $ | 960 |  |  | 2.7 | % |

[0000889331-19-000030:mdna:17]
[same as prior period, unchanged from 0000889331-18-000004:mdna:17]

[0000889331-19-000030:mdna:18]
Net sales decreased $12.3 million or 2.9% for the first quarter of 2019 compared to the first quarter of 2018  primarily due to $9.9 million or 2.4% of unfavorable changes in foreign exchange rates, lower volume in the automotive sensors and passenger car businesses within the Automotive segment, partially offset by higher sales in the semiconductor business driven by the IXYS acquisition.

[0000889331-19-000030:mdna:19]
[same as prior period, unchanged from 0000889331-18-000004:mdna:20]

[0000889331-19-000030:mdna:20]
Gross profit was $155.2 million, or 38.3% of net sales, in the first quarter of 2019 compared to $149.6 million, or 35.8% of net sales, in the first quarter of 2018. The increase in gross margin is primarily due to the 2018 IXYS purchase accounting inventory step-up charge of $17.9 million, which negatively impacted the 2018 gross margin by 4.3%, partially offset by lower volume, unfavorable price impacts and product mix within the Electronics and Automotive segments.

[0000889331-19-000030:mdna:21]
[same as prior period, unchanged from 0000889331-18-000004:mdna:23]

[0000889331-19-000030:mdna:22]
Total operating expenses were $94.6 million, or 23.3% of net sales, for the first quarter of 2019 compared to $112.1 million, or 26.8% of net sales, for the first quarter of 2018. The decrease in operating expenses of $17.5 million is primarily due to lower acquisition and integration related costs of $9.2 million, reduced stock compensation expense of $4.5 million, $2.5 million of backlog amortization expense and $2.1 million of change in control expense related to the IXYS acquisition in 2018.

[0000889331-19-000030:mdna:23]
[same as prior period, unchanged from 0000889331-18-000004:mdna:26]

[0000889331-19-000030:mdna:24]
Operating income was $60.7 million, an increase of $23.1 million, or 61.5%, for the first quarter of 2019 compared to $37.6 million for the first quarter of 2018. The increase in operating income is due to the $17.9 million purchase accounting inventory step-up charges and the lower operating expenses noted above partially offset by lower operating income across all segments. Operating margins increased from 9.0% in the first quarter of 2018 to 15.0% in the first quarter of 2019 driven by factors mentioned above.

[0000889331-19-000030:mdna:25]
[same as prior period, unchanged from 0000889331-18-000004:mdna:29]

[0000889331-19-000030:mdna:26]
Income before income taxes was $46.4 million, or 11.5% of net sales, for the first quarter of 2019 compared to $44.6 million, or 10.7% of net sales, for the first quarter of 2018. In addition to the factors impacting comparative results for operating income discussed above, income before taxes was impacted by foreign exchange losses of $4.2 million during the three months ended March 30, 2019 compared to foreign exchange gains of $10.6 million during the three months ended March 31, 2018, impairment charges of $2.8 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment.

[0000889331-19-000030:mdna:27]
[same as prior period, unchanged from 0000889331-18-000004:mdna:32]

[0000889331-19-000030:mdna:28]
Income tax expense was $9.5 million, or an effective tax rate of 20.3%, for the first quarter of 2019 compared to $8.6 million, or an effective tax rate of 19.3%, for the first quarter of 2018. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-19-000030:mdna:29]
[same as prior period, unchanged from 0000889331-18-000004:mdna:35]

[0000889331-19-000030:mdna:30]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-19-000030:mdna:31]
[same as prior period, unchanged from 0000889331-18-000004:mdna:37]

[0000889331-19-000030:mdna:32]
|  |  | First Quarter |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |
| Electronics |  | $ | 265,394 |  |  | $ | 264,411 |  |  | $ | 983 |  |  | 0.4 | % |
| Automotive |  | 113,483 |  |  | 126,131 |  |  | (12,648 | ) |  | (10.0 | )% |
| Industrial |  | 26,623 |  |  | 27,271 |  |  | (648 | ) |  | (2.4 | )% |
| Total |  | $ | 405,500 |  |  | $ | 417,813 |  |  | $ | (12,313 | ) |  | (2.9 | )% |

[0000889331-19-000030:mdna:33]
[same as prior period, unchanged from 0000889331-18-000004:mdna:39]

[0000889331-19-000030:mdna:34]
Net sales increased $1.0 million, or 0.4%, in the first quarter of 2019 compared to the first quarter of 2018 primarily due to $10.2 million increase in the semiconductor business due to the IXYS acquisition completed on January 17, 2018, partially offset by unfavorable foreign currency impact of $5.3 million and lower electronics products volume.

[0000889331-19-000030:mdna:35]
[same as prior period, unchanged from 0000889331-18-000004:mdna:42]

[0000889331-19-000030:mdna:36]
Net sales decreased $12.6 million, or 10.0%, in the first quarter of 2019 compared to the first quarter of 2018 due to decreased volume in the passenger car and automotive sensors businesses and unfavorable foreign exchange impact of $4.4 million, partially offset by slightly higher volume in the commercial vehicle business.

[0000889331-19-000030:mdna:37]
[same as prior period, unchanged from 0000889331-18-000004:mdna:45]

[0000889331-19-000030:mdna:38]
Net sales decreased slightly by $0.6 million, or 2.4%, in the first quarter of 2019 compared to the first quarter of 2018 primarily due to the exit of the Custom business during the second quarter of 2018 and unfavorable foreign exchange impact of $0.2 million, partially offset by higher volume across the power fuse and relay businesses.

[0000889331-19-000030:mdna:39]
[same as prior period, unchanged from 0000889331-18-000004:mdna:48]

[0000889331-19-000030:mdna:40]
[same as prior period, unchanged from 0000889331-18-000004:mdna:49]

[0000889331-19-000030:mdna:41]
|  |  | First Quarter |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 172,781 |  |  | $ | 179,272 |  |  | $ | (6,491 | ) |  | (3.6 | )% |
| Americas |  | 138,034 |  |  | 138,729 |  |  | (695 | ) |  | (0.5 | )% |
| Europe |  | 94,685 |  |  | 99,812 |  |  | (5,127 | ) |  | (5.1 | )% |
| Total |  | $ | 405,500 |  |  | $ | 417,813 |  |  | $ | (12,313 | ) |  | (2.9 | )% |

[0000889331-19-000030:mdna:42]
[same as prior period, unchanged from 0000889331-18-000004:mdna:57]

[0000889331-19-000030:mdna:43]
Net sales decreased $6.5 million, or 3.6%, in the first quarter of 2019 compared to the first quarter of 2018. The decrease in net sales was primarily due to lower volume in the passenger car and automotive sensors businesses within the Automotive segment and unfavorable foreign currency impact of $2.6 million, partially offset by higher volume in the semiconductor business within the Electronics segment.

[0000889331-19-000030:mdna:44]
[same as prior period, unchanged from 0000889331-18-000004:mdna:51]

[0000889331-19-000030:mdna:45]
Net sales decreased $0.7 million, or 0.5%, in the first quarter of 2019 compared to the first quarter of 2018  primarily due to lower volume in the automotive sensors business in the Automotive segment and unfavorable foreign currency impact of $0.3 million, partially offset by higher volume in the semiconductor business within the Electronics segment.

[0000889331-19-000030:mdna:46]
[same as prior period, unchanged from 0000889331-18-000004:mdna:54]

[0000889331-19-000030:mdna:47]
Net sales decreased $5.1 million, or 5.1%, in the first quarter of 2019 compared to the first quarter of 2018. The decrease in net sales was primarily due to  unfavorable foreign currency effects of $7.0 million, partially offset by higher volume in the commercial vehicles and automotive sensors businesses within the Automotive segment and higher volume in the semiconductor business within the Electronics segment.

[0000889331-19-000030:mdna:48]
[same as prior period, unchanged from 0000889331-18-000004:mdna:60]

[0000889331-19-000030:mdna:49]
[same as prior period, unchanged from 0000889331-18-000004:mdna:61]

[0000889331-19-000030:mdna:50]
Revolving Credit Facility/Term Loan

[0000889331-19-000030:mdna:51]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-19-000030:mdna:52]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principle payments of $5.0 million on the term loan during the three months ended March 30, 2019.

[0000889331-19-000030:mdna:53]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.75% at March 30, 2019.

[0000889331-19-000030:mdna:54]
As of March 30, 2019, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At March 30, 2019, the Company was in compliance with all covenants under the Credit Agreement. Further information regarding the Company’s credit agreement is provided in Note 9, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-19-000030:mdna:55]
[same as prior period, unchanged from 0000889331-18-000004:mdna:68]

[0000889331-19-000030:mdna:56]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes

[0000889331-19-000030:mdna:57]
occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-19-000030:mdna:58]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-19-000030:mdna:59]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 9, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-19-000030:mdna:60]
[same as prior period, unchanged from 0000889331-18-000004:mdna:72]

[0000889331-19-000030:mdna:61]
During the first quarter of 2019, the Company paid quarterly dividends of $10.6 million to the shareholders. On April 26, 2019, the Board of Directors of the Company declared a quarterly dividend of $0.43 per share, payable on June 6, 2019 to stockholders of record as May 23, 2019.

[0000889331-19-000030:mdna:62]
[same as prior period, unchanged from 0000889331-18-000004:mdna:74]

[0000889331-19-000030:mdna:63]
|  |  | First Quarter |
| (in thousands) |  | 2019 |  | 2018 |
| Net cash provided by operating activities |  | $ | 30,919 |  |  | $ | 69,268 |  |
| Net cash used in investing activities |  | (14,244 | ) |  | (324,377 | ) |
| Net cash (used in) provided by financing activities |  | (31,333 | ) |  | 240,308 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,539 |  |  | (2,417 | ) |
| Decrease in cash and cash equivalents |  | (13,119 | ) |  | (17,218 | ) |
| Cash and cash equivalents at beginning of period |  | 489,733 |  |  | 429,676 |  |
| Cash and cash equivalents at end of period |  | $ | 476,614 |  |  | $ | 412,458 |  |

[0000889331-19-000030:mdna:64]
[same as prior period, unchanged from 0000889331-18-000004:mdna:76]

[0000889331-19-000030:mdna:65]
[same as prior period, unchanged from 0000889331-18-000004:mdna:77]

[0000889331-19-000030:mdna:66]
Net cash provided by operating activities was $30.9 million for the first three months of 2019, compared to $69.3 million during the first three months of 2018. The decrease in net cash provided by operating activities reflected lower earnings and higher working capital levels primarily due to the timing of supplier and customer payments.

[0000889331-19-000030:mdna:67]
[same as prior period, unchanged from 0000889331-18-000004:mdna:79]

[0000889331-19-000030:mdna:68]
Net cash used in investing activities was $14.2 million for the three months ended March 30, 2019 compared to $324.4 million during the  three months ended March 31, 2018. Net cash used for the acquisition of IXYS was $306.5 million for the  three months ended March 31, 2018. Capital expenditures were $14.1 million, representing a decrease of $3.8 million compared to 2018.

[0000889331-19-000030:mdna:69]
[same as prior period, unchanged from 0000889331-18-000004:mdna:81]

[0000889331-19-000030:mdna:70]
Net cash used in financing activities was $31.3 million for the three months ended March 30, 2019 compared to net cash provided by financing activities of $240.3 million for the  three months ended March 31, 2018. The Company repurchased 79,916 shares of its common stock during the three months ended March 30, 2019 totaling $13.6 million, but made payments of $17.9 million related to settled share repurchases. The Company made payments of $5.0 million on the term loan during the three months ended March 30, 2019 as compared to $300.0 million of proceeds from the credit facility and senior notes payable and $49.5 million of payments on the credit facility and term loan during the  three months ended March 31, 2018. Additionally, dividends paid increased $1.4 million from $9.2 million in 2018 to $10.6 million for the three months ended March 30, 2019.

[0000889331-19-000030:mdna:71]
[same as prior period, unchanged from 0000889331-18-000004:mdna:83]

[0000889331-19-000030:mdna:72]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 (“Share Repurchase Program”). During the  three months ended March 30, 2019, the Company repurchased 79,916 shares of its common stock totaling $13.6 million. The Share Repurchase Program expired on April 30, 2019 with  471,888 shares repurchased. On April 26, 2019, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020.

[0000889331-19-000030:mdna:73]
[same as prior period, unchanged from 0000889331-18-000004:mdna:86]

[0000889331-19-000030:mdna:74]
As of  March 30, 2019, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-19-000030:mdna:75]
[same as prior period, unchanged from 0000889331-18-000004:mdna:88]

[0000889331-19-000030:mdna:76]
[same as prior period, unchanged from 0000889331-18-000004:mdna:89]

[0000889331-19-000030:mdna:77]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 29, 2018. During the three months ended March 30, 2019, there were no significant changes in the application of critical accounting policies.
