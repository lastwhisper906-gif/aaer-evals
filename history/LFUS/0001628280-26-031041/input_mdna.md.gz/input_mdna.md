# LFUS MD&A — 0001628280-26-031041


## mdna

[0001628280-26-031041:mdna:1]
[same as prior period, unchanged from 0001628280-25-047026:mdna:1]

[0001628280-26-031041:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001628280-26-031041:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 27, 2025.

[0001628280-26-031041:mdna:4]
[same as prior period, unchanged from 0001628280-25-047026:mdna:4]

[0001628280-26-031041:mdna:5]
[same as prior period, unchanged from 0001628280-25-047026:mdna:5]

[0001628280-26-031041:mdna:6]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0001628280-26-031041:mdna:7]
[same as prior period, unchanged from 0001628280-25-047026:mdna:7]

[0001628280-26-031041:mdna:8]
[same as prior period, unchanged from 0001628280-25-047026:mdna:8]

[0001628280-26-031041:mdna:9]
For the first quarter of 2026, the Company recognized net sales of $657.0 million, an increase of $102.7 million, or 18.5% as compared to $554.3 million in the first quarter of 2025 including $33.2 million, or 6.0% of incremental net sales, from the Basler acquisition within the Industrial segment and $17.5 million, or 3.2% of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume in the Electronics segment. The Company recognized net income of $75.1 million, or $2.96 per diluted share, in the first quarter of 2026 compared to $43.6 million, or $1.75 per diluted share, in the first quarter of 2025. The increase in net income was primarily due to higher operating income of $23.5 million from the Electronics segment driven by increases in net sales and volume leverage.

[0001628280-26-031041:mdna:10]
Net cash provided by operating activities was $80.3 million for the three months ended March 28, 2026 compared to $65.8 million for the three months ended March 29, 2025. The increase in net cash provided by operating activities of $14.5 million was primarily due to higher cash earnings, partially offset by increases in working capital primarily resulting from higher annual incentive bonus payments made in 2026 as compared to 2025.

[0001628280-26-031041:mdna:11]
On March 12, 2026, the Company entered into an Amended and Restated Credit Agreement (the "Credit Agreement") to amend and restate and effect certain changes to its existing Credit Agreement, dated as of June 30, 2022 (the “Existing Credit Agreement”), including, among other changes: (i) paying off and eliminating the $300 million unsecured term loan credit facility; (ii) increasing the size of the revolver from $700 million to $800 million; and (iii) extending the maturity date to March 12, 2031 (the “Maturity Date”). As a result of entering into the Credit Agreement, the Company paid off $62.5 million of the term loan and replaced $200 million of the term loan under the Existing Credit Agreement with $200 million borrowing under the revolver under the Credit Agreement. Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-26-031041:mdna:12]
[same as prior period, unchanged from 0001628280-25-047026:mdna:17]

[0001628280-26-031041:mdna:13]
In Item 1A. "Risk factors" of the Company’s Annual Report on Form 10-K for the year ended December 27, 2025, the Company disclosed its exposure to political, economic, and other risks that arise from operating a multinational business, including effects on the global economy due to geopolitical tensions. Among those tensions, is the ongoing military conflict among the U.S., Israel, Iran and Lebanon and the related disruptions to shipping through the Strait of Hormuz, which have led to significant volatility in global energy markets and could lead to prolonged increases in crude oil and natural gas prices. Disruptions in these markets may reduce supply availability and increase material costs, including petroleum-based plastic resins, which we use in some of our products and manufacturing processes. Energy price volatility may also increase transportation and logistics costs for the Company.

[0001628280-26-031041:mdna:14]
[same as prior period, unchanged from 0001628280-25-047026:mdna:21]

[0001628280-26-031041:mdna:15]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The first quarter of 2026 included $7.4 million of restructuring charges primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first quarter of 2026, the Company recognized $1.2 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2026, the Company recognized $5.4 million of purchase accounting inventory step-up adjustment related to the Basler acquisition.

[0001628280-26-031041:mdna:16]
The first quarter of 2025 included $8.9 million of restructuring charges primarily related to employee termination costs, and $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the first quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustment related to the Dortmund acquisition, and $0.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions.

[0001628280-26-031041:mdna:17]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2026 |  | 2025 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 656,969 |  |  | $ | 554,307 |  |  | $ | 102,662 |  |  | 18.5 | % |  |  |  |  |  |  |  |  |
| Cost of sales |  | 402,820 |  |  | 347,051 |  |  | 55,769 |  |  | 16.1 | % |  |  |  |  |  |  |  |  |
| Gross profit |  | 254,149 |  |  | 207,256 |  |  | 46,893 |  |  | 22.6 | % |  |  |  |  |  |  |  |  |
| Operating expenses |  | 152,984 |  |  | 137,106 |  |  | 15,878 |  |  | 11.6 | % |  |  |  |  |  |  |  |  |
| Operating income |  | 101,165 |  |  | 70,150 |  |  | 31,015 |  |  | 44.2 | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | 96,731 |  |  | 59,947 |  |  | 36,784 |  |  | 61.4 | % |  |  |  |  |  |  |  |  |
| Income taxes |  | 21,584 |  |  | 16,376 |  |  | 5,208 |  |  | 31.8 | % |  |  |  |  |  |  |  |  |
| Net income |  | 75,147 |  |  | 43,571 |  |  | 31,576 |  |  | 72.5 | % |  |  |  |  |  |  |  |  |

[0001628280-26-031041:mdna:18]
[same as prior period, unchanged from 0001628280-25-047026:mdna:25]

[0001628280-26-031041:mdna:19]
Net sales increased $102.7 million, or 18.5%, for the first quarter of 2026 compared to the first quarter of 2025 including $33.2 million or 6.0% of incremental net sales from the Basler acquisition within the Industrial segment and $17.5 million or 3.2% of favorable changes in foreign exchange rates. The increase in net sales was primarily due to higher volume of $38.2 million and $17.4 million in the electronics products and semiconductor businesses within the Electronics segment, respectively, driven by higher end market demand and favorable price.

[0001628280-26-031041:mdna:20]
[same as prior period, unchanged from 0001628280-25-047026:mdna:28]

[0001628280-26-031041:mdna:21]
Cost of sales was $402.8 million, or 61.3% of net sales, in the first quarter of 2026 compared to $347.1 million, or 62.6% of net sales, in the first quarter of 2025. The increase of $55.8 million included $25.1 million of incremental cost of sales from the Basler acquisition within the Industrial segment. The remaining increase was due to higher volume across all segments. As a percent of net sales, cost of sales decreased 1.3% primarily due to improved margin from the electronics products business within the Electronics segment, the industrial circuit protection products business within the Industrial segment, and the passenger car products business within the Transportation segment driven by volume leverage and favorable product mix. The improved margin was also favorably impacted by higher gross margin from the Basler acquisition, partially offset by purchase accounting inventory charges of $5.4 million or 0.8%.

[0001628280-26-031041:mdna:22]
[same as prior period, unchanged from 0001628280-25-047026:mdna:31]

[0001628280-26-031041:mdna:23]
Gross profit was $254.1 million, or 38.7% of net sales, in the first quarter of 2026 compared to $207.3 million, or 37.4% of net sales, in the first quarter of 2025. The increase of $46.9 million in gross profit and the improved gross margin were primarily due to higher volume and favorable price and product mix from the electronics products business within the Electronics segment and the industrial circuit protection business within the Industrial segment. Additionally, gross margin was higher due to the passenger car products business within the Transportation segment and higher gross margin from the Basler acquisition, partially offset by the purchase accounting inventory charges of $5.4 million or 0.8%.

[0001628280-26-031041:mdna:24]
[same as prior period, unchanged from 0001628280-25-047026:mdna:34]

[0001628280-26-031041:mdna:25]
Operating expenses were $153.0 million, or 23.3% of net sales, for the first quarter of 2026 compared to $137.1 million, or 24.7% of net sales, for the first quarter of 2025. The increase in operating expenses of $15.9 million was primarily driven by incremental operating expenses of $11.8 million from the Basler acquisition.

[0001628280-26-031041:mdna:26]
[same as prior period, unchanged from 0001628280-25-047026:mdna:37]

[0001628280-26-031041:mdna:27]
Operating income was $101.2 million, representing an increase of $31.0 million, or 44.2%, for the first quarter of 2026 compared to $70.2 million for the first quarter of 2025. The increase in operating income was due to higher gross profit from

[0001628280-26-031041:mdna:28]
the electronics products business within the Electronics segment, the industrial circuit protection products business within the Industrial segment, and the passenger car products business within the Transportation segment, partially offset by higher operating expenses mainly driven by the Basler acquisition noted above. Operating margins increased from 12.7% in the first quarter of 2025 to 15.4% in the first quarter of 2026 driven by improved gross margin from the electronics products business within the Electronics segment, the industrial circuit protection products business within the Industrial segment, and the passenger car products business within the Transportation segment driven by volume leverage and favorable price and product mix.

[0001628280-26-031041:mdna:29]
[same as prior period, unchanged from 0001628280-25-047026:mdna:40]

[0001628280-26-031041:mdna:30]
Income before income taxes was $96.7 million, or 14.7% of net sales, for the first quarter of 2026 compared to $59.9 million, or 10.8% of net sales, for the first quarter of 2025. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by foreign exchange gains of $2.4 million in the first quarter of 2026 compared to foreign exchange losses of $4.8 million in the first quarter of 2025, and lower unrealized losses of $1.5 million in the first quarter of 2026 compared to the first quarter of 2025 related to the Company's equity investment.

[0001628280-26-031041:mdna:31]
[same as prior period, unchanged from 0001628280-25-047026:mdna:43]

[0001628280-26-031041:mdna:32]
The effective tax rate for the three months ended March 28, 2026 was 22.3% compared to the effective tax rate for the three months ended March 29, 2025 of 27.3%. The effective tax rate for 2026 was lower than the effective tax rate for the comparable 2025 period primarily due to lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter of 2026.

[0001628280-26-031041:mdna:33]
The effective tax rate for three months ended March 28, 2026 was higher than the statutory tax rate primarily due to losses in non-U.S. jurisdictions with no related tax benefit, partially offset by lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter. The effective tax rate for the three months ended March 29, 2025 was higher than the statutory tax rate primarily due to losses in non-US jurisdictions with no related tax benefit.

[0001628280-26-031041:mdna:34]
[same as prior period, unchanged from 0001628280-25-047026:mdna:47]

[0001628280-26-031041:mdna:35]
[same as prior period, unchanged from 0001628280-25-047026:mdna:48]

[0001628280-26-031041:mdna:36]
[same as prior period, unchanged from 0001628280-25-047026:mdna:49]

[0001628280-26-031041:mdna:37]
| Net Sales |  | First Quarter |  |  |
| (in thousands) |  | 2026 |  | 2025 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 362,775 |  |  | $ | 307,249 |  |  | $ | 55,526 |  |  | 18.1 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 170,381 |  |  | 161,862 |  |  | 8,519 |  |  | 5.3 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 123,813 |  |  | 85,196 |  |  | 38,617 |  |  | 45.3 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 656,969 |  |  | $ | 554,307 |  |  | $ | 102,662 |  |  | 18.5 | % |  |  |  |  |  |  |  |  |

[0001628280-26-031041:mdna:38]
| Segment Operating Income |  | First Quarter |  |  |
| (in thousands) |  | 2026 |  | 2025 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 70,279 |  |  | $ | 46,766 |  |  | $ | 23,513 |  |  | 50.3 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 24,103 |  |  | 18,917 |  |  | 5,186 |  |  | 27.4 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 20,761 |  |  | 13,074 |  |  | 7,687 |  |  | 58.8 | % |  |  |  |  |  |  |  |  |
| Total segment operating income |  | 115,143 |  |  | 78,757 |  |  | 36,386 |  |  |  |  |  |  |  |  |  |  |  |
| Other (a) |  | (13,978) |  |  | (8,607) |  |  | (5,371) |  |  |  |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 101,165 |  |  | $ | 70,150 |  |  | $ | 31,015 |  |  | 44.2 | % |  |  |  |  |  |  |  |  |

[0001628280-26-031041:mdna:39]
(a) Included in “Other” Operating income for the first quarter of 2026 was $7.4 million of restructuring charges primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In

[0001628280-26-031041:mdna:40]
addition, during the first quarter of 2026, the Company recognized $1.2 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2026, the Company recognized $5.4 million of purchase accounting inventory step-up adjustment related to the Basler acquisition.

[0001628280-26-031041:mdna:41]
Included in “Other” Operating income for the first quarter of 2025 was $8.9 million of restructuring charges primarily related to employee termination costs, and $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the first quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustment related to the Dortmund acquisition, and $0.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions.

[0001628280-26-031041:mdna:42]
[same as prior period, unchanged from 0001628280-25-047026:mdna:54]

[0001628280-26-031041:mdna:43]
[same as prior period, unchanged from 0001628280-25-047026:mdna:55]

[0001628280-26-031041:mdna:44]
Net sales increased $55.5 million, or 18.1%, in the first quarter of 2026 compared to the first quarter of 2025 and included favorable changes in foreign exchange rates of $10.5 million or 3.4%. The net sales increase was primarily due to higher volume of $38.2 million and $17.4 million in the electronics products and semiconductor businesses, respectively, driven by higher end market demand and favorable price.

[0001628280-26-031041:mdna:45]
[same as prior period, unchanged from 0001628280-25-047026:mdna:58]

[0001628280-26-031041:mdna:46]
Operating income was $70.3 million, representing an increase of $23.5 million, or 50.3%, for the first quarter of 2026 compared to $46.8 million for the first quarter of 2025. The increase in operating income was primarily from the electronics products business due to volume leverage and favorable product mix. Operating margins increased from 15.2% in the first quarter of 2025 to 19.4% in the first quarter of 2026 primarily due to volume leverage and favorable price and product mix from the electronics products business.

[0001628280-26-031041:mdna:47]
[same as prior period, unchanged from 0001628280-25-047026:mdna:61]

[0001628280-26-031041:mdna:48]
[same as prior period, unchanged from 0001628280-25-047026:mdna:62]

[0001628280-26-031041:mdna:49]
Net sales increased $8.5 million, or 5.3%, in the first quarter of 2026 compared to the first quarter of 2025 and included favorable changes in foreign exchange rates of $6.2 million or 3.8%. The remaining net sales increase was due to higher volume in the passenger car products business driven by higher market demand with vehicle content growth.

[0001628280-26-031041:mdna:50]
[same as prior period, unchanged from 0001628280-25-047026:mdna:65]

[0001628280-26-031041:mdna:51]
Operating income was $24.1 million, representing an increase of $5.2 million, or 27.4%, for the first quarter of 2026 compared to $18.9 million for the first quarter of 2025. The increase in operating income was primarily due to higher gross margin from the passenger car products business driven by volume leverage and operational execution. Operating margins increased from 11.7% in the first quarter of 2025 to 14.1% in the first quarter of 2026.

[0001628280-26-031041:mdna:52]
[same as prior period, unchanged from 0001628280-25-047026:mdna:68]

[0001628280-26-031041:mdna:53]
[same as prior period, unchanged from 0001628280-25-047026:mdna:69]

[0001628280-26-031041:mdna:54]
Net sales increased $38.6 million, or 45.3%, in the first quarter of 2026 compared to the first quarter of 2025 including $33.2 million of incremental net sales from the Basler acquisition and favorable changes in foreign exchange rates of $0.8 million or 1.0%. The remaining net sales increase was due to higher net sales from the industrial circuit protection products driven by higher volume, partially offset by lower volume from industrial control and sensor products.

[0001628280-26-031041:mdna:55]
[same as prior period, unchanged from 0001628280-25-047026:mdna:72]

[0001628280-26-031041:mdna:56]
Operating income was $20.8 million, representing an increase of $7.7 million, or 58.8%, for the first quarter of 2026 compared to $13.1 million for the first quarter of 2025. The increase in operating income was due to higher gross margin from the industrial circuit protection products driven by volume leverage, operational efficiencies, favorable product mix and the incremental increase from the Basler acquisition. Operating margins increased from 15.3% in the first quarter of 2025 to 16.8% in the first quarter of 2026 due to improved gross margin in the industrial circuit protection products and the Basler acquisition

[0001628280-26-031041:mdna:57]
noted previously, partially offset by lower margin from industrial control and sensor products and higher amortization expenses of $2.9 million related to the Basler acquisition.

[0001628280-26-031041:mdna:58]
[same as prior period, unchanged from 0001628280-25-047026:mdna:75]

[0001628280-26-031041:mdna:59]
[same as prior period, unchanged from 0001628280-25-047026:mdna:76]

[0001628280-26-031041:mdna:60]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2026 |  | 2025 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Americas |  | $ | 261,846 |  |  | $ | 224,690 |  |  | $ | 37,156 |  |  | 16.5 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 248,276 |  |  | 205,284 |  |  | 42,992 |  |  | 20.9 | % |  |  |  |  |  |  |  |  |
| Europe |  | 146,847 |  |  | 124,333 |  |  | 22,514 |  |  | 18.1 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 656,969 |  |  | $ | 554,307 |  |  | $ | 102,662 |  |  | 18.5 | % |  |  |  |  |  |  |  |  |

[0001628280-26-031041:mdna:61]
[same as prior period, unchanged from 0001628280-25-047026:mdna:78]

[0001628280-26-031041:mdna:62]
Net sales increased $37.2 million, or 16.5%, in the first quarter of 2026 compared to the first quarter of 2025 and included favorable changes in foreign exchange rates of $0.8 million. The increase in net sales was primarily due to incremental net sales of $29.9 million from the Basler acquisition within the Industrial segment, and higher volume from the electronics products business within the Electronics segment, partially offset by lower volume from the commercial vehicle business within the Transportation segment and industrial control and sensor products within the Industrial segment.

[0001628280-26-031041:mdna:63]
[same as prior period, unchanged from 0001628280-25-047026:mdna:81]

[0001628280-26-031041:mdna:64]
Net sales increased $43.0 million, or 20.9%, in the first quarter of 2026 compared to the first quarter of 2025 and included favorable changes in foreign exchange rates of $2.3 million. The remaining increase in net sales was primarily due to higher volume from the Electronics segment and the industrial circuit protection products within the Industrial segment, and incremental net sales of $1.8 million from the Basler acquisition within the Industrial segment.

[0001628280-26-031041:mdna:65]
[same as prior period, unchanged from 0001628280-25-047026:mdna:84]

[0001628280-26-031041:mdna:66]
Net sales increased $22.5 million, or 18.1%, in the first quarter of 2026 compared to the first quarter of 2025 and included favorable changes in foreign exchange rates of $14.4 million. The remaining increase in net sales was primarily due to higher volume from the electronics products business within the Electronics segment and across all businesses within the Transportation segment and incremental net sales of $1.5 million from the Basler acquisition within the Industrial segment.

[0001628280-26-031041:mdna:67]
[same as prior period, unchanged from 0001628280-25-047026:mdna:87]

[0001628280-26-031041:mdna:68]
[same as prior period, unchanged from 0001628280-25-047026:mdna:88]

[0001628280-26-031041:mdna:69]
Cash and cash equivalents were $481.7 million as of March 28, 2026, a decrease of $81.7 million, as compared to December 27, 2025. As of March 28, 2026, $67.6 million of the Company's $481.7 million cash and cash equivalents was held by U.S. subsidiaries.

[0001628280-26-031041:mdna:70]
Revolving Credit Facility and Term Loan

[0001628280-26-031041:mdna:71]
On March 12, 2026, the Company entered into an Amended and Restated Credit Agreement (the "Credit Agreement") to amend and restate and effect certain changes to its existing credit agreement, dated as of June 30, 2022 (the “Existing Credit Agreement”), including, among other changes: (i) paying off and eliminating the $300 million unsecured term loan credit facility; (ii) increasing the size of the revolving credit facility from $700 million to $800 million; and (iii) extending the maturity date to March 12, 2031 (the “Maturity Date”). As a result of entering into the Credit Agreement, the Company paid off

[0001628280-26-031041:mdna:72]
$62.5 million of the term loan and replaced $200 million of the term loan under the Existing Credit Agreement with $200 million borrowing under the revolving credit facility under the Credit Agreement. Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-26-031041:mdna:73]
The principal balance of the revolving credit facility is due on the Maturity Date. The revolving loan balances under the Credit Facility were $200.0 million as of March 28, 2026. Prior to entering into the Credit Agreement, the Company paid off $100.0 million of the revolving loan and $3.8 million of the term loan under the Existing Credit Agreement during the first quarter of 2026.

[0001628280-26-031041:mdna:74]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either (i) Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, based upon the Company's Consolidated Leverage Ratio, as defined in the Credit Agreement or (ii) the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-26-031041:mdna:75]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty.

[0001628280-26-031041:mdna:76]
[same as prior period, unchanged from 0001628280-25-047026:mdna:94]

[0001628280-26-031041:mdna:77]
As of March 28, 2026, the effective interest rate on the outstanding borrowings under the Credit Facility was 3.88% on the hedged portion.

[0001628280-26-031041:mdna:78]
As of March 28, 2026, the Company had $1.2 million outstanding letters of credit and had $598.8 million of borrowing capacity available under the revolving credit facility. As of March 28, 2026, the Company was in compliance with all covenants under the Credit Agreement.

[0001628280-26-031041:mdna:79]
[same as prior period, unchanged from 0001628280-25-047026:mdna:97]

[0001628280-26-031041:mdna:80]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due 2023. Interest on the Euro Senior Notes, Series B due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-26-031041:mdna:81]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due 2022. Interest on the U.S. Senior Notes, Series B due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-26-031041:mdna:82]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”)

[0001628280-26-031041:mdna:83]
(together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due 2025. Interest on the U.S. Senior Notes, Series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0001628280-26-031041:mdna:84]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-26-031041:mdna:85]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-26-031041:mdna:86]
[same as prior period, unchanged from 0001628280-25-047026:mdna:103]

[0001628280-26-031041:mdna:87]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage.

[0001628280-26-031041:mdna:88]
[same as prior period, unchanged from 0001628280-25-047026:mdna:105]

[0001628280-26-031041:mdna:89]
Debt Covenants

[0001628280-26-031041:mdna:90]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of March 28, 2026 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2025. As of March 28, 2026, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0001628280-26-031041:mdna:91]
[same as prior period, unchanged from 0001628280-25-047026:mdna:108]

[0001628280-26-031041:mdna:92]
On December 11, 2025, the Company completed the acquisition of Basler. Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. At the time of acquisition, Basler had annualized sales of approximately $130 million. The business is reported within the Company’s Industrial segment. The total purchase consideration of $352.8 million, net of cash acquired, subject to a working capital adjustment. The acquisition was funded with the Company's cash on hand.

[0001628280-26-031041:mdna:93]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab was approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment. The acquisition was funded with the Company's cash on hand.

[0001628280-26-031041:mdna:94]
[same as prior period, unchanged from 0001628280-25-047026:mdna:110]

[0001628280-26-031041:mdna:95]
During the first quarter of 2026, the Company paid quarterly dividends of $18.8 million to its shareholders. On May 6, 2026, the Company announced the declaration of a quarterly cash dividend of $0.75 per share payable on June 4, 2026 to stockholders of record as of May 21, 2026.

[0001628280-26-031041:mdna:96]
[same as prior period, unchanged from 0001628280-25-047026:mdna:112]

[0001628280-26-031041:mdna:97]
|  |  | First Three Months |
| (in thousands) |  | 2026 |  | 2025 |
| Net cash provided by operating activities |  | $ | 80,258 |  |  | $ | 65,758 |  |
| Net cash used in investing activities |  | (16,571) |  |  | (80,508) |  |
| Net cash used in financing activities |  | (142,656) |  |  | (97,034) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (2,762) |  |  | 5,603 |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (81,731) |  |  | (106,181) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 565,104 |  |  | 726,437 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 483,373 |  |  | $ | 620,256 |  |

[0001628280-26-031041:mdna:98]
[same as prior period, unchanged from 0001628280-25-047026:mdna:114]

[0001628280-26-031041:mdna:99]
[same as prior period, unchanged from 0001628280-25-047026:mdna:115]

[0001628280-26-031041:mdna:100]
Net cash provided by operating activities was $80.3 million for the three months ended March 28, 2026 compared to $65.8 million for the three months ended March 29, 2025. The increase in net cash provided by operating activities of $14.5 million was primarily due to higher cash earnings, partially offset by increases in working capital primarily resulting from higher annual incentive bonus payments made in 2026 as compared to 2025.

[0001628280-26-031041:mdna:101]
[same as prior period, unchanged from 0001628280-25-047026:mdna:117]

[0001628280-26-031041:mdna:102]
Net cash used in investing activities was $16.6 million for the three months ended March 28, 2026 compared to $80.5 million during the three months ended March 29, 2025. The Company made a payment of $2.5 million for the Basler acquisition during the three months ended March 28, 2026. Net cash paid for the Dortmund Fab acquisition was $57.4 million during the three months ended March 29, 2025. Capital expenditures for the three months ended March 28, 2026 were $14.1 million, representing a decrease of $9.0 million, compared to the three months ended March 29, 2025.

[0001628280-26-031041:mdna:103]
[same as prior period, unchanged from 0001628280-25-047026:mdna:119]

[0001628280-26-031041:mdna:104]
Net cash used in financing activities was $142.7 million for the three months ended March 28, 2026 compared to $97.0 million for the three months ended March 29, 2025. On March 12, 2026, the Company entered into the Credit Agreement to amend and restate and effect certain changes to its existing credit agreement, dated as of June 30, 2022. As a result of entering into the Credit Agreement, the Company paid off $62.5 million of the term loan and replaced $200 million of the term loan under the existing credit agreement with $200 million borrowing under the revolving credit facility under the Credit Agreement. Prior to the amendment on March 12, 2026, the Company paid off $100.0 million of the revolving credit facility and $3.8 million of the term loan under the prior Credit Agreement during the first quarter of 2026. During the three months ended March 29, 2025, the Company paid off $50.0 million of U.S. Senior Notes, Series A, due February 15, 2025 and made payments of $3.8 million on the term loan. The Company received $45.2 million net proceeds related to stock-based award activities during the three months ended March 28, 2026 compared to $2.1 million for the three months ended March 29, 2025. In addition, the Company paid dividends of $18.8 million and $17.3 million in the three months ended March 28, 2026 and March 29, 2025, respectively. During the three months ended March 29, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million.

[0001628280-26-031041:mdna:105]
[same as prior period, unchanged from 0001628280-25-047026:mdna:121]

[0001628280-26-031041:mdna:106]
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program"). The Company did not repurchase any shares of its common stock for the three months ended March 28, 2026. During the three months ended March 29, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program.

[0001628280-26-031041:mdna:107]
[same as prior period, unchanged from 0001628280-25-047026:mdna:123]

[0001628280-26-031041:mdna:108]
As of March 28, 2026, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the

[0001628280-26-031041:mdna:109]
debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-26-031041:mdna:110]
[same as prior period, unchanged from 0001628280-25-047026:mdna:125]

[0001628280-26-031041:mdna:111]
[same as prior period, unchanged from 0001628280-25-047026:mdna:126]

[0001628280-26-031041:mdna:112]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 27, 2025. During the three months ended March 28, 2026, there were no significant changes in the application of critical accounting policies and estimates.
