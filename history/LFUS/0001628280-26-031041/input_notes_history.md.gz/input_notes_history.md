# LFUS note change history — 0001628280-25-047026 → 0001628280-26-031041


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:1]
As of March 28, 2026, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.
  (was, 2025-10-29, similarity 0.9878):
[0001628280-25-047026:note_history:1]
As of September 27, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

- changed (2026-05-06):
[0001628280-26-031041:note_history:2]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.
  (was, 2025-10-29, similarity 0.999):
[0001628280-25-047026:note_history:2]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

- changed (2026-05-06):
[0001628280-26-031041:note_history:3]
There were no material pending litigation or claims outstanding as of March 28, 2026.
  (was, 2025-10-29, similarity 0.9383):
[0001628280-25-047026:note_history:3]
There were no material pending litigation or claims outstanding as of September 27, 2025.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:4]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of operations and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 27, 2025, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2025-10-29, similarity 0.9915):
[0001628280-25-047026:note_history:4]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2024, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

- changed (2026-05-06):
[0001628280-26-031041:note_history:5]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 28, 2026 and March 29, 2025:
  (was, 2025-10-29, similarity 0.8975):
[0001628280-25-047026:note_history:5]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 27, 2025 and September 28, 2024:

- added (2026-05-06):
[0001628280-26-031041:note_history:6]
|  |  | Three Months Ended March 28, 2026 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 187,123 |  |  | $ | — |  |  | $ | — |  |  | $ | 187,123 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 175,652 |  |  | $ | — |  |  | $ | — |  |  | 175,652 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 78,881 |  |  | — |  |  | 78,881 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 76,240 |  |  | — |  |  | 76,240 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,260 |  |  | — |  |  | 15,260 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 123,813 |  |  | 123,813 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 362,775 |  |  | $ | 170,381 |  |  | $ | 123,813 |  |  | $ | 656,969 |  |  |  |  |  |  |  |  |  |

- changed (2026-05-06):
[0001628280-26-031041:note_history:7]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |
  (was, 2025-10-29, similarity 0.6702):
[0001628280-25-047026:note_history:7]
|  |  | Three Months Ended September 27, 2025 |  | Nine Months Ended September 27, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 174,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 174,073 |  |  | $ | 499,329 |  |  | $ | — |  |  | $ | — |  |  | $ | 499,329 |  |
| Electronics – Passive Products and Sensors |  | 183,384 |  |  | — |  |  | — |  |  | 183,384 |  |  | 501,043 |  |  | — |  |  | — |  |  | 501,043 |  |
| Commercial Vehicle Products |  | — |  |  | 80,272 |  |  | — |  |  | 80,272 |  |  | — |  |  | 244,301 |  |  | — |  |  | 244,301 |  |
| Passenger Car Products |  | — |  |  | 75,636 |  |  | — |  |  | 75,636 |  |  | — |  |  | 220,822 |  |  | — |  |  | 220,822 |  |
| Automotive Sensors |  | — |  |  | 15,403 |  |  | — |  |  | 15,403 |  |  | — |  |  | 47,450 |  |  | — |  |  | 47,450 |  |
| Industrial Products |  | — |  |  | — |  |  | 95,872 |  |  | 95,872 |  |  | — |  |  | — |  |  | 279,415 |  |  | 279,415 |  |
| Total |  | $ | 357,457 |  |  | $ | 171,311 |  |  | $ | 95,872 |  |  | $ | 624,640 |  |  | $ | 1,000,372 |  |  | $ | 512,573 |  |  | $ | 279,415 |  |  | $ | 1,792,360 |  |

- changed (2026-05-06):
[0001628280-26-031041:note_history:8]
Some of the terms of the Company's sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a "ship and debit" program. This program allows the distributors to debit the Company for the difference between the distributors' contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to "debit" its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2025-10-29, similarity 0.8964):
[0001628280-25-047026:note_history:8]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on

- changed (2026-05-06):
[0001628280-26-031041:note_history:9]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 28, 2026 and December 27, 2025 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2025-10-29, similarity 0.8966):
[0001628280-25-047026:note_history:9]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at September 27, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2026-05-06):
[0001628280-26-031041:note_history:10]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Cash and cash equivalents |  | $ | 481,697 |  |  | $ | 563,391 |  |
| Restricted cash included in other long-term assets |  | 1,676 |  |  | 1,713 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 483,373 |  |  | $ | 565,104 |  |
  (was, 2025-10-29, similarity 0.9252):
[0001628280-25-047026:note_history:10]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 814,733 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,696 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 816,429 |  |  | $ | 726,437 |  |

- added (2026-05-06):
[0001628280-26-031041:note_history:11]
Recently Adopted Accounting Standards

- changed (2026-05-06):
[0001628280-26-031041:note_history:12]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2025-05, "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets." The amendments in this update provide entities with a practical expedient when estimating expected credit losses for current accounts receivable and current contract assets arising from transactions accounted for under Topic 606. In developing reasonable and supportable forecasts as part of estimating expected credit losses, the practical expedient allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for fiscal years beginning after December 15, 2025 with early adoption permitted. The adoption of ASU 2025-05 did not have a material impact on the Company's Condensed Consolidated Financial Statements.
  (was, 2025-10-29, similarity 0.8762):
[0001628280-25-047026:note_history:12]
In September 2025, the FASB issued ASU No. 2025-05, "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets." The amendments in this update provide entities with a practical expedient when estimating expected credit losses for current accounts receivable and current contract assets arising from transactions accounted for under Topic 606. In developing reasonable and supportable forecasts as part of estimating expected credit losses, the practical expedient allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for fiscal years beginning after December 15, 2025 with early adoption permitted. The Company does not expect any material effect of the adoption of this guidance on the Company's Condensed Consolidated Financial Statements.

- changed (2026-05-06):
[0001628280-26-031041:note_history:13]
In September 2025, the FASB issued ASU No. 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software." The amendments in this update require the entity to start capitalizing software costs when both of the following criteria are met: (1) management has authorized and committed to funding the software project, and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the "probable-to-complete recognition threshold"). The amendments clarify that the intangibles disclosures are not required for capitalized internal-use software costs. Additionally, the amendments in this update supersede the website development costs guidance and incorporate the recognition requirements for website-specific development costs. The guidance is effective for fiscal years beginning after December 15, 2027 with early adoption permitted. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.
  (was, 2025-10-29, similarity 0.9555):
[0001628280-25-047026:note_history:13]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software." The amendments in this update require the entity to start capitalizing software costs when both of the following criteria are met: (1) management has authorized and committed to funding the software project, and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the "probable-to-complete recognition threshold"). The amendments clarify that the intangibles disclosures are not required for capitalized internal-use software costs. Additionally, the amendments in this update supersede the website development costs guidance and incorporate the recognition requirements for website-specific development costs. The guidance is effective for fiscal years beginning after December 15, 2027 with early adoption permitted. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

- changed (2026-05-06):
[0001628280-26-031041:note_history:14]
In November 2024, the FASB issued ASU No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements; (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively; (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Condensed Consolidated Financial Statements.
  (was, 2025-10-29, similarity 0.7918):
[0001628280-25-047026:note_history:14]
In November 2024, the FASB issued ASU No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are

- removed (2026-05-06):
[0001628280-25-047026:note_history:15]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

- removed (2026-05-06):
[0001628280-25-047026:note_history:16]
historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- removed (2026-05-06):
[0001628280-25-047026:note_history:17]
not separately disaggregated quantitatively (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Condensed Consolidated Financial Statements.

- removed (2026-05-06):
[0001628280-25-047026:note_history:18]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify disclosures in the Company's Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:19]
The carrying amounts of debt at March 28, 2026 and December 27, 2025 were as follows:
  (was, 2025-10-29, similarity 0.9351):
[0001628280-25-047026:note_history:19]
The carrying amounts of debt at September 27, 2025 and December 28, 2024 were as follows:

- changed (2026-05-06):
[0001628280-26-031041:note_history:20]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Revolving credit facility |  | $ | 200,000 |  |  | $ | 100,000 |  |
| Term loan |  | — |  |  | 266,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 109,545 |  |  | 111,977 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 483 |  |  | 1,233 |  |
| Unamortized debt issuance costs |  | (3,496) |  |  | (1,833) |  |
| Total debt |  | 631,532 |  |  | 802,627 |  |
| Less: Current maturities |  | (100,483) |  |  | (96,233) |  |
| Total long-term debt |  | $ | 531,049 |  |  | $ | 706,394 |  |
  (was, 2025-10-29, similarity 0.85):
[0001628280-25-047026:note_history:20]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 270,000 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,889 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 1,955 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,068) |  |  | (2,766) |  |
| Total debt |  | 805,776 |  |  | 856,114 |  |
| Less: Current maturities |  | (16,955) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 788,821 |  |  | $ | 788,502 |  |

- added (2026-05-06):
[0001628280-26-031041:note_history:21]
On March 12, 2026, the Company entered into an Amended and Restated Credit Agreement (the "Credit Agreement") to amend and restate and effect certain changes to its existing credit agreement, dated as of June 30, 2022 (the “Existing Credit Agreement”), including, among other changes: (i) paying off and eliminating the $300 million unsecured term loan credit facility; (ii) increasing the size of the revolving credit facility from $700 million to $800 million; and (iii) extending the maturity date to March 12, 2031 (the “Maturity Date”). As a result of entering into the Credit Agreement, the Company paid off $62.5 million of the term loan and replaced $200 million of the term loan under the Existing Credit Agreement with $200 million borrowing under the revolving credit facility under the Credit Agreement. Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

- added (2026-05-06):
[0001628280-26-031041:note_history:22]
The principal balance of the revolving credit facility is due on the Maturity Date. The revolving loan balances under the Credit Facility were $200.0 million as of March 28, 2026. Prior to entering into the Credit Agreement, the Company paid off $100.0 million of the revolving loan and $3.8 million of the term loan under the Existing Credit Agreement during the first quarter of 2026.

- changed (2026-05-06):
[0001628280-26-031041:note_history:23]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either (i) Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, based upon the Company's Consolidated Leverage Ratio, as defined in the Credit Agreement or (ii) the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.
  (was, 2025-10-29, similarity 0.9207):
[0001628280-25-047026:note_history:23]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

- added (2026-05-06):
[0001628280-26-031041:note_history:24]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty.

- changed (2026-05-06):
[0001628280-26-031041:note_history:25]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a
  (was, 2025-10-29, similarity 0.7265):
[0001628280-25-047026:note_history:25]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

- added (2026-05-06):
[0001628280-26-031041:note_history:26]
notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

- changed (2026-05-06):
[0001628280-26-031041:note_history:27]
As of March 28, 2026, the effective interest rate on the outstanding borrowings under the Credit Facility was 3.88% on the hedged portion.
  (was, 2025-10-29, similarity 0.8571):
[0001628280-25-047026:note_history:27]
As of September 27, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.26%, and 4.13% on the hedged portion.

- changed (2026-05-06):
[0001628280-26-031041:note_history:28]
As of March 28, 2026, the Company had $1.2 million outstanding letters of credit and had $598.8 million of borrowing capacity available under the revolving credit facility. As of March 28, 2026, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2025-10-29, similarity 0.9455):
[0001628280-25-047026:note_history:28]
As of September 27, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 27, 2025, the Company was in compliance with all covenants under the Credit Agreement.

- added (2026-05-06):
[0001628280-26-031041:note_history:29]
Debt Issuance Cost

- added (2026-05-06):
[0001628280-26-031041:note_history:30]
During the three months ended March 28, 2026, the Company incurred debt issuance costs of $2.2 million in connection with the newly amended and restated Credit Agreement completed on March 12, 2026 which, along with the remaining eligible balance of debt issuance costs of the previous credit facility, are being amortized over the 5 year life of the newly amended and restated Credit Agreement.

- changed (2026-05-06):
[0001628280-26-031041:note_history:31]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due 2023. Interest on the Euro Senior Notes, Series B due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.
  (was, 2025-10-29, similarity 0.939):
[0001628280-25-047026:note_history:31]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

- changed (2026-05-06):
[0001628280-26-031041:note_history:32]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due 2022. Interest on the U.S. Senior Notes, Series B due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.
  (was, 2025-10-29, similarity 0.6941):
[0001628280-25-047026:note_history:32]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

- changed (2026-05-06):
[0001628280-26-031041:note_history:33]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due 2025. Interest on the U.S. Senior Notes, Series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.
  (was, 2025-10-29, similarity 0.6295):
[0001628280-25-047026:note_history:33]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- changed (2026-05-06):
[0001628280-26-031041:note_history:34]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that
  (was, 2025-10-29, similarity 0.6012):
[0001628280-25-047026:note_history:34]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of September 27, 2025, the Company was in compliance with all covenants under the Senior Notes.

- added (2026-05-06):
[0001628280-26-031041:note_history:35]
would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of March 28, 2026, the Company was in compliance with all covenants under the Senior Notes.

- changed (2026-05-06):
[0001628280-26-031041:note_history:36]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
  (was, 2025-10-29, similarity 0.9981):
[0001628280-25-047026:note_history:36]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

- changed (2026-05-06):
[0001628280-26-031041:note_history:37]
Interest paid on all Company debt was $10.5 million and $12.2 million for the three months ended March 28, 2026 and March 29, 2025, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.
  (was, 2025-10-29, similarity 0.7269):
[0001628280-25-047026:note_history:37]
Interest paid on all Company debt was $11.1 million and $10.5 million for the three months ended September 27, 2025 and September 28, 2024, respectively, and $29.0 million and $30.1 million for the nine months ended September 27, 2025 and September 28, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.

- removed (2026-05-06):
[0001628280-25-047026:note_history:38]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

- removed (2026-05-06):
[0001628280-25-047026:note_history:39]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 27, 2025, the Company made term loan payments of $3.8 million and $11.3 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $270.0 million, respectively, as of September 27, 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:40]
The carrying amounts of debt at March 28, 2026 and December 27, 2025 were as follows:
  (was, 2025-10-29, similarity 0.9351):
[0001628280-25-047026:note_history:40]
The carrying amounts of debt at September 27, 2025 and December 28, 2024 were as follows:

- changed (2026-05-06):
[0001628280-26-031041:note_history:41]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Revolving credit facility |  | $ | 200,000 |  |  | $ | 100,000 |  |
| Term loan |  | — |  |  | 266,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 109,545 |  |  | 111,977 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 483 |  |  | 1,233 |  |
| Unamortized debt issuance costs |  | (3,496) |  |  | (1,833) |  |
| Total debt |  | 631,532 |  |  | 802,627 |  |
| Less: Current maturities |  | (100,483) |  |  | (96,233) |  |
| Total long-term debt |  | $ | 531,049 |  |  | $ | 706,394 |  |
  (was, 2025-10-29, similarity 0.85):
[0001628280-25-047026:note_history:41]
| (in thousands) |  | September 27, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 270,000 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 110,889 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 1,955 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,068) |  |  | (2,766) |  |
| Total debt |  | 805,776 |  |  | 856,114 |  |
| Less: Current maturities |  | (16,955) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 788,821 |  |  | $ | 788,502 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:42]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.
  (was, 2025-10-29, similarity 0.881):
[0001628280-25-047026:note_history:42]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

- changed (2026-05-06):
[0001628280-26-031041:note_history:43]
|  |  | Three Months Ended March 28, 2026 |  | Three Months Ended March 29, 2025 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase of material/service from related party |  | 0.5 |  | 0.1 |  | 4.2 |  |  | 0.5 |  | 0.2 |  | 1.9 |  |
|  |  | March 28, 2026 |  | December 27, 2025 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 4.2 |  |  | 0.1 |  | 0.1 |  | 2.1 |  |
  (was, 2025-10-29, similarity 0.6838):
[0001628280-25-047026:note_history:43]
|  |  | Three Months Ended September 27, 2025 |  | Three Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.1 |  | 2.4 |  |  | 0.6 |  | 0.2 |  | 0.6 |  |
|  |  | Nine Months Ended September 27, 2025 |  | Nine Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.7 |  | 0.8 |  | 5.7 |  |  | 3.0 |  | 0.6 |  | 3.5 |  |
|  |  | September 27, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.3 |  | — |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:44]
|  |  | Three Months Ended March 28, 2026 |  | Three Months Ended March 29, 2025 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase of material/service from related party |  | 0.5 |  | 0.1 |  | 4.2 |  |  | 0.5 |  | 0.2 |  | 1.9 |  |
|  |  | March 28, 2026 |  | December 27, 2025 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 4.2 |  |  | 0.1 |  | 0.1 |  | 2.1 |  |
  (was, 2025-10-29, similarity 0.6838):
[0001628280-25-047026:note_history:44]
|  |  | Three Months Ended September 27, 2025 |  | Three Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.1 |  | 2.4 |  |  | 0.6 |  | 0.2 |  | 0.6 |  |
|  |  | Nine Months Ended September 27, 2025 |  | Nine Months Ended September 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.7 |  | 0.8 |  | 5.7 |  |  | 3.0 |  | 0.6 |  | 3.5 |  |
|  |  | September 27, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.3 |  | — |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:45]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 28, 2026 and March 29, 2025:
  (was, 2025-10-29, similarity 0.8975):
[0001628280-25-047026:note_history:45]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 27, 2025 and September 28, 2024:

- added (2026-05-06):
[0001628280-26-031041:note_history:46]
|  |  | Three Months Ended March 28, 2026 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 187,123 |  |  | $ | — |  |  | $ | — |  |  | $ | 187,123 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 175,652 |  |  | $ | — |  |  | $ | — |  |  | 175,652 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 78,881 |  |  | — |  |  | 78,881 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 76,240 |  |  | — |  |  | 76,240 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,260 |  |  | — |  |  | 15,260 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 123,813 |  |  | 123,813 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 362,775 |  |  | $ | 170,381 |  |  | $ | 123,813 |  |  | $ | 656,969 |  |  |  |  |  |  |  |  |  |

- changed (2026-05-06):
[0001628280-26-031041:note_history:47]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |
  (was, 2025-10-29, similarity 0.6702):
[0001628280-25-047026:note_history:47]
|  |  | Three Months Ended September 27, 2025 |  | Nine Months Ended September 27, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 174,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 174,073 |  |  | $ | 499,329 |  |  | $ | — |  |  | $ | — |  |  | $ | 499,329 |  |
| Electronics – Passive Products and Sensors |  | 183,384 |  |  | — |  |  | — |  |  | 183,384 |  |  | 501,043 |  |  | — |  |  | — |  |  | 501,043 |  |
| Commercial Vehicle Products |  | — |  |  | 80,272 |  |  | — |  |  | 80,272 |  |  | — |  |  | 244,301 |  |  | — |  |  | 244,301 |  |
| Passenger Car Products |  | — |  |  | 75,636 |  |  | — |  |  | 75,636 |  |  | — |  |  | 220,822 |  |  | — |  |  | 220,822 |  |
| Automotive Sensors |  | — |  |  | 15,403 |  |  | — |  |  | 15,403 |  |  | — |  |  | 47,450 |  |  | — |  |  | 47,450 |  |
| Industrial Products |  | — |  |  | — |  |  | 95,872 |  |  | 95,872 |  |  | — |  |  | — |  |  | 279,415 |  |  | 279,415 |  |
| Total |  | $ | 357,457 |  |  | $ | 171,311 |  |  | $ | 95,872 |  |  | $ | 624,640 |  |  | $ | 1,000,372 |  |  | $ | 512,573 |  |  | $ | 279,415 |  |  | $ | 1,792,360 |  |

- removed (2026-05-06):
[0001628280-25-047026:note_history:48]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001628280-26-031041:note_history:49]
Some of the terms of the Company's sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a "ship and debit" program. This program allows the distributors to debit the Company for the difference between the distributors' contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to "debit" its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2025-10-29, similarity 0.8964):
[0001628280-25-047026:note_history:49]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on

- removed (2026-05-06):
[0001628280-25-047026:note_history:50]
historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2026-05-06):
[0001628280-25-047026:note_history:51]
Subsequent Events
On October 24, 2025, the Company entered into a Membership Interest Purchase Agreement with Basler Holdings, LLC, pursuant to which the Company has agreed to acquire all of the issued and outstanding membership interests of Basler Electric Company (“Basler”). The purchase price is approximately $350 million in cash, subject to certain adjustments after closing. The completion of the transaction is subject to certain customary closing conditions including regulatory approval.

- removed (2026-05-06):
[0001628280-25-047026:note_history:52]
Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. With three manufacturing facilities in Highland, IL, Taylor, TX and Piedras Negras, Mexico, Basler’s technologies regulate and protect mission-critical equipment for a broad and expanding customer base. The business will be reported in the Company's Industrial segment. The Company financed the transaction with cash on hand.
