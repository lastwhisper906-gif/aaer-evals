# LFUS notes — 0001628280-26-031041


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-26-031041:notes:1]
[same as prior period, unchanged from 0001628280-25-047026:notes:1]

[0001628280-26-031041:notes:2]
[same as prior period, unchanged from 0001628280-25-047026:notes:2]

[0001628280-26-031041:notes:3]
Founded in 1927, Littelfuse, Inc. ("Littelfuse" or the "Company") is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0001628280-26-031041:notes:4]
[same as prior period, unchanged from 0001628280-25-047026:notes:4]

[0001628280-26-031041:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of operations and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 27, 2025, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0001628280-26-031041:notes:6]
[same as prior period, unchanged from 0001628280-25-047026:notes:6]

[0001628280-26-031041:notes:7]
[same as prior period, unchanged from 0001628280-25-047026:notes:7]

[0001628280-26-031041:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 28, 2026 and March 29, 2025:

[0001628280-26-031041:notes:9]
|  |  | Three Months Ended March 28, 2026 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 187,123 |  |  | $ | — |  |  | $ | — |  |  | $ | 187,123 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 175,652 |  |  | $ | — |  |  | $ | — |  |  | 175,652 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 78,881 |  |  | — |  |  | 78,881 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 76,240 |  |  | — |  |  | 76,240 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,260 |  |  | — |  |  | 15,260 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 123,813 |  |  | 123,813 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 362,775 |  |  | $ | 170,381 |  |  | $ | 123,813 |  |  | $ | 656,969 |  |  |  |  |  |  |  |  |  |

[0001628280-26-031041:notes:10]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |

[0001628280-26-031041:notes:11]
[same as prior period, unchanged from 0001628280-25-047026:notes:11]

[0001628280-26-031041:notes:12]
[same as prior period, unchanged from 0001628280-25-047026:notes:12]

[0001628280-26-031041:notes:13]
[same as prior period, unchanged from 0001628280-25-047026:notes:13]

[0001628280-26-031041:notes:14]
[same as prior period, unchanged from 0001628280-25-047026:notes:14]

[0001628280-26-031041:notes:15]
[same as prior period, unchanged from 0001628280-25-047026:notes:15]

[0001628280-26-031041:notes:16]
[same as prior period, unchanged from 0001628280-25-047026:notes:16]

[0001628280-26-031041:notes:17]
Some of the terms of the Company's sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a "ship and debit" program. This program allows the distributors to debit the Company for the difference between the distributors' contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to "debit" its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001628280-26-031041:notes:18]
[same as prior period, unchanged from 0001628280-25-047026:notes:19]

[0001628280-26-031041:notes:19]
[same as prior period, unchanged from 0001628280-25-047026:notes:20]

[0001628280-26-031041:notes:20]
[same as prior period, unchanged from 0001628280-25-047026:notes:21]

[0001628280-26-031041:notes:21]
[same as prior period, unchanged from 0001628280-25-047026:notes:22]

[0001628280-26-031041:notes:22]
[same as prior period, unchanged from 0001628280-25-047026:notes:23]

[0001628280-26-031041:notes:23]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 28, 2026 and December 27, 2025 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0001628280-26-031041:notes:24]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Cash and cash equivalents |  | $ | 481,697 |  |  | $ | 563,391 |  |
| Restricted cash included in other long-term assets |  | 1,676 |  |  | 1,713 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 483,373 |  |  | $ | 565,104 |  |

[0001628280-26-031041:notes:25]
Recently Adopted Accounting Standards

[0001628280-26-031041:notes:26]
In September 2025, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2025-05, "Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets." The amendments in this update provide entities with a practical expedient when estimating expected credit losses for current accounts receivable and current contract assets arising from transactions accounted for under Topic 606. In developing reasonable and supportable forecasts as part of estimating expected credit losses, the practical expedient allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset. The guidance is effective for fiscal years beginning after December 15, 2025 with early adoption permitted. The adoption of ASU 2025-05 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

[0001628280-26-031041:notes:27]
Recently Issued Accounting Standards

[0001628280-26-031041:notes:28]
In September 2025, the FASB issued ASU No. 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software." The amendments in this update require the entity to start capitalizing software costs when both of the following criteria are met: (1) management has authorized and committed to funding the software project, and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the "probable-to-complete recognition threshold"). The amendments clarify that the intangibles disclosures are not required for capitalized internal-use software costs. Additionally, the amendments in this update supersede the website development costs guidance and incorporate the recognition requirements for website-specific development costs. The guidance is effective for fiscal years beginning after December 15, 2027 with early adoption permitted. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

[0001628280-26-031041:notes:29]
In November 2024, the FASB issued ASU No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements; (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively; (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Condensed Consolidated Financial Statements.

[0001628280-26-031041:notes:30]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-26-031041:notes:31]
[same as prior period, unchanged from 0001628280-25-047026:notes:33]

[0001628280-26-031041:notes:32]
[same as prior period, unchanged from 0001628280-25-047026:notes:34]

[0001628280-26-031041:notes:33]
Basler Electric

[0001628280-26-031041:notes:34]
On December 11, 2025, the Company completed the acquisition of Basler Electric Company ("Basler"). Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. At the time of acquisition, Basler had annualized sales of approximately $130 million. The business is reported within the Company’s Industrial segment. The purchase price for Basler was $361.7 million and is subject to a working capital adjustment.

[0001628280-26-031041:notes:35]
The Company financed the transaction with cash on hand. The total purchase consideration of $352.8 million, net of cash acquired, has been allocated, on a preliminary basis, based on estimated fair values of assets acquired and liabilities assumed. The purchase price allocation is preliminary because the determination of the fair value of the net assets acquired, including the third-party valuation of acquired tangible assets, is not yet finalized. Thus, the preliminary measurements of fair value set forth in the table below are subject to change during the measurement period as valuations are finalized. The Company expects to finalize the valuation and complete the purchase price allocation as soon as practicable.

[0001628280-26-031041:notes:36]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Basler acquisition:

[0001628280-26-031041:notes:37]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 352,809 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 14,739 |  |
| Inventories | 20,703 |  |
| Other current assets | 4,152 |  |
| Property, plant, and equipment | 21,532 |  |
| Intangible assets | 145,000 |  |
| Goodwill | 160,977 |  |
| Other long-term assets | 4,146 |  |
| Current liabilities | (15,690) |  |
| Other long-term liabilities | (2,750) |  |
|  | $ | 352,809 |  |

[0001628280-26-031041:notes:38]
All Basler assets and liabilities were recorded in the Industrial segment and are primarily reflected in the North America geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Basler’s products and technology with the Company’s existing Industrial products portfolio. Goodwill resulting from the Basler acquisition is expected to be deductible for tax purposes.

[0001628280-26-031041:notes:39]
During the three months ended March 28, 2026, the Company made adjustments to reduce the fair value of intangible assets of $5.0 million, current liabilities of $3.2 million, inventories of $2.6 million, trade receivables of $2.1 million, property, plant, and equipment of $1.7 million, other long-term assets of $1.6 million, and increase in other current assets of $1.2 million. As a result of these adjustments, goodwill was increased by $8.6 million. The Company paid $2.5 million of indebtedness as part of the purchase consideration during the three months ended March 28, 2026.

[0001628280-26-031041:notes:40]
As required by purchase accounting guidance, the Company recorded a $6.4 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up is being amortized as a non-cash charge to cost of goods sold during the fourth quarter of 2025 and first quarter of 2026, as the acquired inventory is sold, and reflected as other non-segment costs. The Company recognized a non-cash charge of $5.4 million to cost of goods sold during the three months ended March 28, 2026. There is no future remaining amortization of this step-up of inventory as of March 28, 2026.

[0001628280-26-031041:notes:41]
For the three months ended March 28, 2026, the Company recorded $0.5 million legal and professional fees related to the Basler acquisition recognized as Selling, general, and administrative expenses and reflected as other non-segment costs. A total of $3.0 million of legal and professional fees related to the Basler acquisition was recognized since 2025. These costs were reflected as other non-segment costs.

[0001628280-26-031041:notes:42]
[same as prior period, unchanged from 0001628280-25-047026:notes:35]

[0001628280-26-031041:notes:43]
[same as prior period, unchanged from 0001628280-25-047026:notes:36]

[0001628280-26-031041:notes:44]
[same as prior period, unchanged from 0001628280-25-047026:notes:37]

[0001628280-26-031041:notes:45]
[same as prior period, unchanged from 0001628280-25-047026:notes:38]

[0001628280-26-031041:notes:46]
[same as prior period, unchanged from 0001628280-25-047026:notes:39]

[0001628280-26-031041:notes:47]
[same as prior period, unchanged from 0001628280-25-047026:notes:40]

[0001628280-26-031041:notes:48]
[same as prior period, unchanged from 0001628280-25-047026:notes:44]

[0001628280-26-031041:notes:49]
During the three months ended March 29, 2025, the Company did not incur any legal and professional fees related to the Dortmund Fab acquisition recognized as Selling, general, and administrative expenses in the Condensed Consolidated Statements of Operations. A total of $3.5 million of legal and professional fees related to the Dortmund Fab acquisition was recognized since 2023. These costs were reflected as other non-segment costs.

[0001628280-26-031041:notes:50]
[same as prior period, unchanged from 0001628280-25-047026:notes:46]

[0001628280-26-031041:notes:51]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company, Basler and Dortmund Fab as though the acquisitions had occurred as of December 31, 2023. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Basler and Dortmund Fab acquisitions occurred as of December 31, 2023, or of future consolidated operating results.

[0001628280-26-031041:notes:52]
|  |  | For the Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Net sales |  | $ | 656,969 |  |  | $ | 587,520 |  |  |  |  |  |
| Income before income taxes |  | 102,559 |  |  | 61,376 |  |  |  |  |  |
| Net income |  | 79,576 |  |  | 44,278 |  |  |  |  |  |
| Net income per share — basic |  | 3.17 |  | 1.79 |  |  |  |  |  |
| Net income per share — diluted |  | 3.13 |  | 1.77 |  |  |  |  |  |

[0001628280-26-031041:notes:53]
[same as prior period, unchanged from 0001628280-25-047026:notes:49]

[0001628280-26-031041:notes:54]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Amortization (a) |  | $ | — |  |  | $ | (2,583) |  |  |  |  |  |
| Depreciation |  | — |  |  | (245) |  |  |  |  |  |
| Amortization of inventory adjustments (b) |  | 5,333 |  |  | (504) |  |  |  |  |  |
| Transaction costs (c) |  | 495 |  |  | (37) |  |  |  |  |  |
| Income tax (expense) benefit of above items |  | (1,399) |  |  | 841 |  |  |  |  |  |
| Total |  | $ | 4,429 |  |  | $ | (2,528) |  |  |  |  |  |

[0001628280-26-031041:notes:55]
(a) The amortization adjustment for the three months ended March 29, 2025, primarily reflects amortization resulting from the measurement of intangibles at their fair values.

[0001628280-26-031041:notes:56]
(b) The amortization of inventory adjustments reflects the reversal of the amount recognized during the three months ended March 28, 2026 and March 29, 2025. The inventory adjustment related to the Basler acquisition is being amortized over three months as the inventory is sold. The inventory adjustment related to the Dortmund Fab acquisition was fully amortized over two months as the inventory was sold during 2025.

[0001628280-26-031041:notes:57]
(c) The transaction costs adjustment reflects the reversal of certain legal and professional fees related to the Basler and Dortmund acquisitions for the three months ended March 28, 2026 and March 29, 2025, respectively


## us-gaap:InventoryDisclosureTextBlock

[0001628280-26-031041:notes:58]
[same as prior period, unchanged from 0001628280-25-047026:notes:55]

[0001628280-26-031041:notes:59]
The components of inventories at March 28, 2026 and December 27, 2025 were as follows:

[0001628280-26-031041:notes:60]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Raw materials |  | $ | 192,058 |  |  | $ | 186,662 |  |
| Work in process |  | 133,686 |  |  | 131,129 |  |
| Finished goods |  | 176,771 |  |  | 181,376 |  |
| Inventory reserves |  | (83,593) |  |  | (82,695) |  |
| Total |  | $ | 418,922 |  |  | $ | 416,472 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-26-031041:notes:61]
[same as prior period, unchanged from 0001628280-25-047026:notes:58]

[0001628280-26-031041:notes:62]
The components of net property, plant, and equipment at March 28, 2026 and December 27, 2025 were as follows:

[0001628280-26-031041:notes:63]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Land and land improvements |  | $ | 23,057 |  |  | $ | 24,088 |  |
| Building and building improvements |  | 215,640 |  |  | 215,024 |  |
| Machinery and equipment |  | 999,855 |  |  | 998,988 |  |
| Accumulated depreciation and amortization |  | (705,024) |  |  | (697,460) |  |
| Total |  | $ | 533,528 |  |  | $ | 540,640 |  |

[0001628280-26-031041:notes:64]
The Company recorded depreciation expense of $19.0 million and $18.4 million for the three months ended March 28, 2026 and March 29, 2025, respectively, in Cost of sales, Selling, general, and administrative expenses, and Research and development expenses in the Condensed Consolidated Statements of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-26-031041:notes:65]
[same as prior period, unchanged from 0001628280-25-047026:notes:62]

[0001628280-26-031041:notes:66]
The amounts for goodwill and changes in the carrying value by segment for the three months ended March 28, 2026 were as follows:

[0001628280-26-031041:notes:67]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net goodwill as of December 27, 2025 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 27, 2025 |  | $ | 1,027,462 |  |  | $ | 242,192 |  |  | $ | 338,739 |  |  | $ | 1,608,393 |  |
| Accumulated impairment losses as of December 27, 2025 |  | (303,133) |  |  | (44,793) |  |  | (49,056) |  |  | (396,982) |  |
| Total |  | 724,329 |  |  | 197,399 |  |  | 289,683 |  |  | 1,211,411 |  |
| Changes during 2026: |  |  |  |  |  |  |  |  |
| Adjustments (a) |  | — |  |  | — |  |  | 8,634 |  |  | 8,634 |  |
| Foreign currency translation adjustments |  | (7,987) |  |  | (916) |  |  | (1,350) |  |  | (10,253) |  |
| Net goodwill as of March 28, 2026 |  |  |  |  |  |  |  |  |
| Gross goodwill as of March 28, 2026 |  | 1,015,516 |  |  | 240,953 |  |  | 345,030 |  |  | 1,601,499 |  |
| Accumulated impairment losses as of March 28, 2026 |  | (299,174) |  |  | (44,470) |  |  | (48,063) |  |  | (391,707) |  |
| Total |  | $ | 716,342 |  |  | $ | 196,483 |  |  | $ | 296,967 |  |  | $ | 1,209,792 |  |

[0001628280-26-031041:notes:68]
(a) The adjustments were related to the acquisition of Basler.

[0001628280-26-031041:notes:69]
The components of intangible assets as of March 28, 2026 and December 27, 2025 were as follows:

[0001628280-26-031041:notes:70]
|  |  |  | As of March 28, 2026 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 16,838 |  |  | $ | 3,783 |  |  | $ | 13,055 |  |
| Patents, licenses, and software |  |  | 288,347 |  |  | 214,771 |  |  | 73,576 |  |
| Distribution network |  |  | 42,246 |  |  | 42,246 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 783,688 |  |  | 300,294 |  |  | 483,394 |  |
| Total |  |  | $ | 1,131,119 |  |  | $ | 561,094 |  |  | $ | 570,025 |  |

[0001628280-26-031041:notes:71]
|  | As of December 27, 2025 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 16,661 |  |  | $ | 3,613 |  |  | $ | 13,048 |  |
| Patents, licenses, and software | 291,192 |  |  | 212,184 |  |  | 79,008 |  |
| Distribution network | 42,384 |  |  | 42,384 |  |  | — |  |
| Customer relationships, trademarks, and tradenames | 793,670 |  |  | 290,819 |  |  | 502,851 |  |
| Total | $ | 1,143,907 |  |  | $ | 549,000 |  |  | $ | 594,907 |  |

[0001628280-26-031041:notes:72]
The intangible assets of $145.0 million acquired from the Basler acquisition, the components of which were as follows:

[0001628280-26-031041:notes:73]
|  | 2026 |
| (in thousands, except weighted average useful life) | Weighted AverageUseful Life (Years) |  | Amount |
| Basler |  |  |  |
| Patents, developed technology | 5 |  | $ | 15,000 |  |
| Customer relationships, trademarks, and tradenames | 14.5 |  | 130,000 |  |
| Total |  |  | $ | 145,000 |  |

[0001628280-26-031041:notes:74]
During the three months ended March 28, 2026 and March 29, 2025, the Company recorded amortization expense of $16.5 million and $14.3 million, respectively.

[0001628280-26-031041:notes:75]
Estimated annual amortization expense related to intangible assets with definite lives as of March 28, 2026 was as follows:

[0001628280-26-031041:notes:76]
| (in thousands) | Amount |
| Remainder of 2026 | $ | 43,947 |  |
| 2027 | 58,361 |  |
| 2028 | 57,960 |  |
| 2029 | 57,549 |  |
| 2030 | 54,090 |  |
| 2031 and thereafter | 298,118 |  |
| Total | $ | 570,025 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-26-031041:notes:77]
[same as prior period, unchanged from 0001628280-25-047026:notes:74]

[0001628280-26-031041:notes:78]
The components of accrued liabilities as of March 28, 2026 and December 27, 2025 were as follows:

[0001628280-26-031041:notes:79]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Employee-related liabilities |  | $ | 89,161 |  |  | $ | 114,662 |  |
| Current lease liability |  | 11,272 |  |  | 11,435 |  |
| Other non-income taxes |  | 10,688 |  |  | 7,960 |  |
| Restructuring liability |  | 7,148 |  |  | 6,014 |  |
| Deferred revenue |  | 6,713 |  |  | 11,215 |  |
| Professional services |  | 5,590 |  |  | 6,629 |  |
| Interest |  | 3,129 |  |  | 7,069 |  |
| Other customer reserves |  | 2,394 |  |  | 2,874 |  |
| Current benefit liability |  | 1,680 |  |  | 1,680 |  |
| Other |  | 33,012 |  |  | 29,733 |  |
| Total |  | $ | 170,787 |  |  | $ | 199,271 |  |

[0001628280-26-031041:notes:80]
[same as prior period, unchanged from 0001628280-25-047026:notes:77]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001628280-26-031041:notes:81]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three months ended March 28, 2026 and March 29, 2025 as follows:

[0001628280-26-031041:notes:82]
|  | Three Months Ended March 28, 2026 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 4,827 |  |  | $ | 2,041 |  |  | $ | 372 |  |  | $ | 7,240 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 178 |  |  | 4 |  |  | — |  |  | 182 |  |  |  |  |  |  |  |  |  |
| Total | $ | 5,005 |  |  | $ | 2,045 |  |  | $ | 372 |  |  | $ | 7,422 |  |  |  |  |  |  |  |  |  |

[0001628280-26-031041:notes:83]
|  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 4,804 |  |  | $ | 3,132 |  |  | $ | 412 |  |  | $ | 8,348 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 511 |  |  | 23 |  |  | 1 |  |  | 535 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 5,315 |  |  | 3,155 |  |  | 413 |  |  | 8,883 |  |  |  |  |  |  |  |  |  |
| Impairment | 136 |  |  | — |  |  | — |  |  | 136 |  |  |  |  |  |  |  |  |  |
| Total | $ | 5,451 |  |  | $ | 3,155 |  |  | $ | 413 |  |  | $ | 9,019 |  |  |  |  |  |  |  |  |  |

[0001628280-26-031041:notes:84]
2026

[0001628280-26-031041:notes:85]
For the three months ended March 28, 2026, the Company recorded total restructuring charges of $7.4 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions for the semiconductor business within the Electronics segment and the reorganization of certain manufacturing, selling and administrative functions for the commercial vehicle business within the Transportation segment.

[0001628280-26-031041:notes:86]
[same as prior period, unchanged from 0001628280-25-047026:notes:81]

[0001628280-26-031041:notes:87]
For the three months ended March 29, 2025, the Company recorded total restructuring charges of $8.9 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and corporate support functions for the semiconductor business within the Electronics segment, and across all businesses within the Transportation segment. In addition, during the first fiscal quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment.

[0001628280-26-031041:notes:88]
The restructuring reserves as of March 28, 2026 and December 27, 2025 were $7.1 million and $6.0 million, respectively, included within Accrued liabilities. Additionally, $0.2 million and $0.3 million were included within Other long-term liabilities in the Condensed Consolidated Balance Sheets as of March 28, 2026 and December 27, 2025, respectively. The Company anticipates the remaining payments associated with employee terminations will primarily be completed during fiscal year 2026.


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-031041:notes:89]
Debt

[0001628280-26-031041:notes:90]
The carrying amounts of debt at March 28, 2026 and December 27, 2025 were as follows:

[0001628280-26-031041:notes:91]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Revolving credit facility |  | $ | 200,000 |  |  | $ | 100,000 |  |
| Term loan |  | — |  |  | 266,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 109,545 |  |  | 111,977 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 483 |  |  | 1,233 |  |
| Unamortized debt issuance costs |  | (3,496) |  |  | (1,833) |  |
| Total debt |  | 631,532 |  |  | 802,627 |  |
| Less: Current maturities |  | (100,483) |  |  | (96,233) |  |
| Total long-term debt |  | $ | 531,049 |  |  | $ | 706,394 |  |

[0001628280-26-031041:notes:92]
Revolving Credit Facility and Term Loan

[0001628280-26-031041:notes:93]
On March 12, 2026, the Company entered into an Amended and Restated Credit Agreement (the "Credit Agreement") to amend and restate and effect certain changes to its existing credit agreement, dated as of June 30, 2022 (the “Existing Credit Agreement”), including, among other changes: (i) paying off and eliminating the $300 million unsecured term loan credit facility; (ii) increasing the size of the revolving credit facility from $700 million to $800 million; and (iii) extending the maturity date to March 12, 2031 (the “Maturity Date”). As a result of entering into the Credit Agreement, the Company paid off $62.5 million of the term loan and replaced $200 million of the term loan under the Existing Credit Agreement with $200 million borrowing under the revolving credit facility under the Credit Agreement. Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-26-031041:notes:94]
The principal balance of the revolving credit facility is due on the Maturity Date. The revolving loan balances under the Credit Facility were $200.0 million as of March 28, 2026. Prior to entering into the Credit Agreement, the Company paid off $100.0 million of the revolving loan and $3.8 million of the term loan under the Existing Credit Agreement during the first quarter of 2026.

[0001628280-26-031041:notes:95]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either (i) Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, based upon the Company's Consolidated Leverage Ratio, as defined in the Credit Agreement or (ii) the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-26-031041:notes:96]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty.

[0001628280-26-031041:notes:97]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a

[0001628280-26-031041:notes:98]
notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0001628280-26-031041:notes:99]
As of March 28, 2026, the effective interest rate on the outstanding borrowings under the Credit Facility was 3.88% on the hedged portion.

[0001628280-26-031041:notes:100]
As of March 28, 2026, the Company had $1.2 million outstanding letters of credit and had $598.8 million of borrowing capacity available under the revolving credit facility. As of March 28, 2026, the Company was in compliance with all covenants under the Credit Agreement.

[0001628280-26-031041:notes:101]
Debt Issuance Cost

[0001628280-26-031041:notes:102]
During the three months ended March 28, 2026, the Company incurred debt issuance costs of $2.2 million in connection with the newly amended and restated Credit Agreement completed on March 12, 2026 which, along with the remaining eligible balance of debt issuance costs of the previous credit facility, are being amortized over the 5 year life of the newly amended and restated Credit Agreement.

[0001628280-26-031041:notes:103]
Senior Notes

[0001628280-26-031041:notes:104]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due 2023. Interest on the Euro Senior Notes, Series B due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-26-031041:notes:105]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due 2022. Interest on the U.S. Senior Notes, Series B due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-26-031041:notes:106]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due 2025. Interest on the U.S. Senior Notes, Series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0001628280-26-031041:notes:107]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-26-031041:notes:108]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-26-031041:notes:109]
The Senior Notes have not been registered under the Securities Act of 1933 ("Securities Act"), or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001628280-26-031041:notes:110]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that

[0001628280-26-031041:notes:111]
would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of March 28, 2026, the Company was in compliance with all covenants under the Senior Notes.

[0001628280-26-031041:notes:112]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001628280-26-031041:notes:113]
Interest paid on all Company debt was $10.5 million and $12.2 million for the three months ended March 28, 2026 and March 29, 2025, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-031041:notes:114]
[same as prior period, unchanged from 0001628280-25-047026:notes:106]

[0001628280-26-031041:notes:115]
[same as prior period, unchanged from 0001628280-25-047026:notes:107]

[0001628280-26-031041:notes:116]
[same as prior period, unchanged from 0001628280-25-047026:notes:108]

[0001628280-26-031041:notes:117]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable or can be corroborated by observable market data;

[0001628280-26-031041:notes:118]
[same as prior period, unchanged from 0001628280-25-047026:notes:110]

[0001628280-26-031041:notes:119]
[same as prior period, unchanged from 0001628280-25-047026:notes:111]

[0001628280-26-031041:notes:120]
[same as prior period, unchanged from 0001628280-25-047026:notes:112]

[0001628280-26-031041:notes:121]
[same as prior period, unchanged from 0001628280-25-047026:notes:113]

[0001628280-26-031041:notes:122]
Cash equivalents primarily consist of money market funds, certificates of deposit, and short-term time deposits, which are held with institutions with sound credit ratings and are highly liquid. The Company classified cash equivalents as Level 1 and were valued at cost, which approximates fair value.

[0001628280-26-031041:notes:123]
[same as prior period, unchanged from 0001628280-25-047026:notes:115]

[0001628280-26-031041:notes:124]
[same as prior period, unchanged from 0001628280-25-047026:notes:116]

[0001628280-26-031041:notes:125]
[same as prior period, unchanged from 0001628280-25-047026:notes:117]

[0001628280-26-031041:notes:126]
For derivatives that will be accounted for as hedging instruments, the Company formally designates and documents, at inception, the financial instrument as a hedge of a specific underlying exposure, the risk management objective, and the strategy for undertaking the hedge transaction. In addition, the Company formally assesses, both at the inception and at least quarterly thereafter, whether the financial instruments used in hedging transactions are effective at offsetting changes in either the fair values or cash flows of the related underlying exposures. For highly effective cash flow hedges, ASC 815 requires the entire change in fair value of the hedging instrument included in the assessment of hedge effectiveness to be recorded in other comprehensive income. No amount of ineffectiveness was recognized for the three months ended March 28, 2026. The Company continues to assess the effectiveness of the hedges on an ongoing basis. The Company does not enter into derivative financial instruments for trading purposes.

[0001628280-26-031041:notes:127]
Cross-Currency Swap Agreement

[0001628280-26-031041:notes:128]
In February 2026, the Company entered into a fixed-to-fixed cross currency swaps to mitigate foreign currency risk exposure related to fluctuations between the Euro and the U.S. dollar. These instruments were designated as net investment hedges to offset the impact of EUR-USD exchange rate volatility associated with the Company's net investments in certain foreign entities. The fair value of the cross-currency swaps was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as net investment hedges are deferred in the foreign currency translation adjustment within accumulated other comprehensive loss. Gains or losses deferred in accumulated other comprehensive loss are reclassified into earnings at the time the underlying hedged net investment is disposed of or substantially liquidated. The Company applied cross-currency swap net investment hedge designation under spot method. Under this method, the Company is allowed to recognize interest income from the spot‑forward differential on a straight‑line basis over the term of the swap agreement, and the spot‑forward differential is excluded from the assessment of hedge effectiveness. For the three months ended March 28, 2026, the Company recorded a pre-tax unrealized gain on the cross-currency swaps of $2.3 million. The primary inputs into the valuation of the cross-currency swaps are interest rate yield curves, foreign exchange rates, cross-currency basis spreads, credit spreads and other market information. The cross-currency swaps are classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by observable market data. As of March 28, 2026, the Company had outstanding cross-currency swap agreements designated as net investment hedges with an aggregate notional value of €84.7 million on the pay leg and $100.0 million on the receive leg.

[0001628280-26-031041:notes:129]
[same as prior period, unchanged from 0001628280-25-047026:notes:119]

[0001628280-26-031041:notes:130]
[same as prior period, unchanged from 0001628280-25-047026:notes:120]

[0001628280-26-031041:notes:131]
| Trade Entry Date | Trade Maturity Date | Weighted-Average Floor | Weighted-Average Ceiling |
| July 3, 2024 | August 29, 2025 | 18.0000 | 19.4350 |
| August 5, 2024 | September 29, 2025 | 19.6550 | 21.0000 |
| September 3, 2024 | November 3, 2025 | 20.0820 | 21.7571 |
| September 30, 2024 | November 26, 2025 | 19.8700 | 21.3650 |
| November 4, 2024 | January 2, 2026 | 20.1200 | 21.6900 |
| December 3, 2024 | February 2, 2026 | 20.4250 | 22.0377 |
| January 2, 2025 | March 2, 2026 | 20.8000 | 21.9082 |
| February 6, 2025 | March 30, 2026 | 20.5300 | 22.0000 |
| April 9, 2025 | June 1, 2026 | 20.9700 | 22.2355 |
| May 1, 2025 | June 29, 2026 | 19.6940 | 20.9700 |
| June 4, 2025 | August 3, 2026 | 19.3100 | 20.3437 |
| July 2, 2025 | August 31, 2026 | 18.8500 | 19.8025 |
| August 5, 2025 | September 29, 2026 | 18.8500 | 19.8000 |
| September 2, 2025 | November 2, 2026 | 18.8100 | 19.8347 |
| September 30, 2025 | November 30, 2026 | 18.4200 | 19.3700 |
| November 4, 2025 | January 4, 2027 | 18.7200 | 19.7000 |
| November 26, 2025 | February 2, 2027 | 18.4300 | 19.4852 |
| January 6, 2026 | March 1, 2027 | 18.0620 | 18.9250 |
| February 4, 2026 | April 5, 2027 | 17.4175 | 18.2500 |
| March 4, 2026 | May 3, 2027 | 17.6720 | 18.4060 |

[0001628280-26-031041:notes:132]
The fair value of the collars was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three months ended March 28, 2026, the Company recorded pre-tax unrealized losses on the collars of $4.0 million. As of March 28, 2026, the Company estimates that approximately $3.2 million of pre-tax gains recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The amounts included in accumulated other comprehensive income will be reclassified to earnings should the hedge no longer be considered effective. No amount of ineffectiveness was included in net income for the three months ended March 28, 2026. The Company will continue to assess the effectiveness of the hedge on an ongoing basis. The primary inputs into the valuation of the collars are interest yield curves, interest rate volatilities, foreign exchange rates, foreign exchange volatilities, credit risk, credit spreads and other market information. The collars are classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0001628280-26-031041:notes:133]
[same as prior period, unchanged from 0001628280-25-047026:notes:123]

[0001628280-26-031041:notes:134]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three months ended March 28, 2026, the Company recorded a pre-tax unrealized gain on the interest rate swap of $0.8 million. As of March 28, 2026, the Company estimates that approximately $1.9 million of pre-tax gains recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by observable market data.

[0001628280-26-031041:notes:135]
[same as prior period, unchanged from 0001628280-25-047026:notes:126]

[0001628280-26-031041:notes:136]
As of March 28, 2026 and December 27, 2025, the fair values of the Company's derivative financial instruments and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0001628280-26-031041:notes:137]
| (in thousands) | Condensed Consolidated Balance Sheets Classification |  | March 28, 2026 |  | December 27, 2025 |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 1,714 |  |  | $ | 1,162 |  |  |  |
|  | Other long-term assets |  | 618 |  |  | 382 |  |  |  |
| Zero cost collar agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 3,602 |  |  | $ | 6,816 |  |  |  |
|  | Other long-term assets |  | — |  |  | 3 |  |  |  |
|  | Accrued liabilities |  | 777 |  |  | — |  |  |  |
|  | Other long-term liabilities |  | 16 |  |  | — |  |  |  |
| Cross-currency swap agreement: |  |  |  |  |  |  |  |
| Designated as net investment hedge | Prepaid expenses and other current assets |  | $ | 757 |  |  | $ | — |  |  |  |
|  | Other long-term assets |  | 1,518 |  |  | — |  |  |  |

[0001628280-26-031041:notes:138]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Operations for the three months ended March 28, 2026 and March 29, 2025 were as follows:

[0001628280-26-031041:notes:139]
|  |  |  |  | Three Months Ended |  |  |
| (in thousands) |  | Classification of (Gains) Losses Recognized in the Condensed Consolidated Statements of Operations |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (464) |  |  | $ | (788) |  |  |  |  |  |
| Zero cost collar agreement |  | Cost of sales |  | (4,078) |  |  | 1,480 |  |  |  |  |  |
| Zero cost collar agreement |  | Selling, general, and administrative expenses |  | (336) |  |  | 121 |  |  |  |  |  |
| Derivatives designated as net investment hedges |  |  |  |  |  |  |  |  |  |  |
| Cross-currency swap agreement |  | Interest expense |  | $ | (97) |  |  | $ | — |  |  |  |  |  |

[0001628280-26-031041:notes:140]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three months ended March 28, 2026 and March 29, 2025 were as follows:

[0001628280-26-031041:notes:141]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | (788) |  |  | $ | 2,318 |  |  |  |  |  |
| Zero cost collar agreement |  | 4,031 |  |  | (2,442) |  |  |  |  |  |
| Derivatives designated as net investment hedges |  |  |  |  |  |  |  |  |
| Cross-currency swap agreement |  | $ | (2,275) |  |  | $ | — |  |  |  |  |  |

[0001628280-26-031041:notes:142]
[same as prior period, unchanged from 0001628280-25-047026:notes:134]

[0001628280-26-031041:notes:143]
[same as prior period, unchanged from 0001628280-25-047026:notes:135]

[0001628280-26-031041:notes:144]
There were no changes during the quarter ended March 28, 2026 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of March 28, 2026 and December 27, 2025, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001628280-26-031041:notes:145]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of March 28, 2026:

[0001628280-26-031041:notes:146]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 430,054 |  |  | $ | — |  |  | $ | — |  |  | $ | 430,054 |  |
| Investments in equity securities |  | 7,396 |  |  | — |  |  | — |  |  | 7,396 |  |
| Mutual funds |  | 26,150 |  |  | — |  |  | — |  |  | 26,150 |  |
| Total |  | $ | 463,600 |  |  | $ | — |  |  | $ | — |  |  | $ | 463,600 |  |

[0001628280-26-031041:notes:147]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 27, 2025:

[0001628280-26-031041:notes:148]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 465,915 |  |  | $ | — |  |  | $ | — |  |  | $ | 465,915 |  |
| Investments in equity securities |  | 7,676 |  |  | — |  |  | — |  |  | 7,676 |  |
| Mutual funds |  | 25,730 |  |  | — |  |  | — |  |  | 25,730 |  |
| Total |  | $ | 499,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 499,321 |  |

[0001628280-26-031041:notes:149]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, trade receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and trade receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at March 28, 2026 and December 27, 2025, as the rates on these borrowings are variable in nature. The purchase price of business acquisitions is primarily allocated to the tangible and identifiable intangible assets acquired and liabilities assumed based on their estimated fair values on the acquisition date, with the excess recorded as goodwill. The Company utilizes Level 3 inputs in the determination of the initial fair value for certain assets acquired and liabilities assumed in business acquisitions.

[0001628280-26-031041:notes:150]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series B and USD Senior Notes, Series B, as of March 28, 2026 and December 27, 2025 were as follows:

[0001628280-26-031041:notes:151]
|  |  | March 28, 2026 |  | December 27, 2025 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 |  | $ | 109,545 |  |  | $ | 103,634 |  |  | $ | 111,977 |  |  | $ | 106,908 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 99,132 |  |  | 100,000 |  |  | 99,152 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 119,169 |  |  | 125,000 |  |  | 120,076 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 94,340 |  |  | 100,000 |  |  | 95,587 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-26-031041:notes:152]
[same as prior period, unchanged from 0001628280-25-047026:notes:144]

[0001628280-26-031041:notes:153]
The Company has Company-sponsored and mandatory defined benefit pension plans covering employees in the United Kingdom ("U.K."), Germany, the Philippines, China, Japan, Mexico, Italy, and France. The amount of the retirement benefits provided under the plans is generally based on years of service and final average pay.

[0001628280-26-031041:notes:154]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Operations. The components of net periodic benefit cost for the three months ended March 28, 2026 and March 29, 2025 were as follows:

[0001628280-26-031041:notes:155]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 945 |  |  | $ | 727 |  |  |  |  |  |
| Interest cost |  | 1,224 |  |  | 954 |  |  |  |  |  |
| Expected return on plan assets |  | (481) |  |  | (459) |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | 116 |  |  | 69 |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 1,804 |  |  | $ | 1,291 |  |  |  |  |  |

[0001628280-26-031041:notes:156]
The Company expects to make approximately $1.5 million of contributions to the plans and pay $2.3 million of benefits directly in 2026.

[0001628280-26-031041:notes:157]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $25 million, representing approximately 31% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in the third quarter of 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0001628280-26-031041:notes:158]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.8 million and $0.7 million for the three months ended March 28, 2026 and March 29, 2025, respectively, in Cost of sales and Other income, net within the Condensed Consolidated Statements of Operations. The pre-tax losses recognized in other comprehensive income (loss) for these plans were $0.3 million and $0.4 million for the three months ended March 28, 2026 and March 29, 2025, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-26-031041:notes:159]
[same as prior period, unchanged from 0001628280-25-047026:notes:151]

[0001628280-26-031041:notes:160]
| (in thousands) |  | Three Months EndedMarch 28, 2026 |  | Three Months EndedMarch 29, 2025 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 511 |  |  | $ | 5 |  |  | $ | 516 |  |  | $ | 227 |  |  | $ | (8) |  |  | $ | 219 |  |
| Cash flow hedges |  | (3,243) |  |  | (1) |  |  | (3,244) |  |  | 124 |  |  | 464 |  |  | 588 |  |
| Foreign currency translation adjustments-Net investment hedge |  | 2,275 |  |  | (523) |  |  | 1,752 |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustments (a) |  | (18,663) |  |  | 465 |  |  | (18,198) |  |  | 37,668 |  |  | (878) |  |  | 36,790 |  |
| Total foreign currency translation adjustments |  | (16,388) |  |  | (58) |  |  | (16,446) |  |  | 37,668 |  |  | (878) |  |  | 36,790 |  |
| Total change in other comprehensive income (loss) |  | $ | (19,120) |  |  | $ | (54) |  |  | $ | (19,174) |  |  | $ | 38,019 |  |  | $ | (422) |  |  | $ | 37,597 |  |

[0001628280-26-031041:notes:161]
(a) The tax shown above within foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries, which have been previously taxed in the U.S. and are not permanently reinvested.

[0001628280-26-031041:notes:162]
The following tables set forth the changes in the components of accumulated other comprehensive income (loss) by component for the three months ended March 28, 2026 and March 29, 2025:

[0001628280-26-031041:notes:163]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Total foreign currencytranslation adjustments |  | Accumulated othercomprehensive loss |
| Balance at December 27, 2025 |  | $ | (12,687) |  |  | $ | 8,132 |  |  | $ | (828) |  |  | $ | (5,383) |  |
| Activity in the period |  | 516 |  |  | (3,244) |  |  | (16,446) |  |  | (19,174) |  |
| Balance at March 28, 2026 |  | $ | (12,171) |  |  | $ | 4,888 |  |  | $ | (17,274) |  |  | $ | (24,557) |  |

[0001628280-26-031041:notes:164]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Total foreign currency translation adjustments |  | Accumulated other comprehensive (loss) income |
| Balance at December 28, 2024 |  | $ | (10,509) |  |  | $ | 1,301 |  |  | $ | (137,153) |  |  | $ | (146,361) |  |
| Activity in the period |  | 219 |  |  | 588 |  |  | 36,790 |  |  | 37,597 |  |
| Balance at March 29, 2025 |  | $ | (10,290) |  |  | $ | 1,889 |  |  | $ | (100,363) |  |  | $ | (108,764) |  |

[0001628280-26-031041:notes:165]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for the three months ended March 28, 2026 and March 29, 2025 were as follows:

[0001628280-26-031041:notes:166]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Pension and postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss, and other |  | $ | 465 |  |  | $ | 421 |  |  |  |  |  |

[0001628280-26-031041:notes:167]
The Company recognizes the amortization of prior service costs in Other income, net within the Condensed Consolidated Statements of Operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-031041:notes:168]
Income Taxes
The effective tax rate for the three months ended March 28, 2026 was 22.3% compared to the effective tax rate for the three months ended March 29, 2025 of 27.3%. The effective tax rate for 2026 was lower than the effective tax rate for the

[0001628280-26-031041:notes:169]
comparable 2025 period primarily due to lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter of 2026.

[0001628280-26-031041:notes:170]
The effective tax rate for three months ended March 28, 2026 was higher than the statutory tax rate primarily due to losses in non-U.S. jurisdictions with no related tax benefit, partially offset by lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter. The effective tax rate for the three months ended March 29, 2025 was higher than the statutory tax rate primarily due to losses in non-US jurisdictions with no related tax benefit.


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-031041:notes:171]
[same as prior period, unchanged from 0001628280-25-047026:notes:162]

[0001628280-26-031041:notes:172]
[same as prior period, unchanged from 0001628280-25-047026:notes:163]

[0001628280-26-031041:notes:173]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 75,147 |  |  | $ | 43,571 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 25,074 |  |  | 24,767 |  |  |  |  |  |
| Effect of dilutive securities |  | 346 |  |  | 196 |  |  |  |  |  |
| Diluted |  | 25,420 |  |  | 24,963 |  |  |  |  |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 3.00 |  |  | $ | 1.76 |  |  |  |  |  |
| Diluted earnings per share |  | $ | 2.96 |  |  | $ | 1.75 |  |  |  |  |  |

[0001628280-26-031041:notes:174]
Potential shares of common stock attributable to performance share units, stock options and restricted stock units excluded from the earnings per share calculation because their effect would be anti-dilutive were 39 and 340,710 for the three months ended March 28, 2026 and March 29, 2025, respectively.

[0001628280-26-031041:notes:175]
Share Repurchase Program
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program"). The Company did not repurchase any shares of its common stock for the three months ended March 28, 2026. During the three months ended March 29, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-031041:notes:176]
[same as prior period, unchanged from 0001628280-25-047026:notes:168]

[0001628280-26-031041:notes:177]
The Company and its subsidiaries design, manufacture and sell components, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company aggregated its operating segments into the reportable segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information and as such, segment asset information is not disclosed. The CODM’s key decisions involve the allocation of resources, such as acquisitions, divestitures, investments, capital expenditures, significant customer contracts, and other key management resources, and assessment of performance, such as executive officer hiring, promotion, and compensation. The CODM uses operating income as the key metric when establishing targets in the annual budget and in evaluating the allocation of resources to each segment. The CODM regularly reviews each segment's operating income against the forecast, budget and previous quarterly results to assess performance and make decisions about the allocation of operating and capital resources to each segment.

[0001628280-26-031041:notes:178]
[same as prior period, unchanged from 0001628280-25-047026:notes:170]

[0001628280-26-031041:notes:179]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes, and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including data center – computing and communication, data center and communications infrastructure, industrial controls, building controls, aerospace and defense, appliances, consumer electronics solutions, healthcare solutions, industrial equipment, energy storage, diversified industrials, grid and utility infrastructure, renewable energy, passenger vehicles, and commercial vehicles.

[0001628280-26-031041:notes:180]
•Transportation Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicles, heavy-duty truck and bus, off-road and recreational vehicles, material handling, agricultural equipment, construction equipment and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engines, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck and bus, off-road and recreational vehicles, material handling, agriculture equipment, construction equipment, and ship, marine and train.

[0001628280-26-031041:notes:181]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), protective and monitoring relays (protection relays, residual current devices and monitors, ground fault circuit interrupters, solid state switches, and arc fault detection devices), and industrial controls and sensors (contactors, transformers, and temperature sensors) for use in various applications such as data center – computing and communication, data center and communications infrastructure, industrial controls, building controls, grid and utility infrastructure, construction, renewable energy, HVAC, processing and extracting, and energy storage.

[0001628280-26-031041:notes:182]
[same as prior period, unchanged from 0001628280-25-047026:notes:174]

[0001628280-26-031041:notes:183]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 362,775 |  |  | $ | 307,249 |  |  |  |  |  |
| Transportation |  | 170,381 |  |  | 161,862 |  |  |  |  |  |
| Industrial |  | 123,813 |  |  | 85,196 |  |  |  |  |  |
| Total net sales |  | $ | 656,969 |  |  | $ | 554,307 |  |  |  |  |  |
| Other segment expenses (b) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 292,496 |  |  | $ | 260,483 |  |  |  |  |  |
| Transportation |  | 146,278 |  |  | 142,945 |  |  |  |  |  |
| Industrial |  | 103,052 |  |  | 72,122 |  |  |  |  |  |
| Total other segment expenses |  | $ | 541,826 |  |  | $ | 475,550 |  |  |  |  |  |
| Segment operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 70,279 |  |  | $ | 46,766 |  |  |  |  |  |
| Transportation |  | 24,103 |  |  | 18,917 |  |  |  |  |  |
| Industrial |  | 20,761 |  |  | 13,074 |  |  |  |  |  |
| Total segment operating income |  | 115,143 |  |  | 78,757 |  |  |  |  |  |
| Other (a) |  | (13,978) |  |  | (8,607) |  |  |  |  |  |
| Total operating income |  | 101,165 |  |  | 70,150 |  |  |  |  |  |
| Interest expense |  | 6,977 |  |  | 8,875 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (2,413) |  |  | 4,843 |  |  |  |  |  |
| Other income, net |  | (130) |  |  | (3,515) |  |  |  |  |  |
| Income before income taxes |  | $ | 96,731 |  |  | $ | 59,947 |  |  |  |  |  |

[0001628280-26-031041:notes:184]
(a) Included in "Other" Operating income for the first fiscal quarter of 2026 was $7.4 million of restructuring charges primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first quarter of 2026, the Company recognized $1.2 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2026, the Company recognized $5.4 million of purchase accounting inventory step-up adjustment related to the Basler acquisition.

[0001628280-26-031041:notes:185]
Included in "Other" Operating income for the first quarter of 2025 was $8.9 million of restructuring charges primarily related to employee termination costs, and $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the first quarter of 2025, the Company recognized $0.5 million of purchase accounting inventory step-down adjustment related to the Dortmund acquisition, and $0.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions.

[0001628280-26-031041:notes:186]
(b) Other segment operating expenses include cost of sales, selling, general, and administration expenses, and research and development expenses. Other segment expenses are reconciled to the operating income of each segment. The CODM regularly assesses the performance of each operating segment focusing on each operating segment’s revenue and operating income.

[0001628280-26-031041:notes:187]
The Company’s depreciation and amortization expenses by segment for the three months ended March 28, 2026 and March 29, 2025 were as follows:

[0001628280-26-031041:notes:188]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Depreciation |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 11,733 |  |  | $ | 11,410 |  |  |  |  |  |
| Transportation |  | 5,040 |  |  | 5,499 |  |  |  |  |  |
| Industrial |  | 2,179 |  |  | 1,521 |  |  |  |  |  |
| Total depreciation |  | $ | 18,952 |  |  | $ | 18,430 |  |  |  |  |  |
| Amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 8,977 |  |  | $ | 9,777 |  |  |  |  |  |
| Transportation |  | 3,362 |  |  | 3,349 |  |  |  |  |  |
| Industrial |  | 4,161 |  |  | 1,205 |  |  |  |  |  |
| Total amortization |  | $ | 16,500 |  |  | $ | 14,331 |  |  |  |  |  |

[0001628280-26-031041:notes:189]
[same as prior period, unchanged from 0001628280-25-047026:notes:181]

[0001628280-26-031041:notes:190]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 229,523 |  |  | $ | 198,378 |  |  |  |  |  |
| China |  | 155,903 |  |  | 129,394 |  |  |  |  |  |
| Other countries (a) |  | 271,543 |  |  | 226,535 |  |  |  |  |  |
| Total net sales |  | $ | 656,969 |  |  | $ | 554,307 |  |  |  |  |  |

[0001628280-26-031041:notes:191]
[same as prior period, unchanged from 0001628280-25-047026:notes:183]

[0001628280-26-031041:notes:192]
| (in thousands) |  | March 28, 2026 |  | December 27, 2025 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 91,352 |  |  | $ | 95,619 |  |
| China |  | 128,909 |  |  | 130,047 |  |
| Mexico |  | 80,712 |  |  | 83,478 |  |
| Germany |  | 113,798 |  |  | 110,246 |  |
| Philippines |  | 60,260 |  |  | 61,591 |  |
| Other countries |  | 58,497 |  |  | 59,659 |  |
| Total long-lived assets |  | $ | 533,528 |  |  | $ | 540,640 |  |

[0001628280-26-031041:notes:193]
[same as prior period, unchanged from 0001628280-25-047026:notes:185]

[0001628280-26-031041:notes:194]
|  |  | Three Months Ended |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 1,080 |  |  | $ | 3,493 |  |
| China |  | 2,009 |  |  | 1,483 |  |
| Mexico |  | 1,415 |  |  | 1,484 |  |
| Germany |  | 8,634 |  |  | 7,620 |  |
| Philippines |  | 1,853 |  |  | 637 |  |
| Other countries |  | 2,356 |  |  | 1,610 |  |
| Total additions to long-lived assets |  | $ | 17,347 |  |  | $ | 16,327 |  |

[0001628280-26-031041:notes:195]
[same as prior period, unchanged from 0001628280-25-047026:notes:187]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-26-031041:notes:196]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0001628280-26-031041:notes:197]
As of March 28, 2026, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-26-031041:notes:198]
Product Warranty Liabilities

[0001628280-26-031041:notes:199]
The Company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0001628280-26-031041:notes:200]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0001628280-26-031041:notes:201]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0001628280-26-031041:notes:202]
Environmental Remediation Liabilities

[0001628280-26-031041:notes:203]
The Company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0001628280-26-031041:notes:204]
Legal Proceedings

[0001628280-26-031041:notes:205]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

[0001628280-26-031041:notes:206]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss, the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.

[0001628280-26-031041:notes:207]
Pending Litigation and Claims

[0001628280-26-031041:notes:208]
There were no material pending litigation or claims outstanding as of March 28, 2026.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-26-031041:notes:209]
Related Party Transactions

[0001628280-26-031041:notes:210]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0001628280-26-031041:notes:211]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0001628280-26-031041:notes:212]
EB Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0001628280-26-031041:notes:213]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services.

[0001628280-26-031041:notes:214]
|  |  | Three Months Ended March 28, 2026 |  | Three Months Ended March 29, 2025 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase of material/service from related party |  | 0.5 |  | 0.1 |  | 4.2 |  |  | 0.5 |  | 0.2 |  | 1.9 |  |
|  |  | March 28, 2026 |  | December 27, 2025 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 4.2 |  |  | 0.1 |  | 0.1 |  | 2.1 |  |
