# LFUS 8-K — 0001628280-26-030892 filed 2026-05-06

## item codes, every 8-K on or before 2026-05-06

- 2026-05-06 0001628280-26-030892 — 2.02, 7.01, 9.01
- 2026-04-28 0000889331-26-000005 — 5.02, 5.07, 9.01
- 2026-03-13 0001140361-26-009393 — 1.01, 2.03, 9.01
- 2026-03-05 0000889331-26-000002 — 5.02, 7.01, 9.01
- 2026-01-28 0001628280-26-003710 — 2.02, 7.01, 9.01
- 2026-01-08 0001140361-26-000720 — 5.02, 9.01
- 2025-10-29 0001628280-25-046908 — 2.02, 7.01, 9.01
- 2025-10-28 0000889331-25-000186 — 1.01, 7.01, 9.01
- 2025-08-07 0000889331-25-000151 — 5.02, 7.01, 9.01
- 2025-07-30 0001628280-25-036551 — 2.02, 7.01, 9.01
- 2025-05-27 0000889331-25-000109 — 5.02, 7.01, 9.01
- 2025-04-29 0000889331-25-000095 — 2.02, 7.01, 9.01
- 2025-04-28 0000889331-25-000082 — 5.02, 5.07, 9.01
- 2025-04-09 0001140361-25-012942 — 5.02, 7.01, 9.01
- 2025-01-28 0000889331-25-000013 — 2.02, 7.01, 9.01
- 2025-01-13 0001140361-25-000873 — 5.02, 9.01
- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2026-05-06

- 2025-02-27 0001140361-25-006294 — NT 10-K, for the period ended 2024-12-28
- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-030892:8k_2_02:1]
EX-99.1
2
q12026earningsreleaseex991.htm
EX-99.1

[0001628280-26-030892:8k_2_02:2]
Document

[0001628280-26-030892:8k_2_02:3]
Exhibit 99.1

[0001628280-26-030892:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0001628280-26-030892:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2026

[0001628280-26-030892:8k_2_02:6]
First Quarter 2026 Highlights:

[0001628280-26-030892:8k_2_02:7]
(Year-over-year comparisons unless otherwise noted)

[0001628280-26-030892:8k_2_02:8]
•Net sales of $657 million, +19%; organic growth contributed +9%

[0001628280-26-030892:8k_2_02:9]
•Cash flow from operations of $80 million; free cash flow of $66 million, +55%

[0001628280-26-030892:8k_2_02:10]
•GAAP diluted earnings per share of $2.96; Adjusted diluted earnings per share of $3.31

[0001628280-26-030892:8k_2_02:11]
•GAAP operating margin of 15.4%, +270 bps; Adjusted EBITDA margin of 22.9%, +280 bps

[0001628280-26-030892:8k_2_02:12]
CHICAGO, May 6, 2026  - Littelfuse, Inc. (NASDAQ: LFUS), a leader in developing smart solutions that enable safe and efficient electrical energy transfer, today reported financial results for the first quarter ended March 28, 2026:

[0001628280-26-030892:8k_2_02:13]
“Our teams delivered a strong start to the year, with first quarter results exceeding our expectations,” said Greg Henderson, Littelfuse President and Chief Executive Officer. “We capitalized on solid market demand and executed well on our strategic priorities while leveraging our leadership in safe and efficient electrical energy transfer. Across all segments, we delivered growth and margin expansion, and we remain focused on driving growth opportunities, broadening our solutions portfolio, and advancing our operational excellence initiatives.”

[0001628280-26-030892:8k_2_02:14]
Second Quarter of 2026*

[0001628280-26-030892:8k_2_02:15]
“Looking ahead to the second quarter, we expect approximately 14% total revenue growth versus the prior year, supported by a strong backlog, continued customer momentum, and contributions from the Basler acquisition. Demand strength remains broad based, and we continue to partner closely with our customers to drive the ongoing evolution to higher power and higher energy density solutions.”

[0001628280-26-030892:8k_2_02:16]
Based on current market conditions, for the second quarter the company expects,

[0001628280-26-030892:8k_2_02:17]
•Net sales in the range of $690 - $710 million, adjusted diluted EPS in the range of $3.65 – $3.85 and an adjusted effective tax rate of 21% - 22%

[0001628280-26-030892:8k_2_02:18]
-more-

[0001628280-26-030892:8k_2_02:19]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001628280-26-030892:8k_2_02:20]
May 14, 2026 Investor Day

[0001628280-26-030892:8k_2_02:21]
The Company will host an Investor Day in New York City on Thursday, May 14, 2026. Greg Henderson, President and CEO, Abhi Khandelwal, Executive Vice President and CFO, and other members of the executive leadership team will present an in-depth review of the company’s business strategy, growth drivers, and financial objectives. The event will also feature interactive Q&A sessions.

[0001628280-26-030892:8k_2_02:22]
Presentations are expected to begin at 9:00 a.m. ET and conclude at 12:00 p.m. ET.

[0001628280-26-030892:8k_2_02:23]
The live webcast, as well as the presentation materials, will be available to the public on the day of the event via the Investor Relations section of Littelfuse.com. The webcast replay will be available within 24 hours of the event and will be archived for 12 months.

[0001628280-26-030892:8k_2_02:24]
First Quarter 2026 Segment Performance Highlights

[0001628280-26-030892:8k_2_02:25]
Electronics Segment

[0001628280-26-030892:8k_2_02:26]
•Net sales for the first quarter 2026 increased +18%. Organic sales increased +15% driven by improved passive products (+22% organic) sales. Semiconductor product (+8% organic) sales also contributed to growth driven by increased protection semiconductor volumes which more than offset lower power semiconductor sales. Favorable FX contributed +3% to growth.

[0001628280-26-030892:8k_2_02:27]
•Adjusted EBITDA margin for the first quarter 2026 increased to 25.1% (+300 bps) primarily due to strong passive products and protection volume leverage.

[0001628280-26-030892:8k_2_02:28]
Transportation Segment

[0001628280-26-030892:8k_2_02:29]
•Net sales for the first quarter 2026 increased +5% as organic sales increased +1% while favorable FX contributed +4% to growth. Organic sales growth benefited from improved passenger vehicle organic sales (+4% organic) and favorable pricing, which offset lower commercial vehicle sales (-1% organic). Passenger vehicle strength was driven by content expansion, more than offsetting lower global passenger car builds and sensor declines in the first quarter. Lower commercial vehicle organic sales reflected the previously disclosed exit of the marine business.

[0001628280-26-030892:8k_2_02:30]
•Adjusted EBITDA margin for the first quarter 2026 increased to 19.1% (+200 bps) driven by volume leverage and operational execution.

[0001628280-26-030892:8k_2_02:31]
-more-

[0001628280-26-030892:8k_2_02:32]
Industrial Segment

[0001628280-26-030892:8k_2_02:33]
•Net sales for the first quarter 2026 increased +45%. Organic sales increased +5% as improved grid & utility infrastructure and data center demand, along with favorable pricing, more than offset lower HVAC demand. The Basler acquisition and favorable FX also contributed +39% and +1% to growth, respectively.

[0001628280-26-030892:8k_2_02:34]
•Adjusted EBITDA margin for the first quarter 2026 increased to 21.9% (+340 bps) driven by favorable volume leverage and mix.

[0001628280-26-030892:8k_2_02:35]
Dividend

[0001628280-26-030892:8k_2_02:36]
•The company will pay a cash dividend on its common stock of $0.75 per share on June 4, 2026, to shareholders of record as of May 21, 2026.

[0001628280-26-030892:8k_2_02:37]
Conference Call and Webcast Information

[0001628280-26-030892:8k_2_02:38]
Littelfuse will host a conference call on Wednesday, May 6, 2026, at 8:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0001628280-26-030892:8k_2_02:39]
About Littelfuse

[0001628280-26-030892:8k_2_02:40]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0001628280-26-030892:8k_2_02:41]
-more-

[0001628280-26-030892:8k_2_02:42]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks, uncertainties and other factors include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; changes in import and export duty and tariff rates; exchange rate fluctuations; commodity price fluctuations; the effect of the Company's accounting policies; labor disputes and shortages; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; integration of acquisitions may not be achieved in a timely manner, or at all; limited realization of the expected benefits from investment and strategic plans; the risk that expected benefits, synergies and growth prospects of the transaction with Basler may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended  December 27, 2025.

[0001628280-26-030892:8k_2_02:43]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 27, 2025, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0001628280-26-030892:8k_2_02:44]
-more-

[0001628280-26-030892:8k_2_02:45]
Non-GAAP Financial Measures

[0001628280-26-030892:8k_2_02:46]
The information included in this press release and other materials filed with the SEC may include non-GAAP financial measures including organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of the company’s core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of its fundamental business operations or were not part of the company’s business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that the company’s definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001628280-26-030892:8k_2_02:47]
LFUS-F

[0001628280-26-030892:8k_2_02:48]
###

[0001628280-26-030892:8k_2_02:49]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-26-030892:8k_2_02:50]
LITTELFUSE, INC.

[0001628280-26-030892:8k_2_02:51]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-030892:8k_2_02:52]
|  |  | (Unaudited) |  |  |
| (in thousands, except share and per share data) |  | March 28,2026 |  | December 27,2025 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 481,697 |  |  | $ | 563,391 |  |
| Short-term investments |  | 279 |  |  | 287 |  |
| Trade receivables, less allowances of $79,896 and $77,073 at March 28, 2026 and December 27, 2025, respectively |  | 380,963 |  |  | 363,215 |  |
| Inventories |  | 418,922 |  |  | 416,472 |  |
| Prepaid income taxes and income taxes receivable |  | 5,240 |  |  | 6,137 |  |
| Prepaid expenses and other current assets |  | 89,135 |  |  | 85,832 |  |
| Total current assets |  | 1,376,236 |  |  | 1,435,334 |  |
| Net property, plant, and equipment |  | 533,528 |  |  | 540,640 |  |
| Intangible assets, net of amortization |  | 570,025 |  |  | 594,907 |  |
| Goodwill |  | 1,209,792 |  |  | 1,211,411 |  |
| Investments |  | 19,524 |  |  | 20,010 |  |
| Deferred income taxes |  | 5,471 |  |  | 5,255 |  |
| Right of use lease assets |  | 82,520 |  |  | 86,263 |  |
| Other long-term assets |  | 60,455 |  |  | 62,976 |  |
| Total assets |  | $ | 3,857,551 |  |  | $ | 3,956,796 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 222,666 |  |  | $ | 211,079 |  |
| Accrued liabilities |  | 170,787 |  |  | 199,271 |  |
| Accrued income taxes |  | 33,354 |  |  | 26,186 |  |
| Current portion of long-term debt |  | 100,483 |  |  | 96,233 |  |
| Total current liabilities |  | 527,290 |  |  | 532,769 |  |
| Long-term debt, less current portion |  | 531,049 |  |  | 706,394 |  |
| Deferred income taxes |  | 101,612 |  |  | 102,335 |  |
| Accrued post-retirement benefits |  | 39,084 |  |  | 38,733 |  |
| Non-current lease liabilities |  | 69,122 |  |  | 71,765 |  |
| Other long-term liabilities |  | 75,330 |  |  | 78,766 |  |
| Total equity |  | 2,514,064 |  |  | 2,426,034 |  |
| Total liabilities and equity |  | $ | 3,857,551 |  |  | $ | 3,956,796 |  |

[0001628280-26-030892:8k_2_02:53]
LITTELFUSE, INC.

[0001628280-26-030892:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-030892:8k_2_02:55]
(Unaudited)

[0001628280-26-030892:8k_2_02:56]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share data) |  | March 28,2026 |  | March 29,2025 |  |  |  |  |
| Net sales |  | $ | 656,969 |  |  | $ | 554,307 |  |  |  |  |  |
| Cost of sales |  | 402,820 |  |  | 347,051 |  |  |  |  |  |
| Gross profit |  | 254,149 |  |  | 207,256 |  |  |  |  |  |
| Selling, general, and administrative expenses |  | 99,325 |  |  | 87,708 |  |  |  |  |  |
| Research and development expenses |  | 29,737 |  |  | 26,048 |  |  |  |  |  |
| Amortization of intangibles |  | 16,500 |  |  | 14,331 |  |  |  |  |  |
| Restructuring, impairment, and other charges |  | 7,422 |  |  | 9,019 |  |  |  |  |  |
| Total operating expenses |  | 152,984 |  |  | 137,106 |  |  |  |  |  |
| Operating income |  | 101,165 |  |  | 70,150 |  |  |  |  |  |
| Interest expense |  | 6,977 |  |  | 8,875 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (2,413) |  |  | 4,843 |  |  |  |  |  |
| Other income, net |  | (130) |  |  | (3,515) |  |  |  |  |  |
| Income before income taxes |  | 96,731 |  |  | 59,947 |  |  |  |  |  |
| Income taxes |  | 21,584 |  |  | 16,376 |  |  |  |  |  |
| Net income |  | $ | 75,147 |  |  | $ | 43,571 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.00 |  |  | $ | 1.76 |  |  |  |  |  |
| Diluted |  | $ | 2.96 |  |  | $ | 1.75 |  |  |  |  |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 25,074 |  |  | 24,767 |  |  |  |  |  |
| Diluted |  | 25,420 |  |  | 24,963 |  |  |  |  |  |
| Comprehensive income |  | $ | 55,973 |  |  | $ | 81,168 |  |  |  |  |  |

[0001628280-26-030892:8k_2_02:57]
LITTELFUSE, INC.

[0001628280-26-030892:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-26-030892:8k_2_02:59]
(Unaudited)

[0001628280-26-030892:8k_2_02:60]
|  |  | Three Months Ended |
| (in thousands) |  | March 28, 2026 |  | March 29, 2025 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 75,147 |  |  | $ | 43,571 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 42,614 |  |  | 37,658 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (21,783) |  |  | (14,745) |  |
| Inventories |  | (6,740) |  |  | 8,699 |  |
| Accounts payable |  | 8,567 |  |  | (8,772) |  |
| Accrued liabilities and income taxes |  | (19,802) |  |  | (8,044) |  |
| Prepaid expenses and other assets |  | 2,255 |  |  | 7,391 |  |
| Net cash provided by operating activities |  | 80,258 |  |  | 65,758 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (2,508) |  |  | (57,417) |  |
| Purchases of property, plant, and equipment |  | (14,094) |  |  | (23,102) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 31 |  |  | 11 |  |
| Net cash used in investing activities |  | (16,571) |  |  | (80,508) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (166,250) |  |  | (53,750) |  |
| Repurchases of common stock |  | — |  |  | (27,374) |  |
| Cash dividends paid |  | (18,836) |  |  | (17,335) |  |
| All other cash provided by financing activities |  | 42,430 |  |  | 1,425 |  |
| Net cash used in financing activities |  | (142,656) |  |  | (97,034) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (2,762) |  |  | 5,603 |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (81,731) |  |  | (106,181) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 565,104 |  |  | 726,437 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 483,373 |  |  | $ | 620,256 |  |

[0001628280-26-030892:8k_2_02:61]
LITTELFUSE, INC.

[0001628280-26-030892:8k_2_02:62]
NET SALES AND OPERATING INCOME BY SEGMENT

[0001628280-26-030892:8k_2_02:63]
(Unaudited)

[0001628280-26-030892:8k_2_02:64]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2026 |  | 2025 |  |  |  | %Growth |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 362,775 |  |  | $ | 307,249 |  |  |  |  | 18.1 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 170,381 |  |  | 161,862 |  |  |  |  | 5.3 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 123,813 |  |  | 85,196 |  |  |  |  | 45.3 | % |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 656,969 |  |  | $ | 554,307 |  |  |  |  | 18.5 | % |  |  |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 70,279 |  |  | $ | 46,766 |  |  |  |  | 50.3 | % |  |  |  |  |  |  |  |  |
| Transportation |  | 24,103 |  |  | 18,917 |  |  |  |  | 27.4 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 20,761 |  |  | 13,074 |  |  |  |  | 58.8 | % |  |  |  |  |  |  |  |  |
| Other (a) |  | (13,978) |  |  | (8,607) |  |  |  |  | N.M. |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 101,165 |  |  | $ | 70,150 |  |  |  |  | 44.2 | % |  |  |  |  |  |  |  |  |
| Operating Margin |  | 15.4 | % |  | 12.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 6,977 |  |  | 8,875 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (2,413) |  |  | 4,843 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net |  | (130) |  |  | (3,515) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 96,731 |  |  | $ | 59,947 |  |  |  |  | 61.4 | % |  |  |  |  |  |  |  |  |

[0001628280-26-030892:8k_2_02:65]
(a) "Other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments, and restructuring and impairment charges. See Supplemental Financial Information for details.

[0001628280-26-030892:8k_2_02:66]
N.M. - Not meaningful

[0001628280-26-030892:8k_2_02:67]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2026 |  | 2025 |  | %Growth |  |  |  |  |  |  |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 19.4 | % |  | 15.2 | % |  | 4.2 | % |  |  |  |  |  |  |
| Transportation |  | 14.1 | % |  | 11.7 | % |  | 2.4 | % |  |  |  |  |  |  |
| Industrial |  | 16.8 | % |  | 15.3 | % |  | 1.5 | % |  |  |  |  |  |  |

[0001628280-26-030892:8k_2_02:68]
LITTELFUSE, INC.

[0001628280-26-030892:8k_2_02:69]
SUPPLEMENTAL FINANCIAL INFORMATION

[0001628280-26-030892:8k_2_02:70]
(In millions of USD except per share amounts - unaudited)

[0001628280-26-030892:8k_2_02:71]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-26 |  | Q1-25 |  |  |  |  |
| GAAP diluted EPS |  | $ | 2.96 |  |  | $ | 1.75 |  |  |  |  |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.35 |  |  | 0.44 |  |  |  |  |  |
| Adjusted diluted EPS |  | $ | 3.31 |  |  | $ | 2.19 |  |  |  |  |  |

[0001628280-26-030892:8k_2_02:72]
| Non-GAAP adjustments - expense / (income) |  |  |  |  |  |  |  |  |
|  |  | Q1-26 |  | Q1-25 |  |  |  |  |
| Acquisition-related and integration costs (a) |  | $ | 1.2 |  |  | $ | 0.1 |  |  |  |  |  |
| Purchase accounting inventory adjustments (b) |  | 5.4 |  |  | (0.5) |  |  |  |  |  |
| Restructuring, impairment and other charges (c) |  | 7.4 |  |  | 9.0 |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 14.0 |  |  | 8.6 |  |  |  |  |  |
| Other income, net (d) |  | 2.7 |  |  | — |  |  |  |  |  |
| Non-operating foreign exchange (gain) loss |  | (2.4) |  |  | 4.8 |  |  |  |  |  |
| Non-GAAP adjustments to income before income taxes |  | 14.3 |  |  | 13.4 |  |  |  |  |  |
| Income taxes (e) |  | 5.3 |  |  | 2.3 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | $ | 9.0 |  |  | $ | 11.1 |  |  |  |  |  |
| Total EPS impact |  | $ | 0.35 |  |  | $ | 0.44 |  |  |  |  |  |

[0001628280-26-030892:8k_2_02:73]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-26 |  | Q1-25 |  |  |  |  |
| Net income |  | $ | 75.1 |  |  | $ | 43.6 |  |  |  |  |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 21.6 |  |  | 16.4 |  |  |  |  |  |
| Interest expense |  | 7.0 |  |  | 8.9 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (2.4) |  |  | 4.8 |  |  |  |  |  |
| Other income, net |  | (0.1) |  |  | (3.5) |  |  |  |  |  |
| GAAP operating income |  | $ | 101.2 |  |  | $ | 70.2 |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 14.0 |  |  | 8.6 |  |  |  |  |  |
| Adjusted operating income |  | $ | 115.1 |  |  | $ | 78.8 |  |  |  |  |  |
| Amortization of intangibles |  | 16.5 |  |  | 14.3 |  |  |  |  |  |
| Depreciation expense |  | 19.0 |  |  | 18.4 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 150.6 |  |  | $ | 111.5 |  |  |  |  |  |
| Net sales |  | $ | 657.0 |  |  | $ | 554.3 |  |  |  |  |  |
| Net income as a percentage of net sales |  | 11.4 | % |  | 7.9 | % |  |  |  |  |
| Operating margin |  | 15.4 | % |  | 12.7 | % |  |  |  |  |
| Adjusted operating margin |  | 17.5 | % |  | 14.2 | % |  |  |  |  |
| Adjusted EBITDA margin |  | 22.9 | % |  | 20.1 | % |  |  |  |  |

[0001628280-26-030892:8k_2_02:74]
| Adjusted EBITDA by Segment |  | Q1-26 |  | Q1-25 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 70.3 |  |  | $ | 24.1 |  |  | $ | 20.8 |  |  | $ | 46.8 |  |  | $ | 18.9 |  |  | $ | 13.1 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 9.0 |  |  | 3.4 |  |  | 4.1 |  |  | 9.8 |  |  | 3.3 |  |  | 1.2 |  |
| Add back depreciation |  | 11.8 |  |  | 5.0 |  |  | 2.2 |  |  | 11.4 |  |  | 5.5 |  |  | 1.5 |  |
| Adjusted EBITDA |  | $ | 91.0 |  |  | $ | 32.5 |  |  | $ | 27.1 |  |  | $ | 68.0 |  |  | $ | 27.7 |  |  | $ | 15.8 |  |
| Adjusted EBITDA Margin |  | 25.1 | % |  | 19.1 | % |  | 21.9 | % |  | 22.1 | % |  | 17.1 | % |  | 18.5 | % |

[0001628280-26-030892:8k_2_02:75]
| Net sales reconciliation |  | Q1-26 vs. Q1-25 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 18 | % |  | 5 | % |  | 45 | % |  | 19 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | — | % |  | 39 | % |  | 6 | % |
| FX impact |  | 3 | % |  | 4 | % |  | 1 | % |  | 3 | % |
| Organic net sales growth |  | 15 | % |  | 1 | % |  | 5 | % |  | 9 | % |

[0001628280-26-030892:8k_2_02:76]
| Electronics segment net sales reconciliation |  | Q1-26 vs. Q1-25 |
|  |  | Electronics - Passive Products and Sensors |  | Electronics - Semiconductor |  | Total Electronics |
| Net sales growth |  | 26 | % |  | 11 | % |  | 18 | % |
| Less: |  |  |  |  |  |  |
| FX impact |  | 4 | % |  | 3 | % |  | 3 | % |
| Organic net sales growth |  | 22 | % |  | 8 | % |  | 15 | % |

[0001628280-26-030892:8k_2_02:77]
| Transportation segment net sales reconciliation |  | Q1-26 vs. Q1-25 |
|  |  | Commercial Vehicle Products |  | Passenger Car Products (1) |  | Auto Sensor Products (1) |  | Total Transportation |
| Net sales growth |  | 1 | % |  | 10 | % |  | 1 | % |  | 5 | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | 2 | % |  | 4 | % |  | 8 | % |  | 4 | % |
| Organic net sales (decline) growth |  | (1) | % |  | 6 | % |  | (7) | % |  | 1 | % |

[0001628280-26-030892:8k_2_02:78]
(1) Passenger vehicle business (PVB) includes passenger car and auto sensor products.

[0001628280-26-030892:8k_2_02:79]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-26 |  | Q1-25 |  |  |  |  |
| Income taxes |  | $ | 21.6 |  |  | $ | 16.4 |  |  |  |  |  |
| Effective rate |  | 22.3 | % |  | 27.3 | % |  |  |  |  |
| Non-GAAP adjustments - income taxes |  | 5.3 |  |  | 2.3 |  |  |  |  |  |
| Adjusted income taxes |  | $ | 26.9 |  |  | $ | 18.7 |  |  |  |  |  |
| Adjusted effective rate |  | 24.2 | % |  | 25.5 | % |  |  |  |  |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-26 |  | Q1-25 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 80.3 |  |  | $ | 65.8 |  |  |  |  |  |
| Less: Purchases of property, plant, and equipment |  | (14.1) |  |  | (23.1) |  |  |  |  |  |
| Free cash flow |  | $ | 66.2 |  |  | $ | 42.7 |  |  |  |  |  |

[0001628280-26-030892:8k_2_02:80]
| Consolidated Total Debt |  | As of March 28, 2026 |
| Consolidated total debt |  | $ | 631.5 |  |
| Unamortized debt issuance costs |  | 3.5 |  |
| Finance lease liability |  | 0.2 |  |
| Consolidated funded indebtedness |  | 635.2 |  |
| Cash held in U.S. (up to $400 million) |  | 67.6 |
| Net debt |  | $ | 567.6 |  |
| Consolidated EBITDA |  | Twelve Months Ended March 28, 2026 |
| Net Loss |  | $ | (40.3) |  |
| Interest expense |  | 32.4 |  |
| Income taxes |  | 80.5 |  |
| Depreciation expense |  | 75.4 |  |
| Amortization expense |  | 62.0 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 28.1 |  |
| Purchase accounting inventory step-up charge |  | 6.4 |  |
| Unrealized loss on investments |  | 2.1 |  |
| Impairment charges |  | 301.9 |  |
| Other |  | 34.1 |  |
| Consolidated EBITDA (1) |  | $ | 582.6 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.0x |

[0001628280-26-030892:8k_2_02:81]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2027 to 2031, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0001628280-26-030892:8k_2_02:82]
The Credit Agreement was amended in Q1 2026 and now allows to add restructuring charges and business optimization expenses in addition to the prior credit agreement.

[0001628280-26-030892:8k_2_02:83]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0001628280-26-030892:8k_2_02:84]
Note: Total will not always foot due to rounding.

[0001628280-26-030892:8k_2_02:85]
(a) Reflected in selling, general and administrative expenses ("SG&A").

[0001628280-26-030892:8k_2_02:86]
(b) Reflected in cost of sales.

[0001628280-26-030892:8k_2_02:87]
(c) Reflected in restructuring, impairment and other charges.

[0001628280-26-030892:8k_2_02:88]
(d) 2026 included the reversal of an indemnification receivable of $2.7 million related to lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter of 2026.

[0001628280-26-030892:8k_2_02:89]
(e) Reflected the tax impact associated with the non-GAAP adjustments including $2.7 million of tax benefits due to lapses in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter of 2026.

[0001628280-26-030892:8k_2_02:90]
###
