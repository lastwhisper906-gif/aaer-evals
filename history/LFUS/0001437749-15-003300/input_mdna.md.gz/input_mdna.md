# LFUS MD&A — 0001437749-15-003300


## mdna

[0001437749-15-003300:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001437749-15-003300:mdna:2]
Littelfuse Overview

[0001437749-15-003300:mdna:3]
Introduction

[0001437749-15-003300:mdna:4]
Littelfuse, Inc. and its subsidiaries (the “company” or “Littelfuse” or “we” or “our”) is the worldwide leader in circuit protection offering the industry's broadest and deepest portfolio of circuit protection products and solutions. The company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment. The company conducts its business through three reportable segments, which are defined by markets and consist of Electronics, Automotive, and Electrical. The company’s customer base includes original equipment manufacturers, tier one automotive suppliers and distributors.

[0001437749-15-003300:mdna:5]
In addition to protecting and growing its core circuit protection business, Littelfuse has been investing in power control and sensing technologies. These newer platforms, combined with the company’s strong balance sheet and operating cash flow, provide opportunities for increased organic and acquisition growth. In 2012, the company set a five-year strategic target plan to grow annual sales at 15% per year; 5% organically and 10% through acquisitions. As of December 27, 2014, two years into the five-year plan, the company has achieved an annual sales growth of 13%; 5% organically and 8% through acquisitions. The company remains focused on only those acquisitions that will add shareholder value. Overall, the company believes its strategy is sound, the fundamentals of its business have not changed, and its long-term goals are achievable.

[0001437749-15-003300:mdna:6]
To maximize shareholder value, the company’s primary strategic goals are to:

[0001437749-15-003300:mdna:7]
|  | ● | Grow organically faster than its markets; |

[0001437749-15-003300:mdna:8]
|  | ● | Double the pace of acquisitions; |

[0001437749-15-003300:mdna:9]
22

[0001437749-15-003300:mdna:10]
|  | ● | Sustain operating margins in the high teens; |

[0001437749-15-003300:mdna:11]
|  | ● | Improve return on investment; and |

[0001437749-15-003300:mdna:12]
|  | ● | Return excess cash to shareholders. |

[0001437749-15-003300:mdna:13]
The company serves markets that are directly impacted by global economic trends with significant exposures to the consumer electronics, automotive, industrial and mining end markets. The company’s results will be impacted positively or negatively by changes in these end markets.

[0001437749-15-003300:mdna:14]
Electronics Segment Overview

[0001437749-15-003300:mdna:15]
The Electronics segment, which accounts for 48% of total sales, has produced solid revenue growth and substantial margin improvement over the last few years. In 2014, sales increased 12% (7% excluding acquisitions) and operating margin increased from 19.0% to 21.2% reflecting growth in all regions. The company believe this is the result of a stable electronics market combined with ongoing design wins and market share gains for Littelfuse.

[0001437749-15-003300:mdna:16]
The electronics business is affected by seasonality. Sales are typically weaker in the first and fourth quarters and stronger in the second quarter and third quarters. This reflects the production ramp up for consumer electronics in advance of the year-end holidays and other factors.

[0001437749-15-003300:mdna:17]
Fourth quarter 2014 sales for Electronics were consistent with normal seasonality as channel inventories remain at appropriate levels. The book-to-bill ratio of 1.06 (1.0 excluding sensors) at the end of the fourth quarter is also consistent with normal seasonal trends.

[0001437749-15-003300:mdna:18]
Automotive Segment Overview

[0001437749-15-003300:mdna:19]
The Automotive segment, which accounts for 38% of sales, has been the company’s fastest growing business over the last few years. In 2014, Automotive sales increased 22% (14% excluding acquisitions) resulting from strong performance across all product categories and all regions

[0001437749-15-003300:mdna:20]
Passenger car fuse sales continue to outperform global car production due primarily to the success of the company’s new high current fuses which are driving increases in content per vehicle. Commercial vehicle products had their best year ever with double-digit sales growth and improved operating margin driven by strength in the North American heavy duty truck market and integration-related cost savings. Automotive sensors also had their second consecutive year of double-digit sales growth primarily reflecting ramp-up of new solar sensor and speed and position sensor platforms. In summary, sales increased in all three major areas of the Automotive business, and while the company is currently experiencing headwinds from the weaker euro, it anticipates continued growth in the year ahead.

[0001437749-15-003300:mdna:21]
Electrical Segment Overview

[0001437749-15-003300:mdna:22]
The Electrical segment, which accounts for about 14% of total sales, has been the company’s most challenging segment for the past two years. In 2014, Electrical sales declined 6% (22% excluding the acquisition of SymCom) reflecting the depressed global mining market, a difficult year for solar sales and continued weakness in non-residential construction.

[0001437749-15-003300:mdna:23]
Toward the end of 2014, the company began seeing signs of improvement in two of its most important end markets: potash mining and non-residential construction. While these positive trends did not significantly impact 2014, the company expects these trends to contribute to growth in 2015. In addition, the company expects improved performance for SymCom in 2015 reflecting new product introductions and progress on integration activities.

[0001437749-15-003300:mdna:24]
Business Acquisitions

[0001437749-15-003300:mdna:25]
On January 3, 2014, the company acquired 100% of SymCom, Inc. (“SymCom”) for $52.8 million (net of cash acquired). Located in Rapid City, South Dakota, SymCom provides overload relays and pump controllers primarily to the industrial market. The acquisition allows the company to strengthen its position in the relay products market by adding new products and new customers within its Electrical business unit segment.

[0001437749-15-003300:mdna:26]
On May 31, 2013, the company acquired 100% of Hamlin, Inc. (“Hamlin”) from Key Safety Systems, for $144.4 million (net of cash acquired). Hamlin is a manufacturer of sensor technology providing standard products and custom solutions for leading global manufacturers in the automotive and electronic industries. The acquisition allows the company to expand its automotive and electronics product offerings in the global sensor market in both the Automotive and Electronics business segments.

[0001437749-15-003300:mdna:27]
Business Segment Information

[0001437749-15-003300:mdna:28]
U.S. Generally Accepted Accounting Principles (“GAAP”) dictates annual and interim reporting standards for an enterprise's operating segments and related disclosures about its products, services, geographic areas and major customers. Within U.S. GAAP, an operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer. The following table is a summary of the company’s business unit segments’ net sales by business unit and geography (in millions):

[0001437749-15-003300:mdna:29]
|  |  | Fiscal Year |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics(b) |  | $ | 410.1 |  |  | $ | 367.1 |  |  | $ | 329.5 |  |
| Automotive(c) (d) |  |  | 325.4 |  |  |  | 267.2 |  |  |  | 206.2 |  |
| Electrical(h) |  |  | 116.5 |  |  |  | 123.6 |  |  |  | 132.2 |  |
| Total |  | $ | 852.0 |  |  | $ | 757.9 |  |  | $ | 667.9 |  |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas(e)(h) |  | $ | 377.7 |  |  | $ | 342.4 |  |  | $ | 303.6 |  |
| Europe(d) (f) |  |  | 163.9 |  |  |  | 136.8 |  |  |  | 107.5 |  |
| Asia-Pacific(g) |  |  | 310.4 |  |  |  | 278.7 |  |  |  | 256.8 |  |
| Total |  | $ | 852.0 |  |  | $ | 757.9 |  |  | $ | 667.9 |  |

[0001437749-15-003300:mdna:30]
(a) Sales by geography represent sales to customer or distributor locations.

[0001437749-15-003300:mdna:31]
(b) 2014 and 2013 includes incremental Hamlin net sales of $36.5 million and $24.1 million, respectively.

[0001437749-15-003300:mdna:32]
(c) 2014 and 2013 includes incremental Hamlin net sales of $20.2 million and $26.9 million, respectively.

[0001437749-15-003300:mdna:33]
(d) 2013 includes incremental Accel and Terra Power net sales of $9.2 million and $5.7 million, respectively.

[0001437749-15-003300:mdna:34]
(e) 2014 and 2013 include incremental Hamlin net sales of $16.7 million and $23.0 million, respectively.

[0001437749-15-003300:mdna:35]
(f) 2014 and 2013 include incremental Hamlin net sales of $9.3 million and $11.6 million, respectively.

[0001437749-15-003300:mdna:36]
(g) 2014 and 2013 include incremental Hamlin net sales of $10.4 million and $16.4 million, respectively.

[0001437749-15-003300:mdna:37]
(h) 2014 includes incremental SymCom net sales of $19.6 million.

[0001437749-15-003300:mdna:38]
Business unit segment information is described more fully in Note 15 of the Notes to Consolidated Financial Statements. The following discussion provides an analysis of the information contained in the Consolidated Financial Statements and accompanying Notes to Consolidated Financial Statements at December 27, 2014 and December 28, 2013, and for the three fiscal years ended December 27, 2014, December 28, 2013 and December 29, 2012.

[0001437749-15-003300:mdna:39]
24

[0001437749-15-003300:mdna:40]
Results of Operations — 2014 compared with 2013

[0001437749-15-003300:mdna:41]
The following table summarizes the company’s consolidated results of operations for the periods presented. The results include incremental activity from the company’s business acquisitions as described, where applicable, in the below analysis. There were also additional expenses and accounting adjustments during 2014. These include a $2.8 million inventory adjustment in 2014 related to the SymCom acquisition as described in Note 2, $0.4 million in acquisition-related costs, $3.2 million in severance charges related to the Lake Mills, Wisconsin and Matamoros, Mexico locations, $2.2 million in internal legal restructuring costs that will enable the up-streaming of cash to the U.S., and $0.3 million in asset impairments.

[0001437749-15-003300:mdna:42]
Fiscal year 2014 also included $3.9 million in foreign currency losses primarily attributable to changes in the value of both the euro and Philippine peso against the U.S. dollar while fiscal year 2013 included $3.3 million in foreign currency gains primarily related to the value of the Philippine peso against the dollar.

[0001437749-15-003300:mdna:43]
|  |  | Fiscal Year |  |  |  |  |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Sales |  | $ | 851,995 |  |  | $ | 757,853 |  |  |  | 12 | % |
| Gross profit |  |  | 324,428 |  |  |  | 296,232 |  |  |  | 10 | % |
| Operating expenses |  |  | 190,598 |  |  |  | 166,351 |  |  |  | 15 | % |
| Operating income |  |  | 133,830 |  |  |  | 129,881 |  |  |  | 3 | % |
| Other expense (income), net |  |  | (6,644 | ) |  |  | (4,646 | ) |  |  | 43 | % |
| Income before income taxes |  |  | 131,646 |  |  |  | 124,235 |  |  |  | 6 | % |
| Net income |  | $ | 99,418 |  |  | $ | 88,784 |  |  |  | 12 | % |

[0001437749-15-003300:mdna:44]
Net sales increased $94.1 million or 12% to $852.0 million for fiscal year 2014 compared to $757.9 million in fiscal year 2013 due primarily to an incremental $56.1 million from business acquisitions and growth in electronic and automotive products, offset by lower electrical sales. The company also experienced $0.4 million in unfavorable foreign currency effects in 2014 as compared to 2013 primarily resulting from sales denominated in Canadian dollars and Japanese yen. During the fourth quarter of 2014, sales were negatively impacted by the steep decline in the euro. Excluding acquisitions and currency effects, net sales increased $38.5 million or 5% year over year. The Automotive business segment sales increased $58.2 million or 22% to $325.4 million. The Electronics business segment sales increased $43.0 million or 12% to $410.1 million, and the Electrical business segment sales decreased $7.1 million or 6% to $116.5 million. Sales levels in 2014, excluding acquisitions and currency effects, were positively impacted by increased demand for the company’s automotive and electronic products partially offset by slowing demand for the company’s electrical products.

[0001437749-15-003300:mdna:45]
The increase in Automotive sales was primarily due to strong organic growth in all product categories and an incremental $20.2 million in sales from Hamlin. Currency effects increased sales by $0.6 million for the full year 2014 compared to 2013. Excluding incremental sales from Hamlin and currency effects, Automotive sales increased $37.3 million or 14% year over year due primarily to increases in content per vehicle and strength in the heavy truck market.

[0001437749-15-003300:mdna:46]
The increase in Electronics sales reflected solid growth for both semiconductor and passive components and incremental sales from Hamlin of $16.3 million. In addition, sales were positively impacted by net favorable currency effects of $0.2 million for the full year 2014. Excluding acquisitions and currency effects, Electronics sales increased $26.5 million or 7% year over year.

[0001437749-15-003300:mdna:47]
25

[0001437749-15-003300:mdna:48]
The decrease in Electrical sales was primarily from declines in custom and relay sales into the mining market and power fuses into the solar market. These declines more than offset incremental sales of $19.6 million from the SymCom acquisition in 2014. The Electrical segment experienced net unfavorable currency effects of $1.3 million primarily from sales denominated in Canadian dollars. Excluding incremental sales and currency effects, Electrical sales decreased $25.4 million or 21% year over year.

[0001437749-15-003300:mdna:49]
On a geographic basis, sales in the Americas increased $35.3 million or 10% in 2014 as compared to 2013 due primarily to incremental sales from business acquisitions of $36.3 million offset by $1.4 million in unfavorable currency effects resulting from sales denominated in Canadian dollars. Excluding acquisitions and currency effects, Americas’ sales increased $0.4 million or less than 1%. Increases in the company’s Automotive and Electronics sales were mostly offset by a decline in Electrical sales. Automotive sales increased $33.4 million or 26% primarily reflecting incremental sales from acquisitions of $12.5 million, strong growth in the passenger vehicle market and growth in the commercial vehicle market. Electronics sales increased $9.6 million or 9% primarily reflecting higher demand and incremental sales from Hamlin of $4.3 million. Electrical sales decreased $7.7 million or 7% resulting from decreases in demand for protection relays and custom products due to continued weakness in the mining segment. This decrease more than offset $19.6 million in incremental sales from SymCom in 2014.

[0001437749-15-003300:mdna:50]
European sales increased $27.1 million or 20% in 2014 compared to 2013 primarily due to strong demand for electronics and automotive products, incremental sales from Hamlin of $9.4 million and $1.0 million in favorable currency effects from sales denominated in euros. Excluding acquisitions and currency effects, European sales increased $16.8 million or 12%. This resulted from increases in the company’s Electronics and Automotive sales partially offset by a decrease in Electrical sales. Automotive sales increased $18.2 million or 21% in 2014 primarily reflecting incremental sales from Hamlin sensors of $6.2 million and higher sales in the passenger vehicle markets driven primarily by increased content. Excluding the impact of incremental sales from Hamlin and favorable currency effects, Automotive sales increased $11.5 million or 13%. Electronics sales increased $9.2 million or 22% reflecting incremental sales from Hamlin of $3.2 million and higher demand in 2014. Electrical sales decreased $0.3 million or 4% in 2014 primarily from decreased demand in the marine market for relays.

[0001437749-15-003300:mdna:51]
Asia-Pacific sales increased $31.7 million or 11% in 2014 compared to 2013 primarily due to increased demand across all product categories and incremental sales from Hamlin of $10.4 million. Currency effects amounted to less than $0.1 million. Excluding acquisitions and currency effects, Asia-Pacific sales increased $21.3 million or 8%. Electronics sales increased $24.2 million or 11% reflecting incremental sales from Hamlin of $8.9 million and increased sales in China offset by weakness in the Taiwan, Japan and Korea markets. Automotive sales increased $6.6 million or 12% reflecting incremental sales from acquisitions of $1.5 million and continued increased demand for passenger vehicles in China as well as gains in market share.

[0001437749-15-003300:mdna:52]
Gross profit was $324.4 million or 38.1% of sales in 2014, compared to $296.2 million or 39.1% of sales in 2013. Gross profit in both 2014 and 2013 were negatively impacted by purchase accounting adjustments in cost of sales of $2.8 million and $1.5 million, respectively. These charges were the additional cost of goods sold for SymCom and Hamlin inventories which had been stepped up to fair value at the acquisition dates as required by purchase accounting rules. Additionally, 2014 gross profit was negatively impacted by $2.7 million in severance charges. These severance charges primarily related to post-Hamlin acquisition reorganization changes. Excluding the impact of these charges, gross profit was $329.9 million or 38.7% of sales as compared to $297.8 million or 39.3% of sales in 2013. The decrease in gross margin was primarily attributable to higher sales of sensors in 2014 which carry lower margins than the company’s core products.

[0001437749-15-003300:mdna:53]
Total operating expense was $190.6 million or 22.4% of net sales for 2014 compared to $166.4 million or 22.0% of net sales for 2013. The increase in operating expenses primarily reflects incremental operating expenses of $14.2 million from business acquisitions and $3.5 million in restructuring, acquisition and impairment costs, $2.2 million of which was to effect changes in the company’s legal structure to allow tax-efficient repatriation of approximately $90.0 million of cash in the fourth quarter of 2014.

[0001437749-15-003300:mdna:54]
Operating income was $133.8 million or 15.7% of net sales in 2014 compared to $129.9 million or 17.1% of net sales in the prior year. The increase in operating income and decrease in operating margin in the current year was due primarily to the factors affecting gross profit and operating expenses discussed above.

[0001437749-15-003300:mdna:55]
Interest expense was $4.9 million in 2014 as compared to $2.9 million in 2013 and is primarily related to the company’s increased borrowing to fund acquisitions.

[0001437749-15-003300:mdna:56]
Impairment and equity in net loss of unconsolidated affiliate was $10.7 million in 2013. During the first quarter of 2013, the company fully impaired its investment in and loan receivable from Shocking Technologies, Inc. (“Shocking”) as described in Note 6 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:57]
Foreign exchange (gain) loss was $3.9 million of loss in 2014 compared to $3.3 million of gain in 2013. The fluctuation in foreign exchange was primarily attributable to changes in the value of both the euro and the Philippine peso against the U.S. dollar in 2014 and the Philippine peso against the dollar in 2013.

[0001437749-15-003300:mdna:58]
Other expense (income), net, consisting of interest income, royalties and non-operating income was $6.6 million of income in 2014 compared to $4.6 million of income in 2013. The year-over-year increase in income primarily reflects higher interest income in 2014.

[0001437749-15-003300:mdna:59]
Income before income taxes was $131.6 million in 2014 compared to $124.2 million in 2013. Income tax expense was $32.2 million in 2014 compared to $35.5 million in 2013. The 2014 effective income tax rate was 24.5% compared to 28.5% in 2013. The lower effective tax rate in 2014 is primarily related to the $6.1 million Shocking tax adjustment booked in 2013. The 2014 and 2013 effective tax rates are lower than the U.S. statutory tax rate primarily the result of income earned in low-tax jurisdictions.

[0001437749-15-003300:mdna:60]
Results of Operations — 2013 compared with 2012

[0001437749-15-003300:mdna:61]
The following table summarizes the company’s consolidated results of operations for the periods presented. The results include incremental activity from the company’s business acquisitions as described, where applicable, in the below analysis. There were also additional expenses and accounting adjustments during 2013. These include a $1.5 million inventory adjustment in 2013 as described in Note 2, and $1.7 million in acquisition related operating expenses in 2013 both related to the Hamlin acquisition. Fiscal year 2013 included $3.3 million in foreign currency gains while fiscal year 2012 included $3.2 million in foreign currency losses, both primarily related to U.S. dollar gains or losses against the Philippine peso.

[0001437749-15-003300:mdna:62]
|  |  | Fiscal Year |  |  |  |  |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | % Change |  |
| Sales |  | $ | 757,853 |  |  | $ | 667,913 |  |  |  | 13 | % |
| Gross profit |  |  | 296,232 |  |  |  | 258,467 |  |  |  | 15 | % |
| Operating expense |  |  | 166,351 |  |  |  | 151,597 |  |  |  | 10 | % |
| Operating income |  |  | 129,881 |  |  |  | 106,870 |  |  |  | 22 | % |
| Other expense (income), net |  |  | (4,646 | ) |  |  | (5,396 | ) |  |  | (14 | %) |
| Income before income taxes |  |  | 124,235 |  |  |  | 100,052 |  |  |  | 24 | % |
| Net income |  | $ | 88,784 |  |  | $ | 75,332 |  |  |  | 18 | % |

[0001437749-15-003300:mdna:63]
Net sales increased $89.9 million or 13% to $757.9 million for fiscal year 2013 compared to $667.9 million in fiscal year 2012 due primarily to an incremental $66.0 million from business acquisitions and growth in electronic and automotive products, offset by lower electrical sales. The company also experienced $1.4 million in favorable foreign currency effects in 2013 as compared to 2012 primarily resulting from sales denominated in euros partially offset by sales denominated in Japanese yen and Canadian dollars. Excluding acquisitions and currency effects, net sales increased $22.6 million or 3% year over year. The Automotive business segment sales increased $61.0 million or 30% to $267.2 million. The Electronics business segment sales increased $37.6 million or 11% to $367.1 million, and the Electrical business segment sales decreased $8.6 million or 7% to $123.6 million. Sales levels in 2013, excluding acquisitions and currency effects, were positively impacted by increased demand for the company’s automotive and electronic products partially offset by slowing demand for the company’s custom mining products.

[0001437749-15-003300:mdna:64]
The increase in Automotive sales was primarily due to an incremental $41.9 million in sales related to business acquisitions in 2013, strong worldwide growth in passenger vehicle fuses, growth in commercial vehicle products and favorable currency effects. Currency effects increased sales by $2.6 million in 2013 compared to 2012 primarily due to the euro. Excluding incremental sales from acquisitions and currency effects, Automotive sales increased $16.5 million or 8% year over year.

[0001437749-15-003300:mdna:65]
The increase in Electronics sales reflected incremental sales from Hamlin of $24.1 million, improving demand across all geographies and a slightly more favorable macroeconomic outlook. In addition, sales were negatively impacted by net unfavorable currency effects of $0.2 million, primarily from sales denominated in Japanese yen. Excluding incremental sales from acquisitions and currency effects, Electronics sales increased $13.7 million or 4% year over year.

[0001437749-15-003300:mdna:66]
The decrease in Electrical sales was primarily due to slowing demand for protection relays and custom products as a result of reduced potash mine expansion activity as well as the global downturn in the broader mining market. The decline was partially offset by stronger power fuse sales which increased 13% year-over-year primarily reflecting strength in the solar and HVAC markets as well as distributor conversions. The Electrical segment experienced net unfavorable currency effects of $1.0 million primarily from sales denominated in Canadian dollars. Excluding incremental sales from currency effects, Electrical sales decreased $7.6 million or 6% year over year.

[0001437749-15-003300:mdna:67]
On a geographic basis, sales in the Americas increased $38.8 million or 13% in 2013 as compared to 2012 primarily due to incremental sales from business acquisitions of $32.4 million offset by $1.2 million in unfavorable currency effects resulting from sales denominated in Canadian dollars. Excluding incremental sales and currency effects, Americas’ sales increased $7.6 million or 3%. This increase resulted from an increase in the company’s Automotive and Electronics business segments offset by a decline in the Electrical business segment. Automotive sales increased $31.3 million or 33% primarily reflecting incremental sales from acquisitions of $25.9 million, strong growth in the passenger vehicle market and growth in the commercial vehicle market. Electronics sales increased $14.4 million or 16% primarily reflecting incremental sales from Hamlin of $6.5 million and higher demand. Electrical sales decreased $7.0 million or 6% resulting from decreases in demand for protection relays and custom products due to continued weakness in the mining segment.

[0001437749-15-003300:mdna:68]
28

[0001437749-15-003300:mdna:69]
European sales increased $29.3 million or 27% in 2013 compared to 2012 primarily due to incremental sales from business acquisitions of $15.7 million and favorable currency effects of $3.8 million primarily from sales denominated in euros. Excluding incremental sales and currency effects, European sales increased $9.8 million or 9%. This resulted from increases in the company’s Electronics and Automotive business segments offset by a decrease in the Electrical business segment. Automotive sales increased $20.2 million or 30% in 2013 primarily reflecting incremental sales from business acquisitions of $11.7 million and higher sales in the passenger vehicle markets driven by increased content. Excluding the impact of incremental sales from acquisitions and unfavorable currency effects, primarily from a weaker euro, Automotive sales increased $6.2 million or 9%. Electronics sales increased $10.6 million or 33% reflecting incremental sales from Hamlin of $4.0 million and higher demand in 2013. Electrical sales decreased $1.6 million or 18% in 2013 primarily from decreased demand for nautical relays.

[0001437749-15-003300:mdna:70]
Asia-Pacific sales increased $21.9 million or 9% in 2013 compared to 2012 primarily due to incremental sales from business acquisitions of $17.9 million offset by unfavorable currency effects of $1.2 million primarily from sales denominated in Japanese yen. Excluding the impact of incremental sales and currency effects, Asia-Pacific sales increased $5.2 million or 2%. Electronics sales increased $12.5 million or 6% reflecting incremental sales from Hamlin of $13.4 million and increased sales in China offset by weakness in the Taiwan, Japan and Korea markets. Automotive sales increased $9.5 million or 22% reflecting incremental sales from acquisitions of $4.5 million and continued increased demand for passenger vehicles in China as well as gains in market share.

[0001437749-15-003300:mdna:71]
Gross profit was $296.2 million or 39.1% of sales in 2013, compared to $258.5 million or 38.7% of sales in 2012. Gross profit in both 2013 and 2012 were negatively impacted by purchase accounting adjustments in cost of sales of $1.5 million and $0.6 million, respectively. These charges were the additional cost of goods sold for Hamlin, Accel and Selco inventories which had been stepped up to fair value at the acquisition dates as required by purchase accounting rules. Excluding the impact of these charges, gross profit was $297.7 million or 39.3% of sales as compared to $259.1 million or 38.8% of sales in 2012. The increase in gross margin was primarily attributable to operating leverage on higher sales.

[0001437749-15-003300:mdna:72]
Total operating expense was $166.4 million or 22.0% of net sales for 2013 compared to $151.6 million or 22.7% of net sales for 2012. The increase in operating expenses primarily reflects incremental operating expenses of $12.5 million from business acquisitions and the increased cost of company incentive programs driven by improved financial performance in 2013. 2012 operating expense included $5.1 million of charges related to the settlement of pension liabilities for certain former employees. Further information regarding the company’s pension settlement charge is provided in Note 12 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:73]
Operating income was $129.9 million or 17.1% of net sales in 2013 compared to $106.9 million or 16.0% of net sales in the prior year. The increase in operating income in the current year was due primarily to the increased sales and resulting operating leverage.

[0001437749-15-003300:mdna:74]
Interest expense was $2.9 million in 2013 as compared to $1.7 million in 2012 and is primarily related to the company’s increased borrowing to fund acquisitions.

[0001437749-15-003300:mdna:75]
Impairment and equity in net loss of unconsolidated affiliate was $10.7 million in 2013. During the first quarter, the company fully impaired its investment in and loan receivable from Shocking Technologies, Inc. (“Shocking”) as described in Note 6 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:76]
Foreign exchange (gain) loss was $3.3 million of gain in 2013 compared to $3.2 million of loss in 2012. The fluctuation in foreign exchange was primarily attributable to changes in the value of the Philippine peso against the U.S. dollar in both fiscal 2013 and 2012.

[0001437749-15-003300:mdna:77]
Other expense (income), net, consisting of interest income, royalties and non-operating income was $4.6 million of income in 2013 compared to $5.4 million of income in 2012. The year-over-year decrease in income primarily reflects the impact of a $1.6 million gain on sale of fixed assets recorded in 2012 as compared to less than $0.1 million of gains recorded in 2013.

[0001437749-15-003300:mdna:78]
Income before income taxes was $124.2 million in 2013 compared to $100.1 million in 2012. Income tax expense was $35.5 million in 2013 compared to $24.7 million in 2012. The 2013 effective income tax rate was 28.5% compared to 24.7% in 2012. The higher effective tax rate in 2013 is primarily related to the $6.1 million Shocking tax adjustment booked in 2013. The 2012 and 2013 effective tax rates are lower than the statutory tax rate primarily due to the result of income earned in low-tax jurisdictions.

[0001437749-15-003300:mdna:79]
Liquidity and Capital Resources

[0001437749-15-003300:mdna:80]
As of December 27, 2014, $288.0 million of the $297.6 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $288.0 million held by foreign subsidiaries, approximately $18.7 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $18.7 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-15-003300:mdna:81]
The company historically has financed capital expenditures through cash flows from operations. Management expects that cash flows from operations and available lines of credit will be sufficient to support both the company’s operations and its debt obligations for the foreseeable future.

[0001437749-15-003300:mdna:82]
Term Loan and Revolving Credit Facilities

[0001437749-15-003300:mdna:83]
On May 31, 2013, the company entered into a new credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consists of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. At December 27, 2014, the company had available $190.9 million of borrowing capacity under the credit agreement at an interest rate of LIBOR plus 1.25% (1.42% as of December 27, 2014).

[0001437749-15-003300:mdna:84]
The credit agreement replaces the company’s previous credit agreement dated June 13, 2011, which was terminated on May 31, 2013.

[0001437749-15-003300:mdna:85]
On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million.

[0001437749-15-003300:mdna:86]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At December 27, 2014, the company was in compliance with all covenants under the credit agreement.

[0001437749-15-003300:mdna:87]
Entrusted Loan

[0001437749-15-003300:mdna:88]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.

[0001437749-15-003300:mdna:89]
Other Obligations

[0001437749-15-003300:mdna:90]
For the fiscal year ended December 27, 2014, the company had $0.8 million available in letters of credit. No amounts were drawn under these letters of credit at December 27, 2014.

[0001437749-15-003300:mdna:91]
Cash Flows and Working Capital

[0001437749-15-003300:mdna:92]
The company started 2014 with $305.2 million of cash. Net cash provided by operating activities in 2014 was approximately $153.1 million and included $99.4 million in net income and $47.8 million in non-cash adjustments (primarily $41.9 million in depreciation and amortization), and $5.9 million of favorable changes in operating assets and liabilities.

[0001437749-15-003300:mdna:93]
Changes in operating assets and liabilities (including short-term and long-term items) that negatively impacted cash flows in 2014 consisted of changes in accounts receivable ($13.1 million), inventory ($2.3 million), accrued expenses including post-retirement ($1.6 million) and accrued taxes ($0.5 million). Increases in accounts receivable and inventory resulted from higher sales volumes in 2014. Accrued expenses including post-retirement included pension contributions of $9.9 million in 2014 and $5.0 million in 2013. Positively impacting cash flows were changes in accounts payable ($17.3 million), accrued payroll and severance ($2.4 million) and prepaid expenses and other ($3.7 million). The increase in accounts payable primarily resulted from large capital purchases in December 2014 and the lengthening of vendor payment terms.

[0001437749-15-003300:mdna:94]
Net cash used in investing activities in 2014 was approximately $104.0 million and included $32.3 million in purchases of property, plant and equipment (primarily production equipment and facilities for capacity expansion and new products at the company’s locations in Piedras Negras, Mexico, Wuxi, China and the Philippines), $17.9 million related to the Entrusted Loan (see Note 7 of the Notes to Consolidated Financial Statements included in this report), $4.3 million for purchases of short-term investments and $56.4 million for the business acquisitions. Offsetting the cash used in investing activities was $0.1 million in proceeds from sales of property, plant and equipment and $6.8 million in proceeds from maturities of short-term investments.

[0001437749-15-003300:mdna:95]
31

[0001437749-15-003300:mdna:96]
Net cash used in financing activities in 2014 was approximately $43.3 million, which included $24.6 million in net borrowing, $2.8 million in excess tax benefits on share-based compensation and $14.1 million in cash proceeds from the exercise of stock options. The company also repurchased $14.3 million of its own stock in 2014. Additionally the company paid cash dividends of $21.2 million during the year and incurred $0.1 million in debt issuance costs. Information regarding the company’s debt is provided in Note 7 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:97]
The effect of exchange rate changes decreased cash by $13.5 million in 2014. The net cash provided by operating activities less net cash used in financing and provided by investing activities plus the effect of exchange rate changes, resulted in a $7.6 million decrease in cash and cash equivalents in 2014. This left the company with a cash balance of $297.6 million at December 27, 2014.

[0001437749-15-003300:mdna:98]
Days sales outstanding (DSO) in accounts receivable was 60 days at year-end 2014 compared to 59 days at year-end 2013 and 58 days at year-end 2012. Days inventory outstanding was 68 days at year-end 2014, compared to 70 days at year-end 2013 and 69 days at year-end 2012.

[0001437749-15-003300:mdna:99]
The ratio of current assets to current liabilities was 2.8 to 1 at year-end 2014, compared to 2.7 to 1 at year-end 2013 and 2.9 to 1 at year-end 2012. The change in the current ratio at the end of 2014 compared to the prior year reflected decreased current liabilities in 2014, primarily related to lower current portion of long-term debt balance and current portion of accrued pension. The carrying amounts of total debt decreased $24.6 million in 2014, compared to an increase of $135.8 million in 2013 and a decrease of $1.0 million in 2012. The decrease in 2014 is due to higher net payments under the revolving credit facility in 2014. The ratio of long-term debt to equity was 0.15 to 1 at year-end 2014 compared to 0.14 to 1 at year-end 2013 and 0.00 to 1 at year-end 2012. Further information regarding the company’s debt is provided in Note 7 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:100]
The company started 2013 with $235.4 million of cash. Net cash provided by operating activities in 2013 was approximately $117.4 million and included $88.8 million in net income and $58.3 million in non-cash adjustments (primarily $34.5 million in depreciation and amortization), partially offset by $29.7 million of changes in operating assets and liabilities.

[0001437749-15-003300:mdna:101]
Changes in operating assets and liabilities in 2013 (including short-term and long-term items) that negatively impacted cash flows in 2013 consisted of changes in accounts receivable ($16.7 million), inventory ($5.5 million), accrued expenses including post-retirement ($8.9 million) and accrued taxes ($10.8 million). Increases in accounts receivable and inventory resulted from higher sales volumes in 2013. Accrued expenses, including post-retirement, included pension contributions of $5.0 million in 2013 and $10.0 million in 2012. Positively impacting cash flows were changes in accounts payable ($2.0 million), accrued payroll and severance ($8.0 million) and prepaid expenses and other ($2.1 million).

[0001437749-15-003300:mdna:102]
The company’s capital expenditures were $32.3 million in 2014, $35.0 million in 2013 and $22.5 million in 2012.

[0001437749-15-003300:mdna:103]
The company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2014 to April 30, 2015. The company repurchased 161,751 shares of its common stock during 2014 under this program and 838,249 shares may yet be purchased under the program as of December 27, 2014. The company withheld 19,439 shares of stock in lieu of withholding taxes on behalf of employees who became vested in restricted stock option grants during 2014.

[0001437749-15-003300:mdna:104]
Contractual Obligations and Commitments

[0001437749-15-003300:mdna:105]
The following table summarizes contractual obligations and commitments as of December 27, 2014:

[0001437749-15-003300:mdna:106]
| (In thousands ) |  | Total |  |  | < 1 Year |  |  | > 1 - < 3 Years |  |  | > 3 - < 5 Years |  |  | > 5 Years |  |
| Term loan |  | $ | 93,750 |  |  | $ | 6,250 |  |  | $ | 20,000 |  |  | $ | 67,500 |  |  | $ | — |  |
| Revolving credit facility |  |  | 83,500 |  |  |  | 83,500 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Entrusted loan |  |  | 17,908 |  |  |  | — |  |  |  | — |  |  |  | 17,908 |  |  |  | — |  |
| Interest payments |  |  | 4,234 |  |  |  | 1,305 |  |  |  | 2,237 |  |  |  | 692 |  |  |  | — |  |
| U.S. Pension termination |  |  | 11,768 |  |  |  | 11,768 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Supplemental Executive Retirement Plan |  |  | 2,411 |  |  |  | 31 |  |  |  | 63 |  |  |  | 63 |  |  |  | 2,254 |  |
| Operating lease payments |  |  | 36,831 |  |  |  | 8,384 |  |  |  | 9,017 |  |  |  | 6,355 |  |  |  | 13,075 |  |
| Purchase obligations |  |  | 50,793 |  |  |  | 50,793 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 301,195 |  |  | $ | 162,031 |  |  | $ | 31,317 |  |  | $ | 92,518 |  |  | $ | 15,329 |  |

[0001437749-15-003300:mdna:107]
Off-Balance Sheet Arrangements

[0001437749-15-003300:mdna:108]
As of December 27, 2014, the company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the company was not liable for guarantees of indebtedness owed by third parties, the company was not directly liable for the debt of any unconsolidated entity and the company did not have any retained or contingent interest in assets. The company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-15-003300:mdna:109]
Recent Accounting Pronouncements

[0001437749-15-003300:mdna:110]
In May 2014, the Financial Accounting Standards Board (FASB) amended prior authoritative guidance for revenue recognition which provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The standard is effective for public entities for annual and interim periods beginning after December 15, 2016. Early adoption is not permitted. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The company is currently evaluating the impact of the adoption of this accounting standard on its consolidated financial statements.

[0001437749-15-003300:mdna:111]
In February 2013, the FASB issued authoritative guidance on the reporting of amounts reclassified out of accumulated other comprehensive income into net income or the balance sheet. Under the new guidance, in addition to the presentation of changes in accumulated balances, an entity shall present separately for each component of other comprehensive income, significant current period reclassifications out of accumulated other comprehensive income and other amounts of current-period other comprehensive income. Both before-tax and net-of-tax presentations are permitted. The guidance is effective for reporting periods beginning after December 15, 2013. The company adopted the guidance on December 28, 2013. There was no significant effect on its consolidated financial statements upon adoption.

[0001437749-15-003300:mdna:112]
Critical Accounting Policies and Estimates

[0001437749-15-003300:mdna:113]
Certain of the accounting policies as discussed below require the application of significant judgment by management in selecting the appropriate estimates and assumptions for calculating amounts to record in the financial statements. Actual results could differ from those estimates and assumptions, impacting the reported results of operations and financial position. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report. Certain accounting policies, however, are considered to be critical in that they are most important to the depiction of the company’s financial condition and results of operations and their application requires management’s subjective judgment in making estimates about the effect of matters that are inherently uncertain. The company believes the following accounting policies are the most critical to aid in fully understanding and evaluating its reported financial results, as they require management’s most difficult, subjective or complex judgments, resulting from the need to make estimates about the effect of matters that are inherently uncertain. The company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors.

[0001437749-15-003300:mdna:114]
Net Sales

[0001437749-15-003300:mdna:115]
Revenue Recognition: The company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured and the pricing is fixed and determinable. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The company’s distribution channels are primarily through direct sales and independent third party distributors.

[0001437749-15-003300:mdna:116]
Revenue and Billing: The company accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the company’s published price lists. The customer is invoiced when the company’s products are shipped to them in accordance with the terms of the sales agreement.

[0001437749-15-003300:mdna:117]
Returns and Credits: Some of the terms of the company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-15-003300:mdna:118]
Return to Stock: The company has a return to stock policy whereby a customer with previous authorization from Littelfuse management can return previously purchased goods for full or partial credit. The company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0001437749-15-003300:mdna:119]
Volume Rebates: The company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-15-003300:mdna:120]
Allowance for Doubtful Accounts: The company evaluates the collectability of its trade receivables based on a combination of factors. The company regularly analyzes its significant customer accounts and, when the company becomes aware of a specific customer’s inability to meet its financial obligations, the company records a specific reserve for bad debt to reduce the related receivable to the amount the company reasonably believes is collectible. The company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0001437749-15-003300:mdna:121]
Inventory

[0001437749-15-003300:mdna:122]
The company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life and quality issues. Based on the analysis, the company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable values. During 2014, 2013 and 2012, the company was required to step up the value of inventory acquired in business combinations to its selling prices less the cost to sell under business combination accounting. This was approximately $2.8 million for SymCom in 2014, $1.5 million for Hamlin in 2013 and $0.6 million in 2012 for Accel and Selco.

[0001437749-15-003300:mdna:123]
Goodwill and Other Intangible Assets

[0001437749-15-003300:mdna:124]
The company annually tests goodwill for impairment on the first day of its fiscal fourth quarter or at an interim date if there is an event or change in circumstances that indicates the asset may be impaired. The company has eight reporting units for goodwill testing purposes. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted five-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after five years) to estimate market value. In addition, the company compares its derived enterprise value on a consolidated basis to the company’s market capitalization as of its test date to ensure its derived value approximates the market value of the company when taken as a whole.

[0001437749-15-003300:mdna:125]
As of the most recent annual test conducted on September 27, 2014, the company concluded the fair value of each of the reporting units exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. Specifically, the company noted that its headroom, defined as the excess of fair value over the carrying value of invested capital, was 114%, 128%, 128%, 190%, 26%, 6%, 82% and 83% for its electronics (non-silicon), electronics (silicon), passenger car, commercial vehicle products, sensors, relays, custom products and fuse reporting units, respectively, at September 27, 2014. Certain key assumptions used in the annual test included a discount rate of 11.8% and a long-term growth rate of 3.0% was used for all reporting units except for relay which had a discount rate of 12.8% as a result of a 1.0% premium factor.

[0001437749-15-003300:mdna:126]
In addition, the company performed a sensitivity test at September 27, 2014 that showed either a 100 basis point increase in its discount rate or a 100 basis point decrease in the long-term growth rate for each reporting unit would not have changed the company’s conclusion that no potential goodwill impairment existed at September 27, 2014.

[0001437749-15-003300:mdna:127]
The company will continue to perform a goodwill impairment test as required on an annual basis and on an interim basis, if certain conditions exist. Factors the company considers important, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the company does not believe its future operating results will vary significantly relative to its historical and projected future operating results.

[0001437749-15-003300:mdna:128]
Long-Lived Assets

[0001437749-15-003300:mdna:129]
The company evaluates long-lived asset groups on an ongoing basis. Long-lived asset groups are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the related asset may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of the asset to future undiscounted cash flows expected to be generated by the asset group. If it is determined to be impaired, the impairment recognized is measured by the amount by which the carrying value of the asset exceeds its fair value. The company’s estimates of future cash flows from such assets could be impacted if it underperforms relative to historical or projected future operating results. The company recorded asset impairment charges of $0.3 million, $0.0 million and $0.5 million for the fiscal years ended 2014, 2013 and 2012, respectively. Further information regarding asset impairments is provided in Note 11 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:130]
The company evaluates its investments quarterly or when there is an indicator of a potential impairment. During the fourth quarter of 2012, company management determined that an indicator of impairment existed for the company’s investment in Shocking Technologies, Inc. Subsequently, the company engaged a third party asset valuation firm to perform an analysis for purposes of assisting management in determining the amount of impairment. Further information regarding the impairment of the company’s investment in Shocking Technologies, Inc. is provided in Note 6 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:131]
Environmental Liabilities

[0001437749-15-003300:mdna:132]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The company evaluates its reserve for coal mine remediation annually utilizing a third party expert.

[0001437749-15-003300:mdna:133]
Pension and Supplemental Executive Retirement Plan

[0001437749-15-003300:mdna:134]
Littelfuse has a number of company-sponsored defined benefit plans primarily in North America, Europe and the Asia-Pacific region. The company recognizes the full unfunded status of these plans on the balance sheet. Actuarial gains and losses and prior service costs and credits are recognized as a component of accumulated other comprehensive income. Accounting for pensions requires estimating the future benefit cost and recognizing the cost over the employee’s expected period of employment with the company. Certain assumptions are required in the calculation of pension costs and obligations. These assumptions include the discount rate, salary scales and the expected long-term rate of return on plan assets. The discount rate is intended to represent the rate at which pension benefit obligations could be settled by purchase of an annuity contract. These assumptions are subject to change based on stock and bond market returns and other economic factors. Actual results that differ from the company’s assumptions are accumulated and amortized over future periods and, therefore, generally affect its recognized expense and accrued liability in such future periods. While the company believes that its assumptions are appropriate given current economic conditions and its actual experience, significant differences in results or significant changes in the company’s assumptions may materially affect its pension obligations and related future expense. Further information regarding these plans is provided in Note 12 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:135]
Equity-based Compensation

[0001437749-15-003300:mdna:136]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments in the foreseeable future.

[0001437749-15-003300:mdna:137]
Total equity-based compensation expense for all equity compensation plans was $9.4 million, $8.9 million, and $7.3 million in 2014, 2013, and 2012, respectively. Further information regarding this expense is provided in Note 13 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:138]
Income Taxes

[0001437749-15-003300:mdna:139]
The company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. Federal and state income taxes are provided on the portion of foreign income that is expected to be remitted to the U.S. and be taxable.

[0001437749-15-003300:mdna:140]
The company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001437749-15-003300:mdna:141]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14 of the Notes to Consolidated Financial Statements included in this report.

[0001437749-15-003300:mdna:142]
Outlook

[0001437749-15-003300:mdna:143]
Sales for the first quarter of 2015 are expected to be in the range of $202.0 to $212.0 million which represents flat revenue at the midpoint compared to the prior year after currency effects (approximately 4% growth in constant currency). Earnings for the first quarter of 2015 are expected to be in the range of $1.00 to $1.14 per diluted share. This includes negative currency effects of approximately $0.10 compared to the prior year.

[0001437749-15-003300:mdna:144]
For the year 2015, the company expects to face substantial currency headwinds. At current exchange rates, sales would be negatively impacted by approximately $30 million and earnings by approximately $0.40 per share compared to 2014. The company has planned improvements in the Electrical, Automotive sensor and commercial vehicle businesses and believes it can achieve modest sales growth and earnings in 2015.

[0001437749-15-003300:mdna:145]
The company expects capital expenditures in 2015 to be in the range of $35 to $40 million primarily for capacity to support volume increases, new product introductions and restructuring activities. The company expects to fund 2015 capital expansion from operating cash flows.
