# LFUS 8-K — 0001437749-15-001708 filed 2015-02-04

## item codes, every 8-K on or before 2015-02-24

- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2015-02-24

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-15-001708:8k_2_02:1]
EX-99
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-15-001708:8k_2_02:2]
ex99-1.htm

[0001437749-15-001708:8k_2_02:3]
Exhibit 99.1

[0001437749-15-001708:8k_2_02:4]
| NEWS RELEASE |  |

[0001437749-15-001708:8k_2_02:5]
CONTACT: Phil Franklin,

[0001437749-15-001708:8k_2_02:6]
Senior Vice President and CFO (773) 628-0810

[0001437749-15-001708:8k_2_02:7]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS

[0001437749-15-001708:8k_2_02:8]
CHICAGO, February 4, 2015 – Littelfuse, Inc. (NASDAQ:LFUS) today reported sales and earnings for the fourth quarter and fiscal year ending December 27, 2014.

[0001437749-15-001708:8k_2_02:9]
Fourth Quarter Highlights

[0001437749-15-001708:8k_2_02:10]
|  | ● | Sales for the fourth quarter of 2014 were $207 million, a 4% increase (7% excluding currency effects) compared to the prior-year quarter due primarily to continued strong growth in the automotive business. Excluding acquisitions, sales increased 2% (4% excluding currency effects) compared to the prior year. |

[0001437749-15-001708:8k_2_02:11]
|  | ● | On a GAAP basis, fourth quarter 2014 earnings were $0.86 per diluted share. This included $4.7 million of special items comprised primarily of restructuring charges and non-operating foreign exchange losses related to balance sheet revaluation (see Supplemental Financial Information on page 9). Excluding these special items, earnings for the fourth quarter of 2014 were $1.02 per diluted share. |

[0001437749-15-001708:8k_2_02:12]
|  | ● | In addition to the restructuring charges mentioned above, operating income for the fourth quarter was negatively impacted by the following: |

[0001437749-15-001708:8k_2_02:13]
|  | o | Foreign currency effects primarily related to the company’s long euro exposure. In total these currency effects negatively affected operating income by approximately $2.1 million in the fourth quarter. |

[0001437749-15-001708:8k_2_02:14]
|  | o | Year-end true up of certain accruals including those for customer credits, inventory reserves and medical and post-retirement plans. In total these expenses negatively affected operating income by approximately $1.9 million in the fourth quarter. |

[0001437749-15-001708:8k_2_02:15]
|  | o | Performance issues at a few of the company’s plants including reduced production volumes and higher overhead expenses. In total these plant performance issues negatively affected operating income by approximately $1.0 million in the fourth quarter. |

[0001437749-15-001708:8k_2_02:16]
|  | ● | The effective tax rate for the fourth quarter was favorably impacted by the mix of income (less income in high tax jurisdictions) and various favorable adjustments. |

[0001437749-15-001708:8k_2_02:17]
-more-

[0001437749-15-001708:8k_2_02:18]
|  | ● | Sales trends by business unit for the fourth quarter were as follows: |

[0001437749-15-001708:8k_2_02:19]
|  | o | Electronics sales increased 1% year over year (3% excluding currency effects) reflecting sales growth in constant currency in all regions. |

[0001437749-15-001708:8k_2_02:20]
|  | o | Automotive sales increased 10% year over year (14% excluding currency effects) reflecting growth across all product categories and all regions. |

[0001437749-15-001708:8k_2_02:21]
|  | o | Electrical sales were flat year over year. Excluding the effects of the SymCom acquisition and currency, electrical sales declined 12% year over year due primarily to continued weakness in mining and lower sales into the solar market. As expected, sales of the company’s custom products increased compared to the third quarter of 2014. |

[0001437749-15-001708:8k_2_02:22]
|  | ● | The electronics book-to-bill ratio for the fourth quarter of 2014 was 1.06 (1.00 excluding Sensors). |

[0001437749-15-001708:8k_2_02:23]
|  | ● | Cash provided by operating activities was $49.3 million for the fourth quarter of 2014 compared to $31.6 million for the fourth quarter of 2013. Capital expenditures for the fourth quarter of 2014 were $12.9 million compared to $9.6 million for the fourth quarter of 2013. |

[0001437749-15-001708:8k_2_02:24]
Full Year Highlights

[0001437749-15-001708:8k_2_02:25]
|  | ● | Sales for 2014 were $852.0 million, a 12.4% increase compared to 2013. Organic growth for the year was 5.0% and acquisition growth was 7.4%. |

[0001437749-15-001708:8k_2_02:26]
|  | ● | On a GAAP basis, 2014 earnings were $4.37 per diluted share, an 11% increase compared to 2013. |

[0001437749-15-001708:8k_2_02:27]
|  | ● | Excluding special items, 2014 earnings were $4.78 per diluted share, a 7% increase compared to 2013. |

[0001437749-15-001708:8k_2_02:28]
|  | ● | Cash flow from operating activities for 2014 was $153.1 million, a 30% increase compared to 2013. |

[0001437749-15-001708:8k_2_02:29]
“After strong performance for the first three quarters of the year, fourth quarter earnings were below our expectations,” said Gordon Hunter, Chief Executive Officer. “The combination of unfavorable currency effects, non-recurring charges and poor execution in a few areas of the business made for a challenging quarter. While we will continue to be impacted by currency headwinds for the foreseeable future, we will also be taking a number of corrective actions including selective price increases, more aggressive expense controls and, where possible, moving faster on our various restructuring efforts.”

[0001437749-15-001708:8k_2_02:30]
“Despite the disappointing results for the fourth quarter, our full year performance was solid,” said Phil Franklin, Chief Financial Officer. “Cash flow continues to be a bright spot as we generated cash from operating activities of $153.1 million for 2014. This beat our previous record by over $30 million.”

[0001437749-15-001708:8k_2_02:31]
-more-

[0001437749-15-001708:8k_2_02:32]
Outlook.

[0001437749-15-001708:8k_2_02:33]
|  | ● | Sales for the first quarter of 2015 are expected to be in the range of $202 to $212 million which represents flat revenue at the midpoint compared to the prior year after currency effects (approximately 4% growth in constant currency). |

[0001437749-15-001708:8k_2_02:34]
|  | ● | Earnings for the first quarter of 2015 are expected to be in the range of $1.00 to $1.14 per diluted share. This includes negative currency effects of approximately $0.10 compared to the prior year. |

[0001437749-15-001708:8k_2_02:35]
“It now seems likely that we will be facing currency headwinds for much of 2015,” said Franklin. “At the current exchange rates, we estimate that sales would be negatively impacted by approximately $30 million and earnings by approximately 40 cents per share compared to 2014. Nevertheless, with our planned improvements in the electrical, automotive sensor and CVP businesses, continued solid performance in the core automotive and electronics businesses and a lower tax rate, we believe we can achieve 2015 earnings above $5.00 per share.

[0001437749-15-001708:8k_2_02:36]
Dividend

[0001437749-15-001708:8k_2_02:37]
The company will pay a cash dividend of $0.25 per common share on March 5, 2015 to shareholders of record at the close of business on February 13, 2015.

[0001437749-15-001708:8k_2_02:38]
Conference Call and Webcast Information

[0001437749-15-001708:8k_2_02:39]
Littelfuse will host a conference call today, Wednesday, February 4, 2015, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the fourth quarter results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay through March 31, 2015 on the company’s website.

[0001437749-15-001708:8k_2_02:40]
About Littelfuse

[0001437749-15-001708:8k_2_02:41]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 8,000 employees in more than 35 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: littelfuse.com.

[0001437749-15-001708:8k_2_02:42]
-more-

[0001437749-15-001708:8k_2_02:43]
| “Safe Harbor” Statement under the Private Securities Litigation Reform Act of 1995. The statements in this press release that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended December 28, 2013. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended December 28, 2013. |

[0001437749-15-001708:8k_2_02:44]
# # #

[0001437749-15-001708:8k_2_02:45]
LITTELFUSE, INC.

[0001437749-15-001708:8k_2_02:46]
Net Sales and Operating Income by Business Unit

[0001437749-15-001708:8k_2_02:47]
(In thousands of USD, unaudited)

[0001437749-15-001708:8k_2_02:48]
|  |  | Fourth Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics (2) |  | $ | 96,339 |  |  | $ | 95,174 |  |  |  | 1% |  |  | $ | 410,065 |  |  | $ | 367,052 |  |  |  | 12% |  |
| Automotive (3) |  |  | 80,332 |  |  |  | 72,888 |  |  |  | 10% |  |  |  | 325,415 |  |  |  | 267,207 |  |  |  | 22% |  |
| Electrical (4) |  |  | 29,949 |  |  |  | 30,067 |  |  |  | (0%) |  |  |  | 116,515 |  |  |  | 123,594 |  |  |  | (6%) |  |
| Total net sales (1) |  | $ | 206,620 |  |  | $ | 198,129 |  |  |  | 4% |  |  | $ | 851,995 |  |  | $ | 757,853 |  |  |  | 12% |  |

[0001437749-15-001708:8k_2_02:49]
| (1) | Total net sales for 2014 include an incremental $4.3M for the quarter and $56.1M year-to-date from business acquisitions. |
| (2) | Total Electronics net sales for 2014 include an incremental $16.3M year-to-date from the Hamlin acquisition. |
| (3) | Total Automotive net sales for 2014 include an incremental $20.2M year-to-date from the Hamlin acquisition. |
| (4) | Total Electrical net sales for 2014 include an incremental $4.3M for the quarter and $19.6M year-to-date from the SymCom acquisition. |

[0001437749-15-001708:8k_2_02:50]
|  |  | Fourth Quarter |  |  | Year-to-Date |  |
|  |  | 2014 |  |  | 2013 |  |  | % Change |  |  | 2014 |  |  | 2013 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 16,176 |  |  | $ | 17,275 |  |  |  | (6%) |  |  | $ | 86,981 |  |  | $ | 69,559 |  |  |  | 25% |  |
| Automotive |  |  | 9,928 |  |  |  | 9,639 |  |  |  | 3% |  |  |  | 45,086 |  |  |  | 39,170 |  |  |  | 15% |  |
| Electrical |  |  | 3,133 |  |  |  | 5,562 |  |  |  | (44%) |  |  |  | 10,674 |  |  |  | 24,363 |  |  |  | (56%) |  |
| Other (5) |  |  | (2,846 | ) | (6) |  | 347 |  |  |  | (920%) |  |  |  | (8,911 | ) |  |  | (3,211 | ) |  |  | 178% |  |
| Total operating income |  | $ | 26,391 |  |  | $ | 32,823 |  |  |  | (20%) |  |  | $ | 133,830 |  |  | $ | 129,881 |  |  |  | 3% |  |
| Interest expense |  |  | 1,167 |  |  |  | 958 |  |  |  |  |  |  |  | 4,903 |  |  |  | 2,917 |  |  |  |  |  |
| Investment impairment |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |  |  | 10,678 |  | (7) |  |  |  |
| Foreign exchange (gain) loss |  |  | 1,903 |  |  |  | (1,374 | ) |  |  |  |  |  |  | 3,925 |  |  |  | (3,303 | ) |  |  |  |  |
| Other (income) expense, net |  |  | (1,751 | ) |  |  | (1,103 | ) |  |  |  |  |  |  | (6,644 | ) |  |  | (4,646 | ) |  |  |  |  |
| Income before taxes |  | $ | 25,072 |  |  | $ | 34,342 |  |  |  | (27%) |  |  | $ | 131,646 |  |  | $ | 124,235 |  |  |  | 6% |  |

[0001437749-15-001708:8k_2_02:51]
| (5) | "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. |
| (6) | Primarily consists of tax consulting and legal expenses to effect changes in the company's legal structure that will enable the up-streaming of cash to the U.S. ($1.1M), severance and restructuring charges at various locations ($1.2M), acquisition-related expenses ($0.3M) and asset impairments ($0.3M). |
| (7) | Impairment and loan losses from investment in Shocking Technologies. |

[0001437749-15-001708:8k_2_02:52]
-more-

[0001437749-15-001708:8k_2_02:53]
LITTELFUSE, INC.

[0001437749-15-001708:8k_2_02:54]
Condensed Consolidated Balance Sheets

[0001437749-15-001708:8k_2_02:55]
(In thousands of USD, except share amounts)

[0001437749-15-001708:8k_2_02:56]
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 297,571 |  |  | $ | 305,192 |  |
| Short-term investments |  |  | 4,302 |  |  |  | 6,886 |  |
| Accounts receivable, less allowances |  |  | 135,356 |  |  |  | 127,887 |  |
| Inventories |  |  | 97,391 |  |  |  | 92,591 |  |
| Deferred income taxes |  |  | 17,481 |  |  |  | 10,463 |  |
| Prepaid expenses and other current assets |  |  | 13,904 |  |  |  | 17,080 |  |
| Assets held for sale |  |  | 5,500 |  |  |  | 5,500 |  |
| Total current assets |  |  | 571,505 |  |  |  | 565,599 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 5,697 |  |  |  | 4,382 |  |
| Buildings |  |  | 64,609 |  |  |  | 59,699 |  |
| Equipment |  |  | 370,179 |  |  |  | 354,475 |  |
|  |  |  | 440,485 |  |  |  | 418,556 |  |
| Accumulated depreciation |  |  | (281,845 | ) |  |  | (268,383 | ) |
| Net property, plant and equipment |  |  | 158,640 |  |  |  | 150,173 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 23,640 |  |  |  | 25,166 |  |
| Distribution network |  |  | 19,428 |  |  |  | 22,770 |  |
| Customer lists, trademarks and tradenames |  |  | 60,605 |  |  |  | 50,421 |  |
| Goodwill |  |  | 196,256 |  |  |  | 186,464 |  |
|  |  |  | 299,929 |  |  |  | 284,821 |  |
| Investments |  |  | 12,056 |  |  |  | 12,286 |  |
| Deferred income taxes |  |  | 5,393 |  |  |  | 5,092 |  |
| Other assets |  |  | 23,303 |  |  |  | 6,402 |  |
| Total assets |  | $ | 1,070,826 |  |  | $ | 1,024,373 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 50,793 |  |  | $ | 33,872 |  |
| Accrued payroll |  |  | 30,511 |  |  |  | 29,437 |  |
| Accrued expenses |  |  | 13,059 |  |  |  | 13,087 |  |
| Accrued severance |  |  | 790 |  |  |  | 182 |  |
| Accrued income taxes |  |  | 9,045 |  |  |  | 5,931 |  |
| Deferred income taxes |  |  | - |  |  |  | 229 |  |
| Current portion of accrued post-retirement benefits |  |  | 11,768 |  |  |  | - |  |
| Current portion of long-term debt |  |  | 88,500 |  |  |  | 126,000 |  |
| Total current liabilities |  |  | 204,466 |  |  |  | 208,738 |  |
| Long-term debt, less current portion |  |  | 106,658 |  |  |  | 93,750 |  |
| Deferred income taxes |  |  | 11,076 |  |  |  | 11,585 |  |
| Accrued post-retirement benefits |  |  | 5,147 |  |  |  | 8,528 |  |
| Other long-term liabilities |  |  | 15,814 |  |  |  | 14,856 |  |
| Total equity |  |  | 727,665 |  |  |  | 686,916 |  |
| Total liabilities and equity |  | $ | 1,070,826 |  |  | $ | 1,024,373 |  |

[0001437749-15-001708:8k_2_02:57]
Common shares issued and outstanding of 22,585,529 and 22,467,491 at December 27, 2014 and December 28, 2013, respectively.

[0001437749-15-001708:8k_2_02:58]
-more-

[0001437749-15-001708:8k_2_02:59]
LITTELFUSE, INC.

[0001437749-15-001708:8k_2_02:60]
Consolidated Statements of Comprehensive Income

[0001437749-15-001708:8k_2_02:61]
(In thousands of USD, except per share data, unaudited)

[0001437749-15-001708:8k_2_02:62]
|  |  | For the Three Months Ended |  |  | For the Twelve Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| Net sales |  | $ | 206,620 |  |  | $ | 198,129 |  |  | $ | 851,995 |  |  | $ | 757,853 |  |
| Cost of sales |  |  | 131,061 |  |  |  | 121,020 |  |  |  | 527,567 |  |  |  | 461,621 |  |
| Gross profit |  |  | 75,559 |  |  |  | 77,109 |  |  |  | 324,428 |  |  |  | 296,232 |  |
| Selling, general and administrative |  |  | 37,829 |  |  |  | 34,566 |  |  |  | 146,975 |  |  |  | 132,657 |  |
| Research and development expenses |  |  | 8,289 |  |  |  | 6,690 |  |  |  | 31,122 |  |  |  | 24,415 |  |
| Amortization of intangibles |  |  | 3,050 |  |  |  | 3,030 |  |  |  | 12,501 |  |  |  | 9,279 |  |
|  |  |  | 49,168 |  |  |  | 44,286 |  |  |  | 190,598 |  |  |  | 166,351 |  |
| Operating income |  |  | 26,391 |  |  |  | 32,823 |  |  |  | 133,830 |  |  |  | 129,881 |  |
| Interest expense |  |  | 1,167 |  |  |  | 958 |  |  |  | 4,903 |  |  |  | 2,917 |  |
| Impairment and loan loss in unconsolidated affiliate |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10,678 |  |
| Foreign currency revaluation (income) expense |  |  | 1,903 |  |  |  | (1,374 | ) |  |  | 3,925 |  |  |  | (3,303 | ) |
| Other (income) expense, net |  |  | (1,751 | ) |  |  | (1,103 | ) |  |  | (6,644 | ) |  |  | (4,646 | ) |
| Income before income taxes |  |  | 25,072 |  |  |  | 34,342 |  |  |  | 131,646 |  |  |  | 124,235 |  |
| Income taxes |  |  | 5,561 |  |  |  | 10,684 |  |  |  | 32,228 |  |  |  | 35,451 |  |
| Net income |  | $ | 19,511 |  |  | $ | 23,658 |  |  | $ | 99,418 |  |  | $ | 88,784 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | 1.05 |  |  | $ | 4.41 |  |  | $ | 3.98 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 1.04 |  |  | $ | 4.37 |  |  | $ | 3.94 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,563 |  |  |  | 22,440 |  |  |  | 22,543 |  |  |  | 22,315 |  |
| Diluted |  |  | 22,729 |  |  |  | 22,657 |  |  |  | 22,727 |  |  |  | 22,537 |  |
| Diluted Net Income Per Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 19,511 |  |  | $ | 23,658 |  |  | $ | 99,418 |  |  | $ | 88,784 |  |
| Less: income allocated to participating securities |  |  | - |  |  |  | (6 | ) |  |  | - |  |  |  | (51 | ) |
| Net income available to common shareholders |  | $ | 19,511 |  |  | $ | 23,652 |  |  | $ | 99,418 |  |  | $ | 88,733 |  |
| Weighted average shares adjusted for securities |  |  | 22,729 |  |  |  | 22,657 |  |  |  | 22,727 |  |  |  | 22,537 |  |
| Diluted net income per share |  | $ | 0.86 |  |  | $ | 1.04 |  |  | $ | 4.37 |  |  | $ | 3.94 |  |
| Comprehensive (loss) income |  | $ | (8,569 | ) |  | $ | 27,022 |  |  | $ | 57,875 |  |  | $ | 92,653 |  |

[0001437749-15-001708:8k_2_02:63]
-more-

[0001437749-15-001708:8k_2_02:64]
LITTELFUSE, INC.

[0001437749-15-001708:8k_2_02:65]
Consolidated Statements of Cash Flows

[0001437749-15-001708:8k_2_02:66]
(In thousands of USD, unaudited)

[0001437749-15-001708:8k_2_02:67]
|  |  | For the Twelve Months Ended |  |
|  |  | December 27, 2014 |  |  | December 28, 2013 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 99,418 |  |  | $ | 88,784 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 29,374 |  |  |  | 25,201 |  |
| Amortization of intangibles |  |  | 12,501 |  |  |  | 9,279 |  |
| Impairment and loan loss in unconsolidated affiliate |  |  | - |  |  |  | 10,678 |  |
| Provision for bad debts |  |  | 130 |  |  |  | 289 |  |
| Non-cash inventory charge (1) |  |  | 2,769 |  |  |  | 1,525 |  |
| Stock-based compensation |  |  | 9,069 |  |  |  | 8,609 |  |
| Excess tax benefit on stock-based compensation |  |  | (2,843 | ) |  |  | (4,054 | ) |
| Loss on sale of assets |  |  | 1,042 |  |  |  | 92 |  |
| Deferred income taxes |  |  | (4,488 | ) |  |  | 6,640 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (13,062 | ) |  |  | (16,683 | ) |
| Inventories |  |  | (2,258 | ) |  |  | (5,486 | ) |
| Accounts payable |  |  | 17,281 |  |  |  | 2,000 |  |
| Accrued expenses (including post retirement) |  |  | (1,577 | ) |  |  | (8,906 | ) |
| Accrued payroll and severance |  |  | 2,360 |  |  |  | 8,032 |  |
| Accrued taxes |  |  | (549 | ) |  |  | (10,773 | ) |
| Prepaid expenses and other |  |  | 3,974 |  |  |  | 2,140 |  |
| Net cash provided by operating activities |  |  | 153,141 |  |  |  | 117,367 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (32,281 | ) |  |  | (34,953 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (56,368 | ) |  |  | (144,382 | ) |
| Purchase of short-term investments |  |  | (4,331 | ) |  |  | (8,478 | ) |
| Proceeds from maturities of short-term investments |  |  | 6,770 |  |  |  | 2,044 |  |
| Increase in entrusted loan receivable |  |  | (17,908 | ) |  |  | - |  |
| Proceeds from sale of assets |  |  | 125 |  |  |  | 176 |  |
| Net cash used in investing activities |  |  | (103,993 | ) |  |  | (185,593 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds from term loan |  |  | - |  |  |  | 100,000 |  |
| Proceeds of revolving credit facility |  |  | 97,500 |  |  |  | 160,500 |  |
| Proceeds from entrusted loan |  |  | 17,908 |  |  |  | - |  |
| Payments of term loan |  |  | (5,000 | ) |  |  | (1,250 | ) |
| Payments of revolving credit facility |  |  | (135,000 | ) |  |  | (123,500 | ) |
| Debt issuance costs paid |  |  | (107 | ) |  |  | (809 | ) |
| Cash dividends paid |  |  | (21,175 | ) |  |  | (18,722 | ) |
| Purchase of common stock |  |  | (14,283 | ) |  |  | - |  |
| Proceeds from exercise of stock options |  |  | 14,061 |  |  |  | 21,959 |  |
| Excess tax benefit on stock-based compensation |  |  | 2,843 |  |  |  | 4,054 |  |
| Net cash (used in) provided by financing activities |  |  | (43,253 | ) |  |  | 142,232 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (13,516 | ) |  |  | (4,218 | ) |
| Increase in cash and cash equivalents |  |  | (7,621 | ) |  |  | 69,788 |  |
| Cash and cash equivalents at beginning of period |  |  | 305,192 |  |  |  | 235,404 |  |
| Cash and cash equivalents at end of period |  | $ | 297,571 |  |  | $ | 305,192 |  |

[0001437749-15-001708:8k_2_02:68]
| (1) | Purchase accounting adjustment related to acquisitions. |

[0001437749-15-001708:8k_2_02:69]
-more-

[0001437749-15-001708:8k_2_02:70]
LITTELFUSE, INC.

[0001437749-15-001708:8k_2_02:71]
Supplemental Financial Information

[0001437749-15-001708:8k_2_02:72]
(in millions of USD except share amounts)

[0001437749-15-001708:8k_2_02:73]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | Q4-14 |  |  | YTD-14 |  |  | Q1-13 |  |  | Q2-13 |  |  | Q3-13 |  |  | Q4-13 |  |  | YTD-13 |  |
| GAAP diluted EPS |  | $ | 1.12 |  |  | $ | 1.08 |  |  | $ | 1.32 |  |  | $ | 0.86 |  |  | $ | 4.37 |  |  | $ | 0.51 |  |  | $ | 1.18 |  |  | $ | 1.19 |  |  | $ | 1.04 |  |  | $ | 3.94 |  |
| EPS impact of special items (below) |  |  | 0.04 |  |  |  | 0.18 |  |  |  | 0.03 |  |  |  | 0.16 |  |  |  | 0.41 |  |  |  | 0.44 |  |  |  | (0.03 | ) |  |  | 0.07 |  |  |  | 0.04 |  |  |  | 0.52 |  |
| Adjusted diluted EPS |  | $ | 1.16 |  |  | $ | 1.26 |  |  | $ | 1.35 |  |  | $ | 1.02 |  |  | $ | 4.78 |  |  | $ | 0.95 |  |  | $ | 1.15 |  |  | $ | 1.26 |  |  | $ | 1.08 |  |  | $ | 4.46 |  |
| Year-over-year adjusted EPS growth |  |  | 22 | % |  |  | 10 | % |  |  | 7 | % |  |  | -6 | % |  |  | 7 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Special Items (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 2.8 |  |  | $ | - |  |  | $ | 1.7 |  |  | $ | 0.3 |  |  | $ | (0.5 | ) |  | $ | 1.5 |  |
| Restructuring |  |  | - |  |  |  | 2.0 |  |  |  | 1.1 |  |  |  | 2.2 |  |  |  | 5.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Impairment charges |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.3 |  |  |  | 0.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Acquisition expenses |  |  | - |  |  |  | 0.2 |  |  |  | - |  |  |  | 0.3 |  |  |  | 0.5 |  |  |  | - |  |  |  | 1.2 |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 1.7 |  |
| Adjustment to Operating income |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 2.8 |  |  |  | 8.9 |  |  |  | - |  |  |  | 2.9 |  |  |  | 0.6 |  |  |  | (0.3 | ) |  |  | 3.2 |  |
| Impairment charges |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10.7 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10.7 |  |
| Foreign exchange (gain)/loss |  |  | (0.3 | ) |  |  | 2.4 |  |  |  | (0.1 | ) |  |  | 1.9 |  |  |  | 3.9 |  |  |  | - |  |  |  | (3.7 | ) |  |  | 1.5 |  |  |  | (1.4 | ) |  |  | (3.6 | ) |
| Adjustment to pre-tax income |  | $ | 1.2 |  |  | $ | 5.9 |  |  | $ | 1.0 |  |  | $ | 4.7 |  |  | $ | 12.8 |  |  | $ | 10.7 |  |  | $ | (0.8 | ) |  | $ | 2.1 |  |  | $ | (1.7 | ) |  | $ | 10.3 |  |
| EPS impact of above special items |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.03 |  |  | $ | 0.16 |  |  | $ | 0.41 |  |  | $ | 0.29 |  |  | $ | (0.03 | ) |  | $ | 0.07 |  |  | $ | (0.06 | ) |  | $ | 0.27 |  |
| EPS impact of Shocking tax adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.15 |  |  |  | - |  |  |  | - |  |  |  | 0.12 |  |  |  | 0.27 |  |
| EPS impact of other special tax items |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.02 | ) |  |  | (0.02 | ) |
| Total EPS impact |  | $ | 0.04 |  |  | $ | 0.18 |  |  | $ | 0.03 |  |  | $ | 0.16 |  |  | $ | 0.41 |  |  | $ | 0.44 |  |  | $ | (0.03 | ) |  | $ | 0.07 |  |  | $ | 0.04 |  |  | $ | 0.52 |  |
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-14 |  |  | Q2-14 |  |  | Q3-14 |  |  | Q4-14 |  |  | YTD-14 |  |  | Q1-13 |  |  | Q2-13 |  |  | Q3-13 |  |  | Q4-13 |  |  | YTD-13 |  |
| Net sales |  | $ | 206.9 |  |  | $ | 220.9 |  |  | $ | 217.6 |  |  | $ | 206.6 |  |  | $ | 852.0 |  |  | $ | 170.9 |  |  | $ | 187.8 |  |  | $ | 201.0 |  |  | $ | 198.1 |  |  | $ | 757.9 |  |
| GAAP operating income |  | $ | 33.6 |  |  | $ | 33.7 |  |  | $ | 40.1 |  |  | $ | 26.4 |  |  | $ | 133.8 |  |  | $ | 28.1 |  |  | $ | 31.4 |  |  | $ | 37.6 |  |  | $ | 32.8 |  |  | $ | 129.9 |  |
| Add back special operating items |  |  | 1.4 |  |  |  | 3.5 |  |  |  | 1.1 |  |  |  | 2.8 |  |  |  | 8.9 |  |  |  | - |  |  |  | 2.9 |  |  |  | 0.6 |  |  |  | (0.3 | ) |  |  | 3.2 |  |
| Adjusted operating income |  | $ | 35.0 |  |  | $ | 37.3 |  |  | $ | 41.3 |  |  | $ | 29.2 |  |  | $ | 142.7 |  |  | $ | 28.1 |  |  | $ | 34.3 |  |  | $ | 38.2 |  |  | $ | 32.5 |  |  | $ | 133.1 |  |
| Adjusted operating margin |  |  | 16.9 | % |  |  | 16.9 | % |  |  | 19.0 | % |  |  | 14.1 | % |  |  | 16.7 | % |  |  | 16.5 | % |  |  | 18.3 | % |  |  | 19.0 | % |  |  | 16.4 | % |  |  | 17.6 | % |
| Add back amortization |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 3.2 |  |  |  | 3.1 |  |  |  | 12.6 |  |  |  | 1.6 |  |  |  | 1.9 |  |  |  | 2.7 |  |  |  | 3.0 |  |  |  | 9.3 |  |
| Add back depreciation |  |  | 7.0 |  |  |  | 7.5 |  |  |  | 7.3 |  |  |  | 7.6 |  |  |  | 29.3 |  |  |  | 6.2 |  |  |  | 6.5 |  |  |  | 6.9 |  |  |  | 5.6 |  |  |  | 25.2 |  |
| Adjusted EBITDA |  | $ | 45.2 |  |  | $ | 47.8 |  |  | $ | 51.7 |  |  | $ | 39.9 |  |  | $ | 184.6 |  |  | $ | 35.9 |  |  | $ | 42.8 |  |  | $ | 47.8 |  |  | $ | 41.1 |  |  | $ | 167.6 |  |
| Adjusted EBITDA margin |  |  | 21.8 | % |  |  | 21.7 | % |  |  | 23.8 | % |  |  | 19.3 | % |  |  | 21.7 | % |  |  | 21.0 | % |  |  | 22.8 | % |  |  | 23.8 | % |  |  | 20.7 | % |  |  | 22.1 | % |
| Year-over-year adjusted EBITDA growth |  |  | 26 | % |  |  | 12 | % |  |  | 8 | % |  |  | -3 | % |  |  | 10 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-15-001708:8k_2_02:74]
Note: Totals will not always foot due to rounding

[0001437749-15-001708:8k_2_02:75]
# # #
