# LFUS 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 6 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001437749-15-003300:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES.

[0001437749-15-003300:item_9a:2]
Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in this Annual Report on Form 10-K a report on management’s assessment of the effectiveness of the company’s internal control over financial reporting, as well as an attestation report from the company’s independent registered public accounting firm on the effectiveness of the company’s internal control over financial reporting.

[0001437749-15-003300:item_9a:3]
Management’s Report on Internal Control over Financial Reporting

[0001437749-15-003300:item_9a:4]
The management of Littelfuse is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Exchange Act Rule 13a-15(f). The Littelfuse internal control system was designed to provide reasonable assurance to its management and the Board of Directors regarding the preparation and fair presentation of published financial statements.

[0001437749-15-003300:item_9a:5]
All internal control systems, no matter how well designed, have inherent limitations. Therefore, even those systems determined effective can provide only reasonable assurance with respect to financial statement preparation and presentation. A material weakness is a deficiency, or a combination of deficiencies, in the internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the annual or interim financial statement will not be prevented or detected on a timely basis.

[0001437749-15-003300:item_9a:6]
Littelfuse management, including the company’s principal executive officer and principal financial officer, assessed the effectiveness of the company’s internal control over financial reporting as of December 27, 2014, based upon the updated framework in Internal Control — Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in 1992 and updated in May 2013. Based on this assessment, the company’s management concluded that, as of December 27, 2014, the company’s internal control over financial reporting was effective.

[0001437749-15-003300:item_9a:7]
Littelfuse management, including the company’s principal executive officer and principal financial officer concluded that at December 28, 2013, a material control weakness related to the company’s evaluation of the income tax considerations, including deferred tax valuation allowances, relating to the write-off of its investment in Shocking Technologies, Inc. during the first quarter of 2013, existed.

[0001437749-15-003300:item_9a:8]
Material Weakness and Related Remediation Initiatives – Income Taxes

[0001437749-15-003300:item_9a:9]
Management has completed steps to remediate the above material weakness associated with this misstatement. The income tax accounting treatment for any material items that are of an unusual or complex nature are formally reviewed by management quarterly.

[0001437749-15-003300:item_9a:10]
78

[0001437749-15-003300:item_9a:11]
Changes in Internal Control over Financial Reporting

[0001437749-15-003300:item_9a:12]
Except as has been described above, there has been no change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that occurred during the 12 months or fiscal quarter ended December 27, 2014, that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0001437749-15-003300:item_9a:13]
Evaluation of Disclosure Controls and Procedures

[0001437749-15-003300:item_9a:14]
The company maintains disclosure controls and procedures, including a formal disclosure committee, that are designed to ensure that information required to be disclosed in the company’s Exchange Act reports is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms, and that such information is accumulated and communicated to the company’s management, including the Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001437749-15-003300:item_9a:15]
As of December 27, 2014, the Chief Executive Officer and Chief Financial Officer of the company evaluated the effectiveness of the disclosure controls and procedures of the company and concluded that these disclosure controls and procedures were effective, for the reasons set forth above.
