# LFUS notes — 0001437749-15-003300


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-15-003300:notes:1]
1. Summary of Significant Accounting Policies and Other Information

[0001437749-15-003300:notes:2]
Nature of Operations: Littelfuse, Inc. and subsidiaries (the “company”) design, manufacture and sell circuit protection devices for use in the automotive, electronic and electrical markets throughout the world. In addition to the broadest and deepest portfolio of circuit protection products and solutions, the company offers a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles and sensors for automobile safety systems, as well as protection relays and power distribution centers for the safe control and distribution of electricity.

[0001437749-15-003300:notes:3]
Fiscal Year: The company’s fiscal years ended on December 27, 2014, December 28, 2013 and December 29, 2012 and contained 52 weeks each.

[0001437749-15-003300:notes:4]
Basis of Presentation: The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America and include the assets, liabilities, revenues and expenses of all wholly-owned subsidiaries and majority-owned subsidiaries over which the company exercises control.

[0001437749-15-003300:notes:5]
Use of Estimates: The process of preparing financial statements in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The company evaluates and updates its assumptions and estimates on an ongoing basis and may employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0001437749-15-003300:notes:6]
Cash Equivalents: All highly liquid investments, with an original maturity of three months or less when purchased, are considered to be cash equivalents.

[0001437749-15-003300:notes:7]
Short-Term and Long-Term Investments: The company has determined that certain of its investment securities are to be classified as available-for-sale. Available-for-sale securities are carried at fair value with the unrealized gains and losses reported as a component of “Accumulated Other Comprehensive Income (Loss).” Realized gains and losses and declines in unrealized value judged to be other-than-temporary on available-for-sale securities are included in other expense (income), net. The cost of securities sold is based on the specific identification method. Interest and dividends on securities classified as available-for-sale are included in interest income. Short-term investments, which are primarily certificates of deposits, are carried at cost which approximates fair value.

[0001437749-15-003300:notes:8]
Fair Value of Financial Instruments: The company’s financial instruments include cash and cash equivalents, accounts receivable, investments and long-term debt. The carrying values of such financial instruments approximate their estimated fair values.

[0001437749-15-003300:notes:9]
Accounts Receivable: The company performs credit evaluations of customers’ financial condition and generally does not require collateral. Credit losses are provided for in the financial statements based upon specific knowledge of a customer’s inability to meet its financial obligations to the company. Historically, credit losses have consistently been within management’s expectations and have not been a material amount. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0001437749-15-003300:notes:10]
The company also maintains allowances against accounts receivable for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.

[0001437749-15-003300:notes:11]
Inventories: Inventories are stated at the lower of cost or market (first in, first out method), which approximates current replacement cost. The company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

[0001437749-15-003300:notes:12]
Investment in Unconsolidated Affiliate: Investments in unconsolidated affiliates over which the company has significant influence over the investees’ operating and financing activities are accounted for under the equity method of accounting. Investments in affiliates over which the company does not have the ability to exert significant influence over the investees’ operating and financing activities are accounted for under the cost method.

[0001437749-15-003300:notes:13]
Property, Plant and Equipment: Land, buildings and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of 21 years for buildings, seven to nine years for equipment, seven years for furniture and fixtures, five years for tooling and three years for computer equipment.

[0001437749-15-003300:notes:14]
Goodwill and Indefinite-Lived Intangible Assets: The company annually tests goodwill and indefinite-lived intangible assets for impairment on the first day of its fiscal fourth quarter or at other dates if there is an event or change in circumstances that indicates the asset may be impaired. The company has eight reporting units for testing purposes. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted five-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after five years) to estimate market value. In addition, the company compares its derived enterprise value on a consolidated basis to the company’s market capitalization as of its test date to ensure its derived
      value approximates the market value of the company when taken as a whole.

[0001437749-15-003300:notes:15]
As of the most recent annual test, the company concluded the fair value of each of the reporting units exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. Specifically, the company noted that its headroom, defined as the excess of fair value over the carrying value of invested capital, was 114%, 128%, 128%, 190%, 26%, 6%, 82% and 83% for its electronics (non-silicon), electronics (silicon), passenger car, commercial vehicle products, sensors, relay, custom products and fuse reporting units, respectively, at September 30, 2014. Certain key assumptions used in the annual test included a discount rate of 11.8% and a long-term growth rate of 3.0% was used for all reporting units except for relay which had a discount rate of 12.8% as a result of a 1.0% premium factor.

[0001437749-15-003300:notes:16]
In addition, the company performed a sensitivity test that showed a 100 basis point increase in its discount rate or a 100 basis point decrease in the long-term growth rate for each reporting unit would not have changed the company’s conclusion that no potential goodwill impairment existed.

[0001437749-15-003300:notes:17]
The company will continue to perform a goodwill and indefinite-lived intangible asset impairment test as required on an annual basis and on an interim basis, if certain conditions exist. Factors the company considers important, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the company does not believe its future operating results will vary significantly relative to its historical and projected future operating results.

[0001437749-15-003300:notes:18]
Other Intangible Assets: Trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of five to 20 years. Patents, licenses and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of seven to 12 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of three to 20 years. Other intangible assets are also tested for impairment when there is a significant event that may cause the asset to be impaired.

[0001437749-15-003300:notes:19]
Environmental Liabilities: Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the company’s recorded liability for such claims, the company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0001437749-15-003300:notes:20]
Pension and Other Post-retirement Benefits: Accounting for pensions requires estimating the future benefit cost and recognizing the cost over the employee’s expected period of employment with the company. Certain assumptions are required in the calculation of pension costs and obligations. These assumptions include the discount rate, salary scales and the expected long-term rate of return on plan assets. The discount rate is intended to represent the rate at which pension benefit obligations could be settled by purchase of an annuity contract. These assumptions are subject to change based on stock and bond market returns and other economic factors. Actual results that differ from the company’s assumptions are accumulated and amortized over future periods and therefore generally affect its recognized expense and accrued liability in such future periods. While the company believes that its
      assumptions are appropriate given current economic conditions and its actual experience, significant differences in results or significant changes in the company’s assumptions may materially affect its pension obligations and related future expense. During the fourth quarter of 2012, the company amended the Littelfuse Inc., Retirement Plan to allow participants who met certain requirements to elect to receive their vested retirement benefits in a lump sum on (or for certain participants annuity payments, on and after) December 1, 2012. This amendment resulted in a settlement charge of $5.1 million in 2012. See Note 12 for additional information.

[0001437749-15-003300:notes:21]
Reclassifications: Certain amounts presented in the 2013 financial statements have been reclassified to conform to the 2014 presentation - specifically a reclassification was made to the company’s intangible asset categories between Distribution network and Customer lists, trademarks and tradenames. This reclassification had no impact on total intangibles, net income or shareholders’ equity for any period.

[0001437749-15-003300:notes:22]
Revenue Recognition: The company recognizes revenue on product sales in the period in which the sales process is complete. This generally occurs when persuasive evidence of an arrangement exists, products are shipped (FOB origin) to the customer in accordance with the terms of the sale, the risk of loss has been transferred, collectability is reasonably assured and the pricing is fixed and determinable.

[0001437749-15-003300:notes:23]
At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The company’s distribution channels are primarily through direct sales and independent third party distributors.

[0001437749-15-003300:notes:24]
Revenue and Billing: The company accepts orders from customers based on long term purchasing contracts and written sales agreements. Contract pricing and selling agreement terms are based on market factors, costs and competition. Pricing normally is negotiated as an adjustment (premium or discount) from the company’s published price lists. The customer is invoiced when the company’s products are shipped to them in accordance with the terms of the sales agreement.

[0001437749-15-003300:notes:25]
Returns and Credits: Some of the terms of the company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization to reduce its price to its buyer. If the company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The company establishes reserves for this
      program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001437749-15-003300:notes:26]
Return to Stock: The company has a return to stock policy whereby a customer with prior authorization from Littelfuse management can return previously purchased goods for full or partial credit. The company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0001437749-15-003300:notes:27]
Volume Rebates: The company offers incentives to certain customers to achieve specific quarterly or annual sales targets. If customers achieve their sales targets, they are entitled to rebates. The company estimates the future cost of these rebates and recognizes this estimated cost as a reduction to revenue as products are sold.

[0001437749-15-003300:notes:28]
Allowance for Doubtful Accounts: The company evaluates the collectability of its trade receivables based on a combination of factors. The company regularly analyzes its significant customer accounts and, when the company becomes aware of a specific customer’s inability to meet its financial obligations, the company records a specific reserve for bad debt to reduce the related receivable to the amount the company reasonably believes is collectible. The company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Accounts receivable balances that are deemed to be uncollectible, are written off against the reserve on a case-by-case basis. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If
      circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted. However, due to the company’s diverse customer base and lack of credit concentration, the company does not believe its estimates would be materially impacted by changes in its assumptions.

[0001437749-15-003300:notes:29]
Advertising Costs: The company expenses advertising costs as incurred, which amounted to $2.8 million in 2014, $1.6 million in 2013 and $1.7 million in 2012, and are included as a component of selling, general and administrative expenses.

[0001437749-15-003300:notes:30]
Shipping and Handling Fees and Costs: Amounts billed to customers related to shipping and handling is classified as revenue. Costs incurred for shipping and handling of $6.7 million, $6.5 million and $6.2 million in 2014, 2013 and 2012, respectively, are classified in selling, general and administrative expenses.

[0001437749-15-003300:notes:31]
Foreign Currency Translation/Remeasurement: The company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. The amount of foreign currency gain or loss from remeasurement recognized in the income statement was a loss of $4.6 million in 2014, income of $5.2 million in 2013 and a loss of $8.5 million in 2012. Adjustments from the translation process are recognized in “Shareholders’ equity” as a component of “Accumulated other comprehensive income.”

[0001437749-15-003300:notes:32]
Stock-based Compensation: The company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as both operating and financing cash flows. See Note 13 for additional information on stock-based compensation.

[0001437749-15-003300:notes:33]
Other Expense (Income), Net: Other expense (income), net consisting of interest income, royalties and non-operating income, was ($6.6 million), ($4.6 million) and ($5.4 million) of income in 2014, 2013 and 2012, respectively.

[0001437749-15-003300:notes:34]
Income Taxes: The company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit carryforwards. Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. Federal and state income taxes are provided on the portion of foreign income that is expected to be remitted to the U.S. and be taxable.

[0001437749-15-003300:notes:35]
Accounting Pronouncements: In May 2014, the Financial Accounting Standards Board (FASB) amended prior authoritative guidance for revenue recognition which provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The standard is effective for public entities for annual and interim periods beginning after December 15, 2016. Early adoption is not permitted. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The company is currently evaluating the impact of the adoption of this accounting standard on its consolidated financial statements.

[0001437749-15-003300:notes:36]
In February 2013, the FASB issued authoritative guidance on the reporting of amounts reclassified out of accumulated other comprehensive income into net income or the balance sheet. Under the new guidance, in addition to the presentation of changes in accumulated balances, an entity shall present separately for each component of other comprehensive income, current period reclassifications out of accumulated other comprehensive income and other amounts of current-period other comprehensive income. Both before-tax and net-of-tax presentations are permitted. The guidance is effective for reporting periods beginning after December 15, 2013. The company adopted the new guidance on December 29, 2013 which had no significant effect on its consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-15-003300:notes:37]
2. Acquisition of Businesses

[0001437749-15-003300:notes:38]
The company accounts for acquisitions using the purchase method in accordance with ASC 805, “Business Combinations.” The results of operations of each acquisition have been included in the accompanying consolidated financial statements as of the dates of the acquisition. Acquisition costs associated with acquisitions were $0.5 million, $1.7 million and $0.9 million for fiscal years 2014, 2013 and 2012, respectively and were recorded in Selling, general and administrative expenses.

[0001437749-15-003300:notes:39]
SymCom

[0001437749-15-003300:notes:40]
On January 3, 2014, the company acquired 100% of SymCom, Inc. (“SymCom”) for $52.8 million net of cash acquired. Located in Rapid City, South Dakota, SymCom provides overload relays and pump controllers primarily to the industrial market. The acquisition allows the company to strengthen its position in the relay products market by adding new products and new customers within its Electrical business unit segment. The company funded the acquisition with available cash and proceeds from credit facilities.

[0001437749-15-003300:notes:41]
The following table sets forth the final purchase price allocation for SymCom acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values.

[0001437749-15-003300:notes:42]
| SymCom final purchase price allocation (in thousands): |  |
| Cash |  | $ | 325 |  |
| Current assets, net |  |  | 9,154 |  |
| Property, plant and equipment |  |  | 11,193 |  |
| Goodwill |  |  | 15,018 |  |
| Trademarks |  |  | 17,020 |  |
| Patents |  |  | 1,500 |  |
| Other non-current assets |  |  | 20 |  |
| Current liabilities |  |  | (1,137 | ) |
|  |  | $ | 53,093 |  |

[0001437749-15-003300:notes:43]
All SymCom goodwill and other assets and liabilities were recorded in the Electrical business unit segment and reflected in the Americas geographical area. The trademarks are being amortized over 15 to 20 years. The patents are being amortized over 16 to 17 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining

[0001437749-15-003300:notes:44]
SymCom’s products with the company’s existing electrical product offerings. Goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-15-003300:notes:45]
As required by purchase accounting rules, the company initially recorded a $2.6 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. During the first quarter of 2014, as a portion of this inventory was sold, cost of goods sold included a $1.4 million non-cash charge for this step-up.

[0001437749-15-003300:notes:46]
During the second quarter of 2014, the inventory step-up valuation was finalized at $2.8 million which resulted in an additional $1.4 million non-cash charge to cost of goods sold for the second quarter of 2014.

[0001437749-15-003300:notes:47]
Pro forma financial information is not presented for the SymCom acquisition due to amounts not being materially different than actual results.

[0001437749-15-003300:notes:48]
Hamlin, Inc.

[0001437749-15-003300:notes:49]
On May 31, 2013, the company acquired 100% of Hamlin, Inc. (“Hamlin”) from Key Safety Systems, for $144.4 million (net of cash acquired). Hamlin is a manufacturer of sensor technology providing standard products and custom solutions for leading global manufacturers in the automotive and electronic industries. The acquisition allows the company to expand its automotive and electronics product offerings in the global sensor market in both the Automotive and Electronics business segments. Hamlin is headquartered in Lake Mills, Wisconsin and has manufacturing, engineering and sales offices in the U.S., Mexico, Europe and Asia. The company funded the acquisition with available cash raised from borrowings on the company’s new credit arrangement (See Note 7).

[0001437749-15-003300:notes:50]
The following table sets forth the final purchase price allocation for Hamlin acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values.

[0001437749-15-003300:notes:51]
| Hamlin final purchase price allocation (in thousands): |  |
| Cash |  | $ | 15,984 |  |
| Current assets, net |  |  | 27,811 |  |
| Property, plant and equipment |  |  | 24,728 |  |
| Goodwill |  |  | 51,218 |  |
| Distribution network |  |  | 35,327 |  |
| Patents and licenses |  |  | 16,276 |  |
| Trademarks |  |  | 6,522 |  |
| Non-current assets |  |  | 2,452 |  |
| Current liabilities |  |  | (7,734 | ) |
| Non-current liabilities |  |  | (12,217 | ) |
|  |  | $ | 160,367 |  |

[0001437749-15-003300:notes:52]
All Hamlin goodwill and other assets and liabilities were recorded in the Automotive and Electronics business unit segments and reflected in the Americas, Europe and Asia-Pacific geographical areas. The distribution network, trademarks and patents and licenses are all being amortized over 10 years.

[0001437749-15-003300:notes:53]
The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining Hamlin’s products with the company’s existing product offerings. A portion of the goodwill for the acquisition is not expected to be deductible for tax purposes.

[0001437749-15-003300:notes:54]
The company initially recorded a $2.1 million step-up of inventory to its fair value as of the acquisition date based on preliminary valuation. During the second and third quarters of 2013, as the remainder of this inventory was sold, cost of goods sold included $1.7 million and $0.3 million of non-cash charges for this step-up, respectively. During the fourth quarter of 2013, the inventory step-up valuation was finalized at $1.5 million which resulted in a $0.5 million non-cash credit to income in the fourth quarter of 2013.

[0001437749-15-003300:notes:55]
The following unaudited pro forma results are provided below for the company’s acquisition of Hamlin and assume that the acquisition of Hamlin had been completed as of the beginning of fiscal year 2012.

[0001437749-15-003300:notes:56]
|  |  | For the twelve months ended |  |
|  |  | December 28, 2013 |  |  | December 29, 2012 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Revenues |  | $ | 789,224 |  |  | $ | 739,968 |  |
| Net income |  | $ | 89,083 |  |  | $ | 80,597 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 4.00 |  |  | $ | 3.69 |  |
| Diluted |  | $ | 3.96 |  |  | $ | 3.64 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,315 |  |  |  | 21,822 |  |
| Diluted |  |  | 22,537 |  |  |  | 22,098 |  |

[0001437749-15-003300:notes:57]
For the twelve months ended December 28, 2013, Hamlin added approximately $51.0 million in revenue and $1.2 million in net income to the company’s consolidated results.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-15-003300:notes:58]
3. Inventories

[0001437749-15-003300:notes:59]
The components of inventories at December 27, 2014 and December 28, 2013 are as follows (in thousands):

[0001437749-15-003300:notes:60]
|  |  | 2014 |  |  | 2013 |  |
| Raw materials |  | $ | 29,756 |  |  | $ | 28,228 |  |
| Work in process |  |  | 15,164 |  |  |  | 17,576 |  |
| Finished goods |  |  | 52,471 |  |  |  | 46,787 |  |
| Total |  | $ | 97,391 |  |  | $ | 92,591 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-15-003300:notes:61]
4. Goodwill and Other Intangible Assets

[0001437749-15-003300:notes:62]
The amounts for goodwill and changes in the carrying value by business unit segment are as follows at December 27, 2014 and December 28, 2013 (in thousands):

[0001437749-15-003300:notes:63]
|  |  | 2014 |  |  | Additions (Reductions)(a) |  |  | Adjustments(c) |  |  | 2013 |  |  | Additions (Reductions)(b) |  |  | Adjustments(c) |  |  | 2012 |  |
| Electronics |  | $ | 60,510 |  |  | $ | 1,654 |  |  | $ | (1,590 | ) |  | $ | 60,446 |  |  | $ | 24,031 |  |  | $ | 992 |  |  | $ | 35,423 |  |
| Automotive |  |  | 81,717 |  |  |  | — |  |  |  | (3,264 | ) |  |  | 84,981 |  |  |  | 26,762 |  |  |  | 1,964 |  |  |  | 56,255 |  |
| Electrical |  |  | 54,029 |  |  |  | 14,920 |  |  |  | (1,928 | ) |  |  | 41,037 |  |  |  | — |  |  |  | (877 | ) |  |  | 41,914 |  |
| Total |  | $ | 196,256 |  |  | $ | 16,574 |  |  | $ | (6,782 | ) |  | $ | 186,464 |  |  | $ | 50,793 |  |  | $ | 2,079 |  |  | $ | 133,592 |  |

[0001437749-15-003300:notes:64]
(a) Electronics addition of $1.7 million and Electrical addition of $14.9 million in 2014 resulted from business acquisitions.

[0001437749-15-003300:notes:65]
(b) Electronic addition of $24.0 million and Automotive additions of $26.8 million in 2013 resulted from the acquisition of Hamlin.

[0001437749-15-003300:notes:66]
(c) Adjustments reflect the impact of changes in foreign exchange rates.

[0001437749-15-003300:notes:67]
There were no accumulated goodwill impairment losses at December 27, 2014, December 28, 2013 or December 29, 2012.

[0001437749-15-003300:notes:68]
The company recorded amortization expense of $12.5 million in 2014, $9.3 million in 2013 and $6.1 million in 2012. The details of other intangible assets and related future amortization expense of existing intangible assets at December 27, 2014 and December 28, 2013 are as follows:

[0001437749-15-003300:notes:69]
|  |  | 2014 |  |  | 2013 |  |
| (in thousands) |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |  | Weighted Average Useful Life |  |  | Gross Carrying Value |  |  | Accumulated Amortization |  |
| Patents, licenses and software(a) |  |  | 11.7 |  |  | $ | 62,378 |  |  | $ | 38,738 |  |  |  | 11.0 |  |  | $ | 63,026 |  |  | $ | 37,860 |  |
| Distribution network(a) |  |  | 12.4 |  |  |  | 46,850 |  |  |  | 27,422 |  |  |  | 12.3 |  |  |  | 47,637 |  |  |  | 24,867 |  |
| Customer lists, trademarks and tradenames(a) |  |  | 13.2 |  |  |  | 80,247 |  |  |  | 24,672 |  |  |  | 12.3 |  |  |  | 63,459 |  |  |  | 18,527 |  |
| Tradenames(b) |  |  | — |  |  |  | 5,030 |  |  |  | — |  |  |  | — |  |  |  | 5,489 |  |  |  | — |  |
| Total |  |  | 12.5 |  |  | $ | 194,505 |  |  | $ | 90,832 |  |  |  | 11.8 |  |  | $ | 179,611 |  |  | $ | 81,254 |  |

[0001437749-15-003300:notes:70]
(a) Increase to gross carrying value in 2014 is primarily related to the preliminary SymCom acquisition purchase price allocation discussed in Note 2. Other changes are primarily due to the impact of foreign currency translation adjustments.

[0001437749-15-003300:notes:71]
(b) Tradenames with indefinite lives.

[0001437749-15-003300:notes:72]
Estimated amortization expense related to intangible assets with definite lives at December 27, 2014 is as follows (in thousands):

[0001437749-15-003300:notes:73]
| 2015 |  | $ | 12,778 |  |
| 2016 |  |  | 10,940 |  |
| 2017 |  |  | 10,485 |  |
| 2018 |  |  | 10,387 |  |
| 2019 |  |  | 10,644 |  |
| 2020 and thereafter |  |  | 43,410 |  |
|  |  | $ | 98,644 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-15-003300:notes:74]
5. Other Investments

[0001437749-15-003300:notes:75]
The company’s other investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company. The Polytronics investment was acquired as part of the Littelfuse GmbH acquisition. The company’s Polytronics shares held at the end of fiscal 2014 and 2013 represent approximately 7.2% of total Polytronics shares outstanding. The fair value of the Polytronics investment was €9.9 million (approximately $12.1 million) at December 27, 2014 and €9.0 million (approximately $12.3 million) at December 28, 2013. Included in 2014 other comprehensive income is an unrealized gain of $1.4 million, due to the increase in fair market value of the Polytronics investment. The remaining movement year
      over year was due to the impact of changes in exchange rates.


## us-gaap:InvestmentsInAndAdvancesToAffiliatesScheduleOfInvestmentsTextBlock

[0001437749-15-003300:notes:76]
6. Investment in Unconsolidated Affiliate

[0001437749-15-003300:notes:77]
Investments in unconsolidated entities over which the company has significant influence over the investees’ operating and financing activities are accounted for under the equity method of accounting. Investments in affiliates in which the company does not have such ability are accounted for under the cost method of accounting.

[0001437749-15-003300:notes:78]
In April 2012, the company invested an additional $10.0 million in certain common and preferred stock of Shocking Technologies, Inc. (“Shocking”) increasing its previous investment interest in Shocking to $16.0 million or approximately 18.4%. In addition, in late-November 2012, the company provided an additional $2.0 million short-term secured loan to Shocking and determined that the company then had the ability to exert significant influence. As a result, the company began accounting for the investment in Shocking using the equity method. In accordance with ASC 323, the company retroactively recorded its proportional share of Shocking's operating losses, which amounted to approximately $4.0 million in 2012.

[0001437749-15-003300:notes:79]
Impairment

[0001437749-15-003300:notes:80]
During the fourth quarter of 2012, the company concluded that there was an other-than-temporary impairment which existed for its investment in Shocking. The company engaged a third-party valuation firm to assist in developing the fair value of the investment in Shocking. Based on the then fair value, the company determined that there was an impairment of approximately $3.3 million which was recorded as a non-operating impairment and equity loss of unconsolidated affiliate in the Consolidated Statements of Net Income.

[0001437749-15-003300:notes:81]
During the first quarter of 2013, the company fully impaired its investment in a loan receivable from Shocking owing to their filing for Chapter 7 bankruptcy on March 12, 2013. The impairment charge of approximately $10.7 million consisted of the remaining equity method investment of $8.7 million and a $2.0 million loan receivable, and reduced the carrying value of both the investment and loan receivable to zero at March 30, 2013.

[0001437749-15-003300:notes:82]
During the fourth quarter of 2013, the company incurred a $6.1 million charge to income tax expense related to the company’s investment in Shocking which had been fully impaired and written off as described above. $3.3 million of this charge was pushed back to the first quarter of 2013 with the remaining $2.8 million (which related to the fourth quarter of 2012) recorded in the fourth quarter of 2013 as the correction of an immaterial error under ASC 250. This charge was determined to be a capital loss for tax purposes, instead of an ordinary loss as the company had previously determined in consultation with a third party expert.

[0001437749-15-003300:notes:83]
The effect of retroactively recording the company’s proportional share of Shocking's operating losses (including the impact of differences in the company’s equity in Shocking’s net assets, which is attributable to amortizable intangible assets) for the quarterly periods in 2012 was as follows:

[0001437749-15-003300:notes:84]
|  |  | 1st Quarter |  |  | 2nd Quarter |  |  | 3rd Quarter |  |  | 4th Quarter |  |  | Total 2012 |  |
| Equity-method losses |  | $ | 525 |  |  | $ | 1,033 |  |  | $ | 1,965 |  |  | $ | 488 |  |  | $ | 4,011 |  |
| Impairment charge |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,323 |  |  |  | 3,323 |  |
| Total |  | $ | 525 |  |  | $ | 1,033 |  |  | $ | 1,965 |  |  | $ | 3,811 |  |  | $ | 7,334 |  |

[0001437749-15-003300:notes:85]
The selected quarterly financial data shown in Note 18 has been restated for the first quarter of 2013 to show the impact of the income tax charge discussed above and the above retroactive application of the equity method of accounting for Shocking.


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-003300:notes:86]
7. Debt

[0001437749-15-003300:notes:87]
The carrying amounts of debt at December 27, 2014 and December 28, 2013 are as follows (in thousands):

[0001437749-15-003300:notes:88]
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 93,750 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 83,500 |  |  |  | 121,000 |  |
| Entrusted loan |  |  | 17,908 |  |  |  | — |  |
| Total debt |  |  | 195,158 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 88,500 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 106,658 |  |  | $ | 93,750 |  |

[0001437749-15-003300:notes:89]
Term Loan and Revolving Credit Facilities

[0001437749-15-003300:notes:90]
On May 31, 2013, the company entered into a new credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consists of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. At December 27, 2014, the company had available $190.9 million of borrowing capacity under the credit agreement at an interest rate of LIBOR plus 1.25% (1.42% as of December 27, 2014).

[0001437749-15-003300:notes:91]
The credit agreement replaces the company’s previous credit agreement dated June 13, 2011 which was terminated on May 31, 2013.

[0001437749-15-003300:notes:92]
The company incurred debt issuance costs of $0.8 million which will be amortized over the life of the new credit agreement.

[0001437749-15-003300:notes:93]
On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement.

[0001437749-15-003300:notes:94]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At December 27, 2014, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-15-003300:notes:95]
The company assumed three credit lines with the acquisition of Hamlin totaling RMB 41.0 million (approximately $6.6 million) as of June 29, 2013 with expiration dates from August 23, 2013 through April 22, 2014. Two of these credit lines expired during the third quarter of 2013 with the remaining credit line expiring during the second  quarter of 2014.

[0001437749-15-003300:notes:96]
The company assumed an agreement for the sale of debts to HSBC Invoice Finance (UK) Ltd. with the acquisition of Hamlin totaling $1.8 million GBP (approximately $2.7 million) as of June 29, 2013. The company terminated this agreement during the third quarter of 2013.

[0001437749-15-003300:notes:97]
For the fiscal years ended December 27, 2014, December 28, 2013, and December 27, 2013, the company had $0.8 million outstanding in letters of credit. No amounts were drawn under these lines of credit at December 27, 2014.

[0001437749-15-003300:notes:98]
Entrusted Loan

[0001437749-15-003300:notes:99]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income
      will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.

[0001437749-15-003300:notes:100]
Interest paid on all company debt was approximately $4.9 million in 2014, $2.9 million in 2013 and $1.7 million in 2012.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-15-003300:notes:101]
8. Financial Instruments and Risk Management

[0001437749-15-003300:notes:102]
Occasionally, the company uses financial instruments to manage its exposures to movements in commodity prices, foreign exchange and interest rates. The use of these financial instruments modifies the company’s exposure to these risks with the goal of reducing the risk or cost to the company. The company does not use derivatives for trading purposes and is not a party to leveraged derivative contracts.

[0001437749-15-003300:notes:103]
The company recognizes all derivative instruments as either assets or liabilities at fair value in the Consolidated Balance Sheets. The fair value is based upon either market quotes for actively traded instruments or independent bids for non-exchange traded instruments. The company formally documents its hedge relationships, including identifying the hedging instruments and the hedged items, as well as its risk management objectives and strategies for undertaking the hedge transaction. This process includes linking derivatives that are designated as hedges of specific assets, liabilities, firm commitments or forecasted transactions to the hedged risk. On the date the derivative is entered into, the company designates the derivative as a fair value hedge, cash flow hedge or a net investment hedge, and accounts for the derivative in accordance with its designation. The company also formally assesses, both at
      inception and at least quarterly thereafter, whether the derivatives are highly effective in offsetting changes in either the fair value or cash flows of the hedged item. If it is determined that a derivative ceases to be a highly effective hedge, or if the anticipated transaction is no longer likely to occur, the company discontinues hedge accounting, and any deferred gains or losses are recorded in the respective measurement period. In determining fair value, the company uses various valuation approaches within the fair value measurement framework. Fair value measurements are determined based on the assumptions that market participants would use in pricing an asset or liability. The company currently does not have any outstanding derivative instruments.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-003300:notes:104]
9. Fair Value of Assets and Liabilities

[0001437749-15-003300:notes:105]
Applicable accounting literature establishes a hierarchy for inputs used in measuring fair value that maximizes the use of observable inputs and minimizes the use of unobservable inputs by requiring that the most observable inputs be used when available. Applicable accounting literature defines levels within the hierarchy based on the reliability of inputs as follows:

[0001437749-15-003300:notes:106]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0001437749-15-003300:notes:107]
Level 2—Valuations based on quoted prices for similar assets or liabilities or identical assets or liabilities in less active markets, such as dealer or broker markets; and

[0001437749-15-003300:notes:108]
Level 3—Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable, such as pricing models, discounted cash flow models and similar techniques not based on market, exchange, dealer or broker-traded transactions.

[0001437749-15-003300:notes:109]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0001437749-15-003300:notes:110]
Investment in Polytronics

[0001437749-15-003300:notes:111]
Equity securities listed on a national market or exchange are valued at the last sales price. Such securities are further detailed in Note 5 and classified within Level 1 of the valuation hierarchy.

[0001437749-15-003300:notes:112]
There were no changes during the year ended December 27, 2014 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of December 27, 2014 and December 28, 2013, the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-15-003300:notes:113]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 27, 2014 (in thousands):

[0001437749-15-003300:notes:114]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |
| Total |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |

[0001437749-15-003300:notes:115]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 28, 2013 (in thousands):

[0001437749-15-003300:notes:116]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 12,286 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,286 |  |
| Total |  | $ | 12,286 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,286 |  |

[0001437749-15-003300:notes:117]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash e

[0001437749-15-003300:notes:118]
quivalents, short-term investments and accounts receivable approximate their fair values. The company’s long-term debt fair value approximates book value at December 27, 2014 and December 28, 2013.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001437749-15-003300:notes:119]
10. Coal Mining Liability

[0001437749-15-003300:notes:120]
Included in other long-term liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €1.9 million ($2.4 million) and €2.2 million ($3.1 million) at December 27, 2014 and December 28, 2013, respectively.  Management, in conjunction with an independent third-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions
      are mostly unknown at this time. The accrual is not discounted as management cannot reasonably estimate when such remediation efforts will take place.


## us-gaap:AssetImpairmentChargesTextBlock

[0001437749-15-003300:notes:121]
11. Asset Impairments

[0001437749-15-003300:notes:122]
During 2014, the company recorded an asset impairment charge of approximately $0.3 million within selling, general and administrative expenses. This charge reflects the write-down of assets from project cancellations. The charge was recognized as an “other” charge for segment reporting purposes. The carrying values of the company’s assets held for sale are $5.5 million for the previously closed manufacturing facility in Des Plaines, Illinois as of December 27, 2014 and December 28, 2013.

[0001437749-15-003300:notes:123]
The company recorded no impairments of assets during 2013.

[0001437749-15-003300:notes:124]
During 2012, the company recorded an asset impairment charge of approximately $0.5 million within selling, general and administrative expenses. This charge reflects the write-down of the company’s previously closed manufacturing facility in Dünsen, Germany to its net selling price. The charge was recognized as an “other” charge for segment reporting purposes. The Dünsen facility was sold during the fourth quarter of 2012. Also, during the third quarter of 2012, the company reclassified its Yangmei, Taiwan facility to assets held for sale. The Yangmei facility was sold during the fourth quarter of 2012 and a gain of approximately $1.5 million was realized. In the fourth quarter of 2012, the company entered into a binding agreement for the future sale of its Des Plaines, Illinois property for $6.0 million on an installment basis over a three year period.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-15-003300:notes:125]
12. Benefit Plans

[0001437749-15-003300:notes:126]
The company has a company-sponsored defined benefit pension plan, the Littelfuse Inc. Retirement Plan, covering certain of its North American employees. The amount of the retirement benefit is based on years of service and final average pay. The plan also provides a temporary supplemental retirement income benefit to help retirees pay the cost of post-retirement medical coverage if the retiree has reached age 62 and has provided at least ten years of service prior to retirement. Such benefits generally cease once the retiree attains age 65. The plan was frozen in 2009. The company also has company-sponsored defined benefit pension plans covering employees in the U.K., Germany, Japan, Taiwan and the Philippines. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0001437749-15-003300:notes:127]
During the fourth quarter of 2012, the company recorded $5.3 million in pension settlement and valuation charges. Approximately $5.1 million of these charges were classified in selling, general and administrative expenses and approximately $0.2 million were classified in cost of sales. During the fourth quarter of 2012, the company amended the Littelfuse Inc. Retirement Plan to allow participants who meet certain requirements to elect, during a limited window period, to receive their vested retirement benefits in a lump sum (or for certain participants annuity payments, on and after) December 1, 2012.

[0001437749-15-003300:notes:128]
The $5.1 million settlement charge recorded in selling, general and administrative expenses related to the amended Littelfuse, Inc. Retirement Plan represents the total amount for eligible participants who elected to receive their benefits under the amendment. The $0.2 million charge recorded in cost of sales is related to the company’s Taiwan manufacturing facility that was closed in 2012.

[0001437749-15-003300:notes:129]
The company’s contributions are made in amounts sufficient to satisfy legal requirements. The company is not expected to be required to make a minimum funding contribution in accordance with the Employee Retirement Income Securities Act of 1974 (“ERISA”) for fiscal year 2015.

[0001437749-15-003300:notes:130]
Total pension expense was $0.3 million, $0.8 million and $5.4 million in 2014, 2013 and 2012, respectively. The decrease in pension expense in 2014 resulted from returns on assets exceeding interest and service costs. The decrease in pension expense in 2013 was related to the pension settlement charge that was recorded in 2012 as described above. The increase in pension expense in 2012 was the result of the pension settlement charge as described above.

[0001437749-15-003300:notes:131]
Benefit plan related information is as follows:

[0001437749-15-003300:notes:132]
|  |  | 2014 |  |  | 2013 |  |
| (In thousands) |  | U.S. |  |  | Foreign |  |  | Total |  |  | U.S. |  |  | Foreign |  |  | Total |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation at beginning of year |  | $ | 84,422 |  |  | $ | 50,331 |  |  | $ | 134,753 |  |  | $ | 95,187 |  |  | $ | 15,406 |  |  | $ | 110,593 |  |
| Service cost |  |  | 600 |  |  |  | 925 |  |  |  | 1,525 |  |  |  | 600 |  |  |  | 744 |  |  |  | 1,344 |  |
| Interest cost |  |  | 3,884 |  |  |  | 2,060 |  |  |  | 5,944 |  |  |  | 3,565 |  |  |  | 1,376 |  |  |  | 4,941 |  |
| Net actuarial loss (gain) |  |  | 22,025 |  |  |  | 5,652 |  |  |  | 27,677 |  |  |  | (9,854 | ) |  |  | 1,111 |  |  |  | (8,743 | ) |
| Benefits paid from the trust |  |  | (5,172 | ) |  |  | (2,525 | ) |  |  | (7,697 | ) |  |  | (5,076 | ) |  |  | (1,755 | ) |  |  | (6,831 | ) |
| Benefits paid directly by company |  |  | — |  |  |  | (155 | ) |  |  | (155 | ) |  |  | — |  |  |  | (112 | ) |  |  | (112 | ) |
| Acquisition |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 31,041 |  |  |  | 31,041 |  |
| Effect of exchange rate movements |  |  | — |  |  |  | (3,548 | ) |  |  | (3,548 | ) |  |  | — |  |  |  | 2,520 |  |  |  | 2,520 |  |
| Benefit obligation at end of year |  | $ | 105,759 |  |  | $ | 52,740 |  |  | $ | 158,499 |  |  | $ | 84,422 |  |  | $ | 50,331 |  |  | $ | 134,753 |  |
| Change in plan assets at fair value: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year |  | $ | 83,748 |  |  | $ | 42,477 |  |  | $ | 126,225 |  |  | $ | 77,949 |  |  | $ | 10,952 |  |  | $ | 88,901 |  |
| Actual return on plan assets |  |  | 10,416 |  |  |  | 5,141 |  |  |  | 15,557 |  |  |  | 5,875 |  |  |  | (196 | ) |  |  | 5,679 |  |
| Employer contributions |  |  | 5,000 |  |  |  | 5,596 |  |  |  | 10,596 |  |  |  | 5,000 |  |  |  | 4,109 |  |  |  | 9,109 |  |
| Benefits paid |  |  | (5,173 | ) |  |  | (2,525 | ) |  |  | (7,698 | ) |  |  | (5,076 | ) |  |  | (1,756 | ) |  |  | (6,832 | ) |
| Acquisition |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 26,904 |  |  |  | 26,904 |  |
| Effect of exchange rate movements |  |  | — |  |  |  | (3,096 | ) |  |  | (3,096 | ) |  |  | — |  |  |  | 2,464 |  |  |  | 2,464 |  |
| Fair value of plan assets at end of year |  |  | 93,991 |  |  |  | 47,593 |  |  |  | 141,584 |  |  |  | 83,748 |  |  |  | 42,477 |  |  |  | 126,225 |  |
| Net amount recognized/(unfunded status) |  | $ | (11,768 | ) |  | $ | (5,147 | ) |  | $ | (16,915 | ) |  | $ | (674 | ) |  | $ | (7,854 | ) |  | $ | (8,528 | ) |
| Amounts recognized in the Consolidated Balance Sheet consist of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of accrued benefit liability |  | $ | (11,768 | ) |  | $ | — |  |  | $ | (11,768 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Accrued benefit liability |  |  | — |  |  |  | (5,147 | ) |  |  | (5,147 | ) |  |  | (674 | ) |  |  | (7,854 | ) |  |  | (8,528 | ) |
| Total liability recognized |  | $ | (11,768 | ) |  | $ | (5,147 | ) |  | $ | (16,915 | ) |  | $ | (674 | ) |  | $ | (7,854 | ) |  | $ | (8,528 | ) |
| Accumulated other comprehensive loss |  | $ | 34,801 |  |  | $ | 7,671 |  |  | $ | 42,472 |  |  | $ | 18,095 |  |  | $ | 5,594 |  |  | $ | 23,689 |  |

[0001437749-15-003300:notes:133]
Amounts recognized in accumulated other comprehensive income (loss), pre-tax consist of:

[0001437749-15-003300:notes:134]
|  |  | 2014 |  |  | 2013 |  |
| (In thousands) |  | U.S. |  |  | Foreign |  |  | Total |  |  | U.S. |  |  | Foreign |  |  | Total |  |
| Net actuarial loss |  | $ | 34,801 |  |  | $ | 7,671 |  |  | $ | 42,472 |  |  | $ | 18,095 |  |  | $ | 5,594 |  |  | $ | 23,689 |  |
| Prior service (cost) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net amount recognized / occurring, pre-tax |  | $ | 34,801 |  |  | $ | 7,671 |  |  | $ | 42,472 |  |  | $ | 18,095 |  |  | $ | 5,594 |  |  | $ | 23,689 |  |

[0001437749-15-003300:notes:135]
The estimated net actuarial loss (gain) which will be amortized from accumulated other comprehensive income (loss) into benefit cost in 2015 is approximately $1.4 million.

[0001437749-15-003300:notes:136]
|  |  | U.S. |  |  | Foreign |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 600 |  |  | $ | 600 |  |  | $ | 600 |  |  | $ | 925 |  |  | $ | 744 |  |  | $ | 601 |  |
| Interest cost |  |  | 3,884 |  |  |  | 3,565 |  |  |  | 4,962 |  |  |  | 2,060 |  |  |  | 1,376 |  |  |  | 644 |  |
| Expected return on plan assets |  |  | (5,646 | ) |  |  | (5,360 | ) |  |  | (6,620 | ) |  |  | (2,292 | ) |  |  | (1,207 | ) |  |  | (480 | ) |
| Amortization of prior service (credit) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Amortization of losses (gains) |  |  | 549 |  |  |  | 942 |  |  |  | 338 |  |  |  | 216 |  |  |  | 130 |  |  |  | 63 |  |
| Total cost of the plan for the year |  |  | (613 | ) |  |  | (253 | ) |  |  | (720 | ) |  |  | 909 |  |  |  | 1,043 |  |  |  | 827 |  |
| Expected plan participants’ contributions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net periodic benefit (credit) cost |  |  | (613 | ) |  |  | (253 | ) |  |  | (720 | ) |  |  | 909 |  |  |  | 1,043 |  |  |  | 827 |  |
| Settlement loss |  |  | — |  |  |  | — |  |  |  | 5,098 |  |  |  | — |  |  |  | — |  |  |  | 188 |  |
| Total (income) expense for the year |  | $ | (613 | ) |  | $ | (253 | ) |  | $ | 4,378 |  |  | $ | 909 |  |  | $ | 1,043 |  |  | $ | 1,015 |  |

[0001437749-15-003300:notes:137]
Weighted average assumptions used to determine net periodic benefit cost for the years 2014, 2013 and 2012 are as follows:

[0001437749-15-003300:notes:138]
|  |  | U.S. |  |  | Foreign |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Discount rate |  |  | 4.8 | % |  |  | 3.9 | % |  |  | 5.4 | % |  |  | 3.7 | % |  |  | 4.5 | % |  |  | 5.5 | % |
| Expected return on plan assets |  |  | 6.8 | % |  |  | 6.8 | % |  |  | 7.8 | % |  |  | 4.9 | % |  |  | 4.8 | % |  |  | 4.5 | % |
| Compensation increase rate |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3.8 | % |  |  | 3.6 | % |  |  | 5.6 | % |
| Measurement dates |  | 12/31/14 |  |  | 12/31/13 |  |  | 12/31/12 |  |  | 12/31/14 |  |  | 12/31/13 |  |  | 12/31/12 |  |

[0001437749-15-003300:notes:139]
The accumulated benefit obligation for the U.S. defined benefit plan was $105.8 million and $84.4 million at December 27, 2014 and December 28, 2013, respectively. The accumulated benefit obligation for the foreign plans was $48.9 million and $46.2 million at December 27, 2014 and December 28, 2013, respectively.

[0001437749-15-003300:notes:140]
Weighted average assumptions used to determine benefit obligations at year-end 2014, 2013 and 2012 are as follows:

[0001437749-15-003300:notes:141]
|  |  | U.S. |  |  | Foreign |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Discount rate |  |  | 3.9 | % |  |  | 4.8 | % |  |  | 3.9 | % |  |  | 3.7 | % |  |  | 4.5 | % |  |  | 4.2 | % |
| Compensation increase rate |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5.3 | % |  |  | 3.8 | % |  |  | 6.3 | % |
| Measurement dates |  | 12/31/14 |  |  | 12/31/13 |  |  | 12/31/12 |  |  | 12/31/14 |  |  | 12/31/13 |  |  | 12/31/12 |  |

[0001437749-15-003300:notes:142]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows (in thousands):

[0001437749-15-003300:notes:143]
| Year |  |  | U.S. |  |  | Foreign |  |
| 2015 |  |  |  | 109,883 |  |  |  | 2,215 |  |
| 2016 |  |  |  | — |  |  |  | 2,095 |  |
| 2017 |  |  |  | — |  |  |  | 2,155 |  |
| 2018 |  |  |  | — |  |  |  | 2,191 |  |
| 2019 |  |  |  | — |  |  |  | 2,232 |  |
| 2020-2024 |  |  |  | — |  |  |  | 12,153 |  |

[0001437749-15-003300:notes:144]
Defined Benefit Plan Assets

[0001437749-15-003300:notes:145]
Based upon analysis of the target asset allocation and historical returns by type of investment, the company has assumed that the expected long-term rate of return will be 6.8% on the Littelfuse, Inc. domestic plan assets and 4.9% on foreign plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0001437749-15-003300:notes:146]
|  |  | U.S. Asset Allocation |  |  | Foreign Asset Allocation |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Equity securities |  |  | 0 | % |  |  | 53 | % |  |  | 30 | % |  |  | 33 | % |
| Debt securities |  |  | 91 | % |  |  | 46 | % |  |  | 68 | % |  |  | 61 | % |
| Cash |  |  | 9 | % |  |  | 1 | % |  |  | 2 | % |  |  | 6 | % |
|  |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001437749-15-003300:notes:147]
The following table presents the company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 27, 2014 (in thousands):

[0001437749-15-003300:notes:148]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Equity 50:50 Index Fund |  | $ | — |  |  | $ | 13,168 |  |  | $ | — |  |  | $ | 13,168 |  |
| Philippine Stock |  |  | 1,069 |  |  |  | — |  |  |  | — |  |  |  | 1,069 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long U.S. Credit Corp Index Fund |  |  | — |  |  |  | 42,911 |  |  |  | — |  |  |  | 42,911 |  |
| Long U.S. Govt Bond Index Fund |  |  | — |  |  |  | 24,116 |  |  |  | — |  |  |  | 24,116 |  |
| Intermediate U.S. Govt Bond Index Fund |  |  | — |  |  |  | 18,884 |  |  |  | — |  |  |  | 18,884 |  |
| Investment grade corporate bond funds |  |  | 8,118 |  |  |  | — |  |  |  | — |  |  |  | 8,118 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | 3,814 |  |  |  | — |  |  |  | 3,814 |  |
| Active Corp Bond – Over 10 Yr Fund |  |  | — |  |  |  | 7,065 |  |  |  | — |  |  |  | 7,065 |  |
| Over 5y Index-Linked Gilts Fund |  |  | — |  |  |  | 11,352 |  |  |  | — |  |  |  | 11,352 |  |
| Philippine Long Govt Securities |  |  | 1,059 |  |  |  | — |  |  |  | — |  |  |  | 1,059 |  |
| Philippine Long Corporate Bonds |  |  | 781 |  |  |  | — |  |  |  | — |  |  |  | 781 |  |
| Cash and equivalents |  |  | 9,247 |  |  |  | — |  |  |  | — |  |  |  | 9,247 |  |
| Total pension plan assets |  | $ | 20,274 |  |  | $ | 121,310 |  |  | $ | — |  |  | $ | 141,584 |  |

[0001437749-15-003300:notes:149]
The following table presents the company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 28, 2013 (in thousands):

[0001437749-15-003300:notes:150]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Equities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| MSCI Emg Mkts Index Fund |  | $ | — |  |  | $ | 4,679 |  |  | $ | — |  |  | $ | 4,679 |  |
| MSCI World Index Fund |  |  | — |  |  |  | 39,332 |  |  |  | — |  |  |  | 39,332 |  |
| Global Equity Index Fund |  |  | — |  |  |  | 12,859 |  |  |  | — |  |  |  | 12,859 |  |
| Philippine Stock |  |  | 918 |  |  |  | — |  |  |  | — |  |  |  | 918 |  |
| Fixed income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long U.S. Credit Corp Index Fund |  |  | — |  |  |  | 24,830 |  |  |  | — |  |  |  | 24,830 |  |
| Long U.S. Govt Bond Index Fund |  |  | — |  |  |  | 8,269 |  |  |  | — |  |  |  | 8,269 |  |
| High yield corporate bond funds |  |  | — |  |  |  | 5,792 |  |  |  | — |  |  |  | 5,792 |  |
| Investment grade corporate bond funds |  |  | 9,637 |  |  |  | — |  |  |  | — |  |  |  | 9,637 |  |
| Over 15y Gilts Index Fund |  |  | — |  |  |  | 5,626 |  |  |  | — |  |  |  | 5,626 |  |
| Act Agg Long Dat 50:50 Fixed Int Fund |  |  | — |  |  |  | 5,174 |  |  |  | — |  |  |  | 5,174 |  |
| AAA Fixed Int Over 15 Year Fund |  |  | — |  |  |  | 5,394 |  |  |  | — |  |  |  | 5,394 |  |
| Other |  |  | 237 |  |  |  | — |  |  |  | — |  |  |  | 237 |  |
| Cash and equivalents |  |  | 3,478 |  |  |  | — |  |  |  | — |  |  |  | 3,478 |  |
| Total pension plan assets |  | $ | 14,270 |  |  | $ | 111,955 |  |  | $ | — |  |  | $ | 126,225 |  |

[0001437749-15-003300:notes:151]
Plan Termination

[0001437749-15-003300:notes:152]
The company filed an Application for Determination for Terminating Plan during 2014 to terminate the U.S. defined benefit pension plan, the Littelfuse Inc. Retirement Plan, effective January 1, 2015. The current liability balance of $11.8 million at December 27, 2014, represents the projected cost to settle the plan’s liability in conjunction with the upcoming plan termination.

[0001437749-15-003300:notes:153]
Defined Contribution Plans

[0001437749-15-003300:notes:154]
The company also maintains a 401(k) savings plan covering substantially all U.S. employees. The company matches 100% of the employee’s annual contributions for the first 4% of the employee’s eligible compensation. Employees are immediately vested in their contributions plus actual earnings thereon, as well as the company contributions. Company matching contributions amounted to $2.1 million, $1.7 million and $1.5 million in each of the years 2014, 2013 and 2012, respectively.

[0001437749-15-003300:notes:155]
On January 1, 2010, the company adopted a non-qualified Supplemental Retirement and Savings Plan. The company will provide additional retirement benefits for certain management employees and named executive officers by allowing participants to contribute up to 90% of their annual compensation with matching contributions of 4% and 5% of the participant’s annual compensation in excess of the IRS compensation limits.

[0001437749-15-003300:notes:156]
The company previously provided additional retirement benefits for certain key executives through its unfunded defined contribution Supplemental Executive Retirement Plan (“SERP”). The company amended the SERP during 2009 to freeze contributions and set the annual interest rate credited to the accounts until distributed at the five-year Treasury constant maturity rate. The charge to expense for the SERP plan amounted to $0.0 million, $0.0 million and $0.1 million in each of the years 2014, 2013 and 2012, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-15-003300:notes:157]
13. Shareholders’ Equity

[0001437749-15-003300:notes:158]
Equity Plans: The company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, performance shares and other stock rights of employees and directors. As of December 27, 2014, there were approximately 1.0 million shares available for issuance of future awards under the company’s equity-based compensation plans.

[0001437749-15-003300:notes:159]
Stock options granted prior to 2002 vested over a five-year period and are exercisable over a ten-year period commencing from the date of vesting. The stock options granted in 2002 through February 2005 vested over a five-year period and are exercisable over a ten-year period commencing from the date of the grant. Stock options granted after February 2005 vest over a three, four or five-year period and are exercisable over either a seven or ten-year period commencing from the date of the grant. Restricted shares and share units granted by the company vest over three to four years.

[0001437749-15-003300:notes:160]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended December 27, 2014.

[0001437749-15-003300:notes:161]
|  |  | Shares Under Option |  |  | Weighted Average Price |  |  | Weighted Average Remaining Contract Life (Years) |  |  | Aggregate Intrinsic Value (000’s) |  |
| Outstanding December 28, 2013 |  |  | 496,203 |  |  | $ | 51.93 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 124,110 |  |  |  | 94.84 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (197,276 | ) |  |  | 44.94 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (1,175 | ) |  |  | 31.83 |  |  |  |  |  |  |  |  |  |
| Outstanding December 27, 2014 |  |  | 421,862 |  |  |  | 67.88 |  |  | 4.6 |  |  | $ | 13,028 |  |
| Exercisable December 27, 2014 |  |  | 170,132 |  |  |  | 49.96 |  |  | 3.0 |  |  |  | 8,302 |  |

[0001437749-15-003300:notes:162]
The following table provides a reconciliation of non-vested restricted share and share unit awards for the fiscal year ended December 27, 2014.

[0001437749-15-003300:notes:163]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
| Nonvested December 28, 2013 |  |  | 184,573 |  |  | $ | 63.56 |  |
| Granted |  |  | 99,880 |  |  |  | 92.96 |  |
| Vested |  |  | (84,128 | ) |  |  | 62.74 |  |
| Forfeited |  |  | (11,327 | ) |  |  | 72.75 |  |
| Nonvested December 27, 2014 |  |  | 188,998 |  |  |  | 78.91 |  |

[0001437749-15-003300:notes:164]
The total intrinsic value of options exercised during 2014, 2013 and 2012 was $9.6 million, $15.3 million, and $9.8 million, respectively. The total fair value of shares vested was $7.6 million, $6.5 million, and $5.8 million for 2014, 2013 and 2012, respectively. The total amount of share-based liabilities paid was $0.3 million, $0.1 million and $0.1 million for 2014, 2013 and 2012, respectively.

[0001437749-15-003300:notes:165]
The company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At December 27, 2014, the unrecognized compensation cost for options, restricted shares and performance shares was $11.5 million before tax, and will be recognized over a weighted-average period of 1.9 years. Compensation cost included as a component of selling, general and administrative expense for all equity compensation plans discussed above was $9.4 million, $8.9 million and $7.3 million for 2014, 2013 and 2012, respectively. The total income tax benefit recognized in the Consolidated Statements of Net Income was $3.3 million, $3.2 million and $2.6 million for 2014, 2013 and 2012, respectively.

[0001437749-15-003300:notes:166]
The company uses the Black-Scholes option valuation model to determine the fair value of awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0001437749-15-003300:notes:167]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Weighted average fair value of options granted |  | $ | 26.25 |  |  | $ | 23.90 |  |  | $ | 23.38 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 1.67 | % |  |  | 0.70 | % |  |  | 0.89 | % |
| Expected dividend yield |  |  | 0.93 | % |  |  | 1.20 | % |  |  | 1.14 | % |
| Expected stock price volatility |  |  | 33.0 | % |  |  | 45.0 | % |  |  | 46.0 | % |
| Expected life of options (years) |  | 4.6 |  |  | 5.1 |  |  | 5.1 |  |

[0001437749-15-003300:notes:168]
Expected volatilities are based on the historical volatility of the company’s stock price. The expected life of options is based on historical data for options granted by the company. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption.

[0001437749-15-003300:notes:169]
Accumulated Other Comprehensive Income (Loss) (AOCI): The following table sets forth the changes in the components of AOCI by component for fiscal years 2014, 2013 and 2012 (in thousands):

[0001437749-15-003300:notes:170]
|  |  | Pension liability adjustments (a) |  |  | Gain on investments (b) |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 29, 2012 |  | $ | (20,879 | ) |  | $ | 7,867 |  |  | $ | 29,560 |  |  | $ | 16,548 |  |
| 2013 activity |  |  | 3,739 |  |  |  | 1,526 |  |  |  | (1,396 | ) |  |  | 3,869 |  |
| Balance at December 28, 2013 |  |  | (17,140 | ) |  |  | 9,393 |  |  |  | 28,164 |  |  |  | 20,417 |  |
| 2014 activity |  |  | (12,475 | ) |  |  | 1,398 |  |  |  | (30,466 | ) |  |  | (41,543 | ) |
| Balance at December 27, 2014 |  | $ | (29,615 | ) |  | $ | 10,791 |  |  | $ | (2,302 | ) |  | $ | (21,126 | ) |

[0001437749-15-003300:notes:171]
(a) Net of tax of $12,587, $6,549, and $11,819 for 2014, 2013 and 2012, respectively.

[0001437749-15-003300:notes:172]
(b) Net of tax of $0, $0 and $0 for 2014, 2013 and 2012, respectively.

[0001437749-15-003300:notes:173]
Preferred Stock: The Board of Directors may authorize the issuance of preferred stock from time to time in one or more series with such designations, preferences, qualifications, limitations, restrictions and optional or other special rights as the Board may fix by resolution.

[0001437749-15-003300:notes:174]
The Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2014 to April 30, 2015. The company repurchased 161,751 of its shares in fiscal 2014 and 838,249 shares remain available for purchase under the initial program as of December 27, 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-003300:notes:175]
14. Income Taxes

[0001437749-15-003300:notes:176]
Domestic and foreign income (loss) before income taxes is as follows (in thousands):

[0001437749-15-003300:notes:177]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Domestic |  | $ | 35,264 |  |  | $ | 20,254 |  |  | $ | 17,490 |  |
| Foreign |  |  | 96,382 |  |  |  | 103,982 |  |  |  | 82,562 |  |
| Income before income taxes |  | $ | 131,646 |  |  | $ | 124,236 |  |  | $ | 100,052 |  |

[0001437749-15-003300:notes:178]
Federal, state and foreign income tax (benefit) expense consists of the following (in thousands):

[0001437749-15-003300:notes:179]
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 8,003 |  |  | $ | 8,265 |  |  | $ | 5,934 |  |
| State |  |  | 1,275 |  |  |  | 2,084 |  |  |  | 1,217 |  |
| Foreign |  |  | 27,438 |  |  |  | 18,462 |  |  |  | 20,230 |  |
| Subtotal |  |  | 36,716 |  |  |  | 28,811 |  |  |  | 27,381 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal and State |  |  | (1,513 | ) |  |  | 3,251 |  |  |  | (6,115 | ) |
| Foreign |  |  | (2,975 | ) |  |  | 3,389 |  |  |  | 3,454 |  |
| Subtotal |  |  | (4,488 | ) |  |  | 6,640 |  |  |  | (2,661 | ) |
| Provision for income taxes |  | $ | 32,228 |  |  | $ | 35,451 |  |  | $ | 24,720 |  |

[0001437749-15-003300:notes:180]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below (in thousands):

[0001437749-15-003300:notes:181]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Tax expense at statutory rate of 35% |  | $ | 46,076 |  |  | $ | 43,481 |  |  | $ | 35,018 |  |
| State and local taxes, net of federal tax benefit |  |  | 1,186 |  |  |  | 1,076 |  |  |  | 536 |  |
| Foreign income tax rate differential |  |  | (14,981 | ) |  |  | (15,497 | ) |  |  | (11,146 | ) |
| Capital loss valuation allowance |  |  | — |  |  |  | 6,085 |  |  |  | — |  |
| Tax on unremitted earnings |  |  | — |  |  |  | (349 | ) |  |  | — |  |
| Other, net |  |  | (53 | ) |  |  | 655 |  |  |  | 312 |  |
| Provision for income taxes |  | $ | 32,228 |  |  | $ | 35,451 |  |  | $ | 24,720 |  |

[0001437749-15-003300:notes:182]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the company’s assets and liabilities. Significant components of the company’s deferred tax assets and liabilities at December 27, 2014 and December 28, 2013, are as follows (in thousands):

[0001437749-15-003300:notes:183]
|  |  | 2014 |  |  | 2013 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 27,088 |  |  | $ | 16,958 |  |
| Foreign tax credit carryforwards |  |  | 5,299 |  |  |  | 6,263 |  |
| R&D credit carryforwards |  |  | — |  |  |  | 147 |  |
| AMT credit carryforwards |  |  | 167 |  |  |  | 1,128 |  |
| Accrued restructuring |  |  | 124 |  |  |  | 45 |  |
| Capital losses |  |  | 4,557 |  |  |  | 6,085 |  |
| Domestic and foreign net operating loss carryforwards |  |  | 525 |  |  |  | 890 |  |
| Gross deferred tax assets |  |  | 37,760 |  |  |  | 31,516 |  |
| Less: Valuation allowance |  |  | (4,557 | ) |  |  | (6,250 | ) |
| Total deferred tax assets |  |  | 33,203 |  |  |  | 25,266 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Tax depreciation and amortization in excess of book |  |  | 21,405 |  |  |  | 21,525 |  |
| Total deferred tax liabilities |  |  | 21,405 |  |  |  | 21,525 |  |
| Net deferred tax assets |  | $ | 11,798 |  |  | $ | 3,741 |  |

[0001437749-15-003300:notes:184]
The deferred tax asset valuation allowance is related to a U.S. capital loss carryover which is not expected to be realized. The remaining domestic and foreign net operating losses either have no expiration date or are expected to be utilized prior to expiration. The foreign tax credit carryforwards begin to expire in 2019. The company paid income taxes of approximately $26.6 million, $30.4 million and $23.8 million in 2014, 2013 and 2012, respectively.

[0001437749-15-003300:notes:185]
U.S. income taxes were not provided on a cumulative total of approximately $351.2 million of undistributed earnings for certain non-U.S. subsidiaries as of December 27, 2014, and accordingly, no deferred tax liability has been established relative to these earnings. The determination of the deferred tax liability associated with the distribution of these earnings is not practicable. The company has three subsidiaries in China on “tax holidays.” The “tax holidays” begin to expire over the next year if the company is not granted extensions which are in process. The company expects to be granted extensions.

[0001437749-15-003300:notes:186]
Such “tax holidays” contributed approximately $3.0 million in tax benefits ($0.13 per diluted share) during 2014 with similar amounts expected in future years while “tax holidays” are in effect.

[0001437749-15-003300:notes:187]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of December 27, 2014, December 28, 2013 and December 29, 2012 is as follows (in thousands):

[0001437749-15-003300:notes:188]
| Balance at January 2, 2012 |  | $ | 112 |  |
| Increases/decreases for tax positions taken in the current year |  |  | — |  |
| Additions for tax positions taken in prior years |  |  | — |  |
| Settlements |  |  | — |  |
| Lapses of statute of limitations |  |  | — |  |
| Balance at December 29, 2012, December 28, 2013 and December 27, 2014 |  | $ | 112 |  |

[0001437749-15-003300:notes:189]
The amount of unrecognized tax benefits at December 27, 2014 was approximately $0.1 million. Of this total, approximately $0.1 million represents the amount of tax benefits that, if recognized, would favorably affect the effective income tax rate in future periods. The company does not reasonably expect a decrease in unrecognized tax benefits in the next 12 months. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility. The U.S. federal statute of limitations remains open for 2011 onward. Foreign and U.S. state statute of limitations generally range from three to seven years. The company received an examination notice from the Internal Revenue Service for the 2012 tax year. The company is currently under examination in Germany for tax years 2008
      through 2010. The company does not expect to recognize a significant amount of additional tax expense as a result of concluding the German tax examination. The company acquired subsidiaries during 2013 and 2014 that are currently under examination in the U.S. and Germany. The U.S. examination is for tax years 2011 and 2012 and the German examination is for the tax years 2008 through 2010. The company is indemnified for any tax liabilities incurred upon conclusion of these examinations.

[0001437749-15-003300:notes:190]
The company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-003300:notes:191]
15. Business Unit Segment Information

[0001437749-15-003300:notes:192]
An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer (“CEO”).

[0001437749-15-003300:notes:193]
The company reports its operations by the following business unit segments: Electronics, Automotive and Electrical.

[0001437749-15-003300:notes:194]
|  | ● | Electronics. Provides circuit protection components and expertise to leading global manufacturers of a wide range of electronic products including mobile phones, computers, LCD TVs, telecommunications equipment, medical devices, lighting products and white goods. The Electronics business segment has the broadest product offering in the industry including fuses and protectors, positive temperature coefficient (“PTC”) resettable fuses, varistors, polymer electrostatic discharge (“ESD”) suppressors, discrete transient voltage suppression (“TVS”) diodes, TVS diode arrays and protection thyristors, gas discharge tubes, power switching components and fuseholders, blocks and related accessories. |

[0001437749-15-003300:notes:195]
|  | ● | Automotive. Provides circuit protection products to the worldwide automotive original equipment manufacturers (“OEM”) and parts distributors of passenger automobiles, trucks, buses and off-road equipment. The company also sells its fuses in the automotive replacement parts market. Products include blade fuses, high current fuses, battery cable protectors and varistors. |

[0001437749-15-003300:notes:196]
|  | ● | Electrical. Provides circuit protection products for industrial and commercial customers. Products include power fuses and other circuit protection devices that are used in commercial and industrial buildings and large equipment such as HVAC systems, elevators and machine tools. |

[0001437749-15-003300:notes:197]
Each of the operating segments is directly responsible for sales, marketing and research and development. Manufacturing, purchasing, logistics, customer service, finance, information technology and human resources are shared functions that are allocated back to the three operating segments. The CEO allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss), but does not evaluate the operating segments using discrete balance sheet information.

[0001437749-15-003300:notes:198]
Sales, marketing and research and development expenses are charged directly into each operating segment. All other functions are shared by the operating segments and expenses for these shared functions are allocated to the operating segments and included in the operating results reported below. The company does not report inter-segment revenue because the operating segments do not record it. The company does not allocate interest and other income, interest expense, equity in loss of unconsolidated affiliate, or taxes to operating segments. Although the CEO uses operating income to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the company as a whole.

[0001437749-15-003300:notes:199]
The company has provided this business unit segment information for all comparable prior periods. Segment information is summarized as follows (in thousands):

[0001437749-15-003300:notes:200]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 410,065 |  |  | $ | 367,052 |  |  | $ | 329,466 |  |
| Automotive |  |  | 325,415 |  |  |  | 267,207 |  |  |  | 206,222 |  |
| Electrical |  |  | 116,515 |  |  |  | 123,594 |  |  |  | 132,225 |  |
| Total net sales |  | $ | 851,995 |  |  | $ | 757,853 |  |  | $ | 667,913 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 22,177 |  |  | $ | 20,735 |  |  | $ | 20,741 |  |
| Automotive |  |  | 14,204 |  |  |  | 9,928 |  |  |  | 6,822 |  |
| Electrical |  |  | 5,494 |  |  |  | 3,817 |  |  |  | 3,870 |  |
| Total depreciation and amortization |  | $ | 41,875 |  |  | $ | 34,480 |  |  | $ | 31,433 |  |

[0001437749-15-003300:notes:201]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 86,981 |  |  | $ | 69,559 |  |  | $ | 51,422 |  |
| Automotive |  |  | 45,086 |  |  |  | 39,170 |  |  |  | 29,817 |  |
| Electrical |  |  | 10,674 |  |  |  | 24,363 |  |  |  | 32,794 |  |
| Other (1) |  |  | (8,911 | ) |  |  | (3,211 | ) |  |  | (7,163 | ) |
| Total operating income |  |  | 133,830 |  |  |  | 129,881 |  |  |  | 106,870 |  |
| Interest expense |  |  | 4,903 |  |  |  | 2,917 |  |  |  | 1,701 |  |
| Impairment and equity in net loss of unconsolidated affiliate (2) |  |  | — |  |  |  | 10,678 |  |  |  | 7,334 |  |
| Foreign exchange loss (gain) |  |  | 3,925 |  |  |  | (3,303 | ) |  |  | 3,179 |  |
| Other expense (income), net |  |  | (6,644 | ) |  |  | (4,646 | ) |  |  | (5,396 | ) |
| Income before income taxes |  | $ | 131,646 |  |  | $ | 124,235 |  |  | $ | 100,052 |  |

[0001437749-15-003300:notes:202]
| (1) |  | Included in “Other” Operating income (loss) for 2014 are acquisition related fees ($0.4 million included in Selling, general and administrative expenses (“SG&A”)), non-cash charges for the sale of inventory that had been stepped-up to fair value at the acquisition date of SymCom ($2.8 million included in Cost of sales (“COS”)) (See Note 2), severance charges ($2.7 million in COS and $0.5 million in SG&A), internal legal restructuring costs ($2.2 million in SG&A) and asset impairments ($0.2 million in Research and development and $0.1 million in SG&A). |
|  |  | Included in “Other” Operating income (loss) for 2013 are acquisition related fees ($1.7 million included in SG&A) and non-cash charges for the sale of inventory that had been stepped-up to fair value at the acquisition date of Hamlin ($1.5 million included in COS (See Note 2)). |
|  |  | Included in “Other” Operating income (loss) for 2012 are acquisition related fees ($1.0 million included in SG&A), non-cash charges for the sale of inventory that had been stepped-up to fair value at the acquisition date of Accel and Terra Power ($0.6 million included in COS), charges related to a pension liability settlement ($5.1 million included in SG&A) (see Note 12), and asset impairment charges related to the sale of the Dünsen, Germany facility ($0.5 million included in SG&A) (See Note 11). |
| (2) |  | During the first quarter of 2013, the company recorded approximately $10.7 million related to the impairment of Shocking Technologies. During the fourth quarter of 2012, the company recorded approximately $7.3 million related to the impairment and equity in net loss of its investment in Shocking Technologies (See Note 6). |

[0001437749-15-003300:notes:203]
The company’s significant net sales, long-lived assets and additions to long-lived assets by country for the fiscal years ended 2014, 2013 and 2012 are as follows (in thousands):

[0001437749-15-003300:notes:204]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 313,762 |  |  | $ | 274,666 |  |  | $ | 222,530 |  |
| China |  |  | 189,191 |  |  |  | 158,494 |  |  |  | 142,553 |  |
| Other countries |  |  | 349,042 |  |  |  | 324,693 |  |  |  | 302,830 |  |
| Total net sales |  | $ | 851,995 |  |  | $ | 757,853 |  |  | $ | 667,913 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 34,179 |  |  | $ | 27,294 |  |  | $ | 14,433 |  |
| China |  |  | 40,981 |  |  |  | 45,843 |  |  |  | 41,504 |  |
| Canada |  |  | 12,899 |  |  |  | 14,429 |  |  |  | 13,839 |  |
| Other countries |  |  | 70,581 |  |  |  | 62,607 |  |  |  | 51,135 |  |
| Total long-lived assets |  | $ | 158,640 |  |  | $ | 150,173 |  |  | $ | 120,911 |  |

[0001437749-15-003300:notes:205]
| Additions to long-lived assets |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| United States |  | $ | 9,134 |  |  | $ | 4,644 |  |  | $ | 2,023 |  |
| China |  |  | 7,265 |  |  |  | 7,864 |  |  |  | 7,164 |  |
| Canada |  |  | 555 |  |  |  | 2,280 |  |  |  | 2,414 |  |
| Other countries |  |  | 15,327 |  |  |  | 20,165 |  |  |  | 10,928 |  |
| Total additions to long-lived assets |  | $ | 32,281 |  |  | $ | 34,953 |  |  | $ | 22,529 |  |

[0001437749-15-003300:notes:206]
For the year ended December 27, 2014, approximately 63% of the company’s net sales were to customers outside the United States (exports and foreign operations) including 22% to China. No single customer accounted for more than 10% of net sales during the last three years.


## us-gaap:CommitmentsDisclosureTextBlock

[0001437749-15-003300:notes:207]
16. Lease Commitments

[0001437749-15-003300:notes:208]
The company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was approximately $8.9 million in 2014, $8.9 million in 2013 and $9.1 million in 2012.

[0001437749-15-003300:notes:209]
Rent expense is recognized on a straight-line basis over the term of the leases. The difference between straight-line basis rent and the amount paid has been recorded as accrued lease obligations. The company also has leases that have lease renewal provisions. As of December 27, 2014, all operating leases outstanding were with third parties. The company did not have any capital leases as of December 27, 2014.

[0001437749-15-003300:notes:210]
Future minimum payments for all non-cancellable operating leases with initial terms of one year or more at December 27, 2014 are as follows (in thousands):

[0001437749-15-003300:notes:211]
| 2015 |  | $ | 8,384 |  |
| 2016 |  |  | 5,194 |  |
| 2017 |  |  | 3,823 |  |
| 2018 |  |  | 3,214 |  |
| 2019 |  |  | 3,140 |  |
| 2020 and thereafter |  |  | 13,076 |  |
|  |  | $ | 36,831 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-003300:notes:212]
17. Earnings Per Share

[0001437749-15-003300:notes:213]
As of January, 2014, the company no longer had “participating securities” as defined under ASC 260. As such, the company now calculates its earnings per share using the treasury method. All of the previous participating securities that resulted in the company using the two-class method have become fully vested or have otherwise expired.

[0001437749-15-003300:notes:214]
In 2013 and 2012, the company calculated its earnings per share using the two-class method which included an earnings allocation formula that determined earnings per share for each class of common stock according to dividends declared and undistributed earnings for the period. Previously, the company’s reported net earnings were reduced by the amount allocated to participating securities to arrive at the earnings allocated to common stock shareholders for purposes of calculating earnings per share under the two-class method.

[0001437749-15-003300:notes:215]
Under the previous two-class method calculation, the dilutive effect of participating securities was calculated using the more dilutive of the treasury stock or the two-class method. The company previously determined the two-class method to be the more dilutive. As such, the earnings allocated to common stock shareholders in the basic earnings per share calculation was adjusted for the reallocation of undistributed earnings to participating securities to arrive at the earnings allocated to common stock shareholders for calculating the diluted earnings per share.

[0001437749-15-003300:notes:216]
The following table sets forth the computation of basic and diluted earnings per share under the two-class method:

[0001437749-15-003300:notes:217]
| (In thousands, except per share amounts) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Net income as reported |  | $ | 99,418 |  |  | $ | 88,784 |  |  | $ | 75,332 |  |
| Less: Distributed earnings available to participating securities |  |  | — |  |  |  | (35 | ) |  |  | (30 | ) |
| Less: Undistributed earnings available to participating securities |  |  | — |  |  |  | (16 | ) |  |  | (98 | ) |
| Numerator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 99,418 |  |  | $ | 88,733 |  |  | $ | 75,204 |  |
| Add: Undistributed earnings allocated to participating securities |  |  | — |  |  |  | 16 |  |  |  | 98 |  |
| Less: Undistributed earnings reallocated to participating securities |  |  | — |  |  |  | (16 | ) |  |  | (97 | ) |
| Numerator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Undistributed and distributed earnings available to common shareholders |  | $ | 99,418 |  |  | $ | 88,733 |  |  | $ | 75,205 |  |
| Denominator for basic earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares |  |  | 22,543 |  |  |  | 22,315 |  |  |  | 21,822 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Common stock equivalents |  |  | 184 |  |  |  | 222 |  |  |  | 276 |  |
| Denominator for diluted earnings per share — |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted for weighted-average shares & assumed conversions |  |  | 22,727 |  |  |  | 22,537 |  |  |  | 22,098 |  |
| Basic earnings per share |  | $ | 4.41 |  |  | $ | 3.98 |  |  | $ | 3.45 |  |
| Diluted earnings per share |  | $ | 4.37 |  |  | $ | 3.94 |  |  | $ | 3.40 |  |

[0001437749-15-003300:notes:218]
The following potential shares of common stock attributable to stock options were excluded from the earnings per share calculation because their effect would be anti-dilutive: 43,693 in 2014; 96,401 in 2013; and 159,983 in 2012.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-15-003300:notes:219]
18. Selected Quarterly Financial Data (Unaudited)

[0001437749-15-003300:notes:220]
The quarterly periods listed in the table below for 2014 are for the 13-weeks ending December 27, 2014, September 27, 2014, June 28, 2014 and March 29, 2014 respectively. The quarterly periods for 2013 are for the 13-weeks ending December 28, 2013, September 28, 2013, June 29, 2013 and March 30, 2013, respectively.

[0001437749-15-003300:notes:221]
(In thousands, except per share data)

[0001437749-15-003300:notes:222]
|  |  | 2014 |  |  | 2013 |  |
|  |  | 4Qa |  |  | 3Qb |  |  | 2Qc |  |  | 1Qd |  |  | 4Qe |  |  | 3Qf |  |  | 2Qg |  |  | 1Qh |  |
| Net sales |  | $ | 206,620 |  |  | $ | 217,608 |  |  | $ | 220,908 |  |  | $ | 206,859 |  |  | $ | 198,129 |  |  | $ | 201,040 |  |  | $ | 187,766 |  |  | $ | 170,918 |  |
| Gross profit |  |  | 75,559 |  |  |  | 87,380 |  |  |  | 82,995 |  |  |  | 78,494 |  |  |  | 77,109 |  |  |  | 80,960 |  |  |  | 73,557 |  |  |  | 64,606 |  |
| Operating income |  |  | 26,391 |  |  |  | 40,130 |  |  |  | 33,719 |  |  |  | 33,590 |  |  |  | 32,823 |  |  |  | 37,559 |  |  |  | 31,382 |  |  |  | 28,117 |  |
| Net income (as previously reported) |  |  | 19,511 |  |  |  | 29,940 |  |  |  | 24,578 |  |  |  | 25,389 |  |  |  | 23,658 |  |  |  | 26,990 |  |  |  | 26,648 |  |  |  | 14,794 |  |
| Tax adjustment(d) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,306 | ) |
| Net income (Q1 2013 as restated) |  |  | 19,511 |  |  |  | 29,940 |  |  |  | 24,578 |  |  |  | 25,389 |  |  |  | 23,658 |  |  |  | 26,990 |  |  |  | 26,648 |  |  |  | 11,488 |  |
| Net income per share (as reported): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | 1.33 |  |  | $ | 1.09 |  |  | $ | 1.13 |  |  | $ | 1.05 |  |  | $ | 1.20 |  |  | $ | 1.19 |  |  | $ | 0.67 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 1.32 |  |  | $ | 1.08 |  |  | $ | 1.12 |  |  | $ | 1.04 |  |  | $ | 1.19 |  |  | $ | 1.18 |  |  | $ | 0.66 |  |
| Impact of tax adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (0.15 | ) |
| Diluted |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (0.15 | ) |
| Net income per share (Q1 2013 as restated): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | 1.33 |  |  | $ | 1.09 |  |  | $ | 1.13 |  |  | $ | 1.05 |  |  | $ | 1.20 |  |  | $ | 1.19 |  |  | $ | 0.52 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 1.32 |  |  | $ | 1.08 |  |  | $ | 1.12 |  |  | $ | 1.04 |  |  | $ | 1.19 |  |  | $ | 1.18 |  |  | $ | 0.51 |  |

[0001437749-15-003300:notes:223]
a – In the fourth quarter of 2014, the company recorded $2.2 million in charges related to severance and to the company’s reorganization of its internal legal structure to enable the up-streaming of cash to the U.S. The company also recorded $0.3 million in acquisition costs and $0.3 million in impairment costs.

[0001437749-15-003300:notes:224]
b – In the third quarter of 2014, the company recorded $1.1 million in charges related to the company’s reorganization of its internal legal structure, as noted above.

[0001437749-15-003300:notes:225]
c – In the second quarter of 2014, the company recorded a $1.4 million non-cash charge related to the step-up of inventory from the SymCom acquisition (See Note 2), $2.0 million in severance charges and $0.2 million in acquisition costs.

[0001437749-15-003300:notes:226]
d – In the first quarter of 2014, the company recorded a $1.4 million non-cash charge related to the step-up of inventory from the SymCom acquisition (See Note 2).

[0001437749-15-003300:notes:227]
e – In the fourth quarter of 2013, the company recorded a $2.8 million charge to income tax expense related to the company’s impairment of its investment in Shocking Technologies in the fourth quarter of 2012 (See Note 6). The company also recorded a $0.5 million non-cash credit related to the step-up of inventory from the Hamlin acquisition (See Note 2) and $0.2 million in acquisition expenses for the Hamlin acquisition.

[0001437749-15-003300:notes:228]
f – In the third quarter of 2013, the company recorded a $0.3 million non-cash charge related to the step-up of inventory from the Hamlin acquisition (See Note 2). The company also recorded $0.3 million in acquisition charges related to the Hamlin acquisition.

[0001437749-15-003300:notes:229]
g – In the second quarter of 2013, the company recorded a $1.7 million non-cash charge related to the step-up of inventory from the Hamlin acquisition (See Note 2). The company also recorded $1.2 million in acquisition charges related to the Hamlin acquisition.

[0001437749-15-003300:notes:230]
h – In the first quarter of 2013, the company recorded a $10.7 million charge related to the impairment of Shocking Technologies. Additionally, the company restated net income for a $3.3 million charge to income tax expense related to the company’s investment in Shocking Technologies (See Note 6).


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-15-003300:notes:231]
SCHEDULE II

[0001437749-15-003300:notes:232]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0001437749-15-003300:notes:233]
(In thousands of USD)

[0001437749-15-003300:notes:234]
| Description |  | Balance at Beginning of Year |  |  | Charged to Costs and Expenses (1) |  |  | Deductions (2) |  |  | Other (3) |  |  | Balance at End of Year |  |
| Year ended December 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 790 |  |  | $ | 130 |  |  | $ | 656 |  |  | $ | 14 |  |  | $ | 278 |  |
| Reserves for sales discounts and allowances |  | $ | 16,117 |  |  | $ | 85,825 |  |  | $ | 82,568 |  |  | $ | (234 | ) |  | $ | 19,140 |  |
| Deferred tax valuation allowance |  | $ | 6,250 |  |  | $ | — |  |  | $ | 1,693 |  |  | $ | — |  |  | $ | 4,557 |  |
| Year ended December 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 705 |  |  | $ | 2,289 |  |  | $ | 2,316 |  |  | $ | 112 |  |  | $ | 790 |  |
| Reserves for sales discounts and allowances |  | $ | 12,803 |  |  | $ | 77,659 |  |  | $ | 74,432 |  |  | $ | 87 |  |  | $ | 16,117 |  |
| Deferred tax valuation allowance |  | $ | 784 |  |  | $ | 6,085 |  |  | $ | 619 |  |  | $ | — |  |  | $ | 6,250 |  |
| Year ended December 29, 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable |  | $ | 394 |  |  | $ | 242 |  |  | $ | 51 |  |  | $ | 120 |  |  | $ | 705 |  |
| Reserves for sales discounts and allowances |  | $ | 11,912 |  |  | $ | 68,004 |  |  | $ | 67,055 |  |  | $ | (58 | ) |  | $ | 12,803 |  |
| Deferred tax valuation allowance |  | $ | 708 |  |  | $ | 76 |  |  | $ | — |  |  | $ | — |  |  | $ | 784 |  |

[0001437749-15-003300:notes:235]
|  | (1) | Includes provision for doubtful accounts, sales returns and sales discounts granted to customers. |

[0001437749-15-003300:notes:236]
|  | (2) | Represents uncollectible accounts written off, net of recoveries and credits issued to customers and the write-off of certain deferred tax assets that previously had full valuation allowances. |

[0001437749-15-003300:notes:237]
|  | (3) | Represents business acquisitions and foreign currency translation adjustments. |
