# LFUS MD&A — 0000889331-24-000129


## mdna

[0000889331-24-000129:mdna:1]
[same as prior period, unchanged from 0000889331-23-000157:mdna:1]

[0000889331-24-000129:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-24-000129:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 30, 2023.

[0000889331-24-000129:mdna:4]
[same as prior period, unchanged from 0000889331-23-000157:mdna:4]

[0000889331-24-000129:mdna:5]
[same as prior period, unchanged from 0000889331-23-000157:mdna:5]

[0000889331-24-000129:mdna:6]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-24-000129:mdna:7]
[same as prior period, unchanged from 0000889331-23-000157:mdna:7]

[0000889331-24-000129:mdna:8]
[same as prior period, unchanged from 0000889331-23-000157:mdna:8]

[0000889331-24-000129:mdna:9]
For the first quarter of 2024, the Company recognized net sales of $535.4 million, a decrease of $74.4 million, or 12.2% as compared to $609.8 million in the first quarter of 2023 including $1.8 million or 0.3% of unfavorable changes in foreign exchange rates. The decrease in net sales was primarily due to lower volume in the Electronics and Industrial segments. The Company recognized net income of $48.5 million, or $1.93 per diluted share, in the first quarter of 2024 compared to $88.7 million, or $3.54 per diluted share, in the first quarter of 2023. The decrease in net income was primarily due to lower operating income of $52.4 million in the Electronics segment driven by a reduction in volume.

[0000889331-24-000129:mdna:10]
Net cash provided by operating activities was $57.2 million for the three months ended March 30, 2024 compared to $53.4 million for the three months ended April 1, 2023. The increase in net cash provided by operating activities was primarily due to reductions in working capital and lower annual incentive compensation payments, partially offset by lower cash earnings.

[0000889331-24-000129:mdna:11]
Other Risks

[0000889331-24-000129:mdna:12]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies" that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-24-000129:mdna:13]
[same as prior period, unchanged from 0000889331-23-000157:mdna:15]

[0000889331-24-000129:mdna:14]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The first quarter of 2024 includes $2.3 million of restructuring charges primarily related to employee termination costs and a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first quarter of 2024, the Company recognized $0.9 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.3 million recorded for the sale of a building in the commercial vehicle business within the Transportation segment.

[0000889331-24-000129:mdna:15]
The first quarter of 2023 includes $3.3 million of legal and professional fees and other integration expenses related to completed acquisitions, and $1.9 million of restructuring, impairment, and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000129:mdna:16]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 535,385 |  |  | $ | 609,782 |  |  | $ | (74,397) |  |  | (12.2) | % |  |  |  |  |  |  |  |  |
| Cost of sales |  | 347,577 |  |  | 364,825 |  |  | (17,248) |  |  | (4.7) | % |  |  |  |  |  |  |  |  |
| Gross profit |  | 187,808 |  |  | 244,957 |  |  | (57,149) |  |  | (23.3) | % |  |  |  |  |  |  |  |  |
| Operating expenses |  | 132,856 |  |  | 134,316 |  |  | (1,460) |  |  | (1.1) | % |  |  |  |  |  |  |  |  |
| Operating income |  | 54,952 |  |  | 110,641 |  |  | (55,689) |  |  | (50.3) | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | 55,704 |  |  | 108,903 |  |  | (53,199) |  |  | (48.8) | % |  |  |  |  |  |  |  |  |
| Income taxes |  | 7,252 |  |  | 20,158 |  |  | (12,906) |  |  | (64.0) | % |  |  |  |  |  |  |  |  |
| Net income |  | $ | 48,452 |  |  | $ | 88,745 |  |  | $ | (40,293) |  |  | (45.4) | % |  |  |  |  |  |  |  |  |

[0000889331-24-000129:mdna:17]
[same as prior period, unchanged from 0000889331-23-000157:mdna:19]

[0000889331-24-000129:mdna:18]
Net sales decreased $74.4 million, or 12.2%, for the first quarter of 2024 compared to the first quarter of 2023 including $1.8 million or 0.3% of unfavorable changes in foreign exchange rates. The decrease in net sales was due to lower volume of $67.5 million and $10.6 million in the Electronics and Industrial segments, respectively, that more than offset higher volume in the passenger car products business within the Transportation segment.

[0000889331-24-000129:mdna:19]
[same as prior period, unchanged from 0000889331-23-000157:mdna:22]

[0000889331-24-000129:mdna:20]
Cost of sales was $347.6 million, or 64.9% of net sales, in the first quarter of 2024, compared to $364.8 million, or 59.8% of net sales, in the first quarter of 2023. As a percent of net sales, cost of sales increased 5.1% driven by lower volume in the Electronics and Industrial segments, partially offset by improved margin from the commercial vehicle and auto sensor businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000129:mdna:21]
[same as prior period, unchanged from 0000889331-23-000157:mdna:25]

[0000889331-24-000129:mdna:22]
Gross profit was $187.8 million, or 35.1% of net sales, in the first quarter of 2024 compared to $245.0 million, or 40.2% of net sales, for the first quarter of 2023. The $57.2 million decrease in gross profit was primarily due to lower volume in the Electronics and Industrial segments, partially offset by improved margin from the commercial vehicle and auto sensor businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000129:mdna:23]
[same as prior period, unchanged from 0000889331-23-000157:mdna:28]

[0000889331-24-000129:mdna:24]
Operating expenses were $132.9 million, or 24.8% of net sales, for the first quarter of 2024 compared to $134.3 million, or 22.0% of net sales, for the first quarter of 2023. The decrease in operating expenses of $1.5 million was primarily due to lower selling, general, and administrative expenses of $2.2 million and amortization expense of $1.0 million, partially offset by higher restructuring, impairment, and other charges of $1.4 million, including a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-24-000129:mdna:25]
[same as prior period, unchanged from 0000889331-23-000157:mdna:31]

[0000889331-24-000129:mdna:26]
Operating income was $55.0 million, representing a decrease of $55.7 million, or 50.3%, for the first quarter of 2024 compared to $110.6 million for the first quarter of 2023. The decrease in operating income was due to lower gross profit from the Electronics segment. Operating margins decreased from 18.1% in the first quarter of 2023 to 10.3% in the first quarter of 2024 driven by lower volume in the Electronics segment.

[0000889331-24-000129:mdna:27]
[same as prior period, unchanged from 0000889331-23-000157:mdna:34]

[0000889331-24-000129:mdna:28]
Income before income taxes was $55.7 million, or 10.4% of net sales, for the first quarter of 2024 compared to $108.9 million, or 17.9% of net sales, for the first quarter of 2023. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by higher foreign exchange gains of $3.4 million and higher interest income from short term investment in cash equivalents in the first quarter of 2024 compared to the first quarter of 2023, partially offset by unrealized losses of $0.4 million during the first quarter of 2024 compared to unrealized gains of $1.8 million during the first quarter of 2023 related to the Company's equity investment.

[0000889331-24-000129:mdna:29]
[same as prior period, unchanged from 0000889331-23-000157:mdna:37]

[0000889331-24-000129:mdna:30]
The effective tax rate for the three months ended March 30, 2024 was 13.0%, compared to the effective tax rate for the three months ended April 1, 2023 of 18.5%. The effective tax rate for the first quarter of 2024 is lower than the effective tax rate for the comparable 2023 period primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits. The effective tax rate for 2023 is lower than the statutory tax rate primarily due to income earned in lower tax jurisdictions, and the effective tax rate for 2024 is lower than the statutory tax rate primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits.

[0000889331-24-000129:mdna:31]
[same as prior period, unchanged from 0000889331-23-000157:mdna:40]

[0000889331-24-000129:mdna:32]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 14, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-24-000129:mdna:33]
[same as prior period, unchanged from 0000889331-23-000157:mdna:42]

[0000889331-24-000129:mdna:34]
| Net Sales |  | First Quarter |  |  |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 291,105 |  |  | $ | 358,593 |  |  | $ | (67,488) |  |  | (18.8) | % |  |  |  |  |  |  |  |  |
| Transportation |  | 170,367 |  |  | 166,641 |  |  | 3,726 |  |  | 2.2 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 73,913 |  |  | 84,548 |  |  | (10,635) |  |  | (12.6) | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 535,385 |  |  | $ | 609,782 |  |  | $ | (74,397) |  |  | (12.2) | % |  |  |  |  |  |  |  |  |

[0000889331-24-000129:mdna:35]
| Operating Income |  | First Quarter |  |  |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 37,803 |  |  | $ | 90,162 |  |  | $ | (52,359) |  |  | (58.1) | % |  |  |  |  |  |  |  |  |
| Transportation |  | 16,206 |  |  | 8,532 |  |  | 7,674 |  |  | 89.9 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 4,796 |  |  | 17,141 |  |  | (12,345) |  |  | (72.0) | % |  |  |  |  |  |  |  |  |
| Other (a) |  | (3,853) |  |  | (5,194) |  |  | 1,341 |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 54,952 |  |  | $ | 110,641 |  |  | $ | (55,689) |  |  | (50.3) | % |  |  |  |  |  |  |  |  |

[0000889331-24-000129:mdna:36]
(a) Included in “Other” Operating income for the first quarter of 2024 was $2.3 million of restructuring charges primarily related to employee termination costs and a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first quarter of 2024, the Company recognized $0.9 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.3 million recorded for the sale of a building in the commercial vehicle business within the Transportation segment.

[0000889331-24-000129:mdna:37]
Included in “Other” Operating income for the first quarter of 2023 was $3.3 million of legal and professional fees and other integration expenses related to completed acquisitions, and $1.9 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000129:mdna:38]
[same as prior period, unchanged from 0000889331-23-000157:mdna:47]

[0000889331-24-000129:mdna:39]
[same as prior period, unchanged from 0000889331-23-000157:mdna:48]

[0000889331-24-000129:mdna:40]
Net sales decreased $67.5 million, or 18.8%, in the first quarter of 2024 compared to the first quarter of 2023 and included unfavorable changes in foreign exchange rates of $0.9 million. The sales decrease was mainly due to lower volume across all businesses driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, as well as industrial markets.

[0000889331-24-000129:mdna:41]
[same as prior period, unchanged from 0000889331-23-000157:mdna:51]

[0000889331-24-000129:mdna:42]
Operating income was $37.8 million, representing a decrease of $52.4 million, or 58.1%, for the first quarter of 2024 compared to $90.2 million for the first quarter of 2023. The decrease in operating income was primarily due to lower volume leverage and unfavorable mix that were partially offset by cost control initiatives. Operating margins decreased from 25.1% in the first quarter of 2023 to 13.0% in the first quarter of 2024 primarily due to the lower volume.

[0000889331-24-000129:mdna:43]
[same as prior period, unchanged from 0000889331-23-000157:mdna:54]

[0000889331-24-000129:mdna:44]
[same as prior period, unchanged from 0000889331-23-000157:mdna:55]

[0000889331-24-000129:mdna:45]
Net sales increased $3.7 million, or 2.2%, in the first quarter of 2024 compared to the first quarter of 2023 and included unfavorable changes in foreign exchange rates of $0.8 million. The sales increase was mainly from the passenger car products business of $8.6 million driven by the ongoing electronification and electrification of vehicles and global passenger vehicle production growth, partially offset by sales declines of $4.6 million from the commercial vehicle business driven by reduced demand largely due to inventory rebalancing at certain distributors and customers.

[0000889331-24-000129:mdna:46]
[same as prior period, unchanged from 0000889331-23-000157:mdna:58]

[0000889331-24-000129:mdna:47]
Operating income was $16.2 million, representing an increase of $7.7 million, or 89.9%, for the first quarter of 2024 compared to $8.5 million for the first quarter of 2023. The increase in operating income was primarily due to favorable price and cost reduction initiatives  from the commercial vehicle business. Operating margins increased from 5.1% in the first quarter of 2023 to 9.5% in the first quarter of 2024 primarily driven by favorable price and cost reduction initiatives from the commercial vehicle business.

[0000889331-24-000129:mdna:48]
[same as prior period, unchanged from 0000889331-23-000157:mdna:61]

[0000889331-24-000129:mdna:49]
[same as prior period, unchanged from 0000889331-23-000157:mdna:62]

[0000889331-24-000129:mdna:50]
Net sales decreased by $10.6 million, or 12.6%, in the first quarter of 2024 compared to the first quarter of 2023, which included unfavorable changes in foreign exchange rates of $0.1 million. The sales decrease was due to lower volume across industrial circuit protection and industrial control products driven by slower end market demand.

[0000889331-24-000129:mdna:51]
[same as prior period, unchanged from 0000889331-23-000157:mdna:65]

[0000889331-24-000129:mdna:52]
Operating income was $4.8 million, representing a decrease of $12.3 million, or 72.0%, for the first quarter of 2024 compared to $17.1 million for the first quarter of 2023. The decrease in operating income was driven by lower volume due to reduced industrial end market demand across industrial circuit protection and industrial control products and unfavorable product mix. Operating margins decreased from 20.3% in the first quarter of 2023 to 6.5% in the first quarter of 2024.

[0000889331-24-000129:mdna:53]
[same as prior period, unchanged from 0000889331-23-000157:mdna:69]

[0000889331-24-000129:mdna:54]
[same as prior period, unchanged from 0000889331-23-000157:mdna:70]

[0000889331-24-000129:mdna:55]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Americas |  | $ | 214,784 |  |  | $ | 233,854 |  |  | $ | (19,070) |  |  | (8.2) | % |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 193,689 |  |  | 228,012 |  |  | (34,323) |  |  | (15.1) | % |  |  |  |  |  |  |  |  |
| Europe |  | 126,912 |  |  | 147,916 |  |  | (21,004) |  |  | (14.2) | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 535,385 |  |  | $ | 609,782 |  |  | $ | (74,397) |  |  | (12.2) | % |  |  |  |  |  |  |  |  |

[0000889331-24-000129:mdna:56]
[same as prior period, unchanged from 0000889331-23-000157:mdna:72]

[0000889331-24-000129:mdna:57]
Net sales decreased $19.1 million, or 8.2%, in the first quarter of 2024 compared to the first quarter of 2023 and included favorable changes in foreign exchange rates of $0.1 million. The decrease in net sales was primarily due to lower volume from the Electronics and Industrial segments, partially offset by higher volume from the passenger car products business within the Transportation segment compared to the first quarter of 2023.

[0000889331-24-000129:mdna:58]
[same as prior period, unchanged from 0000889331-23-000157:mdna:75]

[0000889331-24-000129:mdna:59]
Net sales decreased $34.3 million, or 15.1%, in the first quarter of 2024 compared to the first quarter of 2023 and included unfavorable changes in foreign exchange rates of $3.8 million. The decrease in net sales was primarily due to lower net sales from the Electronics and Industrial segments and lower net sales from the commercial vehicle business within the Transportation segment, partially offset by higher net sales from the passenger car products business within the Transportation segment compared to the first quarter of 2023.

[0000889331-24-000129:mdna:60]
[same as prior period, unchanged from 0000889331-23-000157:mdna:78]

[0000889331-24-000129:mdna:61]
Net sales decreased $21.0 million, or 14.2%, in the first quarter of 2024 compared to the first quarter of 2023 and included favorable changes in foreign exchange rates of $1.9 million. The decrease in net sales was primarily due to lower net sales from the Electronics segment and lower net sales from the commercial vehicle business within the Transportation segment compared to the first quarter of 2023.

[0000889331-24-000129:mdna:62]
[same as prior period, unchanged from 0000889331-23-000157:mdna:82]

[0000889331-24-000129:mdna:63]
[same as prior period, unchanged from 0000889331-23-000157:mdna:83]

[0000889331-24-000129:mdna:64]
Cash and cash equivalents were $562.2 million as of March 30, 2024, an increase of $6.6 million as compared to December 30, 2023. As of March 30, 2024, $157.9 million of the Company's $562.2 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-24-000129:mdna:65]
Revolving Credit Facility and Term Loan

[0000889331-24-000129:mdna:66]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-24-000129:mdna:67]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-24-000129:mdna:68]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 30, 2024, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $286.9 million, respectively, as of March 30, 2024.

[0000889331-24-000129:mdna:69]
[same as prior period, unchanged from 0000889331-23-000157:mdna:89]

[0000889331-24-000129:mdna:70]
As of March 30, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.68%, and 4.13% on the hedged portion.

[0000889331-24-000129:mdna:71]
As of March 30, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of March 30, 2024, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-24-000129:mdna:72]
[same as prior period, unchanged from 0000889331-23-000157:mdna:92]

[0000889331-24-000129:mdna:73]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-24-000129:mdna:74]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-24-000129:mdna:75]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-24-000129:mdna:76]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-24-000129:mdna:77]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-24-000129:mdna:78]
Debt Covenants

[0000889331-24-000129:mdna:79]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of March 30, 2024 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2023. As of March 30, 2024, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-24-000129:mdna:80]
[same as prior period, unchanged from 0000889331-23-000157:mdna:101]

[0000889331-24-000129:mdna:81]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the fab is approximately 93 million Euro, of which 37.2 million Euro down payment (approximately $40.5 million) recorded in Prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets was paid in the third quarter of 2023 after regulatory approvals and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-24-000129:mdna:82]
[same as prior period, unchanged from 0000889331-23-000157:mdna:104]

[0000889331-24-000129:mdna:83]
During the first quarter of 2024 the Company paid quarterly dividends of $16.2 million to the shareholders. On May 1, 2024, the Company announced the declaration of a quarterly cash dividend of $0.65 per share payable on June 6, 2024 to stockholders of record as of May 22, 2024.

[0000889331-24-000129:mdna:84]
[same as prior period, unchanged from 0000889331-23-000157:mdna:106]

[0000889331-24-000129:mdna:85]
|  |  | First Three Months |
| (in thousands) |  | 2024 |  | 2023 |
| Net cash provided by operating activities |  | $ | 57,150 |  |  | $ | 53,407 |  |
| Net cash used in investing activities |  | (8,483) |  |  | (183,188) |  |
| Net cash used in financing activities |  | (33,520) |  |  | (12,204) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (8,550) |  |  | 4,571 |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 6,597 |  |  | (137,414) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 557,123 |  |  | 564,939 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 563,720 |  |  | $ | 427,525 |  |

[0000889331-24-000129:mdna:86]
[same as prior period, unchanged from 0000889331-23-000157:mdna:108]

[0000889331-24-000129:mdna:87]
[same as prior period, unchanged from 0000889331-23-000157:mdna:109]

[0000889331-24-000129:mdna:88]
Net cash provided by operating activities was $57.2 million for the three months ended March 30, 2024 compared to $53.4 million for the three months ended April 1, 2023. The increase in net cash provided by operating activities was primarily due to reductions in working capital and lower annual incentive compensation payments, partially offset by lower cash earnings.

[0000889331-24-000129:mdna:89]
[same as prior period, unchanged from 0000889331-23-000157:mdna:111]

[0000889331-24-000129:mdna:90]
Net cash used in investing activities was $8.5 million for the three months ended March 30, 2024 compared to $183.2 million during the three months ended April 1, 2023. Capital expenditures were $15.5 million, representing a decrease of $10.1 million compared to three months ended April 1, 2023. During the three months ended March 30, 2024, the Company received proceeds of $7.1 million from the sale of a building from the commercial vehicle business within the Transportation segment. Net cash paid for acquisitions was $158.3 million during the three months ended April 1, 2023.

[0000889331-24-000129:mdna:91]
[same as prior period, unchanged from 0000889331-23-000157:mdna:113]

[0000889331-24-000129:mdna:92]
Net cash used in financing activities was $33.5 million for the three months ended March 30, 2024 compared to $12.2 million during the three months ended April 1, 2023. During the three months ended March 30, 2024 and April 1, 2023, the Company made payments of $1.9 million on the term loan for both periods, respectively. The Company paid dividends of $16.2 million and $14.9 million in the three months ended March 30, 2024 and April 1, 2023, respectively. Additionally, during the three months ended March 30, 2024, the Company repurchased 70,280 shares of its common stock totaling $16.1 million.

[0000889331-24-000129:mdna:93]
[same as prior period, unchanged from 0000889331-23-000157:mdna:115]

[0000889331-24-000129:mdna:94]
The Company’s Board of Directors authorized the repurchase of up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 (2021 program). During the three months ended March 30, 2024, the Company repurchased 70,280 shares of its common stock totaling $16.1 million. There is $283.9 million of an authorized amount yet purchased under the 2021 program as of March 30, 2024. The Company did not repurchase shares of its common stock for the three months ended April 1, 2023.

[0000889331-24-000129:mdna:95]
On April 25, 2024, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 to replace its 2021 program.

[0000889331-24-000129:mdna:96]
[same as prior period, unchanged from 0000889331-23-000157:mdna:118]

[0000889331-24-000129:mdna:97]
As of March 30, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-24-000129:mdna:98]
[same as prior period, unchanged from 0000889331-23-000157:mdna:120]

[0000889331-24-000129:mdna:99]
[same as prior period, unchanged from 0000889331-23-000157:mdna:121]

[0000889331-24-000129:mdna:100]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 30, 2023. During the three months ended March 30, 2024, there were no significant changes in the application of critical accounting policies and estimates.
