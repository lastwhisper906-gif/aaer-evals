# LFUS note change history — 0000889331-23-000157 → 0000889331-24-000129


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2024-05-01):
[0000889331-24-000129:note_history:1]
Commitments and Contingencies
Off-Balance Sheet Arrangements

- added (2024-05-01):
[0000889331-24-000129:note_history:2]
As of March 30, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

- added (2024-05-01):
[0000889331-24-000129:note_history:3]
Product Warranty Liabilities

- added (2024-05-01):
[0000889331-24-000129:note_history:4]
The company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

- added (2024-05-01):
[0000889331-24-000129:note_history:5]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

- added (2024-05-01):
[0000889331-24-000129:note_history:6]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

- added (2024-05-01):
[0000889331-24-000129:note_history:7]
Environmental Remediation Liabilities

- added (2024-05-01):
[0000889331-24-000129:note_history:8]
The company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at  its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

- added (2024-05-01):
[0000889331-24-000129:note_history:9]
Legal Proceedings

- added (2024-05-01):
[0000889331-24-000129:note_history:10]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

- added (2024-05-01):
[0000889331-24-000129:note_history:11]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss and therefore the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may  be changed when events result in an expectation different than previously expected.

- added (2024-05-01):
[0000889331-24-000129:note_history:12]
Pending Litigation and Claims

- added (2024-05-01):
[0000889331-24-000129:note_history:13]
There are no material pending litigation or claims outstanding as of March 30, 2024.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000889331-24-000129:note_history:14]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2024 and April 1, 2023:
  (was, 2023-11-01, similarity 0.8968):
[0000889331-23-000157:note_history:14]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 30, 2023 and October 1, 2022:

- added (2024-05-01):
[0000889331-24-000129:note_history:15]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |

- added (2024-05-01):
[0000889331-24-000129:note_history:16]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 209,995 |  |  | $ | — |  |  | $ | — |  |  | $ | 209,995 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,598 |  |  | — |  |  | — |  |  | 148,598 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |

- changed (2024-05-01):
[0000889331-24-000129:note_history:17]
See Note 14, Segment Information, for net sales by segment and countries.
  (was, 2023-11-01, similarity 0.9929):
[0000889331-23-000157:note_history:17]
See Note 15, Segment Information for net sales by segment and countries.

- changed (2024-05-01):
[0000889331-24-000129:note_history:18]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowances, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.
  (was, 2023-11-01, similarity 0.9995):
[0000889331-23-000157:note_history:18]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

- changed (2024-05-01):
[0000889331-24-000129:note_history:19]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.
  (was, 2023-11-01, similarity 0.9922):
[0000889331-23-000157:note_history:19]
The Company elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- changed (2024-05-01):
[0000889331-24-000129:note_history:20]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2023-11-01, similarity 0.7646):
[0000889331-23-000157:note_history:20]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its

- changed (2024-05-01):
[0000889331-24-000129:note_history:21]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.
  (was, 2023-11-01, similarity 0.968):
[0000889331-23-000157:note_history:21]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

- changed (2024-05-01):
[0000889331-24-000129:note_history:22]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 30, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2023-11-01, similarity 0.8117):
[0000889331-23-000157:note_history:22]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at September 30, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2024-05-01):
[0000889331-24-000129:note_history:23]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 562,153 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,567 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 563,720 |  |  | $ | 557,123 |  |
  (was, 2023-11-01, similarity 0.786):
[0000889331-23-000157:note_history:23]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 560,056 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | — |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,535 |  |  | 1,549 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 561,591 |  |  | $ | 564,939 |  |

- added (2024-05-01):
[0000889331-24-000129:note_history:24]
Recently Adopted Accounting Standards

- changed (2024-05-01):
[0000889331-24-000129:note_history:25]
In March 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU")ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Condensed Consolidated Financial Statements.
  (was, 2023-11-01, similarity 0.8316):
[0000889331-23-000157:note_history:25]
In March 2023, the FASB issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective on January 1, 2024. The Company does not expect any material effect on the Company's Condensed Consolidated Financial Statements.

- added (2024-05-01):
[0000889331-24-000129:note_history:26]
In March 2024, the Securities and Exchange Commission (SEC) issued a final rule that requires registrants to provide climate disclosures in annual reports and registration statements. The climate-related final rule requires disclosures in the footnotes to the financial statements, including: 1) specified financial statement effects of severe weather events and other natural conditions, 2) certain carbon offsets and renewable energy credits or certificates if used as a material component of a registrant's plans to achieve its disclosed climate-related targets or goals, 3) material impacts on financial estimates and assumptions in the financial statements if they would materially impacted by risks and uncertainties associated with severe weather events and other natural conditions, previously disclosed climate-related targets, and transition plans. The financial statement disclosure requirements are effective beginning with annual reports for the fiscal year beginning in calendar year 2025, for the Company as a large accelerated filer. These disclosures will be subject to existing audit requirement for financial statements. On April 4, 2024, the SEC chose to stay its climate disclosure rules pending judicial review. The adoption of this rule will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating and is in the process of performing its initial assessment of the potential impact on its Condensed Consolidated Financial Statements.

- added (2024-05-01):
[0000889331-24-000129:note_history:27]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures". The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

- added (2024-05-01):
[0000889331-24-000129:note_history:28]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures". The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of  the Chief Operating Decision Maker (“CODM”) on annual basis as well as an explanation of how CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

- changed (2024-05-01):
[0000889331-24-000129:note_history:29]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements". The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and  will not be
  (was, 2023-11-01, similarity 0.777):
[0000889331-23-000157:note_history:29]
In October 2023, the Financial Accounting Standards Board ("FASB") issued ASU No. 2023-06, "Disclosure Improvements". The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and  will not be effective until June 30, 2027. The company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

- added (2024-05-01):
[0000889331-24-000129:note_history:30]
effective until June 30, 2027. The company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.

- removed (2024-05-01):
[0000889331-23-000157:note_history:31]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,410 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,410 |  |  | $ | 453,860 |  |  | $ | — |  |  | $ | — |  |  | $ | 453,860 |  |
| Electronics – Semiconductor |  | 191,523 |  |  | — |  |  | — |  |  | 191,523 |  |  | 598,813 |  |  | — |  |  | — |  |  | 598,813 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  | — |  |  | — |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- removed (2024-05-01):
[0000889331-23-000157:note_history:32]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  |  |  |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |

- removed (2024-05-01):
[0000889331-23-000157:note_history:33]
price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000889331-24-000129:note_history:34]
The carrying amounts of debt at March 30, 2024 and December 30, 2023 are as follows:
  (was, 2023-11-01, similarity 0.9342):
[0000889331-23-000157:note_history:34]
The carrying amounts of debt at September 30, 2023 and December 31, 2022 are as follows:

- changed (2024-05-01):
[0000889331-24-000129:note_history:35]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 286,875 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,458 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,857 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,517) |  |  | (3,770) |  |
| Total debt |  | 866,673 |  |  | 871,935 |  |
| Less: Current maturities |  | (65,824) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 800,849 |  |  | $ | 857,915 |  |
  (was, 2023-11-01, similarity 0.9479):
[0000889331-23-000157:note_history:35]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 290,625 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 123,605 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 100,363 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,056 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,024) |  |  | (4,847) |  |
| Total debt |  | 992,625 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (135,619) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 857,006 |  |  | $ | 866,623 |  |

- changed (2024-05-01):
[0000889331-24-000129:note_history:36]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.
  (was, 2023-11-01, similarity 0.8408):
[0000889331-23-000157:note_history:36]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to

- changed (2024-05-01):
[0000889331-24-000129:note_history:37]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 30, 2024, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $286.9 million, respectively, as of March 30, 2024.
  (was, 2023-11-01, similarity 0.948):
[0000889331-23-000157:note_history:37]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and nine months ended September 30, 2023, the Company made payments of $1.9 million and $5.6 million on its term loan, respectively. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $290.6 million, respectively, as of September 30, 2023.

- changed (2024-05-01):
[0000889331-24-000129:note_history:38]
As of March 30, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.68%, and 4.13% on the hedged portion.
  (was, 2023-11-01, similarity 0.6067):
[0000889331-23-000157:note_history:38]
As of September 30, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 6.67%.

- changed (2024-05-01):
[0000889331-24-000129:note_history:39]
As of March 30, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving credit facility. As of March 30, 2024, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2023-11-01, similarity 0.9505):
[0000889331-23-000157:note_history:39]
As of September 30, 2023, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving Credit Facility. As of September 30, 2023, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2024-05-01):
[0000889331-24-000129:note_history:40]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.
  (was, 2023-11-01, similarity 0.839):
[0000889331-23-000157:note_history:40]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

- changed (2024-05-01):
[0000889331-24-000129:note_history:41]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 30, 2024, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2023-11-01, similarity 0.9878):
[0000889331-23-000157:note_history:41]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 30, 2023, the Company was in compliance with all covenants under the Senior Notes.

- changed (2024-05-01):
[0000889331-24-000129:note_history:42]
Interest paid on all Company debt was $13.2 million and $11.0 million for the three months ended March 30, 2024 and April 1, 2023, respectively.
  (was, 2023-11-01, similarity 0.6022):
[0000889331-23-000157:note_history:42]
Interest paid on all Company debt was $11.9 million and $8.5 million for the three months ended September 30, 2023 and October 1, 2022, respectively, and $33.2 million and $16.9 million for the nine months ended September 30, 2023 and October 1, 2022, respectively.

- removed (2024-05-01):
[0000889331-23-000157:note_history:43]
0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000889331-24-000129:note_history:44]
The carrying amounts of debt at March 30, 2024 and December 30, 2023 are as follows:
  (was, 2023-11-01, similarity 0.9342):
[0000889331-23-000157:note_history:44]
The carrying amounts of debt at September 30, 2023 and December 31, 2022 are as follows:

- changed (2024-05-01):
[0000889331-24-000129:note_history:45]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 286,875 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,458 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,857 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,517) |  |  | (3,770) |  |
| Total debt |  | 866,673 |  |  | 871,935 |  |
| Less: Current maturities |  | (65,824) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 800,849 |  |  | $ | 857,915 |  |
  (was, 2023-11-01, similarity 0.9479):
[0000889331-23-000157:note_history:45]
| (in thousands) |  | September 30, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 290,625 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 123,605 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 100,363 |  |  | 101,265 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 7,056 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,024) |  |  | (4,847) |  |
| Total debt |  | 992,625 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (135,619) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 857,006 |  |  | $ | 866,623 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2024-05-01):
[0000889331-24-000129:note_history:46]
|  |  | Three Months Ended March 30, 2024 |  | Three Months Ended April 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 2.1 |  |  | 1.0 |  | 0.1 |  | 2.7 |  |
|  |  | March 30, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.8 |  | $ | 0.1 |  | $ | 1.5 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |

- removed (2024-05-01):
[0000889331-23-000157:note_history:47]
|  |  | Three Months Ended September 30, 2023 |  | Three Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.1 |  | 2.0 |  |  | — |  | 0.1 |  | 2.9 |  |
|  |  | Nine Months Ended September 30, 2023 |  | Nine Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.3 |  | 0.3 |  | 7.6 |  |  | 0.3 |  | 0.3 |  | 8.8 |  |
|  |  | September 30, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.8 |  | $ | — |  | $ | 1.6 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2024-05-01):
[0000889331-24-000129:note_history:48]
|  |  | Three Months Ended March 30, 2024 |  | Three Months Ended April 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 2.1 |  |  | 1.0 |  | 0.1 |  | 2.7 |  |
|  |  | March 30, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.8 |  | $ | 0.1 |  | $ | 1.5 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |

- removed (2024-05-01):
[0000889331-23-000157:note_history:49]
|  |  | Three Months Ended September 30, 2023 |  | Three Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.1 |  | 2.0 |  |  | — |  | 0.1 |  | 2.9 |  |
|  |  | Nine Months Ended September 30, 2023 |  | Nine Months Ended October 1, 2022 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.7 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.3 |  | 0.3 |  | 7.6 |  |  | 0.3 |  | 0.3 |  | 8.8 |  |
|  |  | September 30, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.8 |  | $ | — |  | $ | 1.6 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000889331-24-000129:note_history:50]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2024 and April 1, 2023:
  (was, 2023-11-01, similarity 0.8968):
[0000889331-23-000157:note_history:50]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 30, 2023 and October 1, 2022:

- added (2024-05-01):
[0000889331-24-000129:note_history:51]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |

- added (2024-05-01):
[0000889331-24-000129:note_history:52]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 209,995 |  |  | $ | — |  |  | $ | — |  |  | $ | 209,995 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,598 |  |  | — |  |  | — |  |  | 148,598 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |

- removed (2024-05-01):
[0000889331-23-000157:note_history:53]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 152,410 |  |  | $ | — |  |  | $ | — |  |  | $ | 152,410 |  |  | $ | 453,860 |  |  | $ | — |  |  | $ | — |  |  | $ | 453,860 |  |
| Electronics – Semiconductor |  | 191,523 |  |  | — |  |  | — |  |  | 191,523 |  |  | 598,813 |  |  | — |  |  | — |  |  | 598,813 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  | — |  |  | — |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- removed (2024-05-01):
[0000889331-23-000157:note_history:54]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  |  |  |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000889331-24-000129:note_history:55]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowances, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.
  (was, 2023-11-01, similarity 0.9995):
[0000889331-23-000157:note_history:55]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

- changed (2024-05-01):
[0000889331-24-000129:note_history:56]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.
  (was, 2023-11-01, similarity 0.9922):
[0000889331-23-000157:note_history:56]
The Company elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- changed (2024-05-01):
[0000889331-24-000129:note_history:57]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2023-11-01, similarity 0.7646):
[0000889331-23-000157:note_history:57]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its

- changed (2024-05-01):
[0000889331-24-000129:note_history:58]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.
  (was, 2023-11-01, similarity 0.968):
[0000889331-23-000157:note_history:58]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

- removed (2024-05-01):
[0000889331-23-000157:note_history:59]
price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
