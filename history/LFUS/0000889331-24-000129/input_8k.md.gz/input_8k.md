# LFUS 8-K — 0000889331-24-000125 filed 2024-04-30

## item codes, every 8-K on or before 2024-05-01

- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2024-05-01

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-24-000125:8k_2_02:1]
EX-99.1
2
q12024earningsreleaseex991.htm
EX-99.1

[0000889331-24-000125:8k_2_02:2]
Document

[0000889331-24-000125:8k_2_02:3]
Exhibit 99.1

[0000889331-24-000125:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0000889331-24-000125:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2024

[0000889331-24-000125:8k_2_02:6]
Solid execution drives Q1 sales above, and EPS in-line with guidance

[0000889331-24-000125:8k_2_02:7]
CHICAGO, April 30, 2024  - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the first quarter ended March 30, 2024:

[0000889331-24-000125:8k_2_02:8]
•Net sales of $535 million were down 12% versus the prior year period, and down 12% organically

[0000889331-24-000125:8k_2_02:9]
•GAAP diluted EPS was $1.93 and adjusted diluted EPS was $1.76

[0000889331-24-000125:8k_2_02:10]
•Cash flow from operations was $57 million and free cash flow was $42 million

[0000889331-24-000125:8k_2_02:11]
“Our global team delivered solid first quarter results, with sales above and earnings in-line with our expectations, as our increasingly diversified end market exposures, robust technology offering, and portfolio optimization initiatives helped to offset ongoing inventory destocking” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Further, our strong cash generation reflects disciplined execution, while our well-positioned balance sheet will continue to allow us to capitalize on growth opportunities. Looking forward, we remain confident in an expected return to growth during 2024, and believe our experienced team, agile operations and unwavering long-term strategic focus will drive top-tier value for our stakeholders.”

[0000889331-24-000125:8k_2_02:12]
Second Quarter of 2024*

[0000889331-24-000125:8k_2_02:13]
Based on current market conditions, for the second quarter the company expects,

[0000889331-24-000125:8k_2_02:14]
•Net sales in the range of $525 - $555 million, adjusted diluted EPS in the range of $1.65 - $1.85 and an adjusted effective tax rate of approximately 23%

[0000889331-24-000125:8k_2_02:15]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-24-000125:8k_2_02:16]
-more-

[0000889331-24-000125:8k_2_02:17]
Dividend and Share Repurchase Authorization

[0000889331-24-000125:8k_2_02:18]
•The company’s Board of Directors approved a new stock repurchase authorization to replace its expiring previous 3-year program. The company may repurchase up to $300 million in the aggregate of shares of the company’s common stock for the period May 1, 2024, to April 30, 2027.

[0000889331-24-000125:8k_2_02:19]
•The company will pay a cash dividend on its common stock of $0.65 per share on June 6, 2024, to shareholders of record as of May 23, 2024

[0000889331-24-000125:8k_2_02:20]
Conference Call and Webcast Information

[0000889331-24-000125:8k_2_02:21]
Littelfuse will host a conference call on Wednesday, May 1, 2024, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-24-000125:8k_2_02:22]
About Littelfuse

[0000889331-24-000125:8k_2_02:23]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-24-000125:8k_2_02:24]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 30, 2023.

[0000889331-24-000125:8k_2_02:25]
-more

[0000889331-24-000125:8k_2_02:26]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 30, 2023, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-24-000125:8k_2_02:27]
Non-GAAP Financial Measures

[0000889331-24-000125:8k_2_02:28]
The information included in this press release includes the non-GAAP financial measures of organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-24-000125:8k_2_02:29]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-24-000125:8k_2_02:30]
The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-24-000125:8k_2_02:31]
LFUS-F

[0000889331-24-000125:8k_2_02:32]
###

[0000889331-24-000125:8k_2_02:33]
|  | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000www.littelfuse.com |

[0000889331-24-000125:8k_2_02:34]
LITTELFUSE, INC.

[0000889331-24-000125:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-24-000125:8k_2_02:36]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | March 30,2024 |  | December 30,2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 562,153 |  |  | $ | 555,513 |  |
| Short-term investments |  | 231 |  |  | 235 |  |
| Trade receivables, less allowances of $76,496 and $84,696 at March 30, 2024 and December 30, 2023, respectively |  | 295,876 |  |  | 287,018 |  |
| Inventories |  | 456,135 |  |  | 474,607 |  |
| Prepaid income taxes and income taxes receivable |  | 8,574 |  |  | 8,701 |  |
| Prepaid expenses and other current assets |  | 121,142 |  |  | 82,526 |  |
| Total current assets |  | 1,444,111 |  |  | 1,408,600 |  |
| Net property, plant, and equipment |  | 479,435 |  |  | 493,153 |  |
| Intangible assets, net of amortization |  | 584,631 |  |  | 606,136 |  |
| Goodwill |  | 1,294,737 |  |  | 1,309,998 |  |
| Investments |  | 24,204 |  |  | 24,821 |  |
| Deferred income taxes |  | 10,798 |  |  | 10,486 |  |
| Right of use lease assets |  | 63,718 |  |  | 62,370 |  |
| Other long-term assets |  | 41,827 |  |  | 79,711 |  |
| Total assets |  | $ | 3,943,461 |  |  | $ | 3,995,275 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 172,809 |  |  | $ | 173,535 |  |
| Accrued liabilities |  | 124,288 |  |  | 149,214 |  |
| Accrued income taxes |  | 42,051 |  |  | 38,725 |  |
| Current portion of long-term debt |  | 65,824 |  |  | 14,020 |  |
| Total current liabilities |  | 404,972 |  |  | 375,494 |  |
| Long-term debt, less current portion |  | 800,849 |  |  | 857,915 |  |
| Deferred income taxes |  | 100,755 |  |  | 110,820 |  |
| Accrued post-retirement benefits |  | 34,049 |  |  | 34,422 |  |
| Non-current lease liabilities |  | 50,791 |  |  | 49,472 |  |
| Other long-term liabilities |  | 80,752 |  |  | 86,671 |  |
| Total equity |  | 2,471,293 |  |  | 2,480,481 |  |
| Total liabilities and equity |  | $ | 3,943,461 |  |  | $ | 3,995,275 |  |

[0000889331-24-000125:8k_2_02:37]
LITTELFUSE, INC.

[0000889331-24-000125:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-24-000125:8k_2_02:39]
(Unaudited)

[0000889331-24-000125:8k_2_02:40]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share data) |  | March 30,2024 |  | April 1,2023 |  |  |  |  |
| Net sales |  | $ | 535,385 |  |  | $ | 609,782 |  |  |  |  |  |
| Cost of sales |  | 347,577 |  |  | 364,825 |  |  |  |  |  |
| Gross profit |  | 187,808 |  |  | 244,957 |  |  |  |  |  |
| Selling, general, and administrative expenses |  | 86,127 |  |  | 88,310 |  |  |  |  |  |
| Research and development expenses |  | 27,667 |  |  | 27,290 |  |  |  |  |  |
| Amortization of intangibles |  | 15,825 |  |  | 16,866 |  |  |  |  |  |
| Restructuring, impairment, and other charges |  | 3,237 |  |  | 1,850 |  |  |  |  |  |
| Total operating expenses |  | 132,856 |  |  | 134,316 |  |  |  |  |  |
| Operating income |  | 54,952 |  |  | 110,641 |  |  |  |  |  |
| Interest expense |  | 9,611 |  |  | 9,646 |  |  |  |  |  |
| Foreign exchange gain |  | (5,042) |  |  | (1,675) |  |  |  |  |  |
| Other income, net |  | (5,321) |  |  | (6,233) |  |  |  |  |  |
| Income before income taxes |  | 55,704 |  |  | 108,903 |  |  |  |  |  |
| Income taxes |  | 7,252 |  |  | 20,158 |  |  |  |  |  |
| Net income |  | $ | 48,452 |  |  | $ | 88,745 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.95 |  |  | $ | 3.58 |  |  |  |  |  |
| Diluted |  | $ | 1.93 |  |  | $ | 3.54 |  |  |  |  |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,911 |  |  | 24,782 |  |  |  |  |  |
| Diluted |  | 25,124 |  |  | 25,062 |  |  |  |  |  |
| Comprehensive income |  | $ | 18,161 |  |  | $ | 102,028 |  |  |  |  |  |

[0000889331-24-000125:8k_2_02:41]
LITTELFUSE, INC.

[0000889331-24-000125:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-24-000125:8k_2_02:43]
(Unaudited)

[0000889331-24-000125:8k_2_02:44]
|  |  | Three Months Ended |
| (in thousands) |  | March 30, 2024 |  | April 1, 2023 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 48,452 |  |  | $ | 88,745 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 28,729 |  |  | 32,558 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (12,723) |  |  | (13,176) |  |
| Inventories |  | 16,179 |  |  | (1,535) |  |
| Accounts payable |  | 345 |  |  | (16,246) |  |
| Accrued liabilities and income taxes |  | (28,042) |  |  | (43,578) |  |
| Prepaid expenses and other assets |  | 4,210 |  |  | 6,639 |  |
| Net cash provided by operating activities |  | 57,150 |  |  | 53,407 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (158,260) |  |
| Purchases of property, plant, and equipment |  | (15,547) |  |  | (25,665) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 7,064 |  |  | 737 |  |
| Net cash used in investing activities |  | (8,483) |  |  | (183,188) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (1,875) |  |  | (1,875) |  |
| Repurchases of common stock |  | (16,131) |  |  | — |  |
| Cash dividends paid |  | (16,200) |  |  | (14,880) |  |
| All other cash provided by financing activities |  | 686 |  |  | 4,551 |  |
| Net cash used in financing activities |  | (33,520) |  |  | (12,204) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (8,550) |  |  | 4,571 |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 6,597 |  |  | (137,414) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 557,123 |  |  | 564,939 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 563,720 |  |  | $ | 427,525 |  |

[0000889331-24-000125:8k_2_02:45]
LITTELFUSE, INC.

[0000889331-24-000125:8k_2_02:46]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-24-000125:8k_2_02:47]
(Unaudited)

[0000889331-24-000125:8k_2_02:48]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2024 |  | 2023 |  |  |  | %(Decline) / Growth |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 291,105 |  |  | $ | 358,593 |  |  |  |  | (18.8) | % |  |  |  |  |  |  |  |  |
| Transportation |  | 170,367 |  |  | 166,641 |  |  |  |  | 2.2 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 73,913 |  |  | 84,548 |  |  |  |  | (12.6) | % |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 535,385 |  |  | $ | 609,782 |  |  |  |  | (12.2) | % |  |  |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 37,803 |  |  | $ | 90,162 |  |  |  |  | (58.1) | % |  |  |  |  |  |  |  |  |
| Transportation |  | 16,206 |  |  | 8,532 |  |  |  |  | 89.9 | % |  |  |  |  |  |  |  |  |
| Industrial |  | 4,796 |  |  | 17,141 |  |  |  |  | (72.0) | % |  |  |  |  |  |  |  |  |
| Other(a) |  | (3,853) |  |  | (5,194) |  |  |  |  | N.M. |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 54,952 |  |  | $ | 110,641 |  |  |  |  | (50.3) | % |  |  |  |  |  |  |  |  |
| Operating Margin |  | 10.3 | % |  | 18.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 9,611 |  |  | 9,646 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange gain |  | (5,042) |  |  | (1,675) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income, net |  | (5,321) |  |  | (6,233) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 55,704 |  |  | $ | 108,903 |  |  |  |  | (48.8) | % |  |  |  |  |  |  |  |  |

[0000889331-24-000125:8k_2_02:49]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-24-000125:8k_2_02:50]
N.M. - Not meaningful

[0000889331-24-000125:8k_2_02:51]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2024 |  | 2023 |  | %(Decline)/Growth |  |  |  |  |  |  |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 13.0 | % |  | 25.1 | % |  | (12.1) | % |  |  |  |  |  |  |
| Transportation |  | 9.5 | % |  | 5.1 | % |  | 4.4 | % |  |  |  |  |  |  |
| Industrial |  | 6.5 | % |  | 20.3 | % |  | (13.8) | % |  |  |  |  |  |  |

[0000889331-24-000125:8k_2_02:52]
LITTELFUSE, INC.

[0000889331-24-000125:8k_2_02:53]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-24-000125:8k_2_02:54]
(In millions of USD except per share amounts - unaudited)

[0000889331-24-000125:8k_2_02:55]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-24 |  | Q1-23 |  |  |  |  |
| GAAP diluted EPS |  | $ | 1.93 |  |  | $ | 3.54 |  |  |  |  |  |
| EPS impact of Non-GAAP adjustments (below) |  | (0.17) |  |  | 0.10 |  |  |  |  |  |
| Adjusted diluted EPS |  | $ | 1.76 |  |  | $ | 3.64 |  |  |  |  |  |

[0000889331-24-000125:8k_2_02:56]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q1-24 |  | Q1-23 |  |  |  |  |
| Acquisition-related and integration costs (a) |  | $ | 0.9 |  |  | $ | 3.3 |  |  |  |  |  |
| Restructuring, impairment and other charges (b) |  | 3.2 |  |  | 1.9 |  |  |  |  |  |
| Gain on sale of fixed assets (c) |  | (0.3) |  |  | — |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 3.8 |  |  | 5.2 |  |  |  |  |  |
| Other loss (income), net (d) |  | 0.2 |  |  | (0.2) |  |  |  |  |  |
| Non-operating foreign exchange gain |  | (5.0) |  |  | (1.7) |  |  |  |  |  |
| Non-GAAP adjustments to income before income taxes |  | (1.0) |  |  | 3.3 |  |  |  |  |  |
| Income taxes (e) |  | 3.3 |  |  | 0.9 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | $ | (4.3) |  |  | $ | 2.4 |  |  |  |  |  |
| Total EPS impact |  | $ | (0.17) |  |  | $ | 0.10 |  |  |  |  |  |

[0000889331-24-000125:8k_2_02:57]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-24 |  | Q1-23 |  |  |  |  |
| Net income |  | $ | 48.5 |  |  | $ | 88.7 |  |  |  |  |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 7.3 |  |  | 20.2 |  |  |  |  |  |
| Interest expense |  | 9.6 |  |  | 9.6 |  |  |  |  |  |
| Foreign exchange gain |  | (5.0) |  |  | (1.7) |  |  |  |  |  |
| Other income, net |  | (5.3) |  |  | (6.2) |  |  |  |  |  |
| GAAP operating income |  | $ | 55.0 |  |  | $ | 110.6 |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 3.8 |  |  | 5.2 |  |  |  |  |  |
| Adjusted operating income |  | $ | 58.8 |  |  | $ | 115.8 |  |  |  |  |  |
| Amortization of intangibles |  | 15.8 |  |  | 16.9 |  |  |  |  |  |
| Depreciation expenses |  | 16.7 |  |  | 17.6 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 91.3 |  |  | $ | 150.3 |  |  |  |  |  |
| Net sales |  | $ | 535.4 |  |  | $ | 609.8 |  |  |  |  |  |
| Net income as a percentage of net sales |  | 9.1 | % |  | 14.5 | % |  |  |  |  |
| Operating margin |  | 10.3 | % |  | 18.1 | % |  |  |  |  |
| Adjusted operating margin |  | 11.0 | % |  | 19.0 | % |  |  |  |  |
| Adjusted EBITDA margin |  | 17.1 | % |  | 24.6 | % |  |  |  |  |

[0000889331-24-000125:8k_2_02:58]
| Adjusted EBITDA by Segment |  | Q1-24 |  | Q1-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 37.8 |  |  | $ | 16.2 |  |  | $ | 4.8 |  |  | $ | 90.2 |  |  | $ | 8.5 |  |  | $ | 17.1 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 9.8 |  |  | 3.4 |  |  | 2.6 |  |  | 10.2 |  |  | 4.5 |  |  | 2.2 |  |
| Add back depreciation |  | 10.0 |  |  | 5.3 |  |  | 1.4 |  |  | 9.6 |  |  | 6.8 |  |  | 1.2 |  |
| Adjusted EBITDA |  | $ | 57.6 |  |  | $ | 24.9 |  |  | $ | 8.8 |  |  | $ | 110.0 |  |  | $ | 19.8 |  |  | $ | 20.5 |  |
| Adjusted EBITDA Margin |  | 19.8 | % |  | 14.6 | % |  | 11.9 | % |  | 30.7 | % |  | 11.9 | % |  | 24.3 | % |

[0000889331-24-000125:8k_2_02:59]
| Net sales reconciliation |  | Q1-24 vs. Q1-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (19) | % |  | 2 | % |  | (13) | % |  | (12) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | — | % |  | 1 | % |  | — | % |
| FX impact |  | — | % |  | (1) | % |  | — | % |  | — | % |
| Organic net sales (decline) growth |  | (19) | % |  | 3 | % |  | (14) | % |  | (12) | % |

[0000889331-24-000125:8k_2_02:60]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-24 |  | Q1-23 |  |  |  |  |
| Income taxes |  | $ | 7.3 |  |  | $ | 20.2 |  |  |  |  |  |
| Effective rate |  | 13.0 | % |  | 18.5 | % |  |  |  |  |
| Non-GAAP adjustments - income taxes |  | 3.3 |  |  | 0.9 |  |  |  |  |  |
| Adjusted income taxes |  | $ | 10.6 |  |  | $ | 21.1 |  |  |  |  |  |
| Adjusted effective rate |  | 19.3 | % |  | 18.8 | % |  |  |  |  |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-24 |  | Q1-23 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 57.1 |  |  | $ | 53.4 |  |  |  |  |  |
| Less: Purchases of property, plant and equipment |  | (15.5) |  |  | (25.7) |  |  |  |  |  |
| Free cash flow |  | $ | 41.6 |  |  | $ | 27.7 |  |  |  |  |  |

[0000889331-24-000125:8k_2_02:61]
| Consolidated Total Debt |  | As of March 30, 2024 |
| Consolidated Total Debt |  | $ | 866.7 |  |
| Unamortized debt issuance costs |  | 3.5 |  |
| Finance lease liability |  | 0.6 |  |
| Consolidated funded indebtedness |  | 870.8 |  |
| Cash held in U.S. (up to $400 million) |  | 157.9 |
| Net debt |  | $ | 712.9 |  |
| Consolidated EBITDA |  | Twelve Months Ended March 30, 2024 |
| Net Income |  | $ | 219.1 |  |
| Interest expense |  | 39.8 |  |
| Income taxes |  | 56.2 |  |
| Depreciation |  | 70.7 |  |
| Amortization |  | 64.8 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 23.8 |  |
| Purchase accounting inventory step-up charge |  | — |  |
| Unrealized loss on investments |  | 2.5 |  |
| Impairment charges |  | 5.8 |  |
| Other |  | 18.3 |  |
| Consolidated EBITDA (1) |  | $ | 501.0 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.4x |

[0000889331-24-000125:8k_2_02:62]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2024 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-24-000125:8k_2_02:63]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-24-000125:8k_2_02:64]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-24-000125:8k_2_02:65]
Note: Total will not always foot due to rounding.

[0000889331-24-000125:8k_2_02:66]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-24-000125:8k_2_02:67]
(b) reflected in restructuring, impairment and other charges.

[0000889331-24-000125:8k_2_02:68]
(c) 2024 amount included $0.3 million gain from the sale of a building within the Transportation segment.

[0000889331-24-000125:8k_2_02:69]
(d) 2024 amount reflected $0.2 million increase in coal mining reserves, while 2023 amount included $0.2 million gain from the sale of a building within the Electronics segment.

[0000889331-24-000125:8k_2_02:70]
(e) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-24-000125:8k_2_02:71]
###
