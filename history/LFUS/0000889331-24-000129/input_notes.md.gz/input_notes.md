# LFUS notes — 0000889331-24-000129


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-24-000129:notes:1]
[same as prior period, unchanged from 0000889331-23-000157:notes:1]

[0000889331-24-000129:notes:2]
[same as prior period, unchanged from 0000889331-23-000157:notes:2]

[0000889331-24-000129:notes:3]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-24-000129:notes:4]
[same as prior period, unchanged from 0000889331-23-000157:notes:4]

[0000889331-24-000129:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statements of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 30, 2023, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-24-000129:notes:6]
[same as prior period, unchanged from 0000889331-23-000157:notes:6]

[0000889331-24-000129:notes:7]
[same as prior period, unchanged from 0000889331-23-000157:notes:7]

[0000889331-24-000129:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2024 and April 1, 2023:

[0000889331-24-000129:notes:9]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |

[0000889331-24-000129:notes:10]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 209,995 |  |  | $ | — |  |  | $ | — |  |  | $ | 209,995 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,598 |  |  | — |  |  | — |  |  | 148,598 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |

[0000889331-24-000129:notes:11]
See Note 14, Segment Information, for net sales by segment and countries.

[0000889331-24-000129:notes:12]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowances, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-24-000129:notes:13]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-24-000129:notes:14]
[same as prior period, unchanged from 0000889331-23-000157:notes:14]

[0000889331-24-000129:notes:15]
[same as prior period, unchanged from 0000889331-23-000157:notes:15]

[0000889331-24-000129:notes:16]
[same as prior period, unchanged from 0000889331-23-000157:notes:16]

[0000889331-24-000129:notes:17]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-24-000129:notes:18]
[same as prior period, unchanged from 0000889331-23-000157:notes:19]

[0000889331-24-000129:notes:19]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historical activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-24-000129:notes:20]
[same as prior period, unchanged from 0000889331-23-000157:notes:21]

[0000889331-24-000129:notes:21]
[same as prior period, unchanged from 0000889331-23-000157:notes:22]

[0000889331-24-000129:notes:22]
[same as prior period, unchanged from 0000889331-23-000157:notes:23]

[0000889331-24-000129:notes:23]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 30, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-24-000129:notes:24]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 562,153 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,567 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 563,720 |  |  | $ | 557,123 |  |

[0000889331-24-000129:notes:25]
Recently Adopted Accounting Standards

[0000889331-24-000129:notes:26]
In March 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU")ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

[0000889331-24-000129:notes:27]
Recently Issued Accounting Standards

[0000889331-24-000129:notes:28]
In March 2024, the Securities and Exchange Commission (SEC) issued a final rule that requires registrants to provide climate disclosures in annual reports and registration statements. The climate-related final rule requires disclosures in the footnotes to the financial statements, including: 1) specified financial statement effects of severe weather events and other natural conditions, 2) certain carbon offsets and renewable energy credits or certificates if used as a material component of a registrant's plans to achieve its disclosed climate-related targets or goals, 3) material impacts on financial estimates and assumptions in the financial statements if they would materially impacted by risks and uncertainties associated with severe weather events and other natural conditions, previously disclosed climate-related targets, and transition plans. The financial statement disclosure requirements are effective beginning with annual reports for the fiscal year beginning in calendar year 2025, for the Company as a large accelerated filer. These disclosures will be subject to existing audit requirement for financial statements. On April 4, 2024, the SEC chose to stay its climate disclosure rules pending judicial review. The adoption of this rule will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating and is in the process of performing its initial assessment of the potential impact on its Condensed Consolidated Financial Statements.

[0000889331-24-000129:notes:29]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures". The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

[0000889331-24-000129:notes:30]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures". The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of  the Chief Operating Decision Maker (“CODM”) on annual basis as well as an explanation of how CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

[0000889331-24-000129:notes:31]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements". The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and  will not be

[0000889331-24-000129:notes:32]
effective until June 30, 2027. The company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000889331-24-000129:notes:33]
[same as prior period, unchanged from 0000889331-23-000157:notes:29]

[0000889331-24-000129:notes:34]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Condensed Consolidated Financial Statements from the date of the acquisition.

[0000889331-24-000129:notes:35]
[same as prior period, unchanged from 0000889331-23-000157:notes:32]

[0000889331-24-000129:notes:36]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the Dortmund Fab is approximately 93 million Euro, of which 37.2 million Euro down payment (approximately $40.5 million) recorded in Prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets was paid in the third quarter of 2023 after regulatory approvals and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-24-000129:notes:37]
[same as prior period, unchanged from 0000889331-23-000157:notes:34]

[0000889331-24-000129:notes:38]
[same as prior period, unchanged from 0000889331-23-000157:notes:35]

[0000889331-24-000129:notes:39]
The acquisition was funded with cash on hand. The total purchase consideration of $158.3 million, net of cash acquired, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0000889331-24-000129:notes:40]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Western Automation acquisition:

[0000889331-24-000129:notes:41]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 158,260 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables | 3,359 |  |
| Inventories | 3,678 |  |
| Other current assets | 718 |  |
| Property, plant, and equipment | 1,328 |  |
| Intangible assets | 68,000 |  |
| Goodwill | 93,937 |  |
| Other long-term assets | 573 |  |
| Current liabilities | (4,335) |  |
| Other long-term liabilities | (8,998) |  |
|  | $ | 158,260 |  |

[0000889331-24-000129:notes:42]
[same as prior period, unchanged from 0000889331-23-000157:notes:39]

[0000889331-24-000129:notes:43]
During the three months ended April 1, 2023, the Company incurred approximately $1.4 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-24-000129:notes:44]
[same as prior period, unchanged from 0000889331-23-000157:notes:52]

[0000889331-24-000129:notes:45]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and Western Automation as though the acquisition had occurred as of January 2, 2022. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Western Automation acquisition occurred as of January 2, 2022, or of future consolidated operating results.

[0000889331-24-000129:notes:46]
|  |  |  |  | For the Three Months Ended |  |  |
| (in thousands, except per share amounts) |  |  |  | April 1, 2023 |  |  |  |  |
| Net sales |  |  |  | $ | 611,668 |  |  |  |  |  |
| Income before income taxes |  |  |  | 110,613 |  |  |  |  |  |
| Net income |  |  |  | 90,241 |  |  |  |  |  |
| Net income per share — basic |  |  |  | 3.64 |  |  |  |  |  |
| Net income per share — diluted |  |  |  | 3.60 |  |  |  |  |  |

[0000889331-24-000129:notes:47]
[same as prior period, unchanged from 0000889331-23-000157:notes:55]

[0000889331-24-000129:notes:48]
|  |  |  |  | For the Three Months Ended |  |  |
| (in thousands) |  |  |  | April 1, 2023 |  |  |  |  |
| Amortization (a) |  |  |  | $ | (479) |  |  |  |  |  |
| Transaction costs (b) |  |  |  | 1,397 |  |  |  |  |  |
| Income tax expense of above items |  |  |  | (115) |  |  |  |  |  |

[0000889331-24-000129:notes:49]
(a) The amortization adjustment for the three months ended April 1, 2023 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-24-000129:notes:50]
(b) The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three months ended April 1, 2023, and recognition of those fees during the three months ended April 2, 2022.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-24-000129:notes:51]
[same as prior period, unchanged from 0000889331-23-000157:notes:61]

[0000889331-24-000129:notes:52]
The components of inventories at March 30, 2024 and December 30, 2023 are as follows:

[0000889331-24-000129:notes:53]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Raw materials |  | $ | 201,625 |  |  | $ | 201,984 |  |
| Work in process |  | 142,598 |  |  | 137,688 |  |
| Finished goods |  | 173,149 |  |  | 195,886 |  |
| Inventory reserves |  | (61,237) |  |  | (60,951) |  |
| Total |  | $ | 456,135 |  |  | $ | 474,607 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-24-000129:notes:54]
[same as prior period, unchanged from 0000889331-23-000157:notes:64]

[0000889331-24-000129:notes:55]
The components of net property, plant, and equipment at March 30, 2024 and December 30, 2023 are as follows:

[0000889331-24-000129:notes:56]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Land and land improvements |  | $ | 18,529 |  |  | $ | 22,212 |  |
| Building and building improvements |  | 196,292 |  |  | 202,764 |  |
| Machinery and equipment |  | 862,653 |  |  | 859,060 |  |
| Accumulated depreciation |  | (598,039) |  |  | (590,883) |  |
| Total |  | $ | 479,435 |  |  | $ | 493,153 |  |

[0000889331-24-000129:notes:57]
The Company recorded depreciation expense of $16.7 million and $17.6 million for the three months ended March 30, 2024 and April 1, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-24-000129:notes:58]
[same as prior period, unchanged from 0000889331-23-000157:notes:68]

[0000889331-24-000129:notes:59]
Changes in the carrying value of goodwill by segment for the three months ended March 30, 2024 are as follows:

[0000889331-24-000129:notes:60]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net goodwill as of December 30, 2023 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 30, 2023 |  | $ | 936,505 |  |  | $ | 237,115 |  |  | $ | 179,117 |  |  | $ | 1,352,737 |  |
| Accumulated impairment losses as of December 30, 2023 |  | — |  |  | (34,004) |  |  | (8,735) |  |  | (42,739) |  |
| Total |  | 936,505 |  |  | 203,111 |  |  | 170,382 |  |  | 1,309,998 |  |
| Changes during 2024: |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments |  | (13,103) |  |  | (2,003) |  |  | (155) |  |  | (15,261) |  |
| Net goodwill as of March 30, 2024 |  |  |  |  |  |  |  |  |
| Gross goodwill as of March 30, 2024 |  | 923,402 |  |  | 234,620 |  |  | 178,761 |  |  | 1,336,783 |  |
| Accumulated impairment losses as of March 30, 2024 |  | — |  |  | (33,512) |  |  | $ | (8,534) |  |  | (42,046) |  |
| Total |  | $ | 923,402 |  |  | $ | 201,108 |  |  | $ | 170,227 |  |  | $ | 1,294,737 |  |

[0000889331-24-000129:notes:61]
The components of other intangible assets as of March 30, 2024 and December 30, 2023 are as follows:

[0000889331-24-000129:notes:62]
|  |  |  | As of March 30, 2024 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 17,298 |  |  | $ | 2,864 |  |  | $ | 14,434 |  |
| Patents, licenses, and software |  |  | 271,905 |  |  | 167,403 |  |  | 104,502 |  |
| Distribution network |  |  | 41,917 |  |  | 41,917 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 681,982 |  |  | 216,287 |  |  | 465,695 |  |
| Total |  |  | $ | 1,013,102 |  |  | $ | 428,471 |  |  | $ | 584,631 |  |

[0000889331-24-000129:notes:63]
|  | December 30, 2023 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 17,621 |  |  | $ | 2,786 |  |  | $ | 14,835 |  |
| Patents, licenses, and software | 275,337 |  |  | 163,799 |  |  | 111,538 |  |
| Distribution network | 43,210 |  |  | 43,210 |  |  | — |  |
| Customer relationships, trademarks, and tradenames | 689,244 |  |  | 209,481 |  |  | 479,763 |  |
| Total | $ | 1,025,412 |  |  | $ | 419,276 |  |  | $ | 606,136 |  |

[0000889331-24-000129:notes:64]
During the three months ended March 30, 2024 and April 1, 2023, the Company recorded amortization expense of $15.8 million and $16.9 million, respectively.

[0000889331-24-000129:notes:65]
Estimated annual amortization expense related to intangible assets with definite lives as of March 30, 2024 is as follows:

[0000889331-24-000129:notes:66]
| (in thousands) | Amount |
| Remainder of 2024 | $ | 47,167 |  |
| 2025 | 62,662 |  |
| 2026 | 51,823 |  |
| 2027 | 49,755 |  |
| 2028 | 49,135 |  |
| 2029 and thereafter | 324,089 |  |
| Total | $ | 584,631 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-24-000129:notes:67]
[same as prior period, unchanged from 0000889331-23-000157:notes:80]

[0000889331-24-000129:notes:68]
The components of accrued liabilities as of March 30, 2024 and December 30, 2023 are as follows:

[0000889331-24-000129:notes:69]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Employee-related liabilities |  | $ | 56,285 |  |  | $ | 72,635 |  |
| Current lease liability |  | 11,531 |  |  | 12,110 |  |
| Other non-income taxes |  | 7,828 |  |  | 7,855 |  |
| Other customer reserves |  | 5,399 |  |  | 5,998 |  |
| Professional services |  | 5,229 |  |  | 5,282 |  |
| Interest |  | 3,191 |  |  | 6,387 |  |
| Restructuring liability |  | 2,081 |  |  | 2,141 |  |
| Current benefit liability |  | 1,482 |  |  | 1,482 |  |
| Deferred revenue |  | 1,400 |  |  | 2,198 |  |
| Other |  | 29,862 |  |  | 33,126 |  |
| Total |  | $ | 124,288 |  |  | $ | 149,214 |  |

[0000889331-24-000129:notes:70]
Employee-related liabilities consist primarily of payroll, sales commissions, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other customer-related liabilities.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-24-000129:notes:71]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three months ended March 30, 2024 and April 1, 2023 as follows:

[0000889331-24-000129:notes:72]
|  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 544 |  |  | $ | 1,190 |  |  | $ | 435 |  |  | $ | 2,169 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 52 |  |  | 78 |  |  | 5 |  |  | 135 |  |  |  |  |  |  |  |  |  |
| Total restructuring charges | 596 |  |  | 1,268 |  |  | 440 |  |  | 2,304 |  |  |  |  |  |  |  |  |  |
| Impairment | — |  |  | 933 |  |  | — |  |  | 933 |  |  |  |  |  |  |  |  |  |
| Total | $ | 596 |  |  | $ | 2,201 |  |  | $ | 440 |  |  | $ | 3,237 |  |  |  |  |  |  |  |  |  |

[0000889331-24-000129:notes:73]
|  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 672 |  |  | $ | 582 |  |  | $ | 317 |  |  | $ | 1,571 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 7 |  |  | 272 |  |  | — |  |  | 279 |  |  |  |  |  |  |  |  |  |
| Total | $ | 679 |  |  | $ | 854 |  |  | $ | 317 |  |  | $ | 1,850 |  |  |  |  |  |  |  |  |  |

[0000889331-24-000129:notes:74]
2024

[0000889331-24-000129:notes:75]
For the three months ended March 30, 2024, the Company recorded total restructuring charges of $2.3 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment’s commercial vehicle business, and the reorganization of certain selling and administrative functions within the Electronics and Industrial segments. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-24-000129:notes:76]
[same as prior period, unchanged from 0000889331-23-000157:notes:87]

[0000889331-24-000129:notes:77]
For the three months ended April 1, 2023, the Company recorded total restructuring charges of $1.9 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment’s commercial vehicle business and the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K acquisition.

[0000889331-24-000129:notes:78]
The restructuring reserves as of both March 30, 2024 and December 30, 2023 is $2.1 million. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in the fourth quarter fiscal year 2024.


## us-gaap:DebtDisclosureTextBlock

[0000889331-24-000129:notes:79]
Debt

[0000889331-24-000129:notes:80]
The carrying amounts of debt at March 30, 2024 and December 30, 2023 are as follows:

[0000889331-24-000129:notes:81]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 286,875 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,458 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,857 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,517) |  |  | (3,770) |  |
| Total debt |  | 866,673 |  |  | 871,935 |  |
| Less: Current maturities |  | (65,824) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 800,849 |  |  | $ | 857,915 |  |

[0000889331-24-000129:notes:82]
Revolving Credit Facility and Term Loan

[0000889331-24-000129:notes:83]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-24-000129:notes:84]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-24-000129:notes:85]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 30, 2024, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $286.9 million, respectively, as of March 30, 2024.

[0000889331-24-000129:notes:86]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-24-000129:notes:87]
As of March 30, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.68%, and 4.13% on the hedged portion.

[0000889331-24-000129:notes:88]
As of March 30, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving credit facility. As of March 30, 2024, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-24-000129:notes:89]
Senior Notes

[0000889331-24-000129:notes:90]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-24-000129:notes:91]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-24-000129:notes:92]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-24-000129:notes:93]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-24-000129:notes:94]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-24-000129:notes:95]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-24-000129:notes:96]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 30, 2024, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-24-000129:notes:97]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-24-000129:notes:98]
Interest paid on all Company debt was $13.2 million and $11.0 million for the three months ended March 30, 2024 and April 1, 2023, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-24-000129:notes:99]
[same as prior period, unchanged from 0000889331-23-000157:notes:113]

[0000889331-24-000129:notes:100]
[same as prior period, unchanged from 0000889331-23-000157:notes:114]

[0000889331-24-000129:notes:101]
[same as prior period, unchanged from 0000889331-23-000157:notes:115]

[0000889331-24-000129:notes:102]
[same as prior period, unchanged from 0000889331-23-000157:notes:116]

[0000889331-24-000129:notes:103]
[same as prior period, unchanged from 0000889331-23-000157:notes:117]

[0000889331-24-000129:notes:104]
[same as prior period, unchanged from 0000889331-23-000157:notes:118]

[0000889331-24-000129:notes:105]
[same as prior period, unchanged from 0000889331-23-000157:notes:119]

[0000889331-24-000129:notes:106]
[same as prior period, unchanged from 0000889331-23-000157:notes:120]

[0000889331-24-000129:notes:107]
[same as prior period, unchanged from 0000889331-23-000157:notes:121]

[0000889331-24-000129:notes:108]
[same as prior period, unchanged from 0000889331-23-000157:notes:122]

[0000889331-24-000129:notes:109]
[same as prior period, unchanged from 0000889331-23-000157:notes:123]

[0000889331-24-000129:notes:110]
[same as prior period, unchanged from 0000889331-23-000157:notes:124]

[0000889331-24-000129:notes:111]
[same as prior period, unchanged from 0000889331-23-000157:notes:125]

[0000889331-24-000129:notes:112]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by market observable data.

[0000889331-24-000129:notes:113]
The use of derivatives creates exposure to credit risk relating to potential losses that could be recognized in the event that the counterparties to these instruments fail to perform their obligations under the contracts. The Company seeks to minimize this risk by limiting its counterparties to major financial institutions with acceptable credit ratings and monitoring the total value of positions with individual counterparties. In the event of a default by one of its counterparties, the Company may not receive payments provided for under the terms of its derivatives.

[0000889331-24-000129:notes:114]
[same as prior period, unchanged from 0000889331-23-000157:notes:129]

[0000889331-24-000129:notes:115]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at July 14, 2022 was €117.0 million and expired on December 7, 2023 with the final settlement value of $6.3 million which the Company used to convert USD to Euro to pay down the €117.0 million of Euro Senior Notes, Series A due 2023. The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly basis. As a result, changes in fair value during 2023 were reported in Foreign exchange gain in the Condensed Consolidated Statements of Net Income. The fair value of the foreign currency forward contract was valued using market exchange rates by a third party and classified as a Level 2 input under the fair value hierarchy.

[0000889331-24-000129:notes:116]
As of March 30, 2024 and December 30, 2023, the fair values of the Company's derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-24-000129:notes:117]
| (in thousands) | Condensed Consolidated Balance Sheet Classification |  | March 30, 2024 |  | December 30, 2023 |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 3,952 |  |  | $ | 3,712 |  |  |  |
|  | Other long-term assets |  | $ | 4,434 |  |  | $ | 2,140 |  |  |  |

[0000889331-24-000129:notes:118]
The pre-tax gains recognized on derivative financial instruments in the Condensed Consolidated Statements of Net Income for the three months ended March 30, 2024 and April 1, 2023 were as follows:

[0000889331-24-000129:notes:119]
|  |  |  |  | Three Months Ended |  |  |
| (in thousands) |  | Classification of Gain Recognized in the Condensed Consolidated Statements of Net Income |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (1,280) |  |  | $ | (975) |  |  |  |  |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  | Foreign exchange gain |  | $ | — |  |  | $ | (819) |  |  |  |  |  |

[0000889331-24-000129:notes:120]
The pre-tax (gains) recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three months ended March 30, 2024 and April 1, 2023 was as follows:

[0000889331-24-000129:notes:121]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | (2,534) |  |  | $ | (5,366) |  |  |  |  |  |

[0000889331-24-000129:notes:122]
The pre-tax gain of $4.2 million from accumulated other comprehensive loss to earnings is expected to be recognized during the next twelve months.

[0000889331-24-000129:notes:123]
[same as prior period, unchanged from 0000889331-23-000157:notes:138]

[0000889331-24-000129:notes:124]
[same as prior period, unchanged from 0000889331-23-000157:notes:139]

[0000889331-24-000129:notes:125]
There were no changes during the quarter ended March 30, 2024 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of March 30, 2024 and December 30, 2023, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-24-000129:notes:126]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of March 30, 2024:

[0000889331-24-000129:notes:127]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 452,453 |  |  | $ | — |  |  | $ | — |  |  | $ | 452,453 |  |
| Investments in equity securities |  | 10,178 |  |  | — |  |  | — |  |  | 10,178 |  |
| Mutual funds |  | 21,509 |  |  | — |  |  | — |  |  | 21,509 |  |
| Total |  | $ | 484,140 |  |  | $ | — |  |  | $ | — |  |  | $ | 484,140 |  |

[0000889331-24-000129:notes:128]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 30, 2023:

[0000889331-24-000129:notes:129]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 415,788 |  |  | $ | — |  |  | $ | — |  |  | $ | 415,788 |  |
| Investments in equity securities |  | 10,832 |  |  | — |  |  | — |  |  | 10,832 |  |
| Mutual funds |  | 20,148 |  |  | — |  |  | — |  |  | 20,148 |  |
| Total |  | $ | 446,768 |  |  | $ | — |  |  | $ | — |  |  | $ | 446,768 |  |

[0000889331-24-000129:notes:130]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at March 30, 2024 and December 30, 2023, as the rates on these borrowings are variable in nature.

[0000889331-24-000129:notes:131]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of March 30, 2024 and December 30, 2023 were as follows:

[0000889331-24-000129:notes:132]
|  |  | March 30, 2024 |  | December 30, 2023 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 |  | $ | 102,458 |  |  | $ | 93,470 |  |  | $ | 105,246 |  |  | $ | 96,532 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 95,654 |  |  | 100,000 |  |  | 96,127 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 49,203 |  |  | 50,000 |  |  | 49,070 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 114,269 |  |  | 125,000 |  |  | 115,687 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 91,365 |  |  | 100,000 |  |  | 93,228 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-24-000129:notes:133]
[same as prior period, unchanged from 0000889331-23-000157:notes:149]

[0000889331-24-000129:notes:134]
[same as prior period, unchanged from 0000889331-23-000157:notes:150]

[0000889331-24-000129:notes:135]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three months ended March 30, 2024 and April 1, 2023 were as follows:

[0000889331-24-000129:notes:136]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 795 |  |  | $ | 692 |  |  |  |  |  |
| Interest cost |  | 995 |  |  | 937 |  |  |  |  |  |
| Expected return on plan assets |  | (518) |  |  | (469) |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | 46 |  |  | 11 |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 1,318 |  |  | $ | 1,171 |  |  |  |  |  |

[0000889331-24-000129:notes:137]
The Company expects to make approximately $2.2 million of contributions to the plans and pay $2.1 million of benefits directly in 2024.

[0000889331-24-000129:notes:138]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.7 million and $0.4 million for the three months ended March 30, 2024 and April 1, 2023, respectively, in Cost of Sales and Other income, net within the Condensed Consolidated Statements of Net Income. The pre-tax (gains) losses amount recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.3 million and nominal for the three months ended March 30, 2024 and April 1, 2023, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-24-000129:notes:139]
Other Comprehensive Income (Loss)
Changes in other comprehensive income (loss) by component were as follows:

[0000889331-24-000129:notes:140]
| (in thousands) |  | Three Months EndedMarch 30, 2024 |  | Three Months EndedApril 1, 2023 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 360 |  |  | $ | (16) |  |  | $ | 344 |  |  | $ | 24 |  |  | $ | (18) |  |  | $ | 6 |  |
| Cash flow hedge |  | 2,534 |  |  | (608) |  |  | 1,926 |  |  | (3,313) |  |  | 795 |  |  | (2,518) |  |
| Foreign currency translation adjustments (a) |  | (33,170) |  |  | 609 |  |  | (32,561) |  |  | 16,068 |  |  | (273) |  |  | 15,795 |  |
| Total change in other comprehensive (loss) income |  | $ | (30,276) |  |  | $ | (15) |  |  | $ | (30,291) |  |  | $ | 12,779 |  |  | $ | 504 |  |  | $ | 13,283 |  |

[0000889331-24-000129:notes:141]
[same as prior period, unchanged from 0000889331-23-000157:notes:157]

[0000889331-24-000129:notes:142]
The following tables set forth the changes in accumulated other comprehensive loss by component for the three months ended March 30, 2024 and April 1, 2023:

[0000889331-24-000129:notes:143]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at December 30, 2023 |  | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| Activity in the period |  | 344 |  |  | 1,926 |  |  | (32,561) |  |  | (30,291) |  |
| Balance at March 30, 2024 |  | $ | (7,269) |  |  | $ | 6,374 |  |  | $ | (85,213) |  |  | $ | (86,108) |  |

[0000889331-24-000129:notes:144]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at December 31, 2022 |  | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| Activity in the period |  | 6 |  |  | (2,518) |  |  | 15,795 |  |  | 13,283 |  |
| Balance at April 1, 2023 |  | $ | (2,187) |  |  | $ | 4,078 |  |  | $ | (84,372) |  |  | $ | (82,481) |  |

[0000889331-24-000129:notes:145]
Amounts reclassified from accumulated other comprehensive loss to earnings for the three months ended March 30, 2024 and April 1, 2023 were as follows:

[0000889331-24-000129:notes:146]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Pension and postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss (gain) |  | $ | 356 |  |  | $ | (11) |  |  |  |  |  |

[0000889331-24-000129:notes:147]
The Company recognizes the amortization of prior service costs in Other income, net within the Condensed Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-24-000129:notes:148]
Income Taxes
The effective tax rate for the three months ended March 30, 2024 was 13.0%, compared to the effective tax rate for the three months ended April 1, 2023 of 18.5%. The effective tax rate for the first quarter of 2024 is lower than the effective tax rate for the comparable 2023 period primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits. The effective tax rate for 2023 is lower than the statutory tax rate primarily due to income earned in lower tax jurisdictions, and the effective tax rate for 2024 is lower than the statutory tax rate primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits.


## us-gaap:EarningsPerShareTextBlock

[0000889331-24-000129:notes:149]
[same as prior period, unchanged from 0000889331-23-000157:notes:166]

[0000889331-24-000129:notes:150]
[same as prior period, unchanged from 0000889331-23-000157:notes:167]

[0000889331-24-000129:notes:151]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 48,452 |  |  | $ | 88,745 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,911 |  |  | 24,782 |  |  |  |  |  |
| Effect of dilutive securities |  | 213 |  |  | 280 |  |  |  |  |  |
| Diluted |  | 25,124 |  |  | 25,062 |  |  |  |  |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.95 |  |  | $ | 3.58 |  |  |  |  |  |
| Diluted earnings per share |  | $ | 1.93 |  |  | $ | 3.54 |  |  |  |  |  |

[0000889331-24-000129:notes:152]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 175,411 and 90,297 for the three months ended March 30, 2024 and April 1, 2023, respectively.

[0000889331-24-000129:notes:153]
[same as prior period, unchanged from 0000889331-23-000157:notes:170]

[0000889331-24-000129:notes:154]
The Company’s Board of Directors authorized the repurchase of up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 (2021 program). During the three months ended March 30, 2024, the Company repurchased 70,280 shares of its common stock totaling $16.1 million. The Company did not repurchase shares of its common stock for the three months ended April 1, 2023.

[0000889331-24-000129:notes:155]
On April 25, 2024, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 to replace its 2021 program.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-24-000129:notes:156]
[same as prior period, unchanged from 0000889331-23-000157:notes:179]

[0000889331-24-000129:notes:157]
[same as prior period, unchanged from 0000889331-23-000157:notes:180]

[0000889331-24-000129:notes:158]
[same as prior period, unchanged from 0000889331-23-000157:notes:181]

[0000889331-24-000129:notes:159]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related charging infrastructure, aerospace, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-24-000129:notes:160]
[same as prior period, unchanged from 0000889331-23-000157:notes:184]

[0000889331-24-000129:notes:161]
[same as prior period, unchanged from 0000889331-23-000157:notes:185]

[0000889331-24-000129:notes:162]
[same as prior period, unchanged from 0000889331-23-000157:notes:186]

[0000889331-24-000129:notes:163]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 291,105 |  |  | $ | 358,593 |  |  |  |  |  |
| Transportation |  | 170,367 |  |  | 166,641 |  |  |  |  |  |
| Industrial |  | 73,913 |  |  | 84,548 |  |  |  |  |  |
| Total net sales |  | $ | 535,385 |  |  | $ | 609,782 |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 19,841 |  |  | $ | 19,788 |  |  |  |  |  |
| Transportation |  | 8,631 |  |  | 11,291 |  |  |  |  |  |
| Industrial |  | 4,021 |  |  | 3,403 |  |  |  |  |  |
| Total depreciation and amortization |  | $ | 32,493 |  |  | $ | 34,482 |  |  |  |  |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 37,803 |  |  | $ | 90,162 |  |  |  |  |  |
| Transportation |  | 16,206 |  |  | 8,532 |  |  |  |  |  |
| Industrial |  | 4,796 |  |  | 17,141 |  |  |  |  |  |
| Other (a) |  | (3,853) |  |  | (5,194) |  |  |  |  |  |
| Total operating income |  | 54,952 |  |  | 110,641 |  |  |  |  |  |
| Interest expense |  | 9,611 |  |  | 9,646 |  |  |  |  |  |
| Foreign exchange gain |  | (5,042) |  |  | (1,675) |  |  |  |  |  |
| Other income, net |  | (5,321) |  |  | (6,233) |  |  |  |  |  |
| Income before income taxes |  | $ | 55,704 |  |  | $ | 108,903 |  |  |  |  |  |

[0000889331-24-000129:notes:164]
(a) Included in “Other” Operating income for the first quarter of 2024 was $2.3 million of restructuring charges primarily related to employee termination costs and a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the first quarter of 2024, the Company recognized $0.9 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.3 million recorded for the sale of a building in the commercial vehicle business within the Transportation segment.

[0000889331-24-000129:notes:165]
Included in “Other” Operating income for the first quarter of 2023 was $3.3 million of legal and professional fees and other integration expenses related to completed acquisitions, and $1.9 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000129:notes:166]
The Company’s net sales by country were as follows, classified according to the country where the customer is located:

[0000889331-24-000129:notes:167]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | March 30, 2024 |  | April 1, 2023 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 190,433 |  |  | $ | 212,195 |  |  |  |  |  |
| China |  | 115,169 |  |  | 133,467 |  |  |  |  |  |
| Other countries (a) |  | 229,783 |  |  | 264,120 |  |  |  |  |  |
| Total net sales |  | $ | 535,385 |  |  | $ | 609,782 |  |  |  |  |  |

[0000889331-24-000129:notes:168]
The Company’s long-lived assets represent Net property, plant, and equipment, and are classified according to the country where the asset is located were as follows:

[0000889331-24-000129:notes:169]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 67,614 |  |  | $ | 73,126 |  |
| China |  | 135,255 |  |  | 139,736 |  |
| Mexico |  | 100,830 |  |  | 102,218 |  |
| Germany |  | 48,084 |  |  | 47,217 |  |
| Philippines |  | 71,327 |  |  | 73,217 |  |
| Other countries |  | 56,325 |  |  | 57,639 |  |
| Total long-lived assets |  | $ | 479,435 |  |  | $ | 493,153 |  |

[0000889331-24-000129:notes:170]
[same as prior period, unchanged from 0000889331-23-000157:notes:194]

[0000889331-24-000129:notes:171]
|  |  | Three Months Ended |
| (in thousands) |  | March 30, 2024 |  | April 1, 2023 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 4,806 |  |  | $ | 4,091 |  |
| China |  | 2,408 |  |  | 8,403 |  |
| Mexico |  | 2,330 |  |  | 3,744 |  |
| Germany |  | 3,230 |  |  | 1,234 |  |
| Philippines |  | 1,338 |  |  | 1,398 |  |
| Other countries |  | 2,212 |  |  | 2,593 |  |
| Total additions to long-lived assets |  | $ | 16,324 |  |  | $ | 21,463 |  |

[0000889331-24-000129:notes:172]
[same as prior period, unchanged from 0000889331-23-000157:notes:196]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000889331-24-000129:notes:173]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0000889331-24-000129:notes:174]
As of March 30, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-24-000129:notes:175]
Product Warranty Liabilities

[0000889331-24-000129:notes:176]
The company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0000889331-24-000129:notes:177]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0000889331-24-000129:notes:178]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-24-000129:notes:179]
Environmental Remediation Liabilities

[0000889331-24-000129:notes:180]
The company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at  its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0000889331-24-000129:notes:181]
Legal Proceedings

[0000889331-24-000129:notes:182]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

[0000889331-24-000129:notes:183]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss and therefore the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may  be changed when events result in an expectation different than previously expected.

[0000889331-24-000129:notes:184]
Pending Litigation and Claims

[0000889331-24-000129:notes:185]
There are no material pending litigation or claims outstanding as of March 30, 2024.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-24-000129:notes:186]
Related Party Transactions

[0000889331-24-000129:notes:187]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-24-000129:notes:188]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-24-000129:notes:189]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-24-000129:notes:190]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-24-000129:notes:191]
|  |  | Three Months Ended March 30, 2024 |  | Three Months Ended April 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 2.1 |  |  | 1.0 |  | 0.1 |  | 2.7 |  |
|  |  | March 30, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.8 |  | $ | 0.1 |  | $ | 1.5 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000889331-24-000129:notes:192]
The adoption or termination of contracts, instructions or written plans for the purchase or sale of our securities by our Section 16 officers and directors for the three months ended March 30, 2024, each of which is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act (“Rule 10b5-1 Plan”), were as follows:

[0000889331-24-000129:notes:193]
| Name |  | Title |  | Action |  | Date Adopted |  | Expiration Date |  | Aggregate # of securities to be Sold |
| David Heinzmann (1) |  | President and Chief Executive Officer |  | Adoption |  | 2/6/2024 |  | 4/25/2025 |  | 23,061 |

[0000889331-24-000129:notes:194]
(1) David Heinzmann, President and Chief Executive Officer, entered into a pre-arranged stock trading plan pursuant to Rule 10b5-1 on February 6, 2024. Mr. Heinzmann’s plan provides for the potential exercise of vested stock options and the associated sale of up to 23,061 shares of the Company’s common stock. The stock options covered by the plan expire on April 25, 2025 if they have not been exercised. Consequently, the plan expires on April 25, 2025, or upon the earlier completion of all authorized transactions under the plan.
