# LFUS note change history — 0000889331-24-000161 → 0000889331-24-000191


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0000889331-24-000191:note_history:1]
As of September 28, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.
  (was, 2024-07-31, similarity 0.9887):
[0000889331-24-000161:note_history:1]
As of June 29, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

- changed (2024-10-30):
[0000889331-24-000191:note_history:2]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.
  (was, 2024-07-31, similarity 0.8422):
[0000889331-24-000161:note_history:2]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will

- changed (2024-10-30):
[0000889331-24-000191:note_history:3]
There are no material pending litigation or claims outstanding as of September 28, 2024.
  (was, 2024-07-31, similarity 0.9308):
[0000889331-24-000161:note_history:3]
There are no material pending litigation or claims outstanding as of June 29, 2024.

- removed (2024-10-30):
[0000889331-24-000161:note_history:4]
impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-10-30):
[0000889331-24-000191:note_history:5]
Founded in 1927, Littelfuse, Inc. ("Littelfuse" or the "Company") is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

- changed (2024-10-30):
[0000889331-24-000191:note_history:6]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2024 and September 30, 2023:
  (was, 2024-07-31, similarity 0.8997):
[0000889331-24-000161:note_history:6]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2024 and July 1, 2023:

- added (2024-10-30):
[0000889331-24-000191:note_history:7]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

- added (2024-10-30):
[0000889331-24-000191:note_history:8]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 191,523 |  |  | $ | — |  |  | $ | — |  |  | $ | 191,523 |  |  | $ | 598,813 |  |  | $ | — |  |  | $ | — |  |  | $ | 598,813 |  |
| Electronics – Passive Products and Sensors |  | 152,410 |  |  | — |  |  | — |  |  | 152,410 |  |  | 453,860 |  |  | — |  |  | — |  |  | 453,860 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  |  |  |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- changed (2024-10-30):
[0000889331-24-000191:note_history:9]
See Note 14, Segment Information, for net sales by segment and country.
  (was, 2024-07-31, similarity 0.9714):
[0000889331-24-000161:note_history:9]
See Note 14, Segment Information, for net sales by segment and countries.

- changed (2024-10-30):
[0000889331-24-000191:note_history:10]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2024-07-31, similarity 0.9995):
[0000889331-24-000161:note_history:10]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- changed (2024-10-30):
[0000889331-24-000191:note_history:11]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.
  (was, 2024-07-31, similarity 0.9974):
[0000889331-24-000161:note_history:11]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

- changed (2024-10-30):
[0000889331-24-000191:note_history:12]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at September 28, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2024-07-31, similarity 0.7599):
[0000889331-24-000161:note_history:12]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at June 29, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2024-10-30):
[0000889331-24-000191:note_history:13]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 629,670 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,623 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 631,293 |  |  | $ | 557,123 |  |
  (was, 2024-07-31, similarity 0.927):
[0000889331-24-000161:note_history:13]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 561,742 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,554 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 563,296 |  |  | $ | 557,123 |  |

- changed (2024-10-30):
[0000889331-24-000191:note_history:14]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.
  (was, 2024-07-31, similarity 0.6286):
[0000889331-24-000161:note_history:14]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures". The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2)

- changed (2024-10-30):
[0000889331-24-000191:note_history:15]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures." The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of the Chief Operating Decision Maker (“CODM”) on an annual basis as well as an explanation of how the CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.
  (was, 2024-07-31, similarity 0.9991):
[0000889331-24-000161:note_history:15]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures". The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of the Chief Operating Decision Maker (“CODM”) on an annual basis as well as an explanation of how the CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

- removed (2024-10-30):
[0000889331-24-000161:note_history:16]
Founded in 1927, Littelfuse is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

- removed (2024-10-30):
[0000889331-24-000161:note_history:17]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  | — |  |  | — |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

- removed (2024-10-30):
[0000889331-24-000161:note_history:18]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 197,295 |  |  | $ | — |  |  | $ | — |  |  | $ | 197,295 |  |  | $ | 407,290 |  |  | $ | — |  |  | $ | — |  |  | $ | 407,290 |  |
| Electronics – Passive Products and Sensors |  | 152,852 |  |  | — |  |  | — |  |  | 152,852 |  |  | 301,450 |  |  | — |  |  | — |  |  | 301,450 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  |  |  |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |

- removed (2024-10-30):
[0000889331-24-000161:note_history:19]
income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0000889331-24-000191:note_history:20]
The carrying amounts of debt at September 28, 2024 and December 30, 2023 are as follows:
  (was, 2024-07-31, similarity 0.9272):
[0000889331-24-000161:note_history:20]
The carrying amounts of debt at June 29, 2024 and December 30, 2023 are as follows:

- changed (2024-10-30):
[0000889331-24-000191:note_history:21]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,106 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 4,670 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,028) |  |  | (3,770) |  |
| Total debt |  | 867,748 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,799) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 799,949 |  |  | $ | 857,915 |  |
  (was, 2024-07-31, similarity 0.9695):
[0000889331-24-000161:note_history:21]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 101,631 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,142 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,269) |  |  | (3,770) |  |
| Total debt |  | 863,504 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,679) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 795,825 |  |  | $ | 857,915 |  |

- changed (2024-10-30):
[0000889331-24-000191:note_history:22]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the nine months ended September 28, 2024, the Company made payments of $3.8 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of September 28, 2024.
  (was, 2024-07-31, similarity 0.9574):
[0000889331-24-000161:note_history:22]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended June 29, 2024, the Company made payments of $1.9 million and $3.8 million respectively, on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of June 29, 2024.

- changed (2024-10-30):
[0000889331-24-000191:note_history:23]
As of September 28, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.60%, and 4.13% on the hedged portion.
  (was, 2024-07-31, similarity 0.9653):
[0000889331-24-000161:note_history:23]
As of June 29, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.69%, and 4.13% on the hedged portion.

- added (2024-10-30):
[0000889331-24-000191:note_history:24]
As of September 28, 2024, the Company had $0.1 million outstanding letters of credit under the Credit Facility and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 28, 2024, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2024-10-30):
[0000889331-24-000191:note_history:25]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of September 28, 2024, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2024-07-31, similarity 0.9337):
[0000889331-24-000161:note_history:25]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 29, 2024, the Company was in compliance with all covenants under the Senior Notes.

- changed (2024-10-30):
[0000889331-24-000191:note_history:26]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
  (was, 2024-07-31, similarity 0.9981):
[0000889331-24-000161:note_history:26]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

- changed (2024-10-30):
[0000889331-24-000191:note_history:27]
Interest paid on all Company debt was $10.5 million and $11.9 million for the three months ended September 28, 2024 and September 30, 2023, respectively, and $30.1 million and $33.2 million for the nine months ended September 28, 2024 and September 30, 2023, respectively.
  (was, 2024-07-31, similarity 0.7297):
[0000889331-24-000161:note_history:27]
Interest paid on all Company debt was $6.4 million and $10.3 million for the three months ended June 29, 2024 and July 1, 2023, respectively, and $19.6 million and $21.3 million for the six months ended June 29, 2024 and July 1, 2023, respectively.

- removed (2024-10-30):
[0000889331-24-000161:note_history:28]
As of June 29, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving credit facility. As of June 29, 2024, the Company was in compliance with all covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0000889331-24-000191:note_history:29]
The carrying amounts of debt at September 28, 2024 and December 30, 2023 are as follows:
  (was, 2024-07-31, similarity 0.9272):
[0000889331-24-000161:note_history:29]
The carrying amounts of debt at June 29, 2024 and December 30, 2023 are as follows:

- changed (2024-10-30):
[0000889331-24-000191:note_history:30]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,106 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 4,670 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,028) |  |  | (3,770) |  |
| Total debt |  | 867,748 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,799) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 799,949 |  |  | $ | 857,915 |  |
  (was, 2024-07-31, similarity 0.9695):
[0000889331-24-000161:note_history:30]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 101,631 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,142 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,269) |  |  | (3,770) |  |
| Total debt |  | 863,504 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,679) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 795,825 |  |  | $ | 857,915 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0000889331-24-000191:note_history:31]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's executive officers serves on the Board of Directors of ATEC.
  (was, 2024-07-31, similarity 0.9306):
[0000889331-24-000161:note_history:31]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

- changed (2024-10-30):
[0000889331-24-000191:note_history:32]
|  |  | Three Months Ended September 28, 2024 |  | Three Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.2 |  | 0.6 |  |  | 1.2 |  | 0.1 |  | 2.0 |  |
|  |  | Nine Months Ended September 28, 2024 |  | Nine Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | 1.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.0 |  | 0.6 |  | 3.5 |  |  | 3.3 |  | 0.3 |  | 7.6 |  |
|  |  | September 28, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.5 |  | $ | — |  | $ | 0.1 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |
  (was, 2024-07-31, similarity 0.8424):
[0000889331-24-000161:note_history:32]
|  |  | Three Months Ended June 29, 2024 |  | Three Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 0.8 |  |  | 1.1 |  | 0.1 |  | 2.9 |  |
|  |  | Six Months Ended June 29, 2024 |  | Six Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.4 |  | 0.4 |  | 2.9 |  |  | 2.1 |  | 0.2 |  | 5.6 |  |
|  |  | June 29, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.2 |  | $ | 0.1 |  | $ | 0.2 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0000889331-24-000191:note_history:33]
|  |  | Three Months Ended September 28, 2024 |  | Three Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.2 |  | 0.6 |  |  | 1.2 |  | 0.1 |  | 2.0 |  |
|  |  | Nine Months Ended September 28, 2024 |  | Nine Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | 1.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.0 |  | 0.6 |  | 3.5 |  |  | 3.3 |  | 0.3 |  | 7.6 |  |
|  |  | September 28, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.5 |  | $ | — |  | $ | 0.1 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |
  (was, 2024-07-31, similarity 0.8424):
[0000889331-24-000161:note_history:33]
|  |  | Three Months Ended June 29, 2024 |  | Three Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 0.8 |  |  | 1.1 |  | 0.1 |  | 2.9 |  |
|  |  | Six Months Ended June 29, 2024 |  | Six Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.4 |  | 0.4 |  | 2.9 |  |  | 2.1 |  | 0.2 |  | 5.6 |  |
|  |  | June 29, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.2 |  | $ | 0.1 |  | $ | 0.2 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0000889331-24-000191:note_history:34]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2024 and September 30, 2023:
  (was, 2024-07-31, similarity 0.8997):
[0000889331-24-000161:note_history:34]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2024 and July 1, 2023:

- added (2024-10-30):
[0000889331-24-000191:note_history:35]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

- added (2024-10-30):
[0000889331-24-000191:note_history:36]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 191,523 |  |  | $ | — |  |  | $ | — |  |  | $ | 191,523 |  |  | $ | 598,813 |  |  | $ | — |  |  | $ | — |  |  | $ | 598,813 |  |
| Electronics – Passive Products and Sensors |  | 152,410 |  |  | — |  |  | — |  |  | 152,410 |  |  | 453,860 |  |  | — |  |  | — |  |  | 453,860 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  |  |  |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

- removed (2024-10-30):
[0000889331-24-000161:note_history:37]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  | — |  |  | — |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

- removed (2024-10-30):
[0000889331-24-000161:note_history:38]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 197,295 |  |  | $ | — |  |  | $ | — |  |  | $ | 197,295 |  |  | $ | 407,290 |  |  | $ | — |  |  | $ | — |  |  | $ | 407,290 |  |
| Electronics – Passive Products and Sensors |  | 152,852 |  |  | — |  |  | — |  |  | 152,852 |  |  | 301,450 |  |  | — |  |  | — |  |  | 301,450 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  |  |  |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-30):
[0000889331-24-000191:note_history:39]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2024-07-31, similarity 0.9995):
[0000889331-24-000161:note_history:39]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- changed (2024-10-30):
[0000889331-24-000191:note_history:40]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.
  (was, 2024-07-31, similarity 0.9974):
[0000889331-24-000161:note_history:40]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.
