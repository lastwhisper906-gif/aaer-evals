# LFUS 8-K — 0000889331-24-000188 filed 2024-10-29

## item codes, every 8-K on or before 2024-10-30

- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2024-10-30

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-24-000188:8k_2_02:1]
EX-99.1
2
q32024earningsreleaseex991.htm
EX-99.1

[0000889331-24-000188:8k_2_02:2]
Document

[0000889331-24-000188:8k_2_02:3]
Exhibit 99.1

[0000889331-24-000188:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0000889331-24-000188:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS FOR 2024

[0000889331-24-000188:8k_2_02:6]
Operational execution drives third quarter earnings above expectations

[0000889331-24-000188:8k_2_02:7]
CHICAGO, October 29, 2024  - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the third quarter ended September 28, 2024:

[0000889331-24-000188:8k_2_02:8]
•Net sales of $567 million were down 7% versus the prior year period and organically

[0000889331-24-000188:8k_2_02:9]
•GAAP diluted EPS was $2.32 and adjusted diluted EPS was $2.71

[0000889331-24-000188:8k_2_02:10]
•Cash flow from operations was $80 million and free cash flow was $65 million

[0000889331-24-000188:8k_2_02:11]
“In the third quarter, our global teams delivered strong execution and drove sales and earnings above our expectations.” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “While we see soft end market conditions extending into the fourth quarter, we remain focused on driving operational excellence while serving our global customer base and delivering meaningful new business wins. Our proven growth strategy, diversification efforts and strong technology capabilities position us to deliver top tier long-term stakeholder value.”

[0000889331-24-000188:8k_2_02:12]
Fourth Quarter of 2024*

[0000889331-24-000188:8k_2_02:13]
Based on current market conditions, for the fourth quarter the company expects,

[0000889331-24-000188:8k_2_02:14]
•Net sales in the range of $510 - $540 million, adjusted diluted EPS in the range of $1.90 - $2.10 and an adjusted effective tax rate of approximately 14%

[0000889331-24-000188:8k_2_02:15]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-24-000188:8k_2_02:16]
Dividend and Share Repurchase Authorization

[0000889331-24-000188:8k_2_02:17]
•The company will pay a cash dividend on its common stock of $0.70 per share on December 5, 2024, to shareholders of record as of November 21, 2024

[0000889331-24-000188:8k_2_02:18]
-more-

[0000889331-24-000188:8k_2_02:19]
Conference Call and Webcast Information

[0000889331-24-000188:8k_2_02:20]
Littelfuse will host a conference call on Wednesday, October 30, 2024, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-24-000188:8k_2_02:21]
About Littelfuse

[0000889331-24-000188:8k_2_02:22]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-24-000188:8k_2_02:23]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 30, 2023.

[0000889331-24-000188:8k_2_02:24]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 30, 2023, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-24-000188:8k_2_02:25]
-more

[0000889331-24-000188:8k_2_02:26]
Non-GAAP Financial Measures

[0000889331-24-000188:8k_2_02:27]
The information included in this press release includes the non-GAAP financial measures of organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-24-000188:8k_2_02:28]
LFUS-F

[0000889331-24-000188:8k_2_02:29]
###

[0000889331-24-000188:8k_2_02:30]
|  | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000www.littelfuse.com |

[0000889331-24-000188:8k_2_02:31]
LITTELFUSE, INC.

[0000889331-24-000188:8k_2_02:32]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-24-000188:8k_2_02:33]
|  |  | (Unaudited) |  |  |
| (in thousands, except share and per share data) |  | September 28,2024 |  | December 30,2023 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 629,670 |  |  | $ | 555,513 |  |
| Short-term investments |  | 1,011 |  |  | 235 |  |
| Trade receivables, less allowances of $76,151 and $84,696 at September 28, 2024 and December 30, 2023, respectively |  | 338,758 |  |  | 287,018 |  |
| Inventories |  | 453,781 |  |  | 474,607 |  |
| Prepaid income taxes and income taxes receivable |  | 6,793 |  |  | 8,701 |  |
| Prepaid expenses and other current assets |  | 132,510 |  |  | 82,526 |  |
| Total current assets |  | 1,562,523 |  |  | 1,408,600 |  |
| Net property, plant, and equipment |  | 481,592 |  |  | 493,153 |  |
| Intangible assets, net of amortization |  | 560,994 |  |  | 606,136 |  |
| Goodwill |  | 1,317,748 |  |  | 1,309,998 |  |
| Investments |  | 26,607 |  |  | 24,821 |  |
| Deferred income taxes |  | 11,955 |  |  | 10,486 |  |
| Right of use lease assets |  | 60,277 |  |  | 62,370 |  |
| Other long-term assets |  | 40,548 |  |  | 79,711 |  |
| Total assets |  | $ | 4,062,244 |  |  | $ | 3,995,275 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 179,486 |  |  | $ | 173,535 |  |
| Accrued liabilities |  | 152,772 |  |  | 149,214 |  |
| Accrued income taxes |  | 39,809 |  |  | 38,725 |  |
| Current portion of long-term debt |  | 67,799 |  |  | 14,020 |  |
| Total current liabilities |  | 439,866 |  |  | 375,494 |  |
| Long-term debt, less current portion |  | 799,949 |  |  | 857,915 |  |
| Deferred income taxes |  | 95,554 |  |  | 110,820 |  |
| Accrued post-retirement benefits |  | 31,373 |  |  | 34,422 |  |
| Non-current lease liabilities |  | 52,074 |  |  | 49,472 |  |
| Other long-term liabilities |  | 70,328 |  |  | 86,671 |  |
| Total equity |  | 2,573,100 |  |  | 2,480,481 |  |
| Total liabilities and equity |  | $ | 4,062,244 |  |  | $ | 3,995,275 |  |

[0000889331-24-000188:8k_2_02:34]
LITTELFUSE, INC.

[0000889331-24-000188:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-24-000188:8k_2_02:36]
(Unaudited)

[0000889331-24-000188:8k_2_02:37]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) |  | September 28,2024 |  | September 30,2023 |  | September 28,2024 |  | September 30,2023 |
| Net sales |  | $ | 567,390 |  |  | $ | 607,071 |  |  | $ | 1,661,263 |  |  | $ | 1,828,850 |  |
| Cost of sales |  | 351,498 |  |  | 380,200 |  |  | 1,050,559 |  |  | 1,122,190 |  |
| Gross profit |  | 215,892 |  |  | 226,871 |  |  | 610,704 |  |  | 706,660 |  |
| Selling, general, and administrative expenses |  | 83,897 |  |  | 87,204 |  |  | 263,395 |  |  | 270,057 |  |
| Research and development expenses |  | 26,470 |  |  | 25,484 |  |  | 81,283 |  |  | 77,270 |  |
| Amortization of intangibles |  | 15,864 |  |  | 16,022 |  |  | 47,418 |  |  | 49,773 |  |
| Restructuring, impairment, and other charges |  | 1,840 |  |  | 4,516 |  |  | 10,329 |  |  | 13,221 |  |
| Total operating expenses |  | 128,071 |  |  | 133,226 |  |  | 402,425 |  |  | 410,321 |  |
| Operating income |  | 87,821 |  |  | 93,645 |  |  | 208,279 |  |  | 296,339 |  |
| Interest expense |  | 9,772 |  |  | 10,101 |  |  | 29,358 |  |  | 29,803 |  |
| Foreign exchange loss |  | 9,630 |  |  | 11,776 |  |  | 4,273 |  |  | 8,697 |  |
| Other income, net |  | (9,297) |  |  | (3,527) |  |  | (19,916) |  |  | (11,810) |  |
| Income before income taxes |  | 77,716 |  |  | 75,295 |  |  | 194,564 |  |  | 269,649 |  |
| Income taxes |  | 19,658 |  |  | 17,507 |  |  | 42,588 |  |  | 53,045 |  |
| Net income |  | $ | 58,058 |  |  | $ | 57,788 |  |  | $ | 151,976 |  |  | $ | 216,604 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.34 |  |  | $ | 2.32 |  |  | $ | 6.12 |  |  | $ | 8.72 |  |
| Diluted |  | $ | 2.32 |  |  | $ | 2.30 |  |  | $ | 6.07 |  |  | $ | 8.63 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,796 |  |  | 24,893 |  |  | 24,822 |  |  | 24,838 |  |
| Diluted |  | 25,025 |  |  | 25,143 |  |  | 25,040 |  |  | 25,100 |  |
| Comprehensive income |  | $ | 114,451 |  |  | $ | 55,654 |  |  | $ | 157,011 |  |  | $ | 212,842 |  |

[0000889331-24-000188:8k_2_02:38]
LITTELFUSE, INC.

[0000889331-24-000188:8k_2_02:39]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-24-000188:8k_2_02:40]
(Unaudited)

[0000889331-24-000188:8k_2_02:41]
|  |  | Nine Months Ended |
| (in thousands) |  | September 28, 2024 |  | September 30, 2023 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 151,976 |  |  | $ | 216,604 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 101,437 |  |  | 137,988 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (50,672) |  |  | (21,752) |  |
| Inventories |  | 19,865 |  |  | 66,456 |  |
| Accounts payable |  | 5,460 |  |  | (38,475) |  |
| Accrued liabilities and income taxes |  | (19,434) |  |  | (61,359) |  |
| Prepaid expenses and other assets |  | (1,633) |  |  | 13,678 |  |
| Net cash provided by operating activities |  | 206,999 |  |  | 313,140 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (198,810) |  |
| Purchases of property, plant, and equipment |  | (50,065) |  |  | (63,166) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 8,931 |  |  | 597 |  |
| Net cash used in investing activities |  | (41,134) |  |  | (261,379) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (3,750) |  |  | (5,625) |  |
| Repurchases of common stock |  | (40,862) |  |  | — |  |
| Cash dividends paid |  | (49,687) |  |  | (45,973) |  |
| All other cash provided by financing activities |  | 3,000 |  |  | 4,454 |  |
| Net cash used in financing activities |  | (91,299) |  |  | (47,144) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (396) |  |  | (7,965) |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 74,170 |  |  | (3,348) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 557,123 |  |  | 564,939 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 631,293 |  |  | $ | 561,591 |  |

[0000889331-24-000188:8k_2_02:42]
LITTELFUSE, INC.

[0000889331-24-000188:8k_2_02:43]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-24-000188:8k_2_02:44]
(Unaudited)

[0000889331-24-000188:8k_2_02:45]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2024 |  | 2023 |  |  |  | %(Decline) /Growth |  | 2024 |  | 2023 |  |  |  | %(Decline) /Growth |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 304,188 |  |  | $ | 343,933 |  |  |  |  | (11.6) | % |  | $ | 900,932 |  |  | $ | 1,052,673 |  |  |  |  | (14.4) | % |
| Transportation |  | 171,381 |  |  | 177,019 |  |  |  |  | (3.2) | % |  | 510,711 |  |  | 515,708 |  |  |  |  | (1.0) | % |
| Industrial |  | 91,821 |  |  | 86,119 |  |  |  |  | 6.6 | % |  | 249,620 |  |  | 260,469 |  |  |  |  | (4.2) | % |
| Total net sales |  | $ | 567,390 |  |  | $ | 607,071 |  |  |  |  | (6.5) | % |  | $ | 1,661,263 |  |  | $ | 1,828,850 |  |  |  |  | (9.2) | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 48,891 |  |  | $ | 77,022 |  |  |  |  | (36.5) | % |  | $ | 132,859 |  |  | $ | 247,028 |  |  |  |  | (46.2) | % |
| Transportation |  | 23,485 |  |  | 9,694 |  |  |  |  | 142.3 | % |  | 54,925 |  |  | 26,015 |  |  |  |  | 111.1 | % |
| Industrial |  | 17,711 |  |  | 13,201 |  |  |  |  | 34.2 | % |  | 32,054 |  |  | 45,450 |  |  |  |  | (29.5) | % |
| Other(a) |  | (2,266) |  |  | (6,272) |  |  |  |  | N.M. |  | (11,559) |  |  | (22,154) |  |  |  |  | N.M. |
| Total operating income |  | $ | 87,821 |  |  | $ | 93,645 |  |  |  |  | (6.2) | % |  | $ | 208,279 |  |  | $ | 296,339 |  |  |  |  | (29.7) | % |
| Operating Margin |  | 15.5 | % |  | 15.4 | % |  |  |  |  |  | 12.5 | % |  | 16.2 | % |  |  |  |  |
| Interest expense |  | 9,772 |  |  | 10,101 |  |  |  |  |  |  | 29,358 |  |  | 29,803 |  |  |  |  |  |
| Foreign exchange loss |  | 9,630 |  |  | 11,776 |  |  |  |  |  |  | 4,273 |  |  | 8,697 |  |  |  |  |  |
| Other income, net |  | (9,297) |  |  | (3,527) |  |  |  |  |  |  | (19,916) |  |  | (11,810) |  |  |  |  |  |
| Income before income taxes |  | $ | 77,716 |  |  | $ | 75,295 |  |  |  |  | 3.2 | % |  | $ | 194,564 |  |  | $ | 269,649 |  |  |  |  | (27.8) | % |

[0000889331-24-000188:8k_2_02:46]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-24-000188:8k_2_02:47]
N.M. - Not meaningful

[0000889331-24-000188:8k_2_02:48]
|  |  | Third Quarter |  | Year-to-Date |
| (in thousands) |  | 2024 |  | 2023 |  | %(Decline)/Growth |  | 2024 |  | 2023 |  | %(Decline)/Growth |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 16.1 | % |  | 22.4 | % |  | (6.3) | % |  | 14.7 | % |  | 23.5 | % |  | (8.8) | % |
| Transportation |  | 13.7 | % |  | 5.5 | % |  | 8.2 | % |  | 10.8 | % |  | 5.0 | % |  | 5.8 | % |
| Industrial |  | 19.3 | % |  | 15.3 | % |  | 4.0 | % |  | 12.8 | % |  | 17.4 | % |  | (4.6) | % |

[0000889331-24-000188:8k_2_02:49]
LITTELFUSE, INC.

[0000889331-24-000188:8k_2_02:50]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-24-000188:8k_2_02:51]
(In millions of USD except per share amounts - unaudited)

[0000889331-24-000188:8k_2_02:52]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-24 |  | Q3-23 |  | YTD-24 |  | YTD-23 |
| GAAP diluted EPS |  | $ | 2.32 |  |  | $ | 2.30 |  |  | $ | 6.07 |  |  | $ | 8.63 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.39 |  |  | 0.67 |  |  | 0.37 |  |  | 1.09 |  |
| Adjusted diluted EPS |  | $ | 2.71 |  |  | $ | 2.97 |  |  | $ | 6.44 |  |  | $ | 9.72 |  |

[0000889331-24-000188:8k_2_02:53]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q3-24 |  | Q3-23 |  | YTD-24 |  | YTD-23 |
| Acquisition-related and integration costs (a) |  | $ | 1.0 |  |  | $ | 1.8 |  |  | $ | 2.8 |  |  | $ | 9.0 |  |
| Restructuring, impairment and other charges (b) |  | 1.8 |  |  | 4.5 |  |  | 10.3 |  |  | 13.2 |  |
| Gain on sale of fixed assets (c) |  | (0.5) |  |  | — |  |  | (1.5) |  |  | — |  |
| Non-GAAP adjustments to operating income |  | 2.3 |  |  | 6.3 |  |  | 11.6 |  |  | 22.2 |  |
| Other income, net (d) |  | — |  |  | — |  |  | (0.3) |  |  | (0.2) |  |
| Non-operating foreign exchange loss |  | 9.6 |  |  | 11.8 |  |  | 4.3 |  |  | 8.7 |  |
| Non-GAAP adjustments to income before income taxes |  | 11.9 |  |  | 18.1 |  |  | 15.6 |  |  | 30.7 |  |
| Income taxes (e) |  | 2.1 |  |  | 1.2 |  |  | 6.2 |  |  | 3.2 |  |
| Non-GAAP adjustments to net income |  | $ | 9.8 |  |  | $ | 16.9 |  |  | $ | 9.4 |  |  | $ | 27.5 |  |
| Total EPS impact |  | $ | 0.39 |  |  | $ | 0.67 |  |  | $ | 0.37 |  |  | $ | 1.09 |  |

[0000889331-24-000188:8k_2_02:54]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-24 |  | Q3-23 |  | YTD-24 |  | YTD-23 |
| Net income |  | $ | 58.1 |  |  | $ | 57.8 |  |  | $ | 152.0 |  |  | $ | 216.6 |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 19.7 |  |  | 17.5 |  |  | 42.6 |  |  | 53.0 |  |
| Interest expense |  | 9.8 |  |  | 10.1 |  |  | 29.4 |  |  | 29.8 |  |
| Foreign exchange loss |  | 9.6 |  |  | 11.8 |  |  | 4.3 |  |  | 8.7 |  |
| Other income, net |  | (9.3) |  |  | (3.5) |  |  | (19.9) |  |  | (11.8) |  |
| GAAP operating income |  | $ | 87.8 |  |  | $ | 93.6 |  |  | $ | 208.3 |  |  | $ | 296.3 |  |
| Non-GAAP adjustments to operating income |  | 2.3 |  |  | 6.3 |  |  | 11.6 |  |  | 22.2 |  |
| Adjusted operating income |  | $ | 90.1 |  |  | $ | 99.9 |  |  | $ | 219.9 |  |  | $ | 318.5 |  |
| Amortization of intangibles |  | 15.9 |  |  | 16.0 |  |  | 47.4 |  |  | 49.8 |  |
| Depreciation expense |  | 17.3 |  |  | 17.9 |  |  | 51.0 |  |  | 53.5 |  |
| Adjusted EBITDA |  | $ | 123.3 |  |  | $ | 133.8 |  |  | $ | 318.3 |  |  | $ | 421.8 |  |
| Net sales |  | $ | 567.4 |  |  | $ | 607.1 |  |  | $ | 1,661.3 |  |  | $ | 1,828.9 |  |
| Net income as a percentage of net sales |  | 10.2 | % |  | 9.5 | % |  | 9.1 | % |  | 11.8 | % |
| Operating margin |  | 15.5 | % |  | 15.4 | % |  | 12.5 | % |  | 16.2 | % |
| Adjusted operating margin |  | 15.9 | % |  | 16.5 | % |  | 13.2 | % |  | 17.4 | % |
| Adjusted EBITDA margin |  | 21.7 | % |  | 22.0 | % |  | 19.2 | % |  | 23.1 | % |

[0000889331-24-000188:8k_2_02:55]
| Adjusted EBITDA by Segment |  | Q3-24 |  | Q3-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 48.9 |  |  | $ | 23.5 |  |  | $ | 17.7 |  |  | $ | 77.0 |  |  | $ | 9.7 |  |  | $ | 13.2 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 9.9 |  |  | 3.4 |  |  | 2.6 |  |  | 9.8 |  |  | 3.6 |  |  | 2.6 |  |
| Add back depreciation |  | 10.1 |  |  | 5.7 |  |  | 1.5 |  |  | 9.8 |  |  | 6.6 |  |  | 1.5 |  |
| Adjusted EBITDA |  | $ | 68.9 |  |  | $ | 32.6 |  |  | $ | 21.8 |  |  | $ | 96.6 |  |  | $ | 19.9 |  |  | $ | 17.3 |  |
| Adjusted EBITDA Margin |  | 22.6 | % |  | 19.0 | % |  | 23.8 | % |  | 28.1 | % |  | 11.2 | % |  | 20.1 | % |

[0000889331-24-000188:8k_2_02:56]
| Adjusted EBITDA by Segment |  | YTD-24 |  | YTD-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 132.9 |  |  | $ | 54.9 |  |  | $ | 32.1 |  |  | $ | 247.0 |  |  | $ | 26.0 |  |  | $ | 45.5 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 29.6 |  |  | 10.1 |  |  | 7.7 |  |  | 30.1 |  |  | 12.2 |  |  | 7.5 |  |
| Add back depreciation |  | 30.1 |  |  | 16.7 |  |  | 4.2 |  |  | 29.1 |  |  | 20.4 |  |  | 4.0 |  |
| Adjusted EBITDA |  | $ | 192.5 |  |  | $ | 81.8 |  |  | $ | 44.0 |  |  | $ | 306.2 |  |  | $ | 58.6 |  |  | $ | 57.0 |  |
| Adjusted EBITDA Margin |  | 21.4 | % |  | 16.0 | % |  | 17.6 | % |  | 29.1 | % |  | 11.4 | % |  | 21.9 | % |

[0000889331-24-000188:8k_2_02:57]
| Net sales reconciliation |  | Q3-24 vs. Q3-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (12) | % |  | (3) | % |  | 7 | % |  | (7) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | — | % |  | — | % |  | — | % |
| FX impact |  | — | % |  | — | % |  | — | % |  | — | % |
| Organic net sales (decline) growth |  | (12) | % |  | (3) | % |  | 7 | % |  | (7) | % |

[0000889331-24-000188:8k_2_02:58]
| Net sales reconciliation |  | YTD-24 vs. YTD-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales decline |  | (14) | % |  | (1) | % |  | (4) | % |  | (9) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | — | % |  | — | % |  | — | % |
| FX impact |  | — | % |  | — | % |  | — | % |  | — | % |
| Organic net sales decline |  | (14) | % |  | (1) | % |  | (4) | % |  | (9) | % |

[0000889331-24-000188:8k_2_02:59]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-24 |  | Q3-23 |  | YTD-24 |  | YTD-23 |
| Income taxes |  | $ | 19.7 |  |  | $ | 17.5 |  |  | $ | 42.6 |  |  | $ | 53.0 |  |
| Effective rate |  | 25.3 | % |  | 23.3 | % |  | 21.9 | % |  | 19.7 | % |
| Non-GAAP adjustments - income taxes |  | 2.1 |  |  | 1.2 |  |  | 6.2 |  |  | 3.2 |  |
| Adjusted income taxes |  | $ | 21.8 |  |  | $ | 18.7 |  |  | $ | 48.8 |  |  | $ | 56.2 |  |
| Adjusted effective rate |  | 24.3 | % |  | 20.0 | % |  | 23.2 | % |  | 18.7 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q3-24 |  | Q3-23 |  | YTD-24 |  | YTD-23 |
| Net cash provided by operating activities |  | $ | 80.4 |  |  | $ | 161.5 |  |  | $ | 207.0 |  |  | $ | 313.1 |  |
| Less: Purchases of property, plant and equipment |  | (15.4) |  |  | (21.7) |  |  | (50.1) |  |  | (63.2) |  |
| Free cash flow |  | $ | 65.0 |  |  | $ | 139.8 |  |  | $ | 156.9 |  |  | $ | 250.0 |  |

[0000889331-24-000188:8k_2_02:60]
| Consolidated Total Debt |  | As of September 28, 2024 |
| Consolidated Total Debt |  | $ | 867.7 |  |
| Unamortized debt issuance costs |  | 3.0 |  |
| Finance lease liability |  | 0.4 |  |
| Consolidated funded indebtedness |  | 871.1 |  |
| Cash held in U.S. (up to $400 million) |  | 135.5 |
| Net debt |  | $ | 735.6 |  |
| Consolidated EBITDA |  | Twelve Months Ended September 28, 2024 |
| Net Income |  | $ | 194.8 |  |
| Interest expense |  | 39.4 |  |
| Income taxes |  | 58.7 |  |
| Depreciation |  | 69.1 |  |
| Amortization |  | 63.4 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 25.2 |  |
| Purchase accounting inventory step-up charge |  | — |  |
| Unrealized loss on investments |  | (2.6) |  |
| Impairment charges |  | 1.0 |  |
| Other |  | (0.2) |  |
| Consolidated EBITDA (1) |  | $ | 448.8 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.6x |

[0000889331-24-000188:8k_2_02:61]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2024 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-24-000188:8k_2_02:62]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-24-000188:8k_2_02:63]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-24-000188:8k_2_02:64]
Note: Total will not always foot due to rounding.

[0000889331-24-000188:8k_2_02:65]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-24-000188:8k_2_02:66]
(b) reflected in restructuring, impairment and other charges.

[0000889331-24-000188:8k_2_02:67]
(c) 2024 amount reflected a gain of $0.5 million ($1.5 million year-to-date) recorded for the sale of a land use right within the Electronics segment and a gain of $1.0 million for the sale of two buildings within the Transportation segment.

[0000889331-24-000188:8k_2_02:68]
(d) 2024 year-to-date also included a reversal of $0.5 million for an asset retirement obligation charge related the disposal of a business in 2019 and $0.2 million increase in coal mining reserves. 2023 amount included $0.2 million gain from the sale of a building within the Electronics segment.

[0000889331-24-000188:8k_2_02:69]
(e) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-24-000188:8k_2_02:70]
###
