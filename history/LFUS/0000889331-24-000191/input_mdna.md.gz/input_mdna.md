# LFUS MD&A — 0000889331-24-000191


## mdna

[0000889331-24-000191:mdna:1]
[same as prior period, unchanged from 0000889331-24-000161:mdna:1]

[0000889331-24-000191:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-24-000191:mdna:3]
[same as prior period, unchanged from 0000889331-24-000161:mdna:3]

[0000889331-24-000191:mdna:4]
[same as prior period, unchanged from 0000889331-24-000161:mdna:4]

[0000889331-24-000191:mdna:5]
[same as prior period, unchanged from 0000889331-24-000161:mdna:5]

[0000889331-24-000191:mdna:6]
[same as prior period, unchanged from 0000889331-24-000161:mdna:6]

[0000889331-24-000191:mdna:7]
[same as prior period, unchanged from 0000889331-24-000161:mdna:7]

[0000889331-24-000191:mdna:8]
[same as prior period, unchanged from 0000889331-24-000161:mdna:8]

[0000889331-24-000191:mdna:9]
For the third quarter of 2024, the Company recognized net sales of $567.4 million, a decrease of $39.7 million, or 6.5% as compared to $607.1 million in the third quarter of 2023 including $0.7 million or 0.1% of favorable changes in foreign exchange rates. The decrease in net sales was primarily due to lower volume in the Electronics segment. The Company recognized net income of $58.1 million, or $2.32 per diluted share, in the third quarter of 2024 compared to $57.8 million, or $2.30 per diluted share, in the third quarter of 2023.

[0000889331-24-000191:mdna:10]
Net cash provided by operating activities was $207.0 million for the nine months ended September 28, 2024 compared to $313.1 million for the nine months ended September 30, 2023. The decrease in net cash provided by operating activities was primarily due to lower cash earnings.

[0000889331-24-000191:mdna:11]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $23 million, representing approximately 31% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-24-000191:mdna:12]
Risk Related to Market Conditions

[0000889331-24-000191:mdna:13]
The Company performs its goodwill impairment tests annually on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. As part of its interim review for indicators of impairment, management analyzed potential changes in value of individual reporting units with goodwill based on each reporting unit’s operating results for the nine months ended September 28, 2024 compared to expected results. In addition, management considered how other key assumptions, including discount rates and expected long-term growth rates, used in the last fiscal year’s impairment analysis could be impacted by changes in market conditions and economic events.

[0000889331-24-000191:mdna:14]
Management considered trends in these factors when performing its assessment of whether an interim impairment review was required for any reporting unit. Based on this interim assessment, management concluded that as of September 28, 2024, no events or changes in circumstances indicated that it was more likely than not that the fair value of any reporting unit had declined below its carrying value. Nevertheless, significant changes in global economic and market conditions could result in changes to expectations of future financial results and key valuation assumptions. Such changes could result in revisions of management’s estimates of the fair value of the Company’s reporting units and could result in a material impairment of goodwill as of September 29, 2024, the Company’s next annual measurement date.

[0000889331-24-000191:mdna:15]
In particular, the Industrial controls and sensors reporting unit within the Industrial segment is at risk for future impairment if projected operating results are not met or other inputs into the fair value measurement change. The potential reduction in the estimated fair value of the reporting unit is due to lower expectations for future revenue, profitability and cash flows for the Industrial controls and sensors reporting unit as compared to the expectations of the 2023 annual goodwill impairment test driven by lower-than-expected demand in the electric vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe. Continued negative trends could have a significant impact on the estimate fair value of this reporting unit and could result in future impairment charges. As of the October 1, 2023 annual goodwill impairment test, the Industrial controls and sensors reporting unit’s estimated fair value exceeded book value by approximately 23%. As of September 28, 2024, the Industrial controls and sensors reporting unit had $157.8 million of goodwill.

[0000889331-24-000191:mdna:16]
Other Risk

[0000889331-24-000191:mdna:17]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies" that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-24-000191:mdna:18]
[same as prior period, unchanged from 0000889331-24-000161:mdna:14]

[0000889331-24-000191:mdna:19]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The third quarter of 2024 includes $1.8 million ($9.4 million year-to-date) of restructuring charges primarily related to employee termination cost, and $1.0 million ($2.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the third quarter of 2024, the Company recorded a gain of $0.5 million related to the sale of a land use right within the Electronics segment. In addition, the Company recognized a gain of $1.0 million for the sale of two buildings within the Transportation segment during the first half of 2024.

[0000889331-24-000191:mdna:20]
The third quarter of 2023 includes $3.7 million ($8.5 million year-to-date) of restructuring charges, primarily related to employee termination costs, and $1.8 million ($9.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000191:mdna:21]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Net sales |  | $ | 567,390 |  |  | $ | 607,071 |  |  | $ | (39,681) |  |  | (6.5) | % |  | $ | 1,661,263 |  |  | $ | 1,828,850 |  |  | $ | (167,587) |  |  | (9.2) | % |
| Cost of sales |  | 351,498 |  |  | 380,200 |  |  | (28,702) |  |  | (7.5) | % |  | 1,050,559 |  |  | 1,122,190 |  |  | (71,631) |  |  | (6.4) | % |
| Gross profit |  | 215,892 |  |  | 226,871 |  |  | (10,979) |  |  | (4.8) | % |  | 610,704 |  |  | 706,660 |  |  | (95,956) |  |  | (13.6) | % |
| Operating expenses |  | 128,071 |  |  | 133,226 |  |  | (5,155) |  |  | (3.9) | % |  | 402,425 |  |  | 410,321 |  |  | (7,896) |  |  | (1.9) | % |
| Operating income |  | 87,821 |  |  | 93,645 |  |  | (5,824) |  |  | (6.2) | % |  | 208,279 |  |  | 296,339 |  |  | (88,060) |  |  | (29.7) | % |
| Income before income taxes |  | 77,716 |  |  | 75,295 |  |  | 2,421 |  |  | 3.2 | % |  | 194,564 |  |  | 269,649 |  |  | (75,085) |  |  | (27.8) | % |
| Income taxes |  | 19,658 |  |  | 17,507 |  |  | 2,151 |  |  | 12.3 | % |  | 42,588 |  |  | 53,045 |  |  | (10,457) |  |  | (19.7) | % |
| Net income |  | $ | 58,058 |  |  | $ | 57,788 |  |  | $ | 270 |  |  | 0.5 | % |  | $ | 151,976 |  |  | $ | 216,604 |  |  | $ | (64,628) |  |  | (29.8) | % |

[0000889331-24-000191:mdna:22]
[same as prior period, unchanged from 0000889331-24-000161:mdna:18]

[0000889331-24-000191:mdna:23]
Net sales decreased $39.7 million, or 6.5%, for the third quarter of 2024 compared to the third quarter of 2023 including $0.7 million or 0.1% of favorable changes in foreign exchange rates. The decrease in net sales was primarily due to lower volume of $39.7 million in the Electronics segment.

[0000889331-24-000191:mdna:24]
Net sales decreased $167.6 million, or 9.2%, for the first nine months of 2024 compared to the first nine months of 2023, including $6.2 million or 0.3% of unfavorable changes in foreign exchange rates. The sales decrease was primarily due to lower volume of $151.7 million and $10.8 million in the Electronics and Industrial segments, respectively.

[0000889331-24-000191:mdna:25]
[same as prior period, unchanged from 0000889331-24-000161:mdna:21]

[0000889331-24-000191:mdna:26]
Cost of sales was $351.5 million, or 61.9% of net sales, in the third quarter of 2024, compared to $380.2 million, or 62.6% of net sales, in the third quarter of 2023. As a percent of net sales, cost of sales decreased 0.7% driven by improved margins from all businesses within the Transportation and Industrial segments driven by favorable price, product mix and cost reduction initiatives, partially offset by lower volume in the Electronics segments.

[0000889331-24-000191:mdna:27]
Cost of sales was $1,050.6 million, or 63.2% of net sales, in the first nine months of 2024, compared to $1,122.2 million, or 61.4% of net sales, in the first nine months of 2023. As a percent of net sales, cost of sales increased 1.8% driven by lower volume in the Electronics and Industrial segments, partially offset by improved margin from all businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000191:mdna:28]
[same as prior period, unchanged from 0000889331-24-000161:mdna:24]

[0000889331-24-000191:mdna:29]
Gross profit was $215.9 million, or 38.1% of net sales, in the third quarter of 2024 compared to $226.9 million, or 37.4% of net sales, for the third quarter of 2023. The $11.0 million decrease in gross profit was primarily due to lower volume in the Electronics segment, partially offset by improved margin from the Transportation and Industrial segments driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000191:mdna:30]
Gross profit was $610.7 million, or 36.8% of net sales, in the first nine months of 2024 compared to $706.7 million, or 38.6% of net sales, for the first nine months of 2023. The $96.0 million decrease in gross profit was primarily due to lower volume in the Electronics and Industrial segments, partially offset by improved margin from the commercial vehicle and passenger car products businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000191:mdna:31]
[same as prior period, unchanged from 0000889331-24-000161:mdna:27]

[0000889331-24-000191:mdna:32]
Operating expenses were $128.1 million, or 22.6% of net sales, for the third quarter of 2024 compared to $133.2 million, or 21.9% of net sales, for the third quarter of 2023. The decrease in operating expenses of $5.2 million was primarily due to lower selling, general, and administrative expenses of $3.3 million driven by cost control initiatives and lower restructuring, impairment, and other charges of $2.7 million, partially offset by higher research and development expenses of $1.0 million.

[0000889331-24-000191:mdna:33]
Operating expenses were $402.4 million, or 24.2% of net sales, for the first nine months of 2024 compared to $410.3 million, or 22.4% of net sales, for the first nine months of 2023. The decrease in operating expenses of $7.9 million was primarily due to lower selling, general, and administrative expenses of $6.7 million as a result of lower legal and professional fees and other integration expenses related to completed and contemplated acquisitions, lower restructuring, impairment, and other charges of $2.9 million caused by a $3.9 million impairment charge recognized during the second quarter 2023 related to the land and building of a property within the Transportation segment, and lower amortization expense of $2.4 million, partially offset by higher research and development expenses of $4.0 million.

[0000889331-24-000191:mdna:34]
[same as prior period, unchanged from 0000889331-24-000161:mdna:31]

[0000889331-24-000191:mdna:35]
Operating income was $87.8 million, representing a decrease of $5.8 million, or 6.2%, for the third quarter of 2024 compared to $93.6 million for the third quarter of 2023. The decrease in operating income was due to lower gross profit from the Electronics segment, partially offset by higher gross profit from the Transportation and Industrial segments. Operating margins increased from 15.4% in the third quarter of 2023 to 15.5% in the third quarter of 2024 driven by improved gross margin in the Transportation and Industrial segments, partially offset by lower volume in the Electronics segment.

[0000889331-24-000191:mdna:36]
Operating income was $208.3 million, representing a decrease of $88.1 million, or 29.7%, for the first nine months of 2024 compared to $296.3 million for the first nine months of 2023. The decrease in operating income was due to lower gross profit from the Electronics and Industrial segments, partially offset by higher gross profit from the Transportation segment. Operating margins decreased from 16.2% in the first nine months quarter of 2023 to 12.5% in the first nine months of 2024 driven by lower volume in the Electronics segment.

[0000889331-24-000191:mdna:37]
[same as prior period, unchanged from 0000889331-24-000161:mdna:34]

[0000889331-24-000191:mdna:38]
Income before income taxes was $77.7 million, or 13.7% of net sales, for the third quarter of 2024 compared to $75.3 million, or 12.4% of net sales, for the third quarter of 2023. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by unrealized gains of $3.1 million in the third quarter of 2024 compared to unrealized losses of $1.6 million in the third quarter of 2023 related to the Company's equity investment, higher interest income of $2.3 million from short-term investment in cash equivalents, and lower foreign exchange losses of $2.1 million in the third quarter of 2024 compared to the third quarter of 2023.

[0000889331-24-000191:mdna:39]
Income before income taxes was $194.6 million, or 11.7% of net sales, for the first nine months of 2024 compared to $269.6 million, or 14.7% of net sales, for the first nine months of 2023. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by higher interest income of $8.2 million from short-term investments in cash equivalents and lower foreign exchange losses of $4.4 million in the first nine months of 2024 compared to the first nine months of 2023, and unrealized gains of $1.9 million during the first nine months of 2024 compared to unrealized losses of $0.9 million during the first nine months of 2023 related to the Company's equity investment.

[0000889331-24-000191:mdna:40]
[same as prior period, unchanged from 0000889331-24-000161:mdna:37]

[0000889331-24-000191:mdna:41]
The effective tax rate for the three and nine months ended September 28, 2024 was 25.3% and 21.9%, compared to the effective tax rate for the three and nine months ended September 30, 2023 of 23.3% and 19.7%. The effective tax rates for 2024 are higher than the effective tax rates for the comparable 2023 periods primarily due to decreases in the income earned in lower tax jurisdictions in 2024 as compared to 2023.

[0000889331-24-000191:mdna:42]
The effective tax rates for the three months ended September 28, 2024 and September 30, 2023 are higher than the statutory tax rate primarily due to the impact of foreign exchange losses with no related tax benefit. Additionally, for the 2024 period, the effective tax rate was also higher due to the proportion of pre-tax income that is earned in higher tax jurisdictions. The effective tax rate for the nine months ended September 28, 2024 is higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions, partially offset by previously unrecognized tax benefits recognized in the first quarter due to the lapse in the statute of limitations. The effective tax rate for the nine months ended September 30, 2023 is lower than the statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-24-000191:mdna:43]
[same as prior period, unchanged from 0000889331-24-000161:mdna:40]

[0000889331-24-000191:mdna:44]
[same as prior period, unchanged from 0000889331-24-000161:mdna:41]

[0000889331-24-000191:mdna:45]
[same as prior period, unchanged from 0000889331-24-000161:mdna:42]

[0000889331-24-000191:mdna:46]
| Net Sales |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Electronics |  | $ | 304,188 |  |  | $ | 343,933 |  |  | $ | (39,745) |  |  | (11.6) | % |  | $ | 900,932 |  |  | $ | 1,052,673 |  |  | $ | (151,741) |  |  | (14.4) | % |
| Transportation |  | 171,381 |  |  | 177,019 |  |  | (5,638) |  |  | (3.2) | % |  | 510,711 |  |  | 515,708 |  |  | (4,997) |  |  | (1.0) | % |
| Industrial |  | 91,821 |  |  | 86,119 |  |  | 5,702 |  |  | 6.6 | % |  | 249,620 |  |  | 260,469 |  |  | (10,849) |  |  | (4.2) | % |
| Total |  | $ | 567,390 |  |  | $ | 607,071 |  |  | $ | (39,681) |  |  | (6.5) | % |  | $ | 1,661,263 |  |  | $ | 1,828,850 |  |  | $ | (167,587) |  |  | (9.2) | % |

[0000889331-24-000191:mdna:47]
| Operating Income |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Electronics |  | $ | 48,891 |  |  | $ | 77,022 |  |  | $ | (28,131) |  |  | (36.5) | % |  | $ | 132,859 |  |  | $ | 247,028 |  |  | $ | (114,169) |  |  | (46.2) | % |
| Transportation |  | 23,485 |  |  | 9,694 |  |  | 13,791 |  |  | 142.3 | % |  | 54,925 |  |  | 26,015 |  |  | 28,910 |  |  | 111.1 | % |
| Industrial |  | 17,711 |  |  | 13,201 |  |  | 4,510 |  |  | 34.2 | % |  | 32,054 |  |  | 45,450 |  |  | (13,396) |  |  | (29.5) | % |
| Other (a) |  | (2,266) |  |  | (6,272) |  |  | 4,006 |  |  |  |  | (11,559) |  |  | (22,154) |  |  | 10,595 |  |  |  |
| Total |  | $ | 87,821 |  |  | $ | 93,645 |  |  | $ | (5,824) |  |  | (6.2) | % |  | $ | 208,279 |  |  | $ | 296,339 |  |  | $ | (88,060) |  |  | (29.7) | % |

[0000889331-24-000191:mdna:48]
(a) Included in “Other” Operating income for the third quarter of 2024 was $1.8 million ($9.4 million year-to-date) of restructuring charges primarily related to employee termination cost, and $1.0 million ($2.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the third quarter of 2024, the Company recorded a gain of $0.5 million related to the sale of a land use right within the Electronics segment. In addition, the Company recognized a gain of $1.0 million for the sale of two buildings within the Transportation segment during the first half of 2024.

[0000889331-24-000191:mdna:49]
Included in “Other” Operating income for the third quarter of 2023 was $3.7 million ($8.5 million year-to-date) of restructuring charges, primarily related to employee termination costs, and $1.8 million ($9.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000191:mdna:50]
[same as prior period, unchanged from 0000889331-24-000161:mdna:47]

[0000889331-24-000191:mdna:51]
[same as prior period, unchanged from 0000889331-24-000161:mdna:48]

[0000889331-24-000191:mdna:52]
Net sales decreased $39.7 million, or 11.6%, in the third quarter of 2024 compared to the third quarter of 2023 and included favorable changes in foreign exchange rates of $0.5 million. The sales decrease was due to lower volume from the semiconductor business resulting in a sales decline of $39.6 million driven by reduced demand across industrial markets and inventory rebalancing at certain distributors.

[0000889331-24-000191:mdna:53]
Net sales decreased $151.7 million, or 14.4%, in the first nine months of 2024 compared to the first nine months of 2023 and included unfavorable changes in foreign exchange rates of $3.0 million. The sales decrease was mainly due to lower volume from the semiconductor business of $129.4 million and to a lesser extent the electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, as well as industrial markets.

[0000889331-24-000191:mdna:54]
[same as prior period, unchanged from 0000889331-24-000161:mdna:51]

[0000889331-24-000191:mdna:55]
Operating income was $48.9 million, representing a decrease of $28.1 million, or 36.5%, for the third quarter of 2024 compared to $77.0 million for the third quarter of 2023. The decrease in operating income was primarily from the semiconductor business due to lower volume leverage and unfavorable product mix. Operating margins decreased from 22.4% in the third quarter of 2023 to 16.1% in the third quarter of 2024 primarily due to the lower volume.

[0000889331-24-000191:mdna:56]
Operating income was $132.9 million, representing a decrease of $114.2 million, or 46.2%, for the first nine months of 2024 compared to $247.0 million for the first nine months of 2023. The decrease in operating income was primarily due to lower volume leverage and unfavorable product mix that were partially offset by cost control initiatives. Operating margins decreased from 23.5% in the first nine months of 2023 to 14.7% in the first nine months of 2024 primarily due to the lower volume.

[0000889331-24-000191:mdna:57]
[same as prior period, unchanged from 0000889331-24-000161:mdna:54]

[0000889331-24-000191:mdna:58]
[same as prior period, unchanged from 0000889331-24-000161:mdna:55]

[0000889331-24-000191:mdna:59]
Net sales decreased $5.6 million, or 3.2%, in the third quarter of 2024 compared to the third quarter of 2023 and included favorable changes in foreign exchange rates of $0.5 million. The sales decline was primarily due to lower automotive sensors business volume of $5.2 million driven by the strategic exit of certain lower margin products.

[0000889331-24-000191:mdna:60]
Net sales decreased $5.0 million, or 1.0%, in the first nine months of 2024 compared to the first nine months of 2023 and included unfavorable changes in foreign exchange rates of $2.3 million. The sales decrease was mainly driven by lower volume of $9.1 million and $6.4 million from the automotive sensors and the commercial vehicles businesses, respectively, due to the strategic exit of certain lower margin products and reduced demand largely due to inventory rebalancing at certain distributors and customers, partially offset by a sales increase of $10.5 million from the passenger car business driven by the ongoing electronification and electrification of vehicles and vehicle content growth.

[0000889331-24-000191:mdna:61]
[same as prior period, unchanged from 0000889331-24-000161:mdna:58]

[0000889331-24-000191:mdna:62]
Operating income was $23.5 million, representing an increase of $13.8 million, or 142.3%, for the third quarter of 2024 compared to $9.7 million for the third quarter of 2023. The increase in operating income was primarily from the commercial vehicle and passenger car businesses due to favorable price and cost reduction initiatives. Operating margins increased from 5.5% in the third quarter of 2023 to 13.7% in the third quarter of 2024 primarily driven by favorable price and products mix and cost reduction initiatives from all businesses.

[0000889331-24-000191:mdna:63]
Operating income was $54.9 million, representing an increase of $28.9 million, or 111.1%, for the first nine months of 2024 compared to $26.0 million for the first nine months of 2023. The increase in operating income was primarily due to favorable price and cost reduction initiatives from the commercial vehicle business. Operating margins increased from 5.0% in the first nine months of 2023 to 10.8% in the first nine months of 2024 primarily driven by favorable price and products mix and cost reduction initiatives from the commercial vehicle business.

[0000889331-24-000191:mdna:64]
[same as prior period, unchanged from 0000889331-24-000161:mdna:61]

[0000889331-24-000191:mdna:65]
[same as prior period, unchanged from 0000889331-24-000161:mdna:62]

[0000889331-24-000191:mdna:66]
Net sales increased by $5.7 million, or 6.6%, in the third quarter of 2024 compared to the third quarter of 2023, which included unfavorable changes in foreign exchange rates of $0.3 million. The sales increase was due to higher volume from industrial circuit protection and industrial control and sensor products driven by higher end market demand.

[0000889331-24-000191:mdna:67]
Net sales decreased by $10.8 million, or 4.2%, in the first nine months of 2024 compared to the first nine months of 2023, which included unfavorable changes in foreign exchange rates of $0.9 million. The sales decrease was due to lower volume across industrial control products driven by softer end market demand in the first half of 2024.

[0000889331-24-000191:mdna:68]
[same as prior period, unchanged from 0000889331-24-000161:mdna:65]

[0000889331-24-000191:mdna:69]
Operating income was $17.7 million, representing an increase of $4.5 million, or 34.2%, for the third quarter of 2024 compared to $13.2 million for the third quarter of 2023. The increase in operating income was driven by higher volume from industrial circuit protection and industrial control and sensor products driven by increased end market demand. Operating margins increased from 15.3% in the third quarter of 2023 to 19.3% in the third quarter of 2024 due to higher volume, product mix and price.

[0000889331-24-000191:mdna:70]
Operating income was $32.1 million, representing a decrease of $13.4 million, or 29.5%, for the first nine months of 2024 compared to $45.5 million for the first nine months of 2023. The decrease in operating income was driven by lower volume due to reduced industrial end market demand across industrial control products and industrial circuit protection along with cost inflation. Operating margins decreased from 17.4% in the first nine months of 2023 to 12.8% in the first nine months of 2024 due to lower demand and cost inflation, partially offset by favorable price.

[0000889331-24-000191:mdna:71]
[same as prior period, unchanged from 0000889331-24-000161:mdna:68]

[0000889331-24-000191:mdna:72]
[same as prior period, unchanged from 0000889331-24-000161:mdna:69]

[0000889331-24-000191:mdna:73]
|  |  | Third Quarter |  | First Nine Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Americas |  | $ | 237,951 |  |  | $ | 236,706 |  |  | $ | 1,245 |  |  | 0.5 | % |  | $ | 681,064 |  |  | $ | 698,456 |  |  | $ | (17,392) |  |  | (2.5) | % |
| Asia-Pacific |  | 213,942 |  |  | 235,908 |  |  | (21,966) |  |  | (9.3) | % |  | 621,731 |  |  | 693,611 |  |  | (71,880) |  |  | (10.4) | % |
| Europe |  | 115,497 |  |  | 134,457 |  |  | (18,960) |  |  | (14.1) | % |  | 358,468 |  |  | 436,783 |  |  | (78,315) |  |  | (17.9) | % |
| Total |  | $ | 567,390 |  |  | $ | 607,071 |  |  | $ | (39,681) |  |  | (6.5) | % |  | $ | 1,661,263 |  |  | $ | 1,828,850 |  |  | $ | (167,587) |  |  | (9.2) | % |

[0000889331-24-000191:mdna:74]
[same as prior period, unchanged from 0000889331-24-000161:mdna:71]

[0000889331-24-000191:mdna:75]
Net sales increased $1.2 million, or 0.5%, in the third quarter of 2024 compared to the third quarter of 2023 and included unfavorable changes in foreign exchange rates of $0.3 million. The net sales increase was due to higher volume from the Industrial segment, partially offset by lower volume from the Electronics segment compared to the third quarter of 2023.

[0000889331-24-000191:mdna:76]
Net sales decreased $17.4 million, or 2.5%, in the first nine months of 2024 compared to the first nine months of 2023 and included unfavorable changes in foreign exchange rates of $0.5 million. The decrease in net sales was primarily due to lower volume from the Electronics segment, partially offset by higher volume from the Industrial segment and the commercial vehicle and passenger car products businesses within the Transportation segment compared to the first nine months of 2023.

[0000889331-24-000191:mdna:77]
[same as prior period, unchanged from 0000889331-24-000161:mdna:74]

[0000889331-24-000191:mdna:78]
Net sales decreased $22.0 million, or 9.3%, in the third quarter of 2024 compared to the third quarter of 2023 and included unfavorable changes in foreign exchange rates of $0.5 million. The decrease in net sales was primarily due to lower net sales from the Electronics and Industrial segments, partially offset by higher net sales from the commercial vehicle and passenger car products businesses within the Transportation segment compared to the third quarter of 2023.

[0000889331-24-000191:mdna:79]
Net sales decreased $71.9 million, or 10.4%, in the first nine months of 2024 compared to the first nine months of 2023 and included unfavorable changes in foreign exchange rates of $8.1 million. The decrease in net sales was primarily due to lower net sales from the Electronics and Industrial segments, partially offset by higher net sales from the passenger car products business within the Transportation segment compared to the first nine months of 2023.

[0000889331-24-000191:mdna:80]
[same as prior period, unchanged from 0000889331-24-000161:mdna:77]

[0000889331-24-000191:mdna:81]
Net sales decreased $19.0 million, or 14.1%, in the third quarter of 2024 compared to the third quarter of 2023 and included favorable changes in foreign exchange rates of $1.5 million. The decrease in net sales was primarily due to lower net sales from the Electronics and Transportation segments compared to the third quarter of 2023.

[0000889331-24-000191:mdna:82]
Net sales decreased $78.3 million, or 17.9%, in the first nine months of 2024 compared to the first nine months of 2023 and included favorable changes in foreign exchange rates of $2.4 million. The decrease in net sales was primarily due to lower net sales from the Electronics segment and lower net sales from the commercial vehicle and automotive sensors businesses within the Transportation segment compared to the first nine months of 2023.

[0000889331-24-000191:mdna:83]
[same as prior period, unchanged from 0000889331-24-000161:mdna:80]

[0000889331-24-000191:mdna:84]
[same as prior period, unchanged from 0000889331-24-000161:mdna:81]

[0000889331-24-000191:mdna:85]
Cash and cash equivalents were $629.7 million as of September 28, 2024, an increase of $74.2 million, as compared to December 30, 2023. As of September 28, 2024, $135.5 million of the Company's $629.7 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-24-000191:mdna:86]
Revolving Credit Facility and Term Loan

[0000889331-24-000191:mdna:87]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-24-000191:mdna:88]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-24-000191:mdna:89]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the nine months ended September 28, 2024, the Company made payments of $3.8 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of September 28, 2024.

[0000889331-24-000191:mdna:90]
[same as prior period, unchanged from 0000889331-24-000161:mdna:87]

[0000889331-24-000191:mdna:91]
As of September 28, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.60%, and 4.13% on the hedged portion.

[0000889331-24-000191:mdna:92]
As of September 28, 2024, the Company had $0.1 million outstanding letters of credit under the Credit Facility and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 28, 2024, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-24-000191:mdna:93]
[same as prior period, unchanged from 0000889331-24-000161:mdna:90]

[0000889331-24-000191:mdna:94]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-24-000191:mdna:95]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-24-000191:mdna:96]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-24-000191:mdna:97]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-24-000191:mdna:98]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-24-000191:mdna:99]
Debt Covenants

[0000889331-24-000191:mdna:100]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of September 28, 2024 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2023. As of September 28, 2024, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-24-000191:mdna:101]
[same as prior period, unchanged from 0000889331-24-000161:mdna:99]

[0000889331-24-000191:mdna:102]
[same as prior period, unchanged from 0000889331-24-000161:mdna:100]

[0000889331-24-000191:mdna:103]
[same as prior period, unchanged from 0000889331-24-000161:mdna:101]

[0000889331-24-000191:mdna:104]
During the third quarter of 2024 the Company paid quarterly dividends of $17.4 million to the shareholders. On October 29, 2024, the Company announced the declaration of a quarterly cash dividend of $0.70 per share payable on December 5, 2024 to stockholders of record as of November 21, 2024.

[0000889331-24-000191:mdna:105]
[same as prior period, unchanged from 0000889331-24-000161:mdna:103]

[0000889331-24-000191:mdna:106]
|  |  | First Nine Months |
| (in thousands) |  | 2024 |  | 2023 |
| Net cash provided by operating activities |  | $ | 206,999 |  |  | $ | 313,140 |  |
| Net cash used in investing activities |  | (41,134) |  |  | (261,379) |  |
| Net cash used in financing activities |  | (91,299) |  |  | (47,144) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (396) |  |  | (7,965) |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 74,170 |  |  | (3,348) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 557,123 |  |  | 564,939 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 631,293 |  |  | $ | 561,591 |  |

[0000889331-24-000191:mdna:107]
[same as prior period, unchanged from 0000889331-24-000161:mdna:105]

[0000889331-24-000191:mdna:108]
[same as prior period, unchanged from 0000889331-24-000161:mdna:106]

[0000889331-24-000191:mdna:109]
Net cash provided by operating activities was $207.0 million for the nine months ended September 28, 2024 compared to $313.1 million for the nine months ended September 30, 2023. The decrease in net cash provided by operating activities was primarily due to lower cash earnings.

[0000889331-24-000191:mdna:110]
[same as prior period, unchanged from 0000889331-24-000161:mdna:108]

[0000889331-24-000191:mdna:111]
Net cash used in investing activities was $41.1 million for the nine months ended September 28, 2024 compared to $261.4 million during the nine months ended September 30, 2023. Capital expenditures were $50.1 million, representing a decrease of $13.1 million compared to the nine months ended September 30, 2023. During the nine months ended September 28, 2024, the Company received net proceeds of $9.7 million mainly from the sale of a land use right within the Electronics segment and two buildings from the Transportation segment. Net cash paid for the Western Automation acquisition was $198.8 million during the nine months ended September 30, 2023.

[0000889331-24-000191:mdna:112]
[same as prior period, unchanged from 0000889331-24-000161:mdna:110]

[0000889331-24-000191:mdna:113]
Net cash used in financing activities was $91.3 million for the nine months ended September 28, 2024 compared to $47.1 million during the nine months ended September 30, 2023. During the nine months ended September 28, 2024 and September 30, 2023, the Company made payments of $3.8 million and $5.6 million on the term loan, respectively. The Company paid dividends of $49.7 million and $46.0 million in the nine months ended September 28, 2024 and September 30, 2023, respectively. Additionally, during the nine months ended September 28, 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million.

[0000889331-24-000191:mdna:114]
[same as prior period, unchanged from 0000889331-24-000161:mdna:112]

[0000889331-24-000191:mdna:115]
The Company’s Board of Directors authorized the repurchase of up to $300.0 million in the aggregate of shares of the Company’s common stock under a program for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program. The Company did not repurchase shares of its common stock for the three months ended September 28, 2024. During the nine months ended September 28, 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. The Company did not repurchase shares of its common stock for the three and nine months ended September 30, 2023.

[0000889331-24-000191:mdna:116]
[same as prior period, unchanged from 0000889331-24-000161:mdna:114]

[0000889331-24-000191:mdna:117]
As of September 28, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-24-000191:mdna:118]
[same as prior period, unchanged from 0000889331-24-000161:mdna:116]

[0000889331-24-000191:mdna:119]
[same as prior period, unchanged from 0000889331-24-000161:mdna:117]

[0000889331-24-000191:mdna:120]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 30, 2023. During the nine months ended September 28, 2024, there were no significant changes in the application of critical accounting policies and estimates.
