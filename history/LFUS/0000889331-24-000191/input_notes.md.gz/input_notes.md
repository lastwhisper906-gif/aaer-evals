# LFUS notes — 0000889331-24-000191


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-24-000191:notes:1]
[same as prior period, unchanged from 0000889331-24-000161:notes:1]

[0000889331-24-000191:notes:2]
[same as prior period, unchanged from 0000889331-24-000161:notes:2]

[0000889331-24-000191:notes:3]
Founded in 1927, Littelfuse, Inc. ("Littelfuse" or the "Company") is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-24-000191:notes:4]
[same as prior period, unchanged from 0000889331-24-000161:notes:4]

[0000889331-24-000191:notes:5]
[same as prior period, unchanged from 0000889331-24-000161:notes:5]

[0000889331-24-000191:notes:6]
[same as prior period, unchanged from 0000889331-24-000161:notes:6]

[0000889331-24-000191:notes:7]
[same as prior period, unchanged from 0000889331-24-000161:notes:7]

[0000889331-24-000191:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2024 and September 30, 2023:

[0000889331-24-000191:notes:9]
|  |  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 151,954 |  |  | $ | — |  |  | $ | — |  |  | $ | 151,954 |  |  | $ | 469,389 |  |  | $ | — |  |  | $ | — |  |  | $ | 469,389 |  |
| Electronics – Passive Products and Sensors |  | 152,234 |  |  | — |  |  | — |  |  | 152,234 |  |  | 431,543 |  |  | — |  |  | — |  |  | 431,543 |  |
| Commercial Vehicle Products |  | — |  |  | 82,077 |  |  | — |  |  | 82,077 |  |  | — |  |  | 242,350 |  |  | — |  |  | 242,350 |  |
| Passenger Car Products |  | — |  |  | 71,299 |  |  | — |  |  | 71,299 |  |  | — |  |  | 210,597 |  |  | — |  |  | 210,597 |  |
| Automotive Sensors |  | — |  |  | 18,005 |  |  | — |  |  | 18,005 |  |  | — |  |  | 57,764 |  |  | — |  |  | 57,764 |  |
| Industrial Products |  | — |  |  | — |  |  | 91,821 |  |  | 91,821 |  |  | — |  |  | — |  |  | 249,620 |  |  | 249,620 |  |
| Total |  | $ | 304,188 |  |  | $ | 171,381 |  |  | $ | 91,821 |  |  | $ | 567,390 |  |  | $ | 900,932 |  |  | $ | 510,711 |  |  | $ | 249,620 |  |  | $ | 1,661,263 |  |

[0000889331-24-000191:notes:10]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 191,523 |  |  | $ | — |  |  | $ | — |  |  | $ | 191,523 |  |  | $ | 598,813 |  |  | $ | — |  |  | $ | — |  |  | $ | 598,813 |  |
| Electronics – Passive Products and Sensors |  | 152,410 |  |  | — |  |  | — |  |  | 152,410 |  |  | 453,860 |  |  | — |  |  | — |  |  | 453,860 |  |
| Commercial Vehicle Products |  | — |  |  | 81,290 |  |  | — |  |  | 81,290 |  |  | — |  |  | 248,765 |  |  | — |  |  | 248,765 |  |
| Passenger Car Products |  | — |  |  | 72,524 |  |  | — |  |  | 72,524 |  |  | — |  |  | 200,104 |  |  | — |  |  | 200,104 |  |
| Automotive Sensors |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |  | — |  |  | 66,839 |  |  | — |  |  | 66,839 |  |
| Industrial Products |  | — |  |  | — |  |  | 86,119 |  |  | 86,119 |  |  |  |  |  |  | 260,469 |  |  | 260,469 |  |
| Total |  | $ | 343,933 |  |  | $ | 177,019 |  |  | $ | 86,119 |  |  | $ | 607,071 |  |  | $ | 1,052,673 |  |  | $ | 515,708 |  |  | $ | 260,469 |  |  | $ | 1,828,850 |  |

[0000889331-24-000191:notes:11]
See Note 14, Segment Information, for net sales by segment and country.

[0000889331-24-000191:notes:12]
[same as prior period, unchanged from 0000889331-24-000161:notes:12]

[0000889331-24-000191:notes:13]
[same as prior period, unchanged from 0000889331-24-000161:notes:13]

[0000889331-24-000191:notes:14]
[same as prior period, unchanged from 0000889331-24-000161:notes:14]

[0000889331-24-000191:notes:15]
[same as prior period, unchanged from 0000889331-24-000161:notes:15]

[0000889331-24-000191:notes:16]
[same as prior period, unchanged from 0000889331-24-000161:notes:16]

[0000889331-24-000191:notes:17]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-24-000191:notes:18]
[same as prior period, unchanged from 0000889331-24-000161:notes:18]

[0000889331-24-000191:notes:19]
[same as prior period, unchanged from 0000889331-24-000161:notes:19]

[0000889331-24-000191:notes:20]
[same as prior period, unchanged from 0000889331-24-000161:notes:20]

[0000889331-24-000191:notes:21]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-24-000191:notes:22]
[same as prior period, unchanged from 0000889331-24-000161:notes:22]

[0000889331-24-000191:notes:23]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at September 28, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-24-000191:notes:24]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 629,670 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,623 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 631,293 |  |  | $ | 557,123 |  |

[0000889331-24-000191:notes:25]
Recently Adopted Accounting Standards

[0000889331-24-000191:notes:26]
In March 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements." The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

[0000889331-24-000191:notes:27]
Recently Issued Accounting Standards

[0000889331-24-000191:notes:28]
In March 2024, the Securities and Exchange Commission ("SEC") issued a final rule that requires registrants to provide climate disclosures in annual reports and registration statements. The climate-related final rule requires disclosures in the footnotes to the financial statements, including: 1) specified financial statement effects of severe weather events and other natural conditions, 2) certain carbon offsets and renewable energy credits or certificates if used as a material component of a registrant's plans to achieve its disclosed climate-related targets or goals, 3) material impacts on financial estimates and assumptions in the financial statements if they would materially impacted by risks and uncertainties associated with severe weather events and other natural conditions, previously disclosed climate-related targets, and transition plans. The financial statement disclosure requirements are effective beginning with annual reports for the fiscal year beginning in calendar year 2025 for the Company as a large accelerated filer. These disclosures will be subject to existing audit requirement for financial statements. On April 4, 2024, the SEC chose to stay its climate disclosure rules pending judicial review. The adoption of this rule will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating and is in the process of performing its initial assessment of the potential impact on its Condensed Consolidated Financial Statements.

[0000889331-24-000191:notes:29]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

[0000889331-24-000191:notes:30]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures." The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of the Chief Operating Decision Maker (“CODM”) on an annual basis as well as an explanation of how the CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

[0000889331-24-000191:notes:31]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000889331-24-000191:notes:32]
[same as prior period, unchanged from 0000889331-24-000161:notes:33]

[0000889331-24-000191:notes:33]
[same as prior period, unchanged from 0000889331-24-000161:notes:34]

[0000889331-24-000191:notes:34]
[same as prior period, unchanged from 0000889331-24-000161:notes:35]

[0000889331-24-000191:notes:35]
[same as prior period, unchanged from 0000889331-24-000161:notes:36]

[0000889331-24-000191:notes:36]
[same as prior period, unchanged from 0000889331-24-000161:notes:37]

[0000889331-24-000191:notes:37]
[same as prior period, unchanged from 0000889331-24-000161:notes:38]

[0000889331-24-000191:notes:38]
[same as prior period, unchanged from 0000889331-24-000161:notes:39]

[0000889331-24-000191:notes:39]
[same as prior period, unchanged from 0000889331-24-000161:notes:40]

[0000889331-24-000191:notes:40]
[same as prior period, unchanged from 0000889331-24-000161:notes:41]

[0000889331-24-000191:notes:41]
[same as prior period, unchanged from 0000889331-24-000161:notes:42]

[0000889331-24-000191:notes:42]
During the nine months ended September 30, 2023, the Company incurred approximately $1.2 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses in the Condensed Consolidated Statement of Net Income. These costs were reflected as other non-segment costs.

[0000889331-24-000191:notes:43]
[same as prior period, unchanged from 0000889331-24-000161:notes:44]

[0000889331-24-000191:notes:44]
[same as prior period, unchanged from 0000889331-24-000161:notes:45]

[0000889331-24-000191:notes:45]
| (in thousands, except per share amounts) |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| Net sales |  | $ | 607,071 |  |  | $ | 1,830,736 |  |
| Income before income taxes |  | 75,071 |  |  | 271,165 |  |
| Net income |  | 57,591 |  |  | 217,930 |  |
| Net income per share — basic |  | 2.31 |  |  | 8.77 |  |
| Net income per share — diluted |  | 2.29 |  |  | 8.68 |  |

[0000889331-24-000191:notes:46]
[same as prior period, unchanged from 0000889331-24-000161:notes:47]

[0000889331-24-000191:notes:47]
| (in thousands) |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| Amortization (a) |  | $ | — |  |  | $ | (479) |  |
| Transaction costs (b) |  | (224) |  |  | 1,203 |  |
| Income tax benefit (expense) of above items |  | 28 |  |  | (91) |  |

[0000889331-24-000191:notes:48]
(a) The amortization adjustment for the nine months ended September 30, 2023 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-24-000191:notes:49]
(b) The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three and nine months ended September 30, 2023.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-24-000191:notes:50]
[same as prior period, unchanged from 0000889331-24-000161:notes:51]

[0000889331-24-000191:notes:51]
The components of inventories at September 28, 2024 and December 30, 2023 are as follows:

[0000889331-24-000191:notes:52]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Raw materials |  | $ | 202,119 |  |  | $ | 201,984 |  |
| Work in process |  | 137,713 |  |  | 137,688 |  |
| Finished goods |  | 178,570 |  |  | 195,886 |  |
| Inventory reserves |  | (64,621) |  |  | (60,951) |  |
| Total |  | $ | 453,781 |  |  | $ | 474,607 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-24-000191:notes:53]
[same as prior period, unchanged from 0000889331-24-000161:notes:54]

[0000889331-24-000191:notes:54]
The components of net property, plant, and equipment at September 28, 2024 and December 30, 2023 are as follows:

[0000889331-24-000191:notes:55]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Land and land improvements |  | $ | 18,442 |  |  | $ | 22,212 |  |
| Building and building improvements |  | 200,856 |  |  | 202,764 |  |
| Machinery and equipment |  | 896,045 |  |  | 859,060 |  |
| Accumulated depreciation |  | (633,751) |  |  | (590,883) |  |
| Total |  | $ | 481,592 |  |  | $ | 493,153 |  |

[0000889331-24-000191:notes:56]
The Company recorded depreciation expense of $17.3 million and $17.9 million for the three months ended September 28, 2024 and September 30, 2023, respectively, and $51.0 million and $53.5 million for the nine months ended September 28, 2024 and September 30, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-24-000191:notes:57]
[same as prior period, unchanged from 0000889331-24-000161:notes:58]

[0000889331-24-000191:notes:58]
Changes in the carrying value of goodwill by segment for the nine months ended September 28, 2024 are as follows:

[0000889331-24-000191:notes:59]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net goodwill as of December 30, 2023 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 30, 2023 |  | $ | 936,505 |  |  | $ | 237,115 |  |  | $ | 179,117 |  |  | $ | 1,352,737 |  |
| Accumulated impairment losses as of December 30, 2023 |  | — |  |  | (34,004) |  |  | (8,735) |  |  | (42,739) |  |
| Total |  | 936,505 |  |  | 203,111 |  |  | 170,382 |  |  | 1,309,998 |  |
| Changes during 2024: |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments |  | 3,581 |  |  | 1,881 |  |  | 2,288 |  |  | 7,750 |  |
| Net goodwill as of September 28, 2024 |  |  |  |  |  |  |  |  |
| Gross goodwill as of September 28, 2024 |  | 940,086 |  |  | 239,777 |  |  | 181,237 |  |  | 1,361,100 |  |
| Accumulated impairment losses as of September 28, 2024 |  | — |  |  | (34,785) |  |  | (8,567) |  |  | (43,352) |  |
| Total |  | $ | 940,086 |  |  | $ | 204,992 |  |  | $ | 172,670 |  |  | $ | 1,317,748 |  |

[0000889331-24-000191:notes:60]
The components of other intangible assets as of September 28, 2024 and December 30, 2023 are as follows:

[0000889331-24-000191:notes:61]
|  |  |  | As of September 28, 2024 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 16,731 |  |  | $ | 2,989 |  |  | $ | 13,742 |  |
| Patents, licenses, and software |  |  | 277,011 |  |  | 181,471 |  |  | 95,540 |  |
| Distribution network |  |  | 42,106 |  |  | 42,106 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 691,519 |  |  | 239,807 |  |  | 451,712 |  |
| Total |  |  | $ | 1,027,367 |  |  | $ | 466,373 |  |  | $ | 560,994 |  |

[0000889331-24-000191:notes:62]
[same as prior period, unchanged from 0000889331-24-000161:notes:63]

[0000889331-24-000191:notes:63]
During the three months ended September 28, 2024 and September 30, 2023, the Company recorded amortization expense of $15.9 million and $16.0 million, respectively. During the nine months ended September 28, 2024 and September 30, 2023, the Company recorded amortization expense of $47.4 million and $49.8 million, respectively.

[0000889331-24-000191:notes:64]
Estimated annual amortization expense related to intangible assets with definite lives as of September 28, 2024 is as follows:

[0000889331-24-000191:notes:65]
| (in thousands) | Amount |
| Remainder of 2024 | $ | 16,000 |  |
| 2025 | 63,795 |  |
| 2026 | 52,706 |  |
| 2027 | 50,597 |  |
| 2028 | 49,970 |  |
| 2029 and thereafter | 327,926 |  |
| Total | $ | 560,994 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-24-000191:notes:66]
[same as prior period, unchanged from 0000889331-24-000161:notes:67]

[0000889331-24-000191:notes:67]
The components of accrued liabilities as of September 28, 2024 and December 30, 2023 are as follows:

[0000889331-24-000191:notes:68]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Employee-related liabilities |  | $ | 71,614 |  |  | $ | 72,635 |  |
| Current lease liability |  | 10,162 |  |  | 12,110 |  |
| Other non-income taxes |  | 7,597 |  |  | 7,855 |  |
| Interest |  | 5,311 |  |  | 6,387 |  |
| Professional services |  | 4,938 |  |  | 5,282 |  |
| Other customer reserves |  | 4,815 |  |  | 5,998 |  |
| Restructuring liability |  | 4,461 |  |  | 2,141 |  |
| Current hedge liability |  | 4,307 |  |  | — |  |
| Deferred revenue |  | 1,614 |  |  | 2,198 |  |
| Current benefit liability |  | 1,482 |  |  | 1,482 |  |
| Other |  | 36,471 |  |  | 33,126 |  |
| Total |  | $ | 152,772 |  |  | $ | 149,214 |  |

[0000889331-24-000191:notes:69]
[same as prior period, unchanged from 0000889331-24-000161:notes:70]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-24-000191:notes:70]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three and nine months ended September 28, 2024 and September 30, 2023 as follows:

[0000889331-24-000191:notes:71]
|  | Three Months Ended September 28, 2024 |  | Nine Months Ended September 28, 2024 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,140 |  |  | $ | 404 |  |  | $ | 1 |  |  | $ | 1,545 |  |  | $ | 6,245 |  |  | $ | 1,995 |  |  | $ | 417 |  |  | $ | 8,657 |  |
| Other restructuring charges | 95 |  |  | 187 |  |  | 13 |  |  | 295 |  |  | 234 |  |  | 474 |  |  | 31 |  |  | 739 |  |
| Total restructuring charges | 1,235 |  |  | 591 |  |  | 14 |  |  | 1,840 |  |  | 6,479 |  |  | 2,469 |  |  | 448 |  |  | 9,396 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 933 |  |  | — |  |  | 933 |  |
| Total | $ | 1,235 |  |  | $ | 591 |  |  | $ | 14 |  |  | $ | 1,840 |  |  | $ | 6,479 |  |  | $ | 3,402 |  |  | $ | 448 |  |  | $ | 10,329 |  |

[0000889331-24-000191:notes:72]
|  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,174 |  |  | $ | 1,665 |  |  | $ | 293 |  |  | $ | 3,132 |  |  | $ | 2,833 |  |  | $ | 2,598 |  |  | $ | 887 |  |  | $ | 6,318 |  |
| Other restructuring charges | 64 |  |  | 138 |  |  | 364 |  |  | 566 |  |  | 321 |  |  | 822 |  |  | 1,018 |  |  | 2,161 |  |
| Total restructuring charges | 1,238 |  |  | 1,803 |  |  | 657 |  |  | 3,698 |  |  | 3,154 |  |  | 3,420 |  |  | 1,905 |  |  | 8,479 |  |
| Impairment | — |  |  | — |  |  | 818 |  |  | 818 |  |  | — |  |  | 3,870 |  |  | 872 |  |  | 4,742 |  |
| Total | $ | 1,238 |  |  | $ | 1,803 |  |  | $ | 1,475 |  |  | $ | 4,516 |  |  | $ | 3,154 |  |  | $ | 7,290 |  |  | $ | 2,777 |  |  | $ | 13,221 |  |

[0000889331-24-000191:notes:73]
[same as prior period, unchanged from 0000889331-24-000161:notes:74]

[0000889331-24-000191:notes:74]
For the three and nine months ended September 28, 2024, the Company recorded total restructuring charges of $1.8 million and $9.4 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the semiconductor business in the Electronics segment and the reorganization of certain selling and administrative functions within the commercial vehicle business in the Transportation segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-24-000191:notes:75]
[same as prior period, unchanged from 0000889331-24-000161:notes:76]

[0000889331-24-000191:notes:76]
For the three and nine months ended September 30, 2023, the Company recorded total restructuring charges of $3.7 million and $8.5 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment’s commercial vehicle business, and the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K Switches acquisition. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate.

[0000889331-24-000191:notes:77]
The restructuring reserves as of September 28, 2024 and December 30, 2023 are $4.5 million and $2.1 million, respectively. The restructuring liability is included within Accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in the first quarter of fiscal year 2025.


## us-gaap:DebtDisclosureTextBlock

[0000889331-24-000191:notes:78]
Debt

[0000889331-24-000191:notes:79]
The carrying amounts of debt at September 28, 2024 and December 30, 2023 are as follows:

[0000889331-24-000191:notes:80]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,106 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 4,670 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,028) |  |  | (3,770) |  |
| Total debt |  | 867,748 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,799) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 799,949 |  |  | $ | 857,915 |  |

[0000889331-24-000191:notes:81]
Revolving Credit Facility and Term Loan

[0000889331-24-000191:notes:82]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-24-000191:notes:83]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-24-000191:notes:84]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the nine months ended September 28, 2024, the Company made payments of $3.8 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of September 28, 2024.

[0000889331-24-000191:notes:85]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-24-000191:notes:86]
As of September 28, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.60%, and 4.13% on the hedged portion.

[0000889331-24-000191:notes:87]
As of September 28, 2024, the Company had $0.1 million outstanding letters of credit under the Credit Facility and had $599.9 million of borrowing capacity available under the revolving credit facility. As of September 28, 2024, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-24-000191:notes:88]
Senior Notes

[0000889331-24-000191:notes:89]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-24-000191:notes:90]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-24-000191:notes:91]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-24-000191:notes:92]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-24-000191:notes:93]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-24-000191:notes:94]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-24-000191:notes:95]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of September 28, 2024, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-24-000191:notes:96]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-24-000191:notes:97]
Interest paid on all Company debt was $10.5 million and $11.9 million for the three months ended September 28, 2024 and September 30, 2023, respectively, and $30.1 million and $33.2 million for the nine months ended September 28, 2024 and September 30, 2023, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-24-000191:notes:98]
[same as prior period, unchanged from 0000889331-24-000161:notes:99]

[0000889331-24-000191:notes:99]
[same as prior period, unchanged from 0000889331-24-000161:notes:100]

[0000889331-24-000191:notes:100]
[same as prior period, unchanged from 0000889331-24-000161:notes:101]

[0000889331-24-000191:notes:101]
[same as prior period, unchanged from 0000889331-24-000161:notes:102]

[0000889331-24-000191:notes:102]
[same as prior period, unchanged from 0000889331-24-000161:notes:103]

[0000889331-24-000191:notes:103]
[same as prior period, unchanged from 0000889331-24-000161:notes:105]

[0000889331-24-000191:notes:104]
[same as prior period, unchanged from 0000889331-24-000161:notes:106]

[0000889331-24-000191:notes:105]
[same as prior period, unchanged from 0000889331-24-000161:notes:107]

[0000889331-24-000191:notes:106]
[same as prior period, unchanged from 0000889331-24-000161:notes:108]

[0000889331-24-000191:notes:107]
[same as prior period, unchanged from 0000889331-24-000161:notes:109]

[0000889331-24-000191:notes:108]
[same as prior period, unchanged from 0000889331-24-000161:notes:110]

[0000889331-24-000191:notes:109]
[same as prior period, unchanged from 0000889331-24-000161:notes:111]

[0000889331-24-000191:notes:110]
For derivatives that will be accounted for as hedging instruments, the Company formally designates and documents, at inception, the financial instrument as a hedge of a specific underlying exposure, the risk management objective and the strategy for undertaking the hedge transaction. In addition, the Company formally assesses, both at the inception and at least quarterly thereafter, whether the financial instruments used in hedging transactions are effective at offsetting changes in either the fair values or cash flows of the related underlying exposures. For highly effective cash flow hedges, ASC 815 requires the entire change in fair value of the hedging instrument included in the assessment of hedge effectiveness to be recorded in other comprehensive income. No components of the Company's hedging instruments were excluded from the assessment of hedge effectiveness.

[0000889331-24-000191:notes:111]
Zero Cost Collar Agreement

[0000889331-24-000191:notes:112]
In July 2024, the Company implemented a hedging program to manage foreign currency risk exposure related to fluctuations between the U.S. dollar and Mexican peso. These foreign currency zero cost collars are designated as cash flow hedges for a portion of our Mexican peso-denominated manufacturing expenses, predominantly salary expenses, vendor payments, and utility expenses. The July 2024 collars mature in August 2025 at a weighted-average ceiling of 19.435 and a weighted-average floor of 18.000. The August 2024 collars mature in September 2025 at a weighted-average ceiling of 21.000 and a weighted-average floor of 19.655. If the spot rate is between the weighted-average ceiling and floor rates on the date of maturity, then the Company would not owe or receive any payments under these collars. The Company plans to continue executing zero cost collars with 14-month rolling maturities as an ongoing strategy to hedge peso-denominated manufacturing expenses.

[0000889331-24-000191:notes:113]
The fair value of the collars was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three months ended September 28, 2024, the Company recorded a pre-tax unrealized loss on the collars of $4.0 million. The Company estimates that approximately $4.2 million of pre-tax losses currently recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The amounts included in accumulated other comprehensive income will be reclassified to earnings should the hedge no longer be considered effective. No amount of ineffectiveness was included in net income for the three months ended September 28, 2024. The Company will continue to assess the effectiveness of the hedge on an ongoing basis. The primary inputs into the valuation of the collars are interest yield curves, interest rate volatilities, foreign exchange rates, foreign exchange volatilities, credit risk, credit spreads and other market information. The collars are classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by market observable data.

[0000889331-24-000191:notes:114]
Interest Rate Swap

[0000889331-24-000191:notes:115]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three and nine months ended September 28, 2024, the Company recorded a pre-tax unrealized loss on the interest rate swap of $5.9 million and $3.3 million, respectively. The Company estimates that approximately $1.8 million of pre-tax gain currently recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by market observable data.

[0000889331-24-000191:notes:116]
[same as prior period, unchanged from 0000889331-24-000161:notes:113]

[0000889331-24-000191:notes:117]
[same as prior period, unchanged from 0000889331-24-000161:notes:114]

[0000889331-24-000191:notes:118]
[same as prior period, unchanged from 0000889331-24-000161:notes:115]

[0000889331-24-000191:notes:119]
The Company does not enter into derivative financial instruments for trading purposes.

[0000889331-24-000191:notes:120]
As of September 28, 2024 and December 30, 2023, the fair values of the Company's derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-24-000191:notes:121]
| (in thousands) | Condensed Consolidated Balance Sheet Classification |  | September 28, 2024 |  | December 30, 2023 |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 1,792 |  |  | $ | 3,712 |  |  |  |
|  | Other long-term assets |  | $ | 713 |  |  | $ | 2,140 |  |  |  |
| Zero cost collar agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 60 |  |  | $ | — |  |  |  |
|  | Accrued liabilities |  | $ | 4,307 |  |  | $ | — |  |  |  |
|  | Other long-term liabilities |  | $ | 1 |  |  | $ | — |  |  |  |

[0000889331-24-000191:notes:122]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Net Income for the three and nine months ended September 28, 2024 and September 30, 2023 were as follows:

[0000889331-24-000191:notes:123]
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | Classification of (Gains) Losses Recognized in the Condensed Consolidated Statements of Net Income |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (1,282) |  |  | $ | (1,252) |  |  | $ | (3,850) |  |  | $ | (3,246) |  |
| Zero cost collar agreement |  | Cost of sales |  | $ | 409 |  |  | $ | — |  |  | $ | 409 |  |  | $ | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  | Foreign exchange loss |  | $ | — |  |  | $ | 4,310 |  |  | $ | — |  |  | $ | 3,226 |  |

[0000889331-24-000191:notes:124]
The pre-tax losses (gains) recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and nine months ended September 28, 2024 and September 30, 2023 was as follows:

[0000889331-24-000191:notes:125]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | 5,857 |  |  | $ | (2,034) |  |  | $ | 3,346 |  |  | $ | (2,817) |  |
| Zero cost collar agreement |  | $ | 4,003 |  |  | $ | — |  |  | $ | 4,003 |  |  | $ | — |  |

[0000889331-24-000191:notes:126]
[same as prior period, unchanged from 0000889331-24-000161:notes:123]

[0000889331-24-000191:notes:127]
[same as prior period, unchanged from 0000889331-24-000161:notes:124]

[0000889331-24-000191:notes:128]
There were no changes during the quarter ended September 28, 2024 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of September 28, 2024 and December 30, 2023, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-24-000191:notes:129]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of September 28, 2024:

[0000889331-24-000191:notes:130]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 552,735 |  |  | $ | — |  |  | $ | — |  |  | $ | 552,735 |  |
| Investments in equity securities |  | 12,888 |  |  | — |  |  | — |  |  | 12,888 |  |
| Mutual funds |  | 23,479 |  |  | — |  |  | — |  |  | 23,479 |  |
| Total |  | $ | 589,102 |  |  | $ | — |  |  | $ | — |  |  | $ | 589,102 |  |

[0000889331-24-000191:notes:131]
[same as prior period, unchanged from 0000889331-24-000161:notes:128]

[0000889331-24-000191:notes:132]
[same as prior period, unchanged from 0000889331-24-000161:notes:129]

[0000889331-24-000191:notes:133]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at September 28, 2024 and December 30, 2023, as the rates on these borrowings are variable in nature.

[0000889331-24-000191:notes:134]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of September 28, 2024 and December 30, 2023 were as follows:

[0000889331-24-000191:notes:135]
|  |  | September 28, 2024 |  | December 30, 2023 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 |  | $ | 106,106 |  |  | $ | 99,141 |  |  | $ | 105,246 |  |  | $ | 96,532 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 97,967 |  |  | 100,000 |  |  | 96,127 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 49,735 |  |  | 50,000 |  |  | 49,070 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 118,596 |  |  | 125,000 |  |  | 115,687 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 95,229 |  |  | 100,000 |  |  | 93,228 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-24-000191:notes:136]
[same as prior period, unchanged from 0000889331-24-000161:notes:133]

[0000889331-24-000191:notes:137]
[same as prior period, unchanged from 0000889331-24-000161:notes:134]

[0000889331-24-000191:notes:138]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and nine months ended September 28, 2024 and September 30, 2023 were as follows:

[0000889331-24-000191:notes:139]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (in thousands) |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 753 |  |  | $ | 700 |  |  | $ | 2,318 |  |  | $ | 2,087 |  |
| Interest cost |  | 961 |  |  | 961 |  |  | 2,931 |  |  | 2,850 |  |
| Expected return on plan assets |  | (527) |  |  | (470) |  |  | (1,555) |  |  | (1,409) |  |
| Amortization of prior service and net actuarial loss |  | 47 |  |  | 12 |  |  | 139 |  |  | 34 |  |
| Net periodic benefit cost |  | $ | 1,234 |  |  | $ | 1,203 |  |  | $ | 3,833 |  |  | $ | 3,562 |  |

[0000889331-24-000191:notes:140]
[same as prior period, unchanged from 0000889331-24-000161:notes:137]

[0000889331-24-000191:notes:141]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $23 million, representing approximately 31% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-24-000191:notes:142]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.6 million and $0.4 million for the three months ended September 28, 2024 and September 30, 2023, respectively, and $2.0 million and $1.1 million for the nine months ended September 28, 2024 and September 30, 2023, respectively, in Cost of sales and Other income, net within the Condensed Consolidated Statements of Net Income. The pre-tax (gains) losses amount recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.3 million and nominal for the three months ended September 28, 2024 and September 30, 2023, respectively, and $0.9 million and $(0.1) million for the nine months ended September 28, 2024 and September 30, 2023, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-24-000191:notes:143]
[same as prior period, unchanged from 0000889331-24-000161:notes:139]

[0000889331-24-000191:notes:144]
| (in thousands) |  | Three Months EndedSeptember 28, 2024 |  | Three Months EndedSeptember 30, 2023 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 205 |  |  | $ | (14) |  |  | $ | 191 |  |  | $ | (3) |  |  | $ | — |  |  | $ | (3) |  |
| Cash flow hedges |  | (9,860) |  |  | 1,563 |  |  | (8,297) |  |  | 2,034 |  |  | (488) |  |  | 1,546 |  |
| Foreign currency translation adjustments (a) |  | 66,331 |  |  | (1,832) |  |  | 64,499 |  |  | (4,301) |  |  | 624 |  |  | (3,677) |  |
| Total change in other comprehensive income (loss) |  | $ | 56,676 |  |  | $ | (283) |  |  | $ | 56,393 |  |  | $ | (2,270) |  |  | $ | 136 |  |  | $ | (2,134) |  |
| (in thousands) |  | Nine Months EndedSeptember 28, 2024 |  | Nine Months EndedSeptember 30, 2023 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 901 |  |  | $ | (40) |  |  | $ | 861 |  |  | $ | (125) |  |  | $ | (31) |  |  | $ | (156) |  |
| Cash flow hedges |  | (7,349) |  |  | 960 |  |  | (6,389) |  |  | 2,817 |  |  | (676) |  |  | 2,141 |  |
| Foreign currency translation adjustments (a) |  | 11,619 |  |  | (1,056) |  |  | 10,563 |  |  | (6,098) |  |  | 351 |  |  | (5,747) |  |
| Total change in other comprehensive income (loss) |  | $ | 5,171 |  |  | $ | (136) |  |  | $ | 5,035 |  |  | $ | (3,406) |  |  | $ | (356) |  |  | $ | (3,762) |  |

[0000889331-24-000191:notes:145]
[same as prior period, unchanged from 0000889331-24-000161:notes:141]

[0000889331-24-000191:notes:146]
The following tables set forth the changes in accumulated other comprehensive income (loss) by component for the nine months ended September 28, 2024 and September 30, 2023:

[0000889331-24-000191:notes:147]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedges |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at December 30, 2023 |  | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| Activity in the period |  | 861 |  |  | (6,389) |  |  | 10,563 |  |  | 5,035 |  |
| Balance at September 28, 2024 |  | $ | (6,752) |  |  | $ | (1,941) |  |  | $ | (42,089) |  |  | $ | (50,782) |  |

[0000889331-24-000191:notes:148]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedges |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at December 31, 2022 |  | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| Activity in the period |  | (156) |  |  | 2,141 |  |  | (5,747) |  |  | (3,762) |  |
| Balance at September 30, 2023 |  | $ | (2,349) |  |  | $ | 8,737 |  |  | $ | (105,914) |  |  | $ | (99,526) |  |

[0000889331-24-000191:notes:149]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for the three and nine months ended September 28, 2024 and September 30, 2023 were as follows:

[0000889331-24-000191:notes:150]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Pension and postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss (gain) |  | $ | 323 |  |  | $ | (11) |  |  | $ | 1,026 |  |  | $ | (33) |  |

[0000889331-24-000191:notes:151]
[same as prior period, unchanged from 0000889331-24-000161:notes:147]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-24-000191:notes:152]
Income Taxes
The effective tax rate for the three and nine months ended September 28, 2024 was 25.3% and 21.9%, respectively, compared to the effective tax rate for the three and nine months ended September 30, 2023 of 23.3% and 19.7%, respectively. The effective tax rates for 2024 are higher than the effective tax rates for the comparable 2023 periods primarily due to decreases in the income earned in lower tax jurisdictions in 2024 as compared to 2023. 
The effective tax rates for the three months ended September 28, 2024 and September 30, 2023 are higher than the statutory tax rate primarily due to the impact of foreign exchange losses with no related tax benefit. Additionally, for the 2024 period, the effective tax rate was also higher due to the proportion of pre-tax income that is earned in higher tax jurisdictions. The effective tax rate for the nine months ended September 28, 2024 is higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions, partially offset by previously unrecognized tax benefits recognized in the first quarter due to the lapse in the statute of limitations. The effective tax rate for the nine months ended September 30, 2023 is lower than the statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-24-000191:notes:153]
[same as prior period, unchanged from 0000889331-24-000161:notes:149]

[0000889331-24-000191:notes:154]
[same as prior period, unchanged from 0000889331-24-000161:notes:150]

[0000889331-24-000191:notes:155]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share amounts) |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 58,058 |  |  | $ | 57,788 |  |  | $ | 151,976 |  |  | $ | 216,604 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,796 |  |  | 24,893 |  |  | 24,822 |  |  | 24,838 |  |
| Effect of dilutive securities |  | 229 |  |  | 250 |  |  | 218 |  |  | 262 |  |
| Diluted |  | 25,025 |  |  | 25,143 |  |  | 25,040 |  |  | 25,100 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.34 |  |  | $ | 2.32 |  |  | $ | 6.12 |  |  | $ | 8.72 |  |
| Diluted earnings per share |  | $ | 2.32 |  |  | $ | 2.30 |  |  | $ | 6.07 |  |  | $ | 8.63 |  |

[0000889331-24-000191:notes:156]
Potential shares of common stock relating to stock options and restricted share units are excluded from the earnings per share calculation because their effect would be anti-dilutive were 124,197 and 80,828 for the three months ended September 28, 2024 and September 30, 2023, respectively, and 136,635 and 106,156 for the nine months ended September 28, 2024 and September 30, 2023, respectively.

[0000889331-24-000191:notes:157]
[same as prior period, unchanged from 0000889331-24-000161:notes:153]

[0000889331-24-000191:notes:158]
The Company’s Board of Directors authorized the repurchase of up to $300.0 million in the aggregate of shares of the Company’s common stock under a program for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program. The Company did not repurchase shares of its common stock for the three months ended September 28, 2024. During the nine months ended September 28, 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. The Company did not repurchase shares of its common stock for the three and nine months ended September 30, 2023.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-24-000191:notes:159]
[same as prior period, unchanged from 0000889331-24-000161:notes:155]

[0000889331-24-000191:notes:160]
The Company and its subsidiaries design, manufacture and sell component, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company reports its operations by the following segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-24-000191:notes:161]
[same as prior period, unchanged from 0000889331-24-000161:notes:158]

[0000889331-24-000191:notes:162]
[same as prior period, unchanged from 0000889331-24-000161:notes:159]

[0000889331-24-000191:notes:163]
[same as prior period, unchanged from 0000889331-24-000161:notes:160]

[0000889331-24-000191:notes:164]
[same as prior period, unchanged from 0000889331-24-000161:notes:161]

[0000889331-24-000191:notes:165]
[same as prior period, unchanged from 0000889331-24-000161:notes:162]

[0000889331-24-000191:notes:166]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 304,188 |  |  | $ | 343,933 |  |  | $ | 900,932 |  |  | $ | 1,052,673 |  |
| Transportation |  | 171,381 |  |  | 177,019 |  |  | 510,711 |  |  | 515,708 |  |
| Industrial |  | 91,821 |  |  | 86,119 |  |  | 249,620 |  |  | 260,469 |  |
| Total net sales |  | $ | 567,390 |  |  | $ | 607,071 |  |  | $ | 1,661,263 |  |  | $ | 1,828,850 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 20,045 |  |  | $ | 19,623 |  |  | $ | 59,656 |  |  | 59,219 |  |
| Transportation |  | 9,084 |  |  | 10,193 |  |  | 26,827 |  |  | 32,547 |  |
| Industrial |  | 4,041 |  |  | 4,093 |  |  | 11,960 |  |  | 11,517 |  |
| Total depreciation and amortization |  | $ | 33,170 |  |  | $ | 33,909 |  |  | $ | 98,443 |  |  | $ | 103,283 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 48,891 |  |  | $ | 77,022 |  |  | $ | 132,859 |  |  | $ | 247,028 |  |
| Transportation |  | 23,485 |  |  | 9,694 |  |  | 54,925 |  |  | 26,015 |  |
| Industrial |  | 17,711 |  |  | 13,201 |  |  | 32,054 |  |  | 45,450 |  |
| Other (a) |  | (2,266) |  |  | (6,272) |  |  | (11,559) |  |  | (22,154) |  |
| Total operating income |  | 87,821 |  |  | 93,645 |  |  | 208,279 |  |  | 296,339 |  |
| Interest expense |  | 9,772 |  |  | 10,101 |  |  | 29,358 |  |  | 29,803 |  |
| Foreign exchange loss |  | 9,630 |  |  | 11,776 |  |  | 4,273 |  |  | 8,697 |  |
| Other income, net |  | (9,297) |  |  | (3,527) |  |  | (19,916) |  |  | (11,810) |  |
| Income before income taxes |  | $ | 77,716 |  |  | $ | 75,295 |  |  | $ | 194,564 |  |  | $ | 269,649 |  |

[0000889331-24-000191:notes:167]
(a) Included in “Other” Operating income for the third quarter of 2024 includes $1.8 million ($9.4 million year-to-date) of restructuring charges primarily related to employee termination cost, and $1.0 million ($2.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. During the third quarter of 2024, the Company recorded a gain of $0.5 million related to the sale of a land use right within the Electronics segment. In addition, the Company recognized a gain of $1.0 million for the sale of two buildings within the Transportation segment during the first half of 2024.

[0000889331-24-000191:notes:168]
Included in “Other” Operating income for the third quarter of 2023 was $3.7 million ($8.5 million year-to-date) of restructuring charges, primarily related to employee termination costs, and $1.8 million ($9.0 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the third quarter of 2023, the Company recognized a $0.8 million impairment charge substantially related to certain patents in a business within the Industrial segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000191:notes:169]
[same as prior period, unchanged from 0000889331-24-000161:notes:166]

[0000889331-24-000191:notes:170]
|  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) |  | September 28, 2024 |  | September 30, 2023 |  | September 28, 2024 |  | September 30, 2023 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 211,940 |  |  | $ | 217,904 |  |  | $ | 604,198 |  |  | $ | 635,892 |  |
| China |  | 133,051 |  |  | 138,393 |  |  | 379,730 |  |  | 415,430 |  |
| Other countries (a) |  | 222,399 |  |  | 250,774 |  |  | 677,335 |  |  | 777,528 |  |
| Total net sales |  | $ | 567,390 |  |  | $ | 607,071 |  |  | $ | 1,661,263 |  |  | $ | 1,828,850 |  |

[0000889331-24-000191:notes:171]
[same as prior period, unchanged from 0000889331-24-000161:notes:168]

[0000889331-24-000191:notes:172]
| (in thousands) |  | September 28, 2024 |  | December 30, 2023 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 67,491 |  |  | $ | 73,126 |  |
| China |  | 137,813 |  |  | 139,736 |  |
| Mexico |  | 93,057 |  |  | 102,218 |  |
| Germany |  | 56,578 |  |  | 47,217 |  |
| Philippines |  | 68,620 |  |  | 73,217 |  |
| Other countries |  | 58,033 |  |  | 57,639 |  |
| Total long-lived assets |  | $ | 481,592 |  |  | $ | 493,153 |  |

[0000889331-24-000191:notes:173]
[same as prior period, unchanged from 0000889331-24-000161:notes:170]

[0000889331-24-000191:notes:174]
|  |  | Nine Months Ended |
| (in thousands) |  | September 28, 2024 |  | September 30, 2023 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 9,591 |  |  | $ | 7,407 |  |
| China |  | 10,681 |  |  | 22,558 |  |
| Mexico |  | 8,875 |  |  | 11,339 |  |
| Germany |  | 12,160 |  |  | 6,534 |  |
| Philippines |  | 3,025 |  |  | 5,245 |  |
| Other countries |  | 5,759 |  |  | 8,138 |  |
| Total additions to long-lived assets |  | $ | 50,091 |  |  | $ | 61,221 |  |

[0000889331-24-000191:notes:175]
[same as prior period, unchanged from 0000889331-24-000161:notes:172]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000889331-24-000191:notes:176]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0000889331-24-000191:notes:177]
As of September 28, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-24-000191:notes:178]
Product Warranty Liabilities

[0000889331-24-000191:notes:179]
The company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0000889331-24-000191:notes:180]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0000889331-24-000191:notes:181]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-24-000191:notes:182]
Environmental Remediation Liabilities

[0000889331-24-000191:notes:183]
The company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0000889331-24-000191:notes:184]
Legal Proceedings

[0000889331-24-000191:notes:185]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

[0000889331-24-000191:notes:186]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss and therefore the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.

[0000889331-24-000191:notes:187]
Pending Litigation and Claims

[0000889331-24-000191:notes:188]
There are no material pending litigation or claims outstanding as of September 28, 2024.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-24-000191:notes:189]
Related Party Transactions

[0000889331-24-000191:notes:190]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-24-000191:notes:191]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-24-000191:notes:192]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-24-000191:notes:193]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's executive officers serves on the Board of Directors of ATEC.

[0000889331-24-000191:notes:194]
|  |  | Three Months Ended September 28, 2024 |  | Three Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.2 |  | 0.6 |  |  | 1.2 |  | 0.1 |  | 2.0 |  |
|  |  | Nine Months Ended September 28, 2024 |  | Nine Months Ended September 30, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 1.2 |  | $ | — |  | $ | — |  |  | $ | 1.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 3.0 |  | 0.6 |  | 3.5 |  |  | 3.3 |  | 0.3 |  | 7.6 |  |
|  |  | September 28, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.5 |  | $ | — |  | $ | 0.1 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000889331-24-000191:notes:195]
The adoption or termination of contracts, instructions or written plans for the purchase or sale of our securities by our Section 16 officers and directors for the three months ended September 28, 2024, each of which is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act (“Rule 10b5-1 Plan”), were as follows:

[0000889331-24-000191:notes:196]
| Name |  | Title |  | Action |  | Date Adopted |  | Expiration Date |  | Aggregate # of securities to be Sold |
| Matthew J. Cole (1) |  | Senior Vice President, eMobility and Corporate Strategy |  | Adoption |  | 9/12/2024 |  | 3/31/2025 |  | 1,500 |

[0000889331-24-000191:notes:197]
(1) On September 12, 2024, Matthew J. Cole, Senior Vice President, eMobility and Corporate Strategy, entered into a pre-arranged stock trading plan pursuant to Rule 10b5-1. Mr. Cole’s plan provided for the potential exercise of vested stock options and the associated sale of up to 1,500 shares of the Company’s common stock. The stock options covered by the plan will otherwise expire on April 27, 2025 if they have not been exercised. The plan expires on March 31, 2025, or upon the earlier completion of all authorized transactions under the plan.
