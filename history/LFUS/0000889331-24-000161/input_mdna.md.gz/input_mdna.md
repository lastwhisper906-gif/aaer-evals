# LFUS MD&A — 0000889331-24-000161


## mdna

[0000889331-24-000161:mdna:1]
[same as prior period, unchanged from 0000889331-24-000129:mdna:1]

[0000889331-24-000161:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-24-000161:mdna:3]
[same as prior period, unchanged from 0000889331-24-000129:mdna:3]

[0000889331-24-000161:mdna:4]
[same as prior period, unchanged from 0000889331-24-000129:mdna:4]

[0000889331-24-000161:mdna:5]
[same as prior period, unchanged from 0000889331-24-000129:mdna:5]

[0000889331-24-000161:mdna:6]
[same as prior period, unchanged from 0000889331-24-000129:mdna:6]

[0000889331-24-000161:mdna:7]
[same as prior period, unchanged from 0000889331-24-000129:mdna:7]

[0000889331-24-000161:mdna:8]
[same as prior period, unchanged from 0000889331-24-000129:mdna:8]

[0000889331-24-000161:mdna:9]
For the second quarter of 2024, the Company recognized net sales of $558.5 million, a decrease of $53.5 million, or 8.7% as compared to $612.0 million in the second quarter of 2023 including $5.1 million or 0.8% of unfavorable changes in foreign exchange rates. The decrease in net sales was primarily due to lower volume in the Electronics segment. The Company recognized net income of $45.5 million, or $1.82 per diluted share, in the second quarter of 2024 compared to $70.1 million, or $2.79 per diluted share, in the second quarter of 2023. The decrease in net income was primarily due to lower operating income of $33.7 million in the Electronics segment driven by a reduction in volume.

[0000889331-24-000161:mdna:10]
Net cash provided by operating activities was $126.6 million for the six months ended June 29, 2024 compared to $151.6 million for the six months ended July 1, 2023. The decrease in net cash provided by operating activities was primarily due to lower cash earnings, partially offset by reductions in changes in working capital compared to prior year.

[0000889331-24-000161:mdna:11]
During the three and six months ended June 29, 2024, the Company repurchased 109,031 and 179,311 shares of its common stock totaling $24.7 million and $40.9 million, respectively.

[0000889331-24-000161:mdna:12]
[same as prior period, unchanged from 0000889331-24-000129:mdna:11]

[0000889331-24-000161:mdna:13]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies" that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-24-000161:mdna:14]
[same as prior period, unchanged from 0000889331-24-000129:mdna:13]

[0000889331-24-000161:mdna:15]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The second quarter of 2024 includes $5.3 million ($7.6 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2024, the Company recognized $0.8 million ($1.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.7 million ($1.0 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0000889331-24-000161:mdna:16]
The second quarter of 2023 includes $3.9 million ($7.2 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $2.9 million ($4.8 million year-to-date) of restructuring charges primarily related to employee termination costs. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000161:mdna:17]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Net sales |  | $ | 558,489 |  |  | $ | 611,997 |  |  | $ | (53,508) |  |  | (8.7) | % |  | $ | 1,093,874 |  |  | $ | 1,221,779 |  |  | $ | (127,905) |  |  | (10.5) | % |
| Cost of sales |  | 351,485 |  |  | 377,165 |  |  | (25,680) |  |  | (6.8) | % |  | 699,062 |  |  | 741,990 |  |  | (42,928) |  |  | (5.8) | % |
| Gross profit |  | 207,004 |  |  | 234,832 |  |  | (27,828) |  |  | (11.9) | % |  | 394,812 |  |  | 479,789 |  |  | (84,977) |  |  | (17.7) | % |
| Operating expenses |  | 141,498 |  |  | 142,779 |  |  | (1,281) |  |  | (0.9) | % |  | 274,354 |  |  | 277,095 |  |  | (2,741) |  |  | (1.0) | % |
| Operating income |  | 65,506 |  |  | 92,053 |  |  | (26,547) |  |  | (28.8) | % |  | 120,458 |  |  | 202,694 |  |  | (82,236) |  |  | (40.6) | % |
| Income before income taxes |  | 61,144 |  |  | 85,451 |  |  | (24,307) |  |  | (28.4) | % |  | 116,848 |  |  | 194,354 |  |  | (77,506) |  |  | (39.9) | % |
| Income taxes |  | 15,678 |  |  | 15,380 |  |  | 298 |  |  | 1.9 | % |  | 22,930 |  |  | 35,538 |  |  | (12,608) |  |  | (35.5) | % |
| Net income |  | $ | 45,466 |  |  | $ | 70,071 |  |  | $ | (24,605) |  |  | (35.1) | % |  | $ | 93,918 |  |  | $ | 158,816 |  |  | $ | (64,898) |  |  | (40.9) | % |

[0000889331-24-000161:mdna:18]
[same as prior period, unchanged from 0000889331-24-000129:mdna:17]

[0000889331-24-000161:mdna:19]
Net sales decreased $53.5 million, or 8.7%, for the second quarter of 2024 compared to the second quarter of 2023 including $5.1 million or 0.8% of unfavorable changes in foreign exchange rates. The decrease in net sales was primarily due to lower volume of $44.5 million and $5.9 million, in the Electronics and Industrial segments, respectively.

[0000889331-24-000161:mdna:20]
Net sales decreased $127.9 million, or 10.5%, for the first six months of 2024 compared to the first six months of 2023, including $6.9 million or 0.6% of unfavorable changes in foreign exchange rates. The sales decrease was primarily due to lower volume of $112.0 million and $16.6 million in the Electronics and Industrial segments, respectively, that more than offset higher volume of $11.7 million in the passenger car products business within the Transportation segment.

[0000889331-24-000161:mdna:21]
[same as prior period, unchanged from 0000889331-24-000129:mdna:19]

[0000889331-24-000161:mdna:22]
Cost of sales was $351.5 million, or 62.9% of net sales, in the second quarter of 2024, compared to $377.2 million, or 61.6% of net sales, in the second quarter of 2023. As a percent of net sales, cost of sales increased 1.3% driven by lower volume in the Electronics and Industrial segments, partially offset by improved margin from all businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000161:mdna:23]
Cost of sales was $699.1 million, or 63.9% of net sales, in the first six months of 2024, compared to $742.0 million, or 60.7% of net sales, in the first six months of 2023. As a percent of net sales, cost of sales increased 3.2% driven by lower volume in the Electronics and Industrial segments, partially offset by improved margin from the commercial vehicle and auto sensor businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000161:mdna:24]
[same as prior period, unchanged from 0000889331-24-000129:mdna:21]

[0000889331-24-000161:mdna:25]
Gross profit was $207.0 million, or 37.1% of net sales, in the second quarter of 2024 compared to $234.8 million, or 38.4% of net sales, for the second quarter of 2023. The $27.8 million decrease in gross profit was primarily due to lower volume in the Electronics and Industrial segments, partially offset by improved margin from all businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000161:mdna:26]
Gross profit was $394.8 million, or 36.1% of net sales, in the first six months of 2024 compared to $479.8 million, or 39.3% of net sales, for the first six months of 2023. The $85.0 million decrease in gross profit was primarily due to lower volume in the Electronics and Industrial segments, partially offset by improved margin from the commercial vehicle and auto sensor businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives.

[0000889331-24-000161:mdna:27]
[same as prior period, unchanged from 0000889331-24-000129:mdna:23]

[0000889331-24-000161:mdna:28]
Operating expenses were $141.5 million, or 25.3% of net sales, for the second quarter of 2024 compared to $142.8 million, or 23.3% of net sales, for the second quarter of 2023. The decrease in operating expenses of $1.3 million was primarily due to lower restructuring, impairment, and other charges of $1.6 million caused by a $3.9 million impairment charge recognized during the second quarter 2023 related to the land and building of a property within the Transportation segment and lower legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by

[0000889331-24-000161:mdna:29]
higher employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions within the semiconductor business in the Electronics segment and higher research and development expenses.

[0000889331-24-000161:mdna:30]
Operating expenses were $274.4 million, or 25.1% of net sales, for the first six months of 2024 compared to $277.1 million, or 22.7% of net sales, for the first six months of 2023. The decrease in operating expenses of $2.7 million was primarily due to lower selling, general, and administrative expenses of $3.4 million as a result of lower legal and professional fees and other integration expenses related to completed and contemplated acquisitions and lower amortization expense of $2.2 million, partially offset by higher research and development expenses of $3.0 million.

[0000889331-24-000161:mdna:31]
[same as prior period, unchanged from 0000889331-24-000129:mdna:25]

[0000889331-24-000161:mdna:32]
Operating income was $65.5 million, representing a decrease of $26.5 million, or 28.8%, for the second quarter of 2024 compared to $92.1 million for the second quarter of 2023. The decrease in operating income was due to lower gross profit from the Electronics segment, partially offset by higher gross profit from the Transportation segment. Operating margins decreased from 15.0% in the second quarter of 2023 to 11.7% in the second quarter of 2024 driven by lower volume in the Electronics segment.

[0000889331-24-000161:mdna:33]
Operating income was $120.5 million, representing a decrease of $82.2 million, or 40.6%, for the first six months of 2024 compared to $202.7 million for the first six months of 2023. The decrease in operating income was due to lower gross profit from the Electronics and Industrial segments, partially offset by higher gross profit from the Transportation segment. Operating margins decreased from 16.6% in the first six months quarter of 2023 to 11.0% in the first six months of 2024 driven by lower volume in the Electronics segment.

[0000889331-24-000161:mdna:34]
[same as prior period, unchanged from 0000889331-24-000129:mdna:27]

[0000889331-24-000161:mdna:35]
Income before income taxes was $61.1 million, or 10.9% of net sales, for the second quarter of 2024 compared to $85.5 million, or 14.0% of net sales, for the second quarter of 2023. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by higher interest income of $3.1 million from short-term investment in cash equivalents, partially offset by lower foreign exchange gains of $1.1 million in the second quarter of 2024 compared to the second quarter of 2023.

[0000889331-24-000161:mdna:36]
Income before income taxes was $116.8 million, or 10.7% of net sales, for the first six months of 2024 compared to $194.4 million, or 15.9% of net sales, for the first six months of 2023. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by higher interest income of $5.8 million from short-term investment in cash equivalents and higher foreign exchange gains of $2.3 million in the first six months of 2024 compared to the first six months of 2023, partially offset by unrealized losses of $1.1 million during the first six months of 2024 compared to unrealized gains of $0.7 million during the first six months of 2023 related to the Company's equity investment.

[0000889331-24-000161:mdna:37]
[same as prior period, unchanged from 0000889331-24-000129:mdna:29]

[0000889331-24-000161:mdna:38]
The effective tax rate for the three and six months ended June 29, 2024 was 25.6% and 19.6%, compared to the effective tax rate for the three and six months ended July 1, 2023 of 18.0% and 18.3%. The effective tax rates for 2024 are higher than the effective tax rates for the comparable 2023 periods primarily due to decreases in the income earned in lower tax jurisdictions in 2024 as compared to 2023.

[0000889331-24-000161:mdna:39]
The effective tax rate for the three months ended June 29, 2024 is higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions. The effective tax rate for the six months ended June 29, 2024 is lower than the statutory tax rate primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter. The effective tax rates for 2023 are lower than the statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-24-000161:mdna:40]
[same as prior period, unchanged from 0000889331-24-000129:mdna:31]

[0000889331-24-000161:mdna:41]
[same as prior period, unchanged from 0000889331-24-000129:mdna:32]

[0000889331-24-000161:mdna:42]
[same as prior period, unchanged from 0000889331-24-000129:mdna:33]

[0000889331-24-000161:mdna:43]
| Net Sales |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Electronics |  | $ | 305,639 |  |  | $ | 350,147 |  |  | $ | (44,508) |  |  | (12.7) | % |  | $ | 596,744 |  |  | $ | 708,740 |  |  | $ | (111,996) |  |  | (15.8) | % |
| Transportation |  | 168,964 |  |  | 172,048 |  |  | (3,084) |  |  | (1.8) | % |  | 339,331 |  |  | 338,689 |  |  | 642 |  |  | 0.2 | % |
| Industrial |  | 83,886 |  |  | 89,802 |  |  | (5,916) |  |  | (6.6) | % |  | 157,799 |  |  | 174,350 |  |  | (16,551) |  |  | (9.5) | % |
| Total |  | $ | 558,489 |  |  | $ | 611,997 |  |  | $ | (53,508) |  |  | (8.7) | % |  | $ | 1,093,874 |  |  | $ | 1,221,779 |  |  | $ | (127,905) |  |  | (10.5) | % |

[0000889331-24-000161:mdna:44]
| Operating Income |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Electronics |  | $ | 46,165 |  |  | $ | 79,844 |  |  | $ | (33,679) |  |  | (42.2) | % |  | $ | 83,968 |  |  | $ | 170,006 |  |  | $ | (86,038) |  |  | (50.6) | % |
| Transportation |  | 15,234 |  |  | 7,789 |  |  | 7,445 |  |  | 95.6 | % |  | 31,440 |  |  | 16,321 |  |  | 15,119 |  |  | 92.6 | % |
| Industrial |  | 9,547 |  |  | 15,108 |  |  | (5,561) |  |  | (36.8) | % |  | 14,343 |  |  | 32,249 |  |  | (17,906) |  |  | (55.5) | % |
| Other (a) |  | (5,440) |  |  | (10,688) |  |  | 5,248 |  |  |  |  | (9,293) |  |  | (15,882) |  |  | 6,589 |  |  |  |
| Total |  | $ | 65,506 |  |  | $ | 92,053 |  |  | $ | (26,547) |  |  | (28.8) | % |  | $ | 120,458 |  |  | $ | 202,694 |  |  | $ | (82,236) |  |  | (40.6) | % |

[0000889331-24-000161:mdna:45]
(a) Included in “Other” Operating income for the second quarter of 2024 includes $5.3 million ($7.6 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2024, the Company recognized $0.8 million ($1.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.7 million ($1.0 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0000889331-24-000161:mdna:46]
Included in “Other” Operating income for the second quarter of 2023 includes $3.9 million ($7.2 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $2.9 million ($4.8 million year-to-date) of restructuring charges, primarily related to employee termination costs. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000161:mdna:47]
[same as prior period, unchanged from 0000889331-24-000129:mdna:38]

[0000889331-24-000161:mdna:48]
[same as prior period, unchanged from 0000889331-24-000129:mdna:39]

[0000889331-24-000161:mdna:49]
Net sales decreased $44.5 million, or 12.7%, in the second quarter of 2024 compared to the second quarter of 2023 and included unfavorable changes in foreign exchange rates of $2.6 million. The sales decrease was mainly due to lower volume from the semiconductor business driven by reduced demand across industrial markets and inventory rebalancing at certain distributors.

[0000889331-24-000161:mdna:50]
Net sales decreased $112.0 million, or 15.8%, in the first six months of 2024 compared to the first six months of 2023 and included unfavorable changes in foreign exchange rates of $3.5 million. The sales decrease was mainly due to lower volume from the semiconductor and electronics products businesses driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, as well as industrial markets.

[0000889331-24-000161:mdna:51]
[same as prior period, unchanged from 0000889331-24-000129:mdna:41]

[0000889331-24-000161:mdna:52]
Operating income was $46.2 million, representing a decrease of $33.7 million, or 42.2%, for the second quarter of 2024 compared to $79.8 million for the second quarter of 2023. The decrease in operating income was primarily from semiconductor business due to lower volume leverage. Operating margins decreased from 22.8% in the second quarter of 2023 to 15.1% in the second quarter of 2024 primarily due to the lower volume.

[0000889331-24-000161:mdna:53]
Operating income was $84.0 million, representing a decrease of $86.0 million, or 50.6%, for the first six months of 2024 compared to $170.0 million for the first six months of 2023. The decrease in operating income was primarily due to lower volume leverage and unfavorable mix that were partially offset by cost control initiatives. Operating margins decreased from 24.0% in the first six months of 2023 to 14.1% in the first six months of 2024 primarily due to the lower volume.

[0000889331-24-000161:mdna:54]
[same as prior period, unchanged from 0000889331-24-000129:mdna:43]

[0000889331-24-000161:mdna:55]
[same as prior period, unchanged from 0000889331-24-000129:mdna:44]

[0000889331-24-000161:mdna:56]
Net sales decreased $3.1 million, or 1.8%, in the second quarter of 2024 compared to the second quarter of 2023 and included unfavorable changes in foreign exchange rates of $2.0 million. The sales decrease was mainly from sales declines of $3.7 million and $2.6 million from the automotive sensors and commercial vehicle businesses, respectively, driven by reduced demand largely due to inventory rebalancing at certain distributors and customers as well as the strategic exit of certain lower margin products, partially offset by net sales increases of $3.2 million in the passenger car products business driven by vehicle content growth and global passenger vehicle production growth.

[0000889331-24-000161:mdna:57]
Net sales increased $0.6 million, or 0.2%, in the first six months of 2024 compared to the first six months of 2023 and included unfavorable changes in foreign exchange rates of $2.8 million. The sales increase was mainly from the passenger car products business of $11.7 million driven by the ongoing electronification and electrification of vehicles and global passenger vehicle production growth, partially offset by sales declines of $7.2 million and $3.9 million from the commercial vehicle and automotive sensors businesses driven by reduced demand largely due to inventory rebalancing at certain distributors and customers as well as the strategic exit of certain lower margin products.

[0000889331-24-000161:mdna:58]
[same as prior period, unchanged from 0000889331-24-000129:mdna:46]

[0000889331-24-000161:mdna:59]
Operating income was $15.2 million, representing an increase of $7.4 million, or 95.6%, for the second quarter of 2024 compared to $7.8 million for the second quarter of 2023. The increase in operating income was primarily due to favorable price and cost reduction initiatives in the commercial vehicle business. Operating margins increased from 4.5% in the second quarter of 2023 to 9.0% in the second quarter of 2024 primarily driven by favorable price and products mix and cost reduction initiatives from the commercial vehicle business.

[0000889331-24-000161:mdna:60]
Operating income was $31.4 million, representing an increase of $15.1 million, or 92.6%, for the first six months of 2024 compared to $16.3 million for the first six months of 2023. The increase in operating income was primarily due to favorable price and cost reduction initiatives from the commercial vehicle business. Operating margins increased from 4.8% in the first six months of 2023 to 9.3% in the first six months of 2024 primarily driven by favorable price and products mix and cost reduction initiatives from the commercial vehicle business.

[0000889331-24-000161:mdna:61]
[same as prior period, unchanged from 0000889331-24-000129:mdna:48]

[0000889331-24-000161:mdna:62]
[same as prior period, unchanged from 0000889331-24-000129:mdna:49]

[0000889331-24-000161:mdna:63]
Net sales decreased by $5.9 million, or 6.6%, in the second quarter of 2024 compared to the second quarter of 2023, which included unfavorable changes in foreign exchange rates of $0.5 million. The sales decrease was due to lower volume from industrial control products driven by slower end market demand.

[0000889331-24-000161:mdna:64]
Net sales decreased by $16.6 million, or 9.5%, in the first six months of 2024 compared to the first six months of 2023, which included unfavorable changes in foreign exchange rates of $0.6 million. The sales decrease was due to lower volume across industrial control and industrial circuit protection products driven by slower end market demand.

[0000889331-24-000161:mdna:65]
[same as prior period, unchanged from 0000889331-24-000129:mdna:51]

[0000889331-24-000161:mdna:66]
Operating income was $9.5 million, representing a decrease of $5.6 million, or 36.8%, for the second quarter of 2024 compared to $15.1 million for the second quarter of 2023. The decrease in operating income was driven by lower volume due to reduced industrial end market demand across industrial control products and unfavorable product mix. Operating margins decreased from 16.8% in the second quarter of 2023 to 11.4% in the second quarter of 2024 due to lower volume and cost inflation partially offset by favorable price.

[0000889331-24-000161:mdna:67]
Operating income was $14.3 million, representing a decrease of $17.9 million, or 55.5%, for the first six months of 2024 compared to $32.2 million for the first six months of 2023. The decrease in operating income was driven by lower volume due to reduced industrial end market demand across industrial circuit protection and industrial control products and unfavorable product mix. Operating margins decreased from 18.5% in the first six months of 2023 to 9.1% in the first six months of 2024 due to lower demand and cost inflation partially offset by favorable price.

[0000889331-24-000161:mdna:68]
[same as prior period, unchanged from 0000889331-24-000129:mdna:53]

[0000889331-24-000161:mdna:69]
[same as prior period, unchanged from 0000889331-24-000129:mdna:54]

[0000889331-24-000161:mdna:70]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2024 |  | 2023 |  | Change |  | %Change |  | 2024 |  | 2023 |  | Change |  | %Change |
| Americas |  | $ | 228,330 |  |  | $ | 227,896 |  |  | $ | 434 |  |  | 0.2 | % |  | $ | 443,114 |  |  | $ | 461,750 |  |  | $ | (18,636) |  |  | (4.0) | % |
| Asia-Pacific |  | 214,100 |  |  | 229,691 |  |  | (15,591) |  |  | (6.8) | % |  | 407,789 |  |  | 457,703 |  |  | (49,914) |  |  | (10.9) | % |
| Europe |  | 116,059 |  |  | 154,410 |  |  | (38,351) |  |  | (24.8) | % |  | 242,971 |  |  | 302,326 |  |  | (59,355) |  |  | (19.6) | % |
| Total |  | $ | 558,489 |  |  | $ | 611,997 |  |  | $ | (53,508) |  |  | (8.7) | % |  | $ | 1,093,874 |  |  | $ | 1,221,779 |  |  | $ | (127,905) |  |  | (10.5) | % |

[0000889331-24-000161:mdna:71]
[same as prior period, unchanged from 0000889331-24-000129:mdna:56]

[0000889331-24-000161:mdna:72]
Net sales increased $0.4 million, or 0.2%, in the second quarter of 2024 compared to the second quarter of 2023 and included unfavorable changes in foreign exchange rates of $0.2 million. The net sales was essentially flat with higher volume from the commercial vehicle products and passenger car products businesses within the Transportation segment, offset by lower volume from the Electronics and Industrial segments compared to the second quarter of 2023.

[0000889331-24-000161:mdna:73]
Net sales decreased $18.6 million, or 4.0%, in the first six months of 2024 compared to the first six months of 2023 and included unfavorable changes in foreign exchange rates of $0.2 million. The decrease in net sales was primarily due to lower volume from the Electronics and Industrial segments, partially offset by higher volume from the passenger car products business within the Transportation segment compared to the first six months of 2023.

[0000889331-24-000161:mdna:74]
[same as prior period, unchanged from 0000889331-24-000129:mdna:58]

[0000889331-24-000161:mdna:75]
Net sales decreased $15.6 million, or 6.8%, in the second quarter of 2024 compared to the second quarter of 2023 and included unfavorable changes in foreign exchange rates of $3.8 million. The decrease in net sales was primarily due to lower net sales from the Electronics and Industrial segments, partially offset by higher net sales from the passenger car products business within the Transportation segment compared to the second quarter of 2023.

[0000889331-24-000161:mdna:76]
Net sales decreased $49.9 million, or 10.9%, in the first six months of 2024 compared to the first six months of 2023 and included unfavorable changes in foreign exchange rates of $7.6 million. The decrease in net sales was primarily due to lower net sales from the Electronics segment, partially offset by higher net sales from the passenger car products business within the Transportation segment compared to the first six months of 2023.

[0000889331-24-000161:mdna:77]
[same as prior period, unchanged from 0000889331-24-000129:mdna:60]

[0000889331-24-000161:mdna:78]
Net sales decreased $38.4 million, or 24.8%, in the second quarter of 2024 compared to the second quarter of 2023 and included unfavorable changes in foreign exchange rates of $1.0 million. The decrease in net sales was primarily due to lower net sales from the Electronics and Transportation segments compared to the second quarter of 2023.

[0000889331-24-000161:mdna:79]
Net sales decreased $59.4 million, or 19.6%, in the first six months of 2024 compared to the first six months of 2023 and included favorable changes in foreign exchange rates of $0.9 million. The decrease in net sales was primarily due to lower net sales from the Electronics segment and lower net sales from the automotive sensors and commercial vehicle businesses within the Transportation segment compared to the first six months of 2023.

[0000889331-24-000161:mdna:80]
[same as prior period, unchanged from 0000889331-24-000129:mdna:62]

[0000889331-24-000161:mdna:81]
[same as prior period, unchanged from 0000889331-24-000129:mdna:63]

[0000889331-24-000161:mdna:82]
Cash and cash equivalents were $561.7 million as of June 29, 2024, an increase of $6.2 million as compared to December 30, 2023. As of June 29, 2024, $102.1 million of the Company's $561.7 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-24-000161:mdna:83]
Revolving Credit Facility and Term Loan

[0000889331-24-000161:mdna:84]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-24-000161:mdna:85]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-24-000161:mdna:86]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended June 29, 2024, the Company made payments of $1.9 million and $3.8 million, respectively, on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of June 29, 2024.

[0000889331-24-000161:mdna:87]
[same as prior period, unchanged from 0000889331-24-000129:mdna:69]

[0000889331-24-000161:mdna:88]
As of June 29, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.69%, and 4.13% on the hedged portion.

[0000889331-24-000161:mdna:89]
As of June 29, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving credit facility. As of June 29, 2024, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-24-000161:mdna:90]
[same as prior period, unchanged from 0000889331-24-000129:mdna:72]

[0000889331-24-000161:mdna:91]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-24-000161:mdna:92]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”)

[0000889331-24-000161:mdna:93]
were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-24-000161:mdna:94]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-24-000161:mdna:95]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-24-000161:mdna:96]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-24-000161:mdna:97]
Debt Covenants

[0000889331-24-000161:mdna:98]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of June 29, 2024 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2023. As of June 29, 2024, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-24-000161:mdna:99]
[same as prior period, unchanged from 0000889331-24-000129:mdna:80]

[0000889331-24-000161:mdna:100]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the fab is approximately 93 million Euro, of which a 37.2 million Euro down payment (approximately $40.5 million), recorded in Prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. The down payment was paid in the third quarter of 2023 after regulatory approvals, and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-24-000161:mdna:101]
[same as prior period, unchanged from 0000889331-24-000129:mdna:82]

[0000889331-24-000161:mdna:102]
During the second quarter of 2024 the Company paid quarterly dividends of $16.1 million to the shareholders. On July 30, 2024, the Company announced the declaration of a quarterly cash dividend of $0.70 per share, an 8% percent increase from the first quarter, payable on September 5, 2024 to stockholders of record as of August 22, 2024.

[0000889331-24-000161:mdna:103]
[same as prior period, unchanged from 0000889331-24-000129:mdna:84]

[0000889331-24-000161:mdna:104]
|  |  | First Six Months |
| (in thousands) |  | 2024 |  | 2023 |
| Net cash provided by operating activities |  | $ | 126,574 |  |  | $ | 151,633 |  |
| Net cash used in investing activities |  | (26,677) |  |  | (199,020) |  |
| Net cash used in financing activities |  | (79,290) |  |  | (32,686) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (14,434) |  |  | (1,772) |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 6,173 |  |  | (81,845) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 557,123 |  |  | 564,939 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 563,296 |  |  | $ | 483,094 |  |

[0000889331-24-000161:mdna:105]
[same as prior period, unchanged from 0000889331-24-000129:mdna:86]

[0000889331-24-000161:mdna:106]
[same as prior period, unchanged from 0000889331-24-000129:mdna:87]

[0000889331-24-000161:mdna:107]
Net cash provided by operating activities was $126.6 million for the six months ended June 29, 2024 compared to $151.6 million for the six months ended July 1, 2023. The decrease in net cash provided by operating activities was primarily due to lower cash earnings, partially offset by reductions in changes in working capital compared to prior year.

[0000889331-24-000161:mdna:108]
[same as prior period, unchanged from 0000889331-24-000129:mdna:89]

[0000889331-24-000161:mdna:109]
Net cash used in investing activities was $26.7 million for the six months ended June 29, 2024 compared to $199.0 million during the six months ended July 1, 2023. Capital expenditures were $34.7 million, representing a decrease of $6.8 million compared to the six months ended July 1, 2023. During the six months ended June 29, 2024, the Company received proceeds of $8.7 million from the sale of two buildings from the Transportation segment. Net cash paid for the Western Automation acquisition was $158.3 million during the six months ended July 1, 2023.

[0000889331-24-000161:mdna:110]
[same as prior period, unchanged from 0000889331-24-000129:mdna:91]

[0000889331-24-000161:mdna:111]
Net cash used in financing activities was $79.3 million for the six months ended June 29, 2024 compared to $32.7 million during the six months ended July 1, 2023. During the six months ended June 29, 2024 and July 1, 2023, the Company made payments of $3.8 million on the term loan for both periods, respectively. The Company paid dividends of $32.3 million and $29.8 million in the six months ended June 29, 2024 and July 1, 2023, respectively. Additionally, during the six months ended June 29, 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million.

[0000889331-24-000161:mdna:112]
[same as prior period, unchanged from 0000889331-24-000129:mdna:93]

[0000889331-24-000161:mdna:113]
The Company’s Board of Directors authorized the repurchase of up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program. During the three and six months ended June 29, 2024, the Company repurchased 109,031 and 179,311 shares of its common stock totaling $24.7 million and $40.9 million, respectively, of which $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. There is $298.0 million of an authorized amount yet purchased under the 2024 program as of June 29, 2024. The Company did not repurchase shares of its common stock for the three and six months ended July 1, 2023.

[0000889331-24-000161:mdna:114]
[same as prior period, unchanged from 0000889331-24-000129:mdna:96]

[0000889331-24-000161:mdna:115]
As of June 29, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-24-000161:mdna:116]
[same as prior period, unchanged from 0000889331-24-000129:mdna:98]

[0000889331-24-000161:mdna:117]
[same as prior period, unchanged from 0000889331-24-000129:mdna:99]

[0000889331-24-000161:mdna:118]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 30, 2023. During the six months ended June 29, 2024, there were no significant changes in the application of critical accounting policies and estimates.
