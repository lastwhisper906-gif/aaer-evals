# LFUS notes — 0000889331-24-000161


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-24-000161:notes:1]
[same as prior period, unchanged from 0000889331-24-000129:notes:1]

[0000889331-24-000161:notes:2]
[same as prior period, unchanged from 0000889331-24-000129:notes:2]

[0000889331-24-000161:notes:3]
[same as prior period, unchanged from 0000889331-24-000129:notes:3]

[0000889331-24-000161:notes:4]
[same as prior period, unchanged from 0000889331-24-000129:notes:4]

[0000889331-24-000161:notes:5]
[same as prior period, unchanged from 0000889331-24-000129:notes:5]

[0000889331-24-000161:notes:6]
[same as prior period, unchanged from 0000889331-24-000129:notes:6]

[0000889331-24-000161:notes:7]
[same as prior period, unchanged from 0000889331-24-000129:notes:7]

[0000889331-24-000161:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2024 and July 1, 2023:

[0000889331-24-000161:notes:9]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  | — |  |  | — |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

[0000889331-24-000161:notes:10]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 197,295 |  |  | $ | — |  |  | $ | — |  |  | $ | 197,295 |  |  | $ | 407,290 |  |  | $ | — |  |  | $ | — |  |  | $ | 407,290 |  |
| Electronics – Passive Products and Sensors |  | 152,852 |  |  | — |  |  | — |  |  | 152,852 |  |  | 301,450 |  |  | — |  |  | — |  |  | 301,450 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  |  |  |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |

[0000889331-24-000161:notes:11]
[same as prior period, unchanged from 0000889331-24-000129:notes:11]

[0000889331-24-000161:notes:12]
[same as prior period, unchanged from 0000889331-24-000129:notes:12]

[0000889331-24-000161:notes:13]
[same as prior period, unchanged from 0000889331-24-000129:notes:13]

[0000889331-24-000161:notes:14]
[same as prior period, unchanged from 0000889331-24-000129:notes:14]

[0000889331-24-000161:notes:15]
[same as prior period, unchanged from 0000889331-24-000129:notes:15]

[0000889331-24-000161:notes:16]
[same as prior period, unchanged from 0000889331-24-000129:notes:16]

[0000889331-24-000161:notes:17]
[same as prior period, unchanged from 0000889331-24-000129:notes:17]

[0000889331-24-000161:notes:18]
[same as prior period, unchanged from 0000889331-24-000129:notes:18]

[0000889331-24-000161:notes:19]
[same as prior period, unchanged from 0000889331-24-000129:notes:19]

[0000889331-24-000161:notes:20]
[same as prior period, unchanged from 0000889331-24-000129:notes:20]

[0000889331-24-000161:notes:21]
[same as prior period, unchanged from 0000889331-24-000129:notes:21]

[0000889331-24-000161:notes:22]
[same as prior period, unchanged from 0000889331-24-000129:notes:22]

[0000889331-24-000161:notes:23]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at June 29, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-24-000161:notes:24]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 561,742 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,554 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 563,296 |  |  | $ | 557,123 |  |

[0000889331-24-000161:notes:25]
Recently Adopted Accounting Standards

[0000889331-24-000161:notes:26]
In March 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements." The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

[0000889331-24-000161:notes:27]
Recently Issued Accounting Standards

[0000889331-24-000161:notes:28]
In March 2024, the Securities and Exchange Commission ("SEC") issued a final rule that requires registrants to provide climate disclosures in annual reports and registration statements. The climate-related final rule requires disclosures in the footnotes to the financial statements, including: 1) specified financial statement effects of severe weather events and other natural conditions, 2) certain carbon offsets and renewable energy credits or certificates if used as a material component of a registrant's plans to achieve its disclosed climate-related targets or goals, 3) material impacts on financial estimates and assumptions in the financial statements if they would materially impacted by risks and uncertainties associated with severe weather events and other natural conditions, previously disclosed climate-related targets, and transition plans. The financial statement disclosure requirements are effective beginning with annual reports for the fiscal year beginning in calendar year 2025, for the Company as a large accelerated filer. These disclosures will be subject to existing audit requirement for financial statements. On April 4, 2024, the SEC chose to stay its climate disclosure rules pending judicial review. The adoption of this rule will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating and is in the process of performing its initial assessment of the potential impact on its Condensed Consolidated Financial Statements.

[0000889331-24-000161:notes:29]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures". The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2)

[0000889331-24-000161:notes:30]
income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

[0000889331-24-000161:notes:31]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures". The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of the Chief Operating Decision Maker (“CODM”) on an annual basis as well as an explanation of how the CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

[0000889331-24-000161:notes:32]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000889331-24-000161:notes:33]
[same as prior period, unchanged from 0000889331-24-000129:notes:33]

[0000889331-24-000161:notes:34]
[same as prior period, unchanged from 0000889331-24-000129:notes:34]

[0000889331-24-000161:notes:35]
[same as prior period, unchanged from 0000889331-24-000129:notes:35]

[0000889331-24-000161:notes:36]
On June 28, 2023, the Company entered into a definitive purchase agreement to acquire a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The acquisition of the Dortmund Fab is expected to close in early fiscal year 2025. The total purchase price for the Dortmund Fab is approximately 93 million Euro, of which a 37.2 million Euro down payment (approximately $40.5 million) recorded in Prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. The down payment was paid in the third quarter of 2023 after regulatory approvals, and approximately 56 million Euro will be paid at closing. The transaction is not expected to have a material impact on the Company’s fiscal year 2024 financial results and will be reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-24-000161:notes:37]
[same as prior period, unchanged from 0000889331-24-000129:notes:37]

[0000889331-24-000161:notes:38]
[same as prior period, unchanged from 0000889331-24-000129:notes:38]

[0000889331-24-000161:notes:39]
[same as prior period, unchanged from 0000889331-24-000129:notes:39]

[0000889331-24-000161:notes:40]
[same as prior period, unchanged from 0000889331-24-000129:notes:40]

[0000889331-24-000161:notes:41]
[same as prior period, unchanged from 0000889331-24-000129:notes:41]

[0000889331-24-000161:notes:42]
[same as prior period, unchanged from 0000889331-24-000129:notes:42]

[0000889331-24-000161:notes:43]
During the six months ended July 1, 2023, the Company incurred approximately $1.4 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses in the Condensed Consolidated Statement of Net Income. These costs were reflected as other non-segment costs.

[0000889331-24-000161:notes:44]
[same as prior period, unchanged from 0000889331-24-000129:notes:44]

[0000889331-24-000161:notes:45]
[same as prior period, unchanged from 0000889331-24-000129:notes:45]

[0000889331-24-000161:notes:46]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands, except per share amounts) |  | July 1, 2023 |  | July 1, 2023 |
| Net sales |  | $ | 611,997 |  |  | $ | 1,223,665 |  |
| Income before income taxes |  | 85,481 |  |  | 196,094 |  |
| Net income |  | 70,098 |  |  | 160,339 |  |
| Net income per share — basic |  | 2.82 |  |  | 6.46 |  |
| Net income per share — diluted |  | 2.79 |  |  | 6.39 |  |

[0000889331-24-000161:notes:47]
[same as prior period, unchanged from 0000889331-24-000129:notes:47]

[0000889331-24-000161:notes:48]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | July 1, 2023 |  | July 1, 2023 |
| Amortization (a) |  | $ | — |  |  | $ | (479) |  |
| Transaction costs (b) |  | 30 |  |  | 1,427 |  |
| Income tax expense of above items |  | (3) |  |  | (118) |  |

[0000889331-24-000161:notes:49]
(a) The amortization adjustment for the six months ended July 1, 2023 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-24-000161:notes:50]
(b) The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three and six months ended July 1, 2023, and recognition of those fees during the three and six months ended July 2, 2022.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-24-000161:notes:51]
[same as prior period, unchanged from 0000889331-24-000129:notes:51]

[0000889331-24-000161:notes:52]
The components of inventories at June 29, 2024 and December 30, 2023 are as follows:

[0000889331-24-000161:notes:53]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Raw materials |  | $ | 199,815 |  |  | $ | 201,984 |  |
| Work in process |  | 141,887 |  |  | 137,688 |  |
| Finished goods |  | 170,166 |  |  | 195,886 |  |
| Inventory reserves |  | (60,682) |  |  | (60,951) |  |
| Total |  | $ | 451,186 |  |  | $ | 474,607 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-24-000161:notes:54]
[same as prior period, unchanged from 0000889331-24-000129:notes:54]

[0000889331-24-000161:notes:55]
The components of net property, plant, and equipment at June 29, 2024 and December 30, 2023 are as follows:

[0000889331-24-000161:notes:56]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Land and land improvements |  | $ | 17,948 |  |  | $ | 22,212 |  |
| Building and building improvements |  | 191,584 |  |  | 202,764 |  |
| Machinery and equipment |  | 867,976 |  |  | 859,060 |  |
| Accumulated depreciation |  | (604,971) |  |  | (590,883) |  |
| Total |  | $ | 472,537 |  |  | $ | 493,153 |  |

[0000889331-24-000161:notes:57]
The Company recorded depreciation expense of $17.1 million and $18.0 million for the three months ended June 29, 2024 and July 1, 2023, respectively, and $33.7 million and $35.6 million for the six months ended June 29, 2024 and July 1, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-24-000161:notes:58]
[same as prior period, unchanged from 0000889331-24-000129:notes:58]

[0000889331-24-000161:notes:59]
Changes in the carrying value of goodwill by segment for the six months ended June 29, 2024 are as follows:

[0000889331-24-000161:notes:60]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net goodwill as of December 30, 2023 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 30, 2023 |  | $ | 936,505 |  |  | $ | 237,115 |  |  | $ | 179,117 |  |  | $ | 1,352,737 |  |
| Accumulated impairment losses as of December 30, 2023 |  | — |  |  | (34,004) |  |  | (8,735) |  |  | (42,739) |  |
| Total |  | 936,505 |  |  | 203,111 |  |  | 170,382 |  |  | 1,309,998 |  |
| Changes during 2024: |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments |  | (17,205) |  |  | (3,142) |  |  | (1,889) |  |  | (22,236) |  |
| Net goodwill as of June 29, 2024 |  |  |  |  |  |  |  |  |
| Gross goodwill as of June 29, 2024 |  | 919,300 |  |  | 233,364 |  |  | 176,914 |  |  | 1,329,578 |  |
| Accumulated impairment losses as of June 29, 2024 |  | — |  |  | (33,395) |  |  | (8,421) |  |  | (41,816) |  |
| Total |  | $ | 919,300 |  |  | $ | 199,969 |  |  | $ | 168,493 |  |  | $ | 1,287,762 |  |

[0000889331-24-000161:notes:61]
The components of other intangible assets as of June 29, 2024 and December 30, 2023 are as follows:

[0000889331-24-000161:notes:62]
|  |  |  | As of June 29, 2024 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 17,146 |  |  | $ | 2,971 |  |  | $ | 14,175 |  |
| Patents, licenses, and software |  |  | 270,630 |  |  | 171,946 |  |  | 98,684 |  |
| Distribution network |  |  | 41,860 |  |  | 41,860 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 678,721 |  |  | 225,550 |  |  | 453,171 |  |
| Total |  |  | $ | 1,008,357 |  |  | $ | 442,327 |  |  | $ | 566,030 |  |

[0000889331-24-000161:notes:63]
[same as prior period, unchanged from 0000889331-24-000129:notes:63]

[0000889331-24-000161:notes:64]
During the three months ended June 29, 2024 and July 1, 2023, the Company recorded amortization expense of $15.7 million and $16.9 million, respectively. During the six months ended June 29, 2024 and July 1, 2023, the Company recorded amortization expense of $31.6 million and $33.8 million, respectively.

[0000889331-24-000161:notes:65]
Estimated annual amortization expense related to intangible assets with definite lives as of June 29, 2024 is as follows:

[0000889331-24-000161:notes:66]
| (in thousands) | Amount |
| Remainder of 2024 | $ | 31,341 |  |
| 2025 | 62,476 |  |
| 2026 | 51,666 |  |
| 2027 | 49,629 |  |
| 2028 | 48,770 |  |
| 2029 and thereafter | 322,148 |  |
| Total | $ | 566,030 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-24-000161:notes:67]
[same as prior period, unchanged from 0000889331-24-000129:notes:67]

[0000889331-24-000161:notes:68]
The components of accrued liabilities as of June 29, 2024 and December 30, 2023 are as follows:

[0000889331-24-000161:notes:69]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Employee-related liabilities |  | $ | 60,753 |  |  | $ | 72,635 |  |
| Current lease liability |  | 10,623 |  |  | 12,110 |  |
| Other non-income taxes |  | 6,851 |  |  | 7,855 |  |
| Interest |  | 6,356 |  |  | 6,387 |  |
| Professional services |  | 5,703 |  |  | 5,282 |  |
| Restructuring liability |  | 5,490 |  |  | 2,141 |  |
| Other customer reserves |  | 5,373 |  |  | 5,998 |  |
| Deferred revenue |  | 1,875 |  |  | 2,198 |  |
| Current benefit liability |  | 1,482 |  |  | 1,482 |  |
| Other |  | 30,674 |  |  | 33,126 |  |
| Total |  | $ | 135,180 |  |  | $ | 149,214 |  |

[0000889331-24-000161:notes:70]
[same as prior period, unchanged from 0000889331-24-000129:notes:70]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-24-000161:notes:71]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three and six months ended June 29, 2024 and July 1, 2023 as follows:

[0000889331-24-000161:notes:72]
|  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 4,501 |  |  | $ | 437 |  |  | $ | 5 |  |  | $ | 4,943 |  |  | $ | 5,105 |  |  | $ | 1,591 |  |  | $ | 416 |  |  | $ | 7,112 |  |
| Other restructuring charges | 87 |  |  | 209 |  |  | 13 |  |  | 309 |  |  | 139 |  |  | 287 |  |  | 18 |  |  | 444 |  |
| Total restructuring charges | 4,588 |  |  | 646 |  |  | 18 |  |  | 5,252 |  |  | 5,244 |  |  | 1,878 |  |  | 434 |  |  | 7,556 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 933 |  |  | — |  |  | 933 |  |
| Total | $ | 4,588 |  |  | $ | 646 |  |  | $ | 18 |  |  | $ | 5,252 |  |  | $ | 5,244 |  |  | $ | 2,811 |  |  | $ | 434 |  |  | $ | 8,489 |  |

[0000889331-24-000161:notes:73]
|  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 987 |  |  | $ | 351 |  |  | $ | 277 |  |  | $ | 1,615 |  |  | $ | 1,659 |  |  | $ | 933 |  |  | $ | 594 |  |  | $ | 3,186 |  |
| Other restructuring charges | 250 |  |  | 412 |  |  | 654 |  |  | 1,316 |  |  | 257 |  |  | 684 |  |  | 654 |  |  | 1,595 |  |
| Total restructuring charges | 1,237 |  |  | 763 |  |  | 931 |  |  | 2,931 |  |  | 1,916 |  |  | 1,617 |  |  | 1,248 |  |  | 4,781 |  |
| Impairment | — |  |  | 3,870 |  |  | 54 |  |  | 3,924 |  |  | — |  |  | 3,870 |  |  | 54 |  |  | 3,924 |  |
| Total | $ | 1,237 |  |  | $ | 4,633 |  |  | $ | 985 |  |  | $ | 6,855 |  |  | $ | 1,916 |  |  | $ | 5,487 |  |  | $ | 1,302 |  |  | $ | 8,705 |  |

[0000889331-24-000161:notes:74]
[same as prior period, unchanged from 0000889331-24-000129:notes:74]

[0000889331-24-000161:notes:75]
For the three and six months ended June 29, 2024, the Company recorded total restructuring charges of $5.3 million and $7.6 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the semiconductor business in the Electronics segment and the reorganization of certain selling and administrative functions within the commercial vehicle business in the Transportation segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-24-000161:notes:76]
[same as prior period, unchanged from 0000889331-24-000129:notes:76]

[0000889331-24-000161:notes:77]
For the three and six months ended July 1, 2023, the Company recorded total restructuring charges of $2.9 million and $4.8 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K Switches acquisition and the reorganization of certain manufacturing, selling and administrative functions within the commercial vehicle business in the Transportation segment. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate.

[0000889331-24-000161:notes:78]
The restructuring reserves as of both June 29, 2024 and December 30, 2023 is $5.5 million and $2.1 million, respectively. The restructuring liability is included within Accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in the first quarter fiscal year 2025.


## us-gaap:DebtDisclosureTextBlock

[0000889331-24-000161:notes:79]
Debt

[0000889331-24-000161:notes:80]
The carrying amounts of debt at June 29, 2024 and December 30, 2023 are as follows:

[0000889331-24-000161:notes:81]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 101,631 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,142 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,269) |  |  | (3,770) |  |
| Total debt |  | 863,504 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,679) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 795,825 |  |  | $ | 857,915 |  |

[0000889331-24-000161:notes:82]
Revolving Credit Facility and Term Loan

[0000889331-24-000161:notes:83]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-24-000161:notes:84]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-24-000161:notes:85]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended June 29, 2024, the Company made payments of $1.9 million and $3.8 million respectively, on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of June 29, 2024.

[0000889331-24-000161:notes:86]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-24-000161:notes:87]
As of June 29, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.69%, and 4.13% on the hedged portion.

[0000889331-24-000161:notes:88]
As of June 29, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving credit facility. As of June 29, 2024, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-24-000161:notes:89]
Senior Notes

[0000889331-24-000161:notes:90]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fourth quarter of 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-24-000161:notes:91]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-24-000161:notes:92]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-24-000161:notes:93]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-24-000161:notes:94]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-24-000161:notes:95]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-24-000161:notes:96]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 29, 2024, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-24-000161:notes:97]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-24-000161:notes:98]
Interest paid on all Company debt was $6.4 million and $10.3 million for the three months ended June 29, 2024 and July 1, 2023, respectively, and $19.6 million and $21.3 million for the six months ended June 29, 2024 and July 1, 2023, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-24-000161:notes:99]
[same as prior period, unchanged from 0000889331-24-000129:notes:99]

[0000889331-24-000161:notes:100]
[same as prior period, unchanged from 0000889331-24-000129:notes:100]

[0000889331-24-000161:notes:101]
[same as prior period, unchanged from 0000889331-24-000129:notes:101]

[0000889331-24-000161:notes:102]
[same as prior period, unchanged from 0000889331-24-000129:notes:102]

[0000889331-24-000161:notes:103]
[same as prior period, unchanged from 0000889331-24-000129:notes:103]

[0000889331-24-000161:notes:104]
[same as prior period, unchanged from 0000889331-24-000129:notes:104]

[0000889331-24-000161:notes:105]
[same as prior period, unchanged from 0000889331-24-000129:notes:105]

[0000889331-24-000161:notes:106]
[same as prior period, unchanged from 0000889331-24-000129:notes:106]

[0000889331-24-000161:notes:107]
[same as prior period, unchanged from 0000889331-24-000129:notes:107]

[0000889331-24-000161:notes:108]
[same as prior period, unchanged from 0000889331-24-000129:notes:108]

[0000889331-24-000161:notes:109]
[same as prior period, unchanged from 0000889331-24-000129:notes:109]

[0000889331-24-000161:notes:110]
[same as prior period, unchanged from 0000889331-24-000129:notes:110]

[0000889331-24-000161:notes:111]
[same as prior period, unchanged from 0000889331-24-000129:notes:111]

[0000889331-24-000161:notes:112]
[same as prior period, unchanged from 0000889331-24-000129:notes:112]

[0000889331-24-000161:notes:113]
[same as prior period, unchanged from 0000889331-24-000129:notes:113]

[0000889331-24-000161:notes:114]
[same as prior period, unchanged from 0000889331-24-000129:notes:114]

[0000889331-24-000161:notes:115]
[same as prior period, unchanged from 0000889331-24-000129:notes:115]

[0000889331-24-000161:notes:116]
As of June 29, 2024 and December 30, 2023, the fair values of the Company's derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-24-000161:notes:117]
| (in thousands) | Condensed Consolidated Balance Sheet Classification |  | June 29, 2024 |  | December 30, 2023 |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 3,946 |  |  | $ | 3,712 |  |  |  |
|  | Other long-term assets |  | $ | 4,417 |  |  | $ | 2,140 |  |  |  |

[0000889331-24-000161:notes:118]
The pre-tax gains recognized on derivative financial instruments in the Condensed Consolidated Statements of Net Income for the three and six months ended June 29, 2024 and July 1, 2023 were as follows:

[0000889331-24-000161:notes:119]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | Classification of Gain Recognized in the Condensed Consolidated Statements of Net Income |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (1,288) |  |  | $ | (1,119) |  |  | $ | (2,568) |  |  | $ | (2,094) |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  | Foreign exchange gain |  | $ | — |  |  | $ | (264) |  |  | $ | — |  |  | $ | (1,083) |  |

[0000889331-24-000161:notes:120]
The pre-tax losses (gains) recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and six months ended June 29, 2024 and July 1, 2023 was as follows:

[0000889331-24-000161:notes:121]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | 23 |  |  | $ | (4,096) |  |  | $ | (2,511) |  |  | $ | (783) |  |

[0000889331-24-000161:notes:122]
[same as prior period, unchanged from 0000889331-24-000129:notes:122]

[0000889331-24-000161:notes:123]
[same as prior period, unchanged from 0000889331-24-000129:notes:123]

[0000889331-24-000161:notes:124]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value and recorded in Other long-term assets in the Condensed Consolidated Balance Sheets.

[0000889331-24-000161:notes:125]
There were no changes during the quarter ended June 29, 2024 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of June 29, 2024 and December 30, 2023, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-24-000161:notes:126]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of June 29, 2024:

[0000889331-24-000161:notes:127]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 470,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 470,012 |  |
| Investments in equity securities |  | 9,328 |  |  | — |  |  | — |  |  | 9,328 |  |
| Mutual funds |  | 22,064 |  |  | — |  |  | — |  |  | 22,064 |  |
| Total |  | $ | 501,404 |  |  | $ | — |  |  | $ | — |  |  | $ | 501,404 |  |

[0000889331-24-000161:notes:128]
[same as prior period, unchanged from 0000889331-24-000129:notes:128]

[0000889331-24-000161:notes:129]
[same as prior period, unchanged from 0000889331-24-000129:notes:129]

[0000889331-24-000161:notes:130]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at June 29, 2024 and December 30, 2023, as the rates on these borrowings are variable in nature.

[0000889331-24-000161:notes:131]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of June 29, 2024 and December 30, 2023 were as follows:

[0000889331-24-000161:notes:132]
|  |  | June 29, 2024 |  | December 30, 2023 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 |  | $ | 101,631 |  |  | $ | 92,178 |  |  | $ | 105,246 |  |  | $ | 96,532 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 95,690 |  |  | 100,000 |  |  | 96,127 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 49,354 |  |  | 50,000 |  |  | 49,070 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 113,730 |  |  | 125,000 |  |  | 115,687 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 90,810 |  |  | 100,000 |  |  | 93,228 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-24-000161:notes:133]
[same as prior period, unchanged from 0000889331-24-000129:notes:133]

[0000889331-24-000161:notes:134]
[same as prior period, unchanged from 0000889331-24-000129:notes:134]

[0000889331-24-000161:notes:135]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and six months ended June 29, 2024 and July 1, 2023 were as follows:

[0000889331-24-000161:notes:136]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 770 |  |  | $ | 695 |  |  | $ | 1,565 |  |  | $ | 1,387 |  |
| Interest cost |  | 975 |  |  | 952 |  |  | 1,970 |  |  | 1,889 |  |
| Expected return on plan assets |  | (510) |  |  | (470) |  |  | (1,028) |  |  | (939) |  |
| Amortization of prior service and net actuarial loss |  | 46 |  |  | 11 |  |  | 92 |  |  | 22 |  |
| Net periodic benefit cost |  | $ | 1,281 |  |  | $ | 1,188 |  |  | $ | 2,599 |  |  | $ | 2,359 |  |

[0000889331-24-000161:notes:137]
[same as prior period, unchanged from 0000889331-24-000129:notes:137]

[0000889331-24-000161:notes:138]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.7 million and $0.4 million for the three months ended June 29, 2024 and July 1, 2023, respectively, and $1.4 million and $0.8 million for the six months ended June 29, 2024 and July 1, 2023, respectively, in Cost of sales and Other income, net within the Condensed Consolidated Statements of Net Income. The pre-tax (gains) losses amount recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.3 million and nominal for the three months ended June 29, 2024 and July 1, 2023, respectively, and $0.6 million and nominal for the six months ended June 29, 2024 and July 1, 2023, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-24-000161:notes:139]
[same as prior period, unchanged from 0000889331-24-000129:notes:139]

[0000889331-24-000161:notes:140]
| (in thousands) |  | Three Months EndedJune 29, 2024 |  | Three Months EndedJuly 1, 2023 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 336 |  |  | $ | (10) |  |  | $ | 326 |  |  | $ | (146) |  |  | $ | (13) |  |  | $ | (159) |  |
| Cash flow hedge |  | (23) |  |  | 5 |  |  | (18) |  |  | 4,096 |  |  | (983) |  |  | 3,113 |  |
| Foreign currency translation adjustments (a) |  | (21,542) |  |  | 167 |  |  | (21,375) |  |  | (17,865) |  |  | — |  |  | (17,865) |  |
| Total change in other comprehensive (loss) income |  | $ | (21,229) |  |  | $ | 162 |  |  | $ | (21,067) |  |  | $ | (13,915) |  |  | $ | (996) |  |  | $ | (14,911) |  |
| (in thousands) |  | Six Months EndedJune 29, 2024 |  | Six Months EndedJuly 1, 2023 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 696 |  |  | $ | (26) |  |  | $ | 670 |  |  | $ | (122) |  |  | $ | (31) |  |  | $ | (153) |  |
| Cash flow hedge |  | 2,511 |  |  | (603) |  |  | 1,908 |  |  | 783 |  |  | (188) |  |  | 595 |  |
| Foreign currency translation adjustments (a) |  | (54,712) |  |  | 776 |  |  | (53,936) |  |  | (1,797) |  |  | (273) |  |  | (2,070) |  |
| Total change in other comprehensive (loss) income |  | $ | (51,505) |  |  | $ | 147 |  |  | $ | (51,358) |  |  | $ | (1,136) |  |  | $ | (492) |  |  | $ | (1,628) |  |

[0000889331-24-000161:notes:141]
[same as prior period, unchanged from 0000889331-24-000129:notes:141]

[0000889331-24-000161:notes:142]
The following tables set forth the changes in accumulated other comprehensive loss by component for the six months ended June 29, 2024 and July 1, 2023:

[0000889331-24-000161:notes:143]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at December 30, 2023 |  | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| Activity in the period |  | 670 |  |  | 1,908 |  |  | (53,936) |  |  | (51,358) |  |
| Balance at June 29, 2024 |  | $ | (6,943) |  |  | $ | 6,356 |  |  | $ | (106,588) |  |  | $ | (107,175) |  |

[0000889331-24-000161:notes:144]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at December 31, 2022 |  | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| Activity in the period |  | (153) |  |  | 595 |  |  | (2,070) |  |  | (1,628) |  |
| Balance at July 1, 2023 |  | $ | (2,346) |  |  | $ | 7,191 |  |  | $ | (102,237) |  |  | $ | (97,392) |  |

[0000889331-24-000161:notes:145]
Amounts reclassified from accumulated other comprehensive loss to earnings for the three and six months ended June 29, 2024 and July 1, 2023 were as follows:

[0000889331-24-000161:notes:146]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Pension and postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss (gain) |  | $ | 347 |  |  | $ | (11) |  |  | $ | 703 |  |  | $ | (22) |  |

[0000889331-24-000161:notes:147]
[same as prior period, unchanged from 0000889331-24-000129:notes:147]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-24-000161:notes:148]
Income Taxes
The effective tax rate for the three and six months ended June 29, 2024 was 25.6% and 19.6%, compared to the effective tax rate for the three and six months ended July 1, 2023 of 18.0% and 18.3%. The effective tax rates for 2024 are higher than the effective tax rates for the comparable 2023 periods primarily due to decreases in the income earned in lower tax jurisdictions in 2024 as compared to 2023. 
The effective tax rate for the three months ended June 29, 2024 is higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions. The effective tax rate for the six months ended June 29, 2024 is lower than the statutory tax rate primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter. The effective tax rates for 2023 are lower than the statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-24-000161:notes:149]
[same as prior period, unchanged from 0000889331-24-000129:notes:149]

[0000889331-24-000161:notes:150]
[same as prior period, unchanged from 0000889331-24-000129:notes:150]

[0000889331-24-000161:notes:151]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share amounts) |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 45,466 |  |  | $ | 70,071 |  |  | $ | 93,918 |  |  | $ | 158,816 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,822 |  |  | 24,839 |  |  | 24,867 |  |  | 24,810 |  |
| Effect of dilutive securities |  | 208 |  |  | 256 |  |  | 208 |  |  | 268 |  |
| Diluted |  | 25,030 |  |  | 25,095 |  |  | 25,075 |  |  | 25,078 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.83 |  |  | $ | 2.82 |  |  | $ | 3.78 |  |  | $ | 6.40 |  |
| Diluted earnings per share |  | $ | 1.82 |  |  | $ | 2.79 |  |  | $ | 3.75 |  |  | $ | 6.33 |  |

[0000889331-24-000161:notes:152]
Potential shares of common stock relating to stock options and restricted share units are excluded from the earnings per share calculation because their effect would be anti-dilutive were 141,729 and 110,598 for the three months ended June 29, 2024 and July 1, 2023, respectively, and 129,096 and 102,283 for the six months ended June 29, 2024 and July 1, 2023, respectively.

[0000889331-24-000161:notes:153]
[same as prior period, unchanged from 0000889331-24-000129:notes:153]

[0000889331-24-000161:notes:154]
The Company’s Board of Directors authorized the repurchase of up to $300.0 million in the aggregate of shares of the Company’s common stock under a program for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program. During the three and six months ended June 29, 2024, the Company repurchased 109,031 and 179,311 shares of its common stock totaling $24.7 million and $40.9 million, respectively, of which $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. The Company did not repurchase shares of its common stock for the three and six months ended July 1, 2023.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-24-000161:notes:155]
[same as prior period, unchanged from 0000889331-24-000129:notes:156]

[0000889331-24-000161:notes:156]
The Company and its subsidiaries design, manufacture and sell component, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company reports its operations by the following segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is

[0000889331-24-000161:notes:157]
the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-24-000161:notes:158]
[same as prior period, unchanged from 0000889331-24-000129:notes:158]

[0000889331-24-000161:notes:159]
[same as prior period, unchanged from 0000889331-24-000129:notes:159]

[0000889331-24-000161:notes:160]
[same as prior period, unchanged from 0000889331-24-000129:notes:160]

[0000889331-24-000161:notes:161]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), protective and monitoring relays (protection relays, residual current devices and monitors, ground fault circuit interrupters, and arc fault detection devices), and industrial controls and sensors (contactors, transformers, and temperature sensors) for use in various applications such as renewable energy and energy storage systems, industrial safety, factory automation, electric vehicle infrastructure, HVAC systems, non-residential construction, MRO, and mining.

[0000889331-24-000161:notes:162]
[same as prior period, unchanged from 0000889331-24-000129:notes:162]

[0000889331-24-000161:notes:163]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 305,639 |  |  | $ | 350,147 |  |  | $ | 596,744 |  |  | $ | 708,740 |  |
| Transportation |  | 168,964 |  |  | 172,048 |  |  | 339,331 |  |  | 338,689 |  |
| Industrial |  | 83,886 |  |  | 89,802 |  |  | 157,799 |  |  | 174,350 |  |
| Total net sales |  | $ | 558,489 |  |  | $ | 611,997 |  |  | $ | 1,093,874 |  |  | $ | 1,221,779 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 19,770 |  |  | $ | 19,808 |  |  | $ | 39,611 |  |  | 39,596 |  |
| Transportation |  | 9,112 |  |  | 11,063 |  |  | 17,743 |  |  | 22,354 |  |
| Industrial |  | 3,898 |  |  | 4,021 |  |  | 7,919 |  |  | 7,424 |  |
| Total depreciation and amortization |  | $ | 32,780 |  |  | $ | 34,892 |  |  | $ | 65,273 |  |  | $ | 69,374 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 46,165 |  |  | $ | 79,844 |  |  | $ | 83,968 |  |  | $ | 170,006 |  |
| Transportation |  | 15,234 |  |  | 7,789 |  |  | 31,440 |  |  | 16,321 |  |
| Industrial |  | 9,547 |  |  | 15,108 |  |  | 14,343 |  |  | 32,249 |  |
| Other (a) |  | (5,440) |  |  | (10,688) |  |  | (9,293) |  |  | (15,882) |  |
| Total operating income |  | 65,506 |  |  | 92,053 |  |  | 120,458 |  |  | 202,694 |  |
| Interest expense |  | 9,975 |  |  | 10,056 |  |  | 19,586 |  |  | 19,702 |  |
| Foreign exchange gain |  | (315) |  |  | (1,404) |  |  | (5,357) |  |  | (3,079) |  |
| Other income, net |  | (5,298) |  |  | (2,050) |  |  | (10,619) |  |  | (8,283) |  |
| Income before income taxes |  | $ | 61,144 |  |  | $ | 85,451 |  |  | $ | 116,848 |  |  | $ | 194,354 |  |

[0000889331-24-000161:notes:164]
(a) Included in “Other” Operating income for the second quarter of 2024 includes $5.3 million ($7.6 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2024, the Company recognized $0.8 million ($1.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.7 million ($1.0 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0000889331-24-000161:notes:165]
Included in “Other” Operating income for the second quarter of 2023 was $3.9 million ($7.2 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $2.9 million ($4.8 million year-to-date) of restructuring charges primarily related to employee termination costs. In addition, during the second quarter of 2023, the Company recognized a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-24-000161:notes:166]
[same as prior period, unchanged from 0000889331-24-000129:notes:166]

[0000889331-24-000161:notes:167]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 201,825 |  |  | $ | 205,793 |  |  | $ | 392,258 |  |  | $ | 417,988 |  |
| China |  | 131,510 |  |  | 143,570 |  |  | 246,679 |  |  | 277,037 |  |
| Other countries (a) |  | 225,154 |  |  | 262,634 |  |  | 454,937 |  |  | 526,754 |  |
| Total net sales |  | $ | 558,489 |  |  | $ | 611,997 |  |  | $ | 1,093,874 |  |  | $ | 1,221,779 |  |

[0000889331-24-000161:notes:168]
The Company’s long-lived assets represent net property, plant, and equipment, and are classified according to the country where the asset is located were as follows:

[0000889331-24-000161:notes:169]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 66,972 |  |  | $ | 73,126 |  |
| China |  | 134,359 |  |  | 139,736 |  |
| Mexico |  | 95,525 |  |  | 102,218 |  |
| Germany |  | 51,359 |  |  | 47,217 |  |
| Philippines |  | 68,689 |  |  | 73,217 |  |
| Other countries |  | 55,633 |  |  | 57,639 |  |
| Total long-lived assets |  | $ | 472,537 |  |  | $ | 493,153 |  |

[0000889331-24-000161:notes:170]
[same as prior period, unchanged from 0000889331-24-000129:notes:170]

[0000889331-24-000161:notes:171]
|  |  | Six Months Ended |
| (in thousands) |  | June 29, 2024 |  | July 1, 2023 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 6,644 |  |  | $ | 5,482 |  |
| China |  | 7,088 |  |  | 15,228 |  |
| Mexico |  | 5,450 |  |  | 7,176 |  |
| Germany |  | 8,031 |  |  | 3,269 |  |
| Philippines |  | 2,379 |  |  | 3,202 |  |
| Other countries |  | 4,277 |  |  | 5,602 |  |
| Total additions to long-lived assets |  | $ | 33,869 |  |  | $ | 39,959 |  |

[0000889331-24-000161:notes:172]
[same as prior period, unchanged from 0000889331-24-000129:notes:172]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000889331-24-000161:notes:173]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0000889331-24-000161:notes:174]
As of June 29, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-24-000161:notes:175]
Product Warranty Liabilities

[0000889331-24-000161:notes:176]
The company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0000889331-24-000161:notes:177]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0000889331-24-000161:notes:178]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will

[0000889331-24-000161:notes:179]
impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-24-000161:notes:180]
Environmental Remediation Liabilities

[0000889331-24-000161:notes:181]
The company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0000889331-24-000161:notes:182]
Legal Proceedings

[0000889331-24-000161:notes:183]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

[0000889331-24-000161:notes:184]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss and therefore the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.

[0000889331-24-000161:notes:185]
Pending Litigation and Claims

[0000889331-24-000161:notes:186]
There are no material pending litigation or claims outstanding as of June 29, 2024.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-24-000161:notes:187]
Related Party Transactions

[0000889331-24-000161:notes:188]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-24-000161:notes:189]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-24-000161:notes:190]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-24-000161:notes:191]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-24-000161:notes:192]
|  |  | Three Months Ended June 29, 2024 |  | Three Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 0.8 |  |  | 1.1 |  | 0.1 |  | 2.9 |  |
|  |  | Six Months Ended June 29, 2024 |  | Six Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.4 |  | 0.4 |  | 2.9 |  |  | 2.1 |  | 0.2 |  | 5.6 |  |
|  |  | June 29, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.2 |  | $ | 0.1 |  | $ | 0.2 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000889331-24-000161:notes:193]
The adoption or termination of contracts, instructions or written plans for the purchase or sale of our securities by our Section 16 officers and directors for the three months ended June 29, 2024, each of which is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act (“Rule 10b5-1 Plan”), were as follows:

[0000889331-24-000161:notes:194]
| Name |  | Title |  | Action |  | Date Termination of the plan |  | Date Adopted |  | Expiration Date |  | Aggregate # of securities to be Sold |
| Meenal Sethna (1) |  | Executive Vice President and Chief Financial Officer |  | Termination of the plan |  | 5/13/2024 |  | 11/9/2023 |  | 4/25/2025 |  | 9,145 |

[0000889331-24-000161:notes:195]
(1) On May 13, 2024, Meenal Sethna, Executive Vice President and Chief Financial Officer,  terminated a pre-arranged stock trading plan pursuant to Rule 10b5-1 that was adopted November 9, 2023. Ms. Sethna’s plan provided for the potential exercise of vested stock options and the associated sale of up to 9,145 shares of the Company’s common stock. The stock options covered by the plan expire on April 25, 2025 if they are not otherwise terminated.
