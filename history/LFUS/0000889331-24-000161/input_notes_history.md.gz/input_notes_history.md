# LFUS note change history — 0000889331-24-000129 → 0000889331-24-000161


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000889331-24-000161:note_history:1]
As of June 29, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.
  (was, 2024-05-01, similarity 0.9921):
[0000889331-24-000129:note_history:1]
As of March 30, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

- changed (2024-07-31):
[0000889331-24-000161:note_history:2]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will
  (was, 2024-05-01, similarity 0.8422):
[0000889331-24-000129:note_history:2]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

- added (2024-07-31):
[0000889331-24-000161:note_history:3]
impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

- changed (2024-07-31):
[0000889331-24-000161:note_history:4]
There are no material pending litigation or claims outstanding as of June 29, 2024.
  (was, 2024-05-01, similarity 0.9419):
[0000889331-24-000129:note_history:4]
There are no material pending litigation or claims outstanding as of March 30, 2024.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000889331-24-000161:note_history:5]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2024 and July 1, 2023:
  (was, 2024-05-01, similarity 0.9118):
[0000889331-24-000129:note_history:5]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2024 and April 1, 2023:

- added (2024-07-31):
[0000889331-24-000161:note_history:6]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  | — |  |  | — |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

- added (2024-07-31):
[0000889331-24-000161:note_history:7]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 197,295 |  |  | $ | — |  |  | $ | — |  |  | $ | 197,295 |  |  | $ | 407,290 |  |  | $ | — |  |  | $ | — |  |  | $ | 407,290 |  |
| Electronics – Passive Products and Sensors |  | 152,852 |  |  | — |  |  | — |  |  | 152,852 |  |  | 301,450 |  |  | — |  |  | — |  |  | 301,450 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  |  |  |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |

- changed (2024-07-31):
[0000889331-24-000161:note_history:8]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at June 29, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2024-05-01, similarity 0.9843):
[0000889331-24-000129:note_history:8]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 30, 2024 and December 30, 2023 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2024-07-31):
[0000889331-24-000161:note_history:9]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 561,742 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,554 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 563,296 |  |  | $ | 557,123 |  |
  (was, 2024-05-01, similarity 0.9821):
[0000889331-24-000129:note_history:9]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Cash and cash equivalents |  | $ | 562,153 |  |  | $ | 555,513 |  |
| Restricted cash included in other long-term assets |  | 1,567 |  |  | 1,610 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 563,720 |  |  | $ | 557,123 |  |

- changed (2024-07-31):
[0000889331-24-000161:note_history:10]
In March 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements." The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Condensed Consolidated Financial Statements.
  (was, 2024-05-01, similarity 0.9989):
[0000889331-24-000129:note_history:10]
In March 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU")ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

- changed (2024-07-31):
[0000889331-24-000161:note_history:11]
In March 2024, the Securities and Exchange Commission ("SEC") issued a final rule that requires registrants to provide climate disclosures in annual reports and registration statements. The climate-related final rule requires disclosures in the footnotes to the financial statements, including: 1) specified financial statement effects of severe weather events and other natural conditions, 2) certain carbon offsets and renewable energy credits or certificates if used as a material component of a registrant's plans to achieve its disclosed climate-related targets or goals, 3) material impacts on financial estimates and assumptions in the financial statements if they would materially impacted by risks and uncertainties associated with severe weather events and other natural conditions, previously disclosed climate-related targets, and transition plans. The financial statement disclosure requirements are effective beginning with annual reports for the fiscal year beginning in calendar year 2025, for the Company as a large accelerated filer. These disclosures will be subject to existing audit requirement for financial statements. On April 4, 2024, the SEC chose to stay its climate disclosure rules pending judicial review. The adoption of this rule will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating and is in the process of performing its initial assessment of the potential impact on its Condensed Consolidated Financial Statements.
  (was, 2024-05-01, similarity 0.9973):
[0000889331-24-000129:note_history:11]
In March 2024, the Securities and Exchange Commission (SEC) issued a final rule that requires registrants to provide climate disclosures in annual reports and registration statements. The climate-related final rule requires disclosures in the footnotes to the financial statements, including: 1) specified financial statement effects of severe weather events and other natural conditions, 2) certain carbon offsets and renewable energy credits or certificates if used as a material component of a registrant's plans to achieve its disclosed climate-related targets or goals, 3) material impacts on financial estimates and assumptions in the financial statements if they would materially impacted by risks and uncertainties associated with severe weather events and other natural conditions, previously disclosed climate-related targets, and transition plans. The financial statement disclosure requirements are effective beginning with annual reports for the fiscal year beginning in calendar year 2025, for the Company as a large accelerated filer. These disclosures will be subject to existing audit requirement for financial statements. On April 4, 2024, the SEC chose to stay its climate disclosure rules pending judicial review. The adoption of this rule will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating and is in the process of performing its initial assessment of the potential impact on its Condensed Consolidated Financial Statements.

- changed (2024-07-31):
[0000889331-24-000161:note_history:12]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures". The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2)
  (was, 2024-05-01, similarity 0.63):
[0000889331-24-000129:note_history:12]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures". The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

- added (2024-07-31):
[0000889331-24-000161:note_history:13]
income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

- changed (2024-07-31):
[0000889331-24-000161:note_history:14]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures". The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of the Chief Operating Decision Maker (“CODM”) on an annual basis as well as an explanation of how the CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.
  (was, 2024-05-01, similarity 0.9968):
[0000889331-24-000129:note_history:14]
In November 2023, the FASB issued ASU No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures". The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of  the Chief Operating Decision Maker (“CODM”) on annual basis as well as an explanation of how CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of this guidance will modify the Company's disclosures in its Condensed Consolidated Financial Statements.

- changed (2024-07-31):
[0000889331-24-000161:note_history:15]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.
  (was, 2024-05-01, similarity 0.8185):
[0000889331-24-000129:note_history:15]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements". The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and  will not be

- removed (2024-07-31):
[0000889331-24-000129:note_history:16]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |

- removed (2024-07-31):
[0000889331-24-000129:note_history:17]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 209,995 |  |  | $ | — |  |  | $ | — |  |  | $ | 209,995 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,598 |  |  | — |  |  | — |  |  | 148,598 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |

- removed (2024-07-31):
[0000889331-24-000129:note_history:18]
effective until June 30, 2027. The company is currently evaluating the potential effects of these amendments on its Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000889331-24-000161:note_history:19]
The carrying amounts of debt at June 29, 2024 and December 30, 2023 are as follows:
  (was, 2024-05-01, similarity 0.9388):
[0000889331-24-000129:note_history:19]
The carrying amounts of debt at March 30, 2024 and December 30, 2023 are as follows:

- changed (2024-07-31):
[0000889331-24-000161:note_history:20]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 101,631 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,142 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,269) |  |  | (3,770) |  |
| Total debt |  | 863,504 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,679) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 795,825 |  |  | $ | 857,915 |  |
  (was, 2024-05-01, similarity 0.9926):
[0000889331-24-000129:note_history:20]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 286,875 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,458 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,857 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,517) |  |  | (3,770) |  |
| Total debt |  | 866,673 |  |  | 871,935 |  |
| Less: Current maturities |  | (65,824) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 800,849 |  |  | $ | 857,915 |  |

- changed (2024-07-31):
[0000889331-24-000161:note_history:21]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.
  (was, 2024-05-01, similarity 0.7451):
[0000889331-24-000129:note_history:21]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

- changed (2024-07-31):
[0000889331-24-000161:note_history:22]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended June 29, 2024, the Company made payments of $1.9 million and $3.8 million respectively, on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $285.0 million, respectively, as of June 29, 2024.
  (was, 2024-05-01, similarity 0.8785):
[0000889331-24-000129:note_history:22]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 30, 2024, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $286.9 million, respectively, as of March 30, 2024.

- changed (2024-07-31):
[0000889331-24-000161:note_history:23]
As of June 29, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.69%, and 4.13% on the hedged portion.
  (was, 2024-05-01, similarity 0.9712):
[0000889331-24-000129:note_history:23]
As of March 30, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 6.68%, and 4.13% on the hedged portion.

- changed (2024-07-31):
[0000889331-24-000161:note_history:24]
As of June 29, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving credit facility. As of June 29, 2024, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2024-05-01, similarity 0.9676):
[0000889331-24-000129:note_history:24]
As of March 30, 2024, the Company had $0.2 million outstanding letters of credit under the Credit Facility and had $599.8 million of borrowing capacity available under the revolving credit facility. As of March 30, 2024, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2024-07-31):
[0000889331-24-000161:note_history:25]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 29, 2024, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2024-05-01, similarity 0.9921):
[0000889331-24-000129:note_history:25]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 30, 2024, the Company was in compliance with all covenants under the Senior Notes.

- changed (2024-07-31):
[0000889331-24-000161:note_history:26]
Interest paid on all Company debt was $6.4 million and $10.3 million for the three months ended June 29, 2024 and July 1, 2023, respectively, and $19.6 million and $21.3 million for the six months ended June 29, 2024 and July 1, 2023, respectively.
  (was, 2024-05-01, similarity 0.7014):
[0000889331-24-000129:note_history:26]
Interest paid on all Company debt was $13.2 million and $11.0 million for the three months ended March 30, 2024 and April 1, 2023, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000889331-24-000161:note_history:27]
The carrying amounts of debt at June 29, 2024 and December 30, 2023 are as follows:
  (was, 2024-05-01, similarity 0.9388):
[0000889331-24-000129:note_history:27]
The carrying amounts of debt at March 30, 2024 and December 30, 2023 are as follows:

- changed (2024-07-31):
[0000889331-24-000161:note_history:28]
| (in thousands) |  | June 29, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 285,000 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 101,631 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,142 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,269) |  |  | (3,770) |  |
| Total debt |  | 863,504 |  |  | 871,935 |  |
| Less: Current maturities |  | (67,679) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 795,825 |  |  | $ | 857,915 |  |
  (was, 2024-05-01, similarity 0.9926):
[0000889331-24-000129:note_history:28]
| (in thousands) |  | March 30, 2024 |  | December 30, 2023 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 286,875 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,458 |  |  | 105,246 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 5,857 |  |  | 6,709 |  |
| Unamortized debt issuance costs |  | (3,517) |  |  | (3,770) |  |
| Total debt |  | 866,673 |  |  | 871,935 |  |
| Less: Current maturities |  | (65,824) |  |  | (14,020) |  |
| Total long-term debt |  | $ | 800,849 |  |  | $ | 857,915 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2024-07-31):
[0000889331-24-000161:note_history:29]
|  |  | Three Months Ended June 29, 2024 |  | Three Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 0.8 |  |  | 1.1 |  | 0.1 |  | 2.9 |  |
|  |  | Six Months Ended June 29, 2024 |  | Six Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.4 |  | 0.4 |  | 2.9 |  |  | 2.1 |  | 0.2 |  | 5.6 |  |
|  |  | June 29, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.2 |  | $ | 0.1 |  | $ | 0.2 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |

- removed (2024-07-31):
[0000889331-24-000129:note_history:30]
|  |  | Three Months Ended March 30, 2024 |  | Three Months Ended April 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 2.1 |  |  | 1.0 |  | 0.1 |  | 2.7 |  |
|  |  | March 30, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.8 |  | $ | 0.1 |  | $ | 1.5 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2024-07-31):
[0000889331-24-000161:note_history:31]
|  |  | Three Months Ended June 29, 2024 |  | Three Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 0.8 |  |  | 1.1 |  | 0.1 |  | 2.9 |  |
|  |  | Six Months Ended June 29, 2024 |  | Six Months Ended July 1, 2023 |
| (in millions) |  | Powersem | EB-Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.9 |  | $ | — |  | $ | — |  |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 2.4 |  | 0.4 |  | 2.9 |  |  | 2.1 |  | 0.2 |  | 5.6 |  |
|  |  | June 29, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.2 |  | $ | 0.1 |  | $ | 0.2 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |

- removed (2024-07-31):
[0000889331-24-000129:note_history:32]
|  |  | Three Months Ended March 30, 2024 |  | Three Months Ended April 1, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.2 |  | 0.2 |  | 2.1 |  |  | 1.0 |  | 0.1 |  | 2.7 |  |
|  |  | March 30, 2024 |  | December 30, 2023 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | $ | 0.8 |  | $ | 0.1 |  | $ | 1.5 |  |  | $ | 0.5 |  | $ | — |  | $ | 1.0 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000889331-24-000161:note_history:33]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2024 and July 1, 2023:
  (was, 2024-05-01, similarity 0.9118):
[0000889331-24-000129:note_history:33]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2024 and April 1, 2023:

- added (2024-07-31):
[0000889331-24-000161:note_history:34]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  | — |  |  | — |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

- added (2024-07-31):
[0000889331-24-000161:note_history:35]
|  |  | Three Months Ended July 1, 2023 |  | Six Months Ended July 1, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 197,295 |  |  | $ | — |  |  | $ | — |  |  | $ | 197,295 |  |  | $ | 407,290 |  |  | $ | — |  |  | $ | — |  |  | $ | 407,290 |  |
| Electronics – Passive Products and Sensors |  | 152,852 |  |  | — |  |  | — |  |  | 152,852 |  |  | 301,450 |  |  | — |  |  | — |  |  | 301,450 |  |
| Commercial Vehicle Products |  | — |  |  | 83,329 |  |  | — |  |  | 83,329 |  |  | — |  |  | 167,475 |  |  | — |  |  | 167,475 |  |
| Passenger Car Products |  | — |  |  | 65,883 |  |  | — |  |  | 65,883 |  |  | — |  |  | 127,580 |  |  | — |  |  | 127,580 |  |
| Automotive Sensors |  | — |  |  | 22,836 |  |  | — |  |  | 22,836 |  |  | — |  |  | 43,634 |  |  | — |  |  | 43,634 |  |
| Industrial Products |  | — |  |  | — |  |  | 89,802 |  |  | 89,802 |  |  |  |  |  |  | 174,350 |  |  | 174,350 |  |
| Total |  | $ | 350,147 |  |  | $ | 172,048 |  |  | $ | 89,802 |  |  | $ | 611,997 |  |  | $ | 708,740 |  |  | $ | 338,689 |  |  | $ | 174,350 |  |  | $ | 1,221,779 |  |

- removed (2024-07-31):
[0000889331-24-000129:note_history:36]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |

- removed (2024-07-31):
[0000889331-24-000129:note_history:37]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 209,995 |  |  | $ | — |  |  | $ | — |  |  | $ | 209,995 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,598 |  |  | — |  |  | — |  |  | 148,598 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |
