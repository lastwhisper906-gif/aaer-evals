# LFUS MD&A — 0001437749-17-013580


## mdna

[0001437749-17-013580:mdna:1]
[same as prior period, unchanged from 0001437749-17-007864:mdna:1]

[0001437749-17-013580:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-17-013580:mdna:3]
[same as prior period, unchanged from 0001437749-17-007864:mdna:3]

[0001437749-17-013580:mdna:4]
[same as prior period, unchanged from 0001437749-17-007864:mdna:4]

[0001437749-17-013580:mdna:5]
[same as prior period, unchanged from 0001437749-17-007864:mdna:5]

[0001437749-17-013580:mdna:6]
[same as prior period, unchanged from 0001437749-17-007864:mdna:6]

[0001437749-17-013580:mdna:7]
[same as prior period, unchanged from 0001437749-17-007864:mdna:7]

[0001437749-17-013580:mdna:8]
[same as prior period, unchanged from 0001437749-17-007864:mdna:8]

[0001437749-17-013580:mdna:9]
The Company experienced strong performance improvements in the second quarter of 2017 compared to the second quarter of 2016 and in the first six months of 2017 compared to the first six months of 2016. For the second quarter of 2017, the Company recognized net sales of $313.4 million compared to $271.9 million in the second quarter of 2016. The increase of $41.4 million, or 15%, reflects increased net sales of $37.2 million, or 28%, in the Electronics segment and $5.1 million, or 5%, in the Automotive segment, partially offset by decreased net sales of $0.9 million, or 3%, in the Industrial segment. The increased net sales in the Electronics segment was due to strong growth across all the Electronic segment’s business units as well as the ON Portfolio acquisition in August 2016. The increased net sales in the Automotive segment was primarily due to the impact of growth in the passenger car and commercial vehicle businesses. The Company recognized net income of $48.6 million, or $2.11 per diluted share, in the second quarter of 2017 compared to net income of $27.2 million, or $1.20 per diluted share in the second quarter of 2016. Increased net income reflects the impacts of the prior year acquisitions on the current year results as well as a decrease in acquisition-related costs, coupled with a lower effective tax rate.

[0001437749-17-013580:mdna:10]
For the first six months of 2017, the Company recognized net sales of $598.8 million compared to $491.3 million in the first six months of 2016. The increase of $107.5 million, or 22%, reflects increased net sales of $92.2 million, or 40%, in the Electronics segment and $21.0 million, or 10%, in the Automotive segment, partially offset by decreased net sales of $5.7 million, or 10%, in the Industrial segment. The increased net sales in the Electronics segment was due to strong growth across all the Electronic segment’s business units as well as the ON Portfolio acquisition in August 2016. The increased net sales in the Automotive segment was primarily due to the impact of prior year acquisitions as well as growth in the passenger car and commercial vehicle businesses. The Company recognized net income of $87.5 million, or $3.80 per diluted share, in the first six months of 2017 compared to net income of $46.4 million, or $2.05 per diluted share in the first six months of 2016. Increased net income reflects the impacts of the prior year acquisitions on the current year results as well as a decrease in acquisition-related costs, coupled with a lower effective tax rate.

[0001437749-17-013580:mdna:11]
[same as prior period, unchanged from 0001437749-17-007864:mdna:10]

[0001437749-17-013580:mdna:12]
The following table summarizes the Company’s consolidated results of operations for the periods presented. The second quarter of 2017 includes approximately $0.3 million of non-segment charges ($1.8 million year-to-date).  These were primarily attributable to acquisition-related costs related to legal and integration costs associated with the Company’s acquisition in 2016 of the ON Portfolio.

[0001437749-17-013580:mdna:13]
The second quarter of 2016 includes approximately $14.1 million of other non-segment charges ($23.2 million year-to-date).  These included $6.1 million ($12.3 million year-to-date) of acquisition-related costs primarily related to legal and integration costs associated with the Company’s PolySwitch acquisition, a $6.9 million ($6.9 million year-to-date) non-cash inventory charge relating to the PolySwitch acquisition, $0.3 million ($1.9 million year-to-date) in charges related to the closure of the Company’s manufacturing facility in Denmark, $0.7 million ($1.7 million year-to-date) related to the Company’s transfer of its reed sensor manufacturing operation from the U.S. and China to the Philippines and $0.1 million ($0.4 million year-to-date) related to internal legal restructuring costs.

[0001437749-17-013580:mdna:14]
|  |  | Second Quarter |  |  | First Six Months |  |
|  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Net sales |  | $ | 313,355 |  |  | $ | 271,912 |  |  | $ | 41,443 |  |  |  | 15.2% |  |  | $ | 598,797 |  |  | $ | 491,310 |  |  | $ | 107,487 |  |  |  | 21.9% |  |
| Gross profit |  |  | 132,608 |  |  |  | 97,866 |  |  |  | 34,742 |  |  |  | 35.5% |  |  |  | 246,258 |  |  |  | 185,021 |  |  |  | 61,237 |  |  |  | 33.1% |  |
| Operating expenses |  |  | 72,338 |  |  |  | 68,164 |  |  |  | 4,174 |  |  |  | 6.1% |  |  |  | 137,135 |  |  |  | 122,891 |  |  |  | 14,244 |  |  |  | 11.6% |  |
| Operating income |  |  | 60,270 |  |  |  | 29,702 |  |  |  | 30,568 |  |  |  | 102.9% |  |  |  | 109,123 |  |  |  | 62,130 |  |  |  | 46,993 |  |  |  | 75.6% |  |
| Income before income taxes |  |  | 57,357 |  |  |  | 34,014 |  |  |  | 23,343 |  |  |  | 68.6% |  |  |  | 104,785 |  |  |  | 61,091 |  |  |  | 43,694 |  |  |  | 71.5% |  |
| Income taxes |  |  | 8,719 |  |  |  | 6,862 |  |  |  | 1,857 |  |  |  | 27.1% |  |  |  | 17,255 |  |  |  | 14,650 |  |  |  | 2,605 |  |  |  | 17.8% |  |
| Net income |  | $ | 48,638 |  |  | $ | 27,152 |  |  | $ | 21,486 |  |  |  | 79.1% |  |  | $ | 87,530 |  |  | $ | 46,441 |  |  | $ | 41,089 |  |  |  | 88.5% |  |

[0001437749-17-013580:mdna:15]
[same as prior period, unchanged from 0001437749-17-007864:mdna:14]

[0001437749-17-013580:mdna:16]
Net sales increased $41.4 million, or 15.2%, for the second quarter of 2017 compared to the second quarter of 2016 with $16.6 million resulting from incremental net sales related to the ON Portfolio acquisition in the prior year. Increased net sales in the Electronics segment of $37.2 million and the Automotive segment of $5.1 million were partially offset by a $0.9 million decrease in the Industrial segment.

[0001437749-17-013580:mdna:17]
Net sales for the first six months of 2017 increased $107.5 million, or 21.9% compared to the first six months of 2016, partially due to a $77.4 million increase from the prior year PolySwitch, ON Portfolio, and Menber’s acquisitions. Increased net sales in the Electronics segment of $92.2 million and the Automotive segment of $21.0 million were partially offset by a $5.7 million decrease in the Industrial segment.

[0001437749-17-013580:mdna:18]
[same as prior period, unchanged from 0001437749-17-007864:mdna:16]

[0001437749-17-013580:mdna:19]
Gross profit was $132.6 million, or 42.3% of net sales, in the second quarter of 2017, compared to $97.9 million, or 36.0% of net sales in the second quarter of 2016. The increase in gross profit reflects the incremental net sales and improved leverage in expenses and profits related to the prior year acquisitions.

[0001437749-17-013580:mdna:20]
Gross profit for the first six months of 2017 was $246.3 million, or 41.1% of net sales compared to $185.0 million, or 37.7% of net sales for the first six months of 2016. The increase in gross profit reflects the incremental net sales and improved leverage in expenses and profits related to the prior year acquisitions.

[0001437749-17-013580:mdna:21]
[same as prior period, unchanged from 0001437749-17-007864:mdna:18]

[0001437749-17-013580:mdna:22]
Total operating expense was $72.3 million, or 23.1% of net sales, for the second quarter of 2017 compared to $68.2 million, or 25.1% of net sales, for the second quarter of 2016. The increase in operating expenses of $4.1 million is primarily due to incremental operating expenses related to the prior year acquisitions including increased selling costs and amortization of intangibles. Operating expense in 2016 included $5.2 million of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, $0.2 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines and $0.1 million related to internal legal restructuring costs.

[0001437749-17-013580:mdna:23]
Total operating expense for the first six months of 2017 was $137.1 million, or 22.9% of net sales compared to $122.9 million, or 25.0% of net sales, for the first six months of 2016. The increase in operating expenses of $14.2 million is primarily due to incremental operating expenses related to the prior year acquisitions including increased selling costs and amortization of intangibles. Operating expense in 2016 included $11.4 million of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, $1.4 million in charges related to the closure of the company’s manufacturing facility in Denmark, $0.3 million related to internal legal restructuring costs and $0.2 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines.

[0001437749-17-013580:mdna:24]
[same as prior period, unchanged from 0001437749-17-007864:mdna:20]

[0001437749-17-013580:mdna:25]
Operating income was $60.3 million, or 19.2% of net sales, for the second quarter of 2017 compared to $29.7 million, or 10.9% of net sales, for the second quarter of 2016. The increase in operating income is the result of the above-described increased net sales and associated margins partially offset by increased operating expenses. The improvement in operating income as a percentage of net sales reflects the impact of the prior year acquisitions costs on operating expenses.

[0001437749-17-013580:mdna:26]
Operating income for the first six months of 2017 was $109.1 million, or 18.2% of net sales compared to $62.1 million, or 12.6% of net sales, for the first six months of 2016. The increase in operating income is the result of the above-described increased net sales and associated margins partially offset by increased operating expenses. The improvement in operating income as a percentage of net sales reflects the impact of the prior year acquisitions costs on operating expenses.

[0001437749-17-013580:mdna:27]
[same as prior period, unchanged from 0001437749-17-007864:mdna:22]

[0001437749-17-013580:mdna:28]
Income before income taxes was $57.4 million, or 18.3% of net sales, for the second quarter of 2017 compared to $34.0 million, or 12.5% of net sales, for the second quarter of 2016. In addition to the factors impacting comparative results for operating income, income before income taxes was impacted by a favorable comparative increase in the gross profit as a percentage of sales partially offset by an unfavorable increase in the foreign exchange expense. The effect of foreign exchange rate changes on various foreign currency transactions worldwide was approximately $0.6 million of income for the second quarter of 2017 compared to $6.2 million of income for the second quarter of 2016 and primarily reflects fluctuations in the euro against the U.S. dollar. Interest expense was $3.3 million in the second quarter of 2017 as compared to $1.7 million in the second quarter of 2016, primarily reflecting increased borrowings.

[0001437749-17-013580:mdna:29]
Income before income taxes for the first six months of 2017 was $104.8 million, or 17.5% of net sales compared to $61.1 million, or 12.4% of net sales, for the first six months of 2016. In addition to the factors impacting comparative results for operating income, income before income taxes was impacted by a favorable comparative increase in the gross profit as a percentage of sales partially offset by increased interest expense. The effect of foreign exchange rate changes on various foreign currency transactions worldwide was approximately $2.1 million of income for the first six months of 2017 compared to $2.4 million of income for the first six months of 2016. Interest expense was $6.4 million in the first six months of 2017 as compared to $3.7 million in the first six months of 2016, primarily reflecting increased borrowings.

[0001437749-17-013580:mdna:30]
[same as prior period, unchanged from 0001437749-17-007864:mdna:24]

[0001437749-17-013580:mdna:31]
Income tax expense was $8.7 million, or an effective tax rate of 15.2%, for the second quarter of 2017 compared to income tax expense of $6.9 million, or an effective tax rate of 20.2%, for the second quarter of 2016. The effective tax rates for both the second quarter of 2017 and the second quarter of 2016 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. Further, the effective tax rate for the second quarter of 2017 was lower than the effective tax rate for the second quarter of 2016 primarily due to a larger amount of income earned in lower tax jurisdictions in the second quarter of 2017 compared to the second quarter of 2016, as well as the adoption on January 1, 2017 of ASU No. 2016-09 which resulted in the recognition of $1.4 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense in the second quarter of 2017. Historically, these amounts were recorded as additional paid-in capital.

[0001437749-17-013580:mdna:32]
Income tax expense for the first six months of 2017 was $17.3 million, or an effective tax rate of 16.5% compared to income tax expense of $14.7 million, or an effective tax rate of 24.0%, for the first six months of 2016. The effective tax rates for both the first six months of 2017 and the first six months of 2016 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. Further, the effective tax rate for the first six months of 2017 was lower than the effective tax rate for the first six months of 2016 primarily due to a larger amount of income earned in lower tax jurisdictions in the first six months of 2017 compared to the first six months of 2016 as well as the adoption on January 1, 2017 of ASU No. 2016-09 which resulted in the recognition of $1.9 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the first six months of 2017.

[0001437749-17-013580:mdna:33]
[same as prior period, unchanged from 0001437749-17-007864:mdna:26]

[0001437749-17-013580:mdna:34]
[same as prior period, unchanged from 0001437749-17-007864:mdna:27]

[0001437749-17-013580:mdna:35]
[same as prior period, unchanged from 0001437749-17-007864:mdna:28]

[0001437749-17-013580:mdna:36]
|  |  | Second Quarter |  |  | First Six Months |  |
|  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Electronics |  | $ | 169,387 |  |  | $ | 132,170 |  |  | $ | 37,217 |  |  |  | 28.2% |  |  | $ | 323,154 |  |  | $ | 230,966 |  |  | $ | 92,188 |  |  |  | 39.9% |  |
| Automotive |  |  | 116,457 |  |  |  | 111,370 |  |  |  | 5,087 |  |  |  | 4.6% |  |  |  | 224,297 |  |  |  | 203,303 |  |  |  | 20,994 |  |  |  | 10.3% |  |
| Industrial |  |  | 27,511 |  |  |  | 28,372 |  |  |  | (861 | ) |  |  | (3.0%) |  |  |  | 51,346 |  |  |  | 57,041 |  |  |  | (5,695 | ) |  |  | (10.0%) |  |
| Total |  | $ | 313,355 |  |  | $ | 271,912 |  |  | $ | 41,443 |  |  |  | 15.2% |  |  | $ | 598,797 |  |  | $ | 491,310 |  |  | $ | 107,487 |  |  |  | 21.9% |  |

[0001437749-17-013580:mdna:37]
[same as prior period, unchanged from 0001437749-17-007864:mdna:30]

[0001437749-17-013580:mdna:38]
The Electronics segment net sales increased $37.2 million, or 28%, in the second quarter of 2017 compared to the second quarter of 2016 with incremental net sales related to the ON Portfolio acquisition in the prior year. Excluding the impact of the acquisition, the increased Electronics segment net sales were primarily the result of increased net sales of passive, semiconductor and PolySwitch products.

[0001437749-17-013580:mdna:39]
The Electronics segment net sales increased $92.2 million, or 40%, in the first six months of 2017 compared to the first six months of 2016 primarily due to incremental net sales related to the PolySwitch and ON Portfolio acquisitions in the prior year. Excluding the impact of the acquisitions, the increased Electronics segment net sales were primarily the result of increased net sales across all product lines.

[0001437749-17-013580:mdna:40]
[same as prior period, unchanged from 0001437749-17-007864:mdna:32]

[0001437749-17-013580:mdna:41]
The Automotive segment net sales increased $5.1 million, or 5%, in the second quarter of 2017 compared to the second quarter of 2016 primarily due to increased net sales in the passenger car and commercial vehicle businesses, both of which were partially offset by a decrease in the automotive sensor business. The segment also experienced unfavorable foreign exchange impacts of $1.7 million, primarly related to net sales denominated in euros and Chinese renminbi.

[0001437749-17-013580:mdna:42]
The Automotive segment net sales increased $21.0 million, or 10%, in the first six months of 2017 compared to the first six months of 2016 primarily due to incremental net sales related to the PolySwitch and Menber’s acquisitions in the prior year. The segment also experienced unfavorable foreign exchange impacts of $3.4 million, primarily related to net sales denominated in euros and Chinese renminbi. Excluding the impact of prior year acquisitions and foreign currency, slight increases in net sales of passenger car products and commercial vehicle products were offset by a decrease in sensor net sales.

[0001437749-17-013580:mdna:43]
[same as prior period, unchanged from 0001437749-17-007864:mdna:34]

[0001437749-17-013580:mdna:44]
The Industrial segment net sales decreased $0.9 million, or 3%, in the second quarter of 2017 compared to the second quarter of 2016 primarily due to the divestiture of a non-core product line in the fourth quarter of 2016, and decreased net sales in the custom products operations.

[0001437749-17-013580:mdna:45]
The Industrial segment net sales decreased $5.7 million, or 10%, in the first six months of 2017 compared to the first six months of 2016 primarily due to the divestiture of two non-core product lines, one in the first quarter of 2016 and the other in the fourth quarter of 2016, and decreased net sales in the custom products operations.

[0001437749-17-013580:mdna:46]
[same as prior period, unchanged from 0001437749-17-007864:mdna:36]

[0001437749-17-013580:mdna:47]
[same as prior period, unchanged from 0001437749-17-007864:mdna:37]

[0001437749-17-013580:mdna:48]
|  |  | Second Quarter |  |  | First Six Months |  |
|  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Americas |  | $ | 115,039 |  |  | $ | 107,297 |  |  | $ | 7,742 |  |  |  | 7% |  |  | $ | 213,064 |  |  | $ | 207,120 |  |  | $ | 5,944 |  |  |  | 3% |  |
| Europe |  |  | 60,263 |  |  |  | 54,406 |  |  |  | 5,857 |  |  |  | 11% |  |  |  | 119,168 |  |  |  | 97,219 |  |  |  | 21,949 |  |  |  | 23% |  |
| Asia-Pacific |  |  | 138,053 |  |  |  | 110,209 |  |  |  | 27,844 |  |  |  | 25% |  |  |  | 266,565 |  |  |  | 186,971 |  |  |  | 79,594 |  |  |  | 43% |  |
| Total |  | $ | 313,355 |  |  | $ | 271,912 |  |  | $ | 41,443 |  |  |  | 15% |  |  | $ | 598,797 |  |  | $ | 491,310 |  |  | $ | 107,487 |  |  |  | 22% |  |

[0001437749-17-013580:mdna:49]
[same as prior period, unchanged from 0001437749-17-007864:mdna:39]

[0001437749-17-013580:mdna:50]
Net sales in the Americas increased $7.7 million, or 7%, in the second quarter of 2017 compared to the second quarter of 2016. Increased net sales resulting from acquisitions in 2016 and increased net sales in the semiconductor and passives businesses in the Electronics segment and the passenger car and commercial vehicle businesses in the Automotive segment were partially offset by decreased net sales in the Automotive segment’s sensor products and the divestiture of a non-core product line in our Industrial segment.

[0001437749-17-013580:mdna:51]
Net sales in the Americas increased $5.9 million, or 3%, in the first six months of 2017 compared to the first six months of 2016. Increased net sales resulting from acquisitions in 2016 and increased net sales in the semiconductor and passives businesses in the Electronics segment and the passenger car and commercial vehicle businesses in the Automotive segment were partially offset by decreased net sales in the Automotive segment’s sensor products and the divestiture of a non-core product line in our Industrial segment.

[0001437749-17-013580:mdna:52]
[same as prior period, unchanged from 0001437749-17-007864:mdna:41]

[0001437749-17-013580:mdna:53]
European net sales increased $5.9 million, or 11%, in the second quarter of 2017 compared to the second quarter of 2016 primarily due to incremental net sales related to the ON Portfolio acquisition in the prior year partially offset by $1.5 million in unfavorable currency effects primarily results from sales denominated in euros.

[0001437749-17-013580:mdna:54]
European net sales increased $21.9 million, or 23%, in the first six months of 2017 compared to the first six months of 2016 primarily due to incremental net sales related to prior year acquisitions. There was also $3.2 million in unfavorable currency effects primarily results from sales denominated in euros.

[0001437749-17-013580:mdna:55]
[same as prior period, unchanged from 0001437749-17-007864:mdna:43]

[0001437749-17-013580:mdna:56]
Asia-Pacific net sales increased $27.8 million, or 25%, in the first quarter of 2017 compared to the first quarter of 2016, primarily due to incremental net sales from the prior year ON Portfolio acquisition. The Asia-Pacific net sales increase also reflects increased net sales in all of the Electronics segment’s and Automotive segment’s business units.

[0001437749-17-013580:mdna:57]
Asia-Pacific net sales increased $79.6 million, or 43%, in the first six months of 2017 compared to the first six months of 2016, primarily due to incremental net sales from prior year acquisitions. The Asia-Pacific net sales increase also reflects increased net sales in all of the Electronics segment’s and Automotive segment’s business units.

[0001437749-17-013580:mdna:58]
[same as prior period, unchanged from 0001437749-17-007864:mdna:45]

[0001437749-17-013580:mdna:59]
[same as prior period, unchanged from 0001437749-17-007864:mdna:46]

[0001437749-17-013580:mdna:60]
Revolving Credit Facility/Term Loan

[0001437749-17-013580:mdna:61]
On March 4, 2016, the Company entered into a new five-year credit agreement with a group of lenders for up to $700.0 million. The new credit agreement consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of $1.6 million through March 31, 2018 and $3.1 million from June 30, 2018 through December 31, 2020 with the remaining balance due on March 4, 2021.

[0001437749-17-013580:mdna:62]
Outstanding borrowings under the credit agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.30%, based on the Consolidated Leverage Ratio, as defined. The effective interest rate on outstanding borrowings under the credit facility was 2.72% at July 1, 2017. As of July 1, 2017, the Company had $0.1 million outstanding in letters of credit and had available $574.9 million of borrowing capacity under the revolving credit facility. Further information regarding the Company’s credit agreement is provided in Note 4, Debt, of the Notes to Consolidated Financial Statements included in this Quarterly Report.

[0001437749-17-013580:mdna:63]
[same as prior period, unchanged from 0001437749-17-007864:mdna:50]

[0001437749-17-013580:mdna:64]
[same as prior period, unchanged from 0001437749-17-007864:mdna:51]

[0001437749-17-013580:mdna:65]
[same as prior period, unchanged from 0001437749-17-007864:mdna:52]

[0001437749-17-013580:mdna:66]
[same as prior period, unchanged from 0001437749-17-007864:mdna:53]

[0001437749-17-013580:mdna:67]
|  |  | First Six Months |  |
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Net cash provided by operating activities |  | $ | 93,573 |  |  | $ | 35,276 |  |
| Net cash used in investing activities |  |  | (36,117 | ) |  |  | (374,203 | ) |
| Net cash used in financing activities |  |  | (10,069 | ) |  |  | 188,787 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (618 | ) |  |  | 815 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 46,769 |  |  |  | (149,325 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275,124 |  |  |  | 328,786 |  |
| Cash and cash equivalents at end of period |  | $ | 321,893 |  |  | $ | 179,461 |  |

[0001437749-17-013580:mdna:68]
[same as prior period, unchanged from 0001437749-17-007864:mdna:55]

[0001437749-17-013580:mdna:69]
Net cash provided by operating activities was $93.6 million for the first six months of 2017 reflecting $87.5 million in net income and $43.3 million in non-cash adjustments (primarily $30.7 million in depreciation and amortization) offset by $37.2 million in net changes to various operating assets and liabilities.

[0001437749-17-013580:mdna:70]
Changes in operating assets and liabilities for the first six months of 2017 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivable ($32.0 million), inventory ($8.7 million) and decreases in accrued payroll and severance ($13.2 million). The increase in accounts receivable was due to increased net sales in the first six months of 2017. The decrease in accrued payroll and severance was due primarily to payouts for the 2016 management incentive plan which occurred in the first quarter. Changes having a positive impact on cash flows were increases in accounts payable ($8.0 million), accrued expenses ($3.9 million), accrued and deferred taxes ($0.5 million) and decreases in prepaid and other assets ($4.3 million).

[0001437749-17-013580:mdna:71]
[same as prior period, unchanged from 0001437749-17-007864:mdna:58]

[0001437749-17-013580:mdna:72]
Net cash used in investing activities was $36.1 million and primarily related to the acquisition of the Monolith business ($14.2 million), net of cash acquired, and capital expenditures ($28.2 million) both of which were partially offset by proceeds from maturities of short-term investments ($3.7 million), a decrease in the entrusted loan ($2.4 million) and proceeds from the sale of other assets, net ($0.2 million). The decrease in cash used in investing activities is due to cash used in the acquisition of PolySwitch in the first quarter of 2016.

[0001437749-17-013580:mdna:73]
[same as prior period, unchanged from 0001437749-17-007864:mdna:60]

[0001437749-17-013580:mdna:74]
Net cash used in financing activities was $10.1 million and included dividends paid of $15.0 million and $2.1 million from the exercise of stock options including tax benefits both of which were partially offset by $7.0 million in net proceeds on borrowings. The decrease in cash provided by financing activities is due to the Company entering into the new credit agreement and term loan credit facility in the first quarter of 2016.

[0001437749-17-013580:mdna:75]
[same as prior period, unchanged from 0001437749-17-007864:mdna:62]

[0001437749-17-013580:mdna:76]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2017 to April 30, 2018 (“Share Repurchase Program”). The Company did not repurchase any shares of its common stock during the second quarter of 2017.

[0001437749-17-013580:mdna:77]
[same as prior period, unchanged from 0001437749-17-007864:mdna:64]

[0001437749-17-013580:mdna:78]
As of July 1, 2017, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-17-013580:mdna:79]
[same as prior period, unchanged from 0001437749-17-007864:mdna:66]

[0001437749-17-013580:mdna:80]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers" (Topic 606) which supersedes the revenue recognition requirements in ASC 605, "Revenue Recognition." This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. In August, 2015, the FASB issued ASU No. 2015-14, which postponed the effective date of ASU No. 2014-09 to fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted on the original effective date of fiscal years beginning after December 15, 2016. The Company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements, and currently anticipates adopting this standard using the modified retrospective method. While the Company is currently assessing the impact of the new standards, the Company’s revenue is primarily generated from the sale of finished products to customers. Sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does not expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects may be affected. The Company has not yet quantified this potential impact.

[0001437749-17-013580:mdna:81]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company is currently evaluating the impact of this ASU on its consolidated financial statements.

[0001437749-17-013580:mdna:82]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles-Goodwill and Other” (Topic 350). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity no longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 2 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after December 15, 2020, with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company expects to adopt the new standard in 2017.

[0001437749-17-013580:mdna:83]
[same as prior period, unchanged from 0001437749-17-007864:mdna:70]

[0001437749-17-013580:mdna:84]
[same as prior period, unchanged from 0001437749-17-007864:mdna:71]

[0001437749-17-013580:mdna:85]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 31, 2016. During the three months ended July 1, 2017, there were no significant changes in the application of critical accounting policies.
