# LFUS note change history — 0001437749-17-007864 → 0001437749-17-013580


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0001437749-17-013580:note_history:1]
Littelfuse, Inc. and subsidiaries (the “
Company”) design, manufacture, and sell circuit protection devices for use in the automotive, electronics, and industrial markets throughout the world. The Company is 
one
 of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.
  (was, 2017-05-03, similarity 0.9996):
[0001437749-17-007864:note_history:1]
Littelfuse, Inc. and subsidiaries (the “Company”) design, manufacture, and sell circuit protection devices for use in the automotive, electronics, and industrial markets throughout the world. The Company is 
one
 of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.

- changed (2017-08-02):
[0001437749-17-013580:note_history:2]
The 
Company’s accompanying unaudited Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December
  (was, 2017-05-03, similarity 0.9994):
[0001437749-17-007864:note_history:2]
The Company’s accompanying unaudited Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

- added (2017-08-02):
[0001437749-17-013580:note_history:3]
Certain reclassifications of prior year amounts for 
Trade receivables, net
 and

- added (2017-08-02):
[0001437749-17-013580:note_history:4]
Prepaid expenses and other current assets
 were made to conform to the 
2017
 presentation.

- changed (2017-08-02):
[0001437749-17-013580:note_history:5]
Factors the 
Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does 
not
 believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the Relays reporting unit if there are declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October 2, 2016, 
the Company concluded the fair value of the Relays reporting unit exceeded its carrying value of invested capital and therefore, 
no
 potential goodwill impairment existed. As of the 
2016
 annual test date, the Relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 July 1, 2017, 
there were 
no
 events or circumstances that indicate the Relays intangible assets were impaired.
  (was, 2017-05-03, similarity 0.77):
[0001437749-17-007864:note_history:5]
Factors the Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does not believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the relays reporting unit if there are declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October

- added (2017-08-02):
[0001437749-17-013580:note_history:6]
In 
 July 2015, 
the Financial Accounting Standards Board (
“FASB”) issued Accounting Standards Update (“ASU”) 
No.

- changed (2017-08-02):
[0001437749-17-013580:note_history:7]
2015
-
11
 – “Inventory (Topic 
330
): Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
The adoption of the update did 
not
 have a material impact on the Company’s consolidated financial statements. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.
  (was, 2017-05-03, similarity 0.7554):
[0001437749-17-007864:note_history:7]
2017.
 The adoption of the update did not have a material impact on the Company’s consolidated financial statements. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

- added (2017-08-02):
[0001437749-17-013580:note_history:8]
In 
 March 2016, 
the FASB issued ASU 
No.

- added (2017-08-02):
[0001437749-17-013580:note_history:9]
2016
-
09

- added (2017-08-02):
[0001437749-17-013580:note_history:10]
– “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
As a result of the adoption, on a prospective basis, the Company recognized 
$1.4
 million and 
$1.9
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 and 
six
 months ended 
 July 1, 2017, 
respectively. Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Consolidated Statement of Cash Flows. The Company elected 
not
 to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had 
no
 impact on the results of operations.

- added (2017-08-02):
[0001437749-17-013580:note_history:11]
In 
 May 2014, 
the FASB issued ASU 
No.

- changed (2017-08-02):
[0001437749-17-013580:note_history:12]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August, 2015, 
the FASB issued ASU 
No.
  (was, 2017-05-03, similarity 0.9576):
[0001437749-17-007864:note_history:12]
2014,
 the FASB issued ASU No. 
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606)
 which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August,

- added (2017-08-02):
[0001437749-17-013580:note_history:13]
2015
-
14,
 which postponed the effective date of ASU 
No.

- added (2017-08-02):
[0001437749-17-013580:note_history:14]
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted on the original effective date of fiscal years beginning after 
 December 15, 2016. 
The Company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements, and currently anticipates adopting this standard using the modified retrospective method. While the Company is currently assessing the impact of the new standards, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does 
not
 expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may 
be affected. The Company has 
not
 yet quantified this potential impact.

- added (2017-08-02):
[0001437749-17-013580:note_history:15]
In 
 February 2016, 
the FASB issued ASU 
No.

- changed (2017-08-02):
[0001437749-17-013580:note_history:16]
2016
-
02,
 "Leases" (Topic 
842
). This
 ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company is currently evaluating the impact of this ASU on its consolidated financial statements.
  (was, 2017-05-03, similarity 0.7633):
[0001437749-17-007864:note_history:16]
2016,
 the FASB issued ASU No. 
2016
-
02,
 "Leases" (Topic 
842).
 This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December

- added (2017-08-02):
[0001437749-17-013580:note_history:17]
In 
 January 2017, 
the FASB issued ASU 
No.

- changed (2017-08-02):
[0001437749-17-013580:note_history:18]
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350
). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity 
no
 longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December 15, 2020, 
with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January 1, 2017.
  (was, 2017-05-03, similarity 0.9128):
[0001437749-17-007864:note_history:18]
2017,
 the FASB issued ASU No. 
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350).
 This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity no longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December

- changed (2017-08-02):
[0001437749-17-013580:note_history:19]
The Company expects to adopt the new standard in 
2017.
  (was, 2017-05-03, similarity 0.9804):
[0001437749-17-007864:note_history:19]
2017.
 The Company expects to adopt the new standard in 
2017.

- removed (2017-08-02):
[0001437749-17-007864:note_history:20]
2,

- removed (2017-08-02):
[0001437749-17-007864:note_history:21]
2016,
 the Company concluded the fair value of the relays reporting unit exceeded its carrying value of invested capital and therefore, no potential goodwill impairment existed. As of the 
2016
 annual test date, the relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 April

- removed (2017-08-02):
[0001437749-17-007864:note_history:22]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:23]
2017,
 there were no events or circumstances that indicate the Relays intangible assets were impaired.

- removed (2017-08-02):
[0001437749-17-007864:note_history:24]
In 
 July

- removed (2017-08-02):
[0001437749-17-007864:note_history:25]
2015,
 the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 
2015
-
11
 – “Inventory (Topic 
330):
 Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:26]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:27]
2016,
 and interim periods within those fiscal years. The Company adopted the new standard on 
 January

- removed (2017-08-02):
[0001437749-17-007864:note_history:28]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:29]
In 
 March

- removed (2017-08-02):
[0001437749-17-007864:note_history:30]
2016,
 the FASB issued ASU No. 
2016
-
09
 – “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:31]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:32]
2016,
 and interim periods within those fiscal years. The Company adopted the new standard on 
 January

- removed (2017-08-02):
[0001437749-17-007864:note_history:33]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:34]
2017.
 As a result of the adoption, on a prospective basis, the Company recognized 
$0.5
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 months ended 
 April

- removed (2017-08-02):
[0001437749-17-007864:note_history:35]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:36]
2017.
 Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Consolidated Statement of Cash Flows. The Company elected not to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had no impact on the results of operations.

- removed (2017-08-02):
[0001437749-17-007864:note_history:37]
In 
 May

- removed (2017-08-02):
[0001437749-17-007864:note_history:38]
2015,
 the FASB issued ASU No. 
2015
-
14,
 which postponed the effective date of ASU No. 
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:39]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:40]
2017,
 with early adoption permitted on the original effective date of fiscal years beginning after 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:41]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:42]
2016.
 The Company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements and has not concluded on its adoption methodology. While the Company is currently assessing the impact of the new standards, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does not expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may
 be affected. The Company has not yet quantified this potential impact.

- removed (2017-08-02):
[0001437749-17-007864:note_history:43]
In 
 February

- removed (2017-08-02):
[0001437749-17-007864:note_history:44]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:45]
2018,
 with early adoption permitted. Adoption will require a modified retrospective transition. The Company is currently evaluating the impact of this ASU on its consolidated financial statements.

- removed (2017-08-02):
[0001437749-17-007864:note_history:46]
In 
 January

- removed (2017-08-02):
[0001437749-17-007864:note_history:47]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:48]
2020,
 with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January

- removed (2017-08-02):
[0001437749-17-007864:note_history:49]
1,


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0001437749-17-013580:note_history:50]
The carrying amounts of debt at
  (was, 2017-05-03, similarity 0.9118):
[0001437749-17-007864:note_history:50]
The carrying amounts of debt at 
 April

- added (2017-08-02):
[0001437749-17-013580:note_history:51]
July 1, 2017 
and 
 December 31, 2016 
are as follows:

- changed (2017-08-02):
[0001437749-17-013580:note_history:52]
| (in thousands) |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 117,188 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 1,179 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 133,497 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 108,395 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,567 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 481,692 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (7,813 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 473,879 |  |  | $ | 447,892 |  |
  (was, 2017-05-03, similarity 0.9926):
[0001437749-17-007864:note_history:52]
| (in thousands) |  | April 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 118,750 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 2,903 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 125,616 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 101,996 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,742 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 470,523 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 464,273 |  |  | $ | 447,892 |  |

- changed (2017-08-02):
[0001437749-17-013580:note_history:53]
On 
 March 4, 2016, 
the 
Company entered into a new 
five
 year credit agreement with a group of lenders for up to 
$700.0
 million. The new credit agreement consists of an unsecured revolving credit facility of 
$575.0
 million and an unsecured term loan credit facility of up to 
$125.0
 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.
  (was, 2017-05-03, similarity 0.928):
[0001437749-17-007864:note_history:53]
2016,
 the Company entered into a new 
five
 year credit agreement with a group of lenders for up to 
$700.0
 million. The new credit agreement consists of an unsecured revolving credit facility of 
$575.0
 million and an unsecured term loan credit facility of up to 
$125.0
 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of 
$1.6
 million through 
 March

- added (2017-08-02):
[0001437749-17-013580:note_history:54]
Outstanding borrowings under the credit agreement bear interest, at the 
Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.72%
 at 
 July 1, 2017.

- changed (2017-08-02):
[0001437749-17-013580:note_history:55]
As of
  (was, 2017-05-03, similarity 0.625):
[0001437749-17-007864:note_history:55]
As of 
 April

- changed (2017-08-02):
[0001437749-17-013580:note_history:56]
July 1, 2017, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$574.9
 million of borrowing capacity under the revolving credit facility. At 
 July 1, 2017, 
the Company was in compliance with all covenants under the credit agreement.
  (was, 2017-05-03, similarity 0.7643):
[0001437749-17-007864:note_history:56]
2017,
 the Company had 
$0.1
 million outstanding in letters of credit and had available 
$574.9
 million of borrowing capacity under the revolving credit facility. At 
 April

- changed (2017-08-02):
[0001437749-17-013580:note_history:57]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023, 
and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.
  (was, 2017-05-03, similarity 0.6025):
[0001437749-17-007864:note_history:57]
2016,
 the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December

- changed (2017-08-02):
[0001437749-17-013580:note_history:58]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February 15, 2017,
  (was, 2017-05-03, similarity 0.9524):
[0001437749-17-007864:note_history:58]
2016,
 the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February

- changed (2017-08-02):
[0001437749-17-013580:note_history:59]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022, 
and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.
  (was, 2017-05-03, similarity 0.6327):
[0001437749-17-007864:note_history:59]
2027
 (together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on 
 February

- changed (2017-08-02):
[0001437749-17-013580:note_history:60]
The Senior Notes are subject to certain customary covenants, including limitations on the 
Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 July 1, 2017, 
the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.
  (was, 2017-05-03, similarity 0.8923):
[0001437749-17-007864:note_history:60]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 April

- changed (2017-08-02):
[0001437749-17-013580:note_history:61]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the Company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with 
no
 net impact on the Company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in 
 November 2019. 
The balance of the Entrusted Loan was
  (was, 2017-05-03, similarity 0.9819):
[0001437749-17-007864:note_history:61]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the Company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the Company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in 
 November

- changed (2017-08-02):
[0001437749-17-013580:note_history:62]
Chinese renminbi 
8.0
 million (approximately U.S. 
$1.2
 million) at 
 July 1, 2017.
  (was, 2017-05-03, similarity 0.9197):
[0001437749-17-007864:note_history:62]
Chinese renminbi 
20.0
 million (approximately U.S. 
$2.9
 million) at 
 April

- removed (2017-08-02):
[0001437749-17-007864:note_history:63]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:64]
2017
 and 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:65]
31,

- removed (2017-08-02):
[0001437749-17-007864:note_history:66]
2016
 are as follows:

- removed (2017-08-02):
[0001437749-17-007864:note_history:67]
On 
 March

- removed (2017-08-02):
[0001437749-17-007864:note_history:68]
4,

- removed (2017-08-02):
[0001437749-17-007864:note_history:69]
31,

- removed (2017-08-02):
[0001437749-17-007864:note_history:70]
2018
 and 
$3.1
 million from 
 June

- removed (2017-08-02):
[0001437749-17-007864:note_history:71]
30,

- removed (2017-08-02):
[0001437749-17-007864:note_history:72]
2018
 through 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:73]
31,

- removed (2017-08-02):
[0001437749-17-007864:note_history:74]
2020
 with the remaining balance due on 
 March

- removed (2017-08-02):
[0001437749-17-007864:note_history:75]
4,

- removed (2017-08-02):
[0001437749-17-007864:note_history:76]
2021.

- removed (2017-08-02):
[0001437749-17-007864:note_history:77]
Outstanding borrowings under the credit agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of 
one,

- removed (2017-08-02):
[0001437749-17-007864:note_history:78]
two,

- removed (2017-08-02):
[0001437749-17-007864:note_history:79]
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.48%
 at 
 April

- removed (2017-08-02):
[0001437749-17-007864:note_history:80]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:81]
2017.

- removed (2017-08-02):
[0001437749-17-007864:note_history:82]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:83]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:84]
2017,
 the Company was in compliance with all covenants under the credit agreement.

- removed (2017-08-02):
[0001437749-17-007864:note_history:85]
On 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:86]
8,

- removed (2017-08-02):
[0001437749-17-007864:note_history:87]
8,

- removed (2017-08-02):
[0001437749-17-007864:note_history:88]
2016
 for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:89]
8,

- removed (2017-08-02):
[0001437749-17-007864:note_history:90]
2023,
 and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:91]
8,

- removed (2017-08-02):
[0001437749-17-007864:note_history:92]
2028
 (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June

- removed (2017-08-02):
[0001437749-17-007864:note_history:93]
8
 and 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:94]
8,
 commencing 
 June

- removed (2017-08-02):
[0001437749-17-007864:note_history:95]
8,

- removed (2017-08-02):
[0001437749-17-007864:note_history:96]
2017.

- removed (2017-08-02):
[0001437749-17-007864:note_history:97]
On 
 December

- removed (2017-08-02):
[0001437749-17-007864:note_history:98]
8,

- removed (2017-08-02):
[0001437749-17-007864:note_history:99]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:100]
2017,

- removed (2017-08-02):
[0001437749-17-007864:note_history:101]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February

- removed (2017-08-02):
[0001437749-17-007864:note_history:102]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:103]
2022,
 and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February

- removed (2017-08-02):
[0001437749-17-007864:note_history:104]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:105]
15
 and 
 August

- removed (2017-08-02):
[0001437749-17-007864:note_history:106]
15,
 commencing 
 August

- removed (2017-08-02):
[0001437749-17-007864:note_history:107]
15,

- removed (2017-08-02):
[0001437749-17-007864:note_history:108]
2017.

- removed (2017-08-02):
[0001437749-17-007864:note_history:109]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:110]
2017,
 the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.

- removed (2017-08-02):
[0001437749-17-007864:note_history:111]
2019.
 The balance of the Entrusted Loan was

- removed (2017-08-02):
[0001437749-17-007864:note_history:112]
1,

- removed (2017-08-02):
[0001437749-17-007864:note_history:113]
2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0001437749-17-013580:note_history:114]
| (in thousands) |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 117,188 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 1,179 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 133,497 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 108,395 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,567 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 481,692 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (7,813 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 473,879 |  |  | $ | 447,892 |  |
  (was, 2017-05-03, similarity 0.9926):
[0001437749-17-007864:note_history:114]
| (in thousands) |  | April 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 118,750 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 2,903 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 125,616 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 101,996 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,742 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 470,523 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 464,273 |  |  | $ | 447,892 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-08-02):
[0001437749-17-013580:note_history:115]
11

- added (2017-08-02):
[0001437749-17-013580:note_history:116]
) Subsequent Event

- added (2017-08-02):
[0001437749-17-013580:note_history:117]
On

- added (2017-08-02):
[0001437749-17-013580:note_history:118]
July 6, 2017, 
the company completed the acquisition of U.S. Sensor Corp. headquartered in California. The purchase price of 
$24.0
 million is subject to a working capital adjustment and was financed primarily by cash on hand. The acquired business, which will be part of the company's Electronics segment, will contribute to the expansion of the Company’s existing sensor platform portfolio with a range of high-quality temperature sensor products.
