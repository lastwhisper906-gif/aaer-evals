# LFUS notes — 0001437749-17-013580


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-17-013580:notes:1]
[same as prior period, unchanged from 0001437749-17-007864:notes:1]

[0001437749-17-013580:notes:2]
The 
Company’s accompanying unaudited Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

[0001437749-17-013580:notes:3]
[same as prior period, unchanged from 0001437749-17-007864:notes:3]

[0001437749-17-013580:notes:4]
[same as prior period, unchanged from 0001437749-17-007864:notes:4]

[0001437749-17-013580:notes:5]
In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are 
not
 necessarily indicative of annual operating results.

[0001437749-17-013580:notes:6]
Certain reclassifications of prior year amounts for 
Trade receivables, net
 and

[0001437749-17-013580:notes:7]
Prepaid expenses and other current assets
 were made to conform to the 
2017
 presentation.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-17-013580:notes:8]
| (in thousands) |  | Three Months Ended July 2, 2016 |  |  | Six Months Ended July 2, 2016 |  |
| Net sales |  | $ | 286,975 |  |  | $ | 555,750 |  |
| Income before income taxes |  |  | 44,140 |  |  |  | 78,222 |  |
| Net income |  |  | 36,191 |  |  |  | 63,700 |  |
| Net income — basic |  |  | 1.61 |  |  |  | 2.83 |  |
| Net income — diluted |  |  | 1.60 |  |  |  | 2.81 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-013580:notes:9]
4

[0001437749-17-013580:notes:10]
. Debt

[0001437749-17-013580:notes:11]
The carrying amounts of debt at

[0001437749-17-013580:notes:12]
July 1, 2017 
and 
 December 31, 2016 
are as follows:

[0001437749-17-013580:notes:13]
| (in thousands) |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | — |  |  | $ | 112,500 |  |
| Term loan |  |  | 117,188 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | 1,179 |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 133,497 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 108,395 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,567 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 481,692 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (7,813 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 473,879 |  |  | $ | 447,892 |  |

[0001437749-17-013580:notes:14]
Revolving Credit Facility / Term Loan

[0001437749-17-013580:notes:15]
On 
 March 4, 2016, 
the 
Company entered into a new 
five
 year credit agreement with a group of lenders for up to 
$700.0
 million. The new credit agreement consists of an unsecured revolving credit facility of 
$575.0
 million and an unsecured term loan credit facility of up to 
$125.0
 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.

[0001437749-17-013580:notes:16]
Outstanding borrowings under the credit agreement bear interest, at the 
Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.72%
 at 
 July 1, 2017.

[0001437749-17-013580:notes:17]
As of

[0001437749-17-013580:notes:18]
July 1, 2017, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$574.9
 million of borrowing capacity under the revolving credit facility. At 
 July 1, 2017, 
the Company was in compliance with all covenants under the credit agreement.

[0001437749-17-013580:notes:19]
Senior Notes

[0001437749-17-013580:notes:20]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023, 
and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.

[0001437749-17-013580:notes:21]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February 15, 2017,

[0001437749-17-013580:notes:22]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022, 
and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

[0001437749-17-013580:notes:23]
The Senior Notes have 
not
 been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the 
Company.

[0001437749-17-013580:notes:24]
The Senior Notes are subject to certain customary covenants, including limitations on the 
Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 July 1, 2017, 
the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.

[0001437749-17-013580:notes:25]
The 
Company 
 may 
redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001437749-17-013580:notes:26]
Entrusted Loan

[0001437749-17-013580:notes:27]
During 
2014,
 the 
Company entered into an entrusted loan arrangement (“Entrusted Loan”) of

[0001437749-17-013580:notes:28]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the Company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with 
no
 net impact on the Company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in 
 November 2019. 
The balance of the Entrusted Loan was

[0001437749-17-013580:notes:29]
Chinese renminbi 
8.0
 million (approximately U.S. 
$1.2
 million) at 
 July 1, 2017.


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-013580:notes:30]
[same as prior period, unchanged from 0001437749-17-007864:notes:56]

[0001437749-17-013580:notes:31]
[same as prior period, unchanged from 0001437749-17-007864:notes:57]

[0001437749-17-013580:notes:32]
[same as prior period, unchanged from 0001437749-17-007864:notes:58]

[0001437749-17-013580:notes:33]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands, except per share amounts) |  | July 1, 2017 |  |  | July 2, 2016 |  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 48,638 |  |  | $ | 27,152 |  |  | $ | 87,530 |  |  | $ | 46,441 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,822 |  |  |  | 22,528 |  |  |  | 22,785 |  |  |  | 22,483 |  |
| Effect of dilutive securities |  |  | 201 |  |  |  | 146 |  |  |  | 220 |  |  |  | 164 |  |
| Diluted |  |  | 23,023 |  |  |  | 22,674 |  |  |  | 23,005 |  |  |  | 22,647 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.13 |  |  | $ | 1.21 |  |  | $ | 3.84 |  |  | $ | 2.07 |  |
| Diluted earnings per share |  | $ | 2.11 |  |  | $ | 1.20 |  |  | $ | 3.80 |  |  | $ | 2.05 |  |

[0001437749-17-013580:notes:34]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were

[0001437749-17-013580:notes:35]
46,100
 and 
60,491
 for the 
three
 months ended 
 July 1, 2017 
and 
 July 2, 2016, 
respectively, and 
21,896
 and 
36,699
 for the 
six
 months ended 
 July 1, 2017 
and 
 July 2, 2016, 
respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-17-013580:notes:36]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 11,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,916 |  |

[0001437749-17-013580:notes:37]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,435 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001437749-17-013580:notes:38]
|  |  | July 1, 2017 |  |  | December 31, 2016 |  |
| (in thousands) |  | Carrying Value |  |  | Estimated Fair Value |  |  | Carrying Value |  |  | Estimated Fair Value |  |
| Euro Senior Notes, Series A due 2023 |  | $ | 133,497 |  |  | $ | 132,037 |  |  | $ | 122,313 |  |  | $ | 122,586 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 108,395 |  |  |  | 105,505 |  |  |  | 99,314 |  |  |  | 99,230 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 24,928 |  |  |  | — |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 99,890 |  |  |  | — |  |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-17-013580:notes:39]
[same as prior period, unchanged from 0001437749-17-007864:notes:67]

[0001437749-17-013580:notes:40]
[same as prior period, unchanged from 0001437749-17-007864:notes:68]

[0001437749-17-013580:notes:41]
[same as prior period, unchanged from 0001437749-17-007864:notes:69]

[0001437749-17-013580:notes:42]
Level 
1

[0001437749-17-013580:notes:43]
—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0001437749-17-013580:notes:44]
Level 
2

[0001437749-17-013580:notes:45]
—Valuations based upon quoted prices for 
similar
 instruments, prices for identical or similar instruments in markets that are 
not
 active, or model-derived valuations, all of whose significant inputs are observable, and

[0001437749-17-013580:notes:46]
Level 
3

[0001437749-17-013580:notes:47]
—

[0001437749-17-013580:notes:48]
[same as prior period, unchanged from 0001437749-17-007864:notes:73]

[0001437749-17-013580:notes:49]
[same as prior period, unchanged from 0001437749-17-007864:notes:74]

[0001437749-17-013580:notes:50]
[same as prior period, unchanged from 0001437749-17-007864:notes:75]

[0001437749-17-013580:notes:51]
[same as prior period, unchanged from 0001437749-17-007864:notes:76]

[0001437749-17-013580:notes:52]
Investments in equity securities listed on a national market or exchange are valued at the last sales price
 and are classified within Level 
1
 of the valuation hierarchy.

[0001437749-17-013580:notes:53]
There were 
no
 changes during 
the quarter ended 
 July 1, 2017 
to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of 
 July 1, 2017 
and 
 December 31, 2016, 
the Company did

[0001437749-17-013580:notes:54]
not

[0001437749-17-013580:notes:55]
hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-17-013580:notes:56]
The following table presents assets measured at fair value by classification within the fair value hierarchy
 as of 
 July 1, 2017:

[0001437749-17-013580:notes:57]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of

[0001437749-17-013580:notes:58]
December 31, 2016:

[0001437749-17-013580:notes:59]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are 
not
 marked to market on a recurring basis. 
The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at 
 July 1, 2017 
and 
 December 31, 2016, 
as the rates on these borrowings are variable in nature.

[0001437749-17-013580:notes:60]
The 
carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of 
 July 1, 2017 
and 
 December 31, 2016 
are as follows:


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001437749-17-013580:notes:61]
Goodwill and Indefinite-Lived Intangible Assets

[0001437749-17-013580:notes:62]
The 
Company annually tests goodwill and indefinite-lived intangible assets for impairment on the 
first
 day of its fiscal 
fourth
 quarter or at other dates if there is an event or change in circumstances that indicates the asset 
 may 
be impaired. Management determines the fair value of each of its reporting units by using a discounted cash flow model (which includes forecasted 
five
-year income statement and working capital projections, a market-based weighted average cost of capital and terminal values after 
five
 years) to estimate market value. In addition, the Company compares its derived enterprise value on a consolidated basis to the Company’s market capitalization as of its test date to ensure its derived value approximates the market value of the Company when taken as a whole.

[0001437749-17-013580:notes:63]
Factors the 
Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does 
not
 believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the Relays reporting unit if there are declines in profitability or projected future operating results due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October 2, 2016, 
the Company concluded the fair value of the Relays reporting unit exceeded its carrying value of invested capital and therefore, 
no
 potential goodwill impairment existed. As of the 
2016
 annual test date, the Relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 July 1, 2017, 
there were 
no
 events or circumstances that indicate the Relays intangible assets were impaired.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-013580:notes:64]
[same as prior period, unchanged from 0001437749-17-007864:notes:89]

[0001437749-17-013580:notes:65]
The effective tax rate
s for the 
three
 and 
six
 months ended 
 July 1, 2017 
was 
15.2%
 and 
16.5%,
 respectively, compared to effective tax rates for the 
three
 and 
six
 months ended 
 July 2, 2016 
of 
20.2%
 and 
24.0%,
 respectively. The effective tax rates for all periods are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. Further, the effective tax rate for the 
second
 quarter of 
2017
 was lower than the effective tax rate for the 
second
 quarter of 
2016
 primarily due to a larger amount of income earned in lower tax jurisdictions in the 
second
 quarter of 
2017
 compared to the 
second
 quarter of 
2016
 as well as the adoption on 
 January 1, 2017 
of ASU 
No.

[0001437749-17-013580:notes:66]
2016
-
09
 which resulted in the recognition of 
$1.4
 million and 
$1.9
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 and 
six
 months ended 
 July 1, 2017, 
respectively. Historically, these amounts were recorded as additional paid-in capital.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-17-013580:notes:67]
[same as prior period, unchanged from 0001437749-17-007864:notes:91]

[0001437749-17-013580:notes:68]
[same as prior period, unchanged from 0001437749-17-007864:notes:92]

[0001437749-17-013580:notes:69]
The components of inventories at

[0001437749-17-013580:notes:70]
| (in thousands) |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Raw materials |  | $ | 36,104 |  |  | $ | 32,231 |  |
| Work in process |  |  | 26,576 |  |  |  | 23,354 |  |
| Finished goods |  |  | 62,560 |  |  |  | 58,478 |  |
| Total |  | $ | 125,240 |  |  | $ | 114,063 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-17-013580:notes:71]
[same as prior period, unchanged from 0001437749-17-007864:notes:95]

[0001437749-17-013580:notes:72]
[same as prior period, unchanged from 0001437749-17-007864:notes:96]

[0001437749-17-013580:notes:73]
The 
Company accounts for acquisitions using the acquisition method in accordance with ASC 
805,
 “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s consolidated financial statements from the date of the acquisition.

[0001437749-17-013580:notes:74]
[same as prior period, unchanged from 0001437749-17-007864:notes:98]

[0001437749-17-013580:notes:75]
In 
 December 2015, 
the 
Company invested 
$3.5
 million in the preferred stock of Monolith Semiconductor Inc. (“Monolith”), a U.S. start-up company developing silicon carbide technology, which represented approximately 
12%
 of the common stock of Monolith on an as-converted basis. The Company accounted for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was 
$3.5
 million at 
 December 31, 2016.

[0001437749-17-013580:notes:76]
On 
 February 28, 2017, 
pursuant to a Securities Purchase Agreement between the 
Company and the stockholders of Monolith and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired approximately 
62%
 of the outstanding common stock of Monolith for 
$15
 million. The Securities Purchase Agreement includes provisions whereby the Company will acquire the remaining outstanding stock of Monolith (“non-controlling interest”) at a time or times based on Monolith meeting certain technical and sales targets. Consideration for the additional investment(s) will range from 
$1.0
 million to 
$10
 million and will be paid 
no
 later than 
 June 30, 2019.

[0001437749-17-013580:notes:77]
The additional investment resulted in the 
Company gaining control of Monolith and was accounted for as a step-acquisition with the fair value of the original investment immediately before the acquisition estimated to be approximately 
$3.5
 million. As the fair value of the investment immediately prior to the transaction equaled the carrying value, there was 
no
 impact on the Company’s consolidated statement of net income. As the Securities Purchase Agreement includes an obligation of the Company to mandatorily redeem the non-controlling interest for cash, the fair value of the non-controlling interest was recognized as a liability on the Company’s consolidated balance sheet. Changes in the fair value of the non-controlling interest are recognized in the Company’s consolidated statements of net income.

[0001437749-17-013580:notes:78]
Commencing 
 March 1, 2017, 
Monolith was reflected as a consolidated subsidiary within the 
Company’s consolidated financial statements. Had the acquisition occurred as of 
 January

[0001437749-17-013580:notes:79]
1,

[0001437749-17-013580:notes:80]
2017,
 the impact on the Company’s consolidated results of operations would 
not
 have been material.

[0001437749-17-013580:notes:81]
[same as prior period, unchanged from 0001437749-17-007864:notes:109]

[0001437749-17-013580:notes:82]
[same as prior period, unchanged from 0001437749-17-007864:notes:110]

[0001437749-17-013580:notes:83]
All 
Monolith goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Monolith’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-17-013580:notes:84]
[same as prior period, unchanged from 0001437749-17-007864:notes:112]

[0001437749-17-013580:notes:85]
On 
 August 29, 2016, 
the 
Company acquired certain assets of select businesses (the “ON Portfolio”) of ON Semiconductor Corporation for 
$104.0
 million. The Company funded the acquisition with available cash and proceeds from its credit facility

[0001437749-17-013580:notes:86]
[same as prior period, unchanged from 0001437749-17-007864:notes:116]

[0001437749-17-013580:notes:87]
[same as prior period, unchanged from 0001437749-17-007864:notes:117]

[0001437749-17-013580:notes:88]
The following table summarizes 
the purchase price allocation of the fair value of assets acquired and liabilities assumed in the ON Portfolio acquisition:

[0001437749-17-013580:notes:89]
[same as prior period, unchanged from 0001437749-17-007864:notes:119]

[0001437749-17-013580:notes:90]
All the ON Portfolio business goodwill and other assets were recorded in the Electronics segment and are reflected in the Americas and Europe geographic areas. The customer relationships are being amortized over 
13.5
 years. The patented and unpatented technologies are being amortized over 
6
-
8.5
 years. The non-compete agreement is being amortized over 
4
 years. The goodwill resulting from this acquisition consists largely of the 
Company’s expected future product sales and synergies from combining the ON Portfolio products with the Company’s existing

[0001437749-17-013580:notes:91]
[same as prior period, unchanged from 0001437749-17-007864:notes:121]

[0001437749-17-013580:notes:92]
As required by purchase accounting rules, the 
Company recorded a 
$0.7
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. All of the step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-17-013580:notes:93]
Menber
’s

[0001437749-17-013580:notes:94]
On 
 April 4, 2016, 
the 
Company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy for 
$19.2
 million, net of acquired cash and after settlement of a working capital adjustment. The Company funded the acquisition with cash on hand and borrowings under the Company’s revolving credit facility. The acquired business is part of the Company's commercial vehicle product business within the Automotive segment and specializes in the design, manufacturing, and selling of manual and electrical high current switches and trailer connectors for commercial vehicles. The acquisition expands the Company’s commercial vehicle products business globally.

[0001437749-17-013580:notes:95]
The following table summarizes 
the purchase price allocation of the fair value of assets acquired and liabilities assumed in the Menber’s acquisition:

[0001437749-17-013580:notes:96]
[same as prior period, unchanged from 0001437749-17-007864:notes:127]

[0001437749-17-013580:notes:97]
All Menber
’s goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The customer relationships are being amortized over 
10
 years. The patented and unpatented technologies are being amortized over 
5
 years. The trademarks and tradenames are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Menber’s products with the Company’s existing automotive product portfolio. Goodwill for the above acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-17-013580:notes:98]
As required by purchase accounting rules, the 
Company recorded a 
$0.2
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during 
2016,
 as the acquired inventory was sold, with the charge reflected as other non-segment costs.

[0001437749-17-013580:notes:99]
[same as prior period, unchanged from 0001437749-17-007864:notes:130]

[0001437749-17-013580:notes:100]
On 
 March 25, 2016, 
the 
Company acquired 
100%
 of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for 
$348.3
 million, net of acquired cash and after settlement of certain post-closing adjustments. In the 
second
 quarter of 
2017,
 the Company paid the final consideration of 
$3.8
 million. The Company funded the acquisition with available cash on hand and borrowings under the Company’s revolving credit facility. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-17-013580:notes:101]
[same as prior period, unchanged from 0001437749-17-007864:notes:134]

[0001437749-17-013580:notes:102]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the
 PolySwitch acquisition:

[0001437749-17-013580:notes:103]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Original consideration |  | $ | 350,000 |  |
| Post closing consideration adjustment received |  |  | (1,708 | ) |
| Acquired cash |  |  | (3,810 | ) |
| Acquired cash returned to seller |  |  | 3,810 |  |
| Total purchase consideration |  | $ | 348,292 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 60,228 |  |
| Property, plant, and equipment |  |  | 51,613 |  |
| Land lease |  |  | 4,290 |  |
| Patented and unpatented technologies |  |  | 56,425 |  |
| Customer relationships |  |  | 39,720 |  |
| Goodwill |  |  | 165,088 |  |
| Other long-term assets |  |  | 11,228 |  |
| Current liabilities |  |  | (35,280 | ) |
| Other non-current liabilities |  |  | (5,020 | ) |
|  |  | $ | 348,292 |  |

[0001437749-17-013580:notes:104]
All PolySwitch goodwill and other assets and liabilities were recorded in the Electronics 
and Automotive segments and reflected in all geographic areas. The customer relationships are being amortized over 
15
 years. The patented and unpatented technologies are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining PolySwitch products with the Company’s existing automotive and electronics product portfolio. 
$103.8
 million and 
$61.3
 million of the goodwill for the above acquisition has been assigned to the Electronics and Automotive segments, respectively, with 
$64.9
 million expected to be deductible for tax purposes.

[0001437749-17-013580:notes:105]
As required by purchase accounting rules, the 
Company recorded a 
$6.9
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the 
second
 quarter of 
2016,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-17-013580:notes:106]
[same as prior period, unchanged from 0001437749-17-007864:notes:139]

[0001437749-17-013580:notes:107]
The following table summarizes, on a pro forma basis, the combined results of operations of the 
Company and the acquired PolySwitch and the ON Portfolio businesses for the 
three
 months and 
six
 months ended 
 July 2, 2016 
as though the acquisitions had occurred as of 
 January 3, 2016. 
The Company has 
not
 included pro forma results of operations for Menber’s or Monolith as these results were 
not
 material to the Company. The pro forma amounts presented are 
not
 necessarily indicative of either the actual consolidated results had the PolySwitch or ON Portfolio acquisitions occurred as of 
 January 3, 2016 
or of future consolidated operating results.

[0001437749-17-013580:notes:108]
Pro forma results presented above primarily reflect: (
i) incremental depreciation relating to fair value adjustments to property, plant, and equipment; (ii) amortization adjustments relating to fair value estimates of intangible assets; (iii) incremental interest expense on assumed indebtedness; and (iv) additional cost of goods sold relating to the capitalization of gross profit as part of purchase accounting recognized for purposes of the pro forma as if it was recognized during the Company’s 
first
 quarter of 
2016.
 Pro forma adjustments described above have been tax affected using the Company's effective rate during the respective periods.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-17-013580:notes:109]
Recently

[0001437749-17-013580:notes:110]
Adopted

[0001437749-17-013580:notes:111]
Accounting Standards

[0001437749-17-013580:notes:112]
In 
 July 2015, 
the Financial Accounting Standards Board (
“FASB”) issued Accounting Standards Update (“ASU”) 
No.

[0001437749-17-013580:notes:113]
2015
-
11
 – “Inventory (Topic 
330
): Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
The adoption of the update did 
not
 have a material impact on the Company’s consolidated financial statements. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

[0001437749-17-013580:notes:114]
In 
 March 2016, 
the FASB issued ASU 
No.

[0001437749-17-013580:notes:115]
2016
-
09

[0001437749-17-013580:notes:116]
– “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
As a result of the adoption, on a prospective basis, the Company recognized 
$1.4
 million and 
$1.9
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 and 
six
 months ended 
 July 1, 2017, 
respectively. Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Consolidated Statement of Cash Flows. The Company elected 
not
 to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had 
no
 impact on the results of operations.

[0001437749-17-013580:notes:117]
Recently Issued Accounting Standards

[0001437749-17-013580:notes:118]
In 
 May 2014, 
the FASB issued ASU 
No.

[0001437749-17-013580:notes:119]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August, 2015, 
the FASB issued ASU 
No.

[0001437749-17-013580:notes:120]
2015
-
14,
 which postponed the effective date of ASU 
No.

[0001437749-17-013580:notes:121]
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted on the original effective date of fiscal years beginning after 
 December 15, 2016. 
The Company is in the process of performing its initial assessment of the potential impact on its consolidated financial statements, and currently anticipates adopting this standard using the modified retrospective method. While the Company is currently assessing the impact of the new standards, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does 
not
 expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may 
be affected. The Company has 
not
 yet quantified this potential impact.

[0001437749-17-013580:notes:122]
In 
 February 2016, 
the FASB issued ASU 
No.

[0001437749-17-013580:notes:123]
2016
-
02,
 "Leases" (Topic 
842
). This
 ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company is currently evaluating the impact of this ASU on its consolidated financial statements.

[0001437749-17-013580:notes:124]
In 
 January 2017, 
the FASB issued ASU 
No.

[0001437749-17-013580:notes:125]
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350
). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity 
no
 longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December 15, 2020, 
with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January 1, 2017.

[0001437749-17-013580:notes:126]
The Company expects to adopt the new standard in 
2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-17-013580:notes:127]
[same as prior period, unchanged from 0001437749-17-007864:notes:170]

[0001437749-17-013580:notes:128]
[same as prior period, unchanged from 0001437749-17-007864:notes:171]

[0001437749-17-013580:notes:129]
The 
Company has company-sponsored defined benefit pension plans covering employees in the U.K., Germany, the Philippines, China, Japan, and France. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0001437749-17-013580:notes:130]
The components of net periodic benefit cost for the 
three

[0001437749-17-013580:notes:131]
and 
six
 months ended 
 July 1, 2017 
and 
 July 2, 2016 
are as follows:

[0001437749-17-013580:notes:132]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands) |  | July 1, 2017 |  |  | July 2, 2016 |  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 408 |  |  | $ | 333 |  |  | $ | 816 |  |  | $ | 665 |  |
| Interest cost |  |  | 360 |  |  |  | 496 |  |  |  | 720 |  |  |  | 993 |  |
| Expected return on plan assets |  |  | (476 | ) |  |  | (520 | ) |  |  | (952 | ) |  |  | (1,040 | ) |
| Amortization of prior service (credit) |  |  | 84 |  |  |  | 73 |  |  |  | 168 |  |  |  | 146 |  |
| Total cost of the plan |  |  | 376 |  |  |  | 382 |  |  |  | 752 |  |  |  | 764 |  |
| Expected plan participants’ contribution |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net periodic benefit cost |  | $ | 376 |  |  | $ | 382 |  |  | $ | 752 |  |  | $ | 764 |  |

[0001437749-17-013580:notes:133]
The expected return on pension assets is

[0001437749-17-013580:notes:134]
4.5%
 and 
4.9%
 in 
2017
 and 
2016,
 respectively.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001437749-17-013580:notes:135]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments (a) |  |  | Unrealized gains on investments |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 31, 2016 |  | $ | (11,983 | ) |  | $ | 10,769 |  |  | $ | (73,365 | ) |  | $ | (74,579 | ) |
| Activity in the period |  |  | (381 | ) |  |  | 475 |  |  |  | 1,381 |  |  |  | 1,475 |  |
| Balance at July 1, 2017 |  | $ | (12,364 | ) |  | $ | 11,244 |  |  | $ | (71,984 | ) |  | $ | (73,104 | ) |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-17-013580:notes:136]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands) |  | July 1, 2017 |  |  | July 2, 2016 |  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 100,648 |  |  | $ | 93,036 |  |  | $ | 187,306 |  |  | $ | 178,184 |  |
| China |  |  | 83,055 |  |  |  | 62,411 |  |  |  | 157,745 |  |  |  | 110,919 |  |
| Other countries |  |  | 129,652 |  |  |  | 116,465 |  |  |  | 253,746 |  |  |  | 202,207 |  |
| Total net sales |  | $ | 313,355 |  |  | $ | 271,912 |  |  | $ | 598,797 |  |  | $ | 491,310 |  |

[0001437749-17-013580:notes:137]
| (in thousands) |  | July 1, 2017 |  |  | December 31, 2016 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 23,415 |  |  | $ | 23,731 |  |
| China |  |  | 70,671 |  |  |  | 65,345 |  |
| Mexico |  |  | 60,172 |  |  |  | 52,262 |  |
| Philippines |  |  | 31,573 |  |  |  | 33,345 |  |
| Other countries |  |  | 46,708 |  |  |  | 42,492 |  |
| Total long-lived assets |  | $ | 232,539 |  |  | $ | 217,175 |  |

[0001437749-17-013580:notes:138]
|  |  | For the Six Months Ended |  |
| (in thousands) |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 1,149 |  |  | $ | 2,783 |  |
| China |  |  | 10,149 |  |  |  | 3,847 |  |
| Mexico |  |  | 10,925 |  |  |  | 8,164 |  |
| Philippines |  |  | 1,345 |  |  |  | 2,925 |  |
| Other countries |  |  | 5,310 |  |  |  | 2,498 |  |
| Total additions to long-lived assets |  | $ | 28,878 |  |  | $ | 20,217 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-013580:notes:139]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands) |  | July 1, 2017 |  |  | July 2, 2016 |  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 169,387 |  |  | $ | 132,170 |  |  | $ | 323,154 |  |  | $ | 230,966 |  |
| Automotive |  |  | 116,457 |  |  |  | 111,370 |  |  |  | 224,297 |  |  |  | 203,303 |  |
| Industrial |  |  | 27,511 |  |  |  | 28,372 |  |  |  | 51,346 |  |  |  | 57,041 |  |
| Total net sales |  | $ | 313,355 |  |  | $ | 271,912 |  |  | $ | 598,797 |  |  | $ | 491,310 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 8,707 |  |  | $ | 7,717 |  |  | $ | 17,095 |  |  | $ | 13,089 |  |
| Automotive |  |  | 5,580 |  |  |  | 4,988 |  |  |  | 10,950 |  |  |  | 8,254 |  |
| Industrial |  |  | 1,330 |  |  |  | 1,376 |  |  |  | 2,645 |  |  |  | 2,828 |  |
| Other |  |  | - |  |  |  | — |  |  |  | - |  |  |  | 937 |  |
| Total depreciation and amortization |  | $ | 15,617 |  |  | $ | 14,081 |  |  | $ | 30,690 |  |  | $ | 25,108 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 42,967 |  |  | $ | 25,259 |  |  | $ | 78,173 |  |  | $ | 47,675 |  |
| Automotive |  |  | 15,713 |  |  |  | 16,474 |  |  |  | 30,778 |  |  |  | 33,965 |  |
| Industrial |  |  | 1,905 |  |  |  | 2,028 |  |  |  | 2,012 |  |  |  | 3,701 |  |
| Other(a) |  |  | (315 | ) |  |  | (14,059 | ) |  |  | (1,840 | ) |  |  | (23,211 | ) |
| Total operating income |  |  | 60,270 |  |  |  | 29,702 |  |  |  | 109,123 |  |  |  | 62,130 |  |
| Interest expense |  |  | 3,281 |  |  |  | 1,670 |  |  |  | 6,401 |  |  |  | 3,715 |  |
| Foreign exchange loss (gain) |  |  | (558 | ) |  |  | (6,237 | ) |  |  | (2,115 | ) |  |  | (2,414 | ) |
| Other expense (income), net |  |  | 190 |  |  |  | 255 |  |  |  | 52 |  |  |  | (262 | ) |
| Income before income taxes |  | $ | 57,357 |  |  | $ | 34,014 |  |  | $ | 104,785 |  |  | $ | 61,091 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-013580:notes:140]
[same as prior period, unchanged from 0001437749-17-007864:notes:182]

[0001437749-17-013580:notes:141]
[same as prior period, unchanged from 0001437749-17-007864:notes:183]

[0001437749-17-013580:notes:142]
[same as prior period, unchanged from 0001437749-17-007864:notes:184]

[0001437749-17-013580:notes:143]
The 
Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it 
 may 
earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”).  The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does 
not
 evaluate the operating segments using discrete balance sheet information.

[0001437749-17-013580:notes:144]
Sales, marketing
, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the 
three
 operating segments.  The Company does 
not
 report inter-segment revenue because the operating segments do 
not
 record it.  Certain expenses, determined by the CODM to be strategic in nature and 
not
 directly related to segments current results, are 
not
 allocated but identified as “Other”.  Additionally, the Company does 
not
 allocate interest and other income, interest expense, or taxes to operating segments.  These costs are 
not
 allocated to the segments, as management excludes such costs when assessing the performance of the segments.  Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in 
one
 segment 
 may 
benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001437749-17-013580:notes:145]
[same as prior period, unchanged from 0001437749-17-007864:notes:187]

[0001437749-17-013580:notes:146]
[same as prior period, unchanged from 0001437749-17-007864:notes:188]

[0001437749-17-013580:notes:147]
[same as prior period, unchanged from 0001437749-17-007864:notes:189]

[0001437749-17-013580:notes:148]
Segment inform
ation is summarized as follows:

[0001437749-17-013580:notes:149]
(a)

[0001437749-17-013580:notes:150]
Included in “Other” Operating income (loss) for the 
2017

[0001437749-17-013580:notes:151]
second
 quarter is of 
$0.3
 million (
$1.8
 million year-to-date) of acquisition and integration costs associated with the Company’s 
2016
 acquisitions (included in Cost of sales (“COS”) and Selling, general, and administrative expenses (“SG&A)).

[0001437749-17-013580:notes:152]
Included in “Other” Operating income
 (loss) for the 
2016

[0001437749-17-013580:notes:153]
second
 quarter is 
$6.1
 million (
$12.3
 million year-to-date) of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, a 
$6.9
 million (
$6.9
 million year-to-date) inventory adjustment relating to the PolySwitch acquisition as described in Note 
4,

[0001437749-17-013580:notes:154]
$0.3
 million (
$1.9
 million year-to-date) in charges related to the closure of the company’s manufacturing facility in Denmark, 
$0.7
 million (
$1.7
 million year-to-date) related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and 
$0.1
 million (
$0.4
 million year-to-date) related to internal legal restructuring costs.

[0001437749-17-013580:notes:155]
The 
Company’s net sales by country are as follows:

[0001437749-17-013580:notes:156]
The 
Company’s long-lived assets by country, as of 
 July

[0001437749-17-013580:notes:157]
2017
 and 
 December 31, 2016, 
are as follows:

[0001437749-17-013580:notes:158]
The 
Company’s additions to long-lived assets by country are as follows:


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-17-013580:notes:159]
[same as prior period, unchanged from 0001437749-17-007864:notes:197]

[0001437749-17-013580:notes:160]
[same as prior period, unchanged from 0001437749-17-007864:notes:198]

[0001437749-17-013580:notes:161]
Littelfuse, Inc. and subsidiaries (the “
Company”) design, manufacture, and sell circuit protection devices for use in the automotive, electronics, and industrial markets throughout the world. The Company is 
one
 of the world’s leading suppliers of circuit protection products for the electronics, automotive, and industrial markets, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001437749-17-013580:notes:162]
7.
 Shareholders
’ Equity

[0001437749-17-013580:notes:163]
Accumulated Other Comprehensive Income (Loss) (“AOCI”): 
The following table sets forth the changes in the components of AOCI by component for the 
six
 months ended 
 July 1, 2017:

[0001437749-17-013580:notes:164]
(a) The balance
s at 
 July 1, 2017 
and 
 December 31, 2016 
are net of taxes of 
$1.1
 million and 
$1.1
 million, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001437749-17-013580:notes:165]
11

[0001437749-17-013580:notes:166]
) Subsequent Event

[0001437749-17-013580:notes:167]
On

[0001437749-17-013580:notes:168]
July 6, 2017, 
the company completed the acquisition of U.S. Sensor Corp. headquartered in California. The purchase price of 
$24.0
 million is subject to a working capital adjustment and was financed primarily by cash on hand. The acquired business, which will be part of the company's Electronics segment, will contribute to the expansion of the Company’s existing sensor platform portfolio with a range of high-quality temperature sensor products.
