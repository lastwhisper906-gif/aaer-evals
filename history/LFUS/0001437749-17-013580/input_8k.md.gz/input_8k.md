# LFUS 8-K — 0001437749-17-013530 filed 2017-08-02

## item codes, every 8-K on or before 2017-08-02

- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2017-08-02

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-013530:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-17-013530:8k_2_02:2]
ex99-1.htm

[0001437749-17-013530:8k_2_02:3]
Exhibit 99.1

[0001437749-17-013530:8k_2_02:4]
| NEWS RELEASE |  |  |

[0001437749-17-013530:8k_2_02:5]
LITTELFUSE REPORTS SECOND QUARTER RESULTS

[0001437749-17-013530:8k_2_02:6]
CHICAGO, August 2, 2017 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the second quarter ended July 1, 2017.

[0001437749-17-013530:8k_2_02:7]
Second Quarter 2017 Highlights

[0001437749-17-013530:8k_2_02:8]
|  | ● | Net sales were $313.4 million, up 15% versus the prior year period. Organic revenue growth was 11%, excluding the ON portfolio acquisition, e-house business divestiture and currency effects. |

[0001437749-17-013530:8k_2_02:9]
|  | ● | Growth by segment versus the prior year period: |

[0001437749-17-013530:8k_2_02:10]
|  | o | Electronics sales increased 28% (up 16% organically) |

[0001437749-17-013530:8k_2_02:11]
|  | o | Automotive sales increased 5% (up 6% organically) |

[0001437749-17-013530:8k_2_02:12]
|  | o | Industrial sales decreased 3% (up 5% organically) |

[0001437749-17-013530:8k_2_02:13]
|  | ● | GAAP diluted EPS was $2.11; Adjusted EPS of $2.10 increased 46% over last year |

[0001437749-17-013530:8k_2_02:14]
|  | ● | The GAAP and adjusted effective tax rate were both 15.2% for the quarter. Included in the tax rate was a discrete tax benefit of $1.4 million resulting from the new stock compensation accounting guidance. |

[0001437749-17-013530:8k_2_02:15]
|  | ● | Cash flow from operations was $70.6 million |

[0001437749-17-013530:8k_2_02:16]
|  | ● | The electronics book-to-bill ratio for the second quarter was 1.13 |

[0001437749-17-013530:8k_2_02:17]
|  | ● | The company recently announced it had acquired the assets of U.S. Sensor Corporation, a manufacturer of temperature sensors based in Orange, California. |

[0001437749-17-013530:8k_2_02:18]
"We followed our strong first quarter performance with record sales and earnings in the second quarter,” said Dave Heinzmann, Chief Executive Officer. "The strong order rates we’ve seen across our electronics segment since late last year continued in the second quarter, and along with solid operational execution, drove record performance across electronics. Our automotive and industrial segments also performed well, which included the expected profitability improvement in industrial.”

[0001437749-17-013530:8k_2_02:19]
-more-

[0001437749-17-013530:8k_2_02:20]
Third Quarter 2017 Outlook

[0001437749-17-013530:8k_2_02:21]
All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, foreign exchange adjustments and unusual gains and losses. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-17-013530:8k_2_02:22]
“While electronics order rates remain strong, they have slowed from the peak in the second quarter. We continue, however, to see robust end demand and expect the momentum in electronics sales to continue in the third quarter,” continued Heinzmann. “We also expect the automotive and industrial segments to have another solid growth quarter, including margin expansion in both businesses.”

[0001437749-17-013530:8k_2_02:23]
For the third quarter of 2017:

[0001437749-17-013530:8k_2_02:24]
|  | ● | Sales are expected to be in the range of $311 to $323 million, up 13% on an as reported basis and up 9% organically, at the midpoint versus the prior year quarter |

[0001437749-17-013530:8k_2_02:25]
|  | ● | Adjusted diluted earnings per share are expected to be in the range of $2.02 to $2.16 |

[0001437749-17-013530:8k_2_02:26]
For the full year, the company expects an adjusted effective tax rate in the range of 18% – 19%.

[0001437749-17-013530:8k_2_02:27]
Dividend

[0001437749-17-013530:8k_2_02:28]
The company’s board of directors approved a 12% increase in the quarterly cash dividend from $0.33 to $0.37. This equates to an annualized dividend of $1.48 per share. The dividend will be paid on September 7, 2017 to shareholders of record as of August 24, 2017.

[0001437749-17-013530:8k_2_02:29]
Conference Call and Webcast Information

[0001437749-17-013530:8k_2_02:30]
Littelfuse will host a conference call today, Wednesday, August 2, 2017, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. The call will be available for replay on the company’s website.

[0001437749-17-013530:8k_2_02:31]
About Littelfuse

[0001437749-17-013530:8k_2_02:32]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 10,000 employees in more than 40 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: Littelfuse.com.

[0001437749-17-013530:8k_2_02:33]
-more-

[0001437749-17-013530:8k_2_02:34]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company's accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions, uncertainties related to political and regulatory changes and other risks which may be detailed in the company's other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 31, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-013530:8k_2_02:35]
Non-GAAP Financial Measures

[0001437749-17-013530:8k_2_02:36]
The information included in this press release includes the non-GAAP financial measures of adjusted net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is included herein.

[0001437749-17-013530:8k_2_02:37]
The company believes that adjusted net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-17-013530:8k_2_02:38]
CONTACT: Meenal Sethna

[0001437749-17-013530:8k_2_02:39]
Executive Vice President and CFO

[0001437749-17-013530:8k_2_02:40]
(773) 628-0616

[0001437749-17-013530:8k_2_02:41]
###

[0001437749-17-013530:8k_2_02:42]
LFUS-F

[0001437749-17-013530:8k_2_02:43]
| LITTELFUSE, INC. |
| Net Sales and Operating Income by Business Unit |
| (In thousands of USD, unaudited) |

[0001437749-17-013530:8k_2_02:44]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 169,387 |  |  | $ | 132,170 |  |  |  | 28% |  |  | $ | 323,154 |  |  | $ | 230,966 |  |  |  | 40% |  |
| Automotive |  |  | 116,457 |  |  |  | 111,370 |  |  |  | 5% |  |  |  | 224,297 |  |  |  | 203,303 |  |  |  | 10% |  |
| Industrial |  |  | 27,511 |  |  |  | 28,372 |  |  |  | (3%) |  |  |  | 51,346 |  |  |  | 57,041 |  |  |  | (10%) |  |
| Total net sales |  | $ | 313,355 |  |  | $ | 271,912 |  |  |  | 15% |  |  | $ | 598,797 |  |  | $ | 491,310 |  |  |  | 22% |  |

[0001437749-17-013530:8k_2_02:45]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 42,967 |  |  | $ | 25,259 |  |  |  | 70% |  |  | $ | 78,173 |  |  | $ | 47,675 |  |  |  | 64% |  |
| Automotive |  |  | 15,713 |  |  |  | 16,474 |  |  |  | (5%) |  |  |  | 30,778 |  |  |  | 33,965 |  |  |  | (9%) |  |
| Industrial |  |  | 1,905 |  |  |  | 2,028 |  |  |  | (6%) |  |  |  | 2,012 |  |  |  | 3,701 |  |  |  | (46%) |  |
| Other (1) |  |  | (315 | ) |  |  | (14,059 | ) |  |  | 98% |  |  |  | (1,840 | ) |  |  | (23,211 | ) |  |  | (92%) |  |
| Total operating income |  | $ | 60,270 |  |  | $ | 29,702 |  |  |  | 103% |  |  | $ | 109,123 |  |  | $ | 62,130 |  |  |  | 76% |  |
| Operating margins |  | 19.2 | % |  |  | 10.9 | % |  |  |  |  |  |  | 18.2 | % |  |  | 12.6 | % |  |  |  |  |
| Interest expense |  |  | 3,281 |  |  |  | 1,670 |  |  |  |  |  |  |  | 6,401 |  |  |  | 3,715 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | (558 | ) |  |  | (6,237 | ) |  |  |  |  |  |  | (2,115 | ) |  |  | (2,414 | ) |  |  |  |  |
| Other (income) expense, net |  |  | 190 |  |  |  | 255 |  |  |  |  |  |  |  | 52 |  |  |  | (262 | ) |  |  |  |  |
| Income before taxes |  | $ | 57,357 |  |  | $ | 34,014 |  |  |  | 69% |  |  | $ | 104,785 |  |  | $ | 61,091 |  |  |  | 72% |  |

[0001437749-17-013530:8k_2_02:46]
| (1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details on page 8.) |

[0001437749-17-013530:8k_2_02:47]
|  | Second Quarter |  | Year-to-Date |
|  | 2017 |  | 2016 |  | Growth / (Decline) |  | 2017 |  | 2016 |  | Growth / (Decline) |
| Operating Margins |  |  |  |  |  |  |  |  |  |  |  |
| Electronics | 25.4% |  | 19.1% |  | 6.3% |  | 24.2% |  | 20.6% |  | 3.5% |
| Automotive | 13.5% |  | 14.8% |  | -1.3% |  | 13.7% |  | 16.7% |  | -3.0% |
| Industrial | 6.9% |  | 7.1% |  | -0.2% |  | 3.9% |  | 6.5% |  | -2.6% |

[0001437749-17-013530:8k_2_02:48]
| LITTELFUSE, INC. |
| Condensed Consolidated Balance Sheets |
| (In thousands of USD) |

[0001437749-17-013530:8k_2_02:49]
|  |  | July 1, 2017 |  |  | December 31, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 321,893 |  |  | $ | 275,124 |  |
| Short-term investments |  |  | 34 |  |  |  | 3,690 |  |
| Accounts receivable, less allowances |  |  | 199,027 |  |  |  | 176,032 |  |
| Inventories |  |  | 125,240 |  |  |  | 114,063 |  |
| Prepaid income taxes and income taxes receivable |  |  | 6,720 |  |  |  | 11,671 |  |
| Prepaid expenses and other current assets |  |  | 51,938 |  |  |  | 31,501 |  |
| Total current assets |  |  | 704,852 |  |  |  | 612,081 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 9,691 |  |  |  | 9,268 |  |
| Buildings |  |  | 84,481 |  |  |  | 80,553 |  |
| Equipment |  |  | 471,960 |  |  |  | 439,542 |  |
|  |  |  | 566,132 |  |  |  | 529,363 |  |
| Accumulated depreciation |  |  | (333,593 | ) |  |  | (312,188 | ) |
| Net property, plant and equipment |  |  | 232,539 |  |  |  | 217,175 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 85,798 |  |  |  | 83,607 |  |
| Distribution network |  |  | 18,191 |  |  |  | 18,995 |  |
| Customer lists, trademarks and tradenames |  |  | 106,848 |  |  |  | 110,425 |  |
| Goodwill |  |  | 432,134 |  |  |  | 403,544 |  |
|  |  |  | 642,971 |  |  |  | 616,571 |  |
| Investments |  |  | 11,916 |  |  |  | 13,933 |  |
| Deferred income taxes |  |  | 19,028 |  |  |  | 20,585 |  |
| Other assets |  |  | 10,885 |  |  |  | 10,849 |  |
| Total assets |  | $ | 1,622,191 |  |  | $ | 1,491,194 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 100,826 |  |  | $ | 90,712 |  |
| Accrued payroll |  |  | 32,866 |  |  |  | 42,810 |  |
| Accrued expenses |  |  | 50,536 |  |  |  | 36,138 |  |
| Accrued severance |  |  | 629 |  |  |  | 2,785 |  |
| Accrued income taxes |  |  | 9,522 |  |  |  | 8,846 |  |
| Current portion of long-term debt |  |  | 7,813 |  |  |  | 6,250 |  |
| Total current liabilities |  |  | 202,192 |  |  |  | 187,541 |  |
| Long-term debt, less current portion |  |  | 473,879 |  |  |  | 447,892 |  |
| Deferred income taxes |  |  | 8,826 |  |  |  | 7,066 |  |
| Accrued post-retirement benefits |  |  | 15,975 |  |  |  | 13,398 |  |
| Other long-term liabilities |  |  | 25,887 |  |  |  | 20,366 |  |
| Total equity |  |  | 895,432 |  |  |  | 814,931 |  |
| Total liabilities and equity |  | $ | 1,622,191 |  |  | $ | 1,491,194 |  |

[0001437749-17-013530:8k_2_02:50]
| LITTELFUSE, INC. |
| Consolidated Statements of Comprehensive Income |
| (In thousands of USD, except per share data, unaudited) |

[0001437749-17-013530:8k_2_02:51]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| Net sales |  | $ | 313,355 |  |  | $ | 271,912 |  |  | $ | 598,797 |  |  | $ | 491,310 |  |
| Cost of sales |  |  | 180,747 |  |  |  | 174,046 |  |  |  | 352,539 |  |  |  | 306,289 |  |
| Gross profit |  |  | 132,608 |  |  |  | 97,866 |  |  |  | 246,258 |  |  |  | 185,021 |  |
| Selling, general and administrative expenses |  |  | 53,438 |  |  |  | 51,092 |  |  |  | 100,139 |  |  |  | 93,458 |  |
| Research and development expenses |  |  | 12,729 |  |  |  | 11,916 |  |  |  | 24,881 |  |  |  | 20,481 |  |
| Amortization of intangibles |  |  | 6,171 |  |  |  | 5,156 |  |  |  | 12,115 |  |  |  | 8,952 |  |
|  |  |  | 72,338 |  |  |  | 68,164 |  |  |  | 137,135 |  |  |  | 122,891 |  |
| Operating income |  |  | 60,270 |  |  |  | 29,702 |  |  |  | 109,123 |  |  |  | 62,130 |  |
| Interest expense |  |  | 3,281 |  |  |  | 1,670 |  |  |  | 6,401 |  |  |  | 3,715 |  |
| Foreign exchange (gain) loss |  |  | (558 | ) |  |  | (6,237 | ) |  |  | (2,115 | ) |  |  | (2,414 | ) |
| Other (income) expense, net |  |  | 190 |  |  |  | 255 |  |  |  | 52 |  |  |  | (262 | ) |
| Income before income taxes |  |  | 57,357 |  |  |  | 34,014 |  |  |  | 104,785 |  |  |  | 61,091 |  |
| Income taxes |  |  | 8,719 |  |  |  | 6,862 |  |  |  | 17,255 |  |  |  | 14,650 |  |
| Net income |  | $ | 48,638 |  |  | $ | 27,152 |  |  | $ | 87,530 |  |  | $ | 46,441 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.13 |  |  | $ | 1.21 |  |  | $ | 3.84 |  |  | $ | 2.07 |  |
| Diluted |  | $ | 2.11 |  |  | $ | 1.20 |  |  | $ | 3.80 |  |  | $ | 2.05 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,822 |  |  |  | 22,528 |  |  |  | 22,785 |  |  |  | 22,483 |  |
| Diluted |  |  | 23,023 |  |  |  | 22,674 |  |  |  | 23,005 |  |  |  | 22,647 |  |
| Comprehensive income |  | $ | 44,485 |  |  | $ | 11,899 |  |  | $ | 89,004 |  |  | $ | 41,874 |  |

[0001437749-17-013530:8k_2_02:52]
| LITTELFUSE, INC. |
| Consolidated Statements of Cash Flows |
| (In thousands of USD, unaudited) |

[0001437749-17-013530:8k_2_02:53]
|  |  | For the Six Months Ended |  |
|  |  | July 1, 2017 |  |  | July 2, 2016 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 87,530 |  |  | $ | 46,441 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 18,575 |  |  |  | 16,156 |  |
| Amortization of intangibles |  |  | 12,115 |  |  |  | 8,952 |  |
| Impairment of intangible assets |  |  | - |  |  |  | 1,391 |  |
| Provision for bad debts |  |  | 1,895 |  |  |  | - |  |
| Stock-based compensation |  |  | 8,590 |  |  |  | 6,124 |  |
| Non-cash inventory charge |  |  | - |  |  |  | 6,902 |  |
| Excess tax benefit on stock-based compensation |  |  | - |  |  |  | (1,585 | ) |
| Loss on sale of assets |  |  | 593 |  |  |  | 331 |  |
| Deferred income taxes |  |  | 1,514 |  |  |  | - |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (32,039 | ) |  |  | (25,028 | ) |
| Inventories |  |  | (8,739 | ) |  |  | (1,282 | ) |
| Accounts payable |  |  | 7,985 |  |  |  | 2,974 |  |
| Accrued expenses (including post retirement) |  |  | 3,912 |  |  |  | 5,715 |  |
| Accrued payroll and severance |  |  | (13,190 | ) |  |  | (10,227 | ) |
| Accrued taxes |  |  | 515 |  |  |  | (13,946 | ) |
| Prepaid expenses and other |  |  | 4,317 |  |  |  | (7,642 | ) |
| Net cash provided by operating activities |  |  | 93,573 |  |  |  | 35,276 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (28,278 | ) |  |  | (20,217 | ) |
| Acquisition of business, net of cash acquired |  |  | (14,172 | ) |  |  | (354,356 | ) |
| Proceeds from maturities of short-term investments |  |  | 3,739 |  |  |  | - |  |
| Decrease in entrusted loan receivable |  |  | 2,416 |  |  |  | - |  |
| Proceeds from sale of assets |  |  | 178 |  |  |  | 370 |  |
| Net cash used in investing activities |  |  | (36,117 | ) |  |  | (374,203 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | - |  |  |  | 258,000 |  |
| Proceeds of term loan |  |  | - |  |  |  | 125,000 |  |
| Payments of revolving credit facility |  |  | (112,500 | ) |  |  | (97,500 | ) |
| Payments of term loan |  |  | (3,125 | ) |  |  | (86,563 | ) |
| Net proceeds from Sr. Notes Payable |  |  | 125,000 |  |  |  | - |  |
| Payments of entrusted loan |  |  | (2,416 | ) |  |  | - |  |
| Debt issuance costs paid |  |  | (1 | ) |  |  | (1,701 | ) |
| Cash dividends paid |  |  | (14,963 | ) |  |  | (12,995 | ) |
| Net proceeds (payments) related to stock-based award activities |  |  | (2,074 | ) |  |  | 2,960 |  |
| Excess tax benefit on share-based compensation |  |  | - |  |  |  | 1,586 |  |
| Net cash (used in) provided by financing activities |  |  | (10,079 | ) |  |  | 188,787 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (608 | ) |  |  | 815 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 46,769 |  |  |  | (149,325 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275,124 |  |  |  | 328,786 |  |
| Cash and cash equivalents at end of period |  | $ | 321,893 |  |  | $ | 179,461 |  |

[0001437749-17-013530:8k_2_02:54]
| LITTELFUSE, INC. |
| Supplemental Financial Information |
| (in millions of USD except per share amounts) |

[0001437749-17-013530:8k_2_02:55]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-17 |  |  | YTD-17 |  |  | Q2-16 |  |  | YTD-16 |  |
| GAAP diluted EPS |  | $ | 2.11 |  |  | $ | 3.80 |  |  | $ | 1.20 |  |  | $ | 2.05 |  |
| EPS impact of Non-GAAP adjustments (below) |  |  | (0.01 | ) |  |  | (0.01 | ) |  |  | 0.24 |  |  |  | 0.77 |  |
| Adjusted diluted EPS |  | $ | 2.10 |  |  | $ | 3.79 |  |  | $ | 1.44 |  |  | $ | 2.82 |  |

[0001437749-17-013530:8k_2_02:56]
| Non-GAAP Adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-17 |  |  | YTD-17 |  |  | Q2-16 |  |  | YTD-16 |  |
| Reed switch manufacturing transfer costs |  | $ | - |  |  | $ | - |  |  | $ | 0.7 |  |  | $ | 1.7 |  |
| Restructuring |  |  | - |  |  |  | - |  |  |  | 0.1 |  |  |  | 0.5 |  |
| Acquisitions/divestiture/purchase acctg adjs |  |  | 0.3 |  |  |  | 1.8 |  |  |  | 13.0 |  |  |  | 19.2 |  |
| Impairment and severance charges |  |  | - |  |  |  | - |  |  |  | 0.3 |  |  |  | 1.9 |  |
| Adjustment to Operating income |  |  | 0.3 |  |  |  | 1.8 |  |  |  | 14.0 |  |  |  | 23.2 |  |
| Non-operating Foreign exchange loss/(gain) |  |  | (0.6 | ) |  |  | (2.2 | ) |  |  | (6.2 | ) |  |  | (2.4 | ) |
| Adjustment to income before income taxes |  |  | (0.3 | ) |  |  | (0.4 | ) |  |  | 7.8 |  |  |  | 20.8 |  |
| Income taxes |  |  | - |  |  |  | - |  |  |  | 2.3 |  |  |  | 3.4 |  |
| Adjustment to net income |  | $ | (0.3 | ) |  | $ | (0.4 | ) |  | $ | 5.5 |  |  | $ | 17.4 |  |
| Total EPS impact |  | $ | (0.01 | ) |  | $ | (0.01 | ) |  | $ | 0.24 |  |  | $ | 0.77 |  |

[0001437749-17-013530:8k_2_02:57]
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-17 |  |  | YTD-17 |  |  | Q2-16 |  |  | YTD-16 |  |
| Net sales |  | $ | 313.4 |  |  | $ | 598.8 |  |  | $ | 271.9 |  |  | $ | 491.3 |  |
| GAAP operating income |  | $ | 60.3 |  |  | $ | 109.2 |  |  | $ | 29.7 |  |  | $ | 62.1 |  |
| Add back special operating items |  |  | 0.3 |  |  |  | 1.8 |  |  |  | 14.0 |  |  |  | 23.2 |  |
| Adjusted operating income |  | $ | 60.6 |  |  | $ | 111.0 |  |  | $ | 43.7 |  |  | $ | 85.3 |  |
| Adjusted operating margin |  |  | 19.3 | % |  |  | 18.5 | % |  |  | 16.1 | % |  |  | 17.4 | % |
| Add back amortization |  |  | 6.2 |  |  |  | 12.1 |  |  |  | 5.2 |  |  |  | 9.0 |  |
| Add back depreciation |  |  | 9.4 |  |  |  | 18.5 |  |  |  | 8.9 |  |  |  | 16.1 |  |
| Adjusted EBITDA |  | $ | 76.2 |  |  | $ | 141.6 |  |  | $ | 57.8 |  |  | $ | 110.4 |  |
| Adjusted EBITDA margin |  |  | 24.3 | % |  |  | 23.6 | % |  |  | 21.3 | % |  |  | 22.5 | % |

[0001437749-17-013530:8k_2_02:58]
| Net sales reconciliation |  | Q2-17 vs. Q2-16 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales growth |  |  | 28 | % |  |  | 5 | % |  |  | -3 | % |  |  | 15 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 13 | % |  |  | 0 | % |  |  | 0 | % |  |  | 6 | % |
| Divestitures |  |  | 0 | % |  |  | 0 | % |  |  | -8 | % |  |  | -1 | % |
| FX impact |  |  | -1 | % |  |  | -2 | % |  |  | -1 | % |  |  | -1 | % |
| Adjusted (organic) net sales growth |  |  | 16 | % |  |  | 6 | % |  |  | 5 | % |  |  | 11 | % |

[0001437749-17-013530:8k_2_02:59]
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-17 |  |  | YTD-17 |  |  | Q2-16 |  |  | YTD-16 |  |
| Income taxes |  | $ | 8.7 |  |  | $ | 17.2 |  |  | $ | 6.9 |  |  | $ | 14.7 |  |
| Effective rate |  |  | 15.2 | % |  |  | 16.5 | % |  |  | 20.2 | % |  |  | 24.0 | % |
| Non-GAAP adjustment - income taxes |  |  | - |  |  |  | - |  |  |  | 2.3 |  |  |  | 3.3 |  |
| Adjusted income taxes |  | $ | 8.7 |  |  | $ | 17.2 |  |  | $ | 9.2 |  |  | $ | 18.0 |  |
| Adjusted effective rate |  |  | 15.2 | % |  |  | 15.2 | % |  |  | 22.0 | % |  |  | 22.0 | % |

[0001437749-17-013530:8k_2_02:60]
| Free Cash Flow reconcilation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2-17 |  |  | Q2-16 |  |  | YTD-17 |  |  | YTD-16 |  |
| Net cash provided by operating activities |  | $ | 70.6 |  |  | $ | 25.8 |  |  | $ | 93.6 |  |  | $ | 35.3 |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (15.9 | ) |  |  | (11.1 | ) |  |  | (28.3 | ) |  |  | (20.2 | ) |
| Free Cash Flow |  | $ | 54.7 |  |  | $ | 14.7 |  |  | $ | 65.3 |  |  | $ | 15.1 |  |

[0001437749-17-013530:8k_2_02:61]
| Note: Totals will not always foot due to rounding |

[0001437749-17-013530:8k_2_02:62]
# # #
