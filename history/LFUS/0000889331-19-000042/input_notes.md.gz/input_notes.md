# LFUS notes — 0000889331-19-000042


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-19-000042:notes:1]
[same as prior period, unchanged from 0000889331-19-000030:notes:165]

[0000889331-19-000042:notes:2]
[same as prior period, unchanged from 0000889331-19-000030:notes:166]

[0000889331-19-000042:notes:3]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The Company's products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

[0000889331-19-000042:notes:4]
Basis of Presentation

[0000889331-19-000042:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 29, 2018  which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-19-000042:notes:6]
Revenue Recognition

[0000889331-19-000042:notes:7]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.

[0000889331-19-000042:notes:8]
Revenue Disaggregation

[0000889331-19-000042:notes:9]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2019 and June 30, 2018 :

[0000889331-19-000042:notes:10]
|  |  | Three Months Ended June 29, 2019 |  | Six Months Ended June 29, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

[0000889331-19-000042:notes:11]
|  |  | Three Months Ended June 30, 2018 |  | Six Months Ended June 30, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  | 171,036 |  |  | — |  |  | — |  |  | 171,036 |  |  | 320,952 |  |  | — |  |  | — |  |  | 320,952 |  |
| Passenger Car Products |  | — |  |  | 63,581 |  |  | — |  |  | 63,581 |  |  | — |  |  | 127,160 |  |  | — |  |  | 127,160 |  |
| Automotive Sensors |  | — |  |  | 30,729 |  |  | — |  |  | 30,729 |  |  | — |  |  | 62,052 |  |  | — |  |  | 62,052 |  |
| Commercial Vehicle Products |  | — |  |  | 32,862 |  |  | — |  |  | 32,862 |  |  | — |  |  | 64,090 |  |  | — |  |  | 64,090 |  |
| Industrial Products |  | — |  |  | — |  |  | 32,654 |  |  | 32,654 |  |  | — |  |  | — |  |  | 59,926 |  |  | 59,926 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

[0000889331-19-000042:notes:12]
See Note 16, Segment Information for net sales by segment and countries.

[0000889331-19-000042:notes:13]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-19-000042:notes:14]
The Company elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-19-000042:notes:15]
Revenue and Billing

[0000889331-19-000042:notes:16]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

[0000889331-19-000042:notes:17]
Ship and Debit Program

[0000889331-19-000042:notes:18]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-19-000042:notes:19]
Return to Stock

[0000889331-19-000042:notes:20]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-19-000042:notes:21]
Volume Rebates

[0000889331-19-000042:notes:22]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-19-000042:notes:23]
Recently Adopted Accounting Standards

[0000889331-19-000042:notes:24]
In February 2016,  the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, "Leases" (Topic 842), ("ASC 842"). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption requires using a modified retrospective transition with either 1) periods prior to the adoption date being recast or 2) a cumulative-effect adjustment recognized to the opening balance of retained earnings on the adoption date with prior periods not recast.

[0000889331-19-000042:notes:25]
The Company adopted the standard on December 30, 2018 using alternative modified retrospective transition method provided in ASU No. 2018-11, "Leases (Topic 842): Target Improvements." Under this method, the Company recorded a cumulative-effect adjustment as of December 30, 2018 and did not record any retrospective adjustments to comparative periods to reflect the adoption of ASC 842. The new standard provides a number of optional practical expedients in transition. The Company has elected the ‘package of practical expedients’ which permits us not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct costs. The Company has not elected the use-of-hindsight. Adoption of  ASC 842 resulted in the recognition of operating lease right-of-use assets ("ROU") net of deferred rent of $26.1 million and lease liabilities of $29.4 million, as of December 30, 2018 for operating leases on its Condensed Consolidated Balance Sheets, with no  impact to its Condensed Consolidated Statements of Net Income and no impact on Condensed Consolidated Statements of Cash Flow. See Note 6, Lease Commitments, for further discussion.

[0000889331-19-000042:notes:26]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. The Company adopted the new standard on December 30, 2018. The adoption of this guidance did not have a material effect on our Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-19-000042:notes:27]
[same as prior period, unchanged from 0000889331-19-000030:notes:93]

[0000889331-19-000042:notes:28]
[same as prior period, unchanged from 0000889331-19-000030:notes:94]

[0000889331-19-000042:notes:29]
[same as prior period, unchanged from 0000889331-19-000030:notes:95]

[0000889331-19-000042:notes:30]
On January 17, 2018, the Company acquired IXYS Corporation (“IXYS”), a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 3,500 customers through its direct sales force and global distribution partners. The acquisition of IXYS is expected to accelerate the Company’s growth

[0000889331-19-000042:notes:31]
across the power control market driven by IXYS’s extensive power semiconductor portfolio and technology expertise. With IXYS, the Company will be able to diversify and expand its presence within industrial electronics markets, leveraging the strong IXYS industrial OEM customer base. The Company also expects to increase long-term penetration of its power semiconductor portfolio in automotive markets, expanding its global content per vehicle.

[0000889331-19-000042:notes:32]
[same as prior period, unchanged from 0000889331-19-000030:notes:97]

[0000889331-19-000042:notes:33]
[same as prior period, unchanged from 0000889331-19-000030:notes:98]

[0000889331-19-000042:notes:34]
[same as prior period, unchanged from 0000889331-19-000030:notes:99]

[0000889331-19-000042:notes:35]
[same as prior period, unchanged from 0000889331-19-000030:notes:100]

[0000889331-19-000042:notes:36]
[same as prior period, unchanged from 0000889331-19-000030:notes:101]

[0000889331-19-000042:notes:37]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and six months ended June 30, 2018 are net sales of approximately $100.2 million and $186.5 million, respectively, and a loss before income taxes of $13.9 million and $31.7 million, respectively, since the January 17, 2018 acquisition of IXYS. During the three and six months ended June 30,

[0000889331-19-000042:notes:38]
2018, the Company recognized a charge of $19.0 million and $36.9 million, respectively, for the amortization of the fair value inventory step-up. The step-up was a non-cash charge to cost of goods and reflected as other non-segment costs. The Company recognized approximately $1.6 million and $7.5 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the three and six months ended June 30, 2018, of which $4.5 million was recognized immediately as it related to prior services periods.

[0000889331-19-000042:notes:39]
During the three and six months ended June 30, 2018, the Company incurred approximately $0.8 million and $11.0 million, respectively, of legal and professional fees related to this acquisition which were primarily recognized as selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-19-000042:notes:40]
[same as prior period, unchanged from 0000889331-19-000030:notes:104]

[0000889331-19-000042:notes:41]
[same as prior period, unchanged from 0000889331-19-000030:notes:105]

[0000889331-19-000042:notes:42]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share amounts) |  | June 30, 2018 |  | June 30, 2018 |
| Net sales |  | $ | 459,183 |  |  | $ | 893,709 |  |
| Income before income taxes |  | 74,857 |  |  | 134,227 |  |
| Net income |  | 59,283 |  |  | 106,247 |  |
| Net income per share — basic |  | 2.37 |  |  | 4.26 |  |
| Net income per share — diluted |  | 2.33 |  |  | 4.22 |  |

[0000889331-19-000042:notes:43]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-19-000042:notes:44]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 30, 2018 |  | June 30, 2018 |
| Amortization(a) |  | $ | 3,298 |  |  | $ | 5,185 |  |
| Transaction costs(b) |  | — |  |  | 9,976 |  |
| Amortization of inventory step-up(c) |  | 19,031 |  |  | 36,927 |  |
| Stock compensation(d) |  | 210 |  |  | 4,689 |  |
| Income tax impact of above items |  | (5,582 | ) |  | (13,329 | ) |

[0000889331-19-000042:notes:45]
| (a) | The amortization adjustment for the three and six months ended June 30, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and was fully amortized in the fiscal 2017 pro forma results. |

[0000889331-19-000042:notes:46]
| (b) | The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the six months ended June 30, 2018 and recognition of those fees during the six months ended July 1, 2017. |

[0000889331-19-000042:notes:47]
| (c) | The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the three and six months ended June 30, 2018 and recognition of those costs during the three and six months ended July 1, 2017. The inventory step-up was amortized over five months as the inventory was sold. |

[0000889331-19-000042:notes:48]
(d)
The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the six months ended June 30, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-19-000042:notes:49]
[same as prior period, unchanged from 0000889331-19-000030:notes:82]

[0000889331-19-000042:notes:50]
The components of inventories at June 29, 2019 and December 29, 2018 are as follows:

[0000889331-19-000042:notes:51]
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| Raw materials |  | $ | 75,908 |  |  | $ | 69,883 |  |
| Work in process |  | 93,523 |  |  | 88,505 |  |
| Finished goods |  | 84,874 |  |  | 99,840 |  |
| Total |  | $ | 254,305 |  |  | $ | 258,228 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-19-000042:notes:52]
[same as prior period, unchanged from 0000889331-19-000030:notes:114]

[0000889331-19-000042:notes:53]
The components of net property, plant, and equipment at June 29, 2019 and December 29, 2018 are as follows:

[0000889331-19-000042:notes:54]
| (in thousands) | June 29, 2019 |  | December 29, 2018 |
| Land | $ | 24,962 |  |  | $ | 25,630 |  |
| Building | 106,962 |  |  | 114,636 |  |
| Equipment | 612,580 |  |  | 583,043 |  |
| Accumulated depreciation and amortization | (406,004 | ) |  | (383,415 | ) |
| Total | $ | 338,500 |  |  | $ | 339,894 |  |

[0000889331-19-000042:notes:55]
The Company recorded depreciation expense of $12.6 million and $12.8 million for the three months ended June 29, 2019 and June 30, 2018, respectively, and  $25.7 million  and $24.4 million for the six months ended June 29, 2019 and June 30, 2018, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-19-000042:notes:56]
[same as prior period, unchanged from 0000889331-19-000030:notes:72]

[0000889331-19-000042:notes:57]
The amounts for goodwill and changes in the carrying value by segment for the six months ended June 29, 2019 are as follows:

[0000889331-19-000042:notes:58]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 29, 2018 |  | $ | 656,039 |  |  | $ | 132,332 |  |  | $ | 38,344 |  |  | $ | 826,715 |  |
| Currency translation |  | (529 | ) |  | 89 |  |  | 133 |  |  | (307 | ) |
| As of June 29, 2019 |  | $ | 655,510 |  |  | $ | 132,421 |  |  | $ | 38,477 |  |  | $ | 826,408 |  |

[0000889331-19-000042:notes:59]
The components of other intangible assets at June 29, 2019 are as follows:

[0000889331-19-000042:notes:60]
| (in thousands) |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Patents, licenses and software |  | $ | 139,415 |  |  | $ | 75,175 |  |  | $ | 64,240 |  |
| Distribution network |  | 43,900 |  |  | 35,702 |  |  | 8,198 |  |
| Customer relationships, trademarks, and tradenames |  | 374,658 |  |  | 105,922 |  |  | 268,736 |  |
| Total |  | $ | 557,973 |  |  | $ | 216,799 |  |  | $ | 341,174 |  |

[0000889331-19-000042:notes:61]
During the three months ended June 29, 2019 and June 30, 2018, the Company recorded amortization expense of $10.1 million and $13.4 million, respectively. During the six months ended June 29, 2019 and June 30, 2018, the Company recorded amortization expense of $20.2 million and $25.4 million, respectively.

[0000889331-19-000042:notes:62]
Estimated annual amortization expense related to intangible assets with definite lives as of June 29, 2019 is as follows:

[0000889331-19-000042:notes:63]
| (in thousands) | Amount |
| 2019 | $ | 40,119 |  |
| 2020 | 39,458 |  |
| 2021 | 36,833 |  |
| 2022 | 36,743 |  |
| 2023 | 31,524 |  |
| 2024 and thereafter | 176,738 |  |
| Total | $ | 361,415 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000889331-19-000042:notes:64]
[same as prior period, unchanged from 0000889331-19-000030:notes:89]

[0000889331-19-000042:notes:65]
The Company leases office and production space under various non-cancelable operating leases that expire no later than 2025. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The Company also has production equipment, office equipment and vehicles under operating leases. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants.

[0000889331-19-000042:notes:66]
[same as prior period, unchanged from 0000889331-19-000030:notes:91]

[0000889331-19-000042:notes:67]
[same as prior period, unchanged from 0000889331-19-000030:notes:92]

[0000889331-19-000042:notes:68]
The following table presents the classification of ROU assets and lease liabilities as of June 29, 2019:

[0000889331-19-000042:notes:69]
| Leases(in thousands) | Condensed Consolidated Balance Sheet Classification | June 29, 2019 |
| Assets |  |  |
| Operating ROU assets | Right of use lease assets, net | $ | 23,280 |  |
| Liabilities |  |  |
| Current operating lease liabilities | Accrued liabilities | $ | 7,349 |  |
| Non-current operating lease liabilities | Non-current operating lease liabilities | 18,643 |  |
| Total lease liabilities |  | $ | 25,992 |  |

[0000889331-19-000042:notes:70]
The following table represents the lease costs for the three and six months ended June 29, 2019:

[0000889331-19-000042:notes:71]
| Leases cost(in thousands) | Condensed Consolidated Statements of Net Income Classification | Three Months Ended June 29, 2019 | Six Months EndedJune 29, 2019 |
| Short-term lease expenses | Cost of sales, SG&A expenses | $ | 148 |  | $ | 301 |  |
| Variable lease expenses | Cost of sales, SG&A expenses | 187 |  | 381 |  |
| Operating lease rent expenses | Cost of sales, SG&A expenses | 2,215 |  | 4,408 |  |
| Total operating lease costs | Cost of sales, SG&A expenses | $ | 2,550 |  | $ | 5,090 |  |

[0000889331-19-000042:notes:72]
| Maturity of Lease Liabilities as of June 29, 2019(in thousands) | Operating leases |
| 2019 (excluding the six months ended June 29, 2019) | $ | 4,476 |  |
| 2020 | 7,594 |  |
| 2021 | 5,861 |  |
| 2022 | 4,829 |  |
| 2023 | 3,190 |  |
| 2024 and thereafter | 3,147 |  |
| Total lease payments | $ | 29,097 |  |
| Present value of lease liabilities | $ | 25,992 |  |

[0000889331-19-000042:notes:73]
| Operating Lease Term and Discount Rate | June 29, 2019 |
| Weighted-average remaining lease term (years) | 4.26 |  |
| Weighted-average discount rate | 5.17 | % |

[0000889331-19-000042:notes:74]
| Other Information(in thousands) | Six Months EndedJune 29, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flow payments for operating leases | $ | (4,463 | ) |
| Leased assets obtained in exchange for operating lease liabilities | 1,510 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-19-000042:notes:75]
[same as prior period, unchanged from 0000889331-19-000030:notes:4]

[0000889331-19-000042:notes:76]
The components of accrued liabilities at June 29, 2019 and December 29, 2018 are as follows:

[0000889331-19-000042:notes:77]
| (in thousands) | June 29, 2019 |  | December 29, 2018 |
| Employee-related liabilities | $ | 36,048 |  |  | $ | 60,640 |  |
| Other non-income taxes | 30,467 |  |  | 21,523 |  |
| Operating lease liability | 7,349 |  |  | — |  |
| Professional services | 4,595 |  |  | 6,169 |  |
| Interest | 4,366 |  |  | 5,137 |  |
| Accrued share repurchases | — |  |  | 4,349 |  |
| Restructuring liability | 4,753 |  |  | 3,887 |  |
| Other | 24,118 |  |  | 36,700 |  |
| Total | $ | 111,696 |  |  | $ | 138,405 |  |

[0000889331-19-000042:notes:78]
[same as prior period, unchanged from 0000889331-19-000030:notes:7]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-19-000042:notes:79]
[same as prior period, unchanged from 0000889331-19-000030:notes:124]

[0000889331-19-000042:notes:80]
The Company recorded restructuring, impairment and other charges for the three and six months ended June 29, 2019 and June 30, 2018 as follows:

[0000889331-19-000042:notes:81]
|  | Three months ended June 29, 2019 |  | Six months ended June 29, 2019 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 1,698 |  |  | $ | 3,241 |  |  | $ | 674 |  |  | $ | 5,613 |  |  | $ | 3,498 |  |  | $ | 3,846 |  |  | $ | 721 |  |  | $ | 8,065 |  |
| Other restructuring charges | — |  |  | 70 |  |  | — |  |  | 70 |  |  | 13 |  |  | 90 |  |  | 250 |  |  | 353 |  |
| Total restructuring charges | 1,698 |  |  | 3,311 |  |  | 674 |  |  | 5,683 |  |  | 3,511 |  |  | 3,936 |  |  | 971 |  |  | 8,418 |  |
| Total | $ | 1,698 |  |  | $ | 3,311 |  |  | $ | 674 |  |  | $ | 5,683 |  |  | $ | 3,511 |  |  | $ | 3,936 |  |  | $ | 971 |  |  | $ | 8,418 |  |

[0000889331-19-000042:notes:82]
|  | Three months ended June 30, 2018 |  | Six months ended June 30, 2018 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 2,402 |  |  | $ | — |  |  | $ | 62 |  |  | $ | 2,464 |  |  | $ | 3,079 |  |  | $ | 99 |  |  | $ | 65 |  |  | $ | 3,243 |  |
| Other restructuring charges | 670 |  |  | — |  |  | — |  |  | 670 |  |  | 670 |  |  | — |  |  | — |  |  | 670 |  |
| Total restructuring charges | 3,072 |  |  | — |  |  | 62 |  |  | 3,134 |  |  | 3,749 |  |  | 99 |  |  | 65 |  |  | 3,913 |  |
| Impairment | — |  |  | 88 |  |  | 1,037 |  |  | 1,125 |  |  | — |  |  | 88 |  |  | 1,037 |  |  | 1,125 |  |
| Total | $ | 3,072 |  |  | $ | 88 |  |  | $ | 1,099 |  |  | $ | 4,259 |  |  | $ | 3,749 |  |  | $ | 187 |  |  | $ | 1,102 |  |  | $ | 5,038 |  |

[0000889331-19-000042:notes:83]
[same as prior period, unchanged from 0000889331-19-000030:notes:128]

[0000889331-19-000042:notes:84]
For the three and six months ended June 29, 2019, the Company recorded total restructuring charges of $5.7 million and $8.4 million, respectively, for employee termination costs and other restructuring charges.These charges primarily related to the reorganization of operations and selling, general and administrative functions as well as the integration of IXYS within the Electronics segment and the reorganization of operations in the automotive sensors and commercial vehicle products businesses within the Automotive segment.

[0000889331-19-000042:notes:85]
In April 2019, we announced the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment. The Company recorded $1.7 million of employee termination costs associated with this plant closure.

[0000889331-19-000042:notes:86]
[same as prior period, unchanged from 0000889331-19-000030:notes:131]

[0000889331-19-000042:notes:87]
For the three and six months ended June 30, 2018, the Company recorded total restructuring charges of $3.1 million and $3.9 million, respectively, for employee termination costs and other restructuring charges related to lease termination and facility closure. These charges primarily related to the integration of IXYS and the reorganization of the IXYS Radio Pulse business within the Electronics segment. For the three and six months ended June 30, 2018, the Company recorded impairment charges of $1.1 million primarily related to the impairment of a building and a trade name associated with the exit of the Custom business within the Industrial segment.

[0000889331-19-000042:notes:88]
The restructuring reserves as of June 29, 2019 and December 29, 2018 are $4.8 million and $3.9 million, respectively. The restructuring reserves are included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by December 2019.


## us-gaap:DebtDisclosureTextBlock

[0000889331-19-000042:notes:89]
Debt

[0000889331-19-000042:notes:90]
The carrying amounts of debt at June 29, 2019 and December 29, 2018 are as follows:

[0000889331-19-000042:notes:91]
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 132,992 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 107,984 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,155 | ) |  | (4,636 | ) |
| Total debt |  | 686,940 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,940 |  |  | $ | 684,730 |  |

[0000889331-19-000042:notes:92]
Revolving Credit Facility / Term Loan

[0000889331-19-000042:notes:93]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-19-000042:notes:94]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $2.5 million and $7.5 million on the term loan during the three and six months ended June 29, 2019.

[0000889331-19-000042:notes:95]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.65% at June 29, 2019.

[0000889331-19-000042:notes:96]
As of June 29, 2019, the Company had $0.1 million outstanding in letters of credit and had available $531.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At June 29, 2019, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-19-000042:notes:97]
Senior Notes

[0000889331-19-000042:notes:98]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023

[0000889331-19-000042:notes:99]
(“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-19-000042:notes:100]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-19-000042:notes:101]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-19-000042:notes:102]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-19-000042:notes:103]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 29, 2019, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-19-000042:notes:104]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-19-000042:notes:105]
Interest paid on all Company debt was $3.5 million and $3.7 million for the three months ended June 29, 2019 and June 30, 2018, respectively, and $11.5 million and $7.7 million for the six months ended June 29, 2019 and June 30, 2018, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-19-000042:notes:106]
[same as prior period, unchanged from 0000889331-19-000030:notes:59]

[0000889331-19-000042:notes:107]
[same as prior period, unchanged from 0000889331-19-000030:notes:60]

[0000889331-19-000042:notes:108]
[same as prior period, unchanged from 0000889331-19-000030:notes:61]

[0000889331-19-000042:notes:109]
[same as prior period, unchanged from 0000889331-19-000030:notes:62]

[0000889331-19-000042:notes:110]
[same as prior period, unchanged from 0000889331-19-000030:notes:63]

[0000889331-19-000042:notes:111]
[same as prior period, unchanged from 0000889331-19-000030:notes:64]

[0000889331-19-000042:notes:112]
[same as prior period, unchanged from 0000889331-19-000030:notes:65]

[0000889331-19-000042:notes:113]
[same as prior period, unchanged from 0000889331-19-000030:notes:66]

[0000889331-19-000042:notes:114]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the six months ended June 29, 2019, the Company recorded impairment charges of $2.8 million in Other expense (income), net in the Condensed Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value of $1.2 million. The fair value of these investments are measured on a nonrecurring basis and determined to be Level 3 under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-19-000042:notes:115]
[same as prior period, unchanged from 0000889331-19-000030:notes:68]

[0000889331-19-000042:notes:116]
[same as prior period, unchanged from 0000889331-19-000030:notes:69]

[0000889331-19-000042:notes:117]
There were no changes during the quarter ended June 29, 2019 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of June 29, 2019 and December 29, 2018, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-19-000042:notes:118]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of June 29, 2019:

[0000889331-19-000042:notes:119]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Investments in equity securities |  | $ | 11,161 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,161 |  |
| Mutual funds |  | 9,619 |  |  | — |  |  | — |  |  | 9,619 |  |

[0000889331-19-000042:notes:120]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 29, 2018:

[0000889331-19-000042:notes:121]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Investments in equity securities |  | $ | 10,312 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,312 |  |
| Mutual funds |  | 9,112 |  |  | — |  |  | — |  |  | 9,112 |  |

[0000889331-19-000042:notes:122]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at June 29, 2019 and December 29, 2018, as the rates on these borrowings are variable in nature.

[0000889331-19-000042:notes:123]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of June 29, 2019 and December 29, 2018 were as follows:

[0000889331-19-000042:notes:124]
|  |  | June 29, 2019 |  | December 29, 2018 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 132,992 |  |  | $ | 136,568 |  |  | $ | 133,417 |  |  | $ | 130,888 |  |
| Euro Senior Notes, Series B due 2028 |  | 107,984 |  |  | 116,210 |  |  | 108,330 |  |  | 103,774 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 24,781 |  |  | 25,000 |  |  | 24,115 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,440 |  |  | 100,000 |  |  | 94,458 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 49,884 |  |  | 50,000 |  |  | 47,434 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 123,756 |  |  | 125,000 |  |  | 114,731 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-19-000042:notes:125]
[same as prior period, unchanged from 0000889331-19-000030:notes:109]

[0000889331-19-000042:notes:126]
[same as prior period, unchanged from 0000889331-19-000030:notes:110]

[0000889331-19-000042:notes:127]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and six months ended June 29, 2019 and June 30, 2018 were as follows:

[0000889331-19-000042:notes:128]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 514 |  |  | $ | 533 |  |  | $ | 1,014 |  |  | $ | 1,066 |  |
| Interest cost |  | 813 |  |  | 501 |  |  | 1,597 |  |  | 1,002 |  |
| Expected return on plan assets |  | (821 | ) |  | (540 | ) |  | (1,611 | ) |  | (1,080 | ) |
| Amortization of prior service |  | 62 |  |  | 74 |  |  | 124 |  |  | 148 |  |
| Net periodic benefit cost |  | $ | 568 |  |  | $ | 568 |  |  | $ | 1,124 |  |  | $ | 1,136 |  |

[0000889331-19-000042:notes:129]
[same as prior period, unchanged from 0000889331-19-000030:notes:113]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-19-000042:notes:130]
[same as prior period, unchanged from 0000889331-19-000030:notes:18]

[0000889331-19-000042:notes:131]
Changes in other comprehensive (loss) income by component were as follows:

[0000889331-19-000042:notes:132]
| (in thousands) |  | Three Months EndedJune 29, 2019 |  | Three Months EndedJune 30, 2018 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 201 |  |  | $ | 40 |  |  | $ | 161 |  |  | $ | 803 |  |  | $ | 37 |  |  | $ | 766 |  |
| Foreign currency translation adjustments |  | (5,892 | ) |  | — |  |  | (5,892 | ) |  | (16,708 | ) |  | — |  |  | (16,708 | ) |
| Total change in other comprehensive income (loss) |  | $ | (5,691 | ) |  | $ | 40 |  |  | $ | (5,731 | ) |  | $ | (15,905 | ) |  | $ | 37 |  |  | $ | (15,942 | ) |

[0000889331-19-000042:notes:133]
| (in thousands) |  | Six Months EndedJune 29, 2019 |  | Six Months EndedJune 30, 2018 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 123 |  |  | $ | 11 |  |  | $ | 112 |  |  | $ | 734 |  |  | $ | (29 | ) |  | $ | 763 |  |
| Foreign currency translation adjustments |  | 2,230 |  |  | — |  |  | 2,230 |  |  | (16,984 | ) |  | — |  |  | (16,984 | ) |
| Total change in other comprehensive income (loss) |  | $ | 2,353 |  |  | $ | 11 |  |  | $ | 2,342 |  |  | $ | (16,250 | ) |  | $ | (29 | ) |  | $ | (16,221 | ) |

[0000889331-19-000042:notes:134]
The following tables set forth the changes in accumulated other comprehensive (loss) income by component for the six months ended June 29, 2019 and June 30, 2018:

[0000889331-19-000042:notes:135]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 29, 2018 |  | $ | (9,959 | ) |  | $ | (87,965 | ) |  | $ | (97,924 | ) |
| Activity in the period |  | 112 |  |  | 2,230 |  |  | 2,342 |  |
| Balance at June 29, 2019 |  | $ | (9,847 | ) |  | $ | (85,735 | ) |  | $ | (95,582 | ) |

[0000889331-19-000042:notes:136]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Unrealizedgain (loss) oninvestments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 30, 2017 |  | $ | (10,836 | ) |  | $ | 9,795 |  |  | $ | (62,627 | ) |  | $ | (63,668 | ) |
| Cumulative effect adjustment (a) |  | — |  |  | (9,795 | ) |  | — |  |  | (9,795 | ) |
| Activity in the period |  | 763 |  |  | — |  |  | (16,984 | ) |  | (16,221 | ) |
| Balance at June 30, 2018 |  | $ | (10,073 | ) |  | $ | — |  |  | $ | (79,611 | ) |  | $ | (89,684 | ) |

[0000889331-19-000042:notes:137]
(a)The Company adopted ASU 2016-01 on December 31, 2017 on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings.

[0000889331-19-000042:notes:138]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three and six months ended June 29, 2019 and June 30, 2018 were as follows:

[0000889331-19-000042:notes:139]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service |  | $ | 62 |  |  | $ | 74 |  |  | $ | 124 |  |  | $ | 148 |  |

[0000889331-19-000042:notes:140]
[same as prior period, unchanged from 0000889331-19-000030:notes:27]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-19-000042:notes:141]
[same as prior period, unchanged from 0000889331-19-000030:notes:80]

[0000889331-19-000042:notes:142]
The effective tax rate for the three and six months ended June 29, 2019 was 18.2% and 19.2% respectively, compared to the effective tax rate for the three and six months ended June 30, 2018 of 19.1% and 19.2% respectively. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-19-000042:notes:143]
[same as prior period, unchanged from 0000889331-19-000030:notes:47]

[0000889331-19-000042:notes:144]
[same as prior period, unchanged from 0000889331-19-000030:notes:48]

[0000889331-19-000042:notes:145]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share amounts) |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 43,792 |  |  | $ | 42,326 |  |  | $ | 80,781 |  |  | $ | 78,354 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,740 |  |  | 25,004 |  |  | 24,729 |  |  | 24,671 |  |
| Effect of dilutive securities |  | 243 |  |  | 397 |  |  | 269 |  |  | 415 |  |
| Diluted |  | 24,983 |  |  | 25,401 |  |  | 24,998 |  |  | 25,086 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.77 |  |  | $ | 1.69 |  |  | $ | 3.27 |  |  | $ | 3.18 |  |
| Diluted earnings per share |  | $ | 1.75 |  |  | $ | 1.67 |  |  | $ | 3.23 |  |  | $ | 3.12 |  |

[0000889331-19-000042:notes:146]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 167,599 and 47,849 for the three months ended June 29, 2019 and June 30, 2018, respectively, and 121,326 and 23,659 for the six months ended June 29, 2019 and June 30, 2018, respectively .

[0000889331-19-000042:notes:147]
[same as prior period, unchanged from 0000889331-19-000030:notes:51]

[0000889331-19-000042:notes:148]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program"). During the three and six months ended June 29, 2019, the Company repurchased 188,214 and 268,130 shares of its common stock totaling $32.0 million and $45.5 million, respectively.

[0000889331-19-000042:notes:149]
As of July 26, 2019, the Company repurchased 49,816 shares of its common stock since the quarter ended June 29, 2019.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-19-000042:notes:150]
Related Party Transactions

[0000889331-19-000042:notes:151]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method and recorded in investments in the Condensed Consolidated Balance Sheets. The following is a description of the investments and related party transactions.

[0000889331-19-000042:notes:152]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For the three months ended June 29, 2019 and June 30, 2018, the Company recorded revenues of $0.1 million and $0.3 million from sales of products to Powersem for use as components in their products, respectively. For the six months ended June 29, 2019 and June 30, 2018, the Company recorded revenues of $0.2 million and $0.4 million from sales of products to Powersem for use as components in their products, respectively. During the three months ended June 29, 2019 and June 30, 2018, the Company purchased $0.9 million and $1.0 million of products from Powersem, respectively. During the six months ended June 29, 2019 and June 30, 2018, the Company purchased $1.7 million and $2.1 million of products from Powersem, respectively. As of June 29, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

[0000889331-19-000042:notes:153]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During both the three months ended June 29, 2019 and June 30, 2018, EB Tech rendered processing services for the Company totaling approximately $0.1 million. During both the  six months ended June 29, 2019 and June 30, 2018, EB Tech rendered processing services for the Company totaling approximately $0.2 million. As of June 29, 2019 and December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

[0000889331-19-000042:notes:154]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended June 29, 2019 and June 30, 2018, ATEC rendered assembly and test services to the Company totaling approximately $2.3 million and $2.8 million, respectively. During the six months ended June 29, 2019 and June 30, 2018, ATEC rendered assembly and test services to the Company totaling approximately $3.8 million and $5.2 million, respectively. As of June 29, 2019 and December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.

[0000889331-19-000042:notes:155]
On March 25, 2019, the Company entered into a definitive agreement to sell the assets and liabilities of Microwave Technology, Inc. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net Income. The operations of Microwave Technology, Inc. were included in the Electronics segment. One member of the Company’s  Board of Directors is the co-owner of a company that agreed to purchase MWT. This transaction closed on April 26, 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-19-000042:notes:156]
[same as prior period, unchanged from 0000889331-19-000030:notes:159]

[0000889331-19-000042:notes:157]
[same as prior period, unchanged from 0000889331-19-000030:notes:160]

[0000889331-19-000042:notes:158]
[same as prior period, unchanged from 0000889331-19-000030:notes:161]

[0000889331-19-000042:notes:159]
[same as prior period, unchanged from 0000889331-19-000030:notes:162]

[0000889331-19-000042:notes:160]
[same as prior period, unchanged from 0000889331-19-000030:notes:163]

[0000889331-19-000042:notes:161]
[same as prior period, unchanged from 0000889331-19-000030:notes:164]

[0000889331-19-000042:notes:162]
Segment information is summarized as follows:

[0000889331-19-000042:notes:163]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 259,553 |  |  | $ | 299,357 |  |  | $ | 524,947 |  |  | $ | 563,768 |  |
| Automotive |  | 108,650 |  |  | 127,172 |  |  | 222,133 |  |  | 253,302 |  |
| Industrial |  | 29,676 |  |  | 32,654 |  |  | 56,299 |  |  | 59,926 |  |
| Total net sales |  | $ | 397,879 |  |  | $ | 459,183 |  |  | $ | 803,379 |  |  | $ | 876,996 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 14,729 |  |  | $ | 15,651 |  |  | $ | 30,071 |  |  | $ | 29,329 |  |
| Automotive |  | 6,904 |  |  | 5,969 |  |  | 13,781 |  |  | 11,939 |  |
| Industrial |  | 1,056 |  |  | 1,467 |  |  | 2,116 |  |  | 2,927 |  |
| Other |  | — |  |  | 3,103 |  |  | — |  |  | 5,607 |  |
| Total depreciation and amortization |  | $ | 22,689 |  |  | $ | 26,190 |  |  | $ | 45,968 |  |  | $ | 49,802 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 43,630 |  |  | $ | 67,311 |  |  | $ | 92,666 |  |  | $ | 121,275 |  |
| Automotive |  | 10,349 |  |  | 15,711 |  |  | 23,550 |  |  | 34,102 |  |
| Industrial |  | 5,831 |  |  | 5,279 |  |  | 9,336 |  |  | 9,988 |  |
| Other(a) |  | (7,176 | ) |  | (28,679 | ) |  | (12,245 | ) |  | (68,172 | ) |
| Total operating income |  | 52,634 |  |  | 59,622 |  |  | 113,307 |  |  | 97,193 |  |
| Interest expense |  | 5,589 |  |  | 5,782 |  |  | 11,275 |  |  | 11,205 |  |
| Foreign exchange (gain) loss |  | (3,575 | ) |  | 3,200 |  |  | 668 |  |  | (7,354 | ) |
| Other (income) expense, net |  | (2,947 | ) |  | (1,678 | ) |  | 1,358 |  |  | (3,621 | ) |
| Income before income taxes |  | $ | 53,567 |  |  | $ | 52,318 |  |  | $ | 100,006 |  |  | $ | 96,963 |  |

[0000889331-19-000042:notes:164]
(a) Included in “Other” Operating income (loss) for the 2019 second quarter is $1.5 million ($3.8 million year-to-date) of acquisition related and integration charges primarily related to the IXYS acquisition. In addition, there were $5.7 million ($8.4 million year-to-date)of restructuring charges primarily related to employee termination costs. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-19-000042:notes:165]
Included in "Other" Operating income (loss) for the second quarter of  2018 is includes approximately  $26.8 million ($65.4 million year-to-date) of charges primarily related to the IXYS acquisition, which include $19.0 million ($36.9 million year-to-date) of purchase accounting inventory step-up charges, $2.0 million ($13.6 million year-to-date) in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $3.1 million ($5.6 million year-to-date) in backlog amortization costs,   $2.7 million of employee termination costs and other restructuring charges, and $4.5 million year-to-date stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million year-to-date change in control expense related to IXYS. In addition, there were $0.5 million ($1.2 million year-to-date) of employee termination costs, other restructuring, impairment charges of $1.1 million associated with the exit of the Custom business in the second quarter, and $0.3 million ($0.5 million year-to-date) of acquisition-related expenses for other contemplated acquisitions.

[0000889331-19-000042:notes:166]
The Company’s net sales by country were as follows:

[0000889331-19-000042:notes:167]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 115,991 |  |  | $ | 137,236 |  |  | $ | 235,519 |  |  | $ | 261,112 |  |
| China |  | 107,728 |  |  | 127,776 |  |  | 214,593 |  |  | 234,284 |  |
| Other countries(a) |  | 174,160 |  |  | 194,171 |  |  | 353,267 |  |  | 381,600 |  |
| Total net sales |  | $ | 397,879 |  |  | $ | 459,183 |  |  | $ | 803,379 |  |  | $ | 876,996 |  |

[0000889331-19-000042:notes:168]
The Company’s long-lived assets by country were as follows:

[0000889331-19-000042:notes:169]
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 58,015 |  |  | $ | 58,691 |  |
| China |  | 92,621 |  |  | 95,806 |  |
| Mexico |  | 74,147 |  |  | 70,495 |  |
| Germany |  | 37,976 |  |  | 36,548 |  |
| Philippines |  | 37,275 |  |  | 32,459 |  |
| Other countries(a) |  | 38,466 |  |  | 45,895 |  |
| Total long-lived assets |  | $ | 338,500 |  |  | $ | 339,894 |  |

[0000889331-19-000042:notes:170]
The Company’s additions to long-lived assets by country were as follows:

[0000889331-19-000042:notes:171]
|  |  | Six Months Ended |
| (in thousands) |  | June 29, 2019 |  | June 30, 2018 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 3,454 |  |  | $ | 4,234 |  |
| China |  | 4,958 |  |  | 14,711 |  |
| Mexico |  | 8,727 |  |  | 8,874 |  |
| Germany |  | 3,712 |  |  | 5,182 |  |
| Philippines |  | 6,629 |  |  | 4,241 |  |
| Other countries(a) |  | 2,378 |  |  | 3,073 |  |
| Total additions to long-lived assets |  | $ | 29,858 |  |  | $ | 40,315 |  |

[0000889331-19-000042:notes:172]
(a)

[0000889331-19-000042:notes:173]
Each country included in other countries are less than 10% of net sales.
