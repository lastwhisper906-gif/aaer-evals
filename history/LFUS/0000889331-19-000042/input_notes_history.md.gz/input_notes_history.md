# LFUS note change history — 0000889331-19-000030 → 0000889331-19-000042


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000889331-19-000042:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2019 and June 30, 2018 :
  (was, 2019-05-01, similarity 0.9051):
[0000889331-19-000030:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2019 and March 31, 2018 :

- added (2019-07-31):
[0000889331-19-000042:note_history:2]
|  |  | Three Months Ended June 29, 2019 |  | Six Months Ended June 29, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

- added (2019-07-31):
[0000889331-19-000042:note_history:3]
|  |  | Three Months Ended June 30, 2018 |  | Six Months Ended June 30, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  | 171,036 |  |  | — |  |  | — |  |  | 171,036 |  |  | 320,952 |  |  | — |  |  | — |  |  | 320,952 |  |
| Passenger Car Products |  | — |  |  | 63,581 |  |  | — |  |  | 63,581 |  |  | — |  |  | 127,160 |  |  | — |  |  | 127,160 |  |
| Automotive Sensors |  | — |  |  | 30,729 |  |  | — |  |  | 30,729 |  |  | — |  |  | 62,052 |  |  | — |  |  | 62,052 |  |
| Commercial Vehicle Products |  | — |  |  | 32,862 |  |  | — |  |  | 32,862 |  |  | — |  |  | 64,090 |  |  | — |  |  | 64,090 |  |
| Industrial Products |  | — |  |  | — |  |  | 32,654 |  |  | 32,654 |  |  | — |  |  | — |  |  | 59,926 |  |  | 59,926 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- removed (2019-07-31):
[0000889331-19-000030:note_history:4]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  |  |  |  |  |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

- removed (2019-07-31):
[0000889331-19-000030:note_history:5]
|  |  | Three Months Ended March 31, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics – Semiconductor |  | 149,916 |  |  | — |  |  | — |  |  | 149,916 |  |
| Passenger Car Products |  | — |  |  | 63,580 |  |  | — |  |  | 63,580 |  |
| Automotive Sensors |  | — |  |  | 31,323 |  |  | — |  |  | 31,323 |  |
| Commercial Vehicle Products |  | — |  |  | 31,228 |  |  | — |  |  | 31,228 |  |
| Industrial Products |  | — |  |  |  |  |  | 27,271 |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000889331-19-000042:note_history:6]
The carrying amounts of debt at June 29, 2019 and December 29, 2018 are as follows:
  (was, 2019-05-01, similarity 0.9388):
[0000889331-19-000030:note_history:6]
The carrying amounts of debt at March 30, 2019 and December 29, 2018 are as follows:

- changed (2019-07-31):
[0000889331-19-000042:note_history:7]
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 132,992 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 107,984 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,155 | ) |  | (4,636 | ) |
| Total debt |  | 686,940 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,940 |  |  | $ | 684,730 |  |
  (was, 2019-05-01, similarity 0.9928):
[0000889331-19-000030:note_history:7]
| (in thousands) |  | March 30, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 150,000 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,499 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,772 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,380 | ) |  | (4,636 | ) |
| Total debt |  | 686,510 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,510 |  |  | $ | 684,730 |  |

- changed (2019-07-31):
[0000889331-19-000042:note_history:8]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $2.5 million and $7.5 million on the term loan during the three and six months ended June 29, 2019.
  (was, 2019-05-01, similarity 0.8306):
[0000889331-19-000030:note_history:8]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $5.0 million on the term loan during the three months ended March 30, 2019.

- changed (2019-07-31):
[0000889331-19-000042:note_history:9]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.65% at June 29, 2019.
  (was, 2019-05-01, similarity 0.9885):
[0000889331-19-000030:note_history:9]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.75% at March 30, 2019.

- added (2019-07-31):
[0000889331-19-000042:note_history:10]
As of June 29, 2019, the Company had $0.1 million outstanding in letters of credit and had available $531.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At June 29, 2019, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2019-07-31):
[0000889331-19-000042:note_history:11]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023
  (was, 2019-05-01, similarity 0.6978):
[0000889331-19-000030:note_history:11]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

- added (2019-07-31):
[0000889331-19-000042:note_history:12]
(“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

- changed (2019-07-31):
[0000889331-19-000042:note_history:13]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 29, 2019, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2019-05-01, similarity 0.9921):
[0000889331-19-000030:note_history:13]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 30, 2019, the Company was in compliance with all covenants under the Senior Notes.

- changed (2019-07-31):
[0000889331-19-000042:note_history:14]
Interest paid on all Company debt was $3.5 million and $3.7 million for the three months ended June 29, 2019 and June 30, 2018, respectively, and $11.5 million and $7.7 million for the six months ended June 29, 2019 and June 30, 2018, respectively.
  (was, 2019-05-01, similarity 0.686):
[0000889331-19-000030:note_history:14]
Interest paid on all Company debt was $8.0 million and $4.0 million in the three months ended March 30, 2019 and March 31, 2018, respectively.

- removed (2019-07-31):
[0000889331-19-000030:note_history:15]
As of March 30, 2019, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At March 30, 2019, the Company was in compliance with all covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000889331-19-000042:note_history:16]
The carrying amounts of debt at June 29, 2019 and December 29, 2018 are as follows:
  (was, 2019-05-01, similarity 0.9388):
[0000889331-19-000030:note_history:16]
The carrying amounts of debt at March 30, 2019 and December 29, 2018 are as follows:

- changed (2019-07-31):
[0000889331-19-000042:note_history:17]
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 132,992 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 107,984 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,155 | ) |  | (4,636 | ) |
| Total debt |  | 686,940 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,940 |  |  | $ | 684,730 |  |
  (was, 2019-05-01, similarity 0.9928):
[0000889331-19-000030:note_history:17]
| (in thousands) |  | March 30, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 150,000 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,499 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,772 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,380 | ) |  | (4,636 | ) |
| Total debt |  | 686,510 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,510 |  |  | $ | 684,730 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2019-07-31):
[0000889331-19-000042:note_history:18]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For the three months ended June 29, 2019 and June 30, 2018, the Company recorded revenues of $0.1 million and $0.3 million from sales of products to Powersem for use as components in their products, respectively. For the six months ended June 29, 2019 and June 30, 2018, the Company recorded revenues of $0.2 million and $0.4 million from sales of products to Powersem for use as components in their products, respectively. During the three months ended June 29, 2019 and June 30, 2018, the Company purchased $0.9 million and $1.0 million of products from Powersem, respectively. During the six months ended June 29, 2019 and June 30, 2018, the Company purchased $1.7 million and $2.1 million of products from Powersem, respectively. As of June 29, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

- added (2019-07-31):
[0000889331-19-000042:note_history:19]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During both the three months ended June 29, 2019 and June 30, 2018, EB Tech rendered processing services for the Company totaling approximately $0.1 million. During both the  six months ended June 29, 2019 and June 30, 2018, EB Tech rendered processing services for the Company totaling approximately $0.2 million. As of June 29, 2019 and December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

- changed (2019-07-31):
[0000889331-19-000042:note_history:20]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended June 29, 2019 and June 30, 2018, ATEC rendered assembly and test services to the Company totaling approximately $2.3 million and $2.8 million, respectively. During the six months ended June 29, 2019 and June 30, 2018, ATEC rendered assembly and test services to the Company totaling approximately $3.8 million and $5.2 million, respectively. As of June 29, 2019 and December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.
  (was, 2019-05-01, similarity 0.6463):
[0000889331-19-000030:note_history:20]
Automated Technology, Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended March 30, 2019 and March 31, 2018, ATEC rendered assembly and test services to the Company totaling approximately $1.5 million and $2.4 million, respectively. As of March 30, 2019, the Company’s accounts payable balance to ATEC was $0.4 million. As of December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.

- removed (2019-07-31):
[0000889331-19-000030:note_history:21]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For both the three months ended March 30, 2019 and March 31, 2018, the Company recorded revenues of $0.1 million from sales of products to Powersem for use as components in their products. During the three months ended March 30, 2019 and March 31, 2018, the Company purchased $0.8 million and $1.1 million of products from Powersem, respectively. As of March 30, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

- removed (2019-07-31):
[0000889331-19-000030:note_history:22]
EB Tech Ltd.: The Company owns approximately 20% of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. EB Tech rendered processing services for the Company totaling approximately $0.1 million for both three months ended March 30, 2019 and March 31, 2018. As of March 30, 2019 and December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000889331-19-000042:note_history:23]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2019 and June 30, 2018 :
  (was, 2019-05-01, similarity 0.9051):
[0000889331-19-000030:note_history:23]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2019 and March 31, 2018 :

- added (2019-07-31):
[0000889331-19-000042:note_history:24]
|  |  | Three Months Ended June 29, 2019 |  | Six Months Ended June 29, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

- added (2019-07-31):
[0000889331-19-000042:note_history:25]
|  |  | Three Months Ended June 30, 2018 |  | Six Months Ended June 30, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  | 171,036 |  |  | — |  |  | — |  |  | 171,036 |  |  | 320,952 |  |  | — |  |  | — |  |  | 320,952 |  |
| Passenger Car Products |  | — |  |  | 63,581 |  |  | — |  |  | 63,581 |  |  | — |  |  | 127,160 |  |  | — |  |  | 127,160 |  |
| Automotive Sensors |  | — |  |  | 30,729 |  |  | — |  |  | 30,729 |  |  | — |  |  | 62,052 |  |  | — |  |  | 62,052 |  |
| Commercial Vehicle Products |  | — |  |  | 32,862 |  |  | — |  |  | 32,862 |  |  | — |  |  | 64,090 |  |  | — |  |  | 64,090 |  |
| Industrial Products |  | — |  |  | — |  |  | 32,654 |  |  | 32,654 |  |  | — |  |  | — |  |  | 59,926 |  |  | 59,926 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- removed (2019-07-31):
[0000889331-19-000030:note_history:26]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  |  |  |  |  |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

- removed (2019-07-31):
[0000889331-19-000030:note_history:27]
|  |  | Three Months Ended March 31, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics – Semiconductor |  | 149,916 |  |  | — |  |  | — |  |  | 149,916 |  |
| Passenger Car Products |  | — |  |  | 63,580 |  |  | — |  |  | 63,580 |  |
| Automotive Sensors |  | — |  |  | 31,323 |  |  | — |  |  | 31,323 |  |
| Commercial Vehicle Products |  | — |  |  | 31,228 |  |  | — |  |  | 31,228 |  |
| Industrial Products |  | — |  |  |  |  |  | 27,271 |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-07-31):
[0000889331-19-000042:note_history:28]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2019 and June 30, 2018 :
  (was, 2019-05-01, similarity 0.9051):
[0000889331-19-000030:note_history:28]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 30, 2019 and March 31, 2018 :

- added (2019-07-31):
[0000889331-19-000042:note_history:29]
|  |  | Three Months Ended June 29, 2019 |  | Six Months Ended June 29, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

- added (2019-07-31):
[0000889331-19-000042:note_history:30]
|  |  | Three Months Ended June 30, 2018 |  | Six Months Ended June 30, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  | 171,036 |  |  | — |  |  | — |  |  | 171,036 |  |  | 320,952 |  |  | — |  |  | — |  |  | 320,952 |  |
| Passenger Car Products |  | — |  |  | 63,581 |  |  | — |  |  | 63,581 |  |  | — |  |  | 127,160 |  |  | — |  |  | 127,160 |  |
| Automotive Sensors |  | — |  |  | 30,729 |  |  | — |  |  | 30,729 |  |  | — |  |  | 62,052 |  |  | — |  |  | 62,052 |  |
| Commercial Vehicle Products |  | — |  |  | 32,862 |  |  | — |  |  | 32,862 |  |  | — |  |  | 64,090 |  |  | — |  |  | 64,090 |  |
| Industrial Products |  | — |  |  | — |  |  | 32,654 |  |  | 32,654 |  |  | — |  |  | — |  |  | 59,926 |  |  | 59,926 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- removed (2019-07-31):
[0000889331-19-000030:note_history:31]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  |  |  |  |  |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

- removed (2019-07-31):
[0000889331-19-000030:note_history:32]
|  |  | Three Months Ended March 31, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 114,495 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,495 |  |
| Electronics – Semiconductor |  | 149,916 |  |  | — |  |  | — |  |  | 149,916 |  |
| Passenger Car Products |  | — |  |  | 63,580 |  |  | — |  |  | 63,580 |  |
| Automotive Sensors |  | — |  |  | 31,323 |  |  | — |  |  | 31,323 |  |
| Commercial Vehicle Products |  | — |  |  | 31,228 |  |  | — |  |  | 31,228 |  |
| Industrial Products |  | — |  |  |  |  |  | 27,271 |  |  | 27,271 |  |
| Total |  | $ | 264,411 |  |  | $ | 126,131 |  |  | $ | 27,271 |  |  | $ | 417,813 |  |
