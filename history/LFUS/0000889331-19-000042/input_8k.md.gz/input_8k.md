# LFUS 8-K — 0000889331-19-000040 filed 2019-07-31

## item codes, every 8-K on or before 2019-07-31

- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2019-07-31

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-19-000040:8k_2_02:1]
EX-99.1
2
q22019earningsreleaseex991.htm
EXHIBIT 99.1

[0000889331-19-000040:8k_2_02:2]
Exhibit

[0000889331-19-000040:8k_2_02:3]
Exhibit 99.1

[0000889331-19-000040:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-19-000040:8k_2_02:5]
LITTELFUSE REPORTS SECOND QUARTER RESULTS FOR 2019

[0000889331-19-000040:8k_2_02:6]
Company increases dividend by 12% - continues double-digit increase

[0000889331-19-000040:8k_2_02:7]
CHICAGO, July 31, 2019 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the second quarter ended June 29, 2019:

[0000889331-19-000040:8k_2_02:8]
| • | Net sales of $397.9 million were down 13% versus the prior year period, and down 11% organically, primarily due to ongoing global trade uncertainties, continued efforts by distribution partners to reduce excess electronics channel inventories and further declines in global auto production, especially in China |

[0000889331-19-000040:8k_2_02:9]
| • | Segment performance versus the prior year period: |

[0000889331-19-000040:8k_2_02:10]
| • | Electronics sales decreased 13% (down 11% organically) |

[0000889331-19-000040:8k_2_02:11]
| • | Automotive sales decreased 15% (down 12% organically) |

[0000889331-19-000040:8k_2_02:12]
| • | Industrial sales decreased 9% due to the exit of the Custom business in 2018 (up 1% organically) |

[0000889331-19-000040:8k_2_02:13]
| • | GAAP diluted EPS was $1.75 and adjusted diluted EPS was $1.91. EPS was significantly impacted by lower volumes and associated leverage versus the prior year |

[0000889331-19-000040:8k_2_02:14]
| • | GAAP effective tax rate was 18.2% and the adjusted effective tax rate was 17.3% |

[0000889331-19-000040:8k_2_02:15]
| • | Cash flow from operations was $49.2 million and free cash flow was $38.0 million |

[0000889331-19-000040:8k_2_02:16]
| • | During the second quarter and through July 26, 2019, the company repurchased 188,214 and 49,816 shares of common stock, respectively, under its share purchase authorization |

[0000889331-19-000040:8k_2_02:17]
“We continue to work through the challenging business cycles in the electronics and automotive end markets which we expect to persist through this year,” said Dave Heinzmann, Littelfuse Chief Executive Officer. “We are actively managing costs while remaining focused on long-term growth drivers. During the quarter, we saw solid design activity and won business across a number of high-growth applications. With the strength of our core business and execution by our global teams, we are navigating the current environment as we deliver on our five-year growth strategy.”

[0000889331-19-000040:8k_2_02:18]
-more-

[0000889331-19-000040:8k_2_02:19]
For the third quarter of 2019*:

[0000889331-19-000040:8k_2_02:20]
| • | Net sales are expected to be in the range of $362 to $374 million |

[0000889331-19-000040:8k_2_02:21]
| • | Adjusted diluted EPS is expected to be in the range of $1.50 to $1.64 |

[0000889331-19-000040:8k_2_02:22]
| • | Adjusted effective tax rate is expected to be in the range of 20% - 21% |

[0000889331-19-000040:8k_2_02:23]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-19-000040:8k_2_02:24]
Dividend

[0000889331-19-000040:8k_2_02:25]
The company’s Board of Directors approved a 12% increase in the quarterly cash dividend from $0.43 to $0.48. This equates to an annualized dividend of $1.92 per share. The dividend will be paid on September 5, 2019 to shareholders of record as of August 22, 2019.

[0000889331-19-000040:8k_2_02:26]
Conference Call and Webcast Information

[0000889331-19-000040:8k_2_02:27]
Littelfuse will host a conference call today, Wednesday, July 31, 2019, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-19-000040:8k_2_02:28]
About Littelfuse

[0000889331-19-000040:8k_2_02:29]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Our 12,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-19-000040:8k_2_02:30]
-more-

[0000889331-19-000040:8k_2_02:31]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 29, 2018. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 29, 2018.

[0000889331-19-000040:8k_2_02:32]
Non-GAAP Financial Measures

[0000889331-19-000040:8k_2_02:33]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate, free cash flow, and adjusted leverage. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-19-000040:8k_2_02:34]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-19-000040:8k_2_02:35]
CONTACT: Trisha Tuntland

[0000889331-19-000040:8k_2_02:36]
Head of Investor Relations

[0000889331-19-000040:8k_2_02:37]
(773) 628-2163

[0000889331-19-000040:8k_2_02:38]
###

[0000889331-19-000040:8k_2_02:39]
LFUS-F

[0000889331-19-000040:8k_2_02:40]
LITTELFUSE, INC.

[0000889331-19-000040:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-19-000040:8k_2_02:42]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 474,781 |  |  | $ | 489,733 |  |
| Short-term investments |  | 34 |  |  | 34 |  |
| Trade receivables, less allowances of $34,468 and $36,038 at June 29, 2019 and December 29, 2018, respectively |  | 245,723 |  |  | 232,892 |  |
| Inventories |  | 254,305 |  |  | 258,228 |  |
| Prepaid income taxes and income taxes receivable |  | 1,374 |  |  | 2,339 |  |
| Prepaid expenses and other current assets |  | 63,332 |  |  | 49,291 |  |
| Total current assets |  | 1,039,549 |  |  | 1,032,517 |  |
| Net property, plant, and equipment |  | 338,500 |  |  | 339,894 |  |
| Intangible assets, net of amortization |  | 341,174 |  |  | 361,474 |  |
| Goodwill |  | 826,408 |  |  | 826,715 |  |
| Investments |  | 25,456 |  |  | 25,405 |  |
| Deferred income taxes |  | 9,200 |  |  | 7,330 |  |
| Right of use lease assets, net |  | 23,280 |  |  | — |  |
| Other assets |  | 18,018 |  |  | 20,971 |  |
| Total assets |  | $ | 2,621,585 |  |  | $ | 2,614,306 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 123,058 |  |  | $ | 126,323 |  |
| Accrued liabilities |  | 111,696 |  |  | 138,405 |  |
| Accrued income taxes |  | 21,657 |  |  | 20,547 |  |
| Current portion of long-term debt |  | 10,000 |  |  | 10,000 |  |
| Total current liabilities |  | 266,411 |  |  | 295,275 |  |
| Long-term debt, less current portion |  | 676,940 |  |  | 684,730 |  |
| Deferred income taxes |  | 53,039 |  |  | 51,853 |  |
| Accrued post-retirement benefits |  | 30,666 |  |  | 31,874 |  |
| Non-current operating lease liabilities |  | 18,643 |  |  | — |  |
| Other long-term liabilities |  | 65,944 |  |  | 72,232 |  |
| Total equity |  | 1,509,942 |  |  | 1,478,342 |  |
| Total liabilities and equity |  | $ | 2,621,585 |  |  | $ | 2,614,306 |  |

[0000889331-19-000040:8k_2_02:43]
LITTELFUSE, INC.

[0000889331-19-000040:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-19-000040:8k_2_02:45]
(Unaudited)

[0000889331-19-000040:8k_2_02:46]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) |  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Net sales |  | $ | 397,879 |  |  | $ | 459,183 |  |  | $ | 803,379 |  |  | $ | 876,996 |  |
| Cost of sales |  | 256,071 |  |  | 290,196 |  |  | 506,343 |  |  | 558,386 |  |
| Gross profit |  | 141,808 |  |  | 168,987 |  |  | 297,036 |  |  | 318,610 |  |
| Selling, general, and administrative expenses |  | 57,666 |  |  | 73,244 |  |  | 120,621 |  |  | 150,758 |  |
| Research and development expenses |  | 21,458 |  |  | 22,748 |  |  | 42,867 |  |  | 45,288 |  |
| Amortization of intangibles |  | 10,050 |  |  | 13,373 |  |  | 20,241 |  |  | 25,371 |  |
| Total operating expenses |  | 89,174 |  |  | 109,365 |  |  | 183,729 |  |  | 221,417 |  |
| Operating income |  | 52,634 |  |  | 59,622 |  |  | 113,307 |  |  | 97,193 |  |
| Interest expense |  | 5,589 |  |  | 5,782 |  |  | 11,275 |  |  | 11,205 |  |
| Foreign exchange (gain) loss |  | (3,575 | ) |  | 3,200 |  |  | 668 |  |  | (7,354 | ) |
| Other (income) expense, net |  | (2,947 | ) |  | (1,678 | ) |  | 1,358 |  |  | (3,621 | ) |
| Income before income taxes |  | 53,567 |  |  | 52,318 |  |  | 100,006 |  |  | 96,963 |  |
| Income taxes |  | 9,775 |  |  | 9,992 |  |  | 19,225 |  |  | 18,609 |  |
| Net income |  | $ | 43,792 |  |  | $ | 42,326 |  |  | $ | 80,781 |  |  | $ | 78,354 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.77 |  |  | $ | 1.69 |  |  | $ | 3.27 |  |  | $ | 3.18 |  |
| Diluted |  | $ | 1.75 |  |  | $ | 1.67 |  |  | $ | 3.23 |  |  | $ | 3.12 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,740 |  |  | 25,004 |  |  | 24,729 |  |  | 24,671 |  |
| Diluted |  | 24,983 |  |  | 25,401 |  |  | 24,998 |  |  | 25,086 |  |
| Comprehensive income |  | $ | 38,061 |  |  | $ | 26,384 |  |  | $ | 83,123 |  |  | $ | 62,133 |  |

[0000889331-19-000040:8k_2_02:47]
LITTELFUSE, INC.

[0000889331-19-000040:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-19-000040:8k_2_02:49]
(Unaudited)

[0000889331-19-000040:8k_2_02:50]
|  |  | Six Months Ended |
| (in thousands) |  | June 29, 2019 |  | June 30, 2018 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 80,781 |  |  | $ | 78,354 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 62,053 |  |  | 105,559 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (13,242 | ) |  | (33,481 | ) |
| Inventories |  | 6,230 |  |  | (1,502 | ) |
| Accounts payable |  | (17,927 | ) |  | 13,684 |  |
| Accrued liabilities and income taxes |  | (36,713 | ) |  | (16,383 | ) |
| Prepaid expenses and other assets |  | (1,090 | ) |  | (5,316 | ) |
| Net cash provided by operating activities |  | 80,092 |  |  | 140,915 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (775 | ) |  | (310,487 | ) |
| Purchases of property, plant, and equipment |  | (25,249 | ) |  | (40,315 | ) |
| Proceeds from sale of property, plant, and equipment |  | 6,212 |  |  | 68 |  |
| Net cash used in investing activities |  | (19,812 | ) |  | (350,734 | ) |
| FINANCING ACTIVITIES |  |  |  |  |
| Net (payments) proceeds from credit facility and senior notes |  | (7,500 | ) |  | 209,975 |  |
| Purchases of common stock |  | (49,861 | ) |  | — |  |
| Cash dividends paid |  | (21,274 | ) |  | (18,458 | ) |
| All other cash provided by financing activities |  | 3,011 |  |  | 4,690 |  |
| Net cash (used in) provided by financing activities |  | (75,624 | ) |  | 196,207 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 392 |  |  | (7,917 | ) |
| Decrease in cash and cash equivalents |  | (14,952 | ) |  | (21,529 | ) |
| Cash and cash equivalents at beginning of period |  | 489,733 |  |  | 429,676 |  |
| Cash and cash equivalents at end of period |  | $ | 474,781 |  |  | $ | 408,147 |  |

[0000889331-19-000040:8k_2_02:51]
LITTELFUSE, INC.

[0000889331-19-000040:8k_2_02:52]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-19-000040:8k_2_02:53]
(Unaudited)

[0000889331-19-000040:8k_2_02:54]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Growth /(Decline) |  | 2019 |  | 2018 |  | Change |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 259,553 |  |  | $ | 299,357 |  |  | $ | (39,804 | ) |  | (13.3 | )% |  | $ | 524,947 |  |  | $ | 563,768 |  |  | $ | (38,821 | ) |  | (6.9 | )% |
| Automotive |  | 108,650 |  |  | 127,172 |  |  | (18,522 | ) |  | (14.6 | )% |  | 222,133 |  |  | 253,302 |  |  | (31,169 | ) |  | (12.3 | )% |
| Industrial |  | 29,676 |  |  | 32,654 |  |  | (2,978 | ) |  | (9.1 | )% |  | 56,299 |  |  | 59,926 |  |  | (3,627 | ) |  | (6.1 | )% |
| Total net sales |  | $ | 397,879 |  |  | $ | 459,183 |  |  | $ | (61,304 | ) |  | (13.4 | )% |  | $ | 803,379 |  |  | $ | 876,996 |  |  | $ | (73,617 | ) |  | (8.4 | )% |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 43,630 |  |  | $ | 67,311 |  |  | $ | (23,681 | ) |  | (35.2 | )% |  | $ | 92,666 |  |  | $ | 121,275 |  |  | $ | (28,609 | ) |  | (23.6 | )% |
| Automotive |  | 10,349 |  |  | 15,711 |  |  | (5,362 | ) |  | (34.1 | )% |  | 23,550 |  |  | 34,102 |  |  | (10,552 | ) |  | (30.9 | )% |
| Industrial |  | 5,831 |  |  | 5,279 |  |  | 552 |  |  | 10.5 | % |  | 9,336 |  |  | 9,988 |  |  | (652 | ) |  | (6.5 | )% |
| Other(a) |  | (7,176 | ) |  | (28,679 | ) |  |  |  | N.M. |  |  | (12,245 | ) |  | (68,172 | ) |  |  |  |  | N.M. |  |
| Total operating income |  | $ | 52,634 |  |  | $ | 59,622 |  |  | $ | (6,988 | ) |  | (11.7 | )% |  | $ | 113,307 |  |  | $ | 97,193 |  |  | $ | 16,114 |  |  | 16.6 | % |
| Operating Margin |  | 13.2 | % |  | 13.0 | % |  |  |  |  |  | 14.1 | % |  | 11.1 | % |  |  |  |  |
| Interest expense |  | 5,589 |  |  | 5,782 |  |  |  |  |  |  | 11,275 |  |  | 11,205 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (3,575 | ) |  | 3,200 |  |  |  |  |  |  | 668 |  |  | (7,354 | ) |  |  |  |  |
| Other (income) expense, net |  | (2,947 | ) |  | (1,678 | ) |  |  |  |  |  | 1,358 |  |  | (3,621 | ) |  |  |  |  |
| Income before income taxes |  | $ | 53,567 |  |  | $ | 52,318 |  |  | $ | 1,249 |  |  | 2.4 | % |  | $ | 100,006 |  |  | $ | 96,963 |  |  | $ | 3,043 |  |  | 3.1 | % |

[0000889331-19-000040:8k_2_02:55]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and other charges, and restructuring charges. (See Supplemental Financial Information for details.)

[0000889331-19-000040:8k_2_02:56]
N.M. - Not meaningful

[0000889331-19-000040:8k_2_02:57]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2019 |  | 2018 |  | %Growth /(Decline) |  | 2019 |  | 2018 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 16.8 | % |  | 22.5 | % |  | (5.7 | )% |  | 17.7 | % |  | 21.5 | % |  | (3.9 | )% |
| Automotive |  | 9.5 | % |  | 12.4 | % |  | (2.8 | )% |  | 10.6 | % |  | 13.5 | % |  | (2.9 | )% |
| Industrial |  | 19.6 | % |  | 16.2 | % |  | 3.5 | % |  | 16.6 | % |  | 16.7 | % |  | (0.1 | )% |

[0000889331-19-000040:8k_2_02:58]
LITTELFUSE, INC.

[0000889331-19-000040:8k_2_02:59]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-19-000040:8k_2_02:60]
(In millions of USD except per share amounts unaudited)

[0000889331-19-000040:8k_2_02:61]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-19 |  | Q2-18 |  | YTD-19 |  | YTD-18 |
| GAAP diluted EPS |  | $ | 1.75 |  |  | $ | 1.67 |  |  | $ | 3.23 |  |  | $ | 3.12 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.16 |  | 1.01 |  | 0.64 |  |  | 1.95 |  |
| Adjusted diluted EPS |  | $ | 1.91 |  |  | $ | 2.68 |  |  | $ | 3.87 |  |  | $ | 5.07 |  |

[0000889331-19-000040:8k_2_02:62]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q2-19 |  | Q2-18 |  | YTD-19 |  | YTD-18 |
| Acquisition related and integration costs (a) |  | $ | 1.5 |  |  | $ | 2.3 |  |  | $ | 3.8 |  |  | $ | 14.1 |  |
| Restructuring, impairment and other charges (b) |  | 5.7 |  |  | 4.3 |  |  | 8.4 |  |  | 5.0 |  |
| Amortization backlog - IXYS (c) |  | — |  |  | 3.1 |  |  | — |  |  | 5.6 |  |
| Change in control - IXYS (d) |  | — |  |  | — |  |  | — |  |  | 2.1 |  |
| Acquisition related stock-based compensation charge (e) |  | — |  |  | — |  |  | — |  |  | 4.5 |  |
| Purchase accounting inventory adjustments (f) |  | — |  |  | 19.0 |  |  | — |  |  | 36.9 |  |
| Non-GAAP adjustments to operating income |  | 7.2 |  |  | 28.7 |  |  | 12.2 |  |  | 68.2 |  |
| Other expense, net (g) |  | 0.6 |  |  | — |  |  | 5.8 |  |  | — |  |
| Non-operating foreign exchange (gain) loss |  | (3.6 | ) |  | 3.2 |  |  | 0.7 |  |  | (7.4 | ) |
| Non-GAAP adjustments to income before income taxes |  | 4.2 |  |  | 31.9 |  |  | 18.7 |  |  | 60.8 |  |
| Income taxes (h) |  | 0.2 |  |  | 6.1 |  |  | 2.8 |  |  | 11.9 |  |
| Non-GAAP adjustments to net income |  | $ | 4.0 |  |  | $ | 25.8 |  |  | $ | 15.9 |  |  | $ | 48.9 |  |
| Total EPS impact |  | $ | 0.16 |  |  | $ | 1.01 |  |  | $ | 0.64 |  |  | $ | 1.95 |  |

[0000889331-19-000040:8k_2_02:63]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-19 |  | Q2-18 |  | YTD-19 |  | YTD-18 |
| Net sales |  | $ | 397.9 |  |  | $ | 459.2 |  |  | $ | 803.4 |  |  | $ | 877.0 |  |
| GAAP operating income |  | $ | 52.6 |  |  | $ | 59.6 |  |  | $ | 113.3 |  |  | $ | 97.2 |  |
| Add back non-GAAP adjustments |  | 7.2 |  |  | 28.7 |  |  | 12.2 |  |  | 68.2 |  |
| Adjusted operating income |  | $ | 59.8 |  |  | $ | 88.3 |  |  | $ | 125.5 |  |  | $ | 165.4 |  |
| Adjusted operating margin |  | 15.0 | % |  | 19.2 | % |  | 15.6 | % |  | 18.9 | % |
| Add back amortization |  | 10.1 |  |  | 10.3 |  |  | 20.2 |  |  | 19.8 |  |
| Add back depreciation |  | 12.6 |  |  | 12.8 |  |  | 25.7 |  |  | 24.4 |  |
| Adjusted EBITDA |  | $ | 82.5 |  |  | $ | 111.4 |  |  | $ | 171.4 |  |  | $ | 209.6 |  |
| Adjusted EBITDA margin |  | 20.7 | % |  | 24.3 | % |  | 21.3 | % |  | 23.9 | % |

[0000889331-19-000040:8k_2_02:64]
| Net sales reconciliation |  | Q2-19 vs. Q2-18 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | (13 | )% |  | (15 | )% |  | (9 | )% |  | (13 | )% |
| Less: |  |  |  |  |  |  |  |  |
| Divestitures |  | (1 | )% |  | — |  |  | (9 | )% |  | — |  |
| FX impact |  | (1 | )% |  | (3 | )% |  | (1 | )% |  | (2 | )% |
| Organic net sales growth |  | (11 | )% |  | (12 | )% |  | 1 | % |  | (11 | )% |

[0000889331-19-000040:8k_2_02:65]
| Net sales reconciliation |  | 2019 YTD vs. 2018 YTD |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | (7 | )% |  | (12 | )% |  | (6 | )% |  | (8 | )% |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 2 | % |  | — |  |  | — |  |  | 2 | % |
| Divestitures |  | — | % |  | — | % |  | (7 | )% |  | (1 | )% |
| FX impact |  | (2 | )% |  | (3 | )% |  | (1 | )% |  | (2 | )% |
| Organic net sales growth |  | (7 | )% |  | (9 | )% |  | 2 | % |  | (7 | )% |

[0000889331-19-000040:8k_2_02:66]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-19 |  | Q2-18 |  | YTD-19 |  | YTD-18 |
| Income taxes |  | $ | 9.8 |  |  | $ | 10.0 |  |  | $ | 19.2 |  |  | $ | 18.6 |  |
| Effective rate |  | 18.2 | % |  | 19.1 | % |  | 19.2 | % |  | 19.2 | % |
| Non-GAAP adjustments - income taxes |  | 0.2 |  |  | 6.1 |  |  | 2.8 |  |  | 11.9 |  |
| Adjusted income taxes |  | $ | 10.0 |  |  | $ | 16.1 |  |  | $ | 22.0 |  |  | $ | 30.5 |  |
| Adjusted effective rate |  | 17.3 | % |  | 19.1 | % |  | 18.5 | % |  | 19.3 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-19 |  | Q2-18 |  | YTD-19 |  | YTD-18 |
| Net cash provided by operating activities |  | $ | 49.2 |  |  | $ | 71.6 |  |  | $ | 80.1 |  |  | $ | 140.9 |  |
| Less: Purchases of property, plant and equipment |  | (11.2 | ) |  | (22.4 | ) |  | (25.2 | ) |  | (40.3 | ) |
| Free cash flow |  | $ | 38.0 |  |  | $ | 49.2 |  |  | $ | 54.8 |  |  | $ | 100.6 |  |

[0000889331-19-000040:8k_2_02:67]
|  |  | Q3-18 |  | Q4-18 |  | Q1-19 |  | Q2-19 |  | For the Twelve Months Ended June 29, 2019 |
| Adjusted EBITDA |  | $ | 110.5 |  |  | $ | 84.3 |  |  | $ | 89.1 |  |  | $ | 82.5 |  |  | $ | 366.4 |  |
|  |  |  |  |  |  |  |  |  |  | June 29, 2019 |
| Current portion of long-term debt |  |  |  |  |  |  |  |  |  | $ | 10.0 |  |
| Long-term debt, less current portion |  |  |  |  |  |  |  |  |  | 676.9 |  |
| Total debt |  |  |  |  |  |  |  |  |  | $ | 686.9 |  |
| Less: Cash |  |  |  |  |  |  |  |  |  | 474.8 |  |
| Net debt |  |  |  |  |  |  |  |  |  | $ | 212.1 |  |
| Adjusted Gross Leverage (defined as total debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 1.9 |
| Adjusted Net Leverage (defined as net debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 0.6 |

[0000889331-19-000040:8k_2_02:68]
Note: Total will not always foot due to rounding.

[0000889331-19-000040:8k_2_02:69]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-19-000040:8k_2_02:70]
(b) $2.5 million and $3.2 million and $0.5 million and $3.8 million reflected in cost of sales and SG&A, respectively for the three months ended June 29, 2019 and June 30, 2018, and $3.1 million and $5.3 million and $0.9 million and $4.1 million reflected in cost of sales and SG&A, respectively for the six months ended June 29, 2019 and June 30, 2018.

[0000889331-19-000040:8k_2_02:71]
(c) reflected in amortization of intangibles.

[0000889331-19-000040:8k_2_02:72]
(d) reflected in SG&A.

[0000889331-19-000040:8k_2_02:73]
(e) $2.4 million, $1.6 million and $0.5 million reflected in SG&A, research and development expenses and cost of sales, respectively.

[0000889331-19-000040:8k_2_02:74]
(f) reflected in cost of sales.

[0000889331-19-000040:8k_2_02:75]
(g) $0.6 million costs primarily related to a sale of building for three months ended June 29, 2019. Year-to-date amounts included $2.8 million impairment charges to certain other investments, $2.6 million loss on the disposal of a business, and $0.4 million gain primarily related to the final payments for the acquisition of Monolith.

[0000889331-19-000040:8k_2_02:76]
(h) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-19-000040:8k_2_02:77]
###
