# LFUS MD&A — 0000889331-19-000042


## mdna

[0000889331-19-000042:mdna:1]
[same as prior period, unchanged from 0000889331-19-000030:mdna:1]

[0000889331-19-000042:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-19-000042:mdna:3]
[same as prior period, unchanged from 0000889331-19-000030:mdna:3]

[0000889331-19-000042:mdna:4]
[same as prior period, unchanged from 0000889331-19-000030:mdna:4]

[0000889331-19-000042:mdna:5]
[same as prior period, unchanged from 0000889331-19-000030:mdna:5]

[0000889331-19-000042:mdna:6]
[same as prior period, unchanged from 0000889331-19-000030:mdna:6]

[0000889331-19-000042:mdna:7]
[same as prior period, unchanged from 0000889331-19-000030:mdna:7]

[0000889331-19-000042:mdna:8]
[same as prior period, unchanged from 0000889331-19-000030:mdna:8]

[0000889331-19-000042:mdna:9]
For the second quarter of 2019, the Company recognized net sales of  $397.9 million compared to $459.2 million in the second quarter of 2018 representing a decrease of $61.3 million, or 13.4%. The decrease was primarily driven by lower volume in Electronics and Automotive segments and  $7.9 million or 1.7% of unfavorable changes in foreign exchange rates. The Company recognized net income of $43.8 million, or $1.75 per diluted share, in the second quarter of 2019 compared to net income of $42.3 million, or $1.67 per diluted share in the second quarter of 2018. The increase in net income reflects lower non-segment charges compared to prior year primarily due to the IXYS acquisition, partially offset by lower operating income across all segments and foreign exchange losses.

[0000889331-19-000042:mdna:10]
The Company continues to take actions to improve its cost structure and drive the synergies from the integration of IXYS. The Company expects to realize cost savings from the restructuring activities taken during 2019 including the reorganization of certain  manufacturing, selling and administrative functions across all segments. For the three and six months ended June 29, 2019, the Company recorded total restructuring charges of $5.7 million and $8.4 million respectively, for employee termination costs and other restructuring charges, which included $1.7 million of restructuring costs associated with the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment.

[0000889331-19-000042:mdna:11]
Net cash provided by operating activities was $80.1 million for the six months ended June 29, 2019 as compared to $140.9 million for the six months ended June 30, 2018. The decrease in net cash provided by operating activities reflected lower earnings and higher working capital levels primarily due to the timing of supplier payments.

[0000889331-19-000042:mdna:12]
During the three and six months ended June 29, 2019, the Company repurchased 188,214 and 268,130 shares of its common stock totaling $32.0 million and $45.5 million. Since September 30, 2018, the Company has repurchased 660,102 shares of its common stock at an average price of $171.81 totaling $113.4 million.

[0000889331-19-000042:mdna:13]
[same as prior period, unchanged from 0000889331-19-000030:mdna:13]

[0000889331-19-000042:mdna:14]
The following table summarizes the Company’s condensed consolidated results of operations for the periods presented. The second quarter of 2019 includes $7.2 million ($12.2 million year-to-date) of non-segment charges, of which $5.7 million ($8.4 million year-to-date) of restructuring charges are primarily related to employee termination costs and $1.5 million ($3.8 million year-to-date) of acquisition related and integration charges are primarily related to the IXYS acquisition.

[0000889331-19-000042:mdna:15]
The second quarter of  2018 includes approximately  $26.8 million ($65.4 million year-to-date) of charges primarily related to the IXYS acquisition, which include $19.0 million ($36.9 million year-to-date) of purchase accounting inventory step-up charges, $2.0 million ($13.6 million year-to-date) in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $3.1 million ($5.6 million year-to-date)in backlog amortization costs, $2.7 million of employee termination costs and other restructuring charges, and $4.5 million year-to-date stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million year-to-date change in control expense related to IXYS. In addition, there were $0.5 million ($1.2 million year-to-date)of employee termination costs, other restructuring, impairment charges of $1.1 million associated with the exit of the Custom business in the second quarter, and $0.3 million ($0.5 million year-to-date)of acquisition-related expenses for other contemplated acquisitions.

[0000889331-19-000042:mdna:16]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |  | 2019 |  | 2018 |  | Change |  | %Change |
| Net sales |  | $ | 397,879 |  |  | $ | 459,183 |  |  | $ | (61,304 | ) |  | (13.4 | )% |  | $ | 803,379 |  |  | $ | 876,996 |  |  | $ | (73,617 | ) |  | (8.4 | )% |
| Gross profit |  | 141,808 |  |  | 168,987 |  |  | (27,179 | ) |  | (16.1 | )% |  | 297,036 |  |  | 318,610 |  |  | (21,574 | ) |  | (6.8 | )% |
| Operating expenses |  | 89,174 |  |  | 109,365 |  |  | (20,191 | ) |  | (18.5 | )% |  | 183,729 |  |  | 221,417 |  |  | (37,688 | ) |  | (17.0 | )% |
| Operating income |  | 52,634 |  |  | 59,622 |  |  | (6,988 | ) |  | (11.7 | )% |  | 113,307 |  |  | 97,193 |  |  | 16,114 |  |  | 16.6 | % |
| Income before income taxes |  | 53,567 |  |  | 52,318 |  |  | 1,249 |  |  | 2.4 | % |  | 100,006 |  |  | 96,963 |  |  | 3,043 |  |  | 3.1 | % |
| Income taxes |  | 9,775 |  |  | 9,992 |  |  | (217 | ) |  | (2.2 | )% |  | 19,225 |  |  | 18,609 |  |  | 616 |  |  | 3.3 | % |
| Net income |  | $ | 43,792 |  |  | $ | 42,326 |  |  | $ | 1,466 |  |  | 3.5 | % |  | $ | 80,781 |  |  | $ | 78,354 |  |  | $ | 2,427 |  |  | 3.1 | % |

[0000889331-19-000042:mdna:17]
[same as prior period, unchanged from 0000889331-19-000030:mdna:17]

[0000889331-19-000042:mdna:18]
Net sales decreased $61.3 million or 13.4% for the second quarter of 2019 compared to the second quarter of 2018 primarily due to lower volume across the Electronics and Automotive segments from distribution partners reducing excess electronics channel inventories and a decline in global auto production and $7.9 million or 1.7% of unfavorable changes in foreign exchange rates.

[0000889331-19-000042:mdna:19]
Net sales decreased $73.6 million or 8.4% for the first six months of 2019 compared to the first six months of 2018 primarily due to lower volume across the Electronics and Automotive segments and $17.9 million or 2.0% of unfavorable changes in foreign exchange rates.

[0000889331-19-000042:mdna:20]
[same as prior period, unchanged from 0000889331-19-000030:mdna:19]

[0000889331-19-000042:mdna:21]
Gross profit was $141.8 million, or 35.6% of net sales, in the second quarter of 2019 compared to $169.0 million, or 36.8% of net sales, in the second quarter of 2018. The decrease in gross profit is primarily due to lower volumes, unfavorable price impacts and product mix, and costs related to restructuring activities taken during 2019. In addition, the second quarter 2018 gross profit was negatively impacted by the IXYS purchase accounting inventory step-up charge of $19.0 million, which negatively impacted the 2018 gross margin by 4.1%.

[0000889331-19-000042:mdna:22]
Gross profit was $297.0 million, or 37.0% of net sales, in the first six months of 2019 compared to $318.6 million, or 36.3% of net sales, in the first six months  of 2018. The decrease in gross profit reflected lower volume across all segments. The increase in gross margin is primarily due to the 2018 IXYS purchase accounting inventory step-up charge of $36.9 million, which negatively impacted the 2018 gross margin by 4.2%, partially offset by unfavorable price impacts and product mix within the Electronics and Automotive segments.

[0000889331-19-000042:mdna:23]
[same as prior period, unchanged from 0000889331-19-000030:mdna:21]

[0000889331-19-000042:mdna:24]
Total operating expenses were $89.2 million, or 22.4% of net sales, for the second quarter of 2019 compared to $109.4 million, or 23.8% of net sales, for the second quarter of 2018. The decrease in operating expenses of $20.2 million is primarily due to lower annual incentive compensation expenses, global cost saving initiatives, and reduced backlog amortization expense of $3.1 million related to the IXYS acquisition in 2018.

[0000889331-19-000042:mdna:25]
Total operating expenses were $183.7 million, or 22.9% of net sales, for the first six months of 2019 compared to $221.4 million, or 25.2% of net sales, for the first six months of 2018. The decrease in operating expenses of $37.7 million is primarily due to lower annual incentive compensation expenses, lower acquisition and integration related costs of $10.3 million,  global cost saving initiatives, reduced backlog amortization expense of $5.6 million, $4.5 million stock compensation expense and $2.1 million of change in control expense related to the IXYS acquisition in 2018.

[0000889331-19-000042:mdna:26]
[same as prior period, unchanged from 0000889331-19-000030:mdna:23]

[0000889331-19-000042:mdna:27]
Operating income was $52.6 million, a decrease of $7.0 million, or 11.7%, for the second quarter of 2019 compared to $59.6 million for the second quarter of 2018. The decrease in operating income is due to lower gross margin across all segments, partially offset by the lower operating expenses noted above. Operating margins increased from 13.0% in the second quarter of 2018 to 13.2% in the second quarter of 2019 driven by the factors mentioned above.

[0000889331-19-000042:mdna:28]
Operating income was $113.3 million, an increase of $16.1 million, or 16.6%, for the first six months of 2019 compared to $97.2 million for the  first six months  of 2018. The increase in operating income is primarily due to the $36.9 million purchase accounting inventory step-up charges in 2018 and the lower operating expenses noted above partially offset by lower gross profit across all segments. Operating margins increased from 11.1% in the  first six months  of 2018 to 14.1% in the first six months of 2019 driven by the factors mentioned above.

[0000889331-19-000042:mdna:29]
[same as prior period, unchanged from 0000889331-19-000030:mdna:25]

[0000889331-19-000042:mdna:30]
Income before income taxes was $53.6 million, or 13.5% of net sales, for the second quarter of 2019 compared to $52.3 million, or 11.4% of net sales, for the second quarter of 2018. In addition to the factors impacting comparative results for operating income discussed above, income before taxes was impacted by foreign exchange gains of $3.6 million during the three months ended June 29, 2019 compared to foreign exchange losses of $3.2 million during the three months ended June 30, 2018, and interest income of $1.3 million  during  three months ended June 29, 2019 compared to $0.3 million during the three months ended June 30, 2018.

[0000889331-19-000042:mdna:31]
Income before income taxes was $100.0 million, or 12.4% of net sales, for the first six months of 2019 compared to $97.0 million, or 11.1% of net sales, for the first six months of 2018. In addition to the factors impacting comparative results for operating income discussed above, income before taxes was impacted by foreign exchange losses of $0.7 million during the six months ended June 29, 2019 compared to foreign exchange gains of $7.4 million during the six months ended June 30, 2018, impairment charges of $3.1 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment during the six months ended June 29, 2019, partially offset by $1.0 million increases in interest income during during the first six months of 2019 compared to the first six months of 2018.

[0000889331-19-000042:mdna:32]
[same as prior period, unchanged from 0000889331-19-000030:mdna:27]

[0000889331-19-000042:mdna:33]
Income tax expense was $9.8 million, or an effective tax rate of 18.2%, for the second quarter of 2019 compared to $10.0 million, or an effective tax rate of 19.1%, for the second quarter of 2018. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-19-000042:mdna:34]
Income tax expense for the first six months of 2019 was $19.2 million, or an effective tax rate of 19.2%, compared to income tax expense of $18.6 million, or an effective tax rate of 19.2%, for the first six months of 2018. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-19-000042:mdna:35]
[same as prior period, unchanged from 0000889331-19-000030:mdna:29]

[0000889331-19-000042:mdna:36]
[same as prior period, unchanged from 0000889331-19-000030:mdna:30]

[0000889331-19-000042:mdna:37]
[same as prior period, unchanged from 0000889331-19-000030:mdna:31]

[0000889331-19-000042:mdna:38]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |  | 2019 |  | 2018 |  | Change |  | %Change |
| Electronics |  | $ | 259,553 |  |  | $ | 299,357 |  |  | $ | (39,804 | ) |  | (13.3 | )% |  | $ | 524,947 |  |  | $ | 563,768 |  |  | $ | (38,821 | ) |  | (6.9 | )% |
| Automotive |  | 108,650 |  |  | 127,172 |  |  | (18,522 | ) |  | (14.6 | )% |  | 222,133 |  |  | 253,302 |  |  | (31,169 | ) |  | (12.3 | )% |
| Industrial |  | 29,676 |  |  | 32,654 |  |  | (2,978 | ) |  | (9.1 | )% |  | 56,299 |  |  | 59,926 |  |  | (3,627 | ) |  | (6.1 | )% |
| Total |  | $ | 397,879 |  |  | $ | 459,183 |  |  | $ | (61,304 | ) |  | (13.4 | )% |  | $ | 803,379 |  |  | $ | 876,996 |  |  | $ | (73,617 | ) |  | (8.4 | )% |

[0000889331-19-000042:mdna:39]
[same as prior period, unchanged from 0000889331-19-000030:mdna:33]

[0000889331-19-000042:mdna:40]
Net sales decreased $39.8 million, or 13.3%, in the second quarter of 2019 compared to the second quarter of 2018 primarily due to lower volume in the semiconductor and electronics products businesses due to softer market demands and unfavorable changes in foreign exchange rates of $4.4 million.

[0000889331-19-000042:mdna:41]
Net sales decreased $38.8 million, or 6.9%, in the first six months of 2019 compared to the first six months of 2018 primarily due to lower volume in the electronics products and semiconductor businesses due to softer market demands and  unfavorable changes in foreign exchange rates of $9.7 million.

[0000889331-19-000042:mdna:42]
[same as prior period, unchanged from 0000889331-19-000030:mdna:35]

[0000889331-19-000042:mdna:43]
Net sales decreased $18.5 million, or 14.6%, in the second quarter of 2019 compared to the second quarter of 2018 due to decreased volume primarily in the passenger car and automotive sensor businesses and unfavorable changes in foreign exchange rates of $3.3 million.

[0000889331-19-000042:mdna:44]
Net sales decreased $31.2 million, or 12.3%, in the first six months of 2019 compared to the first six months of 2018 due to decreased volume primarily in the passenger car and automotive sensor businesses and unfavorable changes in foreign exchange rates of $7.7 million.

[0000889331-19-000042:mdna:45]
[same as prior period, unchanged from 0000889331-19-000030:mdna:37]

[0000889331-19-000042:mdna:46]
Net sales decreased slightly by $3.0 million, or 9.1%, in the second quarter of 2019 compared to the second quarter of 2018 primarily due to the exit of the Custom business during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.2 million, partially offset by higher volume in the power fuse business.

[0000889331-19-000042:mdna:47]
Net sales decreased slightly by $3.6 million, or 6.1%, in the first six months of 2019 compared to the first six months of 2018 primarily due to the exit of the Custom business during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.5 million, partially offset by higher volume in the power fuse business.

[0000889331-19-000042:mdna:48]
[same as prior period, unchanged from 0000889331-19-000030:mdna:39]

[0000889331-19-000042:mdna:49]
[same as prior period, unchanged from 0000889331-19-000030:mdna:40]

[0000889331-19-000042:mdna:50]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2019 |  | 2018 |  | Change |  | %Change |  | 2019 |  | 2018 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 172,895 |  |  | $ | 203,581 |  |  | $ | (30,686 | ) |  | (15.1 | )% |  | $ | 345,676 |  |  | $ | 382,853 |  |  | $ | (37,177 | ) |  | (9.7 | )% |
| Americas |  | 135,894 |  |  | 146,619 |  |  | (10,725 | ) |  | (7.3 | )% |  | 273,928 |  |  | 285,348 |  |  | (11,420 | ) |  | (4.0 | )% |
| Europe |  | 89,090 |  |  | 108,983 |  |  | (19,893 | ) |  | (18.3 | )% |  | 183,775 |  |  | 208,795 |  |  | (25,020 | ) |  | (12.0 | )% |
| Total |  | $ | 397,879 |  |  | $ | 459,183 |  |  | $ | (61,304 | ) |  | (13.4 | )% |  | $ | 803,379 |  |  | $ | 876,996 |  |  | $ | (73,617 | ) |  | (8.4 | )% |

[0000889331-19-000042:mdna:51]
[same as prior period, unchanged from 0000889331-19-000030:mdna:42]

[0000889331-19-000042:mdna:52]
Net sales decreased $30.7 million, or 15.1%, in the second quarter of 2019 compared to the second quarter of 2018. The decrease in net sales was primarily due to lower volume in semiconductor business and electronics products within the Electronics segment and lower volume in the passenger car and automotive sensors businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $2.6 million.

[0000889331-19-000042:mdna:53]
Net sales decreased $37.2 million, or 9.7%, in the first six months of 2019 compared to the  first six months of 2018. The decrease in net sales was primarily due to lower volume in semiconductor business and electronics products within the Electronics segment and lower volume across all businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $5.2 million.

[0000889331-19-000042:mdna:54]
[same as prior period, unchanged from 0000889331-19-000030:mdna:44]

[0000889331-19-000042:mdna:55]
Net sales decreased $10.7 million, or 7.3%, in the second quarter of 2019 compared to the second quarter of 2018 primarily due to lower volume in semiconductor business within the Electronics segment, lower volume across all businesses in the Automotive segment, the exit of the Custom business within Industrial segment during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.2 million, partially offset by higher volume in electronics products within the Electronics segment.

[0000889331-19-000042:mdna:56]
Net sales decreased $11.4 million, or 4.0%, in the first six months of 2019 compared to the first six months of 2018 primarily due to lower volume in semiconductor business within the Electronics segment, lower volume across all businesses in the Automotive segment, the exit of the Custom business within Industrial segment during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.6 million, partially offset by higher volume in the electronics products within the Electronics segment.

[0000889331-19-000042:mdna:57]
[same as prior period, unchanged from 0000889331-19-000030:mdna:46]

[0000889331-19-000042:mdna:58]
Net sales decreased $19.9 million, or 18.3%, in the second quarter of 2019 compared to the second quarter of 2018. The decrease in net sales was primarily due to lower volume in electronics products within the Electronics segment, lower volume in passenger car products and automotive sensors businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $5.1 million.

[0000889331-19-000042:mdna:59]
Net sales decreased $25.0 million, or 12.0%, in the first six months of 2019 compared to the first six months of 2018. The decrease in net sales was primarily due to lower volume in electronics products within the Electronics segment and unfavorable changes in foreign exchange rates of $12.1 million.

[0000889331-19-000042:mdna:60]
[same as prior period, unchanged from 0000889331-19-000030:mdna:48]

[0000889331-19-000042:mdna:61]
[same as prior period, unchanged from 0000889331-19-000030:mdna:49]

[0000889331-19-000042:mdna:62]
Revolving Credit Facility/Term Loan

[0000889331-19-000042:mdna:63]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-19-000042:mdna:64]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principle payments of $2.5 million and $7.5 million on the term loan during the three and six months ended June 29, 2019.

[0000889331-19-000042:mdna:65]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.65% at June 29, 2019.

[0000889331-19-000042:mdna:66]
As of June 29, 2019, the Company had $0.1 million outstanding in letters of credit and had available $531.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At June 29, 2019, the Company was in compliance with all covenants under the Credit Agreement. Further information regarding the Company’s credit agreement is provided in Note 9, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-19-000042:mdna:67]
[same as prior period, unchanged from 0000889331-19-000030:mdna:55]

[0000889331-19-000042:mdna:68]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-19-000042:mdna:69]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-19-000042:mdna:70]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 9, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-19-000042:mdna:71]
[same as prior period, unchanged from 0000889331-19-000030:mdna:60]

[0000889331-19-000042:mdna:72]
During the second quarter of 2019, the Company paid quarterly dividends of $10.6 million to the shareholders totaling $21.3 million year to date as of June 29, 2019. On July 24, 2019, the Board of Directors approved a 12% increase in the quarterly cash dividend from $0.43 to $0.48. The dividend will be paid on September 5, 2019 to shareholders of record as of August 22, 2019.

[0000889331-19-000042:mdna:73]
[same as prior period, unchanged from 0000889331-19-000030:mdna:62]

[0000889331-19-000042:mdna:74]
|  |  | First Six Months |
| (in thousands) |  | 2019 |  | 2018 |
| Net cash provided by operating activities |  | $ | 80,092 |  |  | $ | 140,915 |  |
| Net cash used in investing activities |  | (19,812 | ) |  | (350,734 | ) |
| Net cash (used in) provided by financing activities |  | (75,624 | ) |  | 196,207 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 392 |  |  | (7,917 | ) |
| Decrease in cash and cash equivalents |  | (14,952 | ) |  | (21,529 | ) |
| Cash and cash equivalents at beginning of period |  | 489,733 |  |  | 429,676 |  |
| Cash and cash equivalents at end of period |  | $ | 474,781 |  |  | $ | 408,147 |  |

[0000889331-19-000042:mdna:75]
[same as prior period, unchanged from 0000889331-19-000030:mdna:64]

[0000889331-19-000042:mdna:76]
[same as prior period, unchanged from 0000889331-19-000030:mdna:65]

[0000889331-19-000042:mdna:77]
Net cash provided by operating activities was $80.1 million for the six months ended June 29, 2019, compared to $140.9 million during the six months ended June 30, 2018. The decrease in net cash provided by operating activities reflected lower earnings and higher working capital levels primarily due to the timing of supplier payments.

[0000889331-19-000042:mdna:78]
[same as prior period, unchanged from 0000889331-19-000030:mdna:67]

[0000889331-19-000042:mdna:79]
Net cash used in investing activities was $19.8 million for the six months ended June 29, 2019 compared to $350.7 million during the six months ended June 30, 2018. Net cash used for the acquisition of IXYS was $306.5 million for the six months ended June 30, 2018. Capital expenditures were $25.2 million, representing a decrease of $15.1 million compared to 2018. Additionally, the Company received proceeds of $6.4 million from the sale of a property within the Industrial segment.

[0000889331-19-000042:mdna:80]
[same as prior period, unchanged from 0000889331-19-000030:mdna:69]

[0000889331-19-000042:mdna:81]
Net cash used in financing activities was $75.6 million for the six months ended June 29, 2019 compared to net cash provided by financing activities of $196.2 million for the six months ended June 30, 2018. The Company repurchased 268,130 shares of its common stock during the six months ended June 29, 2019 totaling $45.5 million, but made payments of $49.9 million related to settled share repurchases. The Company made payments of $7.5 million on the term loan during the six months ended June 29, 2019 as compared to $310.0 million of proceeds from the credit facility and senior notes payable and $100.0 million of payments on the credit facility and term loan during the six months ended June 30, 2018. Additionally, dividends paid increased $2.8 million from $18.5 million in 2018 to $21.3 million for the six months ended June 29, 2019.

[0000889331-19-000042:mdna:82]
[same as prior period, unchanged from 0000889331-19-000030:mdna:71]

[0000889331-19-000042:mdna:83]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 (“2018 Program”). The Share Repurchase Program expired on April 30, 2019 with 471,888 shares repurchased. On April 26, 2019, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020. During the three and six months ended June 29, 2019, the Company repurchased 188,214 and 268,130 shares of its common stock totaling $32.0 million and $45.5 million, respectively.

[0000889331-19-000042:mdna:84]
[same as prior period, unchanged from 0000889331-19-000030:mdna:73]

[0000889331-19-000042:mdna:85]
As of June 29, 2019, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-19-000042:mdna:86]
[same as prior period, unchanged from 0000889331-19-000030:mdna:75]

[0000889331-19-000042:mdna:87]
[same as prior period, unchanged from 0000889331-19-000030:mdna:76]

[0000889331-19-000042:mdna:88]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 29, 2018. During the six months ended June 29, 2019, there were no significant changes in the application of critical accounting policies.
