# LFUS note change history — 0000889331-19-000052 → 0000889331-20-000037


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-04-29):
[0000889331-20-000037:note_history:1]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, the Company’s products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

- changed (2020-04-29):
[0000889331-20-000037:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 28, 2020 and March 30, 2019:
  (was, 2019-10-30, similarity 0.8975):
[0000889331-19-000052:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2019 and September 29, 2018:

- changed (2020-04-29):
[0000889331-20-000037:note_history:3]
|  |  | Three Months Ended March 28, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |
  (was, 2019-10-30, similarity 0.681):
[0000889331-19-000052:note_history:3]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- changed (2020-04-29):
[0000889331-20-000037:note_history:4]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  | — |  |  | — |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |
  (was, 2019-10-30, similarity 0.681):
[0000889331-19-000052:note_history:4]
|  |  | Three Months Ended September 29, 2018 |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- changed (2020-04-29):
[0000889331-20-000037:note_history:5]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.
  (was, 2019-10-30, similarity 0.9479):
[0000889331-19-000052:note_history:5]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

- changed (2020-04-29):
[0000889331-20-000037:note_history:6]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2019-10-30, similarity 0.9795):
[0000889331-19-000052:note_history:6]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2020-04-29):
[0000889331-20-000037:note_history:7]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments." The standard modifies the measurement approach for credit losses on financial instruments, including trade receivables, from an incurred loss method to a current expected credit loss method ("CECL").  The standard requires the measurement of expected credit losses to be based on relevant information, including historical experiences, current conditions and a forecast that is supportable.  The Company adopted the new standard on December 29, 2019.  The adoption of the standard did not have a material effect on our Condensed Consolidated Financial Statements.

- added (2020-04-29):
[0000889331-20-000037:note_history:8]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement."  ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies certain disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018- 13 did not have a material impact on our Condensed Consolidated Financial Statements.

- added (2020-04-29):
[0000889331-20-000037:note_history:9]
In August 2018, the FASB issued ASU No. 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic: 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force)."  ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The Company adopted the new standard on December 29, 2019.  The adoption of ASU 2018-15 did not have a material impact on our Condensed Consolidated Financial Statements.

- added (2020-04-29):
[0000889331-20-000037:note_history:10]
In March 2020, the FASB issued ASU 2020-04 Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting.” This ASU provides optional expedient and exceptions for applying generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by reference rate reform if certain criteria are met. The objective of this is to provide optional guidance for a limited period of time to ease the potential burden in accounting for (or recognizing the effects of) reference rate reform on financial reporting due to the cessation of the London Interbank Offered Rate (LIBOR). The amendments in this update are effective for all entities as of March 12, 2020 through December 31, 2022. The Company does not expect a material effect from the adoption of this guidance on its Condensed Consolidated Financial Statements.

- removed (2020-04-29):
[0000889331-19-000052:note_history:11]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The Company's products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

- removed (2020-04-29):
[0000889331-19-000052:note_history:12]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.

- removed (2020-04-29):
[0000889331-19-000052:note_history:13]
In February 2016,  the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, "Leases" (Topic 842), ("ASC 842"). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption requires using a modified retrospective transition with either 1) periods prior to the adoption date being recast or 2) a cumulative-effect adjustment recognized to the opening balance of retained earnings on the adoption date with prior periods not recast.

- removed (2020-04-29):
[0000889331-19-000052:note_history:14]
The Company adopted the standard on December 30, 2018 using alternative modified retrospective transition method provided in ASU No. 2018-11, "Leases (Topic 842): Target Improvements." Under this method, the Company recorded a cumulative-effect adjustment as of December 30, 2018 and did not record any retrospective adjustments to comparative periods to reflect the adoption of ASC 842. The new standard provides a number of optional practical expedients in transition. The Company has elected the ‘package of practical expedients’ which permits us not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct costs. The Company has not elected the use-of-hindsight. Adoption of  ASC 842 resulted in the recognition of operating lease right-of-use assets ("ROU") net of deferred rent of $26.1 million and lease liabilities of $29.4 million, as of December 30, 2018 for operating leases on its Condensed Consolidated Balance Sheets, with no  impact to its Condensed Consolidated Statements of Net Income and no impact on Condensed Consolidated Statements of Cash Flow. See Note 6, Lease Commitments, for further discussion.

- removed (2020-04-29):
[0000889331-19-000052:note_history:15]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. The Company adopted the new standard on December 30, 2018. The adoption of this guidance did not have a material effect on our Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0000889331-20-000037:note_history:16]
The carrying amounts of debt at March 28, 2020 and December 28, 2019 are as follows:
  (was, 2019-10-30, similarity 0.9342):
[0000889331-19-000052:note_history:16]
The carrying amounts of debt at September 28, 2019 and December 29, 2018 are as follows:

- changed (2020-04-29):
[0000889331-20-000037:note_history:17]
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | — |  |
| Term Loan |  | 142,500 |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,316 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 104,189 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,429 | ) |  | (3,669 | ) |
| Total debt |  | 774,195 |  |  | 679,158 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 764,195 |  |  | $ | 669,158 |  |
  (was, 2019-10-30, similarity 0.9263):
[0000889331-19-000052:note_history:17]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,002 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,932 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,893 | ) |  | (4,636 | ) |
| Total debt |  | 678,160 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 668,160 |  |  | $ | 684,730 |  |

- changed (2020-04-29):
[0000889331-20-000037:note_history:18]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $2.5 million of principal payments on the term loan during the three months ended March 28, 2020.
  (was, 2019-10-30, similarity 0.9097):
[0000889331-19-000052:note_history:18]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $7.5 million on the term loan during the nine months ended September 28, 2019.

- added (2020-04-29):
[0000889331-20-000037:note_history:19]
Outstanding borrowings under the Credit Agreement bore interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 2.47% at March 28, 2020.

- added (2020-04-29):
[0000889331-20-000037:note_history:20]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to coronavirus disease 2019 ("COVID-19").

- added (2020-04-29):
[0000889331-20-000037:note_history:21]
As of March 28, 2020, the Company had no amount outstanding in letters of credit and had available $219.8 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 28, 2020, the Company was in compliance with all covenants under the Credit Agreement.

- added (2020-04-29):
[0000889331-20-000037:note_history:22]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.  The balance under the facility is $240.0 million as of April 3, 2020.

- changed (2020-04-29):
[0000889331-20-000037:note_history:23]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.
  (was, 2019-10-30, similarity 0.6978):
[0000889331-19-000052:note_history:23]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023

- changed (2020-04-29):
[0000889331-20-000037:note_history:24]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 28, 2020, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2019-10-30, similarity 0.9878):
[0000889331-19-000052:note_history:24]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 28, 2019, the Company was in compliance with all covenants under the Senior Notes.

- changed (2020-04-29):
[0000889331-20-000037:note_history:25]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
  (was, 2019-10-30, similarity 0.9981):
[0000889331-19-000052:note_history:25]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

- changed (2020-04-29):
[0000889331-20-000037:note_history:26]
Interest paid on all Company debt was $7.4 million and $8.0 million for the three months ended March 28, 2020 and March 30, 2019, respectively.
  (was, 2019-10-30, similarity 0.6011):
[0000889331-19-000052:note_history:26]
Interest paid on all Company debt was $6.4 million and $8.1 million for the three months ended September 28, 2019 and September 29, 2018, respectively, and $17.9 million and $15.8 million for the nine months ended September 28, 2019 and September 29, 2018, respectively.

- removed (2020-04-29):
[0000889331-19-000052:note_history:27]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.54% at September 28, 2019.

- removed (2020-04-29):
[0000889331-19-000052:note_history:28]
As of September 28, 2019, the Company had less than $0.1 million outstanding in letters of credit and had available $416.5 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 28, 2019, the Company was in compliance with all covenants under the Credit Agreement.

- removed (2020-04-29):
[0000889331-19-000052:note_history:29]
(“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0000889331-20-000037:note_history:30]
The carrying amounts of debt at March 28, 2020 and December 28, 2019 are as follows:
  (was, 2019-10-30, similarity 0.9342):
[0000889331-19-000052:note_history:30]
The carrying amounts of debt at September 28, 2019 and December 29, 2018 are as follows:

- changed (2020-04-29):
[0000889331-20-000037:note_history:31]
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | — |  |
| Term Loan |  | 142,500 |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,316 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 104,189 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,429 | ) |  | (3,669 | ) |
| Total debt |  | 774,195 |  |  | 679,158 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 764,195 |  |  | $ | 669,158 |  |
  (was, 2019-10-30, similarity 0.9263):
[0000889331-19-000052:note_history:31]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,002 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,932 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,893 | ) |  | (4,636 | ) |
| Total debt |  | 678,160 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 668,160 |  |  | $ | 684,730 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0000889331-20-000037:note_history:32]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.
  (was, 2019-10-30, similarity 0.8656):
[0000889331-19-000052:note_history:32]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method and recorded in investments in the Condensed Consolidated Balance Sheets. The following is a description of the investments and related party transactions.

- added (2020-04-29):
[0000889331-20-000037:note_history:33]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

- added (2020-04-29):
[0000889331-20-000037:note_history:34]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

- added (2020-04-29):
[0000889331-20-000037:note_history:35]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

- added (2020-04-29):
[0000889331-20-000037:note_history:36]
|  |  | For the Three Months Ended March 28, 2020 |  | For the Three Months Ended March 30, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Purchase material/ service from related party |  | 0.2 |  | — |  | 1.8 |  |  | 0.8 |  | 0.1 |  | 1.5 |  |
|  |  | March 28, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | — |  |  | 0.2 |  | — |  | 0.1 |  |

- changed (2020-04-29):
[0000889331-20-000037:note_history:37]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.4 million as of March 28, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.
  (was, 2019-10-30, similarity 0.9603):
[0000889331-19-000052:note_history:37]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $1.2 million as of September 28, 2019 where one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

- changed (2020-04-29):
[0000889331-20-000037:note_history:38]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net Income. The operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.
  (was, 2019-10-30, similarity 0.7882):
[0000889331-19-000052:note_history:38]
On March 25, 2019, the Company entered into a definitive agreement to sell the assets and liabilities of Microwave Technology, Inc. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net Income. The operations of Microwave Technology, Inc. were included in the Electronics segment. One member of the Company’s  Board of Directors is the co-owner of a company that agreed to purchase MWT. This transaction closed on April 26, 2019.

- removed (2020-04-29):
[0000889331-19-000052:note_history:39]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For both the three months ended September 28, 2019 and September 29, 2018, the Company recorded revenues of $0.2 million from sales of products to Powersem for use as components in their products. For the nine months ended September 28, 2019 and September 29, 2018, the Company recorded revenues of $0.4 million and $0.6 million from sales of products to Powersem for use as components in their products, respectively. During the three months ended September 28, 2019 and September 29, 2018, the Company purchased $0.8 million and $1.3 million of products from Powersem, respectively. During the nine months ended September 28, 2019 and September 29, 2018, the Company purchased $2.4 million and $3.4 million of products from Powersem, respectively. As of September 28, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

- removed (2020-04-29):
[0000889331-19-000052:note_history:40]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During both the three months ended September 28, 2019 and September 29, 2018, EB Tech rendered processing services for the Company totaling less than $0.1 million. During both the  nine months ended September 28, 2019 and September 29, 2018, EB Tech rendered processing services for the Company totaling approximately $0.3 million. As of September 28, 2019 the Company's accounts payable balance to EB Tech was less than $0.1 million. As of December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

- removed (2020-04-29):
[0000889331-19-000052:note_history:41]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended September 28, 2019 and September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $1.7 million and $2.5 million, respectively. During the nine months ended September 28, 2019 and September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $5.5 million and $7.7 million, respectively. As of September 28, 2019 the Company's accounts payable balance to ATEC was $0.2 million. As of December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2020-04-29):
[0000889331-20-000037:note_history:42]
|  |  | For the Three Months Ended March 28, 2020 |  | For the Three Months Ended March 30, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Purchase material/ service from related party |  | 0.2 |  | — |  | 1.8 |  |  | 0.8 |  | 0.1 |  | 1.5 |  |
|  |  | March 28, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | — |  |  | 0.2 |  | — |  | 0.1 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0000889331-20-000037:note_history:43]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 28, 2020 and March 30, 2019:
  (was, 2019-10-30, similarity 0.8975):
[0000889331-19-000052:note_history:43]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2019 and September 29, 2018:

- changed (2020-04-29):
[0000889331-20-000037:note_history:44]
|  |  | Three Months Ended March 28, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |
  (was, 2019-10-30, similarity 0.681):
[0000889331-19-000052:note_history:44]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- changed (2020-04-29):
[0000889331-20-000037:note_history:45]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  | — |  |  | — |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |
  (was, 2019-10-30, similarity 0.681):
[0000889331-19-000052:note_history:45]
|  |  | Three Months Ended September 29, 2018 |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-04-29):
[0000889331-20-000037:note_history:46]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 28, 2020 and March 30, 2019:
  (was, 2019-10-30, similarity 0.8975):
[0000889331-19-000052:note_history:46]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2019 and September 29, 2018:

- changed (2020-04-29):
[0000889331-20-000037:note_history:47]
|  |  | Three Months Ended March 28, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |
  (was, 2019-10-30, similarity 0.681):
[0000889331-19-000052:note_history:47]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- changed (2020-04-29):
[0000889331-20-000037:note_history:48]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  | — |  |  | — |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |
  (was, 2019-10-30, similarity 0.681):
[0000889331-19-000052:note_history:48]
|  |  | Three Months Ended September 29, 2018 |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- changed (2020-04-29):
[0000889331-20-000037:note_history:49]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.
  (was, 2019-10-30, similarity 0.9479):
[0000889331-19-000052:note_history:49]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

- changed (2020-04-29):
[0000889331-20-000037:note_history:50]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2019-10-30, similarity 0.9795):
[0000889331-19-000052:note_history:50]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- removed (2020-04-29):
[0000889331-19-000052:note_history:51]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.
