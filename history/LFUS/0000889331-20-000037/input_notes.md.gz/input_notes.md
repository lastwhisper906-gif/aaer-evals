# LFUS notes — 0000889331-20-000037


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-20-000037:notes:1]
[same as prior period, unchanged from 0000889331-19-000052:notes:1]

[0000889331-20-000037:notes:2]
[same as prior period, unchanged from 0000889331-19-000052:notes:2]

[0000889331-20-000037:notes:3]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, the Company’s products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

[0000889331-20-000037:notes:4]
[same as prior period, unchanged from 0000889331-19-000052:notes:4]

[0000889331-20-000037:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2019  which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-20-000037:notes:6]
[same as prior period, unchanged from 0000889331-19-000052:notes:6]

[0000889331-20-000037:notes:7]
[same as prior period, unchanged from 0000889331-19-000052:notes:8]

[0000889331-20-000037:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 28, 2020 and March 30, 2019:

[0000889331-20-000037:notes:9]
|  |  | Three Months Ended March 28, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |

[0000889331-20-000037:notes:10]
|  |  | Three Months Ended March 30, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,377 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,377 |  |
| Electronics – Semiconductor |  | 157,017 |  |  | — |  |  | — |  |  | 157,017 |  |
| Passenger Car Products |  | — |  |  | 56,543 |  |  | — |  |  | 56,543 |  |
| Automotive Sensors |  | — |  |  | 26,057 |  |  | — |  |  | 26,057 |  |
| Commercial Vehicle Products |  | — |  |  | 30,883 |  |  | — |  |  | 30,883 |  |
| Industrial Products |  | — |  |  | — |  |  | 26,623 |  |  | 26,623 |  |
| Total |  | $ | 265,394 |  |  | $ | 113,483 |  |  | $ | 26,623 |  |  | $ | 405,500 |  |

[0000889331-20-000037:notes:11]
[same as prior period, unchanged from 0000889331-19-000052:notes:12]

[0000889331-20-000037:notes:12]
[same as prior period, unchanged from 0000889331-19-000052:notes:13]

[0000889331-20-000037:notes:13]
[same as prior period, unchanged from 0000889331-19-000052:notes:14]

[0000889331-20-000037:notes:14]
[same as prior period, unchanged from 0000889331-19-000052:notes:15]

[0000889331-20-000037:notes:15]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0000889331-20-000037:notes:16]
[same as prior period, unchanged from 0000889331-19-000052:notes:17]

[0000889331-20-000037:notes:17]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-20-000037:notes:18]
[same as prior period, unchanged from 0000889331-19-000052:notes:19]

[0000889331-20-000037:notes:19]
[same as prior period, unchanged from 0000889331-19-000052:notes:20]

[0000889331-20-000037:notes:20]
[same as prior period, unchanged from 0000889331-19-000052:notes:21]

[0000889331-20-000037:notes:21]
[same as prior period, unchanged from 0000889331-19-000052:notes:22]

[0000889331-20-000037:notes:22]
Recently Adopted Accounting Standards

[0000889331-20-000037:notes:23]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments." The standard modifies the measurement approach for credit losses on financial instruments, including trade receivables, from an incurred loss method to a current expected credit loss method ("CECL").  The standard requires the measurement of expected credit losses to be based on relevant information, including historical experiences, current conditions and a forecast that is supportable.  The Company adopted the new standard on December 29, 2019.  The adoption of the standard did not have a material effect on our Condensed Consolidated Financial Statements.

[0000889331-20-000037:notes:24]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement."  ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies certain disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018- 13 did not have a material impact on our Condensed Consolidated Financial Statements.

[0000889331-20-000037:notes:25]
In August 2018, the FASB issued ASU No. 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic: 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force)."  ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The Company adopted the new standard on December 29, 2019.  The adoption of ASU 2018-15 did not have a material impact on our Condensed Consolidated Financial Statements.

[0000889331-20-000037:notes:26]
In March 2020, the FASB issued ASU 2020-04 Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting.” This ASU provides optional expedient and exceptions for applying generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by reference rate reform if certain criteria are met. The objective of this is to provide optional guidance for a limited period of time to ease the potential burden in accounting for (or recognizing the effects of) reference rate reform on financial reporting due to the cessation of the London Interbank Offered Rate (LIBOR). The amendments in this update are effective for all entities as of March 12, 2020 through December 31, 2022. The Company does not expect a material effect from the adoption of this guidance on its Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-20-000037:notes:27]
[same as prior period, unchanged from 0000889331-19-000052:notes:50]

[0000889331-20-000037:notes:28]
The components of inventories at March 28, 2020 and December 28, 2019 are as follows:

[0000889331-20-000037:notes:29]
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| Raw materials |  | $ | 75,202 |  |  | $ | 76,732 |  |
| Work in process |  | 84,030 |  |  | 84,561 |  |
| Finished goods |  | 100,415 |  |  | 110,388 |  |
| Inventory Reserves |  | (32,365 | ) |  | (34,174 | ) |
| Total |  | $ | 227,282 |  |  | $ | 237,507 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-20-000037:notes:30]
[same as prior period, unchanged from 0000889331-19-000052:notes:53]

[0000889331-20-000037:notes:31]
The components of net property, plant, and equipment at March 28, 2020 and December 28, 2019 are as follows:

[0000889331-20-000037:notes:32]
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| Land |  | $ | 22,781 |  |  | $ | 24,758 |  |
| Building |  | 105,067 |  |  | 108,501 |  |
| Equipment |  | 633,899 |  |  | 631,273 |  |
| Accumulated depreciation and amortization |  | (426,918 | ) |  | (419,915 | ) |
| Total |  | $ | 334,829 |  |  | $ | 344,617 |  |

[0000889331-20-000037:notes:33]
The Company recorded depreciation expense of $13.8 million and $13.1 million for the three months ended March 28, 2020 and March 30, 2019, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-20-000037:notes:34]
[same as prior period, unchanged from 0000889331-19-000052:notes:57]

[0000889331-20-000037:notes:35]
The amounts for goodwill and changes in the carrying value by segment for the three months ended March 28, 2020 are as follows:

[0000889331-20-000037:notes:36]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 28, 2019 |  | $ | 650,796 |  |  | $ | 131,321 |  |  | $ | 38,472 |  |  | $ | 820,589 |  |
| Currency translation |  | (5,873 | ) |  | (1,693 | ) |  | (260 | ) |  | (7,826 | ) |
| As of March 28, 2020 |  | $ | 644,923 |  |  | $ | 129,628 |  |  | $ | 38,212 |  |  | $ | 812,763 |  |

[0000889331-20-000037:notes:37]
The components of other intangible assets at March 28, 2020 and December 28, 2019 are as follows:

[0000889331-20-000037:notes:38]
|  |  | As of March 28, 2020 |
| (in thousands) |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  | $ | 9,545 |  |  | $ | 1,755 |  |  | $ | 7,790 |  |
| Patents, licenses and software |  | 129,380 |  |  | $ | 80,506 |  |  | $ | 48,874 |  |
| Distribution network |  | 43,076 |  |  | 36,560 |  |  | 6,516 |  |
| Customer relationships, trademarks, and tradenames |  | 357,188 |  |  | 111,975 |  |  | 245,213 |  |
| Total |  | $ | 539,189 |  |  | $ | 230,796 |  |  | $ | 308,393 |  |

[0000889331-20-000037:notes:39]
|  | As of December 28, 2019 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 9,649 |  |  | $ | 1,730 |  |  | $ | 7,919 |  |
| Patents, licenses and software | 131,164 |  |  | 78,828 |  |  | 52,336 |  |
| Distribution network | 43,239 |  |  | 36,163 |  |  | 7,076 |  |
| Customer relationships, trademarks, and tradenames | 360,534 |  |  | 106,618 |  |  | 253,916 |  |
| Total | $ | 544,586 |  |  | $ | 223,339 |  |  | $ | 321,247 |  |

[0000889331-20-000037:notes:40]
During the three months ended March 28, 2020 and March 30, 2019, the Company recorded amortization expense of $10.0 million and $10.2 million, respectively.

[0000889331-20-000037:notes:41]
During the three months ended March 28, 2020, the Company recognized a $0.3 million non-cash impairment charge on a certain patent triggered by the Company’s announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-20-000037:notes:42]
Estimated annual amortization expense related to intangible assets with definite lives as of March 28, 2020 is as follows:

[0000889331-20-000037:notes:43]
| (in thousands) | Amount |
| 2020 | $ | 38,291 |  |
| 2021 | 37,487 |  |
| 2022 | 36,561 |  |
| 2023 | 32,195 |  |
| 2024 | 29,135 |  |
| 2025 and thereafter | 144,705 |  |
| Total | $ | 318,374 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000889331-20-000037:notes:44]
[same as prior period, unchanged from 0000889331-19-000052:notes:65]

[0000889331-20-000037:notes:45]
The Company leases office and production space under various non-cancelable operating leases that expire no later than 2028. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The Company also has production equipment, office equipment and vehicles under operating leases. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants.

[0000889331-20-000037:notes:46]
[same as prior period, unchanged from 0000889331-19-000052:notes:67]

[0000889331-20-000037:notes:47]
[same as prior period, unchanged from 0000889331-19-000052:notes:68]

[0000889331-20-000037:notes:48]
The following table presents the classification of ROU assets and lease liabilities at March 28, 2020 and December 28, 2019:

[0000889331-20-000037:notes:49]
| Leases(in thousands) | Condensed Consolidated Balance Sheet Classification | March 28, 2020 | December 28, 2019 |
| Assets |  |  |  |
| Operating ROU assets | Right of use lease assets, net | $ | 20,611 |  | $ | 21,918 |  |
| Liabilities |  |  |  |
| Current operating lease liabilities | Accrued liabilities | $ | 7,073 |  | $ | 7,259 |  |
| Non-current operating lease liabilities | Non-current operating lease liabilities | $ | 15,960 |  | $ | 17,166 |  |
| Total lease liabilities |  | $ | 23,033 |  | $ | 24,425 |  |

[0000889331-20-000037:notes:50]
The following table represents the lease costs for the three months ended March 28, 2020 and March 30, 2019:

[0000889331-20-000037:notes:51]
| Leases cost(in thousands) | Condensed Consolidated Statements of Net Income Classification | Three Months Ended March 28, 2020 | Three Months EndedMarch 30, 2019 |
| Short-term lease expenses | Cost of sales, SG&A expenses | $ | 117 |  | $ | 153 |  |
| Variable lease expenses | Cost of sales, SG&A expenses | 318 |  | 194 |  |
| Operating lease rent expenses | Cost of sales, SG&A expenses | 2,173 |  | 2,193 |  |
| Total operating lease costs | Cost of sales, SG&A expenses | $ | 2,608 |  | $ | 2,540 |  |

[0000889331-20-000037:notes:52]
| Maturity of Lease Liabilities as of March 28, 2020(in thousands) | Operating leases |
| 2020 (excluding the three months ended March 28, 2020) | $ | 6,156 |  |
| 2021 | 6,620 |  |
| 2022 | 5,341 |  |
| 2023 | 3,590 |  |
| 2024 | 3,177 |  |
| 2025 and thereafter | 498 |  |
| Total lease payments | $ | 25,382 |  |
| Present value of lease liabilities | $ | 23,033 |  |

[0000889331-20-000037:notes:53]
| Operating Lease Term and Discount Rate | March 28, 2020 |
| Weighted-average remaining lease term (years) | 3.90 |  |
| Weighted-average discount rate | 5.04 | % |

[0000889331-20-000037:notes:54]
| Other Information(in thousands) | Three Months EndedMarch 28, 2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flow payments for operating leases | $ | (2,242 | ) |
| Leased assets obtained in exchange for operating lease liabilities | 848 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-20-000037:notes:55]
[same as prior period, unchanged from 0000889331-19-000052:notes:76]

[0000889331-20-000037:notes:56]
The components of accrued liabilities at March 28, 2020 and December 28, 2019 are as follows:

[0000889331-20-000037:notes:57]
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| Employee-related liabilities |  | $ | 32,381 |  |  | $ | 40,774 |  |
| Operating lease liability |  | 7,073 |  |  | 7,259 |  |
| Interest |  | 3,159 |  |  | 5,058 |  |
| Professional services |  | 3,359 |  |  | 3,986 |  |
| Restructuring liability |  | 3,336 |  |  | 2,679 |  |
| Other non-income taxes |  | 2,058 |  |  | 1,940 |  |
| Other |  | 22,146 |  |  | 22,424 |  |
| Total |  | $ | 73,512 |  |  | $ | 84,120 |  |

[0000889331-20-000037:notes:58]
[same as prior period, unchanged from 0000889331-19-000052:notes:79]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-20-000037:notes:59]
[same as prior period, unchanged from 0000889331-19-000052:notes:80]

[0000889331-20-000037:notes:60]
The Company recorded restructuring, impairment and other charges for the three months ended March 28, 2020 and March 30, 2019 as follows:

[0000889331-20-000037:notes:61]
|  | Three months ended March 28, 2020 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 881 |  |  | $ | 399 |  |  | $ | 321 |  |  | $ | 1,601 |  |
| Other restructuring charges | 1 |  |  | 120 |  |  | 3 |  |  | 124 |  |
| Total restructuring charges | 882 |  |  | 519 |  |  | 324 |  |  | 1,725 |  |
| Impairment | — |  |  | — |  |  | 2,237 |  |  | 2,237 |  |
| Total | $ | 882 |  |  | $ | 519 |  |  | $ | 2,561 |  |  | $ | 3,962 |  |

[0000889331-20-000037:notes:62]
|  | Three months ended March 30, 2019 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 1,800 |  |  | $ | 605 |  |  | $ | 47 |  |  | $ | 2,452 |  |
| Other restructuring charges | 13 |  |  | 20 |  |  | 250 |  |  | 283 |  |
| Total restructuring charges | 1,813 |  |  | 625 |  |  | 297 |  |  | 2,735 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,813 |  |  | $ | 625 |  |  | $ | 297 |  |  | $ | 2,735 |  |

[0000889331-20-000037:notes:63]
2020

[0000889331-20-000037:notes:64]
For the three months ended March 28, 2020, the Company recorded total restructuring charges of $1.7 million, for employee termination costs and other restructuring charges. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $2.2 million of impairment charges related to the land and building associated

[0000889331-20-000037:notes:65]
with the Company’s announcement to consolidate a manufacturing facility within the Industrial segment. The impairment charges were included in selling, general and administrative expenses.

[0000889331-20-000037:notes:66]
[same as prior period, unchanged from 0000889331-19-000052:notes:84]

[0000889331-20-000037:notes:67]
For three months ended March 30, 2019, the Company recorded total restructuring charges of $2.7 million, of which $2.5 million, was for employee termination costs and $0.3 million for other restructuring charges. These charges primarily related to reorganization of operations and selling, general and administrative functions as well as integration of IXYS within the Electronics segment and the reorganization of operations in the commercial vehicle products and automotive sensors businesses within the Automotive segment.

[0000889331-20-000037:notes:68]
The restructuring reserves as of March 28, 2020 and December 28, 2019 are $3.3 million and $2.7 million, respectively. The restructuring reserves are included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by March 2021.


## us-gaap:DebtDisclosureTextBlock

[0000889331-20-000037:notes:69]
Debt

[0000889331-20-000037:notes:70]
The carrying amounts of debt at March 28, 2020 and December 28, 2019 are as follows:

[0000889331-20-000037:notes:71]
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | — |  |
| Term Loan |  | 142,500 |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,316 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 104,189 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,429 | ) |  | (3,669 | ) |
| Total debt |  | 774,195 |  |  | 679,158 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 764,195 |  |  | $ | 669,158 |  |

[0000889331-20-000037:notes:72]
Revolving Credit Facility / Term Loan

[0000889331-20-000037:notes:73]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000037:notes:74]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $2.5 million of principal payments on the term loan during the three months ended March 28, 2020.

[0000889331-20-000037:notes:75]
Outstanding borrowings under the Credit Agreement bore interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 2.47% at March 28, 2020.

[0000889331-20-000037:notes:76]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to coronavirus disease 2019 ("COVID-19").

[0000889331-20-000037:notes:77]
As of March 28, 2020, the Company had no amount outstanding in letters of credit and had available $219.8 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 28, 2020, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-20-000037:notes:78]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.  The balance under the facility is $240.0 million as of April 3, 2020.

[0000889331-20-000037:notes:79]
Senior Notes

[0000889331-20-000037:notes:80]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-20-000037:notes:81]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000037:notes:82]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-20-000037:notes:83]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-20-000037:notes:84]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 28, 2020, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-20-000037:notes:85]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-20-000037:notes:86]
Interest paid on all Company debt was $7.4 million and $8.0 million for the three months ended March 28, 2020 and March 30, 2019, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-20-000037:notes:87]
[same as prior period, unchanged from 0000889331-19-000052:notes:107]

[0000889331-20-000037:notes:88]
[same as prior period, unchanged from 0000889331-19-000052:notes:108]

[0000889331-20-000037:notes:89]
[same as prior period, unchanged from 0000889331-19-000052:notes:109]

[0000889331-20-000037:notes:90]
[same as prior period, unchanged from 0000889331-19-000052:notes:110]

[0000889331-20-000037:notes:91]
[same as prior period, unchanged from 0000889331-19-000052:notes:111]

[0000889331-20-000037:notes:92]
[same as prior period, unchanged from 0000889331-19-000052:notes:112]

[0000889331-20-000037:notes:93]
Cash Equivalents

[0000889331-20-000037:notes:94]
Cash equivalents primarily consist of money market funds, which are held with an institution with sound credit rating and are highly liquid. The Company classified cash equivalents as Level 1 and are valued at cost which approximates fair value.

[0000889331-20-000037:notes:95]
[same as prior period, unchanged from 0000889331-19-000052:notes:113]

[0000889331-20-000037:notes:96]
[same as prior period, unchanged from 0000889331-19-000052:notes:114]

[0000889331-20-000037:notes:97]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the three months ended March 30, 2019, the Company recorded impairment charges of $2.8 million in Other expense (income), net in the Condensed Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value. As of March 28, 2020 and December 28, 2019, the balances of these investments were $0.4 million. The fair value of these investments are measured on a nonrecurring basis and determined to be Level 3 under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-20-000037:notes:98]
[same as prior period, unchanged from 0000889331-19-000052:notes:116]

[0000889331-20-000037:notes:99]
[same as prior period, unchanged from 0000889331-19-000052:notes:117]

[0000889331-20-000037:notes:100]
There were no changes during the quarter ended March 28, 2020 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. On October 30, 2019, the Company entered a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Chinese renminbi and U.S. dollar.  The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly basis. The notional value of the forward contracts at December 28, 2019 was $16.0 million and expires on May 5, 2020.  On March 23, 2020, the Company unwound the foreign currency exchange forward contract entered on October 30, 2019 and recognized a gain of $0.2 million within Other expenses,

[0000889331-20-000037:notes:101]
net during the three months ended March 28, 2020. The fair values of the foreign currency forward contract was determined to be Level 2 under the fair value hierarchy and is valued using market exchange rates.

[0000889331-20-000037:notes:102]
As of March 28, 2020 and December 28, 2019, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-20-000037:notes:103]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of March 28, 2020:

[0000889331-20-000037:notes:104]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 198,221 |  |  | $ | — |  |  | $ | — |  |  | $ | 198,221 |  |
| Investments in equity securities |  | 10,529 |  |  | — |  |  | — |  |  | 10,529 |  |
| Mutual funds |  | 8,769 |  |  | — |  |  | — |  |  | 8,769 |  |

[0000889331-20-000037:notes:105]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 28, 2019:

[0000889331-20-000037:notes:106]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 118,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,999 |  |
| Investments in equity securities |  | 12,969 |  |  | — |  |  | — |  |  | 12,969 |  |
| Mutual funds |  | 10,464 |  |  | — |  |  | — |  |  | 10,464 |  |

[0000889331-20-000037:notes:107]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at March 28, 2020 and December 28, 2019, as the rates on these borrowings are variable in nature.

[0000889331-20-000037:notes:108]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of March 28, 2020 and December 28, 2019 were as follows:

[0000889331-20-000037:notes:109]
|  |  | March 28, 2020 |  | December 28, 2019 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 128,316 |  |  | $ | 121,124 |  |  | $ | 129,808 |  |  | $ | 131,710 |  |
| Euro Senior Notes, Series B due 2028 |  | 104,189 |  |  | 94,743 |  |  | 105,400 |  |  | 110,336 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 24,681 |  |  | 25,000 |  |  | 25,054 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 97,097 |  |  | 100,000 |  |  | 102,548 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 48,921 |  |  | 50,000 |  |  | 50,775 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 118,648 |  |  | 125,000 |  |  | 127,701 |  |

[0000889331-20-000037:notes:110]
The Company recognized impairment charges of $1.9 million for the land and building and $0.3 million for a certain patent as a result of the Company’s announcement to consolidate a manufacturing facility within the Industrial segment. See Note 7, Restructuring, Impairment and Other Charges, for further discussion. The fair value of the land and building was determined to be Level 3 under the fair value hierarchy and was valued using a real estate appraisal.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-20-000037:notes:111]
[same as prior period, unchanged from 0000889331-19-000052:notes:126]

[0000889331-20-000037:notes:112]
[same as prior period, unchanged from 0000889331-19-000052:notes:127]

[0000889331-20-000037:notes:113]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three months ended March 28, 2020 and March 30, 2019 were as follows:

[0000889331-20-000037:notes:114]
|  |  | For the Three Months Ended |
| (in thousands) |  | March 28, 2020 |  | March 30, 2019 |
| Components of net periodic benefit cost: |  |  |  |  |
| Service cost |  | $ | 618 |  |  | $ | 500 |  |
| Interest cost |  | 658 |  |  | 784 |  |
| Expected return on plan assets |  | (727 | ) |  | (790 | ) |
| Amortization of prior service and net actuarial loss |  | 145 |  |  | 62 |  |
| Net periodic benefit cost |  | $ | 694 |  |  | $ | 556 |  |

[0000889331-20-000037:notes:115]
The Company expects to make approximately $2.3 million of cash contributions to its pension plans in 2020.

[0000889331-20-000037:notes:116]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. For the three months ended March 28, 2020 and March 30, 2019, the Company recorded $0.5 million and $0.2 million expense, respectively, in Cost of Sales and Other expense (income), net within the Condensed Consolidated Statements of Net Income. For three months ended March 28, 2020, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.2 million.

[0000889331-20-000037:notes:117]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay and administer pension payments to certain of the Company’s UK pension plan participants, or their designated beneficiaries, who have been receiving pension payments. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $36 million, representing approximately 30% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge in the second half of 2021 currently estimated between $18 million and $22 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-20-000037:notes:118]
[same as prior period, unchanged from 0000889331-19-000052:notes:131]

[0000889331-20-000037:notes:119]
[same as prior period, unchanged from 0000889331-19-000052:notes:132]

[0000889331-20-000037:notes:120]
| (in thousands) |  | Three Months EndedMarch 28, 2020 |  | Three Months EndedMarch 30, 2019 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 555 |  |  | $ | (6 | ) |  | $ | 561 |  |  | $ | (78 | ) |  | $ | (29 | ) |  | $ | (49 | ) |
| Foreign currency translation adjustments |  | (15,540 | ) |  | — |  |  | (15,540 | ) |  | 8,122 |  |  | — |  |  | 8,122 |  |
| Total change in other comprehensive income (loss) |  | $ | (14,985 | ) |  | $ | (6 | ) |  | $ | (14,979 | ) |  | $ | 8,044 |  |  | $ | (29 | ) |  | $ | 8,073 |  |

[0000889331-20-000037:notes:121]
The following tables set forth the changes in accumulated other comprehensive (loss) income by component for the three months ended March 28, 2020 and March 30, 2019:

[0000889331-20-000037:notes:122]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 28, 2019 |  | $ | (18,046 | ) |  | $ | (88,777 | ) |  | $ | (106,823 | ) |
| Activity in the period |  | 561 |  |  | (15,540 | ) |  | (14,979 | ) |
| Balance at March 28, 2020 |  | $ | (17,485 | ) |  | $ | (104,317 | ) |  | $ | (121,802 | ) |

[0000889331-20-000037:notes:123]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensiveincome (loss) |
| Balance at December 29, 2018 |  | $ | (9,959 | ) |  | $ | (87,965 | ) |  | $ | (97,924 | ) |
| Activity in the period |  | (49 | ) |  | 8,122 |  |  | 8,073 |  |
| Balance at March 30, 2019 |  | $ | (10,008 | ) |  | $ | (79,843 | ) |  | $ | (89,851 | ) |

[0000889331-20-000037:notes:124]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three months ended March 28, 2020 and March 30, 2019 were as follows:

[0000889331-20-000037:notes:125]
|  |  | Three Months Ended |
| (in thousands) |  | March 28, 2020 |  | March 30, 2019 |
| Pension and Postemployment plans: |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 345 |  |  | $ | 62 |  |

[0000889331-20-000037:notes:126]
[same as prior period, unchanged from 0000889331-19-000052:notes:141]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-20-000037:notes:127]
[same as prior period, unchanged from 0000889331-19-000052:notes:142]

[0000889331-20-000037:notes:128]
The effective tax rate for the three months ended March 28, 2020 was 30.6% compared to the effective tax rate for the three months ended March 30, 2019 of 20.3%. The effective tax rate for the 2020 period is higher than the effective tax rate for the 2019 comparable period primarily due to a reduction in the forecasted income earned in lower tax jurisdictions in 2020 driven by the uncertainty resulting from the impact of COVID-19. The effective tax rate for the 2020 period is higher than the applicable U.S. statutory tax rate primarily due to the forecasted impact of non-U.S. losses and expenses with no tax benefit and the U.S. GILTI tax provisions (in the 2019 period the impact of these items was more than offset by the impact of income earned in lower tax jurisdictions).


## us-gaap:EarningsPerShareTextBlock

[0000889331-20-000037:notes:129]
[same as prior period, unchanged from 0000889331-19-000052:notes:144]

[0000889331-20-000037:notes:130]
[same as prior period, unchanged from 0000889331-19-000052:notes:145]

[0000889331-20-000037:notes:131]
|  |  | Three Months Ended |
| (in thousands, except per share amounts) |  | March 28, 2020 |  | March 30, 2019 |
| Numerator: |  |  |  |  |
| Net income as reported |  | $ | 24,644 |  |  | $ | 36,989 |  |
| Denominator: |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |
| Basic |  | 24,393 |  |  | 24,717 |  |
| Effect of dilutive securities |  | 185 |  |  | 292 |  |
| Diluted |  | 24,578 |  |  | 25,009 |  |
| Earnings Per Share: |  |  |  |  |
| Basic earnings per share |  | $ | 1.01 |  |  | $ | 1.50 |  |
| Diluted earnings per share |  | $ | 1.00 |  |  | $ | 1.48 |  |

[0000889331-20-000037:notes:132]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 153,836 and 77,047 for the three months ended March 28, 2020 and March 30, 2019, respectively.

[0000889331-20-000037:notes:133]
[same as prior period, unchanged from 0000889331-19-000052:notes:148]

[0000889331-20-000037:notes:134]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized to a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program") to replace its previous expired 2018 program. On April 23, 2020, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. The Company does not expect to repurchase shares in the near future due to the uncertainty of the impact and duration of COVID-19.

[0000889331-20-000037:notes:135]
For the three months ended March 28, 2020 and March 30, 2019, the Company repurchased 175,110 and 79,916 shares of its common stock totaling $22.9 million and $13.6 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-20-000037:notes:136]
Related Party Transactions

[0000889331-20-000037:notes:137]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-20-000037:notes:138]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-20-000037:notes:139]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-20-000037:notes:140]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-20-000037:notes:141]
|  |  | For the Three Months Ended March 28, 2020 |  | For the Three Months Ended March 30, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.4 |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Purchase material/ service from related party |  | 0.2 |  | — |  | 1.8 |  |  | 0.8 |  | 0.1 |  | 1.5 |  |
|  |  | March 28, 2020 |  | December 28, 2019 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.1 |  | — |  | — |  |  | 0.2 |  | — |  | 0.1 |  |

[0000889331-20-000037:notes:142]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.4 million as of March 28, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

[0000889331-20-000037:notes:143]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net Income. The operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-20-000037:notes:144]
[same as prior period, unchanged from 0000889331-19-000052:notes:158]

[0000889331-20-000037:notes:145]
[same as prior period, unchanged from 0000889331-19-000052:notes:159]

[0000889331-20-000037:notes:146]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments' current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-20-000037:notes:147]
| • | Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, |

[0000889331-20-000037:notes:148]
positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors,

[0000889331-20-000037:notes:149]
reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage

[0000889331-20-000037:notes:150]
suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, metal-oxide-semiconductor field effect

[0000889331-20-000037:notes:151]
transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies.

[0000889331-20-000037:notes:152]
The segment covers a broad range of end markets, including industrial and automotive electronics, electric vehicle and related infrastructure, data and telecommunications, medical devices, alternative energy, consumer electronics and white goods.

[0000889331-20-000037:notes:153]
| • | Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle end markets. Passenger car fuse products include fuses and fuse accessories for internal combustion engine vehicles and hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle products designed to monitor the passenger compartment occupants, safety and environment as well as the vehicle’s powertrain. |

[0000889331-20-000037:notes:154]
| • | Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in various industrial applications such as oil, gas, mining, alternative energy, electric vehicle infrastructure, non-residential construction, HVAC systems, elevators and other industrial equipment. |

[0000889331-20-000037:notes:155]
[same as prior period, unchanged from 0000889331-19-000052:notes:164]

[0000889331-20-000037:notes:156]
|  |  | Three Months Ended |
| (in thousands) |  | March 28, 2020 |  | March 30, 2019 |
| Net sales |  |  |  |  |
| Electronics |  | $ | 214,189 |  |  | $ | 265,394 |  |
| Automotive |  | 104,770 |  |  | 113,483 |  |
| Industrial |  | 27,137 |  |  | 26,623 |  |
| Total net sales |  | $ | 346,096 |  |  | $ | 405,500 |  |
| Depreciation and amortization |  |  |  |  |
| Electronics |  | $ | 15,531 |  |  | $ | 15,342 |  |
| Automotive |  | 7,187 |  |  | 6,877 |  |
| Industrial |  | 1,084 |  |  | 1,060 |  |
| Total depreciation and amortization |  | $ | 23,802 |  |  | $ | 23,279 |  |
| Operating income (loss) |  |  |  |  |
| Electronics |  | $ | 32,272 |  |  | $ | 49,037 |  |
| Automotive |  | 14,116 |  |  | 13,200 |  |
| Industrial |  | 3,534 |  |  | 3,505 |  |
| Other(a) |  | (5,172 | ) |  | (5,069 | ) |
| Total operating income |  | 44,750 |  |  | 60,673 |  |
| Interest expense |  | 5,418 |  |  | 5,686 |  |
| Foreign exchange loss |  | 2,584 |  |  | 4,243 |  |
| Other expense, net |  | 1,249 |  |  | 4,305 |  |
| Income before income taxes |  | $ | 35,499 |  |  | $ | 46,439 |  |

[0000889331-20-000037:notes:157]
(a) Included in “Other” Operating income (loss) for the 2020 first quarter is $1.2 million of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $4.0 million of restructuring, impairment and other charges, primarily related to impairment charges of $2.2 million associated with the announced consolidation of a manufacturing facility within the Industrial segment and $1.7 million of employee termination costs and other restructuring charges. See Note 7, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-20-000037:notes:158]
Included in "Other" Operating income (loss) for the first quarter of 2019 is $2.4 million of acquisition integration charges primarily related to the IXYS acquisition. In addition, there were $2.7 million of restructuring charges primarily related to employee termination costs.

[0000889331-20-000037:notes:159]
[same as prior period, unchanged from 0000889331-19-000052:notes:168]

[0000889331-20-000037:notes:160]
|  |  | Three Months Ended |
| (in thousands) |  | March 28, 2020 |  | March 30, 2019 |
| Net sales |  |  |  |  |
| United States |  | $ | 102,910 |  |  | $ | 119,528 |  |
| China |  | 86,015 |  |  | 106,866 |  |
| Other countries(a) |  | 157,171 |  |  | 179,106 |  |
| Total net sales |  | $ | 346,096 |  |  | $ | 405,500 |  |

[0000889331-20-000037:notes:161]
[same as prior period, unchanged from 0000889331-19-000052:notes:170]

[0000889331-20-000037:notes:162]
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 54,870 |  |  | $ | 58,081 |  |
| China |  | 83,830 |  |  | 88,306 |  |
| Mexico |  | 69,664 |  |  | 73,096 |  |
| Germany |  | 35,483 |  |  | 36,025 |  |
| Philippines |  | 55,347 |  |  | 51,738 |  |
| Other countries(a) |  | 35,635 |  |  | 37,371 |  |
| Total long-lived assets |  | $ | 334,829 |  |  | $ | 344,617 |  |

[0000889331-20-000037:notes:163]
[same as prior period, unchanged from 0000889331-19-000052:notes:172]

[0000889331-20-000037:notes:164]
|  |  | Three Months Ended |
| (in thousands) |  | March 28, 2020 |  | March 30, 2019 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 580 |  |  | $ | 905 |  |
| China |  | 1,657 |  |  | 1,225 |  |
| Mexico |  | 2,592 |  |  | 5,484 |  |
| Germany |  | 753 |  |  | 598 |  |
| Philippines |  | 3,218 |  |  | 5,229 |  |
| Other countries(a) |  | 2,508 |  |  | 635 |  |
| Total additions to long-lived assets |  | $ | 11,308 |  |  | $ | 14,076 |  |

[0000889331-20-000037:notes:165]
[same as prior period, unchanged from 0000889331-19-000052:notes:174]

[0000889331-20-000037:notes:166]
Each country included in other countries is less than 10% of net sales.
