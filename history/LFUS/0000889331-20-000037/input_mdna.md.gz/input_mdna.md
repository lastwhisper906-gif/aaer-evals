# LFUS MD&A — 0000889331-20-000037


## mdna

[0000889331-20-000037:mdna:1]
[same as prior period, unchanged from 0000889331-19-000052:mdna:1]

[0000889331-20-000037:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-20-000037:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 28, 2019.

[0000889331-20-000037:mdna:4]
[same as prior period, unchanged from 0000889331-19-000052:mdna:4]

[0000889331-20-000037:mdna:5]
[same as prior period, unchanged from 0000889331-19-000052:mdna:5]

[0000889331-20-000037:mdna:6]
Founded in 1927, Littelfuse is a global manufacturer of leading technologies in circuit protection, power control and sensing.

[0000889331-20-000037:mdna:7]
Serving over 100,000 end customers, the Company’s products are found in automotive and commercial vehicles, industrial

[0000889331-20-000037:mdna:8]
applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

[0000889331-20-000037:mdna:9]
The Company maintains a network of global laboratories and engineering centers that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company conducts its business through three reportable segments: Electronics, Automotive, and Industrial. Within these segments, the Company designs, manufactures and sells components and modules for circuit protection, power control and sensing products throughout the world. The circuit protection products protect against electrostatic discharge, power surges, short circuits, voltage spikes and other harmful occurrences; our power control products safely and efficiently control power and improve productivity  and our sensor products are used to identify and detect temperature, proximity, flow speed and fluid level in various applications.

[0000889331-20-000037:mdna:10]
[same as prior period, unchanged from 0000889331-19-000052:mdna:8]

[0000889331-20-000037:mdna:11]
For the first quarter of 2020, the Company recognized net sales of $346.1 million compared to $405.5 million in the first quarter of 2019 representing a decrease of $59.4 million, or 14.6%. The decrease was primarily driven by lower volume in the Electronics segment due to electronics distribution partners and end customers reducing excess inventories, lower volume in the Automotive segment, the impact of COVID-19 and $3.3 million or 0.8% of unfavorable changes in foreign exchange rates, partially offset by higher volume in the Industrial segment. The Company recognized net income of $24.6 million, or $1.00 per diluted share, in the first quarter of 2020 compared to net income of $37.0 million, or $1.48 per diluted share in the first quarter of 2019. The decrease in net income was primarily due to lower operating income in the Electronics segment.

[0000889331-20-000037:mdna:12]
The Company continues to take actions to improve its cost structure. The Company expects to realize cost savings from the restructuring activities taken during 2019 and 2020, including the reorganization of certain manufacturing, selling and administrative functions across all segments and the consolidation of a manufacturing facility within the Industrial Segment.

[0000889331-20-000037:mdna:13]
Net cash provided by operating activities was $45.3 million for the three months ended March 28, 2020 as compared to $30.9 million for the three months ended March 30, 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and inventory levels, partially offset by lower earnings.

[0000889331-20-000037:mdna:14]
During the three months ended March 28, 2020 and March 30, 2019, the Company repurchased 175,110 and 79,916 shares of its common stock totaling $22.9 million and $13.6 million, respectively.

[0000889331-20-000037:mdna:15]
On March 25, 2020, the company borrowed $100.0 million from its current revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. On April 3, 2020, the Company amended the existing credit agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended credit agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.  The current balance under the facility is $240.0 million as of April 3, 2020.

[0000889331-20-000037:mdna:16]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay and administer pension payments to certain of the Company’s UK pension plan participants, or their designated beneficiaries, who have been receiving pension payments. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $36 million, representing approximately 30% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge in the second half of 2021 currently estimated between $18 million and $22 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-20-000037:mdna:17]
Impact of COVID-19 on Business

[0000889331-20-000037:mdna:18]
The global emergence of COVID-19 impacted the Company’s 2020 first quarter results. The Electronics segment had reduced sales volume driven by production disruption from temporary closures of manufacturing facilities in China and the Philippines as a result of government directives.  The Automotive segment had reduced sales volume driven by a reduction in customer demand late in the quarter.  Additionally, the Company incurred incremental costs of approximately $2.5 million primarily due to higher costs for freight and protective supplies, as well as costs related to the above temporary plant closures.

[0000889331-20-000037:mdna:19]
The future impacts of COVID-19 on our business are currently unknown. The Company’s priorities are to focus on our employees, customers and long-term financial health of the company. In an effort to protect the health and safety of our employees, the Company took numerous proactive, aggressive actions from the earliest signs of the outbreak in China, adopting performing temperature checks in many locations, procuring and distributing proper PPE (personal protective equipment) to employees and their families in many locations, following strict hand and respiratory hygiene, sanitization and cleaning protocols and outlining social distancing policies at our locations around the world.  The Company is also limiting the number of employees attending meetings in person, reducing the number of people in our sites at any one time, implementing working from home, and suspending employee travel.

[0000889331-20-000037:mdna:20]
In an effort to contain COVID-19 or slow its spread, governments around the world have also enacted various measures, including orders to close all businesses not deemed “essential,” isolate residents to their homes or places of residence, and practice social distancing when engaging in essential activities.  These government measures have disrupted certain of our operating locations in Asia, Europe and Mexico.  All of our China manufacturing locations that were temporarily closed in February have returned operations to normal capacity levels, while certain operations in Europe, the Philippines and Mexico continue to be temporarily closed or operating at reduced capacity levels.

[0000889331-20-000037:mdna:21]
The Company continues to focus on our customers and to support their critical needs.  We continue to work with customers to provide necessary products, many of which are considered essential, including healthcare and medical devices, transportation, communication and energy infrastructure.

[0000889331-20-000037:mdna:22]
The Company has taken cost containment initiatives to help offset the impact of lower demand and the business disruption created by COVID-19. During the quarter, the Company suspended annual wage increases and its 2020 annual cash incentive program.  The Company also reduced salaries of the CEO and executive leadership team, and reduced cash compensation of its board of directors. The Company continues to develop and execute contingency plans to manage our business performance within this uncertain environment.

[0000889331-20-000037:mdna:23]
The Company anticipates that the global health crisis caused by COVID-19 will negatively impact its business activity. It is currently difficult to estimate the magnitude and duration of the COVID-19 disruption and its impact on our employees, customers, suppliers and vendors.  The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business and operations, including the effects on our customers, employees, and prospects, or on our financial results for the remainder of fiscal 2020.

[0000889331-20-000037:mdna:24]
Risks Related to Market Conditions

[0000889331-20-000037:mdna:25]
The Company performs its annual goodwill impairment tests as of September 30, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.  Since September 30, 2019, the date of the Company’s last annual review for impairment, the market value of the Company’s stock has declined.  Management has considered the resulting decline in the Company’s market capitalization in performing its assessment of whether an interim impairment review was required for any reporting units. As part of this assessment, management analyzed the potential declines in value of individual reporting units based on each reporting unit’s operating results for the three months ended March 28, 2020 compared to expected results as of September 30, 2019. In addition, management considered how other key assumptions, including discount rates, expected profitability and long-term growth rates used in the last fiscal year’s impairment analysis, could be impacted by recent market conditions and economic events. Based on this interim assessment, management concluded that as of March 28, 2020, no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value. A continued global economic slowdown and further business disruption due to COVID-19 could result in changes to expectations of future financial results and key valuation assumptions. These changes could result in changes to management’s estimates of the fair value of the Company’s reporting units and could

[0000889331-20-000037:mdna:26]
result in a review for impairment of goodwill prior to September 29, 2020, the Company’s next annual measurement date, and a potential corresponding impairment charge.

[0000889331-20-000037:mdna:27]
In particular, the automotive sensors reporting unit has experienced declines in sales due to lower automotive market car build, reduced volumes and temporary customer shut-downs due to COVID-19.  In addition, the semiconductors reporting unit has experienced declines in sales due to temporary plant shut-downs and lower customer demand primarily due to COVID-19.  The Company continues to evaluate the impact of COVID-19 on its future long-term expectations for these units. Further negative developments having a significant impact on the estimated fair value of these reporting units could result in future goodwill impairment charges.  As of the September 30, 2019 annual goodwill impairment test, the automotive sensors and semiconductors reporting units estimated fair values exceeded its book value by approximately 40% and 42%, respectively.  As of March 28, 2020, $42.2 million and $462.7 million of goodwill was allocated to the automotive sensors and semiconductors reporting units, respectively.  The automotive sensors reporting unit is included within the Automotive segment and the semiconductors reporting unit is included within the Electronics segment.

[0000889331-20-000037:mdna:28]
While the Company has not historically had significant credit risk on accounts receivable, the impact of the COVID-19 pandemic and associated economic slowdown may increase the Company’s credit risk on accounts receivable. It is possible that the Company’s customers may experience liquidity issues which may impact the timing of the collections on receivables. The Company will continue to evaluate how the ongoing pandemic may impact collectability.

[0000889331-20-000037:mdna:29]
[same as prior period, unchanged from 0000889331-19-000052:mdna:13]

[0000889331-20-000037:mdna:30]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The first quarter of 2020 includes $5.2 million of non-segment charges, which included $4.0 million of restructuring, impairment and other charges primarily related to impairment charges of $2.2 million associated with the announced consolidation of a manufacturing facility in the Industrial segment and employee termination costs and other restructuring charges and $1.2 million of acquisition-related and integration charges primarily related to the IXYS acquisition and other contemplated acquisitions.

[0000889331-20-000037:mdna:31]
The first quarter of 2019 includes $2.4 million of acquisition integration charges primarily related to the IXYS acquisition. In addition, there were $2.7 million of restructuring charges primarily related to employee termination costs.

[0000889331-20-000037:mdna:32]
|  |  | First Quarter |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |
| Net sales |  | $ | 346,096 |  |  | $ | 405,500 |  |  | $ | (59,404 | ) |  | (14.6 | )% |
| Gross profit |  | 123,712 |  |  | 155,228 |  |  | (31,516 | ) |  | (20.3 | )% |
| Operating expenses |  | 78,962 |  |  | 94,555 |  |  | (15,593 | ) |  | (16.5 | )% |
| Operating income |  | 44,750 |  |  | 60,673 |  |  | (15,923 | ) |  | (26.2 | )% |
| Income before income taxes |  | 35,499 |  |  | 46,439 |  |  | (10,940 | ) |  | (23.6 | )% |
| Income taxes |  | 10,855 |  |  | 9,450 |  |  | 1,405 |  |  | 14.9 | % |
| Net income |  | $ | 24,644 |  |  | $ | 36,989 |  |  | $ | (12,345 | ) |  | (33.4 | )% |

[0000889331-20-000037:mdna:33]
[same as prior period, unchanged from 0000889331-19-000052:mdna:17]

[0000889331-20-000037:mdna:34]
Net sales decreased $59.4 million or 14.6% for the first quarter of 2020 compared to the first quarter of 2019 primarily due to lower volume across the Electronics segment from electronics distribution partners and end customers reducing excess inventories and production, and lower volume across the Automotive segment due to a decline in global auto production driven by lower global end market demand and a reduction in customer demand due to COVID-19, disruption across the Electronics and Automotive  segments due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, and $3.3 million or 0.8% of unfavorable changes in foreign exchange rates, partially offset by higher volume in the Industrial segment.

[0000889331-20-000037:mdna:35]
[same as prior period, unchanged from 0000889331-19-000052:mdna:20]

[0000889331-20-000037:mdna:36]
Gross profit was $123.7 million, or 35.7% of net sales, in the first quarter of 2020 compared to $155.2 million, or 38.3% of net sales, in the first quarter of 2019. The decrease in gross profit is primarily due to lower volumes across the Electronics segment, additional costs associated with higher freight, supplies and other costs associated with government-directed plant shutdowns and supply chain constraints due to the impact of COVID-19, and unfavorable price and product mix.

[0000889331-20-000037:mdna:37]
[same as prior period, unchanged from 0000889331-19-000052:mdna:23]

[0000889331-20-000037:mdna:38]
Total operating expenses were $79.0 million, or 22.8% of net sales, for the first quarter of 2020 compared to $94.6 million, or 23.3% of net sales, for the first quarter of 2019. The decrease in operating expenses of $15.6 million is primarily due to global cost saving initiatives across all segments, lower incentive compensation, lower sales commissions and travel expenses due to COVID-19, and lower acquisition-related and integration charges of $1.2 million, partially offset by the impairment charges of $2.2 million related to the Company’s announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-20-000037:mdna:39]
[same as prior period, unchanged from 0000889331-19-000052:mdna:26]

[0000889331-20-000037:mdna:40]
Operating income was $44.8 million, a decrease of $15.9 million, or 26.2%, for the first quarter of 2020 compared to $60.7 million for the first quarter of 2019. The decrease in operating income is primarily due to lower gross margin across the Electronics segment, partially offset by the lower operating expenses noted above. Operating margins decreased from 15.0% in the first quarter of 2019 to 12.9% in the first quarter of 2020 driven by the factors mentioned above.

[0000889331-20-000037:mdna:41]
[same as prior period, unchanged from 0000889331-19-000052:mdna:30]

[0000889331-20-000037:mdna:42]
Income before income taxes was $35.5 million, or 10.3% of net sales, for the first quarter of 2020 compared to $46.4 million, or 11.5% of net sales, for the first quarter of 2019. The decline in income before income taxes was primarily driven be lower operating income discussed above. In addition, income before taxes was primarily impacted by impairment charges of $2.8 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment during three months ended March 28, 2019, lower foreign exchange losses of $1.7 million during the three months ended March 28, 2020 compared to the three months ended March 30, 2019 and higher interest income of $0.9 million during  three months ended March 28, 2020 compared to the three months ended March 30, 2019, partially offset by unrealized investment losses of $2.3 million associated with our equity investments during the three months ended March 28, 2020 compared to unrealized gains of $0.4 million during the three months ended March 30, 2019.

[0000889331-20-000037:mdna:43]
[same as prior period, unchanged from 0000889331-19-000052:mdna:33]

[0000889331-20-000037:mdna:44]
Income tax expense was $10.9 million, or an effective tax rate of 30.6%, for the first quarter of 2020 compared to income tax expense of $9.5 million, or an effective tax rate of 20.3%, for the first quarter of 2019. The effective tax rate for the 2020 period is higher than the effective tax rate for the 2019 comparable period primarily due to a reduction in the forecasted income earned in lower tax jurisdictions in 2020 driven by the uncertainty resulting from the impact of COVID-19. The effective tax rate for the 2020 period is higher than the applicable U.S. statutory tax rate primarily due to the forecasted impact of non-U.S. losses and expenses with no tax benefit and the U.S. GILTI tax provisions (in the 2019 period the impact of these items was more than offset by the impact of income earned in lower tax jurisdictions).

[0000889331-20-000037:mdna:45]
[same as prior period, unchanged from 0000889331-19-000052:mdna:36]

[0000889331-20-000037:mdna:46]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 15, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-20-000037:mdna:47]
[same as prior period, unchanged from 0000889331-19-000052:mdna:38]

[0000889331-20-000037:mdna:48]
|  |  | First Quarter |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |
| Electronics |  | $ | 214,189 |  |  | $ | 265,394 |  |  | $ | (51,205 | ) |  | (19.3 | )% |
| Automotive |  | 104,770 |  |  | 113,483 |  |  | (8,713 | ) |  | (7.7 | )% |
| Industrial |  | 27,137 |  |  | 26,623 |  |  | 514 |  |  | 1.9 | % |
| Total |  | $ | 346,096 |  |  | $ | 405,500 |  |  | $ | (59,404 | ) |  | (14.6 | )% |

[0000889331-20-000037:mdna:49]
[same as prior period, unchanged from 0000889331-19-000052:mdna:40]

[0000889331-20-000037:mdna:50]
Net sales decreased $51.2 million, or 19.3%, in the first quarter of 2020 compared to the first quarter of 2019 primarily due to lower volume across all businesses from electronics distribution partners and end customers reducing excess inventories, production disruption from temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, and unfavorable changes in foreign exchange rates of $1.7 million.

[0000889331-20-000037:mdna:51]
[same as prior period, unchanged from 0000889331-19-000052:mdna:43]

[0000889331-20-000037:mdna:52]
Net sales decreased $8.7 million, or 7.7%, in the first quarter of 2020 compared to the first quarter of 2019 due to decreased volume across all businesses from a decline in global auto production, a reduction in customer demand late in the quarter due to the impact of COVID-19, and unfavorable changes in foreign exchange rates of $1.5 million.

[0000889331-20-000037:mdna:53]
[same as prior period, unchanged from 0000889331-19-000052:mdna:46]

[0000889331-20-000037:mdna:54]
Net sales increased by $0.5 million, or 1.9%, in the first quarter of 2020 compared to the first quarter of 2019 primarily due to higher volume across all businesses, partially offset by unfavorable changes in foreign exchange rates of $0.1 million.

[0000889331-20-000037:mdna:55]
[same as prior period, unchanged from 0000889331-19-000052:mdna:49]

[0000889331-20-000037:mdna:56]
[same as prior period, unchanged from 0000889331-19-000052:mdna:50]

[0000889331-20-000037:mdna:57]
|  |  | First Quarter |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 140,873 |  |  | $ | 172,781 |  |  | $ | (31,908 | ) |  | (18.5 | )% |
| Americas |  | 120,501 |  |  | 138,034 |  |  | (17,533 | ) |  | (12.7 | )% |
| Europe |  | 84,722 |  |  | 94,685 |  |  | (9,963 | ) |  | (10.5 | )% |
| Total |  | $ | 346,096 |  |  | $ | 405,500 |  |  | $ | (59,404 | ) |  | (14.6 | )% |

[0000889331-20-000037:mdna:58]
[same as prior period, unchanged from 0000889331-19-000052:mdna:52]

[0000889331-20-000037:mdna:59]
Net sales decreased $31.9 million, or 18.5%, in the first quarter of 2020 compared to the first quarter of 2019. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment, lower volume in passenger car products and automotive sensor businesses within the Automotive segment, and unfavorable changes in foreign exchange rates of $0.9 million.

[0000889331-20-000037:mdna:60]
[same as prior period, unchanged from 0000889331-19-000052:mdna:55]

[0000889331-20-000037:mdna:61]
Net sales decreased $17.5 million, or 12.7%, in the first quarter of 2020 compared to the first quarter of 2019 primarily due to lower volume across all businesses within the Electronics segment, lower volume in automotive sensor and commercial vehicle businesses in the Automotive segment, and unfavorable changes in foreign exchange rates of $0.1 million, partially offset by higher volume across all businesses within the Industrial segment.

[0000889331-20-000037:mdna:62]
[same as prior period, unchanged from 0000889331-19-000052:mdna:58]

[0000889331-20-000037:mdna:63]
Net sales decreased $10.0 million, or 10.5%, in the first quarter of 2020 compared to the first quarter of 2019. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment, lower volume in passenger car products and commercial vehicle businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $2.3 million, partially offset by higher volume in automotive sensor business within the Electronics segment.

[0000889331-20-000037:mdna:64]
[same as prior period, unchanged from 0000889331-19-000052:mdna:61]

[0000889331-20-000037:mdna:65]
[same as prior period, unchanged from 0000889331-19-000052:mdna:62]

[0000889331-20-000037:mdna:66]
Cash and cash equivalents were $620.6 million as of March 28, 2020, an increase of $89.4 million as compared to December 28, 2019. As of March 28, 2020, $310.1 million of the Company's $620.6 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-20-000037:mdna:67]
Revolving Credit Facility/Term Loan

[0000889331-20-000037:mdna:68]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000037:mdna:69]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $2.5 million of principal payments on the term loan during the three months ended March 28, 2020.

[0000889331-20-000037:mdna:70]
Outstanding borrowings under the Credit Agreement bore interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 2.47% at March 28, 2020.

[0000889331-20-000037:mdna:71]
On March 25, 2020, the company borrowed $100.0 million from its current revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19.

[0000889331-20-000037:mdna:72]
As of March 28, 2020, the Company had no amounts outstanding in letters of credit and had available $219.8 million of borrowing capacity under the Revolving Credit Facility based on financial covenants.

[0000889331-20-000037:mdna:73]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or

[0000889331-20-000037:mdna:74]
more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.  The balance under the facility is $240.0 million as of April 3, 2020.

[0000889331-20-000037:mdna:75]
Further information regarding the Company’s credit agreement is provided in Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-20-000037:mdna:76]
[same as prior period, unchanged from 0000889331-19-000052:mdna:68]

[0000889331-20-000037:mdna:77]
[same as prior period, unchanged from 0000889331-19-000052:mdna:69]

[0000889331-20-000037:mdna:78]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000037:mdna:79]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-20-000037:mdna:80]
Debt Covenants

[0000889331-20-000037:mdna:81]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of March 28, 2020 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2020. As of March 28, 2020, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.  The ultimate magnitude of COVID-19, including the extent of its impact on our financial and operational results, which could be material, will be determined by the length of time that the pandemic continues, its effect on the demand for our products, as well as the effect of governmental regulations imposed in response to the pandemic. While we cannot at this time predict the impact of the COVID-19, it could have a material negative impact on our business, financial condition, results of operations and future cash flows which could impact the Company’s ability to comply with debt covenants in the future.

[0000889331-20-000037:mdna:82]
[same as prior period, unchanged from 0000889331-19-000052:mdna:72]

[0000889331-20-000037:mdna:83]
During the first quarter of 2020 the Company paid quarterly dividends of $11.7 million to the shareholders. On April 23, 2020, the Board of Directors of the Company declared a quarterly cash dividend of $0.48 per share, payable on June 4, 2020 to stockholders of record as of May 21, 2020. Future determinations regarding the declaration and payment of dividends will be at the discretion of our board of directors and will depend on then-existing conditions, including our results of operations, payout ratio, capital requirements, financial condition, prospects and other factors that our board of directors may deem relevant.

[0000889331-20-000037:mdna:84]
[same as prior period, unchanged from 0000889331-19-000052:mdna:74]

[0000889331-20-000037:mdna:85]
|  |  | First three Months |
| (in thousands) |  | 2020 |  | 2019 |
| Net cash provided by operating activities |  | $ | 45,279 |  |  | $ | 30,919 |  |
| Net cash used in investing activities |  | (16,536 | ) |  | (14,244 | ) |
| Net cash provided by (used in) financing activities |  | 65,804 |  |  | (31,333 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (5,111 | ) |  | 1,539 |  |
| Increase (decrease) in cash and cash equivalents |  | 89,436 |  |  | (13,119 | ) |
| Cash and cash equivalents at beginning of period |  | 531,139 |  |  | 489,733 |  |
| Cash and cash equivalents at end of period |  | $ | 620,575 |  |  | $ | 476,614 |  |

[0000889331-20-000037:mdna:86]
[same as prior period, unchanged from 0000889331-19-000052:mdna:76]

[0000889331-20-000037:mdna:87]
[same as prior period, unchanged from 0000889331-19-000052:mdna:77]

[0000889331-20-000037:mdna:88]
Net cash provided by operating activities was $45.3 million for the three months ended March 28, 2020, compared to $30.9 million during the three months ended March 30, 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and inventory levels, partially offset by lower earnings.

[0000889331-20-000037:mdna:89]
[same as prior period, unchanged from 0000889331-19-000052:mdna:79]

[0000889331-20-000037:mdna:90]
Net cash used in investing activities was $16.5 million for the three months ended March 28, 2020 compared to $14.2 million during the three months ended March 30, 2019. Capital expenditures were $16.6 million, representing an increase of $2.5 million compared to 2019.

[0000889331-20-000037:mdna:91]
[same as prior period, unchanged from 0000889331-19-000052:mdna:81]

[0000889331-20-000037:mdna:92]
Net cash provided by financing activities was $65.8 million for the three months ended March 28, 2020 compared to net cash used in financing activities of $31.3 million for the three months ended March 30, 2019. During the three months ended March 28, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. For the three months ended March 28, 2020 and March 30, 2019, the Company repurchased 175,110 and 79,916 shares of its common stock totaling $22.9 million and $13.6 million, respectively, but made payments of $17.9 million related to settled share repurchases during the three months ended March 30, 2019. The Company made payments of $2.5 million and $5.0 million on the term loan during the three months ended March 28, 2020 and March 30, 2019, respectively. Additionally, dividends paid increased $1.1 million from $10.6 million in the three months ended March 30, 2019 to $11.7 million for the three months ended March 28, 2020.

[0000889331-20-000037:mdna:93]
[same as prior period, unchanged from 0000889331-19-000052:mdna:83]

[0000889331-20-000037:mdna:94]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program") to replace its previous expired 2018 program. On April 23, 2020, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. The Company does not expect to repurchase shares in the near future due to the uncertainty of the impact and duration of COVID-19.

[0000889331-20-000037:mdna:95]
During the three months ended March 28, 2020, the Company repurchased 175,110 and 79,916 shares of its common stock totaling $22.9 million and $13.6 million, respectively.

[0000889331-20-000037:mdna:96]
[same as prior period, unchanged from 0000889331-19-000052:mdna:85]

[0000889331-20-000037:mdna:97]
As of March 28, 2020, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-20-000037:mdna:98]
[same as prior period, unchanged from 0000889331-19-000052:mdna:87]

[0000889331-20-000037:mdna:99]
[same as prior period, unchanged from 0000889331-19-000052:mdna:88]

[0000889331-20-000037:mdna:100]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 28, 2019. During the three months ended March 28, 2020, there were no significant changes in the application of critical accounting policies.
