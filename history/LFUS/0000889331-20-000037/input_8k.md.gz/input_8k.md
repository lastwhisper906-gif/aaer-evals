# LFUS 8-K — 0000889331-20-000036 filed 2020-04-29

## item codes, every 8-K on or before 2020-04-29

- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2020-04-29

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-20-000036:8k_2_02:1]
EX-99.1
2
q12020earningsreleasee.htm
EXHIBIT 99.1

[0000889331-20-000036:8k_2_02:2]
Exhibit

[0000889331-20-000036:8k_2_02:3]
Exhibit 99.1

[0000889331-20-000036:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-20-000036:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2020

[0000889331-20-000036:8k_2_02:6]
Company prioritizes global associates, customers and long-term financial health of the business in response to the COVID-19 pandemic

[0000889331-20-000036:8k_2_02:7]
CHICAGO, April 29, 2020 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the first quarter ended March 28, 2020:

[0000889331-20-000036:8k_2_02:8]
| • | Net sales of $346.1 million were down 15% versus the prior year period, and down 13% organically, primarily due to electronics inventory rebalancing and production and demand impacts related to the COVID-19 pandemic |

[0000889331-20-000036:8k_2_02:9]
| • | Growth by segment versus the prior year period: |

[0000889331-20-000036:8k_2_02:10]
| • | Electronics sales decreased 19% (down 18% organically) |

[0000889331-20-000036:8k_2_02:11]
| • | Automotive sales decreased 8% (down 6% organically) |

[0000889331-20-000036:8k_2_02:12]
| • | Industrial sales increased 2% (up 2% organically) |

[0000889331-20-000036:8k_2_02:13]
| • | GAAP diluted EPS was $1.00; adjusted diluted EPS was $1.29 |

[0000889331-20-000036:8k_2_02:14]
| • | GAAP effective tax rate was 30.6% and the adjusted effective tax rate was 26.5% |

[0000889331-20-000036:8k_2_02:15]
| • | Cash flow from operations was $45.3 million and free cash flow was $28.7 million |

[0000889331-20-000036:8k_2_02:16]
Liquidity and Capital Allocation

[0000889331-20-000036:8k_2_02:17]
| • | As of the end of the first quarter, the company had $621 million of cash and $774 million of debt |

[0000889331-20-000036:8k_2_02:18]
| • | The company repurchased approximately $23 million of its shares in the quarter |

[0000889331-20-000036:8k_2_02:19]
| • | The company borrowed $100 million from its credit facility in the quarter to preserve financial flexibility and enhance liquidity |

[0000889331-20-000036:8k_2_02:20]
| • | On April 3, the company amended and extended its $700 million senior unsecured revolving credit facility, providing additional flexibility and reducing costs |

[0000889331-20-000036:8k_2_02:21]
-more-

[0000889331-20-000036:8k_2_02:22]
| • | The company’s current share repurchase authorization expires on April 30, 2020, which will be replaced with a new one million share authorization effective through April 30, 2021. The company is suspending share repurchase activity for the near-term. |

[0000889331-20-000036:8k_2_02:23]
| • | The company will pay a cash dividend on its common stock of $0.48 per share on June 4, 2020 to shareholders of record as of May 21, 2020. If the macro environment disruption intensifies or is sustained, the Board of Directors may consider a change in the dividend. |

[0000889331-20-000036:8k_2_02:24]
| • | 2020 forecasted capital expenditures have been reduced to $60 million for the year |

[0000889331-20-000036:8k_2_02:25]
“These are challenging times and our company is doing its part to help flatten the curve in response to the COVID-19 pandemic,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Our first priority is our global associates - to protect the health and well-being of them, their families, and the communities where we operate, while working to preserve jobs. Our second priority is to continue to support and serve the critical needs of our customers. Our third priority is the long-term financial health of the business. Over the past several years, we have maintained a conservative financial position, which is even more important during these uncertain times. We have made structural changes over the years to strengthen our business, and along with decisive actions we have taken over the past several weeks, we expect to come out stronger on the other side of this challenge.”

[0000889331-20-000036:8k_2_02:26]
2020 Outlook*:

[0000889331-20-000036:8k_2_02:27]
| • | For the second quarter of 2020, the company expects net sales to be down approximately 20% sequentially, with an approximately 45% adjusted operating income fall through, reflecting the impact of COVID-19 on the supply chain and end demand environment |

[0000889331-20-000036:8k_2_02:28]
| • | The company is withdrawing its full year 2020 guidance issued on January 29 due to limited visibility of COVID-19 impacts |

[0000889331-20-000036:8k_2_02:29]
*Littelfuse provides an estimate regarding operating income on a non-GAAP basis. GAAP items excluded may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to estimate the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-20-000036:8k_2_02:30]
-more-

[0000889331-20-000036:8k_2_02:31]
Conference Call and Webcast Information

[0000889331-20-000036:8k_2_02:32]
Littelfuse will host a conference call today, Wednesday, April 29, 2020, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-20-000036:8k_2_02:33]
About Littelfuse

[0000889331-20-000036:8k_2_02:34]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Our 11,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-20-000036:8k_2_02:35]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. These statements may involve risks and uncertainties, including, but not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 28, 2019. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 28, 2019 and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov.

[0000889331-20-000036:8k_2_02:36]
These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-20-000036:8k_2_02:37]
-more-

[0000889331-20-000036:8k_2_02:38]
Non-GAAP Financial Measures

[0000889331-20-000036:8k_2_02:39]
The information included in this press release includes the non-GAAP financial measures of organic sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, consolidated total debt, consolidated EBITDA (as defined in the private placement senior notes), and ratio of consolidated total debt to consolidated EBITDA . Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-20-000036:8k_2_02:40]
The company believes that organic sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that consolidated total debt, consolidated EBITDA, and ratio of consolidated total debt to consolidated EBITDA are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-20-000036:8k_2_02:41]
CONTACT: Trisha Tuntland

[0000889331-20-000036:8k_2_02:42]
Head of Investor Relations

[0000889331-20-000036:8k_2_02:43]
(773) 628-2163

[0000889331-20-000036:8k_2_02:44]
###

[0000889331-20-000036:8k_2_02:45]
LFUS-F

[0000889331-20-000036:8k_2_02:46]
LITTELFUSE, INC.

[0000889331-20-000036:8k_2_02:47]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-20-000036:8k_2_02:48]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | March 28, 2020 |  | December 28, 2019 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 620,575 |  |  | $ | 531,139 |  |
| Short-term investments |  | 43 |  |  | 44 |  |
| Trade receivables, less allowances of $37,482 and $42,043 at March 28, 2020 and December 28, 2019, respectively |  | 207,912 |  |  | 202,309 |  |
| Inventories |  | 227,282 |  |  | 237,507 |  |
| Prepaid income taxes and income taxes receivable |  | 4,253 |  |  | 4,831 |  |
| Prepaid expenses and other current assets |  | 32,418 |  |  | 28,564 |  |
| Total current assets |  | 1,092,483 |  |  | 1,004,394 |  |
| Net property, plant, and equipment |  | 334,829 |  |  | 344,617 |  |
| Intangible assets, net of amortization |  | 308,393 |  |  | 321,247 |  |
| Goodwill |  | 812,763 |  |  | 820,589 |  |
| Investments |  | 21,248 |  |  | 24,099 |  |
| Deferred income taxes |  | 7,608 |  |  | 8,069 |  |
| Right of use lease assets, net |  | 20,611 |  |  | 21,918 |  |
| Other assets |  | 14,694 |  |  | 14,965 |  |
| Total assets |  | $ | 2,612,629 |  |  | $ | 2,559,898 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 106,796 |  |  | $ | 117,320 |  |
| Accrued liabilities |  | 73,512 |  |  | 84,120 |  |
| Accrued income taxes |  | 17,907 |  |  | 14,122 |  |
| Current portion of long-term debt |  | 10,000 |  |  | 10,000 |  |
| Total current liabilities |  | 208,215 |  |  | 225,562 |  |
| Long-term debt, less current portion |  | 764,195 |  |  | 669,158 |  |
| Deferred income taxes |  | 49,698 |  |  | 49,763 |  |
| Accrued post-retirement benefits |  | 35,904 |  |  | 38,198 |  |
| Non-current operating lease liabilities |  | 15,960 |  |  | 17,166 |  |
| Other long-term liabilities |  | 61,709 |  |  | 64,037 |  |
| Total equity |  | 1,476,948 |  |  | 1,496,014 |  |
| Total liabilities and equity |  | $ | 2,612,629 |  |  | $ | 2,559,898 |  |

[0000889331-20-000036:8k_2_02:49]
LITTELFUSE, INC.

[0000889331-20-000036:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-20-000036:8k_2_02:51]
(Unaudited)

[0000889331-20-000036:8k_2_02:52]
|  |  | Three Months Ended |
| (in thousands, except per share data) |  | March 28, 2020 |  | March 30, 2019 |
| Net sales |  | $ | 346,096 |  |  | $ | 405,500 |  |
| Cost of sales |  | 222,384 |  |  | 250,272 |  |
| Gross profit |  | 123,712 |  |  | 155,228 |  |
| Selling, general, and administrative expenses |  | 54,386 |  |  | 62,955 |  |
| Research and development expenses |  | 14,595 |  |  | 21,409 |  |
| Amortization of intangibles |  | 9,981 |  |  | 10,191 |  |
| Total operating expenses |  | 78,962 |  |  | 94,555 |  |
| Operating income |  | 44,750 |  |  | 60,673 |  |
| Interest expense |  | 5,418 |  |  | 5,686 |  |
| Foreign exchange loss |  | 2,584 |  |  | 4,243 |  |
| Other expense, net |  | 1,249 |  |  | 4,305 |  |
| Income before income taxes |  | 35,499 |  |  | 46,439 |  |
| Income taxes |  | 10,855 |  |  | 9,450 |  |
| Net income |  | $ | 24,644 |  |  | $ | 36,989 |  |
| Income per share: |  |  |  |  |
| Basic |  | $ | 1.01 |  |  | $ | 1.50 |  |
| Diluted |  | $ | 1.00 |  |  | $ | 1.48 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |
| Basic |  | 24,393 |  |  | 24,717 |  |
| Diluted |  | 24,578 |  |  | 25,009 |  |
| Comprehensive income |  | $ | 9,665 |  |  | $ | 45,062 |  |

[0000889331-20-000036:8k_2_02:53]
LITTELFUSE, INC.

[0000889331-20-000036:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-20-000036:8k_2_02:55]
(Unaudited)

[0000889331-20-000036:8k_2_02:56]
|  |  | Three Months Ended |
| (in thousands) |  | March 28, 2020 |  | March 30, 2019 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 24,644 |  |  | $ | 36,989 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 35,626 |  |  | 35,376 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (9,457 | ) |  | (5,800 | ) |
| Inventories |  | 6,667 |  |  | (3,250 | ) |
| Accounts payable |  | (3,964 | ) |  | (8,499 | ) |
| Accrued liabilities and income taxes |  | (7,012 | ) |  | (27,170 | ) |
| Prepaid expenses and other assets |  | (1,225 | ) |  | 3,273 |  |
| Net cash provided by operating activities |  | 45,279 |  |  | 30,919 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | — |  |  | (775 | ) |
| Purchases of property, plant, and equipment |  | (16,586 | ) |  | (14,076 | ) |
| Proceeds from sale of property, plant, and equipment |  | 50 |  |  | 607 |  |
| Net cash used in investing activities |  | (16,536 | ) |  | (14,244 | ) |
| FINANCING ACTIVITIES |  |  |  |  |
| Net proceeds (payments) from credit facility |  | 97,500 |  |  | (5,000 | ) |
| Purchases of common stock |  | (22,927 | ) |  | (17,906 | ) |
| Cash dividends paid |  | (11,725 | ) |  | (10,625 | ) |
| All other cash provided by financing activities |  | 2,956 |  |  | 2,198 |  |
| Net cash provided by (used in) financing activities |  | 65,804 |  |  | (31,333 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (5,111 | ) |  | 1,539 |  |
| Increase (decrease) in cash and cash equivalents |  | 89,436 |  |  | (13,119 | ) |
| Cash and cash equivalents at beginning of period |  | 531,139 |  |  | 489,733 |  |
| Cash and cash equivalents at end of period |  | $ | 620,575 |  |  | $ | 476,614 |  |

[0000889331-20-000036:8k_2_02:57]
LITTELFUSE, INC.

[0000889331-20-000036:8k_2_02:58]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-20-000036:8k_2_02:59]
(Unaudited)

[0000889331-20-000036:8k_2_02:60]
|  |  | First Quarter |
| (in thousands) |  | 2020 |  | 2019 |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |
| Electronics |  | $ | 214,189 |  |  | $ | 265,394 |  |  | (19.3 | )% |
| Automotive |  | 104,770 |  |  | 113,483 |  |  | (7.7 | )% |
| Industrial |  | 27,137 |  |  | 26,623 |  |  | 1.9 | % |
| Total net sales |  | $ | 346,096 |  |  | $ | 405,500 |  |  | (14.6 | )% |
| Operating income (loss) |  |  |  |  |  |  |
| Electronics |  | $ | 32,272 |  |  | $ | 49,037 |  |  | (34.2 | )% |
| Automotive |  | 14,116 |  |  | 13,200 |  |  | 6.9 | % |
| Industrial |  | 3,534 |  |  | 3,505 |  |  | 0.8 | % |
| Other(a) |  | (5,172 | ) |  | (5,069 | ) |  | N.M. |  |
| Total operating income |  | $ | 44,750 |  |  | $ | 60,673 |  |  | (26.2 | )% |
| Operating Margin |  | 12.9 | % |  | 15.0 | % |  |  |
| Interest expense |  | 5,418 |  |  | 5,686 |  |  |  |
| Foreign exchange loss |  | 2,584 |  |  | 4,243 |  |  |  |
| Other expense, net |  | 1,249 |  |  | 4,305 |  |  |  |
| Income before income taxes |  | $ | 35,499 |  |  | $ | 46,439 |  |  | (23.6 | )% |

[0000889331-20-000036:8k_2_02:61]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-20-000036:8k_2_02:62]
N.M. - Not meaningful

[0000889331-20-000036:8k_2_02:63]
|  |  | First Quarter |
| (in thousands) |  | 2020 |  | 2019 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |
| Electronics |  | 15.1 | % |  | 18.5 | % |  | (3.4 | )% |
| Automotive |  | 13.5 | % |  | 11.6 | % |  | 1.9 | % |
| Industrial |  | 13.0 | % |  | 13.2 | % |  | (0.2 | )% |

[0000889331-20-000036:8k_2_02:64]
LITTELFUSE, INC.

[0000889331-20-000036:8k_2_02:65]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-20-000036:8k_2_02:66]
(In millions of USD except per share amounts unaudited)

[0000889331-20-000036:8k_2_02:67]
| Non-GAAP EPS reconciliation |  |  |  |  |
|  |  | Q1-20 |  | Q1-19 |
| GAAP diluted EPS |  | $ | 1.00 |  |  | $ | 1.48 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.29 |  | 0.48 |
| Adjusted diluted EPS |  | $ | 1.29 |  |  | $ | 1.96 |  |

[0000889331-20-000036:8k_2_02:68]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |
|  |  | Q1-20 |  | Q1-19 |
| Acquisition-related and integration costs (a) |  | $ | 1.2 |  |  | $ | 2.4 |  |
| Restructuring, impairment and other charges (b) |  | 4.0 |  |  | 2.7 |  |
| Non-GAAP adjustments to operating income |  | 5.2 |  |  | 5.1 |  |
| Other expense, net (c) |  | — |  |  | 5.2 |  |
| Non-operating foreign exchange loss |  | 2.6 |  |  | 4.2 |  |
| Non-GAAP adjustments to income before income taxes |  | 7.8 |  |  | 14.5 |  |
| Income taxes (d) |  | 0.6 |  |  | 2.5 |  |
| Non-GAAP adjustments to net income |  | $ | 7.2 |  |  | $ | 12.0 |  |
| Total EPS impact |  | $ | 0.29 |  |  | $ | 0.48 |  |

[0000889331-20-000036:8k_2_02:69]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |
|  |  | Q1-20 |  | Q1-19 |
| Net sales |  | $ | 346.1 |  |  | $ | 405.5 |  |
| GAAP operating income |  | $ | 44.8 |  |  | $ | 60.7 |  |
| Add back non-GAAP adjustments |  | 5.2 |  |  | 5.1 |  |
| Adjusted operating income |  | $ | 50.0 |  |  | $ | 65.8 |  |
| Adjusted operating margin |  | 14.4 | % |  | 16.2 | % |
| Add back amortization |  | 10.0 |  |  | 10.2 |  |
| Add back depreciation |  | 13.8 |  |  | 13.1 |  |
| Adjusted EBITDA |  | $ | 73.8 |  |  | $ | 89.1 |  |
| Adjusted EBITDA margin |  | 21.3 | % |  | 22.0 | % |

[0000889331-20-000036:8k_2_02:70]
| Net sales reconciliation |  | Q1-20 vs. Q1-19 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | (19 | )% |  | (8 | )% |  | 2 | % |  | (15 | )% |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | (1 | )% |  | (2 | )% |  | — | % |  | (2 | )% |
| Organic net sales growth |  | (18 | )% |  | (6 | )% |  | 2 | % |  | (13 | )% |

[0000889331-20-000036:8k_2_02:71]
| Income tax reconciliation |  |  |  |  |
|  |  | Q1-20 |  | Q1-19 |
| Income taxes |  | $ | 10.9 |  |  | $ | 9.5 |  |
| Effective rate |  | 30.6 | % |  | 20.3 | % |
| Non-GAAP adjustments - income taxes |  | 0.6 |  |  | 2.5 |  |
| Adjusted income taxes |  | $ | 11.5 |  |  | $ | 12.0 |  |
| Adjusted effective rate |  | 26.5 | % |  | 19.7 | % |
| Free cash flow reconciliation |  |  |  |  |
|  |  | Q1-20 |  | Q1-19 |
| Net cash provided by operating activities |  | $ | 45.3 |  |  | $ | 30.9 |  |
| Less: Purchases of property, plant and equipment |  | (16.6 | ) |  | (14.1 | ) |
| Free cash flow |  | $ | 28.7 |  |  | $ | 16.8 |  |

[0000889331-20-000036:8k_2_02:72]
| Consolidated Total Debt (1) |  | As of March 28, 2020 |
| Current-portion of long-term debt |  | $ | 10.0 |  |
| Long-term debt, less current portion |  | 764.2 |  |
| Consolidated Total Debt (1) |  | $ | 774.2 |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (2) |  | Twelve Months Ended March 28, 2020 |
| Net Income |  | $ | 126.7 |  |
| Interest expense |  | 22.0 |  |
| Income taxes |  | 28.2 |  |
| Depreciation |  | 53.2 |  |
| Amortization |  | 39.8 |  |
| Non-cash reductions: |  |  |
| Stock-based compensation expense |  | 18.0 |  |
| Unrealized loss on investments |  | 4.6 |  |
| Impairment charges |  | 2.6 |  |
| Other |  | 3.9 |  |
| Consolidated EBITDA (as defined in the Private Placement Senior Notes) (2) |  | $ | 299.0 |  |
| Ratio of Consolidated Total Debt to Consolidated EBITDA (as defined in Private Placement Senior Notes)* |  | 2.6x |  |

[0000889331-20-000036:8k_2_02:73]
* Our Private Placement Senior Notes, with maturities ranging from 2022 to 2030, contain a financial ratio covenant providing that if, as of the last day of each fiscal quarter, the ratio of Consolidated Total Debt at such time to Consolidated EBITDA for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Private Placement Senior Notes) is triggered

[0000889331-20-000036:8k_2_02:74]
(1) Represents Consolidated Total Debt

[0000889331-20-000036:8k_2_02:75]
(2) Represents Consolidated EBITDA as defined in our Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters

[0000889331-20-000036:8k_2_02:76]
Note: Total will not always foot due to rounding.

[0000889331-20-000036:8k_2_02:77]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-20-000036:8k_2_02:78]
(b) $3.3 million and $0.7 million reflected in SG&A and cost of sales, respectively for the three months ended March 28, 2020 and $2.1 million and $0.6 million reflected in SG&A and cost of sales, respectively for the three months ended March 30, 2019.

[0000889331-20-000036:8k_2_02:79]
(c) amounts as of March 30, 2019 include $2.8 million impairment charges to certain other investments, $2.6 million loss on the disposal of a business, and $0.3 million gain primarily related to the final payments for the acquisition of Monolith.

[0000889331-20-000036:8k_2_02:80]
(d) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-20-000036:8k_2_02:81]
###
