# LFUS notes — 0000889331-20-000045


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-20-000045:notes:1]
[same as prior period, unchanged from 0000889331-20-000037:notes:1]

[0000889331-20-000045:notes:2]
[same as prior period, unchanged from 0000889331-20-000037:notes:2]

[0000889331-20-000045:notes:3]
[same as prior period, unchanged from 0000889331-20-000037:notes:3]

[0000889331-20-000045:notes:4]
[same as prior period, unchanged from 0000889331-20-000037:notes:4]

[0000889331-20-000045:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net (loss) income and comprehensive (loss) income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 28, 2019 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-20-000045:notes:6]
[same as prior period, unchanged from 0000889331-20-000037:notes:6]

[0000889331-20-000045:notes:7]
[same as prior period, unchanged from 0000889331-20-000037:notes:7]

[0000889331-20-000045:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 27, 2020 and June 29, 2019:

[0000889331-20-000045:notes:9]
|  |  | Three Months Ended June 27, 2020 |  |  |  |  |  |  |  | Six Months Ended June 27, 2020 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

[0000889331-20-000045:notes:10]
|  |  | Three Months Ended June 29, 2019 |  |  |  |  |  |  |  | Six Months Ended June 29, 2019 |  |  |  |  |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

[0000889331-20-000045:notes:11]
See Note 14, Segment Information for net sales by segment and countries.

[0000889331-20-000045:notes:12]
[same as prior period, unchanged from 0000889331-20-000037:notes:12]

[0000889331-20-000045:notes:13]
[same as prior period, unchanged from 0000889331-20-000037:notes:13]

[0000889331-20-000045:notes:14]
[same as prior period, unchanged from 0000889331-20-000037:notes:14]

[0000889331-20-000045:notes:15]
[same as prior period, unchanged from 0000889331-20-000037:notes:15]

[0000889331-20-000045:notes:16]
[same as prior period, unchanged from 0000889331-20-000037:notes:16]

[0000889331-20-000045:notes:17]
[same as prior period, unchanged from 0000889331-20-000037:notes:17]

[0000889331-20-000045:notes:18]
[same as prior period, unchanged from 0000889331-20-000037:notes:18]

[0000889331-20-000045:notes:19]
[same as prior period, unchanged from 0000889331-20-000037:notes:19]

[0000889331-20-000045:notes:20]
[same as prior period, unchanged from 0000889331-20-000037:notes:20]

[0000889331-20-000045:notes:21]
[same as prior period, unchanged from 0000889331-20-000037:notes:21]

[0000889331-20-000045:notes:22]
Recently Adopted Accounting Standards

[0000889331-20-000045:notes:23]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments." The standard modifies the measurement approach for credit losses on financial instruments, including trade receivables, from an incurred loss method to a current expected credit loss method ("CECL").  The standard requires the measurement of expected credit losses to be based on relevant information, including historical experiences, current conditions and a forecast that is supportable.  The Company adopted the new standard on December 29, 2019.  The adoption of the standard did not have a material effect on our Condensed Consolidated Financial Statements.

[0000889331-20-000045:notes:24]
In August 2018, the FASB issued ASU No. 2018-13 "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirement for Fair Value Measurement."  ASU 2018-13 modifies the disclosure requirements in Topic 820: "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The new standard removes certain disclosures, modifies other disclosures and adds additional disclosures related to fair value measurement. The Company adopted the new standard on December 29, 2019. The adoption of ASU 2018- 13 did not have a material impact on our Condensed Consolidated Financial Statements.

[0000889331-20-000045:notes:25]
In August 2018, the FASB issued ASU No. 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic: 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force)." ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The Company adopted the new standard on December 29, 2019.  The adoption of ASU 2018-15 did not have a material impact on our Condensed Consolidated Financial Statements.

[0000889331-20-000045:notes:26]
In March 2020, the FASB issued ASU 2020-04 Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting.” This ASU provides optional expedient and exceptions for applying generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by reference rate reform if certain criteria are met. The objective of this is to provide optional guidance for a limited period of time to ease the potential burden in accounting for (or recognizing the effects of) reference rate reform on financial reporting due to the cessation of the London Interbank Offered Rate (LIBOR). The amendments in this update are effective for all entities as of March 12, 2020 through December 31, 2022. The Company does not expect a material effect from the adoption of this guidance on its Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-20-000045:notes:27]
[same as prior period, unchanged from 0000889331-20-000037:notes:27]

[0000889331-20-000045:notes:28]
The components of inventories at June 27, 2020 and December 28, 2019 are as follows:

[0000889331-20-000045:notes:29]
| (in thousands) |  | June 27, 2020 |  | December 28, 2019 |
| Raw materials |  | $ | 82,133 |  |  | $ | 76,732 |  |
| Work in process |  | 92,681 |  |  | 84,561 |  |
| Finished goods |  | 106,904 |  |  | 110,388 |  |
| Inventory Reserves |  | (33,698) |  |  | (34,174) |  |
| Total |  | $ | 248,020 |  |  | $ | 237,507 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-20-000045:notes:30]
[same as prior period, unchanged from 0000889331-20-000037:notes:30]

[0000889331-20-000045:notes:31]
The components of net property, plant, and equipment at June 27, 2020 and December 28, 2019 are as follows:

[0000889331-20-000045:notes:32]
| (in thousands) |  | June 27, 2020 |  | December 28, 2019 |
| Land |  | $ | 23,095 |  |  | $ | 24,758 |  |
| Building |  | 118,409 |  |  | 108,501 |  |
| Equipment |  | 635,661 |  |  | 631,273 |  |
| Accumulated depreciation and amortization |  | (442,488) |  |  | (419,915) |  |
| Total |  | $ | 334,677 |  |  | $ | 344,617 |  |

[0000889331-20-000045:notes:33]
The Company recorded depreciation expense of $13.9 million and $12.6 million for the three months ended June 27, 2020 and June 29, 2019, respectively, and $27.7 million and $25.7 million for six months ended June 27, 2020 and June 29, 2019, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-20-000045:notes:34]
[same as prior period, unchanged from 0000889331-20-000037:notes:34]

[0000889331-20-000045:notes:35]
The amounts for goodwill and changes in the carrying value by segment for the six months ended June 27, 2020 are as follows:

[0000889331-20-000045:notes:36]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 28, 2019 |  | $ | 650,796 |  |  | $ | 131,321 |  |  | $ | 38,472 |  |  | $ | 820,589 |  |
| Impairments |  | — |  |  | (33,841) |  |  | — |  |  | (33,841) |  |
| Currency translation |  | 860 |  |  | 128 |  |  | (135) |  |  | 853 |  |
| As of June 27, 2020 |  | $ | 651,656 |  |  | $ | 97,608 |  |  | $ | 38,337 |  |  | $ | 787,601 |  |

[0000889331-20-000045:notes:37]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. For the three months ended June 27, 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition, during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling their existing program. The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of June 27, 2020, the automotive sensors reporting unit had $9.1 million of remaining goodwill.

[0000889331-20-000045:notes:38]
The components of other intangible assets as of June 27, 2020 and December 28, 2019 are as follows:

[0000889331-20-000045:notes:39]
|  |  |  | As of June 27, 2020 |  |  |  |  |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 9,584 |  |  | $ | 1,800 |  |  | $ | 7,784 |  |
| Patents, licenses and software |  |  | 131,055 |  |  | $ | 83,989 |  |  | $ | 47,066 |  |
| Distribution network |  |  | 43,272 |  |  | 37,302 |  |  | 5,970 |  |
| Customer relationships, trademarks, and tradenames |  |  | 360,769 |  |  | 119,928 |  |  | 240,841 |  |
| Total |  |  | $ | 544,680 |  |  | $ | 243,019 |  |  | $ | 301,661 |  |

[0000889331-20-000045:notes:40]
|  | As of December 28, 2019 |  |  |  |  |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 9,649 |  |  | $ | 1,730 |  |  | $ | 7,919 |  |
| Patents, licenses and software | 131,164 |  |  | 78,828 |  |  | 52,336 |  |
| Distribution network | 43,239 |  |  | 36,163 |  |  | 7,076 |  |
| Customer relationships, trademarks, and tradenames | 360,534 |  |  | 106,618 |  |  | 253,916 |  |
| Total | $ | 544,586 |  |  | $ | 223,339 |  |  | $ | 321,247 |  |

[0000889331-20-000045:notes:41]
During the three months ended June 27, 2020 and June 29, 2019, the Company recorded amortization expense of $9.8 million and $10.0 million, respectively. During six months ended June 27, 2020, the Company recorded amortization expense of $19.8 million and $20.2 million, respectively.

[0000889331-20-000045:notes:42]
During the six months ended June 27, 2020, the Company recognized a $0.3 million non-cash impairment charge on a certain patent triggered by the Company’s announcement to consolidate a manufacturing facility within the Industrial segment.

[0000889331-20-000045:notes:43]
Estimated annual amortization expense related to intangible assets with definite lives as of June 27, 2020 is as follows:

[0000889331-20-000045:notes:44]
| (in thousands) | Amount |
| 2020 | $ | 39,200 |  |
| 2021 | 37,811 |  |
| 2022 | 36,846 |  |
| 2023 | 32,135 |  |
| 2024 | 29,356 |  |
| 2025 and thereafter | 145,511 |  |
| Total | $ | 320,859 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-20-000045:notes:45]
[same as prior period, unchanged from 0000889331-20-000037:notes:55]

[0000889331-20-000045:notes:46]
The components of accrued liabilities as of June 27, 2020 and December 28, 2019 are as follows:

[0000889331-20-000045:notes:47]
| (in thousands) |  | June 27, 2020 |  | December 28, 2019 |
| Employee-related liabilities |  | $ | 40,785 |  |  | $ | 40,774 |  |
| Operating lease liability |  | 6,846 |  |  | 7,259 |  |
| Interest |  | 4,781 |  |  | 5,058 |  |
| Professional services |  | 3,130 |  |  | 3,986 |  |
| Restructuring liability |  | 4,463 |  |  | 2,679 |  |
| Other non-income taxes |  | 2,075 |  |  | 1,940 |  |
| Other |  | 23,276 |  |  | 22,424 |  |
| Total |  | $ | 85,356 |  |  | $ | 84,120 |  |

[0000889331-20-000045:notes:48]
[same as prior period, unchanged from 0000889331-20-000037:notes:58]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-20-000045:notes:49]
Restructuring, Impairment and Other Charges
The Company recorded restructuring, impairment and other charges for the three and six months ended June 27, 2020 and June 29, 2019 as follows:

[0000889331-20-000045:notes:50]
|  | Three months ended June 27, 2020 |  |  |  |  |  |  |  | Six months ended June 27, 2020 |  |  |  |  |  |  |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 856 |  |  | $ | 209 |  |  | $ | 750 |  |  | $ | 1,815 |  |  | $ | 1,737 |  |  | $ | 608 |  |  | $ | 1,071 |  |  | $ | 3,416 |  |
| Other restructuring charges | (1) |  |  | (12) |  |  | 22 |  |  | 9 |  |  | — |  |  | 108 |  |  | 25 |  |  | 133 |  |
| Total restructuring charges | 855 |  |  | 197 |  |  | 772 |  |  | 1,824 |  |  | 1,737 |  |  | 716 |  |  | 1,096 |  |  | 3,549 |  |
| Impairment | — |  |  | 33,841 |  |  | — |  |  | 33,841 |  |  | — |  |  | 33,841 |  |  | 2,237 |  |  | 36,078 |  |
| Total | $ | 855 |  |  | $ | 34,038 |  |  | $ | 772 |  |  | $ | 35,665 |  |  | $ | 1,737 |  |  | $ | 34,557 |  |  | $ | 3,333 |  |  | $ | 39,627 |  |

[0000889331-20-000045:notes:51]
|  | Three months ended June 29, 2019 |  |  |  |  |  |  |  | Six months ended June 29, 2019 |  |  |  |  |  |  |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 1,698 |  |  | $ | 3,241 |  |  | $ | 674 |  |  | $ | 5,613 |  |  | $ | 3,498 |  |  | $ | 3,846 |  |  | $ | 721 |  |  | $ | 8,065 |  |
| Other restructuring charges | — |  |  | 70 |  |  | — |  |  | 70 |  |  | 13 |  |  | 90 |  |  | 250 |  |  | 353 |  |
| Total restructuring charges | 1,698 |  |  | 3,311 |  |  | 674 |  |  | 5,683 |  |  | 3,511 |  |  | 3,936 |  |  | 971 |  |  | 8,418 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 1,698 |  |  | $ | 3,311 |  |  | $ | 674 |  |  | $ | 5,683 |  |  | $ | 3,511 |  |  | $ | 3,936 |  |  | $ | 971 |  |  | $ | 8,418 |  |

[0000889331-20-000045:notes:52]
[same as prior period, unchanged from 0000889331-20-000037:notes:63]

[0000889331-20-000045:notes:53]
For the three and six months ended June 27, 2020, the Company recorded total restructuring charges of $1.8 million and $3.5 million, for employee termination costs and other restructuring charges. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the previously announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $33.8 million and $36.1 million of impairment charges for the three and six months ended June 27, 2020, respectively, which included a $33.8 million goodwill impairment charge associated with the automotive sensors reporting unit within the Automotive segment in the second quarter of 2020 and $2.2 million related to the land and building associated with the Company’s previously announced consolidation of a manufacturing facility within the Industrial segment in the first quarter of 2020. The impairment charges of the land and

[0000889331-20-000045:notes:54]
building were included in selling, general and administrative expenses. See Note 4, Goodwill and Other Intangible Assets for further discussion regarding the goodwill impairment charge.

[0000889331-20-000045:notes:55]
[same as prior period, unchanged from 0000889331-20-000037:notes:66]

[0000889331-20-000045:notes:56]
For the three and six months ended June 29, 2019, the Company recorded total restructuring charges of 5.7 million, and 8.4 million, respectively, for employee termination costs and other restructuring charges. These charges primarily related to reorganization of operations and selling, general and administrative functions as well as integration of IXYS within the Electronics segment and the reorganization of operations in the commercial vehicle products and automotive sensors businesses within the Automotive segment.

[0000889331-20-000045:notes:57]
The restructuring reserves as of June 27, 2020 and December 28, 2019 are $4.5 million and $2.7 million, respectively. The restructuring reserves are included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by March 2021.


## us-gaap:DebtDisclosureTextBlock

[0000889331-20-000045:notes:58]
Debt

[0000889331-20-000045:notes:59]
The carrying amounts of debt at June 27, 2020 and December 28, 2019 are as follows:

[0000889331-20-000045:notes:60]
| (in thousands) |  | June 27,2020 |  | December 28,2019 |
| Revolving Credit Facility |  | $ | 240,000 |  |  | $ | — |  |
| Term Loan |  | — |  |  | 145,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 131,378 |  |  | 129,808 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,675 |  |  | 105,400 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,467) |  |  | (3,669) |  |
| Total debt |  | 776,205 |  |  | 679,158 |  |
| Less: Current maturities |  | — |  |  | (10,000) |  |
| Total long-term debt |  | $ | 776,205 |  |  | $ | 669,158 |  |

[0000889331-20-000045:notes:61]
Revolving Credit Facility / Term Loan

[0000889331-20-000045:notes:62]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000045:notes:63]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $2.5 million and $5.0 million of principal payments on the term loan during the three and six months ended June 27, 2020, respectively.

[0000889331-20-000045:notes:64]
On March 25, 2020, the company borrowed $100.0 million from the revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to coronavirus disease 2019 ("COVID-19").

[0000889331-20-000045:notes:65]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-20-000045:notes:66]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.70% at June 27, 2020.

[0000889331-20-000045:notes:67]
As of June 27, 2020, the Company had no amount outstanding in letters of credit and had available $148.6 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At June 27, 2020, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-20-000045:notes:68]
Senior Notes

[0000889331-20-000045:notes:69]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-20-000045:notes:70]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000045:notes:71]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-20-000045:notes:72]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-20-000045:notes:73]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 27, 2020, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-20-000045:notes:74]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
Interest paid on all Company debt was $3.4 million and $3.5 million for the three months ended June 27, 2020 and June 29, 2019, respectively, and $10.8 million and $11.5 million for the six months ended June 27, 2020 and June 29, 2019, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-20-000045:notes:75]
[same as prior period, unchanged from 0000889331-20-000037:notes:87]

[0000889331-20-000045:notes:76]
[same as prior period, unchanged from 0000889331-20-000037:notes:88]

[0000889331-20-000045:notes:77]
[same as prior period, unchanged from 0000889331-20-000037:notes:89]

[0000889331-20-000045:notes:78]
[same as prior period, unchanged from 0000889331-20-000037:notes:90]

[0000889331-20-000045:notes:79]
[same as prior period, unchanged from 0000889331-20-000037:notes:91]

[0000889331-20-000045:notes:80]
[same as prior period, unchanged from 0000889331-20-000037:notes:92]

[0000889331-20-000045:notes:81]
[same as prior period, unchanged from 0000889331-20-000037:notes:93]

[0000889331-20-000045:notes:82]
[same as prior period, unchanged from 0000889331-20-000037:notes:94]

[0000889331-20-000045:notes:83]
[same as prior period, unchanged from 0000889331-20-000037:notes:95]

[0000889331-20-000045:notes:84]
[same as prior period, unchanged from 0000889331-20-000037:notes:96]

[0000889331-20-000045:notes:85]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the six months ended June 29, 2019, the Company recorded impairment charges of $2.8 million in Other expense (income), net in the Condensed Consolidated Statements of Net (Loss) Income to adjust these certain investments to their estimated fair value. As of June 27, 2020 and December 28, 2019, the balances of these investments were $0.4 million. The fair value of these investments are measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-20-000045:notes:86]
[same as prior period, unchanged from 0000889331-20-000037:notes:98]

[0000889331-20-000045:notes:87]
[same as prior period, unchanged from 0000889331-20-000037:notes:99]

[0000889331-20-000045:notes:88]
There were no changes during the quarter ended June 27, 2020 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. On October 30, 2019, the Company entered a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Chinese renminbi and U.S. dollar.  The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly basis. The notional value of the forward contracts at December 28, 2019 was $16.0 million and expired on May 5, 2020.  On March 23, 2020, the Company unwound the foreign currency exchange forward contract entered on October 30, 2019 and recognized a gain of $0.2 million within Other expenses, net during the six months ended June 27, 2020. The fair value of the foreign currency forward contract was valued using market exchange rates and classified as a Level 2 input under the fair value hierarchy.

[0000889331-20-000045:notes:89]
As of June 27, 2020 and December 28, 2019, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-20-000045:notes:90]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of June 27, 2020:

[0000889331-20-000045:notes:91]
|  |  | Fair Value Measurements Using |  |  |  |  |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 148,409 |  |  | $ | — |  |  | $ | — |  |  | $ | 148,409 |  |
| Investments in equity securities |  | 12,899 |  |  | — |  |  | — |  |  | 12,899 |  |
| Mutual funds |  | 10,650 |  |  | — |  |  | — |  |  | 10,650 |  |

[0000889331-20-000045:notes:92]
[same as prior period, unchanged from 0000889331-20-000037:notes:105]

[0000889331-20-000045:notes:93]
|  |  | Fair Value Measurements Using |  |  |  |  |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash Equivalents |  | $ | 118,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,999 |  |
| Investments in equity securities |  | 12,969 |  |  | — |  |  | — |  |  | 12,969 |  |
| Mutual funds |  | 10,464 |  |  | — |  |  | — |  |  | 10,464 |  |

[0000889331-20-000045:notes:94]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at June 27, 2020 and December 28, 2019, as the rates on these borrowings are variable in nature.

[0000889331-20-000045:notes:95]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of June 27, 2020 and December 28, 2019 were as follows:

[0000889331-20-000045:notes:96]
|  |  | June 27, 2020 |  |  |  | December 28, 2019 |  |  |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 131,378 |  |  | $ | 128,003 |  |  | $ | 129,808 |  |  | $ | 131,710 |  |
| Euro Senior Notes, Series B due 2028 |  | 106,675 |  |  | 104,332 |  |  | 105,400 |  |  | 110,336 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,150 |  |  | 25,000 |  |  | 25,054 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 103,482 |  |  | 100,000 |  |  | 102,548 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 51,355 |  |  | 50,000 |  |  | 50,775 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 128,954 |  |  | 125,000 |  |  | 127,701 |  |

[0000889331-20-000045:notes:97]
The Company recognized impairment charges of $1.9 million for the land and building and $0.3 million for a certain patent as a result of the Company’s announcement to consolidate a manufacturing facility within the Industrial segment during the first quarter of 2020. See Note 6, Restructuring, Impairment and Other Charges, for further discussion. The fair value of the land and building was valued using a real estate appraisal and classified as a Level 3 input under the fair value hierarchy.

[0000889331-20-000045:notes:98]
The fair value as of the measurement date, net book value as of June 27, 2020 and related the goodwill impairment charge for assets measured at fair value on nonrecurring basis subsequent to initial recognition during three months ended June 27, 2020 were as follows:

[0000889331-20-000045:notes:99]
|  |  | Three Months Ended June 27, 2020 |  |  |  | June 27, 2020 |
| (in thousands) |  | Impairment Charge |  | Estimated Fair Value Measurement (Level 3) |  | Carrying Value |
| Goodwill |  | $ | 33,841 |  |  | $ | 8,953 |  |  | $ | 9,142 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-20-000045:notes:100]
[same as prior period, unchanged from 0000889331-20-000037:notes:111]

[0000889331-20-000045:notes:101]
[same as prior period, unchanged from 0000889331-20-000037:notes:112]

[0000889331-20-000045:notes:102]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net (Loss) Income. The components of net periodic benefit cost for the three and six months ended June 27, 2020 and June 29, 2019 were as follows:

[0000889331-20-000045:notes:103]
|  |  | For the Three Months Ended |  |  |  | For the Six Months Ended |  |  |
| (in thousands) |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 592 |  |  | $ | 514 |  |  | $ | 1,210 |  |  | $ | 1,014 |  |
| Interest cost |  | 486 |  |  | 813 |  |  | 1,144 |  |  | 1,597 |  |
| Expected return on plan assets |  | (402) |  |  | (821) |  |  | (1,129) |  |  | (1,611) |  |
| Amortization of prior service and net actuarial loss |  | 264 |  |  | 62 |  |  | 409 |  |  | 124 |  |
| Net periodic benefit cost |  | $ | 940 |  |  | $ | 568 |  |  | $ | 1,634 |  |  | $ | 1,124 |  |

[0000889331-20-000045:notes:104]
[same as prior period, unchanged from 0000889331-20-000037:notes:115]

[0000889331-20-000045:notes:105]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded $0.5 million and $0.2 million expense for the three months ended June 27, 2020 and June 29, 2019, respectively, and $1.0 million and $0.4 million expense for the six months ended June 27, 2020 and June 29, 2019, respectively, in Cost of Sales and Other expense (income), net within the Condensed Consolidated Statements of Net (Loss) Income. For three and six months ended June 27, 2020, the pre-tax amounts recognized in other comprehensive (loss) income as components of net periodic benefit costs for these plans were $0.2 million and $0.4 million.

[0000889331-20-000045:notes:106]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries, who have been receiving pension payments. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $36 million, representing approximately 30% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge in the second half of 2021 currently estimated between $18 million and $22 million, reflecting the accelerated recognition of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses. Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million (£10.9 million) to both the net pension liability and unamortized actuarial loss within other comprehensive (loss) income during the second quarter. Additionally, the Company made a cash contribution of $10.4 million (£8.4 million) under this agreement during the second quarter.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-20-000045:notes:107]
Other Comprehensive (Loss) Income
Changes in other comprehensive (loss) income by component were as follows:

[0000889331-20-000045:notes:108]
| (in thousands) |  | Three Months EndedJune 27, 2020 |  |  |  |  |  | Three Months EndedJune 29, 2019 |  |  |  |  |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | (13,098) |  |  | $ | (2,259) |  |  | $ | (10,839) |  |  | $ | 201 |  |  | $ | 40 |  |  | $ | 161 |  |
| Foreign currency translation adjustments |  | 8,422 |  |  | — |  |  | 8,422 |  |  | (5,892) |  |  | — |  |  | (5,892) |  |
| Total change in other comprehensive income (loss) |  | $ | (4,676) |  |  | $ | (2,259) |  |  | $ | (2,417) |  |  | $ | (5,691) |  |  | $ | 40 |  |  | $ | (5,731) |  |

[0000889331-20-000045:notes:109]
Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million to unamortized actuarial loss within other comprehensive (loss) income. See Note 9, Benefits Plans for further discussion.

[0000889331-20-000045:notes:110]
| (in thousands) |  | Six Months Ended June 27, 2020 |  |  |  |  |  | Six Months Ended June 29, 2019 |  |  |  |  |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | (12,543) |  |  | $ | (2,265) |  |  | $ | (10,278) |  |  | $ | 123 |  |  | $ | 11 |  |  | $ | 112 |  |
| Foreign currency translation adjustments |  | (7,118) |  |  | — |  |  | (7,118) |  |  | 2,230 |  |  | — |  |  | 2,230 |  |
| Total change in other comprehensive income (loss) |  | $ | (19,661) |  |  | $ | (2,265) |  |  | $ | (17,396) |  |  | $ | 2,353 |  |  | $ | 11 |  |  | $ | 2,342 |  |

[0000889331-20-000045:notes:111]
The following tables set forth the changes in accumulated other comprehensive (loss) income by component for the six months ended June 27, 2020 and June 29, 2019:

[0000889331-20-000045:notes:112]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  |  |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensive (loss) income |
| Balance at December 28, 2019 |  | $ | (18,046) |  |  |  |  | $ | (88,777) |  |  | $ | (106,823) |  |
| Activity in the period |  | (10,278) |  |  |  |  | (7,118) |  |  | (17,396) |  |
| Balance at June 27, 2020 |  | $ | (28,324) |  |  |  |  | $ | (95,895) |  |  | $ | (124,219) |  |

[0000889331-20-000045:notes:113]
| (in thousands) |  | Pension andpostretirementliability andreclassificationadjustments |  |  |  | Foreigncurrencytranslationadjustment |  | Accumulatedothercomprehensive (loss) income |
| Balance at December 29, 2018 |  | $ | (9,959) |  |  |  |  | $ | (87,965) |  |  | $ | (97,924) |  |
| Activity in the period |  | 112 |  |  |  |  | 2,230 |  |  | 2,342 |  |
| Balance at June 29, 2019 |  | $ | (9,847) |  |  |  |  | $ | (85,735) |  |  | $ | (95,582) |  |

[0000889331-20-000045:notes:114]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three and six months ended June 27, 2020 and June 29, 2019 were as follows:

[0000889331-20-000045:notes:115]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |  |  |  |  |
| (in thousands) |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |  |  |  |  |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 429 |  |  | $ | 62 |  |  | $ | 774 |  |  | $ | 124 |  |  |  |  |  |

[0000889331-20-000045:notes:116]
The Company recognizes the amortization of prior service costs in Other (expense) income, net within the Condensed Consolidated Statements of Net (Loss) Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-20-000045:notes:117]
Income Taxes The effective tax rate for the three and six months ended June 27, 2020 was 15.1% and 37.2% respectively, compared to the effective tax rate for the three and six months ended June 29, 2019 of 18.2% and 19.2%.


## us-gaap:EarningsPerShareTextBlock

[0000889331-20-000045:notes:118]
[same as prior period, unchanged from 0000889331-20-000037:notes:129]

[0000889331-20-000045:notes:119]
[same as prior period, unchanged from 0000889331-20-000037:notes:130]

[0000889331-20-000045:notes:120]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
| (in thousands, except per share amounts) |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net (loss) income as reported |  | $ | (8,991) |  |  | $ | 43,792 |  |  | $ | 15,653 |  |  | $ | 80,781 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,312 |  |  | 24,740 |  |  | 24,353 |  |  | 24,729 |  |
| Effect of dilutive securities |  | — |  |  | 243 |  |  | 167 |  |  | 269 |  |
| Diluted |  | 24,312 |  |  | 24,983 |  |  | 24,520 |  |  | 24,998 |  |
| (Loss) Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic (loss) earnings per share |  | $ | (0.37) |  |  | $ | 1.77 |  |  | $ | 0.64 |  |  | $ | 3.27 |  |
| Diluted (loss) earnings per share |  | $ | (0.37) |  |  | $ | 1.75 |  |  | $ | 0.64 |  |  | $ | 3.23 |  |

[0000889331-20-000045:notes:121]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 328,624 and 167,599 for the  three months ended June 27, 2020 and June 29, 2019, respectively, and 212,290 and 121,326 for the six months ended June 27, 2020 and June 29, 2019, respectively.

[0000889331-20-000045:notes:122]
[same as prior period, unchanged from 0000889331-20-000037:notes:133]

[0000889331-20-000045:notes:123]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized to a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program") to replace its previous expired 2018 program. On April 23, 2020, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. The Company has suspended share repurchases for the near-term due to the uncertainty of the impact and duration of COVID-19 and to focus on other capital allocation priorities.
The Company did not repurchase any shares of its common stock for the three months ended June 27, 2020. During the three months ended June 29, 2019, the Company repurchased 188,214 shares of its common stock totaling $32.0 million. For the six months ended June 27, 2020 and June 29, 2019, the Company repurchased 175,110 and 268,130 shares of its common stock totaling $22.9 million and $45.5 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-20-000045:notes:124]
Related Party Transactions

[0000889331-20-000045:notes:125]
As a result of the Company’s acquisition of IXYS, the Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-20-000045:notes:126]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-20-000045:notes:127]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-20-000045:notes:128]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-20-000045:notes:129]
|  |  | For the Three Months Ended June 27, 2020 |  |  |  | For the Three Months Ended June 29, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.8 |  | — |  | 1.6 |  |  | 0.9 |  | 0.1 |  | 2.3 |  |
|  |  | For the Six Months Ended June 27, 2020 |  |  |  | For the Six Months Ended June 29, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.7 |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.0 |  | — |  | 3.4 |  |  | 1.7 |  | 0.2 |  | 3.8 |  |
|  |  | June 27, 2020 |  |  |  | December 28, 2019 |  |  |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | 0.2 |  | — |  | 0.1 |  |  | 0.2 |  | — |  | 0.1 |  |

[0000889331-20-000045:notes:130]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.4 million as of June 27, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

[0000889331-20-000045:notes:131]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Condensed Consolidated Statements of Net (Loss) Income. The 
operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-20-000045:notes:132]
[same as prior period, unchanged from 0000889331-20-000037:notes:144]

[0000889331-20-000045:notes:133]
[same as prior period, unchanged from 0000889331-20-000037:notes:145]

[0000889331-20-000045:notes:134]
[same as prior period, unchanged from 0000889331-20-000037:notes:146]

[0000889331-20-000045:notes:135]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, metal-oxide-semiconductor field effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial and automotive electronics, electric vehicle and related infrastructure, data and telecommunications, medical devices, alternative energy, consumer electronics and white goods.

[0000889331-20-000045:notes:136]
•Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle end markets. Passenger car fuse products include fuses and fuse accessories for internal combustion engine vehicles and hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle products designed to monitor the passenger compartment occupants, safety and environment as well as the vehicle’s powertrain.

[0000889331-20-000045:notes:137]
•Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in various industrial applications such as oil, gas, mining, alternative energy, electric vehicle infrastructure, non-residential construction, HVAC systems, elevators and other industrial equipment.

[0000889331-20-000045:notes:138]
[same as prior period, unchanged from 0000889331-20-000037:notes:155]

[0000889331-20-000045:notes:139]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
| (in thousands) |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 223,271 |  |  | $ | 259,553 |  |  | $ | 437,460 |  |  | $ | 524,947 |  |
| Automotive |  | 61,999 |  |  | 108,650 |  |  | 166,769 |  |  | 222,133 |  |
| Industrial |  | 22,067 |  |  | 29,676 |  |  | 49,204 |  |  | 56,299 |  |
| Total net sales |  | $ | 307,337 |  |  | $ | 397,879 |  |  | $ | 653,433 |  |  | $ | 803,379 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,617 |  |  | $ | 14,729 |  |  | $ | 31,148 |  |  | 30,071 |  |
| Automotive |  | 7,071 |  |  | 6,904 |  |  | 14,258 |  |  | 13,781 |  |
| Industrial |  | 1,046 |  |  | 1,056 |  |  | 2,130 |  |  | 2,116 |  |
| Total depreciation and amortization |  | $ | 23,734 |  |  | $ | 22,689 |  |  | $ | 47,536 |  |  | $ | 45,968 |  |
| Operating (loss) income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 32,651 |  |  | $ | 43,630 |  |  | $ | 64,923 |  |  | $ | 92,666 |  |
| Automotive |  | (8,857) |  |  | 10,349 |  |  | 5,259 |  |  | 23,550 |  |
| Industrial |  | (23) |  |  | 5,831 |  |  | 3,511 |  |  | 9,336 |  |
| Other(a) |  | (35,721) |  |  | (7,176) |  |  | (40,893) |  |  | (12,245) |  |
| Total operating (loss) income |  | (11,950) |  |  | 52,634 |  |  | 32,800 |  |  | 113,307 |  |
| Interest expense |  | 5,855 |  |  | 5,589 |  |  | 11,273 |  |  | 11,275 |  |
| Foreign exchange (gain) loss |  | (6,010) |  |  | (3,575) |  |  | (3,426) |  |  | 668 |  |
| Other (income) expense, net |  | (1,210) |  |  | (2,947) |  |  | 39 |  |  | 1,358 |  |
| (Loss) income before income taxes |  | $ | (10,585) |  |  | $ | 53,567 |  |  | $ | 24,914 |  |  | $ | 100,006 |  |

[0000889331-20-000045:notes:140]
(a) Included in “Other” Operating (loss) income for the 2020 second quarter is $0.1 million ($1.3 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there was $35.6 million ($39.6 million year-to-date) of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, $1.8 million ($3.5 million year-to-date) of employee termination costs, and other restructuring charges and impairment charges of $2.2 million recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment. See Note 4, Goodwill and Other Intangible Assets and Note 6, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-20-000045:notes:141]
Included in "Other" Operating income (loss) for the second quarter of 2019 is $1.5 million ($3.8 million year-to-date) of acquisition integration charges primarily related to the IXYS acquisition. In addition, there were $5.7 million ($8.4 million year-to-date) of restructuring charges primarily related to employee termination costs.

[0000889331-20-000045:notes:142]
[same as prior period, unchanged from 0000889331-20-000037:notes:159]

[0000889331-20-000045:notes:143]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
| (in thousands) |  | June 27, 2020 |  | June 29, 2019 |  | June 27, 2020 |  | June 29, 2019 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 76,870 |  |  | $ | 115,991 |  |  | $ | 179,780 |  |  | $ | 235,519 |  |
| China |  | 102,026 |  |  | 107,728 |  |  | 188,041 |  |  | 214,593 |  |
| Other countries(a) |  | 128,441 |  |  | 174,160 |  |  | 285,612 |  |  | 353,267 |  |
| Total net sales |  | $ | 307,337 |  |  | $ | 397,879 |  |  | $ | 653,433 |  |  | $ | 803,379 |  |

[0000889331-20-000045:notes:144]
[same as prior period, unchanged from 0000889331-20-000037:notes:161]

[0000889331-20-000045:notes:145]
| (in thousands) |  | June 27,2020 |  | December 28,2019 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 54,082 |  |  | $ | 58,081 |  |
| China |  | 82,224 |  |  | 88,306 |  |
| Mexico |  | 67,967 |  |  | 73,096 |  |
| Germany |  | 36,721 |  |  | 36,025 |  |
| Philippines |  | 58,272 |  |  | 51,738 |  |
| Other countries(a) |  | 35,411 |  |  | 37,371 |  |
| Total long-lived assets |  | $ | 334,677 |  |  | $ | 344,617 |  |

[0000889331-20-000045:notes:146]
[same as prior period, unchanged from 0000889331-20-000037:notes:163]

[0000889331-20-000045:notes:147]
|  |  | Six Months Ended |  |  |
| (in thousands) |  | June 27, 2020 |  | June 29, 2019 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 2,026 |  |  | $ | 3,454 |  |
| China |  | 4,516 |  |  | 4,958 |  |
| Mexico |  | 4,260 |  |  | 8,727 |  |
| Germany |  | 2,509 |  |  | 3,712 |  |
| Philippines |  | 9,039 |  |  | 6,629 |  |
| Other countries(a) |  | 687 |  |  | 2,378 |  |
| Total additions to long-lived assets |  | $ | 23,037 |  |  | $ | 29,858 |  |

[0000889331-20-000045:notes:148]
(a)Each country included in other countries is less than 10% of net sales.
