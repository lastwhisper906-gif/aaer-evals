# LFUS MD&A — 0000889331-20-000045


## mdna

[0000889331-20-000045:mdna:1]
[same as prior period, unchanged from 0000889331-20-000037:mdna:1]

[0000889331-20-000045:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-20-000045:mdna:3]
[same as prior period, unchanged from 0000889331-20-000037:mdna:3]

[0000889331-20-000045:mdna:4]
[same as prior period, unchanged from 0000889331-20-000037:mdna:4]

[0000889331-20-000045:mdna:5]
[same as prior period, unchanged from 0000889331-20-000037:mdna:5]

[0000889331-20-000045:mdna:6]
[same as prior period, unchanged from 0000889331-20-000037:mdna:6]

[0000889331-20-000045:mdna:7]
[same as prior period, unchanged from 0000889331-20-000037:mdna:7]

[0000889331-20-000045:mdna:8]
[same as prior period, unchanged from 0000889331-20-000037:mdna:8]

[0000889331-20-000045:mdna:9]
The Company maintains a network of global laboratories and engineering centers that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company conducts its business through three reportable segments: Electronics, Automotive, and Industrial. Within these segments, the Company designs, manufactures and sells components and modules for circuit protection, power control and sensing products throughout the world. The circuit protection products protect against electrostatic discharge, power surges, short circuits, voltage spikes and other harmful occurrences; our power control products safely and efficiently control power and improve productivity and our sensor products are used to identify and detect temperature, proximity, flow speed and fluid level in various applications.

[0000889331-20-000045:mdna:10]
[same as prior period, unchanged from 0000889331-20-000037:mdna:10]

[0000889331-20-000045:mdna:11]
For the second quarter of 2020, the Company recognized net sales of $307.3 million compared to $397.9 million in the second quarter of 2019 representing a decrease of $90.5 million, or 22.8%. The decrease was primarily driven by lower volume across all of the segments due to the impact of COVID-19, a decline in global auto production, and $2.3 million or 0.6% of unfavorable changes in foreign exchange rates.  The Company recognized a net loss of $9.0 million, or $0.37 per diluted share, in the second quarter of 2020 compared to net income of $43.8 million, or $1.75 per diluted share in the second quarter of 2019. The net loss was primarily due to a non-cash goodwill impairment charge of $33.8 million related to the automotive sensors reporting unit within the Automotive segment and lower operating income across all the segments.

[0000889331-20-000045:mdna:12]
[same as prior period, unchanged from 0000889331-20-000037:mdna:12]

[0000889331-20-000045:mdna:13]
Net cash provided by operating activities was $101.3 million for the six months ended June 27, 2020 as compared to $80.1 million for the six months ended June 29, 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and favorable changes in net working capital driven by the timing of collections of accounts receivable and changes in accounts payable partially offset by lower earnings largely due to the impact of COVID-19.

[0000889331-20-000045:mdna:14]
On March 25, 2020, the company borrowed $100.0 million from its current revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. On April 3, 2020, the Company amended the existing credit agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended credit agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-20-000045:mdna:15]
[same as prior period, unchanged from 0000889331-20-000037:mdna:16]

[0000889331-20-000045:mdna:16]
[same as prior period, unchanged from 0000889331-20-000037:mdna:17]

[0000889331-20-000045:mdna:17]
COVID-19 continued to negatively impact the Company’s 2020 second quarter financial results. During the second quarter, sales volumes across all of the Company's segments were reduced driven by production disruptions from temporary closures of manufacturing facilities in the Philippines, Mexico and Italy as a result of government directives. Furthermore, sales volumes in the Automotive segment were significantly impacted by lower global end market demand across passenger vehicle end markets. The Company incurred incremental costs of approximately $5.1 million and $7.6 million during the three and six months ended June 27, 2020, respectively,  primarily due to costs related to the above temporary plant closures, higher costs for freight and protective supplies, partially offset by certain international government subsidies and COVID-19 relief programs.

[0000889331-20-000045:mdna:18]
The Company’s priorities continue to be first, on our associates, their families and the communities in which we operate; second, our customers; and third, long-term financial health of the company. In an effort to protect the health and safety of our employees, the Company has enacted numerous proactive, aggressive actions at its facilities globally, and implemented a number of safety procedures including hygiene and disinfection protocols, social distancing and wearing personal protective equipment ("PPE"). The Company expects these actions will continue for the foreseeable future.

[0000889331-20-000045:mdna:19]
In an effort to contain COVID-19 and slow its spread, governments around the world enacted various measures, including orders to close all businesses not deemed “essential”, isolate residents to their homes or places of residence, and practice social distancing when engaging in essential activities. These government measures disrupted certain of our operating locations in many countries around the world. our operations that were closed or running at limited levels during the second quarter returned to normal or nearly normal capacity levels during June, and all of our manufacturing facilities are currently operating.

[0000889331-20-000045:mdna:20]
The Company continues to work with customers to meet production requirements for their products, many of which are considered essential, including healthcare and medical devices, transportation, communication and energy infrastructure.

[0000889331-20-000045:mdna:21]
The Company took cost containment initiatives to help offset the impact of lower demand and the business disruption created by COVID-19. During the first quarter, the Company suspended annual wage increases and its 2020 annual cash incentive program.  The Company also reduced salaries of the CEO and executive leadership team, and reduced cash compensation of its board of directors during the second quarter. The Company continues to develop and execute contingency plans to manage our business performance within this uncertain environment.

[0000889331-20-000045:mdna:22]
The Company anticipates that the global health crisis caused by COVID-19 will negatively impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a resurgence in COVID-19 cases and its impact on our employees, customers, suppliers and vendors.  The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business and operations, including the effects on our customers, employees, and prospects, or on our financial results for the remainder of fiscal 2020.

[0000889331-20-000045:mdna:23]
Goodwill Impairment Assessment

[0000889331-20-000045:mdna:24]
The Company performs its annual goodwill impairment tests on or about September 30, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. As part of its interim review for indicators of impairment, management analyzed potential changes in the value of individual reporting units with goodwill based on each reporting unit’s operating results for the six months ended June 27, 2020 compared to expected results.  In addition, management considered how other key assumptions, including discount rates and expected long-term growth rates, used in last fiscal year’s impairment analysis, could be impacted by changes in market conditions and economic events.

[0000889331-20-000045:mdna:25]
Management considered trends in these factors when performing its assessment of whether an interim impairment review was required for any reporting unit. For the three months ended June 27, 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2019 annual goodwill impairment test. These lower future expectations were driven by projected extended declines in end market demand due to the COVID-19 pandemic. In addition, during the second quarter of 2020, certain customers notified the Company of their decision to delay future programs along with a customer canceling an existing program. The goodwill impairment charge was

[0000889331-20-000045:mdna:26]
determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data As of June 27, 2020, the automotive sensors reporting unit had $9.1 million of remaining goodwill.

[0000889331-20-000045:mdna:27]
In addition, the semiconductors reporting unit has experienced declines in net sales due to temporary plant shut-downs and lower customer demand primarily due to COVID-19. The Company continues to evaluate the impact of COVID-19 on its long-term expectations for this unit. Further negative developments having a significant impact on the estimated fair value of this reporting unit could result in future goodwill impairment charges. As of the September 30, 2019 annual goodwill impairment test, the semiconductors reporting unit estimated fair value exceeded its book value by approximately 42%. As of June 27, 2020, $467.1 million of goodwill was allocated to the semiconductors reporting unit. The semiconductors reporting unit is included within the Electronics segment.

[0000889331-20-000045:mdna:28]
Based on the June 27, 2020 interim assessment, management concluded that other than the goodwill impairment recognized in the automotive sensors reporting unit, no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value. Nevertheless, a continued global economic slowdown and further business disruption due to COVID-19 could result in changes to expectations of future financial results and key valuation assumptions. These changes could result in changes to management’s estimates of the fair value of the Company’s reporting units and could result in a review for impairment of goodwill prior to September 29, 2020, the Company’s next annual measurement date, and a potential corresponding impairment charge.

[0000889331-20-000045:mdna:29]
[same as prior period, unchanged from 0000889331-20-000037:mdna:24]

[0000889331-20-000045:mdna:30]
While the Company has not historically or currently as of June 27, 2020 had significant credit risk on its accounts receivable, the impact of the COVID-19 pandemic and associated economic slowdown may increase the Company’s credit risk on accounts receivable. It is possible that the Company’s customers may experience liquidity issues which may impact the timing of the collections on receivables. The Company will continue to evaluate how the ongoing pandemic may impact collectability.

[0000889331-20-000045:mdna:31]
[same as prior period, unchanged from 0000889331-20-000037:mdna:29]

[0000889331-20-000045:mdna:32]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The second quarter of 2020 includes $0.1 million ($1.3 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $35.6 million ($39.6 million year-to-date) of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, $1.8 million ($3.5 million year-to-date) of employee termination costs, and other restructuring charges and impairment charges of $2.2 million recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment.

[0000889331-20-000045:mdna:33]
The second quarter of 2019 includes $1.5 million ($3.8 million year-to-date) of acquisition integration charges primarily related to the IXYS acquisition. In addition, there were $5.7 million ($8.4 million year-to-date) of restructuring charges primarily related to employee termination costs.

[0000889331-20-000045:mdna:34]
|  |  | Second Quarter |  |  |  |  |  |  |  | First Six Months |  |  |  |  |  |  |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |  | 2020 |  | 2019 |  | Change |  | %Change |
| Net sales |  | $ | 307,337 |  |  | $ | 397,879 |  |  | $ | (90,542) |  |  | (22.8) | % |  | $ | 653,433 |  |  | $ | 803,379 |  |  | $ | (149,946) |  |  | (18.7) | % |
| Gross profit |  | 99,099 |  |  | 141,808 |  |  | (42,709) |  |  | (30.1) | % |  | 222,811 |  |  | 297,036 |  |  | (74,225) |  |  | (25.0) | % |
| Operating expenses |  | 111,049 |  |  | 89,174 |  |  | 21,875 |  |  | 24.5 | % |  | 190,011 |  |  | 183,729 |  |  | 6,282 |  |  | 3.4 | % |
| Operating (loss) income |  | (11,950) |  |  | 52,634 |  |  | (64,584) |  |  | (122.7) | % |  | 32,800 |  |  | 113,307 |  |  | (80,507) |  |  | (71.1) | % |
| (Loss) income before income taxes |  | (10,585) |  |  | 53,567 |  |  | (64,152) |  |  | (119.8) | % |  | 24,914 |  |  | 100,006 |  |  | (75,092) |  |  | (75.1) | % |
| Income taxes |  | (1,594) |  |  | 9,775 |  |  | (11,369) |  |  | (116.3) | % |  | 9,261 |  |  | 19,225 |  |  | (9,964) |  |  | (51.8) | % |
| Net (loss) income |  | $ | (8,991) |  |  | $ | 43,792 |  |  | $ | (52,783) |  |  | (120.5) | % |  | $ | 15,653 |  |  | $ | 80,781 |  |  | $ | (65,128) |  |  | (80.6) | % |

[0000889331-20-000045:mdna:35]
[same as prior period, unchanged from 0000889331-20-000037:mdna:33]

[0000889331-20-000045:mdna:36]
Net sales decreased $90.5 million or 22.8% for the second quarter of 2020 compared to the second quarter of 2019 primarily due to lower volume across all segments due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 and lower volume across the Automotive segment due to a decline in global auto production driven by lower global end market demand, and $2.3 million or 0.6% of unfavorable changes in foreign exchange rates.

[0000889331-20-000045:mdna:37]
Net sales decreased $149.9 million or 18.7% for the first six months of 2020 compared to the first six months of 2019 primarily due to lower volume driven by the disruption across the Electronics and Automotive segments due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, lower volume across the Electronics segment from electronics distribution partners and end customers reducing excess inventories and production, and lower volume across the Automotive segment due to a decline in global auto production driven by lower global end market demand, and $5.6 million or 0.7% of unfavorable changes in foreign exchange rates.

[0000889331-20-000045:mdna:38]
[same as prior period, unchanged from 0000889331-20-000037:mdna:35]

[0000889331-20-000045:mdna:39]
Gross profit was $99.1 million, or 32.2% of net sales, in the second quarter of 2020 compared to $141.8 million, or 35.6% of net sales, for the second quarter of 2019. The decrease in gross profit is primarily due to lower volume across all segments, additional costs associated with government-directed plant shutdowns and supply chain constraints, higher freight, supplies and other costs  due to the impact of COVID-19.

[0000889331-20-000045:mdna:40]
Gross profit was $222.8 million, or 34.1% of net sales, in the  first six months  of 2020 compared to $297.0 million, or 37.0% of net sales, for the first six months  of 2019. The decrease in gross profit reflected lower volume across all segments. The decrease in gross margin is primarily due to lower volumes across the Electronics segment, additional costs associated with government-directed plant shutdowns and supply chain constraints, higher freight, supplies and other costs  due to the impact of COVID-19, and unfavorable price and product mix.

[0000889331-20-000045:mdna:41]
[same as prior period, unchanged from 0000889331-20-000037:mdna:37]

[0000889331-20-000045:mdna:42]
Total operating expenses were $111.0 million, or 36.1% of net sales, for the second quarter of 2020 compared to $89.2 million, or 22.4% of net sales, for the second quarter of 2019. The increase in operating expenses of $21.9 million is primarily due to the goodwill impairment charge of $33.8 million, or 11.0% of net sales, in the automotive sensors reporting unit within the Automotive segment, partially offset by lower incentive compensation, lower research and development expenses of $8.1 million, lower sales commissions and travel expenses due to COVID-19, and lower acquisition-related and integration charges of $1.4 million.

[0000889331-20-000045:mdna:43]
Total operating expenses were $190.0 million, or 29.1% of net sales, for the first six months of 2020 compared to $183.7 million, or 22.9% of net sales, for the first six months of 2019. The increase in operating expenses of $6.3 million is primarily due to the goodwill impairment charge of $33.8 million, or 5.2% of net sales, in the automotive sensors reporting unit within the Automotive segment and impairment charges of $2.2 million related to the Company’s first quarter announcement to consolidate a manufacturing facility within the Industrial segment, partially offset by lower incentive compensation, lower research and development expenses of $14.9 million, lower sales commissions and travel expenses due to COVID-19, and lower acquisition-related and integration charges of $2.5 million.

[0000889331-20-000045:mdna:44]
Operating (Loss) Income

[0000889331-20-000045:mdna:45]
Operating loss was $12.0 million, a decrease of $64.6 million, or 122.7%, for the second quarter of 2020 compared to operating income $52.6 million for the second quarter of 2019. The decrease is primarily due to lower gross margin across all of the segments and higher operating expenses noted above. Operating margins decreased from 13.2% in the second quarter of 2019 to (3.9)% in the second quarter of 2020 driven by the factors mentioned above. The goodwill impairment charge of $33.8 million negatively impacted the operating margin by 11.0% for the second quarter of 2020.

[0000889331-20-000045:mdna:46]
Operating income was $32.8 million, a decrease of $80.5 million, or 71.1%, for the first six months of 2020 compared to $113.3 million for the first six months of 2019. The decrease in operating income is primarily due to lower gross margin across all segments and higher operating expenses noted above. Operating margins decreased from 14.1% in the first six months of 2019 to 5.0% in the first six months of 2020 driven by the factors mentioned above. The goodwill impairment charge of $33.8 million negatively impacted the operating margin by 5.2% for the first six months of 2020.

[0000889331-20-000045:mdna:47]
(Loss) Income Before Income Taxes

[0000889331-20-000045:mdna:48]
Loss before income taxes was $10.6 million, or (3.4)% of net sales, for the second quarter of 2020 compared to income before income tax of $53.6 million, or 13.5% of net sales, for the second quarter of 2019. In addition to the factors impacting comparative results for operating (loss) income discussed above, loss before income taxes was primarily impacted by $1.8 million increase in coal mining reserves, lower interest income of $0.9 million, higher interest expense and higher pension non-service costs, partially offset by higher foreign exchange gains of $2.4 million and unrealized investment gains of $1.7 million associated with our equity investments during the three months ended June 27, 2020 compared to the three months ended June 29, 2019.

[0000889331-20-000045:mdna:49]
Income before income taxes was $24.9 million, or 3.8% of net sales, for the first six months of 2020 compared to $100.0 million, or 12.4% of net sales, for the first six months of 2019.  In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by foreign exchange gains of $3.4 million during the six months ended June 27, 2020 compared to foreign exchange losses of $0.7 million during the six months ended June 29, 2019, impairment charges of $3.1 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment during the six months ended June 29, 2019, partially offset by a $1.5 million increase in coal mining reserve and $1.0 million decreases in unrealized investment gains associated with our equity investments.

[0000889331-20-000045:mdna:50]
[same as prior period, unchanged from 0000889331-20-000037:mdna:43]

[0000889331-20-000045:mdna:51]
Income tax benefit for the second quarter of 2020 was $1.6 million, or an effective tax rate of 15.1%, compared to income tax expense of $9.8 million, or an effective tax rate of 18.2%, for the second quarter of 2019. The effective tax rate for the second quarter of 2020 (which is based upon a pre-tax loss) is lower than the effective tax rate for the comparable 2019 period (which is based upon pre-tax income), primarily due to the goodwill impairment charge of $33.8 million recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit.

[0000889331-20-000045:mdna:52]
Income tax expense for the first six months of 2020 was $9.3 million, or an effective tax rate of 37.2%, compared to income tax expense of $19.2 million, or an effective tax rate of 19.2%, for the first six months of 2019. The effective tax rate for the first six months of 2020 is higher than the effective tax rate for the comparable 2019 period primarily due to the impact of the goodwill impairment charge of $33.8 million, the substantial majority of which did not result in a tax benefit, as well as a reduction in the forecasted income earned in lower tax jurisdictions in 2020 driven by the uncertainty resulting from the impact of COVID-19. The effective tax rate for the first six months of 2020 is higher than the applicable U.S. statutory tax rate primarily due to the impact of the goodwill impairment charge of $33.8 million as well as the forecasted impact of non-U.S. losses and expenses with no tax benefit and the U.S. global intangible low-taxed income tax provisions (in the 2019 comparable period the impact of these items was more than offset by the impact of income earned in lower tax jurisdictions).

[0000889331-20-000045:mdna:53]
[same as prior period, unchanged from 0000889331-20-000037:mdna:45]

[0000889331-20-000045:mdna:54]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 14, Segment Information, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-20-000045:mdna:55]
[same as prior period, unchanged from 0000889331-20-000037:mdna:47]

[0000889331-20-000045:mdna:56]
|  |  | Second Quarter |  |  |  |  |  |  |  | First Six Months |  |  |  |  |  |  |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |  | 2020 |  | 2019 |  | Change |  | %Change |
| Electronics |  | $ | 223,271 |  |  | $ | 259,553 |  |  | $ | (36,282) |  |  | (14.0) | % |  | $ | 437,460 |  |  | $ | 524,947 |  |  | $ | (87,487) |  |  | (16.7) | % |
| Automotive |  | 61,999 |  |  | 108,650 |  |  | (46,651) |  |  | (42.9) | % |  | 166,769 |  |  | 222,133 |  |  | (55,364) |  |  | (24.9) | % |
| Industrial |  | 22,067 |  |  | 29,676 |  |  | (7,609) |  |  | (25.6) | % |  | 49,204 |  |  | 56,299 |  |  | (7,095) |  |  | (12.6) | % |
| Total |  | $ | 307,337 |  |  | $ | 397,879 |  |  | $ | (90,542) |  |  | (22.8) | % |  | $ | 653,433 |  |  | $ | 803,379 |  |  | $ | (149,946) |  |  | (18.7) | % |

[0000889331-20-000045:mdna:57]
[same as prior period, unchanged from 0000889331-20-000037:mdna:49]

[0000889331-20-000045:mdna:58]
Net sales decreased $36.3 million, or 14.0%, in the second quarter of 2020 compared to the second quarter of 2019 primarily due to lower volume in the semiconductor and electronics products businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, and unfavorable changes in foreign exchange rates of $1.2 million.

[0000889331-20-000045:mdna:59]
Net sales decreased $87.5 million, or 16.7%, in the first six months of 2020 compared to the first six months of 2019 primarily due to lower volume in the semiconductor and electronics products businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, lower volume from electronics distribution partners and end customers reducing excess inventories, and unfavorable changes in foreign exchange rates of $2.9 million.

[0000889331-20-000045:mdna:60]
[same as prior period, unchanged from 0000889331-20-000037:mdna:51]

[0000889331-20-000045:mdna:61]
Net sales decreased $46.7 million, or 42.9%, in the second quarter of 2020 compared to the second quarter of 2019 due to decreased volume across all businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, a decline in global auto production driven by lower global end market demand, and unfavorable changes in foreign exchange rates of $0.9 million.

[0000889331-20-000045:mdna:62]
Net sales decreased $55.4 million, or 24.9%, in the first six months of 2020 compared to the first six months of 2019 due to decreased volume across all businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, a decline in global auto production driven by lower global end market demand, and unfavorable changes in foreign exchange rates of $2.5 million.

[0000889331-20-000045:mdna:63]
[same as prior period, unchanged from 0000889331-20-000037:mdna:53]

[0000889331-20-000045:mdna:64]
Net sales decreased by $7.6 million, or 25.6%, in the second quarter of 2020 compared to the second quarter of 2019 primarily due to decreased volume across all businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 and unfavorable changes in foreign exchange rates of $0.2 million.

[0000889331-20-000045:mdna:65]
Net sales decreased by $7.1 million, or 12.6%, in the first six months of 2020 compared to the first six months of 2019 primarily due to decreased volume across all businesses driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19 in the second quarter of 2020, and by unfavorable changes in foreign exchange rates of $0.2 million.

[0000889331-20-000045:mdna:66]
[same as prior period, unchanged from 0000889331-20-000037:mdna:55]

[0000889331-20-000045:mdna:67]
[same as prior period, unchanged from 0000889331-20-000037:mdna:56]

[0000889331-20-000045:mdna:68]
|  |  | Second Quarter |  |  |  |  |  |  |  | First Six Months |  |  |  |  |  |  |
| (in thousands) |  | 2020 |  | 2019 |  | Change |  | %Change |  | 2020 |  | 2019 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 155,737 |  |  | $ | 172,895 |  |  | $ | (17,158) |  |  | (9.9) | % |  | $ | 296,610 |  |  | $ | 345,676 |  |  | $ | (49,066) |  |  | (14.2) | % |
| Americas |  | 89,651 |  |  | 135,894 |  |  | (46,243) |  |  | (34.0) | % |  | 210,152 |  |  | 273,928 |  |  | (63,776) |  |  | (23.3) | % |
| Europe |  | 61,949 |  |  | 89,090 |  |  | (27,141) |  |  | (30.5) | % |  | 146,671 |  |  | 183,775 |  |  | (37,104) |  |  | (20.2) | % |
| Total |  | $ | 307,337 |  |  | $ | 397,879 |  |  | $ | (90,542) |  |  | (22.8) | % |  | $ | 653,433 |  |  | $ | 803,379 |  |  | $ | (149,946) |  |  | (18.7) | % |

[0000889331-20-000045:mdna:69]
[same as prior period, unchanged from 0000889331-20-000037:mdna:58]

[0000889331-20-000045:mdna:70]
Net sales decreased $17.2 million, or 9.9%, in the second quarter of 2020 compared to the second quarter of 2019. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment, lower volume in passenger car products businesses within the Automotive segment, and unfavorable changes in foreign exchange rates of $1.1 million.

[0000889331-20-000045:mdna:71]
Net sales decreased $49.1 million, or 14.2%, in the first six months of 2020 compared to the first six months of 2019. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics and Automotive segments and unfavorable changes in foreign exchange rates of $2.0 million.

[0000889331-20-000045:mdna:72]
[same as prior period, unchanged from 0000889331-20-000037:mdna:60]

[0000889331-20-000045:mdna:73]
Net sales decreased $46.2 million, or 34.0%, in the second quarter of 2020 compared to the second quarter of 2019 primarily due to lower volume across all segments due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, lower volume across the Automotive segment due to a decline in global auto production driven by lower global end market demand, and unfavorable changes in foreign exchange rates of $0.1 million.

[0000889331-20-000045:mdna:74]
Net sales decreased $63.8 million, or 23.3%, in the first six months of 2020 compared to the first six months of 2019 primarily due to lower volume across all segments driven by the production disruption due to temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19, lower volume across the Electronics segment from electronics distribution partners and end customers reducing excess inventories and production, lower volume in all businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $0.3 million.

[0000889331-20-000045:mdna:75]
[same as prior period, unchanged from 0000889331-20-000037:mdna:62]

[0000889331-20-000045:mdna:76]
Net sales decreased $27.1 million, or 30.5%, in the second quarter of 2020 compared to the second quarter of 2019. The decrease in net sales was primarily due to lower volume in the semiconductor business within the Electronics segment, lower volume in all businesses within the Automotive segment, and unfavorable changes in foreign exchange rates of $1.1 million.

[0000889331-20-000045:mdna:77]
Net sales decreased $37.1 million, or 20.2%, in the first six months of 2020 compared to the first six months of 2019. The decrease in net sales was primarily due to lower volume in the semiconductor business within the Electronics segment, lower volume in all businesses within the Automotive segment and unfavorable changes in foreign exchange rates of $3.3 million.

[0000889331-20-000045:mdna:78]
[same as prior period, unchanged from 0000889331-20-000037:mdna:64]

[0000889331-20-000045:mdna:79]
[same as prior period, unchanged from 0000889331-20-000037:mdna:65]

[0000889331-20-000045:mdna:80]
Cash and cash equivalents were $651.9 million as of June 27, 2020, an increase of $120.7 million as compared to December 28, 2019. As of June 27, 2020, $312.6 million of the Company's $651.9 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-20-000045:mdna:81]
Revolving Credit Facility/Term Loan

[0000889331-20-000045:mdna:82]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000045:mdna:83]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also included the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans could be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company was required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $2.5 million and $5.0 million of principal payments on the term loan during the three and six months ended June 27, 2020, respectively.

[0000889331-20-000045:mdna:84]
On March 25, 2020, the company borrowed $100.0 million from its current revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19.

[0000889331-20-000045:mdna:85]
On April 3, 2020, the Company amended the Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-20-000045:mdna:86]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.13% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.70% at June 27, 2020.

[0000889331-20-000045:mdna:87]
As of June 27, 2020, the Company had no amounts outstanding in letters of credit and had available $148.6 million of borrowing capacity under the Revolving Credit Facility based on financial covenants.

[0000889331-20-000045:mdna:88]
Further information regarding the Company’s credit agreement is provided in Note 7, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-20-000045:mdna:89]
[same as prior period, unchanged from 0000889331-20-000037:mdna:76]

[0000889331-20-000045:mdna:90]
[same as prior period, unchanged from 0000889331-20-000037:mdna:77]

[0000889331-20-000045:mdna:91]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000045:mdna:92]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 7, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-20-000045:mdna:93]
Debt Covenants

[0000889331-20-000045:mdna:94]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of June 27, 2020 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2020. As of June 27, 2020, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.  The ultimate magnitude of COVID-19, including the extent of its impact on our financial and operational results, which could be material, will be determined by the length of time that the

[0000889331-20-000045:mdna:95]
pandemic continues, its effect on the demand for our products, as well as the effect of governmental regulations imposed in response to the pandemic. While we cannot at this time predict the impact of the COVID-19, it could have a material negative impact on our business, financial condition, results of operations and future cash flows which could impact the Company’s ability to comply with debt covenants in the future.

[0000889331-20-000045:mdna:96]
[same as prior period, unchanged from 0000889331-20-000037:mdna:82]

[0000889331-20-000045:mdna:97]
During the second quarter of 2020 the Company paid quarterly dividends of $11.7 million to the shareholders. On July 22, 2020, the Board of Directors of the Company declared a quarterly cash dividend of $0.48 per share, payable on September 3, 2020 to stockholders of record as of August 20, 2020. Future determinations regarding the declaration and payment of dividends will be at the discretion of our board of directors and will depend on then-existing conditions, including our results of operations, payout ratio, capital requirements, financial condition, prospects and other factors that our board of directors may deem relevant.

[0000889331-20-000045:mdna:98]
[same as prior period, unchanged from 0000889331-20-000037:mdna:84]

[0000889331-20-000045:mdna:99]
|  |  | First Six Months |  |  |
| (in thousands) |  | 2020 |  | 2019 |
| Net cash provided by operating activities |  | $ | 101,286 |  |  | $ | 80,092 |  |
| Net cash used in investing activities |  | (29,390) |  |  | (19,812) |  |
| Net cash provided by (used in) financing activities |  | 50,526 |  |  | (75,624) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,694) |  |  | 392 |  |
| Increase (decrease) in cash and cash equivalents |  | 120,728 |  |  | (14,952) |  |
| Cash and cash equivalents at beginning of period |  | 531,139 |  |  | 489,733 |  |
| Cash and cash equivalents at end of period |  | $ | 651,867 |  |  | $ | 474,781 |  |

[0000889331-20-000045:mdna:100]
[same as prior period, unchanged from 0000889331-20-000037:mdna:86]

[0000889331-20-000045:mdna:101]
[same as prior period, unchanged from 0000889331-20-000037:mdna:87]

[0000889331-20-000045:mdna:102]
Net cash provided by operating activities was $101.3 million for the six months ended June 27, 2020, compared to $80.1 million during the six months ended June 29, 2019. The increase in net cash provided by operating activities was primarily due to lower annual incentive payments and favorable changes in net working capital driven by the timing of collections of accounts receivable and changes in accounts payable partially offset by lower earnings largely due to the impact of COVID-19.

[0000889331-20-000045:mdna:103]
[same as prior period, unchanged from 0000889331-20-000037:mdna:89]

[0000889331-20-000045:mdna:104]
Net cash used in investing activities was $29.4 million for the six months ended June 27, 2020 compared to $19.8 million during the six months ended June 29, 2019. Capital expenditures were $29.5 million, representing an increase of $4.2 million compared to 2019. During the six months ended June 29, 2019, the Company received proceeds of $6.4 million from the sale of a property within the Industrial segment.

[0000889331-20-000045:mdna:105]
[same as prior period, unchanged from 0000889331-20-000037:mdna:91]

[0000889331-20-000045:mdna:106]
Net cash provided by financing activities was $50.5 million for the six months ended June 27, 2020 compared to net cash used in financing activities of $75.6 million for the six months ended June 29, 2019. During the six months ended June 27, 2020, the company borrowed $100.0 million from its revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. On April 3, 2020, the Company amended the Credit Agreement to eliminate the $200.0 million unsecured term loan credit facility, with the remaining outstanding balance of $140.0 million repaid in full on April 3, 2020 through a new borrowing of $140.0 million under the recently amended revolving credit facility. The Company made principal payments of $5.0 million and $7.5 million on the term loan during the six months ended June 27, 2020 and June 29, 2019, respectively. For the six months ended June 27, 2020 and June 29, 2019, the Company repurchased 175,110 and 268,130 shares of its common stock totaling $22.9 million and $45.5 million, respectively, but made payments of $49.9 million related to settled share repurchases during the six months ended June 29, 2019. Additionally, dividends paid

[0000889331-20-000045:mdna:107]
increased $2.1 million from $21.3 million in the six months ended June 29, 2019 to $23.4 million for the six months ended June 27, 2020.

[0000889331-20-000045:mdna:108]
[same as prior period, unchanged from 0000889331-20-000037:mdna:93]

[0000889331-20-000045:mdna:109]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On April 26, 2019, the Company's Board of Directors authorized a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program") to replace its previous expired 2018 program. On April 23, 2020, the Company's Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. The 2019 program expired on April 30, 2020 with 324,890 of authorized repurchases remaining. The Company has suspended share repurchases for the near-term due to the uncertainty of the impact and duration of COVID-19 and to focus on other capital allocation priorities.

[0000889331-20-000045:mdna:110]
The Company did not repurchase shares of its common stock during the three months ended June 27, 2020, and for the three months ended June 29, 2019, the Company repurchased 188,214 shares of its common stock totaling  $32.0 million. For the six months ended June 27, 2020 and June 29, 2019, the Company repurchased 175,110 and 268,130 shares of its common stock totaling $22.9 million and $45.5 million, respectively.

[0000889331-20-000045:mdna:111]
[same as prior period, unchanged from 0000889331-20-000037:mdna:96]

[0000889331-20-000045:mdna:112]
As of June 27, 2020, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-20-000045:mdna:113]
[same as prior period, unchanged from 0000889331-20-000037:mdna:98]

[0000889331-20-000045:mdna:114]
[same as prior period, unchanged from 0000889331-20-000037:mdna:99]

[0000889331-20-000045:mdna:115]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 28, 2019. During the six months ended June 27, 2020, there were no significant changes in the application of critical accounting policies.
