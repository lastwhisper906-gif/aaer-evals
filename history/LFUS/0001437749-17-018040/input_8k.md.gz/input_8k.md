# LFUS 8-K — 0001437749-17-017988 filed 2017-11-01

## item codes, every 8-K on or before 2017-11-01

- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2017-11-01

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-017988:8k_2_02:1]
EX-99.1
2
ex_98326.htm
EXHIBIT 99.1

[0001437749-17-017988:8k_2_02:2]
ex_98326.htm

[0001437749-17-017988:8k_2_02:3]
Exhibit 99.1

[0001437749-17-017988:8k_2_02:4]
LITTELFUSE REPORTS THIRD QUARTER RESULTS

[0001437749-17-017988:8k_2_02:5]
CHICAGO, November 1, 2017 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the third quarter ended September 30, 2017.

[0001437749-17-017988:8k_2_02:6]
Third Quarter 2017 Highlights

[0001437749-17-017988:8k_2_02:7]
| ● | Net sales were $317.9 million, up 13% versus the prior year period. Organic revenue growth was 9%, excluding revenue from acquisitions closed in the past 12 months, the e-house business divestiture and foreign currency effects. |

[0001437749-17-017988:8k_2_02:8]
| ● | Growth by segment versus the prior year period: |

[0001437749-17-017988:8k_2_02:9]
|  | o | Electronics sales increased 19% (up 11% organically) |

[0001437749-17-017988:8k_2_02:10]
|  | o | Automotive sales increased 7% (up 5% organically) |

[0001437749-17-017988:8k_2_02:11]
|  | o | Industrial sales increased 7% (up 15% organically) |

[0001437749-17-017988:8k_2_02:12]
| ● | GAAP diluted EPS was $1.87; Adjusted EPS of $2.11 increased 13% over last year |

[0001437749-17-017988:8k_2_02:13]
| ● | The GAAP effective tax rate was 22.9% and adjusted effective tax rate was 22.4% |

[0001437749-17-017988:8k_2_02:14]
| ● | Cash flow from operations was a record $87.7 million, up 36% from the prior year period |

[0001437749-17-017988:8k_2_02:15]
| ● | The electronics segment book-to-bill ratio for the third quarter was 1.00 |

[0001437749-17-017988:8k_2_02:16]
| ● | On August 28, the company announced it had entered into a definitive agreement to acquire all of the outstanding shares of IXYS Corporation (NASDAQ: IXYS) in a cash and stock transaction. The transaction represented an enterprise value of approximately $655 million at announcement. (1) |

[0001437749-17-017988:8k_2_02:17]
| ● | In October, the company amended and expanded its unsecured credit facility to $900 million |

[0001437749-17-017988:8k_2_02:18]
“We continued our positive momentum, as our team delivered another quarter of strong sales, earnings and cash flow growth coupled with quality execution,” said Dave Heinzmann, Littelfuse Chief Executive Officer. “While our sales growth was led again by electronics, both our automotive and industrial businesses performed well, delivering the margin expansion we expected. We also took a

[0001437749-17-017988:8k_2_02:19]
-more-

[0001437749-17-017988:8k_2_02:20]
significant step forward in our power control strategy with the pending acquisition of IXYS Corporation. The combination of our talented employees, customer relationships and technological capabilities will create a strong power semiconductor player in the industry.”

[0001437749-17-017988:8k_2_02:21]
Fourth Quarter 2017 Outlook

[0001437749-17-017988:8k_2_02:22]
All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, foreign exchange adjustments and unusual

[0001437749-17-017988:8k_2_02:23]
gains and losses. These items are uncertain, depend on various factors, and could be material to results computed

[0001437749-17-017988:8k_2_02:24]
in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-17-017988:8k_2_02:25]
“While we are seeing a typical seasonal slowdown in order rates, end market demand remains strong across electronics,” continued Heinzmann. “We expect continued top line growth in the fourth quarter across all of our businesses, with normal sequential declines in both sales and margins for the quarter.”

[0001437749-17-017988:8k_2_02:26]
For the fourth quarter of 2017:

[0001437749-17-017988:8k_2_02:27]
| ● | Net sales are expected to be in the range of $292 to $304 million, up 5% on a reported basis and up 2% organically at the midpoint, versus the prior year quarter |

[0001437749-17-017988:8k_2_02:28]
| ● | Adjusted diluted earnings per share are expected to be in the range of $1.58 to $1.72 |

[0001437749-17-017988:8k_2_02:29]
For the full year, the company expects an adjusted effective tax rate in the range of 18% – 19%.

[0001437749-17-017988:8k_2_02:30]
Dividend

[0001437749-17-017988:8k_2_02:31]
The company will pay a cash dividend on its common stock of $0.37 per share on December 7, 2017 to shareholders of record as of November 22, 2017.

[0001437749-17-017988:8k_2_02:32]
Conference Call and Webcast Information

[0001437749-17-017988:8k_2_02:33]
Littelfuse will host a conference call today, Wednesday, November 1, 2017, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the results. The call will be broadcast live and can be accessed at: www.littelfuse.com. The call will be available for replay on the company’s website.

[0001437749-17-017988:8k_2_02:34]
About Littelfuse

[0001437749-17-017988:8k_2_02:35]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and

[0001437749-17-017988:8k_2_02:36]
-more-

[0001437749-17-017988:8k_2_02:37]
industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 10,000 employees in more than 40 locations throughout the Americas, Europe and Asia.  For more information, please visit the Littelfuse website: Littelfuse.com.

[0001437749-17-017988:8k_2_02:38]
| (1) | Based on Littelfuse closing stock price on August 25, 2017 per Bloomberg. Enterprise value inclusive of approximately $95 million net cash position for IXYS Corporation as of June 30, 2017. |

[0001437749-17-017988:8k_2_02:39]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.’s (“Littelfuse” or the “Company”) accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; the ability to satisfy the conditions to closing of the Company’s proposed acquisition of IXYS Corporation (“IXYS”), on the expected timing or at all; the occurrence of any event that could give rise to the termination of the merger agreement entered into by the Company and IXYS; the risk of stockholder litigation relating to the proposed transaction, including resulting expense or delay; higher than expected or unexpected costs associated with or relating to the proposed transaction; the risk that expected benefits, synergies and growth prospects of the proposed transaction may not be achieved in a timely manner, or at all; the risk that IXYS’ business may not be successfully integrated with the Company’s following the closing of the transaction; the risk that the Company and IXYS will be unable to retain and hire key personnel; and the risk that disruption from the proposed transaction may adversely affect the Company’s or IXYS’ business and their respective relationships with customers, suppliers or employees; and other risks which may be detailed in the company's other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 31, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-017988:8k_2_02:40]
Non-GAAP Financial Measures

[0001437749-17-017988:8k_2_02:41]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0001437749-17-017988:8k_2_02:42]
The company believes that organic net sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because

[0001437749-17-017988:8k_2_02:43]
-more-

[0001437749-17-017988:8k_2_02:44]
they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-17-017988:8k_2_02:45]
Important Additional Information and Where to Find It

[0001437749-17-017988:8k_2_02:46]
In connection with the proposed transaction, Littelfuse and IXYS have filed and will file relevant information with the SEC. Littelfuse has filed with the SEC a registration statement on Form S-4 (Registration No. 333-221147) (the “registration statement”) containing a preliminary proxy statement of IXYS that also constitutes a preliminary prospectus of Littelfuse (the “proxy statement/prospectus”). These materials are not yet final and will be amended. INVESTORS AND SECURITY HOLDERS OF IXYS ARE URGED TO CAREFULLY READ THE ENTIRE REGISTRATION STATEMENT, PROXY STATEMENT/PROSPECTUS AND OTHER RELEVANT DOCUMENTS FILED WITH THE SEC WHEN THEY BECOME AVAILABLE, BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT LITTELFUSE, IXYS AND THE PROPOSED TRANSACTION. The registration statement, proxy statement/prospectus and other documents filed by Littelfuse with the SEC may be obtained free of charge at the Littelfuse website at www.littelfuse.com or at the SEC’s website at www.sec.gov. These documents may also be obtained free of charge from Littelfuse by requesting them by mail at Littelfuse, Inc., 8755 West Higgins Road, Suite 500, Chicago, Illinois 60631, Attention: Investor Relations, or by telephone at (773) 628-1000. The documents filed by IXYS with the SEC may be obtained free of charge at IXYS’ website at www.ixys.com or at the SEC’s website at www.sec.gov. These documents may also be obtained free of charge from IXYS by requesting them by mail at IXYS Corporation, 1590 Buckeye Drive, Milpitas, California 95035, Attention: Investor Relations, or by telephone at (408) 457-9000.

[0001437749-17-017988:8k_2_02:47]
Participants in the Solicitation

[0001437749-17-017988:8k_2_02:48]
IXYS, Littelfuse and certain of their directors, executive officers and employees may be deemed participants in the solicitation of proxies from IXYS stockholders in connection with the proposed transaction. Information regarding the persons who may be deemed to be participants in the solicitation of IXYS stockholders in connection with the proposed transaction, including a description of their direct or indirect interests, by security holdings or otherwise, is set forth in the preliminary proxy statement/prospectus. Information about the directors and executive officers of Littelfuse and their ownership of Littelfuse common stock is set forth in the Littelfuse Annual Report on Form 10-K for the fiscal year ended December 31, 2016, which was filed with the SEC on February 27, 2017, and its definitive proxy statement for the Littelfuse 2017 annual meeting of stockholders, which was filed with the SEC on March 16, 2017. Information about the directors and executive officers of IXYS and their ownership of IXYS common stock is set forth in IXYS’ Annual Report on Form 10-K for the fiscal year ended March 31, 2017, which was filed with the SEC on June 12, 2017, and the definitive proxy statement for IXYS’ 2017 annual meeting of stockholders, which was filed with the SEC on July 28, 2017. Free copies of these documents may be obtained as described in the paragraphs above.

[0001437749-17-017988:8k_2_02:49]
-more-

[0001437749-17-017988:8k_2_02:50]
Non-Solicitation

[0001437749-17-017988:8k_2_02:51]
This communication shall not constitute an offer to sell or the solicitation of an offer to buy any securities, nor shall there be any sale of securities in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of any such jurisdiction. No offer of securities shall be made except by means of a prospectus meeting the requirements of Section 10 of the Securities Act of 1933, as amended.

[0001437749-17-017988:8k_2_02:52]
CONTACT: Meenal Sethna

[0001437749-17-017988:8k_2_02:53]
Executive Vice President and CFO

[0001437749-17-017988:8k_2_02:54]
(773) 628-0616

[0001437749-17-017988:8k_2_02:55]
###

[0001437749-17-017988:8k_2_02:56]
| LITTELFUSE, INC. |
| Net Sales and Operating Income by Segment |
| (In thousands of USD, unaudited) |

[0001437749-17-017988:8k_2_02:57]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 175,899 |  |  | $ | 147,730 |  |  |  | 19% |  |  | $ | 499,052 |  |  | $ | 378,696 |  |  |  | 32% |  |
| Automotive |  |  | 113,797 |  |  |  | 106,341 |  |  |  | 7% |  |  |  | 338,094 |  |  |  | 309,644 |  |  |  | 9% |  |
| Industrial |  |  | 28,193 |  |  |  | 26,260 |  |  |  | 7% |  |  |  | 79,539 |  |  |  | 83,301 |  |  |  | (5%) |  |
| Total net sales |  | $ | 317,889 |  |  | $ | 280,331 |  |  |  | 13% |  |  | $ | 916,685 |  |  | $ | 771,641 |  |  |  | 19% |  |

[0001437749-17-017988:8k_2_02:58]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | % Growth / (Decline) |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 44,345 |  |  | $ | 34,571 |  |  |  | 28% |  |  | $ | 122,518 |  |  | $ | 82,246 |  |  |  | 49% |  |
| Automotive |  |  | 16,821 |  |  |  | 15,032 |  |  |  | 12% |  |  |  | 47,599 |  |  |  | 48,997 |  |  |  | (3%) |  |
| Industrial |  |  | 3,757 |  |  |  | 57 |  |  |  | 6491% |  |  |  | 5,769 |  |  |  | 3,758 |  |  |  | 54% |  |
| Other (1) |  |  | (6,314 | ) |  |  | (22,134 | ) |  |  | (71%) |  |  |  | (8,155 | ) |  |  | (45,345 | ) |  |  | (82%) |  |
| Total operating income |  | $ | 58,609 |  |  | $ | 27,526 |  |  |  | 113% |  |  | $ | 167,731 |  |  | $ | 89,656 |  |  |  | 87% |  |
| Operating margins |  |  | 18.4 | % |  |  | 9.8 | % |  |  |  |  |  |  | 18.3 | % |  |  | 11.6 | % |  |  |  |  |
| Interest expense |  |  | 3,467 |  |  |  | 2,571 |  |  |  |  |  |  |  | 9,868 |  |  |  | 6,286 |  |  |  |  |  |
| Foreign exchange loss (gain) |  |  | 632 |  |  |  | (4,700 | ) |  |  |  |  |  |  | (1,483 | ) |  |  | (7,114 | ) |  |  |  |  |
| Other income, net |  |  | (1,013 | ) |  |  | (778 | ) |  |  |  |  |  |  | (962 | ) |  |  | (1,040 | ) |  |  |  |  |
| Income before taxes |  | $ | 55,523 |  |  | $ | 30,433 |  |  |  | 82% |  |  | $ | 160,308 |  |  | $ | 91,524 |  |  |  | 75% |  |

[0001437749-17-017988:8k_2_02:59]
| (1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details.) |

[0001437749-17-017988:8k_2_02:60]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2017 |  |  | 2016 |  |  | Growth / (Decline) |  |  | 2017 |  |  | 2016 |  |  | Growth / (Decline) |  |
| Operating Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  |  | 25.2 | % |  |  | 23.4 | % |  |  | 1.8 | % |  |  | 24.6 | % |  |  | 21.7 | % |  |  | 2.8 | % |
| Automotive |  |  | 14.8 | % |  |  | 14.1 | % |  |  | 0.6 | % |  |  | 14.1 | % |  |  | 15.8 | % |  |  | (1.7 | %) |
| Industrial |  |  | 13.3 | % |  |  | 0.2 | % |  |  | 13.1 | % |  |  | 7.3 | % |  |  | 4.5 | % |  |  | 2.7 | % |

[0001437749-17-017988:8k_2_02:61]
| LITTELFUSE, INC. |
| Condensed Consolidated Balance Sheets |
| (In thousands of USD) |

[0001437749-17-017988:8k_2_02:62]
|  |  | September 30, 2017 |  |  | December 31, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 372,828 |  |  | $ | 275,124 |  |
| Short-term investments |  |  | 35 |  |  |  | 3,690 |  |
| Accounts receivable, less allowances |  |  | 197,539 |  |  |  | 176,032 |  |
| Inventories |  |  | 136,505 |  |  |  | 114,063 |  |
| Prepaid income taxes and income taxes receivable |  |  | 6,658 |  |  |  | 11,671 |  |
| Prepaid expenses and other current assets |  |  | 45,799 |  |  |  | 31,501 |  |
| Total current assets |  |  | 759,364 |  |  |  | 612,081 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 9,690 |  |  |  | 9,268 |  |
| Buildings |  |  | 86,111 |  |  |  | 80,553 |  |
| Equipment |  |  | 493,361 |  |  |  | 439,542 |  |
|  |  |  | 589,162 |  |  |  | 529,363 |  |
| Accumulated depreciation |  |  | (344,288 | ) |  |  | (312,188 | ) |
| Net property, plant and equipment |  |  | 244,874 |  |  |  | 217,175 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 84,455 |  |  |  | 83,607 |  |
| Distribution network |  |  | 20,329 |  |  |  | 18,995 |  |
| Customer lists, trademarks and tradenames |  |  | 104,738 |  |  |  | 110,425 |  |
| Goodwill |  |  | 451,131 |  |  |  | 403,544 |  |
|  |  |  | 660,653 |  |  |  | 616,571 |  |
| Investments |  |  | 10,582 |  |  |  | 13,933 |  |
| Deferred income taxes |  |  | 17,806 |  |  |  | 20,585 |  |
| Other assets |  |  | 8,913 |  |  |  | 10,849 |  |
| Total assets |  | $ | 1,702,192 |  |  | $ | 1,491,194 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 103,849 |  |  | $ | 90,712 |  |
| Accrued payroll |  |  | 42,131 |  |  |  | 42,810 |  |
| Accrued expenses |  |  | 52,786 |  |  |  | 36,138 |  |
| Accrued severance |  |  | 1,734 |  |  |  | 2,785 |  |
| Accrued income taxes |  |  | 16,281 |  |  |  | 8,846 |  |
| Current portion of long-term debt |  |  | 9,375 |  |  |  | 6,250 |  |
| Total current liabilities |  |  | 226,156 |  |  |  | 187,541 |  |
| Long-term debt, less current portion |  |  | 492,272 |  |  |  | 447,892 |  |
| Deferred income taxes |  |  | 7,719 |  |  |  | 7,066 |  |
| Accrued post-retirement benefits |  |  | 16,571 |  |  |  | 13,398 |  |
| Other long-term liabilities |  |  | 26,230 |  |  |  | 20,366 |  |
| Total equity |  |  | 933,244 |  |  |  | 814,931 |  |
| Total liabilities and equity |  | $ | 1,702,192 |  |  | $ | 1,491,194 |  |

[0001437749-17-017988:8k_2_02:63]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Comprehensive Income |
| (In thousands of USD, except per share data, unaudited) |

[0001437749-17-017988:8k_2_02:64]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | September 30, 2017 |  |  | October 1, 2016 |  |  | September 30, 2017 |  |  | October 1, 2016 |  |
| Net sales |  | $ | 317,889 |  |  | $ | 280,331 |  |  | $ | 916,685 |  |  | $ | 771,641 |  |
| Cost of sales |  |  | 184,238 |  |  |  | 166,572 |  |  |  | 536,776 |  |  |  | 472,861 |  |
| Gross profit |  |  | 133,651 |  |  |  | 113,759 |  |  |  | 379,909 |  |  |  | 298,780 |  |
| Selling, general and administrative expenses |  |  | 56,759 |  |  |  | 56,589 |  |  |  | 156,899 |  |  |  | 150,047 |  |
| Research and development expenses |  |  | 11,991 |  |  |  | 10,403 |  |  |  | 36,872 |  |  |  | 30,884 |  |
| Amortization of intangibles |  |  | 6,292 |  |  |  | 4,432 |  |  |  | 18,407 |  |  |  | 13,384 |  |
| Impairment of goodwill and intangible assets |  |  | - |  |  |  | 14,809 |  |  |  | - |  |  |  | 14,809 |  |
|  |  |  | 75,042 |  |  |  | 86,233 |  |  |  | 212,178 |  |  |  | 209,124 |  |
| Operating income |  |  | 58,609 |  |  |  | 27,526 |  |  |  | 167,731 |  |  |  | 89,656 |  |
| Interest expense |  |  | 3,467 |  |  |  | 2,571 |  |  |  | 9,868 |  |  |  | 6,286 |  |
| Foreign exchange loss (gain) |  |  | 632 |  |  |  | (4,700 | ) |  |  | (1,483 | ) |  |  | (7,114 | ) |
| Other income, net |  |  | (1,013 | ) |  |  | (778 | ) |  |  | (962 | ) |  |  | (1,040 | ) |
| Income before income taxes |  |  | 55,523 |  |  |  | 30,433 |  |  |  | 160,308 |  |  |  | 91,524 |  |
| Income taxes |  |  | 12,715 |  |  |  | (369 | ) |  |  | 29,970 |  |  |  | 14,281 |  |
| Net income |  | $ | 42,808 |  |  | $ | 30,802 |  |  | $ | 130,338 |  |  | $ | 77,243 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.88 |  |  | $ | 1.36 |  |  | $ | 5.75 |  |  | $ | 3.43 |  |
| Diluted |  | $ | 1.87 |  |  | $ | 1.35 |  |  | $ | 5.69 |  |  | $ | 3.41 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,713 |  |  |  | 22,578 |  |  |  | 22,678 |  |  |  | 22,515 |  |
| Diluted |  |  | 22,953 |  |  |  | 22,734 |  |  |  | 22,906 |  |  |  | 22,675 |  |
| Comprehensive income |  | $ | 42,569 |  |  | $ | 25,888 |  |  | $ | 131,575 |  |  | $ | 67,762 |  |

[0001437749-17-017988:8k_2_02:65]
| LITTELFUSE, INC. |
| Condensed Consolidated Statements of Cash Flows |
| (In thousands of USD, unaudited) |

[0001437749-17-017988:8k_2_02:66]
|  |  | For the Nine Months Ended |  |
|  |  | September 30, 2017 |  |  | October 1, 2016 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 130,338 |  |  | $ | 77,243 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 28,228 |  |  |  | 24,841 |  |
| Amortization of intangibles |  |  | 18,407 |  |  |  | 13,384 |  |
| Impairment of intangible assets |  |  | - |  |  |  | 14,809 |  |
| Provision for bad debts |  |  | 1,586 |  |  |  | - |  |
| Impairment of long-lived assets |  |  | - |  |  |  | 1,391 |  |
| Stock-based compensation |  |  | 12,437 |  |  |  | 9,166 |  |
| Non-cash inventory charges |  |  | 1,607 |  |  |  | 7,456 |  |
| Excess tax benefit on stock-based compensation |  |  | - |  |  |  | (2,272 | ) |
| Loss on sale of assets |  |  | 584 |  |  |  | 440 |  |
| Deferred income taxes |  |  | 1,863 |  |  |  | - |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (26,792 | ) |  |  | (17,973 | ) |
| Inventories |  |  | (17,159 | ) |  |  | 4,505 |  |
| Accounts payable |  |  | 9,448 |  |  |  | 7,845 |  |
| Accrued expenses (including post retirement) |  |  | 1,757 |  |  |  | 6,497 |  |
| Accrued payroll and severance |  |  | (3,788 | ) |  |  | 1,388 |  |
| Accrued income taxes |  |  | 7,267 |  |  |  | (23,613 | ) |
| Prepaid expenses and other current assets |  |  | 15,537 |  |  |  | (25,092 | ) |
| Net cash provided by operating activities |  |  | 181,320 |  |  |  | 100,015 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (48,470 | ) |  |  | (34,501 | ) |
| Acquisition of business, net of cash acquired |  |  | (38,610 | ) |  |  | (468,636 | ) |
| Proceeds from maturities of short-term investments |  |  | 3,739 |  |  |  | 345 |  |
| Decrease in entrusted loan receivable |  |  | 3,599 |  |  |  | 4,056 |  |
| Proceeds from sale of assets |  |  | 541 |  |  |  | 255 |  |
| Net cash used in investing activities |  |  | (79,201 | ) |  |  | (498,481 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 15,000 |  |  |  | 258,000 |  |
| Proceeds of term loan |  |  | - |  |  |  | 234,000 |  |
| Payments of revolving credit facility |  |  | (112,500 | ) |  |  | (97,500 | ) |
| Payments of term loan |  |  | (4,687 | ) |  |  | (119,125 | ) |
| Net proceeds from senior notes payable |  |  | 125,000 |  |  |  | - |  |
| Payments of entrusted loan |  |  | (3,599 | ) |  |  | (4,056 | ) |
| Debt issuance costs paid |  |  | (2 | ) |  |  | (1,701 | ) |
| Cash dividends paid |  |  | (23,367 | ) |  |  | (20,405 | ) |
| Net (payments) proceeds related to stock-based award activities |  |  | (2,336 | ) |  |  | 14,581 |  |
| Excess tax benefit on share-based compensation |  |  | - |  |  |  | 2,272 |  |
| Purchases of common stock |  |  | - |  |  |  | (3,685 | ) |
| Net cash (used in) provided by financing activities |  |  | (6,491 | ) |  |  | 262,381 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,076 |  |  |  | 1,793 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 97,704 |  |  |  | (134,292 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275,124 |  |  |  | 328,786 |  |
| Cash and cash equivalents at end of period |  | $ | 372,828 |  |  | $ | 194,494 |  |

[0001437749-17-017988:8k_2_02:67]
| LITTELFUSE, INC. |
| Supplemental Financial Information |
| (in millions of USD except per share amounts) |

[0001437749-17-017988:8k_2_02:68]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-17 |  |  | YTD-17 |  |  | Q3-16 |  |  | YTD-16 |  |
| GAAP diluted EPS |  | $ | 1.87 |  |  | $ | 5.69 |  |  | $ | 1.35 |  |  | $ | 3.41 |  |
| EPS impact of Non-GAAP adjustments (below) |  |  | 0.25 |  |  |  | 0.24 |  |  |  | 0.52 |  |  |  | 1.29 |  |
| Adjusted diluted EPS |  | $ | 2.12 |  |  | $ | 5.93 |  |  | $ | 1.87 |  |  | $ | 4.69 |  |
| Non-GAAP Adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-17 |  |  | YTD-17 |  |  | Q3-16 |  |  | YTD-16 |  |
| Reed switch manufacturing transfer costs |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 1.7 |  |
| Restructuring |  |  | 1.5 |  |  |  | 1.5 |  |  |  | 0.9 |  |  |  | 1.4 |  |
| Acquisition-related and integration costs |  |  | 4.8 |  |  |  | 6.6 |  |  |  | 5.9 |  |  |  | 18.2 |  |
| Product line divestiture costs |  |  |  |  |  |  |  |  |  |  | - |  |  |  | 1.9 |  |
| Impairment of intangible assets |  |  |  |  |  |  |  |  |  |  | 14.8 |  |  |  | 14.8 |  |
| Purchase accounting inventory adjustments |  |  | - |  |  |  | - |  |  |  | 0.5 |  |  |  | 7.4 |  |
| Non-gaap adjustments to operating income |  |  | 6.3 |  |  |  | 8.1 |  |  |  | 22.1 |  |  |  | 45.3 |  |
| Non-operating foreign exchange loss/(gain) |  |  | 0.6 |  |  |  | (1.5 | ) |  |  | (4.7 | ) |  |  | (7.1 | ) |
| Non-gaap adjustments to income before income taxes |  |  | 6.9 |  |  |  | 6.6 |  |  |  | 17.4 |  |  |  | 38.2 |  |
| Income taxes |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 5.7 |  |  |  | 9.0 |  |
| Non-gaap adjustments to net income |  | $ | 5.7 |  |  | $ | 5.4 |  |  | $ | 11.7 |  |  | $ | 29.2 |  |
| Total EPS impact |  | $ | 0.25 |  |  | $ | 0.24 |  |  | $ | 0.52 |  |  | $ | 1.29 |  |
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-17 |  |  | YTD-17 |  |  | Q3-16 |  |  | YTD-16 |  |
| Net sales |  | $ | 317.9 |  |  | $ | 916.7 |  |  | $ | 280.3 |  |  | $ | 771.6 |  |
| GAAP operating income |  | $ | 58.6 |  |  | $ | 167.7 |  |  | $ | 27.5 |  |  | $ | 89.7 |  |
| Add back non-gaap adjustments |  |  | 6.3 |  |  |  | 8.1 |  |  |  | 22.1 |  |  |  | 45.3 |  |
| Adjusted operating income |  | $ | 64.9 |  |  | $ | 175.8 |  |  | $ | 49.6 |  |  | $ | 135.0 |  |
| Adjusted operating margin |  |  | 20.4 | % |  |  | 19.2 | % |  |  | 17.7 | % |  |  | 17.5 | % |
| Add back amortization |  |  | 6.3 |  |  |  | 18.4 |  |  |  | 4.4 |  |  |  | 13.4 |  |
| Add back depreciation |  |  | 9.7 |  |  |  | 28.2 |  |  |  | 8.7 |  |  |  | 24.8 |  |
| Adjusted EBITDA |  | $ | 80.9 |  |  | $ | 222.4 |  |  | $ | 62.7 |  |  | $ | 173.2 |  |
| Adjusted EBITDA margin |  |  | 25.4 | % |  |  | 24.3 | % |  |  | 22.4 | % |  |  | 22.4 | % |

[0001437749-17-017988:8k_2_02:69]
| Net sales reconciliation |  | Q3-17 vs. Q3-16 |  |
|  |  | Electronics |  |  | Automotive |  |  | Industrial |  |  | Total |  |
| Net sales growth |  |  | 19 | % |  |  | 7 | % |  |  | 7 | % |  |  | 13 | % |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions |  |  | 8 | % |  |  | - |  |  |  | - |  |  |  | 4 | % |
| Divestitures |  |  | - |  |  |  | - |  |  |  | (8% | ) |  |  | (1% | ) |
| FX impact |  |  | 1 | % |  |  | 2 | % |  |  | 1 | % |  |  | 1 | % |
| Organic net sales growth |  |  | 11 | % |  |  | 5 | % |  |  | 15 | % |  |  | 9 | % |
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-17 |  |  | YTD-17 |  |  | Q3-16 |  |  | YTD-16 |  |
| Income taxes |  | $ | 12.7 |  |  | $ | 30.0 |  |  | $ | (0.4 | ) |  | $ | 14.3 |  |
| Effective rate |  |  | 22.9 | % |  |  | 18.7 | % |  |  | -1.2 | % |  |  | 15.6 | % |
| Non-GAAP adjustments - income taxes |  |  | 1.3 |  |  |  | 1.2 |  |  |  | 5.7 |  |  |  | 9.1 |  |
| Adjusted income taxes |  | $ | 14.0 |  |  | $ | 31.2 |  |  | $ | 5.3 |  |  | $ | 23.4 |  |
| Adjusted effective rate |  |  | 22.4 | % |  |  | 18.7 | % |  |  | 11.2 | % |  |  | 18.0 | % |
| Free cash flow reconcilation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3-17 |  |  | Q3-16 |  |  | YTD-17 |  |  | YTD-16 |  |
| Net cash provided by operating activities |  | $ | 87.7 |  |  | $ | 64.7 |  |  | $ | 181.3 |  |  | $ | 100.0 |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (20.2 | ) |  |  | (14.3 | ) |  |  | (48.5 | ) |  |  | (34.5 | ) |
| Free cash flow |  | $ | 67.5 |  |  | $ | 50.4 |  |  | $ | 132.8 |  |  | $ | 65.5 |  |

[0001437749-17-017988:8k_2_02:70]
| Note: Totals will not always foot due to rounding |
