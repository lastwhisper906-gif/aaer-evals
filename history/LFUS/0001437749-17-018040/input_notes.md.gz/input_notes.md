# LFUS notes — 0001437749-17-018040


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001437749-17-018040:notes:1]
[same as prior period, unchanged from 0001437749-17-013580:notes:1]

[0001437749-17-018040:notes:2]
The 
Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheet, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

[0001437749-17-018040:notes:3]
[same as prior period, unchanged from 0001437749-17-013580:notes:3]

[0001437749-17-018040:notes:4]
[same as prior period, unchanged from 0001437749-17-013580:notes:4]

[0001437749-17-018040:notes:5]
[same as prior period, unchanged from 0001437749-17-013580:notes:5]

[0001437749-17-018040:notes:6]
[same as prior period, unchanged from 0001437749-17-013580:notes:6]

[0001437749-17-018040:notes:7]
[same as prior period, unchanged from 0001437749-17-013580:notes:7]


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-17-018040:notes:8]
| (in thousands) |  | Three Months Ended October 1, 2016 |  |  | Nine Months Ended October 1, 2016 |  |
| Net sales |  | $ | 290,377 |  |  | $ | 846,127 |  |
| Income before income taxes |  |  | 32,760 |  |  |  | 110,982 |  |
| Net income |  |  | 33,119 |  |  |  | 96,819 |  |
| Net income — basic |  |  | 1.47 |  |  |  | 4.30 |  |
| Net income — diluted |  |  | 1.46 |  |  |  | 4.27 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-17-018040:notes:9]
7.

[0001437749-17-018040:notes:10]
Accumulated Other Comprehensive Income (Loss)

[0001437749-17-018040:notes:11]
The following table sets forth the changes in the components of 
Accumulated Other Comprehensive Income (Loss) by component for the 
nine
 months ended 
 September 30, 2017:

[0001437749-17-018040:notes:12]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments (a) |  |  | Unrealized gain/(loss) on investments |  |  | Foreign currency translation adjustment |  |  | Accumulated other comprehensive income (loss) |  |
| Balance at December 31, 2016 |  | $ | (11,983 | ) |  | $ | 10,769 |  |  | $ | (73,365 | ) |  | $ | (74,579 | ) |
| Activity in the period |  |  | (441 | ) |  |  | (1,235 | ) |  |  | 2,912 |  |  |  | 1,236 |  |
| Balance at September 30, 2017 |  | $ | (12,424 | ) |  | $ | 9,534 |  |  | $ | (70,453 | ) |  | $ | (73,343 | ) |

[0001437749-17-018040:notes:13]
(a) The balances at

[0001437749-17-018040:notes:14]
September 30, 2017 
and 
 December 31, 2016 
are net of taxes of 
$1.2
 million and 
$1.1
 million, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-018040:notes:15]
4

[0001437749-17-018040:notes:16]
. Debt

[0001437749-17-018040:notes:17]
The carrying amounts of debt at

[0001437749-17-018040:notes:18]
September 30, 2017 
and 
 December 31, 2016 
were as follows:

[0001437749-17-018040:notes:19]
| (in thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Revolving credit facility |  | $ | 15,000 |  |  | $ | 112,500 |  |
| Term loan |  |  | 115,625 |  |  |  | 120,313 |  |
| Entrusted loan |  |  | — |  |  |  | 3,522 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 137,670 |  |  |  | 122,313 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 111,784 |  |  |  | 99,314 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (3,432 | ) |  |  | (3,820 | ) |
| Total debt |  |  | 501,647 |  |  |  | 454,142 |  |
| Less: Current maturities |  |  | (9,375 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 492,272 |  |  | $ | 447,892 |  |

[0001437749-17-018040:notes:20]
Revolving Credit Facility / Term Loan

[0001437749-17-018040:notes:21]
On 
 October 13, 2017, 
the Company amended its existing 
Credit Agreement to increase the unsecured revolving credit facility from 
$575.0
 million to 
$700.0
 million and increase the unsecured term loan credit facility from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term loans 
 may 
be made in up to 
two
 advances, the 
first
 advance occurring on 
 October 13, 2017 
and the 
second
 advance, in the aggregate amount 
not
 to exceed 
$75.0
 million, to occur in the 
first
 quarter of 
2018.

[0001437749-17-018040:notes:22]
On 
 March 4, 2016, 
the 
Company entered into a new 
five
 year credit agreement with a group of lenders for up to 
$700.0
 million. The new credit agreement consists of an unsecured revolving credit facility of 
$575.0
 million and an unsecured term loan credit facility of up to 
$125.0
 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of 
$1.6
 million through 
 March 31, 2018 
and 
$3.1
 million from 
 June 30, 2018 
through 
 December 31, 2020 
with the remaining balance due on 
 March 4, 2021.

[0001437749-17-018040:notes:23]
Outstanding borrowings under the credit agreement bear interest, at the 
Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
 month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.30%,
 based on the Consolidated Leverage Ratio, as defined. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
2.73%
 at 
 September 30, 2017.

[0001437749-17-018040:notes:24]
As of

[0001437749-17-018040:notes:25]
September 30, 2017, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$559.9
 million of borrowing capacity under the revolving credit facility. At 
 September 30, 2017, 
the Company was in compliance with all covenants under the credit agreement and expects to remain in compliance based on management’s estimates of operating and financial results for 
2017
 and the foreseeable future.

[0001437749-17-018040:notes:26]
Senior Notes

[0001437749-17-018040:notes:27]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023, 
and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.

[0001437749-17-018040:notes:28]
On 
 December 8, 2016, 
the 
Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February 15, 2017,

[0001437749-17-018040:notes:29]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022, 
and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

[0001437749-17-018040:notes:30]
The Senior Notes have 
not
 been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the 
Company.

[0001437749-17-018040:notes:31]
The Senior Notes are subject to certain customary covenants, including limitations on the 
Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 September 30, 2017, 
the Company was in compliance with all covenants under the revolving credit facility and the Senior Notes.

[0001437749-17-018040:notes:32]
The 
Company 
 may 
redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001437749-17-018040:notes:33]
Entrusted Loan

[0001437749-17-018040:notes:34]
During 
2014,
 the 
Company entered into an entrusted loan arrangement (“Entrusted Loan”) of

[0001437749-17-018040:notes:35]
Chinese renminbi 
110.0
 million (approximately U.S. 
$17.9
 million) between 
two
 of its China legal entities, Littelfuse Semiconductor (“Wuxi”) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between 
two
 commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a 
third
 party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan was reflected as both a long-term asset and long-term debt on the Company’s Condensed Consolidated Balance Sheets and was reflected in the investing and financing activities in its Condensed Consolidated Statements of Cash Flows. Interest expense and interest income are recorded between the lender and borrower with 
no
 net impact on the Company’s Condensed Consolidated Statements of Income since the amounts were offsetting. The loan interest rate per annum is 
5.25%.
 The Entrusted Loan was used to finance the operation and working capital needs of the borrower and was scheduled to mature in 
 November 2019. 
The balance of the Entrusted Loan was paid off as of 
 September 30, 2017.


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-018040:notes:36]
[same as prior period, unchanged from 0001437749-17-013580:notes:30]

[0001437749-17-018040:notes:37]
[same as prior period, unchanged from 0001437749-17-013580:notes:31]

[0001437749-17-018040:notes:38]
[same as prior period, unchanged from 0001437749-17-013580:notes:32]

[0001437749-17-018040:notes:39]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (in thousands, except per share amounts) |  | September 30, 2017 |  |  | October 1, 2016 |  |  | September 30, 2017 |  |  | October 1, 2016 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 42,808 |  |  | $ | 30,802 |  |  | $ | 130,338 |  |  | $ | 77,243 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,713 |  |  |  | 22,578 |  |  |  | 22,678 |  |  |  | 22,515 |  |
| Effect of dilutive securities |  |  | 240 |  |  |  | 156 |  |  |  | 228 |  |  |  | 160 |  |
| Diluted |  |  | 22,953 |  |  |  | 22,734 |  |  |  | 22,906 |  |  |  | 22,675 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.88 |  |  | $ | 1.36 |  |  | $ | 5.75 |  |  | $ | 3.43 |  |
| Diluted earnings per share |  | $ | 1.87 |  |  | $ | 1.35 |  |  | $ | 5.69 |  |  | $ | 3.41 |  |

[0001437749-17-018040:notes:40]
[same as prior period, unchanged from 0001437749-17-013580:notes:34]

[0001437749-17-018040:notes:41]
30,579
 and 
76,845
 for the 
three
 months ended 
 September 30, 2017 
and 
 October 1, 2016, 
respectively, and 
35,858
 and 
45,591
 for the 
nine
 months ended 
 September 30, 2017 
and 
 October 1, 2016, 
respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-17-018040:notes:42]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
| (in thousands) |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,582 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,582 |  |

[0001437749-17-018040:notes:43]
[same as prior period, unchanged from 0001437749-17-013580:notes:37]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001437749-17-018040:notes:44]
|  |  | September 30, 2017 |  |  | December 31, 2016 |  |
| (in thousands) |  | Carrying Value |  |  | Estimated Fair Value |  |  | Carrying Value |  |  | Estimated Fair Value |  |
| Euro Senior Notes, Series A due 2023 |  | $ | 137,670 |  |  | $ | 137,581 |  |  | $ | 122,313 |  |  | $ | 122,586 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 111,784 |  |  |  | 110,550 |  |  |  | 99,314 |  |  |  | 99,230 |  |
| USD Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 24,938 |  |  |  | — |  |  |  | — |  |
| USD Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 99,884 |  |  |  | — |  |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-17-018040:notes:45]
[same as prior period, unchanged from 0001437749-17-013580:notes:39]

[0001437749-17-018040:notes:46]
[same as prior period, unchanged from 0001437749-17-013580:notes:40]

[0001437749-17-018040:notes:47]
[same as prior period, unchanged from 0001437749-17-013580:notes:41]

[0001437749-17-018040:notes:48]
[same as prior period, unchanged from 0001437749-17-013580:notes:42]

[0001437749-17-018040:notes:49]
[same as prior period, unchanged from 0001437749-17-013580:notes:43]

[0001437749-17-018040:notes:50]
[same as prior period, unchanged from 0001437749-17-013580:notes:44]

[0001437749-17-018040:notes:51]
[same as prior period, unchanged from 0001437749-17-013580:notes:45]

[0001437749-17-018040:notes:52]
[same as prior period, unchanged from 0001437749-17-013580:notes:46]

[0001437749-17-018040:notes:53]
[same as prior period, unchanged from 0001437749-17-013580:notes:47]

[0001437749-17-018040:notes:54]
[same as prior period, unchanged from 0001437749-17-013580:notes:48]

[0001437749-17-018040:notes:55]
[same as prior period, unchanged from 0001437749-17-013580:notes:49]

[0001437749-17-018040:notes:56]
[same as prior period, unchanged from 0001437749-17-013580:notes:50]

[0001437749-17-018040:notes:57]
[same as prior period, unchanged from 0001437749-17-013580:notes:51]

[0001437749-17-018040:notes:58]
[same as prior period, unchanged from 0001437749-17-013580:notes:52]

[0001437749-17-018040:notes:59]
There were 
no
 changes during 
the quarter ended 
 September 30, 2017 
to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of 
 September 30, 2017 
and 
 December 31, 2016, 
the Company did

[0001437749-17-018040:notes:60]
[same as prior period, unchanged from 0001437749-17-013580:notes:54]

[0001437749-17-018040:notes:61]
[same as prior period, unchanged from 0001437749-17-013580:notes:55]

[0001437749-17-018040:notes:62]
[same as prior period, unchanged from 0001437749-17-013580:notes:57]

[0001437749-17-018040:notes:63]
September 30, 2017:

[0001437749-17-018040:notes:64]
[same as prior period, unchanged from 0001437749-17-013580:notes:58]

[0001437749-17-018040:notes:65]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are 
not
 marked to market on a recurring basis. 
The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at 
 September 30, 2017 
and 
 December 31, 2016, 
as the rates on these borrowings are variable in nature.

[0001437749-17-018040:notes:66]
The carrying value and estimated fair values of the 
Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of 
 September 30, 2017 
and 
 December 31, 2016 
were as follows:


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001437749-17-018040:notes:67]
[same as prior period, unchanged from 0001437749-17-013580:notes:61]

[0001437749-17-018040:notes:68]
[same as prior period, unchanged from 0001437749-17-013580:notes:62]

[0001437749-17-018040:notes:69]
Factors the 
Company considers important when performing the impairment tests, which could result in changes to its estimates, include underperformance relative to historical or projected future operating results and declines in acquisitions and trading multiples. Due to the diverse end user base and non-discretionary product demand, the Company does 
not
 believe its future operating results will vary significantly relative to its historical and projected future operating results. However, it is possible that impairment charges could be recognized for the Relays reporting unit if there are declines in profitability or projected future operating results and cash flows due to changes in volume, market pricing, cost, or the business environment. As of the most recent annual test conducted on 
 October 2, 2016, 
the Company concluded the fair value of the Relays reporting unit exceeded its carrying value of invested capital and therefore, 
no
 potential goodwill impairment existed. As of the 
2016
 annual test date, the Relays reporting unit had 
$41.4
 million of goodwill and intangible assets and the excess of fair value over the carrying value of invested capital was 
15%.
 As of 
 September 30, 2017, 
there were 
no
 events or circumstances that indicate the Relays intangible assets were impaired.

[0001437749-17-018040:notes:70]
In the 
third
 quarter of 
2016,
 due to continued declines in the potash market the Company conducted a goodwill impairment analysis of the Custom Products reporting unit and concluded that the 
reporting unit was impaired. The fair value of the unit was estimated using the expected present value of future cash flows over a 
seven
 year forecast period and appraisal of certain assets. This analysis required a write down of the reporting unit’s carrying value of 
$14.8
 million. A goodwill impairment loss of 
$8.8
 million and intangible assets impairments aggregating 
$6.0
 million were recognized during the 
third
 quarter, including a 
$3.8
 million reduction of the custom products trade names to a 
$0.7
 million remaining value and a 
$2.2
 million reduction of the reporting unit’s customer relationships to 
zero
 value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-018040:notes:71]
[same as prior period, unchanged from 0001437749-17-013580:notes:64]

[0001437749-17-018040:notes:72]
The effective tax rates for the

[0001437749-17-018040:notes:73]
three
 and 
nine
 months ended 
 September 30, 2017 
was 
22.9%
 and 
18.7%,
 respectively, compared to effective tax rates for the 
three
 and 
nine
 months ended 
 October 1, 2016 
of (
1.2%
) and 
15.6%,
 respectively. The effective tax rates for the 
2017
 periods are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by a forecasted accrual for taxes on undistributed current year-earnings of certain non-US affiliates. The effective tax rate for the 
2016
 periods are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions and a 
one
-time deduction with respect to the stock of 
one
 of the company’s affiliates partially offset by the impact of the impairment of goodwill for which 
no
 tax benefit was recorded.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-17-018040:notes:74]
[same as prior period, unchanged from 0001437749-17-013580:notes:67]

[0001437749-17-018040:notes:75]
[same as prior period, unchanged from 0001437749-17-013580:notes:68]

[0001437749-17-018040:notes:76]
[same as prior period, unchanged from 0001437749-17-013580:notes:69]

[0001437749-17-018040:notes:77]
| (in thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Raw materials |  | $ | 38,320 |  |  | $ | 32,231 |  |
| Work in process |  |  | 28,477 |  |  |  | 23,354 |  |
| Finished goods |  |  | 69,708 |  |  |  | 58,478 |  |
| Total |  | $ | 136,505 |  |  | $ | 114,063 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-17-018040:notes:78]
[same as prior period, unchanged from 0001437749-17-013580:notes:71]

[0001437749-17-018040:notes:79]
[same as prior period, unchanged from 0001437749-17-013580:notes:72]

[0001437749-17-018040:notes:80]
The 
Company accounts for acquisitions using the acquisition method in accordance with ASC 
805,
 “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. These acquisitions were recorded by allocating the cost of the acquisition to the assets acquired, including other intangible assets, based on their estimate fair values at the acquisition date. The excess of the cost over the net amounts assigned to the fair value of the assets acquired was recorded as goodwill. The goodwill associated with these acquisitions is primarily attributable to the synergies expected to arise as a result of these acquisitions. The operating results of the acquired business are included in the Company’s condensed consolidated financial statements from the date of the acquisition.

[0001437749-17-018040:notes:81]
2017
 Acquisitions

[0001437749-17-018040:notes:82]
IXYS Corporation

[0001437749-17-018040:notes:83]
On 
 August

[0001437749-17-018040:notes:84]
28,

[0001437749-17-018040:notes:85]
2017,
 the Company announced that it had entered in a definitive agreement to acquire IXYS Corporation (“IXYS”), a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 
3,500
 customers through its direct salesforce and global distribution partners.

[0001437749-17-018040:notes:86]
The Company will acquire all outstanding shares of common stock of IXYS in exchange for a combination of cash and shares of common stock of the Company. Each IXYS stockholder will be entitled to elect to receive, per IXYS share, either 
$23.00
 in cash or 
0.1265
 of a share of Littelfuse common stock, subject to proration. In total, 
50%
 of IXYS stock will be converted into the cash election option and the remaining will be converted into the stock election option. The 
equity value of the transaction at the announcement was approximately 
$750
 million. The exchange ratio is fixed and will 
not
 be adjusted for changes in the market value of shares of Littelfuse or IXYS common stock. The market values of Littelfuse common stock and number of outstanding shares of IXYS common stock and equity-based awards will continue to fluctuate until the acquisition is completed. As a result, the final purchase price will differ from the initially announced purchase price, and that difference 
 may 
be material.

[0001437749-17-018040:notes:87]
The transaction is expected to close in the 
first
 calendar quarter of 
2018
 and is subject to the satisfaction of customary closing conditions, including regulatory approvals and approval by IXYS stockholders.
  The Company expects to finance the cash portion of the transaction consideration through a combination of existing cash and additional debt.

[0001437749-17-018040:notes:88]
U.S. Sensor

[0001437749-17-018040:notes:89]
O
n 
 July 7, 2017, 
the Company acquired the assets of U.S. Sensor Corporation (“U.S. Sensor”) for 
$24.4
 million. The Company funded the acquisition with available cash

[0001437749-17-018040:notes:90]
. The final purchase price is subject to adjustment for finalization of income tax gross up which is expected to be settled in the 
fourth
 quarter of 
2017.
 The acquired business

[0001437749-17-018040:notes:91]
expands the Company’s existing sensor portfolio in several key electronics and industrial end markets. U.S. Sensor manufactures a variety of high quality negative temperature coefficient thermistors as well as thermistor probes and assemblies. Product lines also include thin film platinum resistance temperature detectors (“RTDs”) and RTD assemblies.

[0001437749-17-018040:notes:92]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the U.S. Sensor acquisition:

[0001437749-17-018040:notes:93]
| (in thousands) |  | Purchase Price Allocation |  |
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 24,439 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 4,755 |  |
| Patented and unpatented technologies |  |  | 1,090 |  |
| Trademarks and tradenames |  |  | 200 |  |
| Non-compete agreement |  |  | 50 |  |
| Customer relationships |  |  | 2,830 |  |
| Goodwill |  |  | 16,054 |  |
| Current liabilities |  |  | (540 | ) |
|  |  | $ | 24,439 |  |

[0001437749-17-018040:notes:94]
All U.S. Sensor goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the Company
’s expected future product sales and synergies from combining U.S. Sensor’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-17-018040:notes:95]
As required by purchase accounting rules, the Company recorded a 
$1.6
 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. 
The step-up was amortized as a non-cash charge to cost of goods sold during the 
third
 quarter of 
2017,
 as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-17-018040:notes:96]
[same as prior period, unchanged from 0001437749-17-013580:notes:74]

[0001437749-17-018040:notes:97]
[same as prior period, unchanged from 0001437749-17-013580:notes:75]

[0001437749-17-018040:notes:98]
[same as prior period, unchanged from 0001437749-17-013580:notes:76]

[0001437749-17-018040:notes:99]
The additional investment resulted in the 
Company gaining control of Monolith and was accounted for as a step-acquisition with the fair value of the original investment immediately before the acquisition estimated to be approximately 
$3.5
 million. As the fair value of the investment immediately prior to the transaction equaled the carrying value, there was 
no
 impact on the Company’s condensed consolidated statement of net income. As the Securities Purchase Agreement includes an obligation of the Company to mandatorily redeem the non-controlling interest for cash, the fair value of the non-controlling interest was recognized as a liability on the Company’s condensed consolidated balance sheet. Changes in the fair value of the non-controlling interest are recognized in the Company’s condensed consolidated statements of net income.

[0001437749-17-018040:notes:100]
Commencing 
 March 1, 2017, 
Monolith was reflected as a consolidated subsidiary within the 
Company’s condensed consolidated financial statements. Had the acquisition occurred as of 
 January

[0001437749-17-018040:notes:101]
[same as prior period, unchanged from 0001437749-17-013580:notes:79]

[0001437749-17-018040:notes:102]
[same as prior period, unchanged from 0001437749-17-013580:notes:80]

[0001437749-17-018040:notes:103]
[same as prior period, unchanged from 0001437749-17-013580:notes:81]

[0001437749-17-018040:notes:104]
[same as prior period, unchanged from 0001437749-17-013580:notes:82]

[0001437749-17-018040:notes:105]
All Monolith goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the United States geographic area. The goodwill resulting from this acquisition consists largely of the 
Company’s expected future product sales and synergies from combining Monolith’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is 
not
 expected to be deductible for tax purposes.

[0001437749-17-018040:notes:106]
The purchase price allocations for U.S. Sensor and Monolith are preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary areas that are 
not
 yet finalized relate to the completion of the independent valuations of 
other intangible assets.

[0001437749-17-018040:notes:107]
2016
 Acquisitions

[0001437749-17-018040:notes:108]
[same as prior period, unchanged from 0001437749-17-013580:notes:84]

[0001437749-17-018040:notes:109]
On 
 August 29, 2016, 
the 
Company acquired certain assets of select businesses (the “ON Portfolio”) of ON Semiconductor Corporation for 
$104.0
 million. The Company funded the acquisition with available cash and proceeds from its credit facility

[0001437749-17-018040:notes:110]
[same as prior period, unchanged from 0001437749-17-013580:notes:86]

[0001437749-17-018040:notes:111]
[same as prior period, unchanged from 0001437749-17-013580:notes:87]

[0001437749-17-018040:notes:112]
The following table summarizes the 
final purchase price allocation of the fair value of assets acquired and liabilities assumed in the ON Portfolio acquisition:

[0001437749-17-018040:notes:113]
[same as prior period, unchanged from 0001437749-17-013580:notes:89]

[0001437749-17-018040:notes:114]
[same as prior period, unchanged from 0001437749-17-013580:notes:90]

[0001437749-17-018040:notes:115]
[same as prior period, unchanged from 0001437749-17-013580:notes:91]

[0001437749-17-018040:notes:116]
[same as prior period, unchanged from 0001437749-17-013580:notes:92]

[0001437749-17-018040:notes:117]
[same as prior period, unchanged from 0001437749-17-013580:notes:93]

[0001437749-17-018040:notes:118]
On 
 April 4, 2016, 
the 
Company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy for 
$19.2
 million, net of acquired cash and after settlement of a working capital adjustment. The Company funded the acquisition with cash on hand and borrowings under the Company’s revolving credit facility. The acquired business is part of the Company's commercial vehicle product business within the Automotive segment and specializes in the design, manufacturing, and selling of manual and electrical high current switches and trailer connectors for commercial vehicles. The acquisition expands the Company’s commercial vehicle products business globally.

[0001437749-17-018040:notes:119]
The following table summarizes the 
final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Menber’s acquisition:

[0001437749-17-018040:notes:120]
[same as prior period, unchanged from 0001437749-17-013580:notes:96]

[0001437749-17-018040:notes:121]
[same as prior period, unchanged from 0001437749-17-013580:notes:97]

[0001437749-17-018040:notes:122]
[same as prior period, unchanged from 0001437749-17-013580:notes:98]

[0001437749-17-018040:notes:123]
[same as prior period, unchanged from 0001437749-17-013580:notes:99]

[0001437749-17-018040:notes:124]
On 
 March 25, 2016, 
the 
Company acquired 
100%
 of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for 
$348.3
 million, net of acquired cash and after settlement of certain post-closing adjustments. In the 
second
 quarter of 
2017,
 the Company paid the final consideration of 
$3.8
 million. The Company funded the acquisition with available cash on hand and borrowings under the Company’s revolving credit facility. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-17-018040:notes:125]
[same as prior period, unchanged from 0001437749-17-013580:notes:101]

[0001437749-17-018040:notes:126]
The following table summarizes the 
final purchase price allocation of the fair value of assets acquired and liabilities assumed in the PolySwitch acquisition:

[0001437749-17-018040:notes:127]
[same as prior period, unchanged from 0001437749-17-013580:notes:103]

[0001437749-17-018040:notes:128]
All PolySwitch goodwill and other assets and liabilities were recorded in the Electronics and Automotive segments and reflected in all geographic areas. The customer relationships are being amortized over 
15
 years. The patented and unpatented technologies are being amortized over 
10
 years. The goodwill resulting from this acquisition consists largely of the 
Company’s expected future product sales and synergies from combining PolySwitch products with the Company’s existing automotive and electronics product portfolio. 
$103.8
 million and 
$61.3
 million of the goodwill for the above acquisition has been assigned to the Electronics and Automotive segments, respectively, with 
$64.9
 million expected to be deductible for tax purposes.

[0001437749-17-018040:notes:129]
[same as prior period, unchanged from 0001437749-17-013580:notes:105]

[0001437749-17-018040:notes:130]
[same as prior period, unchanged from 0001437749-17-013580:notes:106]

[0001437749-17-018040:notes:131]
The following table summarizes, on a pro forma basis, the combined results of operations of the 
Company and the acquired PolySwitch and the ON Portfolio businesses for the 
three
 months and 
nine
 months ended 
 October 1, 2016 
as though the acquisitions had occurred as of 
 January 3, 2016. 
The Company has 
not
 included pro forma results of operations for Menber’s, Monolith, or U.S. Sensors as these results were 
not
 material to the Company. The pro forma amounts presented are 
not
 necessarily indicative of either the actual consolidated results had the PolySwitch or ON Portfolio acquisitions occurred as of 
 January 3, 2016 
or of future consolidated operating results.

[0001437749-17-018040:notes:132]
Pro forma results presented above primarily reflect: (i) incremental depreciation relating to fair value adjustments to property, plant, and equipment; (ii) amortization adjustments relating to fair value estimates of intangible assets; (iii) incremental interest expense on assumed indebtedness; and (iv) additional cost of goods sold relating to the capitalization of gross profit as part of purchase accounting recognized for purposes of the pro forma as if it was recognized during the 
Company’s 
first
 quarter of 
2016.
 Pro forma adjustments described above have been tax affected using the Company's effective rate during the respective periods.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-17-018040:notes:133]
Recently Adopted Accounting Standards

[0001437749-17-018040:notes:134]
In 
 July 2015, 
the Financial Accounting Standards Board (
“FASB”) issued Accounting Standards Update (“ASU”) 
No.

[0001437749-17-018040:notes:135]
2015
-
11
 – “Inventory (Topic 
330
): Simplifying the Measurement of Inventory,” which simplifies the measurement of inventory by requiring inventory to be measured at the lower of cost and net realizable value. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
The adoption of the update did 
not
 have a material impact on the Company’s consolidated financial position and results of operations. As a result of the adoption of the update, inventories are stated at the lower of cost or net realizable value. Cost is principally determined using the 
first
-in, 
first
-out method. The Company maintains excess and obsolete allowances against inventory to reduce the carrying value to the expected net realizable value. These allowances are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

[0001437749-17-018040:notes:136]
In 
 March 2016, 
the FASB issued ASU 
No.

[0001437749-17-018040:notes:137]
2016
-
09

[0001437749-17-018040:notes:138]
– “Improvements to Employee Share-Based Payment Accounting,” which amends ASC 
718,
 “Compensation – Stock Compensation.” The update simplifies several aspects of the accounting for employee share-based payment transactions, including accounting for income taxes, forfeitures, and statutory withholding requirements, as well as classification in the Condensed Consolidated Statements of Cash Flows. The update is effective for financial statements issued for fiscal years beginning after 
 December 15, 2016, 
and interim periods within those fiscal years. The Company adopted the new standard on 
 January 1, 2017. 
As a result of the adoption, on a prospective basis, the Company recognized 
$0.1
 million and 
$1.9
 million of excess tax benefits from stock-based compensation as a discrete item in income tax expense for the 
three
 and 
nine
 months ended 
 September 30, 2017, 
respectively. Historically, these amounts were recorded as additional paid-in capital. The Company also elected to apply the change prospectively to the Condensed Consolidated Statement of Cash Flows. As a result, on a prospective basis, share-based payments will be reported as operating activities in the Condensed Consolidated Statement of Cash Flows. The Company elected 
not
 to change its policy on accounting for forfeitures and will continue to estimate a requisite forfeiture rate. Additional amendments to the accounting for income taxes and minimum statutory withholding requirements had 
no
 impact on the results of operations.

[0001437749-17-018040:notes:139]
Recently Issued Accounting Standards

[0001437749-17-018040:notes:140]
In 
 March 2017, 
the FASB issued ASU

[0001437749-17-018040:notes:141]
No.

[0001437749-17-018040:notes:142]
2017
-
07
 “Compensation-Retirement Benefits (Topic 
715
): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changes the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the current guidance, net benefit cost is reported as an employee cost within operating income. The amendment requires the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU 
No.

[0001437749-17-018040:notes:143]
2017
-
07
 will be effective for the 
first
 quarter of 
2018
 and is required to be retrospectively adopted. Had this guidance been adopted as of 
 January 1, 2017, 
operating income within the Condensed Consolidated Statements of Income for the 
three
 months and 
nine
 months ended 
 September 30, 2017 
would have 
not
 changed by a material amount.

[0001437749-17-018040:notes:144]
In 
 January 2017, 
the FASB issued ASU 
No.

[0001437749-17-018040:notes:145]
2017
-
04,
 “Intangibles-Goodwill and Other” (Topic 
350
). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity 
no
 longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 
2
 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after 
 December 15, 2020, 
with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after 
 January 1, 2017.

[0001437749-17-018040:notes:146]
The Company expects to adopt the new standard in 
2017.

[0001437749-17-018040:notes:147]
In 
 January 2016, 
the FASB issued ASU 
No.

[0001437749-17-018040:notes:148]
2016
-
01,
 “
Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU will require the Company to recognize any changes in the fair value of certain equity investments in net income. These changes are currently recognized in other comprehensive income ("OCI"). This guidance is effective for interim and fiscal years beginning after 
 December 15, 2017.

[0001437749-17-018040:notes:149]
In 
 May 2014, 
the FASB issued ASU 
No.

[0001437749-17-018040:notes:150]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. In 
 August, 2015, 
the FASB issued ASU 
No.

[0001437749-17-018040:notes:151]
2015
-
14,
 which postponed the effective date of ASU 
No.

[0001437749-17-018040:notes:152]
2014
-
09
 to fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2017, 
with early adoption permitted on the original effective date of fiscal years beginning after 
 December 15, 2016. 
The Company is in the process of performing its assessment of the potential impact on its consolidated financial statements, and anticipates adopting this standard using the modified retrospective method. While the Company is currently assessing the impact of the new standard, the Company’s revenue is primarily generated from the sale of finished products to customers. Those sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does 
not
 expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects 
 may 
be affected. The Company has 
not
 yet quantified this potential impact.

[0001437749-17-018040:notes:153]
In 
 February 2016, 
the FASB issued ASU 
No.

[0001437749-17-018040:notes:154]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition, however the Company plans to adopt the standard in the 
first
 quarter of 
2019.
 The Company is currently evaluating the impact of ASU 
2016
-
02.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-17-018040:notes:155]
[same as prior period, unchanged from 0001437749-17-013580:notes:127]

[0001437749-17-018040:notes:156]
[same as prior period, unchanged from 0001437749-17-013580:notes:128]

[0001437749-17-018040:notes:157]
[same as prior period, unchanged from 0001437749-17-013580:notes:129]

[0001437749-17-018040:notes:158]
[same as prior period, unchanged from 0001437749-17-013580:notes:130]

[0001437749-17-018040:notes:159]
and 
nine
 months ended 
 September 30, 2017 
and 
 October 1, 2016 
were as follows:

[0001437749-17-018040:notes:160]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (in thousands) |  | September 30, 2017 |  |  | October 1, 2016 |  |  | September 30, 2017 |  |  | October 1, 2016 |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 408 |  |  | $ | 332 |  |  | $ | 1,224 |  |  | $ | 997 |  |
| Interest cost |  |  | 360 |  |  |  | 496 |  |  |  | 1,080 |  |  |  | 1,489 |  |
| Expected return on plan assets |  |  | (476 | ) |  |  | (520 | ) |  |  | (1,428 | ) |  |  | (1,560 | ) |
| Amortization, net |  |  | 84 |  |  |  | 74 |  |  |  | 252 |  |  |  | 220 |  |
| Net periodic benefit cost |  | $ | 376 |  |  | $ | 382 |  |  | $ | 1,128 |  |  | $ | 1,146 |  |

[0001437749-17-018040:notes:161]
[same as prior period, unchanged from 0001437749-17-013580:notes:133]

[0001437749-17-018040:notes:162]
4.5%
 and 
4.9%
 in 
2017
 and 
2016,
 respectively. The Company does 
not
 expect to make cash contributions to its pension plans in 
2017.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-17-018040:notes:163]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (in thousands) |  | September 30, 2017 |  |  | October 1, 2016 |  |  | September 30, 2017 |  |  | October 1, 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 103,233 |  |  | $ | 92,475 |  |  | $ | 290,538 |  |  | $ | 270,659 |  |
| China(a) |  |  | 82,986 |  |  |  | 70,215 |  |  |  | 240,731 |  |  |  | 181,134 |  |
| Other countries |  |  | 131,670 |  |  |  | 117,641 |  |  |  | 385,416 |  |  |  | 319,848 |  |
| Total net sales |  | $ | 317,889 |  |  | $ | 280,331 |  |  | $ | 916,685 |  |  | $ | 771,641 |  |

[0001437749-17-018040:notes:164]
| (in thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 23,922 |  |  | $ | 23,731 |  |
| China(a) |  |  | 80,616 |  |  |  | 65,345 |  |
| Mexico |  |  | 61,664 |  |  |  | 52,262 |  |
| Philippines |  |  | 30,760 |  |  |  | 33,345 |  |
| Other countries |  |  | 47,912 |  |  |  | 42,492 |  |
| Total long-lived assets |  | $ | 244,874 |  |  | $ | 217,175 |  |

[0001437749-17-018040:notes:165]
|  |  | For the Nine Months Ended |  |
| (in thousands) |  | September 30, 2017 |  |  | October 1, 2016 |  |
| Additions to long-lived assets |  |  |  |  |  |  |  |  |
| United States |  | $ | 2,752 |  |  | $ | 4,485 |  |
| China(a) |  |  | 22,165 |  |  |  | 8,272 |  |
| Mexico |  |  | 15,041 |  |  |  | 12,312 |  |
| Philippines |  |  | 2,018 |  |  |  | 4,054 |  |
| Other countries |  |  | 6,494 |  |  |  | 5,378 |  |
| Total additions to long-lived assets |  | $ | 48,470 |  |  | $ | 34,501 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-018040:notes:166]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (in thousands) |  | September 30, 2017 |  |  | October 1, 2016 |  |  | September 30, 2017 |  |  | October 1, 2016 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 175,899 |  |  | $ | 147,730 |  |  | $ | 499,052 |  |  | $ | 378,696 |  |
| Automotive |  |  | 113,797 |  |  |  | 106,341 |  |  |  | 338,094 |  |  |  | 309,644 |  |
| Industrial |  |  | 28,193 |  |  |  | 26,260 |  |  |  | 79,539 |  |  |  | 83,301 |  |
| Total net sales |  | $ | 317,889 |  |  | $ | 280,331 |  |  | $ | 916,685 |  |  | $ | 771,641 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 8,986 |  |  | $ | 7,694 |  |  | $ | 26,080 |  |  | $ | 20,783 |  |
| Automotive |  |  | 5,622 |  |  |  | 4,627 |  |  |  | 16,572 |  |  |  | 12,881 |  |
| Industrial |  |  | 1,338 |  |  |  | 1,733 |  |  |  | 3,982 |  |  |  | 4,561 |  |
| Other |  |  | — |  |  |  | (937 | ) |  |  | — |  |  |  | — |  |
| Total depreciation and amortization |  | $ | 15,946 |  |  | $ | 13,117 |  |  | $ | 46,634 |  |  | $ | 38,225 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 44,345 |  |  | $ | 34,571 |  |  | $ | 122,518 |  |  | $ | 82,246 |  |
| Automotive |  |  | 16,821 |  |  |  | 15,032 |  |  |  | 47,599 |  |  |  | 48,997 |  |
| Industrial |  |  | 3,757 |  |  |  | 57 |  |  |  | 5,769 |  |  |  | 3,758 |  |
| Other(a) |  |  | (6,314 | ) |  |  | (22,134 | ) |  |  | (8,155 | ) |  |  | (45,345 | ) |
| Total operating income |  |  | 58,609 |  |  |  | 27,526 |  |  |  | 167,731 |  |  |  | 89,656 |  |
| Interest expense |  |  | 3,467 |  |  |  | 2,571 |  |  |  | 9,868 |  |  |  | 6,286 |  |
| Foreign exchange loss (gain) |  |  | 632 |  |  |  | (4,700 | ) |  |  | (1,483 | ) |  |  | (7,114 | ) |
| Other income, net |  |  | (1,013 | ) |  |  | (778 | ) |  |  | (962 | ) |  |  | (1,040 | ) |
| Income before income taxes |  | $ | 55,523 |  |  | $ | 30,433 |  |  | $ | 160,308 |  |  | $ | 91,524 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-018040:notes:167]
[same as prior period, unchanged from 0001437749-17-013580:notes:140]

[0001437749-17-018040:notes:168]
[same as prior period, unchanged from 0001437749-17-013580:notes:141]

[0001437749-17-018040:notes:169]
[same as prior period, unchanged from 0001437749-17-013580:notes:142]

[0001437749-17-018040:notes:170]
[same as prior period, unchanged from 0001437749-17-013580:notes:143]

[0001437749-17-018040:notes:171]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the 
three
 operating segments.
  The Company does 
not
 report inter-segment revenue because the operating segments do 
not
 record it.  Certain expenses, determined by the CODM to be strategic in nature and 
not
 directly related to segments current results, are 
not
 allocated but identified as “Other”.  Additionally, the Company does 
not
 allocate interest and other income, interest expense, or taxes to operating segments.  These costs are 
not
 allocated to the segments, as management excludes such costs when assessing the performance of the segments.  Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in 
one
 segment 
 may 
benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001437749-17-018040:notes:172]
|  | ● | Electronics Segment: Provides circuit protection components for overcurrent and overvoltage protection, as well as power control products and sensor components and modules to leading global manufacturers of a wide range of electronic products. The segment covers a broad range of end markets, including consumer electronics, telecommunications equipment, medical devices, lighting products, and white goods. The Electronics segment supplies circuit protection, sensing and control products to various leading manufacturers. The Electronics segment has one of the broadest product offerings in the industry including fuses and protectors, positive temperature coefficient (“PTC”) resettable fuses, varistors, polymer electrostatic discharge (“ESD”) suppressors, discrete TVS diodes, TVS diode arrays protection and switching thyristors, gas discharge tubes, power switching components, fuseholders, reed switch and sensor assemblies, IGBT blocks, and related accessories. |

[0001437749-17-018040:notes:173]
[same as prior period, unchanged from 0001437749-17-013580:notes:146]

[0001437749-17-018040:notes:174]
[same as prior period, unchanged from 0001437749-17-013580:notes:147]

[0001437749-17-018040:notes:175]
Segment information is summarized as follows:

[0001437749-17-018040:notes:176]
| (a) | Included in “Other” Operating income (loss) for the 2017 third quarter is $4.8 million ($6.6 million year-to-date) of acquisition-related and integration charges associated with the company’s acquisitions, including $1.6 million ($1.6 million year-to-date) of purchase accounting inventory charges related to the company’s 2017 acquisition of US Sensor as described in Note 2 and $1.5 million ($1.5 million year-to-date) of charges related to restructuring and production transfers in our Asia operations. |
|  | Included in “Other” Operating income (loss) for the 2016 third quarter is $14.8 million (14.8 million year-to-date) of charges related to the impairment of goodwill and other intangible assets within the custom products reporting unit, $5.9 million ($18.2 million year-to-date) of acquisition-related and integration charges associated with the company’s 2016 acquisitions, $0.6 million ($7.5 million year-to-date) of non-cash inventory charges relating to the company’s 2016 acquisitions as described in Note 2, $1.9 million year-to-date in charges related to the closure of the company’s manufacturing facility in Denmark, $1.7 million year-to-date related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.9 million ($1.3 million year-to-date) related to internal legal restructuring costs. |

[0001437749-17-018040:notes:177]
The 
Company’s net sales by country were as follows:

[0001437749-17-018040:notes:178]
(a) 
Included in China are net sales in China and Hong Kong.

[0001437749-17-018040:notes:179]
The 
Company’s long-lived assets by country, as of 
 September 30, 2017 
and 
 December 31, 2016, 
were as follows:

[0001437749-17-018040:notes:180]
(a) 
Included in China are long-lived assets in China and Hong Kong.

[0001437749-17-018040:notes:181]
The 
Company’s additions to long-lived assets by country were as follows:

[0001437749-17-018040:notes:182]
(a) 
Included in China are additions to long-lived assets in China and Hong Kong.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-17-018040:notes:183]
[same as prior period, unchanged from 0001437749-17-013580:notes:159]

[0001437749-17-018040:notes:184]
[same as prior period, unchanged from 0001437749-17-013580:notes:160]

[0001437749-17-018040:notes:185]
Littelfuse, Inc. and subsidiaries (the “
Company”) is 
one
 of the world’s leading designer, manufacturer and supplier of circuit protection products, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance. The Company’s products protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment.
