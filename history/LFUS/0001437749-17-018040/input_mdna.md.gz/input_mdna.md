# LFUS MD&A — 0001437749-17-018040


## mdna

[0001437749-17-018040:mdna:1]
[same as prior period, unchanged from 0001437749-17-013580:mdna:1]

[0001437749-17-018040:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-17-018040:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-018040:mdna:4]
[same as prior period, unchanged from 0001437749-17-013580:mdna:4]

[0001437749-17-018040:mdna:5]
[same as prior period, unchanged from 0001437749-17-013580:mdna:5]

[0001437749-17-018040:mdna:6]
Littelfuse, Inc. and subsidiaries (the “Company”) is one of the world’s leading designer, manufacturer and supplier of circuit protection products, with expanding platforms in sensors and power control components and modules. In addition to circuit protection products and solutions, the Company offers electronic reed switches and sensors, automotive sensors for comfort and safety systems and a comprehensive line of highly reliable electromechanical and electronic switch and control devices for commercial and specialty vehicles, as well as protection relays and power distribution centers for the safe control and distribution of electricity. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provide customer application support and test products for safety, reliability, and regulatory compliance. The Company’s devices protect products in virtually every market that uses electrical energy, from various electronic devices to automobiles to industrial equipment.

[0001437749-17-018040:mdna:7]
[same as prior period, unchanged from 0001437749-17-013580:mdna:7]

[0001437749-17-018040:mdna:8]
[same as prior period, unchanged from 0001437749-17-013580:mdna:8]

[0001437749-17-018040:mdna:9]
The Company had strong performance in the third quarter of 2017 compared to the third quarter of 2016. For the third quarter of 2017, the Company recognized net sales of $317.9 million compared to $280.3 million in the third quarter of 2016 representing an increase of $37.6 million, or 13.4%. The increase was primarily driven by the Electronics and Automotive segments. Net sales for Electronics increased $28.2 million, or 19.1%, due to strong growth across all the segment’s business units and geographic regions as well as the ON Portfolio and U.S. Sensor acquisitions in August 2016 and July 2017, respectively. Net sales for the Automotive segment increased $7.5 million, or 7.0% primarily due to growth in the passenger car fuse and commercial vehicle products businesses. Net sales in the Industrial segment increased $1.9 million or 7.4% due to growth in the fuse and relay businesses, partially offset by the divestiture of the JRS business in October 2016. The Company recognized net income of $42.8 million, or $1.87 per diluted share, in the third quarter of 2017 compared to net income of $30.8 million, or $1.35 per diluted share in the third quarter of 2016. The increase in net income reflects the impacts of the acquisitions on the current year results as well as a decrease in operating expenses driven by a $14.8 million goodwill and other intangible impairment charge recorded for the Custom Products reporting unit in the third quarter of 2016 and lower acquisition-related costs partially offset by higher income tax expense.

[0001437749-17-018040:mdna:10]
Net sales for the first nine months of 2017 were $916.7 million compared to $771.6 million in the first nine months of 2016. The increase of $145.1 million, or 18.8%, reflects increased net sales of $120.4 million, or 31.8%, in the Electronics segment and $28.5 million, or 9.2%, in the Automotive segment, partially offset by lower net sales of $3.8 million, or 4.5%, in the Industrial segment. The increase in net sales for the Electronics segment was due to strong growth across all the segment’s business units as well as the ON Portfolio, PolySwitch and U.S. Sensor acquisitions. The increase in net sales for the Automotive segment was primarily due to the impact of the prior year acquisitions of PolySwitch and Menber’s as well as volume growth in the passenger car and commercial vehicle businesses. The Company recognized net income of $130.3 million, or $5.69 per diluted share, in the first nine months of 2017 compared to net income of $77.2 million, or $3.41 per diluted share in the first nine months of 2016. Net income increased due to the impacts of the aforementioned acquisitions, higher gross profit driven largely driven by a favorable mix within the Electronics segment, a $14.8 million goodwill and other intangible assets impairment charge recorded in the Custom Products reporting unit in the third quarter of 2016 and lower acquisition-related costs partially offset by higher income tax expense.

[0001437749-17-018040:mdna:11]
Net cash provided by operating activities was $181.3 million for the nine months ended September 30, 2017 as compared to $100.0 million for the nine months ended October 1, 2016. The increase in net cash provided by operating activities reflected higher cash earnings, lower cash taxes and the timing of supplier payments partially offset by the timing of customer payments and increased inventory.

[0001437749-17-018040:mdna:12]
On August 28, 2017, the Company announced that it had entered into a definitive agreement to acquire IXYS, a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power control semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 3,500 customers through its direct salesforce and global distribution partners. IXYS reported revenues of $322 million in its fiscal year ended March 31, 2017.

[0001437749-17-018040:mdna:13]
The Company will acquire all of the outstanding shares of IXYS common stock in exchange for a combination of cash and shares of Company common stock. Each IXYS stockholder will be entitled to elect to receive, per IXYS share, either $23.00 in cash or 0.1265 of a share of Littelfuse common stock, subject to proration so that 50% of the shares of IXYS common stock outstanding immediately prior to the effective time of the merger of the subsidiary of the Company with and into IXYS will be converted into the cash election option and the remaining shares of IXYS common stock will be converted into the stock election option. The exchange ratio is fixed and will not be adjusted for changes in the market value of Littelfuse common stock or IXYS common stock and IXYS equity-based awards will continue to fluctuate until the acquisition is completed. As a result, the final purchase price will differ from the initially announced purchase price, and that difference may be material. The transaction is subject to customary closing conditions, including approval by IXYS stockholders.

[0001437749-17-018040:mdna:14]
On October 13, 2017, the Company amended its existing Credit Agreement to increase the unsecured revolving credit facility from $575.0 million to $700.0 million and increase the unsecured term loan credit facility from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the revolving credit facility and the term loan facility by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term loans may be made in up to two advances, the first advance occurring on October 13, 2017 and the second advance, in the aggregate amount not to exceed $75.0 million, to occur in the first quarter of 2018.

[0001437749-17-018040:mdna:15]
[same as prior period, unchanged from 0001437749-17-013580:mdna:11]

[0001437749-17-018040:mdna:16]
The following table summarizes the Company’s consolidated results of operations for the periods presented. The third quarter of 2017 includes approximately $6.3 million of non-segment charges ($8.2 million year-to-date).  These charges were primarily attributable to acquisition-related and integration costs related to legal, accounting and other expenses associated with completed or contemplated acquisitions of approximately $4.8 million ($6.6 million year-to-date), including $1.6 million ($1.6 million year-to-date) of purchase accounting inventory charges related to the company’s 2017 acquisition of U.S. Sensor as described in Note 2 and $1.5 million ($1.5 million year-to-date) of charges related to restructuring and production transfers in our Asia operations.

[0001437749-17-018040:mdna:17]
The third quarter of 2016 includes $22.1 million of other non-segment charges ($45.3 million year-to-date). These charges included $14.8 million ($14.8 million year-to-date) of charges related to the impairment of the Custom Products reporting unit, $5.9 million ($18.2 million year-to-date) of acquisition-related and integration costs associated with the company’s 2016 acquisitions, $0.6 million ($7.5 million year-to-date) of non-cash inventory charges relating to the company’s 2016 acquisitions as described in Note 2, $1.9 million year-to-date in charges related to the closure of the company’s manufacturing facility in Denmark, $1.7 million year-to-date related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.9 million ($1.3 million year-to-date) related to internal legal restructuring costs.

[0001437749-17-018040:mdna:18]
(in thousands)

[0001437749-17-018040:mdna:19]
|  |  | Third Quarter |  |  | First Nine Months |  |
|  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Net sales |  | $ | 317,889 |  |  | $ | 280,331 |  |  | $ | 37,558 |  |  |  | 13.4 | % |  | $ | 916,685 |  |  | $ | 771,641 |  |  | $ | 145,044 |  |  |  | 18.8 | % |
| Gross profit |  |  | 133,651 |  |  |  | 113,759 |  |  |  | 19,892 |  |  |  | 17.5 | % |  |  | 379,909 |  |  |  | 298,780 |  |  |  | 81,129 |  |  |  | 27.2 | % |
| Operating expenses |  |  | 75,042 |  |  |  | 86,233 |  |  |  | (11,191 | ) |  |  | (13.0 | %) |  |  | 212,178 |  |  |  | 209,124 |  |  |  | 3,053 |  |  |  | 1.5 | % |
| Operating income |  |  | 58,609 |  |  |  | 27,526 |  |  |  | 31,083 |  |  |  | 112.9 | % |  |  | 167,731 |  |  |  | 89,656 |  |  |  | 78,075 |  |  |  | 87.1 | % |
| Income before income taxes |  |  | 55,523 |  |  |  | 30,433 |  |  |  | 25,090 |  |  |  | 82.4 | % |  |  | 160,308 |  |  |  | 91,524 |  |  |  | 68,784 |  |  |  | 75.2 | % |
| Income taxes |  |  | 12,715 |  |  |  | (369 | ) |  |  | 13,084 |  |  |  | (3,545.8 | %) |  |  | 29,970 |  |  |  | 14,281 |  |  |  | 15,689 |  |  |  | 109.9 | % |
| Net income |  | $ | 42,808 |  |  | $ | 30,802 |  |  | $ | 12,006 |  |  |  | 39.0 | % |  | $ | 130,338 |  |  | $ | 77,243 |  |  | $ | 53,095 |  |  |  | 68.7 | % |

[0001437749-17-018040:mdna:20]
[same as prior period, unchanged from 0001437749-17-013580:mdna:15]

[0001437749-17-018040:mdna:21]
Net sales increased $37.6 million, or 13.4%, for the third quarter of 2017 compared to the third quarter of 2016 with increases of $8.5 million and $2.9 million resulting from incremental net sales related to the ON Portfolio and U.S Sensor acquisitions, respectively. The remaining increase in net sales was driven by higher volume across all product lines in the Electronics segment and in the passenger car and commercial vehicle businesses within the Automotive segment.

[0001437749-17-018040:mdna:22]
Net sales for the first nine months of 2017 increased $145.0 million, or 18.8% compared to the first nine months of 2016 with $85.9 million resulting from the prior year acquisitions of PolySwitch, ON Portfolio, and Menber’s and $2.9 million from the current year U.S. Sensor acquisition. The remaining increase in net sales was primarily due to higher volume across all product lines in the Electronics segment and passenger car and commercial vehicle businesses within the Automotive segment partially offset by the divestiture of a core product line in the fourth quarter of 2016 and lower volume in the custom products operations within the Industrial segment.

[0001437749-17-018040:mdna:23]
[same as prior period, unchanged from 0001437749-17-013580:mdna:18]

[0001437749-17-018040:mdna:24]
Gross profit was $133.7 million, or 42.0% of net sales, in the third quarter of 2017, compared to $113.8 million, or 40.6% of net sales in the third quarter of 2016. The increase in gross profit and gross margin reflects the incremental net sales and improved leverage in expenses and profits related to the prior year acquisitions.

[0001437749-17-018040:mdna:25]
Gross profit for the first nine months of 2017 was $379.9 million, or 41.4% of net sales compared to $298.8 million, or 38.7% of net sales for the first nine months of 2016. The increase in gross profit and gross margin reflects the incremental net sales and improved leverage in expenses and profits related to the prior year acquisitions primarily in the Electronics segment.

[0001437749-17-018040:mdna:26]
[same as prior period, unchanged from 0001437749-17-013580:mdna:21]

[0001437749-17-018040:mdna:27]
Total operating expenses were $75.0 million, or 23.6% of net sales, for the third quarter of 2017 compared to $86.2 million, or 30.8% of net sales, for the third quarter of 2016. The decrease in operating expenses of $11.2 million was primarily due to the $14.8 million goodwill and other intangible asset impairment charges related to the Custom Products reporting unit recognized in the third quarter of 2016 that was partially offset by increased amortization expense associated with recent acquisitions of $1.9 million and higher research and development expenses of $1.6 million. Selling, general and administrative expenses increased slightly by $0.2 million to $56.8 million, but decreased from 20.2% to 17.9% as a percentage of net sales, for the three months ended September 30, 2017 versus the three months ended October 1, 2016 primarily as a result of cost control initiatives and lower acquisition and integration charges.

[0001437749-17-018040:mdna:28]
Total operating expenses for the first nine months of 2017 were $212.2 million, or 23.1% of net sales compared to $209.1 million, or 27.1% of net sales, for the first nine months of 2016. The increase in operating expenses of $3.1 million was primarily due to acquisitions, higher selling costs, higher research and development costs of $6.0 million and an increase of $5.0 million in amortization expense of intangible assets due to the acquisitions, partially offset by the $14.8 million of goodwill and other intangible asset impairment charges recognized in 2016 and lower acquisition-related expenses and integration costs of $9.2 million. Selling, general and administrative expenses increased by $6.9 million to $156.9 million, but decreased from 19.4% to 17.1% as a percentage of net sales for the nine months ended September 30, 2017 versus the same period in 2016 primarily as a result of lower acquisition-related expenses and integration costs of $9.2 million and cost control initiatives partially offset by the acquisitions.

[0001437749-17-018040:mdna:29]
[same as prior period, unchanged from 0001437749-17-013580:mdna:24]

[0001437749-17-018040:mdna:30]
Operating income was $58.6 million, an increase of $31.1 million or 113.0% for the third quarter of 2017 compared to $27.5 million for the third quarter of 2016. The increase in operating income was due to the acquisitions and higher Electronics volume and associated gross margin increases along with the $14.8 million goodwill and other intangible assets impairment charges recorded in the third quarter of 2016. Operating margins increased from 9.8% for the three months ended October 1, 2016 to 18.4% for the three months ended September 30, 2017. The 2016 goodwill and other intangible asset impairment charge improved margins by 5.3% while the remaining increase was due to higher volume, improvements in gross margin percentage, lower acquisition costs and operational efficiencies.

[0001437749-17-018040:mdna:31]
Operating income for the first nine months of 2017 was $167.7 million, an increase of $78.1 million or 87.1% compared to $89.7 million for the first nine months of 2016. The increase in operating income was the result of acquisitions and higher volume in the Electronics and Automotive segments. Operating margins increased from 11.6% to 18.3% for the nine months ended September 30, 2017 due to the acquisitions, improvement in gross margins, lower acquisition and integration related costs, the prior year goodwill and other intangible asset impairment charge and operational efficiencies.

[0001437749-17-018040:mdna:32]
[same as prior period, unchanged from 0001437749-17-013580:mdna:27]

[0001437749-17-018040:mdna:33]
Income before income taxes was $55.5 million, or 17.5% of net sales, for the third quarter of 2017 compared to $30.4 million, or 10.9% of net sales, for the third quarter of 2016. Income before income taxes was impacted by higher operating income as described above, partially offset by an unfavorable increase in foreign exchange losses of $5.3 million primarily in the euro and Philippine peso against the U.S. dollar and higher interest expense of $0.9 million, reflecting increased borrowings.

[0001437749-17-018040:mdna:34]
Income before income taxes for the first nine months of 2017 was $160.3 million, or 17.5% of net sales compared to $91.5 million, or 11.9% of net sales, for the first nine months of 2016. Income before income taxes was impacted by an increase in operating income described above, partially offset by unfavorable changes in foreign exchange rates of $5.6 million primarily as a result of fluctuations in the euro and Philippine peso against the U.S. dollar and higher interest expense of $3.6 million due to higher borrowings.

[0001437749-17-018040:mdna:35]
[same as prior period, unchanged from 0001437749-17-013580:mdna:30]

[0001437749-17-018040:mdna:36]
Income tax expense was $12.7 million, or an effective tax rate of 22.9%, for the third quarter of 2017 compared to income tax benefit of $0.4 million, or an effective tax rate of negative 1.2%, for the third quarter of 2016. The effective tax rates for both the third quarter of 2017 and the third quarter of 2016 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. The effective tax rate for the third quarter of 2017 reflected a forecasted accrual for taxes on undistributed current year-earnings of certain non-US affiliates. The effective tax rate for the third quarter of 2016 reflected a one-time deduction with respect to the stock of one of the company’s affiliates partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded.

[0001437749-17-018040:mdna:37]
Income tax expense for the first nine months of 2017 was $30.0 million, or an effective tax rate of 18.7% compared to income tax expense of $14.3 million, or an effective tax rate of 15.6%, for the first nine months of 2016. The effective tax rates for both the first nine months of 2017 and the first nine months of 2016 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions. The effective tax rate for the first nine months of 2017 reflected a forecasted accrual for taxes on undistributed current year-earnings of certain non-US affiliates. The effective tax rate for the first nine months of 2016 reflected the third quarter one-time deduction with respect to the stock of one of the company’s affiliates partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded.

[0001437749-17-018040:mdna:38]
[same as prior period, unchanged from 0001437749-17-013580:mdna:33]

[0001437749-17-018040:mdna:39]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 10, Segment Information, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-17-018040:mdna:40]
The following table provides a summary of the Company’s net sales by segment:

[0001437749-17-018040:mdna:41]
(in thousands)

[0001437749-17-018040:mdna:42]
|  |  | Third Quarter |  |  | First Nine Months |  |
|  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Electronics |  | $ | 175,899 |  |  | $ | 147,730 |  |  | $ | 28,169 |  |  |  | 19.1 | % |  | $ | 499,052 |  |  | $ | 378,696 |  |  | $ | 120,356 |  |  |  | 31.8 | % |
| Automotive |  |  | 113,797 |  |  |  | 106,341 |  |  |  | 7,456 |  |  |  | 7.0 | % |  |  | 338,094 |  |  |  | 309,644 |  |  |  | 28,450 |  |  |  | 9.2 | % |
| Industrial |  |  | 28,193 |  |  |  | 26,260 |  |  |  | 1,933 |  |  |  | 7.4 | % |  |  | 79,539 |  |  |  | 83,301 |  |  |  | (3,762 | ) |  |  | (4.5 | %) |
| Total |  | $ | 317,889 |  |  | $ | 280,331 |  |  | $ | 37,558 |  |  |  | 13.4 | % |  | $ | 916,685 |  |  | $ | 771,641 |  |  | $ | 145,044 |  |  |  | 18.8 | % |

[0001437749-17-018040:mdna:43]
[same as prior period, unchanged from 0001437749-17-013580:mdna:37]

[0001437749-17-018040:mdna:44]
The Electronics segment net sales increased $28.2 million, or 19.1%, in the third quarter of 2017 compared to the third quarter of 2016 due to incremental net sales related to the ON Portfolio and U.S. Sensor acquisitions, higher volume across all product lines and favorable foreign exchange impacts of $0.8 million.

[0001437749-17-018040:mdna:45]
The Electronics segment net sales increased $120.4 million, or 31.8%, in the first nine months of 2017 compared to the first nine months of 2016 primarily due to the PolySwitch, ON Portfolio and U.S Sensor acquisitions, higher volume across all product lines that were partially offset by unfavorable foreign exchange impacts of $1.3 million.

[0001437749-17-018040:mdna:46]
[same as prior period, unchanged from 0001437749-17-013580:mdna:40]

[0001437749-17-018040:mdna:47]
The Automotive segment net sales increased $7.5 million, or 7.0%, in the third quarter of 2017 compared to the third quarter of 2016 primarily due to increased volume in the passenger car and commercial vehicle products businesses and favorable changes in foreign exchange rates of $1.7 million that were partially offset by a decrease in net sales from the automotive sensor business.

[0001437749-17-018040:mdna:48]
The Automotive segment net sales increased $28.5 million, or 9.2%, in the first nine months of 2017 compared to the first nine months of 2016 primarily due to the incremental net sales associated with the PolySwitch and Menber’s acquisitions, higher volume in passenger car and commercial vehicle products that were partially offset by unfavorable foreign exchange impacts of $1.7 million and lower volume in automotive sensor products.

[0001437749-17-018040:mdna:49]
[same as prior period, unchanged from 0001437749-17-013580:mdna:43]

[0001437749-17-018040:mdna:50]
The Industrial segment net sales increased $1.9 million, or 7.4%, in the third quarter of 2017 compared to the third quarter of 2016 primarily due to higher volume in the power fuse and relay operations partially offset by the divestiture of a non-core product line in the custom products business.

[0001437749-17-018040:mdna:51]
The Industrial segment net sales decreased $3.8 million, or 4.5%, in the first nine months of 2017 compared to the first nine months of 2016 primarily due to the divestiture of two non-core product lines, one in the fourth quarter of 2016 and the other in the first quarter of 2016, and lower volume in the custom products operations.

[0001437749-17-018040:mdna:52]
[same as prior period, unchanged from 0001437749-17-013580:mdna:46]

[0001437749-17-018040:mdna:53]
[same as prior period, unchanged from 0001437749-17-013580:mdna:47]

[0001437749-17-018040:mdna:54]
(in thousands)

[0001437749-17-018040:mdna:55]
|  |  | Third Quarter |  |  | First Nine Months |  |
|  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Americas |  | $ | 115,499 |  |  | $ | 106,112 |  |  | $ | 9,387 |  |  |  | 8.9 | % |  | $ | 328,563 |  |  | $ | 313,231 |  |  | $ | 15,332 |  |  |  | 4.9 | % |
| Europe |  |  | 63,365 |  |  |  | 52,200 |  |  |  | 11,165 |  |  |  | 21.4 | % |  |  | 182,534 |  |  |  | 149,417 |  |  |  | 33,117 |  |  |  | 22.2 | % |
| Asia-Pacific |  |  | 139,025 |  |  |  | 122,019 |  |  |  | 17,006 |  |  |  | 13.9 | % |  |  | 405,588 |  |  |  | 308,993 |  |  |  | 96,595 |  |  |  | 31.3 | % |
| Total |  | $ | 317,889 |  |  | $ | 280,331 |  |  | $ | 37,558 |  |  |  | 13.4 | % |  | $ | 916,685 |  |  | $ | 771,641 |  |  | $ | 145,044 |  |  |  | 18.8 | % |

[0001437749-17-018040:mdna:56]
[same as prior period, unchanged from 0001437749-17-013580:mdna:49]

[0001437749-17-018040:mdna:57]
Net sales in the Americas increased $9.4 million, or 8.9%, in the third quarter of 2017 compared to the third quarter of 2016 driven by incremental sales from acquisitions and increased volume in the passenger car and commercial vehicle businesses in the Automotive segment and all product lines in the Electronics segment that were partially offset by lower volume in sensor products within the Automotive segment and the divestiture of a non-core product line in our Industrial segment.

[0001437749-17-018040:mdna:58]
Net sales in the Americas increased $15.3 million, or 4.9%, in the first nine months of 2017 compared to the first nine months of 2016 resulting from acquisitions and higher volume in the passenger car and commercial vehicle businesses in the Automotive segment and all product lines in the Electronics segment that were partially offset by lower volume in sensor products and the divestiture of a non-core product line in our Industrial segment.

[0001437749-17-018040:mdna:59]
[same as prior period, unchanged from 0001437749-17-013580:mdna:52]

[0001437749-17-018040:mdna:60]
European net sales increased $11.2 million, or 21.4%, in the third quarter of 2017 compared to the third quarter of 2016. The increase in net sales was primarily due to the prior year ON Portfolio acquisition and higher volumes in the passives business in the Electronics segment and the passenger car and commercial vehicle businesses in the Automotive segment and $3.0 million in favorable foreign currency effects.

[0001437749-17-018040:mdna:61]
European net sales increased $33.1 million, or 22.2%, in the first nine months of 2017 compared to the first nine months of 2016. The increase in net sales was primarily due to acquisitions and increased net sales in the passives business in the Electronics segment and the passenger car business in the Automotive segment and higher volume

[0001437749-17-018040:mdna:62]
[same as prior period, unchanged from 0001437749-17-013580:mdna:55]

[0001437749-17-018040:mdna:63]
Asia-Pacific net sales increased $17.0 million, or 13.9%, in the third quarter of 2017 compared to the third quarter of 2016 primarily due to incremental net sales from the prior year ON Portfolio acquisition and higher net sales in all of the Electronics segment’s business.

[0001437749-17-018040:mdna:64]
Asia-Pacific net sales increased $96.6 million, or 31.3%, in the first nine months of 2017 compared to the first nine months of 2016, primarily due to incremental net sales from prior year acquisitions and increased volume in the passive and semiconductor businesses in the Electronics segment.

[0001437749-17-018040:mdna:65]
[same as prior period, unchanged from 0001437749-17-013580:mdna:58]

[0001437749-17-018040:mdna:66]
[same as prior period, unchanged from 0001437749-17-013580:mdna:59]

[0001437749-17-018040:mdna:67]
Revolving Credit Facility/Term Loan

[0001437749-17-018040:mdna:68]
On October 13, 2017, the Company amended its existing Credit Agreement to increase the unsecured revolving credit facility from $575.0 million to $700.0 million and increase the unsecured term loan credit facility from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the revolving credit facility and the term loan facility by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term loans may be made in up to two advances, the first advance occurring on October 13, 2017 and the second advance, in the aggregate amount not to exceed $75.0 million, to occur in the first quarter of 2018.

[0001437749-17-018040:mdna:69]
On March 4, 2016, the Company entered into a new five-year credit agreement with a group of lenders for up to $700.0 million. The new credit agreement consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. In addition, the Company has the ability, from time to time, to increase the size of the revolving credit facility and the term loan facility by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders. For the term loan credit facility, the Company is required to make quarterly principal payments of $1.6 million through March 31, 2018 and $3.1 million from June 30, 2018 through December 31, 2020 with the remaining balance due on March 4, 2021.

[0001437749-17-018040:mdna:70]
Outstanding borrowings under the credit agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.30%, based on the Consolidated Leverage Ratio, as defined. The effective interest rate on outstanding borrowings under the credit facility was 2.73% at September 30, 2017. As of September 30, 2017, the Company had $0.1 million outstanding in letters of credit and had available $559.9 million of borrowing capacity under the revolving credit facility. Further information regarding the Company’s credit agreement is provided in Note 4, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-17-018040:mdna:71]
[same as prior period, unchanged from 0001437749-17-013580:mdna:63]

[0001437749-17-018040:mdna:72]
[same as prior period, unchanged from 0001437749-17-013580:mdna:64]

[0001437749-17-018040:mdna:73]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022, and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (together, the “U.S. Senior Notes,” and together with the Euro Senior Notes, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes will be payable semiannually on February 15 and August 15, commencing August 15, 2017. Further information regarding the Company’s Senior Notes is provided in Note 4, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0001437749-17-018040:mdna:74]
[same as prior period, unchanged from 0001437749-17-013580:mdna:66]

[0001437749-17-018040:mdna:75]
|  |  | First Nine Months |  |
| (in thousands) |  | 2017 |  |  | 2016 |  |
| Net cash provided by operating activities |  | $ | 181,320 |  |  | $ | 100,015 |  |
| Net cash used in investing activities |  |  | (79,201 | ) |  |  | (498,481 | ) |
| Net cash (used in) provided by financing activities |  |  | (6,491 | ) |  |  | 262,381 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,076 |  |  |  | 1,793 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 97,704 |  |  |  | (134,292 | ) |
| Cash and cash equivalents at beginning of period |  |  | 275,124 |  |  |  | 328,786 |  |
| Cash and cash equivalents at end of period |  | $ | 372,828 |  |  | $ | 194,494 |  |

[0001437749-17-018040:mdna:76]
The following describes the Company’s cash flows for the nine months ended September 30, 2017 and October 1, 2016.

[0001437749-17-018040:mdna:77]
[same as prior period, unchanged from 0001437749-17-013580:mdna:68]

[0001437749-17-018040:mdna:78]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes and other operating activities.

[0001437749-17-018040:mdna:79]
Net cash provided by operating activities was $181.3 million for the first nine months of 2017, compared to $100.0 million during the nine months ended October 1, 2016. The increase in net cash provided by operating activities was primarily driven by higher cash earnings, lower cash taxes and the timing of supplier payments partially offset by the timing of customer payments and inventory.

[0001437749-17-018040:mdna:80]
[same as prior period, unchanged from 0001437749-17-013580:mdna:71]

[0001437749-17-018040:mdna:81]
Net cash used in investing activities was $79.2 million for the nine months ended September 30, 2017, compared to $498.4 million during the nine months ended October 1, 2016. Net cash used for acquisitions of $38.6 million in the nine months ended September 30, 2017 primarily related to the acquisition of a majority stake in Monolith Semiconductor ($14.2 million) and the acquisition of U.S. Sensor ($24.4 million). Net cash used for acquisitions of $468.6 million for the nine months ended October 1, 2016 primarily related to the acquisitions of Polyswitch ($344.5 million), the ON portfolio business ($104.0 million) and Menber’s ($19.2 million). Capital expenditures was $48.5 million, representing an increase of $14.0 million compared to 2016.

[0001437749-17-018040:mdna:82]
[same as prior period, unchanged from 0001437749-17-013580:mdna:73]

[0001437749-17-018040:mdna:83]
Net cash used in financing activities was $6.5 million for the nine months ended 2017 compared to net cash provided by financing activities of $262.4 million for the nine months ended 2016. The Company had $140.0 million of proceeds from the credit facility and senior notes payable and $117.2 million of payments on the term loan and credit facility in 2017 as compared to $492.0 million of proceeds from the credit facility and term loan and $216.6 million of payments on the term loan and credit facility. Additionally, dividends paid increased $3.0 million from $20.4 million in 2016 to $23.4 million for the nine months ended September 30, 2017.

[0001437749-17-018040:mdna:84]
[same as prior period, unchanged from 0001437749-17-013580:mdna:75]

[0001437749-17-018040:mdna:85]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2017 to April 30, 2018 (“Share Repurchase Program”). The Company did not repurchase any shares of its common stock during the third quarter of 2017.

[0001437749-17-018040:mdna:86]
[same as prior period, unchanged from 0001437749-17-013580:mdna:77]

[0001437749-17-018040:mdna:87]
As of September 30, 2017, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001437749-17-018040:mdna:88]
[same as prior period, unchanged from 0001437749-17-013580:mdna:79]

[0001437749-17-018040:mdna:89]
In March 2017, the FASB issued ASU No. 2017-07 “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changes the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the current guidance, net benefit cost is reported as an employee cost within operating income. The amendment requires the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU No. 2017-07 will be effective for the first quarter of 2018 and is required to be retrospectively adopted. Had this guidance been adopted as of January 1, 2017, operating income within the Condensed Consolidated Statements of Income for the three months and nine months ended September 30, 2017 would have not changed by a material amount.

[0001437749-17-018040:mdna:90]
In January 2017, the FASB issued ASU No. 2017-04, “Intangibles-Goodwill and Other” (Topic 350). This ASU modifies the concept of impairment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. An entity no longer will determine goodwill impairment by calculating the implied fair value of goodwill by assigning the fair value of a reporting unit to all of its assets and liabilities as if that reporting unit had been acquired in a business combination. Because the update will eliminate Step 2 from the goodwill impairment test, it should reduce the cost and complexity of evaluating goodwill for impairment. This ASU is effective for annual or any interim goodwill impairment tests in fiscal years beginning after December 15, 2020, with early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company expects to adopt the new standard in 2017.

[0001437749-17-018040:mdna:91]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU will require the Company to recognize any changes in the fair value of certain equity investments in net income. These changes are currently recognized in other comprehensive income ("OCI"). This guidance is effective for interim and fiscal years beginning after December 15, 2017.

[0001437749-17-018040:mdna:92]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition, however the Company plans to adopt the standard in the first quarter of 2019. The Company is currently evaluating the impact of ASU 2016-02.

[0001437749-17-018040:mdna:93]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers" (Topic 606) which supersedes the revenue recognition requirements in ASC 605, "Revenue Recognition." This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. In August, 2015, the FASB issued ASU No. 2015-14, which postponed the effective date of ASU No. 2014-09 to fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted on the original effective date of fiscal years beginning after December 15, 2016. The Company is in the process of performing its assessment of the potential impact on its consolidated financial statements and has not concluded on its adoption methodology. While the Company is currently assessing the impact of the new standard, the Company’s revenue is primarily generated from the sale of finished products to customers. Sales predominantly contain a single delivery element and revenue is recognized at a single point in time when ownership, risks, and rewards transfer. These are largely un-affected by the new standard. The Company does not expect this new guidance to have a material impact on the amount of overall sales recognized; however, the timing of sales on certain projects may be affected. The Company has not yet quantified this potential impact.

[0001437749-17-018040:mdna:94]
[same as prior period, unchanged from 0001437749-17-013580:mdna:83]

[0001437749-17-018040:mdna:95]
The Company’s Condensed Consolidated Financial Statements are prepared in accordance with U.S. GAAP. In connection with the preparation of the Condensed Consolidated Financial Statements, the Company uses estimates and makes judgments and assumptions about future events that affect the reported amounts of assets, liabilities, revenue, expenses, and the related disclosures. The assumptions, estimates, and judgments are based on historical experience, current trends, and other factors the Company believes are relevant at the time it prepares the Condensed Consolidated Financial Statements.

[0001437749-17-018040:mdna:96]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 31, 2016. During the three months ended September 30, 2017, there were no significant changes in the application of critical accounting policies.
