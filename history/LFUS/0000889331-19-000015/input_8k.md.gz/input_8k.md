# LFUS 8-K — 0000889331-19-000007 filed 2019-01-30

## item codes, every 8-K on or before 2019-02-22

- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2019-02-22

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-19-000007:8k_2_02:1]
EX-99.1
2
q42018ex991.htm
EXHIBIT 99.1

[0000889331-19-000007:8k_2_02:2]
Exhibit

[0000889331-19-000007:8k_2_02:3]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-19-000007:8k_2_02:4]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS FOR 2018

[0000889331-19-000007:8k_2_02:5]
CHICAGO, January 30, 2019 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the fourth quarter and full year ended December 29, 2018:

[0000889331-19-000007:8k_2_02:6]
Fourth Quarter 2018 Highlights

[0000889331-19-000007:8k_2_02:7]
| • | Net sales were $402.3 million, up 32% versus the prior year period. Organic revenue growth was 4% |

[0000889331-19-000007:8k_2_02:8]
| • | Growth by segment versus the prior year: |

[0000889331-19-000007:8k_2_02:9]
| • | Electronics sales increased 62% (up 7% organically) |

[0000889331-19-000007:8k_2_02:10]
| • | Automotive sales decreased 3% on global auto production decline of 4% (down 1% organically) |

[0000889331-19-000007:8k_2_02:11]
| • | Industrial sales decreased 3% due to the exit of the Custom business in 2018 (up 11% organically) |

[0000889331-19-000007:8k_2_02:12]
| • | GAAP diluted EPS was $1.29, up from a loss of $0.48 in the prior year, and includes $14.7 million of after-tax charges primarily related to certain purchase accounting adjustments and integration costs for the IXYS business, and non-operating foreign exchange losses |

[0000889331-19-000007:8k_2_02:13]
| • | Adjusted diluted EPS of $1.87 increased 3% over the prior year |

[0000889331-19-000007:8k_2_02:14]
| • | GAAP effective tax rate was 17.9% and the adjusted effective tax rate was 14.6% |

[0000889331-19-000007:8k_2_02:15]
| • | Cash flow from operations was $79.7 million and free cash flow was $60.9 million |

[0000889331-19-000007:8k_2_02:16]
| • | During the fourth quarter and as of January 29, 2019, the company repurchased approximately 392,000 and 67,000 shares of common stock, respectively, under its share repurchase authorization |

[0000889331-19-000007:8k_2_02:17]
Full Year 2018 Highlights

[0000889331-19-000007:8k_2_02:18]
| • | Net sales were $1.72 billion, up 41% versus the prior year period, and up 8% organically |

[0000889331-19-000007:8k_2_02:19]
| • | Growth by segment versus the prior year: |

[0000889331-19-000007:8k_2_02:20]
| • | Electronics sales increased 70% (up 11% organically) |

[0000889331-19-000007:8k_2_02:21]
| • | Automotive sales increased 6% on a small decline in global auto production (up 4% organically) |

[0000889331-19-000007:8k_2_02:22]
| • | Industrial sales increased 8% (up 13% organically) |

[0000889331-19-000007:8k_2_02:23]
| • | GAAP diluted EPS was $6.52, up 25% versus the prior year |

[0000889331-19-000007:8k_2_02:24]
| • | Adjusted diluted EPS of $9.44 increased 22% versus the prior year |

[0000889331-19-000007:8k_2_02:25]
| • | GAAP effective tax rate was 19.7% and the adjusted effective tax rate was 18.9% |

[0000889331-19-000007:8k_2_02:26]
| • | Cash flow from operations was $331.8 million and free cash flow was $257.0 million, both records for the company |

[0000889331-19-000007:8k_2_02:27]
-more-

[0000889331-19-000007:8k_2_02:28]
“2018 was an exceptional year for us," said Dave Heinzmann, Littelfuse Chief Executive Officer. "Full year organic sales growth of 8% and adjusted EPS growth of 22% reflects the strong execution of our strategy despite softening demand during the fourth quarter. During the year, we made significant progress integrating the company’s largest acquisition, IXYS Corporation, and are seeing the benefits of our expanded portfolio and combined global teams. Across our segments, we captured many strategic wins in our target end markets. We remain confident that our leading technologies, global footprint, close customer relationships, and talented associates position us for continued content growth in excess of the markets we serve.”

[0000889331-19-000007:8k_2_02:29]
For the first quarter of 2019*:

[0000889331-19-000007:8k_2_02:30]
| • | Net sales are expected to be in the range of $404 to $416 million, down 2% on an as reported basis and down 4% organically, at the midpoint versus the prior year quarter |

[0000889331-19-000007:8k_2_02:31]
| • | Adjusted diluted earnings per share are expected to be in the range of $1.86 to $2.00 |

[0000889331-19-000007:8k_2_02:32]
| • | Adjusted effective tax rate is expected to be in the range of 19% - 21% |

[0000889331-19-000007:8k_2_02:33]
For the 2019 full year*:

[0000889331-19-000007:8k_2_02:34]
| • | Adjusted effective tax rate is expected to be in the range of 18% - 20% |

[0000889331-19-000007:8k_2_02:35]
| • | Capital expenditures are expected to be in the range of $90 - $95 million |

[0000889331-19-000007:8k_2_02:36]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-19-000007:8k_2_02:37]
Dividend

[0000889331-19-000007:8k_2_02:38]
The company will pay a cash dividend on its common stock of $0.43 per share on March 7, 2019 to shareholders of record as of February 21, 2019.

[0000889331-19-000007:8k_2_02:39]
Conference Call and Webcast Information

[0000889331-19-000007:8k_2_02:40]
Littelfuse will host a conference call today, Wednesday, January 30, 2019, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-19-000007:8k_2_02:41]
-more-

[0000889331-19-000007:8k_2_02:42]
About Littelfuse

[0000889331-19-000007:8k_2_02:43]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Sold in over 150 countries, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Our 12,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-19-000007:8k_2_02:44]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; the integration of the recently acquired business of IXYS Corporation ("IXYS") and the risk that expected benefits, synergies and growth prospects of the acquisition of IXYS may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 30, 2017. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 30, 2017.

[0000889331-19-000007:8k_2_02:45]
Non-GAAP Financial Measures

[0000889331-19-000007:8k_2_02:46]
The information included in this press release includes the non-GAAP financial measures of organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate and free cash flow. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-19-000007:8k_2_02:47]
The company believes that organic revenue growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-19-000007:8k_2_02:48]
CONTACT: Trisha Tuntland

[0000889331-19-000007:8k_2_02:49]
Head of Investor Relations

[0000889331-19-000007:8k_2_02:50]
(773) 628-2163

[0000889331-19-000007:8k_2_02:51]
###

[0000889331-19-000007:8k_2_02:52]
LFUS-F

[0000889331-19-000007:8k_2_02:53]
LITTELFUSE, INC.

[0000889331-19-000007:8k_2_02:54]
CONSOLIDATED BALANCE SHEETS

[0000889331-19-000007:8k_2_02:55]
| (in thousands) | December 29, 2018 |  | December 30, 2017 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 489,733 |  |  | $ | 429,676 |  |
| Short-term investments | 34 |  |  | 35 |  |
| Trade receivables, less allowances of $36,038 and $27,516, respectively | 232,892 |  |  | 182,699 |  |
| Inventories | 258,228 |  |  | 140,789 |  |
| Prepaid income taxes and income taxes receivable | 2,339 |  |  | 1,689 |  |
| Prepaid expenses and other current assets | 49,291 |  |  | 37,452 |  |
| Total current assets | 1,032,517 |  |  | 792,340 |  |
| Net property, plant, and equipment | 339,894 |  |  | 250,577 |  |
| Intangible assets, net of amortization | 361,474 |  |  | 203,850 |  |
| Goodwill | 826,715 |  |  | 453,414 |  |
| Investments | 25,405 |  |  | 10,993 |  |
| Deferred income taxes | 7,330 |  |  | 11,858 |  |
| Other assets | 20,971 |  |  | 17,070 |  |
| Total assets | $ | 2,614,306 |  |  | $ | 1,740,102 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 126,323 |  |  | $ | 101,844 |  |
| Accrued liabilities | 138,405 |  |  | 100,415 |  |
| Accrued income taxes | 20,547 |  |  | 16,285 |  |
| Current portion of long-term debt | 10,000 |  |  | 6,250 |  |
| Total current liabilities | 295,275 |  |  | 224,794 |  |
| Long-term debt, less current portion | 684,730 |  |  | 489,361 |  |
| Deferred income taxes | 51,853 |  |  | 17,069 |  |
| Accrued post-retirement benefits | 31,874 |  |  | 18,742 |  |
| Other long-term liabilities | 72,232 |  |  | 62,580 |  |
| Total equity | 1,478,342 |  |  | 927,556 |  |
| Total liabilities and equity | $ | 2,614,306 |  |  | $ | 1,740,102 |  |

[0000889331-19-000007:8k_2_02:56]
LITTELFUSE, INC.

[0000889331-19-000007:8k_2_02:57]
CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-19-000007:8k_2_02:58]
(Unaudited)

[0000889331-19-000007:8k_2_02:59]
|  |  | Three Months Ended |  | Fiscal Year Ended |
| (in thousands, except per share data) |  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Net sales |  | $ | 402,281 |  |  | $ | 304,849 |  |  | $ | 1,718,468 |  |  | $ | 1,221,534 |  |
| Cost of sales |  | 247,944 |  |  | 178,225 |  |  | 1,065,927 |  |  | 715,001 |  |
| Gross profit |  | 154,337 |  |  | 126,624 |  |  | 652,541 |  |  | 506,533 |  |
| Selling, general, and administrative expenses |  | 67,461 |  |  | 55,934 |  |  | 288,001 |  |  | 212,833 |  |
| Research and development expenses |  | 21,559 |  |  | 13,617 |  |  | 87,301 |  |  | 50,489 |  |
| Amortization of intangibles |  | 13,689 |  |  | 6,293 |  |  | 52,190 |  |  | 24,700 |  |
| Total operating expenses |  | 102,709 |  |  | 75,844 |  |  | 427,492 |  |  | 288,022 |  |
| Operating income |  | 51,628 |  |  | 50,780 |  |  | 225,049 |  |  | 218,511 |  |
| Interest expense |  | 5,589 |  |  | 3,512 |  |  | 22,569 |  |  | 13,380 |  |
| Foreign exchange loss (gain) |  | 5,509 |  |  | 3,859 |  |  | (863 | ) |  | 2,376 |  |
| Other expense (income), net |  | 763 |  |  | (320 | ) |  | (1,599 | ) |  | (1,282 | ) |
| Income before income taxes |  | 39,767 |  |  | 43,729 |  |  | 204,942 |  |  | 204,037 |  |
| Income taxes |  | 7,102 |  |  | 54,548 |  |  | 40,377 |  |  | 84,518 |  |
| Net income (loss) |  | $ | 32,665 |  |  | $ | (10,819 | ) |  | $ | 164,565 |  |  | $ | 119,519 |  |
| Income (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.31 |  |  | $ | (0.48 | ) |  | $ | 6.62 |  |  | $ | 5.27 |  |
| Diluted |  | $ | 1.29 |  |  | $ | (0.48 | ) |  | $ | 6.52 |  |  | $ | 5.21 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 25,028 |  |  | 22,714 |  |  | 24,870 |  |  | 22,687 |  |
| Diluted |  | 25,299 |  |  | 22,714 |  |  | 25,235 |  |  | 22,931 |  |

[0000889331-19-000007:8k_2_02:60]
LITTELFUSE, INC.

[0000889331-19-000007:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-19-000007:8k_2_02:62]
|  | Year Ended |
| (in thousands) | December 29, 2018 |  | December 30, 2017 |
|  | (Unaudited) |  |  |
| OPERATING ACTIVITIES |  |  |  |
| Net income | $ | 164,565 |  |  | $ | 119,519 |  |
| Adjustments to reconcile net income to net cash provided by operating activities, net: | 169,005 |  |  | 104,044 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Trade receivables | (3,539 | ) |  | (11,087 | ) |
| Inventories | (33,971 | ) |  | (20,180 | ) |
| Accounts payable | 13,708 |  |  | 6,494 |  |
| Accrued liabilities | 29,329 |  |  | 50,626 |  |
| Prepaid expenses and other assets | (7,269 | ) |  | 19,754 |  |
| Net cash provided by operating activities | 331,828 |  |  | 269,170 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisitions of businesses, net of cash acquired | (318,474 | ) |  | (38,512 | ) |
| Purchases of property, plant, and equipment | (74,753 | ) |  | (65,925 | ) |
| All other cash provided by investing activities | 10,979 |  |  | 8,300 |  |
| Net cash used in investing activities | (382,248 | ) |  | (96,137 | ) |
| FINANCING ACTIVITIES |  |  |  |
| Net proceeds from credit facility and senior notes | 207,500 |  |  | 14,687 |  |
| Cash dividends paid | (39,993 | ) |  | (31,770 | ) |
| Purchases of common stock | (63,564 | ) |  | — |  |
| All other cash provided by financing activities | 17,954 |  |  | (7,598 | ) |
| Net cash provided by (used in) financing activities | 121,897 |  |  | (24,681 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (11,420 | ) |  | 6,200 |  |
| Increase in cash and cash equivalents | 60,057 |  |  | 154,552 |  |
| Cash and cash equivalents at beginning of year | 429,676 |  |  | 275,124 |  |
| Cash and cash equivalents at end of year | $ | 489,733 |  |  | $ | 429,676 |  |

[0000889331-19-000007:8k_2_02:63]
LITTELFUSE, INC.

[0000889331-19-000007:8k_2_02:64]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-19-000007:8k_2_02:65]
(Unaudited)

[0000889331-19-000007:8k_2_02:66]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2018 |  | 2017 |  | %Growth /(Decline) |  | 2018 |  | 2017 |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 264,056 |  |  | $ | 162,876 |  |  | 62.1 | % |  | $ | 1,124,296 |  |  | $ | 661,928 |  |  | 69.9 | % |
| Automotive |  | 112,073 |  |  | 115,133 |  |  | (2.7 | )% |  | 479,791 |  |  | 453,227 |  |  | 5.9 | % |
| Industrial |  | 26,152 |  |  | 26,840 |  |  | (2.6 | )% |  | 114,381 |  |  | 106,379 |  |  | 7.5 | % |
| Total net sales |  | $ | 402,281 |  |  | $ | 304,849 |  |  | 32.0 | % |  | $ | 1,718,468 |  |  | $ | 1,221,534 |  |  | 40.7 | % |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 47,687 |  |  | $ | 33,362 |  |  | 42.9 | % |  | $ | 241,426 |  |  | $ | 155,880 |  |  | 54.9 | % |
| Automotive |  | 10,017 |  |  | 14,972 |  |  | (33.1 | )% |  | 54,982 |  |  | 62,571 |  |  | (12.1 | )% |
| Industrial |  | 3,212 |  |  | 4,565 |  |  | (29.6 | )% |  | 17,335 |  |  | 10,334 |  |  | 67.7 | % |
| Other(a) |  | (9,288 | ) |  | (2,119 | ) |  | N.M. |  |  | (88,694 | ) |  | (10,274 | ) |  | N.M. |  |
| Total operating income |  | 51,628 |  |  | 50,780 |  |  | 1.7 | % |  | 225,049 |  |  | 218,511 |  |  | 3.0 | % |
| Operating Margin |  | 12.8 | % |  | 16.7 | % |  |  |  | 13.1 | % |  | 17.9 | % |  |  |
| Interest expense |  | 5,589 |  |  | 3,512 |  |  |  |  | 22,569 |  |  | 13,380 |  |  |  |
| Foreign exchange loss (gain) |  | 5,509 |  |  | 3,859 |  |  |  |  | (863 | ) |  | 2,376 |  |  |  |
| Other expense (income), net |  | 763 |  |  | (320 | ) |  |  |  | (1,599 | ) |  | (1,282 | ) |  |  |
| Income before income taxes |  | $ | 39,767 |  |  | $ | 43,729 |  |  | (9.1 | )% |  | $ | 204,942 |  |  | $ | 204,037 |  |  | 0.4 | % |

[0000889331-19-000007:8k_2_02:67]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and other charges, restructuring costs, asset impairments, and gain and losses on asset sales.( See Supplemental Financial Information for details.)

[0000889331-19-000007:8k_2_02:68]
N.M. - Not meaningful

[0000889331-19-000007:8k_2_02:69]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2018 |  | 2017 |  | %Growth /(Decline) |  | 2018 |  | 2017 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 18.1 | % |  | 20.5 | % |  | (2.4 | )% |  | 21.5 | % |  | 23.5 | % |  | (2.0 | )% |
| Automotive |  | 8.9 | % |  | 13.0 | % |  | (4.1 | )% |  | 11.5 | % |  | 13.8 | % |  | (2.3 | )% |
| Industrial |  | 12.3 | % |  | 17.0 | % |  | (4.7 | )% |  | 15.2 | % |  | 9.7 | % |  | 5.5 | % |

[0000889331-19-000007:8k_2_02:70]
LITTELFUSE, INC.

[0000889331-19-000007:8k_2_02:71]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-19-000007:8k_2_02:72]
(In millions of USD except per share amounts unaudited)

[0000889331-19-000007:8k_2_02:73]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-18 |  | Q4-17 |  | YTD-18 |  | YTD-17 |
| GAAP diluted EPS |  | $ | 1.29 |  |  | $ | (0.48 | ) |  | $ | 6.52 |  |  | $ | 5.21 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.58 |  |  | 2.29 |  |  | 2.92 |  |  | 2.53 |  |
| Adjusted diluted EPS |  | $ | 1.87 |  |  | $ | 1.81 |  |  | $ | 9.44 |  |  | $ | 7.74 |  |

[0000889331-19-000007:8k_2_02:74]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q4-18 |  | Q4-17 |  | YTD-18 |  | YTD-17 |
| Acquisition related and integration costs (a) |  | $ | 3.2 |  |  | $ | 1.4 |  |  | $ | 20.2 |  |  | $ | 8.1 |  |
| Restructuring, impairment and other charges (b) |  | 2.4 |  |  | 0.7 |  |  | 12.6 |  |  | 2.2 |  |
| Amortization backlog - IXYS (c) |  | 3.7 |  |  | — |  |  | 12.4 |  |  | — |  |
| Change in control - IXYS (d) |  | — |  |  | — |  |  | 2.1 |  |  | — |  |
| Acquisition related stock-based compensation charge (e) |  | — |  |  | — |  |  | 4.5 |  |  | — |  |
| Purchase accounting inventory adjustments (f) |  | — |  |  | — |  |  | 36.9 |  |  | — |  |
| Non-GAAP adjustments to operating income |  | 9.3 |  |  | 2.1 |  |  | 88.7 |  |  | 10.3 |  |
| Other expense, net (g) |  | 0.9 |  |  | — |  |  | 0.9 |  |  | — |  |
| Non-operating foreign exchange loss (gain) |  | 5.5 |  |  | 3.9 |  |  | (0.9 | ) |  | 2.4 |  |
| Non-GAAP adjustments to income before income taxes |  | 15.7 |  |  | 6.0 |  |  | 88.7 |  |  | 12.7 |  |
| Income taxes (h) |  | 1.0 |  |  | (46.5 | ) |  | 15.1 |  |  | (45.3 | ) |
| Non-GAAP adjustments to net income |  | $ | 14.7 |  |  | $ | 52.5 |  |  | $ | 73.6 |  |  | $ | 58.0 |  |
| Total EPS impact |  | $ | 0.58 |  |  | $ | 2.29 |  |  | $ | 2.92 |  |  | $ | 2.53 |  |

[0000889331-19-000007:8k_2_02:75]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-18 |  | Q4-17 |  | YTD-18 |  | YTD-17 |
| Net sales |  | $ | 402.3 |  |  | $ | 304.8 |  |  | $ | 1,718.5 |  |  | $ | 1,221.5 |  |
| GAAP operating income |  | $ | 51.6 |  |  | $ | 50.8 |  |  | $ | 225.0 |  |  | $ | 218.5 |  |
| Add back non-GAAP adjustments |  | 9.3 |  |  | 2.1 |  |  | 88.7 |  |  | 10.3 |  |
| Adjusted operating income |  | $ | 60.9 |  |  | $ | 52.9 |  |  | $ | 313.7 |  |  | $ | 228.8 |  |
| Adjusted operating margin |  | 15.1 | % |  | 17.4 | % |  | 18.3 | % |  | 18.7 | % |
| Add back amortization |  | 10.0 |  |  | 6.3 |  |  | 39.8 |  |  | 24.7 |  |
| Add back depreciation |  | 13.4 |  |  | 10.1 |  |  | 51.0 |  |  | 38.3 |  |
| Adjusted EBITDA |  | $ | 84.3 |  |  | $ | 69.3 |  |  | $ | 404.5 |  |  | $ | 291.8 |  |
| Adjusted EBITDA margin |  | 21.0 | % |  | 22.7 | % |  | 23.5 | % |  | 23.9 | % |

[0000889331-19-000007:8k_2_02:76]
| Net sales reconciliation |  | Q4-18 vs. Q4-17 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | 62 | % |  | (3 | )% |  | (3 | )% |  | 32 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 56 | % |  | — |  |  | — |  |  | 30 | % |
| Divestitures |  | — |  |  | — |  |  | (13 | )% |  | (1 | )% |
| FX impact |  | (1 | )% |  | (2 | )% |  | (1 | )% |  | (1 | )% |
| Organic net sales growth |  | 7 | % |  | (1 | )% |  | 11 | % |  | 4 | % |

[0000889331-19-000007:8k_2_02:77]
| Net sales reconciliation |  | YTD-18 vs. YTD-17 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | 70 | % |  | 6 | % |  | 8 | % |  | 41 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 58 | % |  | — |  |  | — |  |  | 32 | % |
| Divestitures |  | — |  |  | — |  |  | (6 | )% |  | (1 | )% |
| FX impact |  | 1 | % |  | 2 | % |  | 1 | % |  | 2 | % |
| Organic net sales growth |  | 11 | % |  | 4 | % |  | 13 | % |  | 8 | % |

[0000889331-19-000007:8k_2_02:78]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-18 |  | Q4-17 |  | YTD-18 |  | YTD-17 |
| Income taxes |  | $ | 7.1 |  |  | $ | 54.5 |  |  | $ | 40.4 |  |  | $ | 84.5 |  |
| Effective rate |  | 17.9 | % |  | 124.7 | % |  | 19.7 | % |  | 41.4 | % |
| Non-GAAP adjustments - income taxes |  | 1.0 |  |  | (46.5 | ) |  | 15.1 |  |  | (45.3 | ) |
| Adjusted income taxes |  | $ | 8.1 |  |  | $ | 8.0 |  |  | $ | 55.5 |  |  | $ | 39.2 |  |
| Adjusted effective rate |  | 14.6 | % |  | 16.2 | % |  | 18.9 | % |  | 18.1 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-18 |  | Q4-17 |  | YTD-18 |  | YTD-17 |
| Net cash provided by operating activities |  | $ | 79.7 |  |  | $ | 87.9 |  |  | $ | 331.8 |  |  | $ | 269.2 |  |
| Less: Purchases of property, plant and equipment |  | (18.8 | ) |  | (17.5 | ) |  | (74.8 | ) |  | (65.9 | ) |
| Free cash flow |  | $ | 60.9 |  |  | $ | 70.4 |  |  | $ | 257.0 |  |  | $ | 203.3 |  |

[0000889331-19-000007:8k_2_02:79]
Note: Total will not always foot due to rounding

[0000889331-19-000007:8k_2_02:80]
(a) reflected in selling, general and administrative expenses ("SG&A")

[0000889331-19-000007:8k_2_02:81]
(b) $2.3 million and $0.1 million reflected in SG&A and cost of sales for three months ended December 29, 2018, respectively. $11.7 million and $0.9 million reflected in SG&A and cost of sales, respectively for the twelve months ended December 29, 2018. $0.7 million and $2.2 million reflected in SG&A for three and twelve months ended December 30, 2017, respectively

[0000889331-19-000007:8k_2_02:82]
(c) reflected in amortization of intangibles

[0000889331-19-000007:8k_2_02:83]
(d) reflected in SG&A

[0000889331-19-000007:8k_2_02:84]
(e) $2.4 million, $1.6 million and $0.5 million reflected in SG&A, research and development expenses and cost of sales, respectively

[0000889331-19-000007:8k_2_02:85]
(f) reflected in cost of sales

[0000889331-19-000007:8k_2_02:86]
(g) included $2.2 million gain on the sale of a building, $1.1 million loss on the sale of a business, $1.0 million of cost associated with the remediation of certain coal mines and $1.0 million contingent consideration expense for the acquisition of Monolith

[0000889331-19-000007:8k_2_02:87]
(h) reflected the tax impact associated with the non-GAAP adjustments. The three months ended December 29, 2018 reflected a $3.2 million tax expense related to the finalization of 2017 provisional reasonable estimate in connection with the legislation commonly referred to as the Tax Cuts and Job Act (the "Tax Act"), partially offset by a$1.5 million benefit for previously unrecognized tax benefits in respect of which the statute of limitations has expired. The three months ended December 30, 2017 reflected an income tax expense of $49 million for the one-time charge (the "Toll Charge") recorded as part of the provisional reasonable estimate of the impact of the Tax Act
