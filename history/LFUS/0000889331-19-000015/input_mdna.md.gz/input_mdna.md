# LFUS MD&A — 0000889331-19-000015


## mdna

[0000889331-19-000015:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0000889331-19-000015:mdna:2]
The following discussion of Littelfuse’s financial condition and results of operations should be read together with the Consolidated Financial Statements and notes to those statements included in Item 8 of Part II of this Annual Report on Form 10-K.

[0000889331-19-000015:mdna:3]
BUSINESS

[0000889331-19-000015:mdna:4]
For a description of the Company’s business, segments and product offerings, see Item 1, Business.

[0000889331-19-000015:mdna:5]
2018 EXECUTIVE OVERVIEW

[0000889331-19-000015:mdna:6]
Net sales increased by $496.9 million, or 40.7%, in 2018 compared to 2017. The increase was primarily driven by the acquisition of IXYS, which added $378.2 million in net sales and higher volume in Electronics segment due to strong demand across various end markets and geographies within the segment. Additionally, net sales increased by $16.7 million due to favorable changes in foreign exchange rates. The Company recognized net income of $164.6 million, or $6.52 per diluted share for the year ended December 29, 2018 compared to net income of $119.5 million, or $5.21 per diluted share, for the year ended December 30, 2017. The increase in net income reflects operating income increases in both the Electronics and Automotive segments and lower income tax expense driven by a one-time tax charge (the "Toll Charge") of $49.0 million in 2017 due to the enactment of the Tax Cuts and Jobs Act, partially offset by $36.9 million of purchase accounting inventory step-up charges, higher amortization expense and acquisition-related and integration charges related to the IXYS acquisition. Additionally, the per share results reflect an increase of 2.1 million shares in the weighted average diluted shares outstanding resulting from the shares issued in conjunction with the acquisition of IXYS.

[0000889331-19-000015:mdna:7]
Net cash provided by operating activities was $331.8 million for the year ended December 29, 2018 as compared to $269.2 million for the year ended December 30, 2017. The increase in net cash provided by operating activities reflected higher earnings and favorable working capital management, which more than offset higher payments related to cash taxes and acquisition and integration costs.

[0000889331-19-000015:mdna:8]
On January 17, 2018, the Company acquired IXYS, a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 3,500 customers through its direct sales force and global distribution partners. The purchase price for IXYS was $856.5 million, which included consideration of cash, Littelfuse common stock, and the value of converted or cash settled IXYS equity awards. IXYS’ operations are included in the Electronics segment.

[0000889331-19-000015:mdna:9]
On July 6, 2018, the Trump administration imposed Section 301 tariffs on certain products (known as List 1) that are imported into the United States where the country of origin is China. Additionally, on August 23, 2018, List 2 was put into effect which imposed an additional 25% tariff to products on the list items. These tariffs primarily impact the Electronics segment and, to a lesser extent, our Automotive segment. The Company continues to evaluate the impact on our future results of operations.

[0000889331-19-000015:mdna:10]
OUTLOOK

[0000889331-19-000015:mdna:11]
Vision and Strategy

[0000889331-19-000015:mdna:12]
The Company works with its customers to design and develop technologies that help them build safer, more reliable and more efficient products for a safer, greener and increasingly connected world in virtually every market that uses electrical energy, including automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Built upon that framework, the Company’s strategy is centered on growing its core circuit protection business, accelerating its growth in power control, and doubling its sensor platform.

[0000889331-19-000015:mdna:13]
The Company’s strategic plan is focused on maximizing shareholder value by driving profitable sales growth, earnings per share growth, strong cash flow generation, and maintaining a balanced approach to capital allocation. The Company pursues the following major strategic initiatives, which are summarized below, along with more specific areas of focus.

[0000889331-19-000015:mdna:14]
| Strategic Objective |  | 2019 and Future Priorities |
| Double digit sales growth |  | ● | Grow through increased product content with existing customers and increased market share |
|  |  | ● | Expand portfolio into new and underpenetrated geographies and end markets |
|  |  | ● | Increase innovation capabilities and investments |
|  |  | ● | Expand presence in products and applications that are converging across business segments |
|  |  | ● | Targeted mergers and acquisitions |
| EPS growth |  | ● | Focus on higher profitability growth opportunities |
|  |  | ● | Grow operating margins through operational excellence |
|  |  | ● | Disciplined approach to managing costs |
| Cash flow and liquidity |  | ● | Disciplined management of working capital |
|  |  | ● | Prudent deployment of capital |
|  |  | ● | Disciplined approach to mergers and acquisitions |
|  |  | ● | Grow dividend in line with earnings |
|  |  | ● | Periodic share repurchases |

[0000889331-19-000015:mdna:15]
The Company’s strategy is to generate profitable sales growth. In order to accomplish this, the Company is focusing on accelerating organic growth by increasing its content and share gains, enhancing technology efforts to drive innovation, capitalizing on cross segment opportunities, and gaining traction in underpenetrated geographies and markets. The Company will continue to make targeted strategic acquisitions that align to its strategy and financial targets to support new business, products, markets, and technologies while leveraging existing customers.

[0000889331-19-000015:mdna:16]
Management believes that sustaining profitability through a combination of profitable organic growth and acquisitions is critical to the Company’s competitiveness, while enhancing value the Company delivers to its customers. In addition, the Company continues to implement initiatives across all platforms to enhance productivity while managing its cost structure, including integration of operations and streamlining administrative and support activities to drive operating margins.

[0000889331-19-000015:mdna:17]
The Company seeks to deploy its capital using a balanced approach. Priorities for capital deployment, over time, include investments to drive increased organic growth, targeted acquisitions that align to the Company’s strategic and financial metrics and returning capital to shareholders through dividends and periodic share repurchases.

[0000889331-19-000015:mdna:18]
The Company uses several key indicators to gauge progress toward achieving these objectives. These indicators include organic sales growth, operating margins, cash flow from operations and capital expenditures. Through cycles, the Company targets double-

[0000889331-19-000015:mdna:19]
digit long-term (2017-2021) sales growth, split between 5-7% accelerated organic sales growth and 5-7% growth from strategic acquisitions, while targeting operating margins between 17% and 19% and double-digit earnings per share growth. Cash flow from operations less capital expenditures is targeted to approximate or exceed net income but in any given year can be significantly impacted by the timing of non-recurring or infrequent expenditures.

[0000889331-19-000015:mdna:20]
Significant Accounting Policies and Critical Estimates

[0000889331-19-000015:mdna:21]
Critical Accounting Policies and Estimates

[0000889331-19-000015:mdna:22]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The Company’s most critical accounting policies are those that are most important to the portrayal of its financial condition and results of operations, and which require the Company to make its most difficult and subjective judgments, often as a result of the need to make estimates of matters that are inherently uncertain. The Company has identified the following as its most critical accounting policies and judgments. Although management believes that its estimates and assumptions are reasonable, they are based upon information available when they are made, and therefore, actual results may differ from these estimates under different assumptions or conditions. The Company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0000889331-19-000015:mdna:23]
Revenue Recognition

[0000889331-19-000015:mdna:24]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.

[0000889331-19-000015:mdna:25]
Revenue Disaggregation

[0000889331-19-000015:mdna:26]
The following table disaggregates the Company’s revenue by primary business units for the fiscal year ended December 29, 2018:

[0000889331-19-000015:mdna:27]
|  |  | Fiscal Year Ended December 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 648,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 648,967 |  |
| Electronics – Passive Products and Sensors |  | 475,329 |  |  | — |  |  | — |  |  | 475,329 |  |
| Passenger Car Products |  | — |  |  | 240,501 |  |  | — |  |  | 240,501 |  |
| Commercial Vehicle Products |  | — |  |  | 121,562 |  |  | — |  |  | 121,562 |  |
| Automotive Sensors |  | — |  |  | 117,728 |  |  | — |  |  | 117,728 |  |
| Industrial Products |  | — |  |  | — |  |  | 114,381 |  |  | 114,381 |  |
| Total |  | $ | 1,124,296 |  |  | $ | 479,791 |  |  | $ | 114,381 |  |  | $ | 1,718,468 |  |

[0000889331-19-000015:mdna:28]
See Note 16, Segment Information, for net sales by segment and countries.

[0000889331-19-000015:mdna:29]
Revenue Recognition

[0000889331-19-000015:mdna:30]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-19-000015:mdna:31]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-19-000015:mdna:32]
Revenue and Billing

[0000889331-19-000015:mdna:33]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

[0000889331-19-000015:mdna:34]
Ship and Debit Program

[0000889331-19-000015:mdna:35]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-19-000015:mdna:36]
Return to Stock

[0000889331-19-000015:mdna:37]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-19-000015:mdna:38]
Volume Rebates

[0000889331-19-000015:mdna:39]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-19-000015:mdna:40]
Allowance for Doubtful Accounts:

[0000889331-19-000015:mdna:41]
The Company evaluates the collectability of its trade receivables based on a combination of factors. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a specific customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-19-000015:mdna:42]
Inventory

[0000889331-19-000015:mdna:43]
The Company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life, and quality issues. Based on the analysis, the Company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable values.

[0000889331-19-000015:mdna:44]
Goodwill

[0000889331-19-000015:mdna:45]
The Company’s methodology for allocating the purchase price of acquisitions is based on established valuation techniques that reflect the consideration of a number of factors, including valuations performed by third-party appraisers when appropriate. Goodwill is measured as the excess of the cost of an acquired entity over the fair value assigned to identifiable assets acquired and liabilities assumed. Based on its current organization structure, the Company has seven reporting units for which cash flows are determinable and to which goodwill has been allocated. Goodwill is either assigned to a specific reporting unit or allocated between reporting units based on the relative excess fair value of each reporting unit.

[0000889331-19-000015:mdna:46]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value.

[0000889331-19-000015:mdna:47]
Quantitative Assessment for Impairment

[0000889331-19-000015:mdna:48]
For the seven reporting units with goodwill, the Company compared the estimated fair value of each reporting unit to its carrying value. If the carrying value of a reporting unit exceeded the estimated fair value, the difference between the estimated fair value and carrying value is recorded as the amount of the goodwill impairment charge. The results of the goodwill impairment test as of October 1, 2018 indicated that the estimated fair values for each of the seven reporting units exceeded their respective carrying values. Accordingly, there were no goodwill impairment charges recorded as part of the Company’s 2018 annual goodwill impairment test.

[0000889331-19-000015:mdna:49]
As part of its impairment test for these reporting units, the Company engaged a third-party appraisal firm to assist in the Company’s determination of the estimated fair values. This determination included estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping. The Company weighted both the income and market approach equally to estimate the concluded fair value of each reporting unit. The determination of fair value requires the Company to make significant estimates and assumptions, which primarily include, but are not limited to: the selection of appropriate peer group companies; control premiums appropriate for acquisitions in which the Company competes; the discount rate; terminal growth rates; and forecasts of revenue, operating income, depreciation and amortization and capital expenditures.

[0000889331-19-000015:mdna:50]
Goodwill Impairment Assumptions

[0000889331-19-000015:mdna:51]
Although the Company believes its estimates of fair value are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results or other underlying assumptions could have a significant impact on the fair value of the reporting units. Future declines in the overall market value of the Company’s equity may also result in a conclusion that the fair value of one or more reporting units has declined below its carrying value.

[0000889331-19-000015:mdna:52]
One measure of the sensitivity of the amount of goodwill impairment charges to key assumptions is the amount by which each reporting unit “passed” (fair value exceeds the carrying value) the goodwill impairment test. All seven of the reporting units passed the goodwill impairment test, with fair values that exceeded the carrying values by between 63% and 370% of their respective estimated fair values. As of the most recent annual test conducted on October 1, 2018, the Company noted that the excess of fair value over the carrying value, was 176%, 80%, 233%, 202%, 63%, 114%, and 370% for its reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, Automotive Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test.

[0000889331-19-000015:mdna:53]
Generally, changes in estimates of expected future cash flows would have a similar effect on the estimated fair value of the reporting unit. That is, a 1.0% decrease in estimated annual future cash flows would decrease the estimated fair value of the reporting unit by approximately 1.0%. The estimated long-term net sales growth rate can have a significant impact on the estimated future cash

[0000889331-19-000015:mdna:54]
flows, and therefore, the fair value of each reporting unit. A 1.0% decrease in the long-term net sales growth rate would have resulted in no reporting units failing the goodwill impairment test. Of the other key assumptions that impact the estimated fair values, most reporting units have the greatest sensitivity to changes in the estimated discount rate. The estimated discount rate was 11.7% for the Electronics-Passive Products and Sensors, Commercial Vehicle Products, Automotive Sensors and Power Fuse reporting units, 9.7% for the Electronics-Semiconductor and Passenger Car Products reporting units, and 12.7% for Relays. A 1.0% increase in the estimated discount rates would have resulted in no reporting units failing the annual goodwill impairment test. The Company believes that its estimates of future cash flows and discount rates are reasonable, but future changes in the underlying assumptions could differ due to the inherent uncertainty in making such estimates. Additionally, price deterioration or lower volume could have a significant impact on the fair values of the reporting units.

[0000889331-19-000015:mdna:55]
Long-Lived Assets

[0000889331-19-000015:mdna:56]
The Company evaluates the recoverability of other long-lived assets, including property, plant and equipment and certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset group may not be recoverable. Factors which could trigger an impairment review include significant underperformance relative to historical or projected operating results, significant changes in the manner of use of the assets or the strategy for the overall business, a significant decrease in the market value of the assets or significant negative industry or economic trends. When the Company determines that the carrying value of long-lived assets may not be recoverable based upon the existence of one or more of the indicators, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition. If the carrying value of an asset exceeds its estimated future undiscounted cash flows, an impairment loss is recorded for the excess of the asset’s carrying value over its fair value. During the year ended December 29, 2018, the Company recognized non-cash impairment charges of $1.6 million and $0.5 million related to a building for sale and the Custom Products reporting unit trade name, respectively, associated with the exit of the Custom business within the Industrial Segment. During the year ended December 30, 2017, the Company recognized a loss of $2.9 million related to certain machinery and equipment in the Electronics and Automotive segments due to changes in the expected use of these certain assets.

[0000889331-19-000015:mdna:57]
Environmental Liabilities

[0000889331-19-000015:mdna:58]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The Company evaluates its reserve for coal mine remediation annually utilizing a third-party expert.

[0000889331-19-000015:mdna:59]
Pension and Supplemental Executive Retirement Plan

[0000889331-19-000015:mdna:60]
The Company records annual income and expense amounts relating to its pension and postretirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors. The Company maintains several pension plans in international locations. The expected returns on plan assets and discount rates are determined based on each plan’s investment approach, local interest rates and plan participant profiles. The discount rates for the Company’s defined benefit plans primarily in Europe and the Asia-Pacific regions at December 29, 2018 and December 30, 2017 were 3.1% and 3.1%, respectively.

[0000889331-19-000015:mdna:61]
A 50 basis point change in the discount rates at December 29, 2018 would have the following effect on the projected benefit obligation:

[0000889331-19-000015:mdna:62]
| (in millions) | 0.5%Increase |  | 0.5%Decrease |
| Projected benefit obligation | $ | (7.4 | ) |  | $ | 8.1 |  |

[0000889331-19-000015:mdna:63]
Equity-based Compensation

[0000889331-19-000015:mdna:64]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments in the foreseeable future.

[0000889331-19-000015:mdna:65]
Total equity-based compensation expense for all equity compensation plans was $28.2 million, $17.3 million, and $12.8 million in 2018, 2017, and 2016, respectively. Further information regarding this expense is provided in Note 12, Stock-Based Compensation, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-19-000015:mdna:66]
Income Taxes

[0000889331-19-000015:mdna:67]
The Company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-19-000015:mdna:68]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws (such as the Tax Act), or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-19-000015:mdna:69]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-19-000015:mdna:70]
On December 22, 2017, the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduces the U.S. corporate federal income tax rate from 35% to 21%, adds base broadening provisions which limit deductions and address excessive international tax planning, imposes a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enables repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. Other than the Toll Charge (which, except for the IXYS impact, was applicable to the Company for 2017), the provisions are generally applicable to the Company in 2018 and beyond.

[0000889331-19-000015:mdna:71]
In accordance with the guidance provided in SEC Staff Accounting Bulletin (“SAB”) No. 118, in the fourth quarter of 2017 the Company recorded a charge of $47.0 million as a provisional reasonable estimate of the impact of the Tax Act, including $49.0 million for the Toll Charge net of $2.0 million for other net tax benefits. In the fourth quarter of 2018, within the measurement period outlined in SAB No. 118, the Company finalized its estimates of the impact of the Tax Act as of December 30, 2017 and recorded a charge of $3.2 million, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. In addition, the Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation. This was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities.

[0000889331-19-000015:mdna:72]
One of the base broadening provisions of the Tax Act is commonly referred to as the tax on global intangible low-taxed income provisions (the "GILTI"). In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the year ended December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-19-000015:mdna:73]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-19-000015:mdna:74]
Off-Balance Sheet Arrangements

[0000889331-19-000015:mdna:75]
Other than non-cancellable operating lease commitments, the Company does not have off-balance sheet arrangements, financings or special purpose entities.

[0000889331-19-000015:mdna:76]
In the financial review that follows, the Company discusses its consolidated results of operations, financial position, cash flows and certain other information. This discussion should be read in conjunction with the Company’s Consolidated Financial Statements and related notes.

[0000889331-19-000015:mdna:77]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 29, 2018 AS COMPARED TO THE YEAR ENDED DECEMBER 30, 2017

[0000889331-19-000015:mdna:78]
The following table summarizes the Company’s consolidated results of operations for periods presented. The fiscal year 2018 includes approximately $88.7 million of non-segment charges, of which $82.9 million of charges are primarily related to the IXYS acquisition as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report. These charges include $36.9 million of purchase accounting inventory step-up charges, $18.7 million in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $12.4 million in backlog amortization costs, $8.3 million of employee termination costs and other restructuring charges, $4.5 million of stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods, and $2.1 million change in control expense related to IXYS. In addition, there were $5.8 million of employee termination costs, impairment and other restructuring charges and acquisition-related expenses for other contemplated acquisitions and included charges associated with the exit of the Custom business in the second quarter within the Industrial segment.

[0000889331-19-000015:mdna:79]
The fiscal year 2017 includes approximately $10.3 million of non-segment charges. These included acquisition-related and integration costs related to legal, accounting and other expenses associated with completed or pending acquisitions of approximately $8.0 million, including $1.6 million of purchase accounting inventory charges related to the Company’s 2017 acquisition of U.S. Sensor as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report, and $2.2 million of charges related to restructuring and production transfers in the Company’s Asia operations.

[0000889331-19-000015:mdna:80]
Fiscal year 2018 also included approximately $0.9 million in foreign currency exchange gains primarily attributable to changes in the value of the euro, Mexico peso, Philippine peso and Chinese renminbi against the U.S. dollar, while fiscal year 2017 also included approximately $2.4 million in foreign currency exchange losses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar.

[0000889331-19-000015:mdna:81]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2018 |  | 2017 |  | Change |  | % Change |
| Net sales | $ | 1,718,468 |  |  | $ | 1,221,534 |  |  | $ | 496,934 |  |  | 40.7 | % |
| Gross profit | 652,541 |  |  | 506,533 |  |  | 146,008 |  |  | 28.8 | % |
| Operating expenses | 427,492 |  |  | 288,022 |  |  | 139,470 |  |  | 48.4 | % |
| Operating income | 225,049 |  |  | 218,511 |  |  | 6,538 |  |  | 3.0 | % |
| Other income, net | (1,599 | ) |  | (1,282 | ) |  | (317 | ) |  | 24.7 | % |
| Income before income taxes | 204,942 |  |  | 204,037 |  |  | 905 |  |  | 0.4 | % |
| Income taxes | 40,377 |  |  | 84,518 |  |  | (44,141 | ) |  | (52.2 | )% |
| Net income | 164,565 |  |  | 119,519 |  |  | 45,046 |  |  | 37.7 | % |

[0000889331-19-000015:mdna:82]
Net Sales

[0000889331-19-000015:mdna:83]
Net sales for 2018 of $1,718.5 million increased $496.9 million, or 40.7%, compared to the prior year with increases of $378.2 million and $6.5 million resulting from incremental net sales related to the IXYS and U.S. Sensor acquisitions, respectively, $16.7 million of favorable changes in foreign exchange rates, and volume growth across all three segments.

[0000889331-19-000015:mdna:84]
Gross Profit

[0000889331-19-000015:mdna:85]
Gross profit was $652.5 million, or 38.0% of net sales, in 2018, compared to $506.5 million, or 41.5% of net sales, in 2017. The increase in gross profit reflects the IXYS acquisition and volume growth and expense leverage across all segments. The decrease in gross margin is primarily due to the purchase accounting inventory charges of $36.9 million, which negatively impacted gross margin by 2.1 percentage points, and an unfavorable mix of products from the IXYS acquisition, which historically had lower gross margins.

[0000889331-19-000015:mdna:86]
Operating Expenses

[0000889331-19-000015:mdna:87]
Total operating expenses were $427.5 million, or 24.9% of net sales, for 2018 compared to $288.0 million, or 23.6% of net sales, for 2017. The increase in operating expenses of $139.5 million was primarily due to the incremental operating expenses related to the IXYS and U.S. Sensor acquisitions, an increase in amortization expense of $27.5 million resulting from the acquisition of IXYS as well as higher acquisition-related and integration costs of $12.1 million. Total operating expenses as a percent of net sales increased from 23.6% in 2017 to 24.9% in 2018 primarily due to the higher amortization expense and acquisition-related and integration charges noted above.

[0000889331-19-000015:mdna:88]
Operating Income

[0000889331-19-000015:mdna:89]
Operating income for 2018 was $225.0 million, an increase of $6.5 million or 3.0% compared to $218.5 million for 2017. The increase in operating income is primarily due to the acquisition of IXYS and volume growth in the Electronics and Industrial segments, partially offset by $36.9 million of purchase accounting inventory charges, higher acquisition-related and integration charges and amortization expense. Operating margins decreased from 17.9% in 2017 to 13.1% in 2018 driven by the purchase accounting inventory charges, higher amortization expense and acquisition-related and integration charges that negatively impacted margins by 2.1%, 1.6% and 0.7%, respectively.

[0000889331-19-000015:mdna:90]
Income Before Income Taxes

[0000889331-19-000015:mdna:91]
Income before income taxes for 2018 was $204.9 million, or 11.9% of net sales compared to $204.0 million, or 16.7% of net sales, for 2017. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was unfavorably impacted by higher interest expense of $9.2 million mainly resulting from increased borrowings, partially offset by  increases in foreign exchange gains of $3.2 million.

[0000889331-19-000015:mdna:92]
Income Taxes

[0000889331-19-000015:mdna:93]
Income tax expense for 2018 was $40.4 million, or an effective tax rate of 19.7% compared to income tax expense of $84.5 million, or an effective tax rate of 41.4%, for 2017. The 2018 income tax expense includes a charge of $3.2 million associated with finalizing the 2017 provisional reasonable estimate, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. The 2017 income tax expense includes a charge of $47 million as a provisional reasonable estimate of the impact of the Tax Act, including $49 million for the Toll Charge net of $2 million for other net tax benefits. Additionally, our tax rates are lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by the impact of taxes on unremitted earnings, and, with respect to 2018, the impact of the GILTI provisions of the Tax Act and non-U.S. losses and expenses with no tax benefit.

[0000889331-19-000015:mdna:94]
Segment Information

[0000889331-19-000015:mdna:95]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-19-000015:mdna:96]
The following table is a summary of the Company’s net sales by segment:

[0000889331-19-000015:mdna:97]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | % Change |
| Electronics | $ | 1,124.3 |  |  | $ | 661.9 |  |  | $ | 462.4 |  |  | 69.9 | % |
| Automotive | 479.8 |  |  | 453.2 |  |  | 26.6 |  |  | 5.9 | % |
| Industrial | 114.4 |  |  | 106.4 |  |  | 8.0 |  |  | 7.5 | % |
| Total | $ | 1,718.5 |  |  | $ | 1,221.5 |  |  | $ | 497.0 |  |  | 40.7 | % |

[0000889331-19-000015:mdna:98]
Electronics Segment

[0000889331-19-000015:mdna:99]
The Electronics segment net sales increased $462.4 million, or 69.9%, in 2018 compared to 2017 due to incremental net sales related to the IXYS and U.S. Sensor acquisitions of $378.2 million and $6.5 million, respectively, volume growth driven by the continued strong demand across various end markets and geographies, and favorable foreign exchange impacts of $6.5 million.

[0000889331-19-000015:mdna:100]
Automotive Segment

[0000889331-19-000015:mdna:101]
Net sales in the Automotive segment increased $26.6 million, or 5.9%, in 2018 compared to 2017 due to volume growth across all businesses primarily led by the commercial vehicle and sensor businesses, and favorable foreign exchange impacts of $9.8 million.

[0000889331-19-000015:mdna:102]
Industrial Segment

[0000889331-19-000015:mdna:103]
The Industrial segment net sales increased $8.0 million, or 7.5%, in 2018 compared to 2017 primarily due to volume growth in the power fuse and relay businesses and favorable foreign exchange impacts of $0.4 million, partially offset by a decline in sales from the exit of the Custom business during 2018.

[0000889331-19-000015:mdna:104]
Geographic Net Sales Information

[0000889331-19-000015:mdna:105]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-19-000015:mdna:106]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | % Change |
| Asia-Pacific | $ | 753.3 |  |  | $ | 541.1 |  |  | $ | 212.2 |  |  | 39.2 | % |
| Americas | 578.6 |  |  | 436.5 |  |  | 142.1 |  |  | 32.6 | % |
| Europe | 386.6 |  |  | 243.9 |  |  | 142.7 |  |  | 58.5 | % |
| Total | $ | 1,718.5 |  |  | $ | 1,221.5 |  |  | $ | 497.0 |  |  | 40.7 | % |

[0000889331-19-000015:mdna:107]
Asia-Pacific

[0000889331-19-000015:mdna:108]
Asia-Pacific net sales increased $212.2 million, or 39.2%, in 2018 compared to 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $173.9 million and volume growth across all segments as well as favorable foreign exchange impacts of $3.7 million.

[0000889331-19-000015:mdna:109]
Americas

[0000889331-19-000015:mdna:110]
Net sales in the Americas increased $142.1 million, or 32.6%, in 2018 compared to 2017 driven by incremental net sales related to the IXYS and U.S. Sensor acquisitions of $90.7 million and $5.5 million, respectively, volume growth across all segments and favorable foreign exchange impacts of $0.4 million.

[0000889331-19-000015:mdna:111]
Europe

[0000889331-19-000015:mdna:112]
European net sales increased $142.7 million, or 58.5%, in 2018 compared to 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $113.6 million with volume growth across the Electronics and Automotive segments as well as favorable foreign exchange impacts of $12.6 million.

[0000889331-19-000015:mdna:113]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 30, 2017 AS COMPARED TO THE YEAR ENDED DECEMBER 31, 2016

[0000889331-19-000015:mdna:114]
The following table summarizes the Company’s consolidated results of operations for periods presented. The fiscal year 2017 includes approximately $10.3 million of non-segment charges. These included acquisition-related and integration costs related to legal, accounting and other expenses associated with completed or pending acquisitions of approximately $8.0 million, including $1.6 million of purchase accounting inventory charges related to the Company’s 2017 acquisition of U.S. Sensor as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report, and $2.2 million of charges related to restructuring and production transfers in the Company’s Asia operations.

[0000889331-19-000015:mdna:115]
The fiscal year 2016 includes approximately $50.0 million of non-segment charges. These included $14.8 million of charges related to the impairment of the Custom Products reporting unit, $21.4 million of acquisition and integration costs associated with the Company’s 2016 acquisitions, primarily PolySwitch, $7.8 million of non-cash fair value step-up inventory charges relating to the Company’s 2016 acquisitions, primarily PolySwitch, as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report, $1.9 million in charges related to the closure of the Company’s manufacturing facility in Denmark, $1.6 million related to the Company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines, and $2.5 million related to restructuring costs.

[0000889331-19-000015:mdna:116]
Fiscal year 2017 also included approximately $2.4 million in foreign currency exchange losses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar, while fiscal year 2016 also included approximately $0.5 million in foreign currency exchange losses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar.

[0000889331-19-000015:mdna:117]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2017 |  | 2016 |  | Change |  | % Change |
| Net sales | $ | 1,221,534 |  |  | $ | 1,056,159 |  |  | $ | 165,375 |  |  | 15.7 | % |
| Gross profit | 506,533 |  |  | 413,117 |  |  | 93,416 |  |  | 22.6 | % |
| Operating expenses | 288,022 |  |  | 282,473 |  |  | 5,549 |  |  | 2.0 | % |
| Operating income | 218,511 |  |  | 130,644 |  |  | 87,867 |  |  | 67.3 | % |
| Other income, net | (1,282 | ) |  | (1,730 | ) |  | (448 | ) |  | (25.9 | )% |
| Income before income taxes | 204,037 |  |  | 123,274 |  |  | 80,763 |  |  | 65.5 | % |
| Income taxes | 84,518 |  |  | 18,786 |  |  | 65,732 |  |  | 349.9 | % |
| Net income | 119,519 |  |  | 104,488 |  |  | 15,031 |  |  | 14.4 | % |

[0000889331-19-000015:mdna:118]
Net Sales

[0000889331-19-000015:mdna:119]
Net sales for 2017 of $1,221.5 million increased $165.4 million, or 15.7%, compared to the prior year, resulting from the prior year acquisitions of PolySwitch, ON Portfolio, and Menber’s and $5.4 million from the current year U.S. Sensor acquisition. The remaining increase in net sales was primarily due to higher volume across all product lines in the Electronics segment and passenger car and commercial vehicle businesses within the Automotive segment partially offset by the divestitures of two non-core product lines within the Industrial segment in 2016.

[0000889331-19-000015:mdna:120]
Gross Profit

[0000889331-19-000015:mdna:121]
Gross profit was $506.5 million, or 41.5% of net sales, in 2017, compared to $413.1 million, or 39.1% of net sales, in 2016. The increase in gross profit and gross margin reflects the incremental net sales and improved leverage in expenses and profits related to the prior year acquisitions, primarily in the Electronics segment.

[0000889331-19-000015:mdna:122]
Operating Expenses

[0000889331-19-000015:mdna:123]
Total operating expenses were $288.0 million, or 23.6% of net sales, for 2017 compared to $282.5 million, or 26.7% of net sales, for 2016. The increase in operating expenses of $5.5 million was primarily due to acquisitions, higher selling costs, higher research and development costs of $8.3 million and an increase of $5.4 million in amortization expense of intangible assets due to the acquisitions, partially offset by the $14.8 million of goodwill and other intangible asset impairment charges recognized in 2016 and lower acquisition-related expenses and integration costs of $13.4 million. Selling, general, and administrative expenses

[0000889331-19-000015:mdna:124]
increased by $6.7 million to $212.8 million, but decreased from 19.5% to 17.4% as a percentage of net sales for 2017 compared to 2016 primarily as a result of lower acquisition-related expenses and integration costs of $13.4 million and cost control initiatives partially offset by the acquisitions.

[0000889331-19-000015:mdna:125]
Operating Income

[0000889331-19-000015:mdna:126]
Operating income for 2017 was $218.5 million, an increase of $87.9 million or 67.3% compared to $130.6 million for 2016. The increase in operating income was the result of acquisitions and higher volume in the Electronics segment. Operating margins increased from 12.4% in 2016 to 17.9% in 2017 due to the acquisitions, improvement in gross margins primarily driven by the Electronics segment, lower acquisition and integration related costs, the prior year goodwill and other intangible asset impairment charge and operational efficiencies. Also, the prior year goodwill and other intangible asset impairment charge reduced the operating margin by 1.4% in 2016.

[0000889331-19-000015:mdna:127]
Income Before Income Taxes

[0000889331-19-000015:mdna:128]
Income before income taxes for 2017 was $204.0 million, or 16.7% of net sales compared to $123.3 million, or 11.7% of net sales, for 2016. Income before income taxes was impacted by an increase in operating income described above, partially offset by higher interest expense of $4.8 million reflecting increased borrowings and unfavorable changes in foreign exchange rates of $1.9 million primarily as a result of fluctuations in the Chinese renminbi and Philippine peso against the U.S. dollar partially offset by fluctuations in the Euro against the U.S. dollar.

[0000889331-19-000015:mdna:129]
Income Taxes

[0000889331-19-000015:mdna:130]
Income tax expense for 2017 was $84.5 million, or an effective tax rate of 41.4% compared to income tax expense of $18.8 million, or an effective tax rate of 15.2%, for 2016. The increase in 2017 reflects a fourth quarter charge of $47 million as a provisional reasonable estimate of the impact of the Tax Act, including $49 million for the Toll Charge net of $2 million for other net tax benefits. Additionally, the effective tax rates for 2017 and 2016 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions partially offset by the impact of taxes on unremitted earnings, and, with respect to 2016, a one-time deduction with respect to the stock of one of the Company’s affiliates, partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded.

[0000889331-19-000015:mdna:131]
Segment Information

[0000889331-19-000015:mdna:132]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-19-000015:mdna:133]
The following table is a summary of the Company’s net sales by segment:

[0000889331-19-000015:mdna:134]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | % Change |
| Electronics | $ | 661.9 |  |  | $ | 535.2 |  |  | $ | 126.7 |  |  | 23.7 | % |
| Automotive | 453.2 |  |  | 415.2 |  |  | 38.0 |  |  | 9.2 | % |
| Industrial | 106.4 |  |  | 105.8 |  |  | 0.6 |  |  | 0.6 | % |
| Total | $ | 1,221.5 |  |  | $ | 1,056.2 |  |  | $ | 165.3 |  |  | 15.7 | % |

[0000889331-19-000015:mdna:135]
Electronics Segment

[0000889331-19-000015:mdna:136]
The Electronics segment net sales increased $126.7 million, or 23.7%, in 2017 compared to 2016 primarily due to the PolySwitch, and ON Portfolio acquisitions in 2016, and the U.S Sensor acquisition in 2017 along with higher volume across the passives, sensors and semiconductor product lines.

[0000889331-19-000015:mdna:137]
Automotive Segment

[0000889331-19-000015:mdna:138]
Net sales in the Automotive segment increased $38.0 million, or 9.2%, in 2017 compared to 2016 primarily due to the incremental net sales associated with the PolySwitch and Menber’s acquisitions in 2016, higher volume in passenger car and commercial

[0000889331-19-000015:mdna:139]
vehicle products and favorable foreign exchange impacts of $1.9 million, partially offset by lower volume in automotive sensor products.

[0000889331-19-000015:mdna:140]
Industrial Segment

[0000889331-19-000015:mdna:141]
The Industrial segment net sales increased $0.6 million, or 0.6%, in 2017 compared to 2016 primarily due to higher volume across all product lines, partially offset by the divestiture of two non-core product lines, one in the fourth quarter of 2016 and the other in the first quarter of 2016.

[0000889331-19-000015:mdna:142]
Geographic Net Sales Information

[0000889331-19-000015:mdna:143]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-19-000015:mdna:144]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | % Change |
| Americas | $ | 436.5 |  |  | $ | 411.1 |  |  | $ | 25.4 |  |  | 6.2 | % |
| Europe | 243.9 |  |  | 200.3 |  |  | 43.6 |  |  | 21.8 | % |
| Asia-Pacific | 541.1 |  |  | 444.8 |  |  | 96.3 |  |  | 21.7 | % |
| Total | $ | 1,221.5 |  |  | $ | 1,056.2 |  |  | $ | 165.3 |  |  | 15.7 | % |

[0000889331-19-000015:mdna:145]
Americas

[0000889331-19-000015:mdna:146]
Net sales in the Americas increased $25.4 million, or 6.2%, in 2017 compared to 2016 resulting from acquisitions and higher volume in the passive and semiconductor product lines in the Electronics segment and the passenger car and commercial vehicle businesses in the Automotive segment that were partially offset by lower volume in sensor products in the Automotive segment and the divestiture of a non-core product line in the Industrial segment.

[0000889331-19-000015:mdna:147]
Europe

[0000889331-19-000015:mdna:148]
European net sales increased $43.6 million, or 21.8%, in 2017 compared to 2016. The increase in net sales was primarily due to acquisitions and increased net sales across all product lines in the Electronics segment and the passenger car and commercial vehicle products businesses in the Automotive segment.

[0000889331-19-000015:mdna:149]
Asia-Pacific

[0000889331-19-000015:mdna:150]
Asia-Pacific net sales increased $96.3 million, or 21.7%, in 2017 compared to 2016, primarily due to incremental net sales from prior year acquisitions and increased volume across all product lines in the Electronics segment.

[0000889331-19-000015:mdna:151]
Liquidity and Capital Resources

[0000889331-19-000015:mdna:152]
Cash and cash equivalents were $489.7 million as of December 29, 2018, an increase of $60.0 million as compared to December 30, 2017.

[0000889331-19-000015:mdna:153]
As of December 29, 2018, $400 million of the Company's $489.7 million cash and cash equivalents was held by non-U.S. subsidiaries. Of the $400 million, at least $200 million can be repatriated with minimal tax consequences, although in certain cases a non-U.S. withholding tax would be payable but subsequently refunded. With respect to the remaining $200 million, the Company has recognized deferred tax liabilities on approximately $91.0 million as of December 29, 2018 because the amounts are not considered to be permanently reinvested, and the Company may access additional amounts through loans and other means. Repatriation of some non-U.S. cash balances is restricted by local laws. Management regularly evaluates whether foreign earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its foreign subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-19-000015:mdna:154]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from

[0000889331-19-000015:mdna:155]
operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0000889331-19-000015:mdna:156]
Revolving Credit Facility/Term Loan

[0000889331-19-000015:mdna:157]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-19-000015:mdna:158]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. In addition to the quarterly principal payments, the Company paid $35.0 million of additional principal on the Term Loan during the fiscal year ended December 29, 2018.

[0000889331-19-000015:mdna:159]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR (fixed for interest periods of one, two, three or six-month periods) plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.59% at December 29, 2018.

[0000889331-19-000015:mdna:160]
Senior Notes

[0000889331-19-000015:mdna:161]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-19-000015:mdna:162]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-19-000015:mdna:163]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing August 15, 2018.

[0000889331-19-000015:mdna:164]
The Company was in compliance with its debt covenants as of December 29, 2018 and expects to remain in compliance based on management’s estimates of operating and financial results for 2019 and the foreseeable future. As of December 29, 2018, the

[0000889331-19-000015:mdna:165]
Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-19-000015:mdna:166]
Acquisitions

[0000889331-19-000015:mdna:167]
During the year ended December 29, 2018, the Company paid $306.5 million, net of cash acquired, for the acquisition of IXYS. Pursuant to the Securities Purchase Agreement, the Company paid $9.0 million for the acquisition of the remaining 38% outstanding common stock of Monolith during the year ended December 29, 2018. The Company financed the cash portion of the acquisition with a combination of cash on hand and borrowings under the credit facility.

[0000889331-19-000015:mdna:168]
During the year ended December 30, 2017, the Company paid $38.5 million, net of cash acquired, for the acquisitions of U.S Sensor and Monolith. The Company financed the cash portion of the acquisition with a combination of cash on hand and borrowings under the credit facility.

[0000889331-19-000015:mdna:169]
During the year ended December 31, 2016, the Company paid $471.1 million of total purchase prices, net of cash acquired, for the acquisitions of the ON Portfolio, Menber’s and PolySwitch. The Company financed the cash portion of these acquisitions with a combination of cash on hand and borrowings under the credit facility.

[0000889331-19-000015:mdna:170]
Cash Flow Overview

[0000889331-19-000015:mdna:171]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes and other operating activities.

[0000889331-19-000015:mdna:172]
The following describes the Company’s cash flows for the twelve months ended December 29, 2018 and December 30, 2017:

[0000889331-19-000015:mdna:173]
|  | Fiscal Year |
| (in millions) | 2018 |  | 2017 |
| Net cash provided by operating activities | $ | 331.8 |  |  | $ | 269.2 |  |
| Net cash used in investing activities | (382.3 | ) |  | (96.1 | ) |
| Net cash provided by (used in) financing activities | 121.9 |  |  | (24.7 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (11.4 | ) |  | 6.2 |  |
| Increase in cash and cash equivalents | 60.0 |  |  | 154.6 |  |
| Cash and cash equivalents at beginning of year | 429.7 |  |  | 275.1 |  |
| Cash and cash equivalents at end of year | $ | 489.7 |  |  | $ | 429.7 |  |

[0000889331-19-000015:mdna:174]
Cash Flow from Operating Activities

[0000889331-19-000015:mdna:175]
Net cash provided by operating activities was $331.8 million for 2018, compared to $269.2 million during 2017. The increase in net cash provided by operating activities was primarily driven by higher earnings and  favorable working capital management that more than offset higher payments related to cash taxes and acquisition and integration costs.

[0000889331-19-000015:mdna:176]
Cash Flow from Investing Activities

[0000889331-19-000015:mdna:177]
Net cash used in investing activities was $382.3 million for 2018, compared to $96.1 million during 2017. Net cash used for the acquisition of IXYS was $306.5 million in 2018 compared to acquisitions of $38.5 million in 2017 related to the acquisition of a majority stake in Monolith for $14.2 million and the acquisition of U.S. Sensor for $24.3 million. Capital expenditures were $74.8 million, representing an increase of $8.8 million compared to 2017. The Company also received proceeds of $9.6 million in 2018 primarily as a result of the sale of a building.

[0000889331-19-000015:mdna:178]
Cash Flow from Financing Activities

[0000889331-19-000015:mdna:179]
Net cash provided by financing activities was $121.9 million for 2018 compared to net cash used in financing activities of $24.7 million for 2017. The Company had $310.0 million of proceeds from the credit facility, term loan and senior notes payable partially offset by payments of $102.5 million on the credit facility and term loan in 2018 as compared to $149.4 million of proceeds from the credit facility, term loan and senior notes payable and $134.7 million of payments on the credit facility and term loan during 2017. The Company repurchased 391,972 shares of its common stock during fiscal 2018 totaling $63.6 million.

[0000889331-19-000015:mdna:180]
The following describes the Company’s cash flows for the twelve months ended December 30, 2017 and December 31, 2016:

[0000889331-19-000015:mdna:181]
|  | Fiscal Year |
| (in millions) | 2017 |  | 2016 |
| Net cash provided by operating activities | $ | 269.2 |  |  | $ | 180.1 |  |
| Net cash used in investing activities | (96.1 | ) |  | (511.2 | ) |
| Net cash (used in) provided by financing activities | (24.7 | ) |  | 284.2 |  |
| Effect of exchange rate changes on cash and cash equivalents | 6.2 |  |  | (6.8 | ) |
| Increase (decrease) in cash and cash equivalents | 154.6 |  |  | (53.7 | ) |
| Cash and cash equivalents at beginning of year | 275.1 |  |  | 328.8 |  |
| Cash and cash equivalents at end of year | $ | 429.7 |  |  | $ | 275.1 |  |

[0000889331-19-000015:mdna:182]
Cash Flow from Operating Activities

[0000889331-19-000015:mdna:183]
Net cash provided by operating activities was $269.2 million for 2017, compared to $180.1 million during 2016. The increase in net cash provided by operating activities was primarily driven by higher earnings, lower cash taxes, reduced acquisition and integration payments and the timing of supplier and customer payments.

[0000889331-19-000015:mdna:184]
Cash Flow from Investing Activities

[0000889331-19-000015:mdna:185]
Net cash used in investing activities was $96.1 million for 2017, compared to $511.2 million during 2016. Net cash used for acquisitions of $38.5 million in 2017 related to the acquisition of a majority stake in Monolith for $14.2 million and the acquisition of U.S. Sensor for $24.3 million. Net cash used for acquisitions of $471.1 million for 2016 primarily related to the acquisitions of PolySwitch for $344.5 million, the ON Portfolio for $104.0 million and Menber’s for $19.2 million. Capital expenditures were $65.9 million, representing an increase of $19.7 million compared to 2016.

[0000889331-19-000015:mdna:186]
Cash Flow from Financing Activities

[0000889331-19-000015:mdna:187]
Net cash used in financing activities was $24.7 million for 2017 compared to net cash provided by financing activities of $284.2 million for 2016. The Company had $149.4 million of proceeds from the credit facility, term loan and senior notes payable and $134.7 million of payments on the term loan and credit facility in 2017 as compared to $718.4 million of proceeds from the credit facility, term loan and senior notes payable and $421.2 million of payments on the term loan and credit facility during 2016.

[0000889331-19-000015:mdna:188]
Dividends

[0000889331-19-000015:mdna:189]
Cash dividends paid totaled $40.0 million, $31.8 million and $27.9 million for 2018, 2017 and 2016, respectively. On January 24, 2019, the Board of Directors of the Company declared a quarterly cash dividend of $0.43 per share, payable on March 7, 2019 to stockholders of record as of February 21, 2019.

[0000889331-19-000015:mdna:190]
Capital Resources

[0000889331-19-000015:mdna:191]
The Company expends capital to support its operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0000889331-19-000015:mdna:192]
Share Repurchase Program

[0000889331-19-000015:mdna:193]
The Company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 (“Share Repurchase Program”). During the fiscal year 2018, the Company repurchased 391,972 shares of its common stock. The Company did not repurchase any shares of its common stock during fiscal 2017.

[0000889331-19-000015:mdna:194]
As of February 18, 2019, the Company has repurchased 79,916 shares of its common stock since the fiscal year ended December 29, 2018.

[0000889331-19-000015:mdna:195]
Contractual Obligations and Commitments

[0000889331-19-000015:mdna:196]
The following table summarizes outstanding contractual obligations and commitments as of December 29, 2018:

[0000889331-19-000015:mdna:197]
| (in thousands) | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | Greaterthan 5 Years |
| Long-term debt(a) | $ | 699,366 |  |  | $ | 10,000 |  |  | $ | 20,000 |  |  | $ | 286,036 |  |  | $ | 383,330 |  |
| Interest payments(b) | 135,902 |  |  | 19,124 |  |  | 37,156 |  |  | 29,440 |  |  | 50,182 |  |
| Operating lease payments(c) | 32,607 |  |  | 9,133 |  |  | 13,164 |  |  | 7,536 |  |  | 2,774 |  |
| Income Tax Obligation(d) | 32,364 |  |  | 3,571 |  |  | 5,738 |  |  | 8,045 |  |  | 15,010 |  |
| Purchase obligations(e) | 30,886 |  |  | 27,814 |  |  | 711 |  |  | 700 |  |  | 1,661 |  |
| Total | $ | 931,125 |  |  | $ | 69,642 |  |  | $ | 76,769 |  |  | $ | 331,757 |  |  | $ | 452,957 |  |

[0000889331-19-000015:mdna:198]
(a)Excludes offsetting issuance costs of $4.6 million. Euro denominated debt amounts are converted based on the Euro to U.S. Dollar spot rate at year end. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-19-000015:mdna:199]
(b)Amounts represent estimated contractual interest payments on outstanding debt. Rates in effect as of December 29, 2018 are used for variable rate debt. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-19-000015:mdna:200]
(c)For more information see Note 7, Lease Commitments, of the Notes to Consolidated Financial Statements.

[0000889331-19-000015:mdna:201]
(d)The Income Tax Obligation represents the remaining amounts payable in regard to the 2017 Littelfuse Toll Charge and the 2018 IXYS Toll Charge. The Company has elected to pay the 2017 Littelfuse Toll Charge and will elect to pay the 2018 IXYS Toll Charge over the eight-year period prescribed by the Tax Act. For more information see Note 14, Income Taxes, of the Notes to Consolidated Financial Statements.

[0000889331-19-000015:mdna:202]
(e)Purchase obligations include purchase commitments and commitments for capital expenditures not recognized in the Company’s Consolidated Balance Sheets.

[0000889331-19-000015:mdna:203]
In addition to the above contractual obligations and commitments, the Company had the following obligations at December 29, 2018:

[0000889331-19-000015:mdna:204]
The Company has Company-sponsored defined benefit pension plans covering employees at various non-U.S. subsidiaries including the U.K., Germany, the Philippines, China, Japan, Mexico, Italy and France. At December 29, 2018, the Company had a net unfunded status of $32.2 million. The Company expects to make approximately $2.3 million of contributions to the plans in 2019. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0000889331-19-000015:mdna:205]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. As of December 29, 2018, there was $9.1 million of accrued compensation benefits included in Other long-term liabilities. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0000889331-19-000015:mdna:206]
As of December 29, 2018, the Company recognized various accruals related to employee compensation including its annual incentive program that are expected to be paid in 2019.

[0000889331-19-000015:mdna:207]
Due to the uncertainty with respect to the cash outflows, the preceding table excludes unrecognized tax benefits of $18.3 million. The Company does not expect to make significant payments of these liabilities within the next year. For additional information, see Note 14, Income Taxes, of the Notes to Consolidated Financial Statements.

[0000889331-19-000015:mdna:208]
Off-Balance Sheet Arrangements

[0000889331-19-000015:mdna:209]
As of December 29, 2018, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-19-000015:mdna:210]
Recent Accounting Pronouncements

[0000889331-19-000015:mdna:211]
Recently issued accounting standards and their estimated effect on the Company’s Consolidated Financial Statements are described in Note 1, Summary of Significant Accounting Policies and Other Information, of the Notes to Consolidated Financial Statements.
