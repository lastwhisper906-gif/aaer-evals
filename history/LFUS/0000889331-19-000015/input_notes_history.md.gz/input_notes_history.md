# LFUS note change history — 0001437749-18-014196 → 0000889331-18-000004


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-10-31):
[0000889331-18-000004:note_history:1]
Summary of Significant Accounting Policies and Other Information
  (was, 2018-08-01, similarity 0.9846):
[0001437749-18-014196:note_history:1]
1.
 Summary of Significant Accounting Policies and Other Information

- added (2018-10-31):
[0000889331-18-000004:note_history:2]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The Company has products in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance.

- changed (2018-10-31):
[0000889331-18-000004:note_history:3]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the year ended December 30, 2017, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2018-08-01, similarity 0.834):
[0001437749-18-014196:note_history:3]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 
10
-Q and Article 
10
 of Regulation S-
X.
 Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income and cash flows prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information 
not
 misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 
10
-K for the year ended 
 December

- changed (2018-10-31):
[0000889331-18-000004:note_history:4]
The following table disaggregates the Company’s revenue by primary business units for the three and nine months ended September 29, 2018:
  (was, 2018-08-01, similarity 0.938):
[0001437749-18-014196:note_history:4]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 and 
six
 months ended 
 June 30, 2018:

- added (2018-10-31):
[0000889331-18-000004:note_history:5]
|  |  | Three Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |

- added (2018-10-31):
[0000889331-18-000004:note_history:6]
|  |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- changed (2018-10-31):
[0000889331-18-000004:note_history:7]
See Note 13, Segment Information for net sales by segment and countries.
  (was, 2018-08-01, similarity 0.9147):
[0001437749-18-014196:note_history:7]
Segment Information
 for net sales by segment and countries.

- changed (2018-10-31):
[0000889331-18-000004:note_history:8]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.
  (was, 2018-08-01, similarity 0.9995):
[0001437749-18-014196:note_history:8]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do 
not
 transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and 
 may 
include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent 
third
-party distributors.

- added (2018-10-31):
[0000889331-18-000004:note_history:9]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- changed (2018-10-31):
[0000889331-18-000004:note_history:10]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.
  (was, 2018-08-01, similarity 0.9946):
[0001437749-18-014196:note_history:10]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than 
one
 year, the Company has elected the practical expedient under ASC 
606
-
10
-
32
-
18
 to 
not
 assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 
606
-
10
-
25
-
18B
 to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

- changed (2018-10-31):
[0000889331-18-000004:note_history:11]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-07 “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the previous guidance, net benefit cost was reported as an employee cost within operating income. The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU No. 2017-07 was effective for the first quarter of 2018 with the Company adopting the new standard on December 31, 2017.
  (was, 2018-08-01, similarity 0.8078):
[0001437749-18-014196:note_history:11]
2017
-
07
 “Compensation-Retirement Benefits (Topic 
715
): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the Statement of Income. Under the previous guidance, net benefit cost was reported as an employee cost within operating income. The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU 
No.

- changed (2018-10-31):
[0000889331-18-000004:note_history:12]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on December 31, 2017, on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings. As a result of the adoption of the new standard and change in fair value of our equity investments, for the nine months ended September 29, 2018, the Company recognized an unrealized loss of $0.3 million in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.
  (was, 2018-08-01, similarity 0.9475):
[0001437749-18-014196:note_history:12]
2016
-
01,
 “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on 
 December 31, 2017, 
on a modified retrospective basis, recognizing the cumulative effect as a 
$9.8
 million increase to retained earnings. As a result of the adoption of the new standard and change in fair value of our equity investments, for the 
six
 months ended 
 June 30, 2018, 
the Company recognized an unrealized gain of 
$2.8
 million in Other (income) expense, net in the Condensed Consolidated Statements of Net Income.

- changed (2018-10-31):
[0000889331-18-000004:note_history:13]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers” (Topic 606) which supersedes the revenue recognition requirements in ASC 605, “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on December 31, 2017 using the modified retrospective method, however, no adjustment to retained earnings was needed. The new guidance did not have a material effect on the Company’s Condensed Consolidated Statements of Net Income. See the Revenue Recognition section above for further discussion.
  (was, 2018-08-01, similarity 0.9292):
[0001437749-18-014196:note_history:13]
2014
-
09,
 “Revenue from Contracts with Customers” (Topic 
606
) which supersedes the revenue recognition requirements in ASC 
605,
 “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits 
two
 implementation approaches, 
one
 requiring retrospective application of the new standard with restatement of prior years and 
one
 requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on 
 December 31, 2017 
using the modified retrospective method, however, 
no
 adjustment to retained earnings was needed. The new guidance did 
not
 have a material effect on the Company’s Condensed Consolidated Statements of Income. See the 
Revenue Recognition
 section above for further discussion.

- changed (2018-10-31):
[0000889331-18-000004:note_history:14]
In October 2016, the FASB issued ASU No. 2016-16, "Income Taxes” (Topic 740). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on December 31, 2017 and it did not have a material impact.
  (was, 2018-08-01, similarity 0.9153):
[0001437749-18-014196:note_history:14]
2016
-
16,
 "Income Taxes” (Topic 
740
). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on 
 December 31, 2017 
and it did 
not
 have a material impact.

- changed (2018-10-31):
[0000889331-18-000004:note_history:15]
In February 2016, the FASB issued ASU No. 2016-02, "Leases" (Topic 842). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the first quarter of 2019. The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has not yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.
  (was, 2018-08-01, similarity 0.9723):
[0001437749-18-014196:note_history:15]
2016
-
02,
 "Leases" (Topic 
842
). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than 
twelve
 months. The accounting by lessors will remain largely unchanged. The ASU is effective for fiscal years, and interim periods within those fiscal years, beginning after 
 December 15, 2018, 
with early adoption permitted. Adoption will require a modified retrospective transition. The Company will adopt the standard in the 
first
 quarter of 
2019.
 The Company has made progress on assessing the Company’s portfolio of leases and compiling a central repository of all active leases. We are in the process of assessing the design of the future lease process and drafting a policy to address the new standard requirements. Key lease data elements are being evaluated including developing a methodology for determining the incremental borrowing rate across all countries where we have operations. While the Company has 
not
 yet completed its evaluation of the impact the new lease accounting standard will have on its Consolidated Financial Statements, the Company expects to recognize right of use assets and lease liabilities for its operating leases in the Consolidated Balance Sheet upon adoption.

- changed (2018-10-31):
[0000889331-18-000004:note_history:16]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 2018-02 will be effective in the first quarter of 2019; however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 2018-02 on the Consolidated Financial Statements.
  (was, 2018-08-01, similarity 0.9334):
[0001437749-18-014196:note_history:16]
2018
-
02
 “Income Statement—Reporting Comprehensive Income (Topic 
220
): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or 
not
 they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. ASU 
2018
-
02
 will be effective in the 
first
 quarter of 
2019;
 however early adoption is permitted for interim and annual periods, including the reporting period in which the Tax Act was enacted. The Company is currently evaluating the impact of ASU 
2018
-
02
 on the Consolidated Financial Statements.

- added (2018-10-31):
[0000889331-18-000004:note_history:17]
In August 2018, the FASB issued ASU No. 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurement."  ASU 2018-13 modified the disclosure requirements in Topic 820, "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits.  The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted.  The company is currently evaluating the potential effects of this guidance on its Consolidated Financial Statements.

- added (2018-10-31):
[0000889331-18-000004:note_history:18]
In August 2018, the FASB issued ASU No. 2018-14 "Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans, which amends ASC 715-20, Compensation - Retirement Benefits - Defined Benefit Plans - General. The amended guidance modifies the disclosure requirements for employers that sponsor defined benefit pension or other post-retirement plans by removing and adding certain disclosures for these plans. The eliminated disclosures include (a) the amounts in  OCI expected to be recognized in net periodic benefit costs over the next fiscal year, and (b) the effects of a one percentage point change in assumed health care cost trend rates on the net periodic benefit costs and the benefit obligation for post-retirement health care benefits. Additional disclosures include descriptions of significant gains and losses affecting the benefit obligation for the period. The adoption of this guidance will modify our disclosures but will not have a material effect on our Consolidated Financial Statements.

- added (2018-10-31):
[0000889331-18-000004:note_history:19]
In August 2018, the FASB issued ASU No. 2018-15, “Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force).” ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license).  The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted. The Company is currently evaluating this guidance on its Consolidated Financial Statements.

- removed (2018-10-31):
[0001437749-18-014196:note_history:20]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global leader in circuit protection products with advancing platforms in power control and sensor technologies, serving customers in the electronics, automotive, and industrial markets. With a diverse and extensive product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, the Company works with its customers to build safer, more reliable and more efficient products for the connected world in virtually every market that uses electrical energy, ranging across consumer electronics, IT and telecommunication applications, industrial electronics, automobiles and other transportation, and heavy industrial applications. The Company has a network of global engineering centers and labs that develop new products and product enhancements, provides customer application support and test products for safety, reliability, and regulatory compliance.

- removed (2018-10-31):
[0001437749-18-014196:note_history:21]
30,

- removed (2018-10-31):
[0001437749-18-014196:note_history:22]
2017,
 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are 
not
 necessarily indicative of annual operating results.

- removed (2018-10-31):
[0001437749-18-014196:note_history:23]
|  |  | For the three months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |
| Electronics – Semiconductor |  |  | 171,036 |  |  |  | — |  |  |  | — |  |  |  | 171,036 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,581 |  |  |  | — |  |  |  | 63,581 |  |
| Automotive Sensors |  |  | — |  |  |  | 30,729 |  |  |  | — |  |  |  | 30,729 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 32,862 |  |  |  | — |  |  |  | 32,862 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 32,654 |  |  |  | 32,654 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:24]
|  |  | For the six months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  |  | 320,952 |  |  |  | — |  |  |  | — |  |  |  | 320,952 |  |
| Passenger Car Products |  |  | — |  |  |  | 127,160 |  |  |  | — |  |  |  | 127,160 |  |
| Automotive Sensors |  |  | — |  |  |  | 62,052 |  |  |  | — |  |  |  | 62,052 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 64,090 |  |  |  | — |  |  |  | 64,090 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 59,926 |  |  |  | 59,926 |  |
| Total |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:25]
See Note 
12,

- removed (2018-10-31):
[0001437749-18-014196:note_history:26]
The Company has elected the practical expedient under ASC 
340
-
40
-
25
-
4
 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than 
one
 year.

- removed (2018-10-31):
[0001437749-18-014196:note_history:27]
In 
 March 2017, 
the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 
No.

- removed (2018-10-31):
[0001437749-18-014196:note_history:28]
2017
-
07
 was effective for the 
first
 quarter of 
2018
 with the Company adopting the new standard on 
 December 31, 2017.

- removed (2018-10-31):
[0001437749-18-014196:note_history:29]
In 
 January 2016, 
the FASB issued ASU 
No.

- removed (2018-10-31):
[0001437749-18-014196:note_history:30]
In 
 May 2014, 
the FASB issued ASU 
No.

- removed (2018-10-31):
[0001437749-18-014196:note_history:31]
In 
 October 2016, 
the FASB issued ASU 
No.

- removed (2018-10-31):
[0001437749-18-014196:note_history:32]
In 
 February 2016, 
the FASB issued ASU 
No.

- removed (2018-10-31):
[0001437749-18-014196:note_history:33]
In 
 February 2018, 
the FASB issued ASU 
No.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-10-31):
[0000889331-18-000004:note_history:34]
Debt
  (was, 2018-08-01, similarity 0.8):
[0001437749-18-014196:note_history:34]
5.
 Debt

- changed (2018-10-31):
[0000889331-18-000004:note_history:35]
The carrying amounts of debt at September 29, 2018 and December 30, 2017 are as follows:
  (was, 2018-08-01, similarity 0.9272):
[0001437749-18-014196:note_history:35]
The carrying amounts of debt at 
 June 30, 2018 
and 
 December 30, 2017 
are as follows:

- added (2018-10-31):
[0000889331-18-000004:note_history:36]
| (in thousands) |  | September 29, 2018 |  | December 30, 2017 |
| Term Loan |  | $ | 155,000 |  |  | $ | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,819 |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,092 |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | — |  |
| Other |  | 2,694 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,892 | ) |  | (4,881 | ) |
| Total debt |  | 700,713 |  |  | 495,611 |  |
| Less: Current maturities |  | (10,076 | ) |  | (6,250 | ) |
| Total long-term debt |  | $ | 690,637 |  |  | $ | 489,361 |  |

- changed (2018-10-31):
[0000889331-18-000004:note_history:37]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of  $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.
  (was, 2018-08-01, similarity 0.9992):
[0001437749-18-014196:note_history:37]
On 
 March 4, 2016, 
the Company entered into a 
five
-year credit agreement (“Credit Agreement”) with a group of lenders for up to 
$700.0
 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of 
$575.0
 million and an unsecured term loan credit facility (“Term Loan”) of up to 
$125.0
 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$150.0
 million, in the aggregate, in each case in minimum increments of 
$25.0
 million, subject to certain conditions and the agreement of participating lenders.

- changed (2018-10-31):
[0000889331-18-000004:note_history:38]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million with the second advance on January 16, 2018) through maturity, with the remaining balance due on October 13, 2022. In addition to the quarterly principal payments, the Company paid an additional $35.0 million of principal on the term loan during the nine months ended September 29, 2018.
  (was, 2018-08-01, similarity 0.9658):
[0001437749-18-014196:note_history:38]
On 
 October 13, 2017, 
the Company amended the Credit Agreement to increase the Revolving Credit Facility from 
$575.0
 million to 
$700.0
 million and increase the Term Loan from 
$125.0
 million to 
$200.0
 million and to extend the expiration date from 
 March 4, 2021 
to 
 October 13, 2022. 
The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional 
$300.0
 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans 
 may 
be made in up to 
two
 advances. The 
first
 advance of 
$125.0
 million occurred on 
 October 13, 2017 
and the 
second
 advance of 
$75.0
 million occurred on 
 January 16, 2018. 
For the Term Loan, the Company is required to make quarterly principal payments of 
1.25%
 of the original term loan (
$2.5
 million with the 
second
 advance on 
 January 16, 2018) 
through maturity, with the remaining balance due on 
 October 13, 2022. 
In addition to the quarterly principal payments, the Company paid 
$35.0
 million of principal on the term loan during the 
three
 months ended 
 June 30, 2018.

- changed (2018-10-31):
[0000889331-18-000004:note_history:39]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.49% at September 29, 2018.
  (was, 2018-08-01, similarity 0.9852):
[0001437749-18-014196:note_history:39]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, 
three
 or 
six
-month periods, plus 
1.00%
 to 
2.00%,
 or at the bank’s Base Rate, as defined, plus 
0.00%
 to 
1.00%,
 based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 
0.15%
 to 
0.25%,
 based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 
3.59%
 at 
 June 30, 2018.

- changed (2018-10-31):
[0000889331-18-000004:note_history:40]
As of September 29, 2018, the Company had $0.1 million outstanding in letters of credit and had available $699.9 million of borrowing capacity under the Revolving Credit Facility. At September 29, 2018, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2018-08-01, similarity 0.625):
[0001437749-18-014196:note_history:40]
As of 
 June 30, 2018, 
the Company had 
$0.1
 million outstanding in letters of credit and had available 
$699.9
 million of borrowing capacity under the Revolving Credit Facility. At 
 June 30, 2018, 
the Company was in compliance with all covenants under the Credit Agreement.

- changed (2018-10-31):
[0000889331-18-000004:note_history:41]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.
  (was, 2018-08-01, similarity 0.9969):
[0001437749-18-014196:note_history:41]
On 
 December 8, 2016, 
the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
€212
 million aggregate principal amount of senior notes in 
two
 series. The funding date for the Euro denominated senior notes occurred on 
 December 8, 2016 
for 
€117
 million in aggregate amount of 
1.14%
 Senior Notes, Series A, due 
 December 8, 2023 (
“Euro Senior Notes, Series A due 
2023”
), and 
€95
 million in aggregate amount of 
1.83%
 Senior Notes, Series B due 
 December 8, 2028 (
“Euro Senior Notes, Series B due 
2028”
) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on 
 June 8 
and 
 December 8, 
commencing 
 June 8, 2017.

- added (2018-10-31):
[0000889331-18-000004:note_history:42]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

- added (2018-10-31):
[0000889331-18-000004:note_history:43]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

- changed (2018-10-31):
[0000889331-18-000004:note_history:44]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 29, 2018, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2018-08-01, similarity 0.9396):
[0001437749-18-014196:note_history:44]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At 
 June 30, 2018, 
the Company was in compliance with all covenants under the Senior Notes.

- removed (2018-10-31):
[0001437749-18-014196:note_history:45]
| (in thousands) |  | June 30, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | — |  |  | $ | — |  |
| Term Loan |  |  | 157,500 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 135,335 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 109,887 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 60 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,184 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 697,598 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,060 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 687,538 |  |  | $ | 489,361 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:46]
On 
 December 8, 2016, 
the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold 
$125
 million aggregate principal amount of senior notes in 
two
 series. On 
 February 15, 2017,

- removed (2018-10-31):
[0001437749-18-014196:note_history:47]
$25
 million in aggregate principal amount of 
3.03%
 Senior Notes, Series A, due 
 February 15, 2022 (
“U.S. Senior Notes, Series A due 
2022”
), and 
$100
 million in aggregate principal amount of 
3.74%
 Senior Notes, Series B, due 
 February 15, 2027 (
“U.S. Senior Notes, Series B due 
2027”
) (together, the “U.S. Senior Notes due 
2022
 and 
2027”
) were funded. Interest on the U.S. Senior Notes due 
2022
 and 
2027
 is payable semiannually on 
 February 15 
and 
 August 15, 
commencing 
 August 15, 2017.

- removed (2018-10-31):
[0001437749-18-014196:note_history:48]
On 
 November 15, 2017, 
the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold 
$175
 million in aggregate principal amount of senior notes in 
two
 series. On 
 January 16, 2018,

- removed (2018-10-31):
[0001437749-18-014196:note_history:49]
$50
 million aggregate principal amount of 
3.48%
 Senior Notes, Series A, due 
 February 15, 2025 (
“U.S. Senior Notes, Series A due 
2025”
) and 
$125
 million in aggregate principal amount of 
3.78%
 Senior Notes, Series B, due 
 February 15, 2030 (
“U.S. Senior Notes, Series B due 
2030”
) (together the “U.S. Senior Notes due 
2025
 and 
2030”
 and with the Euro Senior Notes and the U.S. Senior Notes 
2022
 and 
2027,
 the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 
2025
 and 
2030
 will be payable on 
 February 15 
and 
 August 15, 
commencing on 
 August 15, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-10-31):
[0000889331-18-000004:note_history:50]
The carrying amounts of debt at September 29, 2018 and December 30, 2017 are as follows:

- added (2018-10-31):
[0000889331-18-000004:note_history:51]
| (in thousands) |  | September 29, 2018 |  | December 30, 2017 |
| Term Loan |  | $ | 155,000 |  |  | $ | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  | 136,819 |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,092 |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | — |  |
| Other |  | 2,694 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,892 | ) |  | (4,881 | ) |
| Total debt |  | 700,713 |  |  | 495,611 |  |
| Less: Current maturities |  | (10,076 | ) |  | (6,250 | ) |
| Total long-term debt |  | $ | 690,637 |  |  | $ | 489,361 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:52]
| (in thousands) |  | June 30, 2018 |  |  | December 30, 2017 |  |
| Revolving Credit Facility |  | $ | — |  |  | $ | — |  |
| Term Loan |  |  | 157,500 |  |  |  | 122,500 |  |
| Euro Senior Notes, Series A due 2023 |  |  | 135,335 |  |  |  | 139,623 |  |
| Euro Senior Notes, Series B due 2028 |  |  | 109,887 |  |  |  | 113,369 |  |
| U.S. Senior Notes, Series A due 2022 |  |  | 25,000 |  |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  |  | 100,000 |  |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  |  | 50,000 |  |  |  | — |  |
| U.S. Senior Notes, Series B due 2030 |  |  | 125,000 |  |  |  | — |  |
| Other |  |  | 60 |  |  |  | — |  |
| Unamortized debt issuance costs |  |  | (5,184 | ) |  |  | (4,881 | ) |
| Total debt |  |  | 697,598 |  |  |  | 495,611 |  |
| Less: Current maturities |  |  | (10,060 | ) |  |  | (6,250 | ) |
| Total long-term debt |  | $ | 687,538 |  |  | $ | 489,361 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-10-31):
[0000889331-18-000004:note_history:53]
Related Party Transactions
  (was, 2018-08-01, similarity 0.963):
[0001437749-18-014196:note_history:53]
11.
 Related Party Transactions

- changed (2018-10-31):
[0000889331-18-000004:note_history:54]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the three and nine months ended September 29, 2018, the Company recorded revenues of $0.2 million and $0.6 million, respectively from sales of products to Powersem for use as components in their products. During the three and nine months ended September 29, 2018, the Company purchased $1.3 million and $3.4 million, respectively of products from Powersem. At September 29, 2018, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.
  (was, 2018-08-01, similarity 0.91):
[0001437749-18-014196:note_history:54]
Powersem GmbH:
 The Company owns 
45%
 of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company recorded revenues of 
$0.3
 million and 
$0.4
 million, respectively from sales of products to Powersem for use as components in their products. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
the Company purchased 
$1.0
 million and 
$2.1
 million, respectively of products from Powersem. At 
 June 30, 2018, 
the accounts receivable balance from Powersem was 
$0.1
 million and the accounts payable balance to Powersem was 
$0.3
 million.

- changed (2018-10-31):
[0000889331-18-000004:note_history:55]
EB Tech Ltd.: The Company owns approximately 20% of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the three and nine months ended September 29, 2018 EB Tech rendered processing services for the Company totaling approximately $0.1 million and $0.3 million, respectively. As of September 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.
  (was, 2018-08-01, similarity 0.8314):
[0001437749-18-014196:note_history:55]
EB Tech Ltd.:
 The Company owns approximately 
20%
 of the outstanding equity of EB Tech Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During the 
three
 and 
six
 months ended 
 June 30, 2018 
EB Tech rendered processing services for the Company totaling approximately 
$0.1
 million and 
$0.2
 million, respectively. As of 
 June

- changed (2018-10-31):
[0000889331-18-000004:note_history:56]
Automated Technology, Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three and nine months ended September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $2.5 million and $7.7 million, respectively. As of September 29, 2018, the Company’s accounts payable balance to ATEC was $0.6 million.
  (was, 2018-08-01, similarity 0.7991):
[0001437749-18-014196:note_history:56]
Automated Technology, Inc.
: The Company owns approximately 
24%
 of the outstanding common shares of Automated Technology, Inc (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the 
three
 and 
six
 months ended 
 June 30, 2018, 
ATEC rendered assembly and test services to the Company totaling approximately 
$2.8
 million and 
$5.2
 million, respectively. As of 
 June

- removed (2018-10-31):
[0001437749-18-014196:note_history:57]
30,

- removed (2018-10-31):
[0001437749-18-014196:note_history:58]
2018,
 the Company’s accounts payable balance to EB Tech was immaterial.

- removed (2018-10-31):
[0001437749-18-014196:note_history:59]
30,

- removed (2018-10-31):
[0001437749-18-014196:note_history:60]
2018,
 the Company’s accounts payable balance to ATEC was 
$0.7
 million.


## lfus:RevenueRecognitionAndBillingPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2018-10-31):
[0001437749-18-014196:note_history:61]
Revenue and Billing

- removed (2018-10-31):
[0001437749-18-014196:note_history:62]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than 
one
 year, the Company has elected the practical expedient under ASC 
606
-
10
-
32
-
18
 to 
not
 assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 
606
-
10
-
25
-
18B
 to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.


## lfus:RevenueRecognitionReturnToStockPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2018-10-31):
[0001437749-18-014196:note_history:63]
Return to Stock

- removed (2018-10-31):
[0001437749-18-014196:note_history:64]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-10-31):
[0000889331-18-000004:note_history:65]
The following table disaggregates the Company’s revenue by primary business units for the three and nine months ended September 29, 2018:

- added (2018-10-31):
[0000889331-18-000004:note_history:66]
|  |  | Three Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |

- added (2018-10-31):
[0000889331-18-000004:note_history:67]
|  |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:68]
|  |  | For the three months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |
| Electronics – Semiconductor |  |  | 171,036 |  |  |  | — |  |  |  | — |  |  |  | 171,036 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,581 |  |  |  | — |  |  |  | 63,581 |  |
| Automotive Sensors |  |  | — |  |  |  | 30,729 |  |  |  | — |  |  |  | 30,729 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 32,862 |  |  |  | — |  |  |  | 32,862 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 32,654 |  |  |  | 32,654 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:69]
|  |  | For the six months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  |  | 320,952 |  |  |  | — |  |  |  | — |  |  |  | 320,952 |  |
| Passenger Car Products |  |  | — |  |  |  | 127,160 |  |  |  | — |  |  |  | 127,160 |  |
| Automotive Sensors |  |  | — |  |  |  | 62,052 |  |  |  | — |  |  |  | 62,052 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 64,090 |  |  |  | — |  |  |  | 64,090 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 59,926 |  |  |  | 59,926 |  |
| Total |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-10-31):
[0000889331-18-000004:note_history:70]
Revenue Recognition
  (was, 2018-08-01, similarity 0.7317):
[0001437749-18-014196:note_history:70]
Revenue Disaggregation

- added (2018-10-31):
[0000889331-18-000004:note_history:71]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

- added (2018-10-31):
[0000889331-18-000004:note_history:72]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- added (2018-10-31):
[0000889331-18-000004:note_history:73]
Revenue and Billing

- added (2018-10-31):
[0000889331-18-000004:note_history:74]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

- added (2018-10-31):
[0000889331-18-000004:note_history:75]
Ship and Debit Program

- added (2018-10-31):
[0000889331-18-000004:note_history:76]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2018-10-31):
[0000889331-18-000004:note_history:77]
Return to Stock

- added (2018-10-31):
[0000889331-18-000004:note_history:78]
The Company has a return to stock policy whereby certain customers, with prior authorization from Littelfuse management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

- added (2018-10-31):
[0000889331-18-000004:note_history:79]
Volume Rebates

- added (2018-10-31):
[0000889331-18-000004:note_history:80]
The Company offers volume based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

- removed (2018-10-31):
[0001437749-18-014196:note_history:81]
The following table disaggregates the Company’s revenue by primary business units for the 
three
 and 
six
 months ended 
 June 30, 2018:

- removed (2018-10-31):
[0001437749-18-014196:note_history:82]
|  |  | For the three months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |
| Electronics – Semiconductor |  |  | 171,036 |  |  |  | — |  |  |  | — |  |  |  | 171,036 |  |
| Passenger Car Products |  |  | — |  |  |  | 63,581 |  |  |  | — |  |  |  | 63,581 |  |
| Automotive Sensors |  |  | — |  |  |  | 30,729 |  |  |  | — |  |  |  | 30,729 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 32,862 |  |  |  | — |  |  |  | 32,862 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 32,654 |  |  |  | 32,654 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:83]
|  |  | For the six months ended June 30, 2018 |  |
| (in thousands) |  | Electronics Segment |  |  | Automotive Segment |  |  | Industrial Segment |  |  | Total |  |
| Electronics – Passive Products and Sensors |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  |  | 320,952 |  |  |  | — |  |  |  | — |  |  |  | 320,952 |  |
| Passenger Car Products |  |  | — |  |  |  | 127,160 |  |  |  | — |  |  |  | 127,160 |  |
| Automotive Sensors |  |  | — |  |  |  | 62,052 |  |  |  | — |  |  |  | 62,052 |  |
| Commercial Vehicle Products |  |  | — |  |  |  | 64,090 |  |  |  | — |  |  |  | 64,090 |  |
| Industrial Products |  |  | — |  |  |  | — |  |  |  | 59,926 |  |  |  | 59,926 |  |
| Total |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |

- removed (2018-10-31):
[0001437749-18-014196:note_history:84]
See Note 
12,

- removed (2018-10-31):
[0001437749-18-014196:note_history:85]
Segment Information
 for net sales by segment and countries.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2018-10-31):
[0001437749-18-014196:note_history:86]
Revenue Recognition

- removed (2018-10-31):
[0001437749-18-014196:note_history:87]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do 
not
 transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and 
 may 
include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent 
third
-party distributors.

- removed (2018-10-31):
[0001437749-18-014196:note_history:88]
The Company has elected the practical expedient under ASC 
340
-
40
-
25
-
4
 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than 
one
 year.
