# LFUS notes — 0000889331-20-000014


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000889331-20-000014:notes:1]
Portions of the Littelfuse, Inc. Proxy Statement for the 2020 Annual Meeting of Stockholders (the “Proxy Statement”) are incorporated by reference into Part III of this Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-20-000014:notes:2]
Summary of Significant Accounting Policies and Other Information

[0000889331-20-000014:notes:3]
Nature of Operations

[0000889331-20-000014:notes:4]
Littelfuse, Inc. and subsidiaries (the “Company”) is a global manufacturer of leading technologies in circuit protection, power control and sensing. The company's  products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. With its broad product portfolio of fuses, semiconductors, polymers, ceramics, relays and sensors, and extensive global infrastructure, the Company’s worldwide associates partner with its customers to design, manufacture and deliver innovative, high-quality solutions for a safer, greener and increasingly connected world.

[0000889331-20-000014:notes:5]
Fiscal Year

[0000889331-20-000014:notes:6]
References herein to “2019”, “fiscal 2019” or “fiscal year 2019” refer to the fiscal year ended December 28, 2019. References herein to “2018”, “fiscal 2018” or “fiscal year 2018” refer to the fiscal year ended December 29, 2018. References herein to “2017”, “fiscal 2017” or “fiscal year 2017” refer to the fiscal year ended December 30, 2017. The Company operates on a 52-53 week fiscal year (4-4-5 basis) ending on the Saturday closest to December 31.

[0000889331-20-000014:notes:7]
Basis of Presentation

[0000889331-20-000014:notes:8]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The Company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America and include the assets, liabilities, sales and expenses of all wholly-owned subsidiaries and majority-owned subsidiaries over which the Company exercises control.

[0000889331-20-000014:notes:9]
Use of Estimates

[0000889331-20-000014:notes:10]
The process of preparing financial statements in conformity with generally accepted accounting principles in the United States of America requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The Company evaluates and updates its assumptions and estimates on an ongoing basis and may employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0000889331-20-000014:notes:11]
Cash Equivalents

[0000889331-20-000014:notes:12]
All highly liquid investments, with an original maturity of three months or less when purchased, are considered to be cash equivalents.

[0000889331-20-000014:notes:13]
Short-Term and Long-Term Investments

[0000889331-20-000014:notes:14]
As of December 28, 2019, the Company has an investment in Polytronics Technology Corporation Ltd. (“Polytronics”). The Company’s Polytronics shares held at the end of fiscal 2019 and 2018 represent approximately 7.2% of total Polytronics shares outstanding. The Polytronics investment is carried at fair value. The fair value of the Polytronics investment was €11.6 million (approximately $12.8 million) at December 28, 2019 and €8.9 million (approximately $10.2 million) at December 29, 2018.

[0000889331-20-000014:notes:15]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The Company owns 45% of the outstanding equity of Powersem GmbH, a module manufacturer based in Germany, approximately 19% of the outstanding equity of EB Tech Ltd., a company with expertise in radiation technology based in South Korea, and approximately 24% of the outstanding common shares of Automated Technology, Inc., a supplier located in the Philippines that provides assembly and test services. All equity-level investments are less than majority owned. The Company recognized $0.6 million in losses and $0.7 million in gains from its equity method investments for the fiscal years ended December 28, 2019 and December 29, 2018, respectively. The balance of equity method investments was $11.1 million  and $11.6 million as of the fiscal years ended December 28, 2019 and December 29, 2018, respectively. See Note 18, Related Party Transactions, for further discussion.

[0000889331-20-000014:notes:16]
The balance of the Company's investments accounted for under the cost method was $0.4 million and $7.9 million for the fiscal years ended December 28, 2019 and December 29, 2018, respectively. During the twelve months ended December 28, 2019,

[0000889331-20-000014:notes:17]
the Company recorded impairment charges of $7.3 million in Other income, net in the Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value of $0.4 million. See Note 10, Fair Value of Assets and Liabilities, for further discussion.

[0000889331-20-000014:notes:18]
The Company has investments related to its non-qualified Supplemental Retirement and Savings Plan. The Company maintains accounts for participants through which participants make investment elections. The investment securities are subject to the claims of the Company’s creditors. The investment securities are all mutual funds. The investment securities are measured at net asset value. As of December 28, 2019 and December 29, 2018, the investment securities balance was $10.5 million and $9.1 million, respectively, related to the plan and are included in Other assets on the Consolidated Balance Sheets.

[0000889331-20-000014:notes:19]
Trade Receivables

[0000889331-20-000014:notes:20]
The Company performs credit evaluations of customers’ financial condition and generally does not require collateral. Credit losses are provided for in the financial statements based upon specific knowledge of a customer’s inability to meet its financial obligations to the Company. Historically, credit losses have consistently been within management’s expectations and have not been a material amount. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0000889331-20-000014:notes:21]
The Company also maintains allowances against trade receivables for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.

[0000889331-20-000014:notes:22]
Inventories

[0000889331-20-000014:notes:23]
Inventories are stated at the lower of cost or net realizable value, which approximates current replacement cost. Cost is principally determined using the first-in, first-out method. The Company maintains excess and obsolete reserves against inventory to reduce the carrying value to the expected net realizable value. These reserves are based upon a combination of factors including historical sales volume, market conditions, lower of cost or market analysis and expected realizable value of the inventory.

[0000889331-20-000014:notes:24]
Property, Plant, and Equipment

[0000889331-20-000014:notes:25]
Land, buildings, and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of 21 years for buildings, three to ten years for equipment, seven years for furniture and fixtures, five years for tooling and three years for computer equipment. Leasehold improvements are depreciated over the lesser of their useful life or the lease term. Maintenance and repair costs are charged to expense as incurred. Major overhauls that extend the useful lives of existing assets are capitalized.

[0000889331-20-000014:notes:26]
Goodwill

[0000889331-20-000014:notes:27]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.

[0000889331-20-000014:notes:28]
The Company compares each reporting unit’s fair value, estimated based on comparable company market valuations and expected future discounted cash flows to be generated by the reporting unit, to its carrying value. The results of the goodwill impairment test as of September 30, 2019 indicated that the estimated fair values for each of the seven reporting units exceeded their respective carrying values. As of the most recent annual test conducted on September 30, 2019, the Company noted that the excess of fair value over the carrying value, was 217%, 42%, 137%, 213%, 40%, 89%, and 268% for its reporting units; Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, Automotive Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test. See Note 5, Goodwill and Other Intangible Assets, for additional information.

[0000889331-20-000014:notes:29]
The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments as of December 28, 2019, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value.

[0000889331-20-000014:notes:30]
Long-Lived Assets

[0000889331-20-000014:notes:31]
Customer relationships, trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of 5 to 20 years. Patents, licenses and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of 5 to 17 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of 4 to 10 years.  Land use rights are amortized using the straight-line method over 50 years which is the term of the land use rights.

[0000889331-20-000014:notes:32]
The Company assesses potential impairments to its long-lived assets if events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. An impaired asset is written down to its estimated fair value based upon the most recent information available. Estimated fair market value is generally measured by discounting estimated future cash flows. Long-lived assets, other than goodwill and other intangible assets, that are held for sale are recorded at the lower of carrying value or the fair market value less the estimated cost to sell.

[0000889331-20-000014:notes:33]
Environmental Liabilities

[0000889331-20-000014:notes:34]
Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, the Company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0000889331-20-000014:notes:35]
Pension and Other Post-retirement Benefits

[0000889331-20-000014:notes:36]
The Company records annual income and expense amounts relating to its pension and post-retirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets, but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors.

[0000889331-20-000014:notes:37]
Revenue Recognition

[0000889331-20-000014:notes:38]
Adoption

[0000889331-20-000014:notes:39]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.

[0000889331-20-000014:notes:40]
Revenue Disaggregation

[0000889331-20-000014:notes:41]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 28, 2019 and December 29, 2018:

[0000889331-20-000014:notes:42]
|  |  | Fiscal Year Ended December 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 563,572 |  |  | $ | — |  |  | $ | — |  |  | $ | 563,572 |  |
| Electronics – Passive Products and Sensors |  | 397,508 |  |  | — |  |  | — |  |  | 397,508 |  |
| Passenger Car Products |  | — |  |  | 218,560 |  |  | — |  |  | 218,560 |  |
| Commercial Vehicle Products |  | — |  |  | 111,972 |  |  | — |  |  | 111,972 |  |
| Automotive Sensors |  | — |  |  | 98,001 |  |  | — |  |  | 98,001 |  |
| Industrial Products |  | — |  |  | — |  |  | 114,260 |  |  | 114,260 |  |
| Total |  | $ | 961,080 |  |  | $ | 428,533 |  |  | $ | 114,260 |  |  | $ | 1,503,873 |  |

[0000889331-20-000014:notes:43]
|  |  | Fiscal Year Ended December 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 648,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 648,967 |  |
| Electronics – Passive Products and Sensors |  | 475,329 |  |  | — |  |  | — |  |  | 475,329 |  |
| Passenger Car Products |  | — |  |  | 240,501 |  |  | — |  |  | 240,501 |  |
| Commercial Vehicle Products |  | — |  |  | 121,562 |  |  | — |  |  | 121,562 |  |
| Automotive Sensors |  | — |  |  | 117,728 |  |  | — |  |  | 117,728 |  |
| Industrial Products |  | — |  |  | — |  |  | 114,381 |  |  | 114,381 |  |
| Total |  | $ | 1,124,296 |  |  | $ | 479,791 |  |  | $ | 114,381 |  |  | $ | 1,718,468 |  |

[0000889331-20-000014:notes:44]
See Note 16, Segment Information, for net sales by segment and countries.

[0000889331-20-000014:notes:45]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-20-000014:notes:46]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-20-000014:notes:47]
Revenue and Billing

[0000889331-20-000014:notes:48]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

[0000889331-20-000014:notes:49]
Ship and Debit Program

[0000889331-20-000014:notes:50]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-20-000014:notes:51]
Return to Stock

[0000889331-20-000014:notes:52]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-20-000014:notes:53]
Volume Rebates

[0000889331-20-000014:notes:54]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-20-000014:notes:55]
Allowance for Doubtful Accounts

[0000889331-20-000014:notes:56]
The Company evaluates the collectability of its trade receivables based on a combination of factors. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a specific customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-20-000014:notes:57]
Advertising Costs

[0000889331-20-000014:notes:58]
The Company expenses advertising costs as incurred, which amounted to $2.7 million, $2.8 million, and $2.9 million in fiscal years 2019, 2018 and 2017, respectively, and are included as a component of selling, general, and administrative expenses.

[0000889331-20-000014:notes:59]
Shipping and Handling Fees and Costs

[0000889331-20-000014:notes:60]
Amounts billed to customers related to shipping and handling is classified as revenue. Costs incurred for shipping and handling of $11.0 million, $12.3 million, and $10.9 million in fiscal years 2019, 2018, and 2017, respectively, are classified in selling, general, and administrative expenses.

[0000889331-20-000014:notes:61]
Foreign Currency Translation / Remeasurement

[0000889331-20-000014:notes:62]
The Company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. The amount of foreign currency gain or loss from remeasurement recognized in the income statement was a loss of $5.2 million in fiscal year 2019, a gain of $0.9 million in fiscal year 2018, and a loss of $2.4 million in fiscal year 2017. Adjustments from the translation process are recognized in “Shareholders’ equity” as a component of “Accumulated other comprehensive income/ (loss).”

[0000889331-20-000014:notes:63]
Stock-Based Compensation

[0000889331-20-000014:notes:64]
The Company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as operating cash flows. See Note 12, Stock-Based Compensation, for additional information on stock-based compensation.

[0000889331-20-000014:notes:65]
Coal Mining Liability

[0000889331-20-000014:notes:66]
Included in other long-term liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €0.6 million ($0.7 million) and €1.1 million ($1.3 million) at December 28, 2019 and December 29, 2018, respectively. Management, in conjunction with an independent third-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time.

[0000889331-20-000014:notes:67]
Other Income, Net

[0000889331-20-000014:notes:68]
Other income, net generally consists of interest income, royalties, change in fair value of available-for-sale securities, pension non-service costs and other non-operating expense (income).

[0000889331-20-000014:notes:69]
Income Taxes

[0000889331-20-000014:notes:70]
The Company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards, and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-20-000014:notes:71]
Deferred U.S. income taxes and non-U.S. taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries.  Changes in economic and business conditions, non-U.S. or U.S. tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-20-000014:notes:72]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-20-000014:notes:73]
On December 22, 2017, the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduces the U.S. corporate federal income tax rate from 35% to 21%, adds base broadening provisions which limit deductions and address excessive international tax planning, imposes a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enables repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. Other than the Toll Charge (which, except for the IXYS impact, was applicable to the Company for 2017), the provisions are generally applicable to the Company in 2018 and beyond.

[0000889331-20-000014:notes:74]
In accordance with the guidance provided in SEC Staff Accounting Bulletin (“SAB”) No. 118, in the fourth quarter of 2017 the Company recorded a charge of $47.0 million as a provisional reasonable estimate of the impact of the Tax Act, including $49.0 million for the Toll Charge net of $2.0 million for other net tax benefits. In the fourth quarter of 2018, within the measurement period outlined in SAB No. 118, the Company finalized its estimates of the impact of the Tax Act as of December 30, 2017 and recorded a charge of $3.2 million, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. In addition, the Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation. This was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities.

[0000889331-20-000014:notes:75]
Although certain administrative guidance has been issued, including final and proposed regulations, the appropriate application of many provisions of the Tax Act remain uncertain. The Company used its best judgment as to the application of these provisions in determining its final estimates of the impact of the Tax Act as of December 30, 2017, the Toll Charge associated with the IXYS acquisition as well as the Company’s income tax expense for the fiscal years ended December 28, 2019 and December 29, 2018. Adjustments to income tax expense may be necessary in future periods if provisions of the Tax Act, and their interaction with other provisions of the U.S. Internal Revenue Code, are interpreted differently than interpretations made by the Company, whether through issuance of additional administrative guidance, or through further review of the Tax Act by the Company and its advisors.

[0000889331-20-000014:notes:76]
The Company has elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The long-term portion of this Toll Charge which remains payable as of December 28, 2019, totaling $23.8 million, is included in Other long-term liabilities, and the anticipated 2020 annual installment payment of $3.0 million is included in Accrued income taxes, on the Consolidated Balance Sheet as of December 28, 2019. The Company did not elect to pay the 2018 IXYS Toll Charge over the eight year period provided by the Tax Act and therefore there is no long-term portion of this Toll Charge which remains payable as of December 28, 2019.

[0000889331-20-000014:notes:77]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 28, 2019 and December 29, 2018, deferred taxes were computed

[0000889331-20-000014:notes:78]
without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-20-000014:notes:79]
Fair Value Measurements

[0000889331-20-000014:notes:80]
Certain assets and liabilities are required to be recorded at fair value on a recurring basis. Fair value is determined based on the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants. The Company records the fair value of its available-for-sale securities and pension plan assets on a recurring basis. Assets measured at fair value on a nonrecurring basis include long-lived assets held and used, long-lived assets held for sale, goodwill and other intangible assets. The fair value of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The three-tier value hierarchy, which prioritizes valuation methodologies based on the reliability of the inputs, is:

[0000889331-20-000014:notes:81]
Level 1 – Valuations based on quoted prices for identical assets and liabilities in active markets.

[0000889331-20-000014:notes:82]
Level 2 – Valuations based on observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data.

[0000889331-20-000014:notes:83]
Level 3 – Valuations based on unobservable inputs reflecting the Company’s own assumptions, consistent with reasonably available assumptions made by other market participants.

[0000889331-20-000014:notes:84]
Recently Adopted Accounting Standards

[0000889331-20-000014:notes:85]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-02, "Leases" (Topic 842), ("ASC 842"). This ASU requires lessees to recognize, on the balance sheet, assets and liabilities for the rights and obligations created by leases of greater than twelve months.

[0000889331-20-000014:notes:86]
The Company adopted the standard on December 30, 2018 using the alternative modified retrospective transition method provided in ASU No. 2018-11, "Leases (Topic 842): Target Improvements." Under this method, the Company recorded a cumulative-effect adjustment as of December 30, 2018 and did not record any retrospective adjustments to comparative periods to reflect the adoption of ASC 842. The new standard provides a number of optional practical expedients in transition. The Company has elected the ‘package of practical expedients’ which permits us not to reassess under the new standard our prior conclusions about lease identification, lease classification and initial direct costs. The Company has not elected the use-of-hindsight. Adoption of ASC 842 resulted in the recognition of operating lease right-of-use assets ("ROU") net of deferred rent of $26.1 million and lease liabilities of $29.4 million, as of December 30, 2018 for operating leases on its Consolidated Balance Sheets, with no impact to the Company's Consolidated Statements of Net Income and Consolidated Statements of Cash Flow. See Note 7, Lease Commitments, for further discussion.

[0000889331-20-000014:notes:87]
In February 2018, the FASB issued ASU No. 2018-02 “Income Statement—Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income,” which permits the reclassification of tax effects stranded in accumulated other comprehensive income to retained earnings as a result of the Tax Act. The standard also requires entities to disclose whether or not they elected to reclassify the tax effects related to the Tax Act as well as their policy for releasing income tax effects from accumulated other comprehensive income. The standard allows the option of applying either a retrospective adoption, meaning the standard is applied to all periods in which the effect of the Tax Act is recognized, or applying the amendments in the period of adoption, meaning an adjustment is made to shareholder’s equity as of the beginning of the reporting period. The Company adopted the new standard on December 30, 2018. The adoption of this guidance did not have a material effect on the Company's Consolidated Financial Statements.

[0000889331-20-000014:notes:88]
In January 2018, the FASB released guidance on the accounting for the GILTI provisions of the 2017 U.S. Tax Act. The GILTI provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. The guidance indicates that either accounting for deferred taxes related to GILTI inclusions or treating any taxes on GILTI inclusions as period cost are both acceptable methods subject to an accounting policy election. The Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the year ended December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-20-000014:notes:89]
In March 2017, the FASB issued  ASU No. 2017-07 “Compensation-Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Post-Retirement Benefit Cost,” which changed the presentation of net periodic pension and post-retirement benefit cost (net benefit cost) within the consolidated Statements of Net Income. Under the previous guidance, net benefit cost was reported as an employee cost within operating income. The amendment required the bifurcation of net benefit cost, with the service cost component to be presented with other employee compensation costs in operating income while the other components will be reported separately outside of income from operations. ASU No. 2017-07 was effective for the first quarter of 2018 with the Company adopting the new standard on December 31, 2017.

[0000889331-20-000014:notes:90]
In January 2016, the FASB issued ASU No. 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities” which addressed certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. The ASU requires the Company to recognize any changes in the fair value of certain equity investments in net income. Previously these changes were recognized in other comprehensive income ("OCI"). The Company adopted the new standard on December 31, 2017, on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings. As a result of the adoption of the new standard and change in fair value of our equity investments, for the fiscal year ended December 29, 2018, the Company recognized an unrealized loss of $0.7 million in Other income, net in the Consolidated Statements of Net Income.

[0000889331-20-000014:notes:91]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue from Contracts with Customers” (Topic 606) which supersedes the revenue recognition requirements in ASC 605, “Revenue Recognition.” This ASU provides a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most current revenue recognition guidance. The guidance permits two implementation approaches, one requiring retrospective application of the new standard with restatement of prior years and one requiring prospective application of the new standard with disclosure of results under old standards. The Company adopted the new standard on December 31, 2017 using the modified retrospective method, however, no adjustment to retained earnings was needed. The new guidance did not have a material effect on the Company’s Consolidated Statements of Net Income. See the Revenue Recognition section above for further discussion.

[0000889331-20-000014:notes:92]
In October 2016, the FASB issued ASU No. 2016-16, "Income Taxes” (Topic 740). This ASU update requires entities to recognize the income tax consequences of many intercompany asset transfers at the transaction date. The seller and buyer will immediately recognize the current and deferred income tax consequences of an intercompany transfer of an asset other than inventory. The tax consequences were previously deferred. The Company adopted the new standard on December 31, 2017 and it did not have a material impact.

[0000889331-20-000014:notes:93]
Recently Issued Accounting Standards

[0000889331-20-000014:notes:94]
In June 2016, the FASB issued ASU 2016- 13, “Financial Instruments- Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments.” The standard modifies the measurement approach for credit losses on financial instruments, including trade receivables, from an incurred loss method to a current expected credit loss method (“CECL”). The standard requires the measurement of expected credit losses to be based on relevant information, including historical experience, current conditions and a forecast that is supportable. The standard is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years; early adoption is permitted. The standard must be adopted by applying a cumulative adjustment to retained earnings. The Company anticipates adopting the standard in the first quarter of 2020, although it does not expect a material impact to the Company’s Consolidated Financial Statements.

[0000889331-20-000014:notes:95]
In August 2018, the FASB issued ASU No. 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurement." ASU 2018-13 modified the disclosure requirements in Topic 820, "Fair Value Measurement," based on the FASB Concepts Statement, "Conceptual Framework for Financial Reporting - Chapter 8: Notes to Financial Statements," including consideration of costs and benefits. The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted. The company is currently evaluating the potential effects of this guidance on its Consolidated Financial Statements.

[0000889331-20-000014:notes:96]
In August 2018, the FASB issued ASU No. 2018-14 "Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans," which amends ASC 715-20, Compensation - Retirement Benefits - Defined Benefit Plans - General. The amended guidance modifies the disclosure requirements for employers that sponsor defined benefit pension or other post-retirement plans by removing and adding certain disclosures for these plans. The eliminated disclosures include (a) the amounts in  OCI expected to be recognized in net periodic benefit costs over the next fiscal year, and (b) the effects of a one percentage point change in assumed health care cost trend rates on the net periodic benefit costs and the benefit obligation for post-retirement health care benefits. Additional disclosures include descriptions of significant gains and losses affecting the benefit obligation for the period.

[0000889331-20-000014:notes:97]
This guidance will be effective for financial statements issued for fiscal years ending after December 15, 2020. The adoption of this guidance will modify our disclosures but will not have a material effect on the Company's Consolidated Financial Statements.

[0000889331-20-000014:notes:98]
In August 2018, the FASB issued ASU No. 2018-15, “Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract (a consensus of the FASB Emerging Issues Task Force).” ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The guidance is effective for fiscal years beginning after December 15, 2019 and for interim periods within those fiscal years, with early adoption permitted. The Company is currently evaluating this guidance on its Consolidated Financial Statements.

[0000889331-20-000014:notes:99]
In December 2019, the FASB issued ASU No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards.  The guidance is effective for fiscal years beginning after December 15, 2021 with early adoption permitted.  The Company is currently evaluating this guidance on its Consolidated Financial Statements, The Company does not expect material effect from the adoption of this guidance on the Company's Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-20-000014:notes:100]
Acquisitions

[0000889331-20-000014:notes:101]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0000889331-20-000014:notes:102]
IXYS Corporation

[0000889331-20-000014:notes:103]
On January 17, 2018, the Company acquired IXYS Corporation (“IXYS”), a global pioneer in the power semiconductor and integrated circuit markets with a focus on medium to high voltage power semiconductors across the industrial, communications, consumer and medical markets. IXYS has a broad customer base, serving more than 3,500 customers through its direct sales force and global distribution partners. The acquisition of IXYS is expected to accelerate the Company’s growth across the power control market driven by IXYS’s extensive power semiconductor portfolio and technology expertise. With IXYS, the Company will be able to diversify and expand its presence within industrial electronics markets, leveraging the strong IXYS industrial OEM customer base. The Company also expects to increase long-term penetration of its power semiconductor portfolio in automotive markets, expanding its global content per vehicle.

[0000889331-20-000014:notes:104]
Upon completion of the acquisition, at IXYS stockholders’ election and subject to proration, each share of IXYS common stock, par value $0.01 per share, owned immediately prior to the effective time were canceled and extinguished and automatically converted into the right to receive: (i) $23.00 in cash (subject to applicable withholding tax), without interest (referred to as the cash consideration), or (ii) 0.1265 of a share of common stock, par value $0.01 per share, of Littelfuse (referred to as the stock consideration). IXYS stockholders received cash in lieu of any fractional shares of Littelfuse common stock that the IXYS stockholders would otherwise have been entitled to receive. Additionally, each outstanding option to purchase shares of IXYS common stock granted under an IXYS equity plan were assumed by Littelfuse and converted into an option to acquire (i) a number of shares of Littelfuse common stock equal to the number of shares of IXYS common stock subject to such option immediately prior to the effective time multiplied by 0.1265, rounded down to the nearest whole share, with (ii) an exercise price per share of Littelfuse common stock equal to the exercise price of such IXYS stock option immediately prior to the effective time divided by 0.1265, rounded up to the nearest whole cent.

[0000889331-20-000014:notes:105]
Based on the $207.5 per share opening price of Littelfuse common stock on January 17, 2018, the consideration IXYS stockholders received in exchange of their IXYS common stock in the acquisition had a value of $814.8 million comprised of $380.6 million of cash and $434.2 million of Littelfuse stock. In addition to the consideration transferred related to IXYS common stock, the value of consideration transferred, and included in the purchase price, related to IXYS stock options that were converted to Littelfuse stock options, or cash settled, had a value of $41.7 million. As a result, total consideration was valued at $856.5 million.

[0000889331-20-000014:notes:106]
The total purchase price of $856.5 million has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the IXYS acquisition:

[0000889331-20-000014:notes:107]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | 302,865 |  |
| Cash settled stock options | 3,622 |  |
| Littelfuse stock | 434,192 |  |
| Converted stock options | 38,109 |  |
| Total purchase consideration | 778,788 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | 155,930 |  |
| Property, plant, and equipment | 77,442 |  |
| Intangible assets | 212,720 |  |
| Goodwill | 382,360 |  |
| Other non-current assets | 28,706 |  |
| Other non-current liabilities | (78,370 | ) |
|  | 778,788 |  |

[0000889331-20-000014:notes:108]
Approximately $49.1 million of net receivables was included in IXYS’s current assets, All IXYS goodwill, other assets and liabilities were recorded in the Electronics segment and primarily reflected in the Americas and European geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining IXYS’s products and technology with the Company’s existing electronics product portfolio. Goodwill resulting from the IXYS acquisition is not expected to be deductible for tax purposes. The Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation (this reflects a reduction of $1.0 million recorded in the fourth quarter of 2018 and $2.0 million recorded in the third quarter of 2018 as a consequence of revisions to the Company’s original estimates. For additional information, see Note 14, Income Taxes. As a result of the Company completing its fair value analysis, in the fourth quarter of 2018, the company recorded a reduction of $2.6 million in certain investments held by IXYS.

[0000889331-20-000014:notes:109]
Included in the Company’s Consolidated Statements of Net Income for the fiscal year ended December 29, 2018 are net sales of approximately $378.2 million, and loss before income taxes of $22.2 million, since the January 17, 2018 acquisition of IXYS. The Company recognized approximately $11.9 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the fiscal year ended December 29, 2018, of which $4.5 million was recognized immediately as it related to prior service periods.

[0000889331-20-000014:notes:110]
As required by purchase accounting rules, the Company recorded a $36.9 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was fully amortized as a non-cash charge to cost of goods sold during the first and second quarters of 2018, as the acquired inventory was sold, and reflected as other non-segment costs.

[0000889331-20-000014:notes:111]
During the fiscal year ended December 29, 2018, the Company incurred approximately $11.0 million of legal and professional fees related to this acquisition which were primarily recognized as selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-20-000014:notes:112]
2017 Acquisitions

[0000889331-20-000014:notes:113]
U.S. Sensor

[0000889331-20-000014:notes:114]
On July 7, 2017, the Company acquired the assets of U.S. Sensor Corporation (“U.S. Sensor”). The acquisition purchase price of $24.3 million, net of the finalization of an income tax gross up which was settled in the fourth quarter of 2017, was funded with available cash. The acquired business expands the Company’s existing sensor portfolio in several key electronics and industrial end markets. U.S. Sensor manufactures a variety of high quality negative temperature coefficient thermistors as well as thermistor probes and assemblies. Product lines also include thin film platinum resistance temperature detectors (“RTDs”) and RTD assemblies.

[0000889331-20-000014:notes:115]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the U.S. Sensor acquisition:

[0000889331-20-000014:notes:116]
| (in thousands) | Purchase Price Allocation |
| Total purchase consideration: |  |
| Cash | $ | 24,340 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | $ | 4,635 |  |
| Patented and unpatented technologies | 1,090 |  |
| Trademarks and tradenames | 200 |  |
| Non-compete agreement | 50 |  |
| Customer relationships | 2,830 |  |
| Goodwill | 16,075 |  |
| Current liabilities | (540 | ) |
|  | $ | 24,340 |  |

[0000889331-20-000014:notes:117]
Included in U.S. Sensor’s current assets, net was approximately $1.5 million of receivables. All U.S. Sensor goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the U.S. geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining U.S. Sensor’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is expected to be deductible for tax purposes.

[0000889331-20-000014:notes:118]
As required by purchase accounting rules, the Company recorded a $1.6 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the third quarter of 2017, as the acquired inventory was sold, and reflected as other non-segment costs.

[0000889331-20-000014:notes:119]
Monolith

[0000889331-20-000014:notes:120]
In December 2015, the Company invested $3.5 million in the preferred stock of Monolith Semiconductor Inc. (“Monolith”), a U.S. start-up Company developing silicon carbide technology, which represented approximately 12% of the common stock of Monolith on an as-converted basis. The Company accounted for its investment in Monolith under the cost method with any changes in value recorded in other comprehensive income. The value of the Monolith investment was $3.5 million at December 31, 2016.

[0000889331-20-000014:notes:121]
On February 28, 2017, pursuant to a Securities Purchase Agreement between the Company and the stockholders of Monolith (“Securities Purchase Agreement”) and conditioned on Monolith achieving a product development milestone and other provisions, the Company acquired 62% of the outstanding common stock of Monolith for $15.0 million. The Securities Purchase Agreement includes provisions whereby the Company will acquire the remaining outstanding stock of Monolith (“non-controlling interest”) at a time or times based on Monolith meeting certain technical and sales targets. During the first quarter of 2018, Monolith met the next set of technical and sales targets. As a result, and pursuant to the Securities Purchase Agreement, in April 2018 the Company acquired an additional 19% of the outstanding common stock of Monolith for $5.0 million, of which $4.0 million was paid to the stockholders of Monolith. On October 5, 2018, the Company acquired the remaining 19% outstanding common stock for $5.0 million.

[0000889331-20-000014:notes:122]
The additional investment, in the first quarter of 2017, resulted in the Company gaining control of Monolith and was accounted for as a step-acquisition with the fair value of the original investment immediately before the acquisition estimated to be approximately $3.5 million. As the fair value of the investment immediately prior to the transaction equaled the carrying value, there was no impact on the Company’s Consolidated Statements of Net Income. As the Securities Purchase Agreement includes an obligation of the Company to mandatorily redeem the non-controlling interest for cash, the fair value of the non-controlling interest was recognized as a liability on the Company’s Consolidated Balance Sheets. The original investment of $3.5 million, additional cash consideration of $14.2 million (net of cash acquired), and the non-cash consideration of the fair value of the commitment to purchase the non-controlling interest of $9.0 million resulted in a purchase price of $26.7 million. Changes in the fair value of the non-controlling interest are recognized in the Company’s Consolidated Statements of Net Income.

[0000889331-20-000014:notes:123]
Commencing March 1, 2017, Monolith was reflected as a consolidated subsidiary within the Company’s Consolidated Financial Statements. Had the acquisition occurred as of January 1, 2017, the impact on the Company’s consolidated Statements of Net Income would not have been material.

[0000889331-20-000014:notes:124]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the Monolith acquisition:

[0000889331-20-000014:notes:125]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Original investment | $ | 3,500 |  |
| Cash, net of cash acquired | 14,172 |  |
| Non-cash, fair value of commitment to purchase non-controlling interest | 9,000 |  |
| Total purchase consideration | $ | 26,672 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Current assets, net | $ | 891 |  |
| Property, plant, and equipment | 789 |  |
| Patented and unpatented technologies | 6,720 |  |
| Non-compete agreement | 140 |  |
| Goodwill | 20,641 |  |
| Current liabilities | (639 | ) |
| Other non-current liabilities | (1,870 | ) |
|  | $ | 26,672 |  |

[0000889331-20-000014:notes:126]
Included in Monolith’s current assets, net was approximately $0.7 million of receivables. All Monolith goodwill, other assets and liabilities were recorded in the Electronics segment and reflected in the U.S. geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Monolith’s products and technology with the Company’s existing electronics product portfolio. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0000889331-20-000014:notes:127]
Pro Forma Results

[0000889331-20-000014:notes:128]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and IXYS as though the acquisition had occurred as of January 1, 2017. The Company has not included pro forma results of operations for U.S. Sensor or Monolith as these results were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the IXYS acquisition occurred as of January 1, 2017 or of future consolidated operating results.

[0000889331-20-000014:notes:129]
|  |  | For the Fiscal Year Ended |
| (in thousands, except per share amounts) |  | December 29, 2018 |  | December 30, 2017 |
| Net sales |  | $ | 1,735,181 |  |  | $ | 1,564,956 |  |
| Income before income taxes |  | 272,724 |  |  | 142,150 |  |
| Net income |  | 215,228 |  |  | 75,604 |  |
| Net income per share — basic |  | 8.61 |  |  | 3.05 |  |
| Net income per share — diluted |  | 8.53 |  |  | 3.00 |  |

[0000889331-20-000014:notes:130]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-20-000014:notes:131]
|  |  | For the Fiscal Year Ended |
| (in thousands) |  | December 29, 2018 |  | December 30, 2017 |
| Amortization(a) |  | $ | 12,009 |  |  | $ | (25,203 | ) |
| Depreciation |  | — |  |  | 556 |  |
| Transaction costs(b) |  | 9,976 |  |  | (9,976 | ) |
| Amortization of inventory step-up(c) |  | 36,927 |  |  | (36,927 | ) |
| Stock compensation(d) |  | 5,845 |  |  | (6,635 | ) |
| Interest expense(e) |  | — |  |  | (10,326 | ) |
| Income tax impact of above items |  | (15,446 | ) |  | 29,336 |  |

[0000889331-20-000014:notes:132]
| (a) | The amortization adjustment for the twelve months ended December 29, 2018 primarily reflects the reduction of amortization expense in the period related to the Order backlog intangible asset. The Order backlog has a useful life of twelve months and is fully amortized in the fiscal 2017 pro forma results. The amortization adjustment for the twelve months ended December 30, 2017 reflects incremental amortization resulting for the measurement of intangibles at their fair values. |

[0000889331-20-000014:notes:133]
| (b) | The transaction cost adjustments reflect the reversal of certain bank and attorney fees from the twelve months ended December 29, 2018 and recognition of those fees during the twelve months ended December 30, 2017. |

[0000889331-20-000014:notes:134]
| (c) | The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the twelve months ended December 29, 2018 and the recognition of the full amortization during the twelve months ended December 30, 2017. The inventory step-up was amortized over five months as the inventory was sold. |

[0000889331-20-000014:notes:135]
| (d) | The stock compensation adjustment reflects the reversal of the portion of stock compensation for IXYS stock options that were converted to Littelfuse stock options and expensed immediately during the twelve months ended December 29, 2018. The adjustment for the twelve months ended December 30, 2017 reflect the incremental stock compensation for the converted stock options. |

[0000889331-20-000014:notes:136]
| (e) | The interest expense adjustment reflects incremental interest expense related to the financing of the transaction. |

[0000889331-20-000014:notes:137]
For the fiscal year ended December 28, 2019, the Company recorded $2.7 million of acquisition-related expenses associated with contemplated acquisitions within Selling, general and administrative expenses in the Consolidated Statements of Net Income.


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0000889331-20-000014:notes:138]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the IXYS acquisition:


## us-gaap:InventoryDisclosureTextBlock

[0000889331-20-000014:notes:139]
The components of inventories at December 28, 2019 and December 29, 2018 are as follows:

[0000889331-20-000014:notes:140]
| (in thousands) | 2019 |  | 2018 |
| Raw materials | $ | 76,732 |  |  | $ | 76,060 |  |
| Work in process | 84,561 |  |  | 97,645 |  |
| Finished goods | 110,388 |  |  | 117,207 |  |
| Inventory reserves | (34,174 | ) |  | (32,684 | ) |
| Total | $ | 237,507 |  |  | $ | 258,228 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-20-000014:notes:141]
The components of net property, plant, and equipment at December 28, 2019 and December 29, 2018 are as follows:

[0000889331-20-000014:notes:142]
| (in thousands) | 2019 |  | 2018 |
| Land | $ | 24,758 |  |  | $ | 25,630 |  |
| Building | 108,501 |  |  | 114,636 |  |
| Equipment | 631,273 |  |  | 583,043 |  |
| Accumulated depreciation and amortization | (419,915 | ) |  | (383,415 | ) |
| Total | $ | 344,617 |  |  | $ | 339,894 |  |

[0000889331-20-000014:notes:143]
The Company recorded depreciation expense of $52.5 million, $51.0 million, and $38.3 million for the fiscal years ended December 28, 2019, December 29, 2018, and December 30, 2017, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-20-000014:notes:144]
Goodwill and Other Intangible Assets

[0000889331-20-000014:notes:145]
The amounts for goodwill and changes in the carrying value by segment are as follows:

[0000889331-20-000014:notes:146]
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| As of December 30, 2017 | $ | 278,959 |  |  | $ | 135,829 |  |  | $ | 38,626 |  |  | $ | 453,414 |  |
| Additions(a) | 382,903 |  |  | — |  |  | — |  |  | 382,903 |  |
| Foreign currency translation adjustments | (5,823 | ) |  | (3,497 | ) |  | (282 | ) |  | (9,602 | ) |
| As of December 29, 2018 | $ | 656,039 |  |  | $ | 132,332 |  |  | $ | 38,344 |  |  | $ | 826,715 |  |
| Foreign currency translation adjustments | (5,243 | ) |  | (1,011 | ) |  | 128 |  |  | (6,126 | ) |
| As of December 28, 2019 | $ | 650,796 |  |  | $ | 131,321 |  |  | $ | 38,472 |  |  | $ | 820,589 |  |

[0000889331-20-000014:notes:147]
(a)The 2018 additions resulted primarily from the acquisition of IXYS.

[0000889331-20-000014:notes:148]
The components of intangible assets at December 28, 2019 and December 29, 2018 are as follows:

[0000889331-20-000014:notes:149]
|  | As of December 28, 2019 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 9,649 |  |  | $ | 1,730 |  |  | $ | 7,919 |  |
| Patents, licenses and software | $ | 131,164 |  |  | $ | 78,828 |  |  | $ | 52,336 |  |
| Distribution network | 43,239 |  |  | 36,163 |  |  | 7,076 |  |
| Customer relationships, trademarks, and tradenames | 360,534 |  |  | 106,618 |  |  | 253,916 |  |
| Total | $ | 544,586 |  |  | $ | 223,339 |  |  | $ | 321,247 |  |

[0000889331-20-000014:notes:150]
|  | As of December 29, 2018 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 6,792 |  |  | $ | 1,168 |  |  | $ | 5,624 |  |
| Patents, licenses and software | $ | 132,621 |  |  | $ | 68,263 |  |  | $ | 64,358 |  |
| Distribution network | 43,876 |  |  | 34,564 |  |  | 9,312 |  |
| Customer relationships, trademarks, and tradenames | 374,246 |  |  | 92,066 |  |  | 282,180 |  |
| Total | $ | 557,535 |  |  | $ | 196,061 |  |  | $ | 361,474 |  |

[0000889331-20-000014:notes:151]
During the year ended December 29, 2018, the Company recorded additions to other intangible assets of $212.7 million, for acquisitions during 2018, the components of which were as follows:

[0000889331-20-000014:notes:152]
|  | 2018 |
| (in thousands, except weighted average useful life) | Weighted AverageUseful Life (Years) |  | Amount |
| Patents, licenses and software | 8.0 |  | $ | 51,500 |  |
| Customer relationships, trademarks, and tradenames | 17.2 |  | 148,800 |  |
| Order backlog | 1.0 |  | 12,420 |  |
| Total |  |  | $ | 212,720 |  |

[0000889331-20-000014:notes:153]
For intangible assets with definite lives, the Company recorded amortization expense of $40.0 million, $52.2 million, and $24.7 million in 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:154]
Estimated annual amortization expense related to intangible assets with definite lives at December 28, 2019 is as follows:

[0000889331-20-000014:notes:155]
| (in thousands) | Amount |
| 2020 | $ | 39,660 |  |
| 2021 | 37,865 |  |
| 2022 | 36,724 |  |
| 2023 | 32,372 |  |
| 2024 | 29,273 |  |
| 2025 and thereafter | 145,353 |  |
| Total | $ | 321,247 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-20-000014:notes:156]
Accrued Liabilities

[0000889331-20-000014:notes:157]
The components of accrued liabilities at December 28, 2019 and December 29, 2018 are as follows:

[0000889331-20-000014:notes:158]
| (in thousands) | 2019 |  | 2018 |
| Employee-related liabilities | $ | 40,774 |  |  | $ | 60,640 |  |
| Operating lease liability | 7,259 |  |  | — |  |
| Interest | 5,058 |  |  | 5,137 |  |
| Professional services | 3,986 |  |  | 6,169 |  |
| Restructuring liabilities | 2,679 |  |  | 3,887 |  |
| Other non-income taxes | 1,940 |  |  | 21,523 |  |
| Accrued share repurchases | — |  |  | 4,349 |  |
| Other | 22,424 |  |  | 36,700 |  |
| Total | $ | 84,120 |  |  | $ | 138,405 |  |

[0000889331-20-000014:notes:159]
Employee-related liabilities consist primarily of payroll, sales commission, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other client-related liabilities.


## us-gaap:CommitmentsDisclosureTextBlock

[0000889331-20-000014:notes:160]
Lease Commitments

[0000889331-20-000014:notes:161]
The Company leases office and production space under various non-cancellable operating leases that expire no later than 2025. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The Company also has production equipment, office equipment and vehicles under operating leases. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants.

[0000889331-20-000014:notes:162]
The Company does not have a published credit rating because it has no publicly traded debt; therefore, the Company is generating its incremental borrowing rate (IBR), using a synthetic credit rating model that compares its credit quality to other rated companies based on certain financial metrics and ratios. The reference rate will be based on the yield curve of companies with similar credit quality based on the metrics and adjusted for currency in regions where we have significant operations.

[0000889331-20-000014:notes:163]
All leases with an initial term of 12 months or less that do not include an option to extend or purchase the underlying asset that the Company is reasonably certain to exercise (“short-term leases”) are not recorded on the Consolidated Balance Sheets. Short-term lease expenses are recognized on a straight-line basis over the lease term.

[0000889331-20-000014:notes:164]
The following table presents the classification of ROU assets and lease liabilities as of December 28, 2019:

[0000889331-20-000014:notes:165]
| Leases(in thousands) | Consolidated Balance Sheet Classification | December 28, 2019 |
| Assets |  |  |
| Operating ROU assets | Right of use lease assets, net | $ | 21,918 |  |
| Liabilities |  |  |
| Current operating lease liabilities | Accrued liabilities | $ | 7,259 |  |
| Non-current operating lease liabilities | Non-current operating lease liabilities | 17,166 |  |
| Total lease liabilities |  | $ | 24,425 |  |

[0000889331-20-000014:notes:166]
The following table represents the lease costs for 2019:

[0000889331-20-000014:notes:167]
| Leases cost(in thousands) | Consolidated Statements of Net Income Classification | Fiscal Year Ended December 28, 2019 |
| Short-term lease expenses | Cost of sales, SG&A expenses | $ | 562 |  |
| Variable lease expenses | Cost of sales, SG&A expenses | 916 |  |
| Operating lease rent expenses | Cost of sales, SG&A expenses | 8,664 |  |
| Total operating lease costs | Cost of sales, SG&A expenses | $ | 10,142 |  |

[0000889331-20-000014:notes:168]
The Company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was $10.1 million, $9.6 million, and $11.6 million in 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:169]
| Maturity of Lease Liabilities as of December 28, 2019(in thousands) | Operating leases |
| 2020 | $8,207 |
| 2021 | 6,383 |  |
| 2022 | 5,297 |  |
| 2023 | 3,518 |  |
| 2024 | 3,165 |  |
| 2025 and thereafter | 458 |  |
| Total lease payments | $27,028 |
| Present value of lease liabilities | 24,425 |  |

[0000889331-20-000014:notes:170]
| Operating Lease Term and Discount Rate | Fiscal Year Ended December 28, 2019 |
| Weighted-average remaining lease term (years) | 4.05 |  |
| Weighted-average discount rate | 5.11 | % |

[0000889331-20-000014:notes:171]
| Other Information(in thousands) | Fiscal Year Ended December 28, 2019 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flow payments for operating leases | $ | (8,936 | ) |
| Leased assets obtained in exchange for operating lease liabilities | 3,962 |  |

[0000889331-20-000014:notes:172]
Under ASC 840, future minimum payments for all non-cancellable operating leases with initial terms of one year or more at December 29, 2018 are as follows:

[0000889331-20-000014:notes:173]
| (in thousands) | Fiscal Year EndedDecember 29, 2018 |
| 2019 | 9,133 |  |
| 2020 | 7,590 |  |
| 2021 | 5,574 |  |
| 2022 | 4,590 |  |
| 2023 | 2,946 |  |
| 2024 and thereafter | 2,774 |  |
| Total | $32,607 |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-20-000014:notes:174]
Restructuring, Impairment and Other Charges

[0000889331-20-000014:notes:175]
The Company recorded restructuring, impairment and other charges for fiscal years 2019, 2018, and 2017 as follows:

[0000889331-20-000014:notes:176]
|  | Fiscal Year Ended December 28, 2019 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 5,313 |  |  | $ | 4,251 |  |  | $ | 795 |  |  | $ | 10,359 |  |
| Other restructuring charges | 188 |  |  | 1,714 |  |  | 450 |  |  | 2,352 |  |
| Total restructuring charges | 5,501 |  |  | 5,965 |  |  | 1,245 |  |  | 12,711 |  |
| Impairment | — |  |  | 322 |  |  | — |  |  | 322 |  |
| Total | $ | 5,501 |  |  | $ | 6,287 |  |  | $ | 1,245 |  |  | $ | 13,033 |  |

[0000889331-20-000014:notes:177]
|  | Fiscal Year Ended December 29, 2018 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 8,742 |  |  | $ | 634 |  |  | $ | 127 |  |  | $ | 9,503 |  |
| Other restructuring charges | 670 |  |  | 192 |  |  | — |  |  | 862 |  |
| Total restructuring charges | 9,412 |  |  | 826 |  |  | 127 |  |  | 10,365 |  |
| Impairment | — |  |  | 88 |  |  | 2,130 |  |  | 2,218 |  |
| Total | $ | 9,412 |  |  | $ | 914 |  |  | $ | 2,257 |  |  | $ | 12,583 |  |

[0000889331-20-000014:notes:178]
|  | Fiscal Year Ended December 30, 2017 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 1,244 |  |  | $ | 371 |  |  | $ | 378 |  |  | $ | 1,993 |  |
| Other restructuring charges | 234 |  |  | — |  |  | — |  |  | 234 |  |
| Total restructuring charges | 1,478 |  |  | 371 |  |  | 378 |  |  | 2,227 |  |

[0000889331-20-000014:notes:179]
2019

[0000889331-20-000014:notes:180]
For the year ended December 28, 2019, the Company recorded total restructuring charges of $12.7 million for employee termination costs and other restructuring charges. These charges primarily related to the reorganization of operations and selling, general and administrative functions as well as the integration of IXYS within the Electronics segment and the reorganization of operations in the automotive sensors and commercial vehicle products businesses within the Automotive segment.

[0000889331-20-000014:notes:181]
In April 2019, we announced the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment. The Company recorded $1.7 million of employee termination costs and $1.4 million of other restructuring and impairment charges  associated with this plant closure.

[0000889331-20-000014:notes:182]
2018

[0000889331-20-000014:notes:183]
For the year ended December 29, 2018, the Company recorded total restructuring charges of $10.4 million for employee termination costs and other restructuring charges related to lease termination and facility closure. These charges primarily related to the integration of IXYS and the reorganization of the IXYS Radio Pulse business within the Electronics segment and the reorganization of operations in the Commercial Vehicle Products business within the Automotive segment.

[0000889331-20-000014:notes:184]
For the year ended December 29, 2018, the Company recorded impairment charges of $2.2 million primarily related to the impairment of a building and a trade name associated with the exit of the Custom business within the Industrial segment.

[0000889331-20-000014:notes:185]
2017

[0000889331-20-000014:notes:186]
For the year ended December 30, 2017, the Company recorded total restructuring charges of $2.2 million for employee termination costs and other restructuring charges. The Company recorded $2.0 million for employee termination costs primarily related to the reorganization of selling, general, and administrative functions within the Electronics segments as well as the reorganization of certain operations.

[0000889331-20-000014:notes:187]
The restructuring reserves as of December 28, 2019 and December 29, 2018 are $2.7 million and $3.9 million, respectively. The restructuring reserves are included within accrued liabilities. Payments associated with employee terminations reflected in the above table were substantially completed by December 28, 2019. The Company anticipates that the remaining payments associated with employee terminations will be completed in fiscal 2020.


## us-gaap:DebtDisclosureTextBlock

[0000889331-20-000014:notes:188]
Debt

[0000889331-20-000014:notes:189]
The carrying amounts of debt at December 28, 2019 and December 29, 2018 are as follows:

[0000889331-20-000014:notes:190]
| (in thousands) | 2019 |  | 2018 |
| Term Loan | $ | 145,000 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 | 129,808 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 | 105,400 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 | 125,000 |  |  | 125,000 |  |
| Other | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs | (3,669 | ) |  | (4,636 | ) |
| Total debt | 679,158 |  |  | 694,730 |  |
| Less: Current maturities | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt | $ | 669,158 |  |  | $ | 684,730 |  |

[0000889331-20-000014:notes:191]
Revolving Credit Facility / Term Loan

[0000889331-20-000014:notes:192]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000014:notes:193]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $10.0 million of principal payments on the Term Loan for the fiscal year ended December 28, 2019.

[0000889331-20-000014:notes:194]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR fixed for interest periods of one, two, three or six-month periods plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.20% at December 28, 2019.

[0000889331-20-000014:notes:195]
As of December 28, 2019, the Company had no amounts outstanding in letters of credit and had available $353.4 million of borrowing capacity under the Revolving Credit Facility. At December 28, 2019, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-20-000014:notes:196]
Senior Notes

[0000889331-20-000014:notes:197]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-20-000014:notes:198]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000014:notes:199]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 will be payable on February 15 and August 15, commencing on August 15, 2018.

[0000889331-20-000014:notes:200]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-20-000014:notes:201]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At December 28, 2019, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-20-000014:notes:202]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-20-000014:notes:203]
Interest paid on all Company debt was approximately $21.2 million,  $18.5 million, and $10.6 million in fiscal year ended 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:204]
Debt Issuance Costs

[0000889331-20-000014:notes:205]
The Company paid debt issuance costs of $0.9 million in relation to the $175 million Note Purchase Agreement that was entered on November 15, 2017. The Company incurred debt issuance costs of $1.6 million in relation to the 2017 amendment to the Credit Agreement which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the Credit Agreement. The Company incurred aggregate debt issuance costs of $1.8 million in relation to the Senior Notes issued previously which are being amortized over the respective lives of the Series A and B notes.

[0000889331-20-000014:notes:206]
Debt Maturities

[0000889331-20-000014:notes:207]
Scheduled maturities of the Company’s long-term debt for each of the five years succeeding December 28, 2019 and thereafter are summarized as follows:

[0000889331-20-000014:notes:208]
| (in thousands) | ScheduledMaturities |
| 2020 | $ | 10,000 |  |
| 2021 | 10,000 |  |
| 2022 | 152,619 |  |
| 2023 | 129,808 |  |
| 2024 | — |  |
| 2025 and thereafter | 380,400 |  |
|  | $ | 682,827 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-20-000014:notes:209]
Fair Value of Assets and Liabilities

[0000889331-20-000014:notes:210]
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a three-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows:

[0000889331-20-000014:notes:211]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0000889331-20-000014:notes:212]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable, and

[0000889331-20-000014:notes:213]
Level 3—Valuations based upon one or more significant unobservable inputs.

[0000889331-20-000014:notes:214]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0000889331-20-000014:notes:215]
Cash equivalents primarily consist of money market funds, which are held with an institution with sound credit rating and are highly liquid. The Company classified cash equivalents as Level 1 and are valued at cost, which approximates fair value.

[0000889331-20-000014:notes:216]
Investments in Equity Securities

[0000889331-20-000014:notes:217]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 1 of the valuation hierarchy. Such securities are further detailed in Note 1, Summary of Significant Accounting Policies and Other Information.

[0000889331-20-000014:notes:218]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in Investments and Other assets in the Consolidated Balance Sheets. During the fiscal year ended December 28, 2019, the Company recorded impairment charges of $7.3 million in Other Expense (income), net in the Consolidated Statements of Net Income to adjust these certain investments to their estimated fair value of $0.4 million. The fair value of these investments are measured on a nonrecurring basis and determined to be Level 3 under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.

[0000889331-20-000014:notes:219]
Defined Benefit Plan Assets / Non-qualified Supplemental Retirement and Savings Plan Investments

[0000889331-20-000014:notes:220]
See Note 11, Benefit Plans, for description of valuation methodologies and investment balances for defined benefit plan assets and investments related to the Company’s Non-Qualified Supplemental Retirement and Savings Plan.

[0000889331-20-000014:notes:221]
There were no changes during 2019 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. On October 30, 2019, the Company entered a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Chinese renminbi and U.S dollar. The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly basis. The loss of $0.2 million  associated with the change in fair values of the foreign currency exchange forward contract was recognized in Other income, net in the Consolidated Statements of Net Income along with a $0.2 million liability recorded in Accrued Liabilities on the Consolidated Balance Sheets. The notional value of the forward contracts at December 28, 2019 was $16.0 million and expires on May 5, 2020. The Company does not use derivative financial instruments for trading or speculative purposes. The fair values of the foreign currency forward contract was determined to be Level 2 under the fair value hierarchy and is valued using market exchange rates. As of December 29, 2018, the Company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-20-000014:notes:222]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 28, 2019:

[0000889331-20-000014:notes:223]
|  | Fair Value Measurements Using |  |  |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash Equivalents | $ | 118,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 118,999 |  |
| Investments in equity securities | 12,969 |  |  | — |  |  | — |  |  | 12,969 |  |
| Mutual funds | 10,464 |  |  | — |  |  | — |  |  | 10,464 |  |

[0000889331-20-000014:notes:224]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 29, 2018:

[0000889331-20-000014:notes:225]
|  | Fair Value Measurements Using |  |  |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Investments in equity securities | $ | 10,312 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,312 |  |
| Mutual funds | 9,112 |  |  | — |  |  | — |  |  | 9,112 |  |

[0000889331-20-000014:notes:226]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, trade receivables and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and trade receivables approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at December 28, 2019 and December 29, 2018, as the rates on these borrowings are variable in nature.

[0000889331-20-000014:notes:227]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of December 28, 2019 and December 29, 2018 were as follows:

[0000889331-20-000014:notes:228]
|  | December 28, 2019 |  | December 29, 2018 |
| (in thousands) | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 | $ | 129,808 |  |  | $ | 131,710 |  |  | $ | 133,417 |  |  | $ | 130,888 |  |
| Euro Senior Notes, Series B due 2028 | 105,400 |  |  | 110,336 |  |  | 108,330 |  |  | 103,774 |  |
| USD Senior Notes, Series A due 2022 | 25,000 |  |  | 25,054 |  |  | 25,000 |  |  | 24,115 |  |
| USD Senior Notes, Series B due 2027 | 100,000 |  |  | 102,548 |  |  | 100,000 |  |  | 94,458 |  |
| USD Senior Notes, Series A due 2025 | 50,000 |  |  | 50,775 |  |  | 50,000 |  |  | 47,434 |  |
| USD Senior Notes, Series B due 2030 | 125,000 |  |  | 127,701 |  |  | 125,000 |  |  | 114,731 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-20-000014:notes:229]
Benefit Plans

[0000889331-20-000014:notes:230]
The Company has Company-sponsored defined benefit pension plans covering employees in the United Kingdom ("U.K."), Germany, the Philippines, China, Japan, Mexico, Italy and France. The amount of the retirement benefits provided under the plans is based on years of service and final average pay.

[0000889331-20-000014:notes:231]
IXYS Acquisition

[0000889331-20-000014:notes:232]
During 2018, as a result of the IXYS acquisition, pension liabilities were assumed by the Company in Germany, Philippines, and U.K.

[0000889331-20-000014:notes:233]
Benefit plan related information is as follows for the years 2019 and 2018:

[0000889331-20-000014:notes:234]
| (in thousands) | 2019 |  | 2018 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 102,833 |  |  | $ | 67,268 |  |
| Service cost | 2,040 |  |  | 2,266 |  |
| Interest cost | 3,169 |  |  | 3,104 |  |
| Net actuarial gain/(loss) | 11,286 |  |  | (7,321 | ) |
| Benefits paid from the trust | (3,323 | ) |  | (2,479 | ) |
| Benefits paid directly by the Company | (1,540 | ) |  | (1,802 | ) |
| Settlements | (1,924 | ) |  | (1,291 | ) |
| Acquisitions | — |  |  | 48,358 |  |
| Effect of exchange rate movements | 1,735 |  |  | (6,918 | ) |
| Plan amendment and other | 2,645 |  |  | 1,648 |  |
| Benefit obligation at end of year | $ | 116,921 |  |  | $ | 102,833 |  |
| Change in plan assets at fair value: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 70,676 |  |  | $ | 48,123 |  |
| Actual return on plan assets | 8,222 |  |  | (2,847 | ) |
| Employer contributions | 2,233 |  |  | 2,341 |  |
| Benefits paid | (3,323 | ) |  | (2,479 | ) |
| Settlements | (1,072 | ) |  | (1,291 | ) |
| Acquisitions | — |  |  | 31,954 |  |
| Effect of exchange rate movements | 1,766 |  |  | (5,125 | ) |
| Fair value of plan assets at end of year | 78,502 |  |  | 70,676 |  |
| Net amount unfunded status | $ | (38,419 | ) |  | $ | (32,157 | ) |

[0000889331-20-000014:notes:235]
Amounts recognized in the Consolidated Balance Sheets as of December 28, 2019 and December 29, 2018 consist of the following:

[0000889331-20-000014:notes:236]
| (in thousands) | 2019 |  | 2018 |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |
| Noncurrent assets | $ | 885 |  |  | $ | 811 |  |
| Current benefit liability | (1,106 | ) |  | (1,094 | ) |
| Noncurrent benefit liability | (38,198 | ) |  | (31,874 | ) |
| Net liability recognized | $ | (38,419 | ) |  | $ | (32,157 | ) |

[0000889331-20-000014:notes:237]
The amounts included in accumulated other comprehensive loss in the Consolidated Balance Sheets, excluding tax effects, that have not yet been recognized as components of net periodic benefit costs as of December 28, 2019 and December 29, 2018 were as following:

[0000889331-20-000014:notes:238]
| (in thousands) | 2019 |  | 2018 |
| Net actuarial loss | $ | 15,635 |  |  | $ | 9,777 |  |
| Prior service cost | 4,273 |  |  | 1,607 |  |
| Total | $ | 19,908 |  |  | $ | 11,384 |  |

[0000889331-20-000014:notes:239]
The estimated net actuarial loss and prior service cost which will be amortized from accumulated other comprehensive income (loss) into benefit cost in 2020 is approximately $0.4 million and $0.2 million, respectively.

[0000889331-20-000014:notes:240]
The pre-tax amounts recognized in other comprehensive income (loss) in 2019 as components of net periodic benefit costs were as follows:

[0000889331-20-000014:notes:241]
| (in thousands) | 2019 |
| Amortization of: |  |
| Prior service cost | $ | 80 |  |
| Net actuarial loss | 163 |  |
| Amount arising during the period: |  |
| Prior service cost | (2,645 | ) |
| Net actuarial loss | (6,251 | ) |
| Settlement loss | 260 |  |
| Foreign currency adjustments | (131 | ) |
| Total | $ | (8,524 | ) |

[0000889331-20-000014:notes:242]
The components of net periodic benefits costs for the fiscal years 2019, 2018, and 2017 are as follows:

[0000889331-20-000014:notes:243]
| (in thousands) | 2019 |  | 2018 |  | 2017 |
| Components of net periodic benefit cost: |  |  |  |  |  |
| Service cost | $ | 2,040 |  |  | $ | 2,266 |  |  | $ | 2,037 |  |
| Interest cost | 3,169 |  |  | 3,104 |  |  | 1,887 |  |
| Expected return on plan assets | (3,187 | ) |  | (3,222 | ) |  | (1,990 | ) |
| Amortization of prior service and net actuarial loss | 243 |  |  | 291 |  |  | 337 |  |
| Net periodic benefit cost | 2,265 |  |  | 2,439 |  |  | 2,271 |  |
| Settlement loss / curtailment (gain) | 260 |  |  | 238 |  |  | (25 | ) |
| Total expense for the year | $ | 2,525 |  |  | $ | 2,677 |  |  | $ | 2,246 |  |

[0000889331-20-000014:notes:244]
Weighted average assumptions used to determine net periodic benefit cost for the fiscal years 2019, 2018, and 2017 are as follows:

[0000889331-20-000014:notes:245]
|  | 2019 |  | 2018 |  | 2017 |
| Discount rate | 3.1 | % |  | 2.8 | % |  | 3.0 | % |
| Expected return on plan assets | 4.5 | % |  | 4.2 | % |  | 4.5 | % |
| Compensation increase rate | 4.6 | % |  | 5.0 | % |  | 4.5 | % |

[0000889331-20-000014:notes:246]
The accumulated benefit obligation for the foreign plans was $111.3 million and $99.6 million at December 28, 2019 and December 29, 2018, respectively.

[0000889331-20-000014:notes:247]
The following table provides a summary of under-funded or unfunded pension benefit plans with projected benefit obligations in excess of plan assets as of December 28, 2019 and December 29, 2018:

[0000889331-20-000014:notes:248]
| (in thousands) | 2019 |  | 2018 |
| Projected benefit obligation | $ | 81,362 |  |  | $ | 70,579 |  |
| Fair value of plan assets | 42,058 |  |  | 37,611 |  |

[0000889331-20-000014:notes:249]
The following table provides a summary of under-funded or unfunded pension benefit plans with accumulated benefit obligations in excess of plan assets as of December 28, 2019 and December 29, 2018:

[0000889331-20-000014:notes:250]
| (in thousands) | 2019 |  | 2018 |
| Accumulated benefit obligation | $ | 75,744 |  |  | $ | 66,049 |  |
| Fair value of plan assets | 42,058 |  |  | 36,003 |  |

[0000889331-20-000014:notes:251]
Weighted average assumptions used to determine benefit obligations as of December 28, 2019, December 29, 2018 and December 30, 2017 are as follows:

[0000889331-20-000014:notes:252]
|  | 2019 |  | 2018 |  | 2017 |
| Discount rate | 2.3 | % |  | 3.1 | % |  | 3.1 | % |
| Compensation increase rate | 4.7 | % |  | 4.6 | % |  | 5.0 | % |

[0000889331-20-000014:notes:253]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows:

[0000889331-20-000014:notes:254]
| (in thousands) | Expected Benefit Payments |
| 2020 | $ | 4,511 |  |
| 2021 | 4,726 |  |
| 2022 | 4,624 |  |
| 2023 | 4,900 |  |
| 2024 | 4,910 |  |
| 2025-2029 and thereafter | 29,364 |  |

[0000889331-20-000014:notes:255]
The Company expects to make approximately $2.3 million of contributions to the plans in 2020.

[0000889331-20-000014:notes:256]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. For the fiscal year ended December 28, 2019, December 29, 2018, and December 30, 2017, the Company recorded $1.4 million, $1.8 million, $1.1 million expense, respectively, in Cost of Sales and Other expense (income), net within the Consolidated Statements of Net Income.  As of December 28, 2019 and December 29, 2018, the Company reported benefit liabilities of $2.8 million and $2.7 million for these plans, of which $0.9 million and $1.1 million was recorded in Accrued liabilities and $1.9 million and $1.6 million was recorded in Other long-term liabilities on the Consolidated Balance Sheets, respectively. For fiscal year ended December 28, 2019, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.6 million.

[0000889331-20-000014:notes:257]
Defined Benefit Plan Assets

[0000889331-20-000014:notes:258]
Based upon analysis of the target asset allocation and historical returns by type of investment, the Company has assumed that the expected long-term rate of return will be 4.5% on plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0000889331-20-000014:notes:259]
|  | Asset Allocation |
|  | 2019 |  | 2018 |
| Equity securities | 27 | % |  | 30 | % |
| Debt securities | 72 | % |  | 66 | % |
| Cash and cash equivalents, and other | 1 | % |  | 4 | % |
|  | 100 | % |  | 100 | % |

[0000889331-20-000014:notes:260]
The Company segregated its plan assets by the following major categories and level for determining their fair value as of December 28, 2019 and December 29, 2018. All plan assets that are valued using the net asset value per share (“NAV”) practical expedient have not been included within the fair value hierarchy but are separately disclosed.

[0000889331-20-000014:notes:261]
Cash and cash equivalents – Carrying value approximates fair value. As such, these assets were classified as Level 1. The Company also invests in certain short-term investments which are valued using the amortized cost method and at NAV.

[0000889331-20-000014:notes:262]
Equity – The values of individual equity securities were based on quoted prices in active markets. As such, these assets are classified as Level 1. Additionally, the Company invests in certain equity funds that are valued at calculated NAV.

[0000889331-20-000014:notes:263]
Fixed income – Fixed income securities are typically priced based on a last trade basis and are exchange-traded. Accordingly, the Company classified fixed income securities as Level 1. The Company also invests in certain fixed income funds which are valued at NAV.

[0000889331-20-000014:notes:264]
Insurance Contracts and other – This category includes insurance contracts that are valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market.  Accordingly, insurance contracts was categorized as Level 3.  Additionally, this category includes other assets and liabilities including futures or swaps valued at NAV.

[0000889331-20-000014:notes:265]
For any Level 2 and Level 3 plan assets, management reviews significant investments on a periodic basis including investigation of unusual fluctuations in price or returns and obtaining an understanding of the pricing methodology to assess the reliability of third-party pricing estimates.

[0000889331-20-000014:notes:266]
The valuation methodologies described above may generate a fair value calculation that may not be indicative of net realizable value or future fair values. While the Company believes the valuation methodologies used are appropriate, the use of different methodologies or assumptions in calculating fair value could result in different amounts. The Company invests in various assets in which valuation is determined by NAV. The Company believes that the NAV is representative of fair value at the reporting date, as there are no significant restrictions on redemption of these investments or other reasons to indicate that the investment would be redeemed at an amount different than the NAV.

[0000889331-20-000014:notes:267]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 28, 2019:

[0000889331-20-000014:notes:268]
|  | Fair Value Measurements Using |  |  |  |  |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Equities | $ | 1,796 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,139 |  |  | $ | 20,935 |  |
| Fixed income | 4,535 |  |  | — |  |  | — |  |  | 51,711 |  |  | 56,246 |  |
| Insurance contracts and other | — |  |  | — |  |  | 609 |  |  | 147 |  |  | 756 |  |
| Cash and cash equivalents | 387 |  |  | — |  |  | — |  |  | 178 |  |  | 565 |  |
| Total pension plan assets | $ | 6,718 |  |  | $ | — |  |  | $ | 609 |  |  | $ | 71,175 |  |  | $ | 78,502 |  |

[0000889331-20-000014:notes:269]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 29, 2018:

[0000889331-20-000014:notes:270]
|  | Fair Value Measurements Using |  |  |  |  |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Equities | $ | 1,361 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,527 |  |  | $ | 20,888 |  |
| Fixed income | 3,336 |  |  | — |  |  | — |  |  | 43,134 |  |  | 46,470 |  |
| Insurance contracts and other | — |  |  | — |  |  | 632 |  |  | 1,161 |  |  | 1,793 |  |
| Cash and cash equivalents | 702 |  |  | — |  |  | — |  |  | 823 |  |  | 1,525 |  |
| Total pension plan assets | $ | 5,399 |  |  | $ | — |  |  | $ | 632 |  |  | $ | 64,645 |  |  | $ | 70,676 |  |

[0000889331-20-000014:notes:271]
Defined Contribution Plan

[0000889331-20-000014:notes:272]
The Company also maintains a 401(k) savings plan covering substantially all U.S. employees. The Company matches 100% of the employee’s annual contributions for the first 4% of the employee’s eligible compensation. The Company may provide an additional discretionary match to participants and made discretionary matches of 2% of the employee’s eligible compensation for each of the fiscal year ended December 28, 2019, December 29, 2018 and December 30, 2017. Employees are immediately vested in their contributions plus actual earnings thereon, as well as the Company contributions. Company matching contributions amounted to $5.6 million, $4.5 million, and $3.5 million in 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:273]
Non-qualified Supplemental Retirement and Savings Plan

[0000889331-20-000014:notes:274]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The investments are subject to the claims of the Company’s creditors and the Company is responsible for the payment of all benefits under the plan from its general assets. As of December 28, 2019, there was $10.5 million of marketable securities related to the plan included in Other assets and $10.5 million of accrued compensation benefits included in Other long-term liabilities. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value. The Company made matching contributions to the plan of $0.4 million in 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000889331-20-000014:notes:275]
Equity Plans: The Company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, and other stock rights to employees and directors. As of December 28, 2019, there were 1.2 million shares available for issuance of future awards under the Company’s equity-based compensation plans.

[0000889331-20-000014:notes:276]
Stock options generally vest over a three, four or five-year period and are exercisable over either a seven or ten-year period commencing from the date of the grant. Restricted shares and share units granted by the Company generally vest over three to four years. Stock options and restricted share units may have accelerated vesting upon meeting certain qualified conditions.

[0000889331-20-000014:notes:277]
Upon completion of the IXYS acquisition, IXYS outstanding options were assumed by  the Company and converted into options of 499,027 shares. The Company recognized approximately $11.9 million of stock compensation expense related to IXYS stock options converted to Littelfuse stock options during the fiscal year ended December 29, 2018, of which $4.5 million was recognized immediately as it related to prior service periods. See Note 2, Acquisitions and Dispositions, for further discussion.

[0000889331-20-000014:notes:278]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended December 28, 2019.

[0000889331-20-000014:notes:279]
|  | Shares UnderOption |  | WeightedAveragePrice |  | WeightedAverageRemainingContract Life(Years) |  | AggregateIntrinsicValue(000’s) |
| Outstanding December 29, 2018 | 669,356 |  |  | $ | 116.29 |  |  |  |  |  |
| Granted | 76,742 |  |  | 199.24 |  |  |  |  |  |
| Exercised | (134,982 | ) |  | 97.22 |  |  |  |  |  |
| Forfeited | (10,651 | ) |  | 108.23 |  |  |  |  |  |
| Outstanding December 28, 2019 | 600,465 |  |  | 131.32 |  |  | 4.6 |  | $ | 37,048 |  |
| Exercisable December 28, 2019 | 413,109 |  |  | 111.65 |  |  | 4.0 |  | 33,215 |  |

[0000889331-20-000014:notes:280]
The following table provides a reconciliation of non-vested restricted share and share unit awards ("RSU") for the fiscal year ended December 28, 2019.

[0000889331-20-000014:notes:281]
|  | Shares |  | Weighted Average Grant-Date Fair Value |
| Nonvested December 29, 2018 | 160,794 |  |  | $ | 164.61 |  |
| Granted | 70,225 |  |  | 195.71 |  |
| Vested | (84,990 | ) |  | 154.38 |  |
| Forfeited | (11,893 | ) |  | 181.70 |  |
| Nonvested December 28, 2019 | 134,136 |  |  | 185.86 |  |

[0000889331-20-000014:notes:282]
The total intrinsic value of options exercised during 2019, 2018, and 2017 was $12.5 million, $38.3 million, and $2.2 million, respectively. The total fair value of the vested RSU shares was $15.5 million, $20.8 million, and $15.0 million for 2019, 2018, and 2017, respectively. The total amount of share-based liabilities paid was $0.9 million, $1.1 million and $0.9 million for 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:283]
The Company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At December 28, 2019, the unrecognized compensation cost for options and restricted shares was $17.4 million before tax, and will be recognized over a weighted average period of 1.8 years. Compensation cost included as a component of cost of sales, research and development and selling, general, and administrative expenses for all equity compensation plans discussed above was $19.9 million, $28.2 million, and $17.3 million for 2019, 2018, and 2017, respectively. The total related income tax benefit recognized in the Consolidated Statements of Net Income was $3.3 million, $6.0 million and $6.0 million for 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:284]
The Company uses the Black-Scholes option valuation model to determine the fair value of stock option awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0000889331-20-000014:notes:285]
|  | 2019 |  | 2018 |  | 2017 |
| Weighted average fair value of options granted | $47.63 |  | $45.19 |  | $30.77 |
| Assumptions: |  |  |  |  |  |
| Risk-free interest rate | 2.33% |  | 2.79% |  | 1.79% |
| Expected dividend yield | 0.86% |  | 0.77% |  | 0.86% |
| Expected stock price volatility | 27.0% |  | 25.0% |  | 23.0% |
| Expected life of options (years) | 4.4 |  | 4.4 |  | 4.4 |

[0000889331-20-000014:notes:286]
Expected volatilities are based on the historical volatility of the Company’s stock price. The expected life of options is based on historical data for options granted by the Company. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption. Historical nonvested forfeiture information is the basis for the forfeiture rate assumptions.

[0000889331-20-000014:notes:287]
The fair value of RSU is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-20-000014:notes:288]
Preferred Stock: The Board of Directors may authorize the issuance of preferred stock from time to time in one or more series with such designations, preferences, qualifications, limitations, restrictions, and optional or other special rights as the Board may fix by resolution.

[0000889331-20-000014:notes:289]
Share Repurchase Program

[0000889331-20-000014:notes:290]
On May 2, 2018, the Company announced that the Company’s Board of Directors had authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 ("2018 program"). On May 1, 2019, the Company announced that the Company's Board of Directors had authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program"). During the fiscal year 2019, the Company repurchased 579,916 shares of its common stock totaling $95.0 million. During the fiscal year 2018, the Company repurchased 391,972 shares of its common stock totaling $67.9 million.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-20-000014:notes:291]
Other Comprehensive Income (Loss)

[0000889331-20-000014:notes:292]
Changes in other comprehensive income (loss) by component for fiscal years 2019, 2018, and 2017 were as follows:

[0000889331-20-000014:notes:293]
|  | Fiscal Year Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 30, 2017 |
| (in thousands) | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |
| Defined benefit pension plan and other adjustments | $ | (9,149 | ) |  | $ | 1,062 |  |  | $ | (8,087 | ) |  | $ | 924 |  |  | $ | 47 |  |  | $ | 877 |  |  | $ | 1,532 |  |  | $ | 385 |  |  | $ | 1,147 |  |
| Unrealized loss on investments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (974 | ) |  | — |  |  | (974 | ) |
| Foreign currency translation adjustments | (1,476 | ) |  | 664 |  |  | (812 | ) |  | (25,338 | ) |  | — |  |  | (25,338 | ) |  | 10,738 |  |  | — |  |  | 10,738 |  |
| Total change in other comprehensive (loss) income | $ | (10,625 | ) |  | $ | 1,726 |  |  | $ | (8,899 | ) |  | $ | (24,414 | ) |  | $ | 47 |  |  | $ | (24,461 | ) |  | $ | 11,296 |  |  | $ | 385 |  |  | $ | 10,911 |  |

[0000889331-20-000014:notes:294]
Accumulated Other Comprehensive Income (Loss) (“AOCI”): The following table sets forth the changes in the components of AOCI by component for fiscal years 2019, 2018, and 2017:

[0000889331-20-000014:notes:295]
| (in thousands) | Pension and postretirement liability and reclassification adjustments |  | Gain (loss) on investments |  | Foreign currency translation adjustments |  | Accumulated other comprehensive income (loss) |
| Balance at December 31, 2016 | $ | (11,983 | ) |  | $ | 10,769 |  |  | $ | (73,365 | ) |  | $ | (74,579 | ) |
| 2017 activity | 1,147 |  |  | (974 | ) |  | 10,738 |  |  | 10,911 |  |
| Balance at December 30, 2017 | (10,836 | ) |  | 9,795 |  |  | (62,627 | ) |  | (63,668 | ) |
| Cumulative effect adjustment (a) | $ | — |  |  | $ | (9,795 | ) |  | $ | — |  |  | $ | (9,795 | ) |
| 2018 activity | 877 |  |  | — |  |  | (25,338 | ) |  | (24,461 | ) |
| Balance at December 29, 2018 | (9,959 | ) |  | — |  |  | (87,965 | ) |  | (97,924 | ) |
| 2019 activity | (8,087 | ) |  | — |  |  | (812 | ) |  | (8,899 | ) |
| Balance at December 28, 2019 | (18,046 | ) |  | — |  |  | (88,777 | ) |  | (106,823 | ) |

[0000889331-20-000014:notes:296]
| (a) | The Company adopted ASU 2016-01 on December 31, 2017 on a modified retrospective basis, recognizing the cumulative effect as a $9.8 million increase to retained earnings. See Note 1, Summary of Significant Accounting Policies and Other Information, for further discussion. |

[0000889331-20-000014:notes:297]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for fiscal years 2019, 2018, and 2017 were as follows:

[0000889331-20-000014:notes:298]
|  |  | Fiscal Year Ended |
| (in thousands) |  | December 28, 2019 |  | December 29, 2018 |  | December 30, 2017 |
| Pension and postemployment and other plans: |  |  |  |  |  |  |
| Amortization of prior service, net actuarial loss, and other |  | $ | 372 |  |  | $ | 291 |  |  | $ | 337 |  |
| Settlement loss/curtailment (gain) |  | 260 |  |  | 238 |  |  | (25 | ) |
| Total |  | $ | 632 |  |  | $ | 529 |  |  | $ | 312 |  |

[0000889331-20-000014:notes:299]
The Company recognizes the amortization of prior service costs and settlement loss and curtailment gain in other income, net within the Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-20-000014:notes:300]
On December 22, 2017, the U.S. enacted legislation referred to as the "Tax Act". Among other things, the Tax Act reduces the U.S. corporate federal income tax rate from 35% to 21%, adds base broadening provisions which limit deductions and address excessive international tax planning, imposes a Toll Charge on accumulated earnings of certain non-U.S. subsidiaries and enables repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. Other than the Toll Charge (which, except for the IXYS impact, was applicable to the Company for 2017), the provisions are generally applicable to the Company in 2018 and beyond.

[0000889331-20-000014:notes:301]
In accordance with the guidance provided in SEC SAB No. 118, in the fourth quarter of 2017 the Company recorded a charge of $47.0 million as a provisional reasonable estimate of the impact of the Tax Act, including $49.0 million for the Toll Charge net of $2.0 million for other net tax benefits. In the fourth quarter of 2018, within the measurement period outlined in SAB No. 118, the Company finalized its estimates of the impact of the Tax Act as of December 30, 2017 and recorded a charge of $3.2 million, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. In addition, the Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation. This was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities.

[0000889331-20-000014:notes:302]
The Company has elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The long-term portion of this Toll Charge which remains payable as of December 28, 2019, totaling $23.8 million, is recorded in Other long-term liabilities, and the anticipated 2020 annual installment payment of $3.0 million is included in Accrued income taxes, on the Consolidated Balance Sheet as of December 28, 2019. The Company did not elect to pay the 2018 IXYS Toll Charge over the eight year period provided by the Tax Act and therefore there is no long-term portion of this Toll Charge which remains payable as of December 28, 2019.

[0000889331-20-000014:notes:303]
One of the base broadening provisions of the Tax Act is commonly referred to as the “GILTI” provisions. In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 28, 2019 and December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-20-000014:notes:304]
Domestic and foreign income (loss) before income taxes is as follows:

[0000889331-20-000014:notes:305]
| (in thousands) | 2019 |  | 2018 |  | 2017 |
| Domestic | $ | (11,970 | ) |  | $ | (49,995 | ) |  | $ | (20,496 | ) |
| Foreign | 177,854 |  |  | 254,937 |  |  | 224,533 |  |
| Income before income taxes | $ | 165,884 |  |  | $ | 204,942 |  |  | $ | 204,037 |  |

[0000889331-20-000014:notes:306]
Federal, state and foreign income tax expense (benefit) consists of the following:

[0000889331-20-000014:notes:307]
| (in thousands) | 2019 |  | 2018 |  | 2017 |
| Current: |  |  |  |  |  |
| Federal | $ | (3,495 | ) |  | $ | (3,193 | ) |  | $ | 34,060 |  |
| State | 834 |  |  | 119 |  |  | 450 |  |
| Foreign | 30,610 |  |  | 48,130 |  |  | 32,945 |  |
| Subtotal | 27,949 |  |  | 45,056 |  |  | 67,455 |  |
| Deferred: |  |  |  |  |  |
| Federal and State | 1,839 |  |  | (3,896 | ) |  | 16,562 |  |
| Foreign | (2,986 | ) |  | (783 | ) |  | 501 |  |
| Subtotal | (1,147 | ) |  | (4,679 | ) |  | 17,063 |  |
| Provision for income taxes | $ | 26,802 |  |  | $ | 40,377 |  |  | $ | 84,518 |  |

[0000889331-20-000014:notes:308]
The current federal tax benefit for 2019 includes a benefit of $3.3 million from the recognition of previously unrecognized tax benefits (and the reversal of the related accrued interest) due to a lapse in the statute of limitations.

[0000889331-20-000014:notes:309]
The current federal tax benefit for 2018 includes the benefit of current year losses (which served to partially offset the amount of the IXYS Toll Charge that would otherwise have been payable).

[0000889331-20-000014:notes:310]
The current federal and state income tax expense for 2017 includes the preliminary estimate of $49 million for the Toll Charge as discussed above, partially offset by 13.0 million of foreign tax credits.

[0000889331-20-000014:notes:311]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0000889331-20-000014:notes:312]
| (in thousands) | 2019 |  | 2018 |  | 2017 |
| Tax expense at statutory rate of 21% (35% for 2017) | $ | 34,836 |  |  | $ | 43,038 |  |  | $ | 71,413 |  |
| Non-U.S. income tax rate differential | (22,457 | ) |  | (20,472 | ) |  | (47,077 | ) |
| Non-U.S. losses and expenses with no tax benefit | 6,570 |  |  | 3,107 |  |  | — |  |
| Net impact associated with the GILTI tax provisions | 6,469 |  |  | 5,075 |  |  | — |  |
| Tax on unremitted earnings | 2,136 |  |  | 4,660 |  |  | 12,202 |  |
| Certain changes in unrecognized tax benefits and related accrued interest | (1,468 | ) |  | 208 |  |  | 914 |  |
| State and local taxes, net of federal tax benefit | 1,080 |  |  | (1,238 | ) |  | 292 |  |
| Nondeductible professional fees | 195 |  |  | 1,001 |  |  | 1,240 |  |
| 2017 Toll Charge (and 2018 adjustment) | — |  |  | 2,278 |  |  | 49,000 |  |
| Provisional Tax Act impact other than Toll Charge (and 2018 adjustment) | — |  |  | 966 |  |  | (1,962 | ) |
| Other, net | (559 | ) |  | 1,754 |  |  | (1,504 | ) |
| Provision for income taxes | $ | 26,802 |  |  | $ | 40,377 |  |  | $ | 84,518 |  |

[0000889331-20-000014:notes:313]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the company’s assets and liabilities. Significant components of the company’s deferred tax assets and liabilities at December 28, 2019 and December 29, 2018, are as follows:

[0000889331-20-000014:notes:314]
| (in thousands) | 2019 |  | 2018 |
| Deferred tax assets: |  |  |  |
| Accrued expenses and reserves | $ | 28,294 |  |  | $ | 34,113 |  |
| Domestic and non-U.S. net operating loss carryforwards | 10,511 |  |  | 8,613 |  |
| Non-U.S. interest expense carryforwards | 5,324 |  |  | 885 |  |
| U.S. research credit carryforwards | 2,581 |  |  | 1,245 |  |
| Capitalized expenses | 2,400 |  |  | — |  |
| U.S. foreign tax credit carryforwards | 1,320 |  |  | 1,506 |  |
| Other | 1,261 |  |  | 1,000 |  |
| Gross deferred tax assets | 51,691 |  |  | 47,362 |  |
| Less: Valuation allowance | (5,957 | ) |  | (4,794 | ) |
| Total deferred tax assets | 45,734 |  |  | 42,568 |  |
| Deferred tax liabilities: |  |  |  |
| Excess of book basis over the tax basis of assets | 74,460 |  |  | 74,410 |  |
| Tax on unremitted earnings | 12,968 |  |  | 12,681 |  |
| Total deferred tax liabilities | 87,428 |  |  | 87,091 |  |
| Net deferred tax liabilities | $ | 41,694 |  |  | $ | 44,523 |  |

[0000889331-20-000014:notes:315]
The deferred tax asset valuation allowance is related to certain net operating loss and non-U.S. interest expense carryforwards which are not expected to be realized. The remaining net operating loss and non-U.S. interest expense carryforwards either have no expiration date or are expected to be utilized prior to expiration (which begin expiring in 2021). No deferred tax asset nor valuation allowance has been recorded for certain U.S. and non-U.S. net operating loss carryforwards for which the possibility of usage has been determined to be remote.

[0000889331-20-000014:notes:316]
The Company paid income taxes of $47.6 million, $46.2 million, and $31.8 million in 2019, 2018, and 2017, respectively, and received income tax refunds of $7.1 million, $4.3 million, and 13.7 million in 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:317]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. The Company believes the determination of the amount of such deferred income taxes is impractical as it would depend upon income tax laws and circumstances at the time of the hypothetical distributions or dispositions. As of December 28, 2019, unremitted earnings of the Company’s non-U.S. subsidiaries was approximately $776 million. A distribution of such earnings will generally not be subject to U.S. federal income tax. The Company recognized deferred tax liabilities of $13.0 million ($12.6 million for non-U.S. taxes net of related U.S. foreign tax credits, and $0.4 million for U.S. state taxes) as of December 28, 2019 and $12.7 million ($12.5 million for non-U.S. taxes net of related U.S. foreign tax credits, and $0.2 million for U.S. state taxes) as of December 29, 2018, related to taxes on certain non-U.S. earnings which are not considered to be permanently reinvested. Some of these non-U.S. taxes will provide a U.S. federal income tax benefit as a foreign tax credit, and the amounts as of December 28, 2019 and December 29, 2018 are net of such benefit (some of which, in respect of the year ended December 29, 2018, was recorded as part of finalizing the provisional reasonable estimate of the impact of the Tax Act).

[0000889331-20-000014:notes:318]
The Company has three subsidiaries in China which benefit from lowered income tax rates due to “tax holidays” which apply for three-year periods, subject to extension. The tax holiday for two of these subsidiaries expired at the end of 2019 (one will seek an extension and the tax holiday benefits for the other was not material). The tax holiday for the third subsidiary will expire at the end of 2020 and the Company plans to seek an extension. Such tax holidays contributed $4.2 million in tax benefits, or $0.17 per diluted share, during 2019. Future year tax benefits will depend upon the Company’s ability to obtain extensions, and the level of income earned by the two applicable subsidiaries.

[0000889331-20-000014:notes:319]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of December 28, 2019, December 29, 2018, and December 30, 2017 is as follows:

[0000889331-20-000014:notes:320]
| (in thousands) | Unrecognized Tax Benefits |
| Balance at December 30, 2017 | $ | 7,660 |  |
| Additions for tax positions taken in the current year | 2,929 |  |
| Additions for tax positions related to the pre-acquisition periods of acquired subsidiaries | 9,394 |  |
| Decreases due to a lapse in the statute of limitations | (1,257 | ) |
| Other | (467 | ) |
| Balance at December 29, 2018 | 18,259 |  |
| Additions for tax positions taken in the current year | 1,305 |  |
| Decreases due to a lapse in the statute of limitations | (2,758 | ) |
| Other | (85 | ) |
| Balance at December 28, 2019 | 16,721 |  |

[0000889331-20-000014:notes:321]
The company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense. The company recognized such interest expense of $1.3 million (net of a $0.6 million decrease due to a lapse in the statute of limitations), $1.5 million (net of a $0.3 million decrease due to a lapse in the statute of limitations), and $0.9 million in 2019, 2018, and 2017, respectively. Accrued interest for such matters included in Other long-term liabilities within the Consolidated Balance Sheets was $7.2 million and $5.9 million as of December 28, 2019 and December 29, 2018, respectively.

[0000889331-20-000014:notes:322]
The amount of unrecognized tax benefits included in Other long-term liabilities within the Consolidated Balance Sheets was $16.7 million and $18.3 million as of December 28, 2019 and December 29, 2018, respectively. The December 28, 2019 total represents the net amount of tax benefits that, if recognized, would favorably affect the effective income tax rate in future periods. Of this amount, approximately $0.1 million may be recognized in 2020 based upon the possible lapse in the statute of limitations. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility.

[0000889331-20-000014:notes:323]
The U.S. federal statute of limitations remains open for the Company for the 2016 tax year and later years, although the Company has been audited for the 2016 tax year and the audit concluded in 2018 with no significant adjustments. The U.S. federal statute of limitations remains open for IXYS pre-acquisition tax periods ending March 31, 2017 and January 17, 2018. Non-U.S. and U.S. state statutes of limitations generally range from three to seven years, although certain jurisdictions do not have a statute expiration. Non-U.S. tax examinations occur from time to time, including examinations currently in process in Italy, Canada, and Hong Kong. The company does not expect to recognize a significant amount of additional tax expense as a result of concluding these examinations.


## us-gaap:EarningsPerShareTextBlock

[0000889331-20-000014:notes:324]
Earnings Per Share

[0000889331-20-000014:notes:325]
The following table sets forth the computation of basic and diluted earnings per share:

[0000889331-20-000014:notes:326]
| (in thousands, except per share amounts) | 2019 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |
| Net income as reported | $ | 139,082 |  |  | $ | 164,565 |  |  | $ | 119,519 |  |
| Denominator: |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |
| Basic | 24,576 |  |  | 24,870 |  |  | 22,687 |  |
| Effect of dilutive securities | 242 |  |  | 365 |  |  | 244 |  |
| Diluted | 24,818 |  |  | 25,235 |  |  | 22,931 |  |
| Earnings Per Share: |  |  |  |  |  |
| Basic earnings per share | $ | 5.66 |  |  | $ | 6.62 |  |  | $ | 5.27 |  |
| Diluted earnings per share | $ | 5.60 |  |  | $ | 6.52 |  |  | $ | 5.21 |  |

[0000889331-20-000014:notes:327]
Potential shares of common stock attributable to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 129,658, 42,305, and 37,443 shares in 2019, 2018, and 2017, respectively.

[0000889331-20-000014:notes:328]
On January 17, 2018, the Company acquired IXYS through a combination of cash, Littelfuse common stock, and the value of converted, or cash settled IXYS equity awards. The Company issued approximately 2.1 million shares of Littelfuse common stock and converted IXYS equity awards into approximately 0.5 million Littelfuse equity awards.

[0000889331-20-000014:notes:329]
During the fiscal year 2019, the Company repurchased 579,916 shares of its common stock totaling $95.0 million. During the fiscal year 2018, the Company repurchased 391,972 shares of its common stock totaling $67.9 million. See Note 12 Stock-Based Compensation for further discussion.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-20-000014:notes:330]
Segment Information

[0000889331-20-000014:notes:331]
The Company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The Company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0000889331-20-000014:notes:332]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it.  Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-20-000014:notes:333]
| • | Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, metal-oxide-semiconductor field-effect transistors (“MOSFETs”) and silicon carbide diodes; and insulated gate bipolar transistors (“IGBT”) technologies. |

[0000889331-20-000014:notes:334]
The segment covers a broad range of end markets, including industrial and automotive electronics, electric vehicle and related infrastructure, data and telecommunications, medical devices, alternative energy, consumer electronics and white goods.

[0000889331-20-000014:notes:335]
| • | Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle end markets. Passenger car fuse products include fuses and fuse accessories for internal combustion engine vehicles and hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules for the commercial vehicle industry. Automotive sensor products include a wide range of automotive and commercial vehicle products designed to monitor the passenger compartment occupants, safety and environment as well as the vehicle’s powertrain. |

[0000889331-20-000014:notes:336]
| • | Industrial Segment: Consists of power fuses, protection relays and controls and other circuit protection products for use in various industrial applications such as oil, gas, mining, alternative energy, electric vehicle infrastructure, non-residential construction, HVAC systems, elevators and other industrial equipment. |

[0000889331-20-000014:notes:337]
The Company has provided this segment information for all comparable prior periods. Segment information is summarized as follows:

[0000889331-20-000014:notes:338]
| (in thousands) | 2019 |  | 2018 |  | 2017 |
| Net sales |  |  |  |  |  |
| Electronics | $ | 961,080 |  |  | $ | 1,124,296 |  |  | $ | 661,928 |  |
| Automotive | 428,533 |  |  | 479,791 |  |  | 453,227 |  |
| Industrial | 114,260 |  |  | 114,381 |  |  | 106,379 |  |
| Total net sales | $ | 1,503,873 |  |  | $ | 1,718,468 |  |  | $ | 1,221,534 |  |
| Depreciation and amortization |  |  |  |  |  |
| Electronics | $ | 60,345 |  |  | $ | 61,779 |  |  | $ | 35,215 |  |
| Automotive | 27,922 |  |  | 23,333 |  |  | 22,459 |  |
| Industrial | 4,236 |  |  | 5,661 |  |  | 5,337 |  |
| Other | — |  |  | 12,420 |  |  | — |  |
| Total depreciation and amortization | $ | 92,503 |  |  | $ | 103,193 |  |  | $ | 63,011 |  |
| Operating income (loss) |  |  |  |  |  |
| Electronics | $ | 145,594 |  |  | $ | 241,426 |  |  | $ | 155,880 |  |
| Automotive | 46,719 |  |  | 54,982 |  |  | 62,571 |  |
| Industrial | 22,407 |  |  | 17,335 |  |  | 10,334 |  |
| Other(a) | (21,929 | ) |  | (88,694 | ) |  | (10,274 | ) |
| Total operating income | 192,791 |  |  | 225,049 |  |  | 218,511 |  |
| Interest expense | 22,266 |  |  | 22,569 |  |  | 13,380 |  |
| Foreign exchange (gain) loss | 5,224 |  |  | (863 | ) |  | 2,376 |  |
| Other income, net | (583 | ) |  | (1,599 | ) |  | (1,282 | ) |
| Income before income taxes | $ | 165,884 |  |  | $ | 204,942 |  |  | $ | 204,037 |  |

[0000889331-20-000014:notes:339]
(a) Included in “Other” Operating income (loss) for 2019 is $8.9 million of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there were $13.0 million of restructuring charges primarily related to employee termination costs. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-20-000014:notes:340]
Included in “Other” Operating income (loss) for 2018 is $88.7 million of charges primarily related to the IXYS acquisition, which include $36.9 million of purchase accounting inventory step-up charges, $18.7 million  in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $12.4 million in backlog amortization costs, $8.3 million of employee termination costs, impairment and other restructuring charges, and $4.5 million in stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods and $2.1 million change in control expense related to IXYS. In addition, there were $5.8 million of employee termination costs, impairment and other restructuring charges

[0000889331-20-000014:notes:341]
and acquisition-related expenses for other contemplated acquisitions which included $2.2 million of impairment charges primarily related to the impairment of a building and a trade name associated with the exit of the Custom business within the Industrial segment.

[0000889331-20-000014:notes:342]
Included in “Other” Operating income (loss) for 2017 are costs related to acquisition and integration costs associated with the Company’s completed and pending acquisitions in 2017 ($8.0 million in Cost of sales ("COS") and Selling, general, and administrative expenses (“SG&A”), and charges related to restructuring and production transfers in the Company’s Asia operations ($2.2 million in SG&A).

[0000889331-20-000014:notes:343]
The Company’s net sales, long-lived assets and additions to long-lived assets by country for the fiscal years ended 2019, 2018, and 2017 are as follows:

[0000889331-20-000014:notes:344]
| (in thousands) | 2019 |  | 2018 |  | 2017 |
| Net sales |  |  |  |  |  |
| United States | $ | 440,461 |  |  | $ | 511,544 |  |  | $ | 383,025 |  |
| China | 416,385 |  |  | 468,174 |  |  | 321,111 |  |
| Other countries(a) | 647,027 |  |  | 738,750 |  |  | 517,398 |  |
| Total net sales | $ | 1,503,873 |  |  | $ | 1,718,468 |  |  | $ | 1,221,534 |  |
| Long-lived assets |  |  |  |  |  |
| United States | $ | 58,081 |  |  | $ | 58,691 |  |  | $ | 23,490 |  |
| China | 88,306 |  |  | 95,806 |  |  | 86,866 |  |
| Mexico | 73,096 |  |  | 70,495 |  |  | 62,510 |  |
| Germany | 36,025 |  |  | 36,548 |  |  | 1,082 |  |
| Philippines | 51,738 |  |  | 32,459 |  |  | 31,129 |  |
| Other countries | 37,371 |  |  | 45,895 |  |  | 45,500 |  |
| Total long-lived assets | $ | 344,617 |  |  | $ | 339,894 |  |  | $ | 250,577 |  |
| Additions to long-lived assets |  |  |  |  |  |
| United States | $ | 5,864 |  |  | $ | 5,567 |  |  | $ | 3,518 |  |
| China | 10,400 |  |  | 29,286 |  |  | 32,775 |  |
| Mexico | 13,827 |  |  | 18,723 |  |  | 19,395 |  |
| Germany | 4,017 |  |  | 5,208 |  |  | 93 |  |
| Philippines | 22,944 |  |  | 7,605 |  |  | 2,979 |  |
| Other countries | 9,314 |  |  | 8,364 |  |  | 7,165 |  |
| Total additions to long-lived assets | $ | 66,366 |  |  | $ | 74,753 |  |  | $ | 65,925 |  |

[0000889331-20-000014:notes:345]
| (a) | Each country included in other countries are less than 10% of net sales. |

[0000889331-20-000014:notes:346]
For the year ended December 28, 2019, approximately 71% of the Company’s net sales were to customers outside the United States (exports and foreign operations), including approximately 28% to China. For the year ended December 29, 2018, approximately 70% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 27% to China. For the year ended December 30, 2017, approximately 69% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 26% to China. Sales to Arrow Electronics, Inc., which were included in the Electronics, Automotive, and Industrial segments, were 10.7%, 10.7%, and 10.6% of consolidated net sales in 2019, 2018, and 2017 respectively. No other single customer accounted for more than 10% of net sales during the last three years.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000889331-20-000014:notes:347]
Selected Quarterly Financial Data (Unaudited)

[0000889331-20-000014:notes:348]
The quarterly periods for 2019 are for the 13-weeks ended December 28, 2019, September 28, 2019, June 29, 2019, and March 30, 2019, respectively. The quarterly periods for 2018 are for the 13-weeks ended December 29, 2018, September 29, 2018, June 30, 2018, and March 31, 2018, respectively.

[0000889331-20-000014:notes:349]
| (in thousands, except per share data) |  |  |
|  | 2019 |  | 2018 |
|  | 4Q(a) |  | 3Q(b) |  | 2Q(c) |  | 1Q(d) |  | 4Q(e) |  | 3Q(f) |  | 2Q(g) |  | 1Q(h) |
| Net sales | $ | 338,523 |  |  | $ | 361,971 |  |  | $ | 397,879 |  |  | $ | 405,500 |  |  | $ | 402,281 |  |  | $ | 439,191 |  |  | $ | 459,183 |  |  | $ | 417,813 |  |
| Gross profit | 113,467 |  |  | 130,946 |  |  | 141,808 |  |  | 155,228 |  |  | 154,337 |  |  | 179,594 |  |  | 168,987 |  |  | 149,623 |  |
| Operating income | 32,317 |  |  | 47,167 |  |  | 52,634 |  |  | 60,673 |  |  | 51,628 |  |  | 76,228 |  |  | 59,622 |  |  | 37,571 |  |
| Net income | 22,654 |  |  | 35,647 |  |  | 43,792 |  |  | 36,989 |  |  | 32,665 |  |  | 53,546 |  |  | 42,326 |  |  | 36,029 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.93 |  |  | $ | 1.46 |  |  | $ | 1.77 |  |  | $ | 1.50 |  |  | $ | 1.31 |  |  | $ | 2.13 |  |  | $ | 1.69 |  |  | $ | 1.48 |  |
| Diluted | $ | 0.92 |  |  | $ | 1.44 |  |  | $ | 1.75 |  |  | $ | 1.48 |  |  | $ | 1.29 |  |  | $ | 2.10 |  |  | $ | 1.67 |  |  | $ | 1.45 |  |

[0000889331-20-000014:notes:350]
(a)In the fourth quarter of 2019, the Company recorded $1.9 million in acquisition-related and integration costs and $2.1 million in restructuring, impairment and other costs, and $4.2 million impairment charges related to certain other investments, partially offset by a $3.3 million benefit for previously unrecognized tax benefits in respect of which the statute of limitation has expired.

[0000889331-20-000014:notes:351]
(b)In the third quarter of 2019, the Company recorded $3.2 million in acquisition-related and integration costs and $2.5 million in restructuring and impairment charge

[0000889331-20-000014:notes:352]
(c)In the second quarter of 2019, the Company recorded $5.7 million in restructuring and impairment charges, $1.5 million in acquisition-related and integration costs, and $0.4 million costs primarily related to a sale of building and $0.2 million impairment charges related to a certain other investment.

[0000889331-20-000014:notes:353]
(d)In the first quarter of 2019, the Company recorded $2.8 million impairment charges to certain other investments, $2.6 million loss on the disposal of a business, $2.7 million in restructuring costs, $2.4 million in acquisition-related and integration costs, and $0.3 million gain primarily related to the final payments for the acquisition of Monolith

[0000889331-20-000014:notes:354]
(e)In the fourth quarter of 2018, the Company recorded an estimated one-time tax charge of $3.2 million related to the finalization of 2017 provisional reasonable estimate in connection with the Tax Act, partially offset by a $1.5 million benefit for previously unrecognized tax benefits in respect of which the statute of limitation has expired, $3.7 million in backlog amortization expense from the IXYS acquisition, $3.2 million in acquisition-related and integration costs and $2.4 million  in restructuring, impairment and other costs.

[0000889331-20-000014:notes:355]
(f)In the third quarter of 2018, the Company recorded $5.2 million in restructuring and impairment charges, $3.1 million in backlog amortization expense from the IXYS acquisition and $2.9 million in acquisition-related and integration costs

[0000889331-20-000014:notes:356]
(g)In the second quarter of 2018, the Company recorded $19.0 million for purchase accounting inventory adjustments associated with the acquisition of IXYS, $4.2 million in restructuring and impairment charges, $3.1 million in backlog amortization expense from the IXYS acquisition $2.4 million in acquisition-related and integration costs.

[0000889331-20-000014:notes:357]
(h)In the first quarter of 2018, the Company recorded $17.9 million for purchase accounting inventory adjustments associated with the acquisition of IXYS, $11.7 million in acquisition-related and integration costs, $4.5 million of stock compensation expense recognized immediately upon close for converted IXYS options related to prior services periods, $2.5 million in backlog amortization expense,$2.1 million expense related to change in control and $0.8 million in restructuring costs.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-20-000014:notes:358]
Related Party Transactions

[0000889331-20-000014:notes:359]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-20-000014:notes:360]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-20-000014:notes:361]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB-Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-20-000014:notes:362]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-20-000014:notes:363]
|  | Fiscal Year Ended |
|  | December 28, 2019 |  | December 29, 2018 |
| (in millions) | Powersem |  | EB Tech |  | ATEC |  | Powersem |  | EB Tech |  | ATEC |
| Sales to related party | $ | 0.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | — |  |
| Purchase material/service from related party | 3.2 |  |  | 0.4 |  |  | 7.9 |  |  | 4.5 |  |  | 0.5 |  |  | 9.9 |  |
| Account Receivable balance | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Account Payable balance | $ | 0.2 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | 0.5 |  |

[0000889331-20-000014:notes:364]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.4 million as of December 28, 2019 where one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

[0000889331-20-000014:notes:365]
On April 26, 2019, the Company sold its subsidiary Microwave Technology, LLC. (“MWT”) resulting in a loss on disposal of $2.6 million reflected in Other income (expense), net in the Consolidated Statements of Net Income. The operations of MWT were included in the Electronics segment. One member of the Company’s Board of Directors is an owner of a company that purchased MWT.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000889331-20-000014:notes:366]
SCHEDULE II

[0000889331-20-000014:notes:367]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0000889331-20-000014:notes:368]
| Description | Balance atBeginningof Year |  | Charged toCosts andExpenses (a) |  | Deductions (b) |  | Other (c) |  | Balance atEndof Year |
| (in thousands) |  |  |  |  |  |  |  |  |  |
| Fiscal year ended December 28, 2019 |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable | $ | 1,062 |  |  | $ | 410 |  |  | $ | (172 | ) |  | $ | 10 |  |  | $ | 1,310 |  |
| Reserves for sales discounts and allowances | $ | 34,976 |  |  | $ | 133,434 |  |  | $ | (127,330 | ) |  | $ | (347 | ) |  | $ | 40,733 |  |
| Fiscal year ended December 29, 2018 |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable | $ | 1,172 |  |  | $ | 319 |  |  | $ | (557 | ) |  | $ | 128 |  |  | $ | 1,062 |  |
| Reserves for sales discounts and allowances | $ | 26,344 |  |  | $ | 124,638 |  |  | $ | (118,438 | ) |  | $ | 2,432 |  |  | $ | 34,976 |  |
| Fiscal year ended December 30, 2017 |  |  |  |  |  |  |  |  |  |
| Allowance for losses on accounts receivable | $ | 2,079 |  |  | $ | 3,068 |  |  | $ | (4,070 | ) |  | $ | 95 |  |  | $ | 1,172 |  |
| Reserves for sales discounts and allowances | $ | 23,825 |  |  | $ | 106,781 |  |  | $ | (104,941 | ) |  | $ | 679 |  |  | $ | 26,344 |  |

[0000889331-20-000014:notes:369]
| (a) | Includes provision for doubtful accounts, sales returns and sales discounts granted to customers. |

[0000889331-20-000014:notes:370]
| (b) | Represents uncollectible accounts written off, net of recoveries and credits issued to customers. |

[0000889331-20-000014:notes:371]
(c)

[0000889331-20-000014:notes:372]
Represents business acquisitions and foreign currency translation adjustments.
