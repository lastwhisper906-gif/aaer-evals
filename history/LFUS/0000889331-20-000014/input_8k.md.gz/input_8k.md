# LFUS 8-K — 0000889331-20-000007 filed 2020-01-29

## item codes, every 8-K on or before 2020-02-21

- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2020-02-21

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-20-000007:8k_2_02:1]
EX-99.1
2
q42019ex991.htm
EXHIBIT 99.1

[0000889331-20-000007:8k_2_02:2]
Exhibit

[0000889331-20-000007:8k_2_02:3]
Exhibit 99.1

[0000889331-20-000007:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-20-000007:8k_2_02:5]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS FOR 2019

[0000889331-20-000007:8k_2_02:6]
CHICAGO, January 29, 2020 - Littelfuse, Inc. (NASDAQ: LFUS), a global manufacturer of leading technologies in circuit protection, power control and sensing, today reported financial results for the fourth quarter and full year ended December 28, 2019:

[0000889331-20-000007:8k_2_02:7]
Fourth Quarter 2019 Results

[0000889331-20-000007:8k_2_02:8]
| • | Net sales of $338.5 million were down 16% versus the prior year period, and down 14% organically, primarily due to ongoing global trade uncertainties, excess electronics channel inventories and declines in global auto production |

[0000889331-20-000007:8k_2_02:9]
| • | Segment performance versus the prior year period: |

[0000889331-20-000007:8k_2_02:10]
| • | Electronics sales decreased 21% (down 19% organically) |

[0000889331-20-000007:8k_2_02:11]
| • | Automotive sales decreased 9% (down 8% organically) |

[0000889331-20-000007:8k_2_02:12]
| • | Industrial sales increased 7% (up 7% organically) |

[0000889331-20-000007:8k_2_02:13]
| • | GAAP diluted EPS was $0.92; adjusted diluted EPS was $1.17, which included an $0.11 benefit related to a lower effective tax rate versus the forecasted rate, partially offset by a $0.06 currency headwind |

[0000889331-20-000007:8k_2_02:14]
Full Year 2019 Results

[0000889331-20-000007:8k_2_02:15]
| • | Net sales of $1.50 billion were down 13% versus the prior year period, and down 11% organically |

[0000889331-20-000007:8k_2_02:16]
| • | Segment performance versus the prior year: |

[0000889331-20-000007:8k_2_02:17]
| • | Electronics sales decreased 15% (down 14% organically) |

[0000889331-20-000007:8k_2_02:18]
| • | Automotive sales decreased 11% (down 8% organically) |

[0000889331-20-000007:8k_2_02:19]
| • | Industrial sales were flat (up 4% organically) |

[0000889331-20-000007:8k_2_02:20]
| • | GAAP diluted EPS was $5.60; adjusted diluted EPS was $6.82 |

[0000889331-20-000007:8k_2_02:21]
| • | GAAP effective tax rate was 16.2% and the adjusted effective tax rate was 16.7% |

[0000889331-20-000007:8k_2_02:22]
| • | During the year, the company repurchased approximately $95.0 million of common stock |

[0000889331-20-000007:8k_2_02:23]
| • | Cash flow from operations was $245.3 million and free cash flow was $183.4 million, representing a 132% conversion from net income |

[0000889331-20-000007:8k_2_02:24]
-more-

[0000889331-20-000007:8k_2_02:25]
“Our global teams remained focused on driving long-term growth, profitability and cash generation within a challenging 2019 macro environment," said Dave Heinzmann, Littelfuse President and Chief Executive Officer. "We actively managed costs to align to business conditions and advanced several strategic initiatives across the end markets we serve. Looking ahead, we remain confident that our leading technologies, global footprint, close customer relationships, and talented associates position our company for profitable growth through the course of 2020.”

[0000889331-20-000007:8k_2_02:26]
Guidance excludes potential business impacts from the coronavirus beyond the company's known specific impacts.

[0000889331-20-000007:8k_2_02:27]
For the first quarter of 2020*, the company expects:

[0000889331-20-000007:8k_2_02:28]
•Net sales in the range of $352 to $364 million

[0000889331-20-000007:8k_2_02:29]
•Adjusted diluted EPS in the range of $1.21 to $1.35

[0000889331-20-000007:8k_2_02:30]
•Adjusted effective tax rate in the range of 18.5% - 19.5%

[0000889331-20-000007:8k_2_02:31]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-20-000007:8k_2_02:32]
Dividend

[0000889331-20-000007:8k_2_02:33]
| • | The company will pay a cash dividend on its common stock of $0.48 per share on March 5, 2020 to shareholders of record as of February 20, 2020 |

[0000889331-20-000007:8k_2_02:34]
Conference Call and Webcast Information

[0000889331-20-000007:8k_2_02:35]
Littelfuse will host a conference call today, Wednesday, January 29, 2020, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast live and available for replay at Littelfuse.com.

[0000889331-20-000007:8k_2_02:36]
About Littelfuse

[0000889331-20-000007:8k_2_02:37]
Littelfuse (NASDAQ: LFUS) is a global manufacturer of leading technologies in circuit protection, power control and sensing. Serving over 100,000 end customers, our products are found in automotive and commercial vehicles, industrial applications, data and telecommunications, medical devices, consumer electronics and appliances. Our 11,000 worldwide associates partner with customers to design, manufacture and deliver innovative, high-quality solutions, for a safer, greener and increasingly connected world - everywhere, every day. Learn more at Littelfuse.com.

[0000889331-20-000007:8k_2_02:38]
-more-

[0000889331-20-000007:8k_2_02:39]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity price fluctuations; the effect of Littelfuse, Inc.'s ("Littelfuse" or the "Company") accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 29, 2018. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended December 29, 2018.

[0000889331-20-000007:8k_2_02:40]
Non-GAAP Financial Measures

[0000889331-20-000007:8k_2_02:41]
The information included in this press release includes the non-GAAP financial measures of organic sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted effective tax rate, free cash flow, net debt, adjusted gross leverage, and adjusted net leverage. Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-20-000007:8k_2_02:42]
The company believes that organic sales growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, adjusted gross leverage and adjusted net leverage are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-20-000007:8k_2_02:43]
CONTACT: Trisha Tuntland

[0000889331-20-000007:8k_2_02:44]
Head of Investor Relations

[0000889331-20-000007:8k_2_02:45]
(773) 628-2163

[0000889331-20-000007:8k_2_02:46]
###

[0000889331-20-000007:8k_2_02:47]
LFUS-F

[0000889331-20-000007:8k_2_02:48]
LITTELFUSE, INC.

[0000889331-20-000007:8k_2_02:49]
CONSOLIDATED BALANCE SHEETS

[0000889331-20-000007:8k_2_02:50]
| (in thousands) | December 28, 2019 |  | December 29, 2018 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 531,139 |  |  | $ | 489,733 |  |
| Short-term investments | 44 |  |  | 34 |  |
| Trade receivables, less allowances of $42,043 and $36,038 at December 28, 2019 and December 29, 2018, respectively | 202,309 |  |  | 232,892 |  |
| Inventories | 237,507 |  |  | 258,228 |  |
| Prepaid income taxes and income taxes receivable | 4,831 |  |  | 2,339 |  |
| Prepaid expenses and other current assets | 28,564 |  |  | 49,291 |  |
| Total current assets | 1,004,394 |  |  | 1,032,517 |  |
| Net property, plant, and equipment | 344,617 |  |  | 339,894 |  |
| Intangible assets, net of amortization | 321,247 |  |  | 361,474 |  |
| Goodwill | 820,589 |  |  | 826,715 |  |
| Investments | 24,099 |  |  | 25,405 |  |
| Deferred income taxes | 8,069 |  |  | 7,330 |  |
| Rights of use lease assets, net | 21,918 |  |  | — |  |
| Other assets | 14,965 |  |  | 20,971 |  |
| Total assets | $ | 2,559,898 |  |  | $ | 2,614,306 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 117,320 |  |  | $ | 126,323 |  |
| Accrued liabilities | 84,120 |  |  | 138,405 |  |
| Accrued income taxes | 14,122 |  |  | 20,547 |  |
| Current portion of long-term debt | 10,000 |  |  | 10,000 |  |
| Total current liabilities | 225,562 |  |  | 295,275 |  |
| Long-term debt, less current portion | 669,158 |  |  | 684,730 |  |
| Deferred income taxes | 49,763 |  |  | 51,853 |  |
| Accrued post-retirement benefits | 38,198 |  |  | 31,874 |  |
| Non-current operating lease liabilities | 17,166 |  |  | — |  |
| Other long-term liabilities | 64,037 |  |  | 72,232 |  |
| Total equity | 1,496,014 |  |  | 1,478,342 |  |
| Total liabilities and equity | $ | 2,559,898 |  |  | $ | 2,614,306 |  |

[0000889331-20-000007:8k_2_02:51]
LITTELFUSE, INC.

[0000889331-20-000007:8k_2_02:52]
CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-20-000007:8k_2_02:53]
(Unaudited)

[0000889331-20-000007:8k_2_02:54]
|  |  | Three Months Ended |  | Fiscal Year Ended |
| (in thousands, except per share data) |  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Net sales |  | $ | 338,523 |  |  | $ | 402,281 |  |  | $ | 1,503,873 |  |  | $ | 1,718,468 |  |
| Cost of sales |  | 225,056 |  |  | 247,944 |  |  | 962,424 |  |  | 1,065,927 |  |
| Gross profit |  | 113,467 |  |  | 154,337 |  |  | 541,449 |  |  | 652,541 |  |
| Selling, general, and administrative expenses |  | 53,248 |  |  | 67,461 |  |  | 228,093 |  |  | 288,001 |  |
| Research and development expenses |  | 17,944 |  |  | 21,559 |  |  | 80,539 |  |  | 87,301 |  |
| Amortization of intangibles |  | 9,958 |  |  | 13,689 |  |  | 40,026 |  |  | 52,190 |  |
| Total operating expenses |  | 81,150 |  |  | 102,709 |  |  | 348,658 |  |  | 427,492 |  |
| Operating income |  | 32,317 |  |  | 51,628 |  |  | 192,791 |  |  | 225,049 |  |
| Interest expense |  | 5,432 |  |  | 5,589 |  |  | 22,266 |  |  | 22,569 |  |
| Foreign exchange (gain) loss |  | (412 | ) |  | 5,509 |  |  | 5,224 |  |  | (863 | ) |
| Other expense (income), net |  | 2,823 |  |  | 763 |  |  | (583 | ) |  | (1,599 | ) |
| Income before income taxes |  | 24,474 |  |  | 39,767 |  |  | 165,884 |  |  | 204,942 |  |
| Income taxes |  | 1,820 |  |  | 7,102 |  |  | 26,802 |  |  | 40,377 |  |
| Net income |  | $ | 22,654 |  |  | $ | 32,665 |  |  | $ | 139,082 |  |  | $ | 164,565 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 1.31 |  |  | $ | 5.66 |  |  | $ | 6.62 |  |
| Diluted |  | $ | 0.92 |  |  | $ | 1.29 |  |  | $ | 5.60 |  |  | $ | 6.52 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,366 |  |  | 25,028 |  |  | 24,576 |  |  | 24,870 |  |
| Diluted |  | 24,598 |  |  | 25,299 |  |  | 24,818 |  |  | 25,235 |  |

[0000889331-20-000007:8k_2_02:55]
LITTELFUSE, INC.

[0000889331-20-000007:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-20-000007:8k_2_02:57]
|  | Year Ended |
| (in thousands) | December 28, 2019 |  | December 29, 2018 |
|  | (Unaudited) |  |  |
| OPERATING ACTIVITIES |  |  |  |
| Net income | $ | 139,082 |  |  | $ | 164,565 |  |
| Adjustments to reconcile net income to net cash provided by operating activities, net: | 121,898 |  |  | 169,005 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Trade receivables | 28,497 |  |  | (3,539 | ) |
| Inventories | 22,094 |  |  | (33,971 | ) |
| Accounts payable | (22,574 | ) |  | 13,708 |  |
| Accrued liabilities | (54,242 | ) |  | 29,329 |  |
| Prepaid expenses and other assets | 10,573 |  |  | (7,269 | ) |
| Net cash provided by operating activities | 245,328 |  |  | 331,828 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisitions of businesses, net of cash acquired | (775 | ) |  | (318,474 | ) |
| Purchases of property, plant, and equipment | (61,895 | ) |  | (74,753 | ) |
| All other cash provided by investing activities | 6,213 |  |  | 10,979 |  |
| Net cash used in investing activities | (56,457 | ) |  | (382,248 | ) |
| FINANCING ACTIVITIES |  |  |  |
| Net proceeds from credit facility and senior notes | (10,000 | ) |  | 207,500 |  |
| Cash dividends paid | (44,689 | ) |  | (39,993 | ) |
| Purchases of common stock | (99,387 | ) |  | (63,564 | ) |
| All other cash provided by financing activities | 7,800 |  |  | 17,954 |  |
| Net cash (used in) provided by financing activities | (146,276 | ) |  | 121,897 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,189 | ) |  | (11,420 | ) |
| Increase in cash and cash equivalents | 41,406 |  |  | 60,057 |  |
| Cash and cash equivalents at beginning of year | 489,733 |  |  | 429,676 |  |
| Cash and cash equivalents at end of year | $ | 531,139 |  |  | $ | 489,733 |  |

[0000889331-20-000007:8k_2_02:58]
LITTELFUSE, INC.

[0000889331-20-000007:8k_2_02:59]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-20-000007:8k_2_02:60]
(Unaudited)

[0000889331-20-000007:8k_2_02:61]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2019 |  | 2018 |  | %Growth /(Decline) |  | 2019 |  | 2018 |  | %Growth /(Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 208,881 |  |  | $ | 264,056 |  |  | (20.9 | )% |  | $ | 961,080 |  |  | $ | 1,124,296 |  |  | (14.5 | )% |
| Automotive |  | 101,719 |  |  | 112,073 |  |  | (9.2 | )% |  | 428,533 |  |  | 479,791 |  |  | (10.7 | )% |
| Industrial |  | 27,923 |  |  | 26,152 |  |  | 6.8 | % |  | 114,260 |  |  | 114,381 |  |  | (0.1 | )% |
| Total net sales |  | $ | 338,523 |  |  | $ | 402,281 |  |  | (15.8 | )% |  | $ | 1,503,873 |  |  | $ | 1,718,468 |  |  | (12.5 | )% |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 18,361 |  |  | $ | 47,687 |  |  | (61.5 | )% |  | $ | 145,594 |  |  | $ | 241,426 |  |  | (39.7 | )% |
| Automotive |  | 11,732 |  |  | 10,017 |  |  | 17.1 | % |  | 46,719 |  |  | 54,982 |  |  | (15.0 | )% |
| Industrial |  | 6,249 |  |  | 3,212 |  |  | 94.6 | % |  | 22,407 |  |  | 17,335 |  |  | 29.3 | % |
| Other(a) |  | (4,025 | ) |  | (9,288 | ) |  | N.M. |  |  | (21,929 | ) |  | (88,694 | ) |  | N.M. |  |
| Total operating income |  | 32,317 |  |  | 51,628 |  |  | (37.4 | )% |  | 192,791 |  |  | 225,049 |  |  | (14.3 | )% |
| Operating Margin |  | 9.5 | % |  | 12.8 | % |  |  |  | 12.8 | % |  | 13.1 | % |  |  |
| Interest expense |  | 5,432 |  |  | 5,589 |  |  |  |  | 22,266 |  |  | 22,569 |  |  |  |
| Foreign exchange (gain) loss |  | (412 | ) |  | 5,509 |  |  |  |  | 5,224 |  |  | (863 | ) |  |  |
| Other expense (income), net |  | 2,823 |  |  | 763 |  |  |  |  | (583 | ) |  | (1,599 | ) |  |  |
| Income before income taxes |  | $ | 24,474 |  |  | $ | 39,767 |  |  | (38.5 | )% |  | $ | 165,884 |  |  | $ | 204,942 |  |  | (19.1 | )% |

[0000889331-20-000007:8k_2_02:62]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and other charges, and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-20-000007:8k_2_02:63]
N.M. - Not meaningful

[0000889331-20-000007:8k_2_02:64]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2019 |  | 2018 |  | %Growth /(Decline) |  | 2019 |  | 2018 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 8.8 | % |  | 18.1 | % |  | (9.3 | )% |  | 15.1 | % |  | 21.5 | % |  | (6.4 | )% |
| Automotive |  | 11.5 | % |  | 8.9 | % |  | 2.6 | % |  | 10.9 | % |  | 11.5 | % |  | (0.6 | )% |
| Industrial |  | 22.4 | % |  | 12.3 | % |  | 10.1 | % |  | 19.6 | % |  | 15.2 | % |  | 4.4 | % |

[0000889331-20-000007:8k_2_02:65]
LITTELFUSE, INC.

[0000889331-20-000007:8k_2_02:66]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-20-000007:8k_2_02:67]
(In millions of USD except per share amounts unaudited)

[0000889331-20-000007:8k_2_02:68]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-19 |  | Q4-18 |  | YTD-19 |  | YTD-18 |
| GAAP diluted EPS |  | $ | 0.92 |  |  | $ | 1.29 |  |  | $ | 5.60 |  |  | $ | 6.52 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.25 |  |  | 0.58 |  |  | 1.22 |  |  | 2.92 |  |
| Adjusted diluted EPS |  | $ | 1.17 |  |  | $ | 1.87 |  |  | $ | 6.82 |  |  | $ | 9.44 |  |

[0000889331-20-000007:8k_2_02:69]
| Non-GAAP adjustments - (income)/expense |  |  |  |  |  |  |  |  |
|  |  | Q4-19 |  | Q4-18 |  | YTD-19 |  | YTD-18 |
| Acquisition related and integration costs (a) |  | $ | 2.0 |  |  | $ | 3.2 |  |  | $ | 8.9 |  |  | $ | 20.2 |  |
| Restructuring, impairment and other charges (b) |  | 2.0 |  |  | 2.4 |  |  | 13.0 |  |  | 12.6 |  |
| Amortization backlog - IXYS (c) |  | — |  |  | 3.7 |  |  | — |  |  | 12.4 |  |
| Change in control - IXYS (d) |  | — |  |  | — |  |  | — |  |  | 2.1 |  |
| Acquisition related stock-based compensation charge (e) |  | — |  |  | — |  |  | — |  |  | 4.5 |  |
| Purchase accounting inventory adjustments (f) |  | — |  |  | — |  |  | — |  |  | 36.9 |  |
| Non-GAAP adjustments to operating income |  | 4.0 |  |  | 9.3 |  |  | 21.9 |  |  | 88.7 |  |
| Other expense, net (g) |  | 4.2 |  |  | 0.9 |  |  | 10.0 |  |  | 0.9 |  |
| Non-operating foreign exchange (gain) loss |  | (0.4 | ) |  | 5.5 |  |  | 5.2 |  |  | (0.9 | ) |
| Non-GAAP adjustments to income before income taxes |  | 7.8 |  |  | 15.7 |  |  | 37.1 |  |  | 88.7 |  |
| Income taxes (h) |  | 2.0 |  |  | 1.0 |  |  | 7.1 |  |  | 15.1 |  |
| Non-GAAP adjustments to net income |  | $ | 5.8 |  |  | $ | 14.7 |  |  | $ | 30.0 |  |  | $ | 73.6 |  |
| Total EPS impact |  | $ | 0.25 |  |  | $ | 0.58 |  |  | $ | 1.22 |  |  | $ | 2.92 |  |

[0000889331-20-000007:8k_2_02:70]
| Adjusted operating margin /Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-19 |  | Q4-18 |  | YTD-19 |  | YTD-18 |
| Net sales |  | $ | 338.5 |  |  | $ | 402.3 |  |  | $ | 1,503.9 |  |  | $ | 1,718.5 |  |
| GAAP operating income |  | $ | 32.3 |  |  | $ | 51.6 |  |  | $ | 192.8 |  |  | $ | 225.0 |  |
| Add back non-GAAP adjustments |  | 4.0 |  |  | 9.3 |  |  | 21.9 |  |  | 88.7 |  |
| Adjusted operating income |  | $ | 36.3 |  |  | $ | 60.9 |  |  | $ | 214.7 |  |  | $ | 313.7 |  |
| Adjusted operating margin |  | 10.7 | % |  | 15.1 | % |  | 14.3 | % |  | 18.3 | % |
| Add back amortization |  | 9.9 |  |  | 10.0 |  |  | 40.0 |  |  | 39.8 |  |
| Add back depreciation |  | 13.5 |  |  | 13.4 |  |  | 52.5 |  |  | 51.0 |  |
| Adjusted EBITDA |  | $ | 59.7 |  |  | $ | 84.3 |  |  | $ | 307.2 |  |  | $ | 404.5 |  |
| Adjusted EBITDA margin |  | 17.6 | % |  | 21.0 | % |  | 20.4 | % |  | 23.5 | % |

[0000889331-20-000007:8k_2_02:71]
| Net sales reconciliation |  | Q4-19 vs. Q4-18 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | (21 | )% |  | (9 | )% |  | 7 | % |  | (16 | )% |
| Less: |  |  |  |  |  |  |  |  |
| Divestitures |  | (1 | )% |  | — |  |  | — | % |  | (1 | )% |
| FX impact |  | (1 | )% |  | (1 | )% |  | — | % |  | (1 | )% |
| Organic net sales growth |  | (19 | )% |  | (8 | )% |  | 7 | % |  | (14 | )% |

[0000889331-20-000007:8k_2_02:72]
| Net sales reconciliation |  | YTD-19 vs. YTD-18 |
|  |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net sales growth |  | (15 | )% |  | (11 | )% |  | — | % |  | (13 | )% |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 1 | % |  | — |  |  | — |  |  | 1 | % |
| Divestitures |  | (1 | )% |  | — |  |  | (4 | )% |  | (1 | )% |
| FX impact |  | (1 | )% |  | (3 | )% |  | — | % |  | (2 | )% |
| Organic net sales growth |  | (14 | )% |  | (8 | )% |  | 4 | % |  | (11 | )% |

[0000889331-20-000007:8k_2_02:73]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-19 |  | Q4-18 |  | YTD-19 |  | YTD-18 |
| Income taxes |  | $ | 1.8 |  |  | $ | 7.1 |  |  | $ | 26.8 |  |  | $ | 40.4 |  |
| Effective rate |  | 7.4 | % |  | 17.9 | % |  | 16.2 | % |  | 19.7 | % |
| Non-GAAP adjustments - income taxes |  | 2.0 |  |  | 1.0 |  |  | 7.1 |  |  | 15.1 |  |
| Adjusted income taxes |  | $ | 3.8 |  |  | $ | 8.1 |  |  | $ | 33.9 |  |  | $ | 55.5 |  |
| Adjusted effective rate |  | 11.9 | % |  | 14.6 | % |  | 16.7 | % |  | 18.9 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-19 |  | Q4-18 |  | YTD-19 |  | YTD-18 |
| Net cash provided by operating activities |  | $ | 84.4 |  |  | $ | 79.7 |  |  | $ | 245.3 |  |  | $ | 331.8 |  |
| Less: Purchases of property, plant and equipment |  | (23.5 | ) |  | (18.8 | ) |  | (61.9 | ) |  | (74.8 | ) |
| Free cash flow |  | $ | 60.9 |  |  | $ | 60.9 |  |  | $ | 183.4 |  |  | $ | 257.0 |  |

[0000889331-20-000007:8k_2_02:74]
|  |  | Q1-19 |  | Q2-19 |  | Q3-19 |  | Q4-19 |  | For the Twelve Months Ended December 28, 2019 |
| Adjusted EBITDA |  | $ | 89.1 |  |  | $ | 82.5 |  |  | $ | 76.0 |  |  | $ | 59.7 |  |  | $ | 307.2 |  |
|  |  |  |  |  |  |  |  |  |  | December 28, 2019 |
| Current portion of long-term debt |  |  |  |  |  |  |  |  |  | $ | 10.0 |  |
| Long-term debt, less current portion |  |  |  |  |  |  |  |  |  | 669.2 |  |
| Total debt |  |  |  |  |  |  |  |  |  | $ | 679.2 |  |
| Less: Cash and cash equivalents |  |  |  |  |  |  |  |  |  | 531.1 |  |
| Net debt |  |  |  |  |  |  |  |  |  | $ | 148.1 |  |
| Adjusted Gross Leverage (defined as total debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 2.2 |
| Adjusted Net Leverage (defined as net debt divided by adjusted EBITDA) |  |  |  |  |  |  |  |  |  | 0.5 |

[0000889331-20-000007:8k_2_02:75]
Note: Totals will not always foot due to rounding.

[0000889331-20-000007:8k_2_02:76]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-20-000007:8k_2_02:77]
(b) $1.8 million and $0.2 million and $2.3 million and $0.1 million reflected in SG&A and cost of sales for three months ended December 28, 2019 and December 29, 2018, respectively. $8.2 million and $4.8 million and $11.7 million and $0.9 million reflected in SG&A and cost of sales, respectively for the twelve months ended December 28, 2019 and December 29, 2018.

[0000889331-20-000007:8k_2_02:78]
(c) reflected in amortization of intangibles.

[0000889331-20-000007:8k_2_02:79]
(d) reflected in SG&A.

[0000889331-20-000007:8k_2_02:80]
(e) $2.4 million, $1.6 million and $0.5 million reflected in SG&A, research and development expenses and cost of sales, respectively.

[0000889331-20-000007:8k_2_02:81]
(f) reflected in cost of sales.

[0000889331-20-000007:8k_2_02:82]
(g) 2019 quarter-to-date amount included $4.2 million impairment charges related to certain other investments. 2019 year-to-date primarily consisted of $7.3 million impairment charges related to certain other investments and $2.6 million loss on the disposal of a business. The three and twelve months ended December 29, 2018 included $2.2 million gain on the sale of a building, $1.1 million loss on the sale of a business, $1.0 million of charges associated with the remediation of certain coal mines and $1.0 million contingent consideration expense for the acquisition of Monolith.

[0000889331-20-000007:8k_2_02:83]
(h) reflected the tax impact associated with the non-GAAP adjustments. The three and twelve months ended December 28, 2019 reflected $3.3 million of tax benefits for previously unrecognized tax benefits in respect of which the statute of limitations has expired.The three and twelve months ended December 29, 2018 reflected $3.2 million tax expense related to the finalization of 2017 provisional reasonable estimate in connection with the legislation commonly referred to as the Tax Cuts and Job Act (the "Tax Act"), partially offset by a $1.5 million benefit for previously unrecognized tax benefits in respect of which the statute of limitations has expired.
