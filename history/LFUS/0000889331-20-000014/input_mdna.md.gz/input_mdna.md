# LFUS MD&A — 0000889331-20-000014


## mdna

[0000889331-20-000014:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0000889331-20-000014:mdna:2]
The following discussion of the Company's financial condition and results of operations should be read together with the Consolidated Financial Statements and notes to those statements included in Item 8 of Part II of this Annual Report on Form 10-K.

[0000889331-20-000014:mdna:3]
BUSINESS

[0000889331-20-000014:mdna:4]
For a description of the Company’s business, segments and product offerings, see Item 1, Business.

[0000889331-20-000014:mdna:5]
2019 EXECUTIVE OVERVIEW

[0000889331-20-000014:mdna:6]
Net sales decreased by $214.6 million, or 12.5%, in 2019 compared to 2018. The decrease was primarily driven by lower volume across the Electronics and Automotive segments and $25.0 million or 1.5% of unfavorable changes in foreign exchange rates, partially offset by higher volume in the Industrial segment. The Company recognized net income of $139.1 million, or $5.60 per diluted share, in 2019 compared to net income of $164.6 million, or $6.52 per diluted share in 2018. The decrease in net income reflects lower operating income in the Electronics and Automotive segments, partially offset by lower non-segment charges compared to prior year primarily due to the IXYS acquisition.

[0000889331-20-000014:mdna:7]
The Company continues to take actions to improve its cost structure and drive the synergies from the integration of IXYS. The Company expects to realize cost savings from the restructuring activities taken during 2019 including the reorganization of certain

[0000889331-20-000014:mdna:8]
manufacturing, selling and administrative functions across all segments and the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment.

[0000889331-20-000014:mdna:9]
Net cash provided by operating activities was $245.3 million for the year ended December 28, 2019 as compared to $331.8 million for the year ended December 29, 2018. The decrease in net cash provided by operating activities was primarily driven by lower earnings and higher working capital levels primarily due to the timing of supplier payments, payroll year-end cut off and higher annual incentive compensation payments in 2019.

[0000889331-20-000014:mdna:10]
During the fiscal year 2019, the Company repurchased 579,916 shares of its common stock totaling $95.0 million. During the fiscal year 2018, the Company repurchased 391,972 shares of its common stock totaling $67.9 million.  From September 30, 2018 until December 28, 2019, the Company repurchased 971,888 shares of its common stock at an average price of $167.65 totaling $162.9 million.

[0000889331-20-000014:mdna:11]
OUTLOOK

[0000889331-20-000014:mdna:12]
Vision and Strategy

[0000889331-20-000014:mdna:13]
The Company works with its customers to design and develop technologies that help them build safer, more reliable and more efficient products for a safer, greener and increasingly connected world in virtually every market that uses electrical energy; for example, automotive and commercial vehicles, industrial applications like renewable energy and storage, motor drives and power conversion, data and telecommunications, medical devices, consumer electronics and appliances. Built upon that framework, the Company’s strategy is centered on growing its circuit protection, power control and sensor platforms.

[0000889331-20-000014:mdna:14]
The Company’s strategic plan is focused on increasing shareholder value by driving profitable sales growth, earnings per share growth, strong cash flow generation, and deploying capital consistent with its long-term capital allocation priorities. The Company pursues the following major strategic initiatives, which are summarized below, along with more specific areas of focus.

[0000889331-20-000014:mdna:15]
| Strategic Objective |  | 2020 and Future Priorities |
| Double digit sales growth |  | ● | Grow through increased product content with existing customers and increased market share |
|  |  | ● | Expand portfolio into new and underpenetrated geographies and end markets |
|  |  | ● | Increase innovation capabilities and investments |
|  |  | ● | Expand presence in products and applications that are converging across business segments |
|  |  | ● | Targeted mergers and acquisitions |
| EPS growth |  | ● | Focus on higher profitability growth opportunities |
|  |  | ● | Improve operating margins through operational excellence |
|  |  | ● | Disciplined approach to balancing costs with long-term strategic investments |
| Cash flow and liquidity |  | ● | Disciplined management of working capital |
|  |  | ● | Deployment of capital consistent with capital allocation priorities |
|  |  | ● | Mergers and acquisitions that align with strategy and financial metrics |
|  |  | ● | Grow dividend in line with earnings |
|  |  | ● | Opportunistic share repurchases |

[0000889331-20-000014:mdna:16]
The Company’s strategy is to generate profitable sales growth. In order to accomplish this, the Company is focusing on accelerating organic growth by increasing its content and share gains, enhancing technology efforts to drive innovation, capitalizing on cross segment opportunities, and gaining traction in underpenetrated geographies and markets. The Company will continue to make targeted strategic acquisitions that align to its strategy and financial metrics to support new business, products, markets, and technologies while leveraging existing customers and targeting new customers.

[0000889331-20-000014:mdna:17]
Management believes that profitable growth through a combination of organic growth and strategic acquisitions is critical to the Company’s competitiveness, while enhancing value the Company delivers to its customers and other stakeholders. In addition,

[0000889331-20-000014:mdna:18]
the Company continues to implement initiatives across all platforms to enhance productivity while managing its cost structure to align with business conditions, including integration of operations and streamlining administrative and support activities to drive improved operating margins.

[0000889331-20-000014:mdna:19]
The Company seeks to deploy its capital consistent with capital allocation priorities. Priorities for capital deployment, over time, include investments to drive increased organic growth, targeted acquisitions that align to the Company’s strategic and financial metrics and returning capital to shareholders through dividends and opportunistic share repurchases.

[0000889331-20-000014:mdna:20]
The Company uses several key indicators to gauge progress toward achieving these objectives. These indicators include organic sales growth, operating margins, cash flow from operations and capital expenditures. Through cycles, the Company targets double-digit long-term (2017-2021) sales growth, split between 5-7% average annual accelerated organic sales growth and 5-7% average annual accelerated growth from strategic acquisitions, while targeting operating margins between 17% and 19% and double-digit earnings per share growth. Cash flow from operations less capital expenditures is targeted to approximate or exceed net income but in any given year can be significantly impacted by the timing of non-recurring or infrequent expenditures.

[0000889331-20-000014:mdna:21]
Significant Accounting Policies and Critical Estimates

[0000889331-20-000014:mdna:22]
Critical Accounting Policies and Estimates

[0000889331-20-000014:mdna:23]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The Company’s most critical accounting policies are those that are most important to the portrayal of its financial condition and results of operations, and which require the Company to make its most difficult and subjective judgments, often as a result of the need to make estimates of matters that are inherently uncertain. The Company has identified the following as its most critical accounting policies and judgments. Although management believes that its estimates and assumptions are reasonable, they are based upon information available when they are made, and therefore, actual results may differ from these estimates under different assumptions or conditions. The Company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0000889331-20-000014:mdna:24]
Revenue Recognition

[0000889331-20-000014:mdna:25]
On December 31, 2017, the Company adopted new guidance on revenue from contracts with customers using the modified retrospective method. The adoption did not have a significant impact on the Company’s consolidated financial statements.

[0000889331-20-000014:mdna:26]
Revenue Disaggregation

[0000889331-20-000014:mdna:27]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 28, 2019 and December 29, 2018:

[0000889331-20-000014:mdna:28]
|  |  | Fiscal Year Ended December 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 563,572 |  |  | $ | — |  |  | $ | — |  |  | $ | 563,572 |  |
| Electronics – Passive Products and Sensors |  | 397,508 |  |  | — |  |  | — |  |  | 397,508 |  |
| Passenger Car Products |  | — |  |  | 218,560 |  |  | — |  |  | 218,560 |  |
| Commercial Vehicle Products |  | — |  |  | 111,972 |  |  | — |  |  | 111,972 |  |
| Automotive Sensors |  | — |  |  | 98,001 |  |  | — |  |  | 98,001 |  |
| Industrial Products |  | — |  |  | — |  |  | 114,260 |  |  | 114,260 |  |
| Total |  | $ | 961,080 |  |  | $ | 428,533 |  |  | $ | 114,260 |  |  | $ | 1,503,873 |  |

[0000889331-20-000014:mdna:29]
|  |  | Fiscal Year Ended December 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 648,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 648,967 |  |
| Electronics – Passive Products and Sensors |  | 475,329 |  |  | — |  |  | — |  |  | 475,329 |  |
| Passenger Car Products |  | — |  |  | 240,501 |  |  | — |  |  | 240,501 |  |
| Commercial Vehicle Products |  | — |  |  | 121,562 |  |  | — |  |  | 121,562 |  |
| Automotive Sensors |  | — |  |  | 117,728 |  |  | — |  |  | 117,728 |  |
| Industrial Products |  | — |  |  | — |  |  | 114,381 |  |  | 114,381 |  |
| Total |  | $ | 1,124,296 |  |  | $ | 479,791 |  |  | $ | 114,381 |  |  | $ | 1,718,468 |  |

[0000889331-20-000014:mdna:30]
See Note 16, Segment Information, for net sales by segment and countries.

[0000889331-20-000014:mdna:31]
Revenue Recognition

[0000889331-20-000014:mdna:32]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-20-000014:mdna:33]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-20-000014:mdna:34]
Revenue and Billing

[0000889331-20-000014:mdna:35]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue. This is similar to the Company’s prior practice and therefore the effect of the new guidance is immaterial.

[0000889331-20-000014:mdna:36]
Ship and Debit Program

[0000889331-20-000014:mdna:37]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-20-000014:mdna:38]
Return to Stock

[0000889331-20-000014:mdna:39]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-20-000014:mdna:40]
Volume Rebates

[0000889331-20-000014:mdna:41]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-20-000014:mdna:42]
Allowance for Doubtful Accounts:

[0000889331-20-000014:mdna:43]
The Company evaluates the collectability of its trade receivables based on a combination of factors. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a specific customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also records allowances for all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and past experience. Historically, the allowance for doubtful accounts has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-20-000014:mdna:44]
Inventory

[0000889331-20-000014:mdna:45]
The Company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life, and quality issues. Based on the analysis, the Company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable values.

[0000889331-20-000014:mdna:46]
Goodwill

[0000889331-20-000014:mdna:47]
The Company’s methodology for allocating the purchase price of acquisitions is based on established valuation techniques that reflect the consideration of a number of factors, including valuations performed by third-party appraisers when appropriate. Goodwill is measured as the excess of the cost of an acquired entity over the fair value assigned to identifiable assets acquired and liabilities assumed. Based on its current organization structure, the Company has seven reporting units for which cash flows are determinable and to which goodwill has been allocated.

[0000889331-20-000014:mdna:48]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value.

[0000889331-20-000014:mdna:49]
Quantitative Assessment for Impairment

[0000889331-20-000014:mdna:50]
For the seven reporting units with goodwill, the Company compares the estimated fair value of each reporting unit to its carrying value. If the carrying value of a reporting unit exceeded the estimated fair value, the difference between the estimated fair value and carrying value is recorded as the amount of the goodwill impairment charge. The results of the goodwill impairment test as of September 30, 2019 indicated that the estimated fair values for each of the seven reporting units exceeded their respective carrying values. Accordingly, there were no goodwill impairment charges recorded as part of the Company’s 2019 annual goodwill impairment test.

[0000889331-20-000014:mdna:51]
As part of its impairment test for these reporting units, the Company engaged a third-party appraisal firm to assist in the Company’s determination of the estimated fair values. This determination included estimating the fair value of each reporting unit using both

[0000889331-20-000014:mdna:52]
the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping. The Company weighted both the income and market approach equally to estimate the concluded fair value of each reporting unit. The determination of fair value requires the Company to make significant estimates and assumptions, which primarily include, but are not limited to: the selection of appropriate peer group companies; control premiums appropriate for acquisitions in which the Company competes; the discount rate; terminal growth rates; and forecasts of revenue, operating income, depreciation and amortization and capital expenditures.

[0000889331-20-000014:mdna:53]
Goodwill Impairment Assumptions

[0000889331-20-000014:mdna:54]
Although the Company believes its estimates of fair value are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results or other underlying assumptions could have a significant impact on the fair value of the reporting units. Future declines in the overall market value of the Company’s equity may also result in a conclusion that the fair value of one or more reporting units has declined below its carrying value.

[0000889331-20-000014:mdna:55]
One measure of the sensitivity of the amount of goodwill impairment charges to key assumptions is the amount by which each reporting unit “passed” (fair value exceeds the carrying value) the goodwill impairment test. All seven of the reporting units passed the goodwill impairment test, with fair values that exceeded the carrying values by between 40% and 268% of their respective estimated fair values. As of the most recent annual test conducted on September 30, 2019, the Company noted that the excess of fair value over the carrying value, was 217%, 42%, 137%, 213%, 40%, 89%, and 268% for its reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, Automotive Sensors, Relays, and Power Fuse, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test.

[0000889331-20-000014:mdna:56]
Generally, changes in estimates of expected future cash flows would have a similar effect on the estimated fair value of the reporting unit. That is, a 1.0% decrease in estimated annual future cash flows would decrease the estimated fair value of the reporting unit by approximately 1.0%. The estimated long-term net sales growth rate can have a significant impact on the estimated future cash flows, and therefore, the fair value of each reporting unit. A 1.0% decrease in the long-term net sales growth rate would have resulted in no reporting units failing the goodwill impairment test. Of the other key assumptions that impact the estimated fair values, most reporting units have the greatest sensitivity to changes in the estimated discount rate. The estimated discount rate was 9.7% for the Electronics-Semiconductor, Passenger Car Products and Commercial Vehicle Products reporting units, and 10.7% for the Electronics-Passive Products and Sensor reporting unit and 11.7% for the Automotive Sensors, Power Fuse and Relays reporting units. A 1.0% increase in the estimated discount rates would have resulted in no reporting units failing the annual goodwill impairment test. The Company believes that its estimates of future cash flows and discount rates are reasonable, but future changes in the underlying assumptions could differ due to the inherent uncertainty in making such estimates. Additionally, price deterioration or lower volume could have a significant impact on the fair values of the reporting units.

[0000889331-20-000014:mdna:57]
Long-Lived Assets

[0000889331-20-000014:mdna:58]
The Company evaluates the recoverability of other long-lived assets, including property, plant and equipment and certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset group may not be recoverable. Factors which could trigger an impairment review include significant underperformance relative to historical or projected operating results, significant changes in the manner of use of the assets or the strategy for the overall business, a significant decrease in the market value of the assets or significant negative industry or economic trends. When the Company determines that the carrying value of long-lived assets may not be recoverable based upon the existence of one or more of the indicators, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition. If the carrying value of an asset exceeds its estimated future undiscounted cash flows, an impairment loss is recorded for the excess of the asset’s carrying value over its fair value. During the year-ended December 28, 2019, the Company recognized non-cash impairment charges of $0.3 million for certain machinery and equipment related to the closure of a European manufacturing facility in the automotive sensors business within the Automotive segment. During the year ended December 29, 2018, the Company recognized non-cash impairment charges of $1.6 million and $0.5 million related to a building for sale and the Custom Products reporting unit trade name, respectively, associated with the exit of the Custom business within the Industrial Segment. During the year ended December 30, 2017, the Company recognized a loss of $2.9 million related to certain machinery and equipment in the Electronics and Automotive segments due to changes in the expected use of these certain assets.

[0000889331-20-000014:mdna:59]
Environmental Liabilities

[0000889331-20-000014:mdna:60]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The Company evaluates its reserve for coal mine remediation annually utilizing a third-party expert.

[0000889331-20-000014:mdna:61]
Pension and Supplemental Executive Retirement Plan

[0000889331-20-000014:mdna:62]
The Company records annual income and expense amounts relating to its pension and postretirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive income (loss). The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors. The Company maintains several pension plans in international locations. The expected returns on plan assets and discount rates are determined based on each plan’s investment approach, local interest rates and plan participant profiles. The weighted-average

[0000889331-20-000014:mdna:63]
discount rates for the Company’s defined benefit plans primarily in Europe and the Asia-Pacific regions at December 28, 2019 and December 29, 2018 were 2.3% and 3.1%, respectively.

[0000889331-20-000014:mdna:64]
A 50 basis point change in the discount rates at December 28, 2019 would have the following effect on the projected benefit obligation:

[0000889331-20-000014:mdna:65]
| (in millions) | 0.5%Increase |  | 0.5%Decrease |
| Projected benefit obligation | $ | (8.9 | ) |  | $ | 9.7 |  |

[0000889331-20-000014:mdna:66]
Equity-based Compensation

[0000889331-20-000014:mdna:67]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments in the foreseeable future. The fair value of restricted share units is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-20-000014:mdna:68]
Total equity-based compensation expense for all equity compensation plans was $19.9 million, $28.2 million, and $17.3 million in 2019, 2018, and 2017, respectively. Further information regarding this expense is provided in Note 12, Stock-Based Compensation, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-20-000014:mdna:69]
Income Taxes

[0000889331-20-000014:mdna:70]
The Company accounts for income taxes using the liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-20-000014:mdna:71]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws (such as the Tax Act), or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-20-000014:mdna:72]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-20-000014:mdna:73]
On December 22, 2017, the U.S. enacted legislation commonly referred to as the Tax Cuts and Jobs Act (the "Tax Act"). Among other things, the Tax Act reduces the U.S. corporate federal income tax rate from 35% to 21%, adds base broadening provisions which limit deductions and address excessive international tax planning, imposes a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and enables repatriation of earnings of non-U.S. subsidiaries free of U.S. federal income tax. Other than the Toll Charge (which, except for the IXYS impact, was applicable to the Company for 2017), the provisions are generally applicable to the Company in 2018 and beyond.

[0000889331-20-000014:mdna:74]
In accordance with the guidance provided in SEC Staff Accounting Bulletin (“SAB”) No. 118, in the fourth quarter of 2017 the Company recorded a charge of $47.0 million as a provisional reasonable estimate of the impact of the Tax Act, including $49.0 million for the Toll Charge net of $2.0 million for other net tax benefits. In the fourth quarter of 2018, within the measurement period outlined in SAB No. 118, the Company finalized its estimates of the impact of the Tax Act as of December 29, 2018 and recorded a charge of $3.2 million, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. In addition, the Company recorded $7.0 million for the Toll Charge associated with IXYS as part of the IXYS acquisition purchase price allocation. This was reflected in the opening balance sheet as an increase to goodwill and other long-term liabilities.

[0000889331-20-000014:mdna:75]
One of the base broadening provisions of the Tax Act is the global intangible low-taxed income provisions ("GILTI"). In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 28, 2019 and December 29, 2018, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-20-000014:mdna:76]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-20-000014:mdna:77]
Off-Balance Sheet Arrangements

[0000889331-20-000014:mdna:78]
The Company does not have off-balance sheet arrangements as defined under SEC rules. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-20-000014:mdna:79]
In the financial review that follows, the Company discusses its consolidated results of operations, financial position, cash flows and certain other information. This discussion should be read in conjunction with the Company’s Consolidated Financial Statements and related notes.

[0000889331-20-000014:mdna:80]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 28, 2019 AS COMPARED TO THE YEAR ENDED DECEMBER 29, 2018

[0000889331-20-000014:mdna:81]
The fiscal year 2019 included approximately $21.9 million of non-segment charges, of which $8.9 million of charges are acquisition- related and integration charges primarily related to the IXYS acquisition and other contemplated acquisitions, and $13.0 million of restructuring charges primarily related to employee termination costs. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-20-000014:mdna:82]
The fiscal year 2018 included approximately $88.7 million of non-segment charges, of which $82.9 million of charges are primarily related to the IXYS acquisition as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report. These charges include $36.9 million of purchase accounting inventory step-up charges, $18.7 million in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $12.4 million in backlog amortization costs, $8.3 million of employee termination costs and other restructuring charges, $4.5 million of stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods, and $2.1 million change in control expense related to IXYS. In addition, there were $5.8 million of employee termination costs, impairment and other restructuring charges and acquisition-related expenses for other contemplated acquisitions, which included charges associated with the exit of the Custom business in the second quarter within the Industrial segment.

[0000889331-20-000014:mdna:83]
Fiscal year 2019 also included approximately $5.2 million in foreign currency exchange losses primarily attributable to changes in the value of the euro, Chinese renminbi, and Japanese Yen against the U.S. dollar, while fiscal year 2018 also included approximately $0.9 million in foreign currency exchange gains primarily attributable to changes in the value of the euro, Mexico peso, Philippine peso and Chinese renminbi against the U.S. dollar.

[0000889331-20-000014:mdna:84]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2019 |  | 2018 |  | Change |  | % Change |
| Net sales | $ | 1,503,873 |  |  | $ | 1,718,468 |  |  | $ | (214,595 | ) |  | (12.5 | )% |
| Gross profit | 541,449 |  |  | 652,541 |  |  | (111,092 | ) |  | (17.0 | )% |
| Operating expenses | 348,658 |  |  | 427,492 |  |  | (78,834 | ) |  | (18.4 | )% |
| Operating income | 192,791 |  |  | 225,049 |  |  | (32,258 | ) |  | (14.3 | )% |
| Other income, net | (583 | ) |  | (1,599 | ) |  | 1,016 |  |  | (63.5 | )% |
| Income before income taxes | 165,884 |  |  | 204,942 |  |  | (39,058 | ) |  | (19.1 | )% |
| Income taxes | 26,802 |  |  | 40,377 |  |  | (13,575 | ) |  | (33.6 | )% |
| Net income | 139,082 |  |  | 164,565 |  |  | (25,483 | ) |  | (15.5 | )% |

[0000889331-20-000014:mdna:85]
Net Sales

[0000889331-20-000014:mdna:86]
Net sales for 2019 of $1,503.9 million decreased $214.6 million, or 12.5%, compared to the prior year primarily due to lower volume across the Electronics and Automotive segments driven by electronics distribution partners and end customers reducing excess inventories, a decline in global auto production and a decline in global end market demand, and $25.0 million or 1.5% of unfavorable changes in foreign exchange rates.

[0000889331-20-000014:mdna:87]
Gross Profit

[0000889331-20-000014:mdna:88]
Gross profit was $541.4 million, or 36.0% of net sales, in 2019, compared to $652.5 million, or 38.0% of net sales, in 2018. The decrease in gross profit is primarily due to lower volumes across the Electronics and Automotive segments driven by electronics distribution partners and end customers reducing excess inventories, a decline in global auto production and a decline in global

[0000889331-20-000014:mdna:89]
end market demand, unfavorable price and product mix, and costs related to restructuring activities taken during 2019. In 2018 the IXYS purchase accounting inventory step-up charge of $36.9 million negatively impacted the 2018 gross margin by 2.1%.

[0000889331-20-000014:mdna:90]
Operating Expenses

[0000889331-20-000014:mdna:91]
Total operating expenses were $348.7 million, or 23.2% of net sales, for 2019 compared to $427.5 million, or 24.9% of net sales, for 2018. The decrease in operating expenses of $78.8 million was primarily due to lower annual incentive compensation expenses, reduced backlog amortization expense of $12.4 million, lower acquisition-related and integration costs of $11.3 million, global cost saving initiatives, and $4.5 million stock compensation expense and $2.1 million of change in control expense related to the 2018 IXYS acquisition.

[0000889331-20-000014:mdna:92]
Operating Income

[0000889331-20-000014:mdna:93]
Operating income for 2019 was $192.8 million, a decrease of $32.3 million or 14.3% compared to $225.0 million for 2018. The decrease in operating income is primarily due to lower gross profit across the Electronics and Automotive segments, partially offset by lower operating expenses noted above and the $36.9 million purchase accounting inventory step-up charges in 2018. Operating margins decreased from 13.1% in 2018 to 12.8% in 2019 primarily driven by lower gross profit margin discussed above.

[0000889331-20-000014:mdna:94]
Income Before Income Taxes

[0000889331-20-000014:mdna:95]
Income before income taxes for 2019 was $165.9 million, or 11.0% of net sales compared to $204.9 million, or 11.9% of net sales, for 2018. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was unfavorably impacted by foreign exchange losses of $5.2 million during the fiscal year ended December 28, 2019 compared to foreign exchange gains of $0.9 million during the fiscal year ended December 29, 2018, and decreases of $1.0 million in other income primarily due to the impairment charges of $7.3 million for certain other investments and a $2.6 million loss on the disposal of a business within the Electronics segment during the fiscal year 2019,  partially offset by unrealized investment gains associated with our equity investments and higher interest income.

[0000889331-20-000014:mdna:96]
Income Taxes

[0000889331-20-000014:mdna:97]
Income tax expense for 2019 was $26.8 million, or an effective tax rate of 16.2% compared to income tax expense of $40.4 million, or an effective tax rate of 19.7%, for 2018. The 2019 income tax expense includes a benefit of $3.3 million from the recognition of previously unrecognized tax benefits (and the reversal of the related accrued interest) due to a lapse in the statute of limitations.

[0000889331-20-000014:mdna:98]
The 2018 income tax expense includes a charge of $3.2 million associated with finalizing the 2017 provisional reasonable estimate, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. Additionally, our tax rates are lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by the impact of taxes on unremitted earnings, the GILTI tax provisions and non-U.S. losses and expenses with no tax benefit.

[0000889331-20-000014:mdna:99]
Segment Information

[0000889331-20-000014:mdna:100]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-20-000014:mdna:101]
The following table is a summary of the Company’s net sales by segment:

[0000889331-20-000014:mdna:102]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | % Change |
| Electronics | $ | 961.1 |  |  | $ | 1,124.3 |  |  | $ | (163.2 | ) |  | (14.5 | )% |
| Automotive | 428.5 |  |  | 479.8 |  |  | (51.3 | ) |  | (10.7 | )% |
| Industrial | 114.3 |  |  | 114.4 |  |  | (0.1 | ) |  | (0.1 | )% |
| Total | $ | 1,503.9 |  |  | $ | 1,718.5 |  |  | $ | (214.6 | ) |  | (12.5 | )% |

[0000889331-20-000014:mdna:103]
Electronics Segment

[0000889331-20-000014:mdna:104]
The Electronics segment net sales decreased $163.2 million, or 14.5%, in 2019 compared to 2018 primarily due to lower volume across all businesses due to electronics distribution partners and end customer reducing excess  inventories, a decline in global end market demand, and unfavorable changes in foreign exchange rates of $13.5 million.

[0000889331-20-000014:mdna:105]
Automotive Segment

[0000889331-20-000014:mdna:106]
Net sales in the Automotive segment decreased $51.3 million, or 10.7%, in 2019 compared to 2018 due to lower volume across all businesses primarily from a decline in global auto production, declines in commercial vehicle end market demand, and unfavorable changes in foreign exchange rates of $10.9 million.

[0000889331-20-000014:mdna:107]
Industrial Segment

[0000889331-20-000014:mdna:108]
The Industrial segment net sales decreased slightly by $0.1 million, or 0.1%, in 2019 compared to 2018 primarily due to the exit of the Custom business during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.6 million, partially offset by higher volume across all businesses.

[0000889331-20-000014:mdna:109]
Geographic Net Sales Information

[0000889331-20-000014:mdna:110]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-20-000014:mdna:111]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | % Change |
| Asia-Pacific | $ | 656.8 |  |  | $ | 753.3 |  |  | $ | (96.5 | ) |  | (12.8 | )% |
| Americas | 508.4 |  |  | 578.6 |  |  | (70.2 | ) |  | (12.1 | )% |
| Europe | 338.7 |  |  | 386.6 |  |  | (47.9 | ) |  | (12.4 | )% |
| Total | $ | 1,503.9 |  |  | $ | 1,718.5 |  |  | $ | (214.6 | ) |  | (12.5 | )% |

[0000889331-20-000014:mdna:112]
Asia-Pacific

[0000889331-20-000014:mdna:113]
Asia-Pacific net sales decreased $96.5 million, or 12.8%, in 2019 compared to 2018. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment and the Automotive segment, and unfavorable changes in foreign exchange rates of $6.8 million.

[0000889331-20-000014:mdna:114]
Americas

[0000889331-20-000014:mdna:115]
Net sales in the Americas decreased $70.2 million, or 12.1%, in 2019 compared to 2018 primarily due to lower volume  across all businesses within the Electronics segment and the Automotive segment, the exit of the Custom business within Industrial segment during the second quarter of 2018 and unfavorable changes in foreign exchange rates of $0.8 million, partially offset by higher volume in the power fuse and relay business within Industrial segments.

[0000889331-20-000014:mdna:116]
Europe

[0000889331-20-000014:mdna:117]
European net sales decreased $47.8 million, or 12.4%, in 2019 compared to 2018. The decrease in net sales was primarily due to lower volume across all businesses within the Electronics segment and the Automotive segment, and unfavorable changes in foreign exchange rates of $17.4 million, partially offset by higher volume in the power fuse business within the Industrial segment.

[0000889331-20-000014:mdna:118]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 29, 2018 AS COMPARED TO THE YEAR ENDED DECEMBER 30, 2017

[0000889331-20-000014:mdna:119]
The following table summarizes the Company’s consolidated results of operations for periods presented. The fiscal year 2018 includes approximately $88.7 million of non-segment charges, of which $82.9 million of charges are primarily related to the IXYS acquisition as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report. These charges include $36.9 million of purchase accounting inventory step-up charges, $18.7 million in acquisition-related and integration costs primarily related to legal, accounting and other expenses, $12.4 million in backlog amortization costs, $8.3 million of employee termination costs and other restructuring charges, $4.5 million of stock compensation expense recognized immediately upon close for converted IXYS options related to prior service periods, and $2.1 million change in control expense related to IXYS. In addition, there were $5.8 million of employee termination costs, impairment and other restructuring charges and acquisition-related expenses for other contemplated acquisitions and included charges associated with the exit of the Custom business in the second quarter within the Industrial segment.

[0000889331-20-000014:mdna:120]
The fiscal year 2017 includes approximately $10.3 million of non-segment charges. These included acquisition-related and integration costs related to legal, accounting and other expenses associated with completed or pending acquisitions of approximately $8.0 million, including $1.6 million of purchase accounting inventory charges related to the Company’s 2017 acquisition of U.S. Sensor as described in Note 2, Acquisitions and Dispositions, of the Notes to Consolidated Financial Statements included in this Annual Report, and $2.2 million of charges related to restructuring and production transfers in the Company’s Asia operations.

[0000889331-20-000014:mdna:121]
Fiscal year 2018 also included approximately $0.9 million in foreign currency exchange gains primarily attributable to changes in the value of the euro, Mexico peso, Philippine peso and Chinese renminbi against the U.S. dollar, while fiscal year 2017 also included approximately $2.4 million in foreign currency exchange losses primarily attributable to changes in the value of the euro, Philippine peso and Chinese renminbi against the U.S. dollar.

[0000889331-20-000014:mdna:122]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2018 |  | 2017 |  | Change |  | % Change |
| Net sales | $ | 1,718,468 |  |  | $ | 1,221,534 |  |  | $ | 496,934 |  |  | 40.7 | % |
| Gross profit | 652,541 |  |  | 506,533 |  |  | 146,008 |  |  | 28.8 | % |
| Operating expenses | 427,492 |  |  | 288,022 |  |  | 139,470 |  |  | 48.4 | % |
| Operating income | 225,049 |  |  | 218,511 |  |  | 6,538 |  |  | 3.0 | % |
| Other income, net | (1,599 | ) |  | (1,282 | ) |  | (317 | ) |  | 24.7 | % |
| Income before income taxes | 204,942 |  |  | 204,037 |  |  | 905 |  |  | 0.4 | % |
| Income taxes | 40,337 |  |  | 84,518 |  |  | (44,181 | ) |  | (52.3 | )% |
| Net income | 164,565 |  |  | 119,519 |  |  | 45,046 |  |  | 37.7 | % |

[0000889331-20-000014:mdna:123]
Net Sales

[0000889331-20-000014:mdna:124]
Net sales for 2018 of $1,718.5 million increased $496.9 million, or 40.7%, compared to the prior year with increases of $378.2 million and $6.5 million resulting from incremental net sales related to the IXYS and U.S. Sensor acquisitions, respectively, $16.7 million of favorable changes in foreign exchange rates, and volume growth across all three segments.

[0000889331-20-000014:mdna:125]
Gross Profit

[0000889331-20-000014:mdna:126]
Gross profit was $652.5 million, or 38% of net sales, in 2018, compared to $506.5 million, or 41.5% of net sales, in 2017. The increase in gross profit reflects the IXYS acquisition and volume growth and expense leverage across all segments. The decrease in gross margin is primarily due to the purchase accounting inventory charges of $36.9 million, which negatively impacted gross margin by 2.1 percentage points, and an unfavorable mix of products from the IXYS acquisition, which historically had lower gross margins.

[0000889331-20-000014:mdna:127]
Operating Expenses

[0000889331-20-000014:mdna:128]
Total operating expenses were $427.5 million, or 24.9% of net sales, for 2018 compared to $288.0 million, or 23.6% of net sales, for 2017. The increase in operating expenses of $139.5 million was primarily due to the incremental operating expenses related

[0000889331-20-000014:mdna:129]
to the IXYS and U.S. Sensor acquisitions, an increase in amortization expense of $27.5 million resulting from the acquisition of IXYS as well as higher acquisition-related and integration costs of $12.1 million. Total operating expenses as a percent of net sales increased from 23.6% in 2017 to 24.9% in 2018 primarily due to the higher amortization expense and acquisition-related and integration charges noted above.

[0000889331-20-000014:mdna:130]
Operating Income

[0000889331-20-000014:mdna:131]
Operating income for 2018 was $225.0 million, an increase of $6.5 million or 3.0% compared to $218.5 million for 2017. The increase in operating income is primarily due to the acquisition of IXYS and volume growth in the Electronics and Industrial segments, partially offset by $36.9 million of purchase accounting inventory charges, higher acquisition-related and integration charges and amortization expense. Operating margins decreased from 17.9% in 2017 to 13.1% in 2018 driven by the purchase accounting inventory charges, higher amortization expense and acquisition-related and integration charges that negatively impacted margins by 2.1%, 1.6% and 0.7%, respectively.

[0000889331-20-000014:mdna:132]
Income Before Income Taxes

[0000889331-20-000014:mdna:133]
Income before income taxes for 2018 was $204.9 million, or 11.9% of net sales compared to $204.0 million, or 16.7% of net sales, for 2017. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was unfavorably impacted by higher interest expense of $9.2 million mainly resulting from increased borrowings, partially offset by  increases in foreign exchange gains of $3.2 million.

[0000889331-20-000014:mdna:134]
Income Taxes

[0000889331-20-000014:mdna:135]
Income tax expense for 2018 was $40.4 million, or an effective tax rate of 19.7% compared to income tax expense of $84.5 million, or an effective tax rate of 41.4%, for 2017. The 2018 income tax expense includes a charge of $3.2 million associated with finalizing the 2017 provisional reasonable estimate, including $2.3 million for the Toll Charge and $0.9 million for the net impact of other items. The 2017 income tax expense includes a charge of $47 million as a provisional reasonable estimate of the impact of the Tax Act, including $49 million for the Toll Charge net of $2 million for other net tax benefits. Additionally, our tax rates are lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, partially offset by the impact of taxes on unremitted earnings, and, with respect to 2018, the impact of the GILTI provisions of the Tax Act and non-U.S. losses and expenses with no tax benefit.

[0000889331-20-000014:mdna:136]
Segment Information

[0000889331-20-000014:mdna:137]
The Company reports its operations by the following segments: Electronics, Automotive and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-20-000014:mdna:138]
The following table is a summary of the Company’s net sales by segment:

[0000889331-20-000014:mdna:139]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | % Change |
| Electronics | $ | 1,124.3 |  |  | $ | 661.9 |  |  | $ | 462.4 |  |  | 69.9 | % |
| Automotive | 479.8 |  |  | 453.2 |  |  | 26.6 |  |  | 5.9 | % |
| Industrial | 114.4 |  |  | 106.4 |  |  | 8.0 |  |  | 7.5 | % |
| Total | $ | 1,718.5 |  |  | $ | 1,221.5 |  |  | $ | 497.0 |  |  | 40.7 | % |

[0000889331-20-000014:mdna:140]
Electronics Segment

[0000889331-20-000014:mdna:141]
The Electronics segment net sales increased $462.4 million, or 69.9%, in 2018 compared to 2017 due to incremental net sales related to the IXYS and U.S. Sensor acquisitions of $378.2 million and $6.5 million, respectively, volume growth driven by the continued strong demand across various end markets and geographies, and favorable foreign exchange impacts of $6.5 million.

[0000889331-20-000014:mdna:142]
Automotive Segment

[0000889331-20-000014:mdna:143]
Net sales in the Automotive segment increased $26.6 million, or 5.9%, in 2018 compared to 2017 due to volume growth across all businesses primarily led by the commercial vehicle and sensor businesses, and favorable foreign exchange impacts of $9.8 million.

[0000889331-20-000014:mdna:144]
Industrial Segment

[0000889331-20-000014:mdna:145]
The Industrial segment net sales increased $8.0 million, or 7.5%, in 2018 compared to 2017 primarily due to volume growth in the power fuse and relay businesses and favorable foreign exchange impacts of $0.4 million, partially offset by a decline in sales from the exit of the Custom business during 2018.

[0000889331-20-000014:mdna:146]
Geographic Net Sales Information

[0000889331-20-000014:mdna:147]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-20-000014:mdna:148]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | % Change |
| Asia-Pacific | $ | 753.3 |  |  | $ | 541.1 |  |  | $ | 212.2 |  |  | 39.2 | % |
| Americas | 578.6 |  |  | 436.5 |  |  | 142.1 |  |  | 32.6 | % |
| Europe | 386.6 |  |  | 243.9 |  |  | 142.7 |  |  | 58.5 | % |
| Total | $ | 1,718.5 |  |  | $ | 1,221.5 |  |  | $ | 497.0 |  |  | 40.7 | % |

[0000889331-20-000014:mdna:149]
Asia-Pacific

[0000889331-20-000014:mdna:150]
Asia-Pacific net sales increased $212.2 million, or 39.2%, in 2018 compared to 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $173.9 million and volume growth across all segments as well as favorable foreign exchange impacts of $3.7 million.

[0000889331-20-000014:mdna:151]
Americas

[0000889331-20-000014:mdna:152]
Net sales in the Americas increased $142.1 million, or 32.6%, in 2018 compared to 2017 driven by incremental net sales related to the IXYS and U.S. Sensor acquisitions of $90.7 million and $5.5 million, respectively, volume growth across all segments and favorable foreign exchange impacts of $0.4 million.

[0000889331-20-000014:mdna:153]
Europe

[0000889331-20-000014:mdna:154]
European net sales increased $142.7 million, or 58.5%, in 2018 compared to 2017. The increase in net sales was primarily due to incremental net sales related to the IXYS acquisition of $113.6 million with volume growth across the Electronics and Automotive segments as well as favorable foreign exchange impacts of $12.6 million.

[0000889331-20-000014:mdna:155]
Liquidity and Capital Resources

[0000889331-20-000014:mdna:156]
Cash and cash equivalents were $531.1 million as of December 28, 2019, an increase of $41.4 million as compared to December 29, 2018.

[0000889331-20-000014:mdna:157]
As of December 28, 2019, $333.2 million of the Company's $531.1 million cash and cash equivalents was held by non-U.S. subsidiaries. Of the $333.2 million, at least $165 million can be repatriated with minimal tax consequences, although in certain cases a non-U.S. withholding tax would be payable but subsequently refunded. With respect to the remaining $168.2 million, the Company has recognized deferred tax liabilities on approximately $78.5 million as of December 28, 2019 because the amounts are not considered to be permanently reinvested, and the Company may access additional amounts through loans and other means. Repatriation of some non-U.S. cash balances is restricted by local laws. Management regularly evaluates whether foreign earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its foreign subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-20-000014:mdna:158]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0000889331-20-000014:mdna:159]
Revolving Credit Facility/Term Loan

[0000889331-20-000014:mdna:160]
On March 4, 2016, the Company entered into a five-year credit agreement (“Credit Agreement”) with a group of lenders for up to $700.0 million. The Credit Agreement consisted of an unsecured revolving credit facility (“Revolving Credit Facility”) of $575.0 million and an unsecured term loan credit facility (“Term Loan”) of up to $125.0 million. In addition, the Company had the ability, from time to time, to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $150.0 million, in the aggregate, in each case in minimum increments of $25.0 million, subject to certain conditions and the agreement of participating lenders.

[0000889331-20-000014:mdna:161]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid $10.0 million of principal payments on the Term Loan for the fiscal year ended December 28, 2019.

[0000889331-20-000014:mdna:162]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR fixed for interest periods of one, two, three or six-month periods plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.20% at December 28, 2019.

[0000889331-20-000014:mdna:163]
As of December 28, 2019, the Company had no amounts outstanding in letters of credit and had available $353.4 million of borrowing capacity under the Revolving Credit Facility.

[0000889331-20-000014:mdna:164]
Senior Notes

[0000889331-20-000014:mdna:165]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-20-000014:mdna:166]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-20-000014:mdna:167]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and

[0000889331-20-000014:mdna:168]
2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing August 15, 2018.

[0000889331-20-000014:mdna:169]
The Company was in compliance with its debt covenants as of December 28, 2019 and expects to remain in compliance based on management’s estimates of operating and financial results for 2020 and the foreseeable future. As of December 28, 2019, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-20-000014:mdna:170]
Acquisitions

[0000889331-20-000014:mdna:171]
During the year ended December 29, 2018, the Company paid $306.5 million, net of cash acquired, for the acquisition of IXYS. Pursuant to the Securities Purchase Agreement, the Company paid $9.0 million for the acquisition of the remaining 38% outstanding common stock of Monolith during the year ended December 29, 2018. The Company financed the cash portion of the IXYS acquisition with a combination of cash on hand and borrowings under the credit facility.

[0000889331-20-000014:mdna:172]
During the year ended December 30, 2017, the Company paid $38.5 million, net of cash acquired, for the acquisitions of U.S Sensor and Monolith. The Company financed these acquisitions with a combination of cash on hand and borrowings under the credit facility.

[0000889331-20-000014:mdna:173]
Cash Flow Overview

[0000889331-20-000014:mdna:174]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes and other operating activities.

[0000889331-20-000014:mdna:175]
The following describes the Company’s cash flows for the twelve months ended December 28, 2019 and December 29, 2018:

[0000889331-20-000014:mdna:176]
|  | Fiscal Year |
| (in millions) | 2019 |  | 2018 |
| Net cash provided by operating activities | $ | 245.3 |  |  | $ | 331.8 |  |
| Net cash used in investing activities | (56.4 | ) |  | (382.3 | ) |
| Net cash (used in) provided by financing activities | (146.3 | ) |  | 121.9 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1.2 | ) |  | (11.4 | ) |
| Increase in cash and cash equivalents | 41.4 |  |  | 60.0 |  |
| Cash and cash equivalents at beginning of year | 489.7 |  |  | 429.7 |  |
| Cash and cash equivalents at end of year | $ | 531.1 |  |  | $ | 489.7 |  |

[0000889331-20-000014:mdna:177]
Cash Flow from Operating Activities

[0000889331-20-000014:mdna:178]
Net cash provided by operating activities was $245.3 million for 2019, compared to $331.8 million during 2018. The decrease in net cash provided by operating activities was primarily driven by lower earnings and higher working capital levels primarily due to the timing of supplier payments, payroll year-end cut off and higher annual incentive compensation payments in 2019.

[0000889331-20-000014:mdna:179]
Cash Flow from Investing Activities

[0000889331-20-000014:mdna:180]
Net cash used in investing activities was $56.5 million for 2019, compared to $382.3 million during 2018. Net cash used for the acquisition of IXYS was $306.5 million and $9.0 million for the acquisition of the remaining 38% outstanding common stock of Monolith in 2018. Capital expenditures were $61.9 million, representing a decrease of $12.9 million compared to 2018. The Company also received proceeds of $6.2 million in 2019 primarily as a result of the sale of a property within the Industrial segment.

[0000889331-20-000014:mdna:181]
Cash Flow from Financing Activities

[0000889331-20-000014:mdna:182]
Net cash used in financing activities was $146.3 million for 2019 compared to net cash provided by financing activities of $121.9 million for 2018. The Company repurchased 579,916 shares of its common stock during fiscal 2019 totaling $95.0 million, but made payments of  $99.4 million related to settled share repurchases. The Company made payments of $10.0 million on the term

[0000889331-20-000014:mdna:183]
loan in 2019 as compared to $310.0 million of proceeds from the credit facility, term loan and senior notes payable and $102.5 million of payments on the credit facility and term loan during 2018.

[0000889331-20-000014:mdna:184]
The following describes the Company’s cash flows for the twelve months ended December 29, 2018 and December 30, 2017:

[0000889331-20-000014:mdna:185]
|  | Fiscal Year |
| (in millions) | 2018 |  | 2017 |
| Net cash provided by operating activities | $ | 331.8 |  |  | $ | 269.2 |  |
| Net cash used in investing activities | (382.3 | ) |  | (96.1 | ) |
| Net cash provided by (used in) financing activities | 121.9 |  |  | (24.7 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (11.4 | ) |  | 6.2 |  |
| Increase (decrease) in cash and cash equivalents | 60.0 |  |  | 154.6 |  |
| Cash and cash equivalents at beginning of year | 429.7 |  |  | 275.1 |  |
| Cash and cash equivalents at end of year | $ | 489.7 |  |  | $ | 429.7 |  |

[0000889331-20-000014:mdna:186]
Cash Flow from Operating Activities

[0000889331-20-000014:mdna:187]
Net cash provided by operating activities was $331.8 million for 2018, compared to $269.2 million during 2017. The increase in net cash provided by operating activities was primarily driven by higher earnings and favorable working capital management that more than offset higher payments related to cash taxes and acquisition and integration costs.

[0000889331-20-000014:mdna:188]
Cash Flow from Investing Activities

[0000889331-20-000014:mdna:189]
Net cash used in investing activities was $382.3 million for 2018, compared to $96.1 million during 2017. Net cash used for the acquisition of IXYS was $306.5 million in 2018 compared to acquisitions of $38.5 million in 2017 related to the acquisition of a majority stake in Monolith for $14.2 million and the acquisition of U.S. Sensor for $24.3 million. Capital expenditures were $74.8 million, representing an increase of $8.8 million compared to 2017. The Company also received proceeds of $9.6 million in 2018 primarily as a result of the sale of a building.

[0000889331-20-000014:mdna:190]
Cash Flow from Financing Activities

[0000889331-20-000014:mdna:191]
Net cash provided by financing activities was $121.9 million for 2018 compared to net cash used in financing activities of $24.7 million for 2017. The Company had $310.0 million of proceeds from the credit facility, term loan and senior notes payable partially offset by payments of $102.5 million on credit facility and the term loan in 2018 as compared to $149.4 million of proceeds from the credit facility, term loan and senior notes payable and $134.7 million of payments on credit facility and the term loan during 2017. The Company repurchased 391,972 shares of its common stock during fiscal 2018 totaling $63.6 million.

[0000889331-20-000014:mdna:192]
Dividends

[0000889331-20-000014:mdna:193]
Cash dividends paid totaled $44.7 million, $40.0 million and $31.8 million for 2019, 2018 and 2017, respectively. On January 29, 2020, the Board of Directors of the Company declared a quarterly cash dividend of $0.48 per share, payable on March 5, 2020 to stockholders of record as of February 20, 2020.

[0000889331-20-000014:mdna:194]
Capital Resources

[0000889331-20-000014:mdna:195]
The Company expends capital to support its operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0000889331-20-000014:mdna:196]
Share Repurchase Program

[0000889331-20-000014:mdna:197]
On May 2, 2018, the Company announced that the Company’s Board of Directors had authorized the repurchase of up to 1,000,000 shares of the Company’s common stock under a program for the period May 1, 2018 to April 30, 2019 (the "2018 program"). On May 1, 2019, the Company announced that the Company's Board of Directors had authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 (the "2019 program"). As of April 30, 2019, 528,112 shares remained available for repurchases under the 2018 program.  During the fiscal

[0000889331-20-000014:mdna:198]
year ended December 28, 2019, the Company repurchased 579,916 shares of its common stock totaling $95.0 million. There were 500,000 shares remaining available for purchase under the 2019 program as of December 28, 2019.

[0000889331-20-000014:mdna:199]
Contractual Obligations and Commitments

[0000889331-20-000014:mdna:200]
The following table summarizes outstanding contractual obligations and commitments as of December 28, 2019:

[0000889331-20-000014:mdna:201]
|  | Payments Due By Period |
| (in thousands) | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | Greaterthan 5 Years |
| Long-term debt(a) | $ | 682,827 |  |  | $ | 10,000 |  |  | $ | 162,619 |  |  | $ | 129,808 |  |  | $ | 380,400 |  |
| Interest payments(b) | 114,695 |  |  | 18,114 |  |  | 33,998 |  |  | 23,858 |  |  | 38,725 |  |
| Operating lease payments(c) | 27,028 |  |  | 8,207 |  |  | 11,680 |  |  | 6,683 |  |  | 458 |  |
| Income Tax Obligation(d) | 26,754 |  |  | 3,000 |  |  | 5,273 |  |  | 11,534 |  |  | 6,947 |  |
| Purchase obligations(e) | 22,773 |  |  | 19,377 |  |  | 947 |  |  | 942 |  |  | 1,507 |  |
| Total | $ | 874,077 |  |  | $ | 58,698 |  |  | $ | 214,517 |  |  | $ | 172,825 |  |  | $ | 428,037 |  |

[0000889331-20-000014:mdna:202]
(a)Excludes offsetting issuance costs of $3.7 million. Euro denominated debt amounts are converted based on the Euro to U.S. Dollar spot rate at year end. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:203]
(b)Amounts represent estimated contractual interest payments on outstanding debt. Rates in effect as of December 28, 2019 are used for variable rate debt. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:204]
(c)For more information see Note 7, Lease Commitments, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:205]
(d)The Income Tax Obligation represents the remaining amounts payable regarding the 2017 Littelfuse Toll Charge. The Company has elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. For more information see Note 14, Income Taxes, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:206]
(e)Purchase obligations include purchase commitments and commitments for capital expenditures not recognized in the Company’s Consolidated Balance Sheets.

[0000889331-20-000014:mdna:207]
In addition to the above contractual obligations and commitments, the Company had the following obligations at December 28, 2019:

[0000889331-20-000014:mdna:208]
The Company has Company-sponsored defined benefit pension plans covering employees at various non-U.S. subsidiaries including the U.K., Germany, the Philippines, China, Japan, Mexico, Italy and France. At December 28, 2019, the Company had a net unfunded status of $38.4 million. The Company expects to make approximately $2.3 million of contributions to the plans in 2020. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:209]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. As of December 28, 2019, there was $10.5 million of accrued compensation benefits included in Other long-term liabilities. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:210]
As of December 28, 2019, the Company recognized various accruals related to employee compensation including its annual incentive program that are expected to be paid in 2020.

[0000889331-20-000014:mdna:211]
Due to the uncertainty with respect to the cash outflows, the preceding table excludes unrecognized tax benefits of $16.7 million. The Company does not expect to make significant payments of these liabilities within the next year. For additional information, see Note 14, Income Taxes, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:212]
Off-Balance Sheet Arrangements

[0000889331-20-000014:mdna:213]
As of December 28, 2019, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-20-000014:mdna:214]
Recent Accounting Pronouncements

[0000889331-20-000014:mdna:215]
Recently issued accounting standards and their estimated effect on the Company’s Consolidated Financial Statements are described in Note 1, Summary of Significant Accounting Policies and Other Information, of the Notes to Consolidated Financial Statements.

[0000889331-20-000014:mdna:216]
37
