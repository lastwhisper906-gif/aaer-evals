# LFUS note change history — 0000889331-19-000042 → 0000889331-19-000052


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000889331-19-000052:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2019 and September 29, 2018:
  (was, 2019-07-31, similarity 0.9034):
[0000889331-19-000042:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2019 and June 30, 2018 :

- added (2019-10-30):
[0000889331-19-000052:note_history:2]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- added (2019-10-30):
[0000889331-19-000052:note_history:3]
|  |  | Three Months Ended September 29, 2018 |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- removed (2019-10-30):
[0000889331-19-000042:note_history:4]
|  |  | Three Months Ended June 29, 2019 |  | Six Months Ended June 29, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

- removed (2019-10-30):
[0000889331-19-000042:note_history:5]
|  |  | Three Months Ended June 30, 2018 |  | Six Months Ended June 30, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  | 171,036 |  |  | — |  |  | — |  |  | 171,036 |  |  | 320,952 |  |  | — |  |  | — |  |  | 320,952 |  |
| Passenger Car Products |  | — |  |  | 63,581 |  |  | — |  |  | 63,581 |  |  | — |  |  | 127,160 |  |  | — |  |  | 127,160 |  |
| Automotive Sensors |  | — |  |  | 30,729 |  |  | — |  |  | 30,729 |  |  | — |  |  | 62,052 |  |  | — |  |  | 62,052 |  |
| Commercial Vehicle Products |  | — |  |  | 32,862 |  |  | — |  |  | 32,862 |  |  | — |  |  | 64,090 |  |  | — |  |  | 64,090 |  |
| Industrial Products |  | — |  |  | — |  |  | 32,654 |  |  | 32,654 |  |  | — |  |  | — |  |  | 59,926 |  |  | 59,926 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000889331-19-000052:note_history:6]
The carrying amounts of debt at September 28, 2019 and December 29, 2018 are as follows:
  (was, 2019-07-31, similarity 0.9272):
[0000889331-19-000042:note_history:6]
The carrying amounts of debt at June 29, 2019 and December 29, 2018 are as follows:

- changed (2019-10-30):
[0000889331-19-000052:note_history:7]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,002 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,932 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,893 | ) |  | (4,636 | ) |
| Total debt |  | 678,160 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 668,160 |  |  | $ | 684,730 |  |
  (was, 2019-07-31, similarity 0.9705):
[0000889331-19-000042:note_history:7]
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 132,992 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 107,984 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,155 | ) |  | (4,636 | ) |
| Total debt |  | 686,940 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,940 |  |  | $ | 684,730 |  |

- changed (2019-10-30):
[0000889331-19-000052:note_history:8]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $7.5 million on the term loan during the nine months ended September 28, 2019.
  (was, 2019-07-31, similarity 0.9323):
[0000889331-19-000042:note_history:8]
On October 13, 2017, the Company amended the Credit Agreement to increase the Revolving Credit Facility from $575.0 million to $700.0 million and increase the Term Loan from $125.0 million to $200.0 million and to extend the expiration date from March 4, 2021 to October 13, 2022. The Credit Agreement also includes the option for the Company to increase the size of the Revolving Credit Facility and the Term Loan by up to an additional $300.0 million, in the aggregate, subject to the satisfaction of certain conditions set forth in the Credit Agreement. Term Loans may be made in up to two advances. The first advance of $125.0 million occurred on October 13, 2017 and the second advance of $75.0 million occurred on January 16, 2018. For the Term Loan, the Company is required to make quarterly principal payments of 1.25% of the original term loan ($2.5 million quarterly) through maturity, with the remaining balance due on October 13, 2022. The Company paid quarterly principal payments of $2.5 million and $7.5 million on the term loan during the three and six months ended June 29, 2019.

- changed (2019-10-30):
[0000889331-19-000052:note_history:9]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.54% at September 28, 2019.
  (was, 2019-07-31, similarity 0.9858):
[0000889331-19-000042:note_history:9]
Outstanding borrowings under the Credit Agreement bear interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.00% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.15% to 0.25%, based on the Consolidated Leverage Ratio, as defined in the agreement. The credit agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 3.65% at June 29, 2019.

- added (2019-10-30):
[0000889331-19-000052:note_history:10]
As of September 28, 2019, the Company had less than $0.1 million outstanding in letters of credit and had available $416.5 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At September 28, 2019, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2019-10-30):
[0000889331-19-000052:note_history:11]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At September 28, 2019, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2019-07-31, similarity 0.9396):
[0000889331-19-000042:note_history:11]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 29, 2019, the Company was in compliance with all covenants under the Senior Notes.

- changed (2019-10-30):
[0000889331-19-000052:note_history:12]
Interest paid on all Company debt was $6.4 million and $8.1 million for the three months ended September 28, 2019 and September 29, 2018, respectively, and $17.9 million and $15.8 million for the nine months ended September 28, 2019 and September 29, 2018, respectively.
  (was, 2019-07-31, similarity 0.7297):
[0000889331-19-000042:note_history:12]
Interest paid on all Company debt was $3.5 million and $3.7 million for the three months ended June 29, 2019 and June 30, 2018, respectively, and $11.5 million and $7.7 million for the six months ended June 29, 2019 and June 30, 2018, respectively.

- removed (2019-10-30):
[0000889331-19-000042:note_history:13]
As of June 29, 2019, the Company had $0.1 million outstanding in letters of credit and had available $531.1 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At June 29, 2019, the Company was in compliance with all covenants under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000889331-19-000052:note_history:14]
The carrying amounts of debt at September 28, 2019 and December 29, 2018 are as follows:
  (was, 2019-07-31, similarity 0.9272):
[0000889331-19-000042:note_history:14]
The carrying amounts of debt at June 29, 2019 and December 29, 2018 are as follows:

- changed (2019-10-30):
[0000889331-19-000052:note_history:15]
| (in thousands) |  | September 28, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 128,002 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,932 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,893 | ) |  | (4,636 | ) |
| Total debt |  | 678,160 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 668,160 |  |  | $ | 684,730 |  |
  (was, 2019-07-31, similarity 0.9705):
[0000889331-19-000042:note_history:15]
| (in thousands) |  | June 29, 2019 |  | December 29, 2018 |
| Term Loan |  | $ | 147,500 |  |  | $ | 155,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 132,992 |  |  | 133,417 |  |
| Euro Senior Notes, Series B due 2028 |  | 107,984 |  |  | 108,330 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (4,155 | ) |  | (4,636 | ) |
| Total debt |  | 686,940 |  |  | 694,730 |  |
| Less: Current maturities |  | (10,000 | ) |  | (10,000 | ) |
| Total long-term debt |  | $ | 676,940 |  |  | $ | 684,730 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000889331-19-000052:note_history:16]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For both the three months ended September 28, 2019 and September 29, 2018, the Company recorded revenues of $0.2 million from sales of products to Powersem for use as components in their products. For the nine months ended September 28, 2019 and September 29, 2018, the Company recorded revenues of $0.4 million and $0.6 million from sales of products to Powersem for use as components in their products, respectively. During the three months ended September 28, 2019 and September 29, 2018, the Company purchased $0.8 million and $1.3 million of products from Powersem, respectively. During the nine months ended September 28, 2019 and September 29, 2018, the Company purchased $2.4 million and $3.4 million of products from Powersem, respectively. As of September 28, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.
  (was, 2019-07-31, similarity 0.7769):
[0000889331-19-000042:note_history:16]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany. For the three months ended June 29, 2019 and June 30, 2018, the Company recorded revenues of $0.1 million and $0.3 million from sales of products to Powersem for use as components in their products, respectively. For the six months ended June 29, 2019 and June 30, 2018, the Company recorded revenues of $0.2 million and $0.4 million from sales of products to Powersem for use as components in their products, respectively. During the three months ended June 29, 2019 and June 30, 2018, the Company purchased $0.9 million and $1.0 million of products from Powersem, respectively. During the six months ended June 29, 2019 and June 30, 2018, the Company purchased $1.7 million and $2.1 million of products from Powersem, respectively. As of June 29, 2019, the accounts receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.1 million. As of December 29, 2018, the trade receivable balance from Powersem was $0.1 million and the accounts payable balance to Powersem was $0.2 million.

- changed (2019-10-30):
[0000889331-19-000052:note_history:17]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During both the three months ended September 28, 2019 and September 29, 2018, EB Tech rendered processing services for the Company totaling less than $0.1 million. During both the  nine months ended September 28, 2019 and September 29, 2018, EB Tech rendered processing services for the Company totaling approximately $0.3 million. As of September 28, 2019 the Company's accounts payable balance to EB Tech was less than $0.1 million. As of December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.
  (was, 2019-07-31, similarity 0.7544):
[0000889331-19-000042:note_history:17]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea. During both the three months ended June 29, 2019 and June 30, 2018, EB Tech rendered processing services for the Company totaling approximately $0.1 million. During both the  six months ended June 29, 2019 and June 30, 2018, EB Tech rendered processing services for the Company totaling approximately $0.2 million. As of June 29, 2019 and December 29, 2018, the Company’s accounts payable balance to EB Tech was $0.1 million.

- added (2019-10-30):
[0000889331-19-000052:note_history:18]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended September 28, 2019 and September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $1.7 million and $2.5 million, respectively. During the nine months ended September 28, 2019 and September 29, 2018, ATEC rendered assembly and test services to the Company totaling approximately $5.5 million and $7.7 million, respectively. As of September 28, 2019 the Company's accounts payable balance to ATEC was $0.2 million. As of December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.

- added (2019-10-30):
[0000889331-19-000052:note_history:19]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $1.2 million as of September 28, 2019 where one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.

- removed (2019-10-30):
[0000889331-19-000042:note_history:20]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. During the three months ended June 29, 2019 and June 30, 2018, ATEC rendered assembly and test services to the Company totaling approximately $2.3 million and $2.8 million, respectively. During the six months ended June 29, 2019 and June 30, 2018, ATEC rendered assembly and test services to the Company totaling approximately $3.8 million and $5.2 million, respectively. As of June 29, 2019 and December 29, 2018, the Company’s accounts payable balance to ATEC was $0.5 million.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000889331-19-000052:note_history:21]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2019 and September 29, 2018:
  (was, 2019-07-31, similarity 0.9034):
[0000889331-19-000042:note_history:21]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2019 and June 30, 2018 :

- added (2019-10-30):
[0000889331-19-000052:note_history:22]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- added (2019-10-30):
[0000889331-19-000052:note_history:23]
|  |  | Three Months Ended September 29, 2018 |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- removed (2019-10-30):
[0000889331-19-000042:note_history:24]
|  |  | Three Months Ended June 29, 2019 |  | Six Months Ended June 29, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

- removed (2019-10-30):
[0000889331-19-000042:note_history:25]
|  |  | Three Months Ended June 30, 2018 |  | Six Months Ended June 30, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  | 171,036 |  |  | — |  |  | — |  |  | 171,036 |  |  | 320,952 |  |  | — |  |  | — |  |  | 320,952 |  |
| Passenger Car Products |  | — |  |  | 63,581 |  |  | — |  |  | 63,581 |  |  | — |  |  | 127,160 |  |  | — |  |  | 127,160 |  |
| Automotive Sensors |  | — |  |  | 30,729 |  |  | — |  |  | 30,729 |  |  | — |  |  | 62,052 |  |  | — |  |  | 62,052 |  |
| Commercial Vehicle Products |  | — |  |  | 32,862 |  |  | — |  |  | 32,862 |  |  | — |  |  | 64,090 |  |  | — |  |  | 64,090 |  |
| Industrial Products |  | — |  |  | — |  |  | 32,654 |  |  | 32,654 |  |  | — |  |  | — |  |  | 59,926 |  |  | 59,926 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-30):
[0000889331-19-000052:note_history:26]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended September 28, 2019 and September 29, 2018:
  (was, 2019-07-31, similarity 0.9034):
[0000889331-19-000042:note_history:26]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 29, 2019 and June 30, 2018 :

- added (2019-10-30):
[0000889331-19-000052:note_history:27]
|  |  | Three Months Ended September 28, 2019 |  | Nine Months Ended September 28, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 94,766 |  |  | $ | — |  |  | $ | — |  |  | $ | 94,766 |  |  | $ | 311,624 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,624 |  |
| Electronics – Semiconductor |  | 132,486 |  |  | — |  |  | — |  |  | 132,486 |  |  | 440,575 |  |  | — |  |  | — |  |  | 440,575 |  |
| Passenger Car Products |  | — |  |  | 53,889 |  |  | — |  |  | 53,889 |  |  | — |  |  | 164,348 |  |  | — |  |  | 164,348 |  |
| Automotive Sensors |  | — |  |  | 23,877 |  |  | — |  |  | 23,877 |  |  | — |  |  | 74,616 |  |  | — |  |  | 74,616 |  |
| Commercial Vehicle Products |  | — |  |  | 26,915 |  |  | — |  |  | 26,915 |  |  | — |  |  | 87,850 |  |  | — |  |  | 87,850 |  |
| Industrial Products |  | — |  |  | — |  |  | 30,038 |  |  | 30,038 |  |  | — |  |  | — |  |  | 86,337 |  |  | 86,337 |  |
| Total |  | $ | 227,252 |  |  | $ | 104,681 |  |  | $ | 30,038 |  |  | $ | 361,971 |  |  | $ | 752,199 |  |  | $ | 326,814 |  |  | $ | 86,337 |  |  | $ | 1,165,350 |  |

- added (2019-10-30):
[0000889331-19-000052:note_history:28]
|  |  | Three Months Ended September 29, 2018 |  | Nine Months Ended September 29, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 124,174 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,174 |  |  | $ | 366,990 |  |  | $ | — |  |  | $ | — |  |  | $ | 366,990 |  |
| Electronics – Semiconductor |  | 172,298 |  |  | — |  |  | — |  |  | 172,298 |  |  | 493,250 |  |  | — |  |  | — |  |  | 493,250 |  |
| Passenger Car Products |  | — |  |  | 57,761 |  |  | — |  |  | 57,761 |  |  | — |  |  | 184,922 |  |  | — |  |  | 184,922 |  |
| Automotive Sensors |  | — |  |  | 27,311 |  |  | — |  |  | 27,311 |  |  | — |  |  | 89,362 |  |  | — |  |  | 89,362 |  |
| Commercial Vehicle Products |  | — |  |  | 29,344 |  |  | — |  |  | 29,344 |  |  | — |  |  | 93,434 |  |  | — |  |  | 93,434 |  |
| Industrial Products |  | — |  |  | — |  |  | 28,303 |  |  | 28,303 |  |  | — |  |  | — |  |  | 88,229 |  |  | 88,229 |  |
| Total |  | $ | 296,472 |  |  | $ | 114,416 |  |  | $ | 28,303 |  |  | $ | 439,191 |  |  | $ | 860,240 |  |  | $ | 367,718 |  |  | $ | 88,229 |  |  | $ | 1,316,187 |  |

- removed (2019-10-30):
[0000889331-19-000042:note_history:29]
|  |  | Three Months Ended June 29, 2019 |  | Six Months Ended June 29, 2019 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 108,481 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,481 |  |  | $ | 216,858 |  |  | $ | — |  |  | $ | — |  |  | $ | 216,858 |  |
| Electronics – Semiconductor |  | 151,072 |  |  | — |  |  | — |  |  | 151,072 |  |  | 308,089 |  |  | — |  |  | — |  |  | 308,089 |  |
| Passenger Car Products |  | — |  |  | 53,916 |  |  | — |  |  | 53,916 |  |  | — |  |  | 110,459 |  |  | — |  |  | 110,459 |  |
| Automotive Sensors |  | — |  |  | 24,682 |  |  | — |  |  | 24,682 |  |  | — |  |  | 50,739 |  |  | — |  |  | 50,739 |  |
| Commercial Vehicle Products |  | — |  |  | 30,052 |  |  | — |  |  | 30,052 |  |  | — |  |  | 60,935 |  |  | — |  |  | 60,935 |  |
| Industrial Products |  | — |  |  | — |  |  | 29,676 |  |  | 29,676 |  |  | — |  |  | — |  |  | 56,299 |  |  | 56,299 |  |
| Total |  | $ | 259,553 |  |  | $ | 108,650 |  |  | $ | 29,676 |  |  | $ | 397,879 |  |  | $ | 524,947 |  |  | $ | 222,133 |  |  | $ | 56,299 |  |  | $ | 803,379 |  |

- removed (2019-10-30):
[0000889331-19-000042:note_history:30]
|  |  | Three Months Ended June 30, 2018 |  | Six Months Ended June 30, 2018 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 128,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 128,321 |  |  | $ | 242,816 |  |  | $ | — |  |  | $ | — |  |  | $ | 242,816 |  |
| Electronics – Semiconductor |  | 171,036 |  |  | — |  |  | — |  |  | 171,036 |  |  | 320,952 |  |  | — |  |  | — |  |  | 320,952 |  |
| Passenger Car Products |  | — |  |  | 63,581 |  |  | — |  |  | 63,581 |  |  | — |  |  | 127,160 |  |  | — |  |  | 127,160 |  |
| Automotive Sensors |  | — |  |  | 30,729 |  |  | — |  |  | 30,729 |  |  | — |  |  | 62,052 |  |  | — |  |  | 62,052 |  |
| Commercial Vehicle Products |  | — |  |  | 32,862 |  |  | — |  |  | 32,862 |  |  | — |  |  | 64,090 |  |  | — |  |  | 64,090 |  |
| Industrial Products |  | — |  |  | — |  |  | 32,654 |  |  | 32,654 |  |  | — |  |  | — |  |  | 59,926 |  |  | 59,926 |  |
| Total |  | $ | 299,357 |  |  | $ | 127,172 |  |  | $ | 32,654 |  |  | $ | 459,183 |  |  | $ | 563,768 |  |  | $ | 253,302 |  |  | $ | 59,926 |  |  | $ | 876,996 |  |
