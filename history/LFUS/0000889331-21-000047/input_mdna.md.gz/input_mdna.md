# LFUS MD&A — 0000889331-21-000047


## mdna

[0000889331-21-000047:mdna:1]
[same as prior period, unchanged from 0000889331-21-000034:mdna:1]

[0000889331-21-000047:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-21-000047:mdna:3]
[same as prior period, unchanged from 0000889331-21-000034:mdna:3]

[0000889331-21-000047:mdna:4]
[same as prior period, unchanged from 0000889331-21-000034:mdna:4]

[0000889331-21-000047:mdna:5]
[same as prior period, unchanged from 0000889331-21-000034:mdna:5]

[0000889331-21-000047:mdna:6]
[same as prior period, unchanged from 0000889331-21-000034:mdna:6]

[0000889331-21-000047:mdna:7]
[same as prior period, unchanged from 0000889331-21-000034:mdna:7]

[0000889331-21-000047:mdna:8]
[same as prior period, unchanged from 0000889331-21-000034:mdna:8]

[0000889331-21-000047:mdna:9]
For the second quarter of 2021, the Company recognized net sales of $523.5 million compared to $307.3 million in the second quarter of 2020 representing an increase of $216.2 million, or 70.3%. The increase was primarily driven by higher volumes across all businesses in each of the segments, $26.4 million or 5.0% of net sales from the Hartland acquisition within the Industrial segment and $13.5 million or 4.4% of favorable changes in foreign exchange rates. The Company recognized net income of $82.1 million, or $3.30 per diluted share, in the second quarter of 2021 compared to a net loss of $9.0 million, or $0.37 per diluted share in the second quarter of 2020. The increase in net income reflects higher operating income of $108.2 million driven by a $41.6 million and a $28.1 million increase in operating income in the Electronics and Automotive segments, respectively, and the second quarter of 2020 included a non-cash goodwill impairment charge of $33.8 million related to the automotive sensors reporting unit within the Automotive segment.

[0000889331-21-000047:mdna:10]
[same as prior period, unchanged from 0000889331-21-000034:mdna:10]

[0000889331-21-000047:mdna:11]
Net cash provided by operating activities was $126.3 million for the six months ended June 26, 2021 as compared to $101.3 million for the six months ended June 27, 2020. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth.

[0000889331-21-000047:mdna:12]
[same as prior period, unchanged from 0000889331-21-000034:mdna:12]

[0000889331-21-000047:mdna:13]
The effects from COVID-19 continue to drive increased costs, though lower than 2020 levels. Ongoing costs include spending on personal protective equipment ("PPE"), additional personnel and employee transportation costs, and manufacturing inefficiencies, as well as an increase in freight costs and raw material due to the transportation capacity constraints across the world.

[0000889331-21-000047:mdna:14]
The Company anticipates that the global health crisis caused by COVID-19 may continue to impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a resurgence in COVID-19 cases and its impact on our employees, customers, suppliers and vendors. The Company will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business and operations, including the effects on our customers, employees, and prospects, or on our financial results for the fiscal year 2021.

[0000889331-21-000047:mdna:15]
[same as prior period, unchanged from 0000889331-21-000034:mdna:15]

[0000889331-21-000047:mdna:16]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The second quarter of 2021 includes $3.3 million ($6.8 million year-to-date) of purchase accounting inventory step-

[0000889331-21-000047:mdna:17]
up charges, $0.5 million ($1.3 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions and $0.8 million ($1.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. In addition, there was a loss of $1.0 million recorded during the second quarter of 2021 for a total year-to-date gain of $0.9 million from the sale of a building within the Electronics segment

[0000889331-21-000047:mdna:18]
The second quarter of 2020 includes $0.1 million ($1.3 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there was $35.6 million ($39.6 million year-to-date) of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, $1.8 million ($3.5 million year-to-date) of employee termination costs, and other restructuring charges and impairment charges of $2.2 million recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment.

[0000889331-21-000047:mdna:19]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  | 2021 |  | 2020 |  | Change |  | %Change |
| Net sales |  | $ | 523,488 |  |  | $ | 307,337 |  |  | $ | 216,151 |  |  | 70.3 | % |  | $ | 987,282 |  |  | $ | 653,433 |  |  | $ | 333,849 |  |  | 51.1 | % |
| Cost of sales |  | 326,092 |  |  | 207,435 |  |  | 118,657 |  |  | 57.2 | % |  | 629,420 |  |  | 429,175 |  |  | 200,245 |  |  | 46.7 | % |
| Gross profit |  | 197,396 |  |  | 99,902 |  |  | 97,494 |  |  | 97.6 | % |  | 357,862 |  |  | 224,258 |  |  | 133,604 |  |  | 59.6 | % |
| Operating expenses |  | 101,139 |  |  | 111,852 |  |  | (10,713) |  |  | (9.6) | % |  | 185,124 |  |  | 191,458 |  |  | (6,334) |  |  | (3.3) | % |
| Operating income (loss) |  | 96,257 |  |  | (11,950) |  |  | 108,207 |  |  | 905.5 | % |  | 172,738 |  |  | 32,800 |  |  | 139,938 |  |  | 426.6 | % |
| Income (loss) before income taxes |  | 95,197 |  |  | (10,585) |  |  | 105,782 |  |  | 999.4 | % |  | 167,905 |  |  | 24,914 |  |  | 142,991 |  |  | 573.9 | % |
| Income taxes |  | 13,102 |  |  | (1,594) |  |  | 14,696 |  |  | 922.0 | % |  | 28,097 |  |  | 9,261 |  |  | 18,836 |  |  | 203.4 | % |
| Net income (loss) |  | $ | 82,095 |  |  | $ | (8,991) |  |  | $ | 91,086 |  |  | 1,013.1 | % |  | $ | 139,808 |  |  | $ | 15,653 |  |  | $ | 124,155 |  |  | 793.2 | % |

[0000889331-21-000047:mdna:20]
[same as prior period, unchanged from 0000889331-21-000034:mdna:20]

[0000889331-21-000047:mdna:21]
Net sales increased $216.2 million or 70.3% including $13.5 million or 4.4% of favorable changes in foreign exchange rates for the second quarter of 2021 compared to the second quarter of 2020. The increase was driven by volume growth across each of our segments and businesses within these segments whereas the second quarter of 2020 had temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19. The sales growth was primarily across all businesses within the Electronics and Automotive segments, which had sales increases of $102.1 million and $71.3 million, respectively. The volume increase within the Electronics segment was led by broad-based demand across electronics, transportation and industrial end markets. The volume increase within the Automotive segment was led by growth in global auto and commercial vehicle market demand along with greater content growth across passenger vehicles due to vehicle mix, including growth in electric vehicles. The remaining increase in net sales was primarily due to $26.4 million of net sales resulting from the Hartland acquisition included in the Industrial segment and volume growth across all businesses within the Industrial segment.

[0000889331-21-000047:mdna:22]
Net sales increased $333.8 million or 51.1% including $25.9 million or 4.0% of favorable changes in foreign exchange rates for the first six months of 2021 compared to the first six months of 2020. The increase was due to volume growth across all segments and businesses while the first six months of 2020 had temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19. The increase was primarily due to higher sales of $174.4 million and $95.1 million in the Electronics and Automotive segments, respectively, driven by higher volumes across all businesses within these segments. The volume increase within the Electronics segment was led by broad-based demand across electronics, transportation and industrial end markets. The volume increase within the Automotive segment was led by growth in global auto and commercial vehicle market demand along with greater content growth across passenger vehicles due to vehicle mix, including growth in electric vehicles. The remaining increase in net sales was primarily due to $43.1 million of net sales resulting from the Hartland acquisition included in the Industrial segment and volume growth across all businesses within the Industrial segment.

[0000889331-21-000047:mdna:23]
30

[0000889331-21-000047:mdna:24]
[same as prior period, unchanged from 0000889331-21-000034:mdna:22]

[0000889331-21-000047:mdna:25]
Cost of sales was $326.1 million, or 62.3% of net sales, in 2021, compared to $207.4 million, or 67.5% of net sales, in 2020. The increase in cost of sales was primarily due to greater volume across all segments driven by the factors discussed above along with the acquisition of Hartland. As a percent of net sales, cost of sales decreased 5.2% driven by volume leverage, partially offset by higher freight costs of 1.2%, the Hartland purchase accounting inventory charges of $3.3 million or 0.6%, and higher commodity costs.

[0000889331-21-000047:mdna:26]
Cost of sales was $629.4 million, or 63.8% of net sales for the first six months of 2021, compared to $429.2 million, or 65.7% of net sales for the first six months of 2020. The increase in cost of sales was primarily due to greater volume across all segments driven by the factors discussed above along with the acquisition of Hartland. As a percent of net sales, cost of sales decreased 1.9% driven by volume leverage, partially offset by higher freight costs of 1.1%, the Hartland purchase accounting inventory charges of $6.8 million or 0.7%, and higher commodity costs.

[0000889331-21-000047:mdna:27]
[same as prior period, unchanged from 0000889331-21-000034:mdna:24]

[0000889331-21-000047:mdna:28]
Gross profit was $197.4 million, or 37.7% of net sales, in the second quarter of 2021 compared to $99.9 million, or 32.5% of net sales, for the second quarter of 2020. The $97.5 million increase in gross profit was primarily due to higher volume across all segments while the second quarter of 2020 had additional costs associated with the temporary closures of manufacturing facilities resulting from government directives due to the impact of COVID-19. The increase in gross margin of 5.2% was primarily driven by volume leverage, partially offset by higher freight costs as a percent of net sales of 1.2%, the purchase accounting inventory charges of $3.3 million or 0.6%, and higher commodity costs.

[0000889331-21-000047:mdna:29]
Gross profit was $357.9 million, or 36.2% of net sales, in the first six months of 2021 compared to $224.3 million, or 34.3% of net sales, for the first six months of 2020. The $133.6 million increase in gross profit was primarily due to higher volume across all segments while the first six months of 2020 had additional costs associated with government-directed plant shutdowns and supply chain constraints. The increase in gross margin of 1.9% was primarily driven by volume leverage, partially offset by the higher freight costs as a percent of net sales of 1.1%, the purchase accounting inventory charges of $6.8 million or 0.7%, and higher commodity costs.

[0000889331-21-000047:mdna:30]
[same as prior period, unchanged from 0000889331-21-000034:mdna:26]

[0000889331-21-000047:mdna:31]
Total operating expenses were $101.1 million, or 19.3% of net sales, for the second quarter of 2021 compared to $111.9 million, or 36.4% of net sales, for the second quarter of 2020. The decrease in operating expenses of $10.7 million was primarily due to the goodwill impairment charge of $33.8 million, or 11.0% of net sales, in the automotive sensors reporting unit within the Automotive segment recorded during the second quarter of 2020, partially offset by higher selling, general and administrative expenses of $20.1 million largely due to higher accrued incentive compensation and the Hartland acquisition, and higher research and development expenses of $3.2 million.

[0000889331-21-000047:mdna:32]
Total operating expenses were $185.1 million, or 18.8% of net sales, for the first six months of 2021 compared to $191.5 million, or 29.3% of net sales, for the first six months of 2020. The decrease in operating expenses of $6.3 million is primarily due to the 2020 goodwill impairment charge of $33.8 million, or 5.2% of net sales, in the automotive sensors reporting unit within the Automotive segment and impairment charges of $2.2 million related to the Company’s 2020 first quarter announcement to consolidate a manufacturing facility within the Industrial segment, partially offset by higher selling, general, and administrative expenses of $27.2 million largely due to higher accrued incentive compensation and the Hartland acquisition, and higher research and development expenses of $3.5 million.

[0000889331-21-000047:mdna:33]
Operating Income (Loss)

[0000889331-21-000047:mdna:34]
Operating income was $96.3 million, an increase of $108.2 million for the second quarter of 2021 compared to an operating loss of $12.0 million for the second quarter of 2020. The increase in operating income was primarily due to higher gross profit from all segments as noted above and the second quarter of 2020 goodwill impairment charge of $33.8 million. Operating margins increased from (3.9)% in the second quarter of 2020 to 18.4% in the second quarter of 2021 driven by the factors mentioned above. The goodwill impairment charge of $33.8 million negatively impacted operating margin by 11.0% in the second quarter of 2020.

[0000889331-21-000047:mdna:35]
Operating income was $172.7 million, an increase of $139.9 million, or 426.6%, for the first six months of 2021 compared to $32.8 million for the first six months of 2020. The increase in operating income was primarily due to higher gross margin across all segments and lower operating expenses noted above. Operating margins increased from 5.0% in the first six months

[0000889331-21-000047:mdna:36]
of 2020 to 17.5% in the first six months of 2021 driven by the factors mentioned above. The goodwill impairment charge of $33.8 million negatively impacted the operating margin by 5.2% for the first six months of 2020.

[0000889331-21-000047:mdna:37]
Income (Loss) Before Income Taxes

[0000889331-21-000047:mdna:38]
Income before income taxes was $95.2 million, or 18.2% of net sales, for the second quarter of 2021 compared to a loss before income taxes of $10.6 million, or 3.4% of net sales, for the second quarter of 2020. In addition to the factors impacting comparative results for operating income (loss) discussed above, income before income taxes was primarily impacted by lower foreign exchange gains of $4.3 million and a $0.7 million decreases in unrealized investment gains associated with our equity investments, partially offset by lower interest expense of $1.2 million due to lower outstanding borrowings under the credit facility.

[0000889331-21-000047:mdna:39]
Income before income taxes was $167.9 million, or 17.0% of net sales, for the first six months of 2021 compared to $24.9 million, or 3.8% of net sales, for the first six months of 2020.  In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by a $9.0 million increases in unrealized investment gains associated with our equity investment and lower interest expense of $2.0 million due to lower outstanding borrowings under the credit facility along with a lower effective interest rate, partially offset by the foreign exchange loss of $5.2 million during the six months ended June 26, 2021 compared to foreign exchange gains of $3.4 million during six months ended June 27, 2020.

[0000889331-21-000047:mdna:40]
[same as prior period, unchanged from 0000889331-21-000034:mdna:33]

[0000889331-21-000047:mdna:41]
Income tax expense for the second quarter of 2021 was $13.1 million, or an effective tax rate of 13.8%, compared to income tax benefit of $1.6 million, or an effective tax rate of 15.1%, for the second quarter of 2020. The effective tax rate for the second quarter of 2021 (which is based upon pre-tax income) is lower than the effective tax rate for the comparable 2020 period (which is based upon a pre-tax loss), primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 as compared to 2020, as well as the impact of the goodwill impairment charge of $33.8 million recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit.

[0000889331-21-000047:mdna:42]
Income tax expense for the first six months of 2021 was $28.1 million, or an effective tax rate of 16.7%, compared to income tax expense of $9.3 million, or an effective tax rate of 37.2%, for the first six months of 2020. The effective tax rate for the first six months of 2021 is lower than the effective tax rate for the comparable 2020 period primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 compared to 2020, and the impact of the goodwill impairment charge of $33.8 million recorded in the second quarter of 2020.

[0000889331-21-000047:mdna:43]
The effective tax rate for the 2021 periods is lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0000889331-21-000047:mdna:44]
[same as prior period, unchanged from 0000889331-21-000034:mdna:35]

[0000889331-21-000047:mdna:45]
[same as prior period, unchanged from 0000889331-21-000034:mdna:36]

[0000889331-21-000047:mdna:46]
[same as prior period, unchanged from 0000889331-21-000034:mdna:37]

[0000889331-21-000047:mdna:47]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  | 2021 |  | 2020 |  | Change |  | %Change |
| Electronics |  | $ | 325,347 |  |  | $ | 223,271 |  |  | $ | 102,076 |  |  | 45.7 | % |  | $ | 611,882 |  |  | $ | 437,460 |  |  | $ | 174,422 |  |  | 39.9 | % |
| Automotive |  | 133,318 |  |  | 61,999 |  |  | 71,319 |  |  | 115.0 | % |  | 261,847 |  |  | 166,769 |  |  | 95,078 |  |  | 57.0 | % |
| Industrial |  | 64,823 |  |  | 22,067 |  |  | 42,756 |  |  | 193.8 | % |  | 113,553 |  |  | 49,204 |  |  | 64,349 |  |  | 130.8 | % |
| Total |  | $ | 523,488 |  |  | $ | 307,337 |  |  | $ | 216,151 |  |  | 70.3 | % |  | $ | 987,282 |  |  | $ | 653,433 |  |  | $ | 333,849 |  |  | 51.1 | % |

[0000889331-21-000047:mdna:48]
[same as prior period, unchanged from 0000889331-21-000034:mdna:39]

[0000889331-21-000047:mdna:49]
Net sales increased $102.1 million, or 45.7%, in the second quarter of 2021 compared to the second quarter of 2020 and included favorable changes in foreign exchange rates of $7.3 million. The sales increase was primarily due to increased volume for the electronics products and semiconductor businesses of $62.4 million and $39.6 million, respectively. The volume increases were led by broad-based demand across electronics, transportation and industrial end markets. The second quarter of 2020 also included production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:50]
Net sales increased $174.4 million, or 39.9%, in the first six months of 2021 compared to the first six months of 2020 and included favorable changes in foreign exchange rates of $13.8 million. The sales increase was primarily due to increased volume for the electronics products and semiconductor businesses of $110.3 million and $64.2 million, respectively. The volume increases were driven by strong demand across the consumer electronics, automotive and industrial end markets while the first six months of 2020 were negatively impacted by production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:51]
[same as prior period, unchanged from 0000889331-21-000034:mdna:41]

[0000889331-21-000047:mdna:52]
Net sales increased $71.3 million, or 115.0%, in the second quarter of 2021 compared to the second quarter of 2020 and included favorable changes in foreign exchange rates of $5.8 million. The sales increase was due to higher volume in passenger car products, commercial vehicle products, and the automotive sensors business of $37.7 million, $20.8 million, and $12.8 million, respectively. The volume increase within the Automotive segment was led by growth in global auto and commercial vehicle market demand along with greater content growth across passenger vehicles due to vehicle mix, including growth in electric vehicle. This growth was across all regions, particularly in North America and Europe where volumes and demand increased from the second quarter of 2020 that was negatively impacted by COVID-19 production disruptions and temporary plant closures.

[0000889331-21-000047:mdna:53]
Net sales increased $95.1 million, or 57.0%, in the first six months of 2021 compared to the first six months of 2020 and included favorable changes in foreign exchange rates of $11.3 million. These sales increases were due to higher volume in passenger car products, commercial vehicle products, and the automotive sensors business of $53.0 million, $25.2 million, and $16.9 million, respectively. These increases were due to stronger global auto and commercial vehicle market demand. Each of our regions experienced growth driven by an increase in global auto market demand as compared to the first six months of 2020, which had production disruptions due to the impact of COVID-19. Sales also grew due to the launch of new products and higher content per vehicle due to vehicle mix.

[0000889331-21-000047:mdna:54]
[same as prior period, unchanged from 0000889331-21-000034:mdna:44]

[0000889331-21-000047:mdna:55]
Net sales increased by $42.8 million, or 193.8%, in the second quarter of 2021 compared to the second quarter of 2020, which included favorable changes in foreign exchange rates of $0.4 million. The increase in net sales was primarily due to incremental net sales of $26.4 million or 119.6% from the Hartland acquisition, higher volume of $10.6 million in the industrial circuit protection (power fuse) business led by growth across renewable energy and data center markets, and the transfer of the temperature sensor product line totaling $2.8 million which was previously reported in the Electronics segment. Additionally, the second quarter of 2020 was negatively impacted by temporary plant shutdowns and production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:56]
Net sales increased by $64.3 million, or 130.8%, in the first six months of 2021 compared to the first six months of 2020, which included favorable changes in foreign exchange rates of $0.8 million. The increase in net sales was primarily due to incremental net sales of $43.1 million or 87.5% from the Hartland acquisition, higher volume of $15.1 million in the industrial circuit protection (power fuse) business, and the transfer of the temperature sensor product line totaling $4.7 million which was previously reported in the Electronics segment. Additionally, the first six months of 2020 was negatively impacted by production disruptions and temporary plant shutdown due to the impact of COVID-19.

[0000889331-21-000047:mdna:57]
[same as prior period, unchanged from 0000889331-21-000034:mdna:46]

[0000889331-21-000047:mdna:58]
[same as prior period, unchanged from 0000889331-21-000034:mdna:47]

[0000889331-21-000047:mdna:59]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2021 |  | 2020 |  | Change |  | %Change |  | 2021 |  | 2020 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 239,477 |  |  | $ | 155,737 |  |  | $ | 83,740 |  |  | 53.8 | % |  | $ | 451,662 |  |  | $ | 296,610 |  |  | $ | 155,052 |  |  | 52.3 | % |
| Americas |  | 180,335 |  |  | 89,651 |  |  | 90,684 |  |  | 101.2 | % |  | 333,241 |  |  | 210,152 |  |  | 123,089 |  |  | 58.6 | % |
| Europe |  | 103,676 |  |  | 61,949 |  |  | 41,727 |  |  | 67.4 | % |  | 202,379 |  |  | 146,671 |  |  | 55,708 |  |  | 38.0 | % |
| Total |  | $ | 523,488 |  |  | $ | 307,337 |  |  | $ | 216,151 |  |  | 70.3 | % |  | $ | 987,282 |  |  | $ | 653,433 |  |  | $ | 333,849 |  |  | 51.1 | % |

[0000889331-21-000047:mdna:60]
[same as prior period, unchanged from 0000889331-21-000034:mdna:49]

[0000889331-21-000047:mdna:61]
Net sales increased $83.7 million, or 53.8%, in the second quarter of 2021 compared to the second quarter of 2020 and included favorable changes in foreign exchange rates of $4.8 million. The increase in net sales was primarily due to higher volume across all businesses within the Electronics segment and higher volume in the passenger car products and commercial vehicle businesses within the Automotive segment compared to the second quarter of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:62]
Net sales increased $155.1 million, or 52.3%, in the first six months of 2021 compared to the first six months of 2020 and included favorable changes in foreign exchange rates of $9.0 million. The increase in net sales was primarily due to higher volume across all businesses across all segments compared to the first six months of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:63]
[same as prior period, unchanged from 0000889331-21-000034:mdna:51]

[0000889331-21-000047:mdna:64]
Net sales increased $90.7 million, or 101.2%, in the second quarter of 2021 compared to the second quarter of 2020 and included favorable changes in foreign exchange rates of $0.4 million. The increase in net sales was primarily due to higher volume across all businesses within the Automotive and Electronics segments, incremental sales of $26.4 million from the Hartland acquisition and higher volume in the industrial circuit protection (power fuse) business included in the Industrial segment compared to the second quarter of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:65]
Net sales increased $123.1 million, or 58.6%, in the first six months of 2021 compared to first six months of 2020 and included favorable changes in foreign exchange rates of $0.5 million. The increase in net sales was primarily due to incremental sales of $43.1 million from the Hartland acquisition, higher volume across all businesses within the Electronics and Automotive segments, and higher volume in the industrial circuit protection (power fuse) business included in the Industrial segment compared to the first six months of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:66]
[same as prior period, unchanged from 0000889331-21-000034:mdna:53]

[0000889331-21-000047:mdna:67]
Net sales increased $41.7 million, or 67.4%, in the second quarter of 2021 compared to the second quarter of 2020 and included  favorable changes in foreign exchange rates of $8.3 million. The increase in net sales was primarily due to increased volume across all businesses within the Automotive and Electronics segments compared to the second quarter of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:68]
Net sales increased $55.7 million, or 38.0%, in the first six months of 2021 compared to the first six months of 2020 and included  favorable changes in foreign exchange rates of $16.4 million. The increase in net sales was primarily due to increased volume across all businesses within the Automotive and Electronics segments compared to the first six months of 2020 that had production disruptions due to the impact of COVID-19.

[0000889331-21-000047:mdna:69]
[same as prior period, unchanged from 0000889331-21-000034:mdna:55]

[0000889331-21-000047:mdna:70]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide

[0000889331-21-000047:mdna:71]
sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0000889331-21-000047:mdna:72]
Cash and cash equivalents were $616.3 million as of June 26, 2021, a decrease of $71.2 million as compared to December 26, 2020. As of June 26, 2021, $323.7 million of the Company's $616.3 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-21-000047:mdna:73]
Revolving Credit Facility

[0000889331-21-000047:mdna:74]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the six months ended June 26, 2021. The balance under the facility was $100.0 million as of June 26, 2021.

[0000889331-21-000047:mdna:75]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.59% at June 26, 2021.

[0000889331-21-000047:mdna:76]
As of June 26, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At June 26, 2021, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-21-000047:mdna:77]
[same as prior period, unchanged from 0000889331-21-000034:mdna:62]

[0000889331-21-000047:mdna:78]
[same as prior period, unchanged from 0000889331-21-000034:mdna:63]

[0000889331-21-000047:mdna:79]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000047:mdna:80]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018. Further information regarding the Company’s Senior Notes is provided in Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this Quarterly Report.

[0000889331-21-000047:mdna:81]
Debt Covenants

[0000889331-21-000047:mdna:82]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of June 26, 2021 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2021. As of June 26, 2021, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-21-000047:mdna:83]
[same as prior period, unchanged from 0000889331-21-000034:mdna:68]

[0000889331-21-000047:mdna:84]
[same as prior period, unchanged from 0000889331-21-000034:mdna:69]

[0000889331-21-000047:mdna:85]
[same as prior period, unchanged from 0000889331-21-000034:mdna:70]

[0000889331-21-000047:mdna:86]
During the second quarter of 2021 the Company paid quarterly dividends of $11.8 million to the shareholders. On July 21, 2021, the Board of Directors of the Company approved a 10% increase in the quarterly cash dividend from $0.48 to $0.53 per share, payable on September 2, 2021 to stockholders of record as of August 19, 2021.

[0000889331-21-000047:mdna:87]
[same as prior period, unchanged from 0000889331-21-000034:mdna:72]

[0000889331-21-000047:mdna:88]
[same as prior period, unchanged from 0000889331-21-000034:mdna:73]

[0000889331-21-000047:mdna:89]
[same as prior period, unchanged from 0000889331-21-000034:mdna:74]

[0000889331-21-000047:mdna:90]
|  |  | First Six Months |
| (in thousands) |  | 2021 |  | 2020 |
| Net cash provided by operating activities |  | $ | 126,346 |  |  | $ | 101,286 |  |
| Net cash used in investing activities |  | (139,940) |  |  | (29,390) |  |
| Net cash (used in) provided by financing activities |  | (49,183) |  |  | 50,526 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (2,894) |  |  | (1,694) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (65,671) |  |  | 120,728 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 687,525 |  |  | 531,139 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 621,854 |  |  | $ | 651,867 |  |

[0000889331-21-000047:mdna:91]
[same as prior period, unchanged from 0000889331-21-000034:mdna:76]

[0000889331-21-000047:mdna:92]
[same as prior period, unchanged from 0000889331-21-000034:mdna:77]

[0000889331-21-000047:mdna:93]
Net cash provided by operating activities was $126.3 million for the six months ended June 26, 2021 as compared to $101.3 million for the six months ended June 27, 2020. The increase in net cash provided by operating activities was primarily due to higher cash earnings partially offset by increases in working capital resulting from higher sales growth.

[0000889331-21-000047:mdna:94]
[same as prior period, unchanged from 0000889331-21-000034:mdna:79]

[0000889331-21-000047:mdna:95]
Net cash used in investing activities was $139.9 million for the six months ended June 26, 2021 compared to $29.4 million during the six months ended June 27, 2020. Net cash paid for the Hartland acquisition was $109.9 million for the six months ended June 26, 2021. Capital expenditures were $32.7 million, representing an increase of $3.2 million compared to 2020. During the six months ended June 26, 2021, the Company received proceeds of $2.6 million from the sale of a property within the Electronics segment.

[0000889331-21-000047:mdna:96]
[same as prior period, unchanged from 0000889331-21-000034:mdna:82]

[0000889331-21-000047:mdna:97]
Net cash used in financing activities was $49.2 million for the six months ended June 26, 2021 compared to net cash provided by financing activities of $50.5 million for the six months ended June 27, 2020. The Company made payments of $30.0 million on the amended revolving credit facility during the six months ended June 26, 2021. On April 3, 2020, the Company amended the Credit Agreement to eliminate the $200.0 million unsecured term loan credit facility, with the remaining outstanding balance of $140.0 million repaid in full on April 3, 2020 through a new borrowing of $140.0 million under the amended revolving credit facility. During the six months ended June 27, 2020, the Company borrowed $100.0 million from its revolving credit facility to preserve financial flexibility and enhance liquidity, given the increasing levels of uncertainty related to COVID-19. The Company also made principal payments of $5.0 million on the term loan during the six months ended June 27, 2020. For the six months ended June 27, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million. Additionally, the Company paid dividends $23.6 million and $23.4 million in the six months ended June 26, 2021 and June 27, 2020, respectively.

[0000889331-21-000047:mdna:98]
[same as prior period, unchanged from 0000889331-21-000034:mdna:84]

[0000889331-21-000047:mdna:99]
[same as prior period, unchanged from 0000889331-21-000034:mdna:85]

[0000889331-21-000047:mdna:100]
The Company did not repurchase any shares of its common stock for the three and six months ended June 26, 2021. During the six months ended June 27, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.

[0000889331-21-000047:mdna:101]
[same as prior period, unchanged from 0000889331-21-000034:mdna:87]

[0000889331-21-000047:mdna:102]
As of June 26, 2021, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-21-000047:mdna:103]
[same as prior period, unchanged from 0000889331-21-000034:mdna:89]

[0000889331-21-000047:mdna:104]
[same as prior period, unchanged from 0000889331-21-000034:mdna:90]

[0000889331-21-000047:mdna:105]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 26, 2020. During the six months ended June 26, 2021, there were no significant changes in the application of critical accounting policies.
