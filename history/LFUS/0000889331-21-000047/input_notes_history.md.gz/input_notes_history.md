# LFUS note change history — 0000889331-21-000034 → 0000889331-21-000047


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000889331-21-000047:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 26, 2021 and June 27, 2020:
  (was, 2021-04-28, similarity 0.9044):
[0000889331-21-000034:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 27, 2021 and March 28, 2020:

- added (2021-07-28):
[0000889331-21-000047:note_history:2]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  | — |  |  | — |  |  | 64,823 |  |  | 64,823 |  |  | — |  |  | — |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- added (2021-07-28):
[0000889331-21-000047:note_history:3]
|  |  | Three Months Ended June 27, 2020 |  | Six Months Ended June 27, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

- changed (2021-07-28):
[0000889331-21-000047:note_history:4]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at June 26, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2021-04-28, similarity 0.9843):
[0000889331-21-000034:note_history:4]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at March 27, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2021-07-28):
[0000889331-21-000047:note_history:5]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 616,330 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,790 |  |  | — |  |
| Restricted cash included in other assets |  | 1,734 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 621,854 |  |  | $ | 687,525 |  |
  (was, 2021-04-28, similarity 0.9864):
[0000889331-21-000034:note_history:5]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 572,771 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,462 |  |  | — |  |
| Restricted cash included in other assets |  | 1,064 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 577,297 |  |  | $ | 687,525 |  |

- added (2021-07-28):
[0000889331-21-000047:note_history:6]
In December 2019, the Financial Accounting Standards Board (FASB) issued Accounting Standard Update ("ASU") No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.

- removed (2021-07-28):
[0000889331-21-000034:note_history:7]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:8]
|  |  | Three Months Ended March 28, 2020 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |  |  |  |  |  |  |  |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:9]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000889331-21-000047:note_history:10]
The carrying amounts of debt at June 26, 2021 and December 26, 2020 are as follows:
  (was, 2021-04-28, similarity 0.9388):
[0000889331-21-000034:note_history:10]
The carrying amounts of debt at March 27, 2021 and December 26, 2020 are as follows:

- changed (2021-07-28):
[0000889331-21-000047:note_history:11]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 139,610 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,671) |  |  | (4,114) |  |
| Total debt |  | 651,917 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 626,917 |  |  | $ | 687,034 |  |
  (was, 2021-04-28, similarity 0.9929):
[0000889331-21-000034:note_history:11]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 138,039 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,876) |  |  | (4,114) |  |
| Total debt |  | 648,865 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 623,865 |  |  | $ | 687,034 |  |

- changed (2021-07-28):
[0000889331-21-000047:note_history:12]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the six months ended June 26, 2021. The balance under the facility was $100.0 million as of June 26, 2021.
  (was, 2021-04-28, similarity 0.9674):
[0000889331-21-000034:note_history:12]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the three months ended March 27, 2021. The balance under the facility was $100.0 million as of March 27, 2021.

- changed (2021-07-28):
[0000889331-21-000047:note_history:13]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.59% at June 26, 2021.
  (was, 2021-04-28, similarity 0.9855):
[0000889331-21-000034:note_history:13]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.61% at March 27, 2021.

- changed (2021-07-28):
[0000889331-21-000047:note_history:14]
As of June 26, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At June 26, 2021, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2021-04-28, similarity 0.9115):
[0000889331-21-000034:note_history:14]
As of March 27, 2021, the Company had no amount outstanding in letters of credit and had available $571.3 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 27, 2021, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2021-07-28):
[0000889331-21-000047:note_history:15]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 26, 2021, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2021-04-28, similarity 0.9921):
[0000889331-21-000034:note_history:15]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 27, 2021, the Company was in compliance with all covenants under the Senior Notes.

- changed (2021-07-28):
[0000889331-21-000047:note_history:16]
Interest paid on all Company debt was $2.5 million and $3.4 million for the three months ended June 26, 2021 and June 27, 2020, respectively, and $8.7 million and $10.8 million for the six months ended June 26, 2021 and June 27, 2020, respectively.
  (was, 2021-04-28, similarity 0.7014):
[0000889331-21-000034:note_history:16]
Interest paid on all Company debt was $6.2 million and $7.4 million for the three months ended March 27, 2021 and March 28, 2020, respectively.

- changed (2021-07-28):
[0000889331-21-000047:note_history:17]
The carrying amounts of debt at June 26, 2021 and December 26, 2020 are as follows:
  (was, 2021-04-28, similarity 0.9388):
[0000889331-21-000034:note_history:17]
The carrying amounts of debt at March 27, 2021 and December 26, 2020 are as follows:

- changed (2021-07-28):
[0000889331-21-000047:note_history:18]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 139,610 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,671) |  |  | (4,114) |  |
| Total debt |  | 651,917 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 626,917 |  |  | $ | 687,034 |  |
  (was, 2021-04-28, similarity 0.9929):
[0000889331-21-000034:note_history:18]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 138,039 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,876) |  |  | (4,114) |  |
| Total debt |  | 648,865 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 623,865 |  |  | $ | 687,034 |  |

- changed (2021-07-28):
[0000889331-21-000047:note_history:19]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the six months ended June 26, 2021. The balance under the facility was $100.0 million as of June 26, 2021.
  (was, 2021-04-28, similarity 0.9674):
[0000889331-21-000034:note_history:19]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the three months ended March 27, 2021. The balance under the facility was $100.0 million as of March 27, 2021.

- changed (2021-07-28):
[0000889331-21-000047:note_history:20]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.59% at June 26, 2021.
  (was, 2021-04-28, similarity 0.9855):
[0000889331-21-000034:note_history:20]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company was also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement included representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.61% at March 27, 2021.

- changed (2021-07-28):
[0000889331-21-000047:note_history:21]
As of June 26, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At June 26, 2021, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2021-04-28, similarity 0.9115):
[0000889331-21-000034:note_history:21]
As of March 27, 2021, the Company had no amount outstanding in letters of credit and had available $571.3 million of borrowing capacity under the Revolving Credit Facility based on financial covenants. At March 27, 2021, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2021-07-28):
[0000889331-21-000047:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 26, 2021, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2021-04-28, similarity 0.9921):
[0000889331-21-000034:note_history:22]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 27, 2021, the Company was in compliance with all covenants under the Senior Notes.

- changed (2021-07-28):
[0000889331-21-000047:note_history:23]
Interest paid on all Company debt was $2.5 million and $3.4 million for the three months ended June 26, 2021 and June 27, 2020, respectively, and $8.7 million and $10.8 million for the six months ended June 26, 2021 and June 27, 2020, respectively.
  (was, 2021-04-28, similarity 0.7014):
[0000889331-21-000034:note_history:23]
Interest paid on all Company debt was $6.2 million and $7.4 million for the three months ended March 27, 2021 and March 28, 2020, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000889331-21-000047:note_history:24]
The carrying amounts of debt at June 26, 2021 and December 26, 2020 are as follows:
  (was, 2021-04-28, similarity 0.9388):
[0000889331-21-000034:note_history:24]
The carrying amounts of debt at March 27, 2021 and December 26, 2020 are as follows:

- changed (2021-07-28):
[0000889331-21-000047:note_history:25]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 139,610 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,671) |  |  | (4,114) |  |
| Total debt |  | 651,917 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 626,917 |  |  | $ | 687,034 |  |
  (was, 2021-04-28, similarity 0.9929):
[0000889331-21-000034:note_history:25]
| (in thousands) |  | March 27,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 138,039 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 112,083 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,876) |  |  | (4,114) |  |
| Total debt |  | 648,865 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 623,865 |  |  | $ | 687,034 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2021-07-28):
[0000889331-21-000047:note_history:26]
|  |  | For the Three Months Ended June 26, 2021 |  | For the Three Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.7 |  | 0.1 |  | 2.8 |  |  | 0.8 |  | — |  | 1.6 |  |
|  |  | For the Six Months Ended June 26, 2021 |  | For the Six Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | 0.2 |  | 5.8 |  |  | 1.0 |  | — |  | 3.4 |  |
|  |  | June 26, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 1.8 |  |  | 0.1 |  | — |  | 0.2 |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:27]
|  |  | For the Three Months Ended March 27, 2021 |  | For the Three Months Ended March 28, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.2 |  | $ | — |  | $ | 1.8 |  |
|  |  | March 27, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | $ | 0.2 |  | $ | — |  | $ | 0.3 |  |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:28]
Additionally, the Company has certain cost method investments in VTOOL Ltd. and Securepush Ltd. with a total book value of $0.5 million as of March 27, 2021 and December 26, 2020 and one member of the Company’s Board of Directors is currently an investor and a director of VTOOL Ltd. and Securepush Ltd.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2021-07-28):
[0000889331-21-000047:note_history:29]
|  |  | For the Three Months Ended June 26, 2021 |  | For the Three Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.7 |  | 0.1 |  | 2.8 |  |  | 0.8 |  | — |  | 1.6 |  |
|  |  | For the Six Months Ended June 26, 2021 |  | For the Six Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | 0.2 |  | 5.8 |  |  | 1.0 |  | — |  | 3.4 |  |
|  |  | June 26, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 1.8 |  |  | 0.1 |  | — |  | 0.2 |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:30]
|  |  | For the Three Months Ended March 27, 2021 |  | For the Three Months Ended March 28, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.2 |  | $ | — |  | $ | 1.8 |  |
|  |  | March 27, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts Receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts Payable balance |  | $ | 0.2 |  | $ | — |  | $ | 0.3 |  |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000889331-21-000047:note_history:31]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 26, 2021 and June 27, 2020:
  (was, 2021-04-28, similarity 0.9044):
[0000889331-21-000034:note_history:31]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 27, 2021 and March 28, 2020:

- added (2021-07-28):
[0000889331-21-000047:note_history:32]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  | — |  |  | — |  |  | 64,823 |  |  | 64,823 |  |  | — |  |  | — |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- added (2021-07-28):
[0000889331-21-000047:note_history:33]
|  |  | Three Months Ended June 27, 2020 |  | Six Months Ended June 27, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:34]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:35]
|  |  | Three Months Ended March 28, 2020 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |  |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-28):
[0000889331-21-000047:note_history:36]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 26, 2021 and June 27, 2020:
  (was, 2021-04-28, similarity 0.9044):
[0000889331-21-000034:note_history:36]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 27, 2021 and March 28, 2020:

- added (2021-07-28):
[0000889331-21-000047:note_history:37]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  | — |  |  | — |  |  | 64,823 |  |  | 64,823 |  |  | — |  |  | — |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- added (2021-07-28):
[0000889331-21-000047:note_history:38]
|  |  | Three Months Ended June 27, 2020 |  | Six Months Ended June 27, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:39]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

- removed (2021-07-28):
[0000889331-21-000034:note_history:40]
|  |  | Three Months Ended March 28, 2020 |  |  |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 84,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 84,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 129,591 |  |  | — |  |  | — |  |  | 129,591 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 52,645 |  |  | — |  |  | 52,645 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 24,174 |  |  | — |  |  | 24,174 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 27,137 |  |  | 27,137 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 214,189 |  |  | $ | 104,770 |  |  | $ | 27,137 |  |  | $ | 346,096 |  |  |  |  |  |  |  |  |  |
