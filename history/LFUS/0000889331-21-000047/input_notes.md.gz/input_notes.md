# LFUS notes — 0000889331-21-000047


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-21-000047:notes:1]
[same as prior period, unchanged from 0000889331-21-000034:notes:1]

[0000889331-21-000047:notes:2]
[same as prior period, unchanged from 0000889331-21-000034:notes:2]

[0000889331-21-000047:notes:3]
[same as prior period, unchanged from 0000889331-21-000034:notes:3]

[0000889331-21-000047:notes:4]
[same as prior period, unchanged from 0000889331-21-000034:notes:4]

[0000889331-21-000047:notes:5]
[same as prior period, unchanged from 0000889331-21-000034:notes:5]

[0000889331-21-000047:notes:6]
[same as prior period, unchanged from 0000889331-21-000034:notes:6]

[0000889331-21-000047:notes:7]
[same as prior period, unchanged from 0000889331-21-000034:notes:7]

[0000889331-21-000047:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 26, 2021 and June 27, 2020:

[0000889331-21-000047:notes:9]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  | — |  |  | — |  |  | 64,823 |  |  | 64,823 |  |  | — |  |  | — |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

[0000889331-21-000047:notes:10]
|  |  | Three Months Ended June 27, 2020 |  | Six Months Ended June 27, 2020 |
| (in thousands) |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | AutomotiveSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 92,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,846 |  |  | $ | 177,444 |  |  | $ | — |  |  | $ | — |  |  | $ | 177,444 |  |
| Electronics – Semiconductor |  | 130,425 |  |  | — |  |  | — |  |  | 130,425 |  |  | 260,016 |  |  | — |  |  | — |  |  | 260,016 |  |
| Passenger Car Products |  | — |  |  | 30,309 |  |  | — |  |  | 30,309 |  |  | — |  |  | 82,954 |  |  | — |  |  | 82,954 |  |
| Automotive Sensors |  | — |  |  | 13,899 |  |  | — |  |  | 13,899 |  |  | — |  |  | 38,073 |  |  | — |  |  | 38,073 |  |
| Commercial Vehicle Products |  | — |  |  | 17,791 |  |  | — |  |  | 17,791 |  |  | — |  |  | 45,742 |  |  | — |  |  | 45,742 |  |
| Industrial Products |  | — |  |  | — |  |  | 22,067 |  |  | 22,067 |  |  | — |  |  | — |  |  | 49,204 |  |  | 49,204 |  |
| Total |  | $ | 223,271 |  |  | $ | 61,999 |  |  | $ | 22,067 |  |  | $ | 307,337 |  |  | $ | 437,460 |  |  | $ | 166,769 |  |  | $ | 49,204 |  |  | $ | 653,433 |  |

[0000889331-21-000047:notes:11]
[same as prior period, unchanged from 0000889331-21-000034:notes:11]

[0000889331-21-000047:notes:12]
[same as prior period, unchanged from 0000889331-21-000034:notes:12]

[0000889331-21-000047:notes:13]
[same as prior period, unchanged from 0000889331-21-000034:notes:13]

[0000889331-21-000047:notes:14]
[same as prior period, unchanged from 0000889331-21-000034:notes:14]

[0000889331-21-000047:notes:15]
[same as prior period, unchanged from 0000889331-21-000034:notes:15]

[0000889331-21-000047:notes:16]
[same as prior period, unchanged from 0000889331-21-000034:notes:16]

[0000889331-21-000047:notes:17]
[same as prior period, unchanged from 0000889331-21-000034:notes:17]

[0000889331-21-000047:notes:18]
[same as prior period, unchanged from 0000889331-21-000034:notes:18]

[0000889331-21-000047:notes:19]
[same as prior period, unchanged from 0000889331-21-000034:notes:19]

[0000889331-21-000047:notes:20]
[same as prior period, unchanged from 0000889331-21-000034:notes:20]

[0000889331-21-000047:notes:21]
[same as prior period, unchanged from 0000889331-21-000034:notes:21]

[0000889331-21-000047:notes:22]
[same as prior period, unchanged from 0000889331-21-000034:notes:22]

[0000889331-21-000047:notes:23]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at June 26, 2021 and December 26, 2020 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-21-000047:notes:24]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Cash and cash equivalents |  | $ | 616,330 |  |  | $ | 687,525 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 3,790 |  |  | — |  |
| Restricted cash included in other assets |  | 1,734 |  |  | $ | — |  |
| Total cash, cash equivalents and restricted cash |  | $ | 621,854 |  |  | $ | 687,525 |  |

[0000889331-21-000047:notes:25]
Recently Adopted Accounting Standards

[0000889331-21-000047:notes:26]
In December 2019, the Financial Accounting Standards Board (FASB) issued Accounting Standard Update ("ASU") No. 2019-12, "Income Taxes (Topic 740) - Simplifying the Accounting for Income Taxes" as part of its initiative to reduce complexity in the accounting standards. The guidance is effective for fiscal years beginning after December 15, 2020 with early adoption permitted. The adoption of ASU 2019-12 did not have a material impact on our Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-21-000047:notes:27]
[same as prior period, unchanged from 0000889331-21-000034:notes:27]

[0000889331-21-000047:notes:28]
[same as prior period, unchanged from 0000889331-21-000034:notes:28]

[0000889331-21-000047:notes:29]
[same as prior period, unchanged from 0000889331-21-000034:notes:29]

[0000889331-21-000047:notes:30]
[same as prior period, unchanged from 0000889331-21-000034:notes:30]

[0000889331-21-000047:notes:31]
The total purchase consideration of $109.9 million, net of cash, cash equivalents, and restricted cash has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase consideration is subject to change for the final working capital adjustments. As of June 26, 2021, the Company had restricted cash of $1.7 million in an escrow account for general indemnification purposes. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary areas that are not yet finalized relate to the completion of the valuation of certain contingent liabilities. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-21-000047:notes:32]
[same as prior period, unchanged from 0000889331-21-000034:notes:32]

[0000889331-21-000047:notes:33]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired, and restricted cash | $ | 109,852 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 13,027 |  |
| Inventories | 35,808 |  |
| Other current assets | 2,224 |  |
| Property, plant, and equipment | 6,296 |  |
| Intangible assets | 39,660 |  |
| Goodwill | 40,442 |  |
| Other non-current assets | 3,787 |  |
| Current liabilities | (24,846) |  |
| Other non-current liabilities | (6,546) |  |
|  | $ | 109,852 |  |

[0000889331-21-000047:notes:34]
During the three months ended June 26, 2021, the Company recorded a cumulative net measurement period adjustment that increased goodwill by $ 1.5 million and resulted in a decrease to the fair value assigned to trade receivables, inventories and net current liabilities of $1.3 million, $0.5 million and $0.3 million, respectively. The measurement period adjustment was primarily associated with certain contingent liabilities and customer settlements. The Company made these measurement period adjustments to reflect facts and circumstances that existed as of the acquisition date.

[0000889331-21-000047:notes:35]
[same as prior period, unchanged from 0000889331-21-000034:notes:34]

[0000889331-21-000047:notes:36]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and six months ended June 26, 2021 are net sales of approximately $26.4 million and $43.1 million respectively, and a loss before income taxes of $0.3 million and $2.5 million, respectively since the January 28, 2021 acquisition of Hartland.

[0000889331-21-000047:notes:37]
The Company recorded a $6.8 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the first and second quarters of 2021, as the acquired inventory was sold, and is reflected as other non-segment costs. During the three and six months ended June 26, 2021, the Company recognized a charge of $3.3 million and $6.8 million for the amortization of this fair value inventory step-up.

[0000889331-21-000047:notes:38]
During the three and six months ended June 26, 2021, the Company incurred approximately $0.1 million and $0.8 million of legal and professional fees related to this acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-21-000047:notes:39]
[same as prior period, unchanged from 0000889331-21-000034:notes:38]

[0000889331-21-000047:notes:40]
[same as prior period, unchanged from 0000889331-21-000034:notes:39]

[0000889331-21-000047:notes:41]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands, except per share amounts) |  | June 26,2021 |  | June 27, 2020 |  | June 26,2021 |  | June 27, 2020 |
| Net sales |  | $ | 523,488 |  |  | $ | 323,713 |  |  | $ | 994,320 |  |  | $ | 687,330 |  |
| Income (loss) before income taxes |  | 98,644 |  |  | (10,392) |  |  | 175,939 |  |  | 21,039 |  |
| Net income (loss) |  | 84,818 |  |  | (8,873) |  |  | 146,143 |  |  | 12,565 |  |
| Net income (loss) per share — basic |  | 3.45 |  |  | (0.36) |  |  | 5.95 |  |  | 0.52 |  |
| Net income (loss) per share — diluted |  | 3.41 |  |  | (0.36) |  |  | 5.87 |  |  | 0.51 |  |

[0000889331-21-000047:notes:42]
[same as prior period, unchanged from 0000889331-21-000034:notes:41]

[0000889331-21-000047:notes:43]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | June 26,2021 |  | June 27, 2020 |  | June 26, 2021 |  | June 27, 2020 |
| Amortization(a) |  | $ | — |  |  | $ | (837) |  |  | $ | (280) |  |  | $ | (1,676) |  |
| Depreciation |  | — |  |  | 47 |  |  | 7 |  |  | 95 |  |
| Transaction costs(b) |  | 128 |  |  | (128) |  |  | 835 |  |  | (835) |  |
| Amortization of inventory step-up(c) |  | 3,319 |  |  | (1,659) |  |  | 6,808 |  |  | (6,796) |  |
| Income tax (expense) benefit of above items |  | (724) |  |  | 541 |  |  | (1,555) |  |  | 1,940 |  |

[0000889331-21-000047:notes:44]
(a)The amortization adjustment for the three and six months ended June 27, 2020 primarily reflects incremental amortization resulting for the measurement of intangibles at their fair values.

[0000889331-21-000047:notes:45]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three and six months ended June 26, 2021 and recognition of those fees during the three and six months ended June 27, 2020.

[0000889331-21-000047:notes:46]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the three and six months ended June 26, 2021 and the recognition of the amortization during the three and six months ended June 27, 2020. The inventory step-up was amortized over four months as the inventory was sold.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-21-000047:notes:47]
[same as prior period, unchanged from 0000889331-21-000034:notes:46]

[0000889331-21-000047:notes:48]
The components of inventories at June 26, 2021 and December 26, 2020 are as follows:

[0000889331-21-000047:notes:49]
| (in thousands) |  | June 26, 2021 |  | December 26, 2020 |
| Raw materials |  | $ | 111,769 |  |  | $ | 85,394 |  |
| Work in process |  | 106,552 |  |  | 92,783 |  |
| Finished goods |  | 142,777 |  |  | 114,641 |  |
| Inventory Reserves |  | (35,324) |  |  | (34,816) |  |
| Total |  | $ | 325,774 |  |  | $ | 258,002 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-21-000047:notes:50]
Property, Plant, and Equipment 
The components of net property, plant, and equipment at June 26, 2021 and December 26, 2020 are as follows:

[0000889331-21-000047:notes:51]
| (in thousands) |  | June 26, 2021 |  | December 26, 2020 |
| Land |  | $ | 21,795 |  |  | $ | 22,851 |  |
| Building |  | 128,528 |  |  | 123,497 |  |
| Equipment |  | 706,115 |  |  | 678,220 |  |
| Accumulated depreciation and amortization |  | (503,612) |  |  | (480,390) |  |
| Total |  | $ | 352,826 |  |  | $ | 344,178 |  |

[0000889331-21-000047:notes:52]
The Company recorded depreciation expense of $13.6 million and $13.9 million for the three months ended June 26, 2021 and June 27, 2020, respectively, and $27.3 million and $27.7 million for the six months ended June 26, 2021 and June 27, 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-21-000047:notes:53]
[same as prior period, unchanged from 0000889331-21-000034:notes:53]

[0000889331-21-000047:notes:54]
The amounts for goodwill and changes in the carrying value by segment for the six months ended June 26, 2021 are as follows:

[0000889331-21-000047:notes:55]
| (in thousands) |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Net book value of goodwill as of December 26, 2020 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 26, 2020 |  | $ | 676,325 |  |  | $ | 138,354 |  |  | $ | 47,551 |  |  | $ | 862,230 |  |
| Accumulated impairment losses as of December 26, 2020 |  | — |  |  | (36,423) |  |  | (8,995) |  |  | (45,418) |  |
| Total |  | 676,325 |  |  | 101,931 |  |  | 38,556 |  |  | 816,812 |  |
| Changes during 2021: |  |  |  |  |  |  |  |  |
| Additions(a) |  | — |  |  | — |  |  | 40,442 |  |  | 40,442 |  |
| Currency translation |  | (4,779) |  |  | (1,542) |  |  | 137 |  |  | (6,184) |  |
| Net book value of goodwill as of June 26, 2021 |  |  |  |  |  |  |  |  |
| Gross goodwill as of June 26, 2021 |  | 671,546 |  |  | 136,699 |  |  | 88,130 |  |  | 896,375 |  |
| Accumulated impairment losses as of June 26, 2021 |  | — |  |  | (36,310) |  |  | (8,995) |  |  | (45,305) |  |
| Total |  | $ | 671,546 |  |  | $ | 100,389 |  |  | $ | 79,135 |  |  | $ | 851,070 |  |

[0000889331-21-000047:notes:56]
[same as prior period, unchanged from 0000889331-21-000034:notes:56]

[0000889331-21-000047:notes:57]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. During the second quarter of 2020, the Company recorded a non-cash charge of $33.8 million to recognize the impairment of goodwill in the automotive sensors reporting unit within the Automotive segment. The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of June 26, 2021, the automotive sensors reporting unit had $9.6 million of remaining goodwill.

[0000889331-21-000047:notes:58]
The components of other intangible assets as of June 26, 2021 and December 26, 2020 are as follows:

[0000889331-21-000047:notes:59]
|  |  |  | As of June 26, 2021 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 10,392 |  |  | $ | 2,177 |  |  | $ | 8,215 |  |
| Patents, licenses and software |  |  | 143,717 |  |  | 97,977 |  |  | 45,740 |  |
| Distribution network |  |  | 43,762 |  |  | 39,941 |  |  | 3,821 |  |
| Customer relationships, trademarks, and tradenames |  |  | 401,722 |  |  | 151,727 |  |  | 249,995 |  |
| Total |  |  | $ | 599,593 |  |  | $ | 291,822 |  |  | $ | 307,771 |  |

[0000889331-21-000047:notes:60]
[same as prior period, unchanged from 0000889331-21-000034:notes:59]

[0000889331-21-000047:notes:61]
During the three months ended June 26, 2021 and June 27, 2020, the Company recorded amortization expense of $10.6 million and $9.8 million, respectively. During the six months ended June 26, 2021 and June 27, 2020, the Company recorded amortization expense of $21.2 million and $19.8 million, respectively.

[0000889331-21-000047:notes:62]
[same as prior period, unchanged from 0000889331-21-000034:notes:61]

[0000889331-21-000047:notes:63]
During the six months ended June 26, 2021, the Company recorded additions to intangible assets of $39.7 million, related to the Hartland acquisition, the components of which were as follows:

[0000889331-21-000047:notes:64]
[same as prior period, unchanged from 0000889331-21-000034:notes:63]

[0000889331-21-000047:notes:65]
Estimated annual amortization expense related to intangible assets with definite lives as of June 26, 2021 is as follows:

[0000889331-21-000047:notes:66]
| (in thousands) | Amount |
| 2021 | $ | 41,868 |  |
| 2022 | 40,877 |  |
| 2023 | 36,569 |  |
| 2024 | 33,135 |  |
| 2025 | 32,682 |  |
| 2026 and thereafter | 143,802 |  |
| Total | $ | 328,933 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-21-000047:notes:67]
[same as prior period, unchanged from 0000889331-21-000034:notes:66]

[0000889331-21-000047:notes:68]
The components of accrued liabilities as of June 26, 2021 and December 26, 2020 are as follows:

[0000889331-21-000047:notes:69]
| (in thousands) |  | June 26, 2021 |  | December 26, 2020 |
| Employee-related liabilities |  | $ | 64,909 |  |  | $ | 50,689 |  |
| Operating lease liability |  | 8,853 |  |  | 6,811 |  |
| Other non-income taxes |  | 8,815 |  |  | 2,126 |  |
| Interest |  | 4,506 |  |  | 4,517 |  |
| Professional services |  | 2,962 |  |  | 3,321 |  |
| Deferred revenue |  | 2,444 |  |  | 2,959 |  |
| Restructuring liability |  | 1,109 |  |  | 4,195 |  |
| Customer liability |  | 790 |  |  | 3,858 |  |
| Other |  | 32,057 |  |  | 32,002 |  |
| Total |  | $ | 126,445 |  |  | $ | 110,478 |  |

[0000889331-21-000047:notes:70]
[same as prior period, unchanged from 0000889331-21-000034:notes:69]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-21-000047:notes:71]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment and other charges for the three and six months ended June 26, 2021 and June 27, 2020 as follows:

[0000889331-21-000047:notes:72]
|  | Three months ended June 26, 2021 |  | Six months ended June 26, 2021 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 295 |  |  | $ | 416 |  |  | $ | 6 |  |  | $ | 717 |  |  | $ | 552 |  |  | $ | 416 |  |  | $ | 169 |  |  | $ | 1,137 |  |
| Other restructuring charges | — |  |  | 72 |  |  | — |  |  | 72 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total restructuring charges | 295 |  |  | 488 |  |  | 6 |  |  | 789 |  |  | 552 |  |  | 505 |  |  | 169 |  |  | 1,226 |  |
| Total | $ | 295 |  |  | $ | 488 |  |  | $ | 6 |  |  | $ | 789 |  |  | $ | 552 |  |  | $ | 505 |  |  | $ | 169 |  |  | $ | 1,226 |  |

[0000889331-21-000047:notes:73]
|  | Three months ended June 27, 2020 |  | Six months ended June 27, 2020 |
| (in thousands) | Electronics |  | Automotive |  | Industrial |  | Total |  | Electronics |  | Automotive |  | Industrial |  | Total |
| Employee terminations | $ | 856 |  |  | $ | 209 |  |  | $ | 750 |  |  | $ | 1,815 |  |  | $ | 1,737 |  |  | $ | 608 |  |  | $ | 1,071 |  |  | $ | 3,416 |  |
| Other restructuring charges | (1) |  |  | (12) |  |  | 22 |  |  | 9 |  |  | — |  |  | 108 |  |  | 25 |  |  | 133 |  |
| Total restructuring charges | 855 |  |  | 197 |  |  | 772 |  |  | 1,824 |  |  | 1,737 |  |  | 716 |  |  | 1,096 |  |  | 3,549 |  |
| Impairment | — |  |  | 33,841 |  |  | — |  |  | 33,841 |  |  | — |  |  | 33,841 |  |  | 2,237 |  |  | 36,078 |  |
| Total | $ | 855 |  |  | $ | 34,038 |  |  | $ | 772 |  |  | $ | 35,665 |  |  | $ | 1,737 |  |  | $ | 34,557 |  |  | $ | 3,333 |  |  | $ | 39,627 |  |

[0000889331-21-000047:notes:74]
[same as prior period, unchanged from 0000889331-21-000034:notes:73]

[0000889331-21-000047:notes:75]
For the three and six months ended June 26, 2021, the Company recorded total restructuring charges of $0.8 million and $1.2 million, primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Automotive and Electronics segments.

[0000889331-21-000047:notes:76]
[same as prior period, unchanged from 0000889331-21-000034:notes:75]

[0000889331-21-000047:notes:77]
For the three and six months ended June 27, 2020, the Company recorded total restructuring charges of $1.8 million and $3.5 million, respectively, for employee termination costs and other restructuring charges. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions across all segments and the announced consolidation of a manufacturing facility within the Industrial segment. The Company also recognized $33.8 million and $36.1 million of impairment charges for the three and six months ended June 27, 2020, respectively, which included a $33.8 million goodwill impairment charge associated with the automotive sensors reporting unit within the Automotive segment in the second quarter of 2020 and $2.2 million related to the land and building associated with the Company’s previously announced consolidation of a manufacturing facility within the Industrial segment in the first quarter of 2020. The impairment charges of the land and building were included in selling, genera,l and administrative expenses. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the goodwill impairment charge.

[0000889331-21-000047:notes:78]
The restructuring liability as of June 26, 2021 and December 26, 2020 is $2.9 million and $4.2 million, respectively. The current portion of the total restructuring liability included within accrued liabilities is $1.1 million while the long-term balance of $1.8 million was included within other long-term liabilities, respectively, in the Condensed Consolidated Balance Sheets as of June 26, 2021. The Company anticipates the remaining payments associated with employee terminations will primarily be completed by the third quarter of 2022.


## us-gaap:DebtDisclosureTextBlock

[0000889331-21-000047:notes:79]
Debt

[0000889331-21-000047:notes:80]
The carrying amounts of debt at June 26, 2021 and December 26, 2020 are as follows:

[0000889331-21-000047:notes:81]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 130,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 139,610 |  |  | 142,679 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 115,850 |  |
| U.S. Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | 2,619 |  |  | 2,619 |  |
| Unamortized debt issuance costs |  | (3,671) |  |  | (4,114) |  |
| Total debt |  | 651,917 |  |  | 687,034 |  |
| Less: Current maturities |  | (25,000) |  |  | — |  |
| Total long-term debt |  | $ | 626,917 |  |  | $ | 687,034 |  |

[0000889331-21-000047:notes:82]
Revolving Credit Facility

[0000889331-21-000047:notes:83]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The Company made payments of $30.0 million on the amended revolving credit facility during the six months ended June 26, 2021. The balance under the facility was $100.0 million as of June 26, 2021.

[0000889331-21-000047:notes:84]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.59% at June 26, 2021.

[0000889331-21-000047:notes:85]
As of June 26, 2021, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. At June 26, 2021, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-21-000047:notes:86]
Senior Notes

[0000889331-21-000047:notes:87]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-21-000047:notes:88]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”)

[0000889331-21-000047:notes:89]
(together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-21-000047:notes:90]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-21-000047:notes:91]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-21-000047:notes:92]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At June 26, 2021, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-21-000047:notes:93]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-21-000047:notes:94]
Interest paid on all Company debt was $2.5 million and $3.4 million for the three months ended June 26, 2021 and June 27, 2020, respectively, and $8.7 million and $10.8 million for the six months ended June 26, 2021 and June 27, 2020, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-21-000047:notes:95]
[same as prior period, unchanged from 0000889331-21-000034:notes:94]

[0000889331-21-000047:notes:96]
[same as prior period, unchanged from 0000889331-21-000034:notes:95]

[0000889331-21-000047:notes:97]
[same as prior period, unchanged from 0000889331-21-000034:notes:96]

[0000889331-21-000047:notes:98]
[same as prior period, unchanged from 0000889331-21-000034:notes:97]

[0000889331-21-000047:notes:99]
[same as prior period, unchanged from 0000889331-21-000034:notes:98]

[0000889331-21-000047:notes:100]
[same as prior period, unchanged from 0000889331-21-000034:notes:99]

[0000889331-21-000047:notes:101]
[same as prior period, unchanged from 0000889331-21-000034:notes:100]

[0000889331-21-000047:notes:102]
[same as prior period, unchanged from 0000889331-21-000034:notes:101]

[0000889331-21-000047:notes:103]
[same as prior period, unchanged from 0000889331-21-000034:notes:102]

[0000889331-21-000047:notes:104]
[same as prior period, unchanged from 0000889331-21-000034:notes:103]

[0000889331-21-000047:notes:105]
[same as prior period, unchanged from 0000889331-21-000034:notes:104]

[0000889331-21-000047:notes:106]
The Company has certain convertible debt and convertible preferred stock investments that are accounted for under the cost method reflected in other assets in the Condensed Consolidated Balance Sheets. During the three and six months ended June 26, 2021, the Company impaired the remaining book value of these investments and recorded an impairment charge of $0.5 million in Other (income) expense, net in the Condensed Consolidated Statements of Net Income (Loss). As of December 26, 2020, the balances of these investments was $0.5 million. The fair value of these investments are measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy.

[0000889331-21-000047:notes:107]
[same as prior period, unchanged from 0000889331-21-000034:notes:106]

[0000889331-21-000047:notes:108]
[same as prior period, unchanged from 0000889331-21-000034:notes:107]

[0000889331-21-000047:notes:109]
There were no changes during the quarter ended June 26, 2021 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of June 26, 2021 and December 26, 2020, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-21-000047:notes:110]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of June 26, 2021:

[0000889331-21-000047:notes:111]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 25,768 |  |  | $ | — |  |  | $ | — |  |  | $ | 25,768 |  |
| Investments in equity securities |  | 27,532 |  |  | — |  |  | — |  |  | 27,532 |  |
| Mutual funds |  | 14,545 |  |  | — |  |  | — |  |  | 14,545 |  |
| Total |  | $ | 67,845 |  |  | $ | — |  |  | $ | — |  |  | $ | 67,845 |  |

[0000889331-21-000047:notes:112]
[same as prior period, unchanged from 0000889331-21-000034:notes:111]

[0000889331-21-000047:notes:113]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 73,461 |  |  | $ | — |  |  | $ | — |  |  | $ | 73,461 |  |
| Investments in equity securities |  | 19,186 |  |  | — |  |  | — |  |  | 19,186 |  |
| Mutual funds |  | 13,249 |  |  | — |  |  | — |  |  | 13,249 |  |
| Total |  | $ | 105,896 |  |  | $ | — |  |  | $ | — |  |  | $ | 105,896 |  |

[0000889331-21-000047:notes:114]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving credit facilities’ fair values approximate book value at June 26, 2021 and December 26, 2020, as the rates on these borrowings are variable in nature.

[0000889331-21-000047:notes:115]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of June 26, 2021 and December 26, 2020 were as follows:

[0000889331-21-000047:notes:116]
|  |  | June 26, 2021 |  | December 26, 2020 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 139,610 |  |  | $ | 141,709 |  |  | $ | 142,679 |  |  | $ | 144,323 |  |
| Euro Senior Notes, Series B due 2028 |  | 113,359 |  |  | 119,481 |  |  | 115,850 |  |  | 123,588 |  |
| USD Senior Notes, Series A due 2022 |  | 25,000 |  |  | 25,284 |  |  | 25,000 |  |  | 25,437 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 107,293 |  |  | 100,000 |  |  | 109,552 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 52,845 |  |  | 50,000 |  |  | 53,474 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 134,145 |  |  | 125,000 |  |  | 138,036 |  |

[0000889331-21-000047:notes:117]
The Company recognized impairment charges of $1.9 million for the land and building and $0.3 million for a certain patent as a result of the Company’s announcement to consolidate a manufacturing facility within the Industrial segment during the first quarter of 2020. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. The fair value of the land and building was valued using a real estate appraisal and classified as a Level 3 input under the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-21-000047:notes:118]
[same as prior period, unchanged from 0000889331-21-000034:notes:117]

[0000889331-21-000047:notes:119]
[same as prior period, unchanged from 0000889331-21-000034:notes:118]

[0000889331-21-000047:notes:120]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other (income) expense, net in the Condensed Consolidated Statements of Net Income (Loss). The components of net periodic benefit cost for the three and six months ended June 26, 2021 and June 27, 2020 were as follows:

[0000889331-21-000047:notes:121]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | June 26, 2021 |  | June 27, 2020 |  | June 26, 2021 |  | June 27, 2020 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 700 |  |  | $ | 592 |  |  | $ | 1,402 |  |  | $ | 1,210 |  |
| Interest cost |  | 443 |  |  | 486 |  |  | 883 |  |  | 1,144 |  |
| Expected return on plan assets |  | (371) |  |  | (402) |  |  | (738) |  |  | (1,129) |  |
| Amortization of prior service and net actuarial loss |  | 334 |  |  | 264 |  |  | 665 |  |  | 409 |  |
| Net periodic benefit cost |  | $ | 1,106 |  |  | $ | 940 |  |  | $ | 2,212 |  |  | $ | 1,634 |  |

[0000889331-21-000047:notes:122]
[same as prior period, unchanged from 0000889331-21-000034:notes:121]

[0000889331-21-000047:notes:123]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.5 million for both the three months ended June 26, 2021 and June 27, 2020, respectively, and $1.0 million expense for both the six months ended June 26, 2021 and June 27, 2020, respectively, in Cost of Sales and Other (income) expense, net within the Condensed Consolidated Statements of Net Income (Loss). For the three and six months ended June 26, 2021, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.2 million and 0.3 million. For three and six months ended June 27, 2020, the pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were $0.2 million and $0.4 million, respectively.

[0000889331-21-000047:notes:124]
On April 7, 2020, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to directly pay and administer pension payments to certain of the Company’s U.K. pension plan participants, or their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $55 million, representing approximately 37% of the total obligations 
of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company will record a one-time non-cash settlement charge currently estimated between $18 million and $22 million in the fourth quarter of 2021, reflecting the accelerated recognition of unamortized actuarial losses in the plan. The actual amount and timing of the settlement charge could differ from this estimate due to final data and plan wind-up expenses. Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million (£10.9 million) to both the net pension liability and unamortized actuarial loss within other comprehensive income (loss) during the second quarter of 2020. Additionally, the Company made a cash contribution of $10.4 million (£8.4 million) under this agreement during the second quarter of 2020.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-21-000047:notes:125]
Other Comprehensive Income (Loss)
Changes in other comprehensive income (loss) by component were as follows:

[0000889331-21-000047:notes:126]
| (in thousands) |  | Three Months EndedJune 26, 2021 |  | Three Months EndedJune 27, 2020 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 372 |  |  | $ | 43 |  |  | $ | 329 |  |  | $ | (13,098) |  |  | $ | (2,259) |  |  | $ | (10,839) |  |
| Foreign currency translation adjustments |  | 5,125 |  |  | — |  |  | 5,125 |  |  | 8,422 |  |  | — |  |  | 8,422 |  |
| Total change in other comprehensive income (loss) |  | $ | 5,497 |  |  | $ | 43 |  |  | $ | 5,454 |  |  | $ | (4,676) |  |  | $ | (2,259) |  |  | $ | (2,417) |  |
| (in thousands) |  | Six Months EndedJune 26, 2021 |  | Six Months EndedJune 27, 2020 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 878 |  |  | $ | 95 |  |  | $ | 783 |  |  | (12,543) |  |  | (2,265) |  |  | $ | (10,278) |  |
| Foreign currency translation adjustments |  | (200) |  |  | — |  |  | (200) |  |  | $ | (7,118) |  |  | $ | — |  |  | $ | (7,118) |  |
| Total change in other comprehensive income (loss) |  | $ | 678 |  |  | $ | 95 |  |  | $ | 583 |  |  | $ | (19,661) |  |  | $ | (2,265) |  |  | $ | (17,396) |  |

[0000889331-21-000047:notes:127]
Due to the signing of the group annuity contract being a significant change in the U.K. pension plan, the liabilities of the plan were remeasured as of April 6, 2020 resulting in an increase of $13.4 million to unamortized actuarial loss within other comprehensive income (loss). See Note 10, Benefits Plans for further discussion.

[0000889331-21-000047:notes:128]
The following tables set forth the changes in accumulated other comprehensive (loss) by component for the six months ended June 26, 2021 and June 27, 2020:

[0000889331-21-000047:notes:129]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive (loss) |
| Balance at December 26, 2020 |  | $ | (34,141) |  |  |  |  | $ | (57,016) |  |  | $ | (91,157) |  |
| Activity in the period |  | 783 |  |  |  |  | (200) |  |  | 583 |  |
| Balance at June 26, 2021 |  | $ | (33,358) |  |  |  |  | $ | (57,216) |  |  | $ | (90,574) |  |

[0000889331-21-000047:notes:130]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currency translation adjustment |  | Accumulated other comprehensive (loss) |
| Balance at December 28, 2019 |  | $ | (18,046) |  |  |  |  | $ | (88,777) |  |  | $ | (106,823) |  |
| Activity in the period |  | (10,278) |  |  |  |  | (7,118) |  |  | (17,396) |  |
| Balance at June 27, 2020 |  | $ | (28,324) |  |  |  |  | $ | (95,895) |  |  | $ | (124,219) |  |

[0000889331-21-000047:notes:131]
Amounts reclassified from accumulated other comprehensive (loss) to earnings for the three and six months ended June 26, 2021 and June 27, 2020 were as follows:

[0000889331-21-000047:notes:132]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 26, 2021 |  | June 27, 2020 |  | June 26, 2021 |  | June 27, 2020 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 509 |  |  | $ | 429 |  |  | $ | 1,013 |  |  | $ | 774 |  |

[0000889331-21-000047:notes:133]
[same as prior period, unchanged from 0000889331-21-000034:notes:131]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-21-000047:notes:134]
[same as prior period, unchanged from 0000889331-21-000034:notes:132]

[0000889331-21-000047:notes:135]
The effective tax rate for the three and six months ended June 26, 2021 was 13.8% and 16.7%, respectively, compared to the effective tax rate for the three and six months ended June 27, 2020 of 15.1% and 37.2%, respectively. The effective tax rate for the second quarter of 2021 (which is based upon pre-tax income) is lower than the effective tax rate for the comparable 2020 period (which is based upon a pre-tax loss), primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 as compared to 2020, as well as the impact of the goodwill impairment charge of $33.8 million recorded in the second quarter of 2020, the substantial majority of which did not result in a tax benefit. The effective tax rate for the first six months of 2021 is lower than the effective tax rate for the comparable 2020 period, primarily due to an increase in the forecasted income earned in lower tax jurisdictions in 2021 as compared to 2020, as well as the impact of the goodwill impairment charge of $33.8 million recorded in the second quarter of 2020. The effective tax rate for the 2021 periods is lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-21-000047:notes:136]
Earnings (loss) Per Share

[0000889331-21-000047:notes:137]
[same as prior period, unchanged from 0000889331-21-000034:notes:135]

[0000889331-21-000047:notes:138]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share amounts) |  | June 26, 2021 |  | June 27, 2020 |  | June 26, 2021 |  | June 27, 2020 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) as reported |  | $ | 82,095 |  |  | $ | (8,991) |  |  | $ | 139,808 |  |  | $ | 15,653 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,592 |  |  | 24,312 |  |  | 24,562 |  |  | 24,353 |  |
| Effect of dilutive securities |  | 308 |  |  | — |  |  | 332 |  |  | 167 |  |
| Diluted |  | 24,900 |  |  | 24,312 |  |  | 24,894 |  |  | 24,520 |  |
| Earnings (loss) Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share |  | $ | 3.34 |  |  | $ | (0.37) |  |  | $ | 5.69 |  |  | $ | 0.64 |  |
| Diluted earnings (loss) per share |  | $ | 3.30 |  |  | $ | (0.37) |  |  | $ | 5.62 |  |  | $ | 0.64 |  |

[0000889331-21-000047:notes:139]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 41,216 and 328,624 for the three months ended June 26, 2021 and June 27, 2020,  respectively, and 20,266 and 212,290 for the six months ended June 26, 2021 and June 27, 2020, respectively.

[0000889331-21-000047:notes:140]
[same as prior period, unchanged from 0000889331-21-000034:notes:138]

[0000889331-21-000047:notes:141]
On April 26, 2019, the Company's Board of Directors authorized a program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2019 to April 30, 2020 ("2019 program"). On April 29, 2020, the Company announced that the Board of Directors authorized a new program to repurchase up to 1,000,000 shares of the Company's common stock for the period May 1, 2020 to April 30, 2021 (the "2020 program") to replace its previous expired 2019 program. On April, 28, 2021, the Company announced that the Board of Directors authorized a new three year program to repurchase up to $300.0 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program. 
The Company did not repurchase any shares of its common stock for the three and six months ended June 26, 2021. During the six months ended June 27, 2020, the Company repurchased 175,110 shares of its common stock totaling $22.9 million.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-21-000047:notes:142]
Related Party Transactions

[0000889331-21-000047:notes:143]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-21-000047:notes:144]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-21-000047:notes:145]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-21-000047:notes:146]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-21-000047:notes:147]
|  |  | For the Three Months Ended June 26, 2021 |  | For the Three Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.7 |  | 0.1 |  | 2.8 |  |  | 0.8 |  | — |  | 1.6 |  |
|  |  | For the Six Months Ended June 26, 2021 |  | For the Six Months Ended June 27, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.2 |  | $ | — |  | $ | — |  |  | $ | 0.7 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.8 |  | 0.2 |  | 5.8 |  |  | 1.0 |  | — |  | 3.4 |  |
|  |  | June 26, 2021 |  | December 26, 2020 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | 0.1 |  | — |  | 1.8 |  |  | 0.1 |  | — |  | 0.2 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-21-000047:notes:148]
[same as prior period, unchanged from 0000889331-21-000034:notes:147]

[0000889331-21-000047:notes:149]
[same as prior period, unchanged from 0000889331-21-000034:notes:148]

[0000889331-21-000047:notes:150]
[same as prior period, unchanged from 0000889331-21-000034:notes:149]

[0000889331-21-000047:notes:151]
[same as prior period, unchanged from 0000889331-21-000034:notes:150]

[0000889331-21-000047:notes:152]
•Automotive Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-I suppliers and parts distributors in passenger car, heavy duty truck, off-road vehicles, material handling, agricultural, construction and other commercial vehicle end markets. Passenger car fuse products for internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, and high-voltage fuses. Commercial vehicle products include fuses, switches, relays, and power distribution modules used in applications serving a number of end markets, including

[0000889331-21-000047:notes:153]
heavy truck, construction, agriculture and material handling. Automotive sensor products include a wide range of automotive and commercial vehicle products designed to monitor the passenger compartment occupant's safety and environment as well as the vehicle’s powertrain.

[0000889331-21-000047:notes:154]
[same as prior period, unchanged from 0000889331-21-000034:notes:153]

[0000889331-21-000047:notes:155]
[same as prior period, unchanged from 0000889331-21-000034:notes:154]

[0000889331-21-000047:notes:156]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 26, 2021 |  | June 27, 2020 |  | June 26, 2021 |  | June 27, 2020 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 325,347 |  |  | $ | 223,271 |  |  | $ | 611,882 |  |  | $ | 437,460 |  |
| Automotive |  | 133,318 |  |  | 61,999 |  |  | 261,847 |  |  | 166,769 |  |
| Industrial |  | 64,823 |  |  | 22,067 |  |  | 113,553 |  |  | 49,204 |  |
| Total net sales |  | $ | 523,488 |  |  | $ | 307,337 |  |  | $ | 987,282 |  |  | $ | 653,433 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 15,114 |  |  | $ | 15,617 |  |  | $ | 30,495 |  |  | 31,148 |  |
| Automotive |  | 6,946 |  |  | 7,071 |  |  | 14,019 |  |  | 14,258 |  |
| Industrial |  | 2,155 |  |  | 1,046 |  |  | 3,899 |  |  | 2,130 |  |
| Total depreciation and amortization |  | $ | 24,215 |  |  | $ | 23,734 |  |  | $ | 48,413 |  |  | $ | 47,536 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 74,236 |  |  | $ | 32,651 |  |  | $ | 129,759 |  |  | $ | 64,923 |  |
| Automotive |  | 19,258 |  |  | (8,857) |  |  | 39,574 |  |  | 5,259 |  |
| Industrial |  | 8,375 |  |  | (23) |  |  | 11,881 |  |  | 3,511 |  |
| Other(a) |  | (5,612) |  |  | (35,721) |  |  | (8,476) |  |  | (40,893) |  |
| Total operating income (loss) |  | 96,257 |  |  | (11,950) |  |  | 172,738 |  |  | 32,800 |  |
| Interest expense |  | 4,626 |  |  | 5,855 |  |  | 9,299 |  |  | 11,273 |  |
| Foreign exchange (gain) loss |  | (1,676) |  |  | (6,010) |  |  | 5,161 |  |  | (3,426) |  |
| Other (income) expense, net |  | (1,890) |  |  | (1,210) |  |  | (9,627) |  |  | 39 |  |
| Income (loss) before income taxes |  | $ | 95,197 |  |  | $ | (10,585) |  |  | $ | 167,905 |  |  | $ | 24,914 |  |

[0000889331-21-000047:notes:157]
(a) Included in “Other” Operating income for the second quarter of 2021 was $3.3 million ($6.8 million year-to-date) of purchase accounting inventory step-up charges, $0.5 million ($1.3 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.8 million ($1.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a loss of $1.0 million recorded during the second quarter of 2021 for a total year-to-date gain of $0.9 million from the sale of a building within the Electronics segment.

[0000889331-21-000047:notes:158]
Included in “Other” Operating (loss) income for the 2020 second quarter is $0.1 million ($1.3 million year-to-date) of acquisition-related and integration charges related to the IXYS acquisition and other contemplated acquisitions. In addition, there was $35.6 million ($39.6 million year-to-date) of restructuring, impairment and other charges, primarily related to the goodwill impairment charge of $33.8 million recorded in the second quarter associated with the automotive sensors reporting unit within the Automotive segment, $1.8 million ($3.5 million year-to-date) of employee termination costs, and other restructuring charges and impairment charges of $2.2 million recorded in the first quarter associated with the announced consolidation of a manufacturing facility within the Industrial segment. See Note 5, Goodwill and Other Intangible Assets and Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-21-000047:notes:159]
[same as prior period, unchanged from 0000889331-21-000034:notes:158]

[0000889331-21-000047:notes:160]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 26, 2021 |  | June 27, 2020 |  | June 26, 2021 |  | June 27, 2020 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 154,797 |  |  | $ | 76,870 |  |  | $ | 285,728 |  |  | $ | 179,780 |  |
| China |  | 156,086 |  |  | 102,026 |  |  | 295,244 |  |  | 188,041 |  |
| Other countries(a) |  | 212,605 |  |  | 128,441 |  |  | 406,310 |  |  | 285,612 |  |
| Total net sales |  | $ | 523,488 |  |  | $ | 307,337 |  |  | $ | 987,282 |  |  | $ | 653,433 |  |

[0000889331-21-000047:notes:161]
[same as prior period, unchanged from 0000889331-21-000034:notes:160]

[0000889331-21-000047:notes:162]
| (in thousands) |  | June 26,2021 |  | December 26,2020 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 47,509 |  |  | $ | 46,132 |  |
| China |  | 87,497 |  |  | 85,876 |  |
| Mexico |  | 76,700 |  |  | 70,125 |  |
| Germany |  | 37,447 |  |  | 37,976 |  |
| Philippines |  | 69,308 |  |  | 66,994 |  |
| Other countries(a) |  | 34,365 |  |  | 37,075 |  |
| Total long-lived assets |  | $ | 352,826 |  |  | $ | 344,178 |  |

[0000889331-21-000047:notes:163]
[same as prior period, unchanged from 0000889331-21-000034:notes:162]

[0000889331-21-000047:notes:164]
|  |  | Six Months Ended |
| (in thousands) |  | June 26, 2021 |  | June 27, 2020 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 1,732 |  |  | $ | 2,026 |  |
| China |  | 7,127 |  |  | 4,516 |  |
| Mexico |  | 13,231 |  |  | 4,260 |  |
| Germany |  | 2,533 |  |  | 2,509 |  |
| Philippines |  | 6,941 |  |  | 9,039 |  |
| Other countries(a) |  | 1,793 |  |  | 687 |  |
| Total additions to long-lived assets |  | $ | 33,357 |  |  | $ | 23,037 |  |

[0000889331-21-000047:notes:165]
[same as prior period, unchanged from 0000889331-21-000034:notes:164]
