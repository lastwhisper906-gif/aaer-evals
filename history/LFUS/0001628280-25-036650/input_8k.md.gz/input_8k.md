# LFUS 8-K — 0001628280-25-036551 filed 2025-07-30

## item codes, every 8-K on or before 2025-07-30

- 2025-07-30 0001628280-25-036551 — 2.02, 7.01, 9.01
- 2025-05-27 0000889331-25-000109 — 5.02, 7.01, 9.01
- 2025-04-29 0000889331-25-000095 — 2.02, 7.01, 9.01
- 2025-04-28 0000889331-25-000082 — 5.02, 5.07, 9.01
- 2025-04-09 0001140361-25-012942 — 5.02, 7.01, 9.01
- 2025-01-28 0000889331-25-000013 — 2.02, 7.01, 9.01
- 2025-01-13 0001140361-25-000873 — 5.02, 9.01
- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2025-07-30

- 2025-02-27 0001140361-25-006294 — NT 10-K, for the period ended 2024-12-28
- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-036551:8k_2_02:1]
EX-99.1
2
q22025earningsreleaseex991.htm
EX-99.1

[0001628280-25-036551:8k_2_02:2]
Document

[0001628280-25-036551:8k_2_02:3]
Exhibit 99.1

[0001628280-25-036551:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0001628280-25-036551:8k_2_02:5]
LITTELFUSE REPORTS SECOND QUARTER RESULTS FOR 2025

[0001628280-25-036551:8k_2_02:6]
Second Quarter 2025 Highlights:

[0001628280-25-036551:8k_2_02:7]
(Year-over-year comparisons unless otherwise noted)

[0001628280-25-036551:8k_2_02:8]
•Net sales of $613 million, +9.8%; organic growth contributed +6.2%

[0001628280-25-036551:8k_2_02:9]
•GAAP diluted earnings per share of $2.30, +26%

[0001628280-25-036551:8k_2_02:10]
•Adjusted diluted earnings per share of $2.85, +45%

[0001628280-25-036551:8k_2_02:11]
•GAAP Operating margin of 15.1%, +340 bps; Adjusted EBITDA margin of 21.4%, +280 bps

[0001628280-25-036551:8k_2_02:12]
•YTD Cash flow from operations of $148 million and free cash flow of $115 million; YTD cash conversion of 114%

[0001628280-25-036551:8k_2_02:13]
•The Company’s Board of Directors approved a 7% increase in the quarterly cash dividend from $0.70 to $0.75; this equates to an annualized dividend of $3.00 per share

[0001628280-25-036551:8k_2_02:14]
CHICAGO, July 30, 2025  - Littelfuse, Inc. (NASDAQ: LFUS), a leader in developing smart solutions that enable safe and efficient electrical energy transfer, today reported financial results for  the second quarter ended June 28, 2025:

[0001628280-25-036551:8k_2_02:15]
“Our Q2 results exceeded our expectations, driven by solid growth and operational execution across our businesses,” said Greg Henderson, Littelfuse President and Chief Executive Officer. “We are leveraging our market leadership position and unique product portfolio as we help our customers solve their challenges around the safe and efficient transfer of electrical energy. We exited the quarter with strong bookings, and, into the third quarter, we are well positioned to drive continued growth while enhancing operational performance. We will remain focused on executing through a dynamic environment, and our strong balance sheet and cash generation will continue to support our thoughtful capital allocation strategy.”

[0001628280-25-036551:8k_2_02:16]
“We are executing on our strategic priorities outlined last quarter, with a goal of driving leading long-term shareholder returns.  Our focus on better capitalizing on future growth opportunities, providing more complete solutions to a broader set of customers, and driving operational excellence is delivering stronger growth and improved profitability.”

[0001628280-25-036551:8k_2_02:17]
-more-

[0001628280-25-036551:8k_2_02:18]
Third Quarter of 2025*

[0001628280-25-036551:8k_2_02:19]
Based on current market conditions, for the third quarter the company expects,

[0001628280-25-036551:8k_2_02:20]
•Net sales in the range of $610 - $630 million, adjusted diluted EPS in the range of $2.65 – $2.85 and an adjusted effective tax rate of 25%

[0001628280-25-036551:8k_2_02:21]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001628280-25-036551:8k_2_02:22]
Dividend

[0001628280-25-036551:8k_2_02:23]
•The company will pay a cash dividend on its common stock of $0.75 per share on September 4, 2025, to shareholders of record as of August 21, 2025

[0001628280-25-036551:8k_2_02:24]
Conference Call and Webcast Information

[0001628280-25-036551:8k_2_02:25]
Littelfuse will host a conference call on Wednesday, July 30, 2025, at 8:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0001628280-25-036551:8k_2_02:26]
About Littelfuse

[0001628280-25-036551:8k_2_02:27]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0001628280-25-036551:8k_2_02:28]
-more

[0001628280-25-036551:8k_2_02:29]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks, uncertainties and other factors include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; changes in import and export duty and tariff rates; exchange rate fluctuations; commodity price fluctuations; the effect of the Company's accounting policies; labor disputes and shortages; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; integration of acquisitions may not be achieved in a timely manner, or at all; limited realization of the expected benefits from investment and strategic plans; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for  the year ended  December 28, 2024.

[0001628280-25-036551:8k_2_02:30]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 28, 2024, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0001628280-25-036551:8k_2_02:31]
-more

[0001628280-25-036551:8k_2_02:32]
Non-GAAP Financial Measures

[0001628280-25-036551:8k_2_02:33]
The information included in this press release and other materials filed with the SEC may include the non-GAAP financial measures including organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001628280-25-036551:8k_2_02:34]
LFUS-F

[0001628280-25-036551:8k_2_02:35]
###

[0001628280-25-036551:8k_2_02:36]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-25-036551:8k_2_02:37]
LITTELFUSE, INC.

[0001628280-25-036551:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-036551:8k_2_02:39]
|  |  | (Unaudited) |  |  |
| (in thousands, except share and per share data) |  | June 28,2025 |  | December 28,2024 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 685,184 |  |  | $ | 724,924 |  |
| Short-term investments |  | 298 |  |  | 976 |  |
| Trade receivables, less allowances of $73,121 and $69,990 at June 28, 2025 and December 28, 2024, respectively |  | 363,574 |  |  | 294,371 |  |
| Inventories |  | 412,164 |  |  | 416,273 |  |
| Prepaid income taxes and income taxes receivable |  | 9,018 |  |  | 11,749 |  |
| Prepaid expenses and other current assets |  | 71,812 |  |  | 103,716 |  |
| Total current assets |  | 1,542,050 |  |  | 1,552,009 |  |
| Net property, plant, and equipment |  | 516,517 |  |  | 477,068 |  |
| Intangible assets, net of amortization |  | 474,177 |  |  | 482,118 |  |
| Goodwill |  | 1,359,422 |  |  | 1,228,502 |  |
| Investments |  | 21,602 |  |  | 23,245 |  |
| Deferred income taxes |  | 6,304 |  |  | 4,899 |  |
| Right of use lease assets |  | 89,161 |  |  | 72,211 |  |
| Other long-term assets |  | 56,648 |  |  | 51,727 |  |
| Total assets |  | $ | 4,065,881 |  |  | $ | 3,891,779 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 181,902 |  |  | $ | 188,359 |  |
| Accrued liabilities |  | 154,531 |  |  | 148,276 |  |
| Accrued income taxes |  | 25,617 |  |  | 29,658 |  |
| Current portion of long-term debt |  | 17,692 |  |  | 67,612 |  |
| Total current liabilities |  | 379,742 |  |  | 433,905 |  |
| Long-term debt, less current portion |  | 792,524 |  |  | 788,502 |  |
| Deferred income taxes |  | 103,285 |  |  | 95,532 |  |
| Accrued post-retirement benefits |  | 33,179 |  |  | 29,836 |  |
| Non-current lease liabilities |  | 75,543 |  |  | 60,559 |  |
| Other long-term liabilities |  | 82,643 |  |  | 69,833 |  |
| Total equity |  | 2,598,965 |  |  | 2,413,612 |  |
| Total liabilities and equity |  | $ | 4,065,881 |  |  | $ | 3,891,779 |  |

[0001628280-25-036551:8k_2_02:40]
LITTELFUSE, INC.

[0001628280-25-036551:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0001628280-25-036551:8k_2_02:42]
(Unaudited)

[0001628280-25-036551:8k_2_02:43]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) |  | June 28,2025 |  | June 29,2024 |  | June 28,2025 |  | June 29,2024 |
| Net sales |  | $ | 613,413 |  |  | $ | 558,489 |  |  | $ | 1,167,720 |  |  | $ | 1,093,874 |  |
| Cost of sales |  | 381,359 |  |  | 351,485 |  |  | 728,410 |  |  | 699,062 |  |
| Gross profit |  | 232,054 |  |  | 207,004 |  |  | 439,310 |  |  | 394,812 |  |
| Selling, general, and administrative expenses |  | 95,517 |  |  | 93,371 |  |  | 183,225 |  |  | 179,498 |  |
| Research and development expenses |  | 26,401 |  |  | 27,146 |  |  | 52,449 |  |  | 54,813 |  |
| Amortization of intangibles |  | 14,852 |  |  | 15,729 |  |  | 29,183 |  |  | 31,554 |  |
| Restructuring, impairment, and other charges |  | 2,506 |  |  | 5,252 |  |  | 11,525 |  |  | 8,489 |  |
| Total operating expenses |  | 139,276 |  |  | 141,498 |  |  | 276,382 |  |  | 274,354 |  |
| Operating income |  | 92,778 |  |  | 65,506 |  |  | 162,928 |  |  | 120,458 |  |
| Interest expense |  | 8,568 |  |  | 9,975 |  |  | 17,443 |  |  | 19,586 |  |
| Foreign exchange loss (gain) |  | 10,448 |  |  | (315) |  |  | 15,291 |  |  | (5,357) |  |
| Other income, net |  | (4,452) |  |  | (5,298) |  |  | (7,967) |  |  | (10,619) |  |
| Income before income taxes |  | 78,214 |  |  | 61,144 |  |  | 138,161 |  |  | 116,848 |  |
| Income taxes |  | 20,872 |  |  | 15,678 |  |  | 37,248 |  |  | 22,930 |  |
| Net income |  | $ | 57,342 |  |  | $ | 45,466 |  |  | $ | 100,913 |  |  | $ | 93,918 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.32 |  |  | $ | 1.83 |  |  | $ | 4.08 |  |  | $ | 3.78 |  |
| Diluted |  | $ | 2.30 |  |  | $ | 1.82 |  |  | $ | 4.05 |  |  | $ | 3.75 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,755 |  |  | 24,822 |  |  | 24,760 |  |  | 24,867 |  |
| Diluted |  | 24,905 |  |  | 25,030 |  |  | 24,938 |  |  | 25,075 |  |
| Comprehensive income |  | $ | 155,255 |  |  | $ | 24,399 |  |  | $ | 236,423 |  |  | $ | 42,560 |  |

[0001628280-25-036551:8k_2_02:44]
LITTELFUSE, INC.

[0001628280-25-036551:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-25-036551:8k_2_02:46]
(Unaudited)

[0001628280-25-036551:8k_2_02:47]
|  |  | Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 100,913 |  |  | $ | 93,918 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 86,758 |  |  | 73,161 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (52,635) |  |  | (36,474) |  |
| Inventories |  | 23,316 |  |  | 16,241 |  |
| Accounts payable |  | (7,001) |  |  | 6,819 |  |
| Accrued liabilities and income taxes |  | (14,425) |  |  | (28,829) |  |
| Prepaid expenses and other assets |  | 11,299 |  |  | 1,738 |  |
| Net cash provided by operating activities |  | 148,225 |  |  | 126,574 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (57,417) |  |  | — |  |
| Purchases of property, plant, and equipment |  | (32,999) |  |  | (34,674) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 712 |  |  | 7,997 |  |
| Net cash used in investing activities |  | (89,704) |  |  | (26,677) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (57,500) |  |  | (3,750) |  |
| Repurchases of common stock |  | (27,553) |  |  | (40,862) |  |
| Cash dividends paid |  | (34,677) |  |  | (32,330) |  |
| All other cash provided by financing activities |  | (813) |  |  | (2,348) |  |
| Net cash used in financing activities |  | (120,543) |  |  | (79,290) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 22,468 |  |  | (14,434) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (39,554) |  |  | 6,173 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 726,437 |  |  | 557,123 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 686,883 |  |  | $ | 563,296 |  |

[0001628280-25-036551:8k_2_02:48]
LITTELFUSE, INC.

[0001628280-25-036551:8k_2_02:49]
NET SALES AND OPERATING INCOME BY SEGMENT

[0001628280-25-036551:8k_2_02:50]
(Unaudited)

[0001628280-25-036551:8k_2_02:51]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2025 |  | 2024 |  |  |  | %Growth |  | 2025 |  | 2024 |  |  |  | %Growth |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 335,666 |  |  | $ | 305,639 |  |  |  |  | 9.8 | % |  | $ | 642,915 |  |  | $ | 596,744 |  |  |  |  | 7.7 | % |
| Transportation |  | 179,400 |  |  | 168,964 |  |  |  |  | 6.2 | % |  | 341,262 |  |  | 339,331 |  |  |  |  | 0.6 | % |
| Industrial |  | 98,347 |  |  | 83,886 |  |  |  |  | 17.2 | % |  | 183,543 |  |  | 157,799 |  |  |  |  | 16.3 | % |
| Total net sales |  | $ | 613,413 |  |  | $ | 558,489 |  |  |  |  | 9.8 | % |  | $ | 1,167,720 |  |  | $ | 1,093,874 |  |  |  |  | 6.8 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 49,861 |  |  | $ | 46,165 |  |  |  |  | 8.0 | % |  | $ | 96,627 |  |  | $ | 83,968 |  |  |  |  | 15.1 | % |
| Transportation |  | 28,074 |  |  | 15,234 |  |  |  |  | 84.3 | % |  | 46,991 |  |  | 31,440 |  |  |  |  | 49.5 | % |
| Industrial |  | 18,863 |  |  | 9,547 |  |  |  |  | 97.6 | % |  | 31,937 |  |  | 14,343 |  |  |  |  | 122.7 | % |
| Other(a) |  | (4,020) |  |  | (5,440) |  |  |  |  | N.M. |  | (12,627) |  |  | (9,293) |  |  |  |  | N.M. |
| Total operating income |  | $ | 92,778 |  |  | $ | 65,506 |  |  |  |  | 41.6 | % |  | $ | 162,928 |  |  | $ | 120,458 |  |  |  |  | 35.3 | % |
| Operating Margin |  | 15.1 | % |  | 11.7 | % |  |  |  |  |  | 14.0 | % |  | 11.0 | % |  |  |  |  |
| Interest expense |  | 8,568 |  |  | 9,975 |  |  |  |  |  |  | 17,443 |  |  | 19,586 |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 10,448 |  |  | (315) |  |  |  |  |  |  | 15,291 |  |  | (5,357) |  |  |  |  |  |
| Other income, net |  | (4,452) |  |  | (5,298) |  |  |  |  |  |  | (7,967) |  |  | (10,619) |  |  |  |  |  |
| Income before income taxes |  | $ | 78,214 |  |  | $ | 61,144 |  |  |  |  | 27.9 | % |  | $ | 138,161 |  |  | $ | 116,848 |  |  |  |  | 18.2 | % |

[0001628280-25-036551:8k_2_02:52]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0001628280-25-036551:8k_2_02:53]
N.M. - Not meaningful

[0001628280-25-036551:8k_2_02:54]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2025 |  | 2024 |  | %(Decline)/Growth |  | 2025 |  | 2024 |  | %Growth |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 14.9 | % |  | 15.1 | % |  | (0.2) | % |  | 15.0 | % |  | 14.1 | % |  | 0.9 | % |
| Transportation |  | 15.6 | % |  | 9.0 | % |  | 6.6 | % |  | 13.8 | % |  | 9.3 | % |  | 4.5 | % |
| Industrial |  | 19.2 | % |  | 11.4 | % |  | 7.8 | % |  | 17.4 | % |  | 9.1 | % |  | 8.3 | % |

[0001628280-25-036551:8k_2_02:55]
LITTELFUSE, INC.

[0001628280-25-036551:8k_2_02:56]
SUPPLEMENTAL FINANCIAL INFORMATION

[0001628280-25-036551:8k_2_02:57]
(In millions of USD except per share amounts - unaudited)

[0001628280-25-036551:8k_2_02:58]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-25 |  | Q2-24 |  | YTD-25 |  | YTD-24 |
| GAAP diluted EPS |  | $ | 2.30 |  |  | $ | 1.82 |  |  | $ | 4.05 |  |  | $ | 3.75 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.55 |  |  | 0.15 |  |  | 0.99 |  |  | (0.02) |  |
| Adjusted diluted EPS |  | $ | 2.85 |  |  | $ | 1.97 |  |  | $ | 5.04 |  |  | $ | 3.73 |  |

[0001628280-25-036551:8k_2_02:59]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q2-25 |  | Q2-24 |  | YTD-25 |  | YTD-24 |
| Acquisition-related and integration costs (a) |  | $ | 1.5 |  |  | $ | 0.8 |  |  | $ | 1.6 |  |  | $ | 1.8 |  |
| Purchase accounting inventory adjustments (b) |  | — |  |  | — |  |  | (0.5) |  |  | — |  |
| Restructuring, impairment and other charges (c) |  | 2.5 |  |  | 5.3 |  |  | 11.5 |  |  | 8.5 |  |
| Gain on sale of fixed assets (d) |  | — |  |  | (0.7) |  |  | — |  |  | (1.0) |  |
| Non-GAAP adjustments to operating income |  | 4.0 |  |  | 5.4 |  |  | 12.6 |  |  | 9.3 |  |
| Other income, net (e) |  | — |  |  | (0.5) |  |  | — |  |  | (0.3) |  |
| Non-operating foreign exchange loss (gain) |  | 10.4 |  |  | (0.3) |  |  | 15.3 |  |  | (5.4) |  |
| Non-GAAP adjustments to income before income taxes |  | 14.4 |  |  | 4.6 |  |  | 27.9 |  |  | 3.6 |  |
| Income taxes (f) |  | 0.8 |  |  | 0.7 |  |  | 3.2 |  |  | 4.1 |  |
| Non-GAAP adjustments to net income |  | $ | 13.6 |  |  | $ | 3.9 |  |  | $ | 24.7 |  |  | $ | (0.5) |  |
| Total EPS impact |  | $ | 0.55 |  |  | $ | 0.15 |  |  | $ | 0.99 |  |  | $ | (0.02) |  |

[0001628280-25-036551:8k_2_02:60]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-25 |  | Q2-24 |  | YTD-25 |  | YTD-24 |
| Net income |  | $ | 57.3 |  |  | $ | 45.5 |  |  | $ | 100.9 |  |  | $ | 93.9 |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 20.9 |  |  | 15.7 |  |  | 37.2 |  |  | 22.9 |  |
| Interest expense |  | 8.6 |  |  | 10.0 |  |  | 17.4 |  |  | 19.6 |  |
| Foreign exchange loss (gain) |  | 10.4 |  |  | (0.3) |  |  | 15.3 |  |  | (5.4) |  |
| Other income, net |  | (4.5) |  |  | (5.3) |  |  | (8.0) |  |  | (10.6) |  |
| GAAP operating income |  | $ | 92.8 |  |  | $ | 65.5 |  |  | $ | 162.9 |  |  | $ | 120.5 |  |
| Non-GAAP adjustments to operating income |  | 4.0 |  |  | 5.4 |  |  | 12.6 |  |  | 9.3 |  |
| Adjusted operating income |  | $ | 96.8 |  |  | $ | 70.9 |  |  | $ | 175.5 |  |  | $ | 129.8 |  |
| Amortization of intangibles |  | 14.9 |  |  | 15.7 |  |  | 29.2 |  |  | 31.6 |  |
| Depreciation expense |  | 19.4 |  |  | 17.1 |  |  | 37.8 |  |  | 33.7 |  |
| Adjusted EBITDA |  | $ | 131.1 |  |  | $ | 103.7 |  |  | $ | 242.5 |  |  | $ | 195.0 |  |
| Net sales |  | $ | 613.4 |  |  | $ | 558.5 |  |  | $ | 1,167.7 |  |  | $ | 1,093.9 |  |
| Net income as a percentage of net sales |  | 9.3 | % |  | 8.1 | % |  | 8.6 | % |  | 8.6 | % |
| Operating margin |  | 15.1 | % |  | 11.7 | % |  | 14.0 | % |  | 11.0 | % |
| Adjusted operating margin |  | 15.8 | % |  | 12.7 | % |  | 15.0 | % |  | 11.9 | % |
| Adjusted EBITDA margin |  | 21.4 | % |  | 18.6 | % |  | 20.8 | % |  | 17.8 | % |

[0001628280-25-036551:8k_2_02:61]
| Adjusted EBITDA by Segment |  | Q2-25 |  | Q2-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 49.9 |  |  | $ | 28.1 |  |  | $ | 18.8 |  |  | $ | 46.2 |  |  | $ | 15.2 |  |  | $ | 9.5 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 10.1 |  |  | 3.4 |  |  | 1.4 |  |  | 9.8 |  |  | 3.3 |  |  | 2.6 |  |
| Add back depreciation |  | 12.6 |  |  | 5.3 |  |  | 1.5 |  |  | 10.0 |  |  | 5.8 |  |  | 1.3 |  |
| Adjusted EBITDA |  | $ | 72.6 |  |  | $ | 36.8 |  |  | $ | 21.7 |  |  | $ | 66.0 |  |  | $ | 24.3 |  |  | $ | 13.4 |  |
| Adjusted EBITDA Margin |  | 21.6 | % |  | 20.5 | % |  | 22.1 | % |  | 21.6 | % |  | 14.4 | % |  | 16.0 | % |

[0001628280-25-036551:8k_2_02:62]
| Adjusted EBITDA by Segment |  | YTD-25 |  | YTD-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 96.6 |  |  | $ | 47.0 |  |  | $ | 31.9 |  |  | $ | 84.0 |  |  | $ | 31.4 |  |  | $ | 14.3 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 19.9 |  |  | 6.8 |  |  | 2.5 |  |  | 19.7 |  |  | 6.8 |  |  | 5.1 |  |
| Add back depreciation |  | 24.0 |  |  | 10.8 |  |  | 3.0 |  |  | 19.9 |  |  | 11.0 |  |  | 2.8 |  |
| Adjusted EBITDA |  | $ | 140.5 |  |  | $ | 64.6 |  |  | $ | 37.4 |  |  | $ | 123.6 |  |  | $ | 49.2 |  |  | $ | 22.2 |  |
| Adjusted EBITDA Margin |  | 21.8 | % |  | 18.9 | % |  | 20.4 | % |  | 20.7 | % |  | 14.5 | % |  | 14.1 | % |

[0001628280-25-036551:8k_2_02:63]
| Net sales reconciliation |  | Q2-25 vs. Q2-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 10 | % |  | 6 | % |  | 17 | % |  | 10 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | — | % |  | — | % |  | 2 | % |
| FX impact |  | 1 | % |  | 2 | % |  | — | % |  | 1 | % |
| Organic net sales growth |  | 4 | % |  | 4 | % |  | 17 | % |  | 6 | % |

[0001628280-25-036551:8k_2_02:64]
| Net sales reconciliation |  | YTD-25 vs. YTD-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 8 | % |  | 1 | % |  | 16 | % |  | 7 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | — | % |  | — | % |  | 2 | % |
| FX impact |  | — | % |  | 1 | % |  | (1) | % |  | — | % |
| Organic net sales growth |  | 4 | % |  | — | % |  | 17 | % |  | 5 | % |

[0001628280-25-036551:8k_2_02:65]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-25 |  | Q2-24 |  | YTD-25 |  | YTD-24 |
| Income taxes |  | $ | 20.9 |  |  | $ | 15.7 |  |  | $ | 37.2 |  |  | $ | 22.9 |  |
| Effective rate |  | 26.7 | % |  | 25.6 | % |  | 27.0 | % |  | 19.6 | % |
| Non-GAAP adjustments - income taxes |  | 0.8 |  |  | 0.7 |  |  | 3.2 |  |  | 4.1 |  |
| Adjusted income taxes |  | $ | 21.7 |  |  | $ | 16.4 |  |  | $ | 40.4 |  |  | $ | 27.0 |  |
| Adjusted effective rate |  | 23.4 | % |  | 25.0 | % |  | 24.4 | % |  | 22.4 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-25 |  | Q2-24 |  | YTD-25 |  | YTD-24 |
| Net cash provided by operating activities |  | $ | 82.5 |  |  | $ | 69.4 |  |  | $ | 148.2 |  |  | $ | 126.6 |  |
| Less: Purchases of property, plant and equipment |  | (9.9) |  |  | (19.1) |  |  | (33.0) |  |  | (34.7) |  |
| Free cash flow |  | $ | 72.6 |  |  | $ | 50.3 |  |  | $ | 115.2 |  |  | $ | 91.9 |  |

[0001628280-25-036551:8k_2_02:66]
| Consolidated Total Debt |  | As of June 28, 2025 |
| Consolidated Total Debt |  | $ | 810.2 |  |
| Unamortized debt issuance costs |  | 2.3 |  |
| Finance lease liability |  | 0.2 |  |
| Consolidated funded indebtedness |  | 812.7 |  |
| Cash held in U.S. (up to $400 million) |  | 265.1 |
| Net debt |  | $ | 547.6 |  |
| Consolidated EBITDA |  | Twelve Months Ended June 28, 2025 |
| Net Income |  | $ | 106.9 |  |
| Interest expense |  | 36.6 |  |
| Income taxes |  | 66.0 |  |
| Depreciation |  | 72.4 |  |
| Amortization |  | 59.8 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 22.6 |  |
| Unrealized loss on investments |  | 0.7 |  |
| Impairment charges |  | 92.7 |  |
| Other |  | 25.3 |  |
| Consolidated EBITDA (1) |  | $ | 483.0 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.1x |

[0001628280-25-036551:8k_2_02:67]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2025 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0001628280-25-036551:8k_2_02:68]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0001628280-25-036551:8k_2_02:69]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0001628280-25-036551:8k_2_02:70]
Note: Total will not always foot due to rounding.

[0001628280-25-036551:8k_2_02:71]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0001628280-25-036551:8k_2_02:72]
(b) reflected in cost of sales.

[0001628280-25-036551:8k_2_02:73]
(c) reflected in restructuring, impairment and other charges.

[0001628280-25-036551:8k_2_02:74]
(d) 2024 amount reflected a gain of $0.7 million ($1.0 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0001628280-25-036551:8k_2_02:75]
(e) Q2 2024 included a reversal of $0.5 million for an asset retirement obligation charge related the disposal of a business in 2019. 2024 year-to-date amount reflected $0.2 million increase in coal mining reserves.

[0001628280-25-036551:8k_2_02:76]
(f) reflected the tax impact associated with the non-GAAP adjustments.

[0001628280-25-036551:8k_2_02:77]
###
