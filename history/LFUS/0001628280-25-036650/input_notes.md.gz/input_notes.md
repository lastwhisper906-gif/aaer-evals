# LFUS notes — 0001628280-25-036650


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-036650:notes:1]
Subsequent Events


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-25-036650:notes:2]
[same as prior period, unchanged from 0000889331-25-000099:notes:1]

[0001628280-25-036650:notes:3]
[same as prior period, unchanged from 0000889331-25-000099:notes:2]

[0001628280-25-036650:notes:4]
[same as prior period, unchanged from 0000889331-25-000099:notes:3]

[0001628280-25-036650:notes:5]
[same as prior period, unchanged from 0000889331-25-000099:notes:4]

[0001628280-25-036650:notes:6]
[same as prior period, unchanged from 0000889331-25-000099:notes:5]

[0001628280-25-036650:notes:7]
[same as prior period, unchanged from 0000889331-25-000099:notes:6]

[0001628280-25-036650:notes:8]
[same as prior period, unchanged from 0000889331-25-000099:notes:7]

[0001628280-25-036650:notes:9]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 28, 2025 and June 29, 2024:

[0001628280-25-036650:notes:10]
|  |  | Three Months Ended June 28, 2025 |  | Six Months Ended June 28, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 166,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 166,967 |  |  | $ | 325,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,256 |  |
| Electronics – Passive Products and Sensors |  | 168,699 |  |  | — |  |  | — |  |  | 168,699 |  |  | 317,659 |  |  | — |  |  | — |  |  | 317,659 |  |
| Commercial Vehicle Products |  | — |  |  | 86,260 |  |  | — |  |  | 86,260 |  |  | — |  |  | 164,029 |  |  | — |  |  | 164,029 |  |
| Passenger Car Products |  | — |  |  | 76,151 |  |  | — |  |  | 76,151 |  |  | — |  |  | 145,186 |  |  | — |  |  | 145,186 |  |
| Automotive Sensors |  | — |  |  | 16,989 |  |  | — |  |  | 16,989 |  |  | — |  |  | 32,047 |  |  | — |  |  | 32,047 |  |
| Industrial Products |  | — |  |  | — |  |  | 98,347 |  |  | 98,347 |  |  | — |  |  | — |  |  | 183,543 |  |  | 183,543 |  |
| Total |  | $ | 335,666 |  |  | $ | 179,400 |  |  | $ | 98,347 |  |  | $ | 613,413 |  |  | $ | 642,915 |  |  | $ | 341,262 |  |  | $ | 183,543 |  |  | $ | 1,167,720 |  |

[0001628280-25-036650:notes:11]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  |  |  |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

[0001628280-25-036650:notes:12]
[same as prior period, unchanged from 0000889331-25-000099:notes:11]

[0001628280-25-036650:notes:13]
[same as prior period, unchanged from 0000889331-25-000099:notes:12]

[0001628280-25-036650:notes:14]
[same as prior period, unchanged from 0000889331-25-000099:notes:13]

[0001628280-25-036650:notes:15]
[same as prior period, unchanged from 0000889331-25-000099:notes:14]

[0001628280-25-036650:notes:16]
[same as prior period, unchanged from 0000889331-25-000099:notes:15]

[0001628280-25-036650:notes:17]
[same as prior period, unchanged from 0000889331-25-000099:notes:16]

[0001628280-25-036650:notes:18]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on

[0001628280-25-036650:notes:19]
historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0001628280-25-036650:notes:20]
[same as prior period, unchanged from 0000889331-25-000099:notes:18]

[0001628280-25-036650:notes:21]
[same as prior period, unchanged from 0000889331-25-000099:notes:19]

[0001628280-25-036650:notes:22]
[same as prior period, unchanged from 0000889331-25-000099:notes:20]

[0001628280-25-036650:notes:23]
[same as prior period, unchanged from 0000889331-25-000099:notes:21]

[0001628280-25-036650:notes:24]
[same as prior period, unchanged from 0000889331-25-000099:notes:22]

[0001628280-25-036650:notes:25]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at June 28, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0001628280-25-036650:notes:26]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 685,184 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,699 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 686,883 |  |  | $ | 726,437 |  |

[0001628280-25-036650:notes:27]
Recently Issued Accounting Standards

[0001628280-25-036650:notes:28]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.

[0001628280-25-036650:notes:29]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify disclosures in the Company's Consolidated Financial Statements.

[0001628280-25-036650:notes:30]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may

[0001628280-25-036650:notes:31]
be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-25-036650:notes:32]
[same as prior period, unchanged from 0000889331-25-000099:notes:29]

[0001628280-25-036650:notes:33]
[same as prior period, unchanged from 0000889331-25-000099:notes:30]

[0001628280-25-036650:notes:34]
[same as prior period, unchanged from 0000889331-25-000099:notes:31]

[0001628280-25-036650:notes:35]
[same as prior period, unchanged from 0000889331-25-000099:notes:32]

[0001628280-25-036650:notes:36]
[same as prior period, unchanged from 0000889331-25-000099:notes:33]

[0001628280-25-036650:notes:37]
[same as prior period, unchanged from 0000889331-25-000099:notes:34]

[0001628280-25-036650:notes:38]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 95,942 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables | 5,985 |  |
| Inventories | 6,600 |  |
| Other current assets | 8,278 |  |
| Property, plant, and equipment | 30,132 |  |
| Intangible assets | 1,800 |  |
| Goodwill | 57,534 |  |
| Other long-term assets | 8,579 |  |
| Current liabilities | (7,464) |  |
| Other long-term liabilities | (15,502) |  |
|  | $ | 95,942 |  |

[0001628280-25-036650:notes:39]
All Dortmund Fab assets and liabilities were recorded in the Electronics segment and are primarily reflected in the Europe geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Dortmund Fab’s products and technology with the Company’s existing semiconductor products portfolio. Goodwill resulting from the Dortmund Fab acquisition is expected to be deductible for tax purposes.

[0001628280-25-036650:notes:40]
During the three months ended June 28, 2025, the Company recorded measurement period adjustments to decrease other current assets of $0.2 million and deferred tax liability of $0.1 million. As a result of these adjustments, goodwill was increased by $0.1 million accordingly. In addition, the Company made a reclassification adjustment of $0.8 million between current liabilities and other long-term liabilities. The total impact of the adjustment to Cost of sales was $0.2 million in the three months ended June 28, 2025.

[0001628280-25-036650:notes:41]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three and six months ended June 28, 2025 were net sales of $13.4 million and $23.5 million, respectively, and loss before income taxes was $2.5 million and $2.4 million, respectively, since the December 31, 2024 acquisition of Dortmund Fab.

[0001628280-25-036650:notes:42]
As required by purchase accounting guidance, the Company recorded a $0.5 million step-down of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-down was fully amortized as a non-cash credit to cost of sales during the first fiscal quarter of 2025 as the acquired inventory was sold and reflected as other non-segment costs.

[0001628280-25-036650:notes:43]
During the six months ended June 29, 2024, the Company incurred approximately $0.1 million of legal and professional fees related to the Dortmund Fab acquisition recognized as Selling, general, and administrative expenses in the Condensed Consolidated Statements of Net Income. A total of $3.5 million of legal and professional fees related to the Dortmund Fab acquisition was recognized since 2023. These costs were reflected as other non-segment costs.

[0001628280-25-036650:notes:44]
[same as prior period, unchanged from 0000889331-25-000099:notes:40]

[0001628280-25-036650:notes:45]
[same as prior period, unchanged from 0000889331-25-000099:notes:41]

[0001628280-25-036650:notes:46]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands, except per share amounts) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Net sales |  | $ | 613,413 |  |  | $ | 570,489 |  |  | $ | 1,167,720 |  |  | $ | 1,117,390 |  |
| Income before income taxes |  | 78,214 |  |  | 62,323 |  |  | 137,620 |  |  | 119,333 |  |
| Net income |  | 57,342 |  |  | 46,272 |  |  | 100,534 |  |  | 95,637 |  |
| Net income per share — basic |  | 2.32 |  |  | 1.86 |  |  | 4.06 |  |  | 3.85 |  |
| Net income per share — diluted |  | 2.30 |  |  | 1.85 |  |  | 4.03 |  |  | 3.81 |  |

[0001628280-25-036650:notes:47]
[same as prior period, unchanged from 0000889331-25-000099:notes:43]

[0001628280-25-036650:notes:48]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Amortization of unfavorable production contract (a) |  | $ | — |  |  | $ | 567 |  |  | $ | — |  |  | $ | 1,135 |  |
| Amortization of inventory step-down (b) |  | — |  |  | — |  |  | (504) |  |  | 510 |  |
| Depreciation |  | — |  |  | (274) |  |  | — |  |  | (549) |  |
| Amortization (c) |  | — |  |  | (94) |  |  | — |  |  | (188) |  |
| Transaction costs (d) |  | — |  |  | 16 |  |  | (37) |  |  | (380) |  |
| Income tax (expense) benefit of above items |  | — |  |  | (65) |  |  | 162 |  |  | (158) |  |

[0001628280-25-036650:notes:49]
(a) The amortization of the unfavorable production contract during the three and six months ended June 29, 2024 results from the fair value assigned to the unfavorable production contract liability that is amortized over four years.

[0001628280-25-036650:notes:50]
(b) The amortization of the inventory step-down adjustment reflects the reversal of the amount recognized during the six months ended June 28, 2025, and the recognition of the amortization during the six months ended June 29, 2024. The inventory step-down was fully amortized over two months as the inventory was sold.

[0001628280-25-036650:notes:51]
(c) The amortization adjustment for the three and six months ended June 29, 2024 primarily reflects amortization resulting from the measurement of intangibles at their fair values.

[0001628280-25-036650:notes:52]
(d) The transaction costs adjustment reflects certain legal and professional fees for the six months ended June 28, 2025 and three and six months ended June 29, 2024, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-25-036650:notes:53]
[same as prior period, unchanged from 0000889331-25-000099:notes:49]

[0001628280-25-036650:notes:54]
The components of inventories at June 28, 2025 and December 28, 2024 were as follows:

[0001628280-25-036650:notes:55]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Raw materials |  | $ | 186,682 |  |  | $ | 193,788 |  |
| Work in process |  | 131,501 |  |  | 115,497 |  |
| Finished goods |  | 173,332 |  |  | 173,513 |  |
| Inventory reserves |  | (79,351) |  |  | (66,525) |  |
| Total |  | $ | 412,164 |  |  | $ | 416,273 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-25-036650:notes:56]
[same as prior period, unchanged from 0000889331-25-000099:notes:52]

[0001628280-25-036650:notes:57]
The components of net property, plant, and equipment at June 28, 2025 and December 28, 2024 were as follows:

[0001628280-25-036650:notes:58]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Land and land improvements |  | $ | 18,932 |  |  | $ | 17,593 |  |
| Building and building improvements |  | 206,941 |  |  | 192,441 |  |
| Machinery and equipment |  | 960,156 |  |  | 892,940 |  |
| Accumulated depreciation and amortization |  | (669,512) |  |  | (625,906) |  |
| Total |  | $ | 516,517 |  |  | $ | 477,068 |  |

[0001628280-25-036650:notes:59]
The Company recorded depreciation expense of $19.4 million and $17.1 million for the three months ended June 28, 2025 and June 29, 2024, respectively, and $37.8 million and $33.7 million for the six months ended June 28, 2025 and June 29, 2024, respectively, in Cost of sales, Selling, general, and administrative expenses, and Research and development expenses in the Condensed Consolidated Statements of Net Income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-036650:notes:60]
[same as prior period, unchanged from 0000889331-25-000099:notes:56]

[0001628280-25-036650:notes:61]
The amounts for goodwill and changes in the carrying value of goodwill by segment for the six months ended June 28, 2025 were as follows:

[0001628280-25-036650:notes:62]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net goodwill as of December 28, 2024 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 28, 2024 |  | $ | 906,871 |  |  | $ | 233,286 |  |  | $ | 173,882 |  |  | $ | 1,314,039 |  |
| Accumulated impairment losses as of December 28, 2024 |  | — |  |  | (41,645) |  |  | (43,892) |  |  | (85,537) |  |
| Total |  | 906,871 |  |  | 191,641 |  |  | 129,990 |  |  | 1,228,502 |  |
| Changes during 2025: |  |  |  |  |  |  |  |  |
| Additions (a) |  | 57,534 |  |  | — |  |  | — |  |  | 57,534 |  |
| Foreign currency translation adjustments |  | 60,344 |  |  | 6,206 |  |  | 6,836 |  |  | 73,386 |  |
| Net goodwill as of June 28, 2025 |  |  |  |  |  |  |  |  |
| Gross goodwill as of June 28, 2025 |  | 1,024,749 |  |  | 242,438 |  |  | 185,578 |  |  | 1,452,765 |  |
| Accumulated impairment losses as of June 28, 2025 |  | — |  |  | (44,591) |  |  | (48,752) |  |  | (93,343) |  |
| Total |  | $ | 1,024,749 |  |  | $ | 197,847 |  |  | $ | 136,826 |  |  | $ | 1,359,422 |  |

[0001628280-25-036650:notes:63]
[same as prior period, unchanged from 0000889331-25-000099:notes:59]

[0001628280-25-036650:notes:64]
The components of intangible assets as of June 28, 2025 and December 28, 2024 were as follows:

[0001628280-25-036650:notes:65]
|  |  |  | As of June 28, 2025 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 16,378 |  |  | $ | 3,298 |  |  | $ | 13,080 |  |
| Patents, licenses, and software |  |  | 275,154 |  |  | 200,842 |  |  | 74,312 |  |
| Distribution network |  |  | 42,342 |  |  | 42,342 |  |  | — |  |
| Customer relationships, trademarks, and tradenames |  |  | 658,608 |  |  | 271,823 |  |  | 386,785 |  |
| Total |  |  | $ | 992,482 |  |  | $ | 518,305 |  |  | $ | 474,177 |  |

[0001628280-25-036650:notes:66]
[same as prior period, unchanged from 0000889331-25-000099:notes:62]

[0001628280-25-036650:notes:67]
During the three months ended June 28, 2025 and June 29, 2024, the Company recorded amortization expense of $14.9 million and $15.7 million, respectively. During the six months ended June 28, 2025 and June 29, 2024, the Company recorded amortization expense of $29.2 million and $31.6 million, respectively.

[0001628280-25-036650:notes:68]
During the six months ended June 28, 2025, the Company recorded additions to intangible assets of $1.8 million related to the Dortmund Fab acquisition, the components of which were as follows:

[0001628280-25-036650:notes:69]
[same as prior period, unchanged from 0000889331-25-000099:notes:65]

[0001628280-25-036650:notes:70]
Estimated annual amortization expense related to intangible assets with definite lives as of June 28, 2025 was as follows:

[0001628280-25-036650:notes:71]
| (in thousands) | Amount |
| Remainder of 2025 | $ | 30,022 |  |
| 2026 | 48,788 |  |
| 2027 | 46,611 |  |
| 2028 | 46,208 |  |
| 2029 | 45,798 |  |
| 2030 and thereafter | 256,750 |  |
| Total | $ | 474,177 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001628280-25-036650:notes:72]
[same as prior period, unchanged from 0000889331-25-000099:notes:68]

[0001628280-25-036650:notes:73]
The components of accrued liabilities as of June 28, 2025 and December 28, 2024 were as follows:

[0001628280-25-036650:notes:74]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Employee-related liabilities |  | $ | 77,625 |  |  | $ | 67,639 |  |
| Current lease liability |  | 10,981 |  |  | 13,900 |  |
| Other non-income taxes |  | 7,736 |  |  | 7,022 |  |
| Interest |  | 7,391 |  |  | 8,131 |  |
| Professional services |  | 5,138 |  |  | 6,613 |  |
| Restructuring liability |  | 4,707 |  |  | 4,624 |  |
| Other customer reserves |  | 3,666 |  |  | 3,450 |  |
| Deferred revenue |  | 3,005 |  |  | 1,557 |  |
| Current benefit liability |  | 1,514 |  |  | 1,514 |  |
| Current hedge liability |  | 36 |  |  | 4,067 |  |
| Other |  | 32,732 |  |  | 29,759 |  |
| Total |  | $ | 154,531 |  |  | $ | 148,276 |  |

[0001628280-25-036650:notes:75]
[same as prior period, unchanged from 0000889331-25-000099:notes:71]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001628280-25-036650:notes:76]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for the three and six months ended June 28, 2025 and June 29, 2024 as follows:

[0001628280-25-036650:notes:77]
|  | Three Months Ended June 28, 2025 |  | Six Months Ended June 28, 2025 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 1,100 |  |  | $ | 1,350 |  |  | $ | 24 |  |  | $ | 2,474 |  |  | $ | 5,904 |  |  | $ | 4,482 |  |  | $ | 436 |  |  | $ | 10,822 |  |
| Other restructuring charges | 7 |  |  | 25 |  |  | — |  |  | 32 |  |  | 518 |  |  | 48 |  |  | 1 |  |  | 567 |  |
| Total restructuring charges | 1,107 |  |  | 1,375 |  |  | 24 |  |  | 2,506 |  |  | 6,422 |  |  | 4,530 |  |  | 437 |  |  | 11,389 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | 136 |  |  | — |  |  | — |  |  | 136 |  |
| Total | $ | 1,107 |  |  | $ | 1,375 |  |  | $ | 24 |  |  | $ | 2,506 |  |  | $ | 6,558 |  |  | $ | 4,530 |  |  | $ | 437 |  |  | $ | 11,525 |  |

[0001628280-25-036650:notes:78]
|  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 4,501 |  |  | $ | 437 |  |  | $ | 5 |  |  | $ | 4,943 |  |  | $ | 5,105 |  |  | $ | 1,591 |  |  | $ | 416 |  |  | $ | 7,112 |  |
| Other restructuring charges | 87 |  |  | 209 |  |  | 13 |  |  | 309 |  |  | 139 |  |  | 287 |  |  | 18 |  |  | 444 |  |
| Total restructuring charges | 4,588 |  |  | 646 |  |  | 18 |  |  | 5,252 |  |  | 5,244 |  |  | 1,878 |  |  | 434 |  |  | 7,556 |  |
| Impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 933 |  |  | — |  |  | 933 |  |
| Total | $ | 4,588 |  |  | $ | 646 |  |  | $ | 18 |  |  | $ | 5,252 |  |  | $ | 5,244 |  |  | $ | 2,811 |  |  | $ | 434 |  |  | $ | 8,489 |  |

[0001628280-25-036650:notes:79]
[same as prior period, unchanged from 0000889331-25-000099:notes:75]

[0001628280-25-036650:notes:80]
For the three and six months ended June 28, 2025, the Company recorded total restructuring charges of $2.5 million and $11.4 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and corporate support functions across all businesses within the Transportation segment and for the semiconductor business within the Electronics segment. In addition, during the first fiscal quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment.

[0001628280-25-036650:notes:81]
[same as prior period, unchanged from 0000889331-25-000099:notes:77]

[0001628280-25-036650:notes:82]
For the three and six months ended June 29, 2024, the Company recorded total restructuring charges of $5.3 million and $7.6 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the semiconductor business in the Electronics segment and the reorganization of certain selling and administrative functions within the commercial vehicle business in the Transportation segment. In addition, during the first fiscal quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0001628280-25-036650:notes:83]
The restructuring reserves as of June 28, 2025 and December 28, 2024 were $5.0 million and $4.6 million, respectively. The restructuring liability as of June 28, 2025 was $4.7 million included within Accrued liabilities and $0.3 million within Other long-term liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed during fiscal year 2025.


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-036650:notes:84]
Debt

[0001628280-25-036650:notes:85]
The carrying amounts of debt at June 28, 2025 and December 28, 2024 were as follows:

[0001628280-25-036650:notes:86]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 273,750 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,079 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 2,692 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,305) |  |  | (2,766) |  |
| Total debt |  | 810,216 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,692) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 792,524 |  |  | $ | 788,502 |  |

[0001628280-25-036650:notes:87]
Revolving Credit Facility and Term Loan

[0001628280-25-036650:notes:88]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-25-036650:notes:89]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-25-036650:notes:90]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended June 28, 2025, the Company made term loan payments of $3.8 million and $7.5 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $273.8 million, respectively, as of June 28, 2025.

[0001628280-25-036650:notes:91]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0001628280-25-036650:notes:92]
As of June 28, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.68%, and 4.13% on the hedged portion.

[0001628280-25-036650:notes:93]
As of June 28, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of June 28, 2025, the Company was in compliance with all covenants under the Credit Agreement.

[0001628280-25-036650:notes:94]
Senior Notes

[0001628280-25-036650:notes:95]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-25-036650:notes:96]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-25-036650:notes:97]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0001628280-25-036650:notes:98]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-25-036650:notes:99]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-25-036650:notes:100]
The Senior Notes have not been registered under the Securities Act of 1933 ("Securities Act"), or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001628280-25-036650:notes:101]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of June 28, 2025, the Company was in compliance with all covenants under the Senior Notes.

[0001628280-25-036650:notes:102]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001628280-25-036650:notes:103]
Interest paid on all Company debt was $5.6 million and $6.4 million for the three months ended June 28, 2025 and June 29, 2024, respectively, and $17.8 million and $19.6 million for the six months ended June 28, 2025 and June 29, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-036650:notes:104]
[same as prior period, unchanged from 0000889331-25-000099:notes:101]

[0001628280-25-036650:notes:105]
[same as prior period, unchanged from 0000889331-25-000099:notes:102]

[0001628280-25-036650:notes:106]
[same as prior period, unchanged from 0000889331-25-000099:notes:103]

[0001628280-25-036650:notes:107]
[same as prior period, unchanged from 0000889331-25-000099:notes:104]

[0001628280-25-036650:notes:108]
[same as prior period, unchanged from 0000889331-25-000099:notes:105]

[0001628280-25-036650:notes:109]
[same as prior period, unchanged from 0000889331-25-000099:notes:106]

[0001628280-25-036650:notes:110]
[same as prior period, unchanged from 0000889331-25-000099:notes:107]

[0001628280-25-036650:notes:111]
[same as prior period, unchanged from 0000889331-25-000099:notes:108]

[0001628280-25-036650:notes:112]
[same as prior period, unchanged from 0000889331-25-000099:notes:109]

[0001628280-25-036650:notes:113]
[same as prior period, unchanged from 0000889331-25-000099:notes:110]

[0001628280-25-036650:notes:114]
[same as prior period, unchanged from 0000889331-25-000099:notes:111]

[0001628280-25-036650:notes:115]
[same as prior period, unchanged from 0000889331-25-000099:notes:112]

[0001628280-25-036650:notes:116]
[same as prior period, unchanged from 0000889331-25-000099:notes:113]

[0001628280-25-036650:notes:117]
[same as prior period, unchanged from 0000889331-25-000099:notes:114]

[0001628280-25-036650:notes:118]
[same as prior period, unchanged from 0000889331-25-000099:notes:115]

[0001628280-25-036650:notes:119]
| Trade Entry Date | Trade Maturity Date | Weighted-Average Floor | Weighted-Average Ceiling |
| July 3, 2024 | August 29, 2025 | 18.0000 | 19.4350 |
| August 5, 2024 | September 29, 2025 | 19.6550 | 21.0000 |
| September 3, 2024 | November 3, 2025 | 20.0820 | 21.7571 |
| September 30, 2024 | November 26, 2025 | 19.8700 | 21.3650 |
| November 4, 2024 | January 2, 2026 | 20.1200 | 21.6900 |
| December 3, 2024 | February 2, 2026 | 20.4250 | 22.0377 |
| January 2, 2025 | March 2, 2026 | 20.8000 | 21.9082 |
| February 6, 2025 | March 30, 2026 | 20.5300 | 22.0000 |
| April 9, 2025 | June 1, 2026 | 20.9700 | 22.2355 |
| May 1, 2025 | June 29, 2026 | 19.6940 | 20.9700 |
| June 4, 2025 | August 3, 2026 | 19.3100 | 20.3437 |

[0001628280-25-036650:notes:120]
The fair value of the collars was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three and six months ended June 28, 2025, the Company recorded pre-tax unrealized gains on the collars of $7.0 million and $9.4 million, respectively. As of June 28, 2025, the Company estimates that approximately $5.8 million of pre-tax gain recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The amounts included in accumulated other comprehensive income will be reclassified to earnings should the hedge no longer be considered effective. No amount of ineffectiveness was included in net income for the three and six months ended June 28, 2025. The Company will continue to assess the effectiveness of the hedge on an ongoing basis. The primary inputs into the valuation of the collars are interest yield curves, interest rate volatilities, foreign exchange rates, foreign exchange volatilities, credit risk, credit spreads and other market information. The collars are classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0001628280-25-036650:notes:121]
[same as prior period, unchanged from 0000889331-25-000099:notes:118]

[0001628280-25-036650:notes:122]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the three and six months ended June 28, 2025, the Company recorded a pre-tax unrealized loss on the interest rate swap of $1.1 million and $3.4 million, respectively. As of June 28, 2025, the Company estimates that approximately $2.1 million of pre-tax gain recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0001628280-25-036650:notes:123]
[same as prior period, unchanged from 0000889331-25-000099:notes:120]

[0001628280-25-036650:notes:124]
[same as prior period, unchanged from 0000889331-25-000099:notes:121]

[0001628280-25-036650:notes:125]
As of June 28, 2025 and December 28, 2024, the fair values of the Company's derivative financial instruments and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0001628280-25-036650:notes:126]
| (in thousands) | Condensed Consolidated Balance Sheets Classification |  | June 28, 2025 |  | December 28, 2024 |  |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 1,990 |  |  | $ | 2,482 |  |  |  |
|  | Other long-term assets |  | 759 |  |  | 3,716 |  |  |  |
| Zero cost collar agreement: |  |  |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 5,376 |  |  | $ | 22 |  |  |  |
|  | Other long-term assets |  | 1 |  |  | — |  |  |  |
|  | Accrued liabilities |  | 36 |  |  | 4,067 |  |  |  |
|  | Other long-term liabilities |  | — |  |  | 2 |  |  |  |

[0001628280-25-036650:notes:127]
The pre-tax (gains) losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Net Income for the three and six months ended June 28, 2025 and June 29, 2024 were as follows:

[0001628280-25-036650:notes:128]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | Classification of (Gains) Losses Recognized in the Condensed Consolidated Statements of Net Income |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (782) |  |  | $ | (1,288) |  |  | $ | (1,571) |  |  | $ | (2,568) |  |
| Zero cost collar agreement |  | Cost of sales |  | (119) |  |  | — |  |  | 1,360 |  |  | — |  |
| Zero cost collar agreement |  | Selling, general, and administrative expenses |  | — |  |  | — |  |  | 121 |  |  | — |  |

[0001628280-25-036650:notes:129]
The pre-tax losses (gains) recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and six months ended June 28, 2025 and June 29, 2024 were as follows:

[0001628280-25-036650:notes:130]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | 1,131 |  |  | $ | 23 |  |  | $ | 3,449 |  |  | $ | (2,511) |  |
| Zero cost collar agreement |  | (6,970) |  |  | — |  |  | (9,412) |  |  | — |  |

[0001628280-25-036650:notes:131]
[same as prior period, unchanged from 0000889331-25-000099:notes:128]

[0001628280-25-036650:notes:132]
[same as prior period, unchanged from 0000889331-25-000099:notes:129]

[0001628280-25-036650:notes:133]
There were no changes during the quarter ended June 28, 2025 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of June 28, 2025 and December 28, 2024, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001628280-25-036650:notes:134]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of June 28, 2025:

[0001628280-25-036650:notes:135]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 579,626 |  |  | $ | — |  |  | $ | — |  |  | $ | 579,626 |  |
| Investments in equity securities |  | 9,249 |  |  | — |  |  | — |  |  | 9,249 |  |
| Mutual funds |  | 24,328 |  |  | — |  |  | — |  |  | 24,328 |  |
| Total |  | $ | 613,203 |  |  | $ | — |  |  | $ | — |  |  | $ | 613,203 |  |

[0001628280-25-036650:notes:136]
[same as prior period, unchanged from 0000889331-25-000099:notes:133]

[0001628280-25-036650:notes:137]
[same as prior period, unchanged from 0000889331-25-000099:notes:134]

[0001628280-25-036650:notes:138]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at June 28, 2025 and December 28, 2024, as the rates on these borrowings are variable in nature. The purchase price of business acquisitions is primarily allocated to the tangible and identifiable intangible assets acquired and liabilities assumed based on their estimated fair values on the acquisition date, with the excess recorded as goodwill. The Company utilizes Level 3 inputs in the determination of the initial fair value for certain assets acquired and liabilities assumed in business acquisitions.

[0001628280-25-036650:notes:139]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series B and USD Senior Notes, Series A and Series B, as of June 28, 2025 and December 28, 2024 were as follows:

[0001628280-25-036650:notes:140]
|  |  | June 28, 2025 |  | December 28, 2024 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 |  | $ | 111,079 |  |  | $ | 104,398 |  |  | $ | 98,928 |  |  | $ | 91,741 |  |
| USD Senior Notes, Series A due 2025 |  | — |  |  | — |  |  | 50,000 |  |  | 49,919 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 98,121 |  |  | 100,000 |  |  | 96,623 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 118,391 |  |  | 125,000 |  |  | 114,786 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 94,159 |  |  | 100,000 |  |  | 91,175 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-25-036650:notes:141]
[same as prior period, unchanged from 0000889331-25-000099:notes:138]

[0001628280-25-036650:notes:142]
[same as prior period, unchanged from 0000889331-25-000099:notes:139]

[0001628280-25-036650:notes:143]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other income, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and six months ended June 28, 2025 and June 29, 2024 were as follows:

[0001628280-25-036650:notes:144]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 758 |  |  | $ | 770 |  |  | $ | 1,485 |  |  | $ | 1,565 |  |
| Interest cost |  | 1,003 |  |  | 975 |  |  | 1,957 |  |  | 1,970 |  |
| Expected return on plan assets |  | (481) |  |  | (510) |  |  | (940) |  |  | (1,028) |  |
| Amortization of prior service and net actuarial loss |  | 102 |  |  | 46 |  |  | 171 |  |  | 92 |  |
| Net periodic benefit cost |  | $ | 1,382 |  |  | $ | 1,281 |  |  | $ | 2,673 |  |  | $ | 2,599 |  |

[0001628280-25-036650:notes:145]
[same as prior period, unchanged from 0000889331-25-000099:notes:142]

[0001628280-25-036650:notes:146]
[same as prior period, unchanged from 0000889331-25-000099:notes:143]

[0001628280-25-036650:notes:147]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.7 million for each of the three months ended June 28, 2025 and June 29, 2024, respectively, and $1.4 million for each of the six months ended June 28, 2025 and June 29, 2024, respectively, in Cost of sales and Other income, net within the Condensed Consolidated Statements of Net Income. The pre-tax losses amount recognized in other comprehensive income (loss) for these plans were $0.4 million and $0.3 million for the three months ended June 28, 2025 and June 29, 2024, respectively, and $0.7 million and $0.6 million for the six months ended June 28, 2025 and June 29, 2024, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-036650:notes:148]
[same as prior period, unchanged from 0000889331-25-000099:notes:145]

[0001628280-25-036650:notes:149]
| (in thousands) |  | Three Months EndedJune 28, 2025 |  | Three Months EndedJune 29, 2024 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 151 |  |  | $ | 33 |  |  | $ | 184 |  |  | $ | 336 |  |  | $ | (10) |  |  | $ | 326 |  |
| Cash flow hedges |  | 5,839 |  |  | (9) |  |  | 5,830 |  |  | (23) |  |  | 5 |  |  | (18) |  |
| Foreign currency translation adjustments (a) |  | 94,433 |  |  | (2,534) |  |  | 91,899 |  |  | (21,542) |  |  | 167 |  |  | (21,375) |  |
| Total change in other comprehensive income (loss) |  | $ | 100,423 |  |  | $ | (2,510) |  |  | $ | 97,913 |  |  | $ | (21,229) |  |  | $ | 162 |  |  | $ | (21,067) |  |
| (in thousands) |  | Six Months EndedJune 28, 2025 |  | Six Months EndedJune 29, 2024 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 378 |  |  | $ | 25 |  |  | $ | 403 |  |  | $ | 696 |  |  | $ | (26) |  |  | $ | 670 |  |
| Cash flow hedges |  | 5,963 |  |  | 455 |  |  | 6,418 |  |  | 2,511 |  |  | (603) |  |  | 1,908 |  |
| Foreign currency translation adjustments (a) |  | 132,101 |  |  | (3,412) |  |  | 128,689 |  |  | (54,712) |  |  | 776 |  |  | (53,936) |  |
| Total change in other comprehensive income (loss) |  | $ | 138,442 |  |  | $ | (2,932) |  |  | $ | 135,510 |  |  | $ | (51,505) |  |  | $ | 147 |  |  | $ | (51,358) |  |

[0001628280-25-036650:notes:150]
(a) The tax shown above within foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries which have been previously taxed in the U.S. and are not permanently reinvested.

[0001628280-25-036650:notes:151]
The following tables set forth the changes in the components of accumulated other comprehensive income (loss) by component for the six months ended June 28, 2025 and June 29, 2024:

[0001628280-25-036650:notes:152]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currencytranslation adjustments |  | Accumulated othercomprehensive (loss) income |
| Balance at December 28, 2024 |  | $ | (10,509) |  |  | $ | 1,301 |  |  | $ | (137,153) |  |  | $ | (146,361) |  |
| Activity in the period |  | 403 |  |  | 6,418 |  |  | 128,689 |  |  | 135,510 |  |
| Balance at June 28, 2025 |  | $ | (10,106) |  |  | $ | 7,719 |  |  | $ | (8,464) |  |  | $ | (10,851) |  |

[0001628280-25-036650:notes:153]
| (in thousands) |  | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currency translation adjustments |  | Accumulated other comprehensive loss |
| Balance at December 30, 2023 |  | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| Activity in the period |  | 670 |  |  | 1,908 |  |  | (53,936) |  |  | (51,358) |  |
| Balance at June 29, 2024 |  | $ | (6,943) |  |  | $ | 6,356 |  |  | $ | (106,588) |  |  | $ | (107,175) |  |

[0001628280-25-036650:notes:154]
Amounts reclassified from accumulated other comprehensive income (loss) to earnings for the three and six months ended June 28, 2025 and June 29, 2024 were as follows:

[0001628280-25-036650:notes:155]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Pension and postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss, and other |  | $ | 470 |  |  | $ | 347 |  |  | $ | 891 |  |  | $ | 703 |  |

[0001628280-25-036650:notes:156]
[same as prior period, unchanged from 0000889331-25-000099:notes:153]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-036650:notes:157]
Income Taxes
The effective tax rate for the three and six months ended June 28, 2025 was 26.7% and 27.0%, respectively, compared to the effective tax rate for the three and six months ended June 29, 2024 of 25.6% and 19.6%, respectively. The effective tax rate for 2025 was higher than the effective tax rate for the comparable 2024 periods primarily due to increases in foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit, as compared to 2024. The 2024 periods also recognized more favorable tax rate benefits due to lapses in the statute of limitations for previously unrecognized tax benefits, as compared to the 2025 periods.

[0001628280-25-036650:notes:158]
The effective tax rates for three and six months ended June 28, 2025 were higher than the statutory tax rate primarily due to foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit. The effective tax rate for the three months ended June 29, 2024 was higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions. The effective tax rate for the six months ended June 29, 2024 was lower than the statutory tax rate primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter.

[0001628280-25-036650:notes:159]
On July 4, 2025, the United States has enacted into law the legislation formally titled “An Act to provide for reconciliation pursuant to title II of H. Con. Res. 14”, and commonly referred to as the One Big Beautiful Bill Act (“OBBB”). The OBBB contains multiple business tax provisions, including the permanent extension of several expiring provisions of the Tax Cuts and Jobs Act and multiple modifications to the international tax framework, for which the Company is currently evaluating the impact on its Condensed Consolidated Financial Statements. The legislation has multiple effective dates with certain provisions soon to be effective in 2025 and others to be implemented in future years, and the Company will continue to monitor future administrative guidance and regulations that clarify the legislative text of the OBBB and the bill’s potential effect on the Company’s income taxes.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-036650:notes:160]
[same as prior period, unchanged from 0000889331-25-000099:notes:157]

[0001628280-25-036650:notes:161]
[same as prior period, unchanged from 0000889331-25-000099:notes:158]

[0001628280-25-036650:notes:162]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share amounts) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 57,342 |  |  | $ | 45,466 |  |  | $ | 100,913 |  |  | $ | 93,918 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,755 |  |  | 24,822 |  |  | 24,760 |  |  | 24,867 |  |
| Effect of dilutive securities |  | 150 |  |  | 208 |  |  | 178 |  |  | 208 |  |
| Diluted |  | 24,905 |  |  | 25,030 |  |  | 24,938 |  |  | 25,075 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 2.32 |  |  | $ | 1.83 |  |  | $ | 4.08 |  |  | $ | 3.78 |  |
| Diluted earnings per share |  | $ | 2.30 |  |  | $ | 1.82 |  |  | $ | 4.05 |  |  | $ | 3.75 |  |

[0001628280-25-036650:notes:163]
Potential shares of common stock attributable to performance share units, stock options and restricted stock units excluded from the earnings per share calculation because their effect would be anti-dilutive were 429,709 and 141,729 for the three months ended June 28, 2025 and June 29, 2024, respectively, and 347,711 and 129,096 for the six months ended June 28, 2025 and June 29, 2024, respectively.

[0001628280-25-036650:notes:164]
Share Repurchase Program
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program") to replace its previous 2021 program. The Company did not repurchase any shares of its common stock for the three months ended June 28, 2025. During the six months ended June 28, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. During the three and six months ended June 29, 2024, the Company repurchased 109,031 and 179,311 shares of its common stock totaling $24.7 million and $40.9 million, respectively, of which $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-036650:notes:165]
[same as prior period, unchanged from 0000889331-25-000099:notes:163]

[0001628280-25-036650:notes:166]
[same as prior period, unchanged from 0000889331-25-000099:notes:164]

[0001628280-25-036650:notes:167]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Finance, information technology, and human resources are shared functions that are allocated back to the operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other.” Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0001628280-25-036650:notes:168]
[same as prior period, unchanged from 0000889331-25-000099:notes:167]

[0001628280-25-036650:notes:169]
[same as prior period, unchanged from 0000889331-25-000099:notes:168]

[0001628280-25-036650:notes:170]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), protective and monitoring relays (protection relays, residual current devices and monitors, ground fault circuit interrupters, solid state switches, and arc fault detection devices), and industrial controls and sensors (contactors, transformers, and temperature sensors) for use

[0001628280-25-036650:notes:171]
in various applications such as renewable energy and energy storage systems, industrial safety, factory automation, electric vehicle charging infrastructure, HVAC systems, non-residential construction, MRO, and mining.

[0001628280-25-036650:notes:172]
[same as prior period, unchanged from 0000889331-25-000099:notes:170]

[0001628280-25-036650:notes:173]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 335,666 |  |  | $ | 305,639 |  |  | $ | 642,915 |  |  | $ | 596,744 |  |
| Transportation |  | 179,400 |  |  | 168,964 |  |  | 341,262 |  |  | 339,331 |  |
| Industrial |  | 98,347 |  |  | 83,886 |  |  | 183,543 |  |  | 157,799 |  |
| Total net sales |  | $ | 613,413 |  |  | $ | 558,489 |  |  | $ | 1,167,720 |  |  | $ | 1,093,874 |  |
| Other segment expenses (b) |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 285,805 |  |  | $ | 259,474 |  |  | $ | 546,288 |  |  | 512,776 |  |
| Transportation |  | 151,326 |  |  | 153,730 |  |  | 294,271 |  |  | 307,891 |  |
| Industrial |  | 79,484 |  |  | 74,339 |  |  | 151,606 |  |  | 143,456 |  |
| Total other segment expenses |  | $ | 516,615 |  |  | $ | 487,543 |  |  | $ | 992,165 |  |  | $ | 964,123 |  |
| Segment operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 49,861 |  |  | $ | 46,165 |  |  | $ | 96,627 |  |  | $ | 83,968 |  |
| Transportation |  | 28,074 |  |  | 15,234 |  |  | 46,991 |  |  | 31,440 |  |
| Industrial |  | 18,863 |  |  | 9,547 |  |  | 31,937 |  |  | 14,343 |  |
| Total segment operating income |  | 96,798 |  |  | 70,946 |  |  | 175,555 |  |  | 129,751 |  |
| Other (a) |  | (4,020) |  |  | (5,440) |  |  | (12,627) |  |  | (9,293) |  |
| Total operating income |  | 92,778 |  |  | 65,506 |  |  | 162,928 |  |  | 120,458 |  |
| Interest expense |  | 8,568 |  |  | 9,975 |  |  | 17,443 |  |  | 19,586 |  |
| Foreign exchange loss (gain) |  | 10,448 |  |  | (315) |  |  | 15,291 |  |  | (5,357) |  |
| Other income, net |  | (4,452) |  |  | (5,298) |  |  | (7,967) |  |  | (10,619) |  |
| Income before income taxes |  | $ | 78,214 |  |  | $ | 61,144 |  |  | $ | 138,161 |  |  | $ | 116,848 |  |

[0001628280-25-036650:notes:174]
(a) Included in "Other" Operating income for the second fiscal quarter of 2025 was $2.5 million ($11.4 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2025, the Company recognized $1.5 million ($1.6 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2025, the Company recognized a $0.5 million of purchase accounting inventory step-down adjustment related to the Dortmund Fab acquisition.

[0001628280-25-036650:notes:175]
Included in "Other" Operating income for the second quarter of 2024 was $5.3 million ($7.6 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2024, the Company recognized $0.8 million ($1.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.7 million ($1.0 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0001628280-25-036650:notes:176]
(b) Other segment operating expenses include cost of sales, selling, general, and administration expenses, and research and development expenses. Other segment expenses are reconciled to the operating income of each segment. The CODM regularly assesses the performance of each operating segment focusing on each operating segment’s revenue and operating income. Other segment operating expenses for the three and six months ended June 29, 2024 were included in order to adhere to the implementation of Accounting Standards Updates ("ASU") No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures."

[0001628280-25-036650:notes:177]
The Company’s depreciation and amortization expenses by segment for the three and six months ended June 28, 2025 and June 29, 2024 were as follows:

[0001628280-25-036650:notes:178]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Depreciation |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 12,552 |  |  | $ | 9,961 |  |  | $ | 23,962 |  |  | $ | 19,946 |  |
| Transportation |  | 5,318 |  |  | 5,743 |  |  | 10,817 |  |  | 10,990 |  |
| Industrial |  | 1,505 |  |  | 1,347 |  |  | 3,026 |  |  | 2,783 |  |
| Total depreciation |  | $ | 19,375 |  |  | $ | 17,051 |  |  | $ | 37,805 |  |  | $ | 33,719 |  |
| Amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 10,098 |  |  | $ | 9,809 |  |  | $ | 19,875 |  |  | $ | 19,665 |  |
| Transportation |  | 3,406 |  |  | 3,369 |  |  | 6,755 |  |  | 6,753 |  |
| Industrial |  | 1,348 |  |  | 2,551 |  |  | 2,553 |  |  | 5,136 |  |
| Total amortization |  | $ | 14,852 |  |  | $ | 15,729 |  |  | $ | 29,183 |  |  | $ | 31,554 |  |

[0001628280-25-036650:notes:179]
[same as prior period, unchanged from 0000889331-25-000099:notes:177]

[0001628280-25-036650:notes:180]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 219,480 |  |  | $ | 201,825 |  |  | $ | 417,858 |  |  | $ | 392,258 |  |
| China |  | 146,343 |  |  | 131,510 |  |  | 275,737 |  |  | 246,679 |  |
| Other countries (a) |  | 247,590 |  |  | 225,154 |  |  | 474,125 |  |  | 454,937 |  |
| Total net sales |  | $ | 613,413 |  |  | $ | 558,489 |  |  | $ | 1,167,720 |  |  | $ | 1,093,874 |  |

[0001628280-25-036650:notes:181]
[same as prior period, unchanged from 0000889331-25-000099:notes:179]

[0001628280-25-036650:notes:182]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 73,709 |  |  | $ | 74,698 |  |
| China |  | 128,373 |  |  | 132,504 |  |
| Mexico |  | 87,176 |  |  | 89,558 |  |
| Germany |  | 104,424 |  |  | 58,758 |  |
| Philippines |  | 63,052 |  |  | 66,174 |  |
| Other countries |  | 59,783 |  |  | 55,376 |  |
| Total long-lived assets |  | $ | 516,517 |  |  | $ | 477,068 |  |

[0001628280-25-036650:notes:183]
[same as prior period, unchanged from 0000889331-25-000099:notes:181]

[0001628280-25-036650:notes:184]
|  |  | Six Months Ended |
| (in thousands) |  | June 28, 2025 |  | June 29, 2024 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 5,330 |  |  | $ | 6,644 |  |
| China |  | 3,996 |  |  | 7,088 |  |
| Mexico |  | 3,283 |  |  | 5,450 |  |
| Germany |  | 9,693 |  |  | 8,031 |  |
| Philippines |  | 1,388 |  |  | 2,379 |  |
| Other countries |  | 3,096 |  |  | 4,277 |  |
| Total additions to long-lived assets |  | $ | 26,786 |  |  | $ | 33,869 |  |

[0001628280-25-036650:notes:185]
[same as prior period, unchanged from 0000889331-25-000099:notes:183]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-25-036650:notes:186]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0001628280-25-036650:notes:187]
As of June 28, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-25-036650:notes:188]
Product Warranty Liabilities

[0001628280-25-036650:notes:189]
The Company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0001628280-25-036650:notes:190]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0001628280-25-036650:notes:191]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0001628280-25-036650:notes:192]
Environmental Remediation Liabilities

[0001628280-25-036650:notes:193]
The Company's operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and its employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. The Company could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at its facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. The Company is, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0001628280-25-036650:notes:194]
Legal Proceedings

[0001628280-25-036650:notes:195]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon the Company's experience and current information known, the Company does not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on its results of operations, financial position, and/or cash flows.

[0001628280-25-036650:notes:196]
The Company accounts for litigation and claims losses in accordance with ASC 450, "Contingencies" where loss contingency provisions are recognized for probable and estimable losses at the Company's best estimate of a loss or, when a best estimate cannot be made, at its estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. If the Company is initially unable to develop a best estimate of loss, the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed when events result in an expectation different than previously expected.

[0001628280-25-036650:notes:197]
Pending Litigation and Claims

[0001628280-25-036650:notes:198]
There were no material pending litigation or claims outstanding as of June 28, 2025.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-25-036650:notes:199]
Related Party Transactions

[0001628280-25-036650:notes:200]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0001628280-25-036650:notes:201]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0001628280-25-036650:notes:202]
EB Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0001628280-25-036650:notes:203]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One of the Company's executive officers serves on the Board of Directors of ATEC.

[0001628280-25-036650:notes:204]
|  |  | Three Months Ended June 28, 2025 |  | Three Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.5 |  | 1.4 |  |  | 1.2 |  | 0.2 |  | 0.8 |  |
|  |  | Six Months Ended June 28, 2025 |  | Six Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.6 |  | $ | — |  | $ | — |  |  | $ | 0.9 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.7 |  | 3.3 |  |  | 2.4 |  | 0.4 |  | 2.9 |  |
|  |  | June 28, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | — |  | 0.1 |  | 0.6 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |
