# LFUS MD&A — 0001628280-25-036650


## mdna

[0001628280-25-036650:mdna:1]
[same as prior period, unchanged from 0000889331-25-000099:mdna:1]

[0001628280-25-036650:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001628280-25-036650:mdna:3]
[same as prior period, unchanged from 0000889331-25-000099:mdna:3]

[0001628280-25-036650:mdna:4]
[same as prior period, unchanged from 0000889331-25-000099:mdna:4]

[0001628280-25-036650:mdna:5]
[same as prior period, unchanged from 0000889331-25-000099:mdna:5]

[0001628280-25-036650:mdna:6]
[same as prior period, unchanged from 0000889331-25-000099:mdna:6]

[0001628280-25-036650:mdna:7]
[same as prior period, unchanged from 0000889331-25-000099:mdna:7]

[0001628280-25-036650:mdna:8]
[same as prior period, unchanged from 0000889331-25-000099:mdna:8]

[0001628280-25-036650:mdna:9]
For the second quarter of 2025, the Company recognized net sales of $613.4 million, an increase of $54.9 million, or 9.8% as compared to $558.5 million in the second quarter of 2024 including $13.4 million or 2.4% of incremental net sales from the Dortmund Fab acquisition (defined below) in the semiconductor business within the Electronics segment and $7.0 million or 1.3% of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume in the Electronics and Industrial segments. The Company recognized net income of $57.3 million, or $2.30 per diluted share, in the second quarter of 2025 compared to $45.5 million, or $1.82 per diluted share, in the second quarter of 2024. The increase in net income was primarily due to higher operating income across all segments driven by increases in net sales, volume leverage and cost saving initiatives, which were partially offset by higher foreign exchange losses.

[0001628280-25-036650:mdna:10]
Net cash provided by operating activities was $148.2 million for the six months ended June 28, 2025 compared to $126.6 million for the six months ended June 29, 2024. The increase in net cash provided by operating activities was primarily due to higher cash earnings.

[0001628280-25-036650:mdna:11]
[same as prior period, unchanged from 0000889331-25-000099:mdna:11]

[0001628280-25-036650:mdna:12]
[same as prior period, unchanged from 0000889331-25-000099:mdna:12]

[0001628280-25-036650:mdna:13]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies" that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0001628280-25-036650:mdna:14]
[same as prior period, unchanged from 0000889331-25-000099:mdna:14]

[0001628280-25-036650:mdna:15]
Tariffs have resulted in China and other countries imposing reciprocal tariffs on U.S. goods and ceasing sales of certain products to the U.S. and could result in more U.S. trading partners adopting responsive trade policies, including making it more difficult or costly for us to export our products to those countries. Sales to customers outside of the U.S., and to China in particular, comprise a significant portion of our net sales, and reciprocal tariffs may impact our business in China. Further, tariffs and trade policies may continue to change quickly and without warning, and we may not be able to accurately anticipate and mitigate the impacts.

[0001628280-25-036650:mdna:16]
[same as prior period, unchanged from 0000889331-25-000099:mdna:16]

[0001628280-25-036650:mdna:17]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The second quarter of 2025 included $2.5 million ($11.4 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2025, the Company recognized $1.5 million ($1.6 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2025, the Company recognized a $0.5 million purchase accounting inventory step-down adjustment related to the Dortmund Fab acquisition.

[0001628280-25-036650:mdna:18]
The second quarter of 2024 included $5.3 million ($7.6 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2024, the Company recognized $0.8 million ($1.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.7 million ($1.0 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0001628280-25-036650:mdna:19]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Net sales |  | $ | 613,413 |  |  | $ | 558,489 |  |  | $ | 54,924 |  |  | 9.8 | % |  | $ | 1,167,720 |  |  | $ | 1,093,874 |  |  | $ | 73,846 |  |  | 6.8 | % |
| Cost of sales |  | 381,359 |  |  | 351,485 |  |  | 29,874 |  |  | 8.5 | % |  | 728,410 |  |  | 699,062 |  |  | 29,348 |  |  | 4.2 | % |
| Gross profit |  | 232,054 |  |  | 207,004 |  |  | 25,050 |  |  | 12.1 | % |  | 439,310 |  |  | 394,812 |  |  | 44,498 |  |  | 11.3 | % |
| Operating expenses |  | 139,276 |  |  | 141,498 |  |  | (2,222) |  |  | (1.6) | % |  | 276,382 |  |  | 274,354 |  |  | 2,028 |  |  | 0.7 | % |
| Operating income |  | 92,778 |  |  | 65,506 |  |  | 27,272 |  |  | 41.6 | % |  | 162,928 |  |  | 120,458 |  |  | 42,470 |  |  | 35.3 | % |
| Income before income taxes |  | 78,214 |  |  | 61,144 |  |  | 17,070 |  |  | 27.9 | % |  | 138,161 |  |  | 116,848 |  |  | 21,313 |  |  | 18.2 | % |
| Income taxes |  | 20,872 |  |  | 15,678 |  |  | 5,194 |  |  | 33.1 | % |  | 37,248 |  |  | 22,930 |  |  | 14,318 |  |  | 62.4 | % |
| Net income |  | 57,342 |  |  | 45,466 |  |  | 11,876 |  |  | 26.1 | % |  | 100,913 |  |  | 93,918 |  |  | 6,995 |  |  | 7.4 | % |

[0001628280-25-036650:mdna:20]
[same as prior period, unchanged from 0000889331-25-000099:mdna:20]

[0001628280-25-036650:mdna:21]
Net sales increased $54.9 million, or 9.8%, for the second quarter of 2025 compared to the second quarter of 2024 including $13.4 million or 2.4% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and $7.0 million or 1.3% of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume of $22.6 million in the electronics products business within the Electronics segment, $14.5 million in the Industrial segment, and $7.1 million and $5.5 million in the passenger car products and the commercial vehicle businesses, respectively, within the Transportation segment due to higher end market demand and favorable price, partially offset by lower volume from the remaining semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:22]
Net sales increased $73.8 million, or 6.8%, for the six months of 2025 compared to the six months of 2024 including $23.5 million or 2.2% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and $0.4 million of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume of $38.4 million in the electronics products business within the Electronics segment and $25.7 million in the Industrial segment due to higher end market demand and favorable price, partially offset by lower volume from the remaining semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:23]
[same as prior period, unchanged from 0000889331-25-000099:mdna:22]

[0001628280-25-036650:mdna:24]
Cost of sales was $381.4 million, or 62.2% of net sales, in the second quarter of 2025 compared to $351.5 million, or 62.9% of net sales, in the second quarter of 2024. As a percent of net sales, cost of sales decreased 0.7% primarily driven by improved margin from the commercial vehicle and passenger car products businesses within the Transportation segment and across all businesses within the Industrial segment driven by favorable price, volume leverage, and cost reduction initiatives. In addition, higher volume from the electronics products business within the Electronics segment favorably impacted the decrease in cost of sales as percent of net sales that was partially offset by lower gross margin from the semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:25]
Cost of sales was $728.4 million, or 62.4% of net sales, in the first six months of 2025 compared to $699.1 million, or 63.9% of net sales, in the first six months of 2024. As a percent of net sales, cost of sales decreased 1.5% primarily driven by higher volume in the electronics products business within the Electronics segment and across all businesses in the Industrial segment. Additionally, improved margin from the commercial vehicle and the passenger car products businesses within the Transportation segment driven by volume leverage, favorable price, and cost reduction initiatives favorably impacted the decrease in cost of net sales as percent of net sales that was partially offset by lower volume from the semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:26]
[same as prior period, unchanged from 0000889331-25-000099:mdna:24]

[0001628280-25-036650:mdna:27]
Gross profit was $232.1 million, or 37.8% of net sales, in the second quarter of 2025 compared to $207.0 million, or 37.1% of net sales, in the second quarter of 2024. The $25.1 million increase in gross profit was primarily due to higher volume from the electronics products business within the Electronics segment and across all businesses within the Industrial segment and improved margin from the commercial vehicle and the passenger car products businesses within the Transportation segment, partially offset by lower volume from the semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:28]
Gross profit was $439.3 million, or 37.6% of net sales, in the first six months of 2025 compared to $394.8 million, or 36.1% of net sales, in the first six months of 2024. The $44.5 million increase in gross profit was primarily from higher volume in the electronics products business within the Electronics segment, across all businesses within the Industrial segment, and the commercial vehicle and the passenger car products businesses within the Transportation driven by higher volume, favorable price, and product mix, partially offset by lower volume from the semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:29]
[same as prior period, unchanged from 0000889331-25-000099:mdna:26]

[0001628280-25-036650:mdna:30]
Operating expenses were $139.3 million, or 22.7% of net sales, for the second quarter of 2025 compared to $141.5 million, or 25.3% of net sales, for the second quarter of 2024. The decrease in operating expenses of $2.2 million was primarily due to lower restructuring, impairment, and other charges of $2.7 million related to cost control initiatives in the semiconductor business within the Electronics segment implemented in the prior year.

[0001628280-25-036650:mdna:31]
Operating expenses were $276.4 million, or 23.7% of net sales, for the first six months of 2025 compared to $274.4 million, or 25.1% of net sales, for the first six months of 2024. The increase in operating expenses of $2.0 million was primarily due to higher selling, general, and administrative expenses of $3.7 million driven by the Dortmund Fab acquisition and restructuring, impairment, and other charges of $3.0 million related to company-wide cost control initiatives implemented in the first quarter of 2025, partially offset by lower amortization expense of $2.4 million and research and development expenses of $2.4 million.

[0001628280-25-036650:mdna:32]
[same as prior period, unchanged from 0000889331-25-000099:mdna:28]

[0001628280-25-036650:mdna:33]
Operating income was $92.8 million, representing an increase of $27.3 million, or 41.6%, for the second quarter of 2025 compared to $65.5 million for the second quarter of 2024. The increase in operating income was due to higher gross profit from the electronics products business within the Electronics segment and the Transportation and Industrial segments, and lower operating expenses mainly driven by lower restructuring, impairment, and other charges, partially offset by lower gross profit from the semiconductor business within the Electronics segment. Operating margins increased from 11.7% in the second quarter of 2024 to 15.1% in the second quarter of 2025 driven by improved gross margin in the Transportation and Industrial segments.

[0001628280-25-036650:mdna:34]
Operating income was $162.9 million, representing an increase of $42.5 million, or 35.3%, for the first six months of 2025 compared to $120.5 million for the first six months of 2024. The increase in operating income was due to higher gross profit across all segments, partially offset by higher operating expenses mainly driven by higher selling, general, and administrative expenses from the Dortmund Fab acquisition  and restructuring, impairment, and other charges due to company-wide cost control initiatives implemented in the first quarter of 2025. Operating margins increased from 11.0% in the first six months of 2024 to 14.0% in the first six months of 2025 driven by improved gross margin in the Industrial and Transportation segments.

[0001628280-25-036650:mdna:35]
[same as prior period, unchanged from 0000889331-25-000099:mdna:30]

[0001628280-25-036650:mdna:36]
The effective tax rate for the three and six months ended June 28, 2025 was 26.7% and 27.0%, respectively, compared to the effective tax rate for the three and six months ended June 29, 2024 of 25.6% and 19.6%, respectively. The effective tax rate for 2025 was higher than the effective tax rate for the comparable 2024 periods primarily due to increases in foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit, as compared to 2024. The 2024 periods also recognized more favorable tax rate benefits due to lapses in the statute of limitations for previously unrecognized tax benefits, as compared to the 2025 periods.

[0001628280-25-036650:mdna:37]
The effective tax rates for three and six months ended June 28, 2025 were higher than the statutory tax rate primarily due to foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit. The effective tax rate for the three months ended June 29, 2024 was higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions. The effective tax rate for the six months ended June 29, 2024 was lower than the statutory tax rate primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter.

[0001628280-25-036650:mdna:38]
[same as prior period, unchanged from 0000889331-25-000099:mdna:32]

[0001628280-25-036650:mdna:39]
The effective tax rate for the three and six months ended June 28, 2025 was 26.7% and 27.0%, respectively, compared to the effective tax rate for the three and six months ended June 29, 2024 of 25.6% and 19.6%, respectively. The effective tax rate for 2025 is higher than the effective tax rate for the comparable 2024 periods primarily due to increases in foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit, as compared to 2024. The 2024 periods also recognized more favorable tax rate benefits due to lapses in the statute of limitations for previously unrecognized tax benefits, as compared to the 2025 periods.

[0001628280-25-036650:mdna:40]
The effective tax rates for the three and six months ended June 28, 2025 are higher than the statutory tax rate primarily due to foreign exchange losses and losses in non-U.S. jurisdictions with no related tax benefit. The effective tax rate for the three months ended June 29, 2024 is higher than the statutory tax rate primarily due to the proportion of pre-tax income that is earned in higher tax jurisdictions. The effective tax rate for the six months ended June 29, 2024 is lower than the statutory tax rate primarily due to the lapse in the statute of limitations for previously unrecognized tax benefits recognized in the first quarter.

[0001628280-25-036650:mdna:41]
[same as prior period, unchanged from 0000889331-25-000099:mdna:35]

[0001628280-25-036650:mdna:42]
[same as prior period, unchanged from 0000889331-25-000099:mdna:36]

[0001628280-25-036650:mdna:43]
[same as prior period, unchanged from 0000889331-25-000099:mdna:37]

[0001628280-25-036650:mdna:44]
| Net Sales |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Electronics |  | $ | 335,666 |  |  | $ | 305,639 |  |  | $ | 30,027 |  |  | 9.8 | % |  | $ | 642,915 |  |  | $ | 596,744 |  |  | $ | 46,171 |  |  | 7.7 | % |
| Transportation |  | 179,400 |  |  | 168,964 |  |  | 10,436 |  |  | 6.2 | % |  | 341,262 |  |  | 339,331 |  |  | 1,931 |  |  | 0.6 | % |
| Industrial |  | 98,347 |  |  | 83,886 |  |  | 14,461 |  |  | 17.2 | % |  | 183,543 |  |  | 157,799 |  |  | 25,744 |  |  | 16.3 | % |
| Total |  | $ | 613,413 |  |  | $ | 558,489 |  |  | $ | 54,924 |  |  | 9.8 | % |  | $ | 1,167,720 |  |  | $ | 1,093,874 |  |  | $ | 73,846 |  |  | 6.8 | % |

[0001628280-25-036650:mdna:45]
| Segment Operating Income |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Electronics |  | $ | 49,861 |  |  | $ | 46,165 |  |  | $ | 3,696 |  |  | 8.0 | % |  | $ | 96,627 |  |  | $ | 83,968 |  |  | $ | 12,659 |  |  | 15.1 | % |
| Transportation |  | 28,074 |  |  | 15,234 |  |  | 12,840 |  |  | 84.3 | % |  | 46,991 |  |  | 31,440 |  |  | 15,551 |  |  | 49.5 | % |
| Industrial |  | 18,863 |  |  | 9,547 |  |  | 9,316 |  |  | 97.6 | % |  | 31,937 |  |  | 14,343 |  |  | 17,594 |  |  | 122.7 | % |
| Total segment operating income |  | 96,798 |  |  | 70,946 |  |  | 25,852 |  |  |  |  | 175,555 |  |  | 129,751 |  |  | 45,804 |  |  |  |
| Other (a) |  | (4,020) |  |  | (5,440) |  |  | 1,420 |  |  |  |  | (12,627) |  |  | (9,293) |  |  | (3,334) |  |  |  |
| Total operating income |  | $ | 92,778 |  |  | $ | 65,506 |  |  | $ | 27,272 |  |  | 41.6 | % |  | $ | 162,928 |  |  | $ | 120,458 |  |  | $ | 42,470 |  |  | 35.3 | % |

[0001628280-25-036650:mdna:46]
(a) Included in “Other” Operating income for the second quarter of 2025 was $2.5 million ($11.4 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2025, the Company recognized a $0.1 million impairment charge related to certain machinery and equipment within the Electronics segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2025, the Company recognized $1.5 million ($1.6 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions. During the first quarter of 2025, the Company recognized a $0.5 million  purchase accounting inventory step-down adjustment related to the Dortmund Fab acquisition.

[0001628280-25-036650:mdna:47]
Included in “Other” Operating income for the second quarter of 2024 was $5.3 million ($7.6 million year-to-date) of restructuring charges primarily related to employee termination costs. During the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, during the second quarter of 2024, the Company recognized $0.8 million ($1.8 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, partially offset by a gain of $0.7 million ($1.0 million year-to-date) recorded for the sale of two buildings within the Transportation segment.

[0001628280-25-036650:mdna:48]
[same as prior period, unchanged from 0000889331-25-000099:mdna:42]

[0001628280-25-036650:mdna:49]
[same as prior period, unchanged from 0000889331-25-000099:mdna:43]

[0001628280-25-036650:mdna:50]
Net sales increased $30.0 million, or 9.8%, in the second quarter of 2025 compared to the second quarter of 2024 and included favorable changes in foreign exchange rates of $3.7 million or 1.2% . The net sales increase was primarily due to higher volume of $22.6 million from the electronics products business driven by higher end market demand and $13.4 million of incremental net sales from the Dortmund Fab acquisition in the semiconductor business, partially offset by lower volume from the remaining semiconductor business.

[0001628280-25-036650:mdna:51]
Net sales increased $46.2 million, or 7.7%, in the first six months of 2025 compared to the first six months of 2024 and included unfavorable changes in foreign exchange rates of $0.1 million. The sales increase was primarily due to higher volume of $38.4 million from the electronics products business driven by higher end market demand and $23.5 million of incremental net sales from the Dortmund Fab acquisition in the semiconductor business, partially offset by lower volume from the remaining semiconductor business.

[0001628280-25-036650:mdna:52]
[same as prior period, unchanged from 0000889331-25-000099:mdna:45]

[0001628280-25-036650:mdna:53]
Operating income was $49.9 million, representing an increase of $3.7 million, or 8.0%, for the second quarter of 2025 compared to $46.2 million for the second quarter of 2024. The increase in operating income was primarily from the electronics products business due to volume leverage. Operating margins decreased from 15.1% in the second quarter of 2024 to 14.9% in the second quarter of 2025 primarily due to lower gross margin for the semiconductor business, partially offset by volume leverage from the electronics products business.

[0001628280-25-036650:mdna:54]
Operating income was $96.6 million, representing an increase of $12.7 million, or 15.1%, for the first six months of 2025 compared to $84.0 million for the first six months of 2024. The increase in operating income was primarily from the electronics products business due to volume leverage. Operating margins increased from 14.1% in the first six months of 2024 to 15.0% in the first six months of 2025 primarily due to volume leverage from the electronics products business, partially offset by lower gross margin from the semiconductor business.

[0001628280-25-036650:mdna:55]
[same as prior period, unchanged from 0000889331-25-000099:mdna:47]

[0001628280-25-036650:mdna:56]
[same as prior period, unchanged from 0000889331-25-000099:mdna:48]

[0001628280-25-036650:mdna:57]
Net sales increased $10.4 million, or 6.2%, in the second quarter of 2025 compared to the second quarter of 2024 and included favorable changes in foreign exchange rates of $3.1 million or 1.8%. The net sales increase was primarily due to higher net sales of $7.1 million and $5.5 million in the passenger car products and the commercial vehicle businesses, respectively, driven by increased end market demand and favorable price.

[0001628280-25-036650:mdna:58]
Net sales increased $1.9 million, or 0.6%, in the first six months of 2025 compared to the first six months of 2024 and included favorable changes in foreign exchange rates of $0.9 million. The net sales increase was primarily due to higher net sales of $5.9 million and $3.8 million in the passenger car products and the commercial vehicle businesses respectively, driven by increased end market demand and favorable price, partially offset by lower automotive sensors business volume of $7.7 million driven by the strategic exit of certain lower margin products.

[0001628280-25-036650:mdna:59]
[same as prior period, unchanged from 0000889331-25-000099:mdna:50]

[0001628280-25-036650:mdna:60]
Operating income was $28.1 million, representing an increase of $12.8 million, or 84.3%, for the second quarter of 2025 compared to $15.2 million for the second quarter of 2024. The increase in operating income was primarily from the commercial vehicle and passenger car products businesses due to favorable price, volume leverage, and cost reduction initiatives. Operating margins increased from 9.0% in the second quarter of 2024 to 15.6% in the second quarter of 2025 primarily driven by improved gross margin from the commercial vehicle and passenger car products businesses.

[0001628280-25-036650:mdna:61]
Operating income was $47.0 million, representing an increase of $15.6 million, or 49.5%, for the first six months of 2025 compared to $31.4 million for the first six months of 2024. The increase in operating income was primarily from the commercial vehicle and passenger car products businesses due to favorable price, volume leverage, and cost reduction initiatives. Operating margins increased from 9.3% in the first six months of 2024 to 13.8% in the first six months of 2025 primarily driven by improved gross margin from the commercial vehicle and passenger car products businesses.

[0001628280-25-036650:mdna:62]
[same as prior period, unchanged from 0000889331-25-000099:mdna:52]

[0001628280-25-036650:mdna:63]
[same as prior period, unchanged from 0000889331-25-000099:mdna:53]

[0001628280-25-036650:mdna:64]
Net sales increased $14.5 million, or 17.2%, in the second quarter of 2025 compared to the second quarter of 2024 and included favorable changes in foreign exchange rates of $0.2 million. The net sales increase was due to higher volume from industrial control and sensor and industrial circuit protection products driven by favorable price and higher end market demand.

[0001628280-25-036650:mdna:65]
Net sales increased $25.7 million, or 16.3%, in the first six months of 2025 compared to the first six months of 2024 and included unfavorable changes in foreign exchange rates of $0.4 million. The net sales increase was due to higher volume from industrial control and sensor and industrial circuit protection products driven by higher end market demand and favorable price.

[0001628280-25-036650:mdna:66]
[same as prior period, unchanged from 0000889331-25-000099:mdna:55]

[0001628280-25-036650:mdna:67]
Operating income was $18.9 million, representing an increase of $9.3 million, or 97.6%, for the second quarter of 2025 compared to $9.5 million for the second quarter of 2024. The increase in operating income was driven by higher net sales from industrial control and sensor and industrial circuit protection products driven by favorable price, increased end market demand and product mix. Operating margins increased from 11.4% in the second quarter of 2024 to 19.2% in the second quarter of 2025 due to favorable price and higher volume.

[0001628280-25-036650:mdna:68]
Operating income was $31.9 million, representing an increase of $17.6 million, or 122.7%, for the first six months of 2025 compared to $14.3 million for the first six months of 2024. The increase in operating income was driven by higher volume from industrial control and sensor and industrial circuit protection products driven by increased end market demand, favorable price and product mix. Operating margins increased from 9.1% in the first six months of 2024 to 17.4% in the first six months of 2025 due to higher volume and favorable price.

[0001628280-25-036650:mdna:69]
[same as prior period, unchanged from 0000889331-25-000099:mdna:57]

[0001628280-25-036650:mdna:70]
[same as prior period, unchanged from 0000889331-25-000099:mdna:58]

[0001628280-25-036650:mdna:71]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2025 |  | 2024 |  | Change |  | %Change |  | 2025 |  | 2024 |  | Change |  | %Change |
| Americas |  | $ | 249,440 |  |  | $ | 228,330 |  |  | $ | 21,110 |  |  | 9.2 | % |  | $ | 474,130 |  |  | $ | 443,114 |  |  | $ | 31,016 |  |  | 7.0 | % |
| Asia-Pacific |  | 223,803 |  |  | 214,100 |  |  | 9,703 |  |  | 4.5 | % |  | 429,087 |  |  | 407,789 |  |  | 21,298 |  |  | 5.2 | % |
| Europe |  | 140,170 |  |  | 116,059 |  |  | 24,111 |  |  | 20.8 | % |  | 264,503 |  |  | 242,971 |  |  | 21,532 |  |  | 8.9 | % |
| Total |  | $ | 613,413 |  |  | $ | 558,489 |  |  | $ | 54,924 |  |  | 9.8 | % |  | $ | 1,167,720 |  |  | $ | 1,093,874 |  |  | $ | 73,846 |  |  | 6.8 | % |

[0001628280-25-036650:mdna:72]
[same as prior period, unchanged from 0000889331-25-000099:mdna:60]

[0001628280-25-036650:mdna:73]
Net sales increased $21.1 million, or 9.2%, in the second quarter of 2025 compared to the second quarter of 2024. The increase in net sales was primarily due to higher volume from the Industrial segment, the electronics products business within the Electronics segment and the commercial vehicle businesses within the Transportation segment.

[0001628280-25-036650:mdna:74]
Net sales increased $31.0 million, or 7.0%, in the first six months of 2025 compared to the first six months of 2024 and included unfavorable changes in foreign exchange rates of $0.6 million. The increase in net sales was due to higher volume from the Industrial segment, the electronics products business within the Electronics segment, partially offset by lower volume from the passenger car product business within the Transportation segment.

[0001628280-25-036650:mdna:75]
[same as prior period, unchanged from 0000889331-25-000099:mdna:62]

[0001628280-25-036650:mdna:76]
Net sales increased $9.7 million, or 4.5%, in the second quarter of 2025 compared to the second quarter of 2024 and included favorable changes in foreign exchange rates of $0.8 million. The increase in net sales was primarily due to higher net sales from

[0001628280-25-036650:mdna:77]
the electronics products business within the Electronics segment and the passenger car products business within the Transportation segment, partially offset by lower volume from the semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:78]
Net sales increased $21.3 million, or 5.2%, in the first six months of 2025 compared to the first six months of 2024 and included unfavorable changes in foreign exchange rates of $1.8 million. The increase in net sales was primarily due to higher net sales from the electronics products business within the Electronics segment and the passenger car products and the commercial vehicle businesses within the Transportation segment, partially offset by lower volume from the semiconductor business within the Electronics segment and the automotive sensor business within the Transportation segment.

[0001628280-25-036650:mdna:79]
[same as prior period, unchanged from 0000889331-25-000099:mdna:64]

[0001628280-25-036650:mdna:80]
Net sales increased $24.1 million, or 20.8%, in the second quarter of 2025 compared to the second quarter of 2024 and included favorable changes in foreign exchange rates of $6.2 million. The increase in net sales was primarily due to $13.4 million or 2.4% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and higher net sales from the electronics products business within the Electronics segment.

[0001628280-25-036650:mdna:81]
Net sales increased $21.5 million, or 8.9%, in the first six months of 2025 compared to the first six months of 2024 and included favorable changes in foreign exchange rates of $2.8 million. The increase in net sales was primarily due to $23.5 million or 2.2% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment.

[0001628280-25-036650:mdna:82]
[same as prior period, unchanged from 0000889331-25-000099:mdna:66]

[0001628280-25-036650:mdna:83]
[same as prior period, unchanged from 0000889331-25-000099:mdna:67]

[0001628280-25-036650:mdna:84]
Cash and cash equivalents were $685.2 million as of June 28, 2025, a decrease of $39.7 million, as compared to December 28, 2024. As of June 28, 2025, $265.1 million of the Company's $685.2 million cash and cash equivalents was held by U.S. subsidiaries.

[0001628280-25-036650:mdna:85]
Revolving Credit Facility and Term Loan

[0001628280-25-036650:mdna:86]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-25-036650:mdna:87]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-25-036650:mdna:88]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months

[0001628280-25-036650:mdna:89]
ended June 28, 2025, the Company made term loan payments of $3.8 million and $7.5 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $273.8 million, respectively, as of June 28, 2025.

[0001628280-25-036650:mdna:90]
[same as prior period, unchanged from 0000889331-25-000099:mdna:74]

[0001628280-25-036650:mdna:91]
As of June 28, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.68%, and 4.13% on the hedged portion.

[0001628280-25-036650:mdna:92]
As of June 28, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of June 28, 2025, the Company was in compliance with all covenants under the Credit Agreement.

[0001628280-25-036650:mdna:93]
[same as prior period, unchanged from 0000889331-25-000099:mdna:77]

[0001628280-25-036650:mdna:94]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due on December 8, 2023. Interest on the Euro Senior Notes due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-25-036650:mdna:95]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-25-036650:mdna:96]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025. Interest on the U.S. Senior Notes, series B due 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0001628280-25-036650:mdna:97]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-25-036650:mdna:98]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-25-036650:mdna:99]
[same as prior period, unchanged from 0000889331-25-000099:mdna:83]

[0001628280-25-036650:mdna:100]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage.

[0001628280-25-036650:mdna:101]
[same as prior period, unchanged from 0000889331-25-000099:mdna:85]

[0001628280-25-036650:mdna:102]
Debt Covenants

[0001628280-25-036650:mdna:103]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of June 28, 2025 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2024. As of June 28, 2025, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0001628280-25-036650:mdna:104]
[same as prior period, unchanged from 0000889331-25-000099:mdna:88]

[0001628280-25-036650:mdna:105]
[same as prior period, unchanged from 0000889331-25-000099:mdna:89]

[0001628280-25-036650:mdna:106]
[same as prior period, unchanged from 0000889331-25-000099:mdna:90]

[0001628280-25-036650:mdna:107]
During the second quarter of 2025, the Company paid quarterly dividends of $17.3 million to its shareholders. On July 30, 2025, the Company announced the declaration of a quarterly cash dividend of $0.75 per share, a 7% increase from the first quarter, payable on September 4, 2025 to stockholders of record as of August 21, 2025.

[0001628280-25-036650:mdna:108]
[same as prior period, unchanged from 0000889331-25-000099:mdna:92]

[0001628280-25-036650:mdna:109]
|  |  | First Six Months |
| (in thousands) |  | 2025 |  | 2024 |
| Net cash provided by operating activities |  | $ | 148,225 |  |  | $ | 126,574 |  |
| Net cash used in investing activities |  | (89,704) |  |  | (26,677) |  |
| Net cash used in financing activities |  | (120,543) |  |  | (79,290) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 22,468 |  |  | (14,434) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash |  | (39,554) |  |  | 6,173 |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 726,437 |  |  | 557,123 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 686,883 |  |  | $ | 563,296 |  |

[0001628280-25-036650:mdna:110]
[same as prior period, unchanged from 0000889331-25-000099:mdna:94]

[0001628280-25-036650:mdna:111]
[same as prior period, unchanged from 0000889331-25-000099:mdna:95]

[0001628280-25-036650:mdna:112]
Net cash provided by operating activities was $148.2 million for the six months ended June 28, 2025 compared to $126.6 million for the six months ended June 29, 2024. The increase in net cash provided by operating activities was primarily due to higher cash earnings.

[0001628280-25-036650:mdna:113]
[same as prior period, unchanged from 0000889331-25-000099:mdna:97]

[0001628280-25-036650:mdna:114]
Net cash used in investing activities was $89.7 million for the six months ended June 28, 2025 compared to $26.7 million during the six months ended June 29, 2024. Net cash paid for the Dortmund Fab acquisition was $57.4 million during the six months ended June 28, 2025. Capital expenditures were $33.0 million, representing a decrease of $1.7 million, compared to the six months ended June 29, 2024. During the six months ended June 29, 2024, the Company received proceeds of $8.7 million from the sale of two buildings within the Transportation segment.

[0001628280-25-036650:mdna:115]
[same as prior period, unchanged from 0000889331-25-000099:mdna:99]

[0001628280-25-036650:mdna:116]
Net cash used in financing activities was $120.5 million for the six months ended June 28, 2025 compared to $79.3 million for the six months ended June 29, 2024. During the six months ended June 28, 2025, the Company paid off $50 million of U.S. Senior Notes, Series A, due February 15, 2025 and made payments of $7.5 million on the term loan. During the six months ended June 29, 2024, the Company made payments of $3.8 million on the term loan. The Company paid dividends of $34.7 million and $32.3 million in the six months ended June 28, 2025 and June 29, 2024, respectively. In addition, during the six months ended June 28, 2025 and June 29, 2024, the Company repurchased 120,689 shares of its common stock totaling $27.4 million and 179,311 shares of its common stock totaling $40.9 million, respectively. The Company paid a $0.2 million excise tax related to the share repurchases during the three and six months ended June 28, 2025.

[0001628280-25-036650:mdna:117]
[same as prior period, unchanged from 0000889331-25-000099:mdna:101]

[0001628280-25-036650:mdna:118]
On April 25, 2024, the Company's Board of Directors authorized a three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period from May 1, 2024 to April 30, 2027 ("2024 program") to replace its previous 2021 program. The Company did not repurchase shares of its common stock for the three months ended June 28, 2025. During the six months ended June 28, 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. During the three and six months ended June 29, 2024, the Company repurchased 109,031 and 179,311 shares of its common stock totaling $24.7 million and $40.9 million, respectively, of which $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program.

[0001628280-25-036650:mdna:119]
[same as prior period, unchanged from 0000889331-25-000099:mdna:103]

[0001628280-25-036650:mdna:120]
As of June 28, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-25-036650:mdna:121]
[same as prior period, unchanged from 0000889331-25-000099:mdna:105]

[0001628280-25-036650:mdna:122]
[same as prior period, unchanged from 0000889331-25-000099:mdna:106]

[0001628280-25-036650:mdna:123]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 28, 2024. During the six months ended June 28, 2025, there were no significant changes in the application of critical accounting policies and estimates.
