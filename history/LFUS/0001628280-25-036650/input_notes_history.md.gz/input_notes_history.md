# LFUS note change history — 0000889331-25-000099 → 0001628280-25-036650


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001628280-25-036650:note_history:1]
As of June 28, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.
  (was, 2025-04-30, similarity 0.9921):
[0000889331-25-000099:note_history:1]
As of March 29, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

- changed (2025-07-30):
[0001628280-25-036650:note_history:2]
There were no material pending litigation or claims outstanding as of June 28, 2025.
  (was, 2025-04-30, similarity 0.9427):
[0000889331-25-000099:note_history:2]
There were no material pending litigation or claims outstanding as of March 29, 2025.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001628280-25-036650:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 28, 2025 and June 29, 2024:
  (was, 2025-04-30, similarity 0.9044):
[0000889331-25-000099:note_history:3]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 29, 2025 and March 30, 2024:

- added (2025-07-30):
[0001628280-25-036650:note_history:4]
|  |  | Three Months Ended June 28, 2025 |  | Six Months Ended June 28, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 166,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 166,967 |  |  | $ | 325,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,256 |  |
| Electronics – Passive Products and Sensors |  | 168,699 |  |  | — |  |  | — |  |  | 168,699 |  |  | 317,659 |  |  | — |  |  | — |  |  | 317,659 |  |
| Commercial Vehicle Products |  | — |  |  | 86,260 |  |  | — |  |  | 86,260 |  |  | — |  |  | 164,029 |  |  | — |  |  | 164,029 |  |
| Passenger Car Products |  | — |  |  | 76,151 |  |  | — |  |  | 76,151 |  |  | — |  |  | 145,186 |  |  | — |  |  | 145,186 |  |
| Automotive Sensors |  | — |  |  | 16,989 |  |  | — |  |  | 16,989 |  |  | — |  |  | 32,047 |  |  | — |  |  | 32,047 |  |
| Industrial Products |  | — |  |  | — |  |  | 98,347 |  |  | 98,347 |  |  | — |  |  | — |  |  | 183,543 |  |  | 183,543 |  |
| Total |  | $ | 335,666 |  |  | $ | 179,400 |  |  | $ | 98,347 |  |  | $ | 613,413 |  |  | $ | 642,915 |  |  | $ | 341,262 |  |  | $ | 183,543 |  |  | $ | 1,167,720 |  |

- added (2025-07-30):
[0001628280-25-036650:note_history:5]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  |  |  |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

- changed (2025-07-30):
[0001628280-25-036650:note_history:6]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on
  (was, 2025-04-30, similarity 0.923):
[0000889331-25-000099:note_history:6]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2025-07-30):
[0001628280-25-036650:note_history:7]
historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- changed (2025-07-30):
[0001628280-25-036650:note_history:8]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at June 28, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2025-04-30, similarity 0.9843):
[0000889331-25-000099:note_history:8]
The following table provides a reconciliation of cash, cash equivalents, and restricted cash at March 29, 2025 and December 28, 2024 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2025-07-30):
[0001628280-25-036650:note_history:9]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 685,184 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,699 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 686,883 |  |  | $ | 726,437 |  |
  (was, 2025-04-30, similarity 0.9821):
[0000889331-25-000099:note_history:9]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Cash and cash equivalents |  | $ | 618,687 |  |  | $ | 724,924 |  |
| Restricted cash included in other long-term assets |  | 1,569 |  |  | 1,513 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 620,256 |  |  | $ | 726,437 |  |

- changed (2025-07-30):
[0001628280-25-036650:note_history:10]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.
  (was, 2025-04-30, similarity 0.9994):
[0000889331-25-000099:note_history:10]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)-(v); (b) include certain amounts that are already required to be disclosed under current GAAP in the same disclosure as the other disaggregation requirements; (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively; (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.

- changed (2025-07-30):
[0001628280-25-036650:note_history:11]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may
  (was, 2025-04-30, similarity 0.6339):
[0000889331-25-000099:note_history:11]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.

- added (2025-07-30):
[0001628280-25-036650:note_history:12]
be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.

- removed (2025-07-30):
[0000889331-25-000099:note_history:13]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |

- removed (2025-07-30):
[0000889331-25-000099:note_history:14]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001628280-25-036650:note_history:15]
The carrying amounts of debt at June 28, 2025 and December 28, 2024 were as follows:
  (was, 2025-04-30, similarity 0.9396):
[0000889331-25-000099:note_history:15]
The carrying amounts of debt at March 29, 2025 and December 28, 2024 were as follows:

- changed (2025-07-30):
[0001628280-25-036650:note_history:16]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 273,750 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,079 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 2,692 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,305) |  |  | (2,766) |  |
| Total debt |  | 810,216 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,692) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 792,524 |  |  | $ | 788,502 |  |
  (was, 2025-04-30, similarity 0.9926):
[0000889331-25-000099:note_history:16]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 277,500 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,557 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 3,163 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,530) |  |  | (2,766) |  |
| Total debt |  | 805,690 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,710) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 787,980 |  |  | $ | 788,502 |  |

- changed (2025-07-30):
[0001628280-25-036650:note_history:17]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three and six months ended June 28, 2025, the Company made term loan payments of $3.8 million and $7.5 million, respectively. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $273.8 million, respectively, as of June 28, 2025.
  (was, 2025-04-30, similarity 0.8884):
[0000889331-25-000099:note_history:17]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended March 29, 2025, the Company made term loan payments of $3.8 million. The revolving loan and term loan balances under the Credit Facility were $100.0 million and $277.5 million, respectively, as of March 29, 2025.

- changed (2025-07-30):
[0001628280-25-036650:note_history:18]
As of June 28, 2025, the effective interest rate on the unhedged portion of the outstanding borrowings under the credit facility was 5.68%, and 4.13% on the hedged portion.
  (was, 2025-04-30, similarity 0.959):
[0000889331-25-000099:note_history:18]
As of March 29, 2025, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 5.42%, and 4.13% on the hedged portion.

- added (2025-07-30):
[0001628280-25-036650:note_history:19]
As of June 28, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of June 28, 2025, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2025-07-30):
[0001628280-25-036650:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of June 28, 2025, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2025-04-30, similarity 0.9921):
[0000889331-25-000099:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of March 29, 2025, the Company was in compliance with all covenants under the Senior Notes.

- added (2025-07-30):
[0001628280-25-036650:note_history:21]
Interest paid on all Company debt was $5.6 million and $6.4 million for the three months ended June 28, 2025 and June 29, 2024, respectively, and $17.8 million and $19.6 million for the six months ended June 28, 2025 and June 29, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.

- removed (2025-07-30):
[0000889331-25-000099:note_history:22]
As of March 29, 2025, the Company had $0.1 million outstanding letters of credit and had $599.9 million of borrowing capacity available under the revolving credit facility. As of March 29, 2025, the Company was in compliance with all covenants under the Credit Agreement.

- removed (2025-07-30):
[0000889331-25-000099:note_history:23]
Interest paid on all Company debt was $12.2 million and $13.2 million for the three months ended March 29, 2025 and March 30, 2024, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001628280-25-036650:note_history:24]
The carrying amounts of debt at June 28, 2025 and December 28, 2024 were as follows:
  (was, 2025-04-30, similarity 0.9396):
[0000889331-25-000099:note_history:24]
The carrying amounts of debt at March 29, 2025 and December 28, 2024 were as follows:

- changed (2025-07-30):
[0001628280-25-036650:note_history:25]
| (in thousands) |  | June 28, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 273,750 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 111,079 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 2,692 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,305) |  |  | (2,766) |  |
| Total debt |  | 810,216 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,692) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 792,524 |  |  | $ | 788,502 |  |
  (was, 2025-04-30, similarity 0.9926):
[0000889331-25-000099:note_history:25]
| (in thousands) |  | March 29, 2025 |  | December 28, 2024 |
| Revolving credit facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan |  | 277,500 |  |  | 281,250 |  |
| Euro Senior Notes, Series B due 2028 |  | 102,557 |  |  | 98,928 |  |
| U.S. Senior Notes, Series A due 2025 |  | — |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 3,163 |  |  | 3,702 |  |
| Unamortized debt issuance costs |  | (2,530) |  |  | (2,766) |  |
| Total debt |  | 805,690 |  |  | 856,114 |  |
| Less: Current maturities |  | (17,710) |  |  | (67,612) |  |
| Total long-term debt |  | $ | 787,980 |  |  | $ | 788,502 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001628280-25-036650:note_history:26]
EB Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.
  (was, 2025-04-30, similarity 0.9945):
[0000889331-25-000099:note_history:26]
EB-Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

- changed (2025-07-30):
[0001628280-25-036650:note_history:27]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One of the Company's executive officers serves on the Board of Directors of ATEC.
  (was, 2025-04-30, similarity 0.9888):
[0000889331-25-000099:note_history:27]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's executive officers serves on the Board of Directors of ATEC.

- added (2025-07-30):
[0001628280-25-036650:note_history:28]
|  |  | Three Months Ended June 28, 2025 |  | Three Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.5 |  | 1.4 |  |  | 1.2 |  | 0.2 |  | 0.8 |  |
|  |  | Six Months Ended June 28, 2025 |  | Six Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.6 |  | $ | — |  | $ | — |  |  | $ | 0.9 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.7 |  | 3.3 |  |  | 2.4 |  | 0.4 |  | 2.9 |  |
|  |  | June 28, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | — |  | 0.1 |  | 0.6 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |

- removed (2025-07-30):
[0000889331-25-000099:note_history:29]
|  |  | Three Months Ended March 29, 2025 |  | Three Months Ended March 30, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.5 |  | 0.2 |  | 1.9 |  |  | 1.2 |  | 0.2 |  | 2.1 |  |
|  |  | March 29, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2025-07-30):
[0001628280-25-036650:note_history:30]
|  |  | Three Months Ended June 28, 2025 |  | Three Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.6 |  | 0.5 |  | 1.4 |  |  | 1.2 |  | 0.2 |  | 0.8 |  |
|  |  | Six Months Ended June 28, 2025 |  | Six Months Ended June 29, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.6 |  | $ | — |  | $ | — |  |  | $ | 0.9 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 1.1 |  | 0.7 |  | 3.3 |  |  | 2.4 |  | 0.4 |  | 2.9 |  |
|  |  | June 28, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts receivable balance |  | $ | 0.1 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Accounts payable balance |  | — |  | 0.1 |  | 0.6 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |

- removed (2025-07-30):
[0000889331-25-000099:note_history:31]
|  |  | Three Months Ended March 29, 2025 |  | Three Months Ended March 30, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.3 |  | $ | — |  | $ | — |  |  | $ | 0.5 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.5 |  | 0.2 |  | 1.9 |  |  | 1.2 |  | 0.2 |  | 2.1 |  |
|  |  | March 29, 2025 |  | December 28, 2024 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | 0.1 |  | 0.1 |  | 0.9 |  |  | 0.7 |  | 0.1 |  | 0.7 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001628280-25-036650:note_history:32]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended June 28, 2025 and June 29, 2024:
  (was, 2025-04-30, similarity 0.9044):
[0000889331-25-000099:note_history:32]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended March 29, 2025 and March 30, 2024:

- added (2025-07-30):
[0001628280-25-036650:note_history:33]
|  |  | Three Months Ended June 28, 2025 |  | Six Months Ended June 28, 2025 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 166,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 166,967 |  |  | $ | 325,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,256 |  |
| Electronics – Passive Products and Sensors |  | 168,699 |  |  | — |  |  | — |  |  | 168,699 |  |  | 317,659 |  |  | — |  |  | — |  |  | 317,659 |  |
| Commercial Vehicle Products |  | — |  |  | 86,260 |  |  | — |  |  | 86,260 |  |  | — |  |  | 164,029 |  |  | — |  |  | 164,029 |  |
| Passenger Car Products |  | — |  |  | 76,151 |  |  | — |  |  | 76,151 |  |  | — |  |  | 145,186 |  |  | — |  |  | 145,186 |  |
| Automotive Sensors |  | — |  |  | 16,989 |  |  | — |  |  | 16,989 |  |  | — |  |  | 32,047 |  |  | — |  |  | 32,047 |  |
| Industrial Products |  | — |  |  | — |  |  | 98,347 |  |  | 98,347 |  |  | — |  |  | — |  |  | 183,543 |  |  | 183,543 |  |
| Total |  | $ | 335,666 |  |  | $ | 179,400 |  |  | $ | 98,347 |  |  | $ | 613,413 |  |  | $ | 642,915 |  |  | $ | 341,262 |  |  | $ | 183,543 |  |  | $ | 1,167,720 |  |

- added (2025-07-30):
[0001628280-25-036650:note_history:34]
|  |  | Three Months Ended June 29, 2024 |  | Six Months Ended June 29, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 159,564 |  |  | $ | — |  |  | $ | — |  |  | $ | 159,564 |  |  | $ | 317,435 |  |  | $ | — |  |  | $ | — |  |  | $ | 317,435 |  |
| Electronics – Passive Products and Sensors |  | 146,075 |  |  | — |  |  | — |  |  | 146,075 |  |  | 279,309 |  |  | — |  |  | — |  |  | 279,309 |  |
| Commercial Vehicle Products |  | — |  |  | 80,759 |  |  | — |  |  | 80,759 |  |  | — |  |  | 160,273 |  |  | — |  |  | 160,273 |  |
| Passenger Car Products |  | — |  |  | 69,036 |  |  | — |  |  | 69,036 |  |  | — |  |  | 139,298 |  |  | — |  |  | 139,298 |  |
| Automotive Sensors |  | — |  |  | 19,169 |  |  | — |  |  | 19,169 |  |  | — |  |  | 39,760 |  |  | — |  |  | 39,760 |  |
| Industrial Products |  | — |  |  | — |  |  | 83,886 |  |  | 83,886 |  |  |  |  |  |  | 157,799 |  |  | 157,799 |  |
| Total |  | $ | 305,639 |  |  | $ | 168,964 |  |  | $ | 83,886 |  |  | $ | 558,489 |  |  | $ | 596,744 |  |  | $ | 339,331 |  |  | $ | 157,799 |  |  | $ | 1,093,874 |  |

- removed (2025-07-30):
[0000889331-25-000099:note_history:35]
|  |  | Three Months Ended March 29, 2025 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 158,289 |  |  | $ | — |  |  | $ | — |  |  | $ | 158,289 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 148,960 |  |  | — |  |  | — |  |  | 148,960 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 77,769 |  |  | — |  |  | 77,769 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 69,035 |  |  | — |  |  | 69,035 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 15,058 |  |  | — |  |  | 15,058 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 85,196 |  |  | 85,196 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 307,249 |  |  | $ | 161,862 |  |  | $ | 85,196 |  |  | $ | 554,307 |  |  |  |  |  |  |  |  |  |

- removed (2025-07-30):
[0000889331-25-000099:note_history:36]
|  |  | Three Months Ended March 30, 2024 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | $ | 157,871 |  |  | $ | — |  |  | $ | — |  |  | $ | 157,871 |  |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | 133,234 |  |  | — |  |  | — |  |  | 133,234 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 79,514 |  |  | — |  |  | 79,514 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 70,262 |  |  | — |  |  | 70,262 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,591 |  |  | — |  |  | 20,591 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,913 |  |  | 73,913 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 291,105 |  |  | $ | 170,367 |  |  | $ | 73,913 |  |  | $ | 535,385 |  |  |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001628280-25-036650:note_history:37]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on
  (was, 2025-04-30, similarity 0.923):
[0000889331-25-000099:note_history:37]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2025-07-30):
[0001628280-25-036650:note_history:38]
historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-07-30):
[0001628280-25-036650:note_history:39]
Subsequent Events
