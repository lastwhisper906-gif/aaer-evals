# LFUS notes — 0001437749-16-031011


## us-gaap:AssetImpairmentChargesTextBlock

[0001437749-16-031011:notes:1]
13. Product Line Sale

[0001437749-16-031011:notes:2]
During the first quarter of 2016, the company sold its tangible and intangible assets relating to a marine product line. In connection with this sale, the company recorded asset charges of $1.4 million within Cost of sales ($0.4 million), Selling, general and administrative expenses (less than $0.1 million), Research and development expenses (less than $0.1 million) and Amortization of intangibles ($0.9) million. These charges were recognized as an “other” charge for segment reporting purposes.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-16-031011:notes:3]
|  |  | For the Three Months Ended |  |
| (in thousands, except per share amounts) |  | April 2, 2016 |  |  | March 28, 2015 |  |
| Net sales |  | $ | 253,608 |  |  | $ | 256,133 |  |
| Income before income taxes |  |  | 31,432 |  |  |  | 22,420 |  |
| Net income |  |  | 24,424 |  |  |  | 18,560 |  |
| Net income per share — basic |  |  | 1.09 |  |  |  | 0.82 |  |
| Net income per share — diluted |  |  | 1.08 |  |  |  | 0.81 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-16-031011:notes:4]
12. Accumulated Other Comprehensive Income (Loss) (AOCI)

[0001437749-16-031011:notes:5]
[same as prior period, unchanged from 0001437749-15-019169:notes:2]

[0001437749-16-031011:notes:6]
| AOCI component |  | Balance at January 2, 2016 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Balance at April 2, 2016 |  |
| Pension and postemployment liability and reclassification adjustments(a) |  | $ | (8,722 | ) |  | $ | 92 |  |  | $ | 73 |  |  | $ | (8,557 | ) |
| Unrealized gain on investments(b) |  |  | 11,584 |  |  |  | (1,234 | ) |  |  | — |  |  |  | 10,350 |  |
| Foreign currency translation adjustment |  |  | (48,533 | ) |  |  | 11,755 |  |  |  | — |  |  |  | (36,778 | ) |
| AOCI (loss) income |  | $ | (45,671 | ) |  | $ | 10,613 |  |  | $ | 73 |  |  | $ | (34,985 | ) |

[0001437749-16-031011:notes:7]
(a) Balances are net of tax of $649 and $661 for 2016 and 2015, respectively.

[0001437749-16-031011:notes:8]
(b) Balances are net of tax of $0 and $0 for 2016 and 2015, respectively.


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0001437749-16-031011:notes:9]
5. Investments

[0001437749-16-031011:notes:10]
The company’s investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company

[0001437749-16-031011:notes:11]
, and shares of Monolith Semiconductor, Inc. (“Monolith”), a Texas-based start-up company.

[0001437749-16-031011:notes:12]
Polytronics

[0001437749-16-031011:notes:13]
The Polytronics investment was acquired as part of the Littelfuse GmbH acquisition. The fair value of the Polytronics investment was €9.6 million (approximately $10.9 million) at April 2, 2016 and €10.7 million (approximately $11.7 million) at January 2, 2016. Included in 2016 other comprehensive income is an unrealized loss of $1.3 million, due to the decrease in fair market value of the Polytronics investment. The remaining movement was due to the impact of changes in exchange rates.

[0001437749-16-031011:notes:14]
Monolith

[0001437749-16-031011:notes:15]
In December, 2015, the company invested $3.5 million in the preferred stock of Monolith, a U.S. start-up company developing silicon carbide technology, which represents approximately 12% of the common stock of Monolith on an as-converted basis. The company accounts for its investment in Monolith under the cost method. The value of the Monolith investment was $3.5 million at April 2, 2016 and January 2, 2016.


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-031011:notes:16]
6. Debt

[0001437749-16-031011:notes:17]
The carrying amounts of debt at April 2, 2016 and January 2, 2016 are as follows (in thousands):

[0001437749-16-031011:notes:18]
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 244,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 125,000 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,536 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (1,673 | ) |  |  | (721 | ) |
| Total debt |  |  | 377,363 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 371,113 |  |  | $ | 83,753 |  |

[0001437749-16-031011:notes:19]
Revolving Credit F

[0001437749-16-031011:notes:20]
acility / Term Loan

[0001437749-16-031011:notes:21]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of April 2, 2016, the company had available $330.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (1.94% as of April 2, 2016). At April 2, 2016, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-16-031011:notes:22]
Entrusted Loan

[0001437749-16-031011:notes:23]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million at that time) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.5 million) at April 2, 2016.

[0001437749-16-031011:notes:24]
Debt Issuance Costs

[0001437749-16-031011:notes:25]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which will be amortized over the life of the new credit agreement.

[0001437749-16-031011:notes:26]
In April 2015, the FASB issued ASU No. 2015-03, 
Interest - Imputation of Interest
 (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The company adopted this guidance in the current quarter, on a retrospective basis, and has reclassified the unamortized debt issuance costs into long-term debt as shown in the table above.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-031011:notes:27]
8. Earnings per Share

[0001437749-16-031011:notes:28]
The following table sets forth the computation of basic and diluted earnings per share of April 2, 2016 and March 28, 2015 (in thousands, except per share amounts).

[0001437749-16-031011:notes:29]
|  |  | For the Three Months Ended |  |
|  |  | April 2, 2016 |  |  | March 28, 2015 |  |
| Net income |  | $ | 19,289 |  |  | $ | 19,995 |  |
| Average shares outstanding - Basic |  |  | 22,438 |  |  |  | 22,600 |  |
| Net effect of dilutive stock options and restricted share units |  |  | 183 |  |  |  | 181 |  |
| Average shares - Diluted |  |  | 22,621 |  |  |  | 22,781 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | 0.88 |  |
| Diluted |  | $ | 0.85 |  |  | $ | 0.88 |  |

[0001437749-16-031011:notes:30]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 21,888 and 64,520 for the three months ended April 2, 2016

[0001437749-16-031011:notes:31]
and March 28

[0001437749-16-031011:notes:32]
[same as prior period, unchanged from 0001437749-15-019169:notes:23]

[0001437749-16-031011:notes:33]
[same as prior period, unchanged from 0001437749-15-019169:notes:26]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-16-031011:notes:34]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,927 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,927 |  |
| Total |  | $ | 10,927 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,927 |  |

[0001437749-16-031011:notes:35]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 11,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,697 |  |
| Total |  | $ | 11,697 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,697 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-16-031011:notes:36]
7. Fair Value of Assets and Liabilities

[0001437749-16-031011:notes:37]
[same as prior period, unchanged from 0001437749-15-019169:notes:31]

[0001437749-16-031011:notes:38]
[same as prior period, unchanged from 0001437749-15-019169:notes:32]

[0001437749-16-031011:notes:39]
[same as prior period, unchanged from 0001437749-15-019169:notes:33]

[0001437749-16-031011:notes:40]
[same as prior period, unchanged from 0001437749-15-019169:notes:34]

[0001437749-16-031011:notes:41]
[same as prior period, unchanged from 0001437749-15-019169:notes:35]

[0001437749-16-031011:notes:42]
[same as prior period, unchanged from 0001437749-15-019169:notes:36]

[0001437749-16-031011:notes:43]
Investments

[0001437749-16-031011:notes:44]
The company holds an investment in the equity securities of Polytronics as described in Note 5. Equity securities listed on a national market or exchange are valued at the last sales price. Such securities are classified within Level 1 of the valuation hierarchy. The company also holds an investment in Monolith as described in Note 5 for which the value of the $3.5 million represents the cost of the investment.

[0001437749-16-031011:notes:45]
There were no changes during the quarter ended April 2, 2016 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of April 2, 2016 and January 2, 2016 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-16-031011:notes:46]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of April 2, 2016 (in thousands):

[0001437749-16-031011:notes:47]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of January 2, 2016 (in thousands):

[0001437749-16-031011:notes:48]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt. The carrying amounts of cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt approximate their fair values. The company’s debt fair value approximates book value at April 2, 2016 and January 2, 2016, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-031011:notes:49]
9. Income Taxes

[0001437749-16-031011:notes:50]
The effective tax rate for the first quarter of 2016 was 28.8% compared to an effective tax rate of 24.3% in the first quarter of 2015. The effective tax rates for both 2016 and 2015 are lower than the U.S. statutory tax rate primarily due to the result of more income earned in lower tax jurisdictions.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-16-031011:notes:51]
4. Inventories

[0001437749-16-031011:notes:52]
The components of inventories at April 2, 2016 and January 2, 2016 are as follows (in thousands):

[0001437749-16-031011:notes:53]
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
| Raw material |  | $ | 36,772 |  |  | $ | 33,599 |  |
| Work in process |  |  | 26,201 |  |  |  | 16,479 |  |
| Finished goods |  |  | 70,189 |  |  |  | 48,551 |  |
| Total inventories |  | $ | 133,162 |  |  | $ | 98,629 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-16-031011:notes:54]
3. Acquisition of Businesses

[0001437749-16-031011:notes:55]
PolySwitch

[0001437749-16-031011:notes:56]
On March 25, 2016, the company acquired 100% of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for $350.0 million, subject to certain post-closing adjustments. At April 2, 2016, $70.0 million of the purchase price remained payable subject to certain Chinese regulatory approvals. The company expects to receive these approvals and pay the additional consideration during its fiscal 2016 second quarter. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-16-031011:notes:57]
has a leading position in polymer based resettable circuit protection devices, with a strong global presence in the automotive, battery, industrial, communications and mobile computing markets. PolySwitch has operations in Menlo Park, California and manufacturing facilities in Shanghai and Kunshan, China and Tsukuba, Japan. The acquisition allows the company to strengthen its global circuit protection product portfolio, as well as strengthen its presence in the automotive electronics and battery end markets. The acquisition also significantly increases the company’s presence in Japan. The company funded the acquisition with available cash and proceeds from a new credit facility

[0001437749-16-031011:notes:58]
.

[0001437749-16-031011:notes:59]
The following table represents the preliminary allocation of the total consideration to assets acquired and liabilities assumed in the acquisition of PolySwitch based on the Company’s preliminary estimate of their respective fair values at the acquisition date (in thousands):

[0001437749-16-031011:notes:60]
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 280,000 |  |
| Consideration payable upon certain Chinese regulatory approvals |  |  | 70,000 |  |
| Total purchase consideration |  | $ | 350,000 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Cash |  | $ | 16,958 |  |
| Current assets, net |  |  | 56,992 |  |
| Property, plant and equipment |  |  | 63,903 |  |
| Patented and unpatented technologies |  |  | 56,137 |  |
| Customer relationships |  |  | 53,194 |  |
| Goodwill |  |  | 120,208 |  |
| Other long-term assets |  |  | 19,555 |  |
| Current liabilities |  |  | (35,291 | ) |
| Other non-current liabilities |  |  | (1,656 | ) |
|  |  | $ | 350,000 |  |

[0001437749-16-031011:notes:61]
All PolySwitch goodwill and other assets and liabilities were recorded in the Automotive and Electronics segments and reflected both the Asia-Pacific and Europe geographical areas. The customer relationships are anticipated to be amortized over 15 years. The patented and unpatented technologies are anticipated to be amortized over 10 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining PolySwitch products with the company’s existing automotive and electronics product portfolio. A portion of the goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-16-031011:notes:62]
As required by purchase accounting rules, the company recorded a $8.0 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up is anticipated to be amortized during the second quarter of 2016, as a portion of this inventory is sold and charged to cost of goods sold as a non-cash charge for this step-up.

[0001437749-16-031011:notes:63]
The company’s unaudited Condensed Consolidated Financial Statements as of April 2, 2016 include the opening balance sheet for the PolySwitch business but do not include any income statement activity of the acquired business as the operating results are not material to the company's financial statements for the three months ended April 2, 2016. The operating results of PolySwitch for the nine day period of March 25, 2016 through April 2, 2016 will be included within the company’s statement of income for the quarter ended July 2, 2016.

[0001437749-16-031011:notes:64]
The company incurred legal, professional and other costs related to this acquisition aggregating approximately $5.9 million for the three months ended April 2, 2016. These costs were recognized as selling and administrative expenses and reflected as other non-segment costs.

[0001437749-16-031011:notes:65]
Sigmar S.r.l

[0001437749-16-031011:notes:66]
On October 1, 2015, the company acquired 100% of Sigmar S.r.l. (“Sigmar”). The total purchase price for Sigmar was $6.2 million, net of cash acquired and including additional consideration of $1.1 million paid in the first quarter of 2016 relating to certain working capital related adjustments and an earn-out clause payment. The purchase price remains subject to an inventory related post-closing adjustment and additional payments of up to $0.4 million, subject to the achievement of certain milestones.

[0001437749-16-031011:notes:67]
Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel and selective catalytic reduction (SCR) quality sensors, as well as diesel fuel heaters, solenoid valves and rotating oil filters for automotive and commercial vehicle applications. The acquisition further expanded the company’s automotive sensor product line offerings within its Automotive segment. The company funded the acquisition with available cash.

[0001437749-16-031011:notes:68]
The following table sets forth the preliminary purchase price allocation for Sigmar acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values:

[0001437749-16-031011:notes:69]
| Sigmar preliminary purchase price allocation (in thousands): |  |
| Cash |  | $ | 230 |  |
| Current assets, net |  |  | 4,011 |  |
| Property, plant and equipment |  |  | 1,097 |  |
| Goodwill |  |  | 2,271 |  |
| Patents |  |  | 2,845 |  |
| Current liabilities |  |  | (1,478 | ) |
| Other non-current liabilities |  |  | (2,568 | ) |
|  |  | $ | 6,408 |  |

[0001437749-16-031011:notes:70]
All Sigmar goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographical area. The patents are being amortized over 10 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining Sigmar’s products with the company’s existing automotive product offerings. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-16-031011:notes:71]
Pro Forma Results

[0001437749-16-031011:notes:72]
The following table summarizes, on a pro forma basis, the combined results of operations of the company and PolySwitch as though the acquisition had occurred as of December 28, 2014. The company has not provided Pro forma results of operations for Sigmar as these results were not material to the company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the PolySwitch acquisition occurred as of December 28, 2014 or of future consolidated operating results

[0001437749-16-031011:notes:73]
Pro forma results presented above primarily reflect: (1) incremental depreciation relating to fair value adjustments to property, plant and equipment; (2) amortization adjustments relating to fair value estimates of intangible assets; (3) incremental interest expense on assumed indebtedness; and (4) additional cost of goods sold relating to the capitalization of gross profit which will be recognized during the company’s quarter ended July 2, 2016 as part of purchase accounting recognized for purposes of the pro forma as if it was recognized during the company’s first quarter of 2015. Pro forma adjustments described above have been tax affected using the company's effective rate during the respective periods.

[0001437749-16-031011:notes:74]
The historical PolySwitch results for the three months ended April 2, 2016 and March 28, 2015 do not include a provision for income taxes. Income tax expense for the historical PolySwitch business was only provided at the end of the business’s fiscal year ended September 25, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-16-031011:notes:75]
10. Pensions

[0001437749-16-031011:notes:76]
The components of net periodic benefit cost for the three months ended April 2, 2016, compared with the three months ended March 28, 2015, were (in thousands):

[0001437749-16-031011:notes:77]
|  |  | U.S. Plans |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | April 2, 2016* |  |  | March 28, 2015 |  |  | April 2, 2016 |  |  | March 28 2015 |  |
| Service cost |  | $ | — |  |  | $ | 250 |  |  | $ | 332 |  |  | $ | 315 |  |
| Interest cost |  |  | — |  |  |  | 1,031 |  |  |  | 497 |  |  |  | 513 |  |
| Expected return on plan assets |  |  | — |  |  |  | (916 | ) |  |  | (520 | ) |  |  | (600 | ) |
| Amortization of net loss |  |  | — |  |  |  | 290 |  |  |  | 73 |  |  |  | 61 |  |
| Total cost of the plan |  |  |  |  |  |  | 655 |  |  |  |  |  |  |  | 289 |  |
| Expected plan participants’ contribution |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net periodic benefit cost |  | $ | — |  |  | $ | 655 |  |  | $ | 382 |  |  | $ | 289 |  |

[0001437749-16-031011:notes:78]
* The U.S. pension plan was terminated effective July 30, 2014 and, following receipt of a favorable Letter of Determination from the IRS (dated April14, 2015), all liabilities of the plan were settled during the third quarter of fiscal 2015.

[0001437749-16-031011:notes:79]
The expected rate of return assumption on domestic pension assets was 3.90% in 2015. The expected return on foreign pension assets is 4.95% and 5.39% in 2016 and 2015, respectively.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-16-031011:notes:80]
|  |  | Long-lived assets(b) |  |
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
| United States |  | $ | 24,906 |  |  | $ | 23,965 |  |
| China |  |  | 78,840 |  |  |  | 37,241 |  |
| Canada |  |  | 11,069 |  |  |  | 10,488 |  |
| Other countries |  |  | 115,050 |  |  |  | 90,874 |  |
| Total |  | $ | 229,865 |  |  | $ | 162,568 |  |

[0001437749-16-031011:notes:81]
|  |  | Additions to long-lived assets |  |
|  |  | April 2, 2016 |  |  | March 28, 2015 |  |
| United States |  | $ | 1,618 |  |  | $ | 3,187 |  |
| China |  |  | 1,046 |  |  |  | 667 |  |
| Canada |  |  | 69 |  |  |  | 538 |  |
| Other countries |  |  | 6,406 |  |  |  | 7,887 |  |
| Total |  | $ | 9,139 |  |  | $ | 12,279 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001437749-16-031011:notes:82]
|  |  | Net sales(a) |  |
|  |  | April 2, 2016 |  |  | March 28, 2015 |  |
| United States |  | $ | 85,149 |  |  | $ | 83,373 |  |
| China |  |  | 48,509 |  |  |  | 44,429 |  |
| Other countries |  |  | 85,740 |  |  |  | 82,511 |  |
| Total |  | $ | 219,398 |  |  | $ | 210,313 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-16-031011:notes:83]
|  |  | April 2, 2016 |  |  | March 28, 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 98,796 |  |  | $ | 99,380 |  |
| Automotive |  |  | 91,933 |  |  |  | 84,071 |  |
| Industrial |  |  | 28,669 |  |  |  | 26,862 |  |
| Total net sales |  | $ | 219,398 |  |  | $ | 210,313 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 5,372 |  |  | $ | 5,798 |  |
| Automotive |  |  | 3,266 |  |  |  | 3,336 |  |
| Industrial |  |  | 1,451 |  |  |  | 1,284 |  |
| Other(1) |  |  | 937 |  |  |  | — |  |
| Total depreciation and amortization |  | $ | 11,026 |  |  | $ | 10,418 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 22,416 |  |  | $ | 18,665 |  |
| Automotive |  |  | 17,491 |  |  |  | 11,171 |  |
| Industrial |  |  | 1,673 |  |  |  | 2,730 |  |
| Other (2) |  |  | (9,152 | ) |  |  | (3,018 | ) |
| Total operating income |  |  | 32,428 |  |  |  | 29,548 |  |
| Interest expense |  |  | 2,045 |  |  |  | 1,151 |  |
| Foreign exchange loss |  |  | 3,823 |  |  |  | 3,117 |  |
| Other (income) expense, net |  |  | (517 | ) |  |  | (1,126 | ) |
| Income before income taxes |  | $ | 27,077 |  |  | $ | 26,406 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-031011:notes:84]
11. Segment and Geographic Information

[0001437749-16-031011:notes:85]
The company and its subsidiaries design, manufacture and sell circuit protection devices throughout the world. The company reports its operations by the following segments: Electronics, Automotive, and Industrial. Each operating segment is directly responsible for sales, marketing and research and development. Manufacturing, purchasing, logistics, customer service, finance, information technology and human resources are shared functions that are allocated back to the three operating segments. The CEO allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0001437749-16-031011:notes:86]
[same as prior period, unchanged from 0001437749-15-019169:notes:89]

[0001437749-16-031011:notes:87]
[same as prior period, unchanged from 0001437749-15-019169:notes:90]

[0001437749-16-031011:notes:88]
Segment information for the three months ended April 2, 2016 and March 28, 2015 are summarized as follows (in thousands):

[0001437749-16-031011:notes:89]
(1) Consists of intangible impairments. (See Note 13).

[0001437749-16-031011:notes:90]
(2) Consists of internal resorganization costs ($1.4 million), acquisition related expenses ($6.2 million) and impairment and severance costs related to the planned shut-down of the company’s Roskilde, Denmark operations ($1.6 million) (see Note 13).

[0001437749-16-031011:notes:91]
The company’s significant net sales by country for the three months ended April 2, 2016 and March 28, 2015 are summarized as follows (in thousands):

[0001437749-16-031011:notes:92]
[same as prior period, unchanged from 0001437749-15-019169:notes:94]

[0001437749-16-031011:notes:93]
The company’s significant long-lived assets and additions to long-lived assets by country as of April 2, 2016 and January 2, 2016 are summarized as follows (in thousands):

[0001437749-16-031011:notes:94]
(b) Long-lived assets consists of net property, plant and equipment.

[0001437749-16-031011:notes:95]
11. Segment and Geographic Information, continued


## us-gaap:SubsequentEventsTextBlock

[0001437749-16-031011:notes:96]
14

[0001437749-16-031011:notes:97]
) Subsequent Event

[0001437749-16-031011:notes:98]
On April 4, 2016, the company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy. The purchase price of €16.7 million

[0001437749-16-031011:notes:99]
($19.0 million) is subject to a working capital adjustment and was financed through a mixture of cash on hand and borrowings under the company's credit facility. The acquired business, which will be part of the company's Automotive segment, specializes in the design, manufacturing and selling of manual and electrical battery switches and trailer connectors for commercial vehicles. Menber’s had sales of approximately $23.0 million in 2015.

[0001437749-16-031011:notes:100]
The initial accounting for the acquisition is not complete pending detailed analyses of the facts and circumstances that existed as of the acquisition date.
