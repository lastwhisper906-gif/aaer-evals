# LFUS 8-K — 0001437749-16-030854 filed 2016-05-05

## item codes, every 8-K on or before 2016-05-06

- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2016-05-06

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-030854:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-030854:8k_2_02:2]
ex99-1.htm

[0001437749-16-030854:8k_2_02:3]
Exhibit 99.1

[0001437749-16-030854:8k_2_02:4]
LITTELFUSE REPORTS FIRST QUARTER RESULTS

[0001437749-16-030854:8k_2_02:5]
First Quarter Sales Ahead of Midpoint and Earnings Exceed High End of Guidance

[0001437749-16-030854:8k_2_02:6]
CHICAGO, May 5, 2016 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the first quarter ended April 2, 2016.

[0001437749-16-030854:8k_2_02:7]
First Quarter Highlights*

[0001437749-16-030854:8k_2_02:8]
* All comparisons are to the prior year period unless otherwise noted.

[0001437749-16-030854:8k_2_02:9]
|  | ● | Sales for the first quarter of 2016 were $219.4 million, with growth of 4%. Excluding currency effects, sales increased 6% due to continued growth in the automotive and industrial segments. |

[0001437749-16-030854:8k_2_02:10]
|  | ● | GAAP earnings for the first quarter of 2016 were $0.85 per diluted share. This included $13.0 million of special charges primarily related to transaction and integration planning costs for the acquisition of the circuit protection device business (PolySwitch) from TE Connectivity, and non-operating foreign exchange losses. Excluding these special items, adjusted earnings for the first quarter of 2016 were $1.38 per diluted share, representing a 28% increase. |

[0001437749-16-030854:8k_2_02:11]
|  | ● | Highlights by segment included: |

[0001437749-16-030854:8k_2_02:12]
|  | o | Electronics sales declined about 1% (increased nearly 1% excluding foreign currency effects) as semiconductor sales declined, partially offset by higher sensor sales. |

[0001437749-16-030854:8k_2_02:13]
|  | o | Automotive sales increased 9% (11% excluding foreign currency effects) reflecting strong growth in Asia and Europe, and globally across the automotive sensor business. |

[0001437749-16-030854:8k_2_02:14]
|  | o | Industrial sales increased 7% (9% excluding foreign currency effects) due to strong growth in the fuse business and growth in custom products. |

[0001437749-16-030854:8k_2_02:15]
|  | ● | The electronics book-to-bill ratio for the first quarter of 2016 was 1.05. |

[0001437749-16-030854:8k_2_02:16]
|  | ● | Cash provided by operating activities was $9.5 million for the first quarter of 2016 compared to $23.2 million for the first quarter of 2015, primarily driven by integration costs related to the PolySwitch business and the quarter calendarization which impacted receivable collections in the first quarter. |

[0001437749-16-030854:8k_2_02:17]
-more-

[0001437749-16-030854:8k_2_02:18]
|  | ● | Capital expenditures for the first quarter of 2016 decreased to $9.1 million compared to $12.3 million in the prior year. 2016 also included $1.0 million of capital expenditures relating to integration activities for the PolySwitch acquisition. |

[0001437749-16-030854:8k_2_02:19]
|  | ● | As previously announced, the company completed the acquisition of the PolySwitch business of TE Connectivity Ltd. on March 25, 2016 for $350 million. The company’s first quarter results include the balance sheet from the PolySwitch business but do not include any income statement activity of the business. |

[0001437749-16-030854:8k_2_02:20]
|  | ● | On April 4, 2016, the company announced the acquisition of Menber’s S.p.A., an Italian-based designer and manufacturer of manual and electrical battery switches and trailer connectors for commercial vehicles. Menber’s had sales of approximately $23 million (€21 million) in 2015. |

[0001437749-16-030854:8k_2_02:21]
"Our teams continue to execute well within a mixed macroeconomic environment," said Gordon Hunter, chief executive officer. "Our margins improved by 350 basis points versus first quarter last year, as both our automotive and electronics segments made progress on their margin initiatives, and we benefitted from currency tailwinds. We were also pleased with sales growth across our sensor platforms, as both our automotive and electronics sensor businesses showed strong growth.”

[0001437749-16-030854:8k_2_02:22]
Outlook*

[0001437749-16-030854:8k_2_02:23]
* All comparisons are to the prior year period unless otherwise noted.

[0001437749-16-030854:8k_2_02:24]
"We are excited to add the PolySwitch business into the Littelfuse portfolio, and are in the early stages of understanding customer trends and market dynamics,” said Hunter. "Although there are some market challenges impacting revenue trends in the business, we are focused on top-line growth while driving margin expansion through our integration objectives.”

[0001437749-16-030854:8k_2_02:25]
References to the “core business” below represent the company’s legacy businesses and the recent Menber’s acquisition.

[0001437749-16-030854:8k_2_02:26]
|  | ● | Total sales for the second quarter of 2016 are expected to be in the range of $265 million to $277 million. |

[0001437749-16-030854:8k_2_02:27]
o     Sales of the core business are expected to be in the range of $230 to $240 million, which represents 6% revenue growth at the midpoint.

[0001437749-16-030854:8k_2_02:28]
|  | o | Sales of the PolySwitch business are expected to be in the range of $35 to $37 million, reflecting certain unfavorable market trends, and one-time distributor inventory rebalancing. |

[0001437749-16-030854:8k_2_02:29]
-more-

[0001437749-16-030854:8k_2_02:30]
|  | ● | Total earnings for the second quarter of 2016 are expected to be in the range of $1.35 to $1.49 per diluted share, excluding special items. |

[0001437749-16-030854:8k_2_02:31]
|  | o | Earnings for the core business are expected to be in the range of $1.48 to $1.62 per diluted share, excluding special items, which reflects growth of 17% at the midpoint. |

[0001437749-16-030854:8k_2_02:32]
|  | o | Excluding amortization expense, earnings per diluted share for the PolySwitch business are expected to be approximately break-even, excluding special items. PolySwitch amortization expense is estimated at $0.13 for the quarter. |

[0001437749-16-030854:8k_2_02:33]
|  | ● | The 2016 full year tax rate is expected to be approximately 22% for the company. |

[0001437749-16-030854:8k_2_02:34]
|  | ● | Capital expenditures for the full year 2016 are expected to be in the range of $40 to $45 million for the core business. In addition, capital expenditures for the PolySwitch business and related integration activities are expected to be between $10 and $12 million for 2016. |

[0001437749-16-030854:8k_2_02:35]
"We are pleased with the performance of our core business and are continuing to focus on operational improvements in targeted areas,” said Meenal Sethna, chief financial officer. “Our full year 2016 view of the core business remains unchanged from our February earnings call. Despite some challenging end market trends and currency environment, we still expect to grow our core business revenues in the low to mid single digits this year. We continue to make progress on our margin initiatives, and believe we can grow our full year operating margins in our core business by 150 basis points over last year.”

[0001437749-16-030854:8k_2_02:36]
Conference Call and Webcast Information

[0001437749-16-030854:8k_2_02:37]
Littelfuse will host a conference call today, Thursday, May 5, 2016, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay on the company’s website.

[0001437749-16-030854:8k_2_02:38]
About Littelfuse

[0001437749-16-030854:8k_2_02:39]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 10,000 employees in more than 40 locations throughout the Americas, Europe and Asia. For more information, please visit the Littelfuse website: Littelfuse.com.

[0001437749-16-030854:8k_2_02:40]
-more-

[0001437749-16-030854:8k_2_02:41]
| “Safe Harbor” Statement under the Private Securities Litigation Reform Act of 1995. The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company's accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company's other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 2, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended January 2, 2016. |

[0001437749-16-030854:8k_2_02:42]
LFUS-F                          ###

[0001437749-16-030854:8k_2_02:43]
LITTELFUSE, INC.

[0001437749-16-030854:8k_2_02:44]
Net Sales and Operating Income by Segment

[0001437749-16-030854:8k_2_02:45]
(In thousands of USD, unaudited)

[0001437749-16-030854:8k_2_02:46]
|  |  | First Quarter |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 98,796 |  |  | $ | 99,380 |  |  |  | (1% | ) |
| Automotive |  |  | 91,933 |  |  |  | 84,071 |  |  |  | 9 | % |
| Industrial |  |  | 28,669 |  |  |  | 26,862 |  |  |  | 7 | % |
| Total net sales |  | $ | 219,398 |  |  | $ | 210,313 |  |  |  | 4 | % |

[0001437749-16-030854:8k_2_02:47]
|  |  | First Quarter |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 22,416 |  |  | $ | 18,665 |  |  |  | 20 | % |
| Automotive |  |  | 17,491 |  |  |  | 11,171 |  |  |  | 57 | % |
| Industrial |  |  | 1,673 |  |  |  | 2,730 |  |  |  | (39% | ) |
| Other (1) |  |  | (9,152 | ) |  |  | (3,018 | ) |  |  | 203 | % |
| Total operating income |  | $ | 32,428 |  |  | $ | 29,548 |  |  |  | 10 | % |
| Interest expense |  |  | 2,045 |  |  |  | 1,151 |  |  |  |  |  |
| Foreign exchange loss (gain) |  |  | 3,823 |  |  |  | 3,117 |  |  |  |  |  |
| Other (income) expense, net |  |  | (517 | ) |  |  | (1,126 | ) |  |  |  |  |
| Income before taxes |  | $ | 27,077 |  |  | $ | 26,406 |  |  |  | 3 | % |

[0001437749-16-030854:8k_2_02:48]
(1) "Other" includes special charges such as acquisition-related costs, restructuring costs, gains and losses on asset sales and asset impairments. (See Supplemental Financial Information for details on page 9.)

[0001437749-16-030854:8k_2_02:49]
|  |  | First Quarter |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Segment Amortization Expense |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 798 |  |  | $ | 870 |  |  |  | (8% | ) |
| Automotive |  |  | 1,538 |  |  |  | 1,551 |  |  |  | (1% | ) |
| Industrial |  |  | 523 |  |  |  | 632 |  |  |  | (17% | ) |
| Other(2) |  |  | 937 |  |  |  | - |  |  | na |  |
|  |  | $ | 3,796 |  |  | $ | 3,053 |  |  |  | 24 | % |

[0001437749-16-030854:8k_2_02:50]
(2) Impairment of intangible asset.

[0001437749-16-030854:8k_2_02:51]
-more-

[0001437749-16-030854:8k_2_02:52]
LITTELFUSE, INC.

[0001437749-16-030854:8k_2_02:53]
Condensed Consolidated Balance Sheets

[0001437749-16-030854:8k_2_02:54]
(In thousands of USD, except share amounts)

[0001437749-16-030854:8k_2_02:55]
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 272,864 |  |  | $ | 328,786 |  |
| Short-term investments |  |  | 4,354 |  |  |  | 4,179 |  |
| Accounts receivable, less allowances |  |  | 181,384 |  |  |  | 142,882 |  |
| Inventories |  |  | 133,162 |  |  |  | 98,629 |  |
| Prepaid expenses and other current assets |  |  | 14,024 |  |  |  | 8,238 |  |
| Total current assets |  |  | 605,788 |  |  |  | 582,714 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 9,760 |  |  |  | 5,236 |  |
| Buildings |  |  | 90,839 |  |  |  | 71,383 |  |
| Equipment |  |  | 435,047 |  |  |  | 382,429 |  |
|  |  |  | 535,646 |  |  |  | 459,048 |  |
| Accumulated depreciation |  |  | (305,413 | ) |  |  | (296,480 | ) |
| Net property, plant and equipment |  |  | 230,233 |  |  |  | 162,568 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 75,972 |  |  |  | 20,221 |  |
| Distribution network |  |  | 16,226 |  |  |  | 16,490 |  |
| Customer lists, trademarks and tradenames |  |  | 105,353 |  |  |  | 54,912 |  |
| Goodwill |  |  | 312,064 |  |  |  | 189,767 |  |
|  |  |  | 509,615 |  |  |  | 281,390 |  |
| Investments |  |  | 14,424 |  |  |  | 15,197 |  |
| Deferred income taxes |  |  | 20,049 |  |  |  | 8,333 |  |
| Other assets |  |  | 23,001 |  |  |  | 14,058 |  |
| Total assets |  | $ | 1,403,110 |  |  | $ | 1,064,260 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 73,619 |  |  | $ | 51,658 |  |
| Accrued payroll |  |  | 28,492 |  |  |  | 32,611 |  |
| Accrued expenses |  |  | 40,350 |  |  |  | 24,145 |  |
| Accrued severance |  |  | 4,043 |  |  |  | 3,798 |  |
| Accrued income taxes |  |  | 9,929 |  |  |  | 10,621 |  |
| Consideration payable |  |  | 70,000 |  |  |  | - |  |
| Current portion of long-term debt |  |  | 6,250 |  |  |  | 87,000 |  |
| Total current liabilities |  |  | 232,683 |  |  |  | 209,833 |  |
| Long-term debt, less current portion |  |  | 371,113 |  |  |  | 83,753 |  |
| Deferred income taxes |  |  | 6,191 |  |  |  | 8,014 |  |
| Accrued post-retirement benefits |  |  | 7,481 |  |  |  | 5,653 |  |
| Other long-term liabilities |  |  | 12,329 |  |  |  | 12,809 |  |
| Total equity |  |  | 773,313 |  |  |  | 744,198 |  |
| Total liabilities and equity |  | $ | 1,403,110 |  |  | $ | 1,064,260 |  |

[0001437749-16-030854:8k_2_02:56]
Common shares issued of 22,470,690 and 22,420,785 at April 2, 2016 and January 2, 2016, respectively.

[0001437749-16-030854:8k_2_02:57]
-more-

[0001437749-16-030854:8k_2_02:58]
LITTELFUSE, INC.

[0001437749-16-030854:8k_2_02:59]
Consolidated Statements of Comprehensive Income

[0001437749-16-030854:8k_2_02:60]
(In thousands of USD, except per share data, unaudited)

[0001437749-16-030854:8k_2_02:61]
|  |  | For the Three Months Ended |  |
|  |  | April 2, 2016 |  |  | March 28, 2015 |  |
| Net sales |  | $ | 219,398 |  |  | $ | 210,313 |  |
| Cost of sales |  |  | 132,243 |  |  |  | 133,983 |  |
| Gross profit |  |  | 87,155 |  |  |  | 76,330 |  |
| Selling, general and administrative expenses |  |  | 42,366 |  |  |  | 36,345 |  |
| Research and development expenses |  |  | 8,565 |  |  |  | 7,384 |  |
| Amortization of intangibles |  |  | 3,796 |  |  |  | 3,053 |  |
|  |  |  | 54,727 |  |  |  | 46,782 |  |
| Operating income |  |  | 32,428 |  |  |  | 29,548 |  |
| Interest expense |  |  | 2,045 |  |  |  | 1,151 |  |
| Foreign exchange loss |  |  | 3,823 |  |  |  | 3,117 |  |
| Other (income) expense, net |  |  | (517 | ) |  |  | (1,126 | ) |
| Income before income taxes |  |  | 27,077 |  |  |  | 26,406 |  |
| Income taxes |  |  | 7,788 |  |  |  | 6,411 |  |
| Net income |  | $ | 19,289 |  |  | $ | 19,995 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | 0.88 |  |
| Diluted |  | $ | 0.85 |  |  | $ | 0.88 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,438 |  |  |  | 22,600 |  |
| Diluted |  |  | 22,621 |  |  |  | 22,781 |  |
| Comprehensive income |  | $ | 29,975 |  |  | $ | 9,037 |  |

[0001437749-16-030854:8k_2_02:62]
-more-

[0001437749-16-030854:8k_2_02:63]
LITTELFUSE, INC.

[0001437749-16-030854:8k_2_02:64]
Consolidated Statements of Cash Flows

[0001437749-16-030854:8k_2_02:65]
(In thousands of USD, unaudited)

[0001437749-16-030854:8k_2_02:66]
|  |  | For the Three Months Ended |  |
|  |  | April 2, 2016 |  |  | March 28, 2015 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 19,289 |  |  | $ | 19,995 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 7,230 |  |  |  | 7,365 |  |
| Amortization of intangibles |  |  | 3,796 |  |  |  | 3,053 |  |
| Stock-based compensation |  |  | 2,204 |  |  |  | 1,802 |  |
| Impairment of assets |  |  | 1,391 |  |  |  | - |  |
| Excess tax benefit on stock-based compensation |  |  | (706 | ) |  |  | (672 | ) |
| Loss on sale of assets |  |  | 27 |  |  |  | 105 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (10,413 | ) |  |  | (3,910 | ) |
| Inventories |  |  | (3,484 | ) |  |  | 149 |  |
| Accounts payable |  |  | 3,716 |  |  |  | (2,963 | ) |
| Accrued expenses (including post retirement) |  |  | 7,414 |  |  |  | 2,689 |  |
| Accrued payroll and severance |  |  | (9,351 | ) |  |  | (8,894 | ) |
| Accrued taxes |  |  | (5,312 | ) |  |  | 932 |  |
| Prepaid expenses and other |  |  | (6,309 | ) |  |  | 3,579 |  |
| Net cash provided by operating activities |  |  | 9,492 |  |  |  | 23,230 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (264,098 | ) |  |  | - |  |
| Purchases of property, plant and equipment |  |  | (9,139 | ) |  |  | (12,279 | ) |
| Proceeds from sale of assets |  |  | 18 |  |  |  | 6 |  |
| Net cash used in investing activities |  |  | (273,219 | ) |  |  | (12,273 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 258,000 |  |  |  | 7,000 |  |
| Proceeds of term loan |  |  | 125,000 |  |  |  | - |  |
| Payments of revolving credit facility |  |  | (90,500 | ) |  |  | (11,000 | ) |
| Payments of term loan |  |  | (85,000 | ) |  |  | (1,250 | ) |
| Debt issuance costs paid |  |  | (1,700 | ) |  |  | - |  |
| Cash dividends paid |  |  | (6,483 | ) |  |  | (5,635 | ) |
| Proceeds from exercise of stock options |  |  | 3,710 |  |  |  | 1,768 |  |
| Excess tax benefit on stock-based compensation |  |  | 706 |  |  |  | 672 |  |
| Net cash provided by (used in) financing activities |  |  | 203,733 |  |  |  | (8,445 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 4,072 |  |  |  | (6,452 | ) |
| Decrease in cash and cash equivalents |  |  | (55,922 | ) |  |  | (3,940 | ) |
| Cash and cash equivalents at beginning of period |  |  | 328,786 |  |  |  | 297,571 |  |
| Cash and cash equivalents at end of period |  | $ | 272,864 |  |  | $ | 293,631 |  |

[0001437749-16-030854:8k_2_02:67]
-more-

[0001437749-16-030854:8k_2_02:68]
LITTELFUSE, INC.

[0001437749-16-030854:8k_2_02:69]
Supplemental Financial Information

[0001437749-16-030854:8k_2_02:70]
(in millions of USD except share amounts)

[0001437749-16-030854:8k_2_02:71]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-16 |  |  | Q1-15 |  |
| GAAP diluted EPS |  | $ | 0.85 |  |  | $ | 0.88 |  |
| EPS impact of special items (below) |  |  | 0.53 |  |  |  | 0.20 |  |
| Adjusted diluted EPS |  | $ | 1.38 |  |  | $ | 1.08 |  |
| Year-over-year adjusted EPS growth |  |  | 28 | % |  |  |  |  |
| Special charges (income)/expense |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | 1.0 |  |  | $ | 1.0 |  |
| Restructuring |  |  | 0.4 |  |  |  | 1.2 |  |
| Acquisition expenses |  |  | 6.2 |  |  |  | 0.2 |  |
| Pension wind-up |  |  | - |  |  |  | 0.7 |  |
| Impairment and severance charges |  |  | 1.6 |  |  |  | - |  |
| Adjustment to Operating income |  |  | 9.2 |  |  |  | 3.0 |  |
| Foreign exchange loss/(gain) |  |  | 3.8 |  |  |  | 3.1 |  |
| Adjustment to pre-tax income |  | $ | 13.0 |  |  | $ | 6.1 |  |
| Total EPS impact |  | $ | 0.53 |  |  | $ | 0.20 |  |
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-16 |  |  | Q1-15 |  |
| Net sales |  | $ | 219.4 |  |  | $ | 210.3 |  |
| GAAP operating income |  | $ | 32.4 |  |  | $ | 29.5 |  |
| Add back special operating items |  |  | 9.2 |  |  |  | 3.0 |  |
| Adjusted operating income |  |  | 41.6 |  |  |  | 32.5 |  |
| Adjusted operating margin |  |  | 19.0 | % |  |  | 15.5 | % |
| Add back amortization |  |  | 3.8 |  |  |  | 3.1 |  |
| Add back depreciation |  |  | 7.2 |  |  |  | 7.4 |  |
| Adjusted EBITDA |  | $ | 52.6 |  |  | $ | 43.0 |  |
| Adjusted EBITDA margin |  |  | 24.0 | % |  |  | 20.4 | % |
| Year-over-year adjusted EBITDA growth |  |  | 22 | % |  |  |  |  |

[0001437749-16-030854:8k_2_02:72]
Note: Totals will not always foot due to rounding

[0001437749-16-030854:8k_2_02:73]
###
