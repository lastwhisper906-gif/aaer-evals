# LFUS MD&A — 0001437749-16-031011


## mdna

[0001437749-16-031011:mdna:1]
[same as prior period, unchanged from 0001437749-15-019169:mdna:1]

[0001437749-16-031011:mdna:2]
[same as prior period, unchanged from 0001437749-15-019169:mdna:2]

[0001437749-16-031011:mdna:3]
Littelfuse, Inc. and its subsidiaries (the “company” or “Littelfuse”) is the worldwide leader in circuit protection offering the industry's broadest and deepest portfolio of circuit protection products and solutions. The company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment. The company’s worldwide revenue in 2015 was $867.9 million and net earnings were $82.5 million. The company conducts its business through three reportable segments, which are defined by markets and consist of Electronics, Automotive, and Industrial. The company’s customer base includes original equipment manufacturers, tier one automotive suppliers and distributors.

[0001437749-16-031011:mdna:4]
In addition to protecting and growing its core circuit protection business, Littelfuse has been expanding its portfolio in power control and sensing technologies. These platforms, combined with the company’s strong balance sheet and operating cash flow, provide opportunities for increased organic and acquisition growth. In 2012, the company set a five-year strategic plan to grow annual sales at 15% per year; 5% organically and 10% through acquisitions.

[0001437749-16-031011:mdna:5]
[same as prior period, unchanged from 0001437749-15-019169:mdna:5]

[0001437749-16-031011:mdna:6]
[same as prior period, unchanged from 0001437749-15-019169:mdna:6]

[0001437749-16-031011:mdna:7]
[same as prior period, unchanged from 0001437749-15-019169:mdna:7]

[0001437749-16-031011:mdna:8]
[same as prior period, unchanged from 0001437749-15-019169:mdna:8]

[0001437749-16-031011:mdna:9]
[same as prior period, unchanged from 0001437749-15-019169:mdna:9]

[0001437749-16-031011:mdna:10]
[same as prior period, unchanged from 0001437749-15-019169:mdna:10]

[0001437749-16-031011:mdna:11]
[same as prior period, unchanged from 0001437749-15-019169:mdna:11]

[0001437749-16-031011:mdna:12]
[same as prior period, unchanged from 0001437749-15-019169:mdna:12]

[0001437749-16-031011:mdna:13]
The Electronics segment sells passive and semiconductor components and modules as well as sensors primarily into the global consumer electronics, general industrial and telecommunications markets. The core electronics markets are characterized by significant Asia-Pacific competition and price erosion. As a result the company is focusing additional efforts on higher growth, less price sensitive niche markets (such as LED lighting) and higher-power industrial applications. The PolySwitch business acquisition in 2016 will expand the company’s product offering used in a wide variety of electronic products and utilize the same distribution channels as the company’s core electronics products.

[0001437749-16-031011:mdna:14]
[same as prior period, unchanged from 0001437749-15-019169:mdna:14]

[0001437749-16-031011:mdna:15]
The Automotive segment is comprised of passenger vehicle circuit protection, commercial vehicle products and sensors. The primary growth drivers for these businesses are increasing global demand for passenger and commercial vehicles and increasing content per vehicle for both circuit protection and sensing products. The move away from internal combustion engines to hybrid and electric drive systems that require more circuit protection continues to be an additional growth driver. The PolySwitch business acquisition in 2016 will add to the company’s strong global presence in the automotive market.

[0001437749-16-031011:mdna:16]
Industrial Segment

[0001437749-16-031011:mdna:17]
The Industrial segment derives its revenues from power fuses, protection relays and custom products selling primarily into the industrial, mining, solar and oil and gas markets. Protection relay sales have declined due to the general slowdown in the global mining and oil and gas markets. Custom products sales, after declining over the past two years due to end market softness in the potash market, have begun to grow with the company’s diversification into e-houses used in the heavy industrial and utility markets.

[0001437749-16-031011:mdna:18]
[same as prior period, unchanged from 0001437749-15-019169:mdna:18]

[0001437749-16-031011:mdna:19]
[same as prior period, unchanged from 0001437749-15-019169:mdna:19]

[0001437749-16-031011:mdna:20]
|  |  | First Quarter |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 98,796 |  |  | $ | 99,380 |  |  |  | (1% | ) |
| Automotive |  |  | 91,933 |  |  |  | 84,071 |  |  |  | 9 | % |
| Industrial |  |  | 28,669 |  |  |  | 26,862 |  |  |  | 7 | % |
| Total |  | $ | 219,398 |  |  | $ | 210,313 |  |  |  | 4 | % |

[0001437749-16-031011:mdna:21]
|  |  | First Quarter |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 99,823 |  |  | $ | 97,054 |  |  |  | 3 | % |
| Europe |  |  | 42,813 |  |  |  | 38,968 |  |  |  | 10 | % |
| Asia-Pacific |  |  | 76,762 |  |  |  | 74,291 |  |  |  | 3 | % |
| Total |  | $ | 219,398 |  |  | $ | 210,313 |  |  |  | 4 | % |

[0001437749-16-031011:mdna:22]
[same as prior period, unchanged from 0001437749-15-019169:mdna:21]

[0001437749-16-031011:mdna:23]
Results of Operations – First Quarter, 2016 compared to 2015

[0001437749-16-031011:mdna:24]
The following table summarizes the company’s consolidated results of operations for the periods presented. During the first quarter of 2016, there were approximately $9.2 million of additional special charges. These included $6.2 million of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, $1.6 million in impairment charges related to the closure of the company’s manufacturing facility in Denmark, $1.0 million related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.4 million related to internal legal restructuring costs.

[0001437749-16-031011:mdna:25]
| (In thousands, unaudited) |  | First Quarter |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Sales |  | $ | 219,398 |  |  | $ | 210,313 |  |  |  | 4 | % |
| Gross Profit |  |  | 87,155 |  |  |  | 76,330 |  |  |  | 14 | % |
| Operating expense |  |  | 54,727 |  |  |  | 46,782 |  |  |  | 17 | % |
| Operating income |  |  | 32,428 |  |  |  | 29,548 |  |  |  | 10 | % |
| Other (income) expense, net |  |  | (517 | ) |  |  | (1,126 | ) |  |  | (54% | ) |
| Income before income taxes |  |  | 27,077 |  |  |  | 26,406 |  |  |  | 3 | % |
| Net income |  | $ | 19,289 |  |  | $ | 19,995 |  |  |  | (4% | ) |

[0001437749-16-031011:mdna:26]
Net sales increased $9.1 million or 4% to $219.4 million in the first quarter of 2016 compared to $210.3 million in the first quarter of 2015 due primarily to strong organic growth in the Automotive and Industrial segments. Electronics sales were essentially flat with the first quarter of 2015. The company also experienced $3.5 million in unfavorable foreign currency effects in the first quarter of 2016 as compared to the first quarter of 2015. The unfavorable foreign currency impact primarily resulted from sales denominated in the euro. Excluding currency effects, net sales increased $12.6 million or 6% year-over-year.

[0001437749-16-031011:mdna:27]
Electronics sales decreased $0.6 million or 1% to $98.8 million in the first quarter of 2016 compared to $99.4 million in the first quarter of 2015 primarily reflecting unfavorable currency effects in the current year quarter, partially offset by growth in sensor products. The Electronics segment experienced $1.2 million in unfavorable currency effects in the first quarter of 2016 primarily from sales denominated in euro and Chinese yuan. Excluding currency effects, net sales increased $0.6 million or 1% year-over-year.

[0001437749-16-031011:mdna:28]
Automotive sales increased $7.8 million or 9% to $91.9 million in the first quarter of 2016 compared to $84.1 million in the first quarter of 2015 due primarily to strong organic growth for sensors. The Automotive segment experienced $1.7 million in unfavorable currency effects in the first quarter of 2016 primarily due to sales denominated in euros and Chinese yuan. Excluding currency effects, net sales increased $9.5 million or 11% year-over-year.

[0001437749-16-031011:mdna:29]
Industrial sales increased $1.8 million or 7% to $28.7 million in the first quarter of 2016 compared to $26.9 million in the first quarter of 2015 as higher custom and fuse sales were partially offset by weaker relay sales. The Industrial segment experienced $0.6 million in unfavorable currency effects in the first quarter of 2016 primarily from sales denominated in Canadian dollars. Excluding currency effects, net sales increased $2.4 million or 9% year-over-year.

[0001437749-16-031011:mdna:30]
On a geographic basis, sales in the Americas increased $2.8 million or 3% to $99.8 million in the first quarter of 2016 compared to $97.1 million in the first quarter of 2015 due primarily to strong organic growth in Industrial segment sales offset by lower Electronics segment sales and $0.6 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding currency effects, the Americas sales increased $3.3 million or 3%.

[0001437749-16-031011:mdna:31]
Europe sales increased $3.8 million or 10% to $42.8 million in the first quarter of 2016 compared to $39.0 million in the first quarter of 2015 primarily due to strong sales of automotive products offset by $1.3 million in unfavorable currency effects primarily from sales denominated in euro. Excluding currency effects, Europe sales increased $5.2 million or 13%.

[0001437749-16-031011:mdna:32]
Asia-Pacific sales increased $2.5 million or 3% to $76.8 million in the first quarter of 2016 compared to $74.3 million in the first quarter of 2015 due to strong demand for automotive products offset by unfavorable currency effects of $1.6 million. Excluding currency effects, Asia-Pacific sales increased $4.1 million or 5% year-over-year.

[0001437749-16-031011:mdna:33]
Gross profit was $87.2 million or 40% of net sales for the first quarter of 2016 compared to $76.3 million or 36% of net sales in the same quarter last year. Gross profit for 2016 includes $1.0 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines and $0.4 million related to internal legal restructuring costs. Gross profit for 2015 included $1.0 million related to the reed switch production transfer. Excluding the impact of these charges, gross profit was $88.5 million or 40% of net sales for the first quarter of 2016 compared to $77.3 million or 37% of net sales in the first quarter of 2015. The increase in gross profit margin compared to the prior year was primarily attributable to increased sales of higher margin products in 2016.

[0001437749-16-031011:mdna:34]
Total operating expense was $54.7 million or 25% of net sales for the first quarter of 2016 compared to $46.8 million or 22% of net sales for the same quarter in 2015. Operating expense in 2016 included $7.8 million of charges primarily related to acquisition costs associated with the company’s acquisition of PolySwitch. Operating expense in 2015 included $2.0 million related to internal legal restructuring costs and costs related to the wind-up of the U.S. pension plan. Excluding these charges, total operating expense was $47.0 million or 21% of net sales for 2016 compared to $44.8 million or 21% of net sales in 2015.

[0001437749-16-031011:mdna:35]
Operating income for the first quarter of 2016 was approximately $32.4 million compared to operating income of $29.5 million for the same quarter in 2015. Excluding the impact of special charges as described above, operating income was $41.6 million for the first quarter of 2016 as compared to $32.6 million for the first quarter of 2015. The improvement in operating income is primarily attributable to higher margin sales as discussed above.

[0001437749-16-031011:mdna:36]
Interest expense was $2.0 million in the first quarter of 2016 as compared to $1.2 million in the first quarter of 2015, primarily reflecting comparative borrowings, facility fees and financing fee amortization between the two periods.

[0001437749-16-031011:mdna:37]
Foreign exchange loss (gain), reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $3.8 million of expense for the first quarter of 2016 and $3.1 million of expense for the first quarter of 2015 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar.

[0001437749-16-031011:mdna:38]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $0.5 million of income for first quarter of 2016 and $1.1 million for the first quarter of 2015.

[0001437749-16-031011:mdna:39]
17

[0001437749-16-031011:mdna:40]
Income before income taxes was $27.1 million for the first quarter of 2016 compared to $26.4 million for the first quarter of 2015. Income tax expense was $7.8 million with an effective tax rate of 28.8% for the first quarter of 2016 compared to income tax expense of $6.4 million with an effective tax rate of 24.3% in the first quarter of 2015. The effective tax rates for both the first quarter of 2016 and 2015 are lower than the U.S. statutory tax rate primarily due to more income earned in lower tax jurisdictions.

[0001437749-16-031011:mdna:41]
Net income for the first quarter of 2016 was $19.3 million or $0.85 per diluted share compared to net income of $20.0 million or $0.88 per diluted share for the same quarter of 2015.

[0001437749-16-031011:mdna:42]
[same as prior period, unchanged from 0001437749-15-019169:mdna:56]

[0001437749-16-031011:mdna:43]
As of April 2, 2016, $260.5 million of the $272.9 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $260.5 million held by foreign subsidiaries, approximately $28.0 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $28.0 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-16-031011:mdna:44]
[same as prior period, unchanged from 0001437749-15-019169:mdna:58]

[0001437749-16-031011:mdna:45]
Revolving Credit Facility/Term Loan

[0001437749-16-031011:mdna:46]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of April 2, 2016, the company had available $330.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.5% (1.94% as of April 2, 2016).

[0001437749-16-031011:mdna:47]
The company incurred debt issuance costs of $1.7 million which will be amortized over the life of the existing credit agreement.

[0001437749-16-031011:mdna:48]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At April 2, 2016, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-16-031011:mdna:49]
The company also had $0.1 million outstanding in letters of credit at April 2, 2016. No amounts were drawn under these letters of credit at April 2, 2016.

[0001437749-16-031011:mdna:50]
[same as prior period, unchanged from 0001437749-15-019169:mdna:64]

[0001437749-16-031011:mdna:51]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million at that time) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Net Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.5 million) at April 2, 2016.

[0001437749-16-031011:mdna:52]
[same as prior period, unchanged from 0001437749-15-019169:mdna:66]

[0001437749-16-031011:mdna:53]
The company started 2016 with $328.8 million of cash and cash equivalents. Net cash provided by operating activities was approximately $9.5 million for the first three months of 2016 reflecting $19.3 million in net income and $13.9 million in non-cash adjustments (primarily $11.0 million in depreciation and amortization) offset by $23.7 million in net changes to various operating assets and liabilities.

[0001437749-16-031011:mdna:54]
Changes in operating assets and liabilities for the first three months of 2016 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivable ($10.4 million), inventory ($3.5 million), prepaid and other assets ($6.3 million), accrued payroll and severance ($9.4 million) and accrued and deferred taxes ($5.3 million). The increase in accounts receivable was due to increased sales in the first quarter. The decrease in accrued payroll and severance was due primarily to payouts for the 2015 management incentive plan which occurred in the first quarter. Other changes having a positive impact on cash flows were increases in accounts payable ($3.7 million) and accrued expenses ($7.4 million).

[0001437749-16-031011:mdna:55]
Net cash used in investing activities was approximately $273.2 million and primarily related to the acquisition of the PolySwitch business ($263.0 million) and capital expenditures ($9.1 million).

[0001437749-16-031011:mdna:56]
Net cash provided by financing activities was approximately $203.7 million and included $207.5 million in net proceeds on borrowings offset by dividends paid of $6.5 million and debt issuance costs related to the new credit agreement of $1.7 million, partially offset by $4.4 million from the exercise of stock options including tax benefits. The effects of exchange rate changes increased cash and cash equivalents by approximately $4.1 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $55.9 million decrease in cash, which left the company with a cash and cash equivalents balance of $272.9 million at April 2, 2016.

[0001437749-16-031011:mdna:57]
The ratio of current assets to current liabilities was 2.6 to 1 at the end of the first quarter of 2016 compared to 2.8 to 1 at year-end 2015 and 3.0 to 1 at the end of the first quarter of 2015. Days sales outstanding in accounts receivable was approximately 65 days at the end of the first quarter of 2016 compared to 59 days at the end of the first quarter of 2015 and 59 days at year-end 2015. Days inventory outstanding was approximately 71 days at the end of the first quarter of 2016 compared to 65 days at the year-end 2015 and 65 days at end of the first quarter of 2015.

[0001437749-16-031011:mdna:58]
[same as prior period, unchanged from 0001437749-15-019169:mdna:72]

[0001437749-16-031011:mdna:59]
Net sales for the company’s core business (legacy businesses and the recent member’s acquisition) in the second quarter of 2016 are expected to be in the range of $230 million to $240 million. The midpoint of this range represents 5% growth over the prior year quarter. In addition, revenue from the PolySwitch business is expected to be in the range of $35 million to $37 million for the second quarter of 2016. The total company 2016 second quarter Net sales is expected in the range of $265 million to $277 million.

[0001437749-16-031011:mdna:60]
The company believes it can grow 2016 revenue in its core business (excluding PolySwitch) in the low to mid single digits versus 2015.  The company expects revenue of approximately $40 million per quarter in the second half of 2016 for its PolySwitch business.

[0001437749-16-031011:mdna:61]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-16-031011:mdna:62]
The statements in this section and the other sections of this report that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended January 2, 2016. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended January 2, 2016.
