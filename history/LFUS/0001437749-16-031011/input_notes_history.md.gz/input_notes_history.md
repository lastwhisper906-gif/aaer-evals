# LFUS note change history — 0001437749-15-019169 → 0001437749-16-031011


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001437749-16-031011:note_history:1]
The carrying amounts of debt at April 2, 2016 and January 2, 2016 are as follows (in thousands):
  (was, 2015-10-30, similarity 0.8729):
[0001437749-15-019169:note_history:1]
The carrying amounts of debt at September 26, 2015 and December 27, 2014 are as follows (in thousands):

- added (2016-05-06):
[0001437749-16-031011:note_history:2]
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 244,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 125,000 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,536 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (1,673 | ) |  |  | (721 | ) |
| Total debt |  |  | 377,363 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 371,113 |  |  | $ | 83,753 |  |

- added (2016-05-06):
[0001437749-16-031011:note_history:3]
Revolving Credit F

- added (2016-05-06):
[0001437749-16-031011:note_history:4]
acility / Term Loan

- added (2016-05-06):
[0001437749-16-031011:note_history:5]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of April 2, 2016, the company had available $330.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (1.94% as of April 2, 2016). At April 2, 2016, the company was in compliance with all covenants under the revolving credit facility.

- changed (2016-05-06):
[0001437749-16-031011:note_history:6]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million at that time) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.5 million) at April 2, 2016.
  (was, 2015-10-30, similarity 0.9414):
[0001437749-15-019169:note_history:6]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.

- added (2016-05-06):
[0001437749-16-031011:note_history:7]
Debt Issuance Costs

- added (2016-05-06):
[0001437749-16-031011:note_history:8]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which will be amortized over the life of the new credit agreement.

- added (2016-05-06):
[0001437749-16-031011:note_history:9]
In April 2015, the FASB issued ASU No. 2015-03, 
Interest - Imputation of Interest
 (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The company adopted this guidance in the current quarter, on a retrospective basis, and has reclassified the unamortized debt issuance costs into long-term debt as shown in the table above.

- removed (2016-05-06):
[0001437749-15-019169:note_history:10]
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 90,000 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 107,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 11,517 |  |  |  | 17,908 |  |
| Total debt |  |  | 209,017 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 117,500 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 91,517 |  |  | $ | 106,658 |  |

- removed (2016-05-06):
[0001437749-15-019169:note_history:11]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of September 26, 2015, the company had available $167.4 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.19% as of September 26, 2015). At September 26, 2015, the company was in compliance with all covenants under the revolving credit facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-05-06):
[0001437749-16-031011:note_history:12]
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 244,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 125,000 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,536 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (1,673 | ) |  |  | (721 | ) |
| Total debt |  |  | 377,363 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 371,113 |  |  | $ | 83,753 |  |

- removed (2016-05-06):
[0001437749-15-019169:note_history:13]
|  |  | September 26, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 90,000 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 107,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 11,517 |  |  |  | 17,908 |  |
| Total debt |  |  | 209,017 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 117,500 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 91,517 |  |  | $ | 106,658 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-05-06):
[0001437749-16-031011:note_history:14]
14

- changed (2016-05-06):
[0001437749-16-031011:note_history:15]
) Subsequent Event
  (was, 2015-10-30, similarity 0.9444):
[0001437749-15-019169:note_history:15]
12. Subsequent Event

- added (2016-05-06):
[0001437749-16-031011:note_history:16]
On April 4, 2016, the company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy. The purchase price of €16.7 million

- added (2016-05-06):
[0001437749-16-031011:note_history:17]
($19.0 million) is subject to a working capital adjustment and was financed through a mixture of cash on hand and borrowings under the company's credit facility. The acquired business, which will be part of the company's Automotive segment, specializes in the design, manufacturing and selling of manual and electrical battery switches and trailer connectors for commercial vehicles. Menber’s had sales of approximately $23.0 million in 2015.

- added (2016-05-06):
[0001437749-16-031011:note_history:18]
The initial accounting for the acquisition is not complete pending detailed analyses of the facts and circumstances that existed as of the acquisition date.

- removed (2016-05-06):
[0001437749-15-019169:note_history:19]
On October 1, 2015, the company acquired Sigmar S.r.1. (“Sigmar”), an Italian company that produces sensors used in gas and diesel engine fuel systems, as well as urea level and quality sensors used in diesel emission reduction systems. Sigmar has annual revenues of approximately $6 million and will be reported in the Automotive business segment.
