# LFUS MD&A — 0001437749-16-041083


## mdna

[0001437749-16-041083:mdna:1]
[same as prior period, unchanged from 0001437749-16-036614:mdna:1]

[0001437749-16-041083:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-16-041083:mdna:3]
[same as prior period, unchanged from 0001437749-16-036614:mdna:3]

[0001437749-16-041083:mdna:4]
[same as prior period, unchanged from 0001437749-16-036614:mdna:4]

[0001437749-16-041083:mdna:5]
[same as prior period, unchanged from 0001437749-16-036614:mdna:5]

[0001437749-16-041083:mdna:6]
[same as prior period, unchanged from 0001437749-16-036614:mdna:6]

[0001437749-16-041083:mdna:7]
[same as prior period, unchanged from 0001437749-16-036614:mdna:7]

[0001437749-16-041083:mdna:8]
[same as prior period, unchanged from 0001437749-16-036614:mdna:8]

[0001437749-16-041083:mdna:9]
[same as prior period, unchanged from 0001437749-16-036614:mdna:9]

[0001437749-16-041083:mdna:10]
[same as prior period, unchanged from 0001437749-16-036614:mdna:10]

[0001437749-16-041083:mdna:11]
[same as prior period, unchanged from 0001437749-16-036614:mdna:11]

[0001437749-16-041083:mdna:12]
[same as prior period, unchanged from 0001437749-16-036614:mdna:12]

[0001437749-16-041083:mdna:13]
[same as prior period, unchanged from 0001437749-16-036614:mdna:13]

[0001437749-16-041083:mdna:14]
19

[0001437749-16-041083:mdna:15]
[same as prior period, unchanged from 0001437749-16-036614:mdna:14]

[0001437749-16-041083:mdna:16]
The Electronics segment sells passive and semiconductor components and modules as well as sensors primarily into the global consumer electronics, general industrial and telecommunications markets. The core electronics markets are characterized by significant Asia-Pacific competition and price erosion. As a result the company is focusing additional efforts on higher growth, less price sensitive niche markets (such as LED lighting) and higher-power industrial applications. The PolySwitch business acquisition in 2016 has expanded the company’s product offering used in a wide variety of electronic products and utilizes many of the same distribution channels as the company’s legacy electronics products. On August 29, 2016, the company completed the acquisition of the TVS Diode/Thyristor/IGBT business from ON Semiconductor Corporation. This business is complimentary to and will further expand the semiconductor markets that the segment serves.

[0001437749-16-041083:mdna:17]
[same as prior period, unchanged from 0001437749-16-036614:mdna:16]

[0001437749-16-041083:mdna:18]
The Automotive segment is comprised of passenger vehicle circuit protection, commercial vehicle products and sensors. The primary growth drivers for these businesses are increasing global demand for passenger and commercial vehicles and increasing content per vehicle for both circuit protection and sensing products. The move away from internal combustion engines to hybrid and electric drive systems that require more circuit protection continues to be an additional growth driver. The PolySwitch business acquisition in 2016 has added to the company’s strong global presence in the automotive market. The acquisition of Menber’s further strengthens the company’s position in electrical high current switches and connectors for the commercial vehicle market.

[0001437749-16-041083:mdna:19]
[same as prior period, unchanged from 0001437749-16-036614:mdna:18]

[0001437749-16-041083:mdna:20]
The Industrial segment derives its revenues from power fuses, protection relays and custom products selling primarily into the industrial, mining, solar and oil and gas markets. Protection relay sales have declined due to the general slowdown in the global mining and oil and gas markets. Custom products sales have declined significantly over the past two years due to continued end market softness in the potash mining market. The potash market has recently experienced a steep decline in market pricing and consolidation. Due to negative events in the potash market subsequent to the company’s 2016 second quarter end, the company conducted a step one goodwill impairment analysis for the custom products reporting unit to determine if goodwill was impaired as of July 2, 2016. The fair value of this reporting unit at this date exceeded its carrying value by less than 10%.  Since then, the potash market has continued to see a decline in market pricing in the potash mining industry. Due to this continuing decline in potash pricing, management revisited its long term projections during the company’s third quarter 2016 and conducted another step one goodwill impairment analysis. Based on the revised projections, the custom products reporting unit failed. As required by GAAP, management conducted a step two analysis which indicated a write down of the reporting unit’s carrying value by $14.8 million, with $8.8 million from goodwill and $6.0 million from intangible assets.

[0001437749-16-041083:mdna:21]
20

[0001437749-16-041083:mdna:22]
[same as prior period, unchanged from 0001437749-16-036614:mdna:20]

[0001437749-16-041083:mdna:23]
[same as prior period, unchanged from 0001437749-16-036614:mdna:21]

[0001437749-16-041083:mdna:24]
|  |  | Third Quarter |  |  | First Nine Months |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 147,730 |  |  | $ | 102,616 |  |  |  | 44 | % |  | $ | 378,696 |  |  | $ | 307,549 |  |  |  | 23 | % |
| Automotive |  |  | 106,341 |  |  |  | 81,475 |  |  |  | 31 | % |  |  | 309,644 |  |  |  | 251,464 |  |  |  | 23 | % |
| Industrial |  |  | 26,260 |  |  |  | 31,419 |  |  |  | (16% | ) |  |  | 83,301 |  |  |  | 88,831 |  |  |  | (6% | ) |
| Total |  | $ | 280,331 |  |  | $ | 215,510 |  |  |  | 30 | % |  | $ | 771,641 |  |  | $ | 647,844 |  |  |  | 19 | % |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 106,112 |  |  | $ | 98,974 |  |  |  | 7 | % |  | $ | 313,231 |  |  | $ | 299,061 |  |  |  | 5 | % |
| Europe |  |  | 52,200 |  |  |  | 37,520 |  |  |  | 39 | % |  |  | 149,417 |  |  |  | 115,613 |  |  |  | 29 | % |
| Asia-Pacific |  |  | 122,019 |  |  |  | 79,016 |  |  |  | 54 | % |  |  | 308,993 |  |  |  | 233,170 |  |  |  | 33 | % |
| Total |  | $ | 280,331 |  |  | $ | 215,510 |  |  |  | 30 | % |  | $ | 771,641 |  |  | $ | 647,844 |  |  |  | 19 | % |

[0001437749-16-041083:mdna:25]
[same as prior period, unchanged from 0001437749-16-036614:mdna:23]

[0001437749-16-041083:mdna:26]
The following table summarizes the company’s consolidated results of operations for the periods presented. The quarter of 2016 includes approximately $22.1 million ($45.3 million year-to-date) of other non-segment charges. These included $14.8 million (14.8 million year-to-date) of charges related to the impairment of the custom products reporting unit, $5.9 million ($18.2 million year-to-date) of acquisition and integration costs associated with the company’s 2016 acquisitions, primarily PolySwitch, $0.6 million ($7.5 million year-to-date) of non-cash inventory charges relating to the company’s 2016 acquisitions, primarily PolySwitch, as described in Note 4, $1.9 million year-to-date in charges related to the closure of the company’s manufacturing facility in Denmark, $1.7 million year-to-date related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.9 million ($1.3 million year-to-date) related to internal legal restructuring costs.

[0001437749-16-041083:mdna:27]
The third quarter of 2015 includes approximately $33.4 million ($39.8 million year-to-date) of other non-segment charges. These included $2.1 million ($6.8 million year-to-date) related to internal legal restructuring, $0.3 million ($0.7 million year-to-date) related to acquisition costs and $30.9 million ($32.2 million year-to-date) of expense related to the planned termination of the U.S. pension as described in Note 12.

[0001437749-16-041083:mdna:28]
| (In thousands, unaudited) |  | Third Quarter |  |  | First Nine Months |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Sales |  | $ | 280,331 |  |  | $ | 215,510 |  |  |  | 30 | % |  | $ | 771,641 |  |  | $ | 647,844 |  |  |  | 19 | % |
| Gross profit |  |  | 113,759 |  |  |  | 86,182 |  |  |  | 32 | % |  |  | 298,780 |  |  |  | 247,793 |  |  |  | 21 | % |
| Operating expense |  |  | 86,233 |  |  |  | 77,598 |  |  |  | 11 | % |  |  | 209,124 |  |  |  | 173,490 |  |  |  | 21 | % |
| Operating income |  |  | 27,526 |  |  |  | 8,584 |  |  |  | 221 | % |  |  | 89,656 |  |  |  | 74,303 |  |  |  | 21 | % |
| Interest expense |  |  | 2,571 |  |  |  | 922 |  |  |  | 179 | % |  |  | 6,286 |  |  |  | 3,021 |  |  |  | 108 | % |
| Foreign exchange (gain) loss |  |  | (4,700 | ) |  |  | (3,549 | ) |  |  | 32 | % |  |  | (7,114 | ) |  |  | (1,724 | ) |  |  | 313 | % |
| Other (income) expense, net |  |  | (778 | ) |  |  | (1,430 | ) |  |  | (46% | ) |  |  | (1,040 | ) |  |  | (3,758 | ) |  |  | (72% | ) |
| Income before income taxes |  |  | 30,433 |  |  |  | 12,641 |  |  |  | 141 | % |  |  | 91,524 |  |  |  | 76,764 |  |  |  | 19 | % |
| Net income |  | $ | 30,802 |  |  | $ | 11,324 |  |  |  | 172 | % |  | $ | 77,243 |  |  | $ | 60,003 |  |  |  | 29 | % |

[0001437749-16-041083:mdna:29]
21

[0001437749-16-041083:mdna:30]
Results of Operations – Third Quarter, 2016 compared to 2015

[0001437749-16-041083:mdna:31]
Consolidated net sales of $280.3 for the third quarter of 2016 increased $64.8 million, or 30%, compared to the prior year quarter, reflecting $59.6 million of revenues from businesses acquired over the previous twelve months as well as strong organic growth in the Automotive segment, partially offset by lower sales from the Industrial segment due to weaker end markets.

[0001437749-16-041083:mdna:32]
Electronics sales of $147.7 million for the third quarter of 2016 increased $45.1 million, or 44%, compared to the prior year quarter, reflecting $40.5 million of revenues from businesses acquired over the previous twelve months as well as organic growth in sensor, passive and semiconductor products. This segment continues to leverage the company’s technology expertise to design its products into a broad variety of end markets and market segments.

[0001437749-16-041083:mdna:33]
Automotive sales of $106.3 million for the third quarter of 2016 increased $24.9 million, or 31%, compared to the prior year quarter, reflecting. reflecting $19.1 million of revenues from businesses acquired over the previous twelve months as well as strong organic growth in passenger car products in North America and China, partially offset by lower sales of legacy commercial vehicle products, reflecting weakness in the North American heavy truck, construction and agricultural end markets.

[0001437749-16-041083:mdna:34]
Industrial sales of $26.3 million of the third quarter of 2016 decreased $5.2 million, or 16%, to $26.3 million in the third quarter of 2016 compared to $31.4 million in the third quarter of 2015 primarily reflecting lower relay, fuse and custom product sales due to weakness in the solar, oil and gas and mining markets. The company’s fuse business has benefited from a strong U.S. solar market for a number of years, however this market slowed in the second half of 2016. As the U.S. Congress extended solar energy related tax credits late in 2015, many solar original equipment manufacturers delayed projects to focus on scale and efficiencies. Sales in both the protection relay and custom products businesses continued to be impacted by weakness in the heavy industrial markets, particularly mining, and oil and gas, as those customers restrict their capital spending. In the custom products business, the potash market has continued to see a decline in market pricing in the potash mining industry. As a result, the company has taken an impairment charge of $14.8 million with $8.8 million in goodwill and $6.0 million in intangible assets related to the custom business in this segment.

[0001437749-16-041083:mdna:35]
On a geographic basis, sales in the Americas increased $7.1 million, or 7%, to $106.1 million in the third quarter of 2016 compared to $99.0 million in the third quarter of 2015 primarily reflecting the addition of the PolySwitch and the TVS Diode/Thyristor/IGBT businesses in the current year and, to a lesser extent, increased Automotive segment sales, partially offset by lower Industrial segment sales.

[0001437749-16-041083:mdna:36]
Europe sales increased $14.7 million, or 39%, to $52.2 million in the third quarter of 2016 compared to $37.5 million in the third quarter of 2015 primarily due to strong sales of automotive sensor products, the addition of the businesses acquired in the previous twelve months, increased organic electronic sales and $0.1 million in favorable currency effects primarily from sales denominated in euro. Excluding currency effects, Europe sales increased $14.6 million, or 39%, year-over-year.

[0001437749-16-041083:mdna:37]
Asia-Pacific sales increased $43.0 million, or 54%, to $122.0 million in the third quarter of 2016 compared to $79.0 million in the third quarter of 2015 primarily reflecting the addition of the PolySwitch and the TVS Diode/Thyristor/IGBT businesses in the current year and increased demand for electronics and automotive products, partially offset by unfavorable currency effects of $0.9 million. Excluding currency effects, Asia-Pacific sales increased $43.9 million, or 56%, year-over-year.

[0001437749-16-041083:mdna:38]
Gross profit was $113.8 million, or 41% of net sales, for the third quarter of 2016 compared to $86.2 million, or 40% of net sales, in the same quarter last year. Gross profit for 2016 includes a $0.6 million inventory adjustment relating to the Menber’s and TVS Diode/Thyristor/IGBT business acquisitions and $0.2 million in charges related to restructuring in the relay business. Gross profit for 2015 included $1.2 million of charges related to the reed switch production transfer. Excluding the impact of these charges, gross profit was $114.2 million, or 41% of net sales, for the third quarter of 2016 compared to $87.4 million, or 41% of net sales, in the third quarter of 2015.

[0001437749-16-041083:mdna:39]
Total operating expense was $86.2 million, or 31% of net sales, for the third quarter of 2016 compared to $77.6 million, or 36% of net sales, for the same quarter in 2015. Operating expense in 2016 included $5.9 million of acquisition and integration costs associated with the company’s 2016 acquisitions, primarily PolySwitch, $0.4 million related to restructuring in the relay and custom businesses, $14.8 million in charges related to the goodwill and intangible assets impairments in the custom business and $0.4 million in charges related to the Selco site closure. Operating expense in 2015 included $30.2 million related to settlement of the company’s U.S. pension plan. Excluding these charges, total operating expense was $64.7 million, or 23% of net sales, for 2016 compared to $47.4 million, or 22% of net sales, in 2015.

[0001437749-16-041083:mdna:40]
Due to the reasons noted above, operating income for the third quarter of 2016 was approximately $27.5 million compared to operating income of $8.6 million for the same quarter in 2015.

[0001437749-16-041083:mdna:41]
Interest expense was $2.6 million in the third quarter of 2016 as compared to $0.9 million in the third quarter of 2015, primarily reflecting higher borrowings relating to the March 2016 acquisition of the PolySwitch business.

[0001437749-16-041083:mdna:42]
Foreign exchange (gain) loss, reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $4.7 million of income for the third quarter of 2016 and $3.5 million of income for the third quarter of 2015 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar and the euro against the Japanese yen.

[0001437749-16-041083:mdna:43]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $0.8 million of income for the third quarter of 2016 and $1.4 million of income for the third quarter of 2015. The quarter over quarter decline primarily reflects lower interest income in the current year quarter due to cash used for the acquisition of the PolySwitch business in March 2016.

[0001437749-16-041083:mdna:44]
Income before income taxes was $30.4 million for the third quarter of 2016 compared to $12.6 million for the third quarter of 2015. Income tax benefit was $0.4 million with an effective tax rate of negative 1.2% for the third quarter of 2016 compared to income tax expense of $1.3 million with an effective tax rate of 10.4% in the third quarter of 2015. The effective tax rates for these quarterly periods are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions and, with respect to the 2016 period, a one-time deduction with respect to the stock of one of the company’s affiliates partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded, and, with respect to the 2015 period, the impact of a pension settlement partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations.

[0001437749-16-041083:mdna:45]
Net income for the third quarter of 2016 was $30.8 million or $1.35 per diluted share compared to net income of $11.3 million or $0.50 per diluted share for the same quarter of 2015.

[0001437749-16-041083:mdna:46]
Results of Operations – Nine Months, 2016 compared to 2015

[0001437749-16-041083:mdna:47]
Consolidated net sales for the first nine months of 2016 of $771.6 million increased $123.8 million, or 19%, compared to the prior year period, reflecting $106.5 million of revenues from businesses acquired over the previous twelve months as well as strong organic growth in the Automotive segment and to a lesser extent organic growth in the Electronics segment.

[0001437749-16-041083:mdna:48]
Electronics sales of $378.7 million for the first nine months of 2016 increased $71.2 million, or 23%, compared to the prior year period, reflecting $64.7 million of revenues from businesses acquired over the previous twelve months as well as organic growth in sensor products and to a lesser extent passive and semiconductor products. The Electronics segment experienced $1.8 million in unfavorable currency effects in the first nine months of 2016 primarily from sales denominated in the renminbi and, to a lesser extent, sales denominated in the Korean won. Excluding currency effects, net sales excluding PolySwitch and TVS Diode/Thyristor/IGBT business, increased $8.2 million, or 3%, year-over-year.

[0001437749-16-041083:mdna:49]
23

[0001437749-16-041083:mdna:50]
Automotive sales of $309.6 million for the first nine months of 2016 increased $58.2 million, or 23%, compared to the prior year period, reflecting. reflecting $41.8 million of revenues from businesses acquired over the previous twelve months as well as organic growth in sensor and passenger car products. These increases in sales were partially offset by lower sales of legacy commercial vehicle products, reflecting weakness in the North American heavy truck, construction and agricultural end markets. The Automotive segment experienced $2.5 million in unfavorable currency effects in the first nine months of 2016 primarily from sales denominated in the renminbi. Excluding currency effects, net sales increased $35.5 million, or 14%, year-over-year.

[0001437749-16-041083:mdna:51]
Industrial sales of $83.3 million for the first nine months of 2016 decreased $5.5 million, or 6%, to $83.3 million in the first nine months of 2016 compared to $88.8 million in the first nine months of 2015 primarily reflecting lower sales of relay and custom products. The company’s fuse business has benefited from a strong U.S. solar market for a number of years, however this market slowed in the second half of 2016. As the U.S. Congress extended solar energy related tax credits late in 2015, many solar original equipment manufacturers pushed out projects to focus on scale and efficiencies. Sales in both the protection relay and custom products businesses continued to be impacted by weakness in the heavy industrial markets, particularly mining, and oil and gas, as those customers restrict their capital spending. In the custom products business, the company continues to see a decline in its potash market, which has resulted in the aforementioned impairment charge.

[0001437749-16-041083:mdna:52]
On a geographic basis, sales in the Americas increased $14.2 million, or 5%, to $313.2 million in the first nine months of 2016 compared to $299.1 million in the first nine months of 2015 primarily reflecting the addition of the PolySwitch and TVS Diode/Thyristor/IGBT businesses in the current year and increased Electronics and Automotive segment sales, partially offset by lower Industrial segment sales.

[0001437749-16-041083:mdna:53]
Europe sales increased $33.8 million, or 29%, to $149.4 million in the first nine months of 2016 compared to $115.6 million in the first nine months of 2015 primarily reflecting the addition of the businesses acquired in the previous twelve months and increased automotive and electronic segment sales, partially offset by lower Industrial segment sales.

[0001437749-16-041083:mdna:54]
Asia-Pacific sales increased $75.8 million, or 33%, to $309.0 million in the first nine months of 2016 compared to $233.2 million in the first nine months of 2015 primarily reflecting the addition of the PolySwitch and the TVS Diode/Thyristor/IGBT businesses in the current year and increased demand for electronics and automotive products, partially offset by unfavorable currency effects of $3.9 million. Excluding currency effects, Asia-Pacific sales increased $79.8 million, or 34%, year-over-year.

[0001437749-16-041083:mdna:55]
Gross profit was $298.8 million, or 39% of net sales, for the first nine months of 2016 compared to $247.8 million, or 38% of net sales, in the same period last year. Gross profit for 2016 includes $7.5 million of non-cash inventory charges relating primarily to the PolySwitch acquisition and to a lesser extent the Menber’s and TVS Diode/Thyristor/IGBT business acquisitions, $1.5 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines, $0.9 million of acquisition-related costs primarily related to integration costs associated with the company’s acquisition of the PolySwitch business, $0.1 million in charges related to the closure of the company’s manufacturing facility in Denmark and $0.1 million related to internal legal restructuring costs. Gross profit for 2015 included $3.1 million related to the reed switch production transfer. Excluding the impact of these charges, gross profit was $309.1 million, or 40% of net sales, for the first nine months of 2016 compared to $250.9 million, or 39% of net sales, in the first nine months of 2015.

[0001437749-16-041083:mdna:56]
Total operating expense was $209.1 million, or 27% of net sales, for the first nine months of 2016 compared to $173.5 million, or 27% of net sales, for the same period in 2015. Operating expense in 2016 included $17.3 million of acquisition and integration costs associated with the company’s 2016 acquisitions, primarily PolySwitch, $14.8 million in charges related to the goodwill and intangible asset impairments in the custom business, $0.4 million in charges related to the restructuring in the relay and custom businesses, the $1.8 million in charges related to the closure of the company’s manufacturing facility in Denmark, $0.3 million related to internal legal restructuring costs and $0.2 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines. Operating expense in 2015 included $30.2 million related to the settlement of the company’s U.S. pension plan. Excluding these charges, total operating expense was $174.1 million, or 23% of net sales, for 2016 compared to $143.3 million, or 22% of net sales, in 2015, partially reflecting increased research and development expenses in the current year quarter as compared to the prior year quarter and incremental amortization of intangible assets associated with recent acquisitions.

[0001437749-16-041083:mdna:57]
Operating income for the first nine months of 2016 was approximately $89.7 million compared to operating income of $74.3 million for the same period in 2015.

[0001437749-16-041083:mdna:58]
Interest expense was $6.3 million in the first nine months of 2016 as compared to $3.0 million in the first nine months of 2015, primarily reflecting higher borrowings relating to the March 2016 acquisition of the PolySwitch business.

[0001437749-16-041083:mdna:59]
Foreign exchange (gain) loss, reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $7.1 million of income for the first nine months of 2016 and $1.7 million of income for the first nine months of 2015 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar and the euro against the Japanese yen.

[0001437749-16-041083:mdna:60]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $1.0 million of income for first nine months of 2016 and $3.8 million of income for the first nine months of 2015. The period over period decline primarily reflects lower interest income in the current year period due to cash used for the acquisition of the PolySwitch business in March 2016.

[0001437749-16-041083:mdna:61]
Income before income taxes was $91.5 million for the first nine months of 2016 compared to $76.8 million for the first nine months of 2015. Income tax expense was $14.3 million with an effective tax rate of 15.6% for the first nine months of 2016 compared to income tax expense of $16.8 million with an effective tax rate of 21.8% in the first nine months of 2015. The effective tax rates for these nine month periods are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions and, with respect to the 2016 period, a one-time deduction with respect to the stock of one of the company’s affiliates partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded, and, with respect to the 2015 period, the impact of a pension settlement partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations.

[0001437749-16-041083:mdna:62]
Net income for the first nine months of 2016 was $77.2 million or $3.41 per diluted share compared to net income of $60.0 million or $2.64 per diluted share for the same period of 2015.

[0001437749-16-041083:mdna:63]
[same as prior period, unchanged from 0001437749-16-036614:mdna:60]

[0001437749-16-041083:mdna:64]
As of October 1, 2016, $182.1 million of the $194.5 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $182.1 million held by foreign subsidiaries, approximately $19.7 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $19.7 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-16-041083:mdna:65]
[same as prior period, unchanged from 0001437749-16-036614:mdna:62]

[0001437749-16-041083:mdna:66]
Revolving Credit Facility/Term Loan

[0001437749-16-041083:mdna:67]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of October 1, 2016, the company had available $259.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (2.03% as of October 1, 2016).

[0001437749-16-041083:mdna:68]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement. This new credit agreement was determined to be a modification under ASC 470-50 of the previous credit agreement.

[0001437749-16-041083:mdna:69]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At October 1, 2016, the company was in compliance with all covenants under the credit agreement.

[0001437749-16-041083:mdna:70]
The company also had $0.1 million outstanding in letters of credit at October 1, 2016. No amounts were drawn under these letters of credit at October 1, 2016.

[0001437749-16-041083:mdna:71]
[same as prior period, unchanged from 0001437749-16-036614:mdna:69]

[0001437749-16-041083:mdna:72]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income is recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Net Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 34.5 million (approximately $5.2 million) at October 1, 2016.

[0001437749-16-041083:mdna:73]
[same as prior period, unchanged from 0001437749-16-036614:mdna:71]

[0001437749-16-041083:mdna:74]
The company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2016 to April 30, 2017. The company’s prior share repurchase authorization of 1,000,000 shares expired on April 30, 2016 with 650,000 shares remaining in the program. The company did not repurchase any shares of its common stock during the first nine months of fiscal 2016 under the stock repurchase program.

[0001437749-16-041083:mdna:75]
[same as prior period, unchanged from 0001437749-16-036614:mdna:73]

[0001437749-16-041083:mdna:76]
The company started 2016 with $328.8 million of cash and cash equivalents. Net cash provided by operating activities was approximately $100.0 million for the first nine months of 2016 reflecting $77.2 million in net income and $69.2 million in non-cash adjustments (primarily $38.2 million in depreciation and amortization) offset by uses of $46.4 million to various operating assets and liabilities.

[0001437749-16-041083:mdna:77]
Changes in operating assets and liabilities for the first nine months of 2016 (including short-term and long-term items) that impacted cash flows negatively consisted of uses from accounts receivable ($24.9 million), accrued taxes ($23.6 million) and prepaid expenses and other ($18.2 million), partially offset by sources from accrued expenses ($6.5 million), accounts payable ($7.8 million), inventories ($4.5 million) and accrued payroll and severance ($1.4 million). The increase in prepaid and other was due primarily to the revaluation of inter-company loans. The increase in accounts receivable was due to increased sales in the third quarter. The increase in accrued payroll and severance was due primarily to more payroll from acquisitions.

[0001437749-16-041083:mdna:78]
Net cash used in investing activities for the first nine months of 2016 was approximately $498.5 million and primarily related to the acquisition of the PolySwitch business ($342.3 million, net of cash acquired), the acquisition of the TVS Diode/Thyristor/IGBT business ($104.0 million), the acquisition of Menber’s ($18.9 million) and capital expenditures ($34.5 million).

[0001437749-16-041083:mdna:79]
Net cash provided by financing activities for the first nine months of 2016 was approximately $262.4 million and included $271.3 million in net proceeds on borrowings offset by dividends paid of $20.4 million and debt issuance costs related to the new credit agreement of $1.7 million, partially offset by $16.9 million from the exercise of stock options including tax benefits. The effects of exchange rate changes increased cash and cash equivalents by approximately $1.8 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $134.3 million decrease in cash, which left the company with a cash and cash equivalents balance of $194.5 million at October 1, 2016.

[0001437749-16-041083:mdna:80]
The ratio of current assets to current liabilities was 3.0 to 1 at the end of the third quarter of 2016 compared to 2.8 to 1 at year-end 2015 and 2.7 to 1 at the end of the third quarter of 2015. Days sales outstanding in accounts receivable was approximately 67 days at the end of the third quarter of 2016 compared to 62 days at the end of the third quarter of 2015 and 59 days at year-end 2015. Days inventory outstanding was approximately 66 days at the end of the third quarter of 2016, 65 days at the year-end 2015 and 70 days at the end of the third quarter of 2015.

[0001437749-16-041083:mdna:81]
[same as prior period, unchanged from 0001437749-16-036614:mdna:79]

[0001437749-16-041083:mdna:82]
Sales in the 4th quarter of 2016 are expected to be in the range of $270 million to $280 million. This represents approximately 24% revenue growth at the midpoint from the prior year quarter. Excluding acquisitions, the effects of the e-house business sale and the 2015 “extra week”, this represents approximately 3% revenue growth at the midpoint.
