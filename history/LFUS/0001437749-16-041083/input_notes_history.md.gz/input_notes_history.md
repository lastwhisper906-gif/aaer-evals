# LFUS note change history — 0001437749-16-036614 → 0001437749-16-041083


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-04):
[0001437749-16-041083:note_history:1]
The carrying amounts of debt at October 1, 2016 and January 2, 2016 are as follows (in thousands):
  (was, 2016-08-05, similarity 0.9379):
[0001437749-16-036614:note_history:1]
The carrying amounts of debt at July 2, 2016 and January 2, 2016 are as follows (in thousands):

- added (2016-11-04):
[0001437749-16-041083:note_history:2]
|  |  | October 1, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 315,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 121,875 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 5,173 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,092 | ) |  |  | (721 | ) |
| Total debt |  |  | 440,456 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (87,000 | ) |
| Total long-term debt |  | $ | 434,206 |  |  | $ | 83,753 |  |

- changed (2016-11-04):
[0001437749-16-041083:note_history:3]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of October 1, 2016, the company
  (was, 2016-08-05, similarity 0.9481):
[0001437749-16-036614:note_history:3]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of July 2, 2016, the company had

- changed (2016-11-04):
[0001437749-16-041083:note_history:4]
had $0.1 million outstanding in letters of credit and had available $259.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (2
  (was, 2016-08-05, similarity 0.7665):
[0001437749-16-036614:note_history:4]
had $0.1 million outstanding in letters of credit and had available $337.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (1.97% as of July 2, 2016). At July 2, 2016, the company was in compliance with all covenants under the credit agreement

- added (2016-11-04):
[0001437749-16-041083:note_history:5]
.03% as of October 1, 2016). At October 1, 2016, the company was in compliance with all covenants under the credit agreement

- changed (2016-11-04):
[0001437749-16-041083:note_history:6]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 34.5 million (approximately $5.2 million) at October 1, 2016.
  (was, 2016-08-05, similarity 0.9956):
[0001437749-16-036614:note_history:6]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.3 million) at July 2, 2016.

- added (2016-11-04):
[0001437749-16-041083:note_history:7]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which

- changed (2016-11-04):
[0001437749-16-041083:note_history:8]
, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement.
  (was, 2016-08-05, similarity 0.7506):
[0001437749-16-036614:note_history:8]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement.

- changed (2016-11-04):
[0001437749-16-041083:note_history:9]
This new credit agreement was determined to be a modification under ASC 470-50 of the previous credit agreement.
  (was, 2016-08-05, similarity 0.8586):
[0001437749-16-036614:note_history:9]
was determined to be a modification under ASC 470-50 of the previous credit agreement

- changed (2016-11-04):
[0001437749-16-041083:note_history:10]
In April 2015, the FASB issued ASU No. 2015-03, 
Interest - Imputation of Interest
 (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The company adopted this guidance in the first quarter of 2016, on a retrospective basis, and has reclassified the unamortized debt issuance costs into long-term debt as shown in the table above.
  (was, 2016-08-05, similarity 0.9859):
[0001437749-16-036614:note_history:10]
In April 2015, the FASB issued ASU No. 2015-03, 
Interest - Imputation of Interest
 (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The company adopted this guidance in the current quarter, on a retrospective basis, and has reclassified the unamortized debt issuance costs into long-term debt as shown in the table above.

- removed (2016-11-04):
[0001437749-16-036614:note_history:11]
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 237,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 123,438 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,256 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,212 | ) |  |  | (721 | ) |
| Total debt |  |  | 367,982 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 361,732 |  |  | $ | 83,753 |  |

- removed (2016-11-04):
[0001437749-16-036614:note_history:12]
This new credit agreement

- removed (2016-11-04):
[0001437749-16-036614:note_history:13]
.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-11-04):
[0001437749-16-041083:note_history:14]
|  |  | October 1, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 315,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 121,875 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 5,173 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,092 | ) |  |  | (721 | ) |
| Total debt |  |  | 440,456 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (87,000 | ) |
| Total long-term debt |  | $ | 434,206 |  |  | $ | 83,753 |  |

- removed (2016-11-04):
[0001437749-16-036614:note_history:15]
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 237,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 123,438 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,256 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,212 | ) |  |  | (721 | ) |
| Total debt |  |  | 367,982 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 361,732 |  |  | $ | 83,753 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-11-04):
[0001437749-16-041083:note_history:16]
.

- changed (2016-11-04):
[0001437749-16-041083:note_history:17]
Subsequent Event
  (was, 2016-08-05, similarity 0.7143):
[0001437749-16-036614:note_history:17]
. Subsequent

- added (2016-11-04):
[0001437749-16-041083:note_history:18]
On October 14

- added (2016-11-04):
[0001437749-16-041083:note_history:19]
, 2016, the Company completed the sale of its portable electrical house (e-house) business, located in Winnipeg, Manitoba, Canada. This business was included in the company’s custom products reporting unit within the Industrial segment, and mainly served mining and utility markets. Neither the sale nor the historical results of operation of the sold business are material to the company’s financial results.

- removed (2016-11-04):
[0001437749-16-036614:note_history:20]
E

- removed (2016-11-04):
[0001437749-16-036614:note_history:21]
vent

- removed (2016-11-04):
[0001437749-16-036614:note_history:22]
None.
