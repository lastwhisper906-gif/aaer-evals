# LFUS 8-K — 0001437749-16-040906 filed 2016-11-03

## item codes, every 8-K on or before 2016-11-04

- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2016-11-04

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-040906:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-040906:8k_2_02:2]
ex99-1.htm

[0001437749-16-040906:8k_2_02:3]
Exhibit 99.1

[0001437749-16-040906:8k_2_02:4]
| NEWS RELEASE |  |

[0001437749-16-040906:8k_2_02:5]
LITTELFUSE REPORTS THIRD QUARTER RESULTS

[0001437749-16-040906:8k_2_02:6]
CHICAGO, November 3, 2016 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the third quarter ended October 1, 2016.

[0001437749-16-040906:8k_2_02:7]
Third Quarter Highlights

[0001437749-16-040906:8k_2_02:8]
All comparisons are to the prior year period unless otherwise noted. A reconciliation of non-GAAP (adjusted) financial measures used in this release to the comparable GAAP financial measures is included below.

[0001437749-16-040906:8k_2_02:9]
|  | ● | Sales for the third quarter of 2016 were $280.3 million, a 30% increase. Excluding revenue from acquisitions, sales increased 2%, led by strong growth in the automotive segment partially offset by end market softness in the industrial segment. |

[0001437749-16-040906:8k_2_02:10]
|  | ● | GAAP earnings for the third quarter of 2016 were $1.35 per diluted share. The third quarter GAAP effective tax rate of (1.2%) included a year-to-date adjustment to a 15.6% effective tax rate. Included in GAAP earnings were $17.4 million of pretax special charges. The primary item was $14.8 million in pretax non-cash impairment charges related to the custom business within the industrial segment, due to continued end market softness in the potash mining market. |

[0001437749-16-040906:8k_2_02:11]
|  | ● | Excluding special items, adjusted earnings for the third quarter of 2016 were $1.87 per diluted share, representing a 31% increase. The third quarter adjusted effective tax rate of 11.2% included a year-to-date adjustment to an 18% adjusted effective tax rate. |

[0001437749-16-040906:8k_2_02:12]
|  | ● | Highlights by segment included: |

[0001437749-16-040906:8k_2_02:13]
|  | o | Electronics sales increased 44% (4% excluding revenue from acquisitions), led by higher fuse and sensor sales. |

[0001437749-16-040906:8k_2_02:14]
|  | o | Automotive sales increased 31% (7% excluding revenue from acquisitions), driven by strong growth in Asia. |

[0001437749-16-040906:8k_2_02:15]
|  | o | Industrial sales decreased 16% primarily due to weakness in solar, mining, and oil and gas end markets. |

[0001437749-16-040906:8k_2_02:16]
-more-

[0001437749-16-040906:8k_2_02:17]
|  | ● | The electronics book-to-bill ratio for the third quarter of 2016 was 0.99, which excludes the ON product portfolio acquisition. |

[0001437749-16-040906:8k_2_02:18]
|  | ● | Cash provided by operating activities was $64.7 million for the third quarter of 2016 compared to $51.6 million for the third quarter of 2015. |

[0001437749-16-040906:8k_2_02:19]
|  | ● | Capital expenditures for the third quarter of 2016 increased to $14.3 million compared to $8.6 million in the prior year. The increase was primarily due to capital spending for new acquisitions and integration related activities. |

[0001437749-16-040906:8k_2_02:20]
|  | ● | As announced on October 25th, the company completed the sale of its portable electrical house (e-house) business, which was included in the company’s custom business within the industrial segment. |

[0001437749-16-040906:8k_2_02:21]
"We’re very pleased with our third quarter performance, led by our electronics and automotive segments as well as a sustained reduction in our tax rate," said Gordon Hunter, chief executive officer. "While we continued to face end market weakness across our industrial business, we took further action this quarter to improve profitability. On the acquisition front, we’re ahead of our initial expectations with the PolySwitch integration, and off to a strong start with the ON product portfolio.”

[0001437749-16-040906:8k_2_02:22]
Outlook

[0001437749-16-040906:8k_2_02:23]
All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, foreign exchange adjustments and unusual gains and losses. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-16-040906:8k_2_02:24]
"Order rates in electronics have been strong going into the fourth quarter. However, we expect organic revenue growth to be flat in automotive due to the planned customer transitions in our automotive sensor business,” said Hunter.  “We’re continuing to take action to improve profitability in our industrial segment, as we expect weakness in our industrial end markets to continue into next year.”  The outlook for the fourth quarter of 2016 is as follows:

[0001437749-16-040906:8k_2_02:25]
|  | ● | Total sales are expected to be in the range of $270 million to $280 million. This represents approximately 24% revenue growth at the midpoint. Excluding acquisitions, the effects of the e-house business sale and the fourth quarter 2015 extra week, this represents approximately 3% revenue growth at the midpoint. |

[0001437749-16-040906:8k_2_02:26]
-more-

[0001437749-16-040906:8k_2_02:27]
|  | ● | Adjusted earnings are expected to be in the range of $1.45 to $1.59 per diluted share, excluding special items. |

[0001437749-16-040906:8k_2_02:28]
|  | ● | The adjusted effective tax rate is expected to be 18% for the fourth quarter and full year 2016. |

[0001437749-16-040906:8k_2_02:29]
Conference Call and Webcast Information

[0001437749-16-040906:8k_2_02:30]
Littelfuse will host a conference call today, Thursday, November 3, 2016, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. The call will be available for replay on the company’s website.

[0001437749-16-040906:8k_2_02:31]
About Littelfuse

[0001437749-16-040906:8k_2_02:32]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 10,000 employees in more than 40 locations throughout the Americas, Europe and Asia. For more information, please visit the Littelfuse website: Littelfuse.com.

[0001437749-16-040906:8k_2_02:33]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company's accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company's other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 2, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended January 2, 2016.

[0001437749-16-040906:8k_2_02:34]
-more-

[0001437749-16-040906:8k_2_02:35]
Non-GAAP Financial Measures

[0001437749-16-040906:8k_2_02:36]
The information included in this press release includes the non-GAAP financial measures of adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate. These non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is included herein.

[0001437749-16-040906:8k_2_02:37]
The company believes that adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations. The company believes that these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-16-040906:8k_2_02:38]
CONTACT: Meenal Sethna

[0001437749-16-040906:8k_2_02:39]
Executive Vice President and CFO

[0001437749-16-040906:8k_2_02:40]
(773) 628-0616

[0001437749-16-040906:8k_2_02:41]
###

[0001437749-16-040906:8k_2_02:42]
LFUS-F

[0001437749-16-040906:8k_2_02:43]
LITTELFUSE, INC.

[0001437749-16-040906:8k_2_02:44]
Net Sales and Operating Income by Business Unit

[0001437749-16-040906:8k_2_02:45]
(In thousands of USD, unaudited)

[0001437749-16-040906:8k_2_02:46]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 147,730 |  |  | $ | 102,616 |  |  |  | 44% |  |  | $ | 378,696 |  |  | $ | 307,549 |  |  |  | 23% |  |
| Automotive |  |  | 106,341 |  |  |  | 81,475 |  |  |  | 31% |  |  |  | 309,644 |  |  |  | 251,464 |  |  |  | 23% |  |
| Industrial |  |  | 26,260 |  |  |  | 31,419 |  |  |  | (16%) |  |  |  | 83,301 |  |  |  | 88,831 |  |  |  | (6%) |  |
| Total net sales |  | $ | 280,331 |  |  | $ | 215,510 |  |  |  | 30% |  |  | $ | 771,641 |  |  | $ | 647,844 |  |  |  | 19% |  |

[0001437749-16-040906:8k_2_02:47]
|  |  | Third Quarter |  |  | Year-to-Date |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 34,571 |  |  | $ | 20,923 |  |  |  | 65% |  |  | $ | 82,246 |  |  | $ | 61,755 |  |  |  | 33% |  |
| Automotive |  |  | 15,032 |  |  |  | 15,253 |  |  |  | (1%) |  |  |  | 48,997 |  |  |  | 39,123 |  |  |  | 25% |  |
| Industrial |  |  | 57 |  |  |  | 5,781 |  |  |  | (99%) |  |  |  | 3,758 |  |  |  | 13,220 |  |  |  | (72%) |  |
| Other (1) |  |  | (22,134 | ) |  |  | (33,373 | ) |  |  | (34%) |  |  |  | (45,345 | ) |  |  | (39,795 | ) |  |  | 14% |  |
| Total operating income |  | $ | 27,526 |  |  | $ | 8,584 |  |  |  | 221% |  |  | $ | 89,656 |  |  | $ | 74,303 |  |  |  | 21% |  |
| Interest expense |  |  | 2,571 |  |  |  | 922 |  |  |  |  |  |  |  | 6,286 |  |  |  | 3,021 |  |  |  |  |  |
| Impairment and equity in net loss of unconsolidated affiliate |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |  |  | - |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | (4,700 | ) |  |  | (3,549 | ) |  |  |  |  |  |  | (7,114 | ) |  |  | (1,724 | ) |  |  |  |  |
| Other (income) expense, net |  |  | (778 | ) |  |  | (1,430 | ) |  |  |  |  |  |  | (1,040 | ) |  |  | (3,758 | ) |  |  |  |  |
| Income before taxes |  | $ | 30,433 |  |  | $ | 12,641 |  |  |  | 141% |  |  | $ | 91,524 |  |  | $ | 76,764 |  |  |  | 19% |  |

[0001437749-16-040906:8k_2_02:48]
(1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details on page 8.)

[0001437749-16-040906:8k_2_02:49]
-more-

[0001437749-16-040906:8k_2_02:50]
LITTELFUSE, INC.

[0001437749-16-040906:8k_2_02:51]
Condensed Consolidated Balance Sheets

[0001437749-16-040906:8k_2_02:52]
(In thousands of USD, except share amounts)

[0001437749-16-040906:8k_2_02:53]
|  |  | October 1, 2016 |  |  | January 2, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 194,494 |  |  | $ | 328,786 |  |
| Short-term investments |  |  | 3,961 |  |  |  | 4,179 |  |
| Accounts receivable, less allowances |  |  | 205,211 |  |  |  | 142,882 |  |
| Inventories |  |  | 121,616 |  |  |  | 98,629 |  |
| Prepaid income taxes and income taxes receivable |  |  | 14,344 |  |  |  | 1,510 |  |
| Prepaid expenses and other current assets |  |  | 15,543 |  |  |  | 7,943 |  |
| Total current assets |  |  | 555,169 |  |  |  | 583,929 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 10,044 |  |  |  | 5,236 |  |
| Buildings |  |  | 83,441 |  |  |  | 71,383 |  |
| Equipment |  |  | 439,430 |  |  |  | 382,429 |  |
|  |  |  | 532,915 |  |  |  | 459,048 |  |
| Accumulated depreciation |  |  | (309,062 | ) |  |  | (296,480 | ) |
| Net property, plant and equipment |  |  | 223,853 |  |  |  | 162,568 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 88,322 |  |  |  | 20,221 |  |
| Distribution network |  |  | 19,566 |  |  |  | 16,490 |  |
| Customer lists, trademarks and tradenames |  |  | 116,684 |  |  |  | 54,912 |  |
| Goodwill |  |  | 409,527 |  |  |  | 189,767 |  |
|  |  |  | 634,099 |  |  |  | 281,390 |  |
| Investments |  |  | 14,974 |  |  |  | 15,197 |  |
| Deferred income taxes |  |  | 17,151 |  |  |  | 8,333 |  |
| Other assets |  |  | 12,857 |  |  |  | 14,058 |  |
| Total assets |  | $ | 1,458,103 |  |  | $ | 1,065,475 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 81,382 |  |  | $ | 51,658 |  |
| Accrued payroll |  |  | 39,517 |  |  |  | 32,611 |  |
| Accrued expenses |  |  | 48,713 |  |  |  | 24,145 |  |
| Accrued severance |  |  | 3,420 |  |  |  | 3,798 |  |
| Accrued income taxes |  |  | 8,622 |  |  |  | 11,836 |  |
| Current portion of long-term debt |  |  | 6,250 |  |  |  | 87,000 |  |
| Total current liabilities |  |  | 187,904 |  |  |  | 211,048 |  |
| Long-term debt, less current portion |  |  | 434,206 |  |  |  | 83,753 |  |
| Deferred income taxes |  |  | 7,345 |  |  |  | 8,014 |  |
| Accrued post-retirement benefits |  |  | 6,235 |  |  |  | 5,653 |  |
| Other long-term liabilities |  |  | 19,037 |  |  |  | 17,755 |  |
| Total equity |  |  | 803,376 |  |  |  | 739,252 |  |
| Total liabilities and equity |  | $ | 1,458,103 |  |  | $ | 1,065,475 |  |
| Common shares issued and outstanding of 22,643,816 and 22,420,785 at October 1, 2016 and January 2, 2016, respectively. |  |  |  |  |  |  |  |  |

[0001437749-16-040906:8k_2_02:54]
-more-

[0001437749-16-040906:8k_2_02:55]
LITTELFUSE, INC.

[0001437749-16-040906:8k_2_02:56]
Consolidated Statements of Comprehensive Income

[0001437749-16-040906:8k_2_02:57]
(In thousands of USD, except per share data, unaudited)

[0001437749-16-040906:8k_2_02:58]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | Oct. 1, 2016 |  |  | Sept. 26, 2015 |  |  | Oct. 1, 2016 |  |  | Sept. 26, 2015 |  |
| Net sales |  | $ | 280,331 |  |  | $ | 215,510 |  |  | $ | 771,641 |  |  | $ | 647,844 |  |
| Cost of sales |  |  | 166,572 |  |  |  | 129,328 |  |  |  | 472,861 |  |  |  | 400,051 |  |
| Gross profit |  |  | 113,759 |  |  |  | 86,182 |  |  |  | 298,780 |  |  |  | 247,793 |  |
| Selling, general and administrative expenses |  |  | 56,589 |  |  |  | 37,002 |  |  |  | 150,047 |  |  |  | 112,119 |  |
| Research and development expenses |  |  | 10,403 |  |  |  | 7,479 |  |  |  | 30,884 |  |  |  | 22,224 |  |
| Pension settlement expenses |  |  | - |  |  |  | 30,194 |  |  |  | - |  |  |  | 30,194 |  |
| Amortization of intangibles |  |  | 4,432 |  |  |  | 2,923 |  |  |  | 13,384 |  |  |  | 8,953 |  |
| Impairment of goodwill and intangible assets |  |  | 14,809 |  |  |  | - |  |  |  | 14,809 |  |  |  | - |  |
|  |  |  | 86,233 |  |  |  | 77,598 |  |  |  | 209,124 |  |  |  | 173,490 |  |
| Operating income |  |  | 27,526 |  |  |  | 8,584 |  |  |  | 89,656 |  |  |  | 74,303 |  |
| Interest expense |  |  | 2,571 |  |  |  | 922 |  |  |  | 6,286 |  |  |  | 3,021 |  |
| Foreign exchange (gain) loss |  |  | (4,700 | ) |  |  | (3,549 | ) |  |  | (7,114 | ) |  |  | (1,724 | ) |
| Other (income) expense, net |  |  | (778 | ) |  |  | (1,430 | ) |  |  | (1,040 | ) |  |  | (3,758 | ) |
| Income before income taxes |  |  | 30,433 |  |  |  | 12,641 |  |  |  | 91,524 |  |  |  | 76,764 |  |
| Income taxes |  |  | (369 | ) |  |  | 1,317 |  |  |  | 14,281 |  |  |  | 16,761 |  |
| Net income |  | $ | 30,802 |  |  | $ | 11,324 |  |  | $ | 77,243 |  |  | $ | 60,003 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.36 |  |  | $ | 0.50 |  |  | $ | 3.43 |  |  | $ | 2.65 |  |
| Diluted |  | $ | 1.35 |  |  | $ | 0.50 |  |  | $ | 3.41 |  |  | $ | 2.64 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,578 |  |  |  | 22,581 |  |  |  | 22,515 |  |  |  | 22,623 |  |
| Diluted |  |  | 22,734 |  |  |  | 22,693 |  |  |  | 22,675 |  |  |  | 22,771 |  |
| Comprehensive income |  | $ | 25,888 |  |  | $ | 2,187 |  |  | $ | 67,762 |  |  | $ | 45,896 |  |

[0001437749-16-040906:8k_2_02:59]
-more-

[0001437749-16-040906:8k_2_02:60]
LITTELFUSE, INC.

[0001437749-16-040906:8k_2_02:61]
Consolidated Statements of Cash Flows

[0001437749-16-040906:8k_2_02:62]
(In thousands of USD, unaudited)

[0001437749-16-040906:8k_2_02:63]
|  |  | For the Nine Months Ended |  |
|  |  | Oct. 1, 2016 |  |  | Sept. 26, 2015 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 77,243 |  |  | $ | 60,003 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 24,841 |  |  |  | 22,154 |  |
| Amortization of intangibles |  |  | 13,384 |  |  |  | 8,952 |  |
| Impairment of intangible assets and goodwill |  |  | 14,809 |  |  |  | - |  |
| Loss on sale of product line |  |  | 1,391 |  |  |  | - |  |
| Stock-based compensation |  |  | 9,166 |  |  |  | 7,997 |  |
| Non-cash inventory charge |  |  | 7,456 |  |  |  | - |  |
| Net loss on pension settlement, net of tax |  |  | - |  |  |  | 19,472 |  |
| Excess tax benefit on stock-based compensation |  |  | (2,272 | ) |  |  | (1,500 | ) |
| Loss on sale of assets |  |  | 440 |  |  |  | 308 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (24,862 | ) |  |  | (18,274 | ) |
| Inventories |  |  | 4,505 |  |  |  | (4,203 | ) |
| Accounts payable |  |  | 7,845 |  |  |  | 4,216 |  |
| Accrued expenses (including post retirement) |  |  | 6,497 |  |  |  | 6,577 |  |
| Accrued payroll and severance |  |  | 1,388 |  |  |  | 3,598 |  |
| Accrued taxes |  |  | (23,613 | ) |  |  | 4,006 |  |
| Prepaid expenses and other |  |  | (18,203 | ) |  |  | 277 |  |
| Net cash provided by operating activities |  |  | 100,015 |  |  |  | 113,583 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (34,501 | ) |  |  | (35,016 | ) |
| Acquisition of business, net of cash acquired |  |  | (468,636 | ) |  |  | - |  |
| Proceeds from maturities of short-term investments |  |  | 345 |  |  |  | - |  |
| Decrease in entrusted loan receivable |  |  | 4,056 |  |  |  | 5,930 |  |
| Proceeds from sale of assets |  |  | 255 |  |  |  | 38 |  |
| Net cash used in investing activities |  |  | (498,481 | ) |  |  | (29,048 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 258,000 |  |  |  | 49,000 |  |
| Proceeds of term loan |  |  | 234,000 |  |  |  | - |  |
| Payments of revolving credit facility |  |  | (97,500 | ) |  |  | (25,000 | ) |
| Payments of term loan |  |  | (119,125 | ) |  |  | (3,750 | ) |
| Payments of entrusted loan |  |  | (4,056 | ) |  |  | (5,930 | ) |
| Debt issuance costs paid |  |  | (1,701 | ) |  |  | (42 | ) |
| Cash dividends paid |  |  | (20,405 | ) |  |  | (17,864 | ) |
| Proceeds from exercise of stock options |  |  | 14,581 |  |  |  | 6,186 |  |
| Excess tax benefit on share-based compensation |  |  | 2,272 |  |  |  | 1,500 |  |
| Purchases of common stock |  |  | (3,685 | ) |  |  | (31,252 | ) |
| Net cash (used in) provided by financing activities |  |  | 262,381 |  |  |  | (27,152 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,793 |  |  |  | (18,314 | ) |
| Increase in cash and cash equivalents |  |  | (134,292 | ) |  |  | 39,069 |  |
| Cash and cash equivalents at beginning of period |  |  | 328,786 |  |  |  | 297,571 |  |
| Cash and cash equivalents at end of period |  | $ | 194,494 |  |  | $ | 336,640 |  |

[0001437749-16-040906:8k_2_02:64]
(1) Purchase accounting adjustment related to acquisitions.

[0001437749-16-040906:8k_2_02:65]
-more-

[0001437749-16-040906:8k_2_02:66]
LITTELFUSE, INC.

[0001437749-16-040906:8k_2_02:67]
Supplemental Financial Information

[0001437749-16-040906:8k_2_02:68]
(in millions of USD except share amounts)

[0001437749-16-040906:8k_2_02:69]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-16 |  |  | Q2-16 |  |  | Q3-16 |  |  | YTD-16 |  |  | Q1-15 |  |  | Q2-15 |  |  | Q3-15 |  |  | YTD-15 |  |
| GAAP diluted EPS |  | $ | 0.85 |  |  | $ | 1.20 |  |  | $ | 1.35 |  |  | $ | 3.41 |  |  | $ | 0.88 |  |  | $ | 1.26 |  |  | $ | 0.50 |  |  | $ | 2.64 |  |
| EPS impact of special items (below) |  |  | 0.53 |  |  |  | 0.24 |  |  |  | 0.52 |  |  |  | 1.29 |  |  |  | 0.20 |  |  |  | 0.07 |  |  |  | 0.93 |  |  |  | 1.20 |  |
| Adjusted diluted EPS |  | $ | 1.38 |  |  | $ | 1.44 |  |  | $ | 1.87 |  |  | $ | 4.69 |  |  | $ | 1.08 |  |  | $ | 1.33 |  |  | $ | 1.43 |  |  | $ | 3.84 |  |
| Year-over-year adjusted EPS growth |  |  | 28 | % |  |  | 8 | % |  |  | 31 | % |  |  | 22 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | 1.0 |  |  | $ | 0.7 |  |  | $ | - |  |  | $ | 1.7 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.2 |  |  | $ | 3.1 |  |
| Restructuring |  |  | 0.4 |  |  |  | 0.1 |  |  |  | 0.9 |  |  |  | 1.4 |  |  |  | 1.2 |  |  |  | 1.7 |  |  |  | 0.9 |  |  |  | 3.8 |  |
| Acquisition expenses |  |  | 6.2 |  |  |  | 6.1 |  |  |  | 5.9 |  |  |  | 18.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.7 |  |
| Pension wind-up |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 30.8 |  |  |  | 32.2 |  |
| Product line divestiture costs |  |  | 1.6 |  |  |  | 0.3 |  |  |  | - |  |  |  | 1.9 |  |  |  | - |  |  |  | - |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Impairment of intangible assets |  |  | - |  |  |  | - |  |  |  | 14.8 |  |  |  | 14.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Purchase accounting adjustment |  |  | - |  |  |  | 6.9 |  |  |  | 0.5 |  |  |  | 7.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Adjustment to Operating income |  |  | 9.2 |  |  |  | 14.0 |  |  |  | 22.1 |  |  |  | 45.3 |  |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 33.4 |  |  |  | 39.8 |  |
| Foreign exchange loss/(gain) |  |  | 3.8 |  |  |  | (6.2 | ) |  |  | (4.7 | ) |  |  | (7.1 | ) |  |  | 3.1 |  |  |  | (1.3 | ) |  |  | (3.5 | ) |  |  | (1.7 | ) |
| Adjustment to income before income taxes |  | $ | 13.0 |  |  | $ | 7.8 |  |  | $ | 17.4 |  |  | $ | 38.2 |  |  | $ | 6.1 |  |  | $ | 2.1 |  |  | $ | 29.8 |  |  | $ | 38.1 |  |
| Income taxes |  |  | 1.0 |  |  |  | 2.3 |  |  |  | 5.7 |  |  |  | 9.0 |  |  |  | 1.5 |  |  |  | 0.5 |  |  |  | 8.6 |  |  |  | 10.6 |  |
| Adjustment to net income |  | $ | 12.0 |  |  | $ | 5.5 |  |  | $ | 11.7 |  |  | $ | 29.2 |  |  | $ | 4.6 |  |  | $ | 1.6 |  |  | $ | 21.2 |  |  | $ | 27.5 |  |
| Total EPS impact |  | $ | 0.53 |  |  | $ | 0.24 |  |  | $ | 0.52 |  |  | $ | 1.29 |  |  | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 0.93 |  |  | $ | 1.20 |  |
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-16 |  |  | Q2-16 |  |  | Q3-16 |  |  | YTD-16 |  |  | Q1-15 |  |  | Q2-15 |  |  | Q3-15 |  |  | YTD-15 |  |
| Net sales |  | $ | 219.4 |  |  | $ | 271.9 |  |  | $ | 280.3 |  |  | $ | 771.6 |  |  | $ | 210.3 |  |  | $ | 222.0 |  |  | $ | 215.5 |  |  | $ | 647.8 |  |
| GAAP operating income |  | $ | 32.4 |  |  | $ | 29.7 |  |  | $ | 27.5 |  |  | $ | 89.7 |  |  | $ | 29.5 |  |  | $ | 36.2 |  |  | $ | 8.6 |  |  | $ | 74.3 |  |
| Add back special operating items |  |  | 9.2 |  |  |  | 14.0 |  |  |  | 22.1 |  |  |  | 45.3 |  |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 33.4 |  |  |  | 39.8 |  |
| Adjusted operating income |  | $ | 41.6 |  |  | $ | 43.7 |  |  | $ | 49.6 |  |  | $ | 135.0 |  |  | $ | 32.5 |  |  | $ | 39.6 |  |  | $ | 42.0 |  |  | $ | 114.1 |  |
| Adjusted operating margin |  |  | 19.0 | % |  |  | 16.1 | % |  |  | 17.7 | % |  |  | 17.5 | % |  |  | 15.5 | % |  |  | 17.8 | % |  |  | 19.5 | % |  |  | 17.6 | % |
| Add back amortization |  |  | 3.8 |  |  |  | 5.2 |  |  |  | 4.4 |  |  |  | 13.4 |  |  |  | 3.1 |  |  |  | 2.9 |  |  |  | 3.0 |  |  |  | 9.0 |  |
| Add back depreciation |  |  | 7.2 |  |  |  | 8.9 |  |  |  | 8.7 |  |  |  | 24.8 |  |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 22.1 |  |
| Adjusted EBITDA |  | $ | 52.6 |  |  | $ | 57.8 |  |  | $ | 62.7 |  |  | $ | 173.2 |  |  | $ | 43.0 |  |  | $ | 49.9 |  |  | $ | 52.4 |  |  | $ | 145.2 |  |
| Adjusted EBITDA margin |  |  | 24.0 | % |  |  | 21.3 | % |  |  | 22.4 | % |  |  | 22.4 | % |  |  | 20.4 | % |  |  | 22.5 | % |  |  | 24.3 | % |  |  | 22.4 | % |
| Year-over-year adjusted EBITDA growth |  |  | 22 | % |  |  | 16 | % |  |  | 20 | % |  |  | 19 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-16 |  |  | Q2-16 |  |  | Q3-16 |  |  | YTD-16 |  |  | Q1-15 |  |  | Q2-15 |  |  | Q3-15 |  |  | YTD-15 |  |
| Income taxes |  | $ | 7.8 |  |  | $ | 6.9 |  |  | $ | (0.4 | ) |  | $ | 14.3 |  |  | $ | 6.4 |  |  | $ | 9.0 |  |  | $ | 1.3 |  |  | $ | 16.8 |  |
| Effective rate |  |  | 28.8 | % |  |  | 20.2 | % |  |  | -1.2 | % |  |  | 15.6 | % |  |  | 24.3 | % |  |  | 23.9 | % |  |  | 10.4 | % |  |  | 21.8 | % |
| Non-GAAP adjustment - income taxes |  |  | 1.0 |  |  |  | 2.3 |  |  |  | 5.7 |  |  |  | 9.1 |  |  |  | 1.5 |  |  |  | 0.5 |  |  |  | 8.6 |  |  |  | 10.6 |  |
| Adjusted income taxes |  | $ | 8.8 |  |  | $ | 9.2 |  |  | $ | 5.3 |  |  | $ | 23.4 |  |  | $ | 7.9 |  |  | $ | 9.5 |  |  | $ | 9.9 |  |  | $ | 27.4 |  |
| Adjusted effective rate |  |  | 22.0 | % |  |  | 22.0 | % |  |  | 11.2 | % |  |  | 18.0 | % |  |  | 24.3 | % |  |  | 24.0 | % |  |  | 23.4 | % |  |  | 23.8 | % |

[0001437749-16-040906:8k_2_02:70]
Note: Totals will not always foot due to rounding

[0001437749-16-040906:8k_2_02:71]
###
