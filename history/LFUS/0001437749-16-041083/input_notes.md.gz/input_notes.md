# LFUS notes — 0001437749-16-041083


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001437749-16-041083:notes:1]
2. Correction of immaterial errors

[0001437749-16-041083:notes:2]
In the second quarter of 2016, management determined that the company may incur additional income taxes and interest in a foreign jurisdiction with respect to the 2011 through 2015 fiscal years. The cumulative adjustment for this income tax (including interest of $1.5 million) as of January 2, 2016, is approximately $4.9 million. The adjustment applicable to 2015, 2014, 2013, 2012 and 2011 was $1.6 million, $1.3 million, $1.0 million, $0.9 million and $0.1 million, respectively.

[0001437749-16-041083:notes:3]
Pursuant to the guidance of Staff Accounting Bulletin ("SAB") No. 99, Materiality, the company concluded that the errors were not material to any of its applicable prior period annual and quarterly financial statements. Although the errors were immaterial to prior periods, the prior period annual and interim financial statements were revised, in accordance with SAB No. 108, Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements, due to the significance of the out-of-period correction. The adjustment for each year has been treated as applicable to the fourth quarter of each year.

[0001437749-16-041083:notes:4]
A reconciliation of the effects of the adjustments to the previously reported balance sheet at January 2, 2016 follows ($ in thousands):

[0001437749-16-041083:notes:5]
|  |  | January 2, 2016 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Other long-term liabilities |  | $ | 12,809 |  |  | $ | 4,946 |  |  | $ | 17,755 |  |
| Total equity |  |  | 744,198 |  |  |  | (4,946 | ) |  |  | 739,252 |  |

[0001437749-16-041083:notes:6]
A reconciliation of the effects of the adjustments to the previously reported statements of net income for the years ended January 2, 2016 and December 27, 2014 follows ($ in thousands, except per share amounts):

[0001437749-16-041083:notes:7]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Income taxes |  | $ | 24,482 |  |  | $ | 1,600 |  |  | $ | 26,082 |  |  | $ | 32,228 |  |  | $ | 1,318 |  |  | $ | 33,546 |  |
| Net income |  |  | 82,466 |  |  |  | (1,600 | ) |  |  | 80,866 |  |  |  | 99,418 |  |  |  | (1,318 | ) |  |  | 98,100 |  |
| Net income per share - Basic |  | $ | 3.65 |  |  | $ | (0.07 | ) |  | $ | 3.58 |  |  | $ | 4.41 |  |  | $ | (0.06 | ) |  | $ | 4.35 |  |
| Net income per share - Diluted |  | $ | 3.63 |  |  | $ | (0.07 | ) |  | $ | 3.56 |  |  | $ | 4.37 |  |  | $ | (0.05 | ) |  | $ | 4.32 |  |

[0001437749-16-041083:notes:8]
A reconciliation of the effects of the adjustments to the previously reported statements of cash flows for the years ended January 2, 2016 and December 27, 2014 follows ($ in thousands):

[0001437749-16-041083:notes:9]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Net income |  | $ | 82,466 |  |  | $ | (1,600 | ) |  | $ | 80,866 |  |  | $ | 99,418 |  |  | $ | (1,318 | ) |  | $ | 98,100 |  |
| Accrued taxes |  |  | (1,043 | ) |  |  | 1,600 |  |  |  | 557 |  |  |  | (549 | ) |  |  | 1,318 |  |  |  | 769 |  |
| Net cash provided by operating activities |  |  | 165,826 |  |  |  | — |  |  |  | 165,826 |  |  |  | 153,141 |  |  |  | — |  |  |  | 153,141 |  |

[0001437749-16-041083:notes:10]
A reconciliation of the effects of the adjustments to the previously reported statements of equity for the years ended January 2, 2016 and December 27, 2014 follows ($ in thousands):

[0001437749-16-041083:notes:11]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Net income |  | $ | 82,466 |  |  | $ | (1,600 | ) |  | $ | 80,866 |  |  | $ | 99,418 |  |  | $ | (1,318 | ) |  | $ | 98,100 |  |
| Comprehensive income |  |  | 57,921 |  |  |  | (1,600 | ) |  |  | 56,321 |  |  |  | 57,875 |  |  |  | (1,318 | ) |  |  | 56,557 |  |
| Retained earnings |  |  | 562,717 |  |  |  | (4,946 | ) |  |  | 557,771 |  |  |  | 523,302 |  |  |  | (3,346 | ) |  |  | 519,956 |  |
| Total shareholders’ equity |  |  | 744,198 |  |  |  | (4,946 | ) |  |  | 739,252 |  |  |  | 727,665 |  |  |  | (3,346 | ) |  |  | 724,319 |  |

[0001437749-16-041083:notes:12]
A reconciliation of the effects of the adjustments to the previously reported statement of equity at December 28, 2013 follows ($ in thousands):

[0001437749-16-041083:notes:13]
|  |  | December 28, 2013 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Retained earnings |  | $ | 445,059 |  |  | $ | (2,028 | ) |  | $ | 443,031 |  |
| Total shareholders’ equity |  |  | 686,916 |  |  |  | (2,028 | ) |  |  | 684,888 |  |


## us-gaap:AssetImpairmentChargesTextBlock

[0001437749-16-041083:notes:14]
[same as prior period, unchanged from 0001437749-16-036614:notes:14]

[0001437749-16-041083:notes:15]
5

[0001437749-16-041083:notes:16]
[same as prior period, unchanged from 0001437749-16-036614:notes:16]

[0001437749-16-041083:notes:17]
During the first quarter of 2016, the company sold its tangible and intangible assets relating to a marine product line that it acquired as part of its acquisition of Selco A/S in 2011. In connection with this sale, the company recorded a loss on sale of the product line of $1.4 million reflected within selling, general and administrative expenses for the nine months ended October 1, 2016. This loss was recognized as an “other” charge for segment reporting purposes.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-16-041083:notes:18]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (in thousands, except per share amounts) |  | October 1, 2016 |  |  | September 26, 2015 |  |  | October 1, 2016 |  |  | September 26, 2015 |  |
| Net sales |  | $ | 290,377 |  |  | $ | 278,093 |  |  | $ | 846,127 |  |  | $ | 834,372 |  |
| Income before income taxes |  |  | 32,728 |  |  |  | 17,823 |  |  |  | 110,853 |  |  |  | 88,124 |  |
| Net income |  |  | 33,086 |  |  |  | 6,324 |  |  |  | 96,713 |  |  |  | 69,110 |  |
| Net income per share — basic |  |  | 1.47 |  |  |  | 0.28 |  |  |  | 4.30 |  |  |  | 3.05 |  |
| Net income per share — diluted |  |  | 1.46 |  |  |  | 0.28 |  |  |  | 4.26 |  |  |  | 3.04 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-16-041083:notes:19]
4

[0001437749-16-041083:notes:20]
[same as prior period, unchanged from 0001437749-16-036614:notes:20]

[0001437749-16-041083:notes:21]
[same as prior period, unchanged from 0001437749-16-036614:notes:21]

[0001437749-16-041083:notes:22]
| AOCI component |  | Balance at January 2, 2016 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Balance at October 1, 2016 |  |
| Pension and post employment liability and reclassification adjustments(a) |  | $ | (8,722 | ) |  | $ | (183 | ) |  | $ | 212 |  |  | $ | (8,693 | ) |
| Unrealized gain on investments(b) |  |  | 11,584 |  |  |  | (559 | ) |  |  | — |  |  |  | 11,025 |  |
| Foreign currency translation adjustment |  |  | (48,533 | ) |  |  | (8,951 | ) |  |  | — |  |  |  | (57,484 | ) |
| AOCI (loss) income |  | $ | (45,671 | ) |  | $ | (9,693 | ) |  | $ | 212 |  |  | $ | (55,152 | ) |

[0001437749-16-041083:notes:23]
(a) Balances are net of tax of $661 and $1,056 for January 2, 2016 and October 1, 2016, respectively.

[0001437749-16-041083:notes:24]
(b) Balances are net of tax of $0 and $0 for January 2, 2016 and October 1, 2016, respectively.


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0001437749-16-041083:notes:25]
7

[0001437749-16-041083:notes:26]
[same as prior period, unchanged from 0001437749-16-036614:notes:26]

[0001437749-16-041083:notes:27]
[same as prior period, unchanged from 0001437749-16-036614:notes:27]

[0001437749-16-041083:notes:28]
[same as prior period, unchanged from 0001437749-16-036614:notes:28]

[0001437749-16-041083:notes:29]
[same as prior period, unchanged from 0001437749-16-036614:notes:29]

[0001437749-16-041083:notes:30]
The Polytronics investment was acquired as part of the Littelfuse GmbH acquisition. The fair value of the Polytronics investment was €10.2 million (approximately $11.5 million) at October 1, 2016 and €10.7 million (approximately $11.7 million) at January 2, 2016. Included in 2016 other comprehensive income is an unrealized loss of $0.6 million, due to the decrease in fair market value of the Polytronics investment. The remaining change in the recorded value was due to the impact of changes in exchange rates.

[0001437749-16-041083:notes:31]
[same as prior period, unchanged from 0001437749-16-036614:notes:31]

[0001437749-16-041083:notes:32]
In December 2015, the company invested $3.5 million in the preferred stock of Monolith, a U.S. start-up company developing silicon carbide technology, which represents approximately 12% of the common stock of Monolith on an as-converted basis. The company accounts for its investment in Monolith under the cost method. The carrying value of the Monolith investment was $3.5 million at October 1, 2016 and January 2, 2016.


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-041083:notes:33]
8

[0001437749-16-041083:notes:34]
. Debt

[0001437749-16-041083:notes:35]
The carrying amounts of debt at October 1, 2016 and January 2, 2016 are as follows (in thousands):

[0001437749-16-041083:notes:36]
|  |  | October 1, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 315,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 121,875 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 5,173 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,092 | ) |  |  | (721 | ) |
| Total debt |  |  | 440,456 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | (6,250 | ) |  |  | (87,000 | ) |
| Total long-term debt |  | $ | 434,206 |  |  | $ | 83,753 |  |

[0001437749-16-041083:notes:37]
Revolving Credit F

[0001437749-16-041083:notes:38]
acility / Term Loan

[0001437749-16-041083:notes:39]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of October 1, 2016, the company

[0001437749-16-041083:notes:40]
had $0.1 million outstanding in letters of credit and had available $259.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (2

[0001437749-16-041083:notes:41]
.03% as of October 1, 2016). At October 1, 2016, the company was in compliance with all covenants under the credit agreement

[0001437749-16-041083:notes:42]
.

[0001437749-16-041083:notes:43]
Entrusted Loan

[0001437749-16-041083:notes:44]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 34.5 million (approximately $5.2 million) at October 1, 2016.

[0001437749-16-041083:notes:45]
Debt Issuance Costs

[0001437749-16-041083:notes:46]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which

[0001437749-16-041083:notes:47]
, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement.

[0001437749-16-041083:notes:48]
This new credit agreement was determined to be a modification under ASC 470-50 of the previous credit agreement.

[0001437749-16-041083:notes:49]
In April 2015, the FASB issued ASU No. 2015-03, 
Interest - Imputation of Interest
 (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The company adopted this guidance in the first quarter of 2016, on a retrospective basis, and has reclassified the unamortized debt issuance costs into long-term debt as shown in the table above.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-041083:notes:50]
10

[0001437749-16-041083:notes:51]
[same as prior period, unchanged from 0001437749-16-036614:notes:50]

[0001437749-16-041083:notes:52]
The following table sets forth the computation of basic and diluted earnings per share for the periods ending October 1, 2016 and September 26, 2015 (in thousands, except per share amounts):

[0001437749-16-041083:notes:53]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | October 1, 2016 |  |  | September 26, 2015 |  |  | October 1, 2016 |  |  | September 26, 2015 |  |
| Net income |  | $ | 30.802 |  |  | $ | 11,324 |  |  | $ | 77,243 |  |  | $ | 60,003 |  |
| Average shares outstanding - Basic |  |  | 22,578 |  |  |  | 22,581 |  |  |  | 22,515 |  |  |  | 22,623 |  |
| Net effect of dilutive stock options and restricted share units |  |  | 156 |  |  |  | 112 |  |  |  | 160 |  |  |  | 148 |  |
| Average shares - Diluted |  |  | 22,734 |  |  |  | 22,693 |  |  |  | 22,675 |  |  |  | 22,771 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.36 |  |  | $ | 0.50 |  |  | $ | 3.43 |  |  | $ | 2.65 |  |
| Diluted |  | $ | 1.35 |  |  | $ | 0.50 |  |  | $ | 3.41 |  |  | $ | 2.64 |  |

[0001437749-16-041083:notes:54]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 76,845 and 144,031 for the three months ended October 1, 2016 and September 26, 2015, respectively, and 45,591 and 108,193 for the nine months ended October 1, 2016 and September 26, 2015, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-16-041083:notes:55]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 11,474 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,474 |  |
| Total |  | $ | 11,474 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,474 |  |

[0001437749-16-041083:notes:56]
[same as prior period, unchanged from 0001437749-16-036614:notes:55]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-16-041083:notes:57]
9

[0001437749-16-041083:notes:58]
[same as prior period, unchanged from 0001437749-16-036614:notes:57]

[0001437749-16-041083:notes:59]
[same as prior period, unchanged from 0001437749-16-036614:notes:58]

[0001437749-16-041083:notes:60]
[same as prior period, unchanged from 0001437749-16-036614:notes:59]

[0001437749-16-041083:notes:61]
[same as prior period, unchanged from 0001437749-16-036614:notes:60]

[0001437749-16-041083:notes:62]
[same as prior period, unchanged from 0001437749-16-036614:notes:61]

[0001437749-16-041083:notes:63]
[same as prior period, unchanged from 0001437749-16-036614:notes:62]

[0001437749-16-041083:notes:64]
[same as prior period, unchanged from 0001437749-16-036614:notes:63]

[0001437749-16-041083:notes:65]
[same as prior period, unchanged from 0001437749-16-036614:notes:64]

[0001437749-16-041083:notes:66]
The company holds an investment in the equity securities of Polytronics as described in Note 7. Equity securities listed on a national market or exchange, such as Polytronics securities, are valued at the last sales price. Such securities are classified within Level 1 of the valuation hierarchy. The company also holds an investment in Monolith as described in Note 7 for which the value of the $3.5 million represents the cost of the investment.

[0001437749-16-041083:notes:67]
There were no changes during the quarter ended October 1, 2016 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of October 1, 2016 and January 2, 2016

[0001437749-16-041083:notes:68]
, the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-16-041083:notes:69]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of October 1, 2016 (in thousands):

[0001437749-16-041083:notes:70]
[same as prior period, unchanged from 0001437749-16-036614:notes:68]

[0001437749-16-041083:notes:71]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt. The carrying amounts of cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt approximate their fair values. The company’s debt fair value approximates book value at October 1, 2016 and January 2, 2016, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-041083:notes:72]
11

[0001437749-16-041083:notes:73]
[same as prior period, unchanged from 0001437749-16-036614:notes:71]

[0001437749-16-041083:notes:74]
The effective tax rate for the third quarter of 2016 was negative 1.2% compared to an effective tax rate of 10.4% in the third quarter of 2015. The effective tax rate for the nine months ended October 1, 2016 was 15.6% compared to an effective tax rate of 21.8% for the nine months ended September 26, 2015. The effective tax rates for the periods presented are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions and, with respect to the 2016 periods, a one-time deduction with respect to the stock of one of the company’s affiliates partially offset by the impact of the impairment of goodwill for which no tax benefit was recorded, and, with respect to the 2015 periods, the impact of a pension settlement partially offset by the impact from the restructuring of the legal ownership of the company’s Mexican manufacturing operations.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001437749-16-041083:notes:75]
Impairment of Goodwill and Intangible Assets

[0001437749-16-041083:notes:76]
The company annually tests goodwill for impairment during

[0001437749-16-041083:notes:77]
its fiscal fourth quarter or at an interim date if there is an event or change in circumstances that indicates the asset may be impaired. As of the most recent annual test conducted, the company concluded the fair value of its custom products reporting unit exceeded its carrying value of invested capital by 12% and therefore, no potential goodwill impairment existed in 2015.

[0001437749-16-041083:notes:78]
Due to recent negative events in the potash market subsequent to the company’s 2016

[0001437749-16-041083:notes:79]
second quarter end, the company conducted a step one goodwill impairment analysis for the custom products reporting unit to determine if goodwill was impaired as of July 2, 2016. The fair value of this reporting unit at this date exceeded its carrying value by less than 10%.  Since then, the potash market has continued to see a decline in market pricing in the potash mining industry. Due to this continuing decline in potash pricing

[0001437749-16-041083:notes:80]
, management revisited its long term projections during the company’s third quarter 2016 and conducted another step one goodwill impairment analysis. The custom products reporting unit failed the step one test and management conducted a step two analysis with the revised projections. The fair value of the unit was estimated using the expected present value of future cash flows over a seven year forecast period and appraisal of certain assets. This analysis required a write down of the reporting unit’s carrying value of $14.8 million. A goodwill impairment loss of $8.8 million and intangible assets impairments aggregating $6.0 million were recognized during the third quarter, including a $3.8 million reduction of the custom products trade names to a $0.7 million remaining value and a $2.2 million reduction of the reporting unit’s customer relationships to zero value.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-16-041083:notes:81]
6

[0001437749-16-041083:notes:82]
[same as prior period, unchanged from 0001437749-16-036614:notes:74]

[0001437749-16-041083:notes:83]
The components of inventories at October 1, 2016 and January 2, 2016 are as follows (in thousands):

[0001437749-16-041083:notes:84]
|  |  | October 1, 2016 |  |  | January 2, 2016 |  |
| Raw material |  | $ | 35,450 |  |  | $ | 33,599 |  |
| Work in process |  |  | 24,703 |  |  |  | 16,479 |  |
| Finished goods |  |  | 61,463 |  |  |  | 48,551 |  |
| Total inventories |  | $ | 121,616 |  |  | $ | 98,629 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-16-041083:notes:85]
[same as prior period, unchanged from 0001437749-16-036614:notes:77]

[0001437749-16-041083:notes:86]
TVS Diode/Thyristor/IGBT business

[0001437749-16-041083:notes:87]
On August 29, 2016, the company acquired certain assets of select businesses (the “TVS Diode/Thyristor/IGBT business”) of ON Semiconductor Corporation for $104.0 million. The company funded the acquisition with available cash and proceeds from its credit facility

[0001437749-16-041083:notes:88]
. The acquired business, which is included in the Electronics segment,

[0001437749-16-041083:notes:89]
consists of a product portfolio that includes transient voltage suppression (TVS) diodes, switching thyristors and insulated gate bipolar transistors (IGBT) for automotive ignition applications. The acquisition expands the company’s offerings in power semiconductor applications as well as increases its presence in the automotive electronics market. The TVS Diode/Thyristor/IGBT business products have strong synergies with the company’s existing circuit protection business, will strengthen its channel partnerships and customer engagement, and expand its power semiconductor portfolio.

[0001437749-16-041083:notes:90]
The following table represents the preliminary allocation of the total consideration to assets acquired and liabilities assumed in the acquisition of the TVS Diode/Thyristor/IGBT business based on the company’s preliminary estimate of their respective fair values at the acquisition date (in thousands):

[0001437749-16-041083:notes:91]
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 104,000 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  |  | 4,616 |  |
| Customer relationships |  |  | 31,650 |  |
| Patented and unpatented technologies |  |  | 10,250 |  |
| Non-compete agreement |  |  | 2,500 |  |
| Goodwill |  |  | 54,984 |  |
|  |  | $ | 104,000 |  |

[0001437749-16-041083:notes:92]
All the TVS Diode/Thyristor/IGBT business goodwill and other assets were recorded in the Electronics segment and are reflected in the Americas and Europe geographic areas. The customer relationships are preliminarily being amortized over 13.5 years. The patented and unpatented technologies are preliminarily being amortized over 6-8.5 years. The non-compete agreement is preliminarily being amortized over 4 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining the TVS Diode/Thyristor/IGBT business products with the company’s existing

[0001437749-16-041083:notes:93]
power semiconductor product portfolio. A portion of goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-16-041083:notes:94]
As required by purchase accounting rules, the company recorded a $0.5 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. $0.3 million of the step-up was amortized as a non-cash charge to cost of goods sold during the third quarter of 2016, as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-16-041083:notes:95]
Included in the company’s consolidated statements of net income for the three and nine months ended October 1, 2016 are net sales of approximately $5.6 million and $5.6 million, respectively, since the August 29, 2016 acquisition of the TVS Diode/Thyristor/IGBT business

[0001437749-16-041083:notes:96]
[same as prior period, unchanged from 0001437749-16-036614:notes:78]

[0001437749-16-041083:notes:97]
On April 4, 2016, the company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy for $19.2 million, net of acquired cash and after settlement of a working capital adjustment. At October 1, 2016, $18.9 million of the $19.2 million purchase price has been paid and financed through a mixture of cash on hand and borrowings under the company’s revolving credit facility, with the remaining consideration expected to be paid out in the remainder of 2016. The acquired business is part of the company's commercial vehicle product business within the Automotive segment and specializes in the design, manufacturing and selling of manual and electrical high current switches and trailer connectors for commercial vehicles.

[0001437749-16-041083:notes:98]
[same as prior period, unchanged from 0001437749-16-036614:notes:82]

[0001437749-16-041083:notes:99]
| Total purchase consideration: |  |  |  |  |
| Cash, net of acquired cash |  | $ | 18,909 |  |
| Additional consideration payable |  |  | 253 |  |
| Total purchase consideration |  | $ | 19,162 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 13,560 |  |
| Property, plant and equipment |  |  | 1,693 |  |
| Customer relationships |  |  | 3,050 |  |
| Patented and unpatented technologies |  |  | 224 |  |
| Trademarks and tradenames |  |  | 1,849 |  |
| Goodwill |  |  | 7,651 |  |
| Current liabilities |  |  | (7,421 | ) |
| Other non-current liabilities |  |  | (1,444 | ) |
|  |  | $ | 19,162 |  |

[0001437749-16-041083:notes:100]
All Menber’s goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The customer relationships are being amortized over 1

[0001437749-16-041083:notes:101]
[same as prior period, unchanged from 0001437749-16-036614:notes:85]

[0001437749-16-041083:notes:102]
As required by purchase accounting rules, the company recorded a $0.2 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the third quarter of 2016 with the charge reflected as other non-segment costs.

[0001437749-16-041083:notes:103]
Included in the company’s consolidated statements of net income for the three and nine months ended October 1, 2016 are net sales of approximately $5.3 million and $12.0 million, respectively, since the April 4, 2016 acquisition of Menber’s.

[0001437749-16-041083:notes:104]
[same as prior period, unchanged from 0001437749-16-036614:notes:88]

[0001437749-16-041083:notes:105]
On March 25, 2016, the company acquired 100% of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for $348.0 million, net of acquired cash and after settlement of certain post-closing adjustments.

[0001437749-16-041083:notes:106]
At October 1, 2016, $342.3 million of the $348.0 million purchase price has been paid and financed through a mixture of cash on hand and borrowings under the company’s revolving credit facility, with the remaining consideration expected to be paid by the 2
nd
 quarter of 2017. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-16-041083:notes:107]
has a leading position in polymer based resettable circuit protection devices, with a strong global presence in the automotive, battery, industrial, communications and mobile computing markets. PolySwitch has operations in Menlo Park, California and manufacturing facilities in Shanghai and Kunshan, China and Tsukuba, Japan. The acquisition allows the company to strengthen its global circuit protection product portfolio, as well as strengthen its presence in the automotive electronics and battery end markets. The acquisition also significantly increases the company’s presence in Japan. The company funded the acquisition with available cash and proceeds from a new credit facility

[0001437749-16-041083:notes:108]
[same as prior period, unchanged from 0001437749-16-036614:notes:91]

[0001437749-16-041083:notes:109]
| Total purchase consideration: |  |  |  |  |
| Original consideration |  | $ | 350,000 |  |
| Post closing consideration adjustment received |  |  | (2,029 | ) |
| Acquired cash |  |  | (5,719 | ) |
| Acquired cash to be returned to seller |  |  | 5,719 |  |
| Total purchase consideration |  | $ | 347,971 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Current assets, net |  | $ | 59,751 |  |
| Property, plant and equipment |  |  | 52,025 |  |
| Land lease |  |  | 4,290 |  |
| Patented and unpatented technologies |  |  | 56,425 |  |
| Customer relationships |  |  | 39,720 |  |
| Goodwill |  |  | 163,635 |  |
| Other long-term assets |  |  | 10,711 |  |
| Current liabilities |  |  | (37,068 | ) |
| Other non-current liabilities |  |  | (1,518 | ) |
|  |  | $ | 347,971 |  |

[0001437749-16-041083:notes:110]
[same as prior period, unchanged from 0001437749-16-036614:notes:93]

[0001437749-16-041083:notes:111]
[same as prior period, unchanged from 0001437749-16-036614:notes:94]

[0001437749-16-041083:notes:112]
Included in the company’s consolidated statements of net income for the three and nine months ended October 1, 2016 are net sales of approximately $47.9 million and $84.4 million, respectively, since the March 25, 2016 acquisition of PolySwitch.

[0001437749-16-041083:notes:113]
[same as prior period, unchanged from 0001437749-16-036614:notes:97]

[0001437749-16-041083:notes:114]
On October 1, 2015, the company acquired 100% of Sigmar S.r.l. (“Sigmar”). The total purchase price for Sigmar is expected to be $6.7 million, net of cash acquired and including: (1) additional consideration of $1.

[0001437749-16-041083:notes:115]
0 million paid in the first nine months of 2016 relating to certain working capital related adjustments and an earn-out clause payment; and (2) estimated additional net payments of up to $0.9 million, a portion of which is subject to the achievement of certain milestones.

[0001437749-16-041083:notes:116]
Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel sensors and also manufactures selective catalytic reduction (SCR) quality sensors and diesel fuel heaters for automotive and commercial vehicle applications. The acquisition further expanded the company’s automotive sensor product line offerings within its Automotive segment. The company funded the acquisition with available cash.

[0001437749-16-041083:notes:117]
[same as prior period, unchanged from 0001437749-16-036614:notes:100]

[0001437749-16-041083:notes:118]
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 5,788 |  |
| Estimated additional consideration payable |  |  | 901 |  |
| Total purchase consideration |  | $ | 6,689 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Cash |  | $ | 230 |  |
| Current assets, net |  |  | 4,011 |  |
| Property, plant and equipment |  |  | 1,097 |  |
| Goodwill |  |  | 2,552 |  |
| Patents |  |  | 2,845 |  |
| Current liabilities |  |  | (1,478 | ) |
| Other non-current liabilities |  |  | (2,568 | ) |
|  |  | $ | 6,689 |  |

[0001437749-16-041083:notes:119]
All Sigmar goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographic area. The patents are being amortized over 10 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining Sigmar’s products with the company’s existing automotive product offerings. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-16-041083:notes:120]
[same as prior period, unchanged from 0001437749-16-036614:notes:103]

[0001437749-16-041083:notes:121]
The following table summarizes, on a pro forma basis, the combined results of operations of the company and the acquired PolySwitch and the TVS Diode/Thyristor/IGBT businesses as though the acquisitions had occurred as of December 28, 2014. The company has not provided pro forma results of operations for Menber’s or Sigmar as these results were not material to the company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the PolySwitch or TVS Diode/Thyristor/IGBT acquisitions occurred as of December 28, 2014 or of future consolidated operating results

[0001437749-16-041083:notes:122]
Pro forma results presented above primarily reflect: (1) incremental depreciation relating to fair value adjustments to property, plant and equipment; (2) amortization adjustments relating to fair value estimates of intangible assets; (3) incremental interest expense on assumed indebtedness; and (4) additional cost of goods sold relating to the capitalization of gross profit as part of purchase accounting recognized for purposes of the pro forma as if it was recognized during the company’s first quarter of 2015. Pro forma adjustments described above have been tax affected using the company's effective rate during the respective periods.

[0001437749-16-041083:notes:123]
The historical PolySwitch and TVS Diode/Thyristor/IGBT business results for the three and nine months ended October 1, 2016 and September 26, 2015 do not include a provision for income taxes. Income tax expense for the historical PolySwitch business was only provided at the end of the business’s fiscal year ended September 25, 2015. Income tax expense for the historical TVS Diode/Thyristor/IGBT business was not provided on a standalone basis.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001437749-16-041083:notes:124]
Recently issued accounting pronouncements

[0001437749-16-041083:notes:125]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09 ("ASU 2014-09"), Revenue from Contracts with Customers, which amends guidance for revenue recognition. Under the new standard, revenue will be recognized when control of the promised goods or services is transferred to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods and services. The standard creates a five-step model that will generally require companies to use more judgment and make more estimates than under current guidance when considering the terms of contracts along with all relevant facts and circumstances. These include the identification of customer contracts and separating performance obligations, the determination of transaction price that potentially includes an estimate of variable consideration, allocating the transaction price to each separate performance obligation, and recognizing revenue in line with the pattern of transfer. In August 2015, the FASB issued an No. 2015-14, "Deferral of Effective Date" (Topic 606) to defer the effective date for all entities by one year. The new standard will become effective for annual reporting periods beginning after December 15, 2017, including interim periods within that reporting period. Early adoption is permitted as of annual reporting periods beginning after December 15, 2016. Companies have the option of using either a full or modified retrospective approach in applying this standard. In March 2016, the FASB issued ASU No. 2016-08, "Principal versus Agent Considerations (Reporting Revenue Gross versus Net)" (Topic 606). ASU 2016-08 provides clarification for the implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU No. 2016-10, ASU No. 2016-11, and ASU 2016-12, all of which provide additional clarification of the original revenue standard. The company is currently in the process of evaluating the impact of adoption on its consolidated financial statements.

[0001437749-16-041083:notes:126]
In July 2015, the FASB issued Accounting Standards Update No. 2015-11 ("ASU 2015-11"), Simplifying the Measurement of Inventory. ASU 2015-11 clarifies that inventory should be held at the lower of cost or net realizable value. Net realizable value is defined as the estimated selling price, less the estimated costs to complete, dispose and transport such inventory. ASU 2015-11 will be effective for fiscal years and interim periods beginning after December 15, 2016. ASU 2015-11 is required to be applied prospectively and early adoption is permitted. The company is currently in the process of evaluating the impact of adoption on its consolidated financial statements.

[0001437749-16-041083:notes:127]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02 (“ASU 2016-02”), Leases (Topic 842). ASU 2016-02 establishes a right-of-use (ROU) model that requires a lessee to record a ROU asset and a lease liability on the balance sheet for all leases with terms longer than 12 months. Leases will be classified as either finance or operating, with classification affecting the pattern of expense recognition in the income statement. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. A modified retrospective transition approach is required for capital leases and operating leases existing at, or entered into after, the beginning of the earliest comparative period presented in the financial statements, with certain practical expedients available. The company is currently in the process of evaluating the impact of adoption on its consolidated financial statements.

[0001437749-16-041083:notes:128]
In March 2016, the FASB issued Accounting Standards Update No. 2016-09 ("ASU 2016-09"), Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. ASU 2016-09 will directly impact the tax administration of equity plans. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted and any adjustments should be reflected as of the beginning of the fiscal year that includes that interim period. The company is currently in the process of evaluating the impact of adoption on its consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-16-041083:notes:129]
2. Pensions

[0001437749-16-041083:notes:130]
The components of net periodic benefit cost for the three and nine months ended October 1, 2016, compared with the three and nine months ended September 26, 2015, were (in thousands):

[0001437749-16-041083:notes:131]
|  |  | U.S. Pension Benefits |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | October 1, 2016 |  |  | September 26, 2015 |  |  | October 1, 2016 |  |  | September 26, 2015 |  |  | October 1, 2016 |  |  | September 26, 2015 |  |  | October 1, 2016 |  |  | September 26, 2015 |  |
| Service cost |  | $ | - |  |  | $ | 250 |  |  | $ | - |  |  | $ | 750 |  |  | $ | 332 |  |  | $ | 314 |  |  | $ | 997 |  |  | $ | 944 |  |
| Interest cost |  |  | - |  |  |  | 1,032 |  |  |  | - |  |  |  | 3,094 |  |  |  | 496 |  |  |  | 512 |  |  |  | 1,489 |  |  |  | 1,538 |  |
| Expected return on plan assets |  |  | - |  |  |  | (917 | ) |  |  | - |  |  |  | (2,749 | ) |  |  | (520 | ) |  |  | (599 | ) |  |  | (1,560 | ) |  |  | (1,800 | ) |
| Amortization of net loss |  |  | - |  |  |  | 290 |  |  |  | - |  |  |  | 870 |  |  |  | 74 |  |  |  | 62 |  |  |  | 220 |  |  |  | 185 |  |
| Total cost (credit) of the plan |  |  | - |  |  |  | 655 |  |  |  | - |  |  |  | 1,965 |  |  |  | 382 |  |  |  | 289 |  |  |  | 1,146 |  |  |  | 867 |  |
| Expected plan participants’contribution |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net periodic benefit cost (credit) |  |  | - |  |  |  | 655 |  |  |  | - |  |  |  | 1,965 |  |  |  | 382 |  |  |  | 289 |  |  |  | 1,146 |  |  |  | 867 |  |
| Settlement charge |  |  | - |  |  |  | 30,194 |  |  |  | - |  |  |  | 30,194 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Total pension cost (credit) |  | $ | - |  |  | $ | 30,849 |  |  | $ | - |  |  | $ | 32,159 |  |  | $ | 382 |  |  | $ | 289 |  |  | $ | 1,146 |  |  | $ | 867 |  |

[0001437749-16-041083:notes:132]
[same as prior period, unchanged from 0001437749-16-036614:notes:110]

[0001437749-16-041083:notes:133]
The expected rate of return assumption on U.S. pension assets was 3.90% in 2015. The expected return on foreign pension assets is 4

[0001437749-16-041083:notes:134]
.95% and 5.39% in 2016 and 2015, respectively.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-16-041083:notes:135]
|  |  | Long-lived assets(b) |  |
|  |  | October 1, 2016 |  |  | January 2, 2016 |  |
| United States |  | $ | 24,578 |  |  | $ | 23,965 |  |
| China |  |  | 67,003 |  |  |  | 37,241 |  |
| Mexico |  |  | 51,988 |  |  |  | 47,130 |  |
| Philippines |  |  | 34,511 |  |  |  | 33,525 |  |
| Other countries |  |  | 45,773 |  |  |  | 20,707 |  |
| Total |  | $ | 223,853 |  |  | $ | 162,568 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001437749-16-041083:notes:136]
|  |  | For the Three Months Ended(a) |  |  | For the Nine Months Ended(a) |  |
|  |  | October 1, 2016 |  |  | September 26, 2015 |  |  | October 1, 2016 |  |  | September 26, 2015 |  |
| United States |  | $ | 92,475 |  |  | $ | 85,049 |  |  | $ | 270,659 |  |  | $ | 258,030 |  |
| China |  |  | 70,215 |  |  |  | 49,345 |  |  |  | 181,134 |  |  |  | 143,694 |  |
| Other countries |  |  | 117,641 |  |  |  | 81,116 |  |  |  | 319,848 |  |  |  | 246,120 |  |
| Total |  | $ | 280,331 |  |  | $ | 215,510 |  |  | $ | 771,641 |  |  | $ | 647,844 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-16-041083:notes:137]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | October 1, 2016 |  |  | September 26, 2015 |  |  | October 1, 2016 |  |  | September 26, 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 147,730 |  |  | $ | 102,616 |  |  | $ | 378,696 |  |  | $ | 307,549 |  |
| Automotive |  |  | 106,341 |  |  |  | 81,475 |  |  |  | 309,644 |  |  |  | 251,464 |  |
| Industrial |  |  | 26,260 |  |  |  | 31,419 |  |  |  | 83,301 |  |  |  | 88,831 |  |
| Total net sales |  | $ | 280,331 |  |  | $ | 215,510 |  |  | $ | 771,641 |  |  | $ | 647,844 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 7,694 |  |  | $ | 5,811 |  |  | $ | 20,783 |  |  | $ | 17,384 |  |
| Automotive |  |  | 4,627 |  |  |  | 3,244 |  |  |  | 12,881 |  |  |  | 9,883 |  |
| Industrial |  |  | 1,733 |  |  |  | 1,260 |  |  |  | 4,561 |  |  |  | 3,839 |  |
| Other(1) |  |  | (937 | ) |  |  | - |  |  |  | - |  |  |  | - |  |
| Total depreciation and amortization |  | $ | 13,117 |  |  | $ | 10,315 |  |  | $ | 38,225 |  |  | $ | 31,106 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 34,571 |  |  | $ | 20,923 |  |  | $ | 82,246 |  |  | $ | 61,755 |  |
| Automotive |  |  | 15,032 |  |  |  | 15,253 |  |  |  | 48,997 |  |  |  | 39,123 |  |
| Industrial |  |  | 57 |  |  |  | 5,781 |  |  |  | 3,758 |  |  |  | 13,220 |  |
| Other(2) |  |  | (22,134 | ) |  |  | (33,373 | ) |  |  | (45,345 | ) |  |  | (39,795 | ) |
| Total operating income |  |  | 27,526 |  |  |  | 8,584 |  |  |  | 89,656 |  |  |  | 74,303 |  |
| Interest expense |  |  | 2,571 |  |  |  | 922 |  |  |  | 6,286 |  |  |  | 3,021 |  |
| Foreign exchange (gain) loss |  |  | (4,700 | ) |  |  | (3,549 | ) |  |  | (7,114 | ) |  |  | (1,724 | ) |
| Other (income) expense, net |  |  | (778 | ) |  |  | (1,430 | ) |  |  | (1,040 | ) |  |  | (3,758 | ) |
| Income before income taxes |  | $ | 30,433 |  |  | $ | 12,641 |  |  | $ | 91,524 |  |  | $ | 76,764 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-041083:notes:138]
3

[0001437749-16-041083:notes:139]
[same as prior period, unchanged from 0001437749-16-036614:notes:117]

[0001437749-16-041083:notes:140]
The company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0001437749-16-041083:notes:141]
Sales, marketing and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology and human resources are shared functions that are allocated back to the three operating segments. The company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”

[0001437749-16-041083:notes:142]
. Additionally, the company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the company as a whole.

[0001437749-16-041083:notes:143]
Segment information for the three and nine months ended October 1, 2016 and September 26, 2015 are summarized as follows (in thousands):

[0001437749-16-041083:notes:144]
(1) Consists of intangible impairments related to its loss on sale of product line now reflected in selling, general and administrative expenses for the nine months ended October 1, 2016. (See Note 15).

[0001437749-16-041083:notes:145]
(2) Included in “Other” Operating income (loss) for the 2016 third quarter is $14.8 million (14.8 million year-to-date) of charges related to the impairment of the custom products reporting unit, $5.9 million ($18.2 million year-to-date) of acquisition and integration costs associated with the company’s 2016 acquisitions, primarily PolySwitch, $0.6 million ($7.5 million year-to-date) of non-cash inventory charges relating to the company’s 2016 acquisitions, primarily PolySwitch, as described in Note 4, $1.9 million year-to-date in charges related to the closure of the company’s manufacturing facility in Denmark, $1.7 million year-to-date related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.9 million ($1.3 million year-to-date) related to internal legal restructuring costs.

[0001437749-16-041083:notes:146]
Included in “Other” Operating income (loss) for the 2015 third quarter is $2.1 million ($6.8 million year-to-date) related to internal legal restructuring, $0.3 million ($0.7 million year-to-date) related to acquisition costs and $30.9 million ($32.2 million year-to-date) of expense related to the planned termination of the U.S. pension as described in Note 12

[0001437749-16-041083:notes:147]
The company’s significant net sales by country for the three and nine months ended October 1, 2016 and September 26, 2015 are summarized as follows (in thousands):

[0001437749-16-041083:notes:148]
[same as prior period, unchanged from 0001437749-16-036614:notes:132]

[0001437749-16-041083:notes:149]
The company’s significant long-lived assets by country as of October 1, 2016 and January 2, 2016 are summarized as follows (in thousands):

[0001437749-16-041083:notes:150]
(b) Long-lived assets consist of net property, plant and equipment.


## us-gaap:SubsequentEventsTextBlock

[0001437749-16-041083:notes:151]
Subsequent Event

[0001437749-16-041083:notes:152]
On October 14

[0001437749-16-041083:notes:153]
, 2016, the Company completed the sale of its portable electrical house (e-house) business, located in Winnipeg, Manitoba, Canada. This business was included in the company’s custom products reporting unit within the Industrial segment, and mainly served mining and utility markets. Neither the sale nor the historical results of operation of the sold business are material to the company’s financial results.
