# LFUS MD&A — 0001437749-15-008576


## mdna

[0001437749-15-008576:mdna:1]
[same as prior period, unchanged from 0001437749-14-019177:mdna:1]

[0001437749-15-008576:mdna:2]
[same as prior period, unchanged from 0001437749-14-019177:mdna:2]

[0001437749-15-008576:mdna:3]
Littelfuse, Inc. and its subsidiaries (the “company” or “Littelfuse”) is the worldwide leader in circuit protection offering the industry's broadest and deepest portfolio of circuit protection products and solutions. The company’s devices protect products in virtually every market that uses electrical energy, from consumer electronics to automobiles to industrial equipment. The company’s worldwide revenue in 2014 was $852.0 million and net earnings were $99.4 million. The company conducts its business through three reportable segments, which are defined by markets and consist of Electronics, Automotive, and Electrical. The company’s customer base includes original equipment manufacturers, tier one automotive suppliers and distributors.

[0001437749-15-008576:mdna:4]
In addition to protecting and growing its core circuit protection business, Littelfuse has been investing in power control and sensing technologies. These newer platforms combined with the company’s strong balance sheet and operating cash flow, provide opportunities for increased organic and acquisition growth. In 2012, the company set a five-year strategic plan to grow annual sales at 15% per year; 5% organically and 10% through acquisitions.

[0001437749-15-008576:mdna:5]
[same as prior period, unchanged from 0001437749-14-019177:mdna:5]

[0001437749-15-008576:mdna:6]
[same as prior period, unchanged from 0001437749-14-019177:mdna:6]

[0001437749-15-008576:mdna:7]
[same as prior period, unchanged from 0001437749-14-019177:mdna:7]

[0001437749-15-008576:mdna:8]
[same as prior period, unchanged from 0001437749-14-019177:mdna:8]

[0001437749-15-008576:mdna:9]
[same as prior period, unchanged from 0001437749-14-019177:mdna:9]

[0001437749-15-008576:mdna:10]
[same as prior period, unchanged from 0001437749-14-019177:mdna:10]

[0001437749-15-008576:mdna:11]
[same as prior period, unchanged from 0001437749-14-019177:mdna:11]

[0001437749-15-008576:mdna:12]
[same as prior period, unchanged from 0001437749-14-019177:mdna:12]

[0001437749-15-008576:mdna:13]
The Electronics segment sells passive and semiconductor components and modules primarily into the global consumer electronics, general industrial and telecommunications markets. The core electronics markets are characterized by significant Asia competition and price erosion. As a result the company is focusing additional efforts on higher growth, less price sensitive niche markets (such as LED lighting) and higher-power industrial applications. The Hamlin acquisition in 2013 expanded the company’s product offering into reed switches which are used in a wide variety of electronic products and utilize the same channels as the company’s core electronics products.

[0001437749-15-008576:mdna:14]
[same as prior period, unchanged from 0001437749-14-019177:mdna:14]

[0001437749-15-008576:mdna:15]
The Automotive segment is comprised of passenger vehicle circuit protection, commercial vehicle products and sensors. The primary growth drivers for these businesses are increasing global demand for passenger and commercial vehicles and increasing content per vehicle for both circuit protection and sensing products. The move away from internal combustion engines to hybrid and electric drive systems that require more circuit protection is expected to be an additional growth driver.

[0001437749-15-008576:mdna:16]
[same as prior period, unchanged from 0001437749-14-019177:mdna:16]

[0001437749-15-008576:mdna:17]
The Electrical segment derives its revenues from power fuses, protection relays and custom products selling primarily into the industrial, mining, solar and oil and gas markets. Custom products sales, after several years of strong growth, have declined due to the completion of several large Canadian potash mining projects. The company has expanded this business by moving into new markets such as non-potash mining and oil and gas with mixed results. Protection relay sales have also slowed due to the general slowdown in the global mining market.

[0001437749-15-008576:mdna:18]
[same as prior period, unchanged from 0001437749-14-019177:mdna:19]

[0001437749-15-008576:mdna:19]
[same as prior period, unchanged from 0001437749-14-019177:mdna:20]

[0001437749-15-008576:mdna:20]
|  |  | First Quarter |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 99,380 |  |  | $ | 95,722 |  |  |  | 4% |  |
| Automotive |  |  | 84,071 |  |  |  | 82,419 |  |  |  | 2% |  |
| Electrical |  |  | 26,862 |  |  |  | 28,718 |  |  |  | (6%) |  |
| Total |  | $ | 210,313 |  |  | $ | 206,859 |  |  |  | 2% |  |

[0001437749-15-008576:mdna:21]
|  |  | First Quarter |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 97,054 |  |  | $ | 89,151 |  |  |  | 9% |  |
| Europe |  |  | 38,968 |  |  |  | 43,927 |  |  |  | (11%) |  |
| Asia-Pacific |  |  | 74,291 |  |  |  | 73,781 |  |  |  | 1% |  |
| Total |  | $ | 210,313 |  |  | $ | 206,859 |  |  |  | 2% |  |

[0001437749-15-008576:mdna:22]
[same as prior period, unchanged from 0001437749-14-019177:mdna:22]

[0001437749-15-008576:mdna:23]
Results of Operations – First Quarter, 2015 compared to 2014

[0001437749-15-008576:mdna:24]
The following table summarizes the company’s consolidated results of operations for the periods presented. The results include incremental activity from the company’s business acquisitions as described, where applicable, in the below analysis. During the first quarter of 2015, there was approximately $3.0 million of special charges consisting of $1.0 million related to the company’s transfer of its reed sensor manufacturing from the U.S. to the Philippines, $1.2 million related to internal legal restructuring, $0.2 million related to acquisition costs and $0.7 million of expense related to the planned termination of the U.S. pension as described in Note 9.

[0001437749-15-008576:mdna:25]
| (In thousands, unaudited) |  | First Quarter |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |
| Sales |  | $ | 210,313 |  |  | $ | 206,859 |  |  |  | 2% |  |
| Gross Profit |  |  | 76,330 |  |  |  | 78,494 |  |  |  | (3%) |  |
| Operating expense |  |  | 46,782 |  |  |  | 44,904 |  |  |  | 4% |  |
| Operating income |  |  | 29,548 |  |  |  | 33,590 |  |  |  | (12%) |  |
| Other (income) expense, net |  |  | (1,126 | ) |  |  | (1,186 | ) |  |  | (5%) |  |
| Income before income taxes |  |  | 26,406 |  |  |  | 33,812 |  |  |  | (22%) |  |
| Net income |  | $ | 19,995 |  |  | $ | 25,389 |  |  |  | (21%) |  |

[0001437749-15-008576:mdna:26]
Net sales increased $3.5 million or 2% to $210.3 million in the first quarter of 2015 compared to $206.9 million in the first quarter of 2014 due primarily to strong organic growth in electronics and automotive, partially offset by lower electrical sales. The company also experienced $9.9 million in unfavorable foreign currency effects in the first quarter of 2015 as compared to the first quarter of 2014. The unfavorable foreign currency impact primarily resulted from sales denominated in the euro. Excluding currency effects, net sales increased $13.4 million or 6% year-over-year.

[0001437749-15-008576:mdna:27]
Electronics sales increased $3.6 million or 4% to $99.4 million in the first quarter of 2015 compared to $95.7 million in the first quarter of 2014 due primarily to strong growth for fuse and semiconductor products. The electronics segment experienced $3.0 million in unfavorable currency effects in the first quarter of 2015 primarily from sales denominated in euro. Excluding currency effects, net sales increased $6.6 million or 7% year-over-year.

[0001437749-15-008576:mdna:28]
Automotive sales increased $1.7 million or 2% to $84.1 million in the first quarter of 2015 compared to $82.4 million in the first quarter of 2014 due to strong organic growth for commercial vehicle products and sensors. The automotive segment experienced $5.9 million in unfavorable currency effects in the first quarter of 2015 primarily due to sales denominated in euros. Excluding currency effects, net sales increased $7.6 million or 9% year-over-year.

[0001437749-15-008576:mdna:29]
Electrical sales decreased $1.9 million or 6% to $26.9 million in the first quarter of 2015 compared to $28.7 million in the first quarter of 2014 as higher custom sales were more than offset by weaker fuse and relay sales. The electrical segment experienced $1.0 million in unfavorable currency effects in the first quarter of 2015 primarily from sales denominated in Canadian dollars and the euro. Excluding currency effects, net sales decreased $0.8 million or 3% year-over-year.

[0001437749-15-008576:mdna:30]
On a geographic basis, sales in the Americas increased $7.9 million or 9% to $97.1 million in the first quarter of 2015 compared to $89.2 million in the first quarter of 2014 due to strong organic growth in auto and electronics sales offset by lower electrical sales and $0.7 million in unfavorable currency effects from sales denominated in Canadian dollars. Excluding currency effects, the Americas sales increased $8.6 million or 10%.

[0001437749-15-008576:mdna:31]
Europe sales decreased $5.0 million or 11% to $39.0 million in the first quarter of 2015 compared to $43.9 million in the first quarter of 2014 mainly due to $8.9 million in unfavorable currency effects reflecting a decline in the euro during the current year quarter. Excluding currency effects, Europe sales increased $4.0 million or 9% reflecting strong demand for automotive products.

[0001437749-15-008576:mdna:32]
Asia-Pacific sales increased $0.5 million or 1% to $74.3 million in the first quarter of 2015 compared to $73.8 million in the first quarter of 2014 due to strong demand for automotive and electrical products offset by unfavorable currency effects of $0.3 million. Excluding currency effects, Asia-Pacific sales increased $0.8 million or 1% year-over-year.

[0001437749-15-008576:mdna:33]
Gross profit was $76.3 million or 36% of net sales for the first quarter of 2015 compared to $78.5 million or 38% of net sales in the same quarter last year. Gross profit for 2015 includes $1.0 million related to the transfer of the company’s reed sensor products from the U.S. to the Philippines. Excluding the impact of the transfer, gross profit was 37% of net sales for the first quarter of 2015. Gross profit for 2014 includes the write-off of $1.4 million of stepped-up inventory valuation from the SymCom acquisition. Excluding the impact of the inventory write-off, gross profit was 39% of net sales for the first quarter of 2014. The decrease in gross profit margin compared to the prior year was primarily attributable to foreign exchange losses primarily due to the decline in the euro.

[0001437749-15-008576:mdna:34]
Total operating expense was $46.8 million or 22% of net sales for the first quarter of 2015 compared to $44.9 million or 22% of net sales for the same quarter in 2014. The increase in operating expenses primarily reflects higher wage and benefit costs, internal legal restructuring costs and costs related to the wind-up of the U.S. pension plan.

[0001437749-15-008576:mdna:35]
Operating income for the first quarter of 2015 was approximately $29.5 million compared to operating income of $33.6 million for the same quarter in 2014,primarily as a result of the negative impact of foreign exchange on sales and gross profit as discussed above.

[0001437749-15-008576:mdna:36]
Interest expense was $1.2 million in both the first quarter of 2015 and 2014 and reflects interest for borrowing on the company’s credit agreement.

[0001437749-15-008576:mdna:37]
Foreign exchange loss (gain), reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $3.1 million of expense for the first quarter of 2015 and $0.3 million of income for the first quarter of 2014 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar.

[0001437749-15-008576:mdna:38]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $1.1 million of income for first quarter of 2015 and $1.2 million for the first quarter of 2014.

[0001437749-15-008576:mdna:39]
Income before income taxes was $26.4 million for the first quarter of 2015 compared to $33.8 million for the first quarter of 2014. Income tax expense was $6.4 million with an effective tax rate of 24.3% for the first quarter of 2015 compared to income tax expense of $8.4 million with an effective tax rate of 24.9% in the first quarter of 2014. The effective tax rates for both the first quarter of 2015 and 2014 are lower than the U.S. statutory tax rate primarily due to more income earned in low tax jurisdictions.

[0001437749-15-008576:mdna:40]
Net income for the first quarter of 2015 was $20.0 million or $0.88 per diluted share compared to net income of $25.4 million or $1.12 per diluted share for the same quarter of 2014.

[0001437749-15-008576:mdna:41]
[same as prior period, unchanged from 0001437749-14-019177:mdna:59]

[0001437749-15-008576:mdna:42]
As of March 28, 2015, $282.5 million of the $293.6 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $282.5 million held by foreign subsidiaries, approximately $16.6 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $16.6 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-15-008576:mdna:43]
[same as prior period, unchanged from 0001437749-14-019177:mdna:62]

[0001437749-15-008576:mdna:44]
[same as prior period, unchanged from 0001437749-14-019177:mdna:63]

[0001437749-15-008576:mdna:45]
In 2013, the company entered into a credit agreement with J.P. Morgan Securities LLC for up to $325.0 million which consists of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The credit agreement is for a five year period.

[0001437749-15-008576:mdna:46]
On January 30, 2014, the company increased the unsecured revolving credit facility by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. At March 28, 2015, the company had available $194.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.18% as of March 28, 2015).

[0001437749-15-008576:mdna:47]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At March 28, 2015, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-15-008576:mdna:48]
The company also had $0.8 million outstanding in letters of credit at March 28, 2015. No amounts were drawn under these letters of credit at March 28, 2015.

[0001437749-15-008576:mdna:49]
Entrusted Loan

[0001437749-15-008576:mdna:50]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Net Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.

[0001437749-15-008576:mdna:51]
[same as prior period, unchanged from 0001437749-14-019177:mdna:67]

[0001437749-15-008576:mdna:52]
The company started 2015 with $297.6 million of cash and cash equivalents. Net cash provided by operating activities was approximately $23.2 million for the first three months of 2015 reflecting $20.0 million in net income and $11.7 million in non-cash adjustments (primarily $10.4 million in depreciation and amortization) offset by $8.4 million in net changes to various operating assets and liabilities.

[0001437749-15-008576:mdna:53]
Changes in operating assets and liabilities for the first three months of 2015 (including short-term and long-term items) that impacted cash flows negatively consisted of an increase in accounts receivable ($3.9 million), decreases in accounts payable ($3.0 million) and decreases in accrued payroll and severance ($8.9 million). The increase in accounts receivable was due to increased sales in the first quarter. The decrease in accrued payroll and severance was due primarily to payouts for the 2014 management incentive plan which occurred in the first quarter. Other changes having a positive impact on cash flows were increases in inventories ($0.1 million), prepaid and other assets ($3.6 million), accrued expenses ($2.7 million) and accrued taxes ($0.9 million).

[0001437749-15-008576:mdna:54]
Net cash used in investing activities was approximately $12.3 million and represented capital spending during the quarter.

[0001437749-15-008576:mdna:55]
Net cash used in financing activities was approximately $8.4 million and included $5.3 million in net payments on borrowings and dividends paid of $5.6 million partially offset by $2.4 million from the exercise of stock options including tax benefits. The effects of exchange rate changes decreased cash and cash equivalents by approximately $6.5 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $3.9 million decrease in cash, which left the company with a cash and cash equivalents balance of $293.6 million at March 28, 2015.

[0001437749-15-008576:mdna:56]
The ratio of current assets to current liabilities was 3.0 at the end of the first quarter of 2015 compared to 2.8 at year-end 2014 and 2.2 at the end of the first quarter of 2014. Days sales outstanding in accounts receivable was approximately 59 days at the end of the first quarter of 2015 compared to 60 days at the end of the first quarter of 2014 and 60 days at year-end 2014. Days inventory outstanding was approximately 65 days at the end of the first quarter of 2015 compared to 68 days at the year-end 2014 and 70 days at end of the first quarter of 2014.

[0001437749-15-008576:mdna:57]
[same as prior period, unchanged from 0001437749-14-019177:mdna:74]

[0001437749-15-008576:mdna:58]
Sales are expected to increase sequentially in the second quarter of 2015 due to normal seasonality and improving market conditions in the automotive and electronics segments. The mining sector is expected to remain weak at least through the remainder of this year. Foreign currency effects are expected to remain volatile. The company issued the following guidance for the second quarter of 2015:

[0001437749-15-008576:mdna:59]
|  | ● | Sales for the second quarter are expected to be in the range of $221 million to $231 million assuming a euro-dollar rate of 1.09. This represents 2% revenue growth at the midpoint compared to the prior year or approximately 7% growth excluding currency effects. |

[0001437749-15-008576:mdna:60]
|  | ● | Similar to the prior year, stock compensation expense for the second quarter is expected to be approximately $2 million higher than for the other quarters of the year due to accelerated expensing of options in the quarter granted for all those of retirement age (62 or older). |

[0001437749-15-008576:mdna:61]
|  | ● | The full year effective tax rate is expected to be approximately 23%, although this assumes that Congress approves the R&D tax credit and the “look-through” provision for 2015 as it did in 2014. Until such time, the rate is expected to be 50 to 100 basis points higher. |

[0001437749-15-008576:mdna:62]
|  | ● | Earnings (excluding special items) for the second quarter are expected to be in the range of $1.20 to $1.34 per diluted share. This includes negative currency effects of approximately $0.13 compared to the prior year. |

[0001437749-15-008576:mdna:63]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-15-008576:mdna:64]
The statements in this section and the other sections of this report that are not historical facts are intended to constitute “forward-looking statements” entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company’s accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company’s other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This report should be read in conjunction with information provided in the financial statements appearing in the company’s Annual Report on Form 10-K for the year ended December 27, 2014. For a further discussion of the risk factors of the company, please see Item 1A. “Risk Factors” to the company’s Annual Report on Form 10-K for the year ended December 27, 2014.
