# LFUS notes — 0001437749-15-008576


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-15-008576:notes:1]
2. Acquisition of Business

[0001437749-15-008576:notes:2]
[same as prior period, unchanged from 0001437749-14-019177:notes:3]

[0001437749-15-008576:notes:3]
On January 3, 2014, the company acquired 100% of SymCom, Inc. (“SymCom”) for $52.8 million net of cash acquired. Located in Rapid City, South Dakota, SymCom provides overload relays and pump controllers primarily to the industrial market. The acquisition allows the company to strengthen its position in the relay products market by adding new products and new customers within its Electrical business unit segment. The company funded the acquisition with available cash and proceeds from credit facilities.

[0001437749-15-008576:notes:4]
The following table sets forth the final purchase price allocation for SymCom acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values.

[0001437749-15-008576:notes:5]
| SymCom final purchase price allocation (in thousands): |  |
| Cash |  | $ | 325 |  |
| Current assets, net |  |  | 9,154 |  |
| Property, plant and equipment |  |  | 11,193 |  |
| Goodwill |  |  | 15,018 |  |
| Trademarks |  |  | 17,020 |  |
| Patents |  |  | 1,500 |  |
| Other non-current assets |  |  | 20 |  |
| Current liabilities |  |  | (1,137 | ) |
|  |  | $ | 53,093 |  |

[0001437749-15-008576:notes:6]
[same as prior period, unchanged from 0001437749-14-019177:notes:7]

[0001437749-15-008576:notes:7]
[same as prior period, unchanged from 0001437749-14-019177:notes:8]

[0001437749-15-008576:notes:8]
[same as prior period, unchanged from 0001437749-14-019177:notes:10]


## us-gaap:InventoryDisclosureTextBlock

[0001437749-15-008576:notes:9]
[same as prior period, unchanged from 0001437749-14-019177:notes:19]

[0001437749-15-008576:notes:10]
The components of inventories at March 28, 2015 and December 27, 2014 are as follows (in thousands):

[0001437749-15-008576:notes:11]
|  |  | March 28, 2015 |  |  | December 27, 2014 |  |
| Raw material |  | $ | 33,208 |  |  | $ | 29,756 |  |
| Work in process |  |  | 15,495 |  |  |  | 15,164 |  |
| Finished goods |  |  | 47,456 |  |  |  | 52,471 |  |
| Total inventories |  | $ | 96,159 |  |  | $ | 97,391 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0001437749-15-008576:notes:12]
[same as prior period, unchanged from 0001437749-14-019177:notes:22]

[0001437749-15-008576:notes:13]
The company’s other investments represent shares of Polytronics Technology Corporation Ltd. (“Polytronics”), a Taiwanese company. The Polytronics investment was acquired as part of the Heinrich Companies acquisition in 2004. The fair value of the Polytronics investment was €11.7 million (approximately $12.9 million) at March 28, 2015 and €9.9 million (approximately $12.1 million) at December 27, 2014. Included in 2015 other comprehensive income is an unrealized gain of $2.0 million, due to the increase in fair market value of the Polytronics investment. The remaining movement was due to the impact of changes in exchange rates.


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-008576:notes:14]
5. Debt

[0001437749-15-008576:notes:15]
The carrying amounts of debt at March 28, 2015 and December 27, 2014 are as follows (in thousands):

[0001437749-15-008576:notes:16]
|  |  | March 28, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 92,500 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 79,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 17,969 |  |  |  | 17,908 |  |
| Total debt |  |  | 189,969 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 87,000 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 102,969 |  |  | $ | 106,658 |  |

[0001437749-15-008576:notes:17]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of March 28, 2015, the company had available $194.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.18% as of March 28, 2015). At March 28, 2015, the company was in compliance with all covenants under the revolving credit facility.

[0001437749-15-008576:notes:18]
Entrusted Loan

[0001437749-15-008576:notes:19]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income
      will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-008576:notes:20]
6. Fair Value of Assets and Liabilities

[0001437749-15-008576:notes:21]
[same as prior period, unchanged from 0001437749-14-019177:notes:32]

[0001437749-15-008576:notes:22]
[same as prior period, unchanged from 0001437749-14-019177:notes:33]

[0001437749-15-008576:notes:23]
[same as prior period, unchanged from 0001437749-14-019177:notes:34]

[0001437749-15-008576:notes:24]
[same as prior period, unchanged from 0001437749-14-019177:notes:35]

[0001437749-15-008576:notes:25]
[same as prior period, unchanged from 0001437749-14-019177:notes:36]

[0001437749-15-008576:notes:26]
[same as prior period, unchanged from 0001437749-14-019177:notes:37]

[0001437749-15-008576:notes:27]
[same as prior period, unchanged from 0001437749-14-019177:notes:38]

[0001437749-15-008576:notes:28]
[same as prior period, unchanged from 0001437749-14-019177:notes:39]

[0001437749-15-008576:notes:29]
There were no changes during the quarter ended March 28, 2015 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of March 28, 2015 and December 27, 2014 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-15-008576:notes:30]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of March 28, 2015 (in thousands):

[0001437749-15-008576:notes:31]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 12,862 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,862 |  |
| Total |  | $ | 12,862 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,862 |  |

[0001437749-15-008576:notes:32]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 27, 2014 (in thousands):

[0001437749-15-008576:notes:33]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |
| Total |  | $ | 12,056 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,056 |  |

[0001437749-15-008576:notes:34]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt. The carrying amounts of cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt approximate their fair values. The company’s debt fair value approximates book value at March 28, 2015 and December 27, 2014, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-008576:notes:35]
7. Earnings per Share

[0001437749-15-008576:notes:36]
The following table sets forth the computation of basic and diluted earnings per share of March 28, 2015 and March 29, 2014 (in thousands except per share amounts).

[0001437749-15-008576:notes:37]
|  |  | For the Three Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Net income |  | $ | 19,995 |  |  | $ | 25,389 |  |
| Average shares outstanding - Basic |  |  | 22,600 |  |  |  | 22,492 |  |
| Net effect of dilutive stock options and restricted share units |  |  | 181 |  |  |  | 225 |  |
| Average shares - Diluted |  |  | 22,781 |  |  |  | 22,717 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.88 |  |  | $ | 1.13 |  |
| Diluted |  | $ | 0.88 |  |  | $ | 1.12 |  |

[0001437749-15-008576:notes:38]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 64,520 and 0 for the three months ended March 28, 2015 and March 29, 2014, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-008576:notes:39]
8. Income Taxes

[0001437749-15-008576:notes:40]
The effective tax rate for the first quarter of 2015 was 24.3% compared to an effective tax rate of 24.9% in the first quarter of 2014. The effective tax rates for both 2015 and 2014 are lower than the U.S. statutory tax rate primarily due to the result of more income earned in low tax jurisdictions.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-15-008576:notes:41]
9. Pensions

[0001437749-15-008576:notes:42]
The components of net periodic benefit cost for the three months ended March 28, 2015, compared with the three months ended March 29, 2014, were (in thousands):

[0001437749-15-008576:notes:43]
|  |  | U.S. Plans |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |  | March 28, 2015 |  |  | March 29 2014 |  |
| Service cost |  | $ | 250 |  |  | $ | 150 |  |  | $ | 315 |  |  | $ | 311 |  |
| Interest cost |  |  | 1,031 |  |  |  | 971 |  |  |  | 513 |  |  |  | 591 |  |
| Expected return on plan assets |  |  | (916 | ) |  |  | (1,411 | ) |  |  | (600 | ) |  |  | (573 | ) |
| Amortization of net loss |  |  | 290 |  |  |  | 137 |  |  |  | 61 |  |  |  | 48 |  |
| Total cost of the plan |  |  | 655 |  |  |  | (153 | ) |  |  | 289 |  |  |  | 377 |  |
| Expected plan participants’contribution |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net periodic benefit cost |  | $ | 655 |  |  | $ | (153 | ) |  | $ | 289 |  |  | $ | 377 |  |

[0001437749-15-008576:notes:44]
The expected rate of return assumption on domestic pension assets is 3.90% and 6.75% in 2015 and 2014, respectively. The expected return on foreign pension assets is 5.39% and 5.14% in 2015 and 2014, respectively.

[0001437749-15-008576:notes:45]
Plan Termination

[0001437749-15-008576:notes:46]
The company received approval from the IRS on April 14, 2015 on its Application for Determination for Terminating Plan to terminate the U.S. defined benefit pension plan, the Littelfuse Inc. Retirement Plan, effective January 1, 2015. The current liability balance of $11.8 million at March 28, 2015, represents the projected cost to settle the plan’s liability in conjunction with the upcoming plan termination. Settlement is expected to occur during the third quarter of 2015.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-008576:notes:47]
10. Business Unit Segment Information

[0001437749-15-008576:notes:48]
[same as prior period, unchanged from 0001437749-14-019177:notes:59]

[0001437749-15-008576:notes:49]
[same as prior period, unchanged from 0001437749-14-019177:notes:60]

[0001437749-15-008576:notes:50]
[same as prior period, unchanged from 0001437749-14-019177:notes:61]

[0001437749-15-008576:notes:51]
Business unit segment information for the three months ended March 28, 2015 and March 29, 2014 are summarized as follows (in thousands):

[0001437749-15-008576:notes:52]
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 99,380 |  |  | $ | 95,722 |  |
| Automotive |  |  | 84,071 |  |  |  | 82,419 |  |
| Electrical |  |  | 26,862 |  |  |  | 28,718 |  |
| Total net sales |  | $ | 210,313 |  |  | $ | 206,859 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 5,798 |  |  | $ | 5,370 |  |
| Automotive |  |  | 3,336 |  |  |  | 3,528 |  |
| Electrical |  |  | 1,284 |  |  |  | 1,268 |  |
| Total depreciation and amortization |  | $ | 10,418 |  |  | $ | 10,166 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 18,665 |  |  | $ | 19,068 |  |
| Automotive |  |  | 11,171 |  |  |  | 11,899 |  |
| Electrical |  |  | 2,730 |  |  |  | 4,032 |  |
| Other (1) |  |  | (3,018 | ) |  |  | (1,409 | ) |
| Total operating income |  |  | 29,548 |  |  |  | 33,590 |  |
| Interest expense |  |  | 1,151 |  |  |  | 1,216 |  |
| Foreign exchange loss (gain) |  |  | 3,117 |  |  |  | (252 | ) |
| Other (income) expense, net |  |  | (1,126 | ) |  |  | (1,186 | ) |
| Income before income taxes |  | $ | 26,406 |  |  | $ | 33,812 |  |

[0001437749-15-008576:notes:53]
(1) “Other” consists of restructuring costs ($2.2 million), acquisition expenses ($0.2 million) and pension wind-up costs ($0.7 million).

[0001437749-15-008576:notes:54]
The company’s significant net sales by country for the three months ended March 28, 2015 and March 29, 2014 are summarized as follows (in thousands):

[0001437749-15-008576:notes:55]
|  |  | Net sales(a) |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| United States |  | $ | 83,373 |  |  | $ | 71,874 |  |
| China |  |  | 44,429 |  |  |  | 37,213 |  |
| Other countries |  |  | 82,511 |  |  |  | 97,772 |  |
| Total |  | $ | 210,313 |  |  | $ | 206,859 |  |

[0001437749-15-008576:notes:56]
[same as prior period, unchanged from 0001437749-14-019177:notes:67]

[0001437749-15-008576:notes:57]
The company’s significant long-lived assets and additions to long-lived assets by country as of March 28, 2015 and December 27, 2014 are summarized as follows (in thousands):

[0001437749-15-008576:notes:58]
|  |  | Long-lived assets(b) |  |
|  |  | March 28, 2015 |  |  | December 27, 2014 |  |
| United States |  | $ | 35,641 |  |  | $ | 34,179 |  |
| China |  |  | 39,321 |  |  |  | 40,981 |  |
| Canada |  |  | 12,160 |  |  |  | 12,899 |  |
| Other countries |  |  | 73,750 |  |  |  | 70,581 |  |
| Total |  | $ | 160,872 |  |  | $ | 158,640 |  |

[0001437749-15-008576:notes:59]
(b) Long-lived assets consists of net property, plant and equipment.

[0001437749-15-008576:notes:60]
|  |  | Additions to long-lived assets |  |
|  |  | March 28, 2015 |  |  | March 29, 2014 |  |
| United States |  | $ | 3,187 |  |  | $ | 1,625 |  |
| China |  |  | 667 |  |  |  | 685 |  |
| Canada |  |  | 538 |  |  |  | 145 |  |
| Other countries |  |  | 7,887 |  |  |  | 3,968 |  |
| Total |  | $ | 12,279 |  |  | $ | 6,423 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-15-008576:notes:61]
11. Accumulated Other Comprehensive Income (Loss) (AOCI)

[0001437749-15-008576:notes:62]
[same as prior period, unchanged from 0001437749-14-019177:notes:72]

[0001437749-15-008576:notes:63]
| AOCI component |  | Balance at December 27, 2014 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Balance at March 28, 2015 |  |
| Pension liability adjustment(a) |  | $ | (29,615 | ) |  | $ | 74 |  |  | $ | 986 |  |  | $ | (28,555 | ) |
| Unrealized gain on investments(b) |  |  | 10,791 |  |  |  | 1,956 |  |  |  | — |  |  |  | 12,747 |  |
| Foreign currency translation adjustment |  |  | (2,302 | ) |  |  | (13,974 | ) |  |  | — |  |  |  | (16,276 | ) |
| AOCI (loss) income |  | $ | (21,126 | ) |  | $ | (11,944 | ) |  | $ | 986 |  |  | $ | (32,084 | ) |

[0001437749-15-008576:notes:64]
(a) Balances are net of tax of $12,397 and $12,857 for 2015 and 2014, respectively.

[0001437749-15-008576:notes:65]
(b) Balances are net of tax of $0 and $0 for 2015 and 2014, respectively.
