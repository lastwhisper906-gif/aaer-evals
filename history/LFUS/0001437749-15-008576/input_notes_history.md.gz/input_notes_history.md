# LFUS note change history — 0001437749-14-019177 → 0001437749-15-008576


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-01):
[0001437749-15-008576:note_history:1]
The carrying amounts of debt at March 28, 2015 and December 27, 2014 are as follows (in thousands):
  (was, 2014-10-31, similarity 0.8958):
[0001437749-14-019177:note_history:1]
The carrying amounts of long-term debt at September 27, 2014 and December 28, 2013 are as follows (in thousands):

- changed (2015-05-01):
[0001437749-15-008576:note_history:2]
|  |  | March 28, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 92,500 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 79,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 17,969 |  |  |  | 17,908 |  |
| Total debt |  |  | 189,969 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 87,000 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 102,969 |  |  | $ | 106,658 |  |
  (was, 2014-10-31, similarity 0.9055):
[0001437749-14-019177:note_history:2]
|  |  | September 27, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 95,000 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 181,500 |  |  |  | 121,000 |  |
| Total debt |  |  | 276,500 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 186,500 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 90,000 |  |  | $ | 93,750 |  |

- changed (2015-05-01):
[0001437749-15-008576:note_history:3]
The company currently has a credit agreement with J.P Morgan Securities LLC for up to $375.0 million which consists of an unsecured revolving credit facility of $275.0 million and an unsecured term loan of $100.0 million. The credit agreement, effective May 31, 2013, is for a five year period. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of March 28, 2015, the company had available $194.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.0% (1.18% as of March 28, 2015). At March 28, 2015, the company was in compliance with all covenants under the revolving credit facility.
  (was, 2014-10-31, similarity 0.7072):
[0001437749-14-019177:note_history:3]
On May 31, 2013, the company entered into a new credit agreement with J.P Morgan Securities LLC for up to $325.0 million which consisted of an unsecured revolving credit facility of $225.0 million and an unsecured term loan of $100.0 million. The new credit agreement is for a five year period. On January 30, 2014, the company increased the unsecured revolving credit facility entered into on May 31, 2013, by $50.0 million thereby increasing the total revolver borrowing capacity from $225.0 million to $275.0 million. The company incurred debt issuance costs of $0.1 million which will be amortized over the life of the existing credit agreement. As of September 27, 2014, the company had available $92.9 million of borrowing capacity under the revolving credit agreement at an interest rate of LIBOR plus 1.50% (1.65% as of September 27, 2014). At September 27, 2014, the company was in compliance with all covenants under the revolving credit facility.

- added (2015-05-01):
[0001437749-15-008576:note_history:4]
Entrusted Loan

- added (2015-05-01):
[0001437749-15-008576:note_history:5]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “Lender”) and Suzhou Littelfuse OVS Ltd. (the “Borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities is strictly forbidden under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income
      will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-01):
[0001437749-15-008576:note_history:6]
|  |  | March 28, 2015 |  |  | December 27, 2014 |  |
| Term loan |  | $ | 92,500 |  |  | $ | 93,750 |  |
| Revolving credit facility |  |  | 79,500 |  |  |  | 83,500 |  |
| Entrusted loan |  |  | 17,969 |  |  |  | 17,908 |  |
| Total debt |  |  | 189,969 |  |  |  | 195,158 |  |
| Less: Current maturities |  |  | 87,000 |  |  |  | 88,500 |  |
| Total long-term debt |  | $ | 102,969 |  |  | $ | 106,658 |  |
  (was, 2014-10-31, similarity 0.9055):
[0001437749-14-019177:note_history:6]
|  |  | September 27, 2014 |  |  | December 28, 2013 |  |
| Term loan |  | $ | 95,000 |  |  | $ | 98,750 |  |
| Revolving credit facility |  |  | 181,500 |  |  |  | 121,000 |  |
| Total debt |  |  | 276,500 |  |  |  | 219,750 |  |
| Less: Current maturities |  |  | 186,500 |  |  |  | 126,000 |  |
| Total long-term debt |  | $ | 90,000 |  |  | $ | 93,750 |  |
