# LFUS note change history — 0001437749-16-031011 → 0001437749-16-036614


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-08-05):
[0001437749-16-036614:note_history:1]
7

- changed (2016-08-05):
[0001437749-16-036614:note_history:2]
. Debt
  (was, 2016-05-06, similarity 0.8333):
[0001437749-16-031011:note_history:2]
6. Debt

- changed (2016-08-05):
[0001437749-16-036614:note_history:3]
The carrying amounts of debt at July 2, 2016 and January 2, 2016 are as follows (in thousands):
  (was, 2016-05-06, similarity 0.96):
[0001437749-16-031011:note_history:3]
The carrying amounts of debt at April 2, 2016 and January 2, 2016 are as follows (in thousands):

- changed (2016-08-05):
[0001437749-16-036614:note_history:4]
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 237,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 123,438 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,256 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,212 | ) |  |  | (721 | ) |
| Total debt |  |  | 367,982 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 361,732 |  |  | $ | 83,753 |  |
  (was, 2016-05-06, similarity 0.9874):
[0001437749-16-031011:note_history:4]
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 244,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 125,000 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,536 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (1,673 | ) |  |  | (721 | ) |
| Total debt |  |  | 377,363 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 371,113 |  |  | $ | 83,753 |  |

- changed (2016-08-05):
[0001437749-16-036614:note_history:5]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of July 2, 2016, the company had
  (was, 2016-05-06, similarity 0.75):
[0001437749-16-031011:note_history:5]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of April 2, 2016, the company had available $330.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (1.94% as of April 2, 2016). At April 2, 2016, the company was in compliance with all covenants under the revolving credit facility.

- added (2016-08-05):
[0001437749-16-036614:note_history:6]
had $0.1 million outstanding in letters of credit and had available $337.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (1.97% as of July 2, 2016). At July 2, 2016, the company was in compliance with all covenants under the credit agreement

- added (2016-08-05):
[0001437749-16-036614:note_history:7]
.

- changed (2016-08-05):
[0001437749-16-036614:note_history:8]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.3 million) at July 2, 2016.
  (was, 2016-05-06, similarity 0.9784):
[0001437749-16-031011:note_history:8]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million at that time) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “
Lender
”) and Suzhou Littelfuse OVS Ltd. (the “
Borrower
”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.5 million) at April 2, 2016.

- changed (2016-08-05):
[0001437749-16-036614:note_history:9]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement.
  (was, 2016-05-06, similarity 0.7797):
[0001437749-16-031011:note_history:9]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which will be amortized over the life of the new credit agreement.

- added (2016-08-05):
[0001437749-16-036614:note_history:10]
This new credit agreement

- added (2016-08-05):
[0001437749-16-036614:note_history:11]
was determined to be a modification under ASC 470-50 of the previous credit agreement

- added (2016-08-05):
[0001437749-16-036614:note_history:12]
.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001437749-16-036614:note_history:13]
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 237,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 123,438 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,256 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,212 | ) |  |  | (721 | ) |
| Total debt |  |  | 367,982 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 361,732 |  |  | $ | 83,753 |  |
  (was, 2016-05-06, similarity 0.9874):
[0001437749-16-031011:note_history:13]
|  |  | April 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 244,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 125,000 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,536 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (1,673 | ) |  |  | (721 | ) |
| Total debt |  |  | 377,363 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 371,113 |  |  | $ | 83,753 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-08-05):
[0001437749-16-036614:note_history:14]
5

- changed (2016-08-05):
[0001437749-16-036614:note_history:15]
. Subsequent
  (was, 2016-05-06, similarity 0.7333):
[0001437749-16-031011:note_history:15]
) Subsequent Event

- added (2016-08-05):
[0001437749-16-036614:note_history:16]
E

- added (2016-08-05):
[0001437749-16-036614:note_history:17]
vent

- added (2016-08-05):
[0001437749-16-036614:note_history:18]
None.

- removed (2016-08-05):
[0001437749-16-031011:note_history:19]
On April 4, 2016, the company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy. The purchase price of €16.7 million

- removed (2016-08-05):
[0001437749-16-031011:note_history:20]
($19.0 million) is subject to a working capital adjustment and was financed through a mixture of cash on hand and borrowings under the company's credit facility. The acquired business, which will be part of the company's Automotive segment, specializes in the design, manufacturing and selling of manual and electrical battery switches and trailer connectors for commercial vehicles. Menber’s had sales of approximately $23.0 million in 2015.

- removed (2016-08-05):
[0001437749-16-031011:note_history:21]
The initial accounting for the acquisition is not complete pending detailed analyses of the facts and circumstances that existed as of the acquisition date.
