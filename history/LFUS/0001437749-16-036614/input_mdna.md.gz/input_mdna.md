# LFUS MD&A — 0001437749-16-036614


## mdna

[0001437749-16-036614:mdna:1]
[same as prior period, unchanged from 0001437749-16-031011:mdna:1]

[0001437749-16-036614:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0001437749-16-036614:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations,  should be read in conjunction with information provided in the financial statements and the related Notes thereto appearing in the company's Annual Report on Form 10-K for the year ended January 2, 2016.

[0001437749-16-036614:mdna:4]
[same as prior period, unchanged from 0001437749-16-031011:mdna:2]

[0001437749-16-036614:mdna:5]
[same as prior period, unchanged from 0001437749-16-031011:mdna:3]

[0001437749-16-036614:mdna:6]
[same as prior period, unchanged from 0001437749-16-031011:mdna:4]

[0001437749-16-036614:mdna:7]
[same as prior period, unchanged from 0001437749-16-031011:mdna:5]

[0001437749-16-036614:mdna:8]
[same as prior period, unchanged from 0001437749-16-031011:mdna:6]

[0001437749-16-036614:mdna:9]
[same as prior period, unchanged from 0001437749-16-031011:mdna:7]

[0001437749-16-036614:mdna:10]
[same as prior period, unchanged from 0001437749-16-031011:mdna:8]

[0001437749-16-036614:mdna:11]
[same as prior period, unchanged from 0001437749-16-031011:mdna:9]

[0001437749-16-036614:mdna:12]
[same as prior period, unchanged from 0001437749-16-031011:mdna:10]

[0001437749-16-036614:mdna:13]
[same as prior period, unchanged from 0001437749-16-031011:mdna:11]

[0001437749-16-036614:mdna:14]
[same as prior period, unchanged from 0001437749-16-031011:mdna:12]

[0001437749-16-036614:mdna:15]
The Electronics segment sells passive and semiconductor components and modules as well as sensors primarily into the global consumer electronics, general industrial and telecommunications markets. The core electronics markets are characterized by significant Asia-Pacific competition and price erosion. As a result the company is focusing additional efforts on higher growth, less price sensitive niche markets (such as LED lighting) and higher-power industrial applications. The PolySwitch business acquisition in 2016 has expanded the company’s product offering used in a wide variety of electronic products and utilizes many of the same distribution channels as the company’s legacy electronics products.

[0001437749-16-036614:mdna:16]
[same as prior period, unchanged from 0001437749-16-031011:mdna:14]

[0001437749-16-036614:mdna:17]
The Automotive segment is comprised of passenger vehicle circuit protection, commercial vehicle products and sensors. The primary growth drivers for these businesses are increasing global demand for passenger and commercial vehicles and increasing content per vehicle for both circuit protection and sensing products. The move away from internal combustion engines to hybrid and electric drive systems that require more circuit protection continues to be an additional growth driver. The PolySwitch business acquisition in 2016 has added to the company’s strong global presence in the automotive market. The acquisition of Menber’s further strengthens the company’s position in electrical battery switches and connectors for the commercial vehicle market.

[0001437749-16-036614:mdna:18]
[same as prior period, unchanged from 0001437749-16-031011:mdna:16]

[0001437749-16-036614:mdna:19]
The Industrial segment derives its revenues from power fuses, protection relays and custom products selling primarily into the industrial, mining, solar and oil and gas markets. Protection relay sales have declined due to the general slowdown in the global mining and oil and gas markets. Custom products sales have declined over the past two years due to continued end market softness in the potash mining market. The potash market has recently experienced a steep decline in market pricing. Goodwill associated with the custom products reporting unit is approximately $9 million. As of the most recent annual goodwill impairment test conducted on September 27, 2015, the fair value of custom products reporting unit exceeded its carrying value by 12%. Due to recent negative events in the potash market subsequent to the company’s quarter end, the company conducted a step one goodwill impairment analysis for the custom products reporting unit as of July 2, 2016 to determine if goodwill was impaired at this date. The fair value of this reporting unit at this date exceeded its carrying value by less than 10%.  If there is a continued future decline in the custom products reporting unit and its fair value falls below its carrying value, the goodwill may be impaired.

[0001437749-16-036614:mdna:20]
[same as prior period, unchanged from 0001437749-16-031011:mdna:18]

[0001437749-16-036614:mdna:21]
[same as prior period, unchanged from 0001437749-16-031011:mdna:19]

[0001437749-16-036614:mdna:22]
|  |  | Second Quarter |  |  | First Six Months |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Business Unit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 132,170 |  |  | $ | 105,553 |  |  |  | 25% |  |  | $ | 230,966 |  |  | $ | 204,933 |  |  |  | 13% |  |
| Automotive |  |  | 111,370 |  |  |  | 85,918 |  |  |  | 30% |  |  |  | 203,303 |  |  |  | 169,989 |  |  |  | 20% |  |
| Industrial |  |  | 28,372 |  |  |  | 30,550 |  |  |  | (7%) |  |  |  | 57,041 |  |  |  | 57,412 |  |  |  | (1%) |  |
| Total |  | $ | 271,912 |  |  | $ | 222,021 |  |  |  | 22% |  |  | $ | 491,310 |  |  | $ | 432,334 |  |  |  | 14% |  |
| Geography(a) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 107,297 |  |  | $ | 103,033 |  |  |  | 4% |  |  | $ | 207,120 |  |  | $ | 200,087 |  |  |  | 4% |  |
| Europe |  |  | 54,406 |  |  |  | 39,125 |  |  |  | 39% |  |  |  | 97,219 |  |  |  | 78,093 |  |  |  | 24% |  |
| Asia-Pacific |  |  | 110,209 |  |  |  | 79,863 |  |  |  | 38% |  |  |  | 186,971 |  |  |  | 154,154 |  |  |  | 21% |  |
| Total |  | $ | 271,912 |  |  | $ | 222,021 |  |  |  | 22% |  |  | $ | 491,310 |  |  | $ | 432,334 |  |  |  | 14% |  |

[0001437749-16-036614:mdna:23]
[same as prior period, unchanged from 0001437749-16-031011:mdna:22]

[0001437749-16-036614:mdna:24]
The following table summarizes the company’s consolidated results of operations for the periods presented. The second quarter of 2016 includes approximately $14.1 million of additional special charges ($23.2 million year-to-date). These included $6.1 million ($12.3 million year-to-date) of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, a $6.9 million ($6.9 million year-to-date) non-cash inventory charge relating to the PolySwitch acquisition as described in Note 4, $0.3 million ($1.9 million year-to-date) in charges related to the closure of the company’s manufacturing facility in Denmark, $0.7 million ($1.7 million year-to-date) related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.1 million ($0.4 million year-to-date) related to internal legal restructuring costs.

[0001437749-16-036614:mdna:25]
18

[0001437749-16-036614:mdna:26]
The second quarter of 2015 includes approximately $3.4 million of special charges ($6.4 million year-to-date) consisting of $0.9 million ($1.9 million year-to-date) related to the company’s transfer of its reed sensor manufacturing from the U.S. to the Philippines, $1.7 million ($2.9 million year-to-date) related to internal legal restructuring, $0.2 million ($0.3 million year-to-date) related to acquisition costs and $0.7 million ($1.3 million year-to-date) of expense related to the planned termination of the U.S. pension as described in Note 11.

[0001437749-16-036614:mdna:27]
| (In thousands, unaudited) |  | Second Quarter |  |  | First Six Months |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Sales |  | $ | 271,912 |  |  | $ | 222,021 |  |  |  | 22 | % |  | $ | 491,310 |  |  | $ | 432,334 |  |  |  | 14 | % |
| Gross Profit |  |  | 97,866 |  |  |  | 85,281 |  |  |  | 15 | % |  |  | 185,021 |  |  |  | 161,611 |  |  |  | 14 | % |
| Operating expense |  |  | 68,164 |  |  |  | 49,110 |  |  |  | 39 | % |  |  | 122,891 |  |  |  | 95,892 |  |  |  | 28 | % |
| Operating income |  |  | 29,702 |  |  |  | 36,171 |  |  |  | (18 | %) |  |  | 62,130 |  |  |  | 65,719 |  |  |  | (5 | %) |
| Interest expense |  |  | 1,670 |  |  |  | 948 |  |  |  | 76 | % |  |  | 3,715 |  |  |  | 2,099 |  |  |  | 77 | % |
| Foreign exchange (gain) loss |  |  | (6,237 | ) |  |  | (1,292 | ) |  |  | 383 | % |  |  | (2,414 | ) |  |  | 1,825 |  |  |  | (232 | %) |
| Other (income) expense, net |  |  | 255 |  |  |  | (1,202 | ) |  |  | (121 | %) |  |  | (262 | ) |  |  | (2,328 | ) |  |  | (89 | %) |
| Income before income taxes |  |  | 34,014 |  |  |  | 37,717 |  |  |  | (10 | %) |  |  | 61,091 |  |  |  | 64,123 |  |  |  | (5 | %) |
| Net income |  | $ | 27,152 |  |  | $ | 28,684 |  |  |  | (5 | %) |  | $ | 46,441 |  |  | $ | 48,679 |  |  |  | (5 | %) |

[0001437749-16-036614:mdna:28]
Results of Operations – Second Quarter, 2016 compared to 2015

[0001437749-16-036614:mdna:29]
Net sales for the second quarter of 2016 were $271.9 million, a 22% increase compared to the prior year quarter. Excluding PolySwitch revenue of $36.4 million, net sales increased $13.5 million, or 6%, primarily due to strong organic growth in the Automotive segment and to a lesser extent organic growth in the Electronics segment, partially offset by lower sales from the Industrial segment.

[0001437749-16-036614:mdna:30]
Electronics sales increased $26.6 million, or 25%, compared to the prior year quarter. Excluding PolySwitch, sales increased $2.4 million, or 2%, to $107.9 million in the second quarter of 2016 compared to $105.6 million in the second quarter of 2015 primarily reflecting growth in sensor and passive products, partially offset by lower semiconductor sales. This segment continues to leverage the company’s technology expertise to design its products into a broad variety of end markets and market segments.

[0001437749-16-036614:mdna:31]
Automotive sales increased $25.5 million, or 30%, compared to the prior year quarter. Excluding PolySwitch, sales increased $13.3 million, or 15%, to $99.2 million in the second quarter of 2016 compared to $85.9 million in the second quarter of 2015 reflecting the recent acquisitions of Menber’s and Sigmar as well as organic growth in sensor and passenger car products. These increases in sales were partially offset by lower sales of legacy commercial vehicle products, reflecting weakness in the North American heavy truck, construction and agricultural end markets. The company expects flat to declining automotive sensor revenue in the second half of 2016 as it exits certain low margin legacy business.

[0001437749-16-036614:mdna:32]
Industrial sales decreased $2.2 million, or 7%, to $28.4 million in the second quarter of 2016 compared to $30.6 million in the second quarter of 2015 primarily reflecting lower relay sales, and to a lesser extent, fuse sales. The company’s fuse business has benefited from a strong U.S. solar market for a number of years, however this market slowed in the second quarter of 2016. As the U.S. Congress extended solar energy related tax credits late in 2015, many solar original equipment manufacturers pushed out projects to focus on scale and efficiencies. Sales in both the protection relay and custom products businesses continued to be impacted by weakness in the heavy industrial markets, particularly mining, and oil and gas, as those customers restrict their capital spending. In the custom products business, the company continues to see a decline in its potash market, The steep decline in potash pricing has led to further slow-downs and delays in investments by customers.

[0001437749-16-036614:mdna:33]
On a geographic basis, sales in the Americas increased $4.3 million, or 4%, to $107.3 million in the second quarter of 2016 compared to $103.0 million in the second quarter of 2015 primarily reflecting the addition of the PolySwitch business in the current year and, to a lesser extent, increased Automotive segment sales, partially offset by lower Industrial segment sales and $0.1 million in unfavorable currency effects from sales denominated in Canadian dollars.

[0001437749-16-036614:mdna:34]
Europe sales increased $15.3 million, or 39%, to $54.4 million in the second quarter of 2016 compared to $39.1 million in the second quarter of 2015 primarily due to strong sales of automotive products, the addition of the PolySwitch business in the current year, increased electronic sales and $0.8 million in favorable currency effects primarily from sales denominated in euro. Excluding currency effects, Europe sales increased $14.4 million, or 37%, year-over-year.

[0001437749-16-036614:mdna:35]
Asia-Pacific sales increased $30.3 million, or 38%, to $110.2 million in the second quarter of 2016 compared to $79.9 million in the second quarter of 2015 primarily reflecting the addition of the PolySwitch business in the current year and increased demand for electronics and automotive products, partially offset by unfavorable currency effects of $1.4 million. Excluding currency effects, Asia-Pacific sales increased $31.8 million, or 40%, year-over-year.

[0001437749-16-036614:mdna:36]
Gross profit was $97.9 million, or 36% of net sales, for the second quarter of 2016 compared to $85.3 million, or 38% of net sales, in the same quarter last year. Gross profit for 2016 includes a $6.9 million inventory adjustment relating to the PolySwitch acquisition, $0.9 million of acquisition-related costs primarily related to integration costs associated with the company’s acquisition of the PolySwitch business, $0.5 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines and $0.3 million in charges related to the closure of the company’s manufacturing facility in Denmark. Gross profit for 2015 included $0.9 million related to the reed switch production transfer. Excluding the impact of these charges, gross profit was $106.4 million, or 39% of net sales, for the second quarter of 2016 compared to $86.2 million, or 39% of net sales, in the second quarter of 2015.

[0001437749-16-036614:mdna:37]
Total operating expense was $68.2 million, or 25% of net sales, for the second quarter of 2016 compared to $49.1 million, or 22% of net sales, for the same quarter in 2015. Operating expense in 2016 included $5.2 million of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, $0.2 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines and $0.1 million related to internal legal restructuring costs. Operating expense in 2015 included $1.7 million related to internal legal restructuring, $0.2 million related to acquisition costs and $0.7 million of expense related to the planned termination of the U.S. pension. Excluding these charges, total operating expense was $62.7 million, or 23% of net sales, for 2016 compared to $46.6 million, or 21% of net sales, in 2015, partially reflecting increased research and development expenses in the current year quarter as compared to the prior year quarter and incremental amortization of intangible assets associated with recent acquisitions.

[0001437749-16-036614:mdna:38]
Due to the reasons noted above, operating income for the second quarter of 2016 was approximately $29.7 million compared to operating income of $36.2 million for the same quarter in 2015.

[0001437749-16-036614:mdna:39]
Interest expense was $1.7 million in the second quarter of 2016 as compared to $0.9 million in the second quarter of 2015, primarily reflecting higher borrowings relating to the March 2016 acquisition of the PolySwitch business.

[0001437749-16-036614:mdna:40]
Foreign exchange (gain) loss, reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $6.2 million of income for the second quarter of 2016 and $1.3 million of income for the second quarter of 2015 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar and the euro against the Japanese yen.

[0001437749-16-036614:mdna:41]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $0.3 million of expense for second quarter of 2016 and $1.2 million of income for the second quarter of 2015. The quarter over quarter decline primarily reflects lower interest income in the current year quarter due to cash used for the acquisition of the PolySwitch business in March 2016.

[0001437749-16-036614:mdna:42]
Income before income taxes was $34.0 million for the second quarter of 2016 compared to $37.7 million for the second quarter of 2015. Income tax expense was $6.9 million with an effective tax rate of 20.2% for the second quarter of 2016 compared to income tax expense of $9.0 million with an effective tax rate of 23.9% in the second quarter of 2015. The effective tax rates for both the second quarter of 2016 and 2015 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0001437749-16-036614:mdna:43]
Net income for the second quarter of 2016 was $27.2 million or $1.20 per diluted share compared to net income of $28.7 million or $1.26 per diluted share for the same quarter of 2015.

[0001437749-16-036614:mdna:44]
Results of Operations – Six Months, 2016 compared to 2015

[0001437749-16-036614:mdna:45]
Net sales for the first six months of 2016 were $491.3 million, a 14% increase compared to the prior year period. Excluding PolySwitch revenue of $36.4 million, net sales increased $22.6 million, or 5%, primarily due to strong organic growth in the Automotive segment and to a lesser extent organic growth in the Electronics segment.

[0001437749-16-036614:mdna:46]
Electronics sales increased $26.0 million, or 13%, compared to the prior year period. Excluding PolySwitch, sales increased $1.8 million, or 1%, to $206.7 million in the first six months of 2016 compared to $204.9 million in the first six months of 2015, primarily reflecting growth in sensor and passive products, partially offset by lower semiconductor sales. The Electronics segment experienced $1.6 million in unfavorable currency effects in the first six months of 2016 primarily from sales denominated in the renminbi and, to a lesser extent, sales denominated in the Korean won. Excluding currency effects, Net sales excluding PolySwitch, increased $3.4 million, or 2%, year-over-year. This segment continues to leverage the company’s technology expertise to design its products into a broad variety of end markets and market segments.

[0001437749-16-036614:mdna:47]
Automotive sales increased $33.3 million, or 20%, compared to the prior year period. Excluding PolySwitch, Automotive sales increased $21.1 million, or 12%, to $191.1 million in the first six months of 2016 compared to $170.0 million in the first six months of 2015 reflecting the recent acquisitions of Menber’s and Sigmar as well as organic growth in sensor and passenger car products. These increases in sales were partially offset by lower sales of legacy commercial vehicle products, reflecting weakness in the North American heavy truck, construction and agricultural end markets. The company expects flat to declining automotive sensor revenue in the second half of 2016 as it exits certain low margin legacy business. The Automotive segment experienced $1.9 million in unfavorable currency effects in the first six months of 2016 primarily from sales denominated in the renminbi. Excluding currency effects, net sales increased $23.0 million, or 14%, year-over-year.

[0001437749-16-036614:mdna:48]
Industrial sales decreased $0.4 million, or 1%, to $57.0 million in the first six months of 2016 compared to $57.4 million in the first six months of 2015 primarily reflecting lower relay sales, partially offset by increased custom sales. The company’s fuse business has benefited from a strong U.S. solar market for a number of years, however this market slowed in the second quarter of 2016. As the U.S. Congress extended solar energy related tax credits late in 2015, many solar original equipment manufacturers pushed out projects to focus on scale and efficiencies. Sales in both the protection relay and custom products businesses continued to be impacted by weakness in the heavy industrial markets, particularly mining, and oil and gas, as those customers restrict their capital spending. In the custom products business, the company continues to see a decline in its potash market, The steep decline in potash pricing has led to further slow-downs and delays in investments by customers.

[0001437749-16-036614:mdna:49]
On a geographic basis, sales in the Americas increased $7.0 million, or 4%, to $207.1 million in the first six months of 2016 compared to $200.1 million in the first six months of 2015 primarily reflecting the addition of the PolySwitch business in the current year and increased automotive segment sales and $0.8 million in unfavorable currency effects from sales denominated in Canadian dollars.

[0001437749-16-036614:mdna:50]
Europe sales increased $19.1 million, or 25%, to $97.2 million in the first six months of 2016 compared to $78.1 million in the first six months of 2015 primarily due to strong sales of automotive products, the addition of the PolySwitch business in the current year and increased electronic sales, partially offset by $0.4 million in unfavorable currency effects primarily from sales denominated in euro.

[0001437749-16-036614:mdna:51]
Asia-Pacific sales increased $32.8 million, or 21%, to $187.0 million in the first six months of 2016 compared to $154.2 million in the first six months of 2015 primarily reflecting the addition of the PolySwitch business in the current year and increased demand for electronics and automotive products, partially offset by unfavorable currency effects of $3.1 million. Excluding currency effects, Asia-Pacific sales increased $35.9 million, or 23%, year-over-year.

[0001437749-16-036614:mdna:52]
Gross profit was $185.0 million, or 38% of net sales, for the first six months of 2016 compared to $161.6 million, or 37% of net sales, in the same period last year. Gross profit for 2016 includes a $6.9 million non-cash inventory charge relating to the PolySwitch acquisition, $1.5 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines, $0.9 million of acquisition-related costs primarily related to integration costs associated with the company’s acquisition of the PolySwitch business, $0.5 million in charges related to the closure of the company’s manufacturing facility in Denmark and $0.1 million related to internal legal restructuring costs. Gross profit for 2015 included $1.9 million related to the reed switch production transfer. Excluding the impact of these charges, gross profit was $194.9 million, or 40% of net sales, for the first six months of 2016 compared to $163.5 million, or 38% of net sales, in the first six months of 2015.

[0001437749-16-036614:mdna:53]
Total operating expense was $122.9 million, or 25% of net sales, for the first six months of 2016 compared to $95.9 million, or 22% of net sales, for the same period in 2015. Operating expense in 2016 included $11.4 million of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, $1.4 million in charges related to the closure of the company’s manufacturing facility in Denmark, $0.3 million related to internal legal restructuring costs and $0.2 million related to the transfer of the company’s reed switch production from the U.S. and China to the Philippines. Operating expense in 2015 included $2.9 million related to internal legal restructuring, $0.3 million related to acquisition costs and $1.3 million of expense related to the planned termination of the U.S. pension. Excluding these charges, total operating expense was $109.6 million, or 22% of net sales, for 2016 compared to $91.4 million, or 21% of net sales, in 2015, partially reflecting increased research and development expenses in the current year quarter as compared to the prior year quarter and incremental amortization of intangible assets associated with recent acquisitions.

[0001437749-16-036614:mdna:54]
Due to reasons noted above, operating income for the first six months of 2016 was approximately $62.1 million compared to operating income of $65.7 million for the same period in 2015.

[0001437749-16-036614:mdna:55]
Interest expense was $3.7 million in the first six months of 2016 as compared to $2.1 million in the first six months of 2015, primarily reflecting higher borrowings relating to the March 2016 acquisition of the PolySwitch business.

[0001437749-16-036614:mdna:56]
Foreign exchange (gain) loss, reflecting net gains and losses resulting from the effect of exchange rate changes on various foreign currency transactions worldwide, was approximately $2.4 million of income for the first six months of 2016 and $1.8 million of loss for the first six months of 2015 and primarily reflects fluctuations in the euro and Philippine peso against the U.S. dollar and the euro against the Japanese yen.

[0001437749-16-036614:mdna:57]
Other (income) expense, net, consisting of interest income, royalties and non-operating income items was approximately $0.3 million of income for first six months of 2016 and $2.3 million of income for the first six months of 2015. The period over period decline primarily reflects lower interest income in the current year period due to cash used for the acquisition of the PolySwitch business in March 2016.

[0001437749-16-036614:mdna:58]
Income before income taxes was $61.1 million for the first six months of 2016 compared to $64.1 million for the first six months of 2015. Income tax expense was $14.7 million with an effective tax rate of 24.0% for the first six months of 2016 compared to income tax expense of $15.4 million with an effective tax rate of 24.1% in the first six months of 2015. The effective tax rates for both the first six months of 2016 and 2015 are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.

[0001437749-16-036614:mdna:59]
Net income for the first six months of 2016 was $46.4 million or $2.05 per diluted share compared to net income of $48.7 million or $2.13 per diluted share for the same period of 2015.

[0001437749-16-036614:mdna:60]
[same as prior period, unchanged from 0001437749-16-031011:mdna:42]

[0001437749-16-036614:mdna:61]
As of July 2, 2016, $166.5 million of the $179.5 million of the company’s cash and cash equivalents was held by foreign subsidiaries. Of the $166.5 million held by foreign subsidiaries, approximately $20.1 million could be repatriated with minimal tax consequences. The company expects to maintain its foreign cash balances (other than the aforementioned $20.1 million) for local operating requirements, to provide funds for future capital expenditures and for potential acquisitions. The company does not expect to repatriate these funds to the U.S.

[0001437749-16-036614:mdna:62]
[same as prior period, unchanged from 0001437749-16-031011:mdna:44]

[0001437749-16-036614:mdna:63]
Revolving Credit Facility/Term Loan

[0001437749-16-036614:mdna:64]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of July 2, 2016, the company had available $337.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (1.97% as of July 2, 2016).

[0001437749-16-036614:mdna:65]
22

[0001437749-16-036614:mdna:66]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement. This new credit agreement was determined to be a modification under ASC 470-50 of the previous credit agreement.

[0001437749-16-036614:mdna:67]
This arrangement contains covenants that, among other matters, impose limitations on the incurrence of additional indebtedness, future mergers, sales of assets, payment of dividends, and changes in control, as defined in the agreement. In addition, the company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At July 2, 2016, the company was in compliance with all covenants under the credit agreement.

[0001437749-16-036614:mdna:68]
The company also had $0.1 million outstanding in letters of credit at July 2, 2016. No amounts were drawn under these letters of credit at July 2, 2016.

[0001437749-16-036614:mdna:69]
[same as prior period, unchanged from 0001437749-16-031011:mdna:50]

[0001437749-16-036614:mdna:70]
During the fourth quarter of 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income is recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Net Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.3 million) at July 2, 2016.

[0001437749-16-036614:mdna:71]
Stock Repurchase Program

[0001437749-16-036614:mdna:72]
The company’s Board of Directors authorized the repurchase of up to 1,000,000 shares of the company’s common stock under a program for the period May 1, 2016 to April 30, 2017. The company’s prior share repurchase authorization of 1,000,000 shares expired on April 30, 2016 with 650,000 shares remaining in the program. The company did not repurchase any shares of its common stock during the first six months of fiscal 2016.

[0001437749-16-036614:mdna:73]
[same as prior period, unchanged from 0001437749-16-031011:mdna:52]

[0001437749-16-036614:mdna:74]
The company started 2016 with $328.8 million of cash and cash equivalents. Net cash provided by operating activities was approximately $35.3 million for the first six months of 2016 reflecting $46.4 million in net income and $38.3 million in non-cash adjustments (primarily $25.1 million in depreciation and amortization) offset by $49.4 million in net changes to various operating assets and liabilities.

[0001437749-16-036614:mdna:75]
Changes in operating assets and liabilities for the first six months of 2016 (including short-term and long-term items) that impacted cash flows negatively consisted of increases in accounts receivable ($20.8 million), prepaid and other assets ($11.9 million), decreases in accrued payroll and severance ($10.2 million), accrued and net deferred taxes ($13.9 million) and inventories ($1.3 million). The increase in accounts receivable was due to increased sales in the second quarter. The decrease in accrued payroll and severance was due primarily to payouts for the 2015 management incentive plan which occurred in the first quarter. Changes having a positive impact on cash flows were increases in accrued expenses ($5.7 million) and accounts payable ($3.0 million).

[0001437749-16-036614:mdna:76]
Net cash used in investing activities for the first six months of 2016 was approximately $374.2 million and primarily related to the acquisition of the PolySwitch business ($333.0 million, net of cash acquired), the acquisition of Menber’s ($17.8 million) and capital expenditures ($20.2 million).

[0001437749-16-036614:mdna:77]
Net cash provided by financing activities for the first six months of 2016 was approximately $188.8 million and included $198.9 million in net proceeds on borrowings offset by dividends paid of $13.0 million and debt issuance costs related to the new credit agreement of $1.7 million, partially offset by $4.5 million from the exercise of stock options including tax benefits. The effects of exchange rate changes increased cash and cash equivalents by approximately $0.8 million. The net cash provided by operating activities combined with the effects of exchange rate changes less net cash used in investing and financing activities resulted in a $149.3 million decrease in cash, which left the company with a cash and cash equivalents balance of $179.5 million at July 2, 2016.

[0001437749-16-036614:mdna:78]
The ratio of current assets to current liabilities was 3.0 to 1 at the end of the second quarter of 2016 compared to 2.8 to 1 at year-end 2015 and 3.0 to 1 at the end of the second quarter of 2015. Days sales outstanding in accounts receivable was approximately 66 days at the end of the second quarter of 2016 compared to 62 days at the end of the second quarter of 2015 and 59 days at year-end 2015. Days inventory outstanding was approximately 65 days at the end of the second quarter of 2016 as well as at the year-end 2015 and second quarter of 2015.

[0001437749-16-036614:mdna:79]
[same as prior period, unchanged from 0001437749-16-031011:mdna:58]

[0001437749-16-036614:mdna:80]
Sales in the 3rd quarter of 2016 are expected to be in the range of $262 million to $272 million, which includes PolySwitch sales of approximately $40 million.
