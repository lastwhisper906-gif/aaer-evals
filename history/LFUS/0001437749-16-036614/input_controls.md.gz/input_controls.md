# LFUS 10-Q controls and the auditor's report


## item_4_controls

[0001437749-16-036614:item_4_controls:1]
Item 4. Controls and Procedures.

[0001437749-16-036614:item_4_controls:2]
Each of our Chief Executive Officer and Chief Financial Officer has evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Securities and Exchange Act of 1934) as of the end of the period covered by this quarterly report. Based on such evaluation, such officers have concluded that, as of the end of the period covered by this quarterly report, our disclosure controls and procedures are effective.

[0001437749-16-036614:item_4_controls:3]
There have been no changes in our internal controls over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended July 2, 2016 that have materially affected, or are reasonably likely to materially affect, our internal controls over financial reporting.

[0001437749-16-036614:item_4_controls:4]
25
