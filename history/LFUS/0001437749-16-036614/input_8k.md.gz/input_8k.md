# LFUS 8-K — 0001437749-16-036352 filed 2016-08-04

## item codes, every 8-K on or before 2016-08-05

- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2016-08-05

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001437749-16-036352:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-16-036352:8k_2_02:2]
ex99-1.htm

[0001437749-16-036352:8k_2_02:3]
Exhibit 99.1

[0001437749-16-036352:8k_2_02:4]
NEWS RELEASE

[0001437749-16-036352:8k_2_02:5]
CONTACT: Meenal Sethna

[0001437749-16-036352:8k_2_02:6]
Executive Vice President and CFO

[0001437749-16-036352:8k_2_02:7]
(773) 628-0616

[0001437749-16-036352:8k_2_02:8]
LITTELFUSE REPORTS SECOND QUARTER RESULTS

[0001437749-16-036352:8k_2_02:9]
Second Quarter Sales and Earnings Above Midpoint of Guidance

[0001437749-16-036352:8k_2_02:10]
CHICAGO, August 4, 2016 – Littelfuse, Inc. (NASDAQ:LFUS) today reported financial results for the second quarter ended July 2, 2016.

[0001437749-16-036352:8k_2_02:11]
Second Quarter Highlights*

[0001437749-16-036352:8k_2_02:12]
* All comparisons are to the prior year period unless otherwise noted. A reconciliation of non-GAAP (adjusted) financial measures used in this release to the comparable GAAP financial measures is included below.

[0001437749-16-036352:8k_2_02:13]
|  | ● | Sales for the second quarter of 2016 were $271.9 million, a 22% increase. Excluding PolySwitch revenue of $36.4 million, sales increased 6%, led by strong growth in the automotive segment. |

[0001437749-16-036352:8k_2_02:14]
|  | ● | GAAP earnings for the second quarter of 2016 were $1.20 per diluted share. This included $5.5 million of special charges primarily related to purchase accounting and integration costs for the PolySwitch acquisition, partially offset by non-operating foreign exchange gains. Excluding these items, adjusted earnings for the second quarter of 2016 were $1.44 per diluted share, representing an 8% increase. |

[0001437749-16-036352:8k_2_02:15]
|  | ● | Highlights by segment included: |

[0001437749-16-036352:8k_2_02:16]
|  | o | Electronics sales increased 25%. Excluding PolySwitch, sales increased 2% as higher sensor and fuse sales were partially offset by a decline in semiconductor sales. |

[0001437749-16-036352:8k_2_02:17]
|  | o | Automotive sales increased 30%. Excluding PolySwitch, sales increased 15% reflecting strong growth in Asia and Europe, and globally across the sensor and fuse businesses. |

[0001437749-16-036352:8k_2_02:18]
|  | o | Industrial sales decreased 7% primarily due to a decline in the relay business due to weakness in mining and oil and gas end markets. |

[0001437749-16-036352:8k_2_02:19]
|  | ● | The electronics book-to-bill ratio for the second quarter of 2016 was 1.08 and includes the PolySwitch business. |

[0001437749-16-036352:8k_2_02:20]
-more-

[0001437749-16-036352:8k_2_02:21]
|  | ● | Cash provided by operating activities was $25.8 million for the second quarter of 2016 compared to $38.7 million for the second quarter of 2015. The decline was primarily driven by integration and other non-recurring costs related to the PolySwitch business. |

[0001437749-16-036352:8k_2_02:22]
|  | ● | Capital expenditures for the second quarter of 2016 decreased to $11.1 million compared to $14.1 million in the prior year. |

[0001437749-16-036352:8k_2_02:23]
"Our teams have continued to execute well within an uncertain macro environment," said Gordon Hunter, chief executive officer. "Operating margins improved in both our electronics and automotive segments, while our teams also focused on integrating the PolySwitch business. Our industrial segment continued to face end market weakness, and we’ve taken recent actions to reduce our cost structure across the segment. Despite these challenges, we remain on track for meaningful margin expansion this year as we continue to execute on our footprint consolidations and portfolio initiatives.”

[0001437749-16-036352:8k_2_02:24]
Outlook*

[0001437749-16-036352:8k_2_02:25]
* All comparisons are to the prior year period unless otherwise noted. Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, impairment and severance charges, foreign exchange adjustments and unusual gains and losses. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP.  Littelfuse is not able to forecast the excluded items to the most directly comparable GAAP financial measure without unreasonable efforts.

[0001437749-16-036352:8k_2_02:26]
"Despite the headwinds in some of our markets, our business trends remain solid. We’ve had a strong start to the year with positive momentum across our electronics and automotive segments, and are pleased with the performance of the PolySwitch business to date. However, end market challenges in our industrial segment have impacted profitability, and are expected to continue through this year,” said Hunter.

[0001437749-16-036352:8k_2_02:27]
|  | ● | Total sales for the third quarter of 2016 are expected to be in the range of $262 million to $272 million, which includes PolySwitch sales of approximately $40 million. This represents 24% revenue growth at the midpoint, and 5% revenue growth excluding PolySwitch. |

[0001437749-16-036352:8k_2_02:28]
|  | ● | Total earnings for the third quarter of 2016, including the PolySwitch business, are expected to be in the range of $1.36 to $1.50 per diluted share, excluding special items. |

[0001437749-16-036352:8k_2_02:29]
|  | ● | Operating cash flow for 2016 is expected to be 12-14% of revenue, driven by one-time cash costs for PolySwitch integration activities and other acquisition related items. |

[0001437749-16-036352:8k_2_02:30]
-more-

[0001437749-16-036352:8k_2_02:31]
Conference Call and Webcast Information

[0001437749-16-036352:8k_2_02:32]
Littelfuse will host a conference call today, Thursday, August 4, 2016, at 10:00 a.m. Central / 11:00 a.m. Eastern time to discuss the results. The call will be broadcast live over the Internet and can be accessed through the company’s website: www.littelfuse.com. Listeners should go to the website at least 15 minutes prior to the call to download and install any necessary audio software. The call will be available for replay on the company’s website.

[0001437749-16-036352:8k_2_02:33]
About Littelfuse

[0001437749-16-036352:8k_2_02:34]
Founded in 1927, Littelfuse is the world leader in circuit protection with growing global platforms in power control and sensing. The company serves customers in the electronics, automotive and industrial markets with technologies including fuses, semiconductors, polymers, ceramics, relays and sensors. Littelfuse has over 10,000 employees in more than 40 locations throughout the Americas, Europe and Asia. For more information, please visit the Littelfuse website: Littelfuse.com.

[0001437749-16-036352:8k_2_02:35]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the PSLRA. These statements may involve risks and uncertainties, including, but not limited to, risks relating to product demand and market acceptance, economic conditions, the impact of competitive products and pricing, product quality problems or product recalls, capacity and supply difficulties or constraints, coal mining exposures reserves, failure of an indemnification for environmental liability, exchange rate fluctuations, commodity price fluctuations, the effect of the company's accounting policies, labor disputes, restructuring costs in excess of expectations, pension plan asset returns less than assumed, integration of acquisitions and other risks which may be detailed in the company's other Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 2, 2016. For a further discussion of the risk factors of the company, please see Item 1A. "Risk Factors" to the company's Annual Report on Form 10-K for the year ended January 2, 2016.

[0001437749-16-036352:8k_2_02:36]
Non-GAAP Financial Measures

[0001437749-16-036352:8k_2_02:37]
The information included in this press release includes the non-GAAP financial measures of adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin and adjusted diluted earnings per share. These non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is included herein.

[0001437749-16-036352:8k_2_02:38]
-more-

[0001437749-16-036352:8k_2_02:39]
The company believes that adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin and adjusted diluted earnings per share provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations. The company believes that these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which the Company operates, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that the company’s definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001437749-16-036352:8k_2_02:40]
###

[0001437749-16-036352:8k_2_02:41]
LFUS-F

[0001437749-16-036352:8k_2_02:42]
| LITTELFUSE, INC. |
| Net Sales and Operating Income by Business Unit |
| (In thousands of USD, unaudited) |

[0001437749-16-036352:8k_2_02:43]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 132,170 |  |  | $ | 105,553 |  |  |  | 25 | % |  | $ | 230,966 |  |  | $ | 204,933 |  |  |  | 13 | % |
| Automotive |  |  | 111,370 |  |  |  | 85,918 |  |  |  | 30 | % |  |  | 203,303 |  |  |  | 169,989 |  |  |  | 20 | % |
| Industrial |  |  | 28,372 |  |  |  | 30,550 |  |  |  | (7 | %) |  |  | 57,041 |  |  |  | 57,412 |  |  |  | (1 | %) |
| Total net sales |  | $ | 271,912 |  |  | $ | 222,021 |  |  |  | 22 | % |  | $ | 491,310 |  |  | $ | 432,334 |  |  |  | 14 | % |

[0001437749-16-036352:8k_2_02:44]
|  |  | Second Quarter |  |  | Year-to-Date |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2016 |  |  | 2015 |  |  | % Change |  |
| Operating Income/(Expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 25,259 |  |  | $ | 22,167 |  |  |  | 14 | % |  | $ | 47,675 |  |  | $ | 40,832 |  |  |  | 17 | % |
| Automotive |  |  | 16,474 |  |  |  | 12,699 |  |  |  | 30 | % |  |  | 33,965 |  |  |  | 23,870 |  |  |  | 42 | % |
| Industrial |  |  | 2,028 |  |  |  | 4,709 |  |  |  | (57 | %) |  |  | 3,701 |  |  |  | 7,439 |  |  |  | (50 | %) |
| Other (1) |  |  | (14,059 | ) |  |  | (3,404 | ) |  |  | 313 | % |  |  | (23,211 | ) |  |  | (6,422 | ) |  |  | 261 | % |
| Total operating income |  | $ | 29,702 |  |  | $ | 36,171 |  |  |  | (18 | %) |  | $ | 62,130 |  |  | $ | 65,719 |  |  |  | (5 | %) |
| Interest expense |  |  | 1,670 |  |  |  | 948 |  |  |  |  |  |  |  | 3,715 |  |  |  | 2,099 |  |  |  |  |  |
| Foreign exchange (gain) loss |  |  | (6,237 | ) |  |  | (1,292 | ) |  |  |  |  |  |  | (2,414 | ) |  |  | 1,825 |  |  |  |  |  |
| Other (income) expense, net |  |  | 255 |  |  |  | (1,202 | ) |  |  |  |  |  |  | (262 | ) |  |  | (2,328 | ) |  |  |  |  |
| Income before taxes |  | $ | 34,014 |  |  | $ | 37,717 |  |  |  | (10 | %) |  | $ | 61,091 |  |  | $ | 64,123 |  |  |  | (5 | %) |

[0001437749-16-036352:8k_2_02:45]
| (1) "Other" typically includes special items such as acquisition-related costs, restructuring costs, asset impairments, and gains and losses on asset sales. (See Supplemental Financial Information for details on page 9.) |

[0001437749-16-036352:8k_2_02:46]
-more-

[0001437749-16-036352:8k_2_02:47]
LITTELFUSE, INC.

[0001437749-16-036352:8k_2_02:48]
Condensed Consolidated Balance Sheets

[0001437749-16-036352:8k_2_02:49]
(In thousands of USD, except share amounts)

[0001437749-16-036352:8k_2_02:50]
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
|  |  | (Unaudited) |  |  |  |  |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 179,461 |  |  | $ | 328,786 |  |
| Short-term investments |  |  | 3,920 |  |  |  | 4,179 |  |
| Accounts receivable, less allowances |  |  | 197,543 |  |  |  | 142,882 |  |
| Inventories |  |  | 124,700 |  |  |  | 98,629 |  |
| Prepaid expenses and other current assets |  |  | 14,253 |  |  |  | 8,238 |  |
| Total current assets |  |  | 519,877 |  |  |  | 582,714 |  |
| Property, plant and equipment: |  |  |  |  |  |  |  |  |
| Land |  |  | 14,255 |  |  |  | 5,236 |  |
| Buildings |  |  | 84,457 |  |  |  | 71,383 |  |
| Equipment |  |  | 450,597 |  |  |  | 382,429 |  |
|  |  |  | 549,309 |  |  |  | 459,048 |  |
| Accumulated depreciation |  |  | (324,799 | ) |  |  | (296,480 | ) |
| Net property, plant and equipment |  |  | 224,510 |  |  |  | 162,568 |  |
| Intangible assets, net of amortization: |  |  |  |  |  |  |  |  |
| Patents, licenses and software |  |  | 76,703 |  |  |  | 20,221 |  |
| Distribution network |  |  | 18,664 |  |  |  | 16,490 |  |
| Customer lists, trademarks and tradenames |  |  | 92,313 |  |  |  | 54,912 |  |
| Goodwill |  |  | 363,341 |  |  |  | 189,767 |  |
|  |  |  | 551,021 |  |  |  | 281,390 |  |
| Investments |  |  | 13,936 |  |  |  | 15,197 |  |
| Deferred income taxes |  |  | 13,994 |  |  |  | 8,333 |  |
| Other assets |  |  | 18,460 |  |  |  | 14,058 |  |
| Total assets |  | $ | 1,341,798 |  |  | $ | 1,064,260 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 78,197 |  |  | $ | 51,658 |  |
| Accrued payroll |  |  | 30,615 |  |  |  | 32,611 |  |
| Accrued expenses |  |  | 55,716 |  |  |  | 24,145 |  |
| Accrued severance |  |  | 1,328 |  |  |  | 3,798 |  |
| Accrued income taxes |  |  | 6,682 |  |  |  | 15,567 |  |
| Current portion of long-term debt |  |  | 6,250 |  |  |  | 87,000 |  |
| Total current liabilities |  |  | 178,788 |  |  |  | 214,779 |  |
| Long-term debt, less current portion |  |  | 361,732 |  |  |  | 83,753 |  |
| Deferred income taxes |  |  | 6,347 |  |  |  | 8,014 |  |
| Accrued post-retirement benefits |  |  | 7,498 |  |  |  | 5,653 |  |
| Other long-term liabilities |  |  | 12,576 |  |  |  | 12,809 |  |
| Total equity |  |  | 774,857 |  |  |  | 739,252 |  |
| Total liabilities and equity |  | $ | 1,341,798 |  |  | $ | 1,064,260 |  |

[0001437749-16-036352:8k_2_02:51]
Common shares issued and outstanding of 22,552,780 and 22,420,785 at July 2, 2016 and January 2, 2016, respectively.

[0001437749-16-036352:8k_2_02:52]
-more-

[0001437749-16-036352:8k_2_02:53]
LITTELFUSE, INC.

[0001437749-16-036352:8k_2_02:54]
Consolidated Statements of Comprehensive Income

[0001437749-16-036352:8k_2_02:55]
(In thousands of USD, except per share data, unaudited)

[0001437749-16-036352:8k_2_02:56]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| Net sales |  | $ | 271,912 |  |  | $ | 222,021 |  |  | $ | 491,310 |  |  | $ | 432,334 |  |
| Cost of sales |  |  | 174,046 |  |  |  | 136,740 |  |  |  | 306,289 |  |  |  | 270,723 |  |
| Gross profit |  |  | 97,866 |  |  |  | 85,281 |  |  |  | 185,021 |  |  |  | 161,611 |  |
| Selling, general and administrative expenses |  |  | 51,092 |  |  |  | 38,772 |  |  |  | 93,458 |  |  |  | 75,117 |  |
| Research and development expenses |  |  | 11,916 |  |  |  | 7,361 |  |  |  | 20,481 |  |  |  | 14,745 |  |
| Amortization of intangibles |  |  | 5,156 |  |  |  | 2,977 |  |  |  | 8,952 |  |  |  | 6,030 |  |
|  |  |  | 68,164 |  |  |  | 49,110 |  |  |  | 122,891 |  |  |  | 95,892 |  |
| Operating income |  |  | 29,702 |  |  |  | 36,171 |  |  |  | 62,130 |  |  |  | 65,719 |  |
| Interest expense |  |  | 1,670 |  |  |  | 948 |  |  |  | 3,715 |  |  |  | 2,099 |  |
| Foreign exchange (gain) loss |  |  | (6,237 | ) |  |  | (1,292 | ) |  |  | (2,414 | ) |  |  | 1,825 |  |
| Other (income) expense, net |  |  | 255 |  |  |  | (1,202 | ) |  |  | (262 | ) |  |  | (2,328 | ) |
| Income before income taxes |  |  | 34,014 |  |  |  | 37,717 |  |  |  | 61,091 |  |  |  | 64,123 |  |
| Income taxes |  |  | 6,862 |  |  |  | 9,033 |  |  |  | 14,650 |  |  |  | 15,444 |  |
| Net income |  | $ | 27,152 |  |  | $ | 28,684 |  |  | $ | 46,441 |  |  | $ | 48,679 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.21 |  |  | $ | 1.26 |  |  | $ | 2.07 |  |  | $ | 2.15 |  |
| Diluted |  | $ | 1.20 |  |  | $ | 1.26 |  |  | $ | 2.05 |  |  | $ | 2.13 |  |
| Weighted average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 22,528 |  |  |  | 22,691 |  |  |  | 22,483 |  |  |  | 22,645 |  |
| Diluted |  |  | 22,674 |  |  |  | 22,835 |  |  |  | 22,647 |  |  |  | 22,810 |  |
| Comprehensive income |  | $ | 11,899 |  |  | $ | 34,672 |  |  | $ | 41,874 |  |  | $ | 43,709 |  |

[0001437749-16-036352:8k_2_02:57]
-more-

[0001437749-16-036352:8k_2_02:58]
LITTELFUSE, INC.

[0001437749-16-036352:8k_2_02:59]
Consolidated Statements of Cash Flows

[0001437749-16-036352:8k_2_02:60]
(In thousands of USD, unaudited)

[0001437749-16-036352:8k_2_02:61]
|  |  | For the Six Months Ended |  |
|  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| OPERATING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 46,441 |  |  | $ | 48,679 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 16,156 |  |  |  | 14,761 |  |
| Amortization of intangibles |  |  | 8,952 |  |  |  | 6,030 |  |
| Loss on sale of product line |  |  | 1,391 |  |  |  | - |  |
| Stock-based compensation |  |  | 6,124 |  |  |  | 5,764 |  |
| Non-cash inventory charge |  |  | 6,902 |  |  |  | - |  |
| Excess tax benefit on stock-based compensation |  |  | (1,585 | ) |  |  | (1,470 | ) |
| Loss on sale of assets |  |  | 331 |  |  |  | 329 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (20,846 | ) |  |  | (21,266 | ) |
| Inventories |  |  | (1,282 | ) |  |  | (1,199 | ) |
| Accounts payable |  |  | 2,974 |  |  |  | 3,440 |  |
| Accrued expenses (including post retirement) |  |  | 5,715 |  |  |  | 11,129 |  |
| Accrued payroll and severance |  |  | (10,227 | ) |  |  | (3,652 | ) |
| Accrued taxes |  |  | (13,946 | ) |  |  | (3,003 | ) |
| Prepaid expenses and other |  |  | (11,824 | ) |  |  | 2,422 |  |
| Net cash provided by operating activities |  |  | 35,276 |  |  |  | 61,964 |  |
| INVESTING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (20,217 | ) |  |  | (26,388 | ) |
| Acquisition of business, net of cash acquired |  |  | (354,356 | ) |  |  | - |  |
| Decrease in entrusted loan receivable |  |  | - |  |  |  | 3,519 |  |
| Proceeds from sale of assets |  |  | 370 |  |  |  | 48 |  |
| Net cash used in investing activities |  |  | (374,203 | ) |  |  | (22,821 | ) |
| FINANCING ACTIVITIES: |  |  |  |  |  |  |  |  |
| Proceeds of revolving credit facility |  |  | 258,000 |  |  |  | 11,000 |  |
| Proceeds of term loan |  |  | 125,000 |  |  |  | - |  |
| Payments of revolving credit facility |  |  | (97,500 | ) |  |  | (21,000 | ) |
| Payments of term loan |  |  | (86,563 | ) |  |  | (2,500 | ) |
| Payments of entrusted loan |  |  | - |  |  |  | (3,519 | ) |
| Debt issuance costs paid |  |  | (1,701 | ) |  |  | (42 | ) |
| Cash dividends paid |  |  | (12,995 | ) |  |  | (11,296 | ) |
| Proceeds from exercise of stock options |  |  | 2,960 |  |  |  | 6,278 |  |
| Excess tax benefit on share-based compensation |  |  | 1,586 |  |  |  | 1,470 |  |
| Net cash (used in) provided by financing activities |  |  | 188,787 |  |  |  | (19,609 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 815 |  |  |  | (5,190 | ) |
| Increase in cash and cash equivalents |  |  | (149,325 | ) |  |  | 14,344 |  |
| Cash and cash equivalents at beginning of period |  |  | 328,786 |  |  |  | 297,571 |  |
| Cash and cash equivalents at end of period |  | $ | 179,461 |  |  | $ | 311,915 |  |

[0001437749-16-036352:8k_2_02:62]
(1) Purchase accounting adjustment related to acquisitions.

[0001437749-16-036352:8k_2_02:63]
-more-

[0001437749-16-036352:8k_2_02:64]
LITTELFUSE, INC.

[0001437749-16-036352:8k_2_02:65]
Supplemental Financial Information

[0001437749-16-036352:8k_2_02:66]
(in millions of USD except share amounts)

[0001437749-16-036352:8k_2_02:67]
| GAAP EPS Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-16 |  |  | Q2-16 |  |  | YTD-16 |  |  | Q1-15 |  |  | Q2-15 |  |  | YTD-15 |  |
| GAAP diluted EPS |  | $ | 0.85 |  |  | $ | 1.20 |  |  | $ | 2.05 |  |  | $ | 0.88 |  |  | $ | 1.26 |  |  | $ | 2.13 |  |
| EPS impact of special items (below) |  |  | 0.53 |  |  |  | 0.24 |  |  |  | 0.77 |  |  |  | 0.20 |  |  |  | 0.07 |  |  |  | 0.27 |  |
| Adjusted diluted EPS |  | $ | 1.38 |  |  | $ | 1.44 |  |  | $ | 2.82 |  |  | $ | 1.08 |  |  | $ | 1.33 |  |  | $ | 2.40 |  |
| Year-over-year adjusted EPS growth |  |  | 28 | % |  |  | 8 | % |  |  | 18 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Adjustments - (income)/expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reed switch manufacturing transfer costs |  | $ | 1.0 |  |  | $ | 0.7 |  |  | $ | 1.7 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.9 |  |
| Restructuring |  |  | 0.4 |  |  |  | 0.1 |  |  |  | 0.5 |  |  |  | 1.2 |  |  |  | 1.7 |  |  |  | 2.9 |  |
| Acquisition expenses |  |  | 6.2 |  |  |  | 6.1 |  |  |  | 12.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.4 |  |
| Pension wind-up |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 1.4 |  |
| Impairment and severance charges |  |  | 1.6 |  |  |  | 0.3 |  |  |  | 1.9 |  |  |  | - |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  |  | - |  |  |  | 6.9 |  |  |  | 6.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Adjustment to Operating income |  |  | 9.2 |  |  |  | 14.0 |  |  |  | 23.2 |  |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 6.4 |  |
| Foreign exchange loss/(gain) |  |  | 3.8 |  |  |  | (6.2 | ) |  |  | (2.4 | ) |  |  | 3.1 |  |  |  | (1.3 | ) |  |  | 1.8 |  |
| Adjustment to income before income taxes |  | $ | 13.0 |  |  | $ | 7.8 |  |  | $ | 20.8 |  |  | $ | 6.1 |  |  | $ | 2.1 |  |  | $ | 8.2 |  |
| Income taxes |  | $ | 1.0 |  |  | $ | 2.3 |  |  | $ | 3.4 |  |  | $ | 1.5 |  |  | $ | 0.5 |  |  | $ | 2.0 |  |
| Adjustment to net income |  | $ | 12.0 |  |  | $ | 5.5 |  |  | $ | 17.4 |  |  | $ | 4.6 |  |  | $ | 1.6 |  |  | $ | 6.2 |  |
| Total EPS impact |  | $ | 0.53 |  |  | $ | 0.24 |  |  | $ | 0.77 |  |  | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 0.27 |  |
| Operating margin / EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1-16 |  |  | Q2-16 |  |  | YTD-16 |  |  | Q1-15 |  |  | Q2-15 |  |  | YTD-15 |  |
| Net sales |  | $ | 219.4 |  |  | $ | 271.9 |  |  | $ | 491.3 |  |  | $ | 210.3 |  |  | $ | 222.0 |  |  | $ | 432.3 |  |
| GAAP operating income |  | $ | 32.4 |  |  | $ | 29.7 |  |  | $ | 62.1 |  |  | $ | 29.5 |  |  | $ | 36.2 |  |  | $ | 65.7 |  |
| Add back special operating items |  |  | 9.2 |  |  |  | 14.0 |  |  |  | 23.2 |  |  |  | 3.0 |  |  |  | 3.4 |  |  |  | 6.4 |  |
| Adjusted operating income |  | $ | 41.6 |  |  | $ | 43.7 |  |  | $ | 85.3 |  |  | $ | 32.5 |  |  | $ | 39.6 |  |  | $ | 72.1 |  |
| Adjusted operating margin |  |  | 19.0 | % |  |  | 16.1 | % |  |  | 17.4 | % |  |  | 15.5 | % |  |  | 17.8 | % |  |  | 16.7 | % |
| Add back amortization |  |  | 3.8 |  |  |  | 5.2 |  |  |  | 9.0 |  |  |  | 3.1 |  |  |  | 2.9 |  |  |  | 6.0 |  |
| Add back depreciation |  |  | 7.2 |  |  |  | 8.9 |  |  |  | 16.1 |  |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 14.8 |  |
| Adjusted EBITDA |  | $ | 52.6 |  |  | $ | 57.8 |  |  | $ | 110.4 |  |  | $ | 43.0 |  |  | $ | 49.9 |  |  | $ | 92.9 |  |
| Adjusted EBITDA margin |  |  | 24.0 | % |  |  | 21.3 | % |  |  | 22.5 | % |  |  | 20.4 | % |  |  | 22.5 | % |  |  | 21.5 | % |
| Year-over-year adjusted EBITDA growth |  |  | 22 | % |  |  | 16 | % |  |  | 19 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001437749-16-036352:8k_2_02:68]
| Note: Totals will not always foot due to rounding |

[0001437749-16-036352:8k_2_02:69]
# # #
