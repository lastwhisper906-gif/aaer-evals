# LFUS notes — 0001437749-16-036614


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001437749-16-036614:notes:1]
2. Correction of immaterial errors

[0001437749-16-036614:notes:2]
In the second quarter of 2016, management determined that the company may incur additional income taxes and interest in a foreign jurisdiction with respect to the 2011 through 2015 fiscal years. The cumulative adjustment for this income tax (including interest of $1.5 million) as of January 2, 2016, is approximately $4.9 million. The adjustment applicable to 2015, 2014, 2013, 2012 and 2011 was $1.6 million, $1.3 million, $1.0 million, $0.9 million and $0.1 million, respectively.

[0001437749-16-036614:notes:3]
Pursuant to the guidance of Staff Accounting Bulletin ("SAB") No. 99, Materiality, the Company concluded that the errors were not material to any of its applicable prior period annual and quarterly financial statements. Although the errors were immaterial to prior periods, the prior period annual financial statements were revised, in accordance with SAB No. 108, Considering the Effects of Prior Year Misstatements when Quantifying Misstatements in Current Year Financial Statements, due to the significance of the out-of-period correction. The adjustment for each year has been treated as applicable to the fourth quarter of each year.

[0001437749-16-036614:notes:4]
A reconciliation of the effects of the adjustments to the previously reported balance sheet at January 2, 2016 follows ($ in thousands):

[0001437749-16-036614:notes:5]
|  |  | January 2, 2016 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Accrued income taxes |  | $ | 10,621 |  |  | $ | 4,946 |  |  | $ | 15,567 |  |
| Total current liabilities |  |  | 209,833 |  |  |  | 4,946 |  |  |  | 214,779 |  |
| Total equity |  |  | 744,198 |  |  |  | (4,946 | ) |  |  | 739,252 |  |

[0001437749-16-036614:notes:6]
A reconciliation of the effects of the adjustments to the previously reported statements of net income for the years ended January 2, 2016 and December 27, 2014 follows ($ in thousands, except per share amounts):

[0001437749-16-036614:notes:7]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Income taxes |  | $ | 24,482 |  |  | $ | 1,600 |  |  | $ | 26,082 |  |  | $ | 32,228 |  |  | $ | 1,318 |  |  | $ | 33,546 |  |
| Net income |  |  | 82,466 |  |  |  | (1,600 | ) |  |  | 80,866 |  |  |  | 99,418 |  |  |  | (1,318 | ) |  |  | 98,100 |  |
| Net income per share - Basic |  | $ | 3.65 |  |  | $ | (0.07 | ) |  | $ | 3.58 |  |  | $ | 4.41 |  |  | $ | (0.06 | ) |  | $ | 4.35 |  |
| Net income per share - Diluted |  | $ | 3.63 |  |  | $ | (0.07 | ) |  | $ | 3.56 |  |  | $ | 4.37 |  |  | $ | (0.05 | ) |  | $ | 4.32 |  |

[0001437749-16-036614:notes:8]
A reconciliation of the effects of the adjustments to the previously reported statements of cash flows for the years ended January 2, 2016 and December 27, 2014 follows ($ in thousands):

[0001437749-16-036614:notes:9]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Net income |  | $ | 82,466 |  |  | $ | (1,600 | ) |  | $ | 80,866 |  |  | $ | 99,418 |  |  | $ | (1,318 | ) |  | $ | 98,100 |  |
| Accrued taxes |  |  | (1,043 | ) |  |  | 1,600 |  |  |  | 557 |  |  |  | (549 | ) |  |  | 1,318 |  |  |  | 769 |  |
| Net cash provided by operating activities |  |  | 165,826 |  |  |  | — |  |  |  | 165,826 |  |  |  | 153,141 |  |  |  | — |  |  |  | 153,141 |  |

[0001437749-16-036614:notes:10]
A reconciliation of the effects of the adjustments to the previously reported statements of equity for the years ended January 2, 2016 and December 27, 2014 follows ($ in thousands):

[0001437749-16-036614:notes:11]
|  |  | Year Ended January 2, 2016 |  |  | Year Ended December 27, 2014 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Net income |  | $ | 82,466 |  |  | $ | (1,600 | ) |  | $ | 80,866 |  |  | $ | 99,418 |  |  | $ | (1,318 | ) |  | $ | 98,100 |  |
| Comprehensive income |  |  | 57,921 |  |  |  | (1,600 | ) |  |  | 56,321 |  |  |  | 57,875 |  |  |  | (1,318 | ) |  |  | 56,557 |  |
| Retained earnings |  |  | 562,717 |  |  |  | (4,946 | ) |  |  | 557,771 |  |  |  | 523,302 |  |  |  | (3,346 | ) |  |  | 519,956 |  |
| Total shareholders’ equity |  |  | 744,198 |  |  |  | (4,946 | ) |  |  | 739,252 |  |  |  | 727,665 |  |  |  | (3,346 | ) |  |  | 724,319 |  |

[0001437749-16-036614:notes:12]
A reconciliation of the effects of the adjustments to the previously reported statement of equity at December 28, 2013 follows ($ in thousands):

[0001437749-16-036614:notes:13]
|  |  | December 28, 2013 |  |
|  |  | Previously Reported |  |  | Adjustment |  |  | As Revised |  |
| Retained earnings |  | $ | 445,059 |  |  | $ | (2,028 | ) |  | $ | 443,031 |  |
| Total shareholders’ equity |  |  | 686,916 |  |  |  | (2,028 | ) |  |  | 684,888 |  |


## us-gaap:AssetImpairmentChargesTextBlock

[0001437749-16-036614:notes:14]
1

[0001437749-16-036614:notes:15]
4

[0001437749-16-036614:notes:16]
. Product Line Sale

[0001437749-16-036614:notes:17]
During the first quarter of 2016, the company sold its tangible and intangible assets relating to a marine product line that it acquired as part of its acquisition of Selco A/S in 2011. In connection with this sale, the company recorded asset impairment charges of $1.4 million within cost of sales ($0.4 million), selling, general and administrative expenses (less than $0.1 million), research and development expenses (less than $0.1 million) and amortization of intangibles ($0.9) million. These charges were recognized as an “other” charge for segment reporting purposes.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-16-036614:notes:18]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (in thousands, except per share amounts) |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| Net sales |  | $ | 271,912 |  |  | $ | 267,711 |  |  | $ | 525,520 |  |  | $ | 523,844 |  |
| Income before income taxes |  |  | 40,916 |  |  |  | 41,206 |  |  |  | 72,348 |  |  |  | 64,881 |  |
| Net income |  |  | 32,662 |  |  |  | 32,743 |  |  |  | 57,085 |  |  |  | 56,493 |  |
| Net income per share — basic |  |  | 1.45 |  |  |  | 1.44 |  |  |  | 2.54 |  |  |  | 2.49 |  |
| Net income per share — diluted |  |  | 1.44 |  |  |  | 1.43 |  |  |  | 2.52 |  |  |  | 2.48 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-16-036614:notes:19]
3

[0001437749-16-036614:notes:20]
. Accumulated Other Comprehensive Income (Loss) (AOCI)

[0001437749-16-036614:notes:21]
[same as prior period, unchanged from 0001437749-16-031011:notes:5]

[0001437749-16-036614:notes:22]
| AOCI component |  | Balance at January 2, 2016 |  |  | Other comprehensive income (loss) activity |  |  | Reclassification adjustment for expense included in net income |  |  | Balance at July 2, 2016 |  |
| Pension and postemployment liability and reclassification adjustments(a) |  | $ | (8,722 | ) |  | $ | (45 | ) |  | $ | 144 |  |  | $ | (8,623 | ) |
| Unrealized gain on investments(b) |  |  | 11,584 |  |  |  | (1,486 | ) |  |  | — |  |  |  | 10,098 |  |
| Foreign currency translation adjustment |  |  | (48,533 | ) |  |  | (3,180 | ) |  |  | — |  |  |  | (51,713 | ) |
| AOCI (loss) income |  | $ | (45,671 | ) |  | $ | (4,711 | ) |  | $ | 144 |  |  | $ | (50,238 | ) |

[0001437749-16-036614:notes:23]
(a) Balances are net of tax of $654 and $661 for July 2, 2016 and January 2, 2016, respectively.

[0001437749-16-036614:notes:24]
(b) Balances are net of tax of $0 and $0 for July 2, 2016 and January 2, 2016, respectively.


## us-gaap:CostAndEquityMethodInvestmentsDisclosureTextBlock

[0001437749-16-036614:notes:25]
6

[0001437749-16-036614:notes:26]
. Investments

[0001437749-16-036614:notes:27]
[same as prior period, unchanged from 0001437749-16-031011:notes:10]

[0001437749-16-036614:notes:28]
[same as prior period, unchanged from 0001437749-16-031011:notes:11]

[0001437749-16-036614:notes:29]
[same as prior period, unchanged from 0001437749-16-031011:notes:12]

[0001437749-16-036614:notes:30]
The Polytronics investment was acquired as part of the Littelfuse GmbH acquisition. The fair value of the Polytronics investment was €9.4 million (approximately $10.4 million) at July 2, 2016 and €10.7 million (approximately $11.7 million) at January 2, 2016. Included in 2016 other comprehensive income is an unrealized loss of $1.5 million, due to the decrease in fair market value of the Polytronics investment. The remaining change in in the recorded value was due to the impact of changes in exchange rates.

[0001437749-16-036614:notes:31]
[same as prior period, unchanged from 0001437749-16-031011:notes:14]

[0001437749-16-036614:notes:32]
In December, 2015, the company invested $3.5 million in the preferred stock of Monolith, a U.S. start-up company developing silicon carbide technology, which represents approximately 12% of the common stock of Monolith on an as-converted basis. The company accounts for its investment in Monolith under the cost method. The value of the Monolith investment was $3.5 million at July 2, 2016 and January 2, 2016.


## us-gaap:DebtDisclosureTextBlock

[0001437749-16-036614:notes:33]
7

[0001437749-16-036614:notes:34]
. Debt

[0001437749-16-036614:notes:35]
The carrying amounts of debt at July 2, 2016 and January 2, 2016 are as follows (in thousands):

[0001437749-16-036614:notes:36]
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
| Revolving credit facility |  | $ | 237,500 |  |  | $ | 77,000 |  |
| Term loan |  |  | 123,438 |  |  |  | 85,000 |  |
| Entrusted loan |  |  | 9,256 |  |  |  | 9,474 |  |
| Unamortized debt issuance costs |  |  | (2,212 | ) |  |  | (721 | ) |
| Total debt |  |  | 367,982 |  |  |  | 170,753 |  |
| Less: Current maturities |  |  | 6,250 |  |  |  | 87,000 |  |
| Total long-term debt |  | $ | 361,732 |  |  | $ | 83,753 |  |

[0001437749-16-036614:notes:37]
Revolving Credit F

[0001437749-16-036614:notes:38]
acility / Term Loan

[0001437749-16-036614:notes:39]
On March 4, 2016, the company entered into a new credit agreement with Bank of America, as agent, for up to $700.0 million which consists of an unsecured revolving credit facility of $575.0 million and an unsecured term loan credit facility of up to $125.0 million. The new credit agreement is for a five year period. The new credit agreement replaced the company’s previous credit agreement dated May 31, 2013, which was terminated on March 4, 2016. As of July 2, 2016, the company had

[0001437749-16-036614:notes:40]
had $0.1 million outstanding in letters of credit and had available $337.4 million of borrowing capacity under the revolving credit facility at an interest rate of LIBOR plus 1.5% (1.97% as of July 2, 2016). At July 2, 2016, the company was in compliance with all covenants under the credit agreement

[0001437749-16-036614:notes:41]
.

[0001437749-16-036614:notes:42]
Entrusted Loan

[0001437749-16-036614:notes:43]
During 2014, the company entered into an entrusted loan arrangement (“Entrusted Loan”) of RMB 110.0 million (approximately $17.9 million) between two of its China legal entities, Littelfuse Semiconductor (Wuxi) Company (the “lender”) and Suzhou Littelfuse OVS Ltd. (the “borrower”), utilizing Bank of America, N.A., Shanghai Branch as agent. Direct borrowing and lending between two commonly owned commercial entities was strictly forbidden at the time under China’s regulations requiring the use of a third party agent to enable loans between Chinese legal entities. As a result, the Entrusted Loan is reflected as both a long-term asset and long-term debt on the company’s Consolidated Balance Sheets and is reflected in the investing and financing activities in its Consolidated Statements of Cash Flows. Interest expense and interest income will be recorded between the lender and borrower with no net impact on the company’s Consolidated Statements of Income since the amounts will be offsetting. The loan interest rate per annum is 5.25%. The Entrusted Loan is used to finance the operation and working capital needs of the borrower and matures in November 2019. The balance of the Entrusted Loan was RMB 61.5 million (approximately $9.3 million) at July 2, 2016.

[0001437749-16-036614:notes:44]
Debt Issuance Costs

[0001437749-16-036614:notes:45]
The company incurred debt issuance costs of $1.7 million in relation to the new credit agreement which along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new credit agreement.

[0001437749-16-036614:notes:46]
This new credit agreement

[0001437749-16-036614:notes:47]
was determined to be a modification under ASC 470-50 of the previous credit agreement

[0001437749-16-036614:notes:48]
In April 2015, the FASB issued ASU No. 2015-03, 
Interest - Imputation of Interest
 (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. The company adopted this guidance in the current quarter, on a retrospective basis, and has reclassified the unamortized debt issuance costs into long-term debt as shown in the table above.


## us-gaap:EarningsPerShareTextBlock

[0001437749-16-036614:notes:49]
9

[0001437749-16-036614:notes:50]
. Earnings per Share

[0001437749-16-036614:notes:51]
The following table sets forth the computation of basic and diluted earnings per share of July 2, 2016 and June 27, 2015 (in thousands, except per share amounts).

[0001437749-16-036614:notes:52]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| Net income |  | $ | 27.152 |  |  | $ | 28.684 |  |  | $ | 46,441 |  |  | $ | 48,679 |  |
| Average shares outstanding - Basic |  |  | 22,528 |  |  |  | 22,691 |  |  |  | 22,483 |  |  |  | 22,645 |  |
| Net effect of dilutive stock options and restricted share units |  |  | 146 |  |  |  | 144 |  |  |  | 164 |  |  |  | 165 |  |
| Average shares - Diluted |  |  | 22,674 |  |  |  | 22,835 |  |  |  | 22,647 |  |  |  | 22,810 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.21 |  |  | $ | 1.26 |  |  | $ | 2.07 |  |  | $ | 2.15 |  |
| Diluted |  | $ | 1.20 |  |  | $ | 1.26 |  |  | $ | 2.05 |  |  | $ | 2.13 |  |

[0001437749-16-036614:notes:53]
Potential shares of common stock relating to stock options excluded from the earnings per share calculation because their effect would be anti-dilutive were 60,491 and 113,878 for the three months ended July 2, 2016 and June 27, 2015, respectively, and 36,699 and 90,875 for the six months ended July 2, 2016 and June 27, 2015, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001437749-16-036614:notes:54]
|  |  | Fair Value Measurements Using |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |  | Total |  |
| Investment in Polytronics |  | $ | 10,438 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,438 |  |
| Total |  | $ | 10,438 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,438 |  |

[0001437749-16-036614:notes:55]
[same as prior period, unchanged from 0001437749-16-031011:notes:35]


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-16-036614:notes:56]
8

[0001437749-16-036614:notes:57]
. Fair Value of Assets and Liabilities

[0001437749-16-036614:notes:58]
[same as prior period, unchanged from 0001437749-16-031011:notes:37]

[0001437749-16-036614:notes:59]
[same as prior period, unchanged from 0001437749-16-031011:notes:38]

[0001437749-16-036614:notes:60]
[same as prior period, unchanged from 0001437749-16-031011:notes:39]

[0001437749-16-036614:notes:61]
[same as prior period, unchanged from 0001437749-16-031011:notes:40]

[0001437749-16-036614:notes:62]
[same as prior period, unchanged from 0001437749-16-031011:notes:41]

[0001437749-16-036614:notes:63]
[same as prior period, unchanged from 0001437749-16-031011:notes:42]

[0001437749-16-036614:notes:64]
[same as prior period, unchanged from 0001437749-16-031011:notes:43]

[0001437749-16-036614:notes:65]
The company holds an investment in the equity securities of Polytronics as described in Note 6. Equity securities listed on a national market or exchange, such as Polytronics, are valued at the last sales price. Such securities are classified within Level 1 of the valuation hierarchy. The company also holds an investment in Monolith as described in Note 6 for which the value of the $3.5 million represents the cost of the investment.

[0001437749-16-036614:notes:66]
There were no changes during the quarter ended July 2, 2016 to the company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of July 2, 2016 and January 2, 2016 the company held no non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0001437749-16-036614:notes:67]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of July 2, 2016 (in thousands):

[0001437749-16-036614:notes:68]
[same as prior period, unchanged from 0001437749-16-031011:notes:47]

[0001437749-16-036614:notes:69]
The company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt. The carrying amounts of cash and cash equivalents, short-term investments, accounts receivable, accounts payable and debt approximate their fair values. The company’s debt fair value approximates book value at July 2, 2016 and January 2, 2016, respectively, as the variable interest rates fluctuate along with market interest rates.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-16-036614:notes:70]
10

[0001437749-16-036614:notes:71]
. Income Taxes

[0001437749-16-036614:notes:72]
The effective tax rate for the second quarter of 2016 was 20.2% compared to an effective tax rate of 23.9% in the second quarter of 2015. The effective tax rate for the six months ended July 2, 2016 was 24.0% as compared to an effective tax rate of 24.1% for the six months ended June 27, 2015. The effective tax rates for all periods presented are lower than the U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions.


## us-gaap:InventoryDisclosureTextBlock

[0001437749-16-036614:notes:73]
5

[0001437749-16-036614:notes:74]
. Inventories

[0001437749-16-036614:notes:75]
The components of inventories at July 2, 2016 and January 2, 2016 are as follows (in thousands):

[0001437749-16-036614:notes:76]
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
| Raw material |  | $ | 37,738 |  |  | $ | 33,599 |  |
| Work in process |  |  | 24,978 |  |  |  | 16,479 |  |
| Finished goods |  |  | 61,984 |  |  |  | 48,551 |  |
| Total inventories |  | $ | 124,700 |  |  | $ | 98,629 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001437749-16-036614:notes:77]
. Acquisition of Businesses

[0001437749-16-036614:notes:78]
Menber’s

[0001437749-16-036614:notes:79]
On April 4, 2016, the company completed the acquisition of Menber’s S.p.A. (“Menber’s”) headquartered in Legnago, Italy for $18.7 million, after settlement of a working capital adjustment. At July 2, 2016, $17.8 million of the $18.7 million purchase price has been paid and financed through a mixture of

[0001437749-16-036614:notes:80]
cash on hand and borrowings under the company’s revolving credit facility,

[0001437749-16-036614:notes:81]
with the remaining consideration expected to be paid out in the remainder of 2016. The acquired business is part of the company's commercial vehicle product business within the Automotive segment, specializes in the design, manufacturing and selling of manual and electrical battery switches and trailer connectors for commercial vehicles.

[0001437749-16-036614:notes:82]
The following table represents the preliminary allocation of the total consideration to assets acquired and liabilities assumed in the acquisition of Menber’s based on the company’s preliminary estimate of their respective fair values at the acquisition date (in thousands):

[0001437749-16-036614:notes:83]
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 17,798 |  |
| Additional consideration payable |  |  | 919 |  |
| Total purchase consideration |  | $ | 18,717 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Cash |  | $ | 15 |  |
| Current assets, net |  |  | 13,287 |  |
| Property, plant and equipment |  |  | 1,558 |  |
| Customer relationships |  |  | 3,066 |  |
| Patented and unpatented technologies |  |  | 389 |  |
| Trademarks and tradenames |  |  | 1,849 |  |
| Goodwill |  |  | 7,364 |  |
| Current liabilities |  |  | (7,367 | ) |
| Other non-current liabilities |  |  | (1,444 | ) |
|  |  | $ | 18,717 |  |

[0001437749-16-036614:notes:84]
All Menber’s goodwill and other assets and liabilities were recorded in the Automotive segment and reflected in the Europe geographical area. The customer relationships are being amortized over 1

[0001437749-16-036614:notes:85]
0 years. The patented and unpatented technologies are being amortized over 5 years. The trademarks and tradenames are being amortized over 10 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining Menber’s products with the company’s existing automotive product portfolio. Goodwill for the above acquisition is not expected to be deductible for tax purposes.

[0001437749-16-036614:notes:86]
Included in the company’s consolidated statements of net income for the three months ended July 2, 2016 are net sales of approximately $6.8 million and income before income taxes of approximately $0.6 million since the April 4, 2016 acquisition of Menber’s

[0001437749-16-036614:notes:87]
The company incurred legal, professional and other costs related to this acquisition aggregating approximately $0.1 and $0.2 million for the three and six months ended July 2, 2016. These costs were recognized as selling, general and administrative expenses and reflected as other non-segment costs.

[0001437749-16-036614:notes:88]
[same as prior period, unchanged from 0001437749-16-031011:notes:55]

[0001437749-16-036614:notes:89]
On March 25, 2016, the company acquired 100% of the circuit protection business (“PolySwitch”) of TE Connectivity Ltd. for $350.0 million, subject to certain post-closing adjustments. The PolySwitch business, which is split between the Automotive and Electronics segments,

[0001437749-16-036614:notes:90]
has a leading position in polymer based resettable circuit protection devices, with a strong global presence in the automotive, battery, industrial, communications and mobile computing markets. PolySwitch has operations in Menlo Park, California and manufacturing facilities in Shanghai and Kunshan, China and Tsukuba, Japan. The acquisition allows the company to strengthen its global circuit protection product portfolio, as well as strengthen its presence in the automotive electronics and battery end markets. The acquisition also significantly increases the company’s presence in Japan. The company funded the acquisition with available cash and proceeds from a new credit facility

[0001437749-16-036614:notes:91]
The following table represents the preliminary allocation of the total consideration to assets acquired and liabilities assumed in the acquisition of PolySwitch based on the company’s preliminary estimate of their respective fair values at the acquisition date (in thousands):

[0001437749-16-036614:notes:92]
| Total purchase consideration |  | $ | 350,000 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Cash |  | $ | 16,958 |  |
| Other current assets, net |  |  | 57,114 |  |
| Property, plant and equipment |  |  | 57,042 |  |
| Patented and unpatented technologies |  |  | 56,425 |  |
| Customer relationships |  |  | 39,720 |  |
| Goodwill |  |  | 165,797 |  |
| Other long-term assets |  |  | 15,899 |  |
| Current liabilities |  |  | (53,389 | ) |
| Other non-current liabilities |  |  | (5,566 | ) |
|  |  | $ | 350,000 |  |

[0001437749-16-036614:notes:93]
All PolySwitch goodwill and other assets and liabilities were recorded in the Automotive and Electronics segments and reflected in all geographic areas. The customer relationships are being amortized over 15 years. The patented and unpatented technologies are being amortized over 10 years. The goodwill resulting from this acquisition consists largely of the company’s expected future product sales and synergies from combining PolySwitch products with the company’s existing automotive and electronics product portfolio. A portion of the goodwill for the above acquisition is expected to be deductible for tax purposes.

[0001437749-16-036614:notes:94]
As required by purchase accounting rules, the company recorded a $6.9 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of goods sold during the second quarter of 2016, as the acquired inventory was sold, and reflected as other non-segment costs.

[0001437749-16-036614:notes:95]
Included in the company’s consolidated statements of net income for the three months ended July 2, 2016 are net sales of approximately $36.4 million and a loss before income taxes of approximately $9.1 million since the March 25, 2016 acquisition of PolySwitch.

[0001437749-16-036614:notes:96]
The company incurred legal, professional and other costs related to this acquisition aggregating approximately $5.7 million and $11.6 million for the three and six months ended July 2, 2016, respectively. Of these costs, approximately $0.9 million were recognized as cost of goods sold during the second quarter and the remainder of the costs both periods were recognized as selling, general and administrative expenses. All of these costs were reflected as other non-segment costs.

[0001437749-16-036614:notes:97]
[same as prior period, unchanged from 0001437749-16-031011:notes:65]

[0001437749-16-036614:notes:98]
On October 1, 2015, the company acquired 100% of Sigmar S.r.l. (“Sigmar”). The total purchase price for Sigmar is expected to be $6.7 million, net of cash acquired and including: (1) additional consideration of $1.1 million paid in the first six months of 2016 relating to certain working capital related adjustments and an earn-out clause payment; and (2) estimated additional net payments of up to $0.8 million, a portion of which is subject to the achievement of certain milestones.

[0001437749-16-036614:notes:99]
Located in Ozegna, Italy, Sigmar is a leading global manufacturer of water-in-fuel sensors and also manufactures selective catalytic reduction (SCR) quality sensors, diesel fuel heaters and rotating oil filters for automotive and commercial vehicle applications. The acquisition further expanded the company’s automotive sensor product line offerings within its Automotive segment. The company funded the acquisition with available cash.

[0001437749-16-036614:notes:100]
The following table sets forth the preliminary purchase price allocation for Sigmar acquisition-date net assets, in accordance with the purchase method of accounting with adjustments to record the acquired net assets at their estimated fair values (in thousands):

[0001437749-16-036614:notes:101]
| Total purchase consideration: |  |  |  |  |
| Cash |  | $ | 5,845 |  |
| Estimated additional consideration payable |  |  | 844 |  |
| Total purchase consideration |  | $ | 6,689 |  |
| Preliminary allocation of consideration to assets acquired and liabilities assumed: |  |  |  |  |
| Cash |  | $ | 230 |  |
| Current assets, net |  |  | 4,011 |  |
| Property, plant and equipment |  |  | 1,097 |  |
| Goodwill |  |  | 2,552 |  |
| Patents |  |  | 2,845 |  |
| Current liabilities |  |  | (1,478 | ) |
| Other non-current liabilities |  |  | (2,568 | ) |
|  |  | $ | 6,689 |  |

[0001437749-16-036614:notes:102]
[same as prior period, unchanged from 0001437749-16-031011:notes:70]

[0001437749-16-036614:notes:103]
[same as prior period, unchanged from 0001437749-16-031011:notes:71]

[0001437749-16-036614:notes:104]
The following table summarizes, on a pro forma basis, the combined results of operations of the company and PolySwitch as though the acquisition had occurred as of December 28, 2014. The company has not provided pro forma results of operations for Menber’s or Sigmar as these results were not material to the company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the PolySwitch acquisition occurred as of December 28, 2014 or of future consolidated operating results

[0001437749-16-036614:notes:105]
[same as prior period, unchanged from 0001437749-16-031011:notes:73]

[0001437749-16-036614:notes:106]
The historical PolySwitch results for the three and six months ended July 2, 2016 and June 27, 2015 do not include a provision for income taxes. Income tax expense for the historical PolySwitch business was only provided at the end of the business’s fiscal year ended September 25, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-16-036614:notes:107]
. Pensions

[0001437749-16-036614:notes:108]
The components of net periodic benefit cost for the three and six months ended July 2, 2016, compared with the three and six months ended June 27, 2015, were (in thousands):

[0001437749-16-036614:notes:109]
|  |  | U.S. Pension Benefits |  |  | Foreign Plans |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| Service cost |  | $ | - |  |  | $ | 250 |  |  | $ | - |  |  | $ | 500 |  |  | $ | 333 |  |  | $ | 315 |  |  | $ | 665 |  |  | $ | 630 |  |
| Interest cost |  |  | - |  |  |  | 1,031 |  |  |  | - |  |  |  | 2,062 |  |  |  | 496 |  |  |  | 513 |  |  |  | 993 |  |  |  | 1,026 |  |
| Expected return on plan assetsassets |  |  | - |  |  |  | (916 | ) |  |  | - |  |  |  | (1,832 | ) |  |  | (520 | ) |  |  | (601 | ) |  |  | (1,040 | ) |  |  | (1,201 | ) |
| Amortization of net loss |  |  | - |  |  |  | 290 |  |  |  | - |  |  |  | 580 |  |  |  | 73 |  |  |  | 62 |  |  |  | 146 |  |  |  | 123 |  |
| Total cost (credit) of the plan |  |  | - |  |  |  | 655 |  |  |  | - |  |  |  | 1,310 |  |  |  | 382 |  |  |  | 289 |  |  |  | 764 |  |  |  | 578 |  |
| Expected plan participants’ contribution |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net periodic benefit cost (credit) |  | $ | - |  |  | $ | 655 |  |  | $ | - |  |  | $ | 1,310 |  |  | $ | 382 |  |  | $ | 289 |  |  | $ | 764 |  |  | $ | 578 |  |

[0001437749-16-036614:notes:110]
* The U.S. pension plan was terminated effective July 30, 2014 and, following receipt of a favorable Letter of Determination from the IRS (dated April 14, 2015), all liabilities of the plan were settled during the third quarter of fiscal 2015.

[0001437749-16-036614:notes:111]
The expected rate of return assumption on U.S. pension assets was 3.90% in 2015. The expected return on foreign pension assets is 4.95% and 5.39% in 2016 and 2015, respectively.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001437749-16-036614:notes:112]
|  |  | Long-lived assets(b) |  |
|  |  | July 2, 2016 |  |  | January 2, 2016 |  |
| United States |  | $ | 23,985 |  |  | $ | 23,965 |  |
| China |  |  | 70,325 |  |  |  | 37,241 |  |
| Canada |  |  | 10,925 |  |  |  | 10,488 |  |
| Other countries |  |  | 119,275 |  |  |  | 90,874 |  |
| Total |  | $ | 224,510 |  |  | $ | 162,568 |  |

[0001437749-16-036614:notes:113]
|  |  | Additions to long-lived assets |  |
|  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| United States |  | $ | 2,783 |  |  | $ | 6,615 |  |
| China |  |  | 3,847 |  |  |  | 4,080 |  |
| Canada |  |  | 137 |  |  |  | 878 |  |
| Other countries |  |  | 13,450 |  |  |  | 14,815 |  |
| Total |  | $ | 20,217 |  |  | $ | 26,388 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001437749-16-036614:notes:114]
|  |  | For the Three Months Ended(a) |  |  | For the Six Months Ended(a) |  |
|  |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| United States |  | $ | 93,036 |  |  | $ | 89,608 |  |  | $ | 178,184 |  |  | $ | 172,981 |  |
| China |  |  | 62,411 |  |  |  | 49,920 |  |  |  | 110,919 |  |  |  | 94,349 |  |
| Other countries |  |  | 116,465 |  |  |  | 82,493 |  |  |  | 202,207 |  |  |  | 165,004 |  |
| Total |  | $ | 271,912 |  |  | $ | 222,021 |  |  | $ | 491,310 |  |  | $ | 432,334 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-16-036614:notes:115]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | July 2, 2016 |  |  | June 27, 2015 |  |  | July 2, 2016 |  |  | June 27, 2015 |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 132,170 |  |  | $ | 105,553 |  |  | $ | 230,966 |  |  | $ | 204,933 |  |
| Automotive |  |  | 111,370 |  |  |  | 85,918 |  |  |  | 203,303 |  |  |  | 169,989 |  |
| Industrial |  |  | 28,372 |  |  |  | 30,550 |  |  |  | 57,041 |  |  |  | 57,412 |  |
| Total net sales |  | $ | 271,912 |  |  | $ | 222,021 |  |  | $ | 491,310 |  |  | $ | 432,334 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 7,717 |  |  | $ | 5,775 |  |  | $ | 13,089 |  |  | $ | 11,573 |  |
| Automotive |  |  | 4,988 |  |  |  | 3,303 |  |  |  | 8,254 |  |  |  | 6,639 |  |
| Industrial |  |  | 1,376 |  |  |  | 1,295 |  |  |  | 2,828 |  |  |  | 2,579 |  |
| Other(1) |  |  | - |  |  |  | - |  |  |  | 937 |  |  |  | - |  |
| Total depreciation and amortization |  | $ | 14,081 |  |  | $ | 10,373 |  |  | $ | 25,108 |  |  | $ | 20,791 |  |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 25,259 |  |  | $ | 22,167 |  |  | $ | 47,675 |  |  | $ | 40,832 |  |
| Automotive |  |  | 16,474 |  |  |  | 12,699 |  |  |  | 33,965 |  |  |  | 23,870 |  |
| Industrial |  |  | 2,028 |  |  |  | 4,709 |  |  |  | 3,701 |  |  |  | 7,439 |  |
| Other(2) |  |  | (14,059 | ) |  |  | (3,404 | ) |  |  | (23,211 | ) |  |  | (6,422 | ) |
| Total operating income |  |  | 29,702 |  |  |  | 36,171 |  |  |  | 62,130 |  |  |  | 65,719 |  |
| Interest expense |  |  | 1,670 |  |  |  | 948 |  |  |  | 3,715 |  |  |  | 2,099 |  |
| Foreign exchange (gain) loss |  |  | (6,237 | ) |  |  | (1,292 | ) |  |  | (2,414 | ) |  |  | 1,825 |  |
| Other (income) expense, net |  |  | 255 |  |  |  | (1,202 | ) |  |  | (262 | ) |  |  | (2,328 | ) |
| Income before income taxes |  | $ | 34,014 |  |  | $ | 37,717 |  |  | $ | 61,091 |  |  | $ | 64,123 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-16-036614:notes:116]
2

[0001437749-16-036614:notes:117]
. Segment and Geographic Information

[0001437749-16-036614:notes:118]
The company and its subsidiaries design, manufacture and sell components and modules for circuit protection, power control and sensing throughout the world. The company reports its operations by the following segments: Electronics, Automotive, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information.

[0001437749-16-036614:notes:119]
Sales, marketing and research and development expenses are charged directly into each operating segment. Manufacturing, purchasing, logistics, customer service, finance, information technology and human resources are shared functions that are allocated back to the three operating segments. The company does not report inter-segment revenue because the operating segments do not record it.

[0001437749-16-036614:notes:120]
Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as

[0001437749-16-036614:notes:121]
“

[0001437749-16-036614:notes:122]
Other

[0001437749-16-036614:notes:123]
”

[0001437749-16-036614:notes:124]
Additionally, the company does not allocate interest and other income, interest expense, or taxes to operating segments.

[0001437749-16-036614:notes:125]
These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments.

[0001437749-16-036614:notes:126]
Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the company as a whole.

[0001437749-16-036614:notes:127]
Segment information for the three and six months ended July 2, 2016 and June 27, 2015 are summarized “as follows (in thousands):

[0001437749-16-036614:notes:128]
(1) Consists of intangible impairments. (See Note 14).

[0001437749-16-036614:notes:129]
(2) Included in “Other” Operating income (loss) for the 2016 second quarter is $6.1 million ($12.3 million year-to-date) of acquisition-related costs primarily related to legal and integration costs associated with the company’s acquisition of the PolySwitch business, a $6.9 million ($6.9 million year-to-date) inventory adjustment relating to the PolySwitch acquisition as described in Note 4, $0.3 million ($1.9 million year-to-date) in charges related to the closure of the company’s manufacturing facility in Denmark, $0.7 million ($1.7 million year-to-date) related to the company’s transfer of its reed sensor manufacturing operations from the U.S. and China to the Philippines and $0.1 million ($0.4 million year-to-date) related to internal legal restructuring costs.

[0001437749-16-036614:notes:130]
Included in “Other” Operating income (loss) for the 2015 second quarter is $0.9 million ($1.9 million year-to-date) of costs related to the company’s transfer of its reed sensor manufacturing from the U.S. to the Philippines, $1.7 million ($2.9 million year-to-date) related to internal legal restructuring, $0.2 million ($0.3 million year-to-date) related to acquisition costs and $0.7 million ($1.3 million year-to-date) of expense related to the planned termination of the U.S. pension as described in Note 11

[0001437749-16-036614:notes:131]
The company’s significant net sales by country for the three and six months ended July 2, 2016 and June 27, 2015 are summarized as follows (in thousands):

[0001437749-16-036614:notes:132]
[same as prior period, unchanged from 0001437749-16-031011:notes:92]

[0001437749-16-036614:notes:133]
The company’s significant long-lived assets by country as of July 2, 2016 and January 2, 2016 are summarized as follows (in thousands):

[0001437749-16-036614:notes:134]
[same as prior period, unchanged from 0001437749-16-031011:notes:94]

[0001437749-16-036614:notes:135]
The company’s significant additions to long-lived assets by country for the six months ended July 2, 2016 and June 27, 2015 are summarized as follows (in thousands):


## us-gaap:SubsequentEventsTextBlock

[0001437749-16-036614:notes:136]
. Subsequent

[0001437749-16-036614:notes:137]
E

[0001437749-16-036614:notes:138]
vent

[0001437749-16-036614:notes:139]
None.
