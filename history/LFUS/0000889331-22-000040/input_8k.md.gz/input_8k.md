# LFUS 8-K — 0000889331-22-000037 filed 2022-08-02

## item codes, every 8-K on or before 2022-08-03

- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2022-08-03

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-22-000037:8k_2_02:1]
EX-99.1
2
q22022earningsreleaseex991.htm
EX-99.1

[0000889331-22-000037:8k_2_02:2]
Document

[0000889331-22-000037:8k_2_02:3]
Exhibit 99.1

[0000889331-22-000037:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-22-000037:8k_2_02:5]
LITTELFUSE REPORTS SECOND QUARTER RESULTS FOR 2022

[0000889331-22-000037:8k_2_02:6]
Global business execution delivers strong financial performance

[0000889331-22-000037:8k_2_02:7]
CHICAGO, August 2, 2022  - Littelfuse, Inc. (NASDAQ: LFUS), an industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the second quarter ended July 2, 2022:

[0000889331-22-000037:8k_2_02:8]
•Net sales of $618.4 million were up 18% versus the prior year period, and up 10% organically

[0000889331-22-000037:8k_2_02:9]
•GAAP diluted EPS was $3.48; adjusted diluted EPS was $4.26, up 25% versus the prior year period

[0000889331-22-000037:8k_2_02:10]
•Cash flow from operations was $113.6 million and free cash flow was $87.2 million

[0000889331-22-000037:8k_2_02:11]
•On July 19, the company completed its acquisition of C&K Switches

[0000889331-22-000037:8k_2_02:12]
•The company’s Board of Directors approved a 13% increase in the quarterly cash dividend from $0.53 to

[0000889331-22-000037:8k_2_02:13]
$0.60; this equates to an annualized dividend of $2.40 per share

[0000889331-22-000037:8k_2_02:14]
“We delivered very strong second quarter results above our expectations while continuing to advance our strategic initiatives,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “Our record performance to date in 2022 is a testament to our global teams’ execution across the breadth of our end markets. I am also excited to welcome C&K to our organization which significantly expands our ability to serve customers with market leading technologies, capabilities and talent. Looking ahead, we remain focused on effectively managing our business through market volatility while securing growth opportunities driven by sustainability, connectivity, and safety, which will deliver long-term value to our stakeholders.”

[0000889331-22-000037:8k_2_02:15]
Third Quarter of 2022*

[0000889331-22-000037:8k_2_02:16]
Based on current market conditions, for the third quarter the company expects,

[0000889331-22-000037:8k_2_02:17]
•Net sales in the range of $630 to $644 million; adjusted diluted EPS in the range of $3.71 to $3.87

[0000889331-22-000037:8k_2_02:18]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-22-000037:8k_2_02:19]
-more-

[0000889331-22-000037:8k_2_02:20]
Dividend

[0000889331-22-000037:8k_2_02:21]
•The company will pay a cash dividend on its common stock of $0.60 per share on September 8, 2022, to

[0000889331-22-000037:8k_2_02:22]
shareholders of record as of August 25, 2022

[0000889331-22-000037:8k_2_02:23]
Conference Call and Webcast Information

[0000889331-22-000037:8k_2_02:24]
Littelfuse will host a conference call on Wednesday, August 3, 2022, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at  Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-22-000037:8k_2_02:25]
About Littelfuse

[0000889331-22-000037:8k_2_02:26]
Littelfuse (NASDAQ: LFUS) is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 15 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-22-000037:8k_2_02:27]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse's accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended January 1, 2022.

[0000889331-22-000037:8k_2_02:28]
-more

[0000889331-22-000037:8k_2_02:29]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended January 1, 2022, its Quarterly Report on Form 10-Q for the quarter ended April 2, 2022, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-22-000037:8k_2_02:30]
Non-GAAP Financial Measures

[0000889331-22-000037:8k_2_02:31]
The information included in this press release includes the non-GAAP financial measures of organic net sales growth (decline), adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-22-000037:8k_2_02:32]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-22-000037:8k_2_02:33]
The company believes that organic net sales growth (decline), adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-22-000037:8k_2_02:34]
CONTACT: Trisha Tuntland

[0000889331-22-000037:8k_2_02:35]
Head of Investor Relations

[0000889331-22-000037:8k_2_02:36]
(773) 628-2163

[0000889331-22-000037:8k_2_02:37]
LFUS-F

[0000889331-22-000037:8k_2_02:38]
###

[0000889331-22-000037:8k_2_02:39]
LITTELFUSE, INC.

[0000889331-22-000037:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-22-000037:8k_2_02:41]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | July 2,2022 |  | January 1,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 809,122 |  |  | $ | 478,473 |  |
| Short-term investments |  | 20 |  |  | 28 |  |
| Trade receivables, less allowances of $68,933 and $59,232 at July 2, 2022 and January 1, 2022, respectively |  | 343,321 |  |  | 275,192 |  |
| Inventories |  | 496,207 |  |  | 445,671 |  |
| Prepaid income taxes and income taxes receivable |  | 4,861 |  |  | 2,035 |  |
| Prepaid expenses and other current assets |  | 65,294 |  |  | 68,812 |  |
| Total current assets |  | 1,718,825 |  |  | 1,270,211 |  |
| Net property, plant, and equipment |  | 435,683 |  |  | 437,889 |  |
| Intangible assets, net of amortization |  | 374,593 |  |  | 407,126 |  |
| Goodwill |  | 914,358 |  |  | 929,790 |  |
| Investments |  | 25,626 |  |  | 39,211 |  |
| Deferred income taxes |  | 12,476 |  |  | 13,127 |  |
| Right of use lease assets, net |  | 39,724 |  |  | 29,616 |  |
| Other long-term assets |  | 23,184 |  |  | 24,734 |  |
| Total assets |  | $ | 3,544,469 |  |  | $ | 3,151,704 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 219,764 |  |  | $ | 222,039 |  |
| Accrued liabilities |  | 137,377 |  |  | 159,689 |  |
| Accrued income taxes |  | 34,128 |  |  | 27,905 |  |
| Current portion of long-term debt |  | 7,500 |  |  | 25,000 |  |
| Total current liabilities |  | 398,769 |  |  | 434,633 |  |
| Long-term debt, less current portion |  | 884,569 |  |  | 611,897 |  |
| Deferred income taxes |  | 74,286 |  |  | 81,289 |  |
| Accrued post-retirement benefits |  | 35,090 |  |  | 37,037 |  |
| Non-current operating lease liabilities |  | 32,334 |  |  | 22,305 |  |
| Other long-term liabilities |  | 67,478 |  |  | 71,023 |  |
| Total equity |  | 2,051,943 |  |  | 1,893,520 |  |
| Total liabilities and equity |  | $ | 3,544,469 |  |  | $ | 3,151,704 |  |

[0000889331-22-000037:8k_2_02:42]
LITTELFUSE, INC.

[0000889331-22-000037:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-22-000037:8k_2_02:44]
(Unaudited)

[0000889331-22-000037:8k_2_02:45]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) |  | July 2,2022 |  | June 26,2021 |  | July 2,2022 |  | June 26,2021 |
| Net sales |  | $ | 618,436 |  |  | $ | 523,488 |  |  | $ | 1,241,766 |  |  | $ | 987,282 |  |
| Cost of sales |  | 355,465 |  |  | 326,092 |  |  | 720,199 |  |  | 629,420 |  |
| Gross profit |  | 262,971 |  |  | 197,396 |  |  | 521,567 |  |  | 357,862 |  |
| Selling, general, and administrative expenses |  | 93,093 |  |  | 73,315 |  |  | 168,601 |  |  | 131,603 |  |
| Research and development expenses |  | 23,488 |  |  | 16,394 |  |  | 43,044 |  |  | 31,133 |  |
| Amortization of intangibles |  | 11,592 |  |  | 10,641 |  |  | 24,316 |  |  | 21,162 |  |
| Restructuring, impairment, and other charges |  | 634 |  |  | 789 |  |  | 852 |  |  | 1,226 |  |
| Total operating expenses |  | 128,807 |  |  | 101,139 |  |  | 236,813 |  |  | 185,124 |  |
| Operating income |  | 134,164 |  |  | 96,257 |  |  | 284,754 |  |  | 172,738 |  |
| Interest expense |  | 4,368 |  |  | 4,626 |  |  | 8,670 |  |  | 9,299 |  |
| Foreign exchange loss (gain) |  | 14,124 |  |  | (1,676) |  |  | 21,860 |  |  | 5,161 |  |
| Other expense (income), net |  | 6,060 |  |  | (1,890) |  |  | 10,487 |  |  | (9,627) |  |
| Income before income taxes |  | 109,612 |  |  | 95,197 |  |  | 243,737 |  |  | 167,905 |  |
| Income taxes |  | 22,596 |  |  | 13,102 |  |  | 39,203 |  |  | 28,097 |  |
| Net income |  | $ | 87,016 |  |  | $ | 82,095 |  |  | $ | 204,534 |  |  | $ | 139,808 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.52 |  |  | $ | 3.34 |  |  | $ | 8.28 |  |  | $ | 5.69 |  |
| Diluted |  | $ | 3.48 |  |  | $ | 3.30 |  |  | $ | 8.19 |  |  | $ | 5.62 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,734 |  |  | 24,592 |  |  | 24,712 |  |  | 24,562 |  |
| Diluted |  | 24,985 |  |  | 24,900 |  |  | 24,986 |  |  | 24,894 |  |
| Comprehensive income |  | $ | 55,667 |  |  | $ | 87,549 |  |  | $ | 170,982 |  |  | $ | 140,391 |  |

[0000889331-22-000037:8k_2_02:46]
LITTELFUSE, INC.

[0000889331-22-000037:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-22-000037:8k_2_02:48]
(Unaudited)

[0000889331-22-000037:8k_2_02:49]
|  |  | Six Months Ended |
| (in thousands) |  | July 2, 2022 |  | June 26, 2021 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 204,534 |  |  | $ | 139,808 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 114,659 |  |  | 63,947 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (76,807) |  |  | (69,881) |  |
| Inventories |  | (70,285) |  |  | (38,205) |  |
| Accounts payable |  | 9,153 |  |  | 38,955 |  |
| Accrued liabilities and income taxes |  | (23,107) |  |  | 4,488 |  |
| Prepaid expenses and other assets |  | 7,175 |  |  | (12,766) |  |
| Net cash provided by operating activities |  | 165,322 |  |  | 126,346 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (9,758) |  |  | (109,852) |  |
| Purchases of property, plant, and equipment |  | (56,151) |  |  | (32,657) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 542 |  |  | 2,569 |  |
| Net cash used in investing activities |  | (65,367) |  |  | (139,940) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net proceeds (payments) from credit facility |  | 275,000 |  |  | (30,000) |  |
| Cash dividends paid |  | (26,201) |  |  | (23,596) |  |
| All other cash provided by financing activities |  | (3,782) |  |  | 4,413 |  |
| Net cash provided by (used in) financing activities |  | 245,017 |  |  | (49,183) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (15,511) |  |  | (2,894) |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 329,461 |  |  | (65,671) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 482,836 |  |  | 687,525 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 812,297 |  |  | $ | 621,854 |  |

[0000889331-22-000037:8k_2_02:50]
LITTELFUSE, INC.

[0000889331-22-000037:8k_2_02:51]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-22-000037:8k_2_02:52]
(Unaudited)

[0000889331-22-000037:8k_2_02:53]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2022 |  | 2021 |  |  |  | %Growth /(Decline) |  | 2022 |  | 2021 |  |  |  | %Growth |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 358,176 |  |  | $ | 325,347 |  |  |  |  | 10.1 | % |  | $ | 723,997 |  |  | $ | 611,882 |  |  |  |  | 18.3 | % |
| Transportation |  | 182,027 |  |  | 133,318 |  |  |  |  | 36.5 | % |  | 366,531 |  |  | 261,847 |  |  |  |  | 40.0 | % |
| Industrial |  | 78,233 |  |  | 64,823 |  |  |  |  | 20.7 | % |  | 151,238 |  |  | 113,553 |  |  |  |  | 33.2 | % |
| Total net sales |  | $ | 618,436 |  |  | $ | 523,488 |  |  |  |  | 18.1 | % |  | $ | 1,241,766 |  |  | $ | 987,282 |  |  |  |  | 25.8 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 105,958 |  |  | $ | 74,236 |  |  |  |  | 42.7 | % |  | $ | 226,535 |  |  | $ | 129,759 |  |  |  |  | 74.6 | % |
| Transportation |  | 18,309 |  |  | 19,258 |  |  |  |  | (4.9) | % |  | 44,617 |  |  | 39,574 |  |  |  |  | 12.7 | % |
| Industrial |  | 15,285 |  |  | 8,375 |  |  |  |  | 82.5 | % |  | 27,790 |  |  | 11,881 |  |  |  |  | 133.9 | % |
| Other(a) |  | (5,388) |  |  | (5,612) |  |  |  |  | N.M. |  | (14,188) |  |  | (8,476) |  |  |  |  | N.M. |
| Total operating income |  | $ | 134,164 |  |  | $ | 96,257 |  |  |  |  | 39.4 | % |  | $ | 284,754 |  |  | $ | 172,738 |  |  |  |  | 64.8 | % |
| Operating Margin |  | 21.7 | % |  | 18.4 | % |  |  |  |  |  | 22.9 | % |  | 17.5 | % |  |  |  |  |
| Interest expense |  | 4,368 |  |  | 4,626 |  |  |  |  |  |  | 8,670 |  |  | 9,299 |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 14,124 |  |  | (1,676) |  |  |  |  |  |  | 21,860 |  |  | 5,161 |  |  |  |  |  |
| Other expense (income), net |  | 6,060 |  |  | (1,890) |  |  |  |  |  |  | 10,487 |  |  | (9,627) |  |  |  |  |  |
| Income before income taxes |  | $ | 109,612 |  |  | $ | 95,197 |  |  |  |  | 15.1 | % |  | $ | 243,737 |  |  | $ | 167,905 |  |  |  |  | 45.2 | % |

[0000889331-22-000037:8k_2_02:54]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-22-000037:8k_2_02:55]
N.M. - Not meaningful

[0000889331-22-000037:8k_2_02:56]
|  |  | Second Quarter |  | Year-to-Date |
| (in thousands) |  | 2022 |  | 2021 |  | %Growth /(Decline) |  | 2022 |  | 2021 |  | %Growth /(Decline) |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 29.6 | % |  | 22.8 | % |  | 6.8 | % |  | 31.3 | % |  | 21.2 | % |  | 10.1 | % |
| Transportation |  | 10.1 | % |  | 14.4 | % |  | (4.3) | % |  | 12.2 | % |  | 15.1 | % |  | (2.9) | % |
| Industrial |  | 19.5 | % |  | 12.9 | % |  | 6.6 | % |  | 18.4 | % |  | 10.5 | % |  | 7.9 | % |

[0000889331-22-000037:8k_2_02:57]
LITTELFUSE, INC.

[0000889331-22-000037:8k_2_02:58]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-22-000037:8k_2_02:59]
(In millions of USD except per share amounts - unaudited)

[0000889331-22-000037:8k_2_02:60]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-22 |  | Q2-21 |  | YTD-22 |  | YTD-21 |
| GAAP diluted EPS |  | $ | 3.48 |  |  | $ | 3.30 |  |  | $ | 8.19 |  |  | $ | 5.62 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.78 |  |  | 0.11 |  |  | 1.06 |  |  | 0.46 |  |
| Adjusted diluted EPS |  | $ | 4.26 |  |  | $ | 3.41 |  |  | $ | 9.25 |  |  | $ | 6.08 |  |

[0000889331-22-000037:8k_2_02:61]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q2-22 |  | Q2-21 |  | YTD-22 |  | YTD-21 |
| Acquisition-related and integration costs (a) |  | $ | 4.8 |  |  | $ | 0.5 |  |  | $ | 8.6 |  |  | $ | 1.3 |  |
| Purchase accounting inventory adjustments (b) |  | — |  |  | 3.3 |  |  | 4.8 |  |  | 6.8 |  |
| Restructuring, impairment and other charges (c) |  | 0.6 |  |  | 0.8 |  |  | 0.8 |  |  | 1.3 |  |
| Loss (gain) on sale of fixed assets (d) |  | — |  |  | 1.0 |  |  | — |  |  | (0.9) |  |
| Non-GAAP adjustments to operating income |  | 5.4 |  |  | 5.6 |  |  | 14.2 |  |  | 8.5 |  |
| Other (income) expense, net (e) |  | (0.5) |  |  | 0.5 |  |  | (0.5) |  |  | 0.5 |  |
| Non-operating foreign exchange loss (gain) |  | 14.1 |  |  | (1.7) |  |  | 21.9 |  |  | 5.2 |  |
| Non-GAAP adjustments to income before income taxes |  | 19.0 |  |  | 4.4 |  |  | 35.6 |  |  | 14.2 |  |
| Income taxes (f) |  | (0.4) |  |  | 1.7 |  |  | 9.1 |  |  | 2.5 |  |
| Non-GAAP adjustments to net income |  | $ | 19.4 |  |  | $ | 2.7 |  |  | $ | 26.5 |  |  | $ | 11.7 |  |
| Total EPS impact |  | $ | 0.78 |  |  | $ | 0.11 |  |  | $ | 1.06 |  |  | $ | 0.46 |  |

[0000889331-22-000037:8k_2_02:62]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-22 |  | Q2-21 |  | YTD-22 |  | YTD-21 |
| Net sales |  | $ | 618.4 |  |  | $ | 523.5 |  |  | $ | 1,241.8 |  |  | $ | 987.3 |  |
| GAAP operating income |  | $ | 134.2 |  |  | $ | 96.3 |  |  | $ | 284.8 |  |  | $ | 172.7 |  |
| Add back non-GAAP adjustments |  | 5.4 |  |  | 5.6 |  |  | 14.2 |  |  | 8.5 |  |
| Adjusted operating income |  | $ | 139.6 |  |  | $ | 101.9 |  |  | $ | 299.0 |  |  | $ | 181.2 |  |
| Adjusted operating margin |  | 22.6 | % |  | 19.5 | % |  | 24.1 | % |  | 18.4 | % |
| Add back amortization |  | 11.6 |  |  | 10.6 |  |  | 24.3 |  |  | 21.2 |  |
| Add back depreciation |  | 15.7 |  |  | 13.6 |  |  | 31.3 |  |  | 27.3 |  |
| Adjusted EBITDA |  | $ | 166.9 |  |  | $ | 126.1 |  |  | $ | 354.6 |  |  | $ | 229.7 |  |
| Adjusted EBITDA margin |  | 27.0 | % |  | 24.1 | % |  | 28.6 | % |  | 23.3 | % |

[0000889331-22-000037:8k_2_02:63]
| Adjusted EBITDA by Segment |  | Q2-22 |  | Q2-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 106.0 |  |  | $ | 18.3 |  |  | $ | 15.3 |  |  | $ | 74.2 |  |  | $ | 19.3 |  |  | $ | 8.4 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 6.1 |  |  | 4.3 |  |  | 1.2 |  |  | 7.0 |  |  | 2.3 |  |  | 1.3 |  |
| Add back depreciation |  | 8.4 |  |  | 6.3 |  |  | 1.0 |  |  | 8.1 |  |  | 4.6 |  |  | 0.9 |  |
| Adjusted EBITDA |  | $ | 120.5 |  |  | $ | 28.9 |  |  | $ | 17.5 |  |  | $ | 89.3 |  |  | $ | 26.2 |  |  | $ | 10.6 |  |
| Adjusted EBITDA Margin |  | 33.6 | % |  | 15.9 | % |  | 22.3 | % |  | 27.5 | % |  | 19.7 | % |  | 16.2 | % |

[0000889331-22-000037:8k_2_02:64]
| Adjusted EBITDA by Segment |  | YTD-22 |  | YTD-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 226.5 |  |  | $ | 44.6 |  |  | $ | 27.8 |  |  | $ | 129.8 |  |  | $ | 39.6 |  |  | $ | 11.9 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 12.8 |  |  | 9.0 |  |  | 2.5 |  |  | $ | 14.2 |  |  | $ | 4.7 |  |  | $ | 2.3 |  |
| Add back depreciation |  | 17.1 |  |  | 12.3 |  |  | 1.9 |  |  | $ | 16.3 |  |  | $ | 9.3 |  |  | $ | 1.6 |  |
| Adjusted EBITDA |  | $ | 256.4 |  |  | $ | 65.9 |  |  | $ | 32.2 |  |  | $ | 160.3 |  |  | $ | 53.6 |  |  | $ | 15.8 |  |
| Adjusted EBITDA Margin |  | 35.4 | % |  | 18.0 | % |  | 21.3 | % |  | 26.2 | % |  | 20.5 | % |  | 13.9 | % |

[0000889331-22-000037:8k_2_02:65]
| Net sales reconciliation |  | Q2-22 vs. Q2-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 10 | % |  | 37 | % |  | 21 | % |  | 18 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | 45 | % |  | — | % |  | 11 | % |
| FX impact |  | (3) | % |  | (4) | % |  | (1) | % |  | (3) | % |
| Organic net sales growth (decline) |  | 13 | % |  | (4) | % |  | 22 | % |  | 10 | % |

[0000889331-22-000037:8k_2_02:66]
| Net sales reconciliation |  | YTD-22 vs. YTD-21 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 18 | % |  | 40 | % |  | 33 | % |  | 26 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | — | % |  | 44 | % |  | 8 | % |  | 13 | % |
| FX impact |  | (3) | % |  | (4) | % |  | (1) | % |  | (3) | % |
| Organic net sales growth |  | 21 | % |  | — | % |  | 26 | % |  | 16 | % |

[0000889331-22-000037:8k_2_02:67]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-22 |  | Q2-21 |  | YTD-22 |  | YTD-21 |
| Income taxes |  | $ | 22.6 |  |  | $ | 13.1 |  |  | $ | 39.2 |  |  | $ | 28.1 |  |
| Effective rate |  | 20.6 | % |  | 13.8 | % |  | 16.1 | % |  | 16.7 | % |
| Non-GAAP adjustments - income taxes |  | (0.4) |  |  | 1.7 |  |  | 9.1 |  |  | 2.5 |  |
| Adjusted income taxes |  | $ | 22.2 |  |  | $ | 14.8 |  |  | $ | 48.3 |  |  | $ | 30.6 |  |
| Adjusted effective rate |  | 17.3 | % |  | 14.8 | % |  | 17.3 | % |  | 16.8 | % |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q2-22 |  | Q2-21 |  | YTD-22 |  | YTD-21 |
| Net cash provided by operating activities |  | $ | 113.6 |  |  | $ | 76.2 |  |  | $ | 165.3 |  |  | $ | 126.3 |  |
| Less: Purchases of property, plant and equipment |  | (26.4) |  |  | (17.9) |  |  | (56.2) |  |  | (32.6) |  |
| Free cash flow |  | $ | 87.2 |  |  | $ | 58.2 |  |  | $ | 109.1 |  |  | $ | 93.7 |  |

[0000889331-22-000037:8k_2_02:68]
| Consolidated Total Debt |  | As of July 2, 2022 |
| Consolidated Total Debt |  | $ | 892.1 |  |
| Unamortized debt issuance costs |  | 5.0 |  |
| Consolidated funded indebtedness |  | 897.1 |
| Cash held in U.S. (up to $400 million) |  | 400.0 |
| Net debt |  | $ | 497.1 |  |
| Consolidated EBITDA |  | Twelve Months Ended July 2, 2022 |
| Net Income |  | $ | 348.5 |  |
| Interest expense |  | 17.9 |  |
| Income taxes |  | 68.3 |  |
| Depreciation |  | 60.0 |  |
| Amortization |  | 45.9 |  |
| Non-cash additions (reductions): |  |  |
| Stock-based compensation expense |  | 22.6 |  |
| Non-cash pension settlement charge |  | 19.9 |  |
| Purchase accounting inventory step-up charge |  | 6.4 |  |
| Unrealized loss on investments |  | 12.5 |  |
| Impairment charges |  | — |  |
| Other |  | 62.4 |  |
| Consolidated EBITDA (1) |  | $ | 664.4 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 0.7x |

[0000889331-22-000037:8k_2_02:69]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2023 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-22-000037:8k_2_02:70]
The  Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the Netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-22-000037:8k_2_02:71]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-22-000037:8k_2_02:72]
Note: Total will not always foot due to rounding.

[0000889331-22-000037:8k_2_02:73]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-22-000037:8k_2_02:74]
(b) reflected in cost of sales.

[0000889331-22-000037:8k_2_02:75]
(c) reflected in restructuring, impairment and other charges.

[0000889331-22-000037:8k_2_02:76]
(d) reflected in SG&A, a loss of $1.0 million recorded during the second quarter of 2021 for a total year-to-date gain of $0.9 million from the sale of a building within the Electronics segment 2021.

[0000889331-22-000037:8k_2_02:77]
(e) 2022 amount included $0.5 million gain from the sale of a building within Transportation segment.  2021 amount included $0.5 million of impairment charges on certain other investments.

[0000889331-22-000037:8k_2_02:78]
(f) reflected the tax impact associated with the non-GAAP adjustments and the one-time net benefit of $7.2 million that resulted from the dissolution of one of the Company’s affiliates.

[0000889331-22-000037:8k_2_02:79]
###
