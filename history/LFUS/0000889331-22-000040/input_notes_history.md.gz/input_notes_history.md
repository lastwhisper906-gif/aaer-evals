# LFUS note change history — 0000889331-22-000022 → 0000889331-22-000040


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0000889331-22-000040:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 2, 2022 and June 26, 2021:
  (was, 2022-05-04, similarity 0.9118):
[0000889331-22-000022:note_history:1]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 2, 2022 and March 27, 2021:

- added (2022-08-03):
[0000889331-22-000040:note_history:2]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  | — |  |  | — |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- added (2022-08-03):
[0000889331-22-000040:note_history:3]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  |  |  |  |  | 64,823 |  |  | 64,823 |  |  |  |  |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- changed (2022-08-03):
[0000889331-22-000040:note_history:4]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on
  (was, 2022-05-04, similarity 0.9185):
[0000889331-22-000022:note_history:4]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2022-08-03):
[0000889331-22-000040:note_history:5]
historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- changed (2022-08-03):
[0000889331-22-000040:note_history:6]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at July 2, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2022-05-04, similarity 0.9352):
[0000889331-22-000022:note_history:6]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at April 2, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2022-08-03):
[0000889331-22-000040:note_history:7]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Cash and cash equivalents |  | $ | 809,122 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 1,653 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,522 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 812,297 |  |  | $ | 482,836 |  |
  (was, 2022-05-04, similarity 0.9458):
[0000889331-22-000022:note_history:7]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Cash and cash equivalents |  | $ | 461,617 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 1,745 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,609 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 464,971 |  |  | $ | 482,836 |  |

- changed (2022-08-03):
[0000889331-22-000040:note_history:8]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The adoption of ASU 2021-08 did not have a material impact on the Company's Condensed Consolidated Financial Statements.
  (was, 2022-05-04, similarity 0.8887):
[0000889331-22-000022:note_history:8]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The Company does not expect a material impact from the adoption of this guidance on the Company's Condensed Consolidated Financial Statements.

- removed (2022-08-03):
[0000889331-22-000022:note_history:9]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:10]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  |  |  |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:11]
Recently Issued Accounting Standards


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0000889331-22-000040:note_history:12]
The carrying amounts of debt at July 2, 2022 and January 1, 2022 are as follows:
  (was, 2022-05-04, similarity 0.9517):
[0000889331-22-000022:note_history:12]
The carrying amounts of debt at April 2, 2022 and January 1, 2022 are as follows:

- added (2022-08-03):
[0000889331-22-000040:note_history:13]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 300,000 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 122,533 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 99,494 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Unamortized debt issuance costs |  | (4,958) |  |  | (3,087) |  |
| Total debt |  | 892,069 |  |  | 636,897 |  |
| Less: Current maturities |  | (7,500) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 884,569 |  |  | $ | 611,897 |  |

- changed (2022-08-03):
[0000889331-22-000040:note_history:14]
Revolving Credit Facility and Term Loan
  (was, 2022-05-04, similarity 0.7812):
[0000889331-22-000022:note_history:14]
Revolving Credit Facility

- added (2022-08-03):
[0000889331-22-000040:note_history:15]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

- added (2022-08-03):
[0000889331-22-000040:note_history:16]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement,, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

- added (2022-08-03):
[0000889331-22-000040:note_history:17]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $300.0 million, respectively, as of July 2, 2022.

- added (2022-08-03):
[0000889331-22-000040:note_history:18]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

- added (2022-08-03):
[0000889331-22-000040:note_history:19]
As of July 2, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 2.875%.

- changed (2022-08-03):
[0000889331-22-000040:note_history:20]
As of July 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the revolving Credit Facility. As of July 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.
  (was, 2022-05-04, similarity 0.9646):
[0000889331-22-000022:note_history:20]
As of April 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the Revolving Credit Facility. As of April 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.

- added (2022-08-03):
[0000889331-22-000040:note_history:21]
Debt Issuance Costs

- added (2022-08-03):
[0000889331-22-000040:note_history:22]
During three and six months ended July 2, 2022, the Company paid debt issuance costs of $2.2 million in connection with the new amended Credit Agreement on June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new amended Credit Agreement.

- changed (2022-08-03):
[0000889331-22-000040:note_history:23]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the six months ended July 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.
  (was, 2022-05-04, similarity 0.8587):
[0000889331-22-000022:note_history:23]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is

- changed (2022-08-03):
[0000889331-22-000040:note_history:24]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.
  (was, 2022-05-04, similarity 0.9344):
[0000889331-22-000022:note_history:24]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together the “U.S. Senior Notes due 2025 and 2030” and with the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

- added (2022-08-03):
[0000889331-22-000040:note_history:25]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the 2022 Purchase Agreement, as defined below.

- added (2022-08-03):
[0000889331-22-000040:note_history:26]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2032.

- changed (2022-08-03):
[0000889331-22-000040:note_history:27]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At July 2, 2022, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2022-05-04, similarity 0.9921):
[0000889331-22-000022:note_history:27]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At April 2, 2022, the Company was in compliance with all covenants under the Senior Notes.

- changed (2022-08-03):
[0000889331-22-000040:note_history:28]
Interest paid on all Company debt was $2.3 million and $2.5 million for the three months ended July 2, 2022 and June 26, 2021, respectively, and $8.4 million and $8.7 million for the six months ended July 2, 2022 and June 26, 2021, respectively.
  (was, 2022-05-04, similarity 0.7072):
[0000889331-22-000022:note_history:28]
Interest paid on all Company debt was $6.0 million and $6.2 million for the three months ended April 2, 2022 and March 27, 2021, respectively.

- removed (2022-08-03):
[0000889331-22-000022:note_history:29]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 129,478 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 105,132 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | — |  |  | — |  |
| Unamortized debt issuance costs |  | (2,869) |  |  | (3,087) |  |
| Total debt |  | 606,741 |  |  | 636,897 |  |
| Less: Current maturities |  | — |  |  | (25,000) |  |
| Total long-term debt |  | $ | 606,741 |  |  | $ | 611,897 |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:30]
On April 3, 2020, the Company amended its Credit Agreement to effect certain changes, including, among others: (i) eliminating the $200.0 million unsecured term loan credit facility, the remaining outstanding balance ($140.0 million) of which was repaid in full on April 3, 2020 through the revolving credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company; (iii) modifying performance-based interest rate margins and undrawn fees; and (iv) extending the maturity date to April 3, 2025. The amended Credit Agreement also allows the Company to increase the size of the revolving credit facility or enter into one or more tranches of term loans if there is no event of default and the Company is in compliance with certain financial covenants. The balance under the facility was $100.0 million as of April 2, 2022.

- removed (2022-08-03):
[0000889331-22-000022:note_history:31]
Outstanding borrowings under the amended Credit Agreement bears interest, at the Company’s option, at either LIBOR, fixed for interest periods of one, two, three or six-month periods, plus 1.25% to 2.00%, or at the bank’s Base Rate, as defined, plus 0.25% to 1.00%, based upon the Company’s Consolidated Leverage Ratio, as defined. The Company is also required to pay commitment fees on unused portions of the credit agreement ranging from 0.125% to 0.20%, based on the Consolidated Leverage Ratio, as defined in the agreement. The amended Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature. The effective interest rate on outstanding borrowings under the credit facility was 1.71% on April 2, 2022.

- removed (2022-08-03):
[0000889331-22-000022:note_history:32]
payable semiannually on February 15 and August 15, commencing August 15, 2017. During the three months ended April 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0000889331-22-000040:note_history:33]
The carrying amounts of debt at July 2, 2022 and January 1, 2022 are as follows:
  (was, 2022-05-04, similarity 0.9517):
[0000889331-22-000022:note_history:33]
The carrying amounts of debt at April 2, 2022 and January 1, 2022 are as follows:

- added (2022-08-03):
[0000889331-22-000040:note_history:34]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 300,000 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 122,533 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 99,494 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Unamortized debt issuance costs |  | (4,958) |  |  | (3,087) |  |
| Total debt |  | 892,069 |  |  | 636,897 |  |
| Less: Current maturities |  | (7,500) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 884,569 |  |  | $ | 611,897 |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:35]
| (in thousands) |  | April 2,2022 |  | January 1,2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Euro Senior Notes, Series A due 2023 |  | 129,478 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 105,132 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Other |  | — |  |  | — |  |
| Unamortized debt issuance costs |  | (2,869) |  |  | (3,087) |  |
| Total debt |  | 606,741 |  |  | 636,897 |  |
| Less: Current maturities |  | — |  |  | (25,000) |  |
| Total long-term debt |  | $ | 606,741 |  |  | $ | 611,897 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-08-03):
[0000889331-22-000040:note_history:36]
|  |  | Three Months Ended July 2, 2022 |  | Three Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | 0.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.7 |  | $ | 0.1 |  | $ | 2.8 |  |
|  |  | For the Six Months Ended July 2, 2022 |  | For the Six Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.2 |  | 5.9 |  |  | 1.8 |  | 0.2 |  | 5.8 |  |
|  |  | July 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.8 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:37]
|  |  | Three Months Ended April 2, 2022 |  | Three Months Ended March 27, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.2 |  | 0.1 |  | 2.9 |  |  | 1.1 |  | 0.1 |  | 3.0 |  |
|  |  | April 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | — |  | — |  | 2.0 |  |  | — |  | — |  | 1.8 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-08-03):
[0000889331-22-000040:note_history:38]
|  |  | Three Months Ended July 2, 2022 |  | Three Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | 0.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.7 |  | $ | 0.1 |  | $ | 2.8 |  |
|  |  | For the Six Months Ended July 2, 2022 |  | For the Six Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.2 |  | 5.9 |  |  | 1.8 |  | 0.2 |  | 5.8 |  |
|  |  | July 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.8 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:39]
|  |  | Three Months Ended April 2, 2022 |  | Three Months Ended March 27, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.2 |  | 0.1 |  | 2.9 |  |  | 1.1 |  | 0.1 |  | 3.0 |  |
|  |  | April 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | — |  | — |  | 2.0 |  |  | — |  | — |  | 1.8 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0000889331-22-000040:note_history:40]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 2, 2022 and June 26, 2021:
  (was, 2022-05-04, similarity 0.9118):
[0000889331-22-000022:note_history:40]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 2, 2022 and March 27, 2021:

- added (2022-08-03):
[0000889331-22-000040:note_history:41]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  | — |  |  | — |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

- added (2022-08-03):
[0000889331-22-000040:note_history:42]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  |  |  |  |  | 64,823 |  |  | 64,823 |  |  |  |  |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:43]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

- removed (2022-08-03):
[0000889331-22-000022:note_history:44]
|  |  | Three Months Ended March 27, 2021 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 132,437 |  |  | $ | — |  |  | $ | — |  |  | $ | 132,437 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 154,098 |  |  | — |  |  | — |  |  | 154,098 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 67,901 |  |  | — |  |  | 67,901 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 28,284 |  |  | — |  |  | 28,284 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 32,344 |  |  | — |  |  | 32,344 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  |  |  |  |  | 48,730 |  |  | 48,730 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 286,535 |  |  | $ | 128,529 |  |  | $ | 48,730 |  |  | $ | 463,794 |  |  |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0000889331-22-000040:note_history:45]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on
  (was, 2022-05-04, similarity 0.9185):
[0000889331-22-000022:note_history:45]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- added (2022-08-03):
[0000889331-22-000040:note_history:46]
historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-08-03):
[0000889331-22-000040:note_history:47]
Subsequent eventsOn July 19, 2022, the Company acquired C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The Company financed the transaction through a combination of cash on hand and debt.
  (was, 2022-05-04, similarity 0.6087):
[0000889331-22-000022:note_history:47]
Subsequent eventsOn April 8, 2022, the Company announced that it had entered into a definitive agreement to acquire C&K Switches (“C&K”) for $540 million in cash, subject to a working capital adjustment. Founded in 1928, C&K Switches is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is headquartered in Waltham, Massachusetts, with facilities located around the world and will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The transaction is subject to customary closing conditions and regulatory approvals, and is expected to close during the second quarter of 2022. The Company expects to finance the transaction through a combination of cash on hand and debt.On April 12, 2022, the Company acquired Embed Ltd. (“Embed”).  Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets. The business is headquartered in Coventry, United Kingdom, and will be included in the Commercial Vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand.
