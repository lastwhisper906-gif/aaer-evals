# LFUS notes — 0000889331-22-000040


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-22-000040:notes:1]
[same as prior period, unchanged from 0000889331-22-000022:notes:1]

[0000889331-22-000040:notes:2]
[same as prior period, unchanged from 0000889331-22-000022:notes:2]

[0000889331-22-000040:notes:3]
[same as prior period, unchanged from 0000889331-22-000022:notes:3]

[0000889331-22-000040:notes:4]
[same as prior period, unchanged from 0000889331-22-000022:notes:4]

[0000889331-22-000040:notes:5]
[same as prior period, unchanged from 0000889331-22-000022:notes:5]

[0000889331-22-000040:notes:6]
[same as prior period, unchanged from 0000889331-22-000022:notes:6]

[0000889331-22-000040:notes:7]
[same as prior period, unchanged from 0000889331-22-000022:notes:7]

[0000889331-22-000040:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three and six months ended July 2, 2022 and June 26, 2021:

[0000889331-22-000040:notes:9]
|  |  | Three Months Ended July 2, 2022 |  | Six Months Ended July 2, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 162,313 |  |  | $ | — |  |  | $ | — |  |  | $ | 162,313 |  |  | $ | 332,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 332,256 |  |
| Electronics – Semiconductor |  | 195,863 |  |  | — |  |  | — |  |  | 195,863 |  |  | 391,741 |  |  | — |  |  | — |  |  | 391,741 |  |
| Passenger Car Products |  | — |  |  | 59,778 |  |  | — |  |  | 59,778 |  |  | — |  |  | 124,272 |  |  | — |  |  | 124,272 |  |
| Automotive Sensors |  | — |  |  | 23,201 |  |  | — |  |  | 23,201 |  |  | — |  |  | 49,338 |  |  | — |  |  | 49,338 |  |
| Commercial Vehicle Products |  | — |  |  | 99,048 |  |  | — |  |  | 99,048 |  |  | — |  |  | 192,921 |  |  | — |  |  | 192,921 |  |
| Industrial Products |  | — |  |  | — |  |  | 78,233 |  |  | 78,233 |  |  | — |  |  | — |  |  | 151,238 |  |  | 151,238 |  |
| Total |  | $ | 358,176 |  |  | $ | 182,027 |  |  | $ | 78,233 |  |  | $ | 618,436 |  |  | $ | 723,997 |  |  | $ | 366,531 |  |  | $ | 151,238 |  |  | $ | 1,241,766 |  |

[0000889331-22-000040:notes:10]
|  |  | Three Months Ended June 26, 2021 |  | Six Months Ended June 26, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 155,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 155,276 |  |  | $ | 287,713 |  |  | $ | — |  |  | $ | — |  |  | $ | 287,713 |  |
| Electronics – Semiconductor |  | 170,071 |  |  | — |  |  | — |  |  | 170,071 |  |  | 324,169 |  |  | — |  |  | — |  |  | 324,169 |  |
| Passenger Car Products |  | — |  |  | 68,048 |  |  | — |  |  | 68,048 |  |  | — |  |  | 135,949 |  |  | — |  |  | 135,949 |  |
| Automotive Sensors |  | — |  |  | 26,685 |  |  | — |  |  | 26,685 |  |  | — |  |  | 54,969 |  |  | — |  |  | 54,969 |  |
| Commercial Vehicle Products |  | — |  |  | 38,585 |  |  | — |  |  | 38,585 |  |  | — |  |  | 70,929 |  |  | — |  |  | 70,929 |  |
| Industrial Products |  |  |  |  |  | 64,823 |  |  | 64,823 |  |  |  |  |  |  | 113,553 |  |  | 113,553 |  |
| Total |  | $ | 325,347 |  |  | $ | 133,318 |  |  | $ | 64,823 |  |  | $ | 523,488 |  |  | $ | 611,882 |  |  | $ | 261,847 |  |  | $ | 113,553 |  |  | $ | 987,282 |  |

[0000889331-22-000040:notes:11]
[same as prior period, unchanged from 0000889331-22-000022:notes:11]

[0000889331-22-000040:notes:12]
[same as prior period, unchanged from 0000889331-22-000022:notes:12]

[0000889331-22-000040:notes:13]
[same as prior period, unchanged from 0000889331-22-000022:notes:13]

[0000889331-22-000040:notes:14]
[same as prior period, unchanged from 0000889331-22-000022:notes:14]

[0000889331-22-000040:notes:15]
[same as prior period, unchanged from 0000889331-22-000022:notes:15]

[0000889331-22-000040:notes:16]
[same as prior period, unchanged from 0000889331-22-000022:notes:16]

[0000889331-22-000040:notes:17]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on

[0000889331-22-000040:notes:18]
historic activity, electronic distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-22-000040:notes:19]
[same as prior period, unchanged from 0000889331-22-000022:notes:18]

[0000889331-22-000040:notes:20]
[same as prior period, unchanged from 0000889331-22-000022:notes:19]

[0000889331-22-000040:notes:21]
[same as prior period, unchanged from 0000889331-22-000022:notes:20]

[0000889331-22-000040:notes:22]
[same as prior period, unchanged from 0000889331-22-000022:notes:21]

[0000889331-22-000040:notes:23]
[same as prior period, unchanged from 0000889331-22-000022:notes:22]

[0000889331-22-000040:notes:24]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at July 2, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-22-000040:notes:25]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Cash and cash equivalents |  | $ | 809,122 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 1,653 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,522 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 812,297 |  |  | $ | 482,836 |  |

[0000889331-22-000040:notes:26]
Recently Adopted Accounting Standards

[0000889331-22-000040:notes:27]
In November 2021, the Financial Accounting Standards Board ("FASB") issued ASU No. 2021-10, "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance". The standard, requires annual disclosures about transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy: 1) Information about the nature of the transactions and the related accounting policy used to account for the transactions; 2) The line items on the balance sheet and income statement that are affected by the transactions, and the amounts applicable to each financial statement line item; 3) Significant terms and conditions of the transactions, including commitments and contingencies. The guidance is effective for fiscal years beginning after December 15, 2021 with early adoption permitted. The adoption of ASU 2021-10 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

[0000889331-22-000040:notes:28]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The adoption of ASU 2021-08 did not have a material impact on the Company's Condensed Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-22-000040:notes:29]
[same as prior period, unchanged from 0000889331-22-000022:notes:29]

[0000889331-22-000040:notes:30]
[same as prior period, unchanged from 0000889331-22-000022:notes:30]

[0000889331-22-000040:notes:31]
Embed

[0000889331-22-000040:notes:32]
On April 12, 2022, the Company acquired Embed Ltd. (“Embed”).  Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets. The business is included

[0000889331-22-000040:notes:33]
in the commercial vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand. The total purchase consideration was $9.2 million, net of cash.

[0000889331-22-000040:notes:34]
[same as prior period, unchanged from 0000889331-22-000022:notes:31]

[0000889331-22-000040:notes:35]
On November 30, 2021, the Company completed the previously announced acquisition of Carling Technologies, Inc. (“Carling”), pursuant to the Stock Purchase Agreement, dated as of October 19, 2021. Founded in 1920, Carling has a leading position in switching and circuit protection technologies with a strong global presence in commercial vehicle, marine and datacom/telecom infrastructure markets. At the time of acquisition, Carling had annualized sales of approximately $170 million. The operations of Carling are included in the commercial vehicle business within the Company's Transportation segment. The purchase price for Carling Technologies was approximately $315.5 million subject to a working capital adjustment.

[0000889331-22-000040:notes:36]
The acquisition was funded with cash on hand. The total purchase consideration of $314.1 million, net of cash, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary area not yet finalized relates to the completion of the valuation of certain acquired income tax assets and liabilities. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-22-000040:notes:37]
[same as prior period, unchanged from 0000889331-22-000022:notes:35]

[0000889331-22-000040:notes:38]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 314,094 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 26,129 |  |
| Inventories | 56,657 |  |
| Other current assets | 3,454 |  |
| Property, plant, and equipment | 57,329 |  |
| Intangible assets | 126,390 |  |
| Goodwill | 97,917 |  |
| Other non-current assets | 4,007 |  |
| Current liabilities | (21,495) |  |
| Other non-current liabilities | (36,294) |  |
|  | $ | 314,094 |  |

[0000889331-22-000040:notes:39]
[same as prior period, unchanged from 0000889331-22-000022:notes:37]

[0000889331-22-000040:notes:40]
During the six months ended July 2, 2022, the Company paid $0.5 million related to final working capital adjustment and made measurement period adjustments to reduce the fair value of property, plant and equipment of $7.0 million, inventories of $0.8 million, net accounts receivable of $0.6 million and an increase in intangible assets attributable to customer relationships intangible assets of $0.5 million. As a result of these adjustments along with a corresponding reduction of deferred tax liabilities of $1.7 million, goodwill was increased by $5.6 million.

[0000889331-22-000040:notes:41]
As required by purchase accounting rules, the Company recorded a $6.4 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of sales during the fourth quarter of 2021 and first quarter of 2022, as the acquired inventory was sold, and reflected as other non-segment costs. The Company recognized a non-cash charge of $4.8 million to cost of sales during the six months ended July 2, 2022.

[0000889331-22-000040:notes:42]
[same as prior period, unchanged from 0000889331-22-000022:notes:40]

[0000889331-22-000040:notes:43]
[same as prior period, unchanged from 0000889331-22-000022:notes:41]

[0000889331-22-000040:notes:44]
The total purchase consideration of $108.5 million, net of cash, cash equivalents, and restricted cash has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values. As of July 2, 2022, the Company had restricted cash of $1.7 million in an escrow account for general indemnification purposes.

[0000889331-22-000040:notes:45]
[same as prior period, unchanged from 0000889331-22-000022:notes:43]

[0000889331-22-000040:notes:46]
[same as prior period, unchanged from 0000889331-22-000022:notes:44]

[0000889331-22-000040:notes:47]
[same as prior period, unchanged from 0000889331-22-000022:notes:45]

[0000889331-22-000040:notes:48]
The Company recorded a $6.8 million step-up of inventory to its fair value as of the acquisition date. The step-up was amortized as a non-cash charge to cost of sales during the first and second quarters of 2021, as the acquired inventory was sold, and is reflected as other non-segment costs. During the three and six months ended June 26, 2021, the Company recognized a charge of $3.3 million and 6.8 million, respectively, for the amortization of this fair value inventory step-up.

[0000889331-22-000040:notes:49]
During the three and six months ended June 26, 2021, the Company incurred approximately $0.1 million and $0.8 million, respectively, of legal and professional fees related to this acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-22-000040:notes:50]
[same as prior period, unchanged from 0000889331-22-000022:notes:48]

[0000889331-22-000040:notes:51]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company, Hartland and Carling as though the acquisitions had occurred as of December 29, 2019. The Company has not included pro forma results of operations for Embed as its operations were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Hartland and Carling acquisitions occurred as of December 29, 2019 or of future consolidated operating results.

[0000889331-22-000040:notes:52]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands, except per share amounts) |  | July 2, 2022 |  | June 26, 2021 |  | July 2, 2022 |  | June 26, 2021 |
| Net sales |  | $ | 618,436 |  |  | $ | 568,328 |  |  | $ | 1,241,766 |  |  | $ | 1,085,727 |  |
| Income before income taxes |  | 109,612 |  |  | 98,748 |  |  | 248,506 |  |  | 177,343 |  |
| Net income |  | 87,016 |  |  | 84,927 |  |  | 208,254 |  |  | 147,500 |  |
| Net income per share — basic |  | 3.52 |  |  | 3.45 |  |  | 8.43 |  |  | 6.01 |  |
| Net income per share — diluted |  | 3.48 |  |  | 3.41 |  |  | 8.33 |  |  | 5.93 |  |

[0000889331-22-000040:notes:53]
[same as prior period, unchanged from 0000889331-22-000022:notes:51]

[0000889331-22-000040:notes:54]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | July 2, 2022 |  | June 26, 2021 |  | July 2, 2022 |  | June 26, 2021 |
| Amortization(a) |  | $ | — |  |  | $ | (2,318) |  |  | $ | — |  |  | $ | (4,949) |  |
| Depreciation |  | — |  |  | (28) |  |  | — |  |  | (71) |  |
| Transaction costs(b) |  | — |  |  | 128 |  |  | — |  |  | 835 |  |
| Amortization of inventory step-up(c) |  | — |  |  | 3,319 |  |  | 4,769 |  |  | 6,808 |  |
| Income tax benefit of above items |  | — |  |  | (208) |  |  | (1,049) |  |  | (517) |  |

[0000889331-22-000040:notes:55]
(a)The amortization adjustment for the three and six months ended June 26, 2021 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-22-000040:notes:56]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three and six months ended June 26, 2021.

[0000889331-22-000040:notes:57]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the six months ended July 2, 2022, and three and six months ended June 26, 2021. The inventory step-up was amortized over four months as the inventory was sold.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-22-000040:notes:58]
[same as prior period, unchanged from 0000889331-22-000022:notes:56]

[0000889331-22-000040:notes:59]
The components of inventories at July 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000040:notes:60]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Raw materials |  | $ | 209,540 |  |  | $ | 168,409 |  |
| Work in process |  | 124,751 |  |  | 117,506 |  |
| Finished goods |  | 198,894 |  |  | 195,656 |  |
| Inventory reserves |  | (36,978) |  |  | (35,900) |  |
| Total |  | $ | 496,207 |  |  | $ | 445,671 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-22-000040:notes:61]
[same as prior period, unchanged from 0000889331-22-000022:notes:59]

[0000889331-22-000040:notes:62]
The components of net property, plant, and equipment at July 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000040:notes:63]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Land and land improvements |  | $ | 21,852 |  |  | $ | 23,470 |  |
| Building and building improvements |  | 174,931 |  |  | 151,297 |  |
| Machinery and equipment |  | 762,894 |  |  | 779,559 |  |
| Accumulated depreciation |  | (523,994) |  |  | (516,437) |  |
| Total |  | $ | 435,683 |  |  | $ | 437,889 |  |

[0000889331-22-000040:notes:64]
The Company recorded depreciation expense of $15.7 million and $13.6 million for the three months ended July 2, 2022 and June 26, 2021, respectively, and $31.3 million and $27.3 million for the six months ended July 2, 2022 and June 26, 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-22-000040:notes:65]
[same as prior period, unchanged from 0000889331-22-000022:notes:63]

[0000889331-22-000040:notes:66]
Changes in the carrying value of goodwill by segment for the six months ended July 2, 2022 are as follows:

[0000889331-22-000040:notes:67]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net book value of goodwill as of January 1, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of January 1, 2022 |  | $ | 660,245 |  |  | $ | 228,555 |  |  | $ | 86,232 |  |  | $ | 975,032 |  |
| Accumulated impairment losses as of January 1, 2022 |  | — |  |  | (36,177) |  |  | (9,065) |  |  | (45,242) |  |
| Total |  | 660,245 |  |  | 192,378 |  |  | 77,167 |  |  | 929,790 |  |
| Changes during 2022 |  |  |  |  |  |  |  |  |
| Additions(a) |  | — |  |  | 14,427 |  |  | — |  |  | 14,427 |  |
| Currency translation |  | (23,903) |  |  | (5,578) |  |  | (378) |  |  | (29,859) |  |
| Net book value of goodwill as of July 2, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of July 2, 2022 |  | 636,342 |  |  | 235,068 |  |  | 85,761 |  |  | 957,171 |  |
| Accumulated impairment losses as of July 2, 2022 |  | — |  |  | (33,841) |  |  | $ | (8,972) |  |  | (42,813) |  |
| Total |  | $ | 636,342 |  |  | $ | 201,227 |  |  | $ | 76,789 |  |  | $ | 914,358 |  |

[0000889331-22-000040:notes:68]
(a) The additions resulted from the acquisition of  Embed and Carling.

[0000889331-22-000040:notes:69]
The components of other intangible assets as of July 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000040:notes:70]
|  |  |  | As of July 2, 2022 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 18,974 |  |  | $ | 1,892 |  |  | $ | 17,082 |  |
| Patents, licenses and software |  |  | 177,174 |  |  | 114,658 |  |  | 62,516 |  |
| Distribution network |  |  | 41,575 |  |  | 39,834 |  |  | 1,741 |  |
| Customer relationships, trademarks, and tradenames |  |  | 458,150 |  |  | 164,896 |  |  | 293,254 |  |
| Total |  |  | $ | 695,873 |  |  | $ | 321,280 |  |  | $ | 374,593 |  |

[0000889331-22-000040:notes:71]
[same as prior period, unchanged from 0000889331-22-000022:notes:69]

[0000889331-22-000040:notes:72]
During the three months ended July 2, 2022 and June 26, 2021, the Company recorded amortization expense of $11.6 million and $10.6 million, respectively. During the six months ended July 2, 2022 and June 26, 2021, the Company recorded amortization expense of $24.3 million and $21.2 million, respectively.

[0000889331-22-000040:notes:73]
Estimated annual amortization expense related to intangible assets with definite lives as of July 2, 2022 is as follows:

[0000889331-22-000040:notes:74]
| (in thousands) | Amount |
| 2022 | $ | 48,574 |  |
| 2023 | 44,664 |  |
| 2024 | 41,320 |  |
| 2025 | 38,567 |  |
| 2026 | 33,571 |  |
| 2027 and thereafter | 192,213 |  |
| Total | $ | 398,909 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-22-000040:notes:75]
[same as prior period, unchanged from 0000889331-22-000022:notes:73]

[0000889331-22-000040:notes:76]
The components of accrued liabilities as of July 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000040:notes:77]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Employee-related liabilities |  | $ | 64,857 |  |  | $ | 92,018 |  |
| Professional services |  | 12,008 |  |  | 4,299 |  |
| Operating lease liability |  | 9,177 |  |  | 9,018 |  |
| Other non-income taxes |  | 6,492 |  |  | 4,280 |  |
| Interest |  | 4,197 |  |  | 4,402 |  |
| Restructuring liability |  | 3,020 |  |  | 2,944 |  |
| Current post-retirement benefits liability |  | 1,248 |  |  | 1,248 |  |
| Deferred revenue |  | 686 |  |  | 1,105 |  |
| Other |  | 35,692 |  |  | 40,375 |  |
| Total |  | $ | 137,377 |  |  | $ | 159,689 |  |

[0000889331-22-000040:notes:78]
[same as prior period, unchanged from 0000889331-22-000022:notes:76]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-22-000040:notes:79]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment and other charges for the three and six months ended July 2, 2022 and June 26, 2021 as follows:

[0000889331-22-000040:notes:80]
|  | Three months ended July 2, 2022 |  | Six months ended July 2, 2022 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 201 |  |  | $ | 423 |  |  | $ | — |  |  | $ | 624 |  |  | $ | 406 |  |  | $ | 423 |  |  | $ | — |  |  | $ | 829 |  |
| Other restructuring charges | 3 |  |  | 7 |  |  | — |  |  | 10 |  |  | 3 |  |  | 20 |  |  | — |  |  | 23 |  |
| Total restructuring charges | 204 |  |  | 430 |  |  | — |  |  | 634 |  |  | 409 |  |  | 443 |  |  | — |  |  | 852 |  |
| Total | $ | 204 |  |  | $ | 430 |  |  | $ | — |  |  | $ | 634 |  |  | $ | 409 |  |  | $ | 443 |  |  | $ | — |  |  | $ | 852 |  |

[0000889331-22-000040:notes:81]
|  | Three months ended June 26, 2021 |  | Six months ended June 26, 2021 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 295 |  |  | $ | 416 |  |  | $ | 6 |  |  | $ | 717 |  |  | $ | 552 |  |  | $ | 416 |  |  | $ | 169 |  |  | $ | 1,137 |  |
| Other restructuring charges | — |  |  | 72 |  |  | — |  |  | 72 |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total restructuring charges | 295 |  |  | 488 |  |  | 6 |  |  | 789 |  |  | 552 |  |  | 505 |  |  | 169 |  |  | 1,226 |  |
| Total | $ | 295 |  |  | $ | 488 |  |  | $ | 6 |  |  | $ | 789 |  |  | $ | 552 |  |  | $ | 505 |  |  | $ | 169 |  |  | $ | 1,226 |  |

[0000889331-22-000040:notes:82]
[same as prior period, unchanged from 0000889331-22-000022:notes:80]

[0000889331-22-000040:notes:83]
For the three and six months ended July 2, 2022, the Company recorded total restructuring charges of $0.6 million and $0.9 million, respectively, primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation and Electronics segments.

[0000889331-22-000040:notes:84]
[same as prior period, unchanged from 0000889331-22-000022:notes:82]

[0000889331-22-000040:notes:85]
For the three and six months ended June 26, 2021, the Company recorded total restructuring charges of $0.8 million and $1.2 million, respectively, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation and Electronics segments.

[0000889331-22-000040:notes:86]
The restructuring liability as of July 2, 2022 and January 1, 2022 is $3.0 million and $2.9 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in fiscal year 2022.


## us-gaap:DebtDisclosureTextBlock

[0000889331-22-000040:notes:87]
Debt

[0000889331-22-000040:notes:88]
The carrying amounts of debt at July 2, 2022 and January 1, 2022 are as follows:

[0000889331-22-000040:notes:89]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 300,000 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 122,533 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 99,494 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| Unamortized debt issuance costs |  | (4,958) |  |  | (3,087) |  |
| Total debt |  | 892,069 |  |  | 636,897 |  |
| Less: Current maturities |  | (7,500) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 884,569 |  |  | $ | 611,897 |  |

[0000889331-22-000040:notes:90]
Revolving Credit Facility and Term Loan

[0000889331-22-000040:notes:91]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-22-000040:notes:92]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement,, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-22-000040:notes:93]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $300.0 million, respectively, as of July 2, 2022.

[0000889331-22-000040:notes:94]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-22-000040:notes:95]
As of July 2, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 2.875%.

[0000889331-22-000040:notes:96]
As of July 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the revolving Credit Facility. As of July 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-22-000040:notes:97]
Debt Issuance Costs

[0000889331-22-000040:notes:98]
During three and six months ended July 2, 2022, the Company paid debt issuance costs of $2.2 million in connection with the new amended Credit Agreement on June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new amended Credit Agreement.

[0000889331-22-000040:notes:99]
Senior Notes

[0000889331-22-000040:notes:100]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-22-000040:notes:101]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the six months ended July 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

[0000889331-22-000040:notes:102]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-22-000040:notes:103]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the 2022 Purchase Agreement, as defined below.

[0000889331-22-000040:notes:104]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2032.

[0000889331-22-000040:notes:105]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-22-000040:notes:106]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At July 2, 2022, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-22-000040:notes:107]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-22-000040:notes:108]
Interest paid on all Company debt was $2.3 million and $2.5 million for the three months ended July 2, 2022 and June 26, 2021, respectively, and $8.4 million and $8.7 million for the six months ended July 2, 2022 and June 26, 2021, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-22-000040:notes:109]
[same as prior period, unchanged from 0000889331-22-000022:notes:101]

[0000889331-22-000040:notes:110]
[same as prior period, unchanged from 0000889331-22-000022:notes:102]

[0000889331-22-000040:notes:111]
[same as prior period, unchanged from 0000889331-22-000022:notes:103]

[0000889331-22-000040:notes:112]
[same as prior period, unchanged from 0000889331-22-000022:notes:104]

[0000889331-22-000040:notes:113]
[same as prior period, unchanged from 0000889331-22-000022:notes:105]

[0000889331-22-000040:notes:114]
[same as prior period, unchanged from 0000889331-22-000022:notes:106]

[0000889331-22-000040:notes:115]
[same as prior period, unchanged from 0000889331-22-000022:notes:107]

[0000889331-22-000040:notes:116]
[same as prior period, unchanged from 0000889331-22-000022:notes:108]

[0000889331-22-000040:notes:117]
[same as prior period, unchanged from 0000889331-22-000022:notes:109]

[0000889331-22-000040:notes:118]
[same as prior period, unchanged from 0000889331-22-000022:notes:110]

[0000889331-22-000040:notes:119]
Derivatives

[0000889331-22-000040:notes:120]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive (loss) income until the underlying transactions are recognized in earnings. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by market observable data. There were no transfers in or out of Level 1, Level 2 and Level 3 during the period.

[0000889331-22-000040:notes:121]
The use of derivatives creates exposure to credit risk relating to potential losses that could be recognized in the event that the counterparties to these instruments fail to perform their obligations under the contracts. The Company seeks to minimize this risk by limiting our counterparties to major financial institutions with acceptable credit ratings and monitoring the total value of positions with individual counterparties. In the event of a default by one of our counterparties, the Company may not receive payments provided for under the terms of our derivatives.

[0000889331-22-000040:notes:122]
As of July 2, 2022, the fair values of our derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets was as follows:

[0000889331-22-000040:notes:123]
| (in thousands) | Consolidated Balance Sheet Classification |  | July 2, 2022 |  |  |
| Derivative assets |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 206 |  |  |  |
|  | Other long-term liabilities |  | $ | 918 |  |  |  |

[0000889331-22-000040:notes:124]
The pre-tax losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Operations for the three and six months ended July 2, 2022 were as follows:

[0000889331-22-000040:notes:125]
|  |  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | Classification of Loss Recognized in theCondensed Consolidated Statements of Operations |  | July 2, 2022 |  |  |  | July 2, 2022 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense, net |  | 21 |  |  |  |  | 21 |  |  |  |

[0000889331-22-000040:notes:126]
The pre-tax losses recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three and six months ended July 2, 2022 were as follows:

[0000889331-22-000040:notes:127]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 2, 2022 |  |  |  | July 2, 2022 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | 712 |  |  |  |  | $ | 712 |  |  |  |

[0000889331-22-000040:notes:128]
The pre-tax gain of $0.2 million from accumulated other comprehensive (loss) to earnings is expected to be recognized  during the next twelve months.

[0000889331-22-000040:notes:129]
[same as prior period, unchanged from 0000889331-22-000022:notes:111]

[0000889331-22-000040:notes:130]
[same as prior period, unchanged from 0000889331-22-000022:notes:112]

[0000889331-22-000040:notes:131]
There were no changes during the quarter ended July 2, 2022 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of July 2, 2022 and January 1, 2022, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-22-000040:notes:132]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of July 2, 2022:

[0000889331-22-000040:notes:133]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 251,502 |  |  | $ | — |  |  | $ | — |  |  | $ | 251,502 |  |
| Investments in equity securities |  | 12,112 |  |  | — |  |  | — |  |  | 12,112 |  |
| Mutual funds |  | 13,441 |  |  | — |  |  | — |  |  | 13,441 |  |
| Total |  | $ | 277,055 |  |  | $ | — |  |  | $ | — |  |  | $ | 277,055 |  |

[0000889331-22-000040:notes:134]
[same as prior period, unchanged from 0000889331-22-000022:notes:116]

[0000889331-22-000040:notes:135]
[same as prior period, unchanged from 0000889331-22-000022:notes:117]

[0000889331-22-000040:notes:136]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s Credit Facilities’ fair values approximate book value at July 2, 2022 and January 1, 2022, as the rates on these borrowings are variable in nature.

[0000889331-22-000040:notes:137]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of July 2, 2022 and January 1, 2022 were as follows:

[0000889331-22-000040:notes:138]
|  |  | July 2, 2022 |  | January 1, 2022 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 122,533 |  |  | $ | 121,472 |  |  | $ | 132,444 |  |  | $ | 134,119 |  |
| Euro Senior Notes, Series B due 2028 |  | 99,494 |  |  | 91,857 |  |  | 107,540 |  |  | 110,837 |  |
| USD Senior Notes, Series A due 2022 |  | — |  |  | — |  |  | 25,000 |  |  | 25,055 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 96,318 |  |  | 100,000 |  |  | 104,828 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 48,762 |  |  | 50,000 |  |  | 51,720 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 117,255 |  |  | 125,000 |  |  | 131,837 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-22-000040:notes:139]
[same as prior period, unchanged from 0000889331-22-000022:notes:121]

[0000889331-22-000040:notes:140]
[same as prior period, unchanged from 0000889331-22-000022:notes:122]

[0000889331-22-000040:notes:141]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other expense (income), net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three and six months ended July 2, 2022 and June 26, 2021 were as follows:

[0000889331-22-000040:notes:142]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (in thousands) |  | July 2, 2022 |  | June 26, 2021 |  | July 2, 2022 |  | June 26, 2021 |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 750 |  |  | $ | 700 |  |  | $ | 1,518 |  |  | $ | 1,402 |  |
| Interest cost |  | 628 |  |  | 443 |  |  | 1,272 |  |  | 883 |  |
| Expected return on plan assets |  | (380) |  |  | (371) |  |  | (783) |  |  | (738) |  |
| Amortization of prior service and net actuarial loss |  | 96 |  |  | 334 |  |  | 197 |  |  | 665 |  |
| Net periodic benefit cost |  | $ | 1,094 |  |  | $ | 1,106 |  |  | $ | 2,204 |  |  | $ | 2,212 |  |

[0000889331-22-000040:notes:143]
The Company expects to make approximately $2.6 million of contributions to the plans and pay $1.8 million of benefits directly in 2022.
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.5 million for both the three months ended July 2, 2022 and June 26, 2021, respectively, and $1.0 million for both the six months ended July 2, 2022 and June 26, 2021, respectively, in Cost of Sales and Other expense (income), net within the Condensed Consolidated Statements of Net Income. The pre-tax amounts recognized in other comprehensive loss (income) as components of net periodic benefit costs for these plans were $0.1 million and $0.2 million for the three months ended July 2, 2022 and June 26, 2021, respectively, and $0.2 million and $0.3 million for the six months ended July 2, 2022 and June 26, 2021, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-22-000040:notes:144]
Other Comprehensive (Loss) Income
Changes in other comprehensive (loss) income by component were as follows:

[0000889331-22-000040:notes:145]
| (in thousands) |  | Three Months EndedJuly 2, 2022 |  | Three Months EndedJune 26, 2021 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan and other adjustments |  | $ | 722 |  |  | $ | 83 |  |  | $ | 639 |  |  | $ | 372 |  |  | $ | 43 |  |  | $ | 329 |  |
| Cash flow hedge |  | (712) |  |  | (171) |  |  | (541) |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustments (1) |  | (32,167) |  |  | (720) |  |  | (31,447) |  |  | 5,125 |  |  | — |  |  | 5,125 |  |
| Total change in other comprehensive (loss) income |  | $ | (32,157) |  |  | $ | (808) |  |  | $ | (31,349) |  |  | $ | 5,497 |  |  | $ | 43 |  |  | $ | 5,454 |  |
| (in thousands) |  | Six Months EndedJuly 2, 2022 |  | Six Months EndedJune 26, 2021 |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  | Pre-tax |  | Tax |  | Net of Tax |
| Defined benefit pension plan adjustments |  | $ | 1,045 |  |  | $ | 96 |  |  | $ | 949 |  |  | 878 |  |  | 95 |  |  | $ | 783 |  |
| Cash flow hedge |  | (712) |  |  | (171) |  |  | (541) |  |  | — |  |  | — |  |  | — |  |
| Foreign currency translation adjustments (1) |  | (35,382) |  |  | (1,422) |  |  | (33,960) |  |  | $ | (200) |  |  | $ | — |  |  | $ | (200) |  |
| Total change in other comprehensive (loss) income |  | $ | (35,049) |  |  | $ | (1,497) |  |  | $ | (33,552) |  |  | $ | 678 |  |  | $ | 95 |  |  | $ | 583 |  |

[0000889331-22-000040:notes:146]
[same as prior period, unchanged from 0000889331-22-000022:notes:128]

[0000889331-22-000040:notes:147]
The following tables set forth the changes in accumulated other comprehensive (loss) income by component for the six months ended July 2, 2022 and June 26, 2021:

[0000889331-22-000040:notes:148]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at January 1, 2022 |  | $ | (11,928) |  |  | $ | — |  |  | $ | (61,535) |  |  | $ | (73,463) |  |
| Activity in the period |  | 949 |  |  | (541) |  |  | (33,960) |  |  | (33,552) |  |
| Balance at July 2, 2022 |  | $ | (10,979) |  |  | $ | (541) |  |  | $ | (95,495) |  |  | $ | (107,015) |  |

[0000889331-22-000040:notes:149]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at December 26, 2020 |  | $ | (34,141) |  |  |  |  | $ | (57,016) |  |  | $ | (91,157) |  |
| Activity in the period |  | 783 |  |  |  |  | (200) |  |  | 583 |  |
| Balance at June 26, 2021 |  | $ | (33,358) |  |  |  |  | $ | (57,216) |  |  | $ | (90,574) |  |

[0000889331-22-000040:notes:150]
Amounts reclassified from accumulated other comprehensive (loss) income to earnings for the three and six months ended July 2, 2022 and June 26, 2021 were as follows:

[0000889331-22-000040:notes:151]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 2, 2022 |  | June 26, 2021 |  | July 2, 2022 |  | June 26, 2021 |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | $ | 198 |  |  | $ | 509 |  |  | $ | 395 |  |  | $ | 774 |  |

[0000889331-22-000040:notes:152]
[same as prior period, unchanged from 0000889331-22-000022:notes:134]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-22-000040:notes:153]
Income TaxesThe effective tax rate for the three and six months ended July 2, 2022 was 20.6% and 16.1%, respectively, compared to the effective tax rate for the three and six months ended June 26, 2021 of 13.8% and 16.7%, respectively. The effective tax rate for the second quarter of 2022 is higher than the effective tax rate for the comparable 2021 period, primarily due to foreign exchange losses with no related tax benefit in the 2022 period, as compared to foreign exchange gains with limited tax expense during the comparable 2021 period. The effective tax rate for the first six months of the 2022 period is lower than the applicable U.S. statutory tax rate due to a one-time deduction that resulted from the dissolution of one of the Company’s affiliates, as well as the forecasted impact of income earned in lower tax jurisdictions. The effective tax rate for the comparable 2021 period is lower than the applicable U.S. statutory tax rate primarily due to the forecasted impact of income earned in lower tax jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000889331-22-000040:notes:154]
[same as prior period, unchanged from 0000889331-22-000022:notes:136]

[0000889331-22-000040:notes:155]
[same as prior period, unchanged from 0000889331-22-000022:notes:137]

[0000889331-22-000040:notes:156]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share amounts) |  | July 2, 2022 |  | June 26, 2021 |  | July 2, 2022 |  | June 26, 2021 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 87,016 |  |  | $ | 82,095 |  |  | $ | 204,534 |  |  | $ | 139,808 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,734 |  |  | 24,592 |  |  | 24,712 |  |  | 24,562 |  |
| Effect of dilutive securities |  | 251 |  |  | 308 |  |  | 274 |  |  | 332 |  |
| Diluted |  | 24,985 |  |  | 24,900 |  |  | 24,986 |  |  | 24,894 |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 3.52 |  |  | $ | 3.34 |  |  | $ | 8.28 |  |  | $ | 5.69 |  |
| Diluted earnings per share |  | $ | 3.48 |  |  | $ | 3.30 |  |  | $ | 8.19 |  |  | $ | 5.62 |  |

[0000889331-22-000040:notes:157]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 88,130 and 41,216 for the three months ended July 2, 2022 and June 26, 2021, respectively, and 72,970 and 20,266 for the six months ended July 2, 2022 and June 26, 2021, respectively.

[0000889331-22-000040:notes:158]
[same as prior period, unchanged from 0000889331-22-000022:notes:140]

[0000889331-22-000040:notes:159]
[same as prior period, unchanged from 0000889331-22-000022:notes:141]

[0000889331-22-000040:notes:160]
The Company did not repurchase any shares of its common stock for the three and six months ended July 2, 2022, and June 26, 2021.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-22-000040:notes:161]
Related Party Transactions

[0000889331-22-000040:notes:162]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-22-000040:notes:163]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-22-000040:notes:164]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-22-000040:notes:165]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-22-000040:notes:166]
|  |  | Three Months Ended July 2, 2022 |  | Three Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | 0.1 |  | $ | 0.1 |  | $ | 3.0 |  |  | $ | 0.7 |  | $ | 0.1 |  | $ | 2.8 |  |
|  |  | For the Six Months Ended July 2, 2022 |  | For the Six Months Ended June 26, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.2 |  | 5.9 |  |  | 1.8 |  | 0.2 |  | 5.8 |  |
|  |  | July 2, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.8 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-22-000040:notes:167]
[same as prior period, unchanged from 0000889331-22-000022:notes:149]

[0000889331-22-000040:notes:168]
[same as prior period, unchanged from 0000889331-22-000022:notes:150]

[0000889331-22-000040:notes:169]
[same as prior period, unchanged from 0000889331-22-000022:notes:151]

[0000889331-22-000040:notes:170]
[same as prior period, unchanged from 0000889331-22-000022:notes:152]

[0000889331-22-000040:notes:171]
[same as prior period, unchanged from 0000889331-22-000022:notes:153]

[0000889331-22-000040:notes:172]
[same as prior period, unchanged from 0000889331-22-000022:notes:154]

[0000889331-22-000040:notes:173]
[same as prior period, unchanged from 0000889331-22-000022:notes:155]

[0000889331-22-000040:notes:174]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 2, 2022 |  | June 26, 2021 |  | July 2, 2022 |  | June 26, 2021 |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 358,176 |  |  | $ | 325,347 |  |  | $ | 723,997 |  |  | $ | 611,882 |  |
| Transportation |  | 182,027 |  |  | 133,318 |  |  | 366,531 |  |  | 261,847 |  |
| Industrial |  | 78,233 |  |  | 64,823 |  |  | 151,238 |  |  | 113,553 |  |
| Total net sales |  | $ | 618,436 |  |  | $ | 523,488 |  |  | $ | 1,241,766 |  |  | $ | 987,282 |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 14,511 |  |  | $ | 15,114 |  |  | $ | 29,904 |  |  | 30,495 |  |
| Transportation |  | 10,628 |  |  | 6,946 |  |  | 21,372 |  |  | 14,019 |  |
| Industrial |  | 2,181 |  |  | 2,155 |  |  | 4,342 |  |  | 3,899 |  |
| Total depreciation and amortization |  | $ | 27,320 |  |  | $ | 24,215 |  |  | $ | 55,618 |  |  | $ | 48,413 |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 105,958 |  |  | $ | 74,236 |  |  | $ | 226,535 |  |  | $ | 129,759 |  |
| Transportation |  | 18,309 |  |  | 19,258 |  |  | 44,617 |  |  | 39,574 |  |
| Industrial |  | 15,285 |  |  | 8,375 |  |  | 27,790 |  |  | 11,881 |  |
| Other(a) |  | (5,388) |  |  | (5,612) |  |  | (14,188) |  |  | (8,476) |  |
| Total operating income |  | 134,164 |  |  | 96,257 |  |  | 284,754 |  |  | 172,738 |  |
| Interest expense |  | 4,368 |  |  | 4,626 |  |  | 8,670 |  |  | 9,299 |  |
| Foreign exchange loss (gain) |  | 14,124 |  |  | (1,676) |  |  | 21,860 |  |  | 5,161 |  |
| Other expense (income), net |  | 6,060 |  |  | (1,890) |  |  | 10,487 |  |  | (9,627) |  |
| Income before income taxes |  | $ | 109,612 |  |  | $ | 95,197 |  |  | $ | 243,737 |  |  | $ | 167,905 |  |

[0000889331-22-000040:notes:175]
(a) Included in “Other” Operating income for the second quarter of 2022 was $4.8 million ($8.6 million year-to-date) of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $0.6 million ($0.8 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs, and $4.8 million year-to-date of purchase accounting inventory step-up charges. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-22-000040:notes:176]
Included in “Other” Operating income for the 2021 second quarter was $3.3 million ($6.8 million year-to-date) of purchase accounting inventory step-up charges, $0.5 million ($1.3 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.8 million ($1.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a loss of $1.0 million recorded during the second quarter of 2021 for a total year-to-date gain of $0.9 million from the sale of a building within the Electronics segment.

[0000889331-22-000040:notes:177]
[same as prior period, unchanged from 0000889331-22-000022:notes:159]

[0000889331-22-000040:notes:178]
|  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) |  | July 2, 2022 |  | June 26, 2021 |  | July 2, 2022 |  | June 26, 2021 |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 224,743 |  |  | $ | 154,797 |  |  | $ | 444,981 |  |  | $ | 285,728 |  |
| China |  | 162,322 |  |  | 156,086 |  |  | 327,104 |  |  | 295,244 |  |
| Other countries(a) |  | 231,371 |  |  | 212,605 |  |  | 469,681 |  |  | 406,310 |  |
| Total net sales |  | $ | 618,436 |  |  | $ | 523,488 |  |  | $ | 1,241,766 |  |  | $ | 987,282 |  |

[0000889331-22-000040:notes:179]
[same as prior period, unchanged from 0000889331-22-000022:notes:161]

[0000889331-22-000040:notes:180]
| (in thousands) |  | July 2, 2022 |  | January 1, 2022 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 65,445 |  |  | $ | 57,923 |  |
| China |  | 115,567 |  |  | 122,867 |  |
| Mexico |  | 108,829 |  |  | 107,283 |  |
| Germany |  | 36,495 |  |  | 39,055 |  |
| Philippines |  | 77,256 |  |  | 74,918 |  |
| Other countries(a) |  | 32,091 |  |  | 35,843 |  |
| Total long-lived assets |  | $ | 435,683 |  |  | $ | 437,889 |  |

[0000889331-22-000040:notes:181]
[same as prior period, unchanged from 0000889331-22-000022:notes:163]

[0000889331-22-000040:notes:182]
|  |  | Six Months Ended |
| (in thousands) |  | July 2, 2022 |  | June 26, 2021 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 6,527 |  |  | $ | 1,732 |  |
| China |  | 15,623 |  |  | 7,127 |  |
| Mexico |  | 14,244 |  |  | 13,231 |  |
| Germany |  | 2,432 |  |  | 2,533 |  |
| Philippines |  | 10,138 |  |  | 6,941 |  |
| Other countries(a) |  | 2,558 |  |  | 1,793 |  |
| Total additions to long-lived assets |  | $ | 51,522 |  |  | $ | 33,357 |  |

[0000889331-22-000040:notes:183]
[same as prior period, unchanged from 0000889331-22-000022:notes:165]


## us-gaap:SubsequentEventsTextBlock

[0000889331-22-000040:notes:184]
Subsequent eventsOn July 19, 2022, the Company acquired C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The Company financed the transaction through a combination of cash on hand and debt.
