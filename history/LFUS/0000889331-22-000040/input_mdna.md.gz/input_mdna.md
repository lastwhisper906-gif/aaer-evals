# LFUS MD&A — 0000889331-22-000040


## mdna

[0000889331-22-000040:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000889331-22-000040:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-22-000040:mdna:3]
[same as prior period, unchanged from 0000889331-22-000022:mdna:3]

[0000889331-22-000040:mdna:4]
[same as prior period, unchanged from 0000889331-22-000022:mdna:4]

[0000889331-22-000040:mdna:5]
[same as prior period, unchanged from 0000889331-22-000022:mdna:5]

[0000889331-22-000040:mdna:6]
[same as prior period, unchanged from 0000889331-22-000022:mdna:6]

[0000889331-22-000040:mdna:7]
[same as prior period, unchanged from 0000889331-22-000022:mdna:7]

[0000889331-22-000040:mdna:8]
[same as prior period, unchanged from 0000889331-22-000022:mdna:8]

[0000889331-22-000040:mdna:9]
For the second quarter of 2022, the Company recognized net sales of $618.4 million, an increase of $94.9 million, or 18.1% as compared to $523.5 million in the second quarter of 2021. The increase was primarily driven by higher volumes in the Electronics and Industrial segments and $57.8 million or 11.0% of net sales from the Carling acquisition within the Transportation segment, partially offset by $16.4 million or 3.1% of unfavorable changes in foreign exchange rates. The Company recognized net income of $87.0 million, or $3.48 per diluted share, in the second quarter of 2022 compared to $82.1 million, or $3.30 per diluted share in the second quarter of 2021. The increase in net income reflects higher operating income of $37.9 million primarily due to an increase in operating income of $31.7 million in the Electronics segment partially offset by higher foreign exchange losses of $15.8 million and higher unrealized losses of $9.1 million associated with the Company’s equity investment.

[0000889331-22-000040:mdna:10]
Supply chain constraints, including material and transportation capacity shortages have and are expected to continue to impact the Company, its suppliers and its customers. This has resulted in higher transportation and input costs incurred by the Company.

[0000889331-22-000040:mdna:11]
Net cash provided by operating activities was $165.3 million for the six months ended July 2, 2022 as compared to $126.3 million for the six months ended June 26, 2021. The increase in net cash provided by operating activities was primarily due to higher cash earnings, partially offset by increases in working capital resulting from higher sales growth and higher annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-22-000040:mdna:12]
On June 30, 2022, the Company amended its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-22-000040:mdna:13]
On July 19, 2022, the Company acquired C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The Company financed the transaction through a combination of cash on hand and debt.

[0000889331-22-000040:mdna:14]
On July 28, 2022, the Board of Directors of the Company approved a 13% increase in the quarterly cash dividend from $0.53 to $0.60 per share, payable on September 8, 2022 to stockholders of record as of August 25, 2022.

[0000889331-22-000040:mdna:15]
[same as prior period, unchanged from 0000889331-22-000022:mdna:13]

[0000889331-22-000040:mdna:16]
[same as prior period, unchanged from 0000889331-22-000022:mdna:14]

[0000889331-22-000040:mdna:17]
During the second quarter of 2022, the outbreak of COVID-19 in China in late March resulted in the temporary shut-down of certain of the Company's China manufacturing facilities during April and May. The Company's other manufacturing facilities were operational and were generally running at normal capacity levels. The financial impact of these shut-downs was modest to the Company’s financial results during the second quarter of 2022.

[0000889331-22-000040:mdna:18]
The Company anticipates that the disruptions caused by COVID-19 may continue to impact its business activity for the foreseeable future. It is currently difficult to estimate the magnitude of the COVID-19 disruption, if future disruptions will occur due to a further resurgence in COVID-19 cases and its impact on the Company's employees, customers, suppliers and vendors. The Company will continue to actively monitor the situation and may take further actions altering its business operations that the Company determines are in the best interests of its employees, customers, partners, suppliers, and other stakeholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on the Company's business and operations, including the effects on its customers, employees, and prospects, or on the Company's financial results for the fiscal year 2022.

[0000889331-22-000040:mdna:19]
[same as prior period, unchanged from 0000889331-22-000022:mdna:18]

[0000889331-22-000040:mdna:20]
[same as prior period, unchanged from 0000889331-22-000022:mdna:19]

[0000889331-22-000040:mdna:21]
[same as prior period, unchanged from 0000889331-22-000022:mdna:20]

[0000889331-22-000040:mdna:22]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The second quarter of 2022 includes $4.8 million ($8.6 million year-to-date) of legal and professional fees primarily related to the acquisition of C&K and other integration expenses related to completed and contemplated acquisitions, and $0.6 million ($0.8 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs, and $4.8 million year-to-date of  purchase accounting inventory step-up charges. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion..

[0000889331-22-000040:mdna:23]
The second quarter of 2021 includes $3.3 million ($6.8 million year-to-date) of purchase accounting inventory step-up charges, $0.5 million ($1.3 million year-to-date) of legal and professional fees and other integration expenses related to Hartland and other contemplated acquisitions, and $0.8 million ($1.3 million year-to-date) of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion. In addition, there was a loss of $1.0 million recorded during the second quarter of 2021 for a total year-to-date gain of $0.9 million from the sale of a building within the Electronics segment.

[0000889331-22-000040:mdna:24]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  | 2022 |  | 2021 |  | Change |  | %Change |
| Net sales |  | $ | 618,436 |  |  | $ | 523,488 |  |  | $ | 94,948 |  |  | 18.1 | % |  | $ | 1,241,766 |  |  | $ | 987,282 |  |  | $ | 254,484 |  |  | 25.8 | % |
| Cost of sales |  | 355,465 |  |  | 326,092 |  |  | 29,373 |  |  | 9.0 | % |  | 720,199 |  |  | 629,420 |  |  | 90,779 |  |  | 14.4 | % |
| Gross profit |  | 262,971 |  |  | 197,396 |  |  | 65,575 |  |  | 33.2 | % |  | 521,567 |  |  | 357,862 |  |  | 163,705 |  |  | 45.7 | % |
| Operating expenses |  | 128,807 |  |  | 101,139 |  |  | 27,668 |  |  | 27.4 | % |  | 236,813 |  |  | 185,124 |  |  | 51,689 |  |  | 27.9 | % |
| Operating income |  | 134,164 |  |  | 96,257 |  |  | 37,907 |  |  | 39.4 | % |  | 284,754 |  |  | 172,738 |  |  | 112,016 |  |  | 64.8 | % |
| Income before income taxes |  | 109,612 |  |  | 95,197 |  |  | 14,415 |  |  | 15.1 | % |  | 243,737 |  |  | 167,905 |  |  | 75,832 |  |  | 45.2 | % |
| Income taxes |  | 22,596 |  |  | 13,102 |  |  | 9,494 |  |  | 72.5 | % |  | 39,203 |  |  | 28,097 |  |  | 11,106 |  |  | 39.5 | % |
| Net income |  | $ | 87,016 |  |  | $ | 82,095 |  |  | $ | 4,921 |  |  | 6.0 | % |  | $ | 204,534 |  |  | $ | 139,808 |  |  | $ | 64,726 |  |  | 46.3 | % |

[0000889331-22-000040:mdna:25]
[same as prior period, unchanged from 0000889331-22-000022:mdna:24]

[0000889331-22-000040:mdna:26]
Net sales increased $94.9 million, or 18.1%, including $57.8 million or 11.0% from the Carling acquisition within the Transportation segment and $16.4 million or 3.1% of unfavorable changes in foreign exchange rates for the second quarter of 2022 compared to the second quarter of 2021. The remaining increase was primarily driven by growth across the Company's Electronics and Industrial segments, which had sales increases of $32.8 million and $13.4 million, respectively. The increase within the Electronics segment was led by continued broad-based demand across numerous end markets and price realization. The increase in the Industrial segment was driven across all businesses within the segment and price realization.

[0000889331-22-000040:mdna:27]
Net sales increased $254.5 million, or 25.8%, including $113.5 million or 11.5% from the Carling acquisition and $25.0 million or 2.5% of unfavorable changes in foreign exchange rates for the first six months of 2022 compared to the first six months of 2021. The remaining increase was primarily driven by growth across the Company's Electronics and Industrial segments, which had sales increases of $112.1 million and $37.7 million, respectively. The increase within the Electronics segment was led by continued broad-based demand across numerous end markets. The increase in the Industrial segment was driven across all businesses within the segment.

[0000889331-22-000040:mdna:28]
[same as prior period, unchanged from 0000889331-22-000022:mdna:26]

[0000889331-22-000040:mdna:29]
Cost of sales was $355.5 million, or 57.5% of net sales, in 2022, compared to $326.1 million, or 62.3% of net sales, in 2021. The increase in cost of sales was primarily due to greater volume across the Electronics and Industrial segments driven by the factors discussed above along with the acquisition of Carling. As a percent of net sales, cost of sales decreased 4.8% driven by volume leverage, favorable product mix predominantly in the Electronics segment in 2022 and lower purchase accounting inventory charges of $3.3 million or 0.6%, partially offset by higher commodity costs.

[0000889331-22-000040:mdna:30]
Cost of sales was $720.2 million, or 58.0% of net sales for the first six months of 2022, compared to $629.4 million, or 63.8% of net sales for the first six months of 2021. The increase in cost of sales was primarily due to greater volume across the Electronics and Industrial segments driven by the factors discussed above along with the acquisition of Carling. As a percent of net sales, cost of sales decreased 5.8% driven by volume leverage and lower purchase accounting inventory charges of $2.0 million or 0.2% in 2022, partially offset by higher commodity costs and higher transportation, duty and tariff charges of 0.3%.

[0000889331-22-000040:mdna:31]
[same as prior period, unchanged from 0000889331-22-000022:mdna:28]

[0000889331-22-000040:mdna:32]
Gross profit was $263.0 million, or 42.5% of net sales, in the second quarter of 2022 compared to $197.4 million, or 37.7% of net sales, for the second quarter of 2021. The $65.6 million increase in gross profit was primarily due to higher volume and price in the Electronics and Industrial segments along with acquisition of Carling. The increase in gross margin of 4.8% was primarily driven by volume leverage, price realization and favorable product mix within the Electronics segment and lower purchase accounting inventory charges, partially offset by higher commodity costs.

[0000889331-22-000040:mdna:33]
Gross profit was $521.6 million, or 42.0% of net sales, in the first six months of 2022 compared to $357.9 million, or 36.2% of net sales, for the first six months of 2021. The $163.7 million increase in gross profit was primarily due to higher volume in the Electronics and Industrial segments along with acquisition of Carling. The increase in gross margin of 5.8% was primarily driven by volume leverage, price realization and lower purchase accounting inventory charges of $2.0 million or 0.3% in 2022, partially offset by higher commodity costs and higher transportation, duty and tariff charges of 0.3%.

[0000889331-22-000040:mdna:34]
[same as prior period, unchanged from 0000889331-22-000022:mdna:30]

[0000889331-22-000040:mdna:35]
Total operating expenses were $128.8 million, or 20.8% of net sales, for the second quarter of 2022 compared to $101.1 million, or 19.3% of net sales, for the second quarter of 2021. The increase in operating expenses of $27.7 million was primarily due to the higher selling, general, and administrative expenses of $19.8 million largely due to the Carling acquisition and increased acquisition-related expenses of $4.3 million and higher research and development expenses of $7.1 million.

[0000889331-22-000040:mdna:36]
Total operating expenses were $236.8 million, or 19.1% of net sales, for the first six months of 2022 compared to $185.1 million, or 18.8% of net sales, for the first six months of 2021. The increase in operating expenses of $51.7 million was primarily due to the higher selling, general, and administrative expenses of $37.0 million largely due to the Carling acquisition and increased acquisition-related expenses of $7.3 million, higher research and development expenses of $11.9 million, and higher amortization expense of $3.2 million due to the Carling acquisition.

[0000889331-22-000040:mdna:37]
[same as prior period, unchanged from 0000889331-22-000022:mdna:32]

[0000889331-22-000040:mdna:38]
Operating income was $134.2 million, an increase of $37.9 million, or 39.4%, for the second quarter of 2022 compared to $96.3 million for the second quarter of 2021. The increase in operating income was due to higher gross profit from all segments, particularly in the Electronics segment, partially offset by higher operating expenses as noted above. Operating margins

[0000889331-22-000040:mdna:39]
increased from 18.4% in the second quarter of 2021 to 21.7% in the second quarter of 2022 driven by the factors mentioned above.

[0000889331-22-000040:mdna:40]
Operating income was $284.8 million, an increase of $112.0 million, or 64.8%, for the first six months of 2022 compared to $172.7 million for the first six months of 2021. The increase in operating income was due to higher gross profit from all segments, particularly in the Electronics segment, partially offset by higher operating expenses as noted above. Operating margins increased from 17.5% in the first six months of 2021 to 22.9% in the first six months of 2022 driven by the factors mentioned above.

[0000889331-22-000040:mdna:41]
[same as prior period, unchanged from 0000889331-22-000022:mdna:34]

[0000889331-22-000040:mdna:42]
Income before income taxes was $109.6 million, or 17.7% of net sales, for the second quarter of 2022 compared to $95.2 million, or 18.2% of net sales, for the second quarter of 2021. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange losses of $14.1 million in the second quarter of 2022 compared to foreign exchange gains of $1.7 million in the second quarter of 2021, and $7.8 million of unrealized losses in the second quarter of 2022 compared to unrealized gains of $1.3 million in the second quarter of 2021 related to the Company's equity investment.

[0000889331-22-000040:mdna:43]
Income before income taxes was $243.7 million, or 19.6% of net sales, for the first six months of 2022 compared to $167.9 million, or 17.0% of net sales, for the first six months of 2021. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was impacted by $12.5 million of unrealized losses during the six months ended July 2, 2022 compared to unrealized gains of $8.8 million during six months ended June 26, 2021 related to the Company's equity investment, and higher foreign exchange losses of $16.7 million during the six months ended July 2, 2022.

[0000889331-22-000040:mdna:44]
[same as prior period, unchanged from 0000889331-22-000022:mdna:36]

[0000889331-22-000040:mdna:45]
Income tax expense for the second quarter of 2022 was $22.6 million, or an effective tax rate of 20.6%, compared to $13.1 million, or an effective tax rate of 13.8%, for the second quarter of 2021. The effective tax rate for the second quarter of 2022 is higher than the effective tax rate for the comparable 2021 period, primarily due to foreign exchange losses noted above with no related tax benefit in the 2022 period, as compared to foreign exchange gains with limited tax expense during the comparable 2021 period.

[0000889331-22-000040:mdna:46]
Income tax expense for the first six months of 2022 was $39.2 million, or an effective tax rate of 16.1%, compared to income tax expense of $28.1 million, or an effective tax rate of 16.7%, for the first six months of 2021. The effective tax rate for the first six months of the 2022 period is lower than the applicable U.S. statutory tax rate due to a one-time deduction that resulted from the dissolution of one of the Company’s affiliates, as well as the forecasted impact of income earned in lower tax jurisdictions.  The effective tax rate for the comparable 2021 period is lower than the applicable U.S. statutory tax rate primarily due to the forecasted impact of income earned in lower tax jurisdictions.

[0000889331-22-000040:mdna:47]
[same as prior period, unchanged from 0000889331-22-000022:mdna:38]

[0000889331-22-000040:mdna:48]
[same as prior period, unchanged from 0000889331-22-000022:mdna:39]

[0000889331-22-000040:mdna:49]
[same as prior period, unchanged from 0000889331-22-000022:mdna:40]

[0000889331-22-000040:mdna:50]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  | 2022 |  | 2021 |  | Change |  | %Change |
| Electronics |  | $ | 358,176 |  |  | $ | 325,347 |  |  | $ | 32,829 |  |  | 10.1 | % |  | $ | 723,997 |  |  | $ | 611,882 |  |  | $ | 112,115 |  |  | 18.3 | % |
| Transportation |  | 182,027 |  |  | 133,318 |  |  | 48,709 |  |  | 36.5 | % |  | 366,531 |  |  | 261,847 |  |  | 104,684 |  |  | 40.0 | % |
| Industrial |  | 78,233 |  |  | 64,823 |  |  | 13,410 |  |  | 20.7 | % |  | 151,238 |  |  | 113,553 |  |  | 37,685 |  |  | 33.2 | % |
| Total |  | $ | 618,436 |  |  | $ | 523,488 |  |  | $ | 94,948 |  |  | 18.1 | % |  | $ | 1,241,766 |  |  | $ | 987,282 |  |  | $ | 254,484 |  |  | 25.8 | % |

[0000889331-22-000040:mdna:51]
[same as prior period, unchanged from 0000889331-22-000022:mdna:42]

[0000889331-22-000040:mdna:52]
Net sales increased $32.8 million, or 10.1%, in the second quarter of 2022 compared to the second quarter of 2021 and included unfavorable changes in foreign exchange rates of $9.5 million. The sales increase was primarily due to increased volume for the semiconductor and electronics products businesses of $25.8 million and $7.0 million, respectively, primarily driven by continued broad-based demand across numerous end markets and price realization.

[0000889331-22-000040:mdna:53]
Net sales increased $112.1 million, or 18.3%, in the first six months of 2022 compared to the first six months of 2021 and included unfavorable changes in foreign exchange rates of $14.4 million. The sales increase was primarily due to increased volume for the semiconductor and electronics products businesses of $67.6 million and $44.5 million, respectively. The volume increases were driven by continued broad-based demand across numerous end markets.

[0000889331-22-000040:mdna:54]
[same as prior period, unchanged from 0000889331-22-000022:mdna:44]

[0000889331-22-000040:mdna:55]
Net sales increased $48.7 million, or 36.5%, in the second quarter of 2022 compared to the second quarter of 2021 and included unfavorable changes in foreign exchange rates of $6.3 million. The sales increase was primarily due to the acquisition of Carling which contributed net sales of $57.8 million. Net sales in the commercial vehicle business increased by $60.5 million, largely due to the Carling acquisition noted previously and continued demand across a number of commercial vehicle end markets. The passenger car products and automotive sensors businesses had sales decreases of $8.3 million and $3.5 million, respectively, driven by a decline in global car build compared to the same quarter last year primarily due to supply chain constraints, including China COVID shut-downs and OEM shut downs caused by market shortages of semiconductor chips partially offset by greater content growth from vehicle mix and electric vehicles.

[0000889331-22-000040:mdna:56]
Net sales increased $104.7 million, or 40.0%, in the first six months of 2022 compared to the first six months of 2021 and included favorable changes in foreign exchange rates of $9.9 million. The sales increase was primarily due to the acquisition of Carling which contributed net sales of $113.5 million. Net sales in the commercial vehicle business increased by $122.0 million, largely due to the Carling acquisition noted previously and continued demand across a number of commercial vehicle end markets. The passenger car products and automotive sensors businesses had sales decreases of $11.7 million and $5.6 million, respectively, driven by a decline in global car build compared to last year largely due to supply chain constraints and OEM shut downs caused by market shortages of semiconductor chips as well as a reduction of demand in Europe due to Ukraine/Russia conflict partially offset by greater content growth from vehicle mix and electric vehicles.

[0000889331-22-000040:mdna:57]
[same as prior period, unchanged from 0000889331-22-000022:mdna:46]

[0000889331-22-000040:mdna:58]
Net sales increased by $13.4 million, or 20.7%, in the second quarter of 2022 compared to the second quarter of 2021, which included unfavorable changes in foreign exchange rates of $0.6 million. The increase in net sales was primarily due to higher volume and demand across product lines in renewables, and ongoing improving demand in nonresidential construction, oil & gas, natural resources, and industrial maintenance, repair, and operations end markets along with price realization.

[0000889331-22-000040:mdna:59]
Net sales increased by $37.7 million, or 33.2%, in the first six months of 2022 compared to the first six months of 2021, which included favorable changes in foreign exchange rates of $0.7 million. The increase in net sales was primarily due to higher volume and demand across product lines in industrial safety, HVAC, renewables, nonresidential construction, oil & gas, natural resources, and industrial maintenance, repair, and operations end markets and incremental one month net sales of $9.1 million or 14.0% from the Hartland acquisition.

[0000889331-22-000040:mdna:60]
[same as prior period, unchanged from 0000889331-22-000022:mdna:48]

[0000889331-22-000040:mdna:61]
[same as prior period, unchanged from 0000889331-22-000022:mdna:49]

[0000889331-22-000040:mdna:62]
|  |  | Second Quarter |  | First Six Months |
| (in thousands) |  | 2022 |  | 2021 |  | Change |  | %Change |  | 2022 |  | 2021 |  | Change |  | %Change |
| Asia-Pacific |  | $ | 252,809 |  |  | $ | 239,477 |  |  | $ | 13,332 |  |  | 5.6 | % |  | $ | 513,027 |  |  | $ | 451,662 |  |  | $ | 61,365 |  |  | 13.6 | % |
| Americas |  | 247,591 |  |  | 180,335 |  |  | 67,256 |  |  | 37.3 | % |  | 484,821 |  |  | 333,241 |  |  | 151,580 |  |  | 45.5 | % |
| Europe |  | 118,036 |  |  | 103,676 |  |  | 14,360 |  |  | 13.9 | % |  | 243,918 |  |  | 202,379 |  |  | 41,539 |  |  | 20.5 | % |
| Total |  | $ | 618,436 |  |  | $ | 523,488 |  |  | $ | 94,948 |  |  | 18.1 | % |  | $ | 1,241,766 |  |  | $ | 987,282 |  |  | $ | 254,484 |  |  | 25.8 | % |

[0000889331-22-000040:mdna:63]
[same as prior period, unchanged from 0000889331-22-000022:mdna:51]

[0000889331-22-000040:mdna:64]
Net sales increased  $13.3 million, or 5.6%, in the second quarter of 2022 compared to the second quarter of 2021 and included unfavorable changes in foreign exchange rates of $4.5 million. The increase in net sales was primarily due to higher volume from the semiconductor business within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the second quarter of 2021.

[0000889331-22-000040:mdna:65]
Net sales increased $61.4 million, or 13.6%, in the first six months of 2022 compared to the first six months of 2021 and included unfavorable changes in foreign exchange rates of $5.5 million. The increase in net sales was primarily due to higher volume across all businesses within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the first six months of 2021.

[0000889331-22-000040:mdna:66]
[same as prior period, unchanged from 0000889331-22-000022:mdna:53]

[0000889331-22-000040:mdna:67]
Net sales increased $67.3 million, or 37.3%, in the second quarter of 2022 compared to the second quarter of 2021 and included unfavorable changes in foreign exchange rates of $0.3 million. The increase in net sales was primarily due to incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment and higher volume from all businesses within the Electronics and Industrial segments compared to the second quarter of 2021.

[0000889331-22-000040:mdna:68]
Net sales increased $151.6 million, or 45.5%, in the first six months of 2022 compared to the first six months of 2021 and included unfavorable changes in foreign exchange rates of $0.5 million. The increase in net sales was primarily due to incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment and higher volume from all businesses within the Electronics and Industrial segments compared to the first six months of 2021.

[0000889331-22-000040:mdna:69]
[same as prior period, unchanged from 0000889331-22-000022:mdna:55]

[0000889331-22-000040:mdna:70]
Net sales increased $14.4 million, or 13.9%, in the second quarter of 2022 compared to the second quarter of 2021 and included unfavorable changes in foreign exchange rates of $11.6 million. The increase in net sales was primarily due to increased volume across all businesses within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the second quarter of 2021.

[0000889331-22-000040:mdna:71]
Net sales increased $41.5 million, or 20.5%, in the first six months of 2022 compared to the first six months of 2021 and included favorable changes in foreign exchange rates of $19.0 million. The increase in net sales was primarily due to increased volume across all businesses within the Electronics segment and incremental sales from the Carling acquisition included in the commercial vehicle products business within the Transportation segment compared to the first six months of 2021.

[0000889331-22-000040:mdna:72]
[same as prior period, unchanged from 0000889331-22-000022:mdna:57]

[0000889331-22-000040:mdna:73]
[same as prior period, unchanged from 0000889331-22-000022:mdna:58]

[0000889331-22-000040:mdna:74]
Cash and cash equivalents were $809.1 million as of July 2, 2022, an increase of $330.6 million as compared to January 1, 2022. As of July 2, 2022, $532.2 million of the Company's $809.1 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-22-000040:mdna:75]
Revolving Credit Facility and Term Loan

[0000889331-22-000040:mdna:76]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-22-000040:mdna:77]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement,, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-22-000040:mdna:78]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $300.0 million, respectively, as of July 2, 2022.

[0000889331-22-000040:mdna:79]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-22-000040:mdna:80]
As of July 2, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 2.875%.

[0000889331-22-000040:mdna:81]
As of July 2, 2022, the Company had no amount outstanding in letters of credit and had available $600.0 million of borrowing capacity under the revolving Credit Facility. At July 2, 2022, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-22-000040:mdna:82]
[same as prior period, unchanged from 0000889331-22-000022:mdna:64]

[0000889331-22-000040:mdna:83]
[same as prior period, unchanged from 0000889331-22-000022:mdna:65]

[0000889331-22-000040:mdna:84]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the six months ended July 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

[0000889331-22-000040:mdna:85]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-22-000040:mdna:86]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the 2022 Purchase Agreement, as defined below.

[0000889331-22-000040:mdna:87]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2032.

[0000889331-22-000040:mdna:88]
Debt Covenants

[0000889331-22-000040:mdna:89]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of July 2, 2022 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2022. As of July 2, 2022, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-22-000040:mdna:90]
[same as prior period, unchanged from 0000889331-22-000022:mdna:71]

[0000889331-22-000040:mdna:91]
On July 19, 2022, the Company acquired C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, aerospace, and datacom. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business will be reported as part of the Electronics-Passive Products and Sensors business within the Company's Electronics segment. The Company financed the transaction through a combination of cash on hand and debt.

[0000889331-22-000040:mdna:92]
[same as prior period, unchanged from 0000889331-22-000022:mdna:73]

[0000889331-22-000040:mdna:93]
During the second quarter of 2022 the Company paid quarterly dividends of $26.2 million to the shareholders. On July 28, 2022, the Board of Directors of the Company approved a 13% increase in the quarterly cash dividend from $0.53 to $0.60 per share, payable on September 8, 2022 to stockholders of record as of August 25, 2022.

[0000889331-22-000040:mdna:94]
[same as prior period, unchanged from 0000889331-22-000022:mdna:75]

[0000889331-22-000040:mdna:95]
|  |  | First Six Months |
| (in thousands) |  | 2022 |  | 2021 |
| Net cash provided by operating activities |  | $ | 165,322 |  |  | $ | 126,346 |  |
| Net cash used in investing activities |  | (65,367) |  |  | (139,940) |  |
| Net cash used in financing activities |  | 245,017 |  |  | (49,183) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | (15,511) |  |  | (2,894) |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash |  | 329,461 |  |  | (65,671) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 482,836 |  |  | 687,525 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 812,297 |  |  | $ | 621,854 |  |

[0000889331-22-000040:mdna:96]
[same as prior period, unchanged from 0000889331-22-000022:mdna:77]

[0000889331-22-000040:mdna:97]
[same as prior period, unchanged from 0000889331-22-000022:mdna:78]

[0000889331-22-000040:mdna:98]
Net cash provided by operating activities was $165.3 million for the six months ended July 2, 2022 as compared to $126.3 million for the six months ended June 26, 2021. The increase in net cash provided by operating activities was primarily due to

[0000889331-22-000040:mdna:99]
higher cash earnings, partially offset by increases in working capital resulting from higher sales growth and higher annual incentive bonus payments made in 2022 as compared to 2021.

[0000889331-22-000040:mdna:100]
[same as prior period, unchanged from 0000889331-22-000022:mdna:80]

[0000889331-22-000040:mdna:101]
Net cash used in investing activities was $65.4 million for the six months ended July 2, 2022 compared to $139.9 million during the six months ended June 26, 2021. Net cash paid for acquisitions was $9.8 million and $109.9 million for the six months ended July 2, 2022 and June 26, 2021, respectively. Capital expenditures were $56.2 million, representing an increase of $23.5 million compared to 2021. During six months ended July 2, 2022 and June 26, 2021, the Company received proceeds of $0.5 million from the sale of a property within the Transportation segment and $2.6 million from the sale of a property within the Electronics segment, respectively.

[0000889331-22-000040:mdna:102]
[same as prior period, unchanged from 0000889331-22-000022:mdna:82]

[0000889331-22-000040:mdna:103]
Net cash used in financing activities was $245.0 million for the six months ended July 2, 2022 compared to $49.2 million for the six months ended June 26, 2021. On June 30, 2022, the Company amended its Credit Agreement and borrowed of $300.0 million through a term loan. During the six months ended July 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022. During the six months ended June 26, 2021, the Company made payments of $30.0 million on the amended revolving credit facility. Additionally, the Company paid dividends $26.2 million and $23.6 million in the six months ended July 2, 2022 and June 26, 2021, respectively.

[0000889331-22-000040:mdna:104]
[same as prior period, unchanged from 0000889331-22-000022:mdna:84]

[0000889331-22-000040:mdna:105]
[same as prior period, unchanged from 0000889331-22-000022:mdna:85]

[0000889331-22-000040:mdna:106]
The Company did not repurchase any shares of its common stock for the three and six months ended July 2, 2022, and June 26, 2021.

[0000889331-22-000040:mdna:107]
[same as prior period, unchanged from 0000889331-22-000022:mdna:87]

[0000889331-22-000040:mdna:108]
As of July 2, 2022, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-22-000040:mdna:109]
[same as prior period, unchanged from 0000889331-22-000022:mdna:89]

[0000889331-22-000040:mdna:110]
[same as prior period, unchanged from 0000889331-22-000022:mdna:90]

[0000889331-22-000040:mdna:111]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended January 1, 2022. During the six months ended July 2, 2022, there were no significant changes in the application of critical accounting policies.
