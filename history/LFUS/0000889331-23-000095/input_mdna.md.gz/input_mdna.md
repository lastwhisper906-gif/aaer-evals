# LFUS MD&A — 0000889331-23-000095


## mdna

[0000889331-23-000095:mdna:1]
[same as prior period, unchanged from 0000889331-22-000046:mdna:1]

[0000889331-23-000095:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements Under the Private Securities Litigation Reform Act of 1995 (“PSLRA”).

[0000889331-23-000095:mdna:3]
This report, including the Management’s Discussion and Analysis of Financial Condition and Results of Operations, should be read in conjunction with information provided in the consolidated financial statements and the related Notes thereto appearing in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.

[0000889331-23-000095:mdna:4]
[same as prior period, unchanged from 0000889331-22-000046:mdna:4]

[0000889331-23-000095:mdna:5]
[same as prior period, unchanged from 0000889331-22-000046:mdna:5]

[0000889331-23-000095:mdna:6]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-23-000095:mdna:7]
[same as prior period, unchanged from 0000889331-22-000046:mdna:7]

[0000889331-23-000095:mdna:8]
[same as prior period, unchanged from 0000889331-22-000046:mdna:8]

[0000889331-23-000095:mdna:9]
For the first quarter of 2023, the Company recognized net sales of $609.8 million, a decrease of $13.5 million, or 2.2% as compared to $623.3 million in the first quarter of 2022 including $10.0 million or 1.6% of unfavorable changes in foreign exchange rates. The  decrease in net sales was due to lower volumes in the Electronics and Transportation segments that more than offset $42.5 million or 6.8% and $2.7 million or 0.4%  of incremental net sales from the C&K and Western Automation acquisitions, respectively, and higher volume in the Industrial segment. The Company recognized net income of $88.7 million, or $3.54 per diluted share, in the first quarter of 2023 compared to $117.5 million, or $4.70 per diluted share in the first quarter of 2022. The decrease in net income was primarily due to a decrease in operating income in the Electronics and Transportation segments driven by lower volume.

[0000889331-23-000095:mdna:10]
On February 3, 2023, the Company acquired Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. Western Automation has annualized sales of approximately $25 million and will be reported within the company’s Industrial segment. The company does not expect the acquisition to have a material impact to its 2023 financial results. The Company financed the transaction with cash on hand.

[0000889331-23-000095:mdna:11]
Net cash provided by operating activities was $53.4 million for the three months ended April 1, 2023 as compared to $51.7 million for the three months ended April 2, 2022. The increase in net cash provided by operating activities was primarily due to reductions in working capital, partially offset by lower cash earnings.

[0000889331-23-000095:mdna:12]
[same as prior period, unchanged from 0000889331-22-000046:mdna:16]

[0000889331-23-000095:mdna:13]
The Company continues to operate in a challenging macro environment, including but not limited to, supply chain disruptions, varying regional dynamics, and some pockets of end market softness, and the ongoing war in Ukraine. The Company does not have any direct operations in Ukraine or Russia. The war has had a modest impact on the Company, including higher transportation costs due to the Company modifying its shipping logistics as well as suspending sales into and purchases from Russia.

[0000889331-23-000095:mdna:14]
[same as prior period, unchanged from 0000889331-22-000046:mdna:18]

[0000889331-23-000095:mdna:15]
The following table summarizes the Company’s unaudited condensed consolidated results of operations for the periods presented. The first quarter of 2023 includes $3.3 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $1.9 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000095:mdna:16]
The first quarter of 2022 includes $4.8 million of purchase accounting inventory step-up charges, $3.8 million of legal and professional fees and other integration expenses related to completed and other contemplated acquisitions, and $0.2 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000095:mdna:17]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 609,782 |  |  | $ | 623,330 |  |  | $ | (13,548) |  |  | (2.2) | % |  |  |  |  |  |  |  |  |
| Cost of sales |  | 364,825 |  |  | 364,734 |  |  | 91 |  |  | — | % |  |  |  |  |  |  |  |  |
| Gross profit |  | 244,957 |  |  | 258,596 |  |  | (13,639) |  |  | (5.3) | % |  |  |  |  |  |  |  |  |
| Operating expenses |  | 134,316 |  |  | 108,006 |  |  | 26,310 |  |  | 24.4 | % |  |  |  |  |  |  |  |  |
| Operating income |  | 110,641 |  |  | 150,590 |  |  | (39,949) |  |  | (26.5) | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | 108,903 |  |  | 134,125 |  |  | (25,222) |  |  | (18.8) | % |  |  |  |  |  |  |  |  |
| Income taxes |  | 20,158 |  |  | 16,607 |  |  | 3,551 |  |  | 21.4 | % |  |  |  |  |  |  |  |  |
| Net income |  | $ | 88,745 |  |  | $ | 117,518 |  |  | $ | (28,773) |  |  | (24.5) | % |  |  |  |  |  |  |  |  |

[0000889331-23-000095:mdna:18]
[same as prior period, unchanged from 0000889331-22-000046:mdna:22]

[0000889331-23-000095:mdna:19]
Net sales decreased $13.5 million, or 2.2%, for the first quarter of 2023 compared to the first quarter of 2022 including $10.0 million or 1.6% of unfavorable changes in foreign exchange rates.  The sales decrease was due to lower volume in the Electronics and Transportation segments that more than offset $42.5 million or 6.8% and $2.7 million or 0.4% of incremental net sales associated with the C&K and Western Automation acquisitions included in the Electronics and Industrial segments, respectively, and higher volume in the Industrial segment.

[0000889331-23-000095:mdna:20]
[same as prior period, unchanged from 0000889331-22-000046:mdna:25]

[0000889331-23-000095:mdna:21]
Cost of sales was $364.8 million, or 59.8% of net sales, in the first quarter of 2023, compared to $364.7 million, or 58.5% of net sales, in the first quarter of 2022. As a percent of net sales, cost of sales increased 1.3% driven by lower volumes in the Electronics and Transportation segments, partially offset by volume leverage, and favorable product mix from the Industrial segment.

[0000889331-23-000095:mdna:22]
[same as prior period, unchanged from 0000889331-22-000046:mdna:28]

[0000889331-23-000095:mdna:23]
Gross profit was $245.0 million, or 40.2% of net sales, in the first quarter of 2023 compared to $258.6 million, or 41.5% of net sales, for the first quarter of 2022. The $13.6 million decrease in gross profit was primarily due to lower volume in the Electronics and Transportation segments, partially offset by the acquisition of C&K within Electronics segment, and volume leverage and favorable product mix from the Industrial segment and $4.8 million or 0.8% of purchase accounting inventory charges recorded during the first quarter of 2022.

[0000889331-23-000095:mdna:24]
[same as prior period, unchanged from 0000889331-22-000046:mdna:31]

[0000889331-23-000095:mdna:25]
Operating expenses were $134.3 million, or 22.0% of net sales, for the first quarter of 2023 compared to $108.0 million, or 17.3% of net sales, for the first quarter of 2022. The increase in operating expenses of $26.3 million was primarily due to  higher selling, general, and administrative expenses of $12.8 million, research and development expenses of $7.7 million, and higher amortization expense of $4.1 million mainly due to the C&K and Western Automation acquisitions.

[0000889331-23-000095:mdna:26]
[same as prior period, unchanged from 0000889331-22-000046:mdna:34]

[0000889331-23-000095:mdna:27]
Operating income was $110.6 million, representing a decrease of $39.9 million, or 26.5%, for the first quarter of 2023 compared to $150.6 million for the first quarter of 2022. The decrease in operating income was due to lower gross profit from the Electronics and Transportation segments and higher operating expenses as noted above. Operating margins decreased from 24.2% in the first quarter of 2022 to 18.1% in the first quarter of 2023 driven by lower volumes in the Electronics and Transportation segments and the higher operating expenses mentioned above.

[0000889331-23-000095:mdna:28]
[same as prior period, unchanged from 0000889331-22-000046:mdna:37]

[0000889331-23-000095:mdna:29]
Income before income taxes was $108.9 million, or 17.9% of net sales, for the first quarter of 2023 compared to $134.1 million, or 21.5% of net sales, for the first quarter of 2022. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange gains of $1.7 million in the first quarter of 2023 compared to foreign exchange losses of $7.7 million during the first quarter of 2022 and unrealized gains of

[0000889331-23-000095:mdna:30]
$1.8 million during the first quarter of 2023 compared to unrealized losses of $4.7 million during the first quarter of 2022 related to the Company's equity investment.

[0000889331-23-000095:mdna:31]
[same as prior period, unchanged from 0000889331-22-000046:mdna:40]

[0000889331-23-000095:mdna:32]
Income tax expense for the first quarter of 2023 was $20.2 million, or an effective tax rate of 18.5%, compared to $16.6 million, or an effective tax rate of 12.4%, for the first quarter of 2022. The effective tax rate for the first quarter of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to the impact of a one-time deduction in the first quarter of 2022 that resulted in a net benefit of $7.2 million from the dissolution of one of the Company’s affiliates. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, while for the 2022 period, the effective tax rate also was lower due to the impact of the one-time deduction referred to in the preceding sentence.

[0000889331-23-000095:mdna:33]
[same as prior period, unchanged from 0000889331-22-000046:mdna:43]

[0000889331-23-000095:mdna:34]
[same as prior period, unchanged from 0000889331-22-000046:mdna:44]

[0000889331-23-000095:mdna:35]
[same as prior period, unchanged from 0000889331-22-000046:mdna:45]

[0000889331-23-000095:mdna:36]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 358,593 |  |  | $ | 365,821 |  |  | $ | (7,228) |  |  | (2.0) | % |  |  |  |  |  |  |  |  |
| Transportation |  | 166,641 |  |  | 184,504 |  |  | (17,863) |  |  | (9.7) | % |  |  |  |  |  |  |  |  |
| Industrial |  | 84,548 |  |  | 73,005 |  |  | 11,543 |  |  | 15.8 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 609,782 |  |  | $ | 623,330 |  |  | $ | (13,548) |  |  | (2.2) | % |  |  |  |  |  |  |  |  |

[0000889331-23-000095:mdna:37]
[same as prior period, unchanged from 0000889331-22-000046:mdna:47]

[0000889331-23-000095:mdna:38]
Net sales decreased $7.2 million, or 2.0%, in the first quarter of 2023 compared to the first quarter of 2022 and included unfavorable changes in foreign exchange rates of $4.7 million. The sales decrease was mainly due to lower volume from the Electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, and telecom, which more than offset the incremental net sales of $42.5 million from the C&K acquisition and $14.1 million of higher volume from the semiconductor business driven by increased demand predominantly in our industrial and medical end markets.

[0000889331-23-000095:mdna:39]
[same as prior period, unchanged from 0000889331-22-000046:mdna:50]

[0000889331-23-000095:mdna:40]
Net sales decreased $17.9 million, or 9.7%, in the first quarter of 2023 compared to the first quarter of 2022 and included unfavorable changes in foreign exchange rates of $4.8 million. The commercial vehicle business net sales declined $9.7 million driven by reduced demand across various commercial vehicle end markets and inventory rebalancing at certain distributors, partially offset by price realization. The automotive sensors and passenger car products businesses had net sales declines of $5.3 million and $2.8 million, respectively, primarily due to lower demand in China and certain automotive customers rebalancing their inventory levels of the Company's products, partially offset by price realization.

[0000889331-23-000095:mdna:41]
[same as prior period, unchanged from 0000889331-22-000046:mdna:54]

[0000889331-23-000095:mdna:42]
Net sales increased by $11.5 million, or 15.8%, in the first quarter of 2023 compared to the first quarter of 2022, which included unfavorable changes in foreign exchange rates of $0.5 million. The sales increase was primarily due to higher volume in the MRO/construction, renewables and industrial safety end markets, and the acquisition of Western Automation which contributed net sales of $2.7 million.

[0000889331-23-000095:mdna:43]
[same as prior period, unchanged from 0000889331-22-000046:mdna:57]

[0000889331-23-000095:mdna:44]
[same as prior period, unchanged from 0000889331-22-000046:mdna:58]

[0000889331-23-000095:mdna:45]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2023 |  | 2022 |  | Change |  | %Change |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | $ | 228,012 |  |  | $ | 260,218 |  |  | $ | (32,206) |  |  | (12.4) | % |  |  |  |  |  |  |  |  |
| Americas |  | 233,854 |  |  | 237,230 |  |  | (3,376) |  |  | (1.4) | % |  |  |  |  |  |  |  |  |
| Europe |  | 147,916 |  |  | 125,882 |  |  | 22,034 |  |  | 17.5 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 609,782 |  |  | $ | 623,330 |  |  | $ | (13,548) |  |  | (2.2) | % |  |  |  |  |  |  |  |  |

[0000889331-23-000095:mdna:46]
[same as prior period, unchanged from 0000889331-22-000046:mdna:60]

[0000889331-23-000095:mdna:47]
Net sales decreased $32.2 million, or 12.4%, in the first quarter of 2023 compared to the first quarter of 2022 and included unfavorable changes in foreign exchange rates of $4.0 million. The decrease in net sales was primarily due to lower net sales from electronics products business within Electronics segment and lower net sales across all businesses within Transportation segments, partially offset by incremental sales from the acquisition of C&K, and higher volume from the semiconductor business within the Electronics segment.

[0000889331-23-000095:mdna:48]
[same as prior period, unchanged from 0000889331-22-000046:mdna:63]

[0000889331-23-000095:mdna:49]
Net sales decreased $3.4 million, or 1.4%, in the first quarter of 2023 compared to the first quarter of 2022 and included unfavorable changes in foreign exchange rates of $0.3 million. The decrease in net sales was primarily due to lower net sales from Electronics and Transportation segments, partially offset by incremental sales from C&K acquisition within the Electronics segment, and higher volume within the Industrial segment compared to the first quarter of 2022.

[0000889331-23-000095:mdna:50]
[same as prior period, unchanged from 0000889331-22-000046:mdna:66]

[0000889331-23-000095:mdna:51]
Net sales increased $22.0 million, or 17.5%, in the first quarter of 2023 compared to the first quarter of 2022 and included unfavorable changes in foreign exchange rates of $5.7 million. The increase in net sales was primarily due to incremental sales from the acquisition of C&K, increased volume from the semiconductor business within the Electronics segment, and incremental sales from the Western Automation acquisition included within the Industrial segment compared to the first quarter of 2022.

[0000889331-23-000095:mdna:52]
[same as prior period, unchanged from 0000889331-22-000046:mdna:69]

[0000889331-23-000095:mdna:53]
[same as prior period, unchanged from 0000889331-22-000046:mdna:70]

[0000889331-23-000095:mdna:54]
Cash and cash equivalents were $425.1 million as of April 1, 2023, a decrease of $137.5 million as compared to December 31, 2022. As of April 1, 2023, $79.9 million of the Company's $425.1 million cash and cash equivalents was held by U.S. subsidiaries.

[0000889331-23-000095:mdna:55]
Revolving Credit Facility and Term Loan

[0000889331-23-000095:mdna:56]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000095:mdna:57]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000095:mdna:58]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended April 1, 2023, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $294.4 million, respectively, as of April 1, 2023.

[0000889331-23-000095:mdna:59]
[same as prior period, unchanged from 0000889331-22-000046:mdna:77]

[0000889331-23-000095:mdna:60]
As of April 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 5.91%.

[0000889331-23-000095:mdna:61]
As of April 1, 2023, the Company had no outstanding letters of credit under the Credit Facility and had $600.0 million of borrowing capacity available under the revolving Credit Facility. As of April 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-23-000095:mdna:62]
[same as prior period, unchanged from 0000889331-22-000046:mdna:80]

[0000889331-23-000095:mdna:63]
[same as prior period, unchanged from 0000889331-22-000046:mdna:81]

[0000889331-23-000095:mdna:64]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-23-000095:mdna:65]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000095:mdna:66]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000095:mdna:67]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-23-000095:mdna:68]
Debt Covenants

[0000889331-23-000095:mdna:69]
The Company was in compliance with all covenants under the Credit Agreement and Senior Notes as of April 1, 2023 and currently expects to remain in compliance based on management’s estimates of operating and financial results for 2023. As of April 1, 2023, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-23-000095:mdna:70]
[same as prior period, unchanged from 0000889331-22-000046:mdna:88]

[0000889331-23-000095:mdna:71]
On February 3, 2023, the Company acquired Western Automation for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The business is reported within the Company’s Industrial segment. The Company financed the transaction with cash on hand.

[0000889331-23-000095:mdna:72]
[same as prior period, unchanged from 0000889331-22-000046:mdna:90]

[0000889331-23-000095:mdna:73]
During the first quarter of 2023 the Company paid quarterly dividends of $14.9 million to the shareholders. On May 2, 2023, the Board of Directors of the Company declared quarterly cash dividend of $0.60 per share, payable on June 8, 2023 to stockholders of record as of May 25, 2023.

[0000889331-23-000095:mdna:74]
[same as prior period, unchanged from 0000889331-22-000046:mdna:92]

[0000889331-23-000095:mdna:75]
|  |  | First Three Months |
| (in thousands) |  | 2023 |  | 2022 |
| Net cash provided by operating activities |  | $ | 53,407 |  |  | $ | 51,731 |  |
| Net cash used in investing activities |  | (183,188) |  |  | (29,788) |  |
| Net cash used in financing activities |  | (12,204) |  |  | (37,070) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 4,571 |  |  | (2,738) |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (137,414) |  |  | (17,865) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 564,939 |  |  | 482,836 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 427,525 |  |  | $ | 464,971 |  |

[0000889331-23-000095:mdna:76]
[same as prior period, unchanged from 0000889331-22-000046:mdna:94]

[0000889331-23-000095:mdna:77]
[same as prior period, unchanged from 0000889331-22-000046:mdna:95]

[0000889331-23-000095:mdna:78]
Net cash provided by operating activities was $53.4 million for the three months ended April 1, 2023 as compared to $51.7 million for the three months ended April 2, 2022. The increase in net cash provided by operating activities was primarily due to reductions in working capital, partially offset by lower cash earnings

[0000889331-23-000095:mdna:79]
[same as prior period, unchanged from 0000889331-22-000046:mdna:97]

[0000889331-23-000095:mdna:80]
Net cash used in investing activities was $183.2 million for the three months ended April 1, 2023 compared to $29.8 million during the three months ended April 2, 2022. Net cash paid for West Automation acquisition was $158.3 million during the three months ended April 1, 2023. Capital expenditures were $25.7 million, representing a decrease of $4.1 million compared to three months ended April 2, 2022

[0000889331-23-000095:mdna:81]
[same as prior period, unchanged from 0000889331-22-000046:mdna:99]

[0000889331-23-000095:mdna:82]
Net cash used in financing activities was $12.2 million for the three months ended April 1, 2023 compared to net cash used in financing activities of $37.1 million for the three months ended April 2, 2022. During the three months ended April 2, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022. Additionally, the Company paid dividends of $14.9 million and $13.1 million in the three months ended April 1, 2023 and April 2, 2022, respectively.

[0000889331-23-000095:mdna:83]
[same as prior period, unchanged from 0000889331-22-000046:mdna:102]

[0000889331-23-000095:mdna:84]
On April 28, 2021, the Company announced that the Board of Directors authorized a new three-year program to repurchase up to $300 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 to replace its previous 2020 program.

[0000889331-23-000095:mdna:85]
The Company did not repurchase any shares of its common stock for the three months ended April 1, 2023, and April 2, 2022.

[0000889331-23-000095:mdna:86]
[same as prior period, unchanged from 0000889331-22-000046:mdna:105]

[0000889331-23-000095:mdna:87]
As of April 1, 2023, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-23-000095:mdna:88]
[same as prior period, unchanged from 0000889331-22-000046:mdna:107]

[0000889331-23-000095:mdna:89]
[same as prior period, unchanged from 0000889331-22-000046:mdna:108]

[0000889331-23-000095:mdna:90]
The significant accounting policies and critical accounting estimates are consistent with those discussed in Note 1, Summary of Significant Accounting Policies and Other Information, to the consolidated financial statements and the MD&A section of the Company’s Annual Report on Form 10-K for the year ended December 31, 2022. During the three months ended April 1, 2023, there were no significant changes in the application of critical accounting policies.
