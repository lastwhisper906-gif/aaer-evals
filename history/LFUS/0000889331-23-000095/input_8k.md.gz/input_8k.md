# LFUS 8-K — 0000889331-23-000091 filed 2023-05-02

## item codes, every 8-K on or before 2023-05-03

- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2023-05-03

- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-23-000091:8k_2_02:1]
EX-99.1
2
q12023earningsreleaseex991.htm
EX-99.1

[0000889331-23-000091:8k_2_02:2]
Document

[0000889331-23-000091:8k_2_02:3]
Exhibit 99.1

[0000889331-23-000091:8k_2_02:4]
| NEWS RELEASE | Littelfuse Inc.8755 West Higgins Road, Suite 500Chicago, Illinois 60631p: (773) 628-1000 f: (773) 628-0802www.littelfuse.com |

[0000889331-23-000091:8k_2_02:5]
LITTELFUSE REPORTS FIRST QUARTER RESULTS FOR 2023

[0000889331-23-000091:8k_2_02:6]
Strong company performance above guidance

[0000889331-23-000091:8k_2_02:7]
CHICAGO, May 2, 2023  - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the first quarter ended April 1, 2023:

[0000889331-23-000091:8k_2_02:8]
•Net sales of $609.8 million were down 2% versus the prior year period, and down 8% organically

[0000889331-23-000091:8k_2_02:9]
•GAAP diluted EPS was $3.54; adjusted diluted EPS was $3.64

[0000889331-23-000091:8k_2_02:10]
•Cash flow from operations was $53.4 million, up 3% from the prior year period, and free cash flow was $27.7 million, up 26% from the prior year period

[0000889331-23-000091:8k_2_02:11]
•On February 3, the company completed the acquisition of Western Automation Research and Development Limited, a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables

[0000889331-23-000091:8k_2_02:12]
“Our global teams delivered strong first quarter results, above our sales and adjusted EPS guidance, within a tougher electronics environment,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “The continued resiliency of our business model and the strength of our execution drove strong overall profitability. During the quarter, we made significant progress integrating our strategy-led acquisitions and securing meaningful new business wins within the global structural themes of sustainability, connectivity, and safety. As we continue to manage through some near-term market challenges, our execution, diversification and strategic investments for growth will deliver sustained long-term value for all of our stakeholders.”

[0000889331-23-000091:8k_2_02:13]
Second Quarter of 2023*

[0000889331-23-000091:8k_2_02:14]
Based on current market conditions, for the second quarter the company expects,

[0000889331-23-000091:8k_2_02:15]
•Net sales in the range of $607 to $633 million, adjusted diluted EPS in the range of $3.20 to $3.45 and an adjusted effective tax rate of approximately 16%

[0000889331-23-000091:8k_2_02:16]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-23-000091:8k_2_02:17]
-more-

[0000889331-23-000091:8k_2_02:18]
Dividend

[0000889331-23-000091:8k_2_02:19]
•The company will pay a cash dividend on its common stock of $0.60 per share on June 8, 2023, to shareholders of record as of May 25, 2023

[0000889331-23-000091:8k_2_02:20]
Conference Call and Webcast Information

[0000889331-23-000091:8k_2_02:21]
Littelfuse will host a conference call on Wednesday, May 3, 2023, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-23-000091:8k_2_02:22]
About Littelfuse

[0000889331-23-000091:8k_2_02:23]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-23-000091:8k_2_02:24]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks and uncertainties, include, but are not limited to, risks and uncertainties relating to general economic conditions; the severity and duration of the COVID-19 pandemic and the measures taken in response thereto and the effects of those items on the company’s business; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse's accounting policies; labor disputes; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 31, 2022. Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 31, 2022, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-23-000091:8k_2_02:25]
-more

[0000889331-23-000091:8k_2_02:26]
Non-GAAP Financial Measures

[0000889331-23-000091:8k_2_02:27]
The information included in this press release includes the non-GAAP financial measures of organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations.

[0000889331-23-000091:8k_2_02:28]
A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules.

[0000889331-23-000091:8k_2_02:29]
The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-23-000091:8k_2_02:30]
CONTACT: Trisha Tuntland

[0000889331-23-000091:8k_2_02:31]
Head of Investor Relations

[0000889331-23-000091:8k_2_02:32]
(773) 628-2163

[0000889331-23-000091:8k_2_02:33]
LFUS-F

[0000889331-23-000091:8k_2_02:34]
###

[0000889331-23-000091:8k_2_02:35]
LITTELFUSE, INC.

[0000889331-23-000091:8k_2_02:36]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000889331-23-000091:8k_2_02:37]
|  |  | (Unaudited) |  |  |
| (in thousands) |  | April 1,2023 |  | December 31,2022 |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 425,127 |  |  | $ | 562,588 |  |
| Short-term investments |  | 85 |  |  | 84 |  |
| Trade receivables, less allowances of $88,923 and $83,562 at April 1, 2023 and December 31, 2022, respectively |  | 324,583 |  |  | 306,578 |  |
| Inventories |  | 559,828 |  |  | 547,690 |  |
| Prepaid income taxes and income taxes receivable |  | 5,857 |  |  | 7,215 |  |
| Prepaid expenses and other current assets |  | 86,124 |  |  | 87,641 |  |
| Total current assets |  | 1,401,604 |  |  | 1,511,796 |  |
| Net property, plant, and equipment |  | 492,368 |  |  | 481,110 |  |
| Intangible assets, net of amortization |  | 646,963 |  |  | 593,970 |  |
| Goodwill |  | 1,289,229 |  |  | 1,186,922 |  |
| Investments |  | 26,581 |  |  | 24,121 |  |
| Deferred income taxes |  | 13,780 |  |  | 14,367 |  |
| Right of use lease assets, net |  | 56,583 |  |  | 57,382 |  |
| Other long-term assets |  | 34,628 |  |  | 34,066 |  |
| Total assets |  | $ | 3,961,736 |  |  | $ | 3,903,734 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 191,346 |  |  | $ | 208,571 |  |
| Accrued liabilities |  | 147,776 |  |  | 187,057 |  |
| Accrued income taxes |  | 42,587 |  |  | 41,793 |  |
| Current portion of long-term debt |  | 137,929 |  |  | 134,874 |  |
| Total current liabilities |  | 519,638 |  |  | 572,295 |  |
| Long-term debt, less current portion |  | 866,925 |  |  | 866,623 |  |
| Deferred income taxes |  | 109,453 |  |  | 100,230 |  |
| Accrued post-retirement benefits |  | 29,557 |  |  | 28,037 |  |
| Non-current operating lease liabilities |  | 43,919 |  |  | 45,661 |  |
| Other long-term liabilities |  | 84,768 |  |  | 79,510 |  |
| Total equity |  | 2,307,476 |  |  | 2,211,378 |  |
| Total liabilities and equity |  | $ | 3,961,736 |  |  | $ | 3,903,734 |  |

[0000889331-23-000091:8k_2_02:38]
LITTELFUSE, INC.

[0000889331-23-000091:8k_2_02:39]
CONDENSED CONSOLIDATED STATEMENTS OF NET INCOME

[0000889331-23-000091:8k_2_02:40]
(Unaudited)

[0000889331-23-000091:8k_2_02:41]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share data) |  | April 1,2023 |  | April 2,2022 |  |  |  |  |
| Net sales |  | $ | 609,782 |  |  | $ | 623,330 |  |  |  |  |  |
| Cost of sales |  | 364,825 |  |  | 364,734 |  |  |  |  |  |
| Gross profit |  | 244,957 |  |  | 258,596 |  |  |  |  |  |
| Selling, general, and administrative expenses |  | 88,310 |  |  | 75,508 |  |  |  |  |  |
| Research and development expenses |  | 27,290 |  |  | 19,556 |  |  |  |  |  |
| Amortization of intangibles |  | 16,866 |  |  | 12,724 |  |  |  |  |  |
| Restructuring, impairment, and other charges |  | 1,850 |  |  | 218 |  |  |  |  |  |
| Total operating expenses |  | 134,316 |  |  | 108,006 |  |  |  |  |  |
| Operating income |  | 110,641 |  |  | 150,590 |  |  |  |  |  |
| Interest expense |  | 9,646 |  |  | 4,302 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (1,675) |  |  | 7,736 |  |  |  |  |  |
| Other (income) expense, net |  | (6,233) |  |  | 4,427 |  |  |  |  |  |
| Income before income taxes |  | 108,903 |  |  | 134,125 |  |  |  |  |  |
| Income taxes |  | 20,158 |  |  | 16,607 |  |  |  |  |  |
| Net income |  | $ | 88,745 |  |  | $ | 117,518 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.58 |  |  | $ | 4.76 |  |  |  |  |  |
| Diluted |  | $ | 3.54 |  |  | $ | 4.70 |  |  |  |  |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,782 |  |  | 24,689 |  |  |  |  |  |
| Diluted |  | 25,062 |  |  | 24,981 |  |  |  |  |  |
| Comprehensive income |  | $ | 102,028 |  |  | $ | 115,315 |  |  |  |  |  |

[0000889331-23-000091:8k_2_02:42]
LITTELFUSE, INC.

[0000889331-23-000091:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-23-000091:8k_2_02:44]
(Unaudited)

[0000889331-23-000091:8k_2_02:45]
|  |  | Three Months Ended |
| (in thousands) |  | April 1, 2023 |  | April 2, 2022 |
| OPERATING ACTIVITIES |  |  |  |  |
| Net income |  | $ | 88,745 |  |  | $ | 117,518 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  | 32,558 |  |  | 47,966 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Trade receivables |  | (13,176) |  |  | (45,945) |  |
| Inventories |  | (1,535) |  |  | (30,879) |  |
| Accounts payable |  | (16,246) |  |  | (6,611) |  |
| Accrued liabilities and income taxes |  | (43,578) |  |  | (36,287) |  |
| Prepaid expenses and other assets |  | 6,639 |  |  | 5,969 |  |
| Net cash provided by operating activities |  | 53,407 |  |  | 51,731 |  |
| INVESTING ACTIVITIES |  |  |  |  |
| Acquisitions of businesses, net of cash acquired |  | (158,260) |  |  | — |  |
| Purchases of property, plant, and equipment |  | (25,665) |  |  | (29,809) |  |
| Net proceeds from sale of property, plant and equipment, and other |  | 737 |  |  | 21 |  |
| Net cash used in investing activities |  | (183,188) |  |  | (29,788) |  |
| FINANCING ACTIVITIES |  |  |  |  |
| Net payments of credit facility |  | (1,875) |  |  | (25,000) |  |
| Cash dividends paid |  | (14,880) |  |  | (13,086) |  |
| All other cash provided by financing activities |  | 4,551 |  |  | 1,016 |  |
| Net cash used in financing activities |  | (12,204) |  |  | (37,070) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash |  | 4,571 |  |  | (2,738) |  |
| Decrease in cash, cash equivalents, and restricted cash |  | (137,414) |  |  | (17,865) |  |
| Cash, cash equivalents, and restricted cash at beginning of period |  | 564,939 |  |  | 482,836 |  |
| Cash, cash equivalents, and restricted cash at end of period |  | $ | 427,525 |  |  | $ | 464,971 |  |

[0000889331-23-000091:8k_2_02:46]
LITTELFUSE, INC.

[0000889331-23-000091:8k_2_02:47]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-23-000091:8k_2_02:48]
(Unaudited)

[0000889331-23-000091:8k_2_02:49]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2023 |  | 2022 |  |  |  | %Growth /(Decline) |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 358,593 |  |  | $ | 365,821 |  |  |  |  | (2.0) | % |  |  |  |  |  |  |  |  |
| Transportation |  | 166,641 |  |  | 184,504 |  |  |  |  | (9.7) | % |  |  |  |  |  |  |  |  |
| Industrial |  | 84,548 |  |  | 73,005 |  |  |  |  | 15.8 | % |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 609,782 |  |  | $ | 623,330 |  |  |  |  | (2.2) | % |  |  |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 90,162 |  |  | $ | 120,577 |  |  |  |  | (25.2) | % |  |  |  |  |  |  |  |  |
| Transportation |  | 8,532 |  |  | 26,308 |  |  |  |  | (67.6) | % |  |  |  |  |  |  |  |  |
| Industrial |  | 17,141 |  |  | 12,505 |  |  |  |  | 37.1 | % |  |  |  |  |  |  |  |  |
| Other(a) |  | (5,194) |  |  | (8,800) |  |  |  |  | N.M. |  |  |  |  |  |  |  |  |
| Total operating income |  | $ | 110,641 |  |  | $ | 150,590 |  |  |  |  | (26.5) | % |  |  |  |  |  |  |  |  |
| Operating Margin |  | 18.1 | % |  | 24.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | 9,646 |  |  | 4,302 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (1,675) |  |  | 7,736 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other (income) expense, net |  | (6,233) |  |  | 4,427 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 108,903 |  |  | $ | 134,125 |  |  |  |  | (18.8) | % |  |  |  |  |  |  |  |  |

[0000889331-23-000091:8k_2_02:50]
(a) "other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-23-000091:8k_2_02:51]
N.M. - Not meaningful

[0000889331-23-000091:8k_2_02:52]
|  |  | First Quarter |  |  |
| (in thousands) |  | 2023 |  | 2022 |  | %Growth /(Decline) |  |  |  |  |  |  |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 25.1 | % |  | 33.0 | % |  | (7.9) | % |  |  |  |  |  |  |
| Transportation |  | 5.1 | % |  | 14.3 | % |  | (9.2) | % |  |  |  |  |  |  |
| Industrial |  | 20.3 | % |  | 17.1 | % |  | 3.2 | % |  |  |  |  |  |  |

[0000889331-23-000091:8k_2_02:53]
LITTELFUSE, INC.

[0000889331-23-000091:8k_2_02:54]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-23-000091:8k_2_02:55]
(In millions of USD except per share amounts - unaudited)

[0000889331-23-000091:8k_2_02:56]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-23 |  | Q1-22 |  |  |  |  |
| GAAP diluted EPS |  | $ | 3.54 |  |  | $ | 4.70 |  |  |  |  |  |
| EPS impact of Non-GAAP adjustments (below) |  | 0.10 |  |  | 0.29 |  |  |  |  |  |
| Adjusted diluted EPS |  | $ | 3.64 |  |  | $ | 4.99 |  |  |  |  |  |

[0000889331-23-000091:8k_2_02:57]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q1-23 |  | Q1-22 |  |  |  |  |
| Acquisition-related and integration costs (a) |  | $ | 3.3 |  |  | $ | 3.8 |  |  |  |  |  |
| Purchase accounting inventory adjustments (b) |  | — |  |  | 4.8 |  |  |  |  |  |
| Restructuring, impairment and other charges (c) |  | 1.9 |  |  | 0.2 |  |  |  |  |  |
| Non-GAAP adjustments to operating income |  | 5.2 |  |  | 8.8 |  |  |  |  |  |
| Other income, net (d) |  | (0.2) |  |  | — |  |  |  |  |  |
| Non-operating foreign exchange (gain) loss |  | (1.7) |  |  | 7.7 |  |  |  |  |  |
| Non-GAAP adjustments to income before income taxes |  | 3.3 |  |  | 16.5 |  |  |  |  |  |
| Income taxes (e) |  | 0.9 |  |  | 9.5 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | $ | 2.4 |  |  | $ | 7.0 |  |  |  |  |  |
| Total EPS impact |  | $ | 0.10 |  |  | $ | 0.29 |  |  |  |  |  |

[0000889331-23-000091:8k_2_02:58]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-23 |  | Q1-22 |  |  |  |  |
| Net sales |  | $ | 609.8 |  |  | $ | 623.3 |  |  |  |  |  |
| GAAP operating income |  | $ | 110.6 |  |  | $ | 150.6 |  |  |  |  |  |
| Add back non-GAAP adjustments |  | 5.2 |  |  | 8.8 |  |  |  |  |  |
| Adjusted operating income |  | $ | 115.8 |  |  | $ | 159.4 |  |  |  |  |  |
| Adjusted operating margin |  | 19.0 | % |  | 25.6 | % |  |  |  |  |
| Add back amortization |  | 16.9 |  |  | 12.7 |  |  |  |  |  |
| Add back depreciation |  | 17.6 |  |  | 15.6 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 150.3 |  |  | $ | 187.7 |  |  |  |  |  |
| Adjusted EBITDA margin |  | 24.6 | % |  | 30.1 | % |  |  |  |  |

[0000889331-23-000091:8k_2_02:59]
| Adjusted EBITDA by Segment |  | Q1-23 |  | Q1-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 90.2 |  |  | $ | 8.5 |  |  | $ | 17.1 |  |  | $ | 120.6 |  |  | $ | 26.3 |  |  | $ | 12.5 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 10.2 |  |  | 4.5 |  |  | 2.2 |  |  | 6.8 |  |  | 4.7 |  |  | 1.2 |  |
| Add back depreciation |  | 9.6 |  |  | 6.8 |  |  | 1.2 |  |  | 8.6 |  |  | 6.0 |  |  | 1.0 |  |
| Adjusted EBITDA |  | $ | 110.0 |  |  | $ | 19.8 |  |  | $ | 20.5 |  |  | $ | 136.0 |  |  | $ | 37.0 |  |  | $ | 14.7 |  |
| Adjusted EBITDA Margin |  | 30.7 | % |  | 11.9 | % |  | 24.3 | % |  | 37.2 | % |  | 20.1 | % |  | 20.1 | % |

[0000889331-23-000091:8k_2_02:60]
| Net sales reconciliation |  | Q1-23 vs. Q1-22 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (2) | % |  | (10) | % |  | 16 | % |  | (2) | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 12 | % |  | 1 | % |  | 4 | % |  | 7 | % |
| FX impact |  | (2) | % |  | (3) | % |  | (1) | % |  | (1) | % |
| Organic net sales (decline) growth |  | (12) | % |  | (8) | % |  | 13 | % |  | (8) | % |

[0000889331-23-000091:8k_2_02:61]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-23 |  | Q1-22 |  |  |  |  |
| Income taxes |  | $ | 20.2 |  |  | $ | 16.6 |  |  |  |  |  |
| Effective rate |  | 18.5 | % |  | 12.4 | % |  |  |  |  |
| Non-GAAP adjustments - income taxes |  | 0.9 |  |  | 9.5 |  |  |  |  |  |
| Adjusted income taxes |  | $ | 21.1 |  |  | $ | 26.1 |  |  |  |  |  |
| Adjusted effective rate |  | 18.8 | % |  | 17.3 | % |  |  |  |  |
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q1-23 |  | Q1-22 |  |  |  |  |
| Net cash provided by operating activities |  | $ | 53.4 |  |  | $ | 51.7 |  |  |  |  |  |
| Less: Purchases of property, plant and equipment |  | (25.7) |  |  | (29.8) |  |  |  |  |  |
| Free cash flow |  | $ | 27.7 |  |  | $ | 21.9 |  |  |  |  |  |

[0000889331-23-000091:8k_2_02:62]
| Consolidated Total Debt |  | As of April 1, 2023 |
| Consolidated Total Debt |  | $ | 1,004.9 |  |
| Unamortized debt issuance costs |  | 4.6 |  |
| Consolidated funded indebtedness |  | 1,009.5 |  |
| Cash held in U.S. (up to $400 million) |  | 79.9 |
| Net debt |  | $ | 929.6 |  |
| Consolidated EBITDA |  | Twelve Months Ended April 1, 2023 |
| Net Income |  | $ | 344.4 |  |
| Interest expense |  | 31.6 |  |
| Income taxes |  | 73.3 |  |
| Depreciation |  | 67.1 |  |
| Amortization |  | 59.8 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 23.5 |  |
| Purchase accounting inventory step-up charge |  | 10.8 |  |
| Unrealized loss on investments |  | 7.5 |  |
| Impairment charges |  | 4.5 |  |
| Other |  | 56.9 |  |
| Consolidated EBITDA (1) |  | $ | 679.4 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.4x |

[0000889331-23-000091:8k_2_02:63]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2023 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-23-000091:8k_2_02:64]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-23-000091:8k_2_02:65]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-23-000091:8k_2_02:66]
Note: Total will not always foot due to rounding.

[0000889331-23-000091:8k_2_02:67]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-23-000091:8k_2_02:68]
(b) reflected in cost of sales.

[0000889331-23-000091:8k_2_02:69]
(c) reflected in restructuring, impairment and other charges.

[0000889331-23-000091:8k_2_02:70]
(d) reflected gain of $0.2 million from the sale of a building within the Electronics segment in the first quarter of 2023.

[0000889331-23-000091:8k_2_02:71]
(e) reflected the tax impact associated with the non-GAAP adjustments, and 2022 amount includes the one-time net benefit of $7.2 million that resulted from the dissolution of one of the Company’s affiliates.

[0000889331-23-000091:8k_2_02:72]
###
