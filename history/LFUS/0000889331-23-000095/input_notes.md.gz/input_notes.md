# LFUS notes — 0000889331-23-000095


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-23-000095:notes:1]
[same as prior period, unchanged from 0000889331-22-000046:notes:1]

[0000889331-23-000095:notes:2]
[same as prior period, unchanged from 0000889331-22-000046:notes:2]

[0000889331-23-000095:notes:3]
Founded in 1927, Littelfuse is an industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 18,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-23-000095:notes:4]
[same as prior period, unchanged from 0000889331-22-000046:notes:4]

[0000889331-23-000095:notes:5]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 31, 2022, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

[0000889331-23-000095:notes:6]
[same as prior period, unchanged from 0000889331-22-000046:notes:6]

[0000889331-23-000095:notes:7]
[same as prior period, unchanged from 0000889331-22-000046:notes:7]

[0000889331-23-000095:notes:8]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 1, 2023 and April 2, 2022:

[0000889331-23-000095:notes:9]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 148,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 148,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 209,995 |  |  | — |  |  | — |  |  | 209,995 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |

[0000889331-23-000095:notes:10]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

[0000889331-23-000095:notes:11]
[same as prior period, unchanged from 0000889331-22-000046:notes:11]

[0000889331-23-000095:notes:12]
[same as prior period, unchanged from 0000889331-22-000046:notes:12]

[0000889331-23-000095:notes:13]
[same as prior period, unchanged from 0000889331-22-000046:notes:13]

[0000889331-23-000095:notes:14]
[same as prior period, unchanged from 0000889331-22-000046:notes:14]

[0000889331-23-000095:notes:15]
[same as prior period, unchanged from 0000889331-22-000046:notes:15]

[0000889331-23-000095:notes:16]
[same as prior period, unchanged from 0000889331-22-000046:notes:16]

[0000889331-23-000095:notes:17]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-23-000095:notes:18]
[same as prior period, unchanged from 0000889331-22-000046:notes:19]

[0000889331-23-000095:notes:19]
[same as prior period, unchanged from 0000889331-22-000046:notes:20]

[0000889331-23-000095:notes:20]
[same as prior period, unchanged from 0000889331-22-000046:notes:21]

[0000889331-23-000095:notes:21]
[same as prior period, unchanged from 0000889331-22-000046:notes:22]

[0000889331-23-000095:notes:22]
[same as prior period, unchanged from 0000889331-22-000046:notes:23]

[0000889331-23-000095:notes:23]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at April 1, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

[0000889331-23-000095:notes:24]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 425,127 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 812 |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,586 |  |  | 1,549 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 427,525 |  |  | $ | 564,939 |  |

[0000889331-23-000095:notes:25]
Recently Issued Accounting Standards

[0000889331-23-000095:notes:26]
In March 2023, the Financial Accounting Standards Board ("FASB") issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective on January 1, 2024. The Company does not expect any material effect on the Company's Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000889331-23-000095:notes:27]
Acquisitions

[0000889331-23-000095:notes:28]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired business are included in the Company’s Condensed Consolidated Financial Statements from the date of the acquisition.

[0000889331-23-000095:notes:29]
Western Automation

[0000889331-23-000095:notes:30]
On February 3, 2023, the Company completed the previously announced acquisition of Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including e-Mobility off-board charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The business is reported within the Company’s Industrial segment.

[0000889331-23-000095:notes:31]
The acquisition was funded with cash on hand. The total purchase consideration of $158.3 million, net of cash, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. The primary area not yet finalized relates to the completion of the valuation of certain acquired income tax assets and liabilities. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-23-000095:notes:32]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the Western Automation acquisition:

[0000889331-23-000095:notes:33]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 158,260 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 3,389 |  |
| Inventories | 3,678 |  |
| Other current assets | 718 |  |
| Property, plant, and equipment | 1,328 |  |
| Intangible assets | 68,000 |  |
| Goodwill | 94,823 |  |
| Other non-current assets | 573 |  |
| Current liabilities | (5,251) |  |
| Other non-current liabilities | (8,998) |  |
|  | $ | 158,260 |  |

[0000889331-23-000095:notes:34]
All Western Automation assets and liabilities were recorded in the Industrial segment and are primarily reflected in the Europe geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining Western Automation’s products and technology with the Company’s existing Industrial products portfolio. Goodwill resulting from the Western Automation acquisition is not expected to be deductible for tax purposes.

[0000889331-23-000095:notes:35]
Included in the Company’s Condensed Consolidated Statements of Net Income for the three months ended April 1, 2023 are net sales of $2.7 million, and a loss before income taxes of $0.1 million, since the February 3, 2023 acquisition of Western Automation.

[0000889331-23-000095:notes:36]
During the three months ended April 1, 2023, the Company incurred approximately $1.4 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses. These costs were reflected as other non-segment costs.

[0000889331-23-000095:notes:37]
C&K Switches

[0000889331-23-000095:notes:38]
On July 19, 2022, the Company completed the previously announced acquisition of C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, datacom, and aerospace. At the time the Company and C&K entered into the definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the electronics-passive products and sensors business within the Company's Electronics segment.

[0000889331-23-000095:notes:39]
The acquisition was funded through a combination of cash on hand and debt. The total purchase consideration of $523.0 million, net of cash acquired, has been allocated, on a preliminary basis, to assets acquired and liabilities assumed, as of the completion of the acquisition, based on preliminary estimated fair values. The purchase price allocation is preliminary because the evaluations necessary to assess the fair values of the net assets acquired are still in process. As a result, these allocations are subject to change during the purchase price allocation period as the valuations are finalized.

[0000889331-23-000095:notes:40]
The following table summarizes the preliminary purchase price allocation of the fair value of assets acquired and liabilities assumed in the C&K acquisition:

[0000889331-23-000095:notes:41]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 523,014 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 20,967 |  |
| Inventories | 42,968 |  |
| Other current assets | 2,932 |  |
| Property, plant, and equipment | 32,791 |  |
| Intangible assets | 254,700 |  |
| Goodwill | 270,245 |  |
| Other non-current assets | 14,797 |  |
| Current liabilities | (47,734) |  |
| Long- term debt | (9,626) |  |
| Other non-current liabilities | (59,026) |  |
|  | $ | 523,014 |  |

[0000889331-23-000095:notes:42]
All C&K goodwill, other assets and liabilities were recorded in the Electronics segment and are reflected in the Americas, Europe and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining C&K’s products and technology with the Company’s existing Electronics products portfolio. Goodwill resulting from the C&K acquisition is not expected to be deductible for tax purposes.

[0000889331-23-000095:notes:43]
As required by purchase accounting rules, the Company recorded a $10.8 million step-up of inventory to its fair value as of the acquisition date based on the preliminary valuation. The step-up was amortized as a non-cash charge to cost of sales during the third and fourth quarter of 2022 as the acquired inventory was sold and reflected as other non-segment costs.

[0000889331-23-000095:notes:44]
Embed

[0000889331-23-000095:notes:45]
On April 12, 2022, the Company acquired Embed Ltd. (“Embed”).  Founded in 2005, Embed is a proven provider of embedded software and firmware developed for a broad range of applications serving transportation end markets, primarily including commercial vehicle electrification and eMobility. The business is included in the commercial vehicle business within the Company's Transportation segment. The acquisition was funded with the Company’s cash on hand. The total purchase consideration was $9.2 million, net of cash.

[0000889331-23-000095:notes:46]
Pro Forma Results

[0000889331-23-000095:notes:47]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and Western Automation as though the acquisition had occurred as of January 2, 2022, and C&K as though the acquisition had occurred as of December 27, 2020, and Carling as though the acquisition had occurred as of December 29, 2019. The Company has not included pro forma results of operations for Embed as its operations were not material to the Company. The pro forma amounts presented are not necessarily indicative of either the actual consolidated results had the Western Automation acquisition occurred as of January 2, 2022, and had the C&K acquisition occurred as of December 27, 2020 and had Carling acquisition occurred as of December 29, 2019 or of future consolidated operating results.

[0000889331-23-000095:notes:48]
|  |  | For the Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Net sales |  | $ | 611,668 |  |  | $ | 691,751 |  |  |  |  |  |
| Income before income taxes |  | 110,613 |  |  | 149,479 |  |  |  |  |  |
| Net income |  | 90,241 |  |  | 128,696 |  |  |  |  |  |
| Net income per share — basic |  | 3.64 |  |  | 5.21 |  |  |  |  |  |
| Net income per share — diluted |  | 3.60 |  |  | 5.15 |  |  |  |  |  |

[0000889331-23-000095:notes:49]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-23-000095:notes:50]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Amortization (a) |  | $ | (479) |  |  | $ | (3,731) |  |  |  |  |  |
| Depreciation |  | — |  |  | 723 |  |  |  |  |  |
| Transaction costs (b) |  | 1,397 |  |  | 1,979 |  |  |  |  |  |
| Amortization of inventory step-up (c) |  | — |  |  | 4,769 |  |  |  |  |  |
| Interest expense (d) |  | — |  |  | 194 |  |  |  |  |  |
| Income tax expense of above items |  | (115) |  |  | (1,195) |  |  |  |  |  |

[0000889331-23-000095:notes:51]
(a) The amortization adjustment for the three months ended April 1, 2023 and April 2, 2022 primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-23-000095:notes:52]
(b) The transaction cost adjustments reflect the reversal of certain legal and professional fees from the three months ended April 1, 2023 and April 2, 2022, and recognition of those fees during the three months ended April 2, 2022.

[0000889331-23-000095:notes:53]
(c) The amortization of inventory step-up adjustment reflects the reversal of the amount recognized related to the Carling acquisition during the three months ended April 2, 2022. The inventory step-up was amortized over four months as the inventory was sold.

[0000889331-23-000095:notes:54]
(d) The interest expense adjustment reflects incremental interest expense related to the financing of the C&K acquisition.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-23-000095:notes:55]
[same as prior period, unchanged from 0000889331-22-000046:notes:68]

[0000889331-23-000095:notes:56]
The components of inventories at April 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000095:notes:57]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Raw materials |  | $ | 241,055 |  |  | $ | 231,043 |  |
| Work in process |  | 142,665 |  |  | 134,792 |  |
| Finished goods |  | 225,857 |  |  | 226,215 |  |
| Inventory reserves |  | (49,749) |  |  | (44,360) |  |
| Total |  | $ | 559,828 |  |  | $ | 547,690 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-23-000095:notes:58]
Property, Plant, and Equipment

[0000889331-23-000095:notes:59]
The components of net property, plant, and equipment at April 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000095:notes:60]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Land and land improvements |  | $ | 22,112 |  |  | $ | 22,089 |  |
| Building and building improvements |  | 196,419 |  |  | 191,733 |  |
| Machinery and equipment |  | 840,164 |  |  | 812,540 |  |
| Accumulated depreciation |  | (566,327) |  |  | (545,252) |  |
| Total |  | $ | 492,368 |  |  | $ | 481,110 |  |

[0000889331-23-000095:notes:61]
The Company recorded depreciation expense of $17.6 million and $15.6 million for the three months ended April 1, 2023 and April 2, 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-23-000095:notes:62]
[same as prior period, unchanged from 0000889331-22-000046:notes:74]

[0000889331-23-000095:notes:63]
Changes in the carrying value of goodwill by segment for the three months ended April 1, 2023 are as follows:

[0000889331-23-000095:notes:64]
| (in thousands) |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net book value of goodwill as of December 31, 2022 |  |  |  |  |  |  |  |  |
| Gross goodwill as of December 31, 2022 |  | $ | 909,167 |  |  | $ | 234,793 |  |  | $ | 84,889 |  |  | $ | 1,228,849 |  |
| Accumulated impairment losses as of December 31, 2022 |  | — |  |  | (33,401) |  |  | (8,526) |  |  | (41,927) |  |
| Total |  | 909,167 |  |  | 201,392 |  |  | 76,363 |  |  | 1,186,922 |  |
| Changes during 2023: |  |  |  |  |  |  |  |  |
| Additions (a) |  | — |  |  | — |  |  | 94,823 |  |  | 94,823 |  |
| Currency translation |  | 5,846 |  |  | 1,551 |  |  | 87 |  |  | 7,484 |  |
| Net book value of goodwill as of April 1, 2023 |  |  |  |  |  |  |  |  |
| Gross goodwill as of April 1, 2023 |  | 915,013 |  |  | 236,945 |  |  | 179,820 |  |  | 1,331,778 |  |
| Accumulated impairment losses as of April 1, 2023 |  | — |  |  | (34,002) |  |  | $ | (8,547) |  |  | (42,549) |  |
| Total |  | $ | 915,013 |  |  | $ | 202,943 |  |  | $ | 171,273 |  |  | $ | 1,289,229 |  |

[0000889331-23-000095:notes:65]
(a) The additions resulted from the acquisitions of Western Automation.

[0000889331-23-000095:notes:66]
The components of other intangible assets as of April 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000095:notes:67]
|  |  |  | As of April 1, 2023 |
| (in thousands) |  |  | GrossCarryingValue |  | Accumulated Amortization |  | Net BookValue |
| Land use rights |  |  | $ | 18,169 |  |  | $ | 2,464 |  |  | $ | 15,705 |  |
| Patents, licenses and software |  |  | 271,890 |  |  | 146,126 |  |  | 125,764 |  |
| Distribution network |  |  | 43,089 |  |  | 42,793 |  |  | 296 |  |
| Customer relationships, trademarks, and tradenames |  |  | 682,364 |  |  | 177,166 |  |  | 505,198 |  |
| Total |  |  | $ | 1,015,512 |  |  | $ | 368,549 |  |  | $ | 646,963 |  |

[0000889331-23-000095:notes:68]
|  | December 31, 2022 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 17,938 |  |  | $ | 2,299 |  |  | $ | 15,639 |  |
| Patents, licenses and software | 259,603 |  |  | 140,208 |  |  | 119,395 |  |
| Distribution network | 41,733 |  |  | 40,955 |  |  | 778 |  |
| Customer relationships, trademarks, and tradenames | 623,721 |  |  | 165,563 |  |  | 458,158 |  |
| Total | $ | 942,995 |  |  | $ | 349,025 |  |  | $ | 593,970 |  |

[0000889331-23-000095:notes:69]
During the three months ended April 1, 2023 and April 2, 2022, the Company recorded amortization expense of $16.9 million and $12.7 million, respectively.

[0000889331-23-000095:notes:70]
During the three months ended April 1, 2023, the Company recorded additions to intangible assets of $68.0 million, related to the Western Automation acquisition, the components of which were as follows:

[0000889331-23-000095:notes:71]
| (in thousands) | Weighted Average Useful Life |  | Amount |
| Patents, licenses and software | 6.7 |  | $ | 11,500 |  |
| Customer relationships, trademarks, and tradenames | 14.7 |  | 56,500 |  |
| Total |  |  | $ | 68,000 |  |

[0000889331-23-000095:notes:72]
Estimated annual amortization expense related to intangible assets with definite lives as of April 1, 2023 is as follows:

[0000889331-23-000095:notes:73]
| (in thousands) | Amount |
| 2023 | $ | 65,821 |  |
| 2024 | 63,021 |  |
| 2025 | 62,654 |  |
| 2026 | 51,772 |  |
| 2027 | 49,673 |  |
| 2028 and thereafter | 370,888 |  |
| Total | $ | 663,829 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-23-000095:notes:74]
[same as prior period, unchanged from 0000889331-22-000046:notes:86]

[0000889331-23-000095:notes:75]
The components of accrued liabilities as of April 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000095:notes:76]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Employee-related liabilities |  | $ | 66,427 |  |  | $ | 99,089 |  |
| Current lease liability |  | 12,853 |  |  | 12,841 |  |
| Other non-income taxes |  | 7,691 |  |  | 10,594 |  |
| Professional services |  | 7,023 |  |  | 7,160 |  |
| Other customer reserves |  | 4,790 |  |  | 5,064 |  |
| Interest |  | 3,548 |  |  | 4,449 |  |
| Deferred revenue |  | 2,886 |  |  | 2,593 |  |
| Current benefit liability |  | 1,318 |  |  | 1,318 |  |
| Restructuring liability |  | 1,248 |  |  | 2,434 |  |
| Other |  | 39,992 |  |  | 41,515 |  |
| Total |  | $ | 147,776 |  |  | $ | 187,057 |  |

[0000889331-23-000095:notes:77]
[same as prior period, unchanged from 0000889331-22-000046:notes:89]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-23-000095:notes:78]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment and other charges for the three months ended April 1, 2023 and April 2, 2022 as follows:

[0000889331-23-000095:notes:79]
|  | Three months ended April 1, 2023 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 672 |  |  | $ | 582 |  |  | $ | 317 |  |  | $ | 1,571 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | 7 |  |  | 272 |  |  | — |  |  | 279 |  |  |  |  |  |  |  |  |  |
| Total | $ | 679 |  |  | $ | 854 |  |  | $ | 317 |  |  | $ | 1,850 |  |  |  |  |  |  |  |  |  |

[0000889331-23-000095:notes:80]
|  | Three months ended April 2, 2022 |  |  |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |  |  |  |  |  |  |  |  |
| Employee terminations | $ | 205 |  |  | $ | — |  |  | $ | — |  |  | $ | 205 |  |  |  |  |  |  |  |  |  |
| Other restructuring charges | — |  |  | 13 |  |  | — |  |  | 13 |  |  |  |  |  |  |  |  |  |
| Total | $ | 205 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 218 |  |  |  |  |  |  |  |  |  |

[0000889331-23-000095:notes:81]
2023

[0000889331-23-000095:notes:82]
For the three months ended April 1, 2023, the Company recorded total restructuring charges of $1.9 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment’s commercial vehicle business and the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K acquisition.

[0000889331-23-000095:notes:83]
[same as prior period, unchanged from 0000889331-22-000046:notes:93]

[0000889331-23-000095:notes:84]
For the three months ended April 2, 2022, the Company recorded total restructuring charges of $0.2 million, primarily for employee termination costs. These charges are primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Electronics segment.

[0000889331-23-000095:notes:85]
The restructuring liability as of April 1, 2023 and December 31, 2022 is $1.2 million and $2.4 million, respectively. The restructuring liability is included within accrued liabilities in the Condensed Consolidated Balance Sheets. The Company anticipates the remaining payments associated with employee terminations will primarily be completed in fiscal year 2023.


## us-gaap:DebtDisclosureTextBlock

[0000889331-23-000095:notes:86]
Debt

[0000889331-23-000095:notes:87]
The carrying amounts of debt at April 1, 2023 and December 31, 2022 are as follows:

[0000889331-23-000095:notes:88]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 294,375 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,706 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,693 |  |  | 101,265 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | — |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 8,651 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,571) |  |  | (4,847) |  |
| Total debt |  | 1,004,854 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,929) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 866,925 |  |  | $ | 866,623 |  |

[0000889331-23-000095:notes:89]
Revolving Credit Facility and Term Loan

[0000889331-23-000095:notes:90]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-23-000095:notes:91]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus —% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-23-000095:notes:92]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended April 1, 2023, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $294.4 million, respectively, as of April 1, 2023.

[0000889331-23-000095:notes:93]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-23-000095:notes:94]
As of April 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 5.91%.

[0000889331-23-000095:notes:95]
As of April 1, 2023, the Company had no outstanding letters of credit under the Credit Facility and had $600.0 million of borrowing capacity available under the revolving Credit Facility. As of April 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.

[0000889331-23-000095:notes:96]
Senior Notes

[0000889331-23-000095:notes:97]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). Interest on the Euro Senior Notes is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-23-000095:notes:98]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-23-000095:notes:99]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable semiannually on February 15 and August 15, commencing on August 15, 2018.

[0000889331-23-000095:notes:100]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-23-000095:notes:101]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-23-000095:notes:102]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-23-000095:notes:103]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At April 1, 2023, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-23-000095:notes:104]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-23-000095:notes:105]
Interest paid on all Company debt was $11.0 million and $6.0 million for the three months ended April 1, 2023 and April 2, 2022, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-23-000095:notes:106]
[same as prior period, unchanged from 0000889331-22-000046:notes:119]

[0000889331-23-000095:notes:107]
[same as prior period, unchanged from 0000889331-22-000046:notes:120]

[0000889331-23-000095:notes:108]
[same as prior period, unchanged from 0000889331-22-000046:notes:121]

[0000889331-23-000095:notes:109]
[same as prior period, unchanged from 0000889331-22-000046:notes:122]

[0000889331-23-000095:notes:110]
[same as prior period, unchanged from 0000889331-22-000046:notes:123]

[0000889331-23-000095:notes:111]
[same as prior period, unchanged from 0000889331-22-000046:notes:124]

[0000889331-23-000095:notes:112]
[same as prior period, unchanged from 0000889331-22-000046:notes:125]

[0000889331-23-000095:notes:113]
[same as prior period, unchanged from 0000889331-22-000046:notes:126]

[0000889331-23-000095:notes:114]
[same as prior period, unchanged from 0000889331-22-000046:notes:127]

[0000889331-23-000095:notes:115]
[same as prior period, unchanged from 0000889331-22-000046:notes:128]

[0000889331-23-000095:notes:116]
[same as prior period, unchanged from 0000889331-22-000046:notes:129]

[0000889331-23-000095:notes:117]
[same as prior period, unchanged from 0000889331-22-000046:notes:130]

[0000889331-23-000095:notes:118]
[same as prior period, unchanged from 0000889331-22-000046:notes:131]

[0000889331-23-000095:notes:119]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy, since all significant inputs are corroborated by market observable data.

[0000889331-23-000095:notes:120]
The use of derivatives creates exposure to credit risk relating to potential losses that could be recognized in the event that the counterparties to these instruments fail to perform their obligations under the contracts. The Company seeks to minimize this risk by limiting our counterparties to major financial institutions with acceptable credit ratings and monitoring the total value of

[0000889331-23-000095:notes:121]
positions with individual counterparties. In the event of a default by one of our counterparties, the Company may not receive payments provided for under the terms of our derivatives.

[0000889331-23-000095:notes:122]
[same as prior period, unchanged from 0000889331-22-000046:notes:134]

[0000889331-23-000095:notes:123]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at April 1, 2023 was €117.0 million and expires on December 7, 2023. The foreign currency contract was not designated as a hedge instrument and is marked to market on a monthly basis. As a result, changes in fair value are reported in Foreign exchange (gain) loss in the Consolidated Statements of Operations. The fair value of the foreign currency forward contract was valued using market exchange rates by a third party and classified as a Level 2 input under the fair value hierarchy.

[0000889331-23-000095:notes:124]
As of April 1, 2023, the fair values of our derivative financial instrument and their classifications on the Condensed Consolidated Balance Sheets were as follows:

[0000889331-23-000095:notes:125]
| (in thousands) | Consolidated Balance Sheet Classification |  | April 1, 2023 |  |  |
| Derivatives Designated as Hedging Instruments |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 3,593 |  |  |  |
|  | Other long-term assets |  | $ | 1,773 |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |
| Foreign exchange forward contract | Prepaid expenses and other current assets |  | $ | 7,092 |  |  |  |

[0000889331-23-000095:notes:126]
The pre-tax gains recognized on derivative financial instruments in the Condensed Consolidated Statements of Operations for the three months ended April 1, 2023 were as follows:

[0000889331-23-000095:notes:127]
|  |  |  |  | Three Months Ended |  |  |
| (in thousands) |  | Classification of Gain Recognized in theCondensed Consolidated Statements of Operations |  | April 1, 2023 |  |  |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | Interest expense |  | $ | (975) |  |  |  |  |  |  |  |
| Derivatives Not Designated as Hedging Instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange forward contract |  | Foreign exchange (gain) loss |  | $ | (819) |  |  |  |  |  |  |  |

[0000889331-23-000095:notes:128]
The pre-tax gain recognized on derivative financial instruments in the Condensed Consolidated Statements of Comprehensive Income for the three months ended April 1, 2023 was as follows:

[0000889331-23-000095:notes:129]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | April 1, 2023 |  |  |  |  |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | (5,366) |  |  |  |  |  |  |  |

[0000889331-23-000095:notes:130]
The pre-tax gain of $3.6 million from accumulated other comprehensive loss to earnings is expected to be recognized during the next twelve months.

[0000889331-23-000095:notes:131]
[same as prior period, unchanged from 0000889331-22-000046:notes:143]

[0000889331-23-000095:notes:132]
[same as prior period, unchanged from 0000889331-22-000046:notes:144]

[0000889331-23-000095:notes:133]
There were no changes during the quarter ended April 1, 2023 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of April 1, 2023 and December 31, 2022, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-23-000095:notes:134]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of April 1, 2023:

[0000889331-23-000095:notes:135]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 164,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 164,073 |  |
| Investments in equity securities |  | 12,715 |  |  | — |  |  | — |  |  | 12,715 |  |
| Mutual funds |  | 17,642 |  |  | — |  |  | — |  |  | 17,642 |  |
| Total |  | $ | 194,430 |  |  | $ | — |  |  | $ | — |  |  | $ | 194,430 |  |

[0000889331-23-000095:notes:136]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 31, 2022:

[0000889331-23-000095:notes:137]
|  |  | Fair Value Measurements Using |  |  |
| (in thousands) |  | Quoted Prices inActive Markets forIdentical Assets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Total |
| Cash equivalents |  | $ | 304,101 |  |  | $ | — |  |  | $ | — |  |  | $ | 304,101 |  |
| Investments in equity securities |  | 10,653 |  |  | — |  |  | — |  |  | 10,653 |  |
| Mutual funds |  | 14,094 |  |  | — |  |  | — |  |  | 14,094 |  |
| Total |  | $ | 328,848 |  |  | $ | — |  |  | $ | — |  |  | $ | 328,848 |  |

[0000889331-23-000095:notes:138]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, accounts receivable and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and accounts receivable approximate their fair values. The Company’s revolving and term loan debt facilities' fair values approximate book value at April 1, 2023 and December 31, 2022, as the rates on these borrowings are variable in nature.

[0000889331-23-000095:notes:139]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series A and Series B and USD Senior Notes, Series A and Series B, as of April 1, 2023 and December 31, 2022 were as follows:

[0000889331-23-000095:notes:140]
|  |  | April 1, 2023 |  | December 31, 2022 |
| (in thousands) |  | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series A due 2023 |  | $ | 127,706 |  |  | $ | 125,554 |  |  | $ | 124,716 |  |  | $ | 122,270 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,693 |  |  | 90,411 |  |  | 101,265 |  |  | 87,119 |  |
| USD Senior Notes, Series B due 2027 |  | 100,000 |  |  | 95,299 |  |  | 100,000 |  |  | 93,764 |  |
| USD Senior Notes, Series A due 2025 |  | 50,000 |  |  | 48,700 |  |  | 50,000 |  |  | 48,145 |  |
| USD Senior Notes, Series B due 2030 |  | 125,000 |  |  | 114,593 |  |  | 125,000 |  |  | 112,028 |  |
| USD Senior Notes, due 2032 |  | 100,000 |  |  | 92,406 |  |  | 100,000 |  |  | 90,131 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-23-000095:notes:141]
[same as prior period, unchanged from 0000889331-22-000046:notes:153]

[0000889331-23-000095:notes:142]
The Company has Company-sponsored and mandatory defined benefit pension plans covering employees in the United Kingdom ("U.K."), Germany, the Philippines, China, Japan, Mexico, Italy and France. The amount of the retirement benefits provided under the plans is generally based on years of service and final average pay.

[0000889331-23-000095:notes:143]
The Company recognizes interest cost, expected return on plan assets, and amortization of prior service, net within Other (income) expense, net in the Condensed Consolidated Statements of Net Income. The components of net periodic benefit cost for the three months ended April 1, 2023 and April 2, 2022 were as follows:

[0000889331-23-000095:notes:144]
|  |  | For the Three Months Ended |  |  |
| (in thousands) |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Components of net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 692 |  |  | $ | 768 |  |  |  |  |  |
| Interest cost |  | 937 |  |  | 644 |  |  |  |  |  |
| Expected return on plan assets |  | (469) |  |  | (403) |  |  |  |  |  |
| Amortization of prior service and net actuarial loss |  | 11 |  |  | 101 |  |  |  |  |  |
| Net periodic benefit cost |  | $ | 1,171 |  |  | $ | 1,110 |  |  |  |  |  |

[0000889331-23-000095:notes:145]
The Company expects to make approximately $2.0 million of contributions to the plans and pay $1.9 million of benefits directly in 2023.

[0000889331-23-000095:notes:146]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. The Company recorded expense of $0.4 million and $0.5 million for the three months ended April 1, 2023 and April 2, 2022, respectively, in Cost of Sales and Other (income) expense, net within the Condensed Consolidated Statements of Net Income. The pre-tax amounts recognized in other comprehensive income (loss) as components of net periodic benefit costs for these plans were nominal and $0.1 million for the three months ended April 1, 2023 and April 2, 2022, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-23-000095:notes:147]
Other Comprehensive Income 
Changes in other comprehensive income by component were as follows:

[0000889331-23-000095:notes:148]
| (in thousands) |  | Three Months EndedApril 1, 2023 |  |  |
|  |  | Pre-tax |  | Tax |  | Net of Tax |  |  |  |  |  |  |
| Defined benefit pension plan and other adjustments |  | $ | 24 |  |  | $ | (18) |  |  | $ | 6 |  |  |  |  |  |  |  |
| Cash flow hedge |  | (3,313) |  |  | 795 |  |  | (2,518) |  |  |  |  |  |  |  |
| Foreign currency translation adjustments (a) |  | 16,068 |  |  | (273) |  |  | 15,795 |  |  |  |  |  |  |  |
| Total change in other comprehensive income (loss) |  | $ | 12,779 |  |  | $ | 504 |  |  | $ | 13,283 |  |  |  |  |  |  |  |

[0000889331-23-000095:notes:149]
(a) The tax shown above within the foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries which have been previously taxed in the U.S. and are not permanently reinvested.

[0000889331-23-000095:notes:150]
The following tables set forth the changes in accumulated other comprehensive loss by component for the three months ended April 1, 2023 and April 2, 2022:

[0000889331-23-000095:notes:151]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  | Cash flow hedge |  | Foreign currencytranslation adjustment |  | Accumulated othercomprehensive loss |
| Balance at December 31, 2022 |  | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| Activity in the period |  | 6 |  |  | (2,518) |  |  | 15,795 |  |  | 13,283 |  |
| Balance at April 1, 2023 |  | $ | (2,187) |  |  | $ | 4,078 |  |  | $ | (84,372) |  |  | $ | (82,481) |  |

[0000889331-23-000095:notes:152]
| (in thousands) |  | Defined benefit pension plan and other adjustments |  |  |  | Foreign currency translation adjustment |  | Accumulated other comprehensive loss |
| Balance at January 1, 2022 |  | $ | (11,928) |  |  |  |  | $ | (61,535) |  |  | $ | (73,463) |  |
| Activity in the period |  | 310 |  |  |  |  | (2,513) |  |  | (2,203) |  |
| Balance at April 2, 2022 |  | $ | (11,618) |  |  |  |  | $ | (64,048) |  |  | $ | (75,666) |  |

[0000889331-23-000095:notes:153]
Amounts reclassified from accumulated other comprehensive loss to earnings for the three months ended April 1, 2023 and April 2, 2022 were as follows:

[0000889331-23-000095:notes:154]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Pension and Postemployment plans: |  |  |  |  |  |  |  |  |
| Amortization of prior service and net actuarial (gain) loss |  | $ | (11) |  |  | $ | 197 |  |  |  |  |  |

[0000889331-23-000095:notes:155]
[same as prior period, unchanged from 0000889331-22-000046:notes:166]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-23-000095:notes:156]
Income TaxesThe effective tax rate for the three months ended April 1, 2023 was 18.5%, compared to the effective tax rate for the three months ended April 2, 2022 of 12.4%. The effective tax rate for the first quarter of 2023 is higher than the effective tax rate for the comparable 2022 period, primarily due to the impact in the 2022 period of a one-time deduction that resulted in a net benefit of $7.2 million from the dissolution of one of the Company’s affiliates. The effective tax rates for both periods were lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions, while for the 2022 period, the effective tax rate also was lower due to the impact of the one-time deduction referred to in the preceding sentence.


## us-gaap:EarningsPerShareTextBlock

[0000889331-23-000095:notes:157]
[same as prior period, unchanged from 0000889331-22-000046:notes:169]

[0000889331-23-000095:notes:158]
[same as prior period, unchanged from 0000889331-22-000046:notes:170]

[0000889331-23-000095:notes:159]
|  |  | Three Months Ended |  |  |
| (in thousands, except per share amounts) |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 88,745 |  |  | $ | 117,518 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 24,782 |  |  | 24,689 |  |  |  |  |  |
| Effect of dilutive securities |  | 280 |  |  | 292 |  |  |  |  |  |
| Diluted |  | 25,062 |  |  | 24,981 |  |  |  |  |  |
| Earnings Per Share: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 3.58 |  |  | $ | 4.76 |  |  |  |  |  |
| Diluted earnings per share |  | $ | 3.54 |  |  | $ | 4.70 |  |  |  |  |  |

[0000889331-23-000095:notes:160]
Potential shares of common stock relating to stock options and restricted share units excluded from the earnings per share calculation because their effect would be anti-dilutive were 90,297 and 57,928 for the three months ended April 1, 2023 and April 2, 2022, respectively.

[0000889331-23-000095:notes:161]
[same as prior period, unchanged from 0000889331-22-000046:notes:173]

[0000889331-23-000095:notes:162]
[same as prior period, unchanged from 0000889331-22-000046:notes:174]

[0000889331-23-000095:notes:163]
The Company did not repurchase any shares of its common stock for the three months ended April 1, 2023, and April 2, 2022.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-23-000095:notes:164]
Related Party Transactions

[0000889331-23-000095:notes:165]
The Company has equity ownership in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-23-000095:notes:166]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-23-000095:notes:167]
EB-Tech Co., Ltd.: The Company owns approximately 19% of the outstanding equity of EB Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-23-000095:notes:168]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's Board of Directors serves on the Board of Directors of ATEC.

[0000889331-23-000095:notes:169]
|  |  | Three Months Ended April 1, 2023 |  | Three Months Ended April 2, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.0 |  | $ | 0.1 |  | $ | 2.7 |  |  | $ | 0.2 |  | $ | 0.1 |  | $ | 2.9 |  |
|  |  | April 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.6 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-23-000095:notes:170]
[same as prior period, unchanged from 0000889331-22-000046:notes:182]

[0000889331-23-000095:notes:171]
[same as prior period, unchanged from 0000889331-22-000046:notes:183]

[0000889331-23-000095:notes:172]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Purchasing, logistics, customer service, finance, information technology, and human resources are shared functions that are allocated back to the three operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other”. Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Although the CODM uses operating income (loss) to evaluate the segments, operating costs included in one segment may benefit other segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-23-000095:notes:173]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas

[0000889331-23-000095:notes:174]
discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes; and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related charging infrastructure, aerospace, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-23-000095:notes:175]
•Transportation Segment: Formerly known as Automotive segment. The term “Transportation” represents a more comprehensive description of the Company’s broad range of products, and the applications and end markets it serves. Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicle, heavy-duty truck, off-road vehicle, material handling, agricultural, construction and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engine, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck, construction, agriculture, material handling and marine.

[0000889331-23-000095:notes:176]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), industrial controls (protection relays, contactors, transformers, residual current devices, ground fault circuit interrupters, residual current monitors, and arc fault detection devices) and temperature sensors for use in various applications such as renewable energy and energy storage systems, industrial safety, industrial automation, electric vehicle infrastructure, HVAC systems, non-residential construction, MRO, and mining.

[0000889331-23-000095:notes:177]
[same as prior period, unchanged from 0000889331-22-000046:notes:189]

[0000889331-23-000095:notes:178]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 358,593 |  |  | $ | 365,821 |  |  |  |  |  |
| Transportation |  | 166,641 |  |  | 184,504 |  |  |  |  |  |
| Industrial |  | 84,548 |  |  | 73,005 |  |  |  |  |  |
| Total net sales |  | $ | 609,782 |  |  | $ | 623,330 |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 19,788 |  |  | $ | 15,393 |  |  |  |  |  |
| Transportation |  | 11,291 |  |  | 10,744 |  |  |  |  |  |
| Industrial |  | 3,403 |  |  | 2,161 |  |  |  |  |  |
| Total depreciation and amortization |  | $ | 34,482 |  |  | $ | 28,298 |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 90,162 |  |  | $ | 120,577 |  |  |  |  |  |
| Transportation |  | 8,532 |  |  | 26,308 |  |  |  |  |  |
| Industrial |  | 17,141 |  |  | 12,505 |  |  |  |  |  |
| Other (a) |  | (5,194) |  |  | (8,800) |  |  |  |  |  |
| Total operating income |  | 110,641 |  |  | 150,590 |  |  |  |  |  |
| Interest expense |  | 9,646 |  |  | 4,302 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (1,675) |  |  | 7,736 |  |  |  |  |  |
| Other (income) expense, net |  | (6,233) |  |  | 4,427 |  |  |  |  |  |
| Income before income taxes |  | $ | 108,903 |  |  | $ | 134,125 |  |  |  |  |  |

[0000889331-23-000095:notes:179]
(a) Included in “Other” Operating income for the first quarter of 2023 was $3.3 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $1.9 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000095:notes:180]
Included in “Other” Operating income for the first quarter of 2022 was $4.8 million of purchase accounting inventory step-up charges, $3.8 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, and $0.2 million of restructuring, impairment and other charges, primarily related to employee termination costs. See Note 7, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-23-000095:notes:181]
[same as prior period, unchanged from 0000889331-22-000046:notes:193]

[0000889331-23-000095:notes:182]
|  |  | Three Months Ended |  |  |
| (in thousands) |  | April 1, 2023 |  | April 2, 2022 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| United States |  | $ | 212,195 |  |  | $ | 220,238 |  |  |  |  |  |
| China |  | 133,467 |  |  | 164,782 |  |  |  |  |  |
| Other countries (a) |  | 264,120 |  |  | 238,310 |  |  |  |  |  |
| Total net sales |  | $ | 609,782 |  |  | $ | 623,330 |  |  |  |  |  |

[0000889331-23-000095:notes:183]
[same as prior period, unchanged from 0000889331-22-000046:notes:195]

[0000889331-23-000095:notes:184]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Long-lived assets |  |  |  |  |
| United States |  | $ | 77,246 |  |  | $ | 76,325 |  |
| China |  | 135,233 |  |  | 129,094 |  |
| Mexico |  | 107,427 |  |  | 107,119 |  |
| Germany |  | 41,049 |  |  | 39,635 |  |
| Philippines |  | 77,314 |  |  | 77,240 |  |
| Other countries (a) |  | 54,099 |  |  | 51,697 |  |
| Total long-lived assets |  | $ | 492,368 |  |  | $ | 481,110 |  |

[0000889331-23-000095:notes:185]
[same as prior period, unchanged from 0000889331-22-000046:notes:197]

[0000889331-23-000095:notes:186]
|  |  | Three Months Ended |
| (in thousands) |  | April 1, 2023 |  | April 2, 2022 |
| Additions to long-lived assets |  |  |  |  |
| United States |  | $ | 4,091 |  |  | $ | 3,174 |  |
| China |  | 8,403 |  |  | 6,949 |  |
| Mexico |  | 3,744 |  |  | 7,918 |  |
| Germany |  | 1,234 |  |  | 918 |  |
| Philippines |  | 1,398 |  |  | 6,970 |  |
| Other countries(a) |  | 2,593 |  |  | 1,561 |  |
| Total additions to long-lived assets |  | $ | 21,463 |  |  | $ | 27,490 |  |

[0000889331-23-000095:notes:187]
[same as prior period, unchanged from 0000889331-22-000046:notes:199]
