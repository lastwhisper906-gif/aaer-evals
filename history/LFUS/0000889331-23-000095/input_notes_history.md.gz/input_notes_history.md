# LFUS note change history — 0000889331-22-000046 → 0000889331-23-000095


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000889331-23-000095:note_history:1]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended December 31, 2022, which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.
  (was, 2022-11-02, similarity 0.7355):
[0000889331-22-000046:note_history:1]
The Company’s accompanying unaudited Condensed Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) for interim financial information, the instructions to Form 10-Q and Article 10 of Regulation S-X. Accordingly, certain information and disclosures normally included in the consolidated balance sheets, statements of net income and comprehensive income, statements of cash flows, and statement of  stockholders' equity prepared in conformity with U.S. GAAP have been condensed or omitted as permitted by such rules and regulations, although the Company believes that the disclosures made are adequate to make the information not misleading. They have been prepared in accordance with accounting policies described in the Company’s Annual Report on Form 10-K for the fiscal year ended January 1, 2022 which should be read in conjunction with the disclosures therein. In the opinion of management, all adjustments considered necessary for a fair presentation have been included and are of a normal, recurring nature. Operating results for interim periods are not necessarily indicative of annual operating results.

- changed (2023-05-03):
[0000889331-23-000095:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 1, 2023 and April 2, 2022:
  (was, 2022-11-02, similarity 0.8968):
[0000889331-22-000046:note_history:2]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended October 1, 2022 and September 25, 2021:

- changed (2023-05-03):
[0000889331-23-000095:note_history:3]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 148,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 148,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 209,995 |  |  | — |  |  | — |  |  | 209,995 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |
  (was, 2022-11-02, similarity 0.683):
[0000889331-22-000046:note_history:3]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  |  |  |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- added (2023-05-03):
[0000889331-23-000095:note_history:4]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

- changed (2023-05-03):
[0000889331-23-000095:note_history:5]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2022-11-02, similarity 0.8508):
[0000889331-22-000046:note_history:5]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference

- changed (2023-05-03):
[0000889331-23-000095:note_history:6]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at April 1, 2023 and December 31, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.
  (was, 2022-11-02, similarity 0.7583):
[0000889331-22-000046:note_history:6]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at October 1, 2022 and January 1, 2022 reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows.

- changed (2023-05-03):
[0000889331-23-000095:note_history:7]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 425,127 |  |  | $ | 562,588 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 812 |  |  | 802 |  |
| Restricted cash included in other long-term assets |  | 1,586 |  |  | 1,549 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 427,525 |  |  | $ | 564,939 |  |
  (was, 2022-11-02, similarity 0.9374):
[0000889331-22-000046:note_history:7]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Cash and cash equivalents |  | $ | 474,003 |  |  | $ | 478,473 |  |
| Restricted cash included in prepaid expenses and other current assets |  | 824 |  |  | 2,718 |  |
| Restricted cash included in other long-term assets |  | 1,428 |  |  | $ | 1,645 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 476,255 |  |  | $ | 482,836 |  |

- changed (2023-05-03):
[0000889331-23-000095:note_history:8]
Recently Issued Accounting Standards
  (was, 2022-11-02, similarity 0.8767):
[0000889331-22-000046:note_history:8]
Recently Adopted Accounting Standards

- added (2023-05-03):
[0000889331-23-000095:note_history:9]
In March 2023, the Financial Accounting Standards Board ("FASB") issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements". The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective on January 1, 2024. The Company does not expect any material effect on the Company's Condensed Consolidated Financial Statements.

- removed (2023-05-03):
[0000889331-22-000046:note_history:10]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  | — |  |  | — |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |

- removed (2023-05-03):
[0000889331-22-000046:note_history:11]
between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

- removed (2023-05-03):
[0000889331-22-000046:note_history:12]
In November 2021, the Financial Accounting Standards Board ("FASB") issued ASU No. 2021-10, "Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance". The standard, requires annual disclosures about transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy: 1) Information about the nature of the transactions and the related accounting policy used to account for the transactions; 2) The line items on the balance sheet and income statement that are affected by the transactions, and the amounts applicable to each financial statement line item; 3) Significant terms and conditions of the transactions, including commitments and contingencies. The guidance is effective for fiscal years beginning after December 15, 2021 with early adoption permitted. The adoption of ASU 2021-10 did not have a material impact on the Company's Condensed Consolidated Financial Statements.

- removed (2023-05-03):
[0000889331-22-000046:note_history:13]
In October 2021, the FASB issued ASU No. 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers". The standard requires an entity (acquirer) to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The guidance is effective for fiscal years beginning after December 15, 2022 with early adoption permitted. The adoption of ASU 2021-08 did not have a material impact on the Company's Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000889331-23-000095:note_history:14]
The carrying amounts of debt at April 1, 2023 and December 31, 2022 are as follows:
  (was, 2022-11-02, similarity 0.8456):
[0000889331-22-000046:note_history:14]
The carrying amounts of debt at October 1, 2022 and January 1, 2022 are as follows:

- changed (2023-05-03):
[0000889331-23-000095:note_history:15]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 294,375 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,706 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,693 |  |  | 101,265 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | — |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 8,651 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,571) |  |  | (4,847) |  |
| Total debt |  | 1,004,854 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,929) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 866,925 |  |  | $ | 866,623 |  |
  (was, 2022-11-02, similarity 0.6811):
[0000889331-22-000046:note_history:15]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 298,125 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 114,958 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 93,342 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | — |  |
| Other |  | 9,376 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,971) |  |  | (3,087) |  |
| Total debt |  | 985,830 |  |  | 636,897 |  |
| Less: Current maturities |  | (10,220) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 975,610 |  |  | $ | 611,897 |  |

- added (2023-05-03):
[0000889331-23-000095:note_history:16]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended April 1, 2023, the Company made payments of $1.9 million on its term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $294.4 million, respectively, as of April 1, 2023.

- changed (2023-05-03):
[0000889331-23-000095:note_history:17]
As of April 1, 2023, the effective interest rate on revolving loan and term loan outstanding borrowings was 5.91%.
  (was, 2022-11-02, similarity 0.9533):
[0000889331-22-000046:note_history:17]
As of October 1, 2022, the effective interest rate on revolving loan and term loan outstanding borrowings was 4.13%.

- added (2023-05-03):
[0000889331-23-000095:note_history:18]
As of April 1, 2023, the Company had no outstanding letters of credit under the Credit Facility and had $600.0 million of borrowing capacity available under the revolving Credit Facility. As of April 1, 2023, the Company was in compliance with all covenants under the Credit Agreement.

- changed (2023-05-03):
[0000889331-23-000095:note_history:19]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) were funded. During the first quarter of 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due on February 15, 2022. Interest on the U.S. Senior Notes due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.
  (was, 2022-11-02, similarity 0.7329):
[0000889331-22-000046:note_history:19]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. Interest on the U.S. Senior Notes due 2022 and 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017. During the nine months ended October 1, 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022.

- changed (2023-05-03):
[0000889331-23-000095:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At April 1, 2023, the Company was in compliance with all covenants under the Senior Notes.
  (was, 2022-11-02, similarity 0.9405):
[0000889331-22-000046:note_history:20]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. At October 1, 2022, the Company was in compliance with all covenants under the Senior Notes.

- changed (2023-05-03):
[0000889331-23-000095:note_history:21]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
  (was, 2022-11-02, similarity 0.6871):
[0000889331-22-000046:note_history:21]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.
Interest paid on all Company debt was $8.5 million and $6.1 million for the three months ended October 1, 2022 and September 25, 2021, respectively, and $16.9 million and $14.8 million for the nine months ended October 1, 2022 and September 25, 2021, respectively.

- added (2023-05-03):
[0000889331-23-000095:note_history:22]
Interest paid on all Company debt was $11.0 million and $6.0 million for the three months ended April 1, 2023 and April 2, 2022, respectively.

- removed (2023-05-03):
[0000889331-22-000046:note_history:23]
Revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed  $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the three months ended October 1, 2022, the Company paid  $1.9 million of term loan. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $298.1 million, respectively, as of October 1, 2022.

- removed (2023-05-03):
[0000889331-22-000046:note_history:24]
As of October 1, 2022, the Company had no outstanding in letters of credit under the Credit Facility and had available $600.0 million of borrowing capacity under the revolving Credit Facility. As of October 1, 2022, the Company was in compliance with all covenants under the Credit Agreement.

- removed (2023-05-03):
[0000889331-22-000046:note_history:25]
Debt Issuance Costs

- removed (2023-05-03):
[0000889331-22-000046:note_history:26]
During three and nine months ended October 1, 2022, the Company paid debt issuance costs of $0.4 million and  $2.6 million in connection with the new amended Credit Agreement on June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the new amended Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000889331-23-000095:note_history:27]
The carrying amounts of debt at April 1, 2023 and December 31, 2022 are as follows:
  (was, 2022-11-02, similarity 0.8456):
[0000889331-22-000046:note_history:27]
The carrying amounts of debt at October 1, 2022 and January 1, 2022 are as follows:

- changed (2023-05-03):
[0000889331-23-000095:note_history:28]
| (in thousands) |  | April 1, 2023 |  | December 31, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 294,375 |  |  | 296,250 |  |
| Euro Senior Notes, Series A due 2023 |  | 127,706 |  |  | 124,716 |  |
| Euro Senior Notes, Series B due 2028 |  | 103,693 |  |  | 101,265 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | — |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | 100,000 |  |
| Other |  | 8,651 |  |  | 9,113 |  |
| Unamortized debt issuance costs |  | (4,571) |  |  | (4,847) |  |
| Total debt |  | 1,004,854 |  |  | 1,001,497 |  |
| Less: Current maturities |  | (137,929) |  |  | (134,874) |  |
| Total long-term debt |  | $ | 866,925 |  |  | $ | 866,623 |  |
  (was, 2022-11-02, similarity 0.6811):
[0000889331-22-000046:note_history:28]
| (in thousands) |  | October 1, 2022 |  | January 1, 2022 |
| Revolving Credit Facility |  | $ | 100,000 |  |  | $ | 100,000 |  |
| Term Loan |  | 298,125 |  |  | — |  |
| Euro Senior Notes, Series A due 2023 |  | 114,958 |  |  | 132,444 |  |
| Euro Senior Notes, Series B due 2028 |  | 93,342 |  |  | 107,540 |  |
| U.S. Senior Notes, Series A due 2022 |  | — |  |  | 25,000 |  |
| U.S. Senior Notes, Series B due 2027 |  | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series A due 2025 |  | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2030 |  | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 |  | 100,000 |  |  | — |  |
| Other |  | 9,376 |  |  | — |  |
| Unamortized debt issuance costs |  | (4,971) |  |  | (3,087) |  |
| Total debt |  | 985,830 |  |  | 636,897 |  |
| Less: Current maturities |  | (10,220) |  |  | (25,000) |  |
| Total long-term debt |  | $ | 975,610 |  |  | $ | 611,897 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-05-03):
[0000889331-23-000095:note_history:29]
|  |  | Three Months Ended April 1, 2023 |  | Three Months Ended April 2, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.0 |  | $ | 0.1 |  | $ | 2.7 |  |  | $ | 0.2 |  | $ | 0.1 |  | $ | 2.9 |  |
|  |  | April 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.6 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2023-05-03):
[0000889331-22-000046:note_history:30]
|  |  | Three Months Ended October 1, 2022 |  | Three Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | — |  | $ | 0.1 |  | $ | 2.9 |  |  | $ | 0.8 |  | $ | 0.1 |  | $ | 3.1 |  |
|  |  | For the Nine Months Ended October 1, 2022 |  | For the Nine Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.3 |  | 8.8 |  |  | 2.6 |  | 0.3 |  | 8.9 |  |
|  |  | October 1, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.7 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-05-03):
[0000889331-23-000095:note_history:31]
|  |  | Three Months Ended April 1, 2023 |  | Three Months Ended April 2, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | 0.5 |  | $ | — |  | $ | — |  |  | $ | — |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | $ | 1.0 |  | $ | 0.1 |  | $ | 2.7 |  |  | $ | 0.2 |  | $ | 0.1 |  | $ | 2.9 |  |
|  |  | April 1, 2023 |  | December 31, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | 0.6 |  | $ | — |  | $ | 2.0 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |

- removed (2023-05-03):
[0000889331-22-000046:note_history:32]
|  |  | Three Months Ended October 1, 2022 |  | Three Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Purchase material/service from related party |  | $ | — |  | $ | 0.1 |  | $ | 2.9 |  |  | $ | 0.8 |  | $ | 0.1 |  | $ | 3.1 |  |
|  |  | For the Nine Months Ended October 1, 2022 |  | For the Nine Months Ended September 25, 2021 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Sales to related party |  | $ | — |  | $ | — |  | $ | — |  |  | $ | 0.2 |  | $ | — |  | $ | — |  |
| Purchase material/service from related party |  | 0.3 |  | 0.3 |  | 8.8 |  |  | 2.6 |  | 0.3 |  | 8.9 |  |
|  |  | October 1, 2022 |  | January 1, 2022 |
| (in millions) |  | Powersem | EB Tech | ATEC |  | Powersem | EB Tech | ATEC |
| Accounts payable balance |  | $ | — |  | $ | — |  | $ | 1.7 |  |  | $ | — |  | $ | — |  | $ | 1.8 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000889331-23-000095:note_history:33]
The following tables disaggregate the Company’s revenue by primary business units for the three months ended April 1, 2023 and April 2, 2022:
  (was, 2022-11-02, similarity 0.8968):
[0000889331-22-000046:note_history:33]
The following tables disaggregate the Company’s revenue by primary business units for the three and nine months ended October 1, 2022 and September 25, 2021:

- changed (2023-05-03):
[0000889331-23-000095:note_history:34]
|  |  | Three Months Ended April 1, 2023 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 148,598 |  |  | $ | — |  |  | $ | — |  |  | $ | 148,598 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 209,995 |  |  | — |  |  | — |  |  | 209,995 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 61,697 |  |  | — |  |  | 61,697 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 20,798 |  |  | — |  |  | 20,798 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 84,146 |  |  | — |  |  | 84,146 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 84,548 |  |  | 84,548 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 358,593 |  |  | $ | 166,641 |  |  | $ | 84,548 |  |  | $ | 609,782 |  |  |  |  |  |  |  |  |  |
  (was, 2022-11-02, similarity 0.683):
[0000889331-22-000046:note_history:34]
|  |  | Three Months Ended September 25, 2021 |  | Nine Months Ended September 25, 2021 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 171,299 |  |  | $ | — |  |  | $ | — |  |  | $ | 171,299 |  |  | $ | 459,012 |  |  | $ | — |  |  | $ | — |  |  | $ | 459,012 |  |
| Electronics – Semiconductor |  | 175,941 |  |  | — |  |  | — |  |  | 175,941 |  |  | 500,110 |  |  | — |  |  | — |  |  | 500,110 |  |
| Passenger Car Products |  | — |  |  | 64,630 |  |  | — |  |  | 64,630 |  |  | — |  |  | 200,579 |  |  | — |  |  | 200,579 |  |
| Automotive Sensors |  | — |  |  | 24,112 |  |  | — |  |  | 24,112 |  |  | — |  |  | 79,081 |  |  | — |  |  | 79,081 |  |
| Commercial Vehicle Products |  | — |  |  | 35,673 |  |  | — |  |  | 35,673 |  |  | — |  |  | 106,602 |  |  | — |  |  | 106,602 |  |
| Industrial Products |  | — |  |  | — |  |  | 67,926 |  |  | 67,926 |  |  |  |  |  |  | 181,479 |  |  | 181,479 |  |
| Total |  | $ | 347,240 |  |  | $ | 124,415 |  |  | $ | 67,926 |  |  | $ | 539,581 |  |  | $ | 959,122 |  |  | $ | 386,262 |  |  | $ | 181,479 |  |  | $ | 1,526,863 |  |

- added (2023-05-03):
[0000889331-23-000095:note_history:35]
|  |  | Three Months Ended April 2, 2022 |  |  |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  |  |  |  |  |  |  |  |
| Electronics – Passive Products and Sensors |  | $ | 169,943 |  |  | $ | — |  |  | $ | — |  |  | $ | 169,943 |  |  |  |  |  |  |  |  |  |
| Electronics – Semiconductor |  | 195,878 |  |  | — |  |  | — |  |  | 195,878 |  |  |  |  |  |  |  |  |  |
| Passenger Car Products |  | — |  |  | 64,494 |  |  | — |  |  | 64,494 |  |  |  |  |  |  |  |  |  |
| Automotive Sensors |  | — |  |  | 26,137 |  |  | — |  |  | 26,137 |  |  |  |  |  |  |  |  |  |
| Commercial Vehicle Products |  | — |  |  | 93,873 |  |  | — |  |  | 93,873 |  |  |  |  |  |  |  |  |  |
| Industrial Products |  | — |  |  | — |  |  | 73,005 |  |  | 73,005 |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 365,821 |  |  | $ | 184,504 |  |  | $ | 73,005 |  |  | $ | 623,330 |  |  |  |  |  |  |  |  |  |

- removed (2023-05-03):
[0000889331-22-000046:note_history:36]
|  |  | Three Months Ended October 1, 2022 |  | Nine Months Ended October 1, 2022 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Passive Products and Sensors |  | $ | 188,916 |  |  | $ | — |  |  | $ | — |  |  | $ | 188,916 |  |  | $ | 521,172 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,172 |  |
| Electronics – Semiconductor |  | 208,713 |  |  | — |  |  | — |  |  | 208,713 |  |  | 600,454 |  |  | — |  |  | — |  |  | 600,454 |  |
| Passenger Car Products |  | — |  |  | 62,280 |  |  | — |  |  | 62,280 |  |  | — |  |  | 186,552 |  |  | — |  |  | 186,552 |  |
| Automotive Sensors |  | — |  |  | 22,998 |  |  | — |  |  | 22,998 |  |  | — |  |  | 72,336 |  |  | — |  |  | 72,336 |  |
| Commercial Vehicle Products |  | — |  |  | 96,457 |  |  | — |  |  | 96,457 |  |  | — |  |  | 289,378 |  |  | — |  |  | 289,378 |  |
| Industrial Products |  | — |  |  | — |  |  | 79,516 |  |  | 79,516 |  |  | — |  |  | — |  |  | 230,754 |  |  | 230,754 |  |
| Total |  | $ | 397,629 |  |  | $ | 181,735 |  |  | $ | 79,516 |  |  | $ | 658,880 |  |  | $ | 1,121,626 |  |  | $ | 548,266 |  |  | $ | 230,754 |  |  | $ | 1,900,646 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-03):
[0000889331-23-000095:note_history:37]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
  (was, 2022-11-02, similarity 0.8508):
[0000889331-22-000046:note_history:37]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributor to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference

- removed (2023-05-03):
[0000889331-22-000046:note_history:38]
between the contracted price and the lower approved price. The Company establishes reserves for this program based on historical activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.
