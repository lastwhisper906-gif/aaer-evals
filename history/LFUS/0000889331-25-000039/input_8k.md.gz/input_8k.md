# LFUS 8-K — 0000889331-25-000013 filed 2025-01-28

## item codes, every 8-K on or before 2025-03-13

- 2025-01-28 0000889331-25-000013 — 2.02, 7.01, 9.01
- 2025-01-13 0001140361-25-000873 — 5.02, 9.01
- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2025-03-13

- 2025-02-27 0001140361-25-006294 — NT 10-K, for the period ended 2024-12-28
- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0000889331-25-000013:8k_2_02:1]
EX-99.1
2
q42024ex991.htm
EX-99.1

[0000889331-25-000013:8k_2_02:2]
Document

[0000889331-25-000013:8k_2_02:3]
Exhibit 99.1

[0000889331-25-000013:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0000889331-25-000013:8k_2_02:5]
LITTELFUSE REPORTS FOURTH QUARTER AND FULL YEAR RESULTS FOR 2024

[0000889331-25-000013:8k_2_02:6]
Consistent Execution Drives Fourth Quarter Results In-line with Prior Guidance

[0000889331-25-000013:8k_2_02:7]
CHICAGO, January 28, 2025 - Littelfuse, Inc. (NASDAQ: LFUS), a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world, today reported financial results for the fourth quarter and full year ended December 28, 2024:

[0000889331-25-000013:8k_2_02:8]
Fourth Quarter 2024 Results

[0000889331-25-000013:8k_2_02:9]
•Net sales of $530 million were down 1% versus the prior year period and flat organically

[0000889331-25-000013:8k_2_02:10]
•GAAP diluted loss per share was $1.57, which includes $93m in non-cash goodwill and intangible impairment charges

[0000889331-25-000013:8k_2_02:11]
•Adjusted diluted EPS was $2.04

[0000889331-25-000013:8k_2_02:12]
•Cash flow from operations was $161 million and free cash flow was $135 million

[0000889331-25-000013:8k_2_02:13]
Full Year 2024 Results

[0000889331-25-000013:8k_2_02:14]
•Net sales of $2.2 billion were down 7% versus the prior year period and organically

[0000889331-25-000013:8k_2_02:15]
•GAAP diluted EPS was $4.51 adjusted diluted EPS was $8.48

[0000889331-25-000013:8k_2_02:16]
•Cash flow from operations was $368 million and free cash flow was $292 million

[0000889331-25-000013:8k_2_02:17]
“Our fourth quarter performance, which was in-line with our expectations, reflects ongoing operational execution and our steadfast commitment to our diverse and global customer base,” said Dave Heinzmann, Littelfuse President and Chief Executive Officer. “For the full year 2024, we delivered strong cash conversion while our focused profitability enhancements drove solid second half margin expansion amid difficult end market conditions. Our continued design win momentum, meaningful content opportunities, broad end market exposures and operational improvements position us well as we expect to deliver solid earnings expansion in 2025.”

[0000889331-25-000013:8k_2_02:18]
First Quarter of 2025*

[0000889331-25-000013:8k_2_02:19]
Based on current market conditions, for the first quarter the company expects,

[0000889331-25-000013:8k_2_02:20]
•Net sales in the range of $520 - $550 million, adjusted diluted EPS in the range of $1.70 - $1.90 and an adjusted effective tax rate of approximately 26%

[0000889331-25-000013:8k_2_02:21]
-more-

[0000889331-25-000013:8k_2_02:22]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0000889331-25-000013:8k_2_02:23]
Dividend

[0000889331-25-000013:8k_2_02:24]
•The company will pay a cash dividend on its common stock of $0.70 per share on March 6, 2025, to shareholders of record as of February 20, 2025

[0000889331-25-000013:8k_2_02:25]
Conference Call and Webcast Information

[0000889331-25-000013:8k_2_02:26]
Littelfuse will host a conference call on Wednesday, January 29, 2025, at 9:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0000889331-25-000013:8k_2_02:27]
About Littelfuse

[0000889331-25-000013:8k_2_02:28]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0000889331-25-000013:8k_2_02:29]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks, uncertainties and other factors include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; exchange rate fluctuations; commodity and other raw material price fluctuations; the effect of Littelfuse accounting policies; labor disputes and shortages; restructuring costs in excess of expectations; pension plan asset returns less than assumed; integration of acquisitions; uncertainties related to political or regulatory changes; limited realization of the expected benefits from investment and strategic plans; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 30, 2023.

[0000889331-25-000013:8k_2_02:30]
-more-

[0000889331-25-000013:8k_2_02:31]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 30, 2023, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0000889331-25-000013:8k_2_02:32]
Non-GAAP Financial Measures

[0000889331-25-000013:8k_2_02:33]
The information included in this press release includes the non-GAAP financial measures of organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of our core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of our fundamental business operations or were not part of our business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that our definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0000889331-25-000013:8k_2_02:34]
LFUS-F

[0000889331-25-000013:8k_2_02:35]
###

[0000889331-25-000013:8k_2_02:36]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0000889331-25-000013:8k_2_02:37]
LITTELFUSE, INC.

[0000889331-25-000013:8k_2_02:38]
CONSOLIDATED BALANCE SHEETS

[0000889331-25-000013:8k_2_02:39]
| (in thousands) | December 28, 2024 |  | December 30, 2023 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 724,924 |  |  | $ | 555,513 |  |
| Short-term investments | 976 |  |  | 235 |  |
| Trade receivables, less allowances of $69,990 and $84,696, respectively | 294,371 |  |  | 287,018 |  |
| Inventories | 429,754 |  |  | 474,607 |  |
| Prepaid income taxes and income taxes receivable | 11,749 |  |  | 8,701 |  |
| Prepaid expenses and other current assets | 105,659 |  |  | 82,526 |  |
| Total current assets | 1,567,433 |  |  | 1,408,600 |  |
| Net property, plant, and equipment | 477,068 |  |  | 493,153 |  |
| Intangible assets, net of amortization | 482,118 |  |  | 606,136 |  |
| Goodwill | 1,228,502 |  |  | 1,309,998 |  |
| Investments | 23,245 |  |  | 24,821 |  |
| Deferred income taxes | 4,899 |  |  | 10,486 |  |
| Right of use lease assets | 72,211 |  |  | 62,370 |  |
| Other long-term assets | 48,168 |  |  | 79,711 |  |
| Total assets | $ | 3,903,644 |  |  | $ | 3,995,275 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 188,359 |  |  | $ | 173,535 |  |
| Accrued liabilities | 148,944 |  |  | 149,214 |  |
| Accrued income taxes | 29,658 |  |  | 38,725 |  |
| Current portion of long-term debt | 67,612 |  |  | 14,020 |  |
| Total current liabilities | 434,573 |  |  | 375,494 |  |
| Long-term debt, less current portion | 788,502 |  |  | 857,915 |  |
| Deferred income taxes | 95,532 |  |  | 110,820 |  |
| Accrued post-retirement benefits | 29,836 |  |  | 34,422 |  |
| Non-current lease liabilities | 60,559 |  |  | 49,472 |  |
| Other long-term liabilities | 68,217 |  |  | 86,671 |  |
| Total equity | 2,426,425 |  |  | 2,480,481 |  |
| Total liabilities and equity | $ | 3,903,644 |  |  | $ | 3,995,275 |  |

[0000889331-25-000013:8k_2_02:40]
LITTELFUSE, INC.

[0000889331-25-000013:8k_2_02:41]
CONSOLIDATED STATEMENTS OF NET (LOSS) INCOME

[0000889331-25-000013:8k_2_02:42]
(Unaudited)

[0000889331-25-000013:8k_2_02:43]
|  |  | Three Months Ended |  | Fiscal Year Ended |
| (in thousands, except per share data) |  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Net sales |  | $ | 529,505 |  |  | $ | 533,807 |  |  | $ | 2,190,768 |  |  | $ | 2,362,657 |  |
| Cost of sales |  | 339,186 |  |  | 340,226 |  |  | 1,389,745 |  |  | 1,462,416 |  |
| Gross profit |  | 190,319 |  |  | 193,581 |  |  | 801,023 |  |  | 900,241 |  |
| Selling, general, and administrative expenses |  | 87,694 |  |  | 84,598 |  |  | 351,089 |  |  | 354,655 |  |
| Research and development expenses |  | 26,490 |  |  | 25,159 |  |  | 107,773 |  |  | 102,429 |  |
| Amortization of intangibles |  | 14,709 |  |  | 16,021 |  |  | 62,127 |  |  | 65,794 |  |
| Restructuring, impairment, and other charges |  | 98,112 |  |  | 3,280 |  |  | 108,441 |  |  | 16,501 |  |
| Total operating expenses |  | 227,005 |  |  | 129,058 |  |  | 629,430 |  |  | 539,379 |  |
| Operating (loss) income |  | (36,686) |  |  | 64,523 |  |  | 171,593 |  |  | 360,862 |  |
| Interest expense |  | 9,359 |  |  | 10,063 |  |  | 38,717 |  |  | 39,866 |  |
| Foreign exchange (gain) loss |  | (13,503) |  |  | 3,602 |  |  | (9,230) |  |  | 12,299 |  |
| Other income, net |  | (2,654) |  |  | (8,091) |  |  | (22,570) |  |  | (19,901) |  |
| (Loss) income before income taxes |  | (29,888) |  |  | 58,949 |  |  | 164,676 |  |  | 328,598 |  |
| Income taxes |  | 9,085 |  |  | 16,068 |  |  | 51,673 |  |  | 69,113 |  |
| Net (loss) income |  | $ | (38,973) |  |  | $ | 42,881 |  |  | $ | 113,003 |  |  | $ | 259,485 |  |
| (Loss) income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.57) |  |  | $ | 1.72 |  |  | $ | 4.55 |  |  | $ | 10.44 |  |
| Diluted |  | $ | (1.57) |  |  | $ | 1.71 |  |  | $ | 4.51 |  |  | $ | 10.34 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,818 |  |  | 24,905 |  |  | 24,821 |  |  | 24,854 |  |
| Diluted |  | 24,818 |  |  | 25,111 |  |  | 25,039 |  |  | 25,102 |  |
| Comprehensive (loss) income |  | $ | (134,552) |  |  | $ | 86,590 |  |  | $ | 22,459 |  |  | $ | 299,432 |  |

[0000889331-25-000013:8k_2_02:44]
LITTELFUSE, INC.

[0000889331-25-000013:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000889331-25-000013:8k_2_02:46]
|  | Year Ended |
| (in thousands) | December 28, 2024 |  | December 30, 2023 |
| OPERATING ACTIVITIES |  |  |  |
| Net income | $ | 113,003 |  |  | $ | 259,485 |  |
| Adjustments to reconcile net income to net cash provided by operating activities | 245,835 |  |  | 173,776 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Trade receivables | (15,347) |  |  | 24,517 |  |
| Inventories | 33,662 |  |  | 82,471 |  |
| Accounts payable | 16,260 |  |  | (36,277) |  |
| Accrued liabilities and income taxes | (44,200) |  |  | (61,022) |  |
| Prepaid expenses and other assets | 18,408 |  |  | 14,437 |  |
| Net cash provided by operating activities | 367,621 |  |  | 457,387 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisitions of businesses, net of cash acquired | — |  |  | (198,810) |  |
| Purchases of property, plant, and equipment | (75,877) |  |  | (86,188) |  |
| Net proceeds from sale of property, plant, and equipment | 10,836 |  |  | 832 |  |
| Other | (741) |  |  | (151) |  |
| Net cash used in investing activities | (65,782) |  |  | (284,317) |  |
| FINANCING ACTIVITIES |  |  |  |
| Net payments of credit facility and senior notes | (7,500) |  |  | (128,802) |  |
| Cash dividends paid | (67,061) |  |  | (62,161) |  |
| Purchases of common stock | (40,862) |  |  | — |  |
| All other cash provided by financing activities | 2,987 |  |  | 5,237 |  |
| Net cash used in financing activities | (112,436) |  |  | (185,726) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (20,089) |  |  | 4,840 |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash | 169,314 |  |  | (7,816) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 557,123 |  |  | 564,939 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 726,437 |  |  | $ | 557,123 |  |

[0000889331-25-000013:8k_2_02:47]
LITTELFUSE, INC.

[0000889331-25-000013:8k_2_02:48]
NET SALES AND OPERATING INCOME BY SEGMENT

[0000889331-25-000013:8k_2_02:49]
(Unaudited)

[0000889331-25-000013:8k_2_02:50]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2024 |  | 2023 |  |  |  | %(Decline) / Growth |  | 2024 |  | 2023 |  |  |  | %(Decline) / Growth |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 285,841 |  |  | $ | 297,753 |  |  |  |  | (4.0) | % |  | $ | 1,186,773 |  |  | $ | 1,350,426 |  |  |  |  | (12.1) | % |
| Transportation |  | 161,723 |  |  | 162,570 |  |  |  |  | (0.5) | % |  | 672,434 |  |  | 678,278 |  |  |  |  | (0.9) | % |
| Industrial |  | 81,941 |  |  | 73,484 |  |  |  |  | 11.5 | % |  | 331,561 |  |  | 333,953 |  |  |  |  | (0.7) | % |
| Total net sales |  | $ | 529,505 |  |  | $ | 533,807 |  |  |  |  | (0.8) | % |  | $ | 2,190,768 |  |  | $ | 2,362,657 |  |  |  |  | (7.3) | % |
| Operating (loss) income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 35,186 |  |  | $ | 53,553 |  |  |  |  | (34.3) | % |  | $ | 168,045 |  |  | $ | 300,581 |  |  |  |  | (44.1) | % |
| Transportation |  | 14,614 |  |  | 7,619 |  |  |  |  | 91.8 | % |  | 69,539 |  |  | 33,634 |  |  |  |  | 106.8 | % |
| Industrial |  | 13,977 |  |  | 9,350 |  |  |  |  | 49.5 | % |  | 46,031 |  |  | 54,800 |  |  |  |  | (16.0) | % |
| Other (a) |  | (100,463) |  |  | (5,999) |  |  |  |  | N.M. |  | (112,022) |  |  | (28,153) |  |  |  |  | N.M. |
| Total operating (loss) income |  | $ | (36,686) |  |  | $ | 64,523 |  |  |  |  | (156.9) | % |  | $ | 171,593 |  |  | $ | 360,862 |  |  |  |  | (52.4) | % |
| Operating Margin |  | (6.9) | % |  | 12.1 | % |  |  |  |  |  | 7.8 | % |  | 15.3 | % |  |  |  |  |
| Interest expense |  | 9,359 |  |  | 10,063 |  |  |  |  |  |  | 38,717 |  |  | 39,866 |  |  |  |  |  |
| Foreign exchange (gain) loss |  | (13,503) |  |  | 3,602 |  |  |  |  |  |  | (9,230) |  |  | 12,299 |  |  |  |  |  |
| Other income, net |  | (2,654) |  |  | (8,091) |  |  |  |  |  |  | (22,570) |  |  | (19,901) |  |  |  |  |  |
| (Loss) income before income taxes |  | $ | (29,888) |  |  | $ | 58,949 |  |  |  |  | (150.7) | % |  | $ | 164,676 |  |  | $ | 328,598 |  |  |  |  | (49.9) | % |

[0000889331-25-000013:8k_2_02:51]
(a)"other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0000889331-25-000013:8k_2_02:52]
N.M. - Not meaningful

[0000889331-25-000013:8k_2_02:53]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2024 |  | 2023 |  |  |  | %(Decline) / Growth |  | 2024 |  | 2023 |  |  |  | %(Decline) / Growth |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 12.3 | % |  | 18.0 | % |  |  |  | (5.7) | % |  | 14.2 | % |  | 22.3 | % |  |  |  | (8.1) | % |
| Transportation |  | 9.0 | % |  | 4.7 | % |  |  |  | 4.3 | % |  | 10.3 | % |  | 5.0 | % |  |  |  | 5.3 | % |
| Industrial |  | 17.1 | % |  | 12.7 | % |  |  |  | 4.4 | % |  | 13.9 | % |  | 16.4 | % |  |  |  | (2.5) | % |

[0000889331-25-000013:8k_2_02:54]
LITTELFUSE, INC.

[0000889331-25-000013:8k_2_02:55]
SUPPLEMENTAL FINANCIAL INFORMATION

[0000889331-25-000013:8k_2_02:56]
(In millions of USD except per share amounts - unaudited)

[0000889331-25-000013:8k_2_02:57]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-24 |  | Q4-23 |  | YTD-24 |  | YTD-23 |
| GAAP diluted EPS |  | $ | (1.57) |  |  | $ | 1.71 |  |  | $ | 4.51 |  |  | $ | 10.34 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 3.61 |  |  | 0.31 |  |  | 3.97 |  |  | 1.40 |  |
| Adjusted diluted EPS |  | $ | 2.04 |  |  | $ | 2.02 |  |  | $ | 8.48 |  |  | $ | 11.74 |  |

[0000889331-25-000013:8k_2_02:58]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q4-24 |  | Q4-23 |  | YTD-24 |  | YTD-23 |
| Acquisition-related and integration costs (a) |  | $ | 2.3 |  |  | $ | 2.7 |  |  | $ | 5.1 |  |  | $ | 11.7 |  |
| Restructuring, impairment and other charges (b) |  | 98.1 |  |  | 3.3 |  |  | 108.4 |  |  | 16.5 |  |
| Gain on sale of fixed assets (c) |  | — |  |  | — |  |  | (1.5) |  |  | — |  |
| Non-GAAP adjustments to operating income |  | 100.4 |  |  | 6.0 |  |  | 112.0 |  |  | 28.2 |  |
| Other expense (income), net (d) |  | 1.6 |  |  | — |  |  | 1.3 |  |  | (0.2) |  |
| Non-operating foreign exchange (gain) loss |  | (13.5) |  |  | 3.6 |  |  | (9.2) |  |  | 12.3 |  |
| Non-GAAP adjustments to income before income taxes |  | 88.5 |  |  | 9.6 |  |  | 104.1 |  |  | 40.3 |  |
| Income taxes (e) |  | (1.5) |  |  | 1.8 |  |  | 4.7 |  |  | 5.0 |  |
| Non-GAAP adjustments to net income |  | $ | 90.0 |  |  | $ | 7.8 |  |  | $ | 99.4 |  |  | $ | 35.3 |  |
| Total EPS impact |  | $ | 3.61 |  |  | $ | 0.31 |  |  | $ | 3.97 |  |  | $ | 1.40 |  |

[0000889331-25-000013:8k_2_02:59]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-24 |  | Q4-23 |  | YTD-24 |  | YTD-23 |
| Net (loss) income |  | $ | (39.0) |  |  | $ | 42.9 |  |  | $ | 113.0 |  |  | $ | 259.5 |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 9.1 |  |  | 16.1 |  |  | 51.7 |  |  | 69.1 |  |
| Interest expense |  | 9.4 |  |  | 10.1 |  |  | 38.7 |  |  | 39.9 |  |
| Foreign exchange (gain) loss |  | (13.5) |  |  | 3.6 |  |  | (9.2) |  |  | 12.3 |  |
| Other income, net |  | (2.7) |  |  | (8.1) |  |  | (22.6) |  |  | (19.9) |  |
| GAAP operating (loss) income |  | $ | (36.7) |  |  | $ | 64.5 |  |  | $ | 171.6 |  |  | $ | 360.9 |  |
| Non-GAAP adjustments to operating (loss) income |  | 100.4 |  |  | 6.0 |  |  | 112.0 |  |  | 28.2 |  |
| Adjusted operating income |  | $ | 63.8 |  |  | $ | 70.5 |  |  | $ | 283.6 |  |  | $ | 389.0 |  |
| Amortization of intangibles |  | 14.7 |  |  | 16.0 |  |  | 62.1 |  |  | 65.8 |  |
| Depreciation expenses |  | 17.3 |  |  | 18.1 |  |  | 68.3 |  |  | 71.6 |  |
| Adjusted EBITDA |  | $ | 95.8 |  |  | $ | 104.6 |  |  | $ | 414.1 |  |  | $ | 526.4 |  |
| Net sales |  | $ | 529.5 |  |  | $ | 533.8 |  |  | $ | 2,190.8 |  |  | $ | 2,362.7 |  |
| Net (loss) income as a percentage of net sales |  | (7.4) | % |  | 8.0 | % |  | 5.2 | % |  | 11.0 | % |
| Operating margin |  | (6.9) | % |  | 12.1 | % |  | 7.8 | % |  | 15.3 | % |
| Adjusted operating margin |  | 12.0 | % |  | 13.2 | % |  | 12.9 | % |  | 16.5 | % |
| Adjusted EBITDA margin |  | 18.1 | % |  | 19.6 | % |  | 18.9 | % |  | 22.3 | % |

[0000889331-25-000013:8k_2_02:60]
| Adjusted EBITDA by Segment |  | Q4-24 |  | Q4-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 35.2 |  |  | $ | 14.6 |  |  | $ | 14.0 |  |  | $ | 53.6 |  |  | $ | 7.6 |  |  | $ | 9.4 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 9.8 |  |  | 3.4 |  |  | 1.5 |  |  | 9.8 |  |  | 3.6 |  |  | 2.6 |  |
| Add back depreciation |  | 10.4 |  |  | 5.4 |  |  | 1.5 |  |  | 10.3 |  |  | 6.4 |  |  | 1.4 |  |
| Adjusted EBITDA |  | $ | 55.3 |  |  | $ | 23.4 |  |  | $ | 17.0 |  |  | $ | 73.7 |  |  | $ | 17.6 |  |  | $ | 13.4 |  |
| Adjusted EBITDA Margin |  | 19.3 | % |  | 14.5 | % |  | 20.8 | % |  | 24.7 | % |  | 10.8 | % |  | 18.2 | % |

[0000889331-25-000013:8k_2_02:61]
| Adjusted EBITDA by Segment |  | YTD-24 |  | YTD-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 168.0 |  |  | $ | 69.5 |  |  | $ | 46.0 |  |  | $ | 300.6 |  |  | $ | 33.6 |  |  | $ | 54.8 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 39.4 |  |  | 13.5 |  |  | 9.2 |  |  | 39.9 |  |  | 15.8 |  |  | 10.1 |  |
| Add back depreciation |  | 40.4 |  |  | 22.1 |  |  | 5.8 |  |  | 39.5 |  |  | 26.7 |  |  | 5.4 |  |
| Adjusted EBITDA |  | $ | 247.9 |  |  | $ | 105.2 |  |  | $ | 61.0 |  |  | $ | 379.9 |  |  | $ | 76.1 |  |  | $ | 70.4 |  |
| Adjusted EBITDA Margin |  | 20.9 | % |  | 15.6 | % |  | 18.4 | % |  | 28.1 | % |  | 11.2 | % |  | 21.1 | % |

[0000889331-25-000013:8k_2_02:62]
| Net sales reconciliation |  | Q4-24 vs. Q4-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales (decline) growth |  | (4) | % |  | (1) | % |  | 12 | % |  | (1) | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | — | % |  | — | % |  | — | % |  | — | % |
| Organic net sales (decline) growth |  | (4) | % |  | (1) | % |  | 12 | % |  | — | % |

[0000889331-25-000013:8k_2_02:63]
| Net sales reconciliation |  | YTD-24 vs. YTD-23 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales decline |  | (12) | % |  | (1) | % |  | (1) | % |  | (7) | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | — | % |  | — | % |  | — | % |  | — | % |
| Organic net sales decline |  | (12) | % |  | (1) | % |  | (1) | % |  | (7) | % |

[0000889331-25-000013:8k_2_02:64]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-24 |  | Q4-23 |  | YTD-24 |  | YTD-23 |
| Income taxes |  | $ | 9.1 |  |  | $ | 16.1 |  |  | $ | 51.7 |  |  | $ | 69.1 |  |
| Effective rate |  | (30.4) | % |  | 27.3 | % |  | 31.4 | % |  | 21.0 | % |
| Non-GAAP adjustments - income taxes |  | (1.5) |  |  | 1.8 |  |  | 4.7 |  |  | 5.0 |  |
| Adjusted income taxes |  | $ | 7.6 |  |  | $ | 17.9 |  |  | $ | 56.4 |  |  | $ | 74.1 |  |
| Adjusted effective rate |  | 12.9 | % |  | 26.1 | % |  | 21.0 | % |  | 20.1 | % |

[0000889331-25-000013:8k_2_02:65]
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-24 |  | Q4-23 |  | YTD-24 |  | YTD-23 |
| Net cash provided by operating activities |  | $ | 160.6 |  |  | $ | 144.2 |  |  | $ | 367.6 |  |  | $ | 457.4 |  |
| Less: Purchases of property, plant and equipment |  | (25.8) |  |  | (23.0) |  |  | (75.9) |  |  | (86.2) |  |
| Free cash flow |  | $ | 134.8 |  |  | $ | 121.2 |  |  | $ | 291.7 |  |  | $ | 371.2 |  |

[0000889331-25-000013:8k_2_02:66]
| Consolidated Total Debt |  | As of December 28, 2024 |
| Consolidated Total Debt |  | $ | 856.1 |  |
| Unamortized debt issuance costs |  | 2.8 |  |
| Finance lease liability |  | 0.3 |  |
| Consolidated funded indebtedness |  | $ | 859.2 |  |
| Cash held in U.S. (up to $400 million) |  | 302.2 |  |
| Net debt |  | $ | 557.0 |  |
| Consolidated EBITDA |  | Twelve Months EndedDecember 28, 2024 |
| Net Income |  | $ | 112.8 |  |
| Interest expense |  | 38.7 |  |
| Income taxes |  | 51.7 |  |
| Depreciation |  | 68.3 |  |
| Amortization |  | 62.1 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 26.0 |  |
| Unrealized loss on investments |  | (0.1) |  |
| Impairment charges |  | 93.5 |  |
| Other |  | 3.7 |  |
| Consolidated EBITDA (1) |  | $ | 456.7 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.2x |

[0000889331-25-000013:8k_2_02:67]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2024 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0000889331-25-000013:8k_2_02:68]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0000889331-25-000013:8k_2_02:69]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0000889331-25-000013:8k_2_02:70]
Note: Total will not always foot due to rounding.

[0000889331-25-000013:8k_2_02:71]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0000889331-25-000013:8k_2_02:72]
(b) reflected in restructuring, impairment and other charges. In the fourth quarter 2024, the Company recorded $92.6 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million non-cash goodwill impairment charge associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-25-000013:8k_2_02:73]
(c) 2024 amount reflected a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment and a gain of $1.0 million for the sale of two buildings within the Transportation segment.

[0000889331-25-000013:8k_2_02:74]
(d) 2024 included $1.8 million increase in coal mining reserves, partially offset by a reversal of $0.5 million for an asset retirement obligation charge related the disposal of a business in 2019. 2023 amount included $0.2 million gain from the sale of a building within the Electronics segment.

[0000889331-25-000013:8k_2_02:75]
(e) reflected the tax impact associated with the non-GAAP adjustments.

[0000889331-25-000013:8k_2_02:76]
###
