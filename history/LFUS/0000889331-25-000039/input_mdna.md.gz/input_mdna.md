# LFUS MD&A — 0000889331-25-000039


## mdna

[0000889331-25-000039:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0000889331-25-000039:mdna:2]
The following discussion of the Company's financial condition and results of operations should be read together with the Consolidated Financial Statements and notes to those statements included in Item 8 of Part II of this Annual Report on Form 10-K.

[0000889331-25-000039:mdna:3]
BUSINESS

[0000889331-25-000039:mdna:4]
For a description of the Company’s business, segments and product offerings, see Item 1, Business.

[0000889331-25-000039:mdna:5]
2024 EXECUTIVE OVERVIEW

[0000889331-25-000039:mdna:6]
Net sales were $2,190.8 million, which decreased by $171.9 million, or 7.3%, in 2024 compared to 2023 including $7.9 million of unfavorable changes in foreign exchange rates. The decrease in net sales was primarily due to lower volume of $163.7 million in the Electronics segment primarily driven by reduced demand and inventory rebalancing in the semiconductor business. The Company recognized net income of $100.2 million, or $4.00 per diluted share, in 2024 compared to net income of $259.5 million, or $10.34 per diluted share in 2023. The decrease in net income was primarily due to lower operating income of $130.7 million in the Electronics segment due to lower sales in the semiconductor business and $92.6 million of non-cash impairment charges. The non-cash impairment charges included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively.

[0000889331-25-000039:mdna:7]
Net cash provided by operating activities was $367.6 million for the fiscal year 2024, a decrease of $89.8 million, compared to $457.4 million during the fiscal year 2023. The decrease in net cash provided by operating activities was primarily due to lower cash earnings.

[0000889331-25-000039:mdna:8]
Based on the Company’s assessment, management, including our Chief Executive Officer and Chief Financial Officer, has concluded that, as of December 28, 2024, the Company’s internal control over financial reporting was not effective due to the identification of the material weaknesses described below. In making this assessment, management has concluded that we did not design and maintain an effective control environment commensurate with our financial reporting requirements. Specifically, at certain of our non-U.S. manufacturing locations we lacked sufficiently skilled operational and accounting personnel to ensure that internal control responsibilities were performed and aligned with internal control objectives.

[0000889331-25-000039:mdna:9]
The material weakness in the control environment contributed to an additional material weakness related to the design and operating effectiveness of control activities over the existence of inventory at these locations. The Company did not maintain effective controls related to inventory cycle counts to validate existence of inventory, and consequently, the completeness and accuracy of the data used in evaluating the appropriateness of the valuation of inventory and related reserves. These material weaknesses resulted in corrections through cumulative out-of-period adjustments as described in notes to the consolidated financial statements as of and for the year ended December 28, 2024. The material weaknesses resulted in immaterial corrections to previously released financial results. For a description of the material weaknesses identified by management and the remediation efforts being implemented for the material weaknesses, see “Part II, Item 9A - Controls and Procedures.” for further discussion.

[0000889331-25-000039:mdna:10]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany ("Dortmund Fab") from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab was approximately 94 million Euro, of which a 37.2 million Euro down payment (approximately $40.5 million) was made in the third quarter of 2023 and recorded in Prepaid expenses and other current assets in the Consolidated Balance Sheets after regulatory approvals. The payment of 56.7 million Euro was paid at closing in the beginning of the fiscal year 2025. The transaction did not have any impact on the Company's 2024 financial results and reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0000889331-25-000039:mdna:11]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the

[0000889331-25-000039:mdna:12]
benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $23 million, representing approximately 33% of the total obligations of the Company’s qualified pension plans, and was funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-25-000039:mdna:13]
Other Risk

[0000889331-25-000039:mdna:14]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies" that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-25-000039:mdna:15]
Further, the global trade policies and tensions could create additional complexities. Our international presence subjects us to risks associated with international trade conflicts between the United States and its trade partners, including, without limitation, China, Mexico and Canada, particularly with regard to tariffs and import/export controls. These factors in turn could require us to materially increase prices to our customers which may reduce demand, or, if we do not or are unable to increase prices, could result in lower margins on products sold. Changes in U.S. trade policy have resulted in, and could result in more, U.S. trading partners adopting responsive trade policies making it more difficult or costly for us to export our products to those countries. Additionally, continued geo-political issues may result in customers outside the U.S. seeking to source products from local suppliers, which could result in lower sales or lost customers.

[0000889331-25-000039:mdna:16]
OUTLOOK

[0000889331-25-000039:mdna:17]
Vision and Strategy

[0000889331-25-000039:mdna:18]
The Company closely collaborates with strategic customers to design and manufacture innovative and reliable solutions to help empower a sustainable, connected, and safer world in virtually every market that uses electrical energy.

[0000889331-25-000039:mdna:19]
Within transportation end markets, the Company’s products are found in passenger vehicles and commercial vehicles, like material handling equipment, heavy-duty truck and bus, off-road and recreational vehicles, construction equipment, agricultural machinery, rail, marine and aerospace. The Company is a key enabler of electrification across these transportation applications. The Company is also a key enabler of electronification advancements across these transportation applications. The Company continues to advance its existing customer relationships with OEM, Tier One and channel partners while driving product content growth for advanced, high-growth applications.

[0000889331-25-000039:mdna:20]
Within industrial end markets, the Company’s products are found in renewable energy and energy storage applications, HVAC, factory automation and industrial safety, industrial motor drives and power conversion, electric vehicle charging infrastructure, and heavy and general industrial type applications. The Company utilizes its deep technical engineering capabilities and design support to drive product content growth across high-growth applications like renewables, energy storage, HVAC, and industrial automation and safety.

[0000889331-25-000039:mdna:21]
Within electronics end markets, the Company’s products are found in data center, cloud storage and telecom infrastructure applications, building technologies and automation, appliances, medical devices, gaming and entertainment applications and mobile electronics. The Company leverages its strategic distribution partnerships and deep OEM relationships, coupled with its comprehensive product offerings, to drive product content growth across a broad range of applications.

[0000889331-25-000039:mdna:22]
The Company expects the ever-increasing advancements of application architectures, driven by ongoing electronification and electrification across these end markets, to drive increasing product content opportunities. Built upon that framework, the Company has positioned itself around the structural growth themes of sustainability, connectivity, and safety, which will continue to drive increased demand for the Company’s innovative, reliable solutions across the transportation, industrial and electronics end markets that it serves.

[0000889331-25-000039:mdna:23]
The Company’s five-year strategic plan, built around these structural growth themes, is focused on delivering top-tier shareholder returns by driving double-digit sales growth, best-in-class profitability, earnings per share growth, strong cash flow

[0000889331-25-000039:mdna:24]
generation, and deploying capital to drive value creation. The Company pursues the following major strategic objectives, which are summarized below, along with more specific areas of focus. The Company uses the financial measures below to gauge progress toward achieving these strategic objectives. These measures include organic sales growth, operating margins, cash flow from operations, and returns on invested capital.

[0000889331-25-000039:mdna:25]
| Strategic Objectives |  | Priorities |
| Double-digit sales growth |  | ● | Increase product content with existing and new customers, and expand market share |
| 5-7% average annual organic sales growth |  | ● | Expand presence (i.e. with portfolio and infrastructure) into new and underpenetrated, high-growth geographies and end markets |
| 5-7% average annual growth from strategic acquisitions |  | ● | Increase innovation capabilities and investments |
|  |  | ● | Leverage breadth of go-to-market strategies |
|  |  | ● | Target mergers and acquisitions that enhance and sustain organic growth |
| EPS growth |  | ● | Focus on higher profitability growth opportunities |
| Earnings per share growth greater than revenue growth |  | ● | Improve operating margins through operational and commercial excellence |
|  |  | ● | Disciplined approach to balancing costs with long-term strategic investments |
| Capital allocation and returns |  | ● | Disciplined management of working capital |
| Cash flow from operations less capital expenditures (free cash flow) is targeted to approximate or exceed net income |  | ● | Deployment of capital consistent with capital allocation priorities |
| Target 40% of free cash flow returned to shareholders |  | ● | Mergers and acquisitions that align with strategy and financial metrics |
| Remainder focused on strategic acquisitions |  | ● | Grow dividend in line with earnings |
| Return on invested capital percentage in the high-teens |  | ● | Opportunistic share repurchases |

[0000889331-25-000039:mdna:26]
The Company’s strategy is focused on accelerating organic growth by increasing its product content in applications and share gains, enhancing technology efforts to drive innovation, expanding its digital presence, capitalizing on cross segment opportunities, and gaining traction in niche, high-growth end markets. The Company also leverages strategic acquisitions to enhance its organic growth. The Company will continue to make targeted strategic acquisitions that align to its strategy and financial metrics to drive growth across its businesses, products, markets, and technologies while leveraging existing customers and targeting new customers.

[0000889331-25-000039:mdna:27]
Management believes profitable growth through a combination of organic growth and strategic acquisitions is critical to the Company’s competitiveness, while enhancing the value it delivers to all of its stakeholders. In addition, the Company continues to implement initiatives across all businesses to enhance productivity, and its commercial and operational capabilities, while managing its cost structure to align with business conditions, and the markets it serves. Primary areas of focus include optimizing its global operations, successfully integrating strategic acquisitions, and streamlining administrative and support activities to drive improved operating margins.

[0000889331-25-000039:mdna:28]
The Company seeks to deploy its capital consistent with its capital allocation priorities. These priorities include investments to drive increased organic growth, targeted acquisitions that align to the Company’s strategic and financial metrics, and enhance and sustain its organic growth, and returning capital to shareholders through dividends and opportunistic share repurchases.

[0000889331-25-000039:mdna:29]
28

[0000889331-25-000039:mdna:30]
Critical Estimates and Significant Accounting Policies

[0000889331-25-000039:mdna:31]
The preparation of financial statements in conformity with Generally Accepted Accounting Principles ("GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. The Company’s most critical accounting policies are those that are most important to the portrayal of its financial condition and results of operations, and which require the Company to make its most difficult and subjective judgments, often as a result of the need to make estimates of matters that are inherently uncertain. The Company has identified the following as its most critical accounting policies and judgments. Although management believes that its estimates and assumptions are reasonable, they are based upon information available when they are made, and therefore, actual results may differ from these estimates under different assumptions or conditions. The Company has reviewed these critical accounting policies and related disclosures with the Audit Committee of its Board of Directors. Significant accounting policies are more fully described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0000889331-25-000039:mdna:32]
Critical Accounting Estimates

[0000889331-25-000039:mdna:33]
Goodwill

[0000889331-25-000039:mdna:34]
The Company’s methodology for allocating the purchase price of acquisitions is based on established valuation techniques that reflect the consideration of a number of factors, including valuations performed by third-party appraisers when appropriate. Goodwill is measured as the excess of the cost of an acquired entity over the fair value assigned to identifiable assets acquired and liabilities assumed. Based on its current organization structure, the Company has seven reporting units for which cash flows are determinable and to which goodwill has been allocated.

[0000889331-25-000039:mdna:35]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events.

[0000889331-25-000039:mdna:36]
As a result of the 2024 annual goodwill impairment test, the Company recorded non-cash charges of $36.1 million and $8.6 million to reflect the impairment of goodwill for the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. There were no impairment charges recorded during the fiscal years of 2023 and 2022.

[0000889331-25-000039:mdna:37]
The goodwill impairment charge for the Industrial controls and sensors reporting unit was due to a reduction in the estimated fair value of the reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2023 annual goodwill impairment test. These lower expectations were driven by lower-than-expected demand in the electric vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe.

[0000889331-25-000039:mdna:38]
The goodwill impairment charge for the Automotive sensors reporting unit was due to reductions in the estimated fair value for the Automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2023 annual goodwill impairment test. These lower future expectations were driven by projected  declines in end market demand and reduced revenue and profitability with existing customers.

[0000889331-25-000039:mdna:39]
Quantitative Assessment for Impairment

[0000889331-25-000039:mdna:40]
For the seven reporting units with goodwill, the Company compares the estimated fair value of each reporting unit to its carrying value. If the carrying value of a reporting unit exceeds the estimated fair value, the difference between the estimated fair value and carrying value is recorded as the amount of the goodwill impairment charge. The results of the goodwill impairment test as of September 29, 2024 indicated that the estimated fair values for the Industrial controls and sensors and Automotive sensors reporting units were below their respective carrying values. Accordingly, the Company recorded non-cash charges of $36.1 million and $8.6 million, respectively, to reflect the impairment of goodwill for the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment. As a result of the impairment charge, the Industrial controls and sensors reporting unit had $115.2 million of goodwill

[0000889331-25-000039:mdna:41]
as of December 28, 2024. There was no goodwill remaining within the Automotive sensors reporting unit as of December 28, 2024. For the remainder of the Company's reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, and Industrial Circuit Protection, the results of the goodwill impairment test as of September 29, 2024 indicated that their estimated fair values exceeded their respective carrying values.

[0000889331-25-000039:mdna:42]
As part of its impairment test for these reporting units, the Company engaged a third-party appraisal firm to assist in the Company’s determination of the estimated fair values. This determination included estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping. The Company weighted both the income and market approach equally to estimate the concluded fair value of each reporting unit. The determination of fair value requires the Company to make significant estimates and assumptions, which primarily include, but are not limited to: the selection of appropriate peer group companies; control premiums appropriate for acquisitions in which the Company competes; the discount rate; terminal growth rates; and forecasts of revenue, operating income, depreciation and amortization and capital expenditures.

[0000889331-25-000039:mdna:43]
Goodwill Impairment Assumptions

[0000889331-25-000039:mdna:44]
Although the Company believes its estimates of fair value are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results or other underlying assumptions could have a significant impact on the fair value of the reporting units. Future declines in the overall market value of the Company’s equity may also result in a conclusion that the fair value of one or more reporting units has declined below its carrying value.

[0000889331-25-000039:mdna:45]
One measure of the sensitivity of the amount of goodwill impairment charges to key assumptions is the amount by which each reporting unit “passed” (fair value exceeds the carrying value) the goodwill impairment test. With the exception of the Industrial controls and sensors and the Automotive sensors reporting units, the other five reporting units passed the goodwill impairment test, with estimated fair values that exceeded the carrying values between 44% and 409%. As of the most recent annual test conducted on September 29, 2024, the Company noted that the excess of fair value over the carrying value was 108%, 82%, 96%, 44%, and 409% for its reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, and Industrial Circuit Protection, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test.

[0000889331-25-000039:mdna:46]
Generally, changes in estimates of expected future cash flows would have a similar effect on the estimated fair value of the reporting unit. That is, a 1.0% decrease in estimated annual future cash flows would decrease the estimated fair value of the reporting unit by approximately 1.0%. The estimated long-term net sales growth rate can have a significant impact on the estimated future cash flows, and therefore, the fair value of each reporting unit. A 1.0% decrease in the long-term net sales growth rate would have resulted in no reporting units failing the goodwill impairment test. Of the other key assumptions that impact the estimated fair values, most reporting units have the greatest sensitivity to changes in the estimated discount rate. The estimated discount rate was 10.6% for the Electronics-Passive Products and Sensors, Electronics-Semiconductor, and Industrial Circuit Protection reporting units, 11.5% for the Passenger Car Products and Commercial Vehicle Products reporting units, 12.3% for the Automotive Sensors reporting unit, and 14.9% for the Industrial Controls and Sensors reporting unit. A 1.0% increase in the estimated discount rates would have resulted in no reporting units failing the annual goodwill impairment test. The Company believes that its estimates of future cash flows and discount rates are reasonable, but future changes in the underlying assumptions could differ due to the inherent uncertainty in making such estimates. Additionally, price deterioration or lower volume could have a significant impact on the fair values of the reporting units.

[0000889331-25-000039:mdna:47]
Long-Lived Assets

[0000889331-25-000039:mdna:48]
The Company evaluates the recoverability of other long-lived assets, including property, plant and equipment and certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset group may not be recoverable. Factors which could trigger an impairment review include significant underperformance relative to historical or projected operating results, significant changes in the manner of use of the assets or the strategy for the overall business, and a significant decrease in the market value of the assets or significant negative industry or economic trends. When the Company determines that the carrying value of long-lived assets may not be recoverable based upon the existence of one or more of the indicators, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition. If the carrying value of an asset exceeds its estimated future

[0000889331-25-000039:mdna:49]
undiscounted cash flows, an impairment loss is recorded for the excess of the asset’s carrying value over its fair value. For the fiscal year ended December 28, 2024, the Company recorded non-cash impairment charges of $47.8 million for the impairment of intangible assets, including $47.6 million related to the impairment of certain acquired customer relationships, developed technology, and tradename intangible assets in the Industrial controls and sensors reporting unit within the Industrial segment. The impairment of the intangible assets resulted from lower expectations of future revenue and cash flows driven by lower-than-expected demand in the electrical vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. For the fiscal year ended December 30, 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate, a $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment on certain machinery and equipment in the semiconductor business within the Electronics segment.

[0000889331-25-000039:mdna:50]
Income Taxes

[0000889331-25-000039:mdna:51]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-25-000039:mdna:52]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-25-000039:mdna:53]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-25-000039:mdna:54]
The 2017 Tax Cuts and Jobs Act (the "Tax Act"), among other things, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and included base broadening provisions commonly referred to as the global intangible low-taxed income provisions ("GILTI").

[0000889331-25-000039:mdna:55]
In accordance with guidance issued by the Financial Accounting Standards Board ("FASB") staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 28, 2024, December 30, 2023, and December 31, 2022, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-25-000039:mdna:56]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-25-000039:mdna:57]
Critical Accounting Policies

[0000889331-25-000039:mdna:58]
Revenue Recognition

[0000889331-25-000039:mdna:59]
Revenue Disaggregation

[0000889331-25-000039:mdna:60]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 28, 2024 and December 30, 2023:

[0000889331-25-000039:mdna:61]
|  |  | Fiscal Year Ended December 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 615,372 |  |  | $ | — |  |  | $ | — |  |  | $ | 615,372 |  |
| Electronics – Passive Products and Sensors |  | 571,401 |  |  | — |  |  | — |  |  | 571,401 |  |
| Commercial Vehicle Products |  | — |  |  | 320,549 |  |  | — |  |  | 320,549 |  |
| Passenger Car Products |  | — |  |  | 278,332 |  |  | — |  |  | 278,332 |  |
| Automotive Sensors |  | — |  |  | 73,553 |  |  | — |  |  | 73,553 |  |
| Industrial Products |  | — |  |  | — |  |  | 331,561 |  |  | 331,561 |  |
| Total |  | $ | 1,186,773 |  |  | $ | 672,434 |  |  | $ | 331,561 |  |  | $ | 2,190,768 |  |

[0000889331-25-000039:mdna:62]
|  |  | Fiscal Year Ended December 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | TransportationSegment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 767,393 |  |  | $ | — |  |  | $ | — |  |  | $ | 767,393 |  |
| Electronics – Passive Products and Sensors |  | 583,033 |  |  | — |  |  | — |  |  | 583,033 |  |
| Commercial Vehicle Products |  | — |  |  | 323,758 |  |  | — |  |  | 323,758 |  |
| Passenger Car Products |  | — |  |  | 266,004 |  |  | — |  |  | 266,004 |  |
| Automotive Sensors |  | — |  |  | 88,516 |  |  | — |  |  | 88,516 |  |
| Industrial Products |  | — |  |  | — |  |  | 333,953 |  |  | 333,953 |  |
| Total |  | $ | 1,350,426 |  |  | $ | 678,278 |  |  | $ | 333,953 |  |  | $ | 2,362,657 |  |

[0000889331-25-000039:mdna:63]
|  |  | Fiscal Year Ended December 31, 2022 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 802,281 |  |  | $ | — |  |  | $ | — |  |  | $ | 802,281 |  |
| Electronics – Passive Products and Sensors |  | 690,538 |  |  | — |  |  | — |  |  | 690,538 |  |
| Commercial Vehicle Products |  | — |  |  | 374,707 |  |  | — |  |  | 374,707 |  |
| Passenger Car Products |  | — |  |  | 249,470 |  |  | — |  |  | 249,470 |  |
| Automotive Sensors |  | — |  |  | 91,963 |  |  | — |  |  | 91,963 |  |
| Industrial Products |  | — |  |  | — |  |  | 304,938 |  |  | 304,938 |  |
| Total |  | $ | 1,492,819 |  |  | $ | 716,140 |  |  | $ | 304,938 |  |  | $ | 2,513,897 |  |

[0000889331-25-000039:mdna:64]
See Note 16, Segment Information, for net sales by segment and country.

[0000889331-25-000039:mdna:65]
Revenue Recognition

[0000889331-25-000039:mdna:66]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates and price adjustments. The Company’s sales channels are primarily through direct sales and independent third-party distributors.

[0000889331-25-000039:mdna:67]
The Company has elected the practical expedient under Accounting Standards Codification ("ASC") 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-25-000039:mdna:68]
Revenue and Billing

[0000889331-25-000039:mdna:69]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0000889331-25-000039:mdna:70]
Ship and Debit Program

[0000889331-25-000039:mdna:71]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-25-000039:mdna:72]
Return to Stock

[0000889331-25-000039:mdna:73]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-25-000039:mdna:74]
Volume Rebates

[0000889331-25-000039:mdna:75]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-25-000039:mdna:76]
Allowance for Credit Losses

[0000889331-25-000039:mdna:77]
The Company currently measures the expected credit losses based on our historical credit loss experience. The Company has not experienced significant recent or historical credit losses and is not forecasting any significant credit losses which would require adjustments to our methodology. If current conditions and supportable forecasts indicate that our historical loss experience is not reasonable and no longer supportable, the Company may adjust its historical credit loss experience to reflect these conditions and forecasts. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a customer’s inability to meet its financial obligations, records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also analyzes all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and historical collection and loss experience. Historically, the allowance for credit losses has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-25-000039:mdna:78]
Inventory

[0000889331-25-000039:mdna:79]
The Company performs regular detailed assessments of inventory, which include a review of, among other factors, demand requirements, product life cycle and development plans, component cost trends, product pricing, shelf life, and quality issues. Based on the analysis, the Company records adjustments to inventory for excess quantities, obsolescence or impairment when appropriate to reflect inventory at net realizable value. Historically, inventory reserves have been adequate to reflect inventory at net realizable value.

[0000889331-25-000039:mdna:80]
Environmental Liabilities

[0000889331-25-000039:mdna:81]
Environmental liabilities are accrued based on estimates of the probability of potential future environmental exposure. Costs related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, it would record additional charges as other expense during the period in which the actual loss or change in estimate occurred. The Company evaluates its reserve for coal mine remediation annually utilizing a third-party expert.

[0000889331-25-000039:mdna:82]
Pension Plans

[0000889331-25-000039:mdna:83]
The Company records annual income and expense amounts relating to its pension and postretirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return, and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive loss. The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors. The Company maintains several pension plans in international locations. The expected returns on plan assets and discount rates are determined based on each plan’s investment approach, local interest rates and plan participant profiles. The weighted-average discount rates for the Company’s defined benefit plans primarily in Europe and the Asia-Pacific regions at December 28, 2024 and December 30, 2023 were both 5.6%.

[0000889331-25-000039:mdna:84]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $23 million, representing approximately 33% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-25-000039:mdna:85]
Equity-Based Compensation

[0000889331-25-000039:mdna:86]
Equity-based compensation expense is recorded for stock-option awards and restricted share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate, and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock, and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments for the foreseeable future. The fair value of restricted share units is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-25-000039:mdna:87]
Total equity-based compensation expense for all equity compensation plans was $27.4 million, $25.7 million, and $24.6 million in 2024, 2023, and 2022, respectively. Further information regarding this expense is provided in Note 12, Stock-Based Compensation, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-25-000039:mdna:88]
In the financial review that follows, the Company discusses its consolidated results of operations, financial position, cash flows and certain other information. This discussion should be read in conjunction with the Company’s Consolidated Financial Statements and related notes.

[0000889331-25-000039:mdna:89]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 28, 2024 AS COMPARED TO THE YEAR ENDED DECEMBER 30, 2023

[0000889331-25-000039:mdna:90]
Fiscal year 2024 included $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the

[0000889331-25-000039:mdna:91]
Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0000889331-25-000039:mdna:92]
Fiscal year 2023 included $28.2 million of non-segment charges, of which $11.7 million related to legal and professional fees and other integration expenses related to completed and contemplated acquisitions and $16.5 million of restructuring, impairment and other charges, primarily associated with employee termination costs and a $3.9 million impairment charge for the land and building in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-25-000039:mdna:93]
Fiscal year 2024 also included approximately $9.2 million in foreign currency exchange gains primarily attributable to changes in the value of the Euro, Korean won, and Chinese renminbi against the U.S. dollar, while fiscal year 2023 included approximately $12.3 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Sterling, and Chinese renminbi against the U.S. dollar.

[0000889331-25-000039:mdna:94]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2024 |  | 2023 |  | Change |  | % Change |
| Net sales | $ | 2,190,768 |  |  | $ | 2,362,657 |  |  | $ | (171,889) |  |  | (7.3) | % |
| Cost of sales | 1,403,226 |  |  | 1,462,416 |  |  | (59,190) |  |  | (4.0) | % |
| Gross profit | 787,542 |  |  | 900,241 |  |  | (112,699) |  |  | (12.5) | % |
| Operating expenses | 628,762 |  |  | 539,379 |  |  | 89,383 |  |  | 16.6 | % |
| Operating income | 158,780 |  |  | 360,862 |  |  | (202,082) |  |  | (56.0) | % |
| Other income, net | (22,570) |  |  | (19,901) |  |  | 2,669 |  |  | 13.4 | % |
| Income before income taxes | 151,863 |  |  | 328,598 |  |  | (176,735) |  |  | (53.8) | % |
| Income taxes | 51,673 |  |  | 69,113 |  |  | (17,440) |  |  | (25.2) | % |
| Net income | 100,190 |  |  | 259,485 |  |  | (159,295) |  |  | (61.4) | % |

[0000889331-25-000039:mdna:95]
Net Sales

[0000889331-25-000039:mdna:96]
Net sales were $2,190.8 million, which decreased by $171.9 million, or 7.3% compared to 2023, including $7.9 million of unfavorable changes in foreign exchange rates for 2024 compared to 2023. The net sales decrease was primarily due to lower volume of $163.7 million in the Electronics segment, primarily driven by reduced demand and inventory rebalancing in the semiconductor business.

[0000889331-25-000039:mdna:97]
Cost of Sales

[0000889331-25-000039:mdna:98]
Cost of sales was $1,403.2 million, or 64.1% of net sales, in 2024 compared to $1,462.4 million, or 61.9% of net sales, in 2023. As a percent of net sales, cost of sales increased 2.2% driven by lower volume in the Electronics segment, partially offset by improved margin from all businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives. In addition, during the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that have now been corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The error that was identified by management related to the valuation and existence of inventory that originated in prior periods at certain of our non-U.S. manufacturing locations within the Transportation and Industrial segments. As a result, the Company recorded an out-of-period adjustment of  $13.5 million in the year ended December 28, 2024, of which $12.3 million was the cumulative out-of-period adjustment related to fiscal years prior to 2024. The out-of-period adjustment negatively impacted cost of sales as percentage of net sales by 0.6%.

[0000889331-25-000039:mdna:99]
Gross Profit

[0000889331-25-000039:mdna:100]
Gross profit was $787.5 million, or 35.9% of net sales, in 2024, compared to $900.2 million, or 38.1% of net sales, in 2023. The $112.7 million decrease in gross profit was primarily due to lower volume in the Electronics and Industrial segments, partially offset by improved margin from all businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives. As mentioned above, the out-of-period adjustments of $13.5 million negatively impacted gross margin by 0.6%.

[0000889331-25-000039:mdna:101]
Operating Expenses

[0000889331-25-000039:mdna:102]
Total operating expenses were $628.8 million, or 28.7% of net sales, for 2024 compared to $539.4 million, or 22.8% of net sales, for 2023. The increase in operating expenses of $89.4 million was primarily due to an increase in restructuring, impairment, and other charges of $91.9 million, which included a non-cash impairment charge of $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. Additionally, the Company incurred higher research and development expenses of $5.3 million. These increases in operating expenses were partially offset by lower selling, general, and administrative expenses of $4.2 million as a result of lower legal and professional fees and other integration expenses related to completed and contemplated acquisitions and lower amortization expense of $3.7 million.

[0000889331-25-000039:mdna:103]
Operating Income

[0000889331-25-000039:mdna:104]
Operating income for 2024 was $158.8 million, a decrease of $202.1 million or 56.0% compared to $360.9 million for 2023.  The decrease in operating income was due to lower operating income of $130.7 million from the Electronics segment and higher operating expenses due to the non-cash charge of $92.6 million from the impairment of intangible assets and goodwill as noted above, partially offset by higher operating income of $24.9 million from the Transportation segment. Operating margins decreased from 15.3% in 2023 to 7.2% in 2024 primarily driven by lower volume in the Electronics segment and the higher operating expenses mentioned above. The total non-cash charges of $92.6 million from the impairment of intangible assets and goodwill negatively impacted the 2024 operating margin by 4.2%.

[0000889331-25-000039:mdna:105]
Income Before Income Taxes

[0000889331-25-000039:mdna:106]
Income before income taxes for 2024 was $151.9 million, or 6.9% of net sales compared to $328.6 million, or 13.9% of net sales for 2023. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by foreign exchange gains of $9.2 million in the fiscal year 2024 compared to foreign exchange losses of $12.3 million in the fiscal year 2023, and higher interest income of $9.0 million from short-term investments in cash equivalents, partially offset by higher coal mine charges of $1.8 million and non-operating pension expense.

[0000889331-25-000039:mdna:107]
Income Taxes

[0000889331-25-000039:mdna:108]
Income tax expense for 2024 was $51.7 million, or an effective tax rate of 34.0%, compared to income tax expense of $69.1 million, or an effective tax rate of 21.0% for 2023. The effective tax rate for 2024 is higher than the effective tax rate for 2023,

[0000889331-25-000039:mdna:109]
primarily due to the impact of goodwill impairments and non-US losses with no related tax benefit. The effective tax rate for 2024 is higher than the statutory tax rate primarily due to the impact of goodwill impairments and non-US losses with no related tax benefit as previously noted. Further information regarding these items is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-25-000039:mdna:110]
Segment Information

[0000889331-25-000039:mdna:111]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-25-000039:mdna:112]
The following table is a summary of the Company’s net sales and operating income by segment:

[0000889331-25-000039:mdna:113]
| Net Sales | Fiscal Year |  |  |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  | % Change |
| Electronics | $ | 1,186.8 |  |  | $ | 1,350.4 |  |  | $ | (163.7) |  |  | (12.1) | % |
| Transportation | 672.4 |  |  | 678.3 |  |  | (5.9) |  |  | (0.9) | % |
| Industrial | 331.6 |  |  | 334.0 |  |  | (2.4) |  |  | (0.7) | % |
| Total | $ | 2,190.8 |  |  | $ | 2,362.7 |  |  | $ | (171.9) |  |  | (7.3) | % |

[0000889331-25-000039:mdna:114]
| Segment Operating Income | Fiscal Year |  |  |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  | % Change |
| Electronics | $ | 169.9 |  |  | $ | 300.6 |  |  | $ | (130.7) |  |  | (43.5) | % |
| Transportation | 58.6 |  |  | 33.7 |  |  | 24.9 |  |  | 73.9 | % |
| Industrial | 42.3 |  |  | 54.8 |  |  | (12.5) |  |  | (22.8) | % |
| Total segment operating income | 270.8 |  |  | 389.1 |  |  | (118.3) |  |  |  |
| Other (a) | (112.0) |  |  | (28.2) |  |  | (83.8) |  |  |  |
| Total Operating income | $ | 158.8 |  |  | $ | 360.9 |  |  | $ | (202.1) |  |  | (56.0) | % |

[0000889331-25-000039:mdna:115]
(a) Included in “Other” Operating income for the 2024 was $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0000889331-25-000039:mdna:116]
Included in “Other” Operating income for the 2023 was $28.2 million of non-segment charges, of which $11.7 million was for legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $16.5 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-25-000039:mdna:117]
Electronics Segment

[0000889331-25-000039:mdna:118]
Net Sales

[0000889331-25-000039:mdna:119]
Net sales for the Electronics segment decreased $163.7 million, or 12.1%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $4.3 million or 0.3%. The net sales decrease was mainly due to lower volume from the semiconductor business of $152.0 million and to a lesser extent the electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, as well as industrial markets.

[0000889331-25-000039:mdna:120]
Operating Income

[0000889331-25-000039:mdna:121]
Operating income was $169.9 million, representing a decrease of $130.7 million, or 43.5%, in 2024 compared to $300.6 million in 2023. The decrease in operating income was primarily due to lower volume leverage and unfavorable product mix that were partially offset by cost control initiatives. Operating margins decreased from 22.3% in 2023 to 14.3% in 2024 primarily due to the lower volume from the semiconductor business.

[0000889331-25-000039:mdna:122]
Transportation Segment

[0000889331-25-000039:mdna:123]
Net Sales

[0000889331-25-000039:mdna:124]
Net sales in the Transportation segment decreased $5.9 million, or 0.9%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $2.4 million or 0.4%. The sales decrease was mainly driven by lower volume of $15.0 million and $3.2 million from the automotive sensors and the commercial vehicles businesses, respectively, due to the strategic exit of certain lower margin products and reduced demand largely due to inventory rebalancing at certain distributors and customers, partially offset by a sales increase of $12.3 million from the passenger car business driven by the ongoing electronification and electrification of vehicles and vehicle content growth.

[0000889331-25-000039:mdna:125]
Operating Income

[0000889331-25-000039:mdna:126]
Operating income was $58.6 million, representing an increase of $24.9 million, or 73.9%, in 2024 compared to $33.7 million in 2023. The increase in operating income was primarily due to favorable price and cost reduction initiatives from the commercial vehicle business. Operating margins increased from 5.0% to 8.7% primarily driven by favorable price and product mix and cost reduction initiatives from the commercial vehicle business. In addition, as mentioned above, during the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that have now been corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The out-of-period adjustment related to the Transportation segment was $11.1 million, which negatively impacted operating margin by 1.7%.

[0000889331-25-000039:mdna:127]
Industrial Segment

[0000889331-25-000039:mdna:128]
Net Sales

[0000889331-25-000039:mdna:129]
The Industrial segment net sales decreased by $2.4 million, or 0.7%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $1.2 million or 0.4%. The sales decrease was due to lower volume across industrial control products driven by softer end market demand in the first half of 2024.

[0000889331-25-000039:mdna:130]
Operating Income

[0000889331-25-000039:mdna:131]
Operating income was $42.3 million, representing a decrease of $12.5 million, or 22.8%, in 2024 compared to $54.8 million in 2023. The decrease in operating income was driven by lower volume due to reduced industrial end market demand across industrial control products and industrial circuit protection along with cost inflation. Operating margins were 12.8% in 2024 compared to 16.4% in 2023. The decrease in operating margin was due to cost inflation, partially offset by favorable price. In addition, as mentioned above, during the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that have now been corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The out-of-period adjustment related to the Industrial segment was $4.1 million, which negatively impacted operating margin by 1.2%.

[0000889331-25-000039:mdna:132]
Geographic Net Sales Information

[0000889331-25-000039:mdna:133]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-25-000039:mdna:134]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  | % Change |
| Americas | $ | 900.4 |  |  | $ | 901.5 |  |  | $ | (1.1) |  |  | (0.1) | % |
| Asia-Pacific | 824.7 |  |  | 898.9 |  |  | (74.2) |  |  | (8.3) | % |
| Europe | 465.7 |  |  | 562.3 |  |  | (96.6) |  |  | (17.2) | % |
| Total | $ | 2,190.8 |  |  | $ | 2,362.7 |  |  | $ | (171.9) |  |  | (7.3) | % |

[0000889331-25-000039:mdna:135]
Americas

[0000889331-25-000039:mdna:136]
Net sales in the Americas decreased $1.1 million, or 0.1%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $0.7 million. The decrease in net sales was primarily due to lower volume from the semiconductor business within the Electronics segment, partially offset by higher volume from the Industrial segment and the commercial vehicle and passenger car products businesses within the Transportation segment compared to 2023.

[0000889331-25-000039:mdna:137]
Asia-Pacific

[0000889331-25-000039:mdna:138]
Asia-Pacific net sales decreased $74.2 million, or 8.3%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $9.2 million. The decrease in net sales was primarily due to lower net sales from the semiconductor business within the Electronics segment and the industrial circuit protection business within the Industrial segment, partially offset by higher net sales from the passenger car products business within the Transportation segment compared to 2023.

[0000889331-25-000039:mdna:139]
Europe

[0000889331-25-000039:mdna:140]
Europe net sales decreased $96.6 million, or 17.2%, in 2024 compared to 2023 and included favorable changes in foreign exchange rates of $2.0 million. The decrease in net sales was primarily due to lower net sales from the Electronics segment and lower net sales from the commercial vehicle and automotive sensors businesses within the Transportation segment compared to 2023.

[0000889331-25-000039:mdna:141]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 30, 2023 AS COMPARED TO THE YEAR ENDED DECEMBER 31, 2022

[0000889331-25-000039:mdna:142]
Fiscal year 2023 included $28.2 million of non-segment charges, of which $11.7 million related to legal and professional fees and other integration expenses related to completed and contemplated acquisitions and $16.5 million of restructuring, impairment and other charges, primarily associated with employee termination costs and a $3.9 million impairment charge for the land and building in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-25-000039:mdna:143]
Fiscal year 2022 included $43.2 million of non-segment charges, of which $17.6 million related to legal and professional fees and other integration expenses primarily associated with the C&K Switches and Carling acquisitions and other contemplated acquisitions, $15.6 million of purchase accounting inventory step-up charges, and $10.0 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $2.9 million intangible asset impairment charge within the Electronics segment in the fourth quarter of 2022. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-25-000039:mdna:144]
Fiscal year 2023 also included approximately $12.3 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Sterling, and Chinese renminbi against the U.S. dollar, while fiscal year 2022 included approximately $24.4 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Philippine peso, Sterling, and Chinese renminbi against the U.S. dollar.

[0000889331-25-000039:mdna:145]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2023 |  | 2022 |  | Change |  | % Change |
| Net sales | $ | 2,362,657 |  |  | $ | 2,513,897 |  |  | $ | (151,240) |  |  | (6.0) | % |
| Cost of sales | 1,462,416 |  |  | 1,506,984 |  |  | (44,568) |  |  | (3.0) | % |
| Gross profit | 900,241 |  |  | 1,006,913 |  |  | (106,672) |  |  | (10.6) | % |
| Operating expenses | 539,379 |  |  | 506,087 |  |  | 33,292 |  |  | 6.6 | % |
| Operating income | 360,862 |  |  | 500,826 |  |  | (139,964) |  |  | (27.9) | % |
| Other (income) expense, net | (19,901) |  |  | 7,207 |  |  | (27,108) |  |  | (376.1) | % |
| Income before income taxes | 328,598 |  |  | 443,044 |  |  | (114,446) |  |  | (25.8) | % |
| Income taxes | 69,113 |  |  | 69,738 |  |  | (625) |  |  | (0.9) | % |
| Net income | 259,485 |  |  | 373,306 |  |  | (113,821) |  |  | (30.5) | % |

[0000889331-25-000039:mdna:146]
Net Sales

[0000889331-25-000039:mdna:147]
Net sales were $2,362.7 million, which decreased by $151.2 million, or 6.0% compared to 2022, including $0.7 million of favorable changes in foreign exchange rates for 2023 compared to 2022. The sales decrease was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment that more than offset $105.1 million or 4.2% of incremental net sales from the C&K Switches and Western Automation acquisitions and higher volume from the Industrial segment.

[0000889331-25-000039:mdna:148]
Cost of Sales

[0000889331-25-000039:mdna:149]
Cost of sales was $1,462.4 million, or 61.9% of net sales, in 2023, compared to $1,507.0 million, or 59.9% of net sales, in 2022. As a percent of net sales, cost of sales increased 2.0% driven by lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by volume leverage and favorable product mix from the Industrial segment compared to 2022, and $15.6 million or 0.6% of purchase accounting inventory charges recorded during 2022.

[0000889331-25-000039:mdna:150]
Gross Profit

[0000889331-25-000039:mdna:151]
Gross profit was $900.2 million, or 38.1% of net sales, in 2023, compared to $1,006.9 million, or 40.1% of net sales, in 2022. The $106.7 million decrease in gross profit was primarily due to lower volume in the Electronics segment and the commercial vehicle business within the Transportation segment, partially offset by the acquisition of C&K Switches within the Electronics segment, and volume leverage and favorable product mix from the Industrial segment and $15.6 million or 0.6% of purchase accounting inventory charges recorded during the first nine months of 2022.

[0000889331-25-000039:mdna:152]
Operating Expenses

[0000889331-25-000039:mdna:153]
Total operating expenses were $539.4 million, or 22.8% of net sales, for 2023 compared to $506.1 million, or 20.1% of net sales, for 2022. The increase in operating expenses of $33.3 million was primarily due to higher selling, general, and administrative expenses of $9.8 million, higher amortization expense of $10.1 million and research and development expenses of $6.8 million mainly due to the C&K Switches and Western Automation acquisitions. Additionally, the Company incurred an increase in restructuring, impairment, and other charges of $6.5 million primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation and Industrial segments and a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment. This increase in operating expenses was partially offset by lower variable incentive compensation expense.

[0000889331-25-000039:mdna:154]
Operating Income

[0000889331-25-000039:mdna:155]
Operating income for 2023 was $360.9 million, a decrease of $140.0 million or 27.9% compared to $500.8 million for 2022. The decrease in operating income was due to lower gross profit from the Electronics and Transportation segments and higher

[0000889331-25-000039:mdna:156]
operating expenses as noted above. Operating margins decreased from 19.9% in 2022 to 15.3% in 2023 primarily driven by lower volume in the Electronics and Transportation segments and the higher operating expenses mentioned above.

[0000889331-25-000039:mdna:157]
Income Before Income Taxes

[0000889331-25-000039:mdna:158]
Income before income taxes for 2023 was $328.6 million, or 13.9% of net sales compared to $443.0 million, or 17.6% of net sales, for 2022. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by lower foreign exchange losses of $12.1 million and lower unrealized losses of $13.7 million related to one of the Company's equity investments for 2023 compared to 2022.

[0000889331-25-000039:mdna:159]
Income Taxes

[0000889331-25-000039:mdna:160]
Income tax expense for 2023 was $69.1 million, or an effective tax rate of 21.0%, compared to income tax expense of $69.7 million, or an effective tax rate of 15.7% for 2022. The effective tax rate for 2023 is higher than the effective tax rate for 2022,

[0000889331-25-000039:mdna:161]
primarily due to less income earned in lower tax jurisdictions in 2023, as well as one-time tax benefits in 2022 resulting from losses on investments in the stock of two of the Company's affiliates. The effective tax rate for 2022 was lower than the applicable U.S. statutory tax rate primarily due to income earned in lower tax jurisdictions as well as the impact of the one-time deductions previously noted. Further information regarding these items is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-25-000039:mdna:162]
Segment Information

[0000889331-25-000039:mdna:163]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0000889331-25-000039:mdna:164]
The following table is a summary of the Company’s net sales and operating income by segment:

[0000889331-25-000039:mdna:165]
| Net Sales | Fiscal Year |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | % Change |
| Electronics | $ | 1,350.4 |  |  | $ | 1,492.8 |  |  | $ | (142.4) |  |  | (9.5) | % |
| Transportation | 678.3 |  |  | 716.2 |  |  | (37.9) |  |  | (5.3) | % |
| Industrial | 334.0 |  |  | 304.9 |  |  | 29.1 |  |  | 9.5 | % |
| Total | $ | 2,362.7 |  |  | $ | 2,513.9 |  |  | $ | (151.2) |  |  | (6.0) | % |

[0000889331-25-000039:mdna:166]
| Segment Operating Income | Fiscal Year |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | % Change |
| Electronics | $ | 300.6 |  |  | $ | 431.6 |  |  | $ | (131.0) |  |  | (30.4) | % |
| Transportation | 33.7 |  |  | 63.5 |  |  | (29.8) |  |  | (47.0) | % |
| Industrial | 54.8 |  |  | 48.9 |  |  | 5.9 |  |  | 12.1 | % |
| Total segment operating income | 389.1 |  |  | 544.0 |  |  | (154.9) |  |  |  |
| Other (a) | (28.2) |  |  | (43.2) |  |  | 15.0 |  |  |  |
| Total Operating income | $ | 360.9 |  |  | $ | 500.8 |  |  | $ | (139.9) |  |  | (30.9) | % |

[0000889331-25-000039:mdna:167]
(a) Included in “Other” Operating income for the 2023 was $28.2 million of non-segment charges, of which $11.7 million was for legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $16.5 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-25-000039:mdna:168]
Included in “Other” Operating income for 2022 was $43.2 million of non-segment charges, of which $17.6 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $15.6 million of purchase accounting inventory step-up charges, and $10.0 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $2.9 million non-cash impairment charge for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment in the fourth quarter of 2022. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-25-000039:mdna:169]
Electronics Segment

[0000889331-25-000039:mdna:170]
Net Sales

[0000889331-25-000039:mdna:171]
Net sales for the Electronics segment decreased $142.4 million, or 9.5%, in 2023 compared to 2022 and included favorable changes in foreign exchange rates of $2.1 million or 0.1%. The sales decrease was mainly due to lower volume from the Electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, and telecom, which more than offset the incremental net sales of $91.9 million from the C&K Switches acquisition.

[0000889331-25-000039:mdna:172]
Operating Income

[0000889331-25-000039:mdna:173]
Operating income was $300.6 million, representing a decrease of $131.0 million, or 30.4%, in 2023 compared to $431.6 million in 2022. The decrease in operating income was primarily due to lower volume mainly driven from the Electronics products business, which more than offset the incremental volume from the C&K Switches acquisition. Operating margins decreased from 28.9% in 2022 to 22.3% in 2023 primarily due to the lower volume.

[0000889331-25-000039:mdna:174]
Transportation Segment

[0000889331-25-000039:mdna:175]
Net Sales

[0000889331-25-000039:mdna:176]
Net sales in the Transportation segment decreased $37.9 million, or 5.3%, in 2023 compared to 2022 and included unfavorable changes in foreign exchange rates of $0.7 million or 0.1%. The commercial vehicle business net sales declined $50.9 million, largely driven by reduced demand largely due to inventory rebalancing at certain distributors and customers, and some demand reduction in commercial vehicle end markets. The automotive sensors business had net sales declines of $3.4 million primarily due to lower demand in the United States and China. These declines were partially offset by an increase of $16.5 million from the passenger car products business driven by the ongoing electronification and electrification of vehicles and global passenger vehicle production growth.

[0000889331-25-000039:mdna:177]
Operating Income

[0000889331-25-000039:mdna:178]
Operating income was $33.7 million, representing a decrease of $29.8 million, or 47.0%, in 2023 compared to $63.5 million in 2022. Operating margins declined from 8.9% to 5.0% primarily due to lower volume from the commercial vehicle business, partially offset by higher volume and price realization in the passenger car business.

[0000889331-25-000039:mdna:179]
Industrial Segment

[0000889331-25-000039:mdna:180]
Net Sales

[0000889331-25-000039:mdna:181]
The Industrial segment net sales increased by $29.1 million, or 9.5%, in 2023 compared to 2022 and included unfavorable changes in foreign exchange rates of $0.7 million or 0.2%. The increase in net sales was primarily due to higher volume across multiple end markets, and the acquisition of Western Automation.

[0000889331-25-000039:mdna:182]
Operating Income

[0000889331-25-000039:mdna:183]
Operating income was $54.8 million, representing an increase of $5.9 million, or 12.1%, in 2023 compared to $48.9 million in 2022. The increase in operating income was due to price realization and higher volume, partially offset by higher amortization expenses from the acquisition of Western Automation. Operating margins were 16.4% in 2023 compared to 16.0% in 2022.

[0000889331-25-000039:mdna:184]
Geographic Net Sales Information

[0000889331-25-000039:mdna:185]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0000889331-25-000039:mdna:186]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | % Change |
| Americas | $ | 901.5 |  |  | $ | 992.3 |  |  | $ | (90.8) |  |  | (9.2) | % |
| Asia-Pacific | 898.9 |  |  | 1,019.9 |  |  | (121.0) |  |  | (11.9) | % |
| Europe | 562.3 |  |  | 501.7 |  |  | 60.6 |  |  | 12.1 | % |
| Total | $ | 2,362.7 |  |  | $ | 2,513.9 |  |  | $ | (151.2) |  |  | (6.0) | % |

[0000889331-25-000039:mdna:187]
Americas

[0000889331-25-000039:mdna:188]
Net sales in the Americas decreased $90.8 million, or 9.2%, in 2023 compared to 2022 and included unfavorable changes in foreign exchange rates of $0.1 million. The decrease in net sales was primarily due to lower volume from the electronics products business within the Electronics segment and lower sales from the commercial vehicle business within the Transportation segment, partially offset by incremental sales from C&K Switches acquisition within the Electronics segment and higher sales within the Industrial segment compared to 2022.

[0000889331-25-000039:mdna:189]
Asia-Pacific

[0000889331-25-000039:mdna:190]
Asia-Pacific net sales decreased $121.0 million, or 11.9%, in 2023 compared to 2022 and included unfavorable changes in foreign exchange rates of $12.3 million. The decrease in net sales was primarily due to lower net sales from electronics products business within the Electronics segment and lower net sales from the commercial vehicle business within the Transportation segment, partially offset by incremental sales from C&K Switches acquisition within the Electronics segment and Western Automation acquisition within in the Industrial segment compared to 2022.

[0000889331-25-000039:mdna:191]
Europe

[0000889331-25-000039:mdna:192]
Europe net sales increased $60.6 million, or 12.1%, in 2023 compared to 2022 and included favorable changes in foreign exchange rates of $13.1 million. The increase in net sales was primarily due to incremental sales from the acquisition of C&K Switches, increased volume from the semiconductor business within the Electronics segment and the passenger car products business within the Transportation segment, and the incremental sales from the Western Automation acquisition included within the Industrial segment, partially offset by lower net sales from the electronics products business within the Electronics segment.

[0000889331-25-000039:mdna:193]
38

[0000889331-25-000039:mdna:194]
Liquidity and Capital Resources

[0000889331-25-000039:mdna:195]
Cash and cash equivalents were $724.9 million as of December 28, 2024, an increase of $169.4 million as compared to December 30, 2023.

[0000889331-25-000039:mdna:196]
As of December 28, 2024, $422.8 million of the Company's $724.9 million cash and cash equivalents was held by non-U.S. subsidiaries. Of the $422.8 million, at least $228.7 million can be repatriated with minimal tax consequences, although in certain cases a non-U.S.withholding tax would be payable but subsequently refunded. With respect to the remaining $194.1 million, the Company has recognized deferred tax liabilities on approximately $49.7 million as of December 28, 2024 because the amounts are not considered to be permanently reinvested, and the Company may access additional amounts through loans and other means. Repatriation of some non-U.S. cash balances is restricted by local laws. Management regularly evaluates whether foreign earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its foreign subsidiaries. Changes in economic and business conditions and tax laws could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-25-000039:mdna:197]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0000889331-25-000039:mdna:198]
Revolving Credit Facility and Term Loan

[0000889331-25-000039:mdna:199]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (as so amended and restated, the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-25-000039:mdna:200]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-25-000039:mdna:201]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the fiscal year ended December 28, 2024, the Company made term loan payments of $7.5 million. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $281.3 million, respectively, as of December 28, 2024.

[0000889331-25-000039:mdna:202]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-25-000039:mdna:203]
As of December 28, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 5.71%, and 4.13% on the hedged portion.

[0000889331-25-000039:mdna:204]
As of December 28, 2024, the Company had $0.1 million outstanding letters of credit and had available $599.9 million of borrowing capacity under the revolving credit facility. As of December 28, 2024, the Company was in compliance with all covenants under the credit agreement.

[0000889331-25-000039:mdna:205]
Senior Notes

[0000889331-25-000039:mdna:206]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due 2023. Interest on the Euro Senior Notes, Series B due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-25-000039:mdna:207]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due 2022. Interest on the U.S. Senior Notes, Series B due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-25-000039:mdna:208]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable on February 15 and August 15, commencing on August 15, 2018.

[0000889331-25-000039:mdna:209]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the amended and restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-25-000039:mdna:210]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-25-000039:mdna:211]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-25-000039:mdna:212]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of December 28, 2024, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-25-000039:mdna:213]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-25-000039:mdna:214]
Debt Covenants

[0000889331-25-000039:mdna:215]
The Company was in compliance with its debt covenants as of December 28, 2024. As of December 28, 2024, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0000889331-25-000039:mdna:216]
Acquisitions

[0000889331-25-000039:mdna:217]
Dortmund Fab: On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab is approximately 94 million Euro, of which 37.2 million Euro down payment (approximately $40.5 million) was recorded in Prepaid expenses and other current assets in the Consolidated Balance Sheets. The down payment was paid in the third quarter of 2023 after regulatory approvals, and 56.7 million Euro was paid at closing. The transaction did not have any impact on the Company's 2024 financial results and reported in the Electronics-Semiconductor business within the Company’s Electronics segment. The acquisition was funded with the Company’s cash on hand.

[0000889331-25-000039:mdna:218]
On February 3, 2023, the Company completed the acquisition of Western Automation for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including electric vehicle charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The business is reported within the Company’s Industrial segment. The Company financed the transaction with cash on hand.

[0000889331-25-000039:mdna:219]
On July 19, 2022, the Company acquired C&K Switches for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, datacom, and aerospace. At the time the Company and C&K entered into a definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the electronics-passive products and sensors business within the Company's Electronics segment. The net cash payment of $523.0 million was funded through a combination of cash on hand and debt.

[0000889331-25-000039:mdna:220]
Cash Flow Overview

[0000889331-25-000039:mdna:221]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes, and other operating activities.

[0000889331-25-000039:mdna:222]
The following describes the Company’s cash flows for the fiscal year ended December 28, 2024 and December 30, 2023:

[0000889331-25-000039:mdna:223]
|  | Fiscal Year |
| (in millions) | 2024 |  | 2023 |
| Net cash provided by operating activities | $ | 367.6 |  |  | $ | 457.4 |  |
| Net cash used in investing activities | (65.8) |  |  | (284.3) |  |
| Net cash used in financing activities | (112.4) |  |  | (185.7) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (20.1) |  |  | 4.8 |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash | 169.3 |  |  | (7.8) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 557.1 |  |  | 564.9 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 726.4 |  |  | $ | 557.1 |  |

[0000889331-25-000039:mdna:224]
Cash Flow from Operating Activities

[0000889331-25-000039:mdna:225]
Net cash provided by operating activities was $367.6 million for the fiscal year 2024, a decrease of $89.8 million, compared to $457.4 million during the fiscal year 2023. The decrease in net cash provided by operating activities was primarily due to lower cash earnings.

[0000889331-25-000039:mdna:226]
Cash Flow from Investing Activities

[0000889331-25-000039:mdna:227]
Net cash used in investing activities was $65.8 million for the fiscal year 2024, compared to $284.3 million during the fiscal year 2023. Net cash paid for acquisitions was $198.8 million for the Western Automation and Dortmund Fab acquisitions during the fiscal year 2023. Capital expenditures were $75.9 million, representing a decrease of $10.3 million compared to the fiscal year 2023. The Company also received proceeds of $10.8 million mainly from the sale of a land use right within the Electronics segment and two buildings from the Transportation segment during the fiscal year 2024 as compared to proceeds of $0.8 million from the sale of a property within the Electronics segment during the fiscal year 2023.

[0000889331-25-000039:mdna:228]
Cash Flow from Financing Activities

[0000889331-25-000039:mdna:229]
Net cash used in financing activities was $112.4 million for the fiscal year 2024 compared to $185.7 million during the fiscal year 2023. During the fiscal year 2024, the Company paid $7.5 million on the term loan. During the fiscal year 2023, the Company paid $121.3 million (€117 million) of Euro Senior Notes, Series A due 2023 and $7.5 million on the term loan. The Company paid dividends of $67.1 million and $62.2 million for the fiscal year 2024 and 2023, respectively, representing an increase of $4.9 million from the fiscal year 2023. Additionally, the Company repurchased 179,311 shares of its common stock totaling $40.9 million during the fiscal year 2024.

[0000889331-25-000039:mdna:230]
The following describes the Company’s cash flows for the fiscal year ended December 30, 2023 and December 31, 2022:

[0000889331-25-000039:mdna:231]
|  | Fiscal Year |
| (in millions) | 2023 |  | 2022 |
| Net cash provided by operating activities | $ | 457.4 |  |  | $ | 419.7 |  |
| Net cash used in investing activities | (284.3) |  |  | (636.4) |  |
| Net cash (used in) provided by financing activities | (185.7) |  |  | 310.2 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 4.8 |  |  | (11.4) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash | (7.8) |  |  | 82.1 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 564.9 |  |  | 482.8 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 557.1 |  |  | $ | 564.9 |  |

[0000889331-25-000039:mdna:232]
Cash Flow from Operating Activities

[0000889331-25-000039:mdna:233]
Net cash provided by operating activities was $457.4 million for the fiscal year 2023, an increase of $37.7 million, compared to $419.7 million during the fiscal year 2022. The increase in net cash provided by operating activities was primarily due to reductions in working capital partially offset by lower cash earnings.

[0000889331-25-000039:mdna:234]
Cash Flow from Investing Activities

[0000889331-25-000039:mdna:235]
Net cash used in investing activities was $284.3 million for the fiscal year 2023, compared to $636.4 million during the fiscal year 2022. Net cash paid for acquisitions was $198.8 million for the Dortmund Fab and Western Automation acquisitions during the fiscal year 2023 versus $532.7 million primarily for the C&K Switches and Embed acquisitions during the fiscal year 2022. Capital expenditures were $86.2 million, representing a decrease of $18.2 million compared to the fiscal year 2022. The Company also received proceeds of $0.8 million primarily from the sale of a property within the Electronics segment during the fiscal year 2023 as compared to proceeds of $0.7 million from the sale of a property within the Transportation segment during the fiscal year 2022.

[0000889331-25-000039:mdna:236]
Cash Flow from Financing Activities

[0000889331-25-000039:mdna:237]
Net cash used in financing activities was $185.7 million for the fiscal year 2023 compared to $310.2 million net cash provided by financing activities for the fiscal year 2022. On July 18, 2022, the Company issued and funded $100 million in aggregate principal amount of 4.33% U.S. Senior Notes, due 2032. On June 30, 2022, the Company amended and restated its Credit Agreement and borrowed $300.0 million through a term loan. During the fiscal year 2023, the Company paid $121.3 million (€117 million) of Euro Senior Notes, Series A due 2023 and $7.5 million on the term loan. During the fiscal year 2022, the Company paid $25.0 million of U.S. Senior Notes, Series A due on February 15, 2022 and $3.8 million on the term loan. Additionally, the Company paid dividends of $62.2 million and $55.9 million for the fiscal year 2023 and 2022, respectively, representing an increase of $6.3 million from the fiscal year 2022.

[0000889331-25-000039:mdna:238]
Contractual Obligations and Commitments

[0000889331-25-000039:mdna:239]
The following table summarizes outstanding contractual obligations and commitments as of December 28, 2024:

[0000889331-25-000039:mdna:240]
|  | Payments Due by Period |
| (in thousands) | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | Greaterthan 5 Years |
| Long-term debt(a) | $ | 858,880 |  |  | $ | 67,612 |  |  | $ | 467,341 |  |  | $ | 98,927 |  |  | $ | 225,000 |  |
| Interest payments(b) | 128,020 |  |  | 37,002 |  |  | 57,910 |  |  | 19,920 |  |  | 13,188 |  |
| Operating and finance lease payments(c) | 93,748 |  |  | 17,547 |  |  | 21,577 |  |  | 18,287 |  |  | 36,337 |  |
| Income tax obligation(d) | 8,192 |  |  | 8,192 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations(e) | 27,749 |  |  | 26,268 |  |  | 1,034 |  |  | 447 |  |  | — |  |
| Total | $ | 1,116,589 |  |  | $ | 156,621 |  |  | $ | 547,862 |  |  | $ | 137,581 |  |  | $ | 274,525 |  |

[0000889331-25-000039:mdna:241]
(a)Excludes offsetting issuance costs of $2.8 million. Euro denominated debt amounts are converted based on the Euro to U.S. Dollar spot rate at year end. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-25-000039:mdna:242]
(b)Amounts represent estimated contractual interest payments on outstanding debt. Rates in effect as of December 28, 2024 are used for variable rate debt. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0000889331-25-000039:mdna:243]
(c)For more information see Note 7, Lease Commitments, of the Notes to Consolidated Financial Statements.

[0000889331-25-000039:mdna:244]
(d)The income tax obligation represents the remaining amounts payable regarding the 2017 Littelfuse Toll Charge. The Company has elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The anticipated 2025 annual installment payment of $8.2 million, which represents the eighth and final required installment, is included in Accrued income taxes, on the Consolidated Balance Sheet as of December 28, 2024. For more information see Note 14, Income Taxes, of the Notes to Consolidated Financial Statements.

[0000889331-25-000039:mdna:245]
(e)Purchase obligations include purchase commitments and commitments for capital expenditures not recognized in the Company’s Consolidated Balance Sheets.

[0000889331-25-000039:mdna:246]
In addition to the above contractual obligations and commitments, the Company had the following obligations at December 28, 2024:

[0000889331-25-000039:mdna:247]
The Company has Company-sponsored defined benefit pension plans covering employees at various non-U.S. subsidiaries including the U.K., Germany, the Philippines, China, Japan, Mexico, Italy, and France. At December 28, 2024, the Company had a net unfunded status of $31.3 million. The Company expects to make approximately $1.2 million of contributions to the plans and pay $2.1 million of benefits directly in 2025. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0000889331-25-000039:mdna:248]
Dividends

[0000889331-25-000039:mdna:249]
Cash dividends paid totaled $67.1 million, $62.2 million and $55.9 million for 2024, 2023 and 2022, respectively. On January 28, 2025, the Board of Directors of the Company declared a quarterly cash dividend of $0.70 per share, payable on March 6, 2025 to stockholders of record as of February 20, 2025.

[0000889331-25-000039:mdna:250]
Capital Resources

[0000889331-25-000039:mdna:251]
The Company expends capital to support its operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0000889331-25-000039:mdna:252]
Share Repurchase Program

[0000889331-25-000039:mdna:253]
The Company's Board of Directors authorized the repurchase of up to $300 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program.

[0000889331-25-000039:mdna:254]
During the fiscal year of 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. There is $298.0 million of an authorized amount not yet purchased under the 2024 program as of December 28, 2024. During the fiscal years of 2023 and 2022, the Company did not repurchase any shares of its common stock.

[0000889331-25-000039:mdna:255]
Off-Balance Sheet Arrangements

[0000889331-25-000039:mdna:256]
As of December 28, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-25-000039:mdna:257]
Recent Accounting Pronouncements

[0000889331-25-000039:mdna:258]
Recently issued accounting standards and their estimated effect on the Company’s Consolidated Financial Statements are described in Note 1, Summary of Significant Accounting Policies and Other Information, of the Notes to Consolidated Financial Statements.
