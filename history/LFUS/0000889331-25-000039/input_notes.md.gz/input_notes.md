# LFUS notes — 0000889331-25-000039


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000889331-25-000039:notes:1]
Portions of the Littelfuse, Inc. Proxy Statement for the 2024 Annual Meeting of Stockholders (the “Proxy Statement”) are incorporated by reference into Part III of this Form 10-K.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000889331-25-000039:notes:2]
The cybersecurity and data protection program at Littelfuse is based on foundational principles outlined in applicable industry and internationally accepted-cybersecurity frameworks. The Company has experienced and will continue to experience cyber-attacks, attempts to breach its systems, and other similar incidents, however we do not believe that the prior cyber incidents have materially affected or are reasonably likely to materially affect the Company. Littelfuse faces risks from cybersecurity threats that could have a material adverse effect on its business, financial condition, results of operations, cash flows, or reputation. Like all cybersecurity programs, there is no guarantee that every attack method and technique has been fully addressed, as these change constantly, but Littelfuse is diligent in its attempts to protect data of the Company and its stakeholders.

[0000889331-25-000039:notes:3]
Littelfuse strives to assess and update its cybersecurity program on a regular basis using an Information Security Management System ("ISMS") comprised of three main elements – 1) independent internationally recognized vendors and technologies for assessments and monitoring, 2) strong internal controls based on industry standards, and 3) Board and Senior Leadership governance and support.
From an external assessment and monitoring perspective, Littelfuse engages third parties to monitor and report on known exploitable vulnerabilities, within and external to Littelfuse’s information technology ("IT") ecosystems.  These third parties provide assessment and vulnerability scanning tools to detect exploitable unauthorized access into the Littelfuse environments.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000889331-25-000039:notes:4]
The Audit Committee of the Board of Directors is tasked with reviewing the Company’s policies and procedures related to cybersecurity risks and incidents. The Company’s Chief Information Officer ("CIO") oversees its cybersecurity program, and regularly provides updates to Littelfuse Senior Leadership and the Audit Committee, as well as the full Board, which include information regarding our cybersecurity program initiatives, insurance coverage, acquisition integration processes, program performance as well as the maturity of the Littelfuse cybersecurity program. These cybersecurity maturity updates are based on cybersecurity maturity reporting and analysis by the Littelfuse internal IT team, as well as reporting provided by independent third parties. The updates help Senior Leadership, the Audit Committee, and the Board to understand the risks the organization faces based on changing cybersecurity threats and on changes to the Littelfuse environment due to factors such as acquisitions and new technology upgrades and improvements. Representatives from Littelfuse’s technology team and other business functions receive regular cybersecurity risk reports and use this information for its decision making in operational improvements as well as budget and resource allocations. The CIO has managed and evolved the cyber security function at Littelfuse for the past five years and is supported by a cyber security leader with over 20 years of Littelfuse experience in IT infrastructure, IT operations, and cybersecurity.

[0000889331-25-000039:notes:5]
The ISMS within Littelfuse consists of internationally recognized program elements that reduce the risk of an operational or cybersecurity incident from significantly impacting Littelfuse and its customers, vendors, and employees. These ISMS elements include but are not limited to:

[0000889331-25-000039:notes:6]
Security Awareness and Training – Littelfuse has an IT security awareness program consisting of training on the fundamentals of information security protection.  These training courses are provided annually.

[0000889331-25-000039:notes:7]
Network Protection – Network protection, detection, and monitoring technologies have been deployed on all external and internal network connections to segment different sections of the business from each other to strengthen key protection capabilities.

[0000889331-25-000039:notes:8]
Identity and Access Management ("IAM") – Littelfuse has implemented user authentication controls on its systems, devices, data, and applications. In addition, multi-factor authentication is implemented for all personnel who remotely access or have privileged account access to Littelfuse systems and networks.

[0000889331-25-000039:notes:9]
Data Classification and Protection – Littelfuse has implemented data loss prevention and classification labels and encryption on its internal unstructured data to prevent unauthorized data loss and data sharing. Structured data in ERP systems and core business systems are encrypted and protected by industry cybersecurity standards and procedures.

[0000889331-25-000039:notes:10]
Endpoint Protection – Littelfuse has implemented anti-virus, malware, and endpoint protection management detection and monitoring solutions on end-user devices and servers. Logs and alerts from these monitoring solutions are routed to independent third-party monitoring vendors that provide 24/7 monitoring, around the world.

[0000889331-25-000039:notes:11]
Threat and Vulnerability Management – Littelfuse uses an internationally recognized managed security services provider ("MSSP") and technologies to collect security alert and audit logs on a 24/7 basis, monitor and assess latest threat intelligence, provide analysis on new identified potential vulnerabilities, and provide response and support services to rapidly reduce any identified vulnerabilities.

[0000889331-25-000039:notes:12]
Security Incident Management – Security incident response plans and procedures have been developed in collaboration with our MSSP. They allow us to assess potential threats, first and second level notification and response protocols, and supporting notification protocols – both internally and externally. These plans, procedures, and protocols are tested and updated on a regular basis.

[0000889331-25-000039:notes:13]
Resiliency and Contingency Planning – Risk assessments are performed on a regular basis to assess the IT risk of single points of failure, security maturity, and security vulnerabilities. The results of these assessments are used to define various resiliency and contingency mitigation strategies, corrective action plans, on-site and remote data back-up strategies and technologies and allocation of IT resources.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000889331-25-000039:notes:14]
Summary of Significant Accounting Policies and Other Information

[0000889331-25-000039:notes:15]
Nature of Operations

[0000889331-25-000039:notes:16]
Littelfuse, Inc. and subsidiaries (the “Company”) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 16,000 global associates, the Company partners with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, the Company’s products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day.

[0000889331-25-000039:notes:17]
Fiscal Year

[0000889331-25-000039:notes:18]
References herein to “2024”, “fiscal 2024” or “fiscal year 2024” refer to the fiscal year ended December 28, 2024. References herein to “2023”, “fiscal 2023” or “fiscal year 2023” refer to the fiscal year ended December 30, 2023. References herein to “2022”, “fiscal 2022” or “fiscal year 2022” refer to the fiscal year ended December 31, 2022. The Company operates on a 52-53 week fiscal year (4-4-5 basis) ending on the Saturday closest to December 31.

[0000889331-25-000039:notes:19]
Basis of Presentation

[0000889331-25-000039:notes:20]
The Consolidated Financial Statements include the accounts of Littelfuse, Inc. and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The Company’s Consolidated Financial Statements were prepared in accordance with generally accepted accounting principles in the United States of America ("U.S.") and include the assets, liabilities, sales and expenses of all wholly owned subsidiaries and majority-owned subsidiaries over which the Company exercises control.

[0000889331-25-000039:notes:21]
Out-of-Period Adjustments

[0000889331-25-000039:notes:22]
During the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that have now been corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The error was identified by management and related to the valuation and existence of inventory that originated in prior periods at certain of our non-U.S. manufacturing locations within the Transportation and Industrial segments. As a result, the Company recorded an out-of-period adjustment to the prior years of $12.3 million in the year ended December 28, 2024. The adjustment increased cost of sales, offset by a reduction in inventory. The out-of-period adjustment resulted in a decrease to net income of $12.3 million. The Company evaluated the impact of the error and out-of-period adjustment and concluded it was not material to any previously issued financial statements and the adjustment was not material to the year ended December 28, 2024.

[0000889331-25-000039:notes:23]
Use of Estimates

[0000889331-25-000039:notes:24]
The process of preparing financial statements in conformity with generally accepted accounting principles in the U.S. requires management to make estimates and assumptions that affect the amounts of assets and liabilities at the date of the Consolidated Financial Statements, and the reported amounts of revenues and expenses and the accompanying notes. The Company evaluates and updates its assumptions and estimates on an ongoing basis and may employ outside experts to assist in its evaluation, as considered necessary. Actual results could differ from those estimates.

[0000889331-25-000039:notes:25]
Cash, Cash Equivalents and Restricted Cash

[0000889331-25-000039:notes:26]
All highly liquid investments, with an original maturity of three months or less when purchased, are considered to be cash equivalents. The Company maintains several pools including multicurrency notional pools and physical pools internationally and a zero-balance account ("ZBA") structure in the U.S. In the notional pools, actual cash balances are not physically converted and are not commingled between participating legal entities. The Company will classify any overdraft balances within accrued expenses and other current liabilities on the Consolidated Balance Sheets.

[0000889331-25-000039:notes:27]
The following table provides a reconciliation of cash, cash equivalents and restricted cash at December 28, 2024 and December 30, 2023 reported within the Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Consolidated Statement of Cash Flows.

[0000889331-25-000039:notes:28]
|  |  | Fiscal Year Ended |
| (in millions) |  | 2024 |  | 2023 |
| Cash and cash equivalents |  | $ | 724,924 |  |  | $ | 555,513 |  |
| Restricted cash included in other assets |  | 1,513 |  |  | 1,610 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 726,437 |  |  | $ | 557,123 |  |

[0000889331-25-000039:notes:29]
Short-Term and Long-Term Investments

[0000889331-25-000039:notes:30]
As of December 28, 2024, the Company has an investment in Polytronics Technology Corporation Ltd. (“Polytronics”). The Company’s Polytronics shares held at the end of fiscal 2024 and 2023 represent approximately 6.7% of total Polytronics shares outstanding for both years. The Polytronics investment is carried at fair value. The fair value of the Polytronics investment was €9.8 million (approximately $10.2 million) at December 28, 2024 and €9.7 million (approximately $10.8 million) at December 30, 2023.

[0000889331-25-000039:notes:31]
As a result of the Company’s acquisition of IXYS Corporation ("IXYS"), the Company has equity ownerships in various investments that are accounted for under the equity method. The Company owns 45% of the outstanding equity of Powersem GmbH, a module manufacturer based in Germany, approximately 15% of the outstanding equity of EB-Tech Co., Ltd., a company with expertise in radiation technology based in South Korea, and approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc., a supplier located in the Philippines that provides assembly and test services. The Company recognized a loss of $0.6 million and a gain $0.5 million from its equity method investments for both the fiscal years ended December 28, 2024 and December 30, 2023, respectively, recorded in Other (income) expense, net, in the Consolidated Statements of Net Income. The balance of these equity method investments was $13.1 million and $14.0 million as of the fiscal years ended December 28, 2024 and December 30, 2023, respectively. See Note 18, Related Party Transactions, for further discussion.

[0000889331-25-000039:notes:32]
The Company has investments related to its non-qualified Supplemental Retirement and Savings Plan. The Company maintains accounts for participants through which participants make investment elections. The investment securities are subject to the claims of the Company’s creditors. The investment securities are all mutual funds. The investment securities are measured at net asset value. As of December 28, 2024 and December 30, 2023, the investment securities balance was $23.3 million and $20.1 million, respectively, related to the plan and are included in Other long-term assets on the Consolidated Balance Sheets.

[0000889331-25-000039:notes:33]
Trade Receivables

[0000889331-25-000039:notes:34]
The Company performs credit evaluations of customers’ financial condition and generally does not require collateral. A receivable is considered past due if payments have not been received within agreed upon invoice terms. Write-offs are recorded at the time a customer receivable is deemed uncollectible.

[0000889331-25-000039:notes:35]
The Company also maintains allowances against trade receivables for the settlement of rebates and sales discounts to customers. These allowances are based upon specific customer sales and sales discounts as well as actual historical experience.

[0000889331-25-000039:notes:36]
Inventories

[0000889331-25-000039:notes:37]
Inventories are stated at the lower of cost or net realizable value, which approximates current replacement cost. Cost is principally determined using the first-in, first-out method. The Company maintains excess and obsolete reserves against inventory to reduce the carrying value to the expected net realizable value. These reserves are based upon a combination of factors including historical sales volume, market conditions, and lower of cost or net realizable value of the inventory.

[0000889331-25-000039:notes:38]
Property, Plant, and Equipment

[0000889331-25-000039:notes:39]
Land, buildings, and equipment are carried at cost. Depreciation is calculated using the straight-line method with useful lives of up to 35 years for buildings, three to 20 years for equipment, seven years for furniture and fixtures, five years for tooling, and three years for computer equipment. Leasehold improvements are depreciated over the lesser of their useful life or the lease term. Maintenance and repair costs are charged to expense as incurred. Major overhauls that extend the useful lives of existing assets are capitalized.

[0000889331-25-000039:notes:40]
Goodwill

[0000889331-25-000039:notes:41]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value.

[0000889331-25-000039:notes:42]
The results of the goodwill impairment test as of September 29, 2024 indicated that the estimated fair values for the Industrial controls and sensors and Automotive sensors reporting units were below their respective carrying values. Accordingly, the Company recorded non-cash impairment charges of $36.1 million and $8.6 million, respectively, to reflect the impairment of goodwill for the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment. As a result of these impairment charges, the Industrial controls and sensors reporting unit had $115.2 million of goodwill as of December 28, 2024. There was no goodwill remaining within the Automotive sensors reporting unit as of December 28, 2024. For the remainder of the Company's reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, and Industrial Circuit Protection, the results of the goodwill impairment test as of September 29, 2024 indicated that their estimated fair values exceeded their respective carrying values.

[0000889331-25-000039:notes:43]
The Company compares each reporting unit’s fair value, estimated based on comparable company market valuations and expected future discounted cash flows to be generated by the reporting unit, to its carrying value. With the exception of the Industrial controls and sensors and the Automotive sensors reporting units, the other five reporting units passed the most recent annual test conducted on September 29, 2024 with estimated fair values that exceeded the carrying values by 108%, 82%, 96%, 44%, and 409% for its reporting units: Electronics-Passive Products and Sensors, Electronics-Semiconductor, Passenger Car Products, Commercial Vehicle Products, and Industrial Circuit Protection, respectively. Relatively small changes in the Company’s key assumptions would not have resulted in any reporting units failing the goodwill impairment test. See Note 5, Goodwill and Other Intangible Assets, for additional information.

[0000889331-25-000039:notes:44]
There were no impairment charges recorded during the fiscal years of 2023 and 2022.

[0000889331-25-000039:notes:45]
The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events. Based on the interim assessments as of December 28, 2024, management concluded that no events or changes in circumstances indicated that it was more likely than not that the fair value for any reporting unit had declined below its carrying value.

[0000889331-25-000039:notes:46]
Long-Lived Assets

[0000889331-25-000039:notes:47]
During the fourth quarter of  2024, the Company recorded non-cash impairment charges of $47.8 million for the impairment of intangible assets, including $47.6 million related to the impairment of certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment. The impairment of the intangible assets resulted from lower expectations of future revenue and cash flows driven by lower-than-expected demand in the electrical vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe. The fair value was determined using Level 3 inputs and estimated based on cash flow analyses, which included management’s assumptions related to future revenues and profitability. The remaining impairment charges included $0.2 million for patents and customer relationships related to exit of a small business in China within the Industrial segment. See Note 5, Goodwill and Other Intangible Assets for additional information. Additionally, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-25-000039:notes:48]
Customer relationships, trademarks and tradenames are amortized using the straight-line method over estimated useful lives that have a range of 3 to 20 years. Patents, licenses, and software are amortized using the straight-line method or an accelerated method over estimated useful lives that have a range of 4 to 17 years. The distribution networks are amortized on either a straight-line or accelerated basis over estimated useful lives that have a range of 4 to 10 years. Land use rights are amortized using the straight-line method up to 50 years which is the term of the land use rights.

[0000889331-25-000039:notes:49]
The Company assesses potential impairments to its long-lived assets if events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. An impaired asset is written down to its estimated fair value based upon the most recent information available. Estimated fair market value is generally measured by discounting estimated future cash flows. Long-lived assets, other than goodwill and other intangible assets, which are held for sale are recorded at the lower of carrying value or the fair market value less the estimated cost to sell.

[0000889331-25-000039:notes:50]
Environmental Liabilities

[0000889331-25-000039:notes:51]
Environmental liabilities are accrued based on engineering studies estimating the cost of remediating sites. Expenses related to on-going maintenance of environmental sites are expensed as incurred. If actual or estimated probable future losses exceed the Company’s recorded liability for such claims, the Company would record additional charges during the period in which the actual loss or change in estimate occurred.

[0000889331-25-000039:notes:52]
Pension and Other Post-retirement Benefits

[0000889331-25-000039:notes:53]
The Company records annual income and expense amounts relating to its pension and post-retirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets, but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive loss. The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors.

[0000889331-25-000039:notes:54]
Revenue Recognition

[0000889331-25-000039:notes:55]
Revenue Disaggregation

[0000889331-25-000039:notes:56]
The following table disaggregates the Company’s revenue by primary business units for the fiscal years ended December 28, 2024, December 30, 2023, and December 31, 2022:

[0000889331-25-000039:notes:57]
|  |  | Fiscal Year Ended December 28, 2024 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 615,372 |  |  | $ | — |  |  | $ | — |  |  | $ | 615,372 |  |
| Electronics – Passive Products and Sensors |  | 571,401 |  |  | — |  |  | — |  |  | 571,401 |  |
| Commercial Vehicle Products |  | — |  |  | 320,549 |  |  | — |  |  | 320,549 |  |
| Passenger Car Products |  | — |  |  | 278,332 |  |  | — |  |  | 278,332 |  |
| Automotive Sensors |  | — |  |  | 73,553 |  |  | — |  |  | 73,553 |  |
| Industrial Products |  | — |  |  | — |  |  | 331,561 |  |  | 331,561 |  |
| Total |  | $ | 1,186,773 |  |  | $ | 672,434 |  |  | $ | 331,561 |  |  | $ | 2,190,768 |  |

[0000889331-25-000039:notes:58]
|  |  | Fiscal Year Ended December 30, 2023 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 767,393 |  |  | $ | — |  |  | $ | — |  |  | $ | 767,393 |  |
| Electronics – Passive Products and Sensors |  | 583,033 |  |  | — |  |  | — |  |  | 583,033 |  |
| Commercial Vehicle Products |  | — |  |  | 323,758 |  |  | — |  |  | 323,758 |  |
| Passenger Car Products |  | — |  |  | 266,004 |  |  | — |  |  | 266,004 |  |
| Automotive Sensors |  | — |  |  | 88,516 |  |  | — |  |  | 88,516 |  |
| Industrial Products |  | — |  |  | — |  |  | 333,953 |  |  | 333,953 |  |
| Total |  | $ | 1,350,426 |  |  | $ | 678,278 |  |  | $ | 333,953 |  |  | $ | 2,362,657 |  |

[0000889331-25-000039:notes:59]
|  |  | Fiscal Year Ended December 31, 2022 |
| (in thousands) |  | ElectronicsSegment |  | Transportation Segment |  | IndustrialSegment |  | Total |
| Electronics – Semiconductor |  | $ | 802,281 |  |  | $ | — |  |  | $ | — |  |  | $ | 802,281 |  |
| Electronics – Passive Products and Sensors |  | 690,538 |  |  | — |  |  | — |  |  | 690,538 |  |
| Commercial Vehicle Products |  | — |  |  | 374,707 |  |  | — |  |  | 374,707 |  |
| Passenger Car Products |  | — |  |  | 249,470 |  |  | — |  |  | 249,470 |  |
| Automotive Sensors |  | — |  |  | 91,963 |  |  | — |  |  | 91,963 |  |
| Industrial Products |  | — |  |  | — |  |  | 304,938 |  |  | 304,938 |  |
| Total |  | $ | 1,492,819 |  |  | $ | 716,140 |  |  | $ | 304,938 |  |  | $ | 2,513,897 |  |

[0000889331-25-000039:notes:60]
See Note 16, Segment Information, for net sales by segment and country.

[0000889331-25-000039:notes:61]
The Company recognizes revenue on product sales in the period in which the Company satisfies its performance obligation and control of the product is transferred to the customer. The Company’s sales arrangements with customers are predominately short term in nature and generally provide for transfer of control at the time of shipment as this is the point at which title and risk of loss of the product transfers to the customer. At the end of each period, for those shipments where title to the products and the risk of loss and rewards of ownership do not transfer until the product has been received by the customer, the Company adjusts revenues and cost of sales for the delay between the time that the products are shipped and when they are received by the customer. The amount of revenue recorded reflects the consideration to which the Company expects to be entitled in exchange for goods and may include adjustments for customer allowance, rebates, and price adjustments. The Company’s distribution channels are primarily through direct sales and independent third-party distributors.

[0000889331-25-000039:notes:62]
The Company has elected the practical expedient under ASC 340-40-25-4 to expense commissions when incurred as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0000889331-25-000039:notes:63]
Revenue and Billing

[0000889331-25-000039:notes:64]
The Company generally accepts orders from customers through receipt of purchase orders or electronic data interchange based on written sales agreements and purchasing contracts. Contract pricing and selling agreement terms are based on market factors, costs, and competition. Pricing is often negotiated as an adjustment (premium or discount) from the Company’s published price lists. The customer is invoiced when the Company’s products are shipped to them in accordance with the terms of the sales agreement. As the Company’s standard payment terms are less than one year, the Company has elected the practical expedient under ASC 606-10-32-18 to not assess whether a contract has a significant financing component. The Company also elected the practical expedient provided in ASC 606-10-25-18B to treat all product shipping and handling activities as fulfillment activities, and therefore recognize the gross revenue associated with the contract, inclusive of any shipping and handling revenue.

[0000889331-25-000039:notes:65]
Ship and Debit Program

[0000889331-25-000039:notes:66]
Some of the terms of the Company’s sales agreements and normal business conditions provide customers (distributors) the ability to receive price adjustments on products previously shipped and invoiced. This practice is common in the industry and is referred to as a “ship and debit” program. This program allows the distributors to debit the Company for the difference between the distributors’ contracted price and a lower price for specific transactions. Under certain circumstances (usually in a competitive situation or large volume opportunity), a distributor will request authorization for pricing allowances to reduce its price. When the Company approves such a reduction, the distributor is authorized to “debit” its account for the difference between the contracted price and the lower approved price. The Company establishes reserves for this program based on historic activity, distributor inventory levels and actual authorizations for the debit and recognizes these debits as a reduction of revenue.

[0000889331-25-000039:notes:67]
Return to Stock

[0000889331-25-000039:notes:68]
The Company has a return to stock policy whereby certain customers, with prior authorization from the Company's management, can return previously purchased goods for full or partial credit. The Company establishes an estimated allowance for these returns based on historic activity. Sales revenue and cost of sales are reduced to anticipate estimated returns.

[0000889331-25-000039:notes:69]
Volume Rebates

[0000889331-25-000039:notes:70]
The Company offers volume-based sales incentives to certain customers to encourage greater product sales. If customers achieve their specific quarterly or annual sales targets, they are entitled to rebates. The Company estimates the projected amount of rebates that will be achieved by the customer and recognizes this estimated cost as a reduction to revenue as products are sold.

[0000889331-25-000039:notes:71]
Allowance for Credit Losses

[0000889331-25-000039:notes:72]
The Company currently measures the expected credit losses based on our historical credit loss experience. The Company has not experienced significant recent or historical credit losses and is not forecasting any significant credit losses which would require adjustments to our methodology. If current conditions and supportable forecasts indicate that our historical loss experience is not reasonable and no longer supportable, the Company may adjust its historical credit loss experience and to reflect these conditions and forecasts. The Company regularly analyzes its significant customer accounts and, when the Company becomes aware of a customer’s inability to meet its financial obligations, the Company records a specific reserve for bad debt to reduce the related receivable to the amount the Company reasonably believes is collectible. The Company also analyzes all other customers based on a variety of factors including the length of time the receivables are past due, the financial health of the customer, macroeconomic considerations and historical collection and loss experience. Historically, the allowance for credit losses has been adequate to cover bad debts. If circumstances related to specific customers change, the estimates of the recoverability of receivables could be further adjusted.

[0000889331-25-000039:notes:73]
As of December 28, 2024 and December 30, 2023, the Company’s allowance for credit losses was $1.6 million and $2.2 million, respectively. Additionally, the Company had $3.8 million and $5.4 million of trade receivables greater than 90 days past due as of December 28, 2024 and December 30, 2023, respectively.

[0000889331-25-000039:notes:74]
Advertising Costs

[0000889331-25-000039:notes:75]
The Company expenses advertising costs as incurred, which amounted to $5.0 million, $4.0 million, and $3.8 million in fiscal years 2024, 2023 and 2022, respectively, and are included as a component of selling, general, and administrative expenses.

[0000889331-25-000039:notes:76]
Shipping and Handling Fees and Costs

[0000889331-25-000039:notes:77]
Amounts billed to customers related to shipping and handling are classified as revenue. Costs incurred for shipping and handling of $15.3 million, $15.4 million, and $13.9 million in fiscal years 2024, 2023, and 2022, respectively, are classified in selling, general, and administrative expenses.

[0000889331-25-000039:notes:78]
Foreign Currency Translation / Remeasurement

[0000889331-25-000039:notes:79]
The Company’s foreign subsidiaries use the local currency or the U.S. dollar as their functional currency, as appropriate. Assets and liabilities are translated using exchange rates at the balance sheet date, and revenues and expenses are translated at weighted average rates. Adjustments from the translation process are recognized in Shareholders’ equity as a component of Accumulated other comprehensive income (loss). The amount of foreign currency (gain) or loss recognized in the Consolidated Statements of Net Income were (gain) loss of $(9.2) million, $12.3 million, and $24.4 million in fiscal years 2024, 2023 and 2022, respectively.

[0000889331-25-000039:notes:80]
Stock-Based Compensation

[0000889331-25-000039:notes:81]
The Company recognizes compensation expense for the cost of awards of equity compensation using a fair value method. Benefits of tax deductions in excess of recognized compensation expense are reported as operating cash flows. See Note 12, Stock-Based Compensation, for additional information on stock-based compensation.

[0000889331-25-000039:notes:82]
Coal Mining Liability

[0000889331-25-000039:notes:83]
Included in accrued liabilities is an accrual related to former coal mining operations at Littelfuse GmbH (formerly known as Heinrich Industries, AG) for the amounts of €2.2 million ($2.3 million) and €2.5 million ($2.7 million) at December 28, 2024 and December 30, 2023, respectively. Management, in conjunction with an independent third-party, performs an annual evaluation of the former coal mining operations in order to develop an estimate of the probable future obligations in regard to remediating the dangers (such as a shaft collapse) of abandoned coal mine shafts in the former coal mining operations. Management accrues for costs associated with such remediation efforts based on management's best estimate when such costs

[0000889331-25-000039:notes:84]
are probable and reasonably able to be estimated. The ultimate determination can only be done after respective investigations because the concrete conditions are mostly unknown at this time.

[0000889331-25-000039:notes:85]
Other (Income) Expense, Net

[0000889331-25-000039:notes:86]
Other (income) expense, net generally consists of interest income, royalties, change in fair value of available-for-sale securities, pension non-service costs and settlements and other non-operating (income) expense. The amount of interest income included in Other (income) expense, net, was $28.0 million, $18.9 million, and $5.0 million in fiscal years 2024, 2023 and 2022, respectively.

[0000889331-25-000039:notes:87]
Income Taxes

[0000889331-25-000039:notes:88]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using enacted tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards, and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0000889331-25-000039:notes:89]
Deferred U.S. income taxes and non-U.S. taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0000889331-25-000039:notes:90]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0000889331-25-000039:notes:91]
The 2017 Tax Cuts and Jobs Act (the "Tax Act"), among other things, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and included base broadening provisions commonly referred to as the global intangible low-taxed income provisions ("GILTI").

[0000889331-25-000039:notes:92]
The Company elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The anticipated 2025 annual installment payment of this Toll Charge of $8.2 million, which represents the eighth and final required installment, is included in Accrued income taxes, on the Consolidated Balance Sheets as of December 28, 2024.

[0000889331-25-000039:notes:93]
In accordance with guidance issued by the FASB staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 28, 2024, December 30, 2023, and December 31, 2022, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0000889331-25-000039:notes:94]
Fair Value Measurements

[0000889331-25-000039:notes:95]
Certain assets and liabilities are required to be recorded at fair value on a recurring basis. Fair value is determined based on the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants. The Company records the fair value of its available-for-sale securities and pension plan assets on a recurring basis. Assets measured at fair value on a nonrecurring basis include long-lived assets held and used, long-lived assets held for sale, goodwill, and other intangible assets. The fair value of cash and cash equivalents, short-term investments, accounts receivable, accounts payable, and accrued liabilities approximate their carrying values. The three-tier value hierarchy, which prioritizes valuation methodologies based on the reliability of the inputs, is:

[0000889331-25-000039:notes:96]
Level 1 – Valuations based on unadjusted quoted prices for identical assets and liabilities in active markets.

[0000889331-25-000039:notes:97]
Level 2 – Valuations based on observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data.

[0000889331-25-000039:notes:98]
Level 3 – Valuations based on unobservable inputs reflecting the Company’s own assumptions, consistent with reasonably available assumptions made by other market participants.

[0000889331-25-000039:notes:99]
Recently Adopted Accounting Standards

[0000889331-25-000039:notes:100]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Updates ("ASU") No. 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures." The amendments in this update require additional detailed and enhanced information about reportable segments' expense, including significant segment expenses and other segment items that bridge segment revenue, significant expenses to segment profit or loss. The ASU also requires disclosure of the title and position of the Chief Operating Decision Maker (“CODM”) on an annual basis as well as an explanation of how the CODM uses the reported measures and other disclosures. The amendments in this update do not change how a public entity identifies its operating segments, aggregates those operating segments, or applies the quantitative thresholds to determine its reportable segments. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The adoption of ASU 2023-07 modified the Company's disclosures in its Consolidated Financial Statements. See Note 16, Segment Information, for more details.

[0000889331-25-000039:notes:101]
In March 2023, the FASB issued ASU No. 2023-01, "Leases (Topic 842): Common Control Arrangements." The standard requires that leasehold improvements associated with common control leases be: 1) Amortized by the lessee over the useful life of the leasehold improvements to the common control group (regardless of the lease term) as long as the lessee controls the use of the underlying asset (the leased asset) through a lease. However, if the lessor obtained the right to control the use of the underlying asset through a lease with another entity not within the same common control group, the amortization period may not exceed the amortization period of the common control group. 2) Accounted for as a transfer between entities under common control through an adjustment to equity (or net assets for not-for-profit entities) if, and when, the lessee no longer controls the use of the underlying asset. Additionally, those leasehold improvements are subject to the impairment guidance in Topic 360, Property, Plant, and Equipment. This standard is effective for fiscal years beginning after December 15, 2023 including interim periods within those fiscal years. The adoption of ASU 2023-01 did not have a material impact on the Company's Consolidated Financial Statements.

[0000889331-25-000039:notes:102]
Recently Issued Accounting Standards

[0000889331-25-000039:notes:103]
In November 2024, the FASB issued ASU No. 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40)." The amendments in this update require disclosure, in the notes to financial statements, of specified information about certain costs and expenses. The amendments require that at each interim and annual reporting period an entity (a) disclose the amounts of (i) purchases of inventory, (ii) employee compensation, (iii) depreciation, (iv) intangible asset amortization, and (v) depreciation, depletion, and amortization recognized as part of oil and gas producing activities ("DD&A") included in each relevant expense caption. A relevant expense caption is an expense caption presented on the face of the income statement within continuing operations that contains any of the expense categories listed in (i)–(v); (b) include certain amounts that are already required to be disclosed under current Generally Accepted Accounting Principles ("GAAP") in the same disclosure as the other disaggregation requirements; (c) disclose a qualitative description of the amounts remaining in relevant expense captions that are not separately disaggregated quantitatively; (d) disclose the total amount of selling expenses and, in annual reporting periods, an entity’s definition of selling expenses. The guidance is effective for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The adoption of this guidance will increase the Company's disclosures in its Consolidated Financial Statements. The Company is currently evaluating the potential impact on the disclosures in the Company's Consolidated Financial Statements.

[0000889331-25-000039:notes:104]
In December 2023, the FASB issued ASU No. 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." The amendments in this update provide more transparency about income tax information through improvements to the income tax disclosure primarily related to the income tax rate reconciliation and income taxes paid information. These requirements include: (1) consistent categories and greater disaggregation of information in the rate reconciliation and (2) income taxes paid disaggregated by jurisdiction. The other amendments in this update improve the effectiveness and comparability of disclosures by (3) adding disclosures of pretax income (or loss) and income tax expense (or benefit), and (4) removing disclosures that are no longer considered cost beneficial or relevant. The guidance is effective for fiscal years beginning after December 15, 2024 with early adoption permitted. The adoption of this guidance will modify our disclosures in the Company's Consolidated Financial Statements.

[0000889331-25-000039:notes:105]
In October 2023, the FASB issued ASU No. 2023-06, "Disclosure Improvements." The amendments in this update represent changes to clarify or improve the disclosure or presentation requirements of a variety of Topics in the ASC. The Company may be affected by one or more of those amendments. The amendments in this ASU should be applied prospectively and will not be effective until June 30, 2027. The Company is currently evaluating the potential effects of these amendments on its Consolidated Financial Statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000889331-25-000039:notes:106]
Acquisitions

[0000889331-25-000039:notes:107]
The Company accounts for acquisitions using the acquisition method in accordance with ASC 805, “Business Combinations,” in which assets acquired and liabilities assumed are recorded at fair value as of the date of acquisition. The operating results of the acquired businesses are included in the Company’s Consolidated Financial Statements from the date of the acquisition.

[0000889331-25-000039:notes:108]
Dortmund Fab

[0000889331-25-000039:notes:109]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab is approximately 94 million Euro, of which a 37.2 million Euro down payment (approximately $40.5 million) was recorded in Prepaid expenses and other current assets in the Consolidated Balance Sheets. The down payment was paid in the third quarter of 2023 after regulatory approvals, and 56.7 million Euro was paid at closing. The transaction did not have any impact on the Company's 2024 financial results and reported in the Electronics-Semiconductor business within the Company’s Electronics segment. The acquisition was funded with the Company’s cash on hand. The acquisition will be accounted for under the acquisition method of accounting. The required disclosures have not been provided as the initial accounting for the business combination was not complete prior to the issuance of these financial statements

[0000889331-25-000039:notes:110]
Western Automation

[0000889331-25-000039:notes:111]
On February 3, 2023, the Company completed the acquisition of Western Automation Research and Development Limited (“Western Automation”) for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including electric vehicle charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The

[0000889331-25-000039:notes:112]
business is reported within the Company’s Industrial segment.

[0000889331-25-000039:notes:113]
The acquisition was funded with cash on hand. The total purchase consideration of $158.3 million, net of cash, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0000889331-25-000039:notes:114]
The following table summarizes the final purchase price allocation of the fair value of assets acquired and liabilities assumed in the Western Automation acquisition:

[0000889331-25-000039:notes:115]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 158,260 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 3,359 |  |
| Inventories | 3,678 |  |
| Other current assets | 718 |  |
| Property, plant, and equipment | 1,328 |  |
| Intangible assets | 68,000 |  |
| Goodwill | 93,937 |  |
| Other long-term assets | 573 |  |
| Current liabilities | (4,335) |  |
| Other long-term liabilities | (8,998) |  |
|  | $ | 158,260 |  |

[0000889331-25-000039:notes:116]
All Western Automation assets and liabilities were recorded in the Industrial segment and are primarily reflected in the Europe geographic area. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales

[0000889331-25-000039:notes:117]
and synergies from combining Western Automation’s products and technology with the Company’s existing Industrial products portfolio. Goodwill resulting from the Western Automation acquisition is not expected to be deductible for tax purposes.

[0000889331-25-000039:notes:118]
For the fiscal year ended December 30, 2023, the Company incurred $1.2 million of legal and professional fees related to the Western Automation acquisition recognized as Selling, general, and administrative expenses and reflected as other non-segment costs.

[0000889331-25-000039:notes:119]
C&K Switches

[0000889331-25-000039:notes:120]
On July 19, 2022, the Company acquired C&K Switches (“C&K”) for $540 million in cash. Founded in 1928, C&K is a leading designer and manufacturer of high-performance electromechanical switches and interconnect solutions with a strong global presence across a broad range of end markets, including industrial, transportation, datacom, and aerospace. At the time the Company and C&K entered into a definitive agreement, C&K had annualized sales of over $200 million. The business is reported as part of the electronics-passive products and sensors business within the Company's Electronics segment.

[0000889331-25-000039:notes:121]
The acquisition was funded through a combination of cash on hand and debt. The total purchase consideration of $523.0 million, net of cash acquired, has been allocated to assets acquired and liabilities assumed, as of the completion of the acquisition, based on estimated fair values.

[0000889331-25-000039:notes:122]
The following table summarizes the purchase price allocation of the fair value of assets acquired and liabilities assumed in the C&K acquisition:

[0000889331-25-000039:notes:123]
| (in thousands) | Purchase PriceAllocation |
| Total purchase consideration: |  |
| Cash, net of cash acquired | $ | 523,014 |  |
| Allocation of consideration to assets acquired and liabilities assumed: |  |
| Trade receivables, net | 20,967 |  |
| Inventories | 42,968 |  |
| Other current assets | 2,932 |  |
| Property, plant, and equipment | 32,791 |  |
| Intangible assets | 254,700 |  |
| Goodwill | 274,124 |  |
| Other long-term assets | 14,797 |  |
| Current liabilities | (47,687) |  |
| Long-term debt | (9,626) |  |
| Other long-term liabilities | (62,952) |  |
|  | $ | 523,014 |  |

[0000889331-25-000039:notes:124]
All C&K goodwill, other assets and liabilities were recorded in the Electronics segment and are reflected in the Americas, Europe and Asia-Pacific geographic areas. The goodwill resulting from this acquisition consists largely of the Company’s expected future product sales and synergies from combining C&K’s products and technology with the Company’s existing Electronics products portfolio. Goodwill resulting from the C&K acquisition is not expected to be deductible for tax purposes.

[0000889331-25-000039:notes:125]
As required by purchase accounting rules, the Company recorded a $10.8 million step-up of inventory to its fair value as of the acquisition date. The step-up was amortized as a non-cash charge to cost of sales during the third and fourth quarter of 2022 as the acquired inventory was sold and reflected as other non-segment costs.

[0000889331-25-000039:notes:126]
For the fiscal year ended December 31, 2022, the Company incurred $9.1 million of legal and professional fees related to the C&K acquisition recognized as Selling, general, and administrative expenses and reflected as other non-segment costs.

[0000889331-25-000039:notes:127]
Pro Forma Results

[0000889331-25-000039:notes:128]
The following table summarizes, on an unaudited pro forma basis, the combined results of operations of the Company and Western Automation as though the acquisition had occurred as of January 2, 2022, and C&K as though the acquisition had occurred as of December 27, 2020. The pro forma amounts presented are not necessarily indicative of either the actual

[0000889331-25-000039:notes:129]
consolidated results had the Western Automation acquisition occurred as of January 2, 2022, and had C&K acquisition occurred as of December 27, 2020 or of future consolidated operating results.

[0000889331-25-000039:notes:130]
|  |  | For the Fiscal Year Ended |
| (in thousands, except per share amounts) |  | December 30, 2023 |  | December 31, 2022 |
| Net sales |  | $ | 2,364,543 |  |  | $ | 2,665,028 |  |
| Income before income taxes |  | 330,114 |  |  | 486,285 |  |
| Net income |  | 260,812 |  |  | 402,470 |  |
| Net income per share — basic |  | 10.49 |  |  | 16.27 |  |
| Net income per share — diluted |  | 10.39 |  |  | 16.11 |  |

[0000889331-25-000039:notes:131]
Pro forma results presented above primarily reflect the following adjustments:

[0000889331-25-000039:notes:132]
|  |  |  |  | For the Fiscal Year Ended |
| (in thousands) |  |  |  | December 30, 2023 |  | December 31, 2022 |
| Amortization (a) |  |  |  | $ | (479) |  |  | $ | (10,388) |  |
| Depreciation |  |  |  | — |  |  | 1,979 |  |
| Transaction costs (b) |  |  |  | 1,203 |  |  | 7,905 |  |
| Amortization of inventory step-up (c) |  |  |  | — |  |  | 15,593 |  |
| Interest expense (d) |  |  |  | — |  |  | 815 |  |
| Income tax (expense) benefit of above items |  |  |  | (91) |  |  | (4,701) |  |

[0000889331-25-000039:notes:133]
(a)The amortization adjustment for the twelve months ended December 30, 2023 and December 31, 2022, primarily reflects incremental amortization resulting from the measurement of intangibles at their fair values.

[0000889331-25-000039:notes:134]
(b)The transaction cost adjustments reflect the reversal of certain legal and professional fees from the twelve months ended December 30, 2023 and December 31, 2022, respectively, and recognition of those fees during the twelve months ended December 31, 2022.

[0000889331-25-000039:notes:135]
(c)The amortization of inventory step-up adjustment reflects the reversal of the amount recognized during the twelve months ended December 31, 2022. The inventory step-up is amortized over four months for all acquisitions, as the inventory was sold.

[0000889331-25-000039:notes:136]
(d)The interest expense adjustment reflects lower interest expense associated with the financing of the C&K acquisition that replaced higher pre-acquisition debt.


## us-gaap:InventoryDisclosureTextBlock

[0000889331-25-000039:notes:137]
The components of inventories at December 28, 2024 and December 30, 2023 are as follows:

[0000889331-25-000039:notes:138]
| (in thousands) | 2024 |  | 2023 |
| Raw materials | $ | 193,788 |  |  | $ | 201,984 |  |
| Work in process | 115,497 |  |  | 137,688 |  |
| Finished goods | 173,513 |  |  | 195,886 |  |
| Inventory reserves | (66,525) |  |  | (60,951) |  |
| Total | $ | 416,273 |  |  | $ | 474,607 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000889331-25-000039:notes:139]
Property, Plant, and Equipment, net

[0000889331-25-000039:notes:140]
The components of net property, plant, and equipment at December 28, 2024 and December 30, 2023 are as follows:

[0000889331-25-000039:notes:141]
| (in thousands) | 2024 |  | 2023 |
| Land and land improvements | $ | 17,593 |  |  | $ | 22,212 |  |
| Building and building improvements | 192,441 |  |  | 202,764 |  |
| Machinery and equipment | 892,940 |  |  | 859,060 |  |
| Accumulated depreciation and amortization | (625,906) |  |  | (590,883) |  |
| Total | $ | 477,068 |  |  | $ | 493,153 |  |

[0000889331-25-000039:notes:142]
The Company recorded depreciation expense of $68.3 million, $71.6 million, and $65.0 million for the fiscal years ended December 28, 2024, December 30, 2023, and December 31, 2022, respectively, in Cost of sales, Selling, general, and administrative expenses, and Research and development expenses in the Consolidated Statements of Net Income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000889331-25-000039:notes:143]
Goodwill and Other Intangible Assets

[0000889331-25-000039:notes:144]
The amounts for goodwill and changes in the carrying value by segment are as follows:

[0000889331-25-000039:notes:145]
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Gross goodwill as of December 31, 2022 | $ | 909,167 |  |  | $ | 234,793 |  |  | $ | 84,889 |  |  | $ | 1,228,849 |  |
| Accumulated impairment losses as of December 31, 2022 | — |  |  | (33,401) |  |  | (8,526) |  |  | (41,927) |  |
| Net goodwill as of December 31, 2022 | $ | 909,167 |  |  | $ | 201,392 |  |  | $ | 76,363 |  |  | $ | 1,186,922 |  |
| Changes during 2023: |  |  |  |  |  |  |  |
| Additions (a) | 3,879 |  |  |  |  | 93,937 |  |  | 97,816 |  |
| Foreign currency translation adjustments | 23,459 |  |  | 2,322 |  |  | 291 |  |  | 26,072 |  |
| Gross goodwill as of December 30, 2023 | 936,505 |  |  | 237,115 |  |  | 179,117 |  |  | 1,352,737 |  |
| Accumulated impairment losses as of December 30, 2023 | — |  |  | (34,004) |  |  | (8,735) |  |  | (42,739) |  |
| Net goodwill as of December 30, 2023 | $ | 936,505 |  |  | $ | 203,111 |  |  | $ | 170,382 |  |  | $ | 1,309,998 |  |
| Changes during 2024: |  |  |  |  |  |  |  |
| Impairments | — |  |  | (8,616) |  |  | (36,147) |  |  | (44,763) |  |
| Foreign currency translation adjustments | (29,634) |  |  | (2,854) |  |  | (4,245) |  |  | (36,733) |  |
| Gross goodwill as of December 28, 2024 | 906,871 |  |  | 233,286 |  |  | 173,882 |  |  | 1,314,039 |  |
| Accumulated impairment losses as of December 28, 2024 | — |  |  | (41,645) |  |  | (43,892) |  |  | (85,537) |  |
| Net goodwill as of December 28, 2024 | $ | 906,871 |  |  | $ | 191,641 |  |  | $ | 129,990 |  |  | $ | 1,228,502 |  |

[0000889331-25-000039:notes:146]
(a) The additions resulted from the acquisitions of Western Automation and C&K Switches.

[0000889331-25-000039:notes:147]
The Company tests its goodwill annually for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The results of the goodwill impairment test as of September 29, 2024 indicated that the estimated fair values for the Industrial controls and sensors and Automotive sensors reporting units were below their respective carrying values. Accordingly, the Company recorded non-cash charges of $36.1 million and $8.6 million, respectively, to reflect the impairment of goodwill for the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment. There were no impairment charges recorded during the fiscal years of 2023 and 2022.

[0000889331-25-000039:notes:148]
The goodwill impairment charge for the Industrial controls and sensors reporting unit was due to reduction in the estimated fair value of the reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2023 annual goodwill impairment test driven by lower-than-expected demand in the electric vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe.

[0000889331-25-000039:notes:149]
The goodwill impairment charge for the Automotive sensors reporting unit was due to reductions in the estimated fair value for the automotive sensors reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2023 annual goodwill impairment test. These lower future expectations were driven by projected declines in end market demand and reduced revenue and profitability with existing customers.

[0000889331-25-000039:notes:150]
The goodwill impairment charge was determined using Level 3 inputs, including discounted cash flow analysis and comparable marketplace fair value data. As of December 28, 2024, the Industrial controls and sensors reporting unit had $115.2 million of remaining goodwill, and the Automotive sensors reporting unit had no remaining goodwill.

[0000889331-25-000039:notes:151]
The components of intangible assets at December 28, 2024 and December 30, 2023 are as follows:

[0000889331-25-000039:notes:152]
|  | As of December 28, 2024 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 16,079 |  |  | $ | 2,994 |  |  | $ | 13,085 |  |
| Patents, licenses, and software | 260,096 |  |  | 180,674 |  |  | 79,422 |  |
| Distribution network | 41,667 |  |  | 41,667 |  |  | — |  |
| Customer relationships, trademarks, and tradenames | 632,572 |  |  | 242,961 |  |  | 389,611 |  |
| Total | $ | 950,414 |  |  | $ | 468,296 |  |  | $ | 482,118 |  |

[0000889331-25-000039:notes:153]
|  | As of December 30, 2023 |
| (in thousands) | GrossCarryingValue |  | AccumulatedAmortization |  | Net BookValue |
| Land use rights | $ | 17,621 |  |  | $ | 2,786 |  |  | $ | 14,835 |  |
| Patents, licenses, and software | 275,337 |  |  | 163,799 |  |  | 111,538 |  |
| Distribution network | 43,210 |  |  | 43,210 |  |  | — |  |
| Customer relationships, trademarks, and tradenames | 689,244 |  |  | 209,481 |  |  | 479,763 |  |
| Total | $ | 1,025,412 |  |  | $ | 419,276 |  |  | $ | 606,136 |  |

[0000889331-25-000039:notes:154]
For intangible assets with definite lives, the Company recorded amortization expense of $62.1 million, $65.8 million, and $55.7 million in 2024, 2023, and 2022, respectively.

[0000889331-25-000039:notes:155]
During the fourth quarter of 2024, the Company recorded non-cash impairment charges of $47.8 million for the impairment of intangible assets, including $47.6 million related to the impairment of certain acquired customer relationships, developed technology, and tradename intangible assets in the Industrial controls and sensors reporting unit within the Industrial segment. This impairment resulted from lower expectations of future revenue and cash flows and was determined using Level 3 inputs and estimated based on cash flow analyses, which included management’s assumptions related to future revenues and profitability. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within Industrial segment. During the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-25-000039:notes:156]
Estimated annual amortization expense related to intangible assets with definite lives at December 28, 2024 is as follows:

[0000889331-25-000039:notes:157]
| (in thousands) | Amount |
| 2025 | $ | 57,135 |  |
| 2026 | 46,492 |  |
| 2027 | 44,467 |  |
| 2028 | 44,081 |  |
| 2029 | 43,616 |  |
| 2030 and thereafter | 246,327 |  |
| Total | $ | 482,118 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000889331-25-000039:notes:158]
Accrued Liabilities

[0000889331-25-000039:notes:159]
The components of accrued liabilities at December 28, 2024 and December 30, 2023 are as follows:

[0000889331-25-000039:notes:160]
| (in thousands) | 2024 |  | 2023 |
| Employee-related liabilities | $ | 67,639 |  |  | $ | 72,635 |  |
| Current lease liability | 13,900 |  |  | 12,110 |  |
| Interest | 8,131 |  |  | 6,387 |  |
| Other non-income taxes | 7,022 |  |  | 7,855 |  |
| Professional services | 6,613 |  |  | 5,282 |  |
| Restructuring liability | 4,624 |  |  | 2,141 |  |
| Current hedge liability | 4,067 |  |  | — |  |
| Other customer reserves | 3,450 |  |  | 5,998 |  |
| Deferred revenue | 1,557 |  |  | 2,198 |  |
| Current benefit liability | 1,514 |  |  | 1,482 |  |
| Other | 29,759 |  |  | 33,126 |  |
| Total | $ | 148,276 |  |  | $ | 149,214 |  |

[0000889331-25-000039:notes:161]
Employee-related liabilities consist primarily of payroll, sales commission, bonus, employee benefit accruals and workers’ compensation. Bonus accruals include amounts earned pursuant to the Company’s primary employee incentive compensation plans. Other accrued liabilities include miscellaneous operating accruals and other customer-related liabilities.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000889331-25-000039:notes:162]
Lease Commitments
Under ASC 842, a contract contains a lease if there is an identified asset and the Company has the right to control the asset. The Company determines whether a contract contains a lease at contract inception. The Company leases office and production space under various non-cancellable operating leases that expire no later than 2036. Certain real estate leases include one or more options to renew. The exercise of lease renewal options is at the Company's sole discretion. Options to extend the lease are included in the lease term when it is reasonably certain the Company will exercise the option. The Company also has production equipment, office equipment and vehicles under operating leases and finance leases that were acquired through the C&K acquisition. The depreciable life of assets and leasehold improvements are limited by the expected lease term, unless there is a transfer of title or purchase option that is reasonably certain of exercise. Certain leases include rental payments adjusted periodically for inflation. The lease agreements do not contain any material residual value guarantee or material restrictive covenants. The Company has elected to use the available practical expedient to account for the lease and non-lease components of its leases as a single component. As the Company elected not to separate lease and non-lease components and instead to account for them as a single lease component, the variable lease cost primarily represents variable payments such as common area maintenance and utilities.

[0000889331-25-000039:notes:163]
The Company does not have a published credit rating because it has no publicly traded debt; therefore, the Company is generating its incremental borrowing rate ("IBR"), using a synthetic credit rating model that compares its credit quality to other rated companies based on certain financial metrics and ratios. The reference rate will be based on the yield curve of companies with similar credit quality based on the metrics and adjusted for currency in regions where we have significant operations.

[0000889331-25-000039:notes:164]
All leases with an initial term of 12 months or less that do not include an option to extend or purchase the underlying asset that the Company is reasonably certain to exercise (“short-term leases”) are not recorded on the Consolidated Balance Sheets. Short-term lease expenses are recognized on a straight-line basis over the lease term.

[0000889331-25-000039:notes:165]
The following table presents the classification of right of use assets and lease liabilities as of December 28, 2024 and December 30, 2023:

[0000889331-25-000039:notes:166]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Balance Sheet Classification |  | December 28, 2024 |  | December 30, 2023 |
| Operating Leases |  |  |  |  |  |
| Right of use assets - operating lease | Right of use lease assets |  | $ | 71,513 |  |  | $ | 60,991 |  |
| Current operating lease liabilities | Accrued liabilities |  | 13,626 |  |  | 11,676 |  |
| Non-current operating lease liabilities | Non-current lease liabilities |  | 60,558 |  |  | 49,180 |  |
| Total operating lease liabilities |  |  | $ | 74,184 |  |  | $ | 60,856 |  |
| Finance Leases |  |  |  |  |  |
| Right of use assets - finance lease | Right of use lease assets |  | $ | 698 |  |  | $ | 1,379 |  |
| Current finance lease liabilities | Accrued liabilities |  | 274 |  |  | 434 |  |
| Non-current finance lease liabilities | Non-current lease liabilities |  | 1 |  |  | 292 |  |
| Total finance lease liabilities |  |  | $ | 275 |  |  | $ | 726 |  |

[0000889331-25-000039:notes:167]
The following table represents the lease costs for 2024, 2023, and 2022:

[0000889331-25-000039:notes:168]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Statements of Net Income Classification |  | December 28, 2024 |  | December 30, 2023 |  | December 31, 2022 |
| Operating lease expenses | Cost of sales, Selling, general, and administrative expenses |  | $ | 17,310 |  |  | $ | 15,817 |  |  | $ | 14,071 |  |
| Finance lease: |  |  |  |  |  |  |  |
| Finance lease expenses | Cost of sales |  | 96 |  |  | 219 |  |  | 112 |  |
| Interest on lease liabilities | Other (income) expense, net |  | 8 |  |  | 19 |  |  | 13 |  |
| Short-term lease expenses | Cost of sales, Selling, general, and administrative expenses |  | 1,170 |  |  | 1,229 |  |  | 1,130 |  |
| Variable lease expenses | Cost of sales, Selling, general, and administrative expenses |  | 1,151 |  |  | 1,034 |  |  | 1,091 |  |
| Total lease costs | Cost of sales, Selling, general, and administrative expenses |  | $ | 19,735 |  |  | $ | 18,318 |  |  | $ | 16,417 |  |

[0000889331-25-000039:notes:169]
The Company leases certain office and warehouse space as well as certain machinery and equipment under non-cancellable operating leases. Rent expense under these leases was $19.7 million, $18.3 million, and $16.4 million in 2024, 2023, and 2022, respectively.

[0000889331-25-000039:notes:170]
| Maturity of lease liabilities as of December 28, 2024(in thousands) | Operating Leases |  | Finance Leases |
| 2025 | $ | 17,270 |  |  | $ | 277 |  |
| 2026 | 11,053 |  |  | 1 |  |
| 2027 | 10,523 |  |  | — |  |
| 2028 | 9,909 |  |  | — |  |
| 2029 | 8,378 |  |  | — |  |
| 2030 and thereafter | 36,337 |  |  | — |  |
| Total lease payments | $ | 93,470 |  |  | $ | 278 |  |
| Less: Imputed interest | (19,286) |  |  | (3) |  |
| Present value of lease liabilities | $ | 74,184 |  |  | $ | 275 |  |

[0000889331-25-000039:notes:171]
|  | Fiscal Year Ended |
|  | December 28, 2024 |  | December 30, 2023 |
| Weighted-average remaining lease term (years) |  |  |  |
| Operating leases | 8.67 |  | 8.38 |
| Finance leases | 1.00 |  | 1.69 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 5.39 | % |  | 5.39 | % |
| Finance leases | 2.00 | % |  | 1.90 | % |

[0000889331-25-000039:notes:172]
|  | Fiscal Year Ended |
| (in thousands) | December 28, 2024 |  | December 30, 2023 |  | December 31, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flow - payments on operating leases | $ | (13,258) |  |  | $ | (14,518) |  |  | $ | (12,298) |  |
| Operating cash flow - interest payments on finance leases | (8) |  |  | (19) |  |  | (13) |  |
| Financing cash flow - payments on finance lease obligations | (280) |  |  | (1,164) |  |  | (719) |  |
| Leased assets obtained in exchange of new lease obligations, including leases acquired: |  |  |  |  |  |
| Operating leases | $ | 26,785 |  |  | $ | 16,689 |  |  | $ | 37,760 |  |
| Finance leases | — |  |  | — |  |  | 2,502 |  |

[0000889331-25-000039:notes:173]
The net gain recorded from a sale leaseback transaction was $0.3 million for the fiscal year ended December 28, 2024. There were no sale leaseback transactions for the fiscal years ended December 30, 2023 and December 31, 2022.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000889331-25-000039:notes:174]
Restructuring, Impairment, and Other Charges
The Company recorded restructuring, impairment, and other charges for fiscal years 2024, 2023, and 2022 as follows:

[0000889331-25-000039:notes:175]
|  | Fiscal Year Ended December 28, 2024 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 8,748 |  |  | $ | 4,620 |  |  | $ | 583 |  |  | $ | 13,951 |  |
| Other restructuring charges | 310 |  |  | 543 |  |  | 122 |  |  | 975 |  |
| Total restructuring charges | 9,058 |  |  | 5,163 |  |  | 705 |  |  | 14,926 |  |
| Impairment | — |  |  | 9,549 |  |  | 83,966 |  |  | 93,515 |  |
| Total | $ | 9,058 |  |  | $ | 14,712 |  |  | $ | 84,671 |  |  | $ | 108,441 |  |

[0000889331-25-000039:notes:176]
|  | Fiscal Year Ended December 30, 2023 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 4,162 |  |  | $ | 3,649 |  |  | $ | 894 |  |  | $ | 8,705 |  |
| Other restructuring charges | 342 |  |  | 976 |  |  | 1,625 |  |  | 2,943 |  |
| Total restructuring charges | 4,504 |  |  | 4,625 |  |  | 2,519 |  |  | 11,648 |  |
| Impairment | 111 |  |  | 3,870 |  |  | 872 |  |  | 4,853 |  |
| Total | $ | 4,615 |  |  | $ | 8,495 |  |  | $ | 3,391 |  |  | $ | 16,501 |  |

[0000889331-25-000039:notes:177]
|  | Fiscal Year Ended December 31, 2022 |
| (in thousands) | Electronics |  | Transportation |  | Industrial |  | Total |
| Employee terminations | $ | 2,792 |  |  | $ | 2,694 |  |  | $ | 283 |  |  | $ | 5,769 |  |
| Other restructuring charges | 276 |  |  | 1,076 |  |  | — |  |  | 1,352 |  |
| Total restructuring charges | 3,068 |  |  | 3,770 |  |  | 283 |  |  | 7,121 |  |
| Impairment | 2,856 |  |  | — |  |  | — |  |  | 2,856 |  |
| Total | $ | 5,924 |  |  | $ | 3,770 |  |  | $ | 283 |  |  | $ | 9,977 |  |

[0000889331-25-000039:notes:178]
2024

[0000889331-25-000039:notes:179]
For the year ended December 28, 2024, the Company recorded $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recorded total restructuring charges of $14.9 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the goodwill and intangible impairment charges.

[0000889331-25-000039:notes:180]
2023

[0000889331-25-000039:notes:181]
For the year ended December 30, 2023, the Company recorded total restructuring charges of $11.6 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment's commercial vehicle business, the reorganization of certain selling and administrative functions within the Electronics segment due to the C&K Switches acquisition, and reorganization of certain manufacturing, selling and administrative functions within the Industrial segment. During 2023, the Company recorded a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate, a $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment related to certain machinery and equipment in the semiconductor business within the Electronics segment.

[0000889331-25-000039:notes:182]
2022

[0000889331-25-000039:notes:183]
For the year ended December 31, 2022, the Company recorded total restructuring charges of $7.1 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions within the Transportation segment's passenger car and automotive sensor businesses and the reorganization of selling and administrative functions within the Electronics segment due to the C&K acquisition. During the fourth quarter of 2022, the Company recorded a $2.9 million non-cash impairment charge for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment. See Note 5, Goodwill and Other Intangible Assets for further discussion regarding the intangible asset impairment charge.

[0000889331-25-000039:notes:184]
The restructuring reserves as of December 28, 2024 and December 30, 2023 are $4.6 million and $2.1 million, respectively. The restructuring reserves are included within accrued liabilities. Payments associated with employee terminations reflected in the above table were substantially completed by December 28, 2024. The Company anticipates that the remaining payments associated with employee terminations will be substantially completed in fiscal 2025.


## us-gaap:DebtDisclosureTextBlock

[0000889331-25-000039:notes:185]
Debt

[0000889331-25-000039:notes:186]
The carrying amounts of debt at December 28, 2024 and December 30, 2023 are as follows:

[0000889331-25-000039:notes:187]
| (in thousands) | 2024 |  | 2023 |
| Revolving credit facility | $ | 100,000 |  |  | $ | 100,000 |  |
| Term loan | 281,250 |  |  | 288,750 |  |
| Euro Senior Notes, Series B due 2028 | 98,928 |  |  | 105,246 |  |
| U.S. Senior Notes, Series A due 2025 | 50,000 |  |  | 50,000 |  |
| U.S. Senior Notes, Series B due 2027 | 100,000 |  |  | 100,000 |  |
| U.S. Senior Notes, Series B due 2030 | 125,000 |  |  | 125,000 |  |
| U.S. Senior Notes, due 2032 | 100,000 |  |  | 100,000 |  |
| Other | 3,702 |  |  | 6,709 |  |
| Unamortized debt issuance costs | (2,766) |  |  | (3,770) |  |
| Total debt | 856,114 |  |  | 871,935 |  |
| Less: Current maturities | (67,612) |  |  | (14,020) |  |
| Total long-term debt | $ | 788,502 |  |  | $ | 857,915 |  |

[0000889331-25-000039:notes:188]
Interest paid on all Company debt was $36.2 million, $37.2 million, and $25.4 million in fiscal year 2024, 2023, and 2022, respectively, which included cash settlements received from the interest rate swap entered on May 12, 2022.

[0000889331-25-000039:notes:189]
Revolving Credit Facility and Term Loan

[0000889331-25-000039:notes:190]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (as so amended and restated, the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0000889331-25-000039:notes:191]
Loans made under the available credit facility pursuant to the Credit Agreement ("the Credit Facility") bear interest at the Company’s option, at either SOFR, fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0000889331-25-000039:notes:192]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the fiscal year ended December 28, 2024, the Company made term loan payments of $7.5 million. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $281.3 million, respectively, as of December 28, 2024.

[0000889331-25-000039:notes:193]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0000889331-25-000039:notes:194]
As of December 28, 2024, the effective interest rate on unhedged portion of the outstanding borrowings under the credit facility was 5.71%, and 4.13% on the hedged portion.

[0000889331-25-000039:notes:195]
As of December 28, 2024, the Company had $0.1 million outstanding in letters of credit and had available $599.9 million of borrowing capacity under the revolving credit facility. As of December 28, 2024, the Company was in compliance with all covenants under the credit agreement.

[0000889331-25-000039:notes:196]
Senior Notes

[0000889331-25-000039:notes:197]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due 2023. Interest on the Euro Senior Notes, Series B due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0000889331-25-000039:notes:198]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due 2022. Interest on the U.S. Senior Notes, Series B due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0000889331-25-000039:notes:199]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. Interest on the U.S. Senior Notes due 2025 and 2030 is payable on February 15 and August 15, commencing on August 15, 2018.

[0000889331-25-000039:notes:200]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0000889331-25-000039:notes:201]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0000889331-25-000039:notes:202]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0000889331-25-000039:notes:203]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of December 28, 2024, the Company was in compliance with all covenants under the Senior Notes.

[0000889331-25-000039:notes:204]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to noteholders, and are required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0000889331-25-000039:notes:205]
Debt Issuance Costs

[0000889331-25-000039:notes:206]
During fiscal year 2022, the Company paid debt issuance costs of $2.7 million in connection with the amended and restated Credit Agreement, dated June 30, 2022 which, along with the remaining balance of debt issuance costs of the previous credit facility, are being amortized over the life of the amended and restated Credit Agreement.

[0000889331-25-000039:notes:207]
Debt Maturities

[0000889331-25-000039:notes:208]
Scheduled maturities of the Company’s long-term debt for each of the five years succeeding December 28, 2024 and thereafter are summarized as follows:

[0000889331-25-000039:notes:209]
| (in thousands) | ScheduledMaturities |
| 2025 | $ | 67,612 |  |
| 2026 | 16,091 |  |
| 2027 | 451,250 |  |
| 2028 | 98,927 |  |
| 2029 | — |  |
| 2030 and thereafter | 225,000 |  |
|  | $ | 858,880 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000889331-25-000039:notes:210]
Fair Value of Assets and Liabilities
For assets and liabilities measured at fair value on a recurring and nonrecurring basis, a three-level hierarchy of measurements based upon observable and unobservable inputs is used to arrive at fair value. Observable inputs are developed based on market data obtained from independent sources, while unobservable inputs reflect the Company’s assumptions about valuation based on the best information available in the circumstances. Depending on the inputs, the Company classifies each fair value measurement as follows:

[0000889331-25-000039:notes:211]
Level 1—Valuations based on unadjusted quoted prices for identical assets or liabilities in active markets;

[0000889331-25-000039:notes:212]
Level 2—Valuations based upon quoted prices for similar instruments, prices for identical or similar instruments in markets that are not active, or model-derived valuations, all of whose significant inputs are observable or can be corroborated by observable market data;

[0000889331-25-000039:notes:213]
Level 3—Valuations based upon one or more significant unobservable inputs;

[0000889331-25-000039:notes:214]
There were no transfers in or out of Level 1, Level 2 and Level 3 during the year ended December 28, 2024.

[0000889331-25-000039:notes:215]
Following is a description of the valuation methodologies used for instruments measured at fair value and their classification in the valuation hierarchy.

[0000889331-25-000039:notes:216]
Cash Equivalents

[0000889331-25-000039:notes:217]
Cash equivalents primarily consist of money market funds, certificates of deposit, and short-term time deposits, which are held with institutions with sound credit ratings and are highly liquid. The Company classified cash equivalents as Level 1 and are valued at cost, which approximates fair value.

[0000889331-25-000039:notes:218]
Investments in Equity Securities

[0000889331-25-000039:notes:219]
Investments in equity securities listed on a national market or exchange are valued at the last sales price and classified within Level 1 of the valuation hierarchy. Such securities are further detailed in Note 1, Summary of Significant Accounting Policies and Other Information.

[0000889331-25-000039:notes:220]
Derivatives Designated as Hedging Instruments

[0000889331-25-000039:notes:221]
For derivatives that will be accounted for as hedging instruments, the Company formally designates and documents, at inception, the financial instrument as a hedge of a specific underlying exposure, the risk management objective, and the strategy for undertaking the hedge transaction. In addition, the Company formally assesses, both at the inception and at least quarterly thereafter, whether the financial instruments used in hedging transactions are effective at offsetting changes in either the fair values or cash flows of the related underlying exposures. For highly effective cash flow hedges, ASC 815 requires the entire

[0000889331-25-000039:notes:222]
change in fair value of the hedging instrument included in the assessment of hedge effectiveness to be recorded in other comprehensive income. No components of the Company's hedging instruments were excluded from the assessment of hedge effectiveness.

[0000889331-25-000039:notes:223]
Zero Cost Collar Agreement

[0000889331-25-000039:notes:224]
In July 2024, the Company implemented a hedging program to manage foreign currency risk exposure related to fluctuations between the U.S. dollar and Mexican peso. These foreign currency zero cost collars are designated as cash flow hedges for a portion of our Mexican peso-denominated manufacturing expenses, predominantly salary expenses, vendor payments, and utility expenses. The collars that were entered on July 3, 2024, mature on August 29, 2025 at a weighted-average ceiling of 19.435 and a weighted-average floor of 18.000. The collars that were entered on August 5, 2024, mature on September 29, 2025 at a weighted-average ceiling of 21.000 and a weighted-average floor of 19.655. The collars that were entered on September 3, 2024, mature on November 3, 2025 at a weighted-average ceiling of 21.757 and a weighted-average floor of 20.082. The collars that were entered on September 30, 2024, mature on November 26, 2025 at a weighted-average ceiling of 21.365 and a weighted-average floor of 19.870. The collars that were entered on November 4, 2024, mature on January 2, 2026 at a weighted-average ceiling of 21.690 and a weighted-average floor of 20.120. The collars that were entered on December 2, 2024, mature on February 2, 2026 at a weighted-average ceiling of 22.0377 and a weighted-average floor of 20.425. If the spot rate is between the weighted-average ceiling and floor rates on the date of maturity, then the Company would not owe or receive any payments under these collars. The Company plans to continue executing zero cost collars with 14-month rolling maturities as an ongoing strategy to hedge peso-denominated manufacturing expenses.

[0000889331-25-000039:notes:225]
The fair value of the collars was determined using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive loss until the underlying transactions are recognized in earnings. For the fiscal year ended December 28, 2024, the Company recorded a pre-tax unrealized loss on the collars of $3.5 million. The Company estimates that approximately $3.6 million of pre-tax losses currently recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The amounts included in accumulated other comprehensive loss will be reclassified to earnings should the hedge no longer be considered effective. No amount of ineffectiveness was included in net income for the fiscal year ended December 28, 2024. The Company will continue to assess the effectiveness of the hedge on an ongoing basis. The primary inputs into the valuation of the collars are interest yield curves, interest rate volatilities, foreign exchange rates, foreign exchange volatilities, credit risk, credit spreads and other market information. The collars are classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by market observable data.

[0000889331-25-000039:notes:226]
Interest Rate Swap

[0000889331-25-000039:notes:227]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027. The fair value of the interest rate swap was valued using an independent third-party valuation model. Pursuant to this model, changes in fair value of derivatives that are designated as cash flow hedges are deferred in accumulated other comprehensive (loss) income until the underlying transactions are recognized in earnings. For the fiscal year ended December 28, 2024, the Company recorded a pre-tax unrealized gain on the interest rate swap of $0.3 million. The Company estimates that approximately $2.7 million of pre-tax gain currently recorded in accumulated other comprehensive loss will be recognized in earnings over the next 12 months. The primary inputs into the valuation of the interest rate swap are interest yield curves, interest rate volatility, credit risk, credit spreads and other market information. The interest rate swap is classified within Level 2 of the fair value hierarchy since all significant inputs are corroborated by observable market data.

[0000889331-25-000039:notes:228]
The use of derivatives creates exposure to credit risk relating to potential losses that could be recognized in the event that the counterparties to these instruments fail to perform their obligations under the contracts. The Company seeks to minimize this risk by limiting our counterparties to major financial institutions with acceptable credit ratings and monitoring the total value of positions with individual counterparties. In the event of a default by one of our counterparties, the Company may not receive payments provided for under the terms of our derivatives.

[0000889331-25-000039:notes:229]
Derivatives Not Designated as Hedging Instruments

[0000889331-25-000039:notes:230]
On July 14, 2022, the Company entered into a foreign currency exchange forward contract to mitigate the currency fluctuation risk between the Euro and U.S. dollar on its Euro denominated Senior Notes, Series A due 2023. The notional value of the forward contract at July 14, 2022 was €117 million and expired on December 7, 2023 with the final settlement value of $6.3 million which the Company used to convert USD to Euro to pay down the €117 million of Euro Senior Notes, Series A due 2023. The foreign currency contract was not designated as a hedge instrument and was marked to market on a monthly

[0000889331-25-000039:notes:231]
basis. As a result, changes in fair value during 2023 were reported in Foreign exchange loss in the Consolidated Statements of Net Income. The fair value of the foreign currency forward contract was valued by a third party using market exchange rates and classified as a Level 2 input under the fair value hierarchy.

[0000889331-25-000039:notes:232]
As of December 28, 2024 and December 30, 2023, the fair values of our derivative financial instrument and their classifications on the Consolidated Balance Sheets were as follows:

[0000889331-25-000039:notes:233]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Consolidated Balance Sheets Classification |  | December 28, 2024 |  | December 30, 2023 |
| Derivatives designated as hedging instruments |  |  |  |  |  |
| Interest rate swap agreement: |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 2,482 |  |  | $ | 3,712 |  |
|  | Other long-term assets |  | 3,716 |  |  | 2,140 |  |
| Zero cost collar agreement: |  |  |  |  |  |
| Designated as cash flow hedge | Prepaid expenses and other current assets |  | $ | 22 |  |  | $ | — |  |
|  | Accrued liabilities |  | 4,067 |  |  | — |  |
|  | Other long-term assets |  | 2 |  |  | — |  |

[0000889331-25-000039:notes:234]
The pre-tax (gains) losses recognized on derivative financial instruments in the Consolidated Statements of Operations for the fiscal year ended December 28, 2024 and December 30, 2023 were as follows:

[0000889331-25-000039:notes:235]
|  |  |  | Fiscal Year Ended |
| (in thousands) | Classification of (Gains) Losses Recognized in the Consolidated Statements of Net Income |  | December 28, 2024 |  | December 30, 2023 |
| Derivatives designated as cash flow hedges |  |  |  |  |  |
| Interest rate swap agreement | Interest expense, net |  | $ | (4,826) |  |  | $ | (4,551) |  |
| Zero cost collar agreement | Cost of sales |  | 1,766 |  |  | — |  |
| Zero cost collar agreement | Selling, general, and administrative expenses |  | 97 |  |  | — |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |
| Foreign exchange forward contract | Foreign exchange gain |  | $ | — |  |  | $ | (52) |  |

[0000889331-25-000039:notes:236]
The pre-tax (gain) losses recognized on derivative financial instruments in the Consolidated Statements of Comprehensive Income for the fiscal year ended December 28, 2024 and December 30, 2023 was as follows:

[0000889331-25-000039:notes:237]
|  |  | Fiscal Year Ended |  |  |
| (in thousands) |  | December 28, 2024 |  | December 30, 2023 |  |  |
| Derivatives designated as cash flow hedges |  |  |  |  |  |  |
| Interest rate swap agreement |  | $ | (346) |  |  | $ | 2,827 |  |  |  |
| Zero cost collar agreement |  | $ | 3,534 |  |  | $ | — |  |  |  |

[0000889331-25-000039:notes:238]
Mutual Funds

[0000889331-25-000039:notes:239]
The Company has a non-qualified Supplemental Retirement and Savings Plan that provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains investment accounts for participants through which participants make investment elections. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value and recorded in Other long-term assets on the Consolidated Balance sheet.

[0000889331-25-000039:notes:240]
There were no changes during the fiscal year ended December 28, 2024 to the Company’s valuation techniques used to measure asset and liability fair values on a recurring basis. As of December 28, 2024 and December 30, 2023, the Company did not hold any non-financial assets or liabilities that are required to be measured at fair value on a recurring basis.

[0000889331-25-000039:notes:241]
Defined Benefit Plan Assets / Non-qualified Supplemental Retirement and Savings Plan Investments

[0000889331-25-000039:notes:242]
See Note 11, Benefit Plans, for a description of valuation methodologies and investment balances for defined benefit plan assets and investments related to the Company’s Non-Qualified Supplemental Retirement and Savings Plan.

[0000889331-25-000039:notes:243]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 28, 2024:

[0000889331-25-000039:notes:244]
|  | Fair Value Measurements Using |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash equivalents | $ | 658,491 |  |  | $ | — |  |  | $ | — |  |  | $ | 658,491 |  |
| Investments in equity securities | 10,182 |  |  | — |  |  | — |  |  | 10,182 |  |
| Mutual funds | 23,268 |  |  | — |  |  | — |  |  | 23,268 |  |
| Total | $ | 691,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 691,941 |  |

[0000889331-25-000039:notes:245]
The following table presents assets measured at fair value by classification within the fair value hierarchy as of December 30, 2023:

[0000889331-25-000039:notes:246]
|  | Fair Value Measurements Using |
| (in thousands) | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total |
| Cash equivalents | $ | 415,788 |  |  | $ | — |  |  | $ | — |  |  | $ | 415,788 |  |
| Investments in equity securities | 10,832 |  |  | — |  |  | — |  |  | 10,832 |  |
| Mutual funds | 20,148 |  |  | — |  |  | — |  |  | 20,148 |  |
| Total: | $ | 446,768 |  |  | $ | — |  |  | $ | — |  |  | $ | 446,768 |  |

[0000889331-25-000039:notes:247]
In addition to the methods and assumptions used for the financial instruments recorded at fair value as discussed above, the following methods and assumptions are used to estimate the fair value of other financial instruments that are not marked to market on a recurring basis. The Company’s other financial instruments include cash and cash equivalents, short-term investments, trade receivables and its long-term debt. Due to their short-term maturity, the carrying amounts of cash and cash equivalents, short-term investments and trade receivables approximate their fair values. The Company’s revolving and term loan debt facilities’ fair values approximate book value at December 28, 2024 and December 30, 2023, as the rates on these borrowings are variable in nature.

[0000889331-25-000039:notes:248]
The carrying value and estimated fair values of the Company’s Euro Senior Notes, Series B and USD Senior Notes, Series A and Series B, as of December 28, 2024 and December 30, 2023 were as follows:

[0000889331-25-000039:notes:249]
|  | December 28, 2024 |  | December 30, 2023 |
| (in thousands) | CarryingValue |  | EstimatedFair Value |  | CarryingValue |  | EstimatedFair Value |
| Euro Senior Notes, Series B due 2028 | $ | 98,928 |  |  | $ | 91,741 |  |  | $ | 105,246 |  |  | $ | 96,532 |  |
| USD Senior Notes, Series A due 2025 | 50,000 |  |  | 49,919 |  |  | 50,000 |  |  | 49,070 |  |
| USD Senior Notes, Series B due 2027 | 100,000 |  |  | 96,623 |  |  | 100,000 |  |  | 96,127 |  |
| USD Senior Notes, Series B due 2030 | 125,000 |  |  | 114,786 |  |  | 125,000 |  |  | 115,687 |  |
| USD Senior Notes, due 2032 | 100,000 |  |  | 91,175 |  |  | 100,000 |  |  | 93,228 |  |

[0000889331-25-000039:notes:250]
Impairments

[0000889331-25-000039:notes:251]
The results of the annual goodwill impairment test as of September 29, 2024 indicated that the estimated fair values for Industrial controls and sensors and Automotive Sensors reporting units were below their respective carrying values. Accordingly, the Company recorded non-cash impairment charges of $36.1 million and $8.6 million, respectively, to reflect the impairment of goodwill for the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment. Additionally, during the fourth quarter of 2024, the Company also recorded a non-cash impairment charge of $47.8 million primarily related to certain acquired customer relationships, developed technology, and tradename intangible assets in the Industrial controls and sensors reporting unit within the Industrial segment. See Note 5, Goodwill and Other Intangible Assets, for further discussion. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0000889331-25-000039:notes:252]
2024 goodwill and intangible assets impairment charges were the result of measuring a reporting unit at fair value on a nonrecurring basis as shown below:

[0000889331-25-000039:notes:253]
| (in thousands) | For Fiscal Year Ended December 28, 2024 |  | December 28, 2024 |
|  | Impairment Charge |  | Estimated Fair Value Measurement (Level 3) |  | Net Carrying Value |
| Industrial controls and sensors reporting unit |  |  |  |  |  |
| Customer relationships, trademarks, and tradenames | $ | 40,641 |  |  | $ | 6,620 |  |  | $ | 7,142 |  |
| Patents, licenses and software | 6,938 |  |  | 950 |  |  | 1,065 |  |
| Intangible assets, net of amortization | $ | 47,579 |  |  | $ | 7,570 |  |  | $ | 8,207 |  |
| Goodwill | $ | 36,147 |  |  | $ | 119,361 |  |  | $ | 115,159 |  |
| Automotive sensors reporting unit |  |  |  |  |  |
| Goodwill | $ | 8,616 |  |  | $ | — |  |  | $ | — |  |

[0000889331-25-000039:notes:254]
During 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate, a $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment related to certain machinery and equipment in the semiconductor business within the Electronics segment. See Note 8, Restructuring, Impairment, and Other Charges, for further discussion.

[0000889331-25-000039:notes:255]
During the fourth quarter of 2022, the Company recorded a $2.9 million intangible asset impairment charge in Restructuring, impairment, and other charges in the Consolidated Statements of Net Income, for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment. See Note 5, Goodwill and Other Intangible Assets, for further discussion. Additionally, the Company recorded a non-cash impairment charge of $1.7 million for certain machinery and equipment within Electronics segment due to a decision to cease further production of a product line during the fourth quarter of 2022. The fair value of the patent, technology, and machinery and equipment were measured on a nonrecurring basis using Level 3 inputs under the fair value hierarchy. The Company's accounting and finance management determines the valuation policies and procedures for Level 3 fair value measurements and is responsible for the development and determination of unobservable inputs.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000889331-25-000039:notes:256]
Benefit Plans

[0000889331-25-000039:notes:257]
The Company has Company-sponsored and mandatory defined benefit pension plans covering employees in the United Kingdom ("U.K."), Germany, the Philippines, China, Japan, Mexico, Italy, and France. The amount of the retirement benefits provided under the plans is generally based on years of service and final average pay.

[0000889331-25-000039:notes:258]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $23 million, representing approximately 33% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on

[0000889331-25-000039:notes:259]
hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-25-000039:notes:260]
Benefit plan related information is as follows for the years 2024 and 2023:

[0000889331-25-000039:notes:261]
| (in thousands) | 2024 |  | 2023 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 73,521 |  |  | $ | 64,526 |  |
| Service cost | 3,060 |  |  | 2,774 |  |
| Interest cost | 3,873 |  |  | 3,795 |  |
| Net actuarial loss | 501 |  |  | 4,312 |  |
| Benefits paid from the plan assets | (2,037) |  |  | (1,933) |  |
| Benefits paid directly by the Company | (2,042) |  |  | (2,035) |  |
| Settlements | (1,248) |  |  | (1,687) |  |
| Effect of exchange rate movements | (4,946) |  |  | 3,769 |  |
| Benefit obligation at end of year | $ | 70,682 |  |  | $ | 73,521 |  |
| Change in plan assets at fair value: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 37,696 |  |  | $ | 35,433 |  |
| Actual (loss) gain on plan assets | (529) |  |  | 1,358 |  |
| Employer contributions | 5,376 |  |  | 1,821 |  |
| Benefits paid from the plan assets | (2,037) |  |  | (1,933) |  |
| Settlements | — |  |  | (463) |  |
| Effect of exchange rate movements | (1,168) |  |  | 1,480 |  |
| Fair value of plan assets at end of year | 39,338 |  |  | 37,696 |  |
| Net amount unfunded status | $ | (31,344) |  |  | $ | (35,825) |  |

[0000889331-25-000039:notes:262]
Amounts recognized in the Consolidated Balance Sheets as of December 28, 2024 and December 30, 2023 consist of the following:

[0000889331-25-000039:notes:263]
| (in thousands) | 2024 |  | 2023 |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |
| Non-current assets | $ | 6 |  |  | $ | 79 |  |
| Current benefit liability | (1,514) |  |  | (1,482) |  |
| Non-current benefit liability | (29,836) |  |  | (34,422) |  |
| Net liability recognized | $ | (31,344) |  |  | $ | (35,825) |  |

[0000889331-25-000039:notes:264]
The amounts included in accumulated other comprehensive loss in the Consolidated Balance Sheets, excluding tax effects that have not yet been recognized as components of net periodic benefit costs as of December 28, 2024 and December 30, 2023 were as follows:

[0000889331-25-000039:notes:265]
| (in thousands) | 2024 |  | 2023 |
| Net actuarial loss | $ | 6,679 |  |  | $ | 4,182 |  |
| Prior service cost | 1,304 |  |  | 1,440 |  |
| Total | $ | 7,983 |  |  | $ | 5,622 |  |

[0000889331-25-000039:notes:266]
The pre-tax amounts recognized in other comprehensive (loss) income in 2024 and 2023 were as follows:

[0000889331-25-000039:notes:267]
|  | 2024 |  | 2023 |
| (in thousands) |  |  |  |
| Amortization of: |  |  |  |
| Prior service cost | $ | 93 |  |  | $ | 94 |  |
| Net actuarial loss (gain) | 81 |  |  | (49) |  |
| Amount arising during the period: |  |  |  |
| Net actuarial loss | (3,099) |  |  | (4,202) |  |
| Net curtailment and settlement loss (gain) | 299 |  |  | (266) |  |
| Foreign currency adjustments | 265 |  |  | (334) |  |
| Total | $ | (2,361) |  |  | $ | (4,757) |  |

[0000889331-25-000039:notes:268]
Due to the signing of the group annuity contract for the U.K. pension plan, the liabilities of the plan were remeasured as of October 4, 2024 resulting in an increase of $3.8 million to unamortized actuarial loss within other comprehensive income (loss). In addition, the net actuarial loss during 2024 as compared to 2023 were impacted by lower discount rates in 2024 as compared to 2023.

[0000889331-25-000039:notes:269]
The components of net periodic benefit costs for the fiscal years 2024, 2023, and 2022 are as follows:

[0000889331-25-000039:notes:270]
| (in thousands) | 2024 |  | 2023 |  | 2022 |
| Components of net periodic benefit cost: |  |  |  |  |  |
| Service cost | $ | 3,060 |  |  | $ | 2,774 |  |  | $ | 3,072 |  |
| Interest cost | 3,873 |  |  | 3,795 |  |  | 2,529 |  |
| Expected return on plan assets | (2,069) |  |  | (1,879) |  |  | (1,507) |  |
| Amortization of prior service and net actuarial loss | 174 |  |  | 45 |  |  | 378 |  |
| Net periodic benefit cost | 5,038 |  |  | 4,735 |  |  | 4,472 |  |
| Net settlement loss (gain) | 299 |  |  | (266) |  |  | (820) |  |
| Total expense for the year | $ | 5,337 |  |  | $ | 4,469 |  |  | $ | 3,652 |  |

[0000889331-25-000039:notes:271]
Weighted average assumptions used to determine net periodic benefit cost for the fiscal years 2024, 2023, and 2022 are as follows:

[0000889331-25-000039:notes:272]
|  | 2024 |  | 2023 |  | 2022 |
| Discount rate | 5.6 | % |  | 5.8 | % |  | 3.1 | % |
| Expected return on plan assets | 5.5 | % |  | 5.2 | % |  | 3.3 | % |
| Compensation increase rate | 4.8 | % |  | 4.7 | % |  | 4.8 | % |

[0000889331-25-000039:notes:273]
The accumulated benefit obligation for the plans was $58.7 million and $60.6 million as of December 28, 2024 and December 30, 2023, respectively.

[0000889331-25-000039:notes:274]
The following table provides a summary of under-funded or unfunded pension benefit plans with projected benefit obligations in excess of plan assets as of December 28, 2024 and December 30, 2023:

[0000889331-25-000039:notes:275]
| (in thousands) | 2024 |  | 2023 |
| Projected benefit obligation | $ | 47,016 |  |  | $ | 73,029 |  |
| Fair value of plan assets | 15,666 |  |  | 37,124 |  |

[0000889331-25-000039:notes:276]
The following table provides a summary of under-funded or unfunded pension benefit plans with accumulated benefit obligations in excess of plan assets as of December 28, 2024 and December 30, 2023:

[0000889331-25-000039:notes:277]
| (in thousands) | 2024 |  | 2023 |
| Accumulated benefit obligation | $ | 28,028 |  |  | $ | 53,400 |  |
| Fair value of plan assets | 5,419 |  |  | 28,032 |  |

[0000889331-25-000039:notes:278]
Weighted average assumptions used to determine benefit obligations as of December 28, 2024, December 30, 2023 and December 31, 2022 are as follows:

[0000889331-25-000039:notes:279]
|  | 2024 |  | 2023 |  | 2022 |
| Discount rate | 5.6 | % |  | 5.6 | % |  | 5.8 | % |
| Compensation increase rate | 4.8 | % |  | 4.8 | % |  | 4.7 | % |

[0000889331-25-000039:notes:280]
Expected benefit payments to be paid to participants for the fiscal year ending are as follows:

[0000889331-25-000039:notes:281]
| (in thousands) | Expected Benefit Payments |
| 2025 | $ | 4,149 |  |
| 2026 | 4,054 |  |
| 2027 | 4,037 |  |
| 2028 | 4,791 |  |
| 2029 | 5,368 |  |
| 2030-2034 and thereafter | 34,181 |  |

[0000889331-25-000039:notes:282]
The Company expects to make approximately $1.2 million of contributions to the plans and pay $2.1 million of benefits directly in 2025.

[0000889331-25-000039:notes:283]
The Company also sponsors certain post-employment plans in foreign countries and other statutory benefit plans. For the fiscal years ended December 28, 2024, December 30, 2023, and December 31, 2022, the Company recorded $5.0 million, $1.5 million and $1.9 million expense, respectively, in Cost of sales, Restructuring, impairment, and other charges, and Other (income) expense, net within the Consolidated Statements of Net Income. As of December 28, 2024 and December 30, 2023, the Company reported benefit liabilities of $4.4 million and $4.8 million for these plans, of which $1.5 million and $1.7 million was recorded in Accrued liabilities and $2.9 million and $3.1 million was recorded in Other long-term liabilities on the Consolidated Balance Sheets, respectively. For the fiscal years ended December 28, 2024 and December 30, 2023, the pre-tax amounts recognized in other comprehensive income (loss) for these plans were $0.2 million and $1.3 million, respectively. For the fiscal year ended December 28, 2024, the expense reclassified from accumulated other comprehensive loss to earnings as components of net periodic benefit costs was $3.3 million. For the fiscal year ended December 30, 2023, the expense reclassified from accumulated other comprehensive loss to earnings as components of net periodic benefit costs was $0.4 million, including $0.5 million net settlement loss.

[0000889331-25-000039:notes:284]
Defined Benefit Plan Assets

[0000889331-25-000039:notes:285]
Based upon analysis of the target asset allocation and historical returns by type of investment, the Company has assumed that the expected long-term rate of return will be 5.5% on plan assets. Assets are invested to maximize long-term return taking into consideration timing of settlement of the retirement liabilities and liquidity needs for benefits payments. Pension plan assets were invested as follows, and were not materially different from the target asset allocation:

[0000889331-25-000039:notes:286]
|  | Asset Allocation |
|  | 2024 |  | 2023 |
| Cash and cash equivalents, and other | 1 | % |  | 3 | % |
| Equity securities | 7 | % |  | 7 | % |
| Fixed income securities | 32 | % |  | 90 | % |
| Bulk annuity contract | 60 | % |  | — | % |
|  | 100 | % |  | 100 | % |

[0000889331-25-000039:notes:287]
The Company segregated its plan assets by the following major categories and level for determining their fair value as of December 28, 2024 and December 30, 2023. All plan assets that are valued using the net asset value per share (“NAV”) practical expedient have not been included within the fair value hierarchy, but are separately disclosed.

[0000889331-25-000039:notes:288]
Cash and cash equivalents – Carrying value approximates fair value. As such, these assets were classified as Level 1. The Company also invests in certain short-term investments which are valued using the amortized cost method. Lastly, the Company has certain pooled pension funds that have short-term investments with third party mutual funds that are valued at unit value per share at measurement date. As such, these assets were classified as Level 2.

[0000889331-25-000039:notes:289]
Equity – The values of individual equity securities were based on quoted prices in active markets. As such, these assets are classified as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in certain equity securities that are not quoted on active markets; therefore, they were classified as Level 2.

[0000889331-25-000039:notes:290]
Fixed income – Fixed income securities are typically priced based on a last trade basis and are exchange-traded. Accordingly, the Company classified fixed income securities as Level 1. The Company has certain pooled pension funds which have mutual funds with underlying investments in fixed income securities and funds priced based on a valuation model rather than a last trade basis and are not exchange-traded. As such, they were classified as Level 2. The Company also invests in certain fixed income funds which are valued at the NAV.

[0000889331-25-000039:notes:291]
Insurance contracts and other – This category includes pooled pension funds which have mutual funds with underlying investments in other assets and liabilities including alternatives priced based on a valuation model and are not exchange-traded. These were classified as Level 2. This category also includes insurance contracts that are valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market. Accordingly, insurance contracts were categorized as Level 3. Lastly, this category includes other assets and liabilities including futures or swaps.

[0000889331-25-000039:notes:292]
Bulk Annuity Contract – Bulk annuity contract includes a U.K insurance policy issued by an authorized U.K. life insurer. This bulk annuity contract is valued by the re-insurer with the valuation inputs being not highly observable or traded on an open market. Accordingly, this contract was categorized as Level 3.

[0000889331-25-000039:notes:293]
For any Level 2 and Level 3 plan assets, management reviews significant investments on a periodic basis including investigation of unusual fluctuations in price or returns and obtaining an understanding of the pricing methodology to assess the reliability of third-party pricing estimates.

[0000889331-25-000039:notes:294]
The valuation methodologies described above may generate a fair value calculation that may not be indicative of net realizable value or future fair values. While the Company believes the valuation methodologies used are appropriate, the use of different methodologies or assumptions in calculating fair value could result in different amounts. The Company invests in assets in which valuation is determined by the NAV. The Company believes that the NAV is representative of fair value at the reporting date, as there are no significant restrictions on redemption of these investments or other reasons to indicate that the investment would be redeemed at an amount different than the NAV.

[0000889331-25-000039:notes:295]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 28, 2024:

[0000889331-25-000039:notes:296]
|  | Fair Value Measurements Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Insurance contracts and other | $ | — |  |  | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 131 |  |
| Cash and cash equivalents | 422 |  |  | — |  |  | — |  |  | — |  |  | 422 |  |
| Equities | 2,921 |  |  | — |  |  | — |  |  | — |  |  | 2,921 |  |
| Fixed income | 7,224 |  |  | — |  |  | — |  |  | 5,198 |  |  | 12,422 |  |
| Bulk annuity contract | — |  |  | — |  |  | 23,442 |  |  | — |  |  | 23,442 |  |
| Total pension plan assets | $ | 10,567 |  |  | $ | — |  |  | $ | 23,573 |  |  | $ | 5,198 |  |  | $ | 39,338 |  |

[0000889331-25-000039:notes:297]
The following table presents the Company’s pension plan assets measured at fair value by classification within the fair value hierarchy as of December 30, 2023:

[0000889331-25-000039:notes:298]
|  | Fair Value Measurements Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | NAV |  | Total |
| Insurance contracts and other | $ | — |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |
| Cash and cash equivalents | 310 |  |  | 933 |  |  | — |  |  | — |  |  | 1,243 |  |
| Equities | 2,609 |  |  | — |  |  | — |  |  | — |  |  | 2,609 |  |
| Fixed income | 6,425 |  |  | 21,909 |  |  | — |  |  | 5,377 |  |  | 33,711 |  |
| Total pension plan assets | $ | 9,344 |  |  | $ | 22,842 |  |  | $ | 133 |  |  | $ | 5,377 |  |  | $ | 37,696 |  |

[0000889331-25-000039:notes:299]
The fair value measurement of plan assets using significant unobservable inputs (Level 3) changed during 2024 and 2023 due to the following:

[0000889331-25-000039:notes:300]
| (in thousands) | Level 3 |
| Balance at December 31, 2022 | $ | 328 |  |
| Level 3 assets transferred in from Level 1 and 2 assets valued at NAV: |  |
| Employer contribution | 2 |  |
| Actual return on assets | 15 |  |
| Benefits paid from the plan assets | (221) |  |
| Foreign currency adjustments | 9 |  |
| Balance at December 30, 2023 | $ | 133 |  |
| Level 3 assets transferred in from Level 1 and 2 assets valued at NAV: |  |
| Bulk annuity contract added during the year | 23,442 |  |
| Employer contribution | 2 |  |
| Actual return on assets | 4 |  |
| Foreign currency adjustments | (8) |  |
| Balance at December 28, 2024 | $ | 23,573 |  |

[0000889331-25-000039:notes:301]
Defined Contribution Plan

[0000889331-25-000039:notes:302]
The Company also maintains a 401(k) savings plan covering substantially all U.S. employees. The Company matches 100% of the employee’s annual contributions for the first 4% of the employee’s eligible compensation. The Company may provide an additional discretionary match to participants and made discretionary matches of 2% of the employee’s eligible compensation for each of the fiscal years ended December 28, 2024, December 30, 2023 and December 31, 2022. Employees are immediately vested in their contributions plus actual earnings thereon, as well as the Company contributions. Company matching contributions amounted to $6.5 million, $7.7 million, and $5.5 million in 2024, 2023, and 2022, respectively.

[0000889331-25-000039:notes:303]
Non-qualified Supplemental Retirement and Savings Plan

[0000889331-25-000039:notes:304]
The Company has a non-qualified Supplemental Retirement and Savings Plan which provides additional retirement benefits for certain management employees and named executive officers by allowing participants to defer a portion of their annual compensation. The Company maintains accounts for participants through which participants make investment elections. The investments are subject to the claims of the Company’s creditors and the Company is responsible for the payment of all benefits under the plan from its general assets. As of December 28, 2024, there was $23.3 million of marketable securities related to the plan included in Other long-term assets and $23.3 million of accrued compensation benefits included in Other long-term liabilities. The marketable securities are classified as Level 1 under the fair value hierarchy as they are maintained in mutual funds with readily determinable fair value. The Company made matching contributions to the plan of $0.5 million, $0.6 million, and $0.2 million in 2024, 2023, and 2022, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000889331-25-000039:notes:305]
Equity Plans: The Company has equity-based compensation plans authorizing the granting of stock options, restricted shares, restricted share units, and other stock rights to employees and directors. As of December 28, 2024, there were 1.0 million shares available for issuance of future awards under the Company’s equity-based compensation plans.

[0000889331-25-000039:notes:306]
Stock options generally vest over a three-year period and are exercisable over either a seven or ten-year period commencing from the date of the grant. Restricted shares and share units granted by the Company generally vest over three years. Stock options and restricted share units may have accelerated vesting upon meeting certain qualified conditions.

[0000889331-25-000039:notes:307]
The following table provides a reconciliation of outstanding stock options for the fiscal year ended December 28, 2024.

[0000889331-25-000039:notes:308]
|  | Shares UnderOption |  | WeightedAveragePrice |  | WeightedAverageRemainingContract Life(Years) |  | AggregateIntrinsicValue(000’s) |
| Outstanding December 30, 2023 | 598,357 |  |  | $ | 191.33 |  |  |  |  |  |
| Granted | 96,592 |  |  | 231.13 |  |  |  |  |  |
| Exercised | (64,437) |  |  | 165.01 |  |  |  |  |  |
| Forfeited | (700) |  |  | 242.47 |  |  |  |  |  |
| Outstanding December 28, 2024 | 629,812 |  |  | 200.07 |  |  | 3.6 |  | $ | 25,427 |  |
| Exercisable December 28, 2024 | 449,884 |  |  | 186.40 |  |  | 2.8 |  | 24,658 |  |

[0000889331-25-000039:notes:309]
The following table provides a reconciliation of non-vested restricted share and share unit awards ("RSU") for the fiscal year ended December 28, 2024.

[0000889331-25-000039:notes:310]
|  | Shares |  | Weighted Average Grant-Date Fair Value |
| Nonvested December 30, 2023 | 160,498 |  |  | $ | 237.09 |  |
| Granted | 104,905 |  |  | 225.92 |  |
| Vested | (75,258) |  |  | 240.37 |  |
| Forfeited | (4,132) |  |  | 232.69 |  |
| Nonvested December 28, 2024 | 186,013 |  |  | 229.56 |  |

[0000889331-25-000039:notes:311]
The total intrinsic value of options exercised during 2024, 2023, and 2022 was $6.3 million, $12.2 million, and $3.7 million, respectively. The total fair value of the vested RSU shares was $16.2 million, $19.8 million, and $15.4 million for 2024, 2023, and 2022, respectively. The total amount of share-based liabilities paid was $1.3 million, $2.2 million, and $1.1 million for 2024, 2023, and 2022, respectively.

[0000889331-25-000039:notes:312]
The Company recognizes compensation cost of all share-based awards as an expense on a straight-line basis over the vesting period of the awards. At December 28, 2024, the unrecognized compensation cost for options and restricted shares was $24.3 million before tax, and will be recognized over a weighted average period of 1.8 years. Compensation cost included as a component of cost of sales, research and development and selling, general, and administrative expenses for all equity compensation plans discussed above was $27.4 million, $25.7 million, and $24.6 million for 2024, 2023, and 2022, respectively. The total related income tax benefit recognized in the Consolidated Statements of Net Income was $4.0 million, $3.8 million, and $3.5 million for 2024, 2023, and 2022, respectively.

[0000889331-25-000039:notes:313]
The Company uses the Black-Scholes option valuation model to determine the fair value of stock option awards granted. The weighted average fair value of and related assumptions for options granted are as follows:

[0000889331-25-000039:notes:314]
|  | 2024 |  | 2023 |  | 2022 |
| Weighted average fair value of options granted | $75.25 |  | $77.40 |  | $70.39 |
| Assumptions: |  |  |  |  |  |
| Risk-free interest rate | 4.71% |  | 3.67% |  | 2.83% |
| Expected dividend yield | 1.13% |  | 1.00% |  | 0.92% |
| Expected stock price volatility | 34.9% |  | 36.0% |  | 35.0% |
| Expected life of options (years) | 4.4 |  | 4.4 |  | 4.4 |

[0000889331-25-000039:notes:315]
Expected volatilities are based on the historical volatility of the Company’s stock price. The expected life of options is based on historical data for options granted by the Company. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the expected life assumption. Historical nonvested forfeiture information is the basis for the forfeiture rate assumptions.

[0000889331-25-000039:notes:316]
The fair value of RSU is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period.

[0000889331-25-000039:notes:317]
Preferred Stock: The Board of Directors may authorize the issuance of preferred stock from time to time in one or more series with such designations, preferences, qualifications, limitations, restrictions, and optional or other special rights as the Board may fix by resolution.

[0000889331-25-000039:notes:318]
Share Repurchase Program

[0000889331-25-000039:notes:319]
The Company's Board of Directors authorized the repurchase of up to $300 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program. 
During the fiscal year of 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. There are $298.0 million of an authorized amount yet purchased under the 2024 program as of December 28, 2024. During the fiscal years of 2023 and 2022, the Company did not repurchase any shares of its common stock.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000889331-25-000039:notes:320]
Other Comprehensive Income (Loss)
Changes in other comprehensive income (loss) by component for fiscal years 2024, 2023, and 2022 were as follows:

[0000889331-25-000039:notes:321]
|  | Fiscal Year Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 31, 2022 |
| (in thousands) | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |  | Pre-tax |  | Tax |  | Net of tax |
| Defined benefit pension plan and other adjustments | $ | (2,947) |  |  | $ | 51 |  |  | $ | (2,896) |  |  | $ | (5,911) |  |  | $ | 491 |  |  | $ | (5,420) |  |  | $ | 11,560 |  |  | $ | (1,825) |  |  | $ | 9,735 |  |
| Cash flow hedges | (3,188) |  |  | 41 |  |  | (3,147) |  |  | (2,827) |  |  | 679 |  |  | (2,148) |  |  | 8,679 |  |  | (2,083) |  |  | 6,596 |  |
| Foreign currency translation adjustments (1) | (86,273) |  |  | 1,772 |  |  | (84,501) |  |  | 48,227 |  |  | (712) |  |  | 47,515 |  |  | (39,619) |  |  | 987 |  |  | (38,632) |  |
| Total change in other comprehensive income (loss) | $ | (92,408) |  |  | $ | 1,864 |  |  | $ | (90,544) |  |  | $ | 39,489 |  |  | $ | 458 |  |  | $ | 39,947 |  |  | $ | (19,380) |  |  | $ | (2,921) |  |  | $ | (22,301) |  |

[0000889331-25-000039:notes:322]
(1) The tax shown above within the foreign currency translation adjustments is the U.S. tax associated with the foreign currency translation adjustments of earnings of non-U.S. subsidiaries which have been previously taxed in the U.S. and are not permanently reinvested.

[0000889331-25-000039:notes:323]
Accumulated Other Comprehensive Loss (“AOCI”): The following table sets forth the changes in the components of AOCI by component for fiscal years 2024, 2023, and 2022:

[0000889331-25-000039:notes:324]
| (in thousands) | Pension and postretirement liability and reclassification adjustments |  | Cash flow hedges |  | Foreign currency translation adjustments |  | Accumulated other comprehensive income (loss) |
| Balance at January 1, 2022 | $ | (11,928) |  |  | $ | — |  |  | $ | (61,535) |  |  | $ | (73,463) |  |
| 2022 activity | 9,735 |  |  | 6,596 |  |  | (38,632) |  |  | (22,301) |  |
| Balance at December 31, 2022 | $ | (2,193) |  |  | $ | 6,596 |  |  | $ | (100,167) |  |  | $ | (95,764) |  |
| 2023 activity | (5,420) |  |  | (2,148) |  |  | 47,515 |  |  | 39,947 |  |
| Balance at December 30, 2023 | $ | (7,613) |  |  | $ | 4,448 |  |  | $ | (52,652) |  |  | $ | (55,817) |  |
| 2024 activity | (2,896) |  |  | (3,147) |  |  | (84,501) |  |  | (90,544) |  |
| Balance at December 28, 2024 | $ | (10,509) |  |  | $ | 1,301 |  |  | $ | (137,153) |  |  | $ | (146,361) |  |

[0000889331-25-000039:notes:325]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $23 million, representing approximately 33% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0000889331-25-000039:notes:326]
Due to the signing of the group annuity contract for the U.K. pension plan, the liabilities of the plan were remeasured as of October 4, 2024 resulting in an increase of $3.8 million to unamortized actuarial loss within other comprehensive income (loss). See Note 11, Benefits Plans for further discussion.

[0000889331-25-000039:notes:327]
Amounts reclassified from accumulated other comprehensive loss to earnings for fiscal years 2024, 2023, and 2022 were as follows:

[0000889331-25-000039:notes:328]
|  |  | Fiscal Year Ended |
| (in thousands) |  | December 28, 2024 |  | December 30, 2023 |  | December 31, 2022 |
| Pension and postemployment and other plans: |  |  |  |  |  |  |
| Amortization of prior service, net actuarial loss (gain), and other |  | $ | 3,441 |  |  | $ | (43) |  |  | $ | 785 |  |
| Net settlement loss and accelerated prior service costs |  | 299 |  |  | 247 |  |  | 477 |  |
| Total |  | $ | 3,740 |  |  | $ | 204 |  |  | $ | 1,262 |  |

[0000889331-25-000039:notes:329]
The Company recognizes the amortization of prior service costs and net settlement loss in Restructuring, impairment, and other charges and Other (income) expense, net within the Consolidated Statements of Net Income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000889331-25-000039:notes:330]
The Company elected to pay the 2017 Littelfuse Toll Charge over the eight-year period prescribed by the Tax Act. The anticipated 2025 annual installment payment of this Toll Charge of $8.2 million, which represents the eighth and final required installment, is included in Accrued income taxes, on the Consolidated Balance Sheet as of December 28, 2024.

[0000889331-25-000039:notes:331]
Domestic and foreign income (loss) before income taxes is as follows:

[0000889331-25-000039:notes:332]
| (in thousands) | 2024 |  | 2023 |  | 2022 |
| Domestic | $ | 3,151 |  |  | $ | 40,571 |  |  | $ | 32,462 |  |
| Foreign | 148,712 |  |  | 288,027 |  |  | 410,582 |  |
| Income before income taxes | $ | 151,863 |  |  | $ | 328,598 |  |  | $ | 443,044 |  |

[0000889331-25-000039:notes:333]
Federal, state, and foreign income tax expense (benefit) consists of the following:

[0000889331-25-000039:notes:334]
| (in thousands) | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |
| Federal | $ | (5,881) |  |  | $ | 8,188 |  |  | $ | 12,423 |  |
| State | 1,826 |  |  | 2,880 |  |  | 2,183 |  |
| Foreign | 58,551 |  |  | 57,999 |  |  | 77,551 |  |
| Subtotal | $ | 54,496 |  |  | $ | 69,067 |  |  | $ | 92,157 |  |
| Deferred: |  |  |  |  |  |
| Federal and State | $ | 4,091 |  |  | $ | 1,751 |  |  | $ | (9,182) |  |
| Foreign | (6,914) |  |  | (1,705) |  |  | (13,237) |  |
| Subtotal | $ | (2,823) |  |  | $ | 46 |  |  | $ | (22,419) |  |
| Provision for income taxes | $ | 51,673 |  |  | $ | 69,113 |  |  | $ | 69,738 |  |

[0000889331-25-000039:notes:335]
A reconciliation between income taxes computed on income before income taxes at the federal statutory rate and the provision for income taxes is provided below:

[0000889331-25-000039:notes:336]
| (in thousands) | 2024 |  | 2023 |  | 2022 |
| Tax expense at statutory rate of 21% | $ | 31,891 |  |  | $ | 69,006 |  |  | $ | 93,039 |  |
| Non-U.S. income tax rate differential | (1,130) |  |  | (25,623) |  |  | (41,731) |  |
| Non-U.S. losses and expenses with no tax benefit | 9,401 |  |  | 11,261 |  |  | 10,660 |  |
| Tax on unremitted earnings | 6,616 |  |  | 6,394 |  |  | 10,870 |  |
| Tax impact of non-deductible goodwill impairment charge | 5,810 |  |  | — |  |  | — |  |
| Net impact associated with U.S. tax on non-U.S. income, including GILTI | 5,809 |  |  | 4,739 |  |  | 2,546 |  |
| State and local taxes, net of federal tax benefit | 2,533 |  |  | 1,503 |  |  | 215 |  |
| Certain changes in unrecognized tax benefits and related accrued interest | (8,692) |  |  | (172) |  |  | 1,839 |  |
| One-time tax deductions for stock of subsidiaries | — |  |  | — |  |  | (11,495) |  |
| Other, net | (565) |  |  | 2,005 |  |  | 3,795 |  |
| Provision for income taxes | $ | 51,673 |  |  | $ | 69,113 |  |  | $ | 69,738 |  |

[0000889331-25-000039:notes:337]
Deferred income taxes are provided for the tax effects of temporary differences between the financial reporting bases and the tax bases of the Company’s assets and liabilities. Significant components of the Company’s deferred tax assets and liabilities at December 28, 2024 and December 30, 2023, are as follows:

[0000889331-25-000039:notes:338]
| (in thousands) | 2024 |  | 2023 |
| Deferred tax assets: |  |  |  |
| Net operating loss carryforwards | $ | 46,263 |  |  | $ | 36,941 |  |
| Interest expense carryforwards | 34,800 |  |  | 34,205 |  |
| Accrued expenses and reserves | 32,336 |  |  | 39,299 |  |
| Capitalized expenses | 18,939 |  |  | 16,872 |  |
| Lease liabilities | 13,016 |  |  | — |  |
| U.S. foreign tax credit carryforwards | 3,490 |  |  | 3,561 |  |
| U.S. research and other general business tax credit carryforwards | 1,252 |  |  | 1,468 |  |
| Other | 196 |  |  | — |  |
| Deferred tax assets | 150,292 |  |  | 132,346 |  |
| Less: Valuation allowance | (55,468) |  |  | (41,542) |  |
| Total deferred tax assets | 94,824 |  |  | 90,804 |  |
| Deferred tax liabilities: |  |  |  |
| Excess of book basis over the tax basis for intangible assets and goodwill | 133,701 |  |  | 148,659 |  |
| Excess of book basis over the tax basis for property, plant, and equipment | 24,238 |  |  | 22,570 |  |
| Tax on unremitted earnings | 14,612 |  |  | 18,621 |  |
| Right of use lease assets | 12,906 |  |  | — |  |
| Unrealized foreign currency exchange gains | — |  |  | 1,288 |  |
| Total deferred tax liabilities | 185,457 |  |  | 191,138 |  |
| Net deferred tax liabilities | $ | 90,633 |  |  | $ | 100,334 |  |

[0000889331-25-000039:notes:339]
The deferred tax asset valuation allowance is mainly related to certain U.S. and non-U.S. net operating loss and non-U.S. interest expense carryforwards which are not more likely that not to be realized. The remaining U.S. and non-U.S. net operating loss and interest expense carryforwards either have no expiration date or are expected to be utilized prior to expiration (which begin expiring in 2025). No deferred tax asset nor valuation allowance has been recorded for certain U.S. and non-U.S. net operating loss carryforwards for which the possibility of usage has been determined to be remote.

[0000889331-25-000039:notes:340]
The Company paid income taxes of $88.1 million, $81.1 million, and $96.8 million in 2024, 2023, and 2022, respectively, and received income tax refunds of $4.3 million, $7.2 million, and $3.2 million in 2024, 2023, and 2022, respectively.

[0000889331-25-000039:notes:341]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those subsidiaries for which such excess is considered to be permanently reinvested in those operations. The Company believes the determination of the amount of such deferred income taxes is impractical as it would depend upon income tax laws and circumstances at the time of the hypothetical distributions or dispositions. As of December 28, 2024, unremitted earnings of the Company’s non-U.S. subsidiaries were approximately $1.5 billion. A distribution of such earnings will generally not be subject to U.S. federal income tax. The Company recognized deferred tax liabilities of $14.6 million as of December 28, 2024 and $18.6 million as of December 30, 2023, related to taxes on certain non-U.S. earnings which are not considered to be permanently reinvested.

[0000889331-25-000039:notes:342]
The Company has two subsidiaries in China which benefit from lower tax rates due to “tax holidays” which apply for three-year periods. The tax holiday for one of the subsidiaries expired at the end of 2023, but was later extended for an additional three years, retroactive to include all of 2024, as well as 2025 and 2026, and for the other subsidiary the tax holiday will expire at the end of 2025. Together, the tax holidays contributed $5.0 million in tax benefits, or $0.20 per diluted share, during 2024. Future year tax benefits will depend upon the Company’s ability to obtain extensions, after the three-year periods expire. There can be no assurance that future extensions will be granted.

[0000889331-25-000039:notes:343]
A reconciliation of the beginning and ending amount of unrecognized tax benefits as of December 28, 2024, December 30, 2023, and December 31, 2022 is as follows:

[0000889331-25-000039:notes:344]
| (in thousands) | Unrecognized Tax Benefits |
| Balance at December 31, 2022 | $ | 30,374 |  |
| Additions for tax positions related to pre-acquisition periods of acquired subsidiaries | 1,975 |  |
| Additions for tax positions taken in the current year | 1,200 |  |
| Decreases for tax positions taken in the prior year | (792) |  |
| Decreases for lapses in statute of limitations | (1,051) |  |
| Decreases for settlements | (215) |  |
| Other | (42) |  |
| Balance at December 30, 2023 | $ | 31,449 |  |
| Additions for tax positions taken in the current year | 1,251 |  |
| Additions for tax positions taken in the prior year | 375 |  |
| Decreases for lapses in statute of limitations | (7,650) |  |
| Other | 574 |  |
| Balance at December 28, 2024 | $ | 25,999 |  |

[0000889331-25-000039:notes:345]
The December 28, 2024 total in the table above represents the net amount of tax benefits that, if recognized, would favorably affect the effective tax rate in future periods. Of this amount, approximately $6.3 million may be recognized in 2025 based upon the possible lapse in the statute of limitations. None of the positions included in unrecognized tax benefits are related to tax positions for which the ultimate deductibility is highly certain, but for which there is uncertainty about the timing of such deductibility.

[0000889331-25-000039:notes:346]
The Company recognizes accrued interest and penalties associated with uncertain tax positions as part of income tax expense. The Company recognized such interest benefit of $2.7 million (including a $4.1 million decrease due to a lapse in the statute of limitations), $0.5 million expense (net of a $1.7 million decrease due to a lapse in the statute of limitations) and $1.4 million expense (net of a $0.2 million decrease due to a lapse in the statute of limitations) in 2024, 2023, and 2022, respectively. Accrued interest for such matters included in Other long-term liabilities within the Consolidated Balance Sheets was $11.1 million and $14.4 million as of December 28, 2024 and December 30, 2023, respectively.

[0000889331-25-000039:notes:347]
The U.S. federal statute of limitations remains open for the Company for the 2018 tax year and later years. Non-U.S. and U.S. state statutes of limitations generally range from three to seven years, although certain jurisdictions do not have a statute expiration. Tax examinations occur from time to time, including examinations currently in process in Italy, Germany, the Netherlands, Singapore, other non-U.S. jurisdictions and certain U.S. states. The Company does not expect to recognize a significant amount of additional tax expense as a result of concluding these examinations.


## us-gaap:EarningsPerShareTextBlock

[0000889331-25-000039:notes:348]
Earnings Per Share

[0000889331-25-000039:notes:349]
The following table sets forth the computation of basic and diluted earnings per share:

[0000889331-25-000039:notes:350]
| (in thousands, except per share amounts) | 2024 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |
| Net income as reported | $ | 100,190 |  |  | $ | 259,485 |  |  | $ | 373,306 |  |
| Denominator: |  |  |  |  |  |
| Weighted average shares outstanding |  |  |  |  |  |
| Basic | 24,821 |  |  | 24,854 |  |  | 24,734 |  |
| Effect of dilutive securities | 218 |  |  | 248 |  |  | 252 |  |
| Diluted | 25,039 |  |  | 25,102 |  |  | 24,986 |  |
| Earnings Per Share: |  |  |  |  |  |
| Basic earnings per share | $ | 4.04 |  |  | $ | 10.44 |  |  | $ | 15.09 |  |
| Diluted earnings per share | $ | 4.00 |  |  | $ | 10.34 |  |  | $ | 14.94 |  |

[0000889331-25-000039:notes:351]
Potential shares of common stock attributable to stock options and restricted shares excluded from the earnings per share calculation because their effect would be anti-dilutive were 139,839, 110,002, and 87,425 shares in 2024, 2023, and 2022, respectively.
During the fiscal year of 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. There are $298.0 million of an authorized amount not yet purchased under the 2024 program as of December 28, 2024. During the fiscal years of 2023 and 2022, the Company did not repurchase any shares of its common stock.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000889331-25-000039:notes:352]
Segment Information

[0000889331-25-000039:notes:353]
The Company and its subsidiaries design, manufacture and sell component, modules and subassemblies to empower the long-term structural themes of sustainability, connectivity and safety. The Company aggregated its operating segments into the reportable segments: Electronics, Transportation, and Industrial. An operating segment is defined as a component of an enterprise that engages in business activities from which it may earn revenues and incur expenses, and about which separate financial information is regularly evaluated by the Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources. The CODM is the Company’s President and Chief Executive Officer (“CEO”). The CODM allocates resources to and assesses the performance of each operating segment using information about its revenue and operating income (loss) before interest and taxes, but does not evaluate the operating segments using discrete balance sheet information and as such, segment asset information is not disclosed. The CODM’s key decisions involve the allocation of resources, such as acquisitions, divestitures, investments, capital expenditures, significant customer contracts, and other key management resources, and assessment of performance, such as executive officer hiring, promotion, and compensation. The CODM uses operating income as the key metric when establishing targets in the annual budget and in evaluating the allocation of resources to each segment. The CODM regularly reviews each segment's operating income against the forecast, budget and previous quarterly results to assess performance and make decisions about the allocation of operating and capital resources to each segment.

[0000889331-25-000039:notes:354]
Sales, marketing, and research and development expenses are charged directly into each operating segment. Finance, information technology, and human resources are shared functions that are allocated back to the operating segments. The Company does not report inter-segment revenue because the operating segments do not record it. Certain expenses, determined by the CODM to be strategic in nature and not directly related to segments current results, are not allocated but identified as “Other.” Additionally, the Company does not allocate interest and other income, interest expense, or taxes to operating segments. These costs are not allocated to the segments, as management excludes such costs when assessing the performance of the segments. Except as discussed above, the accounting policies for segment reporting are the same as for the Company as a whole.

[0000889331-25-000039:notes:355]
•Electronics Segment: Consists of one of the broadest product offerings in the industry, including fuses and fuse accessories, positive temperature coefficient (“PTC”) resettable fuses, electromechanical switches and interconnect solutions, polymer electrostatic discharge (“ESD”) suppressors, varistors, reed switch based magnetic sensing, gas discharge tubes; semiconductor products such as discrete transient voltage suppressor (“TVS”) diodes, TVS diode arrays, protection and switching thyristors, silicon and silicon carbide metal-oxide-semiconductor field effect transistors (“MOSFETs”) and diodes, and insulated gate bipolar transistors (“IGBT”) technologies. The segment covers a broad range of end markets, including industrial motor drives and power conversion, automotive electronics, electric vehicle and related charging infrastructure, aerospace, power supplies, data centers and telecommunications, medical devices, alternative energy and energy storage, building and home automation, appliances, and mobile electronics.

[0000889331-25-000039:notes:356]
•Transportation Segment: Consists of a wide range of circuit protection, power control and sensing technologies for global original equipment manufacturers (“OEMs”), Tier-one suppliers and parts and aftermarket distributors in passenger vehicles, heavy-duty truck and bus, off-road and recreational vehicles, material handling equipment, agricultural machinery, construction equipment and other commercial vehicle end markets. Passenger vehicle products are used in internal combustion engines, hybrid and electric vehicles including blade fuses, battery cable protectors, resettable fuses, high-current fuses, high-voltage fuses, and sensor products designed to monitor the occupant’s safety and environment as well as the vehicle’s powertrain. Commercial vehicle products include fuses, switches, circuit breakers, relays, and power distribution modules and units used in applications serving a number of end markets, including heavy-duty truck and bus, construction, agriculture, material handling and marine.

[0000889331-25-000039:notes:357]
•Industrial Segment: Consists of industrial circuit protection (industrial fuses), protective and monitoring relays (protection relays, residual current devices and monitors, ground fault circuit interrupters, solid state switches, and arc fault detection devices), and industrial controls and sensors (contactors, transformers, and temperature sensors) for use in various applications such as renewable energy and energy storage systems, industrial safety, factory automation, electric vehicle charging infrastructure, HVAC systems, non-residential construction, MRO, and mining.

[0000889331-25-000039:notes:358]
The Company has provided this segment information for all comparable prior periods. Segment information is summarized as follows:

[0000889331-25-000039:notes:359]
| (in thousands) | 2024 |  | 2023 |  | 2022 |
| Net sales |  |  |  |  |  |
| Electronics | $ | 1,186,773 |  |  | $ | 1,350,426 |  |  | $ | 1,492,819 |  |
| Transportation | 672,434 |  |  | 678,278 |  |  | 716,140 |  |
| Industrial | 331,561 |  |  | 333,953 |  |  | 304,938 |  |
| Total net sales | $ | 2,190,768 |  |  | $ | 2,362,657 |  |  | $ | 2,513,897 |  |
| Other segment expenses |  |  |  |  |  |
| Electronics | $ | 1,016,880 |  |  | $ | 1,049,845 |  |  | $ | 1,061,203 |  |
| Transportation | 613,856 |  |  | 644,644 |  |  | 652,601 |  |
| Industrial | 289,230 |  |  | 279,153 |  |  | 256,085 |  |
| Total other segment expenses | $ | 1,919,966 |  |  | $ | 1,973,642 |  |  | $ | 1,969,889 |  |
| Segment operating income |  |  |  |  |  |
| Electronics | $ | 169,893 |  |  | $ | 300,581 |  |  | $ | 431,616 |  |
| Transportation | 58,578 |  |  | 33,634 |  |  | 63,539 |  |
| Industrial | 42,331 |  |  | 54,800 |  |  | 48,853 |  |
| Total segment operating income | 270,802 |  |  | 389,015 |  |  | 544,008 |  |
| Other(a) | (112,022) |  |  | (28,153) |  |  | (43,182) |  |
| Total operating income | 158,780 |  |  | 360,862 |  |  | 500,826 |  |
| Interest expense | 38,717 |  |  | 39,866 |  |  | 26,216 |  |
| Foreign exchange (gain) loss | (9,230) |  |  | 12,299 |  |  | 24,359 |  |
| Other (income) expense, net | (22,570) |  |  | (19,901) |  |  | 7,207 |  |
| Income before income taxes | $ | 151,863 |  |  | $ | 328,598 |  |  | $ | 443,044 |  |

[0000889331-25-000039:notes:360]
(a) Included in “Other” Operating income for 2024 was $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0000889331-25-000039:notes:361]
Included in “Other” Operating income for 2023 was 11.7 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions and $11.6 million of restructuring, impairment and other charges, primarily related to employee termination costs. During 2023, the Company recorded a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment, $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment related to certain machinery and equipment in the semiconductor business within the Electronics segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-25-000039:notes:362]
Included in “Other” Operating income for 2022 was $17.6 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $15.6 million of purchase accounting inventory step-up charges, and

[0000889331-25-000039:notes:363]
$10.0 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $2.9 million non-cash impairment charge for certain acquired technology and patent intangible assets due to a change in use and projected cash flows within the Electronics segment in the fourth quarter of 2022. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. In addition, there was a gain of $5.0 million recorded for the sale of buildings within the Electronics segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0000889331-25-000039:notes:364]
Other segment operating expenses include cost of sales, selling, general, and administration expenses, and research and development expenses. Other segment expenses are reconciled to the operating income of each segment. The CODM regularly assesses the performance of each operating segment focusing on each operating segment’s revenue and operating income.

[0000889331-25-000039:notes:365]
The Company’s depreciation and amortization expenses by segment for the fiscal years ended 2024, 2023, and 2022 are as follows:

[0000889331-25-000039:notes:366]
| (in thousands) | 2024 |  | 2023 |  | 2022 |
| Depreciation |  |  |  |  |  |
| Electronics | $ | 40,456 |  |  | $ | 39,461 |  |  | $ | 35,496 |  |
| Transportation | 22,117 |  |  | 26,732 |  |  | 25,647 |  |
| Industrial | 5,752 |  |  | 5,441 |  |  | 3,868 |  |
| Total depreciation | $ | 68,325 |  |  | $ | 71,634 |  |  | $ | 65,011 |  |
| Amortization |  |  |  |  |  |
| Electronics | $ | 39,362 |  |  | $ | 39,883 |  |  | $ | 32,698 |  |
| Transportation | 13,518 |  |  | 15,782 |  |  | 18,109 |  |
| Industrial | 9,247 |  |  | 10,129 |  |  | 4,888 |  |
| Total amortization | $ | 62,127 |  |  | $ | 65,794 |  |  | $ | 55,695 |  |

[0000889331-25-000039:notes:367]
The Company’s net sales classified according to the country where the customer is located, net property, plant, and equipment and additions to net property, plant, and equipment by country for the fiscal years ended 2024, 2023, and 2022 are as follows:

[0000889331-25-000039:notes:368]
| (in thousands) | 2024 |  | 2023 |  | 2022 |
| Net sales |  |  |  |  |  |
| U.S. | $ | 800,331 |  |  | $ | 820,735 |  |  | $ | 912,498 |  |
| China | 506,643 |  |  | 546,786 |  |  | 638,978 |  |
| Other countries(a) | 883,794 |  |  | 995,136 |  |  | 962,421 |  |
| Total net sales | $ | 2,190,768 |  |  | $ | 2,362,657 |  |  | $ | 2,513,897 |  |
| Long-lived assets |  |  |  |  |  |
| U.S. | $ | 74,698 |  |  | $ | 73,126 |  |  | $ | 76,325 |  |
| China | 132,504 |  |  | 139,736 |  |  | 129,094 |  |
| Mexico | 89,558 |  |  | 102,218 |  |  | 107,119 |  |
| Germany | 58,758 |  |  | 47,217 |  |  | 39,635 |  |
| Philippines | 66,174 |  |  | 73,217 |  |  | 77,240 |  |
| Other countries | 55,376 |  |  | 57,639 |  |  | 51,697 |  |
| Total long-lived assets | $ | 477,068 |  |  | $ | 493,153 |  |  | $ | 481,110 |  |
| Additions to long-lived assets |  |  |  |  |  |
| U.S. | $ | 19,081 |  |  | $ | 9,502 |  |  | $ | 14,603 |  |
| China | 16,045 |  |  | 32,805 |  |  | 35,297 |  |
| Mexico | 10,181 |  |  | 13,920 |  |  | 26,514 |  |
| Germany | 19,972 |  |  | 10,279 |  |  | 5,255 |  |
| Philippines | 4,383 |  |  | 6,156 |  |  | 14,847 |  |
| Other countries | 8,751 |  |  | 10,992 |  |  | 7,678 |  |
| Total additions to long-lived assets | $ | 78,413 |  |  | $ | 83,654 |  |  | $ | 104,194 |  |

[0000889331-25-000039:notes:369]
(a)Each country included in other countries are less than 10% of net sales.

[0000889331-25-000039:notes:370]
For the year ended December 28, 2024, approximately 63% of the Company’s net sales were to customers outside the U.S. (exports and foreign operations), including approximately 23% to China. For the year ended December 30, 2023, approximately 65% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 23% to China. For the year ended December 31, 2022, approximately 64% of the Company's net sales were to customers outside the U.S. (exports and foreign operations), including approximately 25% to China. Sales to Arrow Electronics, Inc., which were included in the Electronics, Transportation, and Industrial segments, were 9.4%, 11.2%, and 11.5% of consolidated net sales in 2024, 2023, and 2022 respectively. No other single customer accounted for more than 10% of net sales during the last three years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000889331-25-000039:notes:371]
Commitments and Contingencies
Off-Balance Sheet Arrangements

[0000889331-25-000039:notes:372]
As of December 28, 2024, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0000889331-25-000039:notes:373]
Product Warranty Liabilities

[0000889331-25-000039:notes:374]
The Company's policy is to accrue for warranty claims when a loss is both probable and estimable. Liabilities for warranty claims have historically not been material and in limited instances, customers may make claims for costs they incurred or other damages related to a claim.

[0000889331-25-000039:notes:375]
The Company carries insurance for potential product liability claims at coverage levels based on the Company's prior claims experience. This coverage is subject to deductibles, and various terms and conditions. The Company cannot assure that the level of coverage will be sufficient to cover every possible claim that can arise in its businesses, now or in the future, or that such coverage always will be available should the Company, now or in the future, wish to extend, increase or otherwise adjust its insurance.

[0000889331-25-000039:notes:376]
The Company has been notified by one of its customers of a product recall potentially due to certain fuses provided by Littelfuse and incorporated in such products. The Company is currently working with its customer to investigate the cause and level of responsibility for this recall. The Company has determined pursuant to ASC 450, "Contingencies", that a loss is reasonably possible. However, the Company continues to evaluate this matter and the ultimate costs of the recall and range of the potential loss cannot be determined at this time. Accordingly, no accrual has been made yet for this matter. Factors that will impact the amount of such losses include the per vehicle cost of fuse replacement, the determination of the relative liability among the customer, the Company, and any relevant third parties, as well as actual insurance recoveries.

[0000889331-25-000039:notes:377]
Environmental Remediation Liabilities

[0000889331-25-000039:notes:378]
Refer to Note 1: Summary of Significant Accounting Policies and Other Information related to environmental liabilities. Our operations and facilities are subject to U.S. and non-U.S. laws and regulations governing the protection of the environment and our employees, including those governing air emissions, chemical usage, water discharges, the management and disposal of hazardous substances and wastes, and the cleanup of contaminated sites. We could incur significant costs, including cleanup costs, fines, civil or criminal sanctions, or third-party property damage or personal injury claims, in the event of violations or liabilities under these laws and regulations, or non-compliance with the environmental permits required at our facilities. Potentially significant expenditures could be required in order to comply with environmental laws that may be adopted or imposed in the future. We are, however, not aware of any threatened or pending material environmental investigations, lawsuits, or claims involving the Company or its operations.

[0000889331-25-000039:notes:379]
Legal Proceedings

[0000889331-25-000039:notes:380]
In the ordinary course of business, the Company may be involved in a number of claims and litigation matters. While it is not feasible to predict the outcome of these matters, based upon our experience and current information known to us, we do not expect the outcome of these matters, either individually or in the aggregate, to have a material adverse effect on our results of operations, financial position, and/or cash flows.

[0000889331-25-000039:notes:381]
The Company accounts for litigation and claims losses in accordance with FASB ASC Topic 450, Contingencies where loss contingency provisions are recognized for probable and estimable losses at our best estimate of a loss or, when a best estimate cannot be made, at our estimate of the minimum loss. These estimates require the application of considerable judgment and are refined each accounting period as additional information becomes known. We are often initially unable to develop a best estimate of loss and therefore the minimum amount, which could be an immaterial amount, is recognized. As information becomes known, either the minimum loss amount is increased, or a best estimate can be made, resulting in additional loss provisions. A best estimate may be changed to a lower amount when events result in an expectation of a more favorable outcome than previously expected.

[0000889331-25-000039:notes:382]
Pending Litigation and Claims

[0000889331-25-000039:notes:383]
There are no material pending litigation or claims outstanding as of December 28, 2024.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000889331-25-000039:notes:384]
Related Party Transactions

[0000889331-25-000039:notes:385]
As a result of the Company’s acquisition of IXYS, the Company has equity ownerships in various investments that are accounted for under the equity method. The following is a description of the investments and related party transactions.

[0000889331-25-000039:notes:386]
Powersem GmbH: The Company owns 45% of the outstanding equity of Powersem GmbH (“Powersem”), a module manufacturer based in Germany.

[0000889331-25-000039:notes:387]
EB-Tech Co., Ltd.: The Company owns approximately 15% of the outstanding equity of EB-Tech Co., Ltd. (“EB Tech”), a company with expertise in radiation technology based in South Korea.

[0000889331-25-000039:notes:388]
Automated Technology (Phil), Inc.: The Company owns approximately 24% of the outstanding common shares of Automated Technology (Phil), Inc. (“ATEC”), a supplier located in the Philippines that provides assembly and test services. One member of the Company's executive officers serves on the Board of Directors of ATEC.

[0000889331-25-000039:notes:389]
|  | Fiscal Year Ended |
|  | December 28, 2024 |  | December 30, 2023 |
| (in millions) | Powersem |  | EB Tech |  | ATEC |  | Powersem |  | EB Tech |  | ATEC |
| Sales to related party | $ | 1.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.1 |  |  | $ | — |  |  | $ | — |  |
| Purchase of material/services from related party | 3.8 |  |  | 0.7 |  |  | 5.7 |  |  | 4.3 |  |  | 0.4 |  |  | 9.0 |  |
| Accounts payable balance | $ | 0.7 |  |  | $ | 0.1 |  |  | $ | 0.7 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 1.0 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000889331-25-000039:notes:390]
SCHEDULE II

[0000889331-25-000039:notes:391]
VALUATION AND QUALIFYING ACCOUNTS AND RESERVES

[0000889331-25-000039:notes:392]
| Description | Balance atBeginningof Year |  | Charged toCosts andExpenses (a) |  | Deductions (b) |  | Other (c) |  | Balance atEndof Year |
| (in thousands) |  |  |  |  |  |  |  |  |  |
| Fiscal year ended December 28, 2024 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 2,187 |  |  | $ | (182) |  |  | $ | (345) |  |  | $ | (71) |  |  | $ | 1,589 |  |
| Reserves for sales discounts and allowances | $ | 82,509 |  |  | $ | 138,735 |  |  | $ | (151,946) |  |  | $ | (897) |  |  | $ | 68,401 |  |
| Fiscal year ended December 30, 2023 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 1,575 |  |  | $ | 519 |  |  | $ | (181) |  |  | $ | 274 |  |  | $ | 2,187 |  |
| Reserves for sales discounts and allowances | $ | 81,987 |  |  | $ | 186,021 |  |  | $ | (186,043) |  |  | $ | 544 |  |  | $ | 82,509 |  |
| Fiscal year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses on accounts receivable | $ | 1,910 |  |  | $ | 166 |  |  | $ | (222) |  |  | $ | (279) |  |  | $ | 1,575 |  |
| Reserves for sales discounts and allowances | $ | 57,322 |  |  | $ | 184,201 |  |  | $ | (158,499) |  |  | $ | (1,037) |  |  | $ | 81,987 |  |

[0000889331-25-000039:notes:393]
(a)Includes provision for credit losses, sales returns and sales discounts granted to customers.

[0000889331-25-000039:notes:394]
(b)Represents uncollectible accounts written off, net of recoveries and credits issued to customers.

[0000889331-25-000039:notes:395]
(c)Represents business acquisitions and foreign currency translation adjustments.
