# LFUS 10-K controls and the auditor's report


## auditors_report

[0000889331-25-000039:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000889331-25-000039:auditors_report:2]
Board of Directors and Shareholders

[0000889331-25-000039:auditors_report:3]
Littelfuse, Inc.

[0000889331-25-000039:auditors_report:4]
Opinion on the financial statements

[0000889331-25-000039:auditors_report:5]
We have audited the accompanying consolidated balance sheet of Littelfuse, Inc. and subsidiaries (the “Company”) as of December 28, 2024, the related consolidated statements of net income, comprehensive income, equity, and cash flows, for the period ended December 28, 2024, and the related notes and financial statement schedule included under Item 15(a) (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 28, 2024, and the results of its operations and its cash flows for the period ended December 28, 2024, in conformity with accounting principles generally accepted in the United States of America.

[0000889331-25-000039:auditors_report:6]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of  December 28, 2024, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated March 13, 2025, expressed an adverse opinion on the Company's internal control over financial reporting because of material weaknesses.

[0000889331-25-000039:auditors_report:7]
Basis for opinion

[0000889331-25-000039:auditors_report:8]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000889331-25-000039:auditors_report:9]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0000889331-25-000039:auditors_report:10]
Critical audit matter

[0000889331-25-000039:auditors_report:11]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000889331-25-000039:auditors_report:12]
Goodwill and Other Intangible Assets– Refer to Notes 1 and 5 to the financial statements

[0000889331-25-000039:auditors_report:13]
Critical Audit Matter Description

[0000889331-25-000039:auditors_report:14]
The Company’s evaluation of goodwill for impairment involves the comparison of the fair value of each reporting unit to its carrying value. The Company engages a third-party appraisal firm to assist in the Company’s determination of the estimated fair values for each reporting unit. This determination includes estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping.

[0000889331-25-000039:auditors_report:15]
The Company evaluates the recoverability of other long-lived assets, including certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset group may not be recoverable. When the Company determines that the carrying value of long-lived assets may not be recoverable, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition.

[0000889331-25-000039:auditors_report:16]
We identified the valuation of goodwill and the acquired customer relationships intangible asset within the Industrial controls and sensors reporting unit (“reporting unit”) as a critical audit matter because of the reporting unit’s historical performance as compared to projections and because of the significant judgments made by management to estimate the respective fair values. This required a high degree of auditor judgment and an increased extent of effort, including the need to involve our fair value specialists, when auditing management’s judgments related to (1) forecasts of revenue and earnings before interest, taxes, and amortization (“EBITA”), the selection of the peer group companies and associated market multiples, and the selection of the discount rate in estimating the fair value of the reporting unit, and related to (2) the forecast of revenue and the selection of the discount rate in estimating the fair value of the customer relationships intangible asset.

[0000889331-25-000039:auditors_report:17]
How the Critical Audit Matter Was Addressed in the Audit

[0000889331-25-000039:auditors_report:18]
Our audit procedures related to (1) the Company’s forecasts of revenue and EBITA, the selection of the peer group companies and associated market multiples, and the selection of the discount rate used by management to estimate the fair value of the reporting unit and (2) the forecast of revenue and the selection of the discount rate in estimating the fair value of the customer relationship intangible asset, included the following, among others:

[0000889331-25-000039:auditors_report:19]
•We tested the design and operating effectiveness of controls over the annual goodwill impairment assessment and the customer relationships intangible asset impairment assessment, including those over (1) the preparation of the revenue and EBITA forecasts, the selection of peer group companies and associated market multiples, and the selection of the discount rate to estimate the fair value of the reporting unit and (2) the preparation of the revenue forecast and the selection of the discount rate to estimate the fair value of the customer relationship intangible asset.

[0000889331-25-000039:auditors_report:20]
•We evaluated management’s ability to accurately forecast revenue and EBITA (“forecasts”) by comparing actual results to management’s historical forecasts.

[0000889331-25-000039:auditors_report:21]
•We evaluated the reasonableness of management’s forecasts by comparing the forecasts to:

[0000889331-25-000039:auditors_report:22]
◦Internal communications to management and the Board of Directors.

[0000889331-25-000039:auditors_report:23]
◦Historical results, third-party economic research, industry performance, and peer company performance.

[0000889331-25-000039:auditors_report:24]
◦Actual results from the September 29, 2024, annual measurement date to December 28, 2024.

[0000889331-25-000039:auditors_report:25]
•We performed sensitivity analyses to evaluate changes to both impairment tests if key assumptions are changed.

[0000889331-25-000039:auditors_report:26]
•With the assistance of our fair value specialists, for the customer relationships intangible asset impairment assessment, we assessed the reasonableness of the valuation methodology and the discount rate, by:

[0000889331-25-000039:auditors_report:27]
◦Evaluating whether the fair value model being used is appropriate considering the Company’s circumstances and valuation premise identified.

[0000889331-25-000039:auditors_report:28]
◦Developing a range of independent estimates and comparing those to the discount rate selected by management.

[0000889331-25-000039:auditors_report:29]
◦Testing the underlying source information and mathematical accuracy of the calculations.

[0000889331-25-000039:auditors_report:30]
•With the assistance of our fair value specialists, for the goodwill impairment assessment we evaluated the reasonableness of the (1) valuation methodology, (2) peer group companies and resulting market multiples, and (3) the discount rate, by:

[0000889331-25-000039:auditors_report:31]
◦Evaluating whether the fair value model being used is appropriate considering the Company’s circumstances and valuation premise identified.

[0000889331-25-000039:auditors_report:32]
◦Evaluating the market multiples by considering the reasonableness of the selected peer group companies and comparing the multiples selected by management to management’s identified peer group companies.

[0000889331-25-000039:auditors_report:33]
◦Developing a range of independent estimates and comparing those to the discount rate selected by management.

[0000889331-25-000039:auditors_report:34]
◦Testing the underlying source information and mathematical accuracy of the calculations.

[0000889331-25-000039:auditors_report:35]
/s/ Deloitte & Touche LLP

[0000889331-25-000039:auditors_report:36]
Chicago, Illinois

[0000889331-25-000039:auditors_report:37]
March 13, 2025

[0000889331-25-000039:auditors_report:38]
We have served as the Company's auditor since 2024.

[0000889331-25-000039:auditors_report:39]
Report of Independent Registered Public Accounting Firm

[0000889331-25-000039:auditors_report:40]
Board of Directors and Shareholders

[0000889331-25-000039:auditors_report:41]
Littelfuse, Inc.

[0000889331-25-000039:auditors_report:42]
Opinion on the financial statements

[0000889331-25-000039:auditors_report:43]
We have audited the accompanying consolidated balance sheet of Littelfuse, Inc. (a Delaware corporation) and subsidiaries (the “Company”) as of December 30, 2023, the related consolidated statements of net income, comprehensive income, equity, and cash flows for each of the two years in the period ended December 30, 2023, and the related notes and financial statement schedule included under Item 15(a) (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of December 30, 2023, and the results of its operations and its cash flows for each of the two years in the period ended December 30, 2023, in conformity with accounting principles generally accepted in the United States of America.

[0000889331-25-000039:auditors_report:44]
Basis for opinion

[0000889331-25-000039:auditors_report:45]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000889331-25-000039:auditors_report:46]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0000889331-25-000039:auditors_report:47]
/s/ GRANT THORNTON LLP

[0000889331-25-000039:auditors_report:48]
We served as the Company’s auditor from 2014 to 2023.

[0000889331-25-000039:auditors_report:49]
Southfield, Michigan

[0000889331-25-000039:auditors_report:50]
February 16, 2024 (except for Note 16, as to which the date is March 13, 2025)

[0000889331-25-000039:auditors_report:51]
Report of Independent Registered Public Accounting Firm

[0000889331-25-000039:auditors_report:52]
Board of Directors and Shareholders

[0000889331-25-000039:auditors_report:53]
Littelfuse, Inc.

[0000889331-25-000039:auditors_report:54]
Opinion on internal control over financial reporting

[0000889331-25-000039:auditors_report:55]
We have audited the internal control over financial reporting of Littelfuse, Inc. and subsidiaries (the “Company”) as of December 28, 2024, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, because of the effect of the material weaknesses identified below on the achievement of the objectives of the control criteria, the Company has not maintained effective internal control over financial reporting as of December 28, 2024, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0000889331-25-000039:auditors_report:56]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended December 28, 2024, of the Company and our report dated March 13, 2025, expressed an unqualified opinion on those consolidated financial statements.

[0000889331-25-000039:auditors_report:57]
Basis for opinion

[0000889331-25-000039:auditors_report:58]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000889331-25-000039:auditors_report:59]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000889331-25-000039:auditors_report:60]
Definition and limitations of internal control over financial reporting

[0000889331-25-000039:auditors_report:61]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000889331-25-000039:auditors_report:62]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000889331-25-000039:auditors_report:63]
Material weaknesses

[0000889331-25-000039:auditors_report:64]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the company’s annual or interim financial statements will not be prevented or detected on a timely basis.

[0000889331-25-000039:auditors_report:65]
Management identified a material weakness as the Company did not design and maintain an effective control environment commensurate with its financial reporting requirements. Specifically, at certain of its non-U.S. manufacturing locations, the Company lacked sufficiently skilled operational and accounting personnel to ensure that internal control responsibilities were performed and aligned with internal control objectives.

[0000889331-25-000039:auditors_report:66]
The material weakness in the control environment contributed to an additional material weakness related to the design and operating effectiveness of control activities over the existence of inventory at these locations. The Company did not maintain effective controls related to inventory cycle counts to validate existence of inventory, and consequently, the completeness and accuracy of the data used in evaluating the appropriateness of the valuation of inventory and related reserves.

[0000889331-25-000039:auditors_report:67]
These material weaknesses were considered in determining the nature, timing, and extent of audit tests applied in our audit of the consolidated financial statements as of and for the year ended December 28, 2024, of the Company, and this report does not affect our report on such financial statements.

[0000889331-25-000039:auditors_report:68]
/s/ Deloitte & Touche LLP

[0000889331-25-000039:auditors_report:69]
Chicago, Illinois

[0000889331-25-000039:auditors_report:70]
March 13, 2025

[0000889331-25-000039:auditors_report:71]
51

[0000889331-25-000039:auditors_report:72]
LITTELFUSE, INC.


## item_9a

[0000889331-25-000039:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES.

[0000889331-25-000039:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000889331-25-000039:item_9a:3]
The Company maintains disclosure controls and procedures that are designed to ensure that information required to be disclosed in its reports filed under the Securities Exchange Act of 1934, as amended, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and that such information is accumulated and communicated to management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure. In designing and evaluating the disclosure controls and procedures, the Company recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives, and the Company is required to apply its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0000889331-25-000039:item_9a:4]
As required by SEC Rule 15d-15(b), the Company carried out an evaluation, under the supervision and with the participation of its management, including the Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of its disclosure controls and procedures pursuant to SEC Rule 13a-15 and based upon the updated framework in Internal Control — Integrated Framework (2013), as of the end of the period covered by this Annual Report on Form 10-K. The Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were not effective as of December 28, 2024 due to a material weakness in our internal control over financial reporting as described below.

[0000889331-25-000039:item_9a:5]
Notwithstanding the conclusion by our Chief Executive Officer and Chief Financial Officer that our disclosure controls and procedures as of December 28, 2024 were not effective, and notwithstanding the material weaknesses in our internal control over financial reporting described below, management has concluded that our consolidated financial statements for all periods involved fairly present, in all material respects, our financial condition, results of operations and cash flows at and for the periods presented.

[0000889331-25-000039:item_9a:6]
Management’s Report on Internal Control over Financial Reporting

[0000889331-25-000039:item_9a:7]
99

[0000889331-25-000039:item_9a:8]
Management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Exchange Act Rule 13a-15(f) and 15d-15(f) based on the criteria established in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“the COSO Framework). The Company’s internal control system is designed to provide reasonable assurance to its management and the Board of Directors regarding the preparation and fair presentation of published financial statements.

[0000889331-25-000039:item_9a:9]
The Company’s independent registered public accounting firm, Deloitte & Touche LLP, has issued an attestation report on the Company’s internal control over financial reporting as of December 28, 2024. This report is included with this Form 10-K.

[0000889331-25-000039:item_9a:10]
Inherent Limitations on Effectiveness of Controls and Procedures

[0000889331-25-000039:item_9a:11]
There are inherent limitations to the effectiveness of any system of internal control over financial reporting. Accordingly, even an effective system of internal control over financial reporting can only provide reasonable assurance with respect to financial statement preparation and presentation in accordance with accounting principles generally accepted in the United States of America. Our internal controls over financial reporting are subject to various inherent limitations, including cost limitations, judgments used in decision making, assumptions about the likelihood of future events, the soundness of our systems, and the possibility of human error, and the risk of fraud. Moreover, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may be inadequate because of changes in conditions and the risk that the degree of compliance with policies or procedures may deteriorate over time.

[0000889331-25-000039:item_9a:12]
Material Weakness

[0000889331-25-000039:item_9a:13]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting such that there is a reasonable possibility that a material misstatement of the Company’s annual or interim financial statement will not be prevented or detected on a timely basis.

[0000889331-25-000039:item_9a:14]
Based on the Company’s assessment, management, including our Chief Executive Officer and Chief Financial Officer, has concluded that, as of December 28, 2024, the Company’s internal control over financial reporting was not effective due to the identification of the material weaknesses described below. In making this assessment, management has concluded that we did not design and maintain an effective control environment commensurate with our financial reporting requirements. Specifically, at certain of our non-U.S. manufacturing locations we lacked sufficiently skilled operational and accounting personnel to ensure that internal control responsibilities were performed and aligned with internal control objectives.

[0000889331-25-000039:item_9a:15]
The material weakness in the control environment contributed to an additional material weakness related to the design and operating effectiveness of control activities over the existence of inventory at these locations. The Company did not maintain effective controls related to inventory cycle counts to validate existence of inventory, and consequently, the completeness and accuracy of the data used in evaluating the appropriateness of the valuation of inventory and related reserves. These material weaknesses resulted in corrections through cumulative out-of-period adjustments as described in notes to the consolidated financial statements as of and for the year ended December 28, 2024.

[0000889331-25-000039:item_9a:16]
Changes in Internal Control over Financial Reporting

[0000889331-25-000039:item_9a:17]
Except as otherwise described above, there was no change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) identified in connection with the evaluation of our internal control performed during the fiscal quarter ended December 28, 2024, that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0000889331-25-000039:item_9a:18]
Remediation Plan for Material Weaknesses

[0000889331-25-000039:item_9a:19]
Our management team is committed to maintaining a strong internal control environment. The Company, with oversight from our Audit Committee of the Board of Directors, is taking comprehensive actions to remediate the material weaknesses. The Company has developed and is in the process of implementing its remediation plan, which will include the following steps:

[0000889331-25-000039:item_9a:20]
Control environment

[0000889331-25-000039:item_9a:21]
•recruiting of personnel with appropriate internal controls, and accounting knowledge and experience commensurate with our accounting and reporting requirements;

[0000889331-25-000039:item_9a:22]
•enhanced supervision of personnel at certain locations to ensure compliance with established Company policies; and

[0000889331-25-000039:item_9a:23]
100

[0000889331-25-000039:item_9a:24]
•evaluating and updating (as appropriate) the sufficiency of policies and training provided to personnel to ensure the appropriate segregation of duties and adherence to the Code of Conduct.

[0000889331-25-000039:item_9a:25]
Control activities

[0000889331-25-000039:item_9a:26]
•augmentation of training and clear instruction as to the process for recording of adjustments to inventories;

[0000889331-25-000039:item_9a:27]
•full physical inventory observations, facilitated by independent counters, until the cycle count and related inventory existence controls at certain of our non-U.S. manufacturing locations are operating effectively;

[0000889331-25-000039:item_9a:28]
•implementation of a management review control over inventory movements;

[0000889331-25-000039:item_9a:29]
•examination and enhancement of the procedures to evaluate the completeness and accuracy of data and assumptions utilized in computing inventory reserves.

[0000889331-25-000039:item_9a:30]
We intend to remediate the material weaknesses as soon as possible; however, the material weaknesses will not be considered remediated until the applicable controls operate for a sufficient period of time and management has concluded, through testing, that the appropriate controls are operating effectively.
