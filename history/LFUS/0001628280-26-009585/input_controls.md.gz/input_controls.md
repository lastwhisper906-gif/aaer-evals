# LFUS 10-K controls and the auditor's report


## auditors_report

[0001628280-26-009585:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001628280-26-009585:auditors_report:2]
Board of Directors and Shareholders

[0001628280-26-009585:auditors_report:3]
Littelfuse, Inc.

[0001628280-26-009585:auditors_report:4]
Opinion on the financial statements

[0001628280-26-009585:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Littelfuse, Inc. and subsidiaries (the “Company”) as of December 27, 2025 and December 28, 2024, the related consolidated statements of net (loss) income, comprehensive income, equity, and cash flows, for the periods ended December 27, 2025 and December 28, 2024, and the related notes and financial statement schedule included under Item 15(a) (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 27, 2025 and December 28, 2024, and the results of its operations and its cash flows for the periods ended December 27, 2025 and December 28, 2024, in conformity with accounting principles generally accepted in the United States of America.

[0001628280-26-009585:auditors_report:6]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of December 27, 2025, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated February 19, 2026, expressed an unqualified opinion on the Company's internal control over financial reporting.

[0001628280-26-009585:auditors_report:7]
Basis for opinion

[0001628280-26-009585:auditors_report:8]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001628280-26-009585:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001628280-26-009585:auditors_report:10]
Critical audit matter

[0001628280-26-009585:auditors_report:11]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001628280-26-009585:auditors_report:12]
Goodwill and Other Intangible Assets– Refer to Notes 1 and 5 to the financial statements

[0001628280-26-009585:auditors_report:13]
Critical Audit Matter Description

[0001628280-26-009585:auditors_report:14]
The Company’s evaluation of goodwill for impairment involves the comparison of the estimated fair value of each reporting unit to its carrying value. The Company engages a third-party appraisal firm to assist in the Company’s determination of the estimated fair values for each reporting unit. This determination includes estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping.

[0001628280-26-009585:auditors_report:15]
We identified the valuation of goodwill within the Electronics-Semiconductor and Industrial Controls and Sensors reporting units (“reporting units”) as a critical audit matter because of the reporting units’ historical and current year performance as compared to projections and because of the significant judgments made by management to estimate the respective fair values. This required a high degree of auditor judgment and an increased extent of effort, including the need to involve our fair value specialists, when auditing management’s judgments related to forecasts of revenue and earnings before interest, taxes, depreciation, and amortization (“EBITDA”), in addition to the selection of the discount rate in estimating the fair value of the reporting units.

[0001628280-26-009585:auditors_report:16]
How the Critical Audit Matter Was Addressed in the Audit

[0001628280-26-009585:auditors_report:17]
Our audit procedures related to the Company’s forecasts of revenue and EBITDA, and the selection of the discount rate used by management to estimate the fair value of the reporting units, included the following, among others:

[0001628280-26-009585:auditors_report:18]
•We tested the design and operating effectiveness of controls over the annual goodwill impairment assessment, including those over the preparation of the revenue and EBITDA forecasts, and the selection of the discount rate to estimate the fair value of the reporting units.

[0001628280-26-009585:auditors_report:19]
•We evaluated management’s ability to accurately forecast revenue and EBITDA (“forecasts”) by comparing actual results to management’s historical forecasts.

[0001628280-26-009585:auditors_report:20]
•We evaluated the reasonableness of management’s forecasts by comparing the forecasts to:

[0001628280-26-009585:auditors_report:21]
◦Internal communications to management and the Board of Directors.

[0001628280-26-009585:auditors_report:22]
◦Historical results, third-party economic research, industry performance, and peer company performance.

[0001628280-26-009585:auditors_report:23]
◦Actual results from the September 28, 2025, annual measurement date to December 27, 2025.

[0001628280-26-009585:auditors_report:24]
•We performed sensitivity analyses to evaluate changes to the impairment test if key assumptions are changed.

[0001628280-26-009585:auditors_report:25]
•With the assistance of our fair value specialists, for the goodwill impairment assessments we evaluated the reasonableness of the (1) valuation methodology, and (2) discount rate, by:

[0001628280-26-009585:auditors_report:26]
◦Evaluating whether the fair value model being used is appropriate considering the Company’s circumstances and valuation premise identified.

[0001628280-26-009585:auditors_report:27]
◦Developing a range of independent estimates and comparing those to the discount rate selected by management.

[0001628280-26-009585:auditors_report:28]
◦Testing the underlying source information and mathematical accuracy of the calculations.

[0001628280-26-009585:auditors_report:29]
/s/ Deloitte & Touche LLP

[0001628280-26-009585:auditors_report:30]
Chicago, Illinois

[0001628280-26-009585:auditors_report:31]
February 19, 2026

[0001628280-26-009585:auditors_report:32]
We have served as the Company's auditor since 2024.

[0001628280-26-009585:auditors_report:33]
Report of Independent Registered Public Accounting Firm

[0001628280-26-009585:auditors_report:34]
Board of Directors and Shareholders

[0001628280-26-009585:auditors_report:35]
Littelfuse, Inc.

[0001628280-26-009585:auditors_report:36]
Opinion on the financial statements

[0001628280-26-009585:auditors_report:37]
We have audited the accompanying consolidated balance sheet of Littelfuse, Inc. (a Delaware corporation) and subsidiaries (the “Company”) as of December 30, 2023 (not presented herein), the related consolidated statements of net income, comprehensive income, equity, and cash flows for the year then ended, and the related notes and financial statement schedule included under Item 15(a) (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of December 30, 2023, and the results of its operations and its cash flows for the year then ended, in conformity with accounting principles generally accepted in the United States of America.

[0001628280-26-009585:auditors_report:38]
Basis for opinion

[0001628280-26-009585:auditors_report:39]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001628280-26-009585:auditors_report:40]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001628280-26-009585:auditors_report:41]
/s/ GRANT THORNTON LLP

[0001628280-26-009585:auditors_report:42]
We have served as the Company’s auditor from 2014 to 2023.

[0001628280-26-009585:auditors_report:43]
Southfield, Michigan

[0001628280-26-009585:auditors_report:44]
February 16, 2024 (except for Note 16, as to which the date is March 13, 2025)

[0001628280-26-009585:auditors_report:45]
Report of Independent Registered Public Accounting Firm

[0001628280-26-009585:auditors_report:46]
Board of Directors and Shareholders

[0001628280-26-009585:auditors_report:47]
Littelfuse, Inc.

[0001628280-26-009585:auditors_report:48]
Opinion on internal control over financial reporting

[0001628280-26-009585:auditors_report:49]
We have audited the internal control over financial reporting of Littelfuse, Inc. and subsidiaries (the “Company”) as of December 27, 2025, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 27, 2025, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0001628280-26-009585:auditors_report:50]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended December 27, 2025, of the Company and our report dated February 19, 2026, expressed an unqualified opinion on those consolidated financial statements.

[0001628280-26-009585:auditors_report:51]
On December 11, 2025, the Company completed the acquisition of Basler, as discussed in Note 2 – Acquisitions. Management has excluded Basler’s internal controls over financial reporting from its assessment of the effectiveness of internal controls over financial reporting as of December 27, 2025. Basler’s net sales and total assets represent approximately 0.2% and 9%, respectively, of the consolidated financial statement amounts as of and for the fiscal year ended, December 27, 2025.

[0001628280-26-009585:auditors_report:52]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001628280-26-009585:auditors_report:53]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001628280-26-009585:auditors_report:54]
Definition and limitations of internal control over financial reporting

[0001628280-26-009585:auditors_report:55]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001628280-26-009585:auditors_report:56]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001628280-26-009585:auditors_report:57]
/s/ Deloitte & Touche LLP

[0001628280-26-009585:auditors_report:58]
Chicago, Illinois

[0001628280-26-009585:auditors_report:59]
February 19, 2026

[0001628280-26-009585:auditors_report:60]
LITTELFUSE, INC.


## item_9a

[0001628280-26-009585:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES.

[0001628280-26-009585:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001628280-26-009585:item_9a:3]
The Company maintains disclosure controls and procedures that are designed to ensure that information required to be disclosed in its reports filed under the Securities Exchange Act of 1934, as amended, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and that such information is accumulated and communicated to management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure. In designing and evaluating the disclosure controls and procedures, the Company recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives, and the Company is required to apply its judgment in evaluating the cost-benefit relationship of possible controls and procedures.

[0001628280-26-009585:item_9a:4]
As required by SEC Rule 15d-15(b), the Company carried out an evaluation, under the supervision and with the participation of its management, including the Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of its disclosure controls and procedures pursuant to SEC Rule 13a-15 and based upon the updated framework in Internal Control — Integrated Framework (2013), as of the end of the period covered by this Annual Report on Form 10-K. The Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of December 27, 2025.

[0001628280-26-009585:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001628280-26-009585:item_9a:6]
Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in this Annual Report on Form 10-K a report on management’s assessment of the effectiveness of the Company’s internal control over financial reporting, as well as an attestation report from the Company’s independent registered public accounting firm on the effectiveness of the Company’s internal control over financial reporting. Management is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Exchange Act Rule 13a-15(f) and 15d-15(f), based on the criteria established in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway

[0001628280-26-009585:item_9a:7]
103

[0001628280-26-009585:item_9a:8]
Commission (“the COSO Framework). The Company’s internal control system was designed to provide reasonable assurance to its management and the Board of Directors regarding the preparation and fair presentation of published financial statements.

[0001628280-26-009585:item_9a:9]
The Company’s management, including its Principal Executive Officer and Principal Financial Officer, assessed the effectiveness of the Company’s internal control over financial reporting as of December 27, 2025, based upon the updated framework in Internal Control — Integrated Framework (2013). Based on this assessment, the Company’s management concluded that, as of December 27, 2025, the Company’s internal control over financial reporting was effective.

[0001628280-26-009585:item_9a:10]
On December 11, 2025, the Company completed the acquisition of Basler, as discussed in Note 2 – Acquisitions. Management has excluded Basler's internal controls over financial reporting from its assessment of the effectiveness of internal controls over financial reporting as of December 27, 2025. Basler’s net sales and total assets represent approximately 0.2% and 9%, respectively, of the consolidated financial statement amounts as of and for the fiscal year ended, December 27, 2025.

[0001628280-26-009585:item_9a:11]
The Company’s independent registered public accounting firm, Deloitte & Touche LLP, has audited the consolidated financial statements included in this Annual Report on Form 10-K issued and have issued an attestation report on our internal control over financial reporting as of December 27, 2025.

[0001628280-26-009585:item_9a:12]
Changes in Internal Control over Financial Reporting

[0001628280-26-009585:item_9a:13]
During the fiscal year of 2025, the Company completed a number of initiatives and actions to address the previously reported material weaknesses, which included the following:

[0001628280-26-009585:item_9a:14]
Control Environment

[0001628280-26-009585:item_9a:15]
•The Company replaced key finance and operational roles at certain non-U.S. manufacturing locations, and recruited personnel with appropriate internal controls experience and accounting knowledge commensurate with our accounting and reporting requirements;

[0001628280-26-009585:item_9a:16]
•The Company completed the redesign of the regional operations and finance organizational structures; and

[0001628280-26-009585:item_9a:17]
•New corporate policies and procedures have been adopted and disseminated along with appropriate training provided to strengthen the control environment and inventory management oversight.

[0001628280-26-009585:item_9a:18]
Control Activities

[0001628280-26-009585:item_9a:19]
•Key monitoring controls have been designed and implemented for full physical counts, inventory storage locations, and over the completeness and accuracy of excessive and obsolete inventory calculations; and

[0001628280-26-009585:item_9a:20]
•Full physical inventory observations, facilitated by independent counters, have been performed in certain non-U.S. locations in the second, third and fourth quarters of the fiscal year 2025.

[0001628280-26-009585:item_9a:21]
After implementing the above initiatives and actions, the Company completed the necessary testing and concluded that the material weaknesses outlined above have been remediated as of December 27, 2025.

[0001628280-26-009585:item_9a:22]
Other than the changes described above to address and remediate the previously disclosed material weaknesses, there has been no change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the most recent fiscal quarter that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0001628280-26-009585:item_9a:23]
Inherent Limitations on Effectiveness of Controls and Procedures

[0001628280-26-009585:item_9a:24]
There are inherent limitations to the effectiveness of any system of internal control over financial reporting. Accordingly, even an effective system of internal control over financial reporting can only provide reasonable assurance with respect to financial statement preparation and presentation in accordance with accounting principles generally accepted in the United States of America. Our internal controls over financial reporting are subject to various inherent limitations, including cost limitations, judgments used in decision making, assumptions about the likelihood of future events, the soundness of our systems, and the possibility of human error, and the risk of fraud. Moreover, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may be inadequate because of changes in conditions and the risk that the degree of compliance with policies or procedures may deteriorate over time.
