# LFUS 8-K — 0001628280-26-003710 filed 2026-01-28

## item codes, every 8-K on or before 2026-02-19

- 2026-01-28 0001628280-26-003710 — 2.02, 7.01, 9.01
- 2026-01-08 0001140361-26-000720 — 5.02, 9.01
- 2025-10-29 0001628280-25-046908 — 2.02, 7.01, 9.01
- 2025-10-28 0000889331-25-000186 — 1.01, 7.01, 9.01
- 2025-08-07 0000889331-25-000151 — 5.02, 7.01, 9.01
- 2025-07-30 0001628280-25-036551 — 2.02, 7.01, 9.01
- 2025-05-27 0000889331-25-000109 — 5.02, 7.01, 9.01
- 2025-04-29 0000889331-25-000095 — 2.02, 7.01, 9.01
- 2025-04-28 0000889331-25-000082 — 5.02, 5.07, 9.01
- 2025-04-09 0001140361-25-012942 — 5.02, 7.01, 9.01
- 2025-01-28 0000889331-25-000013 — 2.02, 7.01, 9.01
- 2025-01-13 0001140361-25-000873 — 5.02, 9.01
- 2024-10-29 0000889331-24-000188 — 2.02, 7.01, 9.01
- 2024-07-30 0000889331-24-000159 — 2.02, 7.01, 9.01
- 2024-04-30 0000889331-24-000125 — 2.02, 7.01, 9.01
- 2024-04-26 0000889331-24-000064 — 5.02, 5.07, 9.01
- 2024-02-01 0000889331-24-000014 — 5.02
- 2024-01-30 0000889331-24-000010 — 2.02, 7.01, 9.01
- 2024-01-05 0000889331-24-000004 — 5.02
- 2023-10-31 0000889331-23-000154 — 2.02, 7.01, 9.01
- 2023-09-28 0000889331-23-000145 — 5.02, 8.01, 9.01
- 2023-08-16 0000889331-23-000135 — 4.01
- 2023-08-01 0000889331-23-000129 — 2.02, 7.01, 9.01
- 2023-05-15 0000889331-23-000104 — 5.02, 8.01, 9.01
- 2023-05-02 0000889331-23-000091 — 2.02, 7.01, 9.01
- 2023-04-28 0000889331-23-000039 — 5.02, 5.07, 8.01, 9.01
- 2023-02-02 0000889331-23-000007 — 5.03, 9.01
- 2023-02-01 0000889331-23-000003 — 2.02, 7.01, 9.01
- 2022-11-01 0000889331-22-000044 — 2.02, 7.01, 9.01
- 2022-08-02 0000889331-22-000037 — 2.02, 7.01, 9.01
- 2022-07-19 0000889331-22-000032 — 2.03, 7.01, 9.01
- 2022-06-30 0000889331-22-000028 — 1.01, 2.03, 9.01
- 2022-05-19 0001140361-22-019845 — 1.01, 2.03, 9.01
- 2022-05-03 0000889331-22-000020 — 2.02, 7.01, 9.01
- 2022-04-29 0000889331-22-000015 — 5.07
- 2022-04-08 0001140361-22-013670 — 1.01, 7.01, 9.01
- 2022-02-01 0000889331-22-000004 — 2.02, 7.01, 9.01
- 2021-11-30 0000889331-21-000069 — 2.01, 7.01, 9.01
- 2021-10-26 0000889331-21-000062 — 2.02, 7.01, 9.01
- 2021-10-20 0000889331-21-000057 — 1.01, 7.01, 9.01
- 2021-07-28 0000889331-21-000045 — 2.02, 7.01, 9.01
- 2021-04-28 0000889331-21-000032 — 2.02, 7.01, 9.01
- 2021-04-23 0000889331-21-000026 — 5.02, 5.07
- 2021-02-23 0000889331-21-000014 — 7.01, 9.01
- 2021-02-03 0000889331-21-000006 — 2.02, 9.01
- 2021-01-27 0000889331-21-000004 — 5.02
- 2020-10-28 0000889331-20-000052 — 2.02, 9.01
- 2020-07-29 0000889331-20-000043 — 2.02, 9.01
- 2020-04-29 0000889331-20-000036 — 2.02, 9.01
- 2020-04-24 0000889331-20-000029 — 5.02 — amendment of 0000889331-20-000003
- 2020-04-24 0000889331-20-000027 — 5.02, 5.07, 9.01
- 2020-04-07 0000889331-20-000025 — 1.01, 2.03, 9.01
- 2020-02-26 0000889331-20-000016 — 7.01, 9.01
- 2020-01-29 0000889331-20-000007 — 2.02, 9.01
- 2020-01-27 0000889331-20-000003 — 5.02, 8.01, 9.01
- 2019-10-30 0000889331-19-000049 — 2.02, 9.01
- 2019-08-28 0000889331-19-000045 — 7.01, 9.01
- 2019-07-31 0000889331-19-000040 — 2.02, 9.01
- 2019-07-17 0000889331-19-000035 — 2.02
- 2019-05-01 0000889331-19-000028 — 2.02, 9.01
- 2019-04-29 0000889331-19-000023 — 5.02, 5.07
- 2019-01-30 0000889331-19-000007 — 2.02, 9.01
- 2019-01-25 0000889331-19-000003 — 5.03, 9.01
- 2018-12-10 0000889331-18-000008 — 5.02, 8.01, 9.01
- 2018-10-31 0001437749-18-019099 — 2.02, 9.01
- 2018-08-01 0001437749-18-014136 — 2.02, 8.01, 9.01
- 2018-05-03 0001437749-18-008417 — 8.01, 9.01
- 2018-05-02 0001437749-18-008297 — 2.02, 9.01
- 2018-04-30 0001437749-18-008145 — 5.07
- 2018-03-23 0001437749-18-005267 — 9.01 — amendment of 0001104659-18-002723
- 2018-01-31 0001437749-18-001357 — 2.02, 9.01
- 2018-01-23 0001437749-18-000993 — 5.02, 9.01
- 2018-01-18 0001104659-18-002723 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-01-04 0001104659-18-000788 — 8.01, 9.01
- 2017-11-15 0001437749-17-019474 — 1.01, 2.03, 9.01
- 2017-11-01 0001437749-17-017988 — 2.02, 9.01
- 2017-10-16 0001437749-17-017141 — 1.01, 2.03, 9.01
- 2017-08-28 0001104659-17-053761 — 1.01, 8.01, 9.01
- 2017-08-14 0001437749-17-014727 — 5.02, 9.01
- 2017-08-02 0001437749-17-013530 — 2.02, 9.01
- 2017-07-18 0001437749-17-012737 — 2.02, 7.01, 9.01
- 2017-05-03 0001437749-17-007795 — 2.02, 9.01
- 2017-05-01 0001437749-17-007625 — 5.02, 5.07, 9.01
- 2017-03-02 0001437749-17-003603 — 7.01, 9.01
- 2017-02-15 0001437749-17-002588 — 1.01, 2.03, 9.01
- 2017-02-01 0001437749-17-001426 — 2.02, 9.01
- 2016-12-09 0001437749-16-043140 — 1.01, 2.03, 7.01, 9.01
- 2016-12-07 0001437749-16-043008 — 7.01
- 2016-11-16 0001437749-16-042222 — 5.02, 9.01
- 2016-11-03 0001437749-16-040906 — 2.02, 9.01
- 2016-10-24 0001437749-16-040112 — 2.02, 7.01, 9.01
- 2016-08-29 0000898822-16-000433 — 8.01
- 2016-08-25 0000898822-16-000429 — 8.01, 9.01
- 2016-08-04 0001437749-16-036352 — 2.02, 9.01
- 2016-07-26 0001437749-16-035667 — 5.02, 9.01
- 2016-06-10 0001437749-16-033638 — 9.01 — amendment of 0001437749-16-028458
- 2016-05-05 0001437749-16-030854 — 2.02, 9.01
- 2016-04-28 0001437749-16-030217 — 5.07
- 2016-03-28 0001437749-16-028458 — 2.01, 8.01, 9.01
- 2016-03-10 0001437749-16-027272 — 1.01, 1.02, 2.03, 9.01
- 2016-02-03 0001437749-16-024613 — 5.02, 9.01
- 2016-02-02 0001437749-16-024462 — 2.02, 9.01
- 2015-11-12 0001437749-15-020546 — 1.01, 9.01
- 2015-11-09 0001437749-15-020125 — 8.01, 9.01
- 2015-10-28 0001437749-15-018951 — 2.02, 9.01
- 2015-07-29 0001437749-15-014196 — 2.02, 9.01
- 2015-04-29 0001437749-15-008246 — 2.02, 5.07, 9.01
- 2015-02-04 0001437749-15-001708 — 2.02, 9.01
- 2014-12-22 0001437749-14-022368 — 5.02, 9.01
- 2014-11-12 0001437749-14-020421 — 8.01, 9.01
- 2014-10-30 0001437749-14-019106 — 5.03, 9.01
- 2014-10-29 0001437749-14-018971 — 2.02, 9.01
- 2014-07-31 0001437749-14-013753 — 1.02
- 2014-07-30 0001437749-14-013652 — 2.02, 9.01
- 2014-04-29 0001437749-14-007372 — 2.02, 5.07, 9.01
- 2014-04-28 0001437749-14-007296 — 5.02
- 2014-04-10 0001437749-14-006377 — 8.01, 9.01
- 2014-03-10 0001437749-14-003741 — 4.01, 9.01
- 2014-02-05 0001437749-14-001558 — 4.02
- 2014-02-05 0001437749-14-001533 — 2.02, 9.01
- 2014-02-04 0001437749-14-001485 — 1.01, 2.03, 9.01
- 2014-01-10 0001437749-14-000465 — 5.02, 9.01
- 2013-10-30 0001437749-13-013589 — 2.02, 9.01
- 2013-07-31 0001437749-13-009639 — 2.02, 9.01
- 2013-06-05 0001437749-13-007074 — 1.01, 1.02, 2.01, 2.03, 9.01
- 2013-05-31 0001437749-13-006915 — 7.01, 9.01
- 2013-04-30 0001437749-13-004881 — 2.02, 5.07, 9.01
- 2013-04-15 0001437749-13-004430 — 1.01, 7.01, 9.01
- 2013-04-10 0001437749-13-004235 — 2.02, 9.01
- 2013-02-05 0001437749-13-001099 — 2.02, 9.01
- 2012-12-10 0001437749-12-012701 — 7.01, 9.01
- 2012-11-01 0001437749-12-010776 — 2.02, 9.01
- 2012-08-01 0001437749-12-007467 — 2.02, 9.01
- 2012-07-02 0001437749-12-006592 — 5.02, 9.01
- 2012-05-04 0001437749-12-004515 — 5.02
- 2012-05-03 0001437749-12-004431 — 5.07
- 2012-05-03 0001437749-12-004410 — 2.02, 9.01
- 2012-02-08 0001437749-12-001203 — 5.02
- 2012-02-07 0001437749-12-001141 — 2.02, 9.01
- 2011-12-21 0001398432-11-001026 — 5.02
- 2011-11-03 0001437749-11-007992 — 2.02, 9.01
- 2011-08-04 0001437749-11-005435 — 2.02, 9.01
- 2011-06-17 0000950123-11-059913 — 1.01, 1.02, 2.03, 9.01
- 2011-05-05 0001437749-11-002809 — 2.02, 9.01
- 2011-05-03 0001437749-11-002749 — 5.07
- 2011-04-13 0001437749-11-002284 — 2.02, 9.01
- 2011-02-10 0001437749-11-000771 — 2.02, 9.01
- 2010-11-04 0001437749-10-003672 — 2.02, 9.01
- 2010-08-05 0000950123-10-072919 — 2.02, 9.01
- 2010-06-11 0000950123-10-057452 — 8.01, 9.01
- 2010-05-06 0000950123-10-045094 — 2.02, 9.01
- 2010-05-05 0000950123-10-044469 — 5.02, 5.07, 9.01
- 2010-04-09 0000950123-10-033523 — 2.02, 9.01
- 2010-02-08 0000950123-10-009689 — 2.02, 9.01
- 2010-01-12 0000950123-10-001932 — 8.01, 9.01
- 2009-10-29 0000950123-09-054554 — 2.02, 9.01
- 2009-10-16 0000950123-09-050764 — 5.02, 9.01
- 2009-09-16 0000950123-09-043549 — 8.01, 9.01
- 2009-07-30 0000950123-09-027375 — 2.02, 9.01
- 2009-07-07 0000950123-09-020491 — 2.02, 9.01
- 2009-05-20 0000950137-09-004020 — 8.01, 9.01
- 2009-04-30 0000950152-09-004420 — 2.02, 9.01
- 2009-04-28 0000950137-09-003344 — 5.02, 9.01
- 2009-03-31 0000950137-09-002439 — 5.02
- 2009-02-04 0000950137-09-000763 — 2.02, 9.01
- 2009-01-28 0000950137-09-000627 — 5.02
- 2008-10-30 0000950152-08-008406 — 5.05, 9.01
- 2008-10-29 0000950137-08-013271 — 2.02, 9.01
- 2008-10-01 0000950137-08-012252 — 1.01, 2.03
- 2008-09-29 0000950134-08-017269 — 2.02, 9.01
- 2008-07-30 0000950137-08-009865 — 2.02, 9.01
- 2008-05-01 0000950134-08-008018 — 5.02, 9.01
- 2008-04-30 0000950137-08-006335 — 2.02, 9.01
- 2008-03-17 0000950137-08-003793 — 5.02, 9.01
- 2008-03-10 0000950137-08-003472 — 8.01, 9.01
- 2008-02-07 0000950137-08-001754 — 1.01
- 2008-02-06 0000950137-08-001674 — 2.02, 9.01
- 2007-11-01 0000950137-07-016396 — 5.03, 9.01
- 2007-10-31 0000950137-07-016275 — 7.01, 9.01
- 2007-09-14 0000950137-07-014158 — 5.02
- 2007-08-03 0000950137-07-011180 — 5.02, 9.01
- 2007-08-01 0000950137-07-010969 — 7.01, 9.01
- 2007-06-21 0000950137-07-008998 — 8.01, 9.01
- 2007-05-03 0000950137-07-006679 — 5.02, 8.01, 9.01
- 2007-05-02 0000950137-07-006568 — 7.01, 9.01
- 2007-03-19 0000950137-07-004030 — 5.02
- 2007-03-19 0000950137-07-004016 — 8.01, 9.01
- 2007-02-09 0000950137-07-001779 — 5.02, 5.03, 9.01
- 2007-02-06 0000950137-07-001526 — 2.02, 9.01
- 2006-12-28 0000950137-06-014186 — 1.01
- 2006-12-08 0000950137-06-013400 — 8.01, 9.01
- 2006-11-02 0000950137-06-011729 — 2.02, 9.01
- 2006-08-09 0000950137-06-008894 — 2.02, 9.01
- 2006-08-08 0000950137-06-008827 — 1.01
- 2006-07-26 0000950137-06-008098 — 1.01, 1.02
- 2006-07-12 0000950137-06-007749 — 1.01, 9.01
- 2006-06-26 0000950137-06-007195 — 8.01, 9.01
- 2006-05-25 0000950137-06-006276 — 5.03, 9.01 — amendment of 0000950137-06-005798
- 2006-05-11 0000950137-06-005798 — 1.01, 5.03, 9.01
- 2006-05-09 0000950137-06-005589 — 2.02, 9.01
- 2006-05-05 0000950137-06-005421 — 1.01, 9.01
- 2006-03-20 0000950137-06-003291 — 1.01
- 2006-03-10 0000950137-06-002829 — 8.01, 9.01
- 2006-03-07 0000950137-06-002625 — 1.01
- 2006-03-06 0000950137-06-002620 — 1.01
- 2006-03-01 0000950137-06-002419 — 1.01
- 2006-02-23 0000950137-06-002154 — 8.01, 9.01
- 2006-02-10 0000950137-06-001659 — 2.02, 9.01
- 2006-02-08 0000950137-06-001488 — 7.01, 9.01
- 2006-02-07 0000950134-06-001988 — 8.01, 9.01
- 2005-12-29 0000950137-05-015377 — 5.02
- 2005-12-22 0000950134-05-023672 — 1.01
- 2005-11-02 0000950134-05-020233 — 7.01, 9.01
- 2005-08-23 0000950137-05-010537 — 8.01
- 2005-08-03 0000950137-05-009476 — 7.01, 9.01
- 2005-07-08 0000950137-05-008480 — 8.01, 9.01
- 2005-05-12 0000950137-05-005827 — 1.01, 7.01, 9.01
- 2005-05-09 0000950137-05-005544 — 7.01, 9.01
- 2005-04-22 0000950137-05-004786 — 9.01 — amendment of 0000950137-04-003608
- 2005-02-10 0000950137-05-001484 — 7.01, 9.01
- 2005-01-21 0000950137-05-000592 — 1.01
- 2005-01-05 0000950137-05-000108 — 1.01
- 2004-11-12 0000950137-04-009794 — 1.01, 9.01
- 2004-11-09 0000950137-04-009635 — 5.02, 9.01
- 2004-11-01 0000950137-04-009259 — 7.01, 9.01
- 2004-07-29 0000950134-04-010811 — 5, 7
- 2004-07-20 0000950137-04-005707 — 2, 7 — amendment of 0000950137-04-003608
- 2004-05-06 0000950137-04-003608 — 5, 7
- 2004-04-28 0000950137-04-003235 — 5, 7
- 2004-03-05 0000950137-04-001491 — 5, 7
- 2004-02-03 0000950137-04-000497 — 7, 9
- 2003-10-22 0000950137-03-005344 — 7, 9
- 2003-09-22 0000950137-03-004881 — 2, 7 — amendment of 0000950137-03-003745
- 2003-07-23 0000950124-03-002398 — 7, 9
- 2003-07-10 0000950137-03-003745 — 2, 7
- 2003-04-24 0000950137-03-002386 — 7, 9

## late-filing notifications on or before 2026-02-19

- 2025-02-27 0001140361-25-006294 — NT 10-K, for the period ended 2024-12-28
- 2002-05-15 0000950137-02-003138 — NT 10-Q, for the period ended 2002-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-003710:8k_2_02:1]
EX-99.1
2
q42025ex991.htm
EX-99.1

[0001628280-26-003710:8k_2_02:2]
Document

[0001628280-26-003710:8k_2_02:3]
Exhibit 99.1

[0001628280-26-003710:8k_2_02:4]
|  | FOR IMMEDIATE RELEASEDavid Kelley224-727-2535dkelley@littelfuse.com |

[0001628280-26-003710:8k_2_02:5]
Littelfuse Reports Fourth Quarter and Full Year 2025 Results

[0001628280-26-003710:8k_2_02:6]
Fourth Quarter Highlights:

[0001628280-26-003710:8k_2_02:7]
(Year-over-year comparisons unless otherwise noted)

[0001628280-26-003710:8k_2_02:8]
•Net sales of $594 million, +12%; organic growth contributed +7%

[0001628280-26-003710:8k_2_02:9]
•Cash flow from operations of $139 million and free cash flow of $120 million

[0001628280-26-003710:8k_2_02:10]
•Recorded non-cash goodwill impairment charge of $301 million related to the Semiconductor Products business within the Electronics Segment

[0001628280-26-003710:8k_2_02:11]
•GAAP diluted loss per share of ($9.72); Adjusted diluted earnings per share of $2.69

[0001628280-26-003710:8k_2_02:12]
•GAAP operating margin of (-37.5%); Adjusted EBITDA margin of 20.5%, +480 bps

[0001628280-26-003710:8k_2_02:13]
Full Year Highlights:

[0001628280-26-003710:8k_2_02:14]
(Year-over-year comparisons unless otherwise noted)

[0001628280-26-003710:8k_2_02:15]
•Net sales of $2,386 million, +9%; organic growth contributed +6%

[0001628280-26-003710:8k_2_02:16]
•Cash flow from operations of $434 million and free cash flow of $366 million

[0001628280-26-003710:8k_2_02:17]
•GAAP diluted loss per share of ($2.89), which includes a non-cash goodwill impairment charge of $301 million related to the Semiconductor Products business within the Electronics Segment

[0001628280-26-003710:8k_2_02:18]
•Adjusted diluted earnings per share of $10.68, +34%

[0001628280-26-003710:8k_2_02:19]
•GAAP operating margin of 1.6%; Adjusted EBITDA margin of 20.9%, +260 bps

[0001628280-26-003710:8k_2_02:20]
CHICAGO, January 28, 2026 - Littelfuse, Inc. (NASDAQ: LFUS), a leader in developing smart solutions that enable safe and efficient electrical energy transfer, today reported financial results for its fourth quarter ended December 27, 2025:

[0001628280-26-003710:8k_2_02:21]
“I am proud of our teams as we finished the year with significant momentum, delivering fourth quarter results above our guidance range and successfully closing the acquisition of Basler Electric,” said Greg Henderson, Littelfuse President and Chief Executive Officer. “Throughout 2025, we remained disciplined in executing our strategic priorities, which is reflected in our solid full year revenue growth and margin expansion. Across our segments, we are entering 2026 from a position of strength as we leverage our leadership in safe and efficient electrical energy transfer to accelerate growth, broaden our solutions for an expanding customer base, and drive continued operational enhancements.”

[0001628280-26-003710:8k_2_02:22]
-more-

[0001628280-26-003710:8k_2_02:23]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-26-003710:8k_2_02:24]
First Quarter of 2026*

[0001628280-26-003710:8k_2_02:25]
“Looking ahead to the first quarter, we expect approximately 15% total revenue growth versus the prior year, supported by our strengthening backlog, deepening customer engagement, and contributions from the Basler acquisition. As our end markets continue to evolve requiring higher power and energy density solutions, we remain committed to driving technology innovations to help our customers solve increasingly complex challenges. Our focus is on executing our strategic priorities and scaling the company to deliver leading long term performance and shareholder value.”

[0001628280-26-003710:8k_2_02:26]
Based on current market conditions, for the first quarter the company expects,

[0001628280-26-003710:8k_2_02:27]
•Net sales in the range of $625 - $645 million, adjusted diluted EPS in the range of $2.70 – $2.90 and an adjusted effective tax rate of 24%

[0001628280-26-003710:8k_2_02:28]
*Littelfuse provides guidance on a non-GAAP (adjusted) basis. GAAP items excluded from guidance may include the after-tax impact of items including acquisition and integration costs, restructuring, impairment and other charges, certain purchase accounting adjustments, non-operating foreign exchange adjustments and significant and unusual items. These items are uncertain, depend on various factors, and could be material to results computed in accordance with GAAP. Littelfuse is not able to forecast the excluded items in order to provide the most directly comparable GAAP financial measure without unreasonable efforts.

[0001628280-26-003710:8k_2_02:29]
Fourth Quarter 2025 Segment Performance Highlights

[0001628280-26-003710:8k_2_02:30]
Electronics Segment

[0001628280-26-003710:8k_2_02:31]
•Net sales for the fourth quarter 2025 increased +21%. Organic sales increased +14% driven by improved passive products (+23% organic) sales. Semiconductor product (+6% organic) sales also contributed to growth driven by increased protection semiconductor demand which more than offset lower power semiconductor volumes. The Dortmund Fab acquisition and favorable FX contributed +4% and +2% to growth, respectively.

[0001628280-26-003710:8k_2_02:32]
•Adjusted EBITDA margin for the fourth quarter 2025 increased to 23.7% (+370 bps) primarily due to strong passive products and protection volume leverage which more than offset continued soft power semiconductor volumes.

[0001628280-26-003710:8k_2_02:33]
•The fourth quarter 2025 includes a non-cash goodwill impairment charge of $301 million related to the Semiconductor product business reflecting weaker sales and profitability than original expectations amid persistent soft market conditions.

[0001628280-26-003710:8k_2_02:34]
Transportation Segment

[0001628280-26-003710:8k_2_02:35]
•Net sales for the fourth quarter 2025 increased +1% as favorable FX impact of +2% offset lower organic sales. Organic sales decreased -1% as improved passenger vehicle organic sales (+2% organic) was more than offset by lower commercial vehicle sales (-4% organic). Passenger vehicle strength was driven by solid demand for core passenger car products, more than offsetting lower global passenger car builds and sensor declines in the fourth quarter. Lower commercial vehicle sales reflected the previously disclosed exit of the marine business as well as continued soft on-highway, off-road and agriculture end market demand.

[0001628280-26-003710:8k_2_02:36]
•Adjusted EBITDA margin for the fourth quarter 2025 increased to 16.0% (+830 bps) driven by improved operational execution and a favorable year-over-year comparison against a prior-year cumulative out-of-period adjustment ($11.1 million), which more than offset lower volume and unfavorable mix.

[0001628280-26-003710:8k_2_02:37]
-more-

[0001628280-26-003710:8k_2_02:38]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-26-003710:8k_2_02:39]
Industrial Segment

[0001628280-26-003710:8k_2_02:40]
•Net sales for the fourth quarter 2025 increased +4%. Organic sales decreased 1% as improved energy storage, utility & grid infrastructure, renewables and data center demand was more than offset by lower HVAC demand. The Basler acquisition and favorable FX also contributed +5% and +1% to growth, respectively.

[0001628280-26-003710:8k_2_02:41]
•Adjusted EBITDA margin for the fourth quarter 2025 was flat at 16.2% as improved productivity and mix as well as a favorable year-over-year comparison against a prior-year cumulative out-of-period adjustment ($4.1 million) was offset by lower volume.

[0001628280-26-003710:8k_2_02:42]
Full Year 2025 Segment Performance Highlights

[0001628280-26-003710:8k_2_02:43]
Electronics Segment

[0001628280-26-003710:8k_2_02:44]
•Net sales for the full year 2025 increased +13%. Organic sales increased +8% driven by improved passive products (+17% organic) sales. Semiconductor product organic sales were flat as improved protection semiconductor demand was offset by lower power semiconductor volumes. The Dortmund Fab acquisition and favorable FX also contributed +4% and +1% to growth, respectively.

[0001628280-26-003710:8k_2_02:45]
•Adjusted EBITDA margin for the full year 2025 increased to 22.9% (+190 bps) primarily due to strong passive products and protection volume leverage, which more than offset continued soft power semiconductor volumes.

[0001628280-26-003710:8k_2_02:46]
Transportation Segment

[0001628280-26-003710:8k_2_02:47]
•Net sales for the full year 2025 increased +1% as favorable FX impact of +1% offset lower organic sales. Organic sales decreased -1% as flat passenger vehicle organic sales was more than offset by lower commercial vehicle sales (-1% organic). Flat full year passenger vehicle sales reflects solid core passenger car products growth offset by sensor declines. Lower commercial vehicle sales reflected soft on-highway, off-road and agriculture end market demand.

[0001628280-26-003710:8k_2_02:48]
•Adjusted EBITDA margin for the full year 2025 increased to 17.7% (+370 bps) driven by improved operational execution and a favorable year-over-year comparison against a prior-year cumulative out-of-period adjustment ($11.1 million), which more than offset lower volume.

[0001628280-26-003710:8k_2_02:49]
Industrial Segment

[0001628280-26-003710:8k_2_02:50]
•Net sales for the full year 2025 increased +10%. Organic sales increased 9% driven by growth from energy storage, renewables, data center and HVAC end markets. The Basler acquisition also contributed +1% to growth.

[0001628280-26-003710:8k_2_02:51]
•Adjusted EBITDA margin for the full year 2025 increased to 19.5% (+220 bps) driven by improved volume leverage and a favorable year-over-year comparison against a prior-year cumulative out-of-period adjustment ($4.1 million).

[0001628280-26-003710:8k_2_02:52]
Dividend

[0001628280-26-003710:8k_2_02:53]
•The company will pay a cash dividend on its common stock of $0.75 per share on March 5, 2026, to shareholders of record as of February 19, 2026.

[0001628280-26-003710:8k_2_02:54]
-more-

[0001628280-26-003710:8k_2_02:55]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-26-003710:8k_2_02:56]
Conference Call and Webcast Information

[0001628280-26-003710:8k_2_02:57]
Littelfuse will host a conference call on Wednesday, January 28, 2026, at 8:00 a.m. Central Time to discuss the results. The call will be broadcast and available for replay at Littelfuse.com. A slide presentation is available in the Investor Relations section of the company’s website at Littelfuse.com.

[0001628280-26-003710:8k_2_02:58]
About Littelfuse

[0001628280-26-003710:8k_2_02:59]
Littelfuse, Inc. (NASDAQ: LFUS) is a diversified, industrial technology manufacturing company empowering a sustainable, connected, and safer world. Across more than 20 countries, and with approximately 17,000 global associates, we partner with customers to design and deliver innovative, reliable solutions. Serving over 100,000 end customers, our products are found in a variety of industrial, transportation and electronics end markets – everywhere, every day. Learn more at Littelfuse.com.

[0001628280-26-003710:8k_2_02:60]
The statements in this press release that are not historical facts are intended to constitute "forward-looking statements" entitled to the safe-harbor provisions of the Private Securities Litigation Reform Act. Such statements are based on Littelfuse, Inc.’s (“Littelfuse” or the “Company”) current expectations and are subject to a number of factors and uncertainties, which could cause actual results to differ materially from those described in the forward-looking statements. These risks, uncertainties and other factors include, but are not limited to, risks and uncertainties relating to general economic conditions; product demand and market acceptance; economic conditions; the impact of competitive products and pricing; product quality problems or product recalls; capacity and supply difficulties or constraints; coal mining exposures reserves; cybersecurity matters; failure of an indemnification for environmental liability; changes in import and export duty and tariff rates; exchange rate fluctuations; commodity price fluctuations; the effect of the Company's accounting policies; labor disputes and shortages; restructuring costs in excess of expectations; pension plan asset returns less than assumed; uncertainties related to political or regulatory changes; integration of acquisitions may not be achieved in a timely manner, or at all; limited realization of the expected benefits from investment and strategic plans; the risk that expected benefits, synergies and growth prospects of the transaction with Basler may not be achieved in a timely manner, or at all; and other risks which may be detailed in the company's Securities and Exchange Commission filings. Should one or more of these risks or uncertainties materialize or should the underlying assumptions prove incorrect, actual results and outcomes may differ materially from those indicated or implied in the forward-looking statements. This release should be read in conjunction with information provided in the financial statements appearing in the company's Annual Report on Form 10-K for the year ended December 28, 2024.

[0001628280-26-003710:8k_2_02:61]
Further discussion of the risk factors of the company can be found under the caption "Risk Factors" in the company's Annual Report on Form 10-K for the year ended December 28, 2024, and in other filings and submissions with the SEC, each of which are available free of charge on the company’s investor relations website at investor.littelfuse.com and on the SEC’s website at www.sec.gov. These forward-looking statements are made as of the date hereof. The company does not undertake any obligation to update, amend or clarify these forward-looking statements to reflect events or circumstances after the date hereof or to reflect the availability of new information.

[0001628280-26-003710:8k_2_02:62]
-more-

[0001628280-26-003710:8k_2_02:63]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-26-003710:8k_2_02:64]
Non-GAAP Financial Measures

[0001628280-26-003710:8k_2_02:65]
The information included in this press release and other materials filed with the SEC may include non-GAAP financial measures including organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, adjusted effective tax rate, free cash flow, net debt, consolidated EBITDA, and consolidated net leverage ratio (as defined in the credit agreement). Many of these non-GAAP financial measures exclude the effect of certain expenses and income not related directly to the underlying performance of our fundamental business operations. A reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures is set forth in the attached schedules. The company believes that organic net sales (decline) growth, adjusted operating income, adjusted operating margin, adjusted EBITDA, adjusted EBITDA margin, adjusted diluted earnings per share, adjusted income taxes, and adjusted effective tax rate provide useful information to investors regarding its operational performance because they enhance an investor’s overall understanding of the company’s core financial performance and facilitate comparisons to historical results of operations, by excluding items that are not related directly to the underlying performance of its fundamental business operations or were not part of the company’s business operations during a comparable period. The company believes that free cash flow is a useful measure of its ability to generate cash. The company believes that net debt, consolidated EBITDA, and consolidated net leverage ratio are useful measures of its credit position. The company believes that all of these non-GAAP financial measures are commonly used by financial analysts and others in the industries in which we operate, and thus further provide useful information to investors. Management additionally uses these measures when assessing the performance of the business and for business planning purposes. Note that the company’s definitions of these non-GAAP financial measures may differ from those terms as defined or used by other companies.

[0001628280-26-003710:8k_2_02:66]
LFUS-F

[0001628280-26-003710:8k_2_02:67]
###

[0001628280-26-003710:8k_2_02:68]
|  | Littelfuse Inc.6133 North River Road, Suite 500Rosemont, Illinois 60018p: (773) 628-1000www.littelfuse.com |

[0001628280-26-003710:8k_2_02:69]
LITTELFUSE, INC.

[0001628280-26-003710:8k_2_02:70]
CONSOLIDATED BALANCE SHEETS

[0001628280-26-003710:8k_2_02:71]
| (in thousands) | December 27, 2025 |  | December 28, 2024 |
|  | (Unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 563,391 |  |  | $ | 724,924 |  |
| Short-term investments | 287 |  |  | 976 |  |
| Trade receivables, less allowances of $77,073 and $69,990, respectively | 363,215 |  |  | 294,371 |  |
| Inventories | 416,472 |  |  | 416,273 |  |
| Prepaid income taxes and income taxes receivable | 6,137 |  |  | 11,749 |  |
| Prepaid expenses and other current assets | 85,832 |  |  | 103,716 |  |
| Total current assets | 1,435,334 |  |  | 1,552,009 |  |
| Net property, plant, and equipment | 540,640 |  |  | 477,068 |  |
| Intangible assets, net of amortization | 634,907 |  |  | 482,118 |  |
| Goodwill | 1,171,411 |  |  | 1,228,502 |  |
| Investments | 20,010 |  |  | 23,245 |  |
| Deferred income taxes | 5,255 |  |  | 4,899 |  |
| Right of use lease assets | 86,263 |  |  | 72,211 |  |
| Other long-term assets | 62,976 |  |  | 51,727 |  |
| Total assets | $ | 3,956,796 |  |  | $ | 3,891,779 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 211,079 |  |  | $ | 188,359 |  |
| Accrued liabilities | 199,271 |  |  | 148,276 |  |
| Accrued income taxes | 26,186 |  |  | 29,658 |  |
| Current portion of long-term debt | 96,233 |  |  | 67,612 |  |
| Total current liabilities | 532,769 |  |  | 433,905 |  |
| Long-term debt, less current portion | 706,394 |  |  | 788,502 |  |
| Deferred income taxes | 102,335 |  |  | 95,532 |  |
| Accrued post-retirement benefits | 38,733 |  |  | 29,836 |  |
| Non-current lease liabilities | 71,765 |  |  | 60,559 |  |
| Other long-term liabilities | 78,766 |  |  | 69,833 |  |
| Total equity | 2,426,034 |  |  | 2,413,612 |  |
| Total liabilities and equity | $ | 3,956,796 |  |  | $ | 3,891,779 |  |

[0001628280-26-003710:8k_2_02:72]
6

[0001628280-26-003710:8k_2_02:73]
LITTELFUSE, INC.

[0001628280-26-003710:8k_2_02:74]
CONSOLIDATED STATEMENTS OF NET (LOSS) INCOME

[0001628280-26-003710:8k_2_02:75]
(Unaudited)

[0001628280-26-003710:8k_2_02:76]
|  |  | Three Months Ended |  | Fiscal Year Ended |
| (in thousands, except per share data) |  | December 27, 2025 |  | December 28, 2024 |  | December 27, 2025 |  | December 28, 2024 |
| Net sales |  | $ | 593,934 |  |  | $ | 529,505 |  |  | $ | 2,386,294 |  |  | $ | 2,190,768 |  |
| Cost of sales |  | 368,189 |  |  | 352,667 |  |  | 1,480,251 |  |  | 1,403,226 |  |
| Gross profit |  | 225,745 |  |  | 176,838 |  |  | 906,043 |  |  | 787,542 |  |
| Selling, general, and administrative expenses |  | 98,978 |  |  | 87,026 |  |  | 381,773 |  |  | 350,421 |  |
| Research and development expenses |  | 27,118 |  |  | 26,490 |  |  | 106,899 |  |  | 107,773 |  |
| Amortization of intangibles |  | 15,573 |  |  | 14,709 |  |  | 59,793 |  |  | 62,127 |  |
| Restructuring, impairment, and other charges |  | 306,892 |  |  | 98,112 |  |  | 320,050 |  |  | 108,441 |  |
| Total operating expenses |  | 448,561 |  |  | 226,337 |  |  | 868,515 |  |  | 628,762 |  |
| Operating (loss) income |  | (222,816) |  |  | (49,499) |  |  | 37,528 |  |  | 158,780 |  |
| Interest expense |  | 8,282 |  |  | 9,359 |  |  | 34,303 |  |  | 38,717 |  |
| Foreign exchange loss (gain) |  | 1,146 |  |  | (13,503) |  |  | 16,612 |  |  | (9,230) |  |
| Other income, net |  | (2,974) |  |  | (2,654) |  |  | (16,994) |  |  | (22,570) |  |
| (Loss) income before income taxes |  | (229,270) |  |  | (42,701) |  |  | 3,607 |  |  | 151,863 |  |
| Income taxes |  | 12,865 |  |  | 9,085 |  |  | 75,307 |  |  | 51,673 |  |
| Net (loss) income |  | $ | (242,135) |  |  | $ | (51,786) |  |  | $ | (71,700) |  |  | $ | 100,190 |  |
| (Loss) income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (9.72) |  |  | $ | (2.09) |  |  | $ | (2.89) |  |  | $ | 4.04 |  |
| Diluted |  | $ | (9.72) |  |  | $ | (2.09) |  |  | $ | (2.89) |  |  | $ | 4.00 |  |
| Weighted-average shares and equivalent shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 24,909 |  |  | 24,818 |  |  | 24,817 |  |  | 24,821 |  |
| Diluted |  | 24,909 |  |  | 24,818 |  |  | 24,817 |  |  | 25,039 |  |
| Comprehensive (loss) income |  | $ | (233,130) |  |  | $ | (147,365) |  |  | $ | 69,278 |  |  | $ | 9,646 |  |

[0001628280-26-003710:8k_2_02:77]
7

[0001628280-26-003710:8k_2_02:78]
LITTELFUSE, INC.

[0001628280-26-003710:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-26-003710:8k_2_02:80]
|  | Year Ended |
| (in thousands) | December 27, 2025 |  | December 28, 2024 |
| OPERATING ACTIVITIES |  |  |  |
| Net (loss) income | $ | (71,700) |  |  | $ | 100,190 |  |
| Adjustments to reconcile net (loss) income to net cash provided by operating activities | 478,580 |  |  | 237,143 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Trade receivables | (36,401) |  |  | (15,347) |  |
| Inventories | 40,181 |  |  | 47,143 |  |
| Accounts payable | 11,342 |  |  | 16,260 |  |
| Accrued liabilities and income taxes | 4,095 |  |  | (34,560) |  |
| Prepaid expenses and other assets | 7,667 |  |  | 16,792 |  |
| Net cash provided by operating activities | 433,764 |  |  | 367,621 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisitions of businesses, net of cash acquired | (407,718) |  |  | — |  |
| Purchases of property, plant, and equipment | (67,637) |  |  | (75,877) |  |
| Net proceeds from sale of property, plant, and equipment | 5,806 |  |  | 10,836 |  |
| Other | 689 |  |  | (741) |  |
| Net cash used in investing activities | (468,860) |  |  | (65,782) |  |
| FINANCING ACTIVITIES |  |  |  |
| Net payments of credit facility and senior notes | (65,000) |  |  | (7,500) |  |
| Cash dividends paid | (71,991) |  |  | (67,061) |  |
| Purchases of common stock | (27,553) |  |  | (40,862) |  |
| All other cash provided by financing activities | 15,271 |  |  | 2,987 |  |
| Net cash used in financing activities | (149,273) |  |  | (112,436) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 23,036 |  |  | (20,089) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash | (161,333) |  |  | 169,314 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 726,437 |  |  | 557,123 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 565,104 |  |  | $ | 726,437 |  |

[0001628280-26-003710:8k_2_02:81]
8

[0001628280-26-003710:8k_2_02:82]
LITTELFUSE, INC.

[0001628280-26-003710:8k_2_02:83]
NET SALES AND OPERATING INCOME BY SEGMENT

[0001628280-26-003710:8k_2_02:84]
(Unaudited)

[0001628280-26-003710:8k_2_02:85]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2025 |  | 2024 |  |  |  | %Growth / (Decline) |  | 2025 |  | 2024 |  |  |  | %Growth / (Decline) |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 345,150 |  |  | $ | 285,841 |  |  |  |  | 20.7 | % |  | $ | 1,345,522 |  |  | $ | 1,186,773 |  |  |  |  | 13.4 | % |
| Transportation |  | 163,804 |  |  | 161,723 |  |  |  |  | 1.3 | % |  | 676,377 |  |  | 672,434 |  |  |  |  | 0.6 | % |
| Industrial |  | 84,980 |  |  | 81,941 |  |  |  |  | 3.7 | % |  | 364,395 |  |  | 331,561 |  |  |  |  | 9.9 | % |
| Total net sales |  | $ | 593,934 |  |  | $ | 529,505 |  |  |  |  | 12.2 | % |  | $ | 2,386,294 |  |  | $ | 2,190,768 |  |  |  |  | 8.9 | % |
| Operating (loss) income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | $ | 59,799 |  |  | $ | 37,034 |  |  |  |  | 61.5 | % |  | $ | 220,066 |  |  | $ | 169,893 |  |  |  |  | 29.5 | % |
| Transportation |  | 17,602 |  |  | 3,653 |  |  |  |  | 381.9 | % |  | 84,780 |  |  | 58,578 |  |  |  |  | 44.7 | % |
| Industrial |  | 10,168 |  |  | 10,277 |  |  |  |  | (1.1) | % |  | 59,023 |  |  | 42,331 |  |  |  |  | 39.4 | % |
| Other (a) |  | (310,385) |  |  | (100,463) |  |  |  |  | N.M. |  | (326,341) |  |  | (112,022) |  |  |  |  | N.M. |
| Total operating (loss) income |  | $ | (222,816) |  |  | $ | (49,499) |  |  |  |  | (350.1) | % |  | $ | 37,528 |  |  | $ | 158,780 |  |  |  |  | (76.4) | % |
| Operating Margin |  | (37.5) | % |  | (9.3) | % |  |  |  |  |  | 1.6 | % |  | 7.2 | % |  |  |  |  |
| Interest expense |  | 8,282 |  |  | 9,359 |  |  |  |  |  |  | 34,303 |  |  | 38,717 |  |  |  |  |  |
| Foreign exchange loss (gain) |  | 1,146 |  |  | (13,503) |  |  |  |  |  |  | 16,612 |  |  | (9,230) |  |  |  |  |  |
| Other income, net |  | (2,974) |  |  | (2,654) |  |  |  |  |  |  | (16,994) |  |  | (22,570) |  |  |  |  |  |
| (Loss) income before income taxes |  | $ | (229,270) |  |  | $ | (42,701) |  |  |  |  | (436.9) | % |  | $ | 3,607 |  |  | $ | 151,863 |  |  |  |  | (97.6) | % |

[0001628280-26-003710:8k_2_02:86]
(a)"other" typically includes non-GAAP adjustments such as acquisition-related and integration costs, purchase accounting inventory adjustments and restructuring and impairment charges. (See Supplemental Financial Information for details.)

[0001628280-26-003710:8k_2_02:87]
N.M. - Not meaningful

[0001628280-26-003710:8k_2_02:88]
|  |  | Fourth Quarter |  | Year-to-Date |
| (in thousands) |  | 2025 |  | 2024 |  |  |  | %Growth (decline) |  | 2025 |  | 2024 |  |  |  | %Growth |
| Operating Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Electronics |  | 17.3 | % |  | 13.0 | % |  |  |  | 4.3 | % |  | 16.4 | % |  | 14.3 | % |  |  |  | 2.1 | % |
| Transportation |  | 10.7 | % |  | 2.3 | % |  |  |  | 8.4 | % |  | 12.5 | % |  | 8.7 | % |  |  |  | 3.8 | % |
| Industrial |  | 12.0 | % |  | 12.5 | % |  |  |  | (0.5) | % |  | 16.2 | % |  | 12.8 | % |  |  |  | 3.4 | % |

[0001628280-26-003710:8k_2_02:89]
9

[0001628280-26-003710:8k_2_02:90]
LITTELFUSE, INC.

[0001628280-26-003710:8k_2_02:91]
SUPPLEMENTAL FINANCIAL INFORMATION

[0001628280-26-003710:8k_2_02:92]
(In millions of USD except per share amounts - unaudited)

[0001628280-26-003710:8k_2_02:93]
| Non-GAAP EPS reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-25 |  | Q4-24 |  | YTD-25 |  | YTD-24 |
| GAAP (loss per share)/ diluted EPS |  | $ | (9.72) |  |  | $ | (2.09) |  |  | $ | (2.89) |  |  | $ | 4.00 |  |
| EPS impact of Non-GAAP adjustments (below) |  | 12.41 |  |  | 3.61 |  |  | 13.57 |  |  | 3.97 |  |
| Adjusted diluted EPS |  | $ | 2.69 |  |  | $ | 1.53 |  |  | $ | 10.68 |  |  | $ | 7.97 |  |

[0001628280-26-003710:8k_2_02:94]
| Non-GAAP adjustments - (income) / expense |  |  |  |  |  |  |  |  |
|  |  | Q4-25 |  | Q4-24 |  | YTD-25 |  | YTD-24 |
| Acquisition-related and integration costs (a) |  | $ | 2.4 |  |  | $ | 2.4 |  |  | $ | 5.4 |  |  | $ | 5.1 |  |
| Purchase accounting inventory adjustments (b) |  | 1.1 |  |  | — |  |  | 0.6 |  |  | — |  |
| Restructuring, impairment and other charges (c) |  | 306.9 |  |  | 98.1 |  |  | 320.1 |  |  | 108.4 |  |
| Gain on sale of fixed assets (d) |  | — |  |  | — |  |  | — |  |  | (1.5) |  |
| Loss on sale of the Marine business (e) |  | — |  |  | — |  |  | 0.3 |  |  | — |  |
| Non-GAAP adjustments to operating (loss) income |  | 310.4 |  |  | 100.5 |  |  | 326.4 |  |  | 112.0 |  |
| Other expense (income), net (f) |  | 0.6 |  |  | 1.6 |  |  | 0.6 |  |  | 1.3 |  |
| Non-operating foreign exchange loss (gain) |  | 1.1 |  |  | (13.5) |  |  | 16.6 |  |  | (9.2) |  |
| Non-GAAP adjustments to (loss) income before income taxes |  | 312.2 |  |  | 88.5 |  |  | 343.6 |  |  | 104.1 |  |
| Income taxes (g) |  | 2.4 |  |  | (1.5) |  |  | 4.6 |  |  | 4.7 |  |
| Non-GAAP adjustments to net (loss) income |  | $ | 309.8 |  |  | $ | 90.0 |  |  | $ | 339.0 |  |  | $ | 99.4 |  |
| Total EPS impact |  | $ | 12.41 |  |  | $ | 3.61 |  |  | $ | 13.57 |  |  | $ | 3.97 |  |

[0001628280-26-003710:8k_2_02:95]
| Adjusted operating margin / Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-25 |  | Q4-24 |  | YTD-25 |  | YTD-24 |
| Net (loss) income |  | $ | (242.1) |  |  | $ | (51.8) |  |  | $ | (71.7) |  |  | $ | 100.2 |  |
| Add: |  |  |  |  |  |  |  |  |
| Income taxes |  | 12.9 |  |  | 9.1 |  |  | 75.3 |  |  | 51.7 |  |
| Interest expense |  | 8.3 |  |  | 9.4 |  |  | 34.3 |  |  | 38.7 |  |
| Foreign exchange loss (gain) |  | 1.1 |  |  | (13.5) |  |  | 16.6 |  |  | (9.2) |  |
| Other income, net |  | (3.0) |  |  | (2.7) |  |  | (17.0) |  |  | (22.6) |  |
| GAAP operating (loss) income |  | $ | (222.8) |  |  | $ | (49.5) |  |  | $ | 37.5 |  |  | $ | 158.8 |  |
| Non-GAAP adjustments to operating (loss) income |  | 310.4 |  |  | 100.5 |  |  | 326.4 |  |  | 112.0 |  |
| Adjusted operating income |  | $ | 87.6 |  |  | $ | 51.0 |  |  | $ | 363.9 |  |  | $ | 270.8 |  |
| Amortization of intangibles |  | 15.5 |  |  | 14.7 |  |  | 59.8 |  |  | 62.1 |  |
| Depreciation expense |  | 18.5 |  |  | 17.3 |  |  | 74.9 |  |  | 68.3 |  |
| Adjusted EBITDA |  | $ | 121.6 |  |  | $ | 83.0 |  |  | $ | 498.6 |  |  | $ | 401.2 |  |
| Net sales |  | $ | 593.9 |  |  | $ | 529.5 |  |  | $ | 2,386.3 |  |  | $ | 2,190.8 |  |
| Net (loss) income as a percentage of net sales |  | (40.8) | % |  | (9.8) | % |  | (3.0) | % |  | 4.6 | % |
| Operating margin |  | (37.5) | % |  | (9.3) | % |  | 1.6 | % |  | 7.2 | % |
| Adjusted operating margin |  | 14.7 | % |  | 9.6 | % |  | 15.2 | % |  | 12.4 | % |
| Adjusted EBITDA margin |  | 20.5 | % |  | 15.7 | % |  | 20.9 | % |  | 18.3 | % |

[0001628280-26-003710:8k_2_02:96]
10

[0001628280-26-003710:8k_2_02:97]
| Adjusted EBITDA by Segment |  | Q4-25 |  | Q4-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 59.8 |  |  | $ | 17.6 |  |  | $ | 10.2 |  |  | $ | 37.0 |  |  | $ | 3.7 |  |  | $ | 10.3 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 10.2 |  |  | 3.3 |  |  | 2.0 |  |  | 9.8 |  |  | 3.4 |  |  | 1.5 |  |
| Add back depreciation |  | 11.7 |  |  | 5.2 |  |  | 1.6 |  |  | 10.4 |  |  | 5.4 |  |  | 1.5 |  |
| Adjusted EBITDA |  | $ | 81.7 |  |  | $ | 26.1 |  |  | $ | 13.8 |  |  | $ | 57.2 |  |  | $ | 12.5 |  |  | $ | 13.3 |  |
| Adjusted EBITDA Margin |  | 23.7 | % |  | 16.0 | % |  | 16.2 | % |  | 20.0 | % |  | 7.7 | % |  | 16.2 | % |

[0001628280-26-003710:8k_2_02:98]
| Adjusted EBITDA by Segment |  | YTD-25 |  | YTD-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Electronics |  | Transportation |  | Industrial |
| GAAP operating income |  | $ | 220.1 |  |  | $ | 84.8 |  |  | $ | 59.0 |  |  | $ | 169.9 |  |  | $ | 58.6 |  |  | $ | 42.3 |  |
| Add: |  |  |  |  |  |  |  |  |  |  |  |  |
| Add back amortization |  | 40.4 |  |  | 13.5 |  |  | 5.9 |  |  | 39.4 |  |  | 13.5 |  |  | 9.2 |  |
| Add back depreciation |  | 47.6 |  |  | 21.2 |  |  | 6.1 |  |  | 40.4 |  |  | 22.1 |  |  | 5.8 |  |
| Adjusted EBITDA |  | $ | 308.1 |  |  | $ | 119.5 |  |  | $ | 71.0 |  |  | $ | 249.7 |  |  | $ | 94.2 |  |  | $ | 57.3 |  |
| Adjusted EBITDA Margin |  | 22.9 | % |  | 17.7 | % |  | 19.5 | % |  | 21.0 | % |  | 14.0 | % |  | 17.3 | % |

[0001628280-26-003710:8k_2_02:99]
| Net sales reconciliation |  | Q4-25 vs. Q4-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 21 | % |  | 1 | % |  | 4 | % |  | 12 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | — | % |  | 5 | % |  | 3 | % |
| FX impact |  | 2 | % |  | 2 | % |  | 1 | % |  | 2 | % |
| Organic net sales growth (decline) |  | 14 | % |  | (1) | % |  | (1) | % |  | 7 | % |

[0001628280-26-003710:8k_2_02:100]
| Electronics segment net sales reconciliation |  | Q4-25 vs. Q4-24 |
|  |  | Electronics - Semiconductor |  | Electronics - Passive Products and Sensors |  | Total Electronics |
| Net sales growth |  | 17 | % |  | 25 | % |  | 21 | % |
| Less: |  |  |  |  |  |  |
| Acquisitions |  | 9 | % |  | — | % |  | 4 | % |
| FX impact |  | 2 | % |  | 2 | % |  | 2 | % |
| Organic net sales growth |  | 6 | % |  | 23 | % |  | 14 | % |

[0001628280-26-003710:8k_2_02:101]
| Transportation segment net sales reconciliation |  | Q4-25 vs. Q4-24 |
|  |  | Commercial Vehicle Products |  | Passenger Car Products (1) |  | Auto Sensor Products (1) |  | Total Transportation |
| Net sales (decline) growth |  | (3) | % |  | 8 | % |  | (7) | % |  | 1 | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | 1 | % |  | 3 | % |  | 5 | % |  | 2 | % |
| Organic net sales (decline) growth |  | (4) | % |  | 5 | % |  | (12) | % |  | (1) | % |

[0001628280-26-003710:8k_2_02:102]
(1) Passenger vehicle business (PVB) includes passenger car and auto sensor products.

[0001628280-26-003710:8k_2_02:103]
11

[0001628280-26-003710:8k_2_02:104]
| Net sales reconciliation |  | YTD-25 vs. YTD-24 |
|  |  | Electronics |  | Transportation |  | Industrial |  | Total |
| Net sales growth |  | 13 | % |  | 1 | % |  | 10 | % |  | 9 | % |
| Less: |  |  |  |  |  |  |  |  |
| Acquisitions |  | 4 | % |  | — | % |  | 1 | % |  | 2 | % |
| FX impact |  | 1 | % |  | 1 | % |  | — | % |  | 1 | % |
| Organic net sales growth (decline) |  | 8 | % |  | (1) | % |  | 9 | % |  | 6 | % |

[0001628280-26-003710:8k_2_02:105]
| Electronics segment net sales reconciliation |  | YTD-25 vs. YTD-24 |
|  |  | Electronics - Semiconductor |  | Electronics - Passive Products and Sensors |  | Total Electronics |
| Net sales growth |  | 9 | % |  | 18 | % |  | 13 | % |
| Less: |  |  |  |  |  |  |
| Acquisitions |  | 8 | % |  | — | % |  | 4 | % |
| FX impact |  | 1 | % |  | 1 | % |  | 1 | % |
| Organic net sales growth |  | — | % |  | 17 | % |  | 8 | % |

[0001628280-26-003710:8k_2_02:106]
| Transportation segment net sales reconciliation |  | YTD-25 vs. YTD-24 |
|  |  | Commercial Vehicle Products |  | Passenger Car Products (1) |  | Auto Sensor Products (1) |  | Total Transportation |
| Net sales growth (decline) |  | — | % |  | 6 | % |  | (15) | % |  | 1 | % |
| Less: |  |  |  |  |  |  |  |  |
| FX impact |  | 1 | % |  | 1 | % |  | 2 | % |  | 1 | % |
| Organic net sales (decline) growth |  | (1) | % |  | 5 | % |  | (18) | % |  | (1) | % |

[0001628280-26-003710:8k_2_02:107]
(1) Passenger vehicle business (PVB) includes passenger car and auto sensor products.

[0001628280-26-003710:8k_2_02:108]
| Income tax reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-25 |  | Q4-24 |  | YTD-25 |  | YTD-24 |
| Income taxes |  | $ | 12.9 |  |  | $ | 9.1 |  |  | $ | 75.3 |  |  | $ | 51.7 |  |
| Effective rate |  | (5.6) | % |  | (21.3) | % |  | 2,088.2 | % |  | 34.0 | % |
| Non-GAAP adjustments - income taxes |  | 2.4 |  |  | (1.5) |  |  | 4.6 |  |  | 4.7 |  |
| Adjusted income taxes |  | $ | 15.3 |  |  | $ | 7.6 |  |  | $ | 79.9 |  |  | $ | 56.4 |  |
| Adjusted effective rate |  | 18.4 | % |  | 16.6 | % |  | 23.0 | % |  | 22.0 | % |

[0001628280-26-003710:8k_2_02:109]
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Q4-25 |  | Q4-24 |  | YTD-25 |  | YTD-24 |
| Net cash provided by operating activities |  | $ | 138.7 |  |  | $ | 160.6 |  |  | $ | 433.8 |  |  | $ | 367.6 |  |
| Less: Purchases of property, plant and equipment |  | (18.9) |  |  | (25.8) |  |  | (67.6) |  |  | (75.9) |  |
| Free cash flow |  | $ | 119.7 |  |  | $ | 134.8 |  |  | $ | 366.1 |  |  | $ | 291.7 |  |

[0001628280-26-003710:8k_2_02:110]
12

[0001628280-26-003710:8k_2_02:111]
| Consolidated Total Debt |  | As of December 27, 2025 |
| Consolidated Total Debt |  | $ | 802.6 |  |
| Unamortized debt issuance costs |  | 1.8 |  |
| Finance lease liability |  | 0.2 |  |
| Consolidated funded indebtedness |  | $ | 804.6 |  |
| Cash held in U.S. (up to $400 million) |  | 144.3 |  |
| Net debt |  | $ | 660.3 |  |
| Consolidated EBITDA |  | Twelve Months EndedDecember 27, 2025 |
| Net loss |  | $ | (71.9) |  |
| Interest expense |  | 34.3 |  |
| Income taxes |  | 75.3 |  |
| Depreciation |  | 74.9 |  |
| Amortization |  | 59.8 |  |
| Non-cash additions: |  |  |
| Stock-based compensation expense |  | 27.3 |  |
| Purchase accounting inventory step-up charge |  | 0.6 |  |
| Unrealized loss on investments |  | 3.6 |  |
| Impairment charges |  | 302.1 |  |
| Other |  | 38.5 |  |
| Consolidated EBITDA (1) |  | $ | 544.5 |  |
| Consolidated Net Leverage Ratio (as defined in the Credit Agreement) * |  | 1.2x |

[0001628280-26-003710:8k_2_02:112]
* Our Credit Agreement and Private Placement Note with maturities ranging from 2024 to 2032, contain financial ratio covenants providing that if, as of the last day of each fiscal quarter, the Consolidated Net Leverage ratio at such time for the then most recently concluded period of four consecutive fiscal quarters of the Company exceeds 3.50:1.00, an Event of Default (as defined in the Credit Agreement and Private Placement Senior Notes) is triggered.

[0001628280-26-003710:8k_2_02:113]
The Credit Agreement and Private Placement Senior Notes were amended in Q2 2022 and now allow for the addition of acquisition and integration costs up to 15% of Consolidated EBITDA and the netting of up to $400M of Available Cash (Cash held by US Subsidiaries).

[0001628280-26-003710:8k_2_02:114]
(1) Represents Consolidated EBITDA as defined in our Credit Agreement and Private Placement Senior Notes and is calculated using the most recently concluded period of four consecutive quarters.

[0001628280-26-003710:8k_2_02:115]
Note: Total will not always foot due to rounding.

[0001628280-26-003710:8k_2_02:116]
(a) reflected in selling, general and administrative expenses ("SG&A").

[0001628280-26-003710:8k_2_02:117]
(b) reflected in cost of sales.

[0001628280-26-003710:8k_2_02:118]
(c) reflected in restructuring, impairment and other charges. In the fourth quarter of 2025, the Company recorded a $301.2 million non-cash goodwill impairment charge related to the Electronics-Semiconductor reporting unit within the Electronics segment. The Company recognized impairment charges of $0.5 million and $0.4 million related to certain machinery and equipment in the commercial vehicle business within the Transportation segment and the electronics products business within the Electronics segment, respectively. In the fourth quarter of 2024, the Company recorded $92.6 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million non-cash goodwill impairment charge associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0001628280-26-003710:8k_2_02:119]
(d) 2024 amount reflected a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment and a gain of $1.0 million for the sale of two buildings within the Transportation segment.

[0001628280-26-003710:8k_2_02:120]
(e) 2025 amount reflected $0.3 million loss related to the sale of the Marine business within the Transportation segment.

[0001628280-26-003710:8k_2_02:121]
13

[0001628280-26-003710:8k_2_02:122]
(f) 2025 included $0.6 million increase in coal mining reserves. 2024 included $1.8 million increase in coal mining reserves, partially offset by a reversal of $0.5 million for an asset retirement obligation charge related the disposal of a business in 2019.

[0001628280-26-003710:8k_2_02:123]
(g) reflected the tax impact associated with the non-GAAP adjustments.

[0001628280-26-003710:8k_2_02:124]
###

[0001628280-26-003710:8k_2_02:125]
14
