# LFUS MD&A — 0001628280-26-009585


## mdna

[0001628280-26-009585:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001628280-26-009585:mdna:2]
The following discussion of the Company's financial condition and results of operations should be read together with the Consolidated Financial Statements and notes to those statements included in Item 8 of Part II of this Annual Report on Form 10-K.

[0001628280-26-009585:mdna:3]
BUSINESS

[0001628280-26-009585:mdna:4]
For a description of the Company’s business, segments and product offerings, see Item 1, Business.

[0001628280-26-009585:mdna:5]
2025 EXECUTIVE OVERVIEW

[0001628280-26-009585:mdna:6]
Net sales were $2,386.3 million, which increased by $195.5 million, or 8.9%, in 2025 compared to 2024 including $49.0 million, or 2.2% of incremental net sales, from the Dortmund Fab acquisition (defined below) in the semiconductor business within the Electronics segment and $17.6 million or 0.8% of favorable changes in foreign exchange rates. The remaining increase in net sales was primarily due to higher volume of $104.5 million in the electronics products business within the Electronics segment and $32.8 million in the Industrial segment due to higher end market demand and favorable pricing. The Company recognized a net loss of $71.7 million, or $2.89 per diluted share, in 2025 compared to net income of $100.2 million, or $4.00 per diluted share in 2024. The net loss was primarily impacted by a $301.2 million non-cash goodwill impairment charge for the Electronics-Semiconductor reporting unit within the Electronics segment during the fourth quarter of 2025, partially offset by higher operating income of $50.2 million within the Electronics segment driven by the electronics products business and increases of $26.2 million and $16.7 million in operating income across the Transportation and Industrial segments, respectively.

[0001628280-26-009585:mdna:7]
Net cash provided by operating activities was $433.8 million in the fiscal year 2025, an increase of $66.1 million, compared to $367.6 million in the fiscal year 2024. The increase in net cash provided by operating activities was primarily due to higher cash earnings compared to prior year.

[0001628280-26-009585:mdna:8]
On December 11, 2025, the Company completed the acquisition of Basler Electric Company ("Basler"). Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. At the time of acquisition, Basler had annualized sales of approximately $130 million. The business is reported within the Company’s Industrial segment. The total purchase consideration was $350.3 million, net of cash acquired, subject to a working capital adjustment.

[0001628280-26-009585:mdna:9]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The total purchase price for the Dortmund Fab was approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment.

[0001628280-26-009585:mdna:10]
Other Risk

[0001628280-26-009585:mdna:11]
The Company uses various metals in the manufacturing of its products, including copper, zinc, tin, gold, silver, and ruthenium. Worldwide demand, availability, and pricing of these raw materials have been volatile. In recent years, the prices of many of these raw materials continue to fluctuate, and in many cases increase, and fluctuations may persist in the future. Also in the fourth quarter and through the date of filing, precious metal commodity pricing has significantly increased. If the Company must pay more for certain materials, it could reduce our profit margin or otherwise have a material adverse effect on our business and financial results.

[0001628280-26-009585:mdna:12]
Recently, the U.S. government has imposed extensive tariffs on goods imported from several countries, including, without limitation, China, Mexico and Canada, as well as certain broad, product-specific tariffs on foreign goods and products. Tariffs may increase the cost of materials in our supply chain, incur reciprocal levies on components and finished products exported to or imported from affected countries, and have an adverse impact on our cost of goods sold in the U.S. and abroad. These factors in turn could require us to materially increase prices to our customers which may reduce demand, or, if we do not or are unable to increase prices, could result in lower gross margins on products sold.

[0001628280-26-009585:mdna:13]
Tariffs have resulted in China and other countries imposing reciprocal tariffs on U.S. goods and ceasing sales of certain products to the U.S. and could result in more U.S. trading partners adopting responsive trade policies, including making it more difficult or costly for us to export our products to those countries. Sales to customers outside of the U.S., and to China in particular, comprise a significant portion of our net sales, and reciprocal tariffs may impact our business in China. Further, tariffs and trade policies may continue to change quickly and without warning, and we may not be able to accurately anticipate and mitigate the impacts.

[0001628280-26-009585:mdna:14]
Critical Accounting Estimates

[0001628280-26-009585:mdna:15]
The preparation of financial statements in conformity with Generally Accepted Accounting Principles ("GAAP") requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Although management believes that its estimates and assumptions are reasonable, they are based upon information available when they are made, and therefore, actual results may differ from these estimates under different assumptions or conditions. The Company has reviewed these critical accounting estimates and related disclosures with the Audit Committee of its Board of Directors. Significant accounting policies are described in the Notes to Consolidated Financial Statements included elsewhere in this Annual Report.

[0001628280-26-009585:mdna:16]
Goodwill

[0001628280-26-009585:mdna:17]
The Company’s methodology for allocating the purchase price of acquisitions is based on established valuation techniques that reflect the consideration of a number of factors, including valuations performed by third-party appraisers when appropriate. Goodwill is measured as the excess of the cost of an acquired entity over the fair value assigned to identifiable assets acquired and liabilities assumed. Based on its current organization structure, the Company has seven reporting units for which cash flows are determinable and to which goodwill has been allocated.

[0001628280-26-009585:mdna:18]
The Company annually tests goodwill for impairment on the first day of its fiscal fourth quarter, or more frequently if an event occurs or circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying value. The Company also performs an interim review for indicators of impairment each quarter to assess whether an interim impairment review is required for any reporting unit. As part of its interim reviews, management analyzes potential changes in the value of individual reporting units based on each reporting unit’s operating results for the period compared to expected results as of the prior year’s annual impairment test. In addition, management considers how other key assumptions, including discount rates and expected long-term growth rates, used in the last annual impairment test, could be impacted by changes in market conditions and economic events.

[0001628280-26-009585:mdna:19]
Based on the results of the annual goodwill impairment test in 2025, in the fourth quarter, the Company recorded a non-cash charge of $301.2 million to reflect the impairment of goodwill for the Electronics-Semiconductor reporting unit within the Electronics segment, reflecting the amount by which the reporting unit’s estimated fair value was below its carrying value. The estimated fair value declined primarily due to updates to management’s forecasts that reduced revenue growth, profitability and cash flows. These forecasts require significant judgment and are inherently uncertain, particularly in light of the recent leadership transition and strategic reassessment in the semiconductor business. The reduction in projected cash flows was driven principally by lower projected volumes in the power semiconductor business, largely associated with the Dortmund fab, which reduced expected future cash generation for the reporting unit. Changes in future operating performance relative to these projections, or further changes in strategy, market conditions, or execution related to the Dortmund fab, could affect the reporting unit’s estimated fair value and may result in additional impairment charges in future periods.

[0001628280-26-009585:mdna:20]
As a result of the 2024 annual goodwill impairment test, the Company recorded non-cash charges of $36.1 million and $8.6 million to reflect the impairment of goodwill for the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment, respectively. The goodwill impairment charge for the Industrial Controls and Sensors reporting unit was due to a reduction in the estimated fair value of the reporting unit based on lower expectations for future revenue, profitability and cash flows as compared to the expectations of the 2023 annual goodwill impairment test. These lower expectations were driven by lower-than-expected demand in the electric vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe.

[0001628280-26-009585:mdna:21]
There was no impairment charge recorded during the fiscal year of 2023.

[0001628280-26-009585:mdna:22]
Quantitative Assessment for Impairment

[0001628280-26-009585:mdna:23]
For the six reporting units with goodwill, the Company compares the estimated fair value of each reporting unit to its carrying value. There was no goodwill remaining within the Automotive Sensors reporting unit. If the carrying value of a reporting unit exceeds the estimated fair value, the difference between the estimated fair value and carrying value is recorded as the amount of the goodwill impairment charge. As a result of the impairment charge described above, the Electronics-Semiconductor reporting unit had $238.5 million of goodwill as of December 27, 2025. For the remainder of the Company's reporting units with goodwill: Electronics-Passive Products and Sensors, Passenger Car Products, Commercial Vehicle Products, Industrial Controls and Sensors, and Industrial Circuit Protection, the results of the goodwill impairment test as of September 28, 2025 indicated that their estimated fair values exceeded their respective carrying values.

[0001628280-26-009585:mdna:24]
As part of its impairment test for these reporting units, the Company engaged a third-party appraisal firm to assist in the Company’s determination of the estimated fair values. This determination included estimating the fair value of each reporting unit using both the income and market approaches. The income approach requires management to estimate a number of factors for each reporting unit, including projected operating results, economic projections, anticipated future cash flows, discount rates and the allocation of shared or corporate items. The market approach estimates fair values using comparable marketplace fair value data from within a comparable industry grouping. The Company weighted both the income and market approach equally to estimate the concluded fair value of each reporting unit. The determination of fair value requires the Company to make significant estimates and assumptions, which primarily include, but are not limited to: the selection of appropriate peer group companies; control premiums appropriate for acquisitions in which the Company competes; the discount rate; terminal growth rates; and forecasts of revenue, operating income, depreciation and amortization and capital expenditures.

[0001628280-26-009585:mdna:25]
Goodwill Impairment Assumptions

[0001628280-26-009585:mdna:26]
Although the Company believes its estimates of fair value are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results or other underlying assumptions could have a significant impact on the fair value of the reporting units. Future declines in the overall market value of the Company’s equity may also result in a conclusion that the fair value of one or more reporting units has declined below its carrying value.

[0001628280-26-009585:mdna:27]
One measure of the sensitivity of the amount of goodwill impairment charges to key assumptions is the amount by which each reporting unit “passed” (fair value exceeds the carrying value) the goodwill impairment test. With the exception of the Electronics-Semiconductor reporting unit within the Electronics segment, the other five reporting units with goodwill passed the goodwill impairment test, with estimated fair values that exceeded the carrying values between 22% and 303%. As of the most recent annual test conducted on September 28, 2025, the Company noted that the excess of fair value over the carrying value was 87%, 153%, 99%, 22% and 303% for its reporting units: Electronics-Passive Products and Sensors, Passenger Car Products, Commercial Vehicle Products, Industrial Controls and Sensors, and Industrial Circuit Protection, respectively.

[0001628280-26-009585:mdna:28]
Generally, changes in estimates of expected future cash flows would have a similar effect on the estimated fair value of the reporting unit. That is, a 1.0% decrease in estimated annual future cash flows would decrease the estimated fair value of the reporting unit by approximately 1.0%. The estimated long-term net sales growth rate can have a significant impact on the estimated future cash flows, and therefore, the fair value of each reporting unit. A 1.0% decrease in the long-term net sales growth rate would have resulted in no additional reporting units failing the goodwill impairment test. Of the other key assumptions that impact the estimated fair values, most reporting units have the greatest sensitivity to changes in the estimated discount rate. The estimated discount rate was 12.0% for the Electronics-Passive Products and Sensors reporting unit, 12.5% for the Electronics-Semiconductor reporting unit, 11.0% for the Passenger Car Products and Commercial Vehicle Products reporting units, 14.0% for the Industrial Controls and Sensors reporting unit, and 13.0% for Industrial Circuit Protection reporting unit. A 1.0% increase in the estimated discount rates would have resulted in no reporting units failing the annual goodwill impairment test. The Company believes that its estimates of future cash flows and discount rates are reasonable, but future changes in the underlying assumptions could differ due to the inherent uncertainty in making such estimates. Additionally, price deterioration or lower volume could have a significant impact on the fair values of the reporting units.

[0001628280-26-009585:mdna:29]
Long-Lived Assets

[0001628280-26-009585:mdna:30]
The Company evaluates the recoverability of other long-lived assets, including property, plant and equipment and certain identifiable intangible assets, whenever events or changes in circumstances indicate that the carrying value of an asset or asset group may not be recoverable. Factors which could trigger an impairment review include significant underperformance relative to historical or projected operating results, significant changes in the manner of use of the assets or the strategy for the overall business, and a significant decrease in the market value of the assets or significant negative industry or economic trends. When the Company determines that the carrying value of long-lived assets may not be recoverable based upon the existence of one or

[0001628280-26-009585:mdna:31]
more of the indicators, the assets are assessed for impairment based on the estimated future undiscounted cash flows expected to result from the use of the asset and its eventual disposition. If the carrying value of an asset exceeds its estimated future undiscounted cash flows, an impairment loss is recorded for the excess of the asset’s carrying value over its fair value.

[0001628280-26-009585:mdna:32]
For the fiscal year ended December 27, 2025, the Company recognized impairment charges of $0.5 million and $0.4 million related to certain machinery and equipment in the commercial vehicle business within the Transportation segment and the electronics products business within the Electronics segment, respectively.

[0001628280-26-009585:mdna:33]
For the fiscal year ended December 28, 2024, the Company recorded non-cash impairment charges of $47.8 million for the impairment of intangible assets, including $47.6 million related to the impairment of certain acquired customer relationships, developed technology, and tradename intangible assets in the Industrial controls and sensors reporting unit within the Industrial segment. The impairment of the intangible assets resulted from lower expectations of future revenue and cash flows driven by lower-than-expected demand in the electrical vehicle end market as well as reduced government funding to support charging infrastructures for electric vehicles, primarily in Europe. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment related to certain machinery and equipment in the commercial vehicle business within the Transportation segment.

[0001628280-26-009585:mdna:34]
For the fiscal year ended December 30, 2023, the Company recognized a $3.9 million impairment charge related to the land and building of a property in the commercial vehicle business within the Transportation segment that the Company made the decision to donate, a $0.9 million impairment charge substantially related to certain patents in a business within the Industrial segment, and a $0.1 million impairment on certain machinery and equipment in the semiconductor business within the Electronics segment.

[0001628280-26-009585:mdna:35]
Purchase Price Allocation

[0001628280-26-009585:mdna:36]
The Company records acquisitions using the purchase method of accounting. All of the assets acquired and liabilities assumed are recorded at fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. The fair value assigned to tangible and intangible assets acquired and liabilities assumed are based on management’s estimates and assumptions, as well as other information compiled by management, including valuations that utilize customary valuation procedures and techniques. Significant assumptions and estimates include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. If the actual results differ from the estimates and judgments used in these estimates, the amounts recorded in the financial statements may be exposed to potential impairment of the intangible assets and goodwill, as discussed in the Goodwill and Long-lived Assets under the Critical Accounting Estimates section.

[0001628280-26-009585:mdna:37]
A significant portion of these fair value measurements relate to identifiable intangible assets, including customer relationships. The valuation of customer relationships is a critical accounting estimate due to the significant judgment required and the sensitivity of the estimate to changes in assumptions. Changes in these assumptions, particularly the attrition rate and discount rate, could have a material impact on the estimated fair value of customer relationships and the related amortization expense recognized in future periods.

[0001628280-26-009585:mdna:38]
Income Taxes

[0001628280-26-009585:mdna:39]
The Company accounts for income taxes using the asset and liability method. Deferred taxes are recognized for the future effects of temporary differences between financial and income tax reporting using tax rates in effect for the years in which the differences are expected to reverse. The Company recognizes deferred taxes for temporary differences, operating loss carryforwards and tax credit and other tax attribute carryforwards (excluding carryforwards where usage has been determined to be remote). Deferred tax assets are reduced by a valuation allowance if it is more likely than not that some portion, or all, of the deferred tax assets will not be realized. U.S. state and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to the U.S. and be taxable (and non-U.S. income taxes are provided on the portion of non-U.S. income that is expected to be remitted to an upper-tier non-U.S. entity). Deferred tax assets and liabilities are adjusted for the effects of changes in tax laws and rates on the date of enactment.

[0001628280-26-009585:mdna:40]
Deferred income taxes are not provided on the excess of the investment value for financial reporting over the tax basis of investments in those non-U.S. subsidiaries for which such excess is considered to be permanently reinvested in those operations. Management regularly evaluates whether non-U.S. earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its non-U.S. subsidiaries. Changes in economic and business conditions, non-U.S. or U.S. tax laws, or the Company’s financial situation could result in changes to these judgments and the need to record additional tax liabilities.

[0001628280-26-009585:mdna:41]
The Company recognizes the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such a position are measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement.

[0001628280-26-009585:mdna:42]
There are a number of estimates and assumptions inherent in calculating the various components of income taxes. Future events such as changes in tax legislation, jurisdictional mix of earnings, findings in tax audits, and earnings repatriation plans could have an impact on those estimates and our effective tax rate.

[0001628280-26-009585:mdna:43]
The 2017 Tax Cuts and Jobs Act (the "Tax Act"), among other things, imposed a one-time tax (the “Toll Charge”) on accumulated earnings of certain non-U.S. subsidiaries and included base broadening provisions commonly referred to as the global intangible low-taxed income provisions ("GILTI").

[0001628280-26-009585:mdna:44]
The Company elected to pay its 2017 Toll Charge over the eight-year period prescribed by the Tax Act. The eighth and final installment of the Toll Charge of $8.2 million was paid in 2025, and accordingly, there was no remaining liability on the Consolidated Balance Sheet as of December 27, 2025.

[0001628280-26-009585:mdna:45]
In accordance with guidance issued by the Financial Accounting Standards Board ("FASB") staff, the Company has adopted an accounting policy to treat any GILTI inclusions as a period cost if and when incurred. Thus, for the fiscal years ended December 27, 2025, December 28, 2024, and December 30, 2023, deferred taxes were computed without consideration of the possible future impact of the GILTI provisions, and any current year impact was recorded as a part of the current portion of income tax expense.

[0001628280-26-009585:mdna:46]
On July 4, 2025, the United States enacted into law the legislation formally titled "An Act to provide for reconciliation pursuant to title II of H. Con. Res. 14," and commonly referred to as the One Big Beautiful Bill Act ("OBBB"). The OBBB contains multiple business tax provisions, including the permanent extension of several expiring provisions of the Tax Act and multiple modifications to the international tax framework. The legislation has multiple effective dates with certain provisions effective in 2025 and others to be implemented in future years, and the Company determined the impact for the year ended December 27, 2025 was not significant. The Company will continue to monitor future administrative guidance and regulations that clarify the legislative text of the OBBB and the bill’s potential effect on the Company’s income taxes.

[0001628280-26-009585:mdna:47]
Further information regarding income taxes, including a detailed reconciliation of current year activity, is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001628280-26-009585:mdna:48]
Pension Plans

[0001628280-26-009585:mdna:49]
The Company records annual income and expense amounts relating to its pension and postretirement benefits plans based on calculations which include various actuarial assumptions including discount rates, expected long-term rates of return, and compensation increases. The Company reviews its actuarial assumptions on an annual basis as of the fiscal year-end balance sheet date (or more frequently if a significant event requiring remeasurement occurs) and modifies the assumption based on current rates and trends when it is appropriate to do so. The effects of modifications are recognized immediately on the Consolidated Balance Sheets but are generally amortized into operating earnings over future periods, with the deferred amount recorded in accumulated other comprehensive loss. The Company believes that the assumptions utilized in recording its obligations under its plans are reasonable based on its experience, market conditions and input from its actuaries and investment advisors. The Company maintains several pension plans in international locations. The expected returns on plan assets and discount rates are determined based on each plan’s investment approach, local interest rates and plan participant profiles. The weighted-average discount rates for the Company’s defined benefit plans primarily in Europe and the Asia-Pacific regions at December 27, 2025 and December 28, 2024 were  6.1% and 5.6%, respectively.

[0001628280-26-009585:mdna:50]
On October 4, 2024, the Company entered into a definitive agreement to purchase a group annuity contract, under which an insurance company will be required to pay pension payments to the Company’s United Kingdom pension plan to match required pension payments until a later buyout, at which point the insurance company will directly pay and administer the

[0001628280-26-009585:mdna:51]
benefits to the plan's participants, or to their designated beneficiaries. The purchase of this group annuity contract will reduce the Company’s outstanding pension benefit obligation by approximately $25 million, representing approximately 31% of the total obligations of the Company’s qualified pension plans, and will be funded with pension plan assets and additional cash on hand. In connection with this transaction, the Company currently expects to record a one-time non-cash settlement charge in the second half of 2026 estimated between $6 million and $8 million, reflecting the accelerated recognition of a portion of unamortized actuarial losses in the plan. The actual settlement charge could differ from this estimate due to final data and plan wind-up expenses.

[0001628280-26-009585:mdna:52]
Equity-Based Compensation

[0001628280-26-009585:mdna:53]
Equity-based compensation expense is recorded for stock-option awards and restricted share units and performance share units based upon the fair values of the awards. The fair value of stock-option awards is estimated at the grant date using the Black-Scholes option pricing model, which includes assumptions for volatility, expected term, risk-free interest rate, and dividend yield. Expected volatility is based on implied volatilities from traded options on Littelfuse stock, historical volatility of Littelfuse stock, and other factors. Historical data is used to estimate employee termination experience and the expected term of the options. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company initiated a quarterly cash dividend in 2010 and expects to continue making cash dividend payments for the foreseeable future. The fair value of restricted share units without rights to dividend equivalents is determined based on the Company's stock price on the grant date reduced by the present value of expected dividends through the vesting period. The fair value of restricted share units with rights to dividend equivalents is based on the Company’s stock price on the grant date. The fair value of performance share units is estimated at the grant date using Monte Carlo simulation which includes assumptions for volatility, correlation, risk-free interest rate, and dividend yield. Expected volatilities and correlation factors are based on the historical volatility of the Company’s and each peer company’s stock price. The risk-free rates are based on yields available at the time of grant on U.S. Treasury bonds with maturities consistent with the remaining performance period.

[0001628280-26-009585:mdna:54]
Total equity-based compensation expense for all equity compensation plans was $28.6 million, $27.4 million, and $25.7 million in 2025, 2024, and 2023, respectively. Further information regarding this expense is provided in Note 12, Stock-Based Compensation, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001628280-26-009585:mdna:55]
In the financial review that follows, the Company discusses its consolidated results of operations, financial position, cash flows and certain other information. This discussion should be read in conjunction with the Company’s Consolidated Financial Statements and related notes.

[0001628280-26-009585:mdna:56]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 27, 2025 AS COMPARED TO THE YEAR ENDED DECEMBER 28, 2024

[0001628280-26-009585:mdna:57]
Fiscal year 2025 included $302.1 million of non-cash impairment charges, which included a $301.2 million non-cash goodwill impairment charge associated with the Electronics-Semiconductor reporting unit within the Electronics segment. In addition, the Company recognized impairment charges of $0.5 million and $0.4 million related to certain machinery and equipment in the commercial vehicle business within the Transportation segment and the electronics products business within the Electronics segment, respectively. The Company also recognized total restructuring charges of $18.0 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions in the power semiconductor business within the Electronics segment and the reorganization of certain manufacturing, selling and administrative functions in the commercial vehicle business and automotive sensors business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.4 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $0.6 million of purchase accounting inventory adjustments related to the Basler and Dortmund Fab acquisitions, and a $0.3 million loss related to the sale of the Marine business within the Transportation segment.

[0001628280-26-009585:mdna:58]
Fiscal year 2024 included $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial Controls and Sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and

[0001628280-26-009585:mdna:59]
the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0001628280-26-009585:mdna:60]
Fiscal year 2025 also included approximately $16.6 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro and Chinese renminbi against the U.S. dollar, while fiscal year 2024 included approximately $9.2 million in foreign currency exchange gains primarily attributable to changes in the value of the Euro, Korean won, and Chinese renminbi against the U.S. dollar.

[0001628280-26-009585:mdna:61]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2025 |  | 2024 |  | Change |  | % Change |
| Net sales | $ | 2,386,294 |  |  | $ | 2,190,768 |  |  | $ | 195,526 |  |  | 8.9 | % |
| Cost of sales | 1,480,251 |  |  | 1,403,226 |  |  | 77,025 |  |  | 5.5 | % |
| Gross profit | 906,043 |  |  | 787,542 |  |  | 118,501 |  |  | 15.0 | % |
| Operating expenses | 868,515 |  |  | 628,762 |  |  | 239,753 |  |  | 38.1 | % |
| Operating income | 37,528 |  |  | 158,780 |  |  | (121,252) |  |  | (76.4) | % |
| Other income, net | (16,994) |  |  | (22,570) |  |  | (5,576) |  |  | (24.7) | % |
| Income before income taxes | 3,607 |  |  | 151,863 |  |  | (148,256) |  |  | (97.6) | % |
| Income taxes | 75,307 |  |  | 51,673 |  |  | 23,634 |  |  | 45.7 | % |
| Net (loss) income | (71,700) |  |  | 100,190 |  |  | (171,890) |  |  | (171.6) | % |

[0001628280-26-009585:mdna:62]
Net Sales

[0001628280-26-009585:mdna:63]
Net sales were $2,386.3 million, which increased by $195.5 million, or 8.9% compared to 2024, including $49.0 million or 2.2% of incremental net sales, from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and $17.6 million or 0.8% of favorable changes in foreign exchange rates for 2025 compared to 2024. The remaining increase in net sales was primarily due to higher volume of $104.5 million in the electronics products business within the Electronics segment and $32.8 million in the Industrial segment due to higher end market demand and favorable price.

[0001628280-26-009585:mdna:64]
Cost of Sales

[0001628280-26-009585:mdna:65]
Cost of sales was $1,480.3 million, or 62.0% of net sales, in 2025 compared to $1,403.2 million, or 64.1% of net sales, in 2024. As a percent of net sales, cost of sales decreased 2.1% primarily driven by higher volume in the electronics products business within the Electronics segment and across all businesses in the Industrial segment. Additionally, improved margin from the passenger car products within the Transportation segment driven by volume leverage, favorable price, and cost reduction initiatives favorably impacted the decrease in cost of sales as a percentage of net sales that was partially offset by lower margin from the semiconductor business within the Electronics segment. During the fiscal year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that were corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The error that was identified by management related to the valuation and existence of inventory that originated in prior periods at certain of our non-U.S. manufacturing locations within the Transportation and Industrial segments. As a result, the Company recorded an out-of-period adjustment of $13.5 million in the year ended December 28, 2024, of which $12.3 million was the cumulative out-of-period adjustment related to fiscal years prior to 2024. The out-of-period adjustment negatively impacted cost of sales as a percentage of net sales by 0.6%.

[0001628280-26-009585:mdna:66]
Gross Profit

[0001628280-26-009585:mdna:67]
Gross profit was $906.0 million, or 38.0% of net sales, in 2025 compared to $787.5 million, or 35.9% of net sales, in 2024. The $118.5 million increase in gross profit was primarily from higher net sales of $104.5 million in the electronics products business within the Electronics segment, $15.3 million in the passenger car products business within the Transportation segment, and improved margin in the industrial circuit protection products business within the Industrial segment, driven by higher volume, favorable price, and product mix. As mentioned above, the out-of-period adjustments of $13.5 million negatively impacted gross margin by 0.6% for the fiscal year 2024.

[0001628280-26-009585:mdna:68]
Operating Expenses

[0001628280-26-009585:mdna:69]
Total operating expenses were $868.5 million, or 36.4% of net sales, for 2025 compared to $628.8 million, or 28.7% of net sales, for 2024. The increase in operating expenses of $239.8 million was primarily due to an increase in restructuring, impairment, and other charges of $211.6 million. The Company recorded a non-cash goodwill impairment charge of $301.2 million associated with the Electronics-Semiconductor reporting unit within the Electronics segment during 2025, while in 2024, the Company recorded $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial Controls and Sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment, respectively. Additionally, the remaining increase in operating expenses in 2025 was due to higher selling, general, and administrative expenses of $31.4 million driven by higher annual incentive compensation expenses and the Dortmund Fab acquisition.

[0001628280-26-009585:mdna:70]
Operating Income

[0001628280-26-009585:mdna:71]
Operating income in 2025 was $37.5 million, a decrease of $121.3 million or 76.4% compared to $158.8 million for 2024.  The decrease in operating income was primarily due to the non-cash goodwill impairment charge of $301.2 million recognized in 2025 compared to the non-cash charge of $92.6 million from the impairment of intangible assets and goodwill in 2024 as noted above, partially offset by higher operating income of $50.2 million,  $26.2 million and $16.7 million across the Electronics, Transportation and Industrial segments, respectively. Operating margins decreased from 7.2% in 2024 to 1.6% in 2025 primarily driven by higher non-cash impairment charge mentioned above. The non-cash charge of $301.2 million from the impairment of goodwill negatively impacted the 2025 operating margin by 12.6%, while the total non-cash charges of $92.6 million from the impairment of intangible assets and goodwill negatively impacted the 2024 operating margin by 4.2%.

[0001628280-26-009585:mdna:72]
Income Before Income Taxes

[0001628280-26-009585:mdna:73]
Income before income taxes in 2025 was $3.6 million, or 0.2% of net sales compared to $151.9 million, or 6.9% of net sales for 2024. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily impacted by foreign exchange losses of $16.6 million in the fiscal year 2025 compared to foreign exchange gains of $9.2 million in the fiscal year 2024, and unrealized losses of $3.6 million during the fiscal year 2025 compared to unrealized gains of $0.1 million during the fiscal year 2024 related to the Company's equity investment, and higher loss of $1.0 million from investments under equity method and higher non-operating pension expense of $0.9 million.

[0001628280-26-009585:mdna:74]
Income Taxes

[0001628280-26-009585:mdna:75]
Income tax expense in 2025 was $75.3 million, or an effective tax rate of 2,087.8%, compared to income tax expense of $51.7 million, or an effective tax rate of 34.0% in 2024. The effective tax rate in 2025 is higher than the effective tax rate for 2024, primarily due to the increased impact of the goodwill impairment charge in 2025 with no related tax benefit. The effective tax rate for 2025 is higher than the statutory tax rate primarily due to the impact of the 2025 goodwill impairment with no related tax benefit as previously noted. Further information regarding these items is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001628280-26-009585:mdna:76]
Segment Information

[0001628280-26-009585:mdna:77]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001628280-26-009585:mdna:78]
The following table is a summary of the Company’s net sales and operating income by segment:

[0001628280-26-009585:mdna:79]
| Net Sales | Fiscal Year |  |  |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  | % Change |
| Electronics | $ | 1,345.5 |  |  | $ | 1,186.8 |  |  | $ | 158.7 |  |  | 13.4 | % |
| Transportation | 676.4 |  |  | 672.4 |  |  | 4.0 |  |  | 0.6 | % |
| Industrial | 364.4 |  |  | 331.6 |  |  | 32.8 |  |  | 9.9 | % |
| Total | $ | 2,386.3 |  |  | $ | 2,190.8 |  |  | $ | 195.5 |  |  | 8.9 | % |

[0001628280-26-009585:mdna:80]
| Segment Operating Income | Fiscal Year |  |  |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  | % Change |
| Electronics | $ | 220.1 |  |  | $ | 169.9 |  |  | $ | 50.2 |  |  | 29.6 | % |
| Transportation | 84.8 |  |  | 58.6 |  |  | 26.2 |  |  | 44.7 | % |
| Industrial | 59.0 |  |  | 42.3 |  |  | 16.7 |  |  | 39.5 | % |
| Total segment operating income | 363.9 |  |  | 270.8 |  |  | 93.1 |  |  |  |
| Other (a) | (326.3) |  |  | (112.0) |  |  | (214.3) |  |  |  |
| Total operating income | $ | 37.5 |  |  | $ | 158.8 |  |  | $ | (121.2) |  |  | (76.4) | % |

[0001628280-26-009585:mdna:81]
(a) Fiscal year 2025 included $302.1 million of non-cash impairment charges, which included a $301.2 million non-cash goodwill impairment charge associated with the Electronics-Semiconductor reporting unit within the Electronics segment. In addition, the Company recognized impairment charges of $0.5 million and $0.4 million related to certain machinery and equipment in the commercial vehicle business within the Transportation segment and the electronics products business within the Electronics segment, respectively. The Company also recognized total restructuring charges of $18.0 million, primarily for employee termination costs. These charges primarily related to the reorganization of certain manufacturing, selling and administrative functions in the power semiconductor business within the Electronics segment and the reorganization of certain manufacturing, selling and administrative functions in the commercial vehicle business and automotive sensors business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.4 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $0.6 million of purchase accounting inventory adjustments related to the Basler and Dortmund Fab acquisitions, and a $0.3 million loss related to the sale of the Marine business within the Transportation segment.

[0001628280-26-009585:mdna:82]
Fiscal year 2024 included $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial Controls and Sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0001628280-26-009585:mdna:83]
Electronics Segment

[0001628280-26-009585:mdna:84]
Net Sales

[0001628280-26-009585:mdna:85]
Net sales in the Electronics segment increased $158.7 million, or 13.4%, in 2025 compared to 2024 and included $49.0 million or 4.1% of incremental sales from the Dortmund Fab acquisition in the semiconductor business and favorable changes in foreign exchange rates of $9.7 million or 0.8%. The net sales increase was primarily due to higher volume of $104.5 million from the electronics products business driven by higher end market demand.

[0001628280-26-009585:mdna:86]
Operating Income

[0001628280-26-009585:mdna:87]
Operating income was $220.1 million, representing an increase of $50.2 million, or 29.6%, in 2025 compared to $169.9 million in 2024. The increase in operating income was primarily from the electronics products business due to volume leverage. Operating margins increased from 14.3% in 2024 to 16.4% in 2025 primarily due to volume leverage from the electronics products business, partially offset by lower gross margin from the semiconductor business.

[0001628280-26-009585:mdna:88]
Transportation Segment

[0001628280-26-009585:mdna:89]
Net Sales

[0001628280-26-009585:mdna:90]
Net sales in the Transportation segment increased $4.0 million, or 0.6%, in 2025 compared to 2024 and included favorable changes in foreign exchange rates of $7.5 million or 1.1%. After factoring in the favorable changes in foreign exchange, net sales decreased by $3.5 million as the lower volume from automotive sensors driven by the strategic exit of certain lower margin products more than offset increases in the passenger car products business driven by solid demand for core passenger car products and favorable price.

[0001628280-26-009585:mdna:91]
Operating Income

[0001628280-26-009585:mdna:92]
Operating income was $84.8 million, representing an increase of $26.2 million, or 44.7%, in 2025 compared to $58.6 million in 2024. The increase in operating income was primarily from the passenger car products business due to favorable price, volume leverage, cost reduction initiatives, along with the 2024 out-of-period adjustment of $11.1 million. Operating margins increased from 8.7% in 2024 to 12.5% in 2025 primarily driven by improved gross margin from the passenger car products business, partially offset by lower gross margin in the automotive sensors business. In addition to the factors impacting operating income discussed above, the 2024 out-of-period adjustment of $11.1 million negatively impacted 2024 operating margins by 1.7%.

[0001628280-26-009585:mdna:93]
Industrial Segment

[0001628280-26-009585:mdna:94]
Net Sales

[0001628280-26-009585:mdna:95]
Net sales in the Industrial segment increased by $32.8 million, or 9.9%, in 2025 compared to 2024 and included favorable changes in foreign exchange rates of $0.4 million or 0.1%. The net sales increase was due to higher volume from  industrial circuit protection and industrial control and sensor products driven by growth from energy storage, renewables, data center and HVAC end markets and favorable price.

[0001628280-26-009585:mdna:96]
Operating Income

[0001628280-26-009585:mdna:97]
Operating income was $59.0 million, representing an increase of $16.7 million, or 39.5%, in 2025 compared to $42.3 million in 2024. The increase in operating income was driven by higher volume from industrial circuit protection and industrial control and sensor products driven by increased end market demand, favorable price and cost reductions along with the 2024 out-of-period adjustment of $4.1 million. Operating margins increased from 12.8% in 2024 to 16.2% in 2025 primarily due to higher volume, favorable price and cost reductions. In addition to the factors impacting operating income discussed above, the 2024 out-of-period adjustment related to the Industrial segment negatively impacted the 2024 operating margin by 1.2%.

[0001628280-26-009585:mdna:98]
Geographic Net Sales Information

[0001628280-26-009585:mdna:99]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0001628280-26-009585:mdna:100]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  | % Change |
| Americas | 947.9 |  |  | $ | 900.4 |  |  | $ | 47.6 |  |  | 5.3 | % |
| Asia-Pacific | 906.5 |  |  | 824.7 |  |  | 81.8 |  |  | 9.9 | % |
| Europe | 531.9 |  |  | 465.7 |  |  | 66.1 |  |  | 14.2 | % |
| Total | $ | 2,386.3 |  |  | $ | 2,190.8 |  |  | $ | 195.5 |  |  | 8.9 | % |

[0001628280-26-009585:mdna:101]
Americas

[0001628280-26-009585:mdna:102]
Net sales in the Americas increased $47.6 million, or 5.3%, in 2025 compared to 2024. The increase in net sales was primarily due to higher volume from the electronics products business within the Electronics segment and all businesses across the Industrial segment, partially offset by lower volume from the automotive sensors business within the Transportation segment and lower volume from the semiconductor business within the Electronics segment compared to 2024.

[0001628280-26-009585:mdna:103]
Asia-Pacific

[0001628280-26-009585:mdna:104]
Asia-Pacific net sales increased $81.8 million, or 9.9%, in 2025 compared to 2024 and included unfavorable changes in foreign exchange rates of $1.3 million. The increase in net sales was primarily due to higher volume from the Electronics segment,

[0001628280-26-009585:mdna:105]
industrial circuit protection products within the Industrial segment and the passenger car products business within the Transportation segment, partially offset by lower volume from the automotive sensors business within the Transportation segment compared to 2024.

[0001628280-26-009585:mdna:106]
Europe

[0001628280-26-009585:mdna:107]
Europe net sales increased $66.1 million, or 14.2%, in 2025 compared to 2024 and included $49.0 million or 10.5% of incremental net sales from the Dortmund Fab acquisition in the semiconductor business within the Electronics segment and favorable changes in foreign exchange rates of $18.9 million. After factoring in the favorable changes in exchange rates, net sales decreased due to lower power semiconductor volumes.

[0001628280-26-009585:mdna:108]
RESULTS OF OPERATIONS FOR THE YEAR ENDED DECEMBER 28, 2024 AS COMPARED TO THE YEAR ENDED DECEMBER 30, 2023

[0001628280-26-009585:mdna:109]
Fiscal year 2024 included $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial Controls and Sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial Controls and Sensors reporting unit within the Industrial segment and the Automotive Sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0001628280-26-009585:mdna:110]
Fiscal year 2023 included $28.2 million of non-segment charges, of which $11.7 million related to legal and professional fees and other integration expenses related to completed and contemplated acquisitions and $16.5 million of restructuring, impairment and other charges, primarily associated with employee termination costs and a $3.9 million impairment charge for the land and building in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment, and Other Charges, for further discussion.

[0001628280-26-009585:mdna:111]
Fiscal year 2024 also included approximately $9.2 million in foreign currency exchange gains primarily attributable to changes in the value of the Euro, Korean won, and Chinese renminbi against the U.S. dollar, while fiscal year 2023 included approximately $12.3 million in foreign currency exchange losses primarily attributable to changes in the value of the Euro, Sterling, and Chinese renminbi against the U.S. dollar.

[0001628280-26-009585:mdna:112]
|  | Fiscal Year |  |  |  |  |
| (in thousands, except % change) | 2024 |  | 2023 |  | Change |  | % Change |
| Net sales | $ | 2,190,768 |  |  | $ | 2,362,657 |  |  | $ | (171,889) |  |  | (7.3) | % |
| Cost of sales | 1,403,226 |  |  | 1,462,416 |  |  | (59,190) |  |  | (4.0) | % |
| Gross profit | 787,542 |  |  | 900,241 |  |  | (112,699) |  |  | (12.5) | % |
| Operating expenses | 628,762 |  |  | 539,379 |  |  | 89,383 |  |  | 16.6 | % |
| Operating income | 158,780 |  |  | 360,862 |  |  | (202,082) |  |  | (56.0) | % |
| Other income, net | (22,570) |  |  | (19,901) |  |  | 2,669 |  |  | 13.4 | % |
| Income before income taxes | 151,863 |  |  | 328,598 |  |  | (176,735) |  |  | (53.8) | % |
| Income taxes | 51,673 |  |  | 69,113 |  |  | (17,440) |  |  | (25.2) | % |
| Net income | 100,190 |  |  | 259,485 |  |  | (159,295) |  |  | (61.4) | % |

[0001628280-26-009585:mdna:113]
Net Sales

[0001628280-26-009585:mdna:114]
Net sales were $2,190.8 million, which decreased by $171.9 million, or 7.3% compared to 2023, including $7.9 million of unfavorable changes in foreign exchange rates for 2024 compared to 2023. The net sales decrease was primarily due to lower

[0001628280-26-009585:mdna:115]
volume of $163.7 million in the Electronics segment, primarily driven by reduced demand and inventory rebalancing in the semiconductor business.

[0001628280-26-009585:mdna:116]
Cost of Sales

[0001628280-26-009585:mdna:117]
Cost of sales was $1,403.2 million, or 64.1% of net sales, in 2024 compared to $1,462.4 million, or 61.9% of net sales, in 2023. As a percent of net sales, cost of sales increased 2.2% driven by lower volume in the Electronics segment, partially offset by improved margin from all businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives. In addition, during the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that were corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The error that was identified by management related to the valuation and existence of inventory that originated in prior periods at certain of our non-U.S. manufacturing locations within the Transportation and Industrial segments. As a result, the Company recorded an out-of-period adjustment of $13.5 million in the year ended December 28, 2024, of which $12.3 million was the cumulative out-of-period adjustment related to fiscal years prior to 2024. The out-of-period adjustment negatively impacted cost of sales as percentage of net sales by 0.6%.

[0001628280-26-009585:mdna:118]
Gross Profit

[0001628280-26-009585:mdna:119]
Gross profit was $787.5 million, or 35.9% of net sales, in 2024, compared to $900.2 million, or 38.1% of net sales, in 2023. The $112.7 million decrease in gross profit was primarily due to lower volume in the Electronics and Industrial segments, partially offset by improved margin from all businesses within the Transportation segment driven by favorable price, product mix and cost reduction initiatives. As mentioned above, the out-of-period adjustments of $13.5 million negatively impacted gross margin by 0.6%.

[0001628280-26-009585:mdna:120]
Operating Expenses

[0001628280-26-009585:mdna:121]
Total operating expenses were $628.8 million, or 28.7% of net sales, for 2024 compared to $539.4 million, or 22.8% of net sales, for 2023. The increase in operating expenses of $89.4 million was primarily due to an increase in restructuring, impairment, and other charges of $91.9 million, which included a non-cash impairment charge of $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. Additionally, the Company incurred higher research and development expenses of $5.3 million. These increases in operating expenses were partially offset by lower selling, general, and administrative expenses of $4.2 million as a result of lower legal and professional fees and other integration expenses related to completed and contemplated acquisitions and lower amortization expense of $3.7 million.

[0001628280-26-009585:mdna:122]
Operating Income

[0001628280-26-009585:mdna:123]
Operating income for 2024 was $158.8 million, a decrease of $202.1 million or 56.0% compared to $360.9 million for 2023.  The decrease in operating income was due to lower operating income of $130.7 million from the Electronics segment and higher operating expenses due to the non-cash charge of $92.6 million from the impairment of intangible assets and goodwill as noted above, partially offset by higher operating income of $24.9 million from the Transportation segment. Operating margins decreased from 15.3% in 2023 to 7.2% in 2024 primarily driven by lower volume in the Electronics segment and the higher operating expenses mentioned above. The total non-cash charges of $92.6 million from the impairment of intangible assets and goodwill negatively impacted the 2024 operating margin by 4.2%.

[0001628280-26-009585:mdna:124]
Income Before Income Taxes

[0001628280-26-009585:mdna:125]
Income before income taxes for 2024 was $151.9 million, or 6.9% of net sales compared to $328.6 million, or 13.9% of net sales for 2023. In addition to the factors impacting comparative results for operating income discussed above, income before income taxes was primarily benefited by foreign exchange gains of $9.2 million in the fiscal year 2024 compared to foreign exchange losses of $12.3 million in the fiscal year 2023, and higher interest income of $9.0 million from short-term investments in cash equivalents, partially offset by higher coal mine charges of $1.8 million and non-operating pension expense.

[0001628280-26-009585:mdna:126]
Income Taxes

[0001628280-26-009585:mdna:127]
Income tax expense for 2024 was $51.7 million, or an effective tax rate of 34.0%, compared to income tax expense of $69.1 million, or an effective tax rate of 21.0% for 2023. The effective tax rate for 2024 is higher than the effective tax rate for 2023,

[0001628280-26-009585:mdna:128]
primarily due to the impact of goodwill impairments and non-US losses with no related tax benefit. The effective tax rate for 2024 is higher than the statutory tax rate primarily due to the impact of goodwill impairments and non-US losses with no related tax benefit as previously noted. Further information regarding these items is provided in Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001628280-26-009585:mdna:129]
Segment Information

[0001628280-26-009585:mdna:130]
The Company reports its operations by the following segments: Electronics, Transportation and Industrial. Segment information is described more fully in Note 16, Segment Information, of the Notes to Consolidated Financial Statements included in this Annual Report.

[0001628280-26-009585:mdna:131]
The following table is a summary of the Company’s net sales and operating income by segment:

[0001628280-26-009585:mdna:132]
| Net Sales | Fiscal Year |  |  |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  | % Change |
| Electronics | $ | 1,186.8 |  |  | $ | 1,350.4 |  |  | $ | (163.7) |  |  | (12.1) | % |
| Transportation | 672.4 |  |  | 678.3 |  |  | (5.9) |  |  | (0.9) | % |
| Industrial | 331.6 |  |  | 334.0 |  |  | (2.4) |  |  | (0.7) | % |
| Total | $ | 2,190.8 |  |  | $ | 2,362.7 |  |  | $ | (171.9) |  |  | (7.3) | % |

[0001628280-26-009585:mdna:133]
| Segment Operating Income | Fiscal Year |  |  |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  | % Change |
| Electronics | $ | 169.9 |  |  | $ | 300.6 |  |  | $ | (130.7) |  |  | (43.5) | % |
| Transportation | 58.6 |  |  | 33.7 |  |  | 24.9 |  |  | 73.9 | % |
| Industrial | 42.3 |  |  | 54.8 |  |  | (12.5) |  |  | (22.8) | % |
| Total segment operating income | 270.8 |  |  | 389.1 |  |  | (118.3) |  |  |  |
| Other (a) | (112.0) |  |  | (28.2) |  |  | (83.8) |  |  |  |
| Total Operating income | $ | 158.8 |  |  | $ | 360.9 |  |  | $ | (202.1) |  |  | (56.0) | % |

[0001628280-26-009585:mdna:134]
(a) Included in “Other” Operating income for the 2024 was $93.5 million of non-cash impairment charges, which included $47.8 million for the impairment of intangible assets primarily related to certain acquired customer relationships, developed technology, and tradename in the Industrial controls and sensors reporting unit within the Industrial segment, and $36.1 million and $8.6 million of non-cash goodwill impairment charges associated with the Industrial controls and sensors reporting unit within the Industrial segment and the Automotive sensors reporting unit within the Transportation segment, respectively. The remaining impairment charges included $0.2 million for patents and customer relationships related to the exit of a small business in China within the Industrial segment. In addition, during the first quarter of 2024, the Company recognized a $0.9 million impairment charge related to certain machinery and equipment in the commercial vehicle business within the Transportation segment. The Company also recognized total restructuring charges of $14.9 million, primarily for employee termination costs related to the reorganization of certain manufacturing, selling and administrative functions in the semiconductor business within the Electronics segment and the reorganization of certain selling and administrative functions in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion. Also included in "Other" Operating income was $5.1 million of legal and professional fees and other integration expenses related to completed and contemplated acquisitions, a gain of $1.0 million for the sale of two buildings within the Transportation segment, and a gain of $0.5 million recorded for the sale of a land use right within the Electronics segment.

[0001628280-26-009585:mdna:135]
Included in “Other” Operating income for the 2023 was $28.2 million of non-segment charges, of which $11.7 million was for legal and professional fees and other integration expenses related to completed and contemplated acquisitions, $16.5 million of restructuring, impairment and other charges, primarily related to employee termination costs and a $3.9 million impairment charge related to the land and building in the commercial vehicle business within the Transportation segment. See Note 8, Restructuring, Impairment and Other Charges, for further discussion.

[0001628280-26-009585:mdna:136]
Electronics Segment

[0001628280-26-009585:mdna:137]
Net Sales

[0001628280-26-009585:mdna:138]
Net sales for the Electronics segment decreased $163.7 million, or 12.1%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $4.3 million or 0.3%. The net sales decrease was mainly due to lower volume from the semiconductor business of $152.0 million and to a lesser extent the electronics products business driven by inventory rebalancing at certain distributors and reduced demand across certain electronics markets, including consumer facing and personal electronics, as well as industrial markets.

[0001628280-26-009585:mdna:139]
Operating Income

[0001628280-26-009585:mdna:140]
Operating income was $169.9 million, representing a decrease of $130.7 million, or 43.5%, in 2024 compared to $300.6 million in 2023. The decrease in operating income was primarily due to lower volume leverage and unfavorable product mix that were partially offset by cost control initiatives. Operating margins decreased from 22.3% in 2023 to 14.3% in 2024 primarily due to the lower volume from the semiconductor business.

[0001628280-26-009585:mdna:141]
Transportation Segment

[0001628280-26-009585:mdna:142]
Net Sales

[0001628280-26-009585:mdna:143]
Net sales in the Transportation segment decreased $5.9 million, or 0.9%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $2.4 million or 0.4%. The sales decrease was mainly driven by lower volume of $15.0 million and $3.2 million from the automotive sensors and the commercial vehicles businesses, respectively, due to the strategic exit of certain lower margin products and reduced demand largely due to inventory rebalancing at certain distributors and customers, partially offset by a sales increase of $12.3 million from the passenger car business driven by the ongoing electronification and electrification of vehicles and vehicle content growth.

[0001628280-26-009585:mdna:144]
Operating Income

[0001628280-26-009585:mdna:145]
Operating income was $58.6 million, representing an increase of $24.9 million, or 73.9%, in 2024 compared to $33.7 million in 2023. The increase in operating income was primarily due to favorable price and cost reduction initiatives from the commercial vehicle business. Operating margins increased from 5.0% to 8.7% primarily driven by favorable price and product mix and cost reduction initiatives from the commercial vehicle business. In addition, as mentioned above, during the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that were corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The out-of-period adjustment related to the Transportation segment was $11.1 million, which negatively impacted operating margin by 1.7%.

[0001628280-26-009585:mdna:146]
Industrial Segment

[0001628280-26-009585:mdna:147]
Net Sales

[0001628280-26-009585:mdna:148]
The Industrial segment net sales decreased by $2.4 million, or 0.7%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $1.2 million or 0.4%. The sales decrease was due to lower volume across industrial control products driven by softer end market demand in the first half of 2024.

[0001628280-26-009585:mdna:149]
Operating Income

[0001628280-26-009585:mdna:150]
Operating income was $42.3 million, representing a decrease of $12.5 million, or 22.8%, in 2024 compared to $54.8 million in 2023. The decrease in operating income was driven by lower volume due to reduced industrial end market demand across industrial control products and industrial circuit protection along with cost inflation. Operating margins were 12.8% in 2024 compared to 16.4% in 2023. The decrease in operating margin was due to cost inflation, partially offset by favorable price. In addition, as mentioned above, during the year ended December 28, 2024, the Company identified certain errors in its previously issued financial statements that were corrected through cumulative out-of-period adjustments in the financial statements as of and for the year ended December 28, 2024. The out-of-period adjustment related to the Industrial segment was $4.1 million, which negatively impacted operating margin by 1.2%.

[0001628280-26-009585:mdna:151]
Geographic Net Sales Information

[0001628280-26-009585:mdna:152]
Net sales by geography represent net sales to customer or distributor locations. The following table is a summary of the Company’s net sales by geography:

[0001628280-26-009585:mdna:153]
|  | Fiscal Year |  |  |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  | % Change |
| Americas | $ | 900.4 |  |  | $ | 901.5 |  |  | $ | (1.1) |  |  | (0.1) | % |
| Asia-Pacific | 824.7 |  |  | 898.9 |  |  | (74.2) |  |  | (8.3) | % |
| Europe | 465.7 |  |  | 562.3 |  |  | (96.6) |  |  | (17.2) | % |
| Total | $ | 2,190.8 |  |  | $ | 2,362.7 |  |  | $ | (171.9) |  |  | (7.3) | % |

[0001628280-26-009585:mdna:154]
Americas

[0001628280-26-009585:mdna:155]
Net sales in the Americas decreased $1.1 million, or 0.1%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $0.7 million. The decrease in net sales was primarily due to lower volume from the semiconductor business within the Electronics segment, partially offset by higher volume from the Industrial segment and the commercial vehicle and passenger car products businesses within the Transportation segment compared to 2023.

[0001628280-26-009585:mdna:156]
Asia-Pacific

[0001628280-26-009585:mdna:157]
Asia-Pacific net sales decreased $74.2 million, or 8.3%, in 2024 compared to 2023 and included unfavorable changes in foreign exchange rates of $9.2 million. The decrease in net sales was primarily due to lower net sales from the semiconductor business within the Electronics segment and the industrial circuit protection business within the Industrial segment, partially offset by higher net sales from the passenger car products business within the Transportation segment compared to 2023.

[0001628280-26-009585:mdna:158]
Europe

[0001628280-26-009585:mdna:159]
Europe net sales decreased $96.6 million, or 17.2%, in 2024 compared to 2023 and included favorable changes in foreign exchange rates of $2.0 million. The decrease in net sales was primarily due to lower net sales from the Electronics segment and lower net sales from the commercial vehicle and automotive sensors businesses within the Transportation segment compared to 2023.

[0001628280-26-009585:mdna:160]
Liquidity and Capital Resources

[0001628280-26-009585:mdna:161]
Cash and cash equivalents were $563.4 million as of December 27, 2025, a decrease of $161.5 million as compared to December 28, 2024.

[0001628280-26-009585:mdna:162]
As of December 27, 2025, $419.1 million of the Company's $563.4 million cash and cash equivalents was held by non-U.S. subsidiaries. Of the $419.1 million, at least $230.4 million can be repatriated with minimal tax consequences, although in certain cases a non-U.S. withholding tax would be payable but subsequently refunded. With respect to the remaining $188.7 million, the Company has recognized deferred tax liabilities on approximately $114.4 million as of December 27, 2025 because the amounts are not considered to be permanently reinvested, and the Company may access additional amounts through loans and other means. Repatriation of some non-U.S. cash balances is restricted by local laws. Management regularly evaluates whether foreign earnings are expected to be permanently reinvested. This evaluation requires judgment about the future operating and liquidity needs of the Company and its foreign subsidiaries. Changes in economic and business conditions and tax laws could result in changes to these judgments and the need to record additional tax liabilities.

[0001628280-26-009585:mdna:163]
The Company has historically supported its liquidity needs through cash flows from operations. Management expects that the Company’s (i) current level of cash, cash equivalents, and marketable securities, (ii) current and forecasted cash flows from operations, (iii) availability under existing funding arrangements, and (iv) access to capital in the capital markets will provide sufficient funds to support the Company’s operations, capital expenditures, investments, and debt obligations on both a short-term and long-term basis.

[0001628280-26-009585:mdna:164]
Revolving Credit Facility and Term Loan

[0001628280-26-009585:mdna:165]
On June 30, 2022, the Company amended and restated its Credit Agreement, dated as of April 3, 2020 (as so amended and restated, the “Credit Agreement”) to effect certain changes, including, among other changes: (i) adding a $300 million unsecured term loan credit facility; (ii) making certain financial and non-financial covenants less restrictive on the Company and its subsidiaries; (iii) replacing LIBOR-based interest rate benchmarks and modifying performance-based interest rate margins; and (iv) extending the maturity date to June 30, 2027 (the “Maturity Date”). Pursuant to the Credit Agreement, the Company may, from time to time, increase the size of the revolving credit facility or enter into one or more tranches of term loans in minimum increments of $25 million if there is no event of default and the Company is in compliance with certain financial covenants.

[0001628280-26-009585:mdna:166]
Loans made under the available credit facility pursuant to the Credit Agreement (the "Credit Facility") bear interest at the Company’s option, at either Secured Overnight Financing Rate ("SOFR"), fixed for interest periods of one, two, three or six-month periods, plus 1.00% to 1.75%, plus a SOFR adjustment of 0.10% or at the bank’s Base Rate, as defined in the Credit Agreement, plus 0.00% to 0.75%, based upon the Company’s Consolidated Leverage Ratio, as defined in the Credit Agreement. The Company is also required to pay commitment fees on unused portions of the Credit Facility ranging from 0.10% to 0.175%, based on the Consolidated Leverage Ratio, as defined in the Credit Agreement. The Credit Agreement includes representations, covenants and events of default that are customary for financing transactions of this nature.

[0001628280-26-009585:mdna:167]
Under the Credit Agreement, revolving loans may be borrowed, repaid and reborrowed until the Maturity Date, at which time all amounts borrowed must be repaid. The Company borrowed $300.0 million under a term loan on June 30, 2022. The principal balance of the term loans must be repaid in quarterly installments on the last day of each calendar quarter in the amount of $1.9 million commencing September 30, 2022, through June 30, 2024, and in the amount of $3.8 million commencing September 30, 2024, through March 31, 2027, with the remaining outstanding principal balance payable in full on the Maturity Date. Accrued interest on the loans is payable in arrears on each interest payment date applicable thereto and at such other times as may be specified in the Credit Agreement. Subject to certain conditions, (i) the Company may terminate or reduce the Aggregate Revolving Commitments, as defined in the Credit Agreement, in whole or in part, and (ii) the Company may prepay the revolving loans or the term loans at any time, without premium or penalty. During the fiscal year ended December 27, 2025, the Company made term loan payments of $15.0 million. The revolving loan and term loan balance under the Credit Facility was $100.0 million and $266.3 million, respectively, as of December 27, 2025.

[0001628280-26-009585:mdna:168]
On May 12, 2022, the Company entered into an interest rate swap agreement to manage interest rate risk exposure, effectively converting the interest rate on the Company's SOFR based floating-rate loans to a fixed-rate. The interest rate swap, with a notional value of $200 million, was designated as a cash flow hedge against the variability of cash flows associated with the Company's SOFR based loans scheduled to mature on June 30, 2027.

[0001628280-26-009585:mdna:169]
As of December 27, 2025, the effective interest rate on unhedged portion of the outstanding borrowings under the Credit Facility was 4.82%, and 3.88% on the hedged portion.

[0001628280-26-009585:mdna:170]
As of December 27, 2025, the Company had $1.1 million outstanding letters of credit and had available $598.9 million of borrowing capacity under the revolving credit facility. As of December 27, 2025, the Company was in compliance with all covenants under the credit agreement.

[0001628280-26-009585:mdna:171]
Senior Notes

[0001628280-26-009585:mdna:172]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold €212 million aggregate principal amount of senior notes in two series. The funding date for the Euro denominated senior notes occurred on December 8, 2016 for €117 million in aggregate amount of 1.14% Senior Notes, Series A, due December 8, 2023 (“Euro Senior Notes, Series A due 2023”), and €95 million in aggregate amount of 1.83% Senior Notes, Series B due December 8, 2028 (“Euro Senior Notes, Series B due 2028”) (together, the “Euro Senior Notes”). During the fiscal year ended December 30, 2023, the Company paid off €117 million of Euro Senior Notes, Series A due 2023. Interest on the Euro Senior Notes, Series B due 2028 is payable semiannually on June 8 and December 8, commencing June 8, 2017.

[0001628280-26-009585:mdna:173]
On December 8, 2016, the Company entered into a Note Purchase Agreement, pursuant to which the Company issued and sold $125 million aggregate principal amount of senior notes in two series. On February 15, 2017, $25 million in aggregate principal amount of 3.03% Senior Notes, Series A, due February 15, 2022 (“U.S. Senior Notes, Series A due 2022”), and $100 million in aggregate principal amount of 3.74% Senior Notes, Series B, due February 15, 2027 (“U.S. Senior Notes, Series B due 2027”) (together, the “U.S. Senior Notes due 2022 and 2027”) were funded. During the fiscal year ended December 31, 2022, the Company paid off $25 million of U.S. Senior Notes, Series A due 2022. Interest on the U.S. Senior Notes, Series B due 2027 is payable semiannually on February 15 and August 15, commencing August 15, 2017.

[0001628280-26-009585:mdna:174]
On November 15, 2017, the Company entered into a Note Purchase Agreement pursuant to which the Company issued and sold $175 million in aggregate principal amount of senior notes in two series. On January 16, 2018, $50 million aggregate principal amount of 3.48% Senior Notes, Series A, due February 15, 2025 (“U.S. Senior Notes, Series A due 2025”) and $125 million in aggregate principal amount of 3.78% Senior Notes, Series B, due February 15, 2030 (“U.S. Senior Notes, Series B due 2030”) (together, the “U.S. Senior Notes due 2025 and 2030”) were funded. During the first fiscal quarter of 2025, the Company paid

[0001628280-26-009585:mdna:175]
off $50 million of U.S. Senior Notes, Series A due 2025. Interest on the U.S. Senior Notes Series B due 2030 is payable on February 15 and August 15, commencing on August 15, 2018.

[0001628280-26-009585:mdna:176]
On May 18, 2022, the above note purchase agreements were amended to, among other things, update certain terms, including financial covenants to be consistent with the terms of the amended and restated Credit Agreement and the 2022 Purchase Agreement, as defined below.

[0001628280-26-009585:mdna:177]
On May 18, 2022, the Company entered into a Note Purchase Agreement (“2022 Purchase Agreement”) pursuant to which the Company issued and funded on July 18, 2022 $100 million in aggregate principal amount of 4.33% Senior Notes, due June 30, 2032 (“U.S. Senior Notes, due 2032”) (together with the U.S. Senior Notes due 2025 and 2030, the Euro Senior Notes and the U.S. Senior Notes due 2022 and 2027, the “Senior Notes”). Interest on the U.S. Senior Notes due 2032 is payable semiannually on June 30 and December 30, commencing on December 30, 2022.

[0001628280-26-009585:mdna:178]
The Senior Notes have not been registered under the Securities Act, or applicable state securities laws. The Senior Notes are general unsecured senior obligations and rank equal in right of payment with all existing and future unsecured unsubordinated indebtedness of the Company.

[0001628280-26-009585:mdna:179]
The Senior Notes are subject to certain customary covenants, including limitations on the Company’s ability, with certain exceptions, to engage in mergers, consolidations, asset sales and transactions with affiliates, to engage in any business that would substantially change the general business of the Company, and to incur liens. In addition, the Company is required to satisfy certain financial covenants and tests relating to, among other matters, interest coverage and leverage. As of December 27, 2025, the Company was in compliance with all covenants under the Senior Notes.

[0001628280-26-009585:mdna:180]
The Company may redeem the Senior Notes upon the satisfaction of certain conditions and the payment of a make-whole amount to note holders and is required to offer to repurchase the Senior Notes at par following certain events, including a change of control.

[0001628280-26-009585:mdna:181]
Debt Covenants

[0001628280-26-009585:mdna:182]
The Company was in compliance with its debt covenants as of December 27, 2025. As of December 27, 2025, the Company met all the conditions required to borrow under the Credit Agreement and management expects the Company to continue to meet the applicable borrowing conditions.

[0001628280-26-009585:mdna:183]
Acquisitions

[0001628280-26-009585:mdna:184]
On December 11, 2025, the Company completed the acquisition of Basler. Basler is a leading designer and manufacturer of innovative electrical control and protection solutions for high-growth industrial markets including grid and utility infrastructure, power generation and data center. At the time of acquisition, Basler had annualized sales of approximately $130 million. The business is reported within the Company’s Industrial segment. The total purchase consideration was $350.3 million, net of cash acquired, subject to a working capital adjustment. The acquisition was funded with the Company's cash on hand.

[0001628280-26-009585:mdna:185]
On December 31, 2024, the Company completed the acquisition of a 200mm wafer fab located in Dortmund, Germany (“Dortmund Fab”) from Elmos Semiconductor SE. The Dortmund Fab will increase power semiconductor capacity to support opportunities across a broad base of industrial end markets including energy storage, automation, motor drives, renewables, power supplies, and charging infrastructure. The total purchase price for the Dortmund Fab was approximately €94 million, of which a €37.2 million down payment (approximately $40.5 million) was paid in the third quarter of 2023 after regulatory approvals, and €56.7 million (approximately $58.8 million) was paid at closing. The business is reported in the Electronics-Semiconductor business within the Company’s Electronics segment. The acquisition was funded with the Company’s cash on hand.

[0001628280-26-009585:mdna:186]
On February 3, 2023, the Company completed the acquisition of Western Automation for approximately $162 million in cash. Headquartered in Galway, Ireland, Western Automation is a designer and manufacturer of electrical shock protection devices used across a broad range of high-growth end markets, including electric vehicle charging infrastructure, industrial safety and renewables. At the time the Company and Western Automation entered into the definitive agreement, Western Automation had annualized sales of approximately $25 million. The business is reported within the Company’s Industrial segment. The Company financed the transaction with cash on hand.

[0001628280-26-009585:mdna:187]
Cash Flow Overview

[0001628280-26-009585:mdna:188]
Operating cash inflows are largely attributable to sales of the Company’s products. Operating cash outflows are largely attributable to recurring expenditures for raw materials, labor, rent, interest, taxes, and other operating activities.

[0001628280-26-009585:mdna:189]
The following describes the Company’s cash flows for the fiscal year ended December 27, 2025 and December 28, 2024:

[0001628280-26-009585:mdna:190]
|  | Fiscal Year |
| (in millions) | 2025 |  | 2024 |
| Net cash provided by operating activities | $ | 433.8 |  |  | $ | 367.6 |  |
| Net cash used in investing activities | (468.9) |  |  | (65.8) |  |
| Net cash used in financing activities | (149.3) |  |  | (112.4) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 23.0 |  |  | (20.1) |  |
| (Decrease) increase in cash, cash equivalents, and restricted cash | (161.3) |  |  | 169.3 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 726.4 |  |  | 557.1 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 565.1 |  |  | $ | 726.4 |  |

[0001628280-26-009585:mdna:191]
Cash Flow from Operating Activities

[0001628280-26-009585:mdna:192]
Net cash provided by operating activities was $433.8 million in the fiscal year 2025, an increase of $66.1 million, compared to $367.6 million in the fiscal year 2024. The increase in net cash provided by operating activities was primarily due to higher cash earnings.

[0001628280-26-009585:mdna:193]
Cash Flow from Investing Activities

[0001628280-26-009585:mdna:194]
Net cash used in investing activities was $468.9 million in the fiscal year 2025, compared to $65.8 million in the fiscal year 2024. Net cash paid for acquisitions was $407.7 million for the Basler and Dortmund Fab acquisitions in the fiscal year 2025. Capital expenditures were $67.6 million, representing a decrease of $8.2 million compared to the fiscal year 2024. The Company also received proceeds of $5.6 million mainly from the sale of the Marine business within the Transportation segment in the fiscal year 2025 as compared to proceeds of $10.8 million from the sale of a land use right within the Electronics segment and two buildings from the Transportation segment in the fiscal year 2024.

[0001628280-26-009585:mdna:195]
Cash Flow from Financing Activities

[0001628280-26-009585:mdna:196]
Net cash used in financing activities was $149.3 million in the fiscal year 2025 compared to $112.4 million in the fiscal year 2024. During the fiscal year 2025, the Company paid $50 million of U.S. Senior Notes, Series A, due February 15, 2025 and $15.0 million on the term loan under the Credit Facility. During the fiscal year 2024, the Company paid $7.5 million on the term loan. The Company paid dividends of $72.0 million, an increase of $4.9 million, in the fiscal year 2025 compared to $67.1 million in the fiscal year 2024. In addition, the Company repurchased 120,689 shares and 179,311 shares of its common stock totaling $27.4 million and $40.9 million during the fiscal year 2025 and 2024, respectively. The Company paid a $0.2 million excise tax related to the share repurchases during the fiscal year 2025. Additionally, the Company received $22.6 million of net proceeds from stock option exercises and restricted stock units vesting activities during the fiscal year 2025 compared to $5.7 million in the fiscal year 2024.

[0001628280-26-009585:mdna:197]
The following describes the Company’s cash flows for the fiscal year ended December 28, 2024 and December 30, 2023:

[0001628280-26-009585:mdna:198]
|  | Fiscal Year |
| (in millions) | 2024 |  | 2023 |
| Net cash provided by operating activities | $ | 367.6 |  |  | $ | 457.4 |  |
| Net cash used in investing activities | (65.8) |  |  | (284.3) |  |
| Net cash used in financing activities | (112.4) |  |  | (185.7) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (20.1) |  |  | 4.8 |  |
| Increase (decrease) in cash, cash equivalents, and restricted cash | 169.3 |  |  | (7.8) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 557.1 |  |  | 564.9 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 726.4 |  |  | $ | 557.1 |  |

[0001628280-26-009585:mdna:199]
Cash Flow from Operating Activities

[0001628280-26-009585:mdna:200]
Net cash provided by operating activities was $367.6 million for the fiscal year 2024, a decrease of $89.8 million, compared to $457.4 million during the fiscal year 2023. The decrease in net cash provided by operating activities was primarily due to lower cash earnings.

[0001628280-26-009585:mdna:201]
Cash Flow from Investing Activities

[0001628280-26-009585:mdna:202]
Net cash used in investing activities was $65.8 million for the fiscal year 2024, compared to $284.3 million during the fiscal year 2023. Net cash paid for acquisitions was $198.8 million for the Western Automation and Dortmund Fab acquisitions during the fiscal year 2023. Capital expenditures were $75.9 million, representing a decrease of $10.3 million compared to the fiscal year 2023. The Company also received proceeds of $10.8 million mainly from the sale of a land use right within the Electronics segment and two buildings from the Transportation segment during the fiscal year 2024 as compared to proceeds of $0.8 million from the sale of a property within the Electronics segment during the fiscal year 2023.

[0001628280-26-009585:mdna:203]
Cash Flow from Financing Activities

[0001628280-26-009585:mdna:204]
Net cash used in financing activities was $112.4 million for the fiscal year 2024 compared to $185.7 million during the fiscal year 2023. During the fiscal year 2024, the Company paid $7.5 million on the term loan. During the fiscal year 2023, the Company paid $121.3 million (€117 million) of Euro Senior Notes, Series A due 2023 and $7.5 million on the term loan. The Company paid dividends of $67.1 million and $62.2 million for the fiscal year 2024 and 2023, respectively, representing an increase of $4.9 million from the fiscal year 2023. Additionally, the Company repurchased 179,311 shares of its common stock totaling $40.9 million during the fiscal year 2024.

[0001628280-26-009585:mdna:205]
Contractual Obligations and Commitments

[0001628280-26-009585:mdna:206]
The following table summarizes outstanding contractual obligations and commitments as of December 27, 2025:

[0001628280-26-009585:mdna:207]
|  | Payments Due by Period |
| (in thousands) | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | Greaterthan 5 Years |
| Total debt(a) | $ | 804,460 |  |  | $ | 96,233 |  |  | $ | 483,227 |  |  | $ | 125,000 |  |  | $ | 100,000 |  |
| Interest payments(b) | 86,960 |  |  | 32,270 |  |  | 32,447 |  |  | 15,748 |  |  | 6,495 |  |
| Operating and finance lease payments(c) | 102,348 |  |  | 15,376 |  |  | 28,263 |  |  | 23,618 |  |  | 35,091 |  |
| Purchase obligations(d) | 16,574 |  |  | 14,692 |  |  | 1,882 |  |  | — |  |  | — |  |
| Total | $ | 1,010,342 |  |  | $ | 158,571 |  |  | $ | 545,819 |  |  | $ | 164,366 |  |  | $ | 141,586 |  |

[0001628280-26-009585:mdna:208]
(a)Excludes offsetting issuance costs of $1.8 million. Euro denominated debt amounts are converted based on the Euro to U.S. Dollar spot rate at year end. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0001628280-26-009585:mdna:209]
(b)Amounts represent estimated contractual interest payments on outstanding debt. Rates in effect as of December 27, 2025 are used for variable rate debt. For more information see Note 9, Debt, of the Notes to Consolidated Financial Statements.

[0001628280-26-009585:mdna:210]
(c)For more information see Note 7, Lease Commitments, of the Notes to Consolidated Financial Statements.

[0001628280-26-009585:mdna:211]
(d)Purchase obligations include purchase commitments and commitments for capital expenditures not recognized in the Company’s Consolidated Balance Sheets.

[0001628280-26-009585:mdna:212]
In addition to the above contractual obligations and commitments, the Company had the following obligations at December 27, 2025:

[0001628280-26-009585:mdna:213]
The Company has Company-sponsored defined benefit pension plans covering employees at various non-U.S. subsidiaries including the U.K., Germany, the Philippines, China, Japan, Mexico, Italy, and France. At December 27, 2025, the Company had a net unfunded status of $40.2 million. The Company expects to make approximately $1.5 million of contributions to the plans and pay $2.3 million of benefits directly in 2026. For additional information, see Note 11, Benefit Plans, of the Notes to Consolidated Financial Statements.

[0001628280-26-009585:mdna:214]
Dividends

[0001628280-26-009585:mdna:215]
Cash dividends paid totaled $72.0 million, $67.1 million and $62.2 million for 2025, 2024 and 2023, respectively. On January 28, 2026, the Board of Directors of the Company declared a quarterly cash dividend of $0.75 per share, payable on March 5, 2026 to stockholders of record as of February 19, 2026.

[0001628280-26-009585:mdna:216]
Capital Resources

[0001628280-26-009585:mdna:217]
The Company expends capital to support its operating and strategic plans. Such expenditures include strategic acquisitions, investments to maintain capital assets, develop new products or improve existing products, and to enhance capacity or productivity. Many of the associated projects have long lead-times and require commitments in advance of actual spending.

[0001628280-26-009585:mdna:218]
Share Repurchase Program

[0001628280-26-009585:mdna:219]
The Company's Board of Directors authorized the repurchase of up to $300 million in the aggregate of shares of the Company’s common stock for the period May 1, 2021 to April 30, 2024 ("2021 program"). On April 25, 2024, the Company's Board of Directors authorized a new three-year program to repurchase up to $300.0 million in the aggregate of shares of the Company's stock for the period May 1, 2024 to April 30, 2027 ("2024 program") to replace the expired 2021 program.

[0001628280-26-009585:mdna:220]
During the fiscal year of 2025, the Company repurchased 120,689 shares of its common stock totaling $27.4 million pursuant to the 2024 program. There is $270.6 million of an authorized amount not yet purchased under the 2024 program as of December 27, 2025. During the fiscal year of 2024, the Company repurchased 179,311 shares of its common stock totaling $40.9 million, of which, $38.9 million was pursuant to the 2021 program and $2.0 million was pursuant to the 2024 program. During the fiscal year of 2023, the Company did not repurchase any shares of its common stock.

[0001628280-26-009585:mdna:221]
Off-Balance Sheet Arrangements

[0001628280-26-009585:mdna:222]
As of December 27, 2025, the Company did not have any off-balance sheet arrangements, as defined under SEC rules. Specifically, the Company was not liable for guarantees of indebtedness owed by third parties, the Company was not directly liable for the debt of any unconsolidated entity and the Company did not have any retained or contingent interest in assets. The Company does not participate in transactions that generate relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities.

[0001628280-26-009585:mdna:223]
Recent Accounting Pronouncements

[0001628280-26-009585:mdna:224]
Recently issued accounting standards and their estimated effect on the Company’s Consolidated Financial Statements are described in Note 1, Summary of Significant Accounting Policies and Other Information, of the Notes to Consolidated Financial Statements.
